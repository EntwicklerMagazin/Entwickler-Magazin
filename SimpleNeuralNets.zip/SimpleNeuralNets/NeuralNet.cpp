#include "NeuralNet.h"

using namespace std;



static CRandomNumbersNN RandomNumbers;

static constexpr float constMinRandomOutputSynapsePlasticity = -0.0001f;
static constexpr float constMaxRandomOutputSynapsePlasticity = 0.0001f;



// Konstruktor:
CRandomNumbersNN::
CRandomNumbersNN() : newValue(1)
{}

// Destruktor:
CRandomNumbersNN::
~CRandomNumbersNN()
{}

/* Neuen Startwert f�r die Berechnung der
Zufallszahlen festlegen */
void CRandomNumbersNN::Change_Seed(
	uint64_t newSeed)
{
	newValue = newSeed;
}

/* Startwert f�r die Berechnung der Zufallszahlen
auf 1 zur�cksetzen */
void CRandomNumbersNN::Reset_Seed(void)
{
	newValue = 1;
}

// zuf�llige 32-Bit-Flie�kommazahlen:
float CRandomNumbersNN::
Get_FloatNumber(float low, float high)
{
	

	newValue = (newValue*constParkMillerMultiplier) %
		constParkMillerModulus;

	float value = low + (high - low)*
		((double)newValue / fconstParkMillerModulus);

	if (value == 0.0f)
		value = 0.0001f;

	return value;
}

float CRandomNumbersNN::
Get_FloatNumber_IncludingZero(float low, float high)
{
	

	newValue = (newValue*constParkMillerMultiplier) %
		constParkMillerModulus;

	float value = low + (high - low)*
		((double)newValue / fconstParkMillerModulus);

	return value;
}

// zuf�llige 64-Bit-Flie�kommazahlen:
double CRandomNumbersNN::
Get_DoubleNumber(double low, double high)
{
	

	newValue = (newValue*constParkMillerMultiplier) %
		constParkMillerModulus;

	double value = low + (high - low)*
		((double)newValue / fconstParkMillerModulus);

	if (value == 0.0)
		value = 0.0001;

	return value;
}

// zuf�llige 64-Bit-Flie�kommazahlen:
double CRandomNumbersNN::
Get_DoubleNumber_IncludingZero(double low, double high)
{
	

	newValue = (newValue*constParkMillerMultiplier) %
		constParkMillerModulus;

	double value = low + (high - low)*
		((double)newValue / fconstParkMillerModulus);

	return value;
}

// zuf�llige 32-Bit-Ganzzahlen:
int32_t CRandomNumbersNN::
Get_IntegerNumber(int32_t low,
	int32_t high_excluded)
{
	newValue = (newValue*constParkMillerMultiplier) %
		constParkMillerModulus;

	int32_t tempVal = low + (high_excluded - low)*
		((double)newValue / fconstParkMillerModulus);

	if (tempVal < high_excluded)
		return tempVal;
	else
		return low;
}

int32_t CRandomNumbersNN::Get_IntegerNumber2(int32_t low, int32_t high)
{
	if(high > 0)
		high++;

	if (low < 0)
		low--;

	newValue = (newValue*constParkMillerMultiplier) %
		constParkMillerModulus;

	int32_t tempVal = low + (high - low)*
		((double)newValue / fconstParkMillerModulus);

	return tempVal;
}

// zuf�llige positive 32-Bit-Ganzzahlen:
uint32_t CRandomNumbersNN::
Get_UnsignedIntegerNumber(uint32_t low,
	uint32_t high_excluded)
{
	newValue = (newValue*constParkMillerMultiplier) %
		constParkMillerModulus;

	uint32_t tempVal = low + (high_excluded - low)*
		((double)newValue / fconstParkMillerModulus);

	if (tempVal < high_excluded)
		return tempVal;
	else
		return low;
}

uint32_t CRandomNumbersNN::
Get_UnsignedIntegerNumber2(uint32_t low,
	uint32_t high)
{
	high++;

	newValue = (newValue*constParkMillerMultiplier) %
		constParkMillerModulus;

	uint32_t tempVal = low + (high - low)*
		((double)newValue / fconstParkMillerModulus);

	return tempVal;	
}


CImageDataF::CImageDataF()
{}

CImageDataF::~CImageDataF()
{
	delete[] pValueArray;
	pValueArray = nullptr;
}

void CImageDataF::Initialize(uint32_t sizeXDir, uint32_t sizeYDir)
{
	delete[] pValueArray;
	pValueArray = nullptr;

	SizeXDir = sizeXDir;
	SizeYDir = sizeYDir;
	Size = sizeXDir * sizeYDir;

	pValueArray = new (std::nothrow) float[Size];

	for (uint32_t i = 0; i < Size; i++)
		pValueArray[i] = 0.0f;
}

void CImageDataF::Clear(float value)
{
	for (uint32_t i = 0; i < Size; i++)
		pValueArray[i] = value;
}

// old resolution => new resolution
// 32x32 => 16x16
// 30x30 => 15x15
// 15x15 => 8x8
void CImageDataF::Bisect_Resolution(float *pOutputArray)
{
	uint32_t inputArraySizeXMinus1 = SizeXDir - 1;
	uint32_t inputArraySizeYMinus1 = SizeYDir - 1;

	uint32_t ixInput, iyInput, tempIy1, tempIy2, idInput;
	uint32_t ixInputPlus1, iyInputPlus1;
	uint32_t counter = 0;

	float tempValue;

	for (iyInput = 0; iyInput < SizeYDir; iyInput += 2)
	{
		tempIy1 = SizeXDir*iyInput;
		iyInputPlus1 = min(inputArraySizeYMinus1, (iyInput + 1));
		tempIy2 = SizeXDir*iyInputPlus1;

		for (ixInput = 0; ixInput < SizeXDir; ixInput += 2)
		{
			ixInputPlus1 = min(inputArraySizeXMinus1, (ixInput + 1));

			idInput = ixInput + tempIy1;
			tempValue = pValueArray[idInput];

			idInput = ixInputPlus1 + tempIy1;
			tempValue += pValueArray[idInput];

			idInput = ixInput + tempIy2;
			tempValue += pValueArray[idInput];

			idInput = ixInputPlus1 + tempIy2;
			tempValue += pValueArray[idInput];

			tempValue *= 0.25f;

			pOutputArray[counter] = tempValue;
			counter++;
		}
	}
}

void CImageDataF::MaxPoolingPooling2x2(float *pOutputArray)
{
	uint32_t inputArraySizeXMinus1 = SizeXDir - 1;
	uint32_t inputArraySizeYMinus1 = SizeYDir - 1;


	uint32_t ixInput, iyInput, tempIy1, tempIy2, idInput;
	uint32_t ixInputPlus1, iyInputPlus1;
	uint32_t counter = 0;

	float maxValue;

	for (iyInput = 0; iyInput < SizeYDir; iyInput += 2)
	{
		tempIy1 = SizeXDir*iyInput;
		iyInputPlus1 = min(inputArraySizeYMinus1, (iyInput + 1));
		tempIy2 = SizeXDir*iyInputPlus1;

		for (ixInput = 0; ixInput < SizeXDir; ixInput += 2)
		{
			ixInputPlus1 = min(inputArraySizeXMinus1, (ixInput + 1));

			idInput = ixInput + tempIy1;
			maxValue = pValueArray[idInput];

			idInput = ixInputPlus1 + tempIy1;
			maxValue = max(maxValue, pValueArray[idInput]);

			idInput = ixInput + tempIy2;
			maxValue = max(maxValue, pValueArray[idInput]);

			idInput = ixInputPlus1 + tempIy2;
			maxValue = max(maxValue, pValueArray[idInput]);

			pOutputArray[counter] = maxValue;
			counter++;
		}
	}
}

void CImageDataF::L2Pooling2x2(float *pOutputArray)
{
	uint32_t inputArraySizeXMinus1 = SizeXDir - 1;
	uint32_t inputArraySizeYMinus1 = SizeYDir - 1;

	uint32_t ixInput, iyInput, tempIy1, tempIy2, idInput;
	uint32_t ixInputPlus1, iyInputPlus1;
	uint32_t counter = 0;

	float tempValue, tempValue2;

	for (iyInput = 0; iyInput < SizeYDir; iyInput += 2)
	{
		tempIy1 = SizeXDir*iyInput;
		iyInputPlus1 = min(inputArraySizeYMinus1, (iyInput + 1));
		tempIy2 = SizeXDir*iyInputPlus1;

		for (ixInput = 0; ixInput < SizeXDir; ixInput += 2)
		{
			ixInputPlus1 = min(inputArraySizeXMinus1, (ixInput + 1));

			idInput = ixInput + tempIy1;
			tempValue2 = pValueArray[idInput];
			tempValue = tempValue2 * tempValue2;

			idInput = ixInputPlus1 + tempIy1;
			tempValue2 = pValueArray[idInput];
			tempValue += tempValue2 * tempValue2;

			idInput = ixInput + tempIy2;
			tempValue2 = pValueArray[idInput];
			tempValue += tempValue2 * tempValue2;

			idInput = ixInputPlus1 + tempIy2;
			tempValue2 = pValueArray[idInput];
			tempValue += tempValue2 * tempValue2;

			pOutputArray[counter] = sqrt(tempValue);
			counter++;
		}
	}
}

C1DimDataF::C1DimDataF()
{}

C1DimDataF::~C1DimDataF()
{
	delete[] pValueArray;
	pValueArray = nullptr;
}

void C1DimDataF::Initialize(uint32_t size)
{
	delete[] pValueArray;
	pValueArray = nullptr;

	Size = size;

	pValueArray = new (std::nothrow) float[Size];

	for (uint32_t i = 0; i < Size; i++)
		pValueArray[i] = 0.0f;
}

void C1DimDataF::Clear(float value)
{
	for (uint32_t i = 0; i < Size; i++)
		pValueArray[i] = value;
}

void C1DimDataF::Bisect_Resolution(float *pOutputArray)
{
	uint32_t inputArraySizeMinus1 = Size - 1;

	uint32_t inputPlus1;

	uint32_t counter = 0;

	float tempValue;

	for (uint32_t i = 0; i < Size; i += 2)
	{
		inputPlus1 = min(inputArraySizeMinus1, (i + 1));

		tempValue = pValueArray[i];
		tempValue += pValueArray[inputPlus1];

		tempValue *= 0.5f;

		pOutputArray[counter] = tempValue;
		counter++;
	}
}

void C1DimDataF::MaxPoolingPooling2x1(float *pOutputArray)
{
	uint32_t inputArraySizeMinus1 = Size - 1;

	uint32_t inputPlus1;

	uint32_t counter = 0;

	float maxValue;

	for (uint32_t i = 0; i < Size; i += 2)
	{
		inputPlus1 = min(inputArraySizeMinus1, (i + 1));

		maxValue = pValueArray[i];
		maxValue = max(maxValue, pValueArray[inputPlus1]);

		pOutputArray[counter] = maxValue;
		counter++;
	}
}

void C1DimDataF::L2Pooling2x1(float *pOutputArray)
{
	uint32_t inputArraySizeMinus1 = Size - 1;

	uint32_t inputPlus1;

	uint32_t counter = 0;

	float tempValue, tempValue2;

	for (uint32_t i = 0; i < Size; i += 2)
	{
		inputPlus1 = min(inputArraySizeMinus1, (i + 1));

		tempValue2 = pValueArray[i];
		tempValue = tempValue2 * tempValue2;

		tempValue2 = pValueArray[inputPlus1];
		tempValue += tempValue2 * tempValue2;

		pOutputArray[counter] = sqrt(tempValue);
		counter++;
	}
}






CGeometricNeuron::CGeometricNeuron()
{}

CGeometricNeuron::~CGeometricNeuron()
{
	delete[] pSynapsePlasticityArray;
	pSynapsePlasticityArray = nullptr;
	delete[] pConnectionWeightArray;
	pConnectionWeightArray = nullptr;
	delete[] pDistanceArray;
	pDistanceArray = nullptr;
	delete[] pReceiverNeuronIDArray;
	pReceiverNeuronIDArray = nullptr;
}

void CGeometricNeuron::Connect_With_Brain(CGeometricNeuron* pNeuronArray)
{
	pUsedNeuronArray = pNeuronArray;
}

void CGeometricNeuron::Set_Position(float x, float y, float z)
{
	PosX = x;
	PosY = y;
	PosZ = z;
}

void CGeometricNeuron::Calculate_ConnectionDistances(void)
{
	//cout << "NeuronID: " << NeuronID << endl;
	float diffX, diffY, diffZ;
	int32_t neuronID;


	for (int32_t i = 0; i < NumConnections; i++)
	{
		neuronID = pReceiverNeuronIDArray[i];

		diffX = PosX - pUsedNeuronArray[neuronID].PosX;
		diffY = PosY - pUsedNeuronArray[neuronID].PosY;
		diffZ = PosZ - pUsedNeuronArray[neuronID].PosZ;

		pDistanceArray[i] = sqrt(diffX*diffX + diffY*diffY + diffZ*diffZ);
		//cout << "Distance: " << pDistanceArray[i] << endl;
	}
}

void CGeometricNeuron::Calculate_ConnectionSquareDistances(void)
{
	//cout << "NeuronID: " << NeuronID << endl;
	float diffX, diffY, diffZ;
	int32_t neuronID;


	for (int32_t i = 0; i < NumConnections; i++)
	{
		neuronID = pReceiverNeuronIDArray[i];

		diffX = PosX - pUsedNeuronArray[neuronID].PosX;
		diffY = PosY - pUsedNeuronArray[neuronID].PosY;
		diffZ = PosZ - pUsedNeuronArray[neuronID].PosZ;

		pDistanceArray[i] = diffX*diffX + diffY*diffY + diffZ*diffZ;
		//cout << "Distance: " << pDistanceArray[i] << endl;
	}
}

void CGeometricNeuron::Set_ConnectionWeight(float weight, int32_t synapseID)
{
	pConnectionWeightArray[synapseID] = weight;
}

void CGeometricNeuron::Connect_With_ReceiverNeuron(int32_t neuronID, int32_t synapseID)
{
	pSynapsePlasticityArray[synapseID] = 0.0f;
	pDistanceArray[synapseID] = 10000.0f;
	pReceiverNeuronIDArray[synapseID] = neuronID;
}

void CGeometricNeuron::Connect_With_ReceiverNeurons(int32_t *pNeuronIDArray)
{
	for (int32_t i = 0; i < NumConnections; i++)
	{
		pSynapsePlasticityArray[i] = 0.0f;
		pDistanceArray[i] = 10000.0f;
		pReceiverNeuronIDArray[i] = pNeuronIDArray[i];
	}
}

void CGeometricNeuron::Init_Neuron(int32_t neuronID, int32_t numConnections)
{
	delete[] pSynapsePlasticityArray;
	pSynapsePlasticityArray = nullptr;
	delete[] pConnectionWeightArray;
	pConnectionWeightArray = nullptr;
	delete[] pDistanceArray;
	pDistanceArray = nullptr;
	delete[] pReceiverNeuronIDArray;
	pReceiverNeuronIDArray = nullptr;

	NeuronID = neuronID;

	Activity = 0.0f;
	ReceiverSynapseID = -1;
	ReceiverNeuronID = -1;
	NumConnections = numConnections;

	pSynapsePlasticityArray = new (std::nothrow) float[NumConnections];
	pConnectionWeightArray = new (std::nothrow) float[NumConnections];
	pDistanceArray = new (std::nothrow) float[NumConnections];
	pReceiverNeuronIDArray = new (std::nothrow) int32_t[NumConnections];

	for (int32_t i = 0; i < NumConnections; i++)
	{
		pSynapsePlasticityArray[i] = 0.0f;
		pConnectionWeightArray[i] = 0.99f;//1.0f;
		pDistanceArray[i] = 10000.0f;
		pReceiverNeuronIDArray[i] = -1;
	}
}

void CGeometricNeuron::Init_FullyConnectedNeuron(int32_t neuronID, int32_t numNeurons)
{
	delete[] pSynapsePlasticityArray;
	pSynapsePlasticityArray = nullptr;
	delete[] pConnectionWeightArray;
	pConnectionWeightArray = nullptr;
	delete[] pDistanceArray;
	pDistanceArray = nullptr;
	delete[] pReceiverNeuronIDArray;
	pReceiverNeuronIDArray = nullptr;

	NeuronID = neuronID;

	Activity = 0.0f;
	ReceiverSynapseID = -1;
	ReceiverNeuronID = -1;
	NumConnections = numNeurons - 1;

	pSynapsePlasticityArray = new (std::nothrow) float[NumConnections];
	pConnectionWeightArray = new (std::nothrow) float[NumConnections];
	pDistanceArray = new (std::nothrow) float[NumConnections];
	pReceiverNeuronIDArray = new (std::nothrow) int32_t[NumConnections];

	int32_t i;

	for (i = 0; i < NumConnections; i++)
	{
		pSynapsePlasticityArray[i] = 0.0f;
		pConnectionWeightArray[i] = 1.0f;
		pDistanceArray[i] = 10000.0f;
		pReceiverNeuronIDArray[i] = -1;
	}

	int32_t counter = 0;

	for (i = 0; i < numNeurons; i++)
	{
		if (i == NeuronID)
			continue;

		pReceiverNeuronIDArray[counter] = i;
		counter++;
	}
}

void CGeometricNeuron::Reset_Activity(void)
{
	ReceiverSynapseID = -1;
	ReceiverNeuronID = -1;
	Activity = 0.0f;
}

void CGeometricNeuron::Set_Activity(float value)
{
	Activity = value;
}

int32_t CGeometricNeuron::Get_ID_Of_Strongest_ConnectedNeuron(void)
{
	float maxPlasticity = -100000.0f;
	int32_t belongingSynapseID = -1;

	for (int32_t i = 0; i < NumConnections; i++)
	{
		if(maxPlasticity < pSynapsePlasticityArray[i])
		{
			maxPlasticity = pSynapsePlasticityArray[i];
			belongingSynapseID = i;
		}
	}

	return pReceiverNeuronIDArray[belongingSynapseID];
}



void CGeometricNeuron::Reduce_PlasticityValues(float decreaseValue, float minPlasticityValue)
{
	for (int32_t i = 0; i < NumConnections; i++)
	{
		pSynapsePlasticityArray[i] -= decreaseValue;
		pSynapsePlasticityArray[i] = max(minPlasticityValue, pSynapsePlasticityArray[i]);
	}
}

void CGeometricNeuron::Reset_PlasticityValues(void)
{
	for (int32_t i = 0; i < NumConnections; i++)
		pSynapsePlasticityArray[i] = 0.0f;
}

void CGeometricNeuron::Update_PlasticityValues(float finalActivity, float learningRate)
{
	if (ReceiverSynapseID < 0)
		return;

	pSynapsePlasticityArray[ReceiverSynapseID] += learningRate * finalActivity;

	ReceiverSynapseID = -1;
}



void CGeometricNeuron::Propagate_Signal(int32_t receiverNeuronID)
{
	int32_t receiverSynapseID = -1;

	int32_t i;

	for (i = 0; i < NumConnections; i++)
	{
		if (pReceiverNeuronIDArray[i] == receiverNeuronID)
		{
			receiverSynapseID = i;
			break;
		}
	}

	if (receiverSynapseID < 0)
		return;

	ReceiverSynapseID = receiverSynapseID;
	pUsedNeuronArray[receiverNeuronID].Activity = pConnectionWeightArray[receiverSynapseID] * Activity / pDistanceArray[receiverSynapseID];
}

int32_t CGeometricNeuron::Propagate_Signal_To_NonActivatedNeuron(CRandomNumbersNN *pRandomNumbers)
{
	float maxPlasticity = -1000000.0f;

	int32_t IDofSynapseWithMaxPlasticity = 0;

	float plasticity;

	for (uint32_t i = 0; i < NumConnections; i++)
	{
		plasticity = pSynapsePlasticityArray[i];

		if(plasticity > maxPlasticity)
		{
			maxPlasticity = plasticity;
			IDofSynapseWithMaxPlasticity = i;
		}
	}

	int32_t testReceiverNeuronID;
	int32_t testReceiverSynapseID;

	do
	{
		testReceiverSynapseID = pRandomNumbers->Get_IntegerNumber(0, NumConnections);

		if(testReceiverSynapseID != IDofSynapseWithMaxPlasticity)
			testReceiverSynapseID = pRandomNumbers->Get_IntegerNumber(0, NumConnections);

		///
		//if (testReceiverSynapseID != IDofSynapseWithMaxPlasticity)
			//testReceiverSynapseID = pRandomNumbers->Get_IntegerNumber(0, NumConnections);
		///

		testReceiverNeuronID = pReceiverNeuronIDArray[testReceiverSynapseID];

		if (pUsedNeuronArray[testReceiverNeuronID].Activity == 0.0f)
			break;

	} while (true);

	ReceiverSynapseID = testReceiverSynapseID;
	ReceiverNeuronID = pReceiverNeuronIDArray[ReceiverSynapseID];
	pUsedNeuronArray[ReceiverNeuronID].Activity = pConnectionWeightArray[ReceiverSynapseID] * Activity / pDistanceArray[ReceiverSynapseID];
	return ReceiverNeuronID;
}

int32_t CGeometricNeuron::Propagate_Signal(CRandomNumbersNN *pRandomNumbers)
{
	float maxPlasticity = -1000000.0f;

	int32_t IDofSynapseWithMaxPlasticity = 0;

	float plasticity;

	for (uint32_t i = 0; i < NumConnections; i++)
	{
		plasticity = pSynapsePlasticityArray[i];

		if (plasticity > maxPlasticity)
		{
			maxPlasticity = plasticity;
			IDofSynapseWithMaxPlasticity = i;
		}
	}

	int32_t testReceiverSynapseID = pRandomNumbers->Get_IntegerNumber(0, NumConnections);

	if (testReceiverSynapseID != IDofSynapseWithMaxPlasticity)
		testReceiverSynapseID = pRandomNumbers->Get_IntegerNumber(0, NumConnections);

	ReceiverSynapseID = testReceiverSynapseID;
	ReceiverNeuronID = pReceiverNeuronIDArray[ReceiverSynapseID];
	pUsedNeuronArray[ReceiverNeuronID].Activity = pConnectionWeightArray[ReceiverSynapseID] * Activity / pDistanceArray[ReceiverSynapseID];
	return ReceiverNeuronID;
}

int32_t CGeometricNeuron::Propagate_Signal_Randomly(CRandomNumbersNN *pRandomNumbers)
{
	int32_t randomReceiverSynapseID = pRandomNumbers->Get_IntegerNumber(0, NumConnections);
	
	ReceiverSynapseID = randomReceiverSynapseID;
	ReceiverNeuronID = pReceiverNeuronIDArray[ReceiverSynapseID];
	pUsedNeuronArray[ReceiverNeuronID].Activity = pConnectionWeightArray[ReceiverSynapseID] * Activity / pDistanceArray[ReceiverSynapseID];
	return ReceiverNeuronID;
}

int32_t CGeometricNeuron::Select_Connected_Neuron_Randomly(CRandomNumbersNN *pRandomNumbers)
{
	int32_t randomReceiverSynapseID = pRandomNumbers->Get_IntegerNumber(0, NumConnections);

	ReceiverSynapseID = randomReceiverSynapseID;
	ReceiverNeuronID = pReceiverNeuronIDArray[ReceiverSynapseID];
	return ReceiverNeuronID;
}



CGeometricNeuralNet::CGeometricNeuralNet()
{}

CGeometricNeuralNet::~CGeometricNeuralNet()
{
	delete[] pNeuronArray;
	pNeuronArray = nullptr;
}

float CGeometricNeuralNet::Find_MaxPlasticityValue(void)
{
	MaxPlasticityValue = -1000000.0f;

	//int32_t numConnectionsPerNeuron = NumNeurons - 1;
	int32_t numConnectionsPerNeuron;

	float plasticityValue;
	int32_t i, j;

	for (i = 0; i < NumNeurons; i++)
	{
		numConnectionsPerNeuron = pNeuronArray[i].NumConnections;

		for (j = 0; j < numConnectionsPerNeuron; j++)
		{
			plasticityValue = pNeuronArray[i].pSynapsePlasticityArray[j];

			if (plasticityValue == 0.0f)
				continue;

			if (MaxPlasticityValue < plasticityValue)
				MaxPlasticityValue = plasticityValue;
		}
	}

	return MaxPlasticityValue;
}

float CGeometricNeuralNet::Find_MinNonZeroPlasticityValue(void)
{
	MinNonZeroPlasticityValue = 1000000.0f;

	//int32_t numConnectionsPerNeuron = NumNeurons - 1;
	int32_t numConnectionsPerNeuron;

	float plasticityValue;
	int32_t i, j;

	for (i = 0; i < NumNeurons; i++)
	{
		numConnectionsPerNeuron = pNeuronArray[i].NumConnections;

		for (j = 0; j < numConnectionsPerNeuron; j++)
		{
			plasticityValue = pNeuronArray[i].pSynapsePlasticityArray[j];

			if (plasticityValue == 0.0f)
				continue;

			if (MinNonZeroPlasticityValue > plasticityValue)
				MinNonZeroPlasticityValue = plasticityValue;
		}
	}

	return MinNonZeroPlasticityValue;
}

int32_t CGeometricNeuralNet::Get_ID_Of_Strongest_ConnectedNeuron(int32_t lastNeuronID)
{
	return pNeuronArray[lastNeuronID].Get_ID_Of_Strongest_ConnectedNeuron();
}

void CGeometricNeuralNet::Reduce_PlasticityValues(float decreaseValue, float minPlasticityValue)
{
	for (int32_t i = 0; i < NumNeurons; i++)
		pNeuronArray[i].Reduce_PlasticityValues(decreaseValue, minPlasticityValue);
}

void CGeometricNeuralNet::Train_NeuralNet_PathFinding(int32_t IDofFirstNeuron, int32_t IDofLastNeuron, float initialActivity, float learningRate)
{
	int32_t i, idOfNextNeuron;

	for (i = 0; i < NumNeurons; i++)
		pNeuronArray[i].Reset_Activity();

	pNeuronArray[IDofFirstNeuron].Set_Activity(initialActivity);

	idOfNextNeuron = pNeuronArray[IDofFirstNeuron].Propagate_Signal(&RandomNumbers);

	if (idOfNextNeuron == IDofLastNeuron)
	{
		float finalActivity = pNeuronArray[IDofLastNeuron].Activity;

		for (i = 0; i < NumNeurons; i++)
			pNeuronArray[i].Update_PlasticityValues(finalActivity, learningRate);

		return;
	}

	do
	{
		idOfNextNeuron = pNeuronArray[idOfNextNeuron].Propagate_Signal(&RandomNumbers);

		if (idOfNextNeuron == IDofLastNeuron)
			break;

	} while (true);

	float finalActivity = pNeuronArray[IDofLastNeuron].Activity;

	for (i = 0; i < NumNeurons; i++)
		pNeuronArray[i].Update_PlasticityValues(finalActivity, learningRate);
}

void CGeometricNeuralNet::Start_Training(void)
{
	for (int32_t i = 0; i < NumNeurons; i++)
	{
		pNeuronArray[i].Reset_Activity();
		pNeuronArray[i].Reset_PlasticityValues();
	}
}

void CGeometricNeuralNet::Random_PathFinding(int32_t IDofFirstNeuron, int32_t IDofLastNeuron, float initialActivity, float learningRate)
{
	/*
	int32_t i, idOfNextNeuron;

	for (i = 0; i < NumNeurons; i++)
		pNeuronArray[i].Reset_Activity();

	pNeuronArray[IDofFirstNeuron].Set_Activity(initialActivity);

	idOfNextNeuron = pNeuronArray[IDofFirstNeuron].Propagate_Signal_Randomly(&RandomNumbers);
	
	if (idOfNextNeuron == IDofLastNeuron)
	{
		float finalActivity = pNeuronArray[IDofLastNeuron].Activity;

		for (i = 0; i < NumNeurons; i++)
			pNeuronArray[i].Update_PlasticityValues(finalActivity, learningRate);

		return;
	}

	do
	{
		idOfNextNeuron = pNeuronArray[idOfNextNeuron].Propagate_Signal_Randomly(&RandomNumbers);

		if (idOfNextNeuron == IDofLastNeuron)
			break;

	} while (true);

	float finalActivity = pNeuronArray[IDofLastNeuron].Activity;

	for (i = 0; i < NumNeurons; i++)
		pNeuronArray[i].Update_PlasticityValues(finalActivity, learningRate);
	*/

	int32_t i, idOfNextNeuron, idOfActualNeuron;

	for (i = 0; i < NumNeurons; i++)
		pNeuronArray[i].Reset_Activity();
	

	idOfNextNeuron = pNeuronArray[IDofFirstNeuron].Select_Connected_Neuron_Randomly(&RandomNumbers);

	do
	{
		idOfNextNeuron = pNeuronArray[idOfNextNeuron].Select_Connected_Neuron_Randomly(&RandomNumbers);

		if (idOfNextNeuron == IDofLastNeuron)
			break;

	} while (true);

	int32_t receiverSynapseID;

	
	pNeuronArray[IDofFirstNeuron].Set_Activity(initialActivity);
	idOfNextNeuron = pNeuronArray[IDofFirstNeuron].ReceiverNeuronID;

	receiverSynapseID = pNeuronArray[IDofFirstNeuron].ReceiverSynapseID;
	pNeuronArray[idOfNextNeuron].Activity = pNeuronArray[IDofFirstNeuron].pConnectionWeightArray[receiverSynapseID] * pNeuronArray[IDofFirstNeuron].Activity / pNeuronArray[IDofFirstNeuron].pDistanceArray[receiverSynapseID];
	//cout << pNeuronArray[idOfNextNeuron].Activity << endl;
	
	do
	{
		idOfActualNeuron = idOfNextNeuron;
		idOfNextNeuron = pNeuronArray[idOfActualNeuron].ReceiverNeuronID;

		receiverSynapseID = pNeuronArray[idOfActualNeuron].ReceiverSynapseID;
		pNeuronArray[idOfNextNeuron].Activity = pNeuronArray[idOfActualNeuron].pConnectionWeightArray[receiverSynapseID] * pNeuronArray[idOfActualNeuron].Activity / pNeuronArray[idOfActualNeuron].pDistanceArray[receiverSynapseID];
		//cout << pNeuronArray[idOfNextNeuron].Activity << endl;

		if (idOfNextNeuron == IDofLastNeuron)
			break;

	} while (true);

	
	float finalActivity = pNeuronArray[IDofLastNeuron].Activity;

	for (i = 0; i < NumNeurons; i++)
		pNeuronArray[i].Update_PlasticityValues(finalActivity, learningRate);
}

void CGeometricNeuralNet::Train_NeuralNet_TSP(int32_t IDofFirstAndLastNeuron, float initialActivity, float learningRate)
{
	int32_t i, idOfNextNeuron;

	for (i = 0; i < NumNeurons; i++)
		pNeuronArray[i].Reset_Activity();

	pNeuronArray[IDofFirstAndLastNeuron].Set_Activity(initialActivity);
	
	idOfNextNeuron = pNeuronArray[IDofFirstAndLastNeuron].Propagate_Signal_To_NonActivatedNeuron(&RandomNumbers);

	int32_t pathCounter = 1;

	do
	{
		if (pathCounter == NumNeurons - 1)
		{
			pNeuronArray[idOfNextNeuron].Propagate_Signal(IDofFirstAndLastNeuron);
			break;
		}
		else
		{
			idOfNextNeuron = pNeuronArray[idOfNextNeuron].Propagate_Signal_To_NonActivatedNeuron(&RandomNumbers);
			pathCounter++;
		}

	} while (true);

	float finalActivity = pNeuronArray[IDofFirstAndLastNeuron].Activity;


	for (i = 0; i < NumNeurons; i++)
		pNeuronArray[i].Update_PlasticityValues(finalActivity, learningRate);
}



void CGeometricNeuralNet::Set_Position(int32_t neuronID, float x, float y, float z)
{
	pNeuronArray[neuronID].Set_Position(x, y, z);
}

void CGeometricNeuralNet::Calculate_ConnectionDistances(void)
{
	for (int32_t i = 0; i < NumNeurons; i++)
		pNeuronArray[i].Calculate_ConnectionDistances();
}

void CGeometricNeuralNet::Calculate_ConnectionSquareDistances(void)
{
	for (int32_t i = 0; i < NumNeurons; i++)
		pNeuronArray[i].Calculate_ConnectionSquareDistances();
}

void CGeometricNeuralNet::Set_ConnectionWeight(int32_t neuronID, float weight, int32_t synapseID)
{
	pNeuronArray[neuronID].Set_ConnectionWeight(weight, synapseID);
}

void CGeometricNeuralNet::Set_ConnectionWeight(int32_t neuronID, int32_t receiverNeuronID, float weight)
{
	int32_t numConnections = pNeuronArray[neuronID].NumConnections;

	for(int32_t i = 0; i < numConnections; i++)
	{
		if(pNeuronArray[neuronID].pReceiverNeuronIDArray[i] == receiverNeuronID)
		{
			pNeuronArray[neuronID].pConnectionWeightArray[i] = weight;
			return;
		}
	}
}

void CGeometricNeuralNet::Connect_With_ReceiverNeuron(int32_t neuronID, int32_t receiverNeuronID, int32_t synapseID)
{
	pNeuronArray[neuronID].Connect_With_ReceiverNeuron(receiverNeuronID, synapseID);
}

void CGeometricNeuralNet::Init_Neuron(int32_t neuronID, int32_t numConnections)
{
	pNeuronArray[neuronID].Init_Neuron(neuronID, numConnections);
}

void CGeometricNeuralNet::Initialize_NeuralNet(int32_t numNeurons)
{
	delete[] pNeuronArray;
	pNeuronArray = nullptr;

	MinNonZeroPlasticityValue = 0.0f;
	MaxPlasticityValue = 0.0f;

	NumNeurons = numNeurons;

	pNeuronArray = new (std::nothrow) CGeometricNeuron[numNeurons];

	for (int32_t i = 0; i < numNeurons; i++)
		pNeuronArray[i].Connect_With_Brain(pNeuronArray);
}

void CGeometricNeuralNet::Initialize_FullyConnected_NeuralNet(int32_t numNeurons)
{
	delete[] pNeuronArray;
	pNeuronArray = nullptr;

	MinNonZeroPlasticityValue = 0.0f;
	MaxPlasticityValue = 0.0f;

	NumNeurons = numNeurons;

	pNeuronArray = new (std::nothrow) CGeometricNeuron[numNeurons];

	for (int32_t i = 0; i < numNeurons; i++)
	{
		pNeuronArray[i].Init_FullyConnectedNeuron(i, numNeurons);
		pNeuronArray[i].Connect_With_Brain(pNeuronArray);
	}
}






CNeuron::CNeuron()
{}

CNeuron::~CNeuron()
{
	delete[] pOutputSynapseActivityStatusArray;
	pOutputSynapseActivityStatusArray = nullptr;

	delete[] pOutputSynapsePlasticityArray;
	pOutputSynapsePlasticityArray = nullptr;

	delete[] pOutputSynapseMinBlockingValueArray;
	pOutputSynapseMinBlockingValueArray = nullptr;

	delete[] pOutputSynapseMaxBlockingValueArray;
	pOutputSynapseMaxBlockingValueArray = nullptr;

	delete[] pReceiverNeuronIDArray;
	pReceiverNeuronIDArray = nullptr;

	delete[] pRBFCentroidValueArray;
	pRBFCentroidValueArray = nullptr;
}



void CNeuron::Set_Input(float value)
{
	if (UsedAsInputNeuron == false)
		return;

	NeuronOutput = value;
}

void CNeuron::Add_Input(float value)
{
	if (UsedAsInputNeuron == false)
		return;

	NeuronOutput += value;
}

void CNeuron::Use_As_RBFNeuron(void)
{
	
	UsedAsInputNeuron = false;
	UsedAsHiddenNeuron = false;
	UsedAsOutputNeuron = false;
	UsedAsBiasNeuron = false;
	UsedAsRBFNeuron = true;

	Set_ActivationFunction(RBFActivationFunc);
}

void CNeuron::Use_As_InputNeuron(void)
{
	

	UsedAsInputNeuron = true;
	UsedAsHiddenNeuron = false;
	UsedAsOutputNeuron = false;
	UsedAsBiasNeuron = false;
	UsedAsRBFNeuron = false;
}

void CNeuron::Use_As_HiddenNeuron(void)
{
	UsedAsInputNeuron = false;
	UsedAsHiddenNeuron = true;
	UsedAsOutputNeuron = false;
	UsedAsBiasNeuron = false;
	UsedAsMemoryNeuron = false;
	UsedAsRBFNeuron = false;
}

void CNeuron::Use_As_OutputNeuron(void)
{
	UsedAsInputNeuron = false;
	UsedAsHiddenNeuron = false;
	UsedAsOutputNeuron = true;
	UsedAsBiasNeuron = false;
	UsedAsMemoryNeuron = false;
	UsedAsRBFNeuron = false;
}

void CNeuron::Use_As_BiasNeuron(void)
{
	UsedAsInputNeuron = false;
	UsedAsHiddenNeuron = false;
	UsedAsOutputNeuron = false;
	UsedAsBiasNeuron = true;
	UsedAsMemoryNeuron = false;
	UsedAsRBFNeuron = false;

	NeuronOutput = -1.0f;
}

void CNeuron::Use_As_MemoryNeuron(void)
{
	UsedAsInputNeuron = false;
	UsedAsHiddenNeuron = false;
	UsedAsOutputNeuron = false;
	UsedAsBiasNeuron = false;
	UsedAsMemoryNeuron = true;
	UsedAsRBFNeuron = false;
}


void CNeuron::Set_OutputSynapseBlockingValue(float minValue, float maxValue, uint32_t synapseID)
{
	pOutputSynapseMinBlockingValueArray[synapseID] = minValue;
	pOutputSynapseMaxBlockingValueArray[synapseID] = maxValue;
}

void CNeuron::Set_OutputSynapsePlasticity(float value, uint32_t synapseID)
{
	pOutputSynapsePlasticityArray[synapseID] = value;
}

void CNeuron::Set_LearningRate(float learningRate)
{
	LearningRate = learningRate;
}

void CNeuron::Connect_With_Brain(CNeuron* pNeuronArray)
{
	Dropout = false;
	pUsedNeuronArray = pNeuronArray;
}

void CNeuron::Set_ActivationFunction(pActivationFunc pFunc)
{
	pActivationFunction = pFunc;
}

void CNeuron::Set_UserDefErrorFunction(pErrorFunc pFunc)
{
	pUserDefErrorFunction = pFunc;
}

void CNeuron::Set_ErrorFactors(float factor1, float factor2)
{
	ErrorFactor1 = factor1;
	ErrorFactor2 = factor2;
}

void CNeuron::Reset_NeuronInput(void)
{
	NeuronInput = 0.0f;
}

float CNeuron::Get_NeuronInput(void)
{
	return NeuronInput;
}

void CNeuron::Set_NeuronInput(float value)
{
	NeuronInput = value;
}

void CNeuron::Disable_Random_OutputSynapses(CRandomNumbersNN *pRandomNumbers, float probabilityValue)
{
	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > probabilityValue)
			continue;

		pOutputSynapseActivityStatusArray[i] = false;
		pOutputSynapsePlasticityArray[i] = 0.0f;
	}
}

void CNeuron::Enable_Disabled_OutputSynapses(CRandomNumbersNN *pRandomNumbers, float minPlasticityValue, float maxPlasticityValue)
{
	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		if (pOutputSynapseActivityStatusArray[i] == false)
		{
			pOutputSynapseActivityStatusArray[i] = true;
			pOutputSynapsePlasticityArray[i] = RandomNumbers.Get_FloatNumber(minPlasticityValue, maxPlasticityValue);
		}
	}
}

void CNeuron::Enable_Disabled_OutputSynapses(CRandomNumbersNN *pRandomNumbers, float minPlasticityValue, float maxPlasticityValue, float probabilityValue)
{
	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > probabilityValue)
			continue;

		if (pOutputSynapseActivityStatusArray[i] == false)
		{
			pOutputSynapseActivityStatusArray[i] = true;
			pOutputSynapsePlasticityArray[i] = RandomNumbers.Get_FloatNumber(minPlasticityValue, maxPlasticityValue);
		}
	}
}

void CNeuron::Init_OutputSynapses(uint32_t numOfOutputSynapses)
{
	Dropout = false;

	if (numOfOutputSynapses > NumOfOutputSynapsesMax)
	{
		NumOfOutputSynapsesMax = numOfOutputSynapses;
		NumOfOutputSynapses = numOfOutputSynapses;

		delete[] pOutputSynapseActivityStatusArray;
		pOutputSynapseActivityStatusArray = nullptr;

		delete[] pOutputSynapsePlasticityArray;
		pOutputSynapsePlasticityArray = nullptr;

		delete[] pOutputSynapseMinBlockingValueArray;
		pOutputSynapseMinBlockingValueArray = nullptr;

		delete[] pOutputSynapseMaxBlockingValueArray;
		pOutputSynapseMaxBlockingValueArray = nullptr;

		delete[] pReceiverNeuronIDArray;
		pReceiverNeuronIDArray = nullptr;

		pOutputSynapseActivityStatusArray = new (std::nothrow) bool[NumOfOutputSynapses];

		pOutputSynapsePlasticityArray = new (std::nothrow) float[NumOfOutputSynapses];
		pReceiverNeuronIDArray = new (std::nothrow) uint32_t[NumOfOutputSynapses];

		pOutputSynapseMinBlockingValueArray = new (std::nothrow) float[NumOfOutputSynapses];
		pOutputSynapseMaxBlockingValueArray = new (std::nothrow) float[NumOfOutputSynapses];
	}
	else //if(numOfOutputSynapses <= NumOfOutputSynapsesMax)
		NumOfOutputSynapses = numOfOutputSynapses;

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		pOutputSynapseActivityStatusArray[i] = true;
		pOutputSynapsePlasticityArray[i] = 0.0f;
		pReceiverNeuronIDArray[i] = 0;
		pOutputSynapseMinBlockingValueArray[i] = 0.0f;
		pOutputSynapseMaxBlockingValueArray[i] = 1.0f;
	}
}

void CNeuron::Connect_With_ReceiverNeuron(uint32_t neuronID, uint32_t synapseID)
{
	pReceiverNeuronIDArray[synapseID] = neuronID;
}

void CNeuron::Connect_With_ReceiverNeurons(uint32_t *pNeuronIDArray)
{
	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
		pReceiverNeuronIDArray[i] = pNeuronIDArray[i];
}

void CNeuron::Modify_OutputSynapsePlasticities(float multiplier)
{
	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
		pOutputSynapsePlasticityArray[i] *= multiplier;
}

void CNeuron::Randomize_OutputSynapsePlasticities(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue)
{
	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
		pOutputSynapsePlasticityArray[i] = pRandomNumbers->Get_FloatNumber(minValue, maxValue);
}

void CNeuron::Add_Randomized_OutputSynapsePlasticities(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float weight1, float weight2)
{
	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
		pOutputSynapsePlasticityArray[i] = weight1 * pOutputSynapsePlasticityArray[i] + weight2 * pRandomNumbers->Get_FloatNumber(minValue, maxValue);
}

void CNeuron::Randomize_OutputSynapsePlasticities(CRandomNumbersNN *pRandomNumbers, float *pRandomValueArray, uint32_t numArrayElements)
{
	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
		pOutputSynapsePlasticityArray[i] = pRandomValueArray[pRandomNumbers->Get_UnsignedIntegerNumber(0, numArrayElements)];
}

void CNeuron::Add_Randomized_OutputSynapsePlasticities(CRandomNumbersNN *pRandomNumbers, float *pRandomValueArray, uint32_t numArrayElements, float weight1, float weight2)
{
	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
		pOutputSynapsePlasticityArray[i] = weight1 * pOutputSynapsePlasticityArray[i] + weight2 * pRandomValueArray[pRandomNumbers->Get_UnsignedIntegerNumber(0, numArrayElements)];
}

void CNeuron::Clone_OutputSynapsePlasticities(const CNeuron &originalObject)
{
	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		pOutputSynapseActivityStatusArray[i] = originalObject.pOutputSynapseActivityStatusArray[i];
		pOutputSynapsePlasticityArray[i] = originalObject.pOutputSynapsePlasticityArray[i];
	}
}

void CNeuron::Clone_OutputSynapsePlasticities(const CNeuron &originalObject, CRandomNumbersNN *pRandomNumbers, float variance)
{
	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		pOutputSynapseActivityStatusArray[i] = originalObject.pOutputSynapseActivityStatusArray[i];
		pOutputSynapsePlasticityArray[i] = originalObject.pOutputSynapsePlasticityArray[i];
		pOutputSynapsePlasticityArray[i] += pRandomNumbers->Get_FloatNumber(-variance, variance);
	}
}

void CNeuron::Clone_OutputSynapsePlasticities(const CNeuron &originalObject, CRandomNumbersNN *pRandomNumbers, float minVariance, float maxVariance)
{
	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		pOutputSynapseActivityStatusArray[i] = originalObject.pOutputSynapseActivityStatusArray[i];
		pOutputSynapsePlasticityArray[i] = originalObject.pOutputSynapsePlasticityArray[i];
		pOutputSynapsePlasticityArray[i] += pRandomNumbers->Get_FloatNumber(minVariance, maxVariance);
	}
}

void CNeuron::Combine_OutputSynapsePlasticities(CNeuron *pParentNeuron1, CNeuron *pParentNeuron2, CRandomNumbersNN *pRandomNumbers, float minWeight1)
{
	float weight1, weight2;

	float newPlasticity;

	bool activityStatus1, activityStatus2;

	

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		activityStatus1 = pParentNeuron1->pOutputSynapseActivityStatusArray[i];
		activityStatus2 = pParentNeuron2->pOutputSynapseActivityStatusArray[i];

		if(activityStatus1 == false && activityStatus2 == false)
		{
			pOutputSynapseActivityStatusArray[i] = false;
			pOutputSynapsePlasticityArray[i] = 0.0f;
		}
		else if (activityStatus1 == true && activityStatus2 == true)
		{
			pOutputSynapseActivityStatusArray[i] = true;

			weight1 = pRandomNumbers->Get_FloatNumber(minWeight1, 1.0f);
			weight2 = 1.0f - weight1;
			newPlasticity = weight1*pParentNeuron1->pOutputSynapsePlasticityArray[i];
			newPlasticity += weight2*pParentNeuron2->pOutputSynapsePlasticityArray[i];

			pOutputSynapsePlasticityArray[i] = newPlasticity;
		}
		else if (activityStatus1 == true && activityStatus2 == false)
		{
			pOutputSynapseActivityStatusArray[i] = true;
			pOutputSynapsePlasticityArray[i] = pParentNeuron1->pOutputSynapsePlasticityArray[i];
		}
		else if (activityStatus1 == false && activityStatus2 == true)
		{
			pOutputSynapseActivityStatusArray[i] = true;
			pOutputSynapsePlasticityArray[i] = pParentNeuron2->pOutputSynapsePlasticityArray[i];
		}
		
	}
}

void CNeuron::Combine_OutputSynapsePlasticities(CNeuron *pParentNeuron1, CNeuron *pParentNeuron2, CRandomNumbersNN *pRandomNumbers)
{
	float weight1, weight2;

	float newPlasticity;

	bool activityStatus1, activityStatus2;



	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		activityStatus1 = pParentNeuron1->pOutputSynapseActivityStatusArray[i];
		activityStatus2 = pParentNeuron2->pOutputSynapseActivityStatusArray[i];

		if (activityStatus1 == false && activityStatus2 == false)
		{
			pOutputSynapseActivityStatusArray[i] = false;
			pOutputSynapsePlasticityArray[i] = 0.0f;
		}
		else if (activityStatus1 == true && activityStatus2 == true)
		{
			pOutputSynapseActivityStatusArray[i] = true;

			if(pRandomNumbers->Get_FloatNumber(0.0f, 1.0) < 0.5)
				pOutputSynapsePlasticityArray[i] = pParentNeuron1->pOutputSynapsePlasticityArray[i];
			else
				pOutputSynapsePlasticityArray[i] = pParentNeuron2->pOutputSynapsePlasticityArray[i];
		}
		else if (activityStatus1 == true && activityStatus2 == false)
		{
			pOutputSynapsePlasticityArray[i] = pParentNeuron1->pOutputSynapsePlasticityArray[i];
		}
		else if (activityStatus1 == false && activityStatus2 == true)
		{
			pOutputSynapsePlasticityArray[i] = pParentNeuron2->pOutputSynapsePlasticityArray[i];
		}

	}
}






bool CNeuron::Save_RBFCentroidValues(const char* pFilename)
{
	std::ofstream WriteFile;

	// neue Datei erzeugen bzw. alte �berschreiben:
	WriteFile.open(pFilename);

	// neue Datei erzeugen bzw. Inhalt ans Ende einer bestehenden Datei schreiben: 
	//WriteFile.open(pFilename, ios::app);

	if (WriteFile.good() == false)
		return false;

	for (uint32_t i = 0; i < NumOfRBFCentroidValues; i++)
	{
		WriteFile << pRBFCentroidValueArray[i] << "  ";
	}

	WriteFile.close();

	return true;
}

bool CNeuron::Save_ReceiverNeuronIDs_And_OutputSynapsePlasticities_Ext(const char* pFilename)
{
	std::ofstream WriteFile;

	// neue Datei erzeugen bzw. alte �berschreiben:
	WriteFile.open(pFilename);

	// neue Datei erzeugen bzw. Inhalt ans Ende einer bestehenden Datei schreiben: 
	//WriteFile.open(pFilename, ios::app);

	if (WriteFile.good() == false)
		return false;

	WriteFile << NumOfOutputSynapses << "  ";

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		WriteFile << pReceiverNeuronIDArray[i] << "  ";
		WriteFile << pOutputSynapsePlasticityArray[i] << "  ";
	}

	WriteFile.close();

	return true;
}

bool CNeuron::Save_ReceiverNeuronIDs_And_OutputSynapsePlasticities(const char* pFilename)
{
	std::ofstream WriteFile;

	// neue Datei erzeugen bzw. alte �berschreiben:
	WriteFile.open(pFilename);

	// neue Datei erzeugen bzw. Inhalt ans Ende einer bestehenden Datei schreiben: 
	//WriteFile.open(pFilename, ios::app);

	if (WriteFile.good() == false)
		return false;

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		WriteFile << pReceiverNeuronIDArray[i] << "  ";
		WriteFile << pOutputSynapsePlasticityArray[i] << "  ";
	}

	WriteFile.close();

	return true;
}

bool CNeuron::Save_OutputSynapsePlasticities(const char* pFilename)
{
	std::ofstream WriteFile;

	// neue Datei erzeugen bzw. alte �berschreiben:
	WriteFile.open(pFilename);

	// neue Datei erzeugen bzw. Inhalt ans Ende einer bestehenden Datei schreiben: 
	//WriteFile.open(pFilename, ios::app);

	if (WriteFile.good() == false)
		return false;

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		WriteFile << pOutputSynapsePlasticityArray[i] << "  ";
	}

	WriteFile.close();

	return true;
}





bool CNeuron::Load_RBFCentroidValues(const char* pFilename)
{
	std::ifstream ReadFile;

	// eine existierende Datei zum Lesen �ffnen:
	ReadFile.open(pFilename);

	if (ReadFile.good() == false)
		return false;

	for (uint32_t i = 0; i < NumOfRBFCentroidValues; i++)
	{
		ReadFile >> pRBFCentroidValueArray[i];
	}
	
	ReadFile.close();

	return true;
}

bool CNeuron::Load_ReceiverNeuronIDs_And_OutputSynapsePlasticities(const char* pFilename)
{
	std::ifstream ReadFile;

	// eine existierende Datei zum Lesen �ffnen:
	ReadFile.open(pFilename);

	if (ReadFile.good() == false)
		return false;

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		ReadFile >> pReceiverNeuronIDArray[i];
		ReadFile >> pOutputSynapsePlasticityArray[i];
	}


	ReadFile.close();

	return true;
}

bool CNeuron::Load_ReceiverNeuronIDs_And_OutputSynapsePlasticities_Ext(const char* pFilename)
{
	Dropout = false;

	delete[] pOutputSynapseActivityStatusArray;
	pOutputSynapseActivityStatusArray = nullptr;

	delete[] pOutputSynapsePlasticityArray;
	pOutputSynapsePlasticityArray = nullptr;

	delete[] pOutputSynapseMinBlockingValueArray;
	pOutputSynapseMinBlockingValueArray = nullptr;

	delete[] pOutputSynapseMaxBlockingValueArray;
	pOutputSynapseMaxBlockingValueArray = nullptr;

	delete[] pReceiverNeuronIDArray;
	pReceiverNeuronIDArray = nullptr;

	std::ifstream ReadFile;

	// eine existierende Datei zum Lesen �ffnen:
	ReadFile.open(pFilename);

	if (ReadFile.good() == false)
		return false;

	ReadFile >> NumOfOutputSynapses;

	NumOfOutputSynapsesMax = NumOfOutputSynapses;
	
	pOutputSynapseActivityStatusArray = new (std::nothrow) bool[NumOfOutputSynapses];

	pOutputSynapsePlasticityArray = new (std::nothrow) float[NumOfOutputSynapses];
	pReceiverNeuronIDArray = new (std::nothrow) uint32_t[NumOfOutputSynapses];

	pOutputSynapseMinBlockingValueArray = new (std::nothrow) float[NumOfOutputSynapses];
	pOutputSynapseMaxBlockingValueArray = new (std::nothrow) float[NumOfOutputSynapses];

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		pOutputSynapseActivityStatusArray[i] = true;
		pOutputSynapsePlasticityArray[i] = 0.0f;
		pReceiverNeuronIDArray[i] = 0;
		pOutputSynapseMinBlockingValueArray[i] = 0.0f;
		pOutputSynapseMaxBlockingValueArray[i] = 1.0f;
	}

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		ReadFile >> pReceiverNeuronIDArray[i];
		ReadFile >> pOutputSynapsePlasticityArray[i];
	}


	ReadFile.close();

	return true;
}

bool CNeuron::Load_OutputSynapsePlasticities(const char* pFilename)
{
	std::ifstream ReadFile;

	// eine existierende Datei zum Lesen �ffnen:
	ReadFile.open(pFilename);

	if (ReadFile.good() == false)
		return false;

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		//pOutputSynapsePlasticityArray[i] = 0.0f;
		ReadFile >> pOutputSynapsePlasticityArray[i];
		//cout << pOutputSynapsePlasticityArray[i] << endl;
	}


	ReadFile.close();

	//getchar();

	return true;
}


void CNeuron::Update_NeuronInput(float value)
{
	if (UsedAsRBFNeuron == false)
	{
		NeuronInput += value;
		return;
	}

	float tempFloat = pRBFCentroidValueArray[RBFInputCounter] - value;
	tempFloat *= tempFloat;

	RBFCentroidDistanceSqSum += tempFloat;
	RBFInputCounter++;
}

void CNeuron::Propagate_BinaryValue(uint32_t synapseID)
{
	if (Dropout == true)
		return;

	if (NeuronOutput < pOutputSynapseMinBlockingValueArray[synapseID])
		return;
	if (NeuronOutput > pOutputSynapseMaxBlockingValueArray[synapseID])
		return;

	uint32_t receiverNeuronID = pReceiverNeuronIDArray[synapseID];
	pUsedNeuronArray[receiverNeuronID].NeuronInput += 1.0f;
}

void CNeuron::Propagate_BinaryValue(void)
{
	if (Dropout == true)
		return;

	uint32_t receiverNeuronID;

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		if(NeuronOutput < pOutputSynapseMinBlockingValueArray[i])
			continue;
		if (NeuronOutput > pOutputSynapseMaxBlockingValueArray[i])
			continue;

		receiverNeuronID = pReceiverNeuronIDArray[i];
		pUsedNeuronArray[receiverNeuronID].NeuronInput += 1.0f;
	}
}

void CNeuron::Propagate_SynapticOutput(uint32_t synapseID)
{
	if (Dropout == true)
		return;

	if (NeuronOutput == 0.0f)
		return;

	uint32_t receiverNeuronID = pReceiverNeuronIDArray[synapseID];
	//pUsedNeuronArray[receiverNeuronID].NeuronInput += NeuronOutput*pOutputSynapsePlasticityArray[synapseID];
	pUsedNeuronArray[receiverNeuronID].Update_NeuronInput(NeuronOutput*pOutputSynapsePlasticityArray[synapseID]);
}

void CNeuron::Propagate_SynapticOutput(void)
{
	if(Dropout == true)
		return;

	if (NeuronOutput == 0.0f)
		return;

	uint32_t receiverNeuronID;

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		if (pOutputSynapseActivityStatusArray[i] == false)
			continue;

		receiverNeuronID = pReceiverNeuronIDArray[i];
		//pUsedNeuronArray[receiverNeuronID].NeuronInput += NeuronOutput*pOutputSynapsePlasticityArray[i];
		pUsedNeuronArray[receiverNeuronID].Update_NeuronInput(NeuronOutput*pOutputSynapsePlasticityArray[i]);
	}
}

void CNeuron::Propagate_MaximumAbsolutSynapticOutput(uint32_t synapseID)
{
	if (Dropout == true)
		return;

	//if (NeuronOutput == 0.0f)
		//return;

	uint32_t receiverNeuronID = pReceiverNeuronIDArray[synapseID];

	float absValue = abs(pUsedNeuronArray[receiverNeuronID].NeuronInput);
	float value = NeuronOutput*pOutputSynapsePlasticityArray[synapseID];

	if (abs(value) > absValue)
		pUsedNeuronArray[receiverNeuronID].NeuronInput = value;
}

void CNeuron::Propagate_MaximumAbsolutSynapticOutput(void)
{
	if (Dropout == true)
		return;

	//if (NeuronOutput == 0.0f)
		//return;

	uint32_t receiverNeuronID;
	float value, absValue;

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		receiverNeuronID = pReceiverNeuronIDArray[i];

		absValue = abs(pUsedNeuronArray[receiverNeuronID].NeuronInput);
		value = NeuronOutput*pOutputSynapsePlasticityArray[i];
	
		if(abs(value) > absValue)
			pUsedNeuronArray[receiverNeuronID].NeuronInput = value;
	}
}

void CNeuron::Propagate_MaximumSynapticOutput(uint32_t synapseID)
{
	if (Dropout == true)
		return;

	//if (NeuronOutput == 0.0f)
		//return;

	uint32_t receiverNeuronID = pReceiverNeuronIDArray[synapseID];
	pUsedNeuronArray[receiverNeuronID].NeuronInput = max(NeuronOutput*pOutputSynapsePlasticityArray[synapseID], pUsedNeuronArray[receiverNeuronID].NeuronInput);
}

void CNeuron::Propagate_MinimumSynapticOutput(uint32_t synapseID)
{
	if (Dropout == true)
		return;

	//if (NeuronOutput == 0.0f)
		//return;

	uint32_t receiverNeuronID = pReceiverNeuronIDArray[synapseID];
	pUsedNeuronArray[receiverNeuronID].NeuronInput = min(NeuronOutput*pOutputSynapsePlasticityArray[synapseID], pUsedNeuronArray[receiverNeuronID].NeuronInput);
}

void CNeuron::Propagate_MaximumSynapticOutput(void)
{
	if (Dropout == true)
		return;

	//if (NeuronOutput == 0.0f)
		//return;

	uint32_t receiverNeuronID;

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		receiverNeuronID = pReceiverNeuronIDArray[i];
		pUsedNeuronArray[receiverNeuronID].NeuronInput = max(NeuronOutput*pOutputSynapsePlasticityArray[i], pUsedNeuronArray[receiverNeuronID].NeuronInput);
	}
}

void CNeuron::Propagate_MinimumSynapticOutput(void)
{
	if (Dropout == true)
		return;

	//if (NeuronOutput == 0.0f)
		//return;

	uint32_t receiverNeuronID;

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		receiverNeuronID = pReceiverNeuronIDArray[i];
		pUsedNeuronArray[receiverNeuronID].NeuronInput = min(NeuronOutput*pOutputSynapsePlasticityArray[i], pUsedNeuronArray[receiverNeuronID].NeuronInput);
	}
}


void CNeuron::Calculate_NeuronOutput_And_Retain_Input(void)
{
	NeuronOutput_LastCalculationStep = NeuronOutput;
	NeuronOutput = pActivationFunction(NeuronInput);

	RBFInputCounter = 0;
	RBFCentroidDistanceSqSum = 0.0f;
}

void CNeuron::Calculate_NeuronOutput(void)
{
	if (UsedAsRBFNeuron == true)
		NeuronInput = RBF_Factor*RBFCentroidDistanceSqSum;
	
	NeuronOutput_LastCalculationStep = NeuronOutput;
	NeuronOutput = pActivationFunction(NeuronInput);
	NeuronInput = 0.0f;

	RBFInputCounter = 0;
	RBFCentroidDistanceSqSum = 0.0f;
}

void CNeuron::Accumulate_NeuronInput_And_Calculate_NeuronOutput(float minOutputValue)
{
	NeuronOutput_LastCalculationStep = NeuronOutput;
	NeuronOutput = pActivationFunction(NeuronInput);

	RBFInputCounter = 0;
	RBFCentroidDistanceSqSum = 0.0f;

	if (NeuronOutput < minOutputValue)
		return;

	NeuronInput = 0.0f;
}

void CNeuron::Accumulate_NeuronInput_And_Calculate_NeuronOutput(float minOutputValue, float maxOutputValue)
{
	NeuronOutput_LastCalculationStep = NeuronOutput;
	NeuronOutput = pActivationFunction(NeuronInput);

	RBFInputCounter = 0;
	RBFCentroidDistanceSqSum = 0.0f;

	if (NeuronOutput < minOutputValue)
		return;
	if (NeuronOutput > maxOutputValue)
		return;

	NeuronInput = 0.0f;
}

void CNeuron::Calculate_NeuronOutput(float inputDecrease, float minInputValue)
{
	NeuronOutput_LastCalculationStep = NeuronOutput;
	NeuronOutput = pActivationFunction(NeuronInput);
	NeuronInput -= inputDecrease;
	NeuronInput = max(minInputValue, NeuronInput);

	RBFInputCounter = 0;
	RBFCentroidDistanceSqSum = 0.0f;
}

void CNeuron::Accumulate_NeuronInput_And_Calculate_NeuronOutput(float minOutputValue, float inputDecrease, float minInputValue)
{
	NeuronOutput_LastCalculationStep = NeuronOutput;
	NeuronOutput = pActivationFunction(NeuronInput);

	RBFInputCounter = 0;
	RBFCentroidDistanceSqSum = 0.0f;

	if (NeuronOutput < minOutputValue)
		return;

	NeuronInput -= inputDecrease;
	NeuronInput = max(minInputValue, NeuronInput);
}

void CNeuron::Accumulate_NeuronInput_And_Calculate_NeuronOutput(float minOutputValue, float maxOutputValue, float inputDecrease, float minInputValue)
{
	NeuronOutput_LastCalculationStep = NeuronOutput;
	NeuronOutput = pActivationFunction(NeuronInput);

	RBFInputCounter = 0;
	RBFCentroidDistanceSqSum = 0.0f;

	if (NeuronOutput < minOutputValue)
		return;
	if (NeuronOutput > maxOutputValue)
		return;

	NeuronInput -= inputDecrease;
	NeuronInput = max(minInputValue, NeuronInput);
}

void CNeuron::Reset_NeuronOutput(void)
{
	NeuronOutput_LastCalculationStep = 0.0f;
	NeuronOutput = 0.0f;
	NeuronInput = 0.0f;
	RBFInputCounter = 0;
	RBFCentroidDistanceSqSum = 0.0f;
}



float CNeuron::Get_NeuronOutput(void)
{
	return NeuronOutput;
}

void CNeuron::Set_BiasNeuronOutput(float value)
{
	if (UsedAsBiasNeuron == false)
		return;

	NeuronOutput = value;
}

void CNeuron::Set_NeuronOutput(float value)
{
	if (UsedAsBiasNeuron == true)
		return;

	NeuronOutput = value;
}





void CNeuron::Set_Error(float value)
{
	ErrorValue = value;
}

float CNeuron::Calculate_Error(float desiredNeuronOutputValue)
{
	if (UsedAsInputNeuron == true)
	{
		ErrorValue = 0.0f;
		return 0.0f;
	}

	// Abweichung:
	float variance = desiredNeuronOutputValue - NeuronOutput;
	ErrorValue = variance * ErrorFactor1 * exp(-(ErrorFactor2 * NeuronOutput * NeuronOutput));

	/* Hinweis: Wenn bereits eine geringe Neuronenaktivit�t (NeuronOutput)
	zu einer gro�en Abweichung f�hrt, ist auch der Fehler gro�. Abweichungen
	bei einer starken Neuronenaktivit�t f�hren hingegen zu einem kleineren
	Fehler. */


	return variance*variance;
}

float CNeuron::Calculate_Error_WithUserDefFunction(float desiredNeuronOutput)
{
	if (UsedAsInputNeuron == true)
	{
		ErrorValue = 0.0f;
		return 0.0f;
	}

	// Abweichung:
	float variance = desiredNeuronOutput - NeuronOutput;
	ErrorValue = variance * pUserDefErrorFunction(NeuronOutput);

	return variance*variance;
}

void CNeuron::Calculate_Error(void)
{
	if (UsedAsInputNeuron == true)
	{
		ErrorValue = 0.0f;
		return;
	}


	uint32_t receiverNeuronID;

	float errorSum = 0.0f;

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		receiverNeuronID = pReceiverNeuronIDArray[i];
		errorSum += pUsedNeuronArray[receiverNeuronID].ErrorValue * pOutputSynapsePlasticityArray[i];
	}

	ErrorValue = errorSum * ErrorFactor1 * exp(-(ErrorFactor2 * NeuronOutput * NeuronOutput));

	/* Hinweis: Abweichungen bei einer geringen Neuronenaktivit�t f�hren
	zu einem gr��eren Fehler. Abweichungen bei einer starken Neuronenaktivit�t
	f�hren hingegen zu einem kleineren Fehler. */
}

void CNeuron::Calculate_InputNeuronError(void)
{
	if (UsedAsInputNeuron == false)
	{
		ErrorValue = 0.0f;
		return;
	}

	uint32_t receiverNeuronID;

	float errorSum = 0.0f;

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		receiverNeuronID = pReceiverNeuronIDArray[i];
		errorSum += pUsedNeuronArray[receiverNeuronID].ErrorValue * pOutputSynapsePlasticityArray[i];
	}

	ErrorValue = errorSum * ErrorFactor1 * exp(-(ErrorFactor2 * NeuronOutput * NeuronOutput));

	/* Hinweis: Abweichungen bei einer geringen Neuronenaktivit�t f�hren
	zu einem gr��eren Fehler. Abweichungen bei einer starken Neuronenaktivit�t
	f�hren hingegen zu einem kleineren Fehler. */
}

void CNeuron::Calculate_Error_WithUserDefFunction(void)
{
	if (UsedAsInputNeuron == true)
	{
		ErrorValue = 0.0f;
		return;
	}


	uint32_t receiverNeuronID;

	float errorSum = 0.0f;

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		receiverNeuronID = pReceiverNeuronIDArray[i];
		errorSum += pUsedNeuronArray[receiverNeuronID].ErrorValue * pOutputSynapsePlasticityArray[i];
	}

	ErrorValue = errorSum * pUserDefErrorFunction(NeuronOutput);

	
}

void CNeuron::Calculate_InputNeuronError_WithUserDefFunction(void)
{
	if (UsedAsInputNeuron == false)
	{
		ErrorValue = 0.0f;
		return;
	}

	uint32_t receiverNeuronID;

	float errorSum = 0.0f;

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		receiverNeuronID = pReceiverNeuronIDArray[i];
		errorSum += pUsedNeuronArray[receiverNeuronID].ErrorValue * pOutputSynapsePlasticityArray[i];
	}

	ErrorValue = errorSum * pUserDefErrorFunction(NeuronOutput);


}


void CNeuron::Remove_Unused_Connections(void)
{
	/*uint32_t counter = 0;

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		if (pOutputSynapsePlasticityArray[i] == 0.0f)
			counter++;
	}

	
	uint32_t numOfUsedConnections = NumOfOutputSynapses - counter;

	float *pTempPlasticityArray = new (std::nothrow) float[numOfUsedConnections];
	uint32_t *pTempReceiverNeuronIDArray = new (std::nothrow) uint32_t[numOfUsedConnections];

	counter = 0;*/

	uint32_t numOfUsedConnections = 0;

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		if (pOutputSynapsePlasticityArray[i] != 0.0f && pOutputSynapseActivityStatusArray[i] == true)
			numOfUsedConnections++;
	}

	float *pTempPlasticityArray = new (std::nothrow) float[numOfUsedConnections];
	uint32_t *pTempReceiverNeuronIDArray = new (std::nothrow) uint32_t[numOfUsedConnections];
	
	uint32_t counter = 0;

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		if (pOutputSynapsePlasticityArray[i] != 0.0f)
		{
			pTempPlasticityArray[counter] = pOutputSynapsePlasticityArray[i];
			pTempReceiverNeuronIDArray[counter] = pReceiverNeuronIDArray[i];

			counter++;
		}
	}

	delete[] pOutputSynapseActivityStatusArray;
	pOutputSynapseActivityStatusArray = nullptr;

	delete[] pOutputSynapsePlasticityArray;
	pOutputSynapsePlasticityArray = nullptr;

	delete[] pReceiverNeuronIDArray;
	pReceiverNeuronIDArray = nullptr;

	NumOfOutputSynapses = numOfUsedConnections;

	pOutputSynapsePlasticityArray = new (std::nothrow) float[NumOfOutputSynapses];
	pReceiverNeuronIDArray = new (std::nothrow) uint32_t[NumOfOutputSynapses];
	pOutputSynapseActivityStatusArray = new (std::nothrow) bool[numOfUsedConnections];

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		pOutputSynapseActivityStatusArray[i] = true;
		pOutputSynapsePlasticityArray[i] = pTempPlasticityArray[i];
		pReceiverNeuronIDArray[i] = pTempReceiverNeuronIDArray[i];
	}

	delete[] pTempReceiverNeuronIDArray;
	pTempReceiverNeuronIDArray = nullptr;

	delete[] pTempPlasticityArray;
	pTempPlasticityArray = nullptr;
}

void CNeuron::Round_OutputWeights(float precision, float invPrecision)
{
	float fValue;
	int32_t iValue;

	
	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		iValue = static_cast<int32_t>(invPrecision * pOutputSynapsePlasticityArray[i]);
		fValue = static_cast<float>(iValue);
		fValue *= precision;

		pOutputSynapsePlasticityArray[i] = fValue;
	}
}

void CNeuron::Adjust_OutputSynapses_AfterErrorCalculations(void)
{
	if (UsedAsOutputNeuron == true)
		return;

	uint32_t receiverNeuronID;

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		receiverNeuronID = pReceiverNeuronIDArray[i];
		pOutputSynapsePlasticityArray[i] += LearningRate * pUsedNeuronArray[receiverNeuronID].ErrorValue * NeuronOutput;
	}
}

void CNeuron::Adjust_OutputSynapse_AfterErrorCalculations(uint32_t synapseID)
{
	if (UsedAsOutputNeuron == true)
		return;

	uint32_t receiverNeuronID = pReceiverNeuronIDArray[synapseID];
	pOutputSynapsePlasticityArray[synapseID] += LearningRate * pUsedNeuronArray[receiverNeuronID].ErrorValue * NeuronOutput;
}

void CNeuron::Adjust_OutputSynapse_AfterErrorCalculations2(uint32_t receiverNeuronID)
{
	if (UsedAsOutputNeuron == true)
		return;

	uint32_t synapseID = 0;

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		if (pReceiverNeuronIDArray[i] == receiverNeuronID)
		{
			synapseID = i;
			break;
		}
	}

	pOutputSynapsePlasticityArray[synapseID] += LearningRate * pUsedNeuronArray[receiverNeuronID].ErrorValue * NeuronOutput;
}

void CNeuron::Adjust_OutputSynapses_AfterErrorCalculationsExt(void)
{
	if (UsedAsOutputNeuron == true)
		return;

	uint32_t receiverNeuronID;

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		receiverNeuronID = pReceiverNeuronIDArray[i];
		//pOutputSynapsePlasticityArray[i] += LearningRate * (RandomNumbers.Get_FloatNumber(constMinRandomOutputSynapsePlasticity, constMaxRandomOutputSynapsePlasticity) + pUsedNeuronArray[receiverNeuronID].ErrorValue * NeuronOutput);
		pOutputSynapsePlasticityArray[i] += LearningRate * (pUsedNeuronArray[receiverNeuronID].ErrorValue + RandomNumbers.Get_FloatNumber(constMinRandomOutputSynapsePlasticity, constMaxRandomOutputSynapsePlasticity)) * NeuronOutput;
	}
}

void CNeuron::Adjust_OutputSynapse_AfterErrorCalculationsExt(uint32_t synapseID)
{
	if (UsedAsOutputNeuron == true)
		return;

	uint32_t receiverNeuronID = pReceiverNeuronIDArray[synapseID];
	//pOutputSynapsePlasticityArray[synapseID] += LearningRate * (RandomNumbers.Get_FloatNumber(constMinRandomOutputSynapsePlasticity, constMaxRandomOutputSynapsePlasticity) + pUsedNeuronArray[receiverNeuronID].ErrorValue * NeuronOutput);
	pOutputSynapsePlasticityArray[synapseID] += LearningRate * (pUsedNeuronArray[receiverNeuronID].ErrorValue + RandomNumbers.Get_FloatNumber(constMinRandomOutputSynapsePlasticity, constMaxRandomOutputSynapsePlasticity)) * NeuronOutput;
}

void CNeuron::Adjust_OutputSynapse_AfterErrorCalculationsExt2(uint32_t receiverNeuronID)
{
	if (UsedAsOutputNeuron == true)
		return;

	uint32_t synapseID = 0;

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		if (pReceiverNeuronIDArray[i] == receiverNeuronID)
		{
			synapseID = i;
			break;
		}
	}

	//pOutputSynapsePlasticityArray[synapseID] += LearningRate * (RandomNumbers.Get_FloatNumber(constMinRandomOutputSynapsePlasticity, constMaxRandomOutputSynapsePlasticity) + pUsedNeuronArray[receiverNeuronID].ErrorValue * NeuronOutput);
	pOutputSynapsePlasticityArray[synapseID] += LearningRate * (pUsedNeuronArray[receiverNeuronID].ErrorValue + RandomNumbers.Get_FloatNumber(constMinRandomOutputSynapsePlasticity, constMaxRandomOutputSynapsePlasticity)) * NeuronOutput;
}


void CNeuron::Set_DropoutState(bool state)
{
	Dropout = state;
}

void CNeuron::Init_RBFCentroid(uint32_t numOfRBFCentroidValues)
{
	Use_As_RBFNeuron();

	RBFInputCounter = 0;
	RBFCentroidDistanceSqSum = 0.0f;

	delete[] pRBFCentroidValueArray;
	pRBFCentroidValueArray = nullptr;

	NumOfRBFCentroidValues = numOfRBFCentroidValues;

	pRBFCentroidValueArray = new (std::nothrow) float[numOfRBFCentroidValues];

	for (uint32_t i = 0; i < numOfRBFCentroidValues; i++)
		pRBFCentroidValueArray[i] = 0.0f;
}

void CNeuron::Set_RBFCentroidValues(float rBF_Factor, float *pValueArray)
{
	RBF_Factor = rBF_Factor;

	RBFInputCounter = 0;

	for (uint32_t i = 0; i < NumOfRBFCentroidValues; i++)
		pRBFCentroidValueArray[i] = pValueArray[i];
}

void CNeuron::Clone(const CNeuron &originalObject)
{
	delete[] pOutputSynapseActivityStatusArray;
	pOutputSynapseActivityStatusArray = nullptr;

	delete[] pOutputSynapsePlasticityArray;
	pOutputSynapsePlasticityArray = nullptr;

	delete[] pOutputSynapseMinBlockingValueArray;
	pOutputSynapseMinBlockingValueArray = nullptr;

	delete[] pOutputSynapseMaxBlockingValueArray;
	pOutputSynapseMaxBlockingValueArray = nullptr;

	delete[] pReceiverNeuronIDArray;
	pReceiverNeuronIDArray = nullptr;

	delete[] pRBFCentroidValueArray;
	pRBFCentroidValueArray = nullptr;

	Dropout = originalObject.Dropout;
	UsedAsInputNeuron = originalObject.UsedAsInputNeuron;
	UsedAsHiddenNeuron = originalObject.UsedAsHiddenNeuron;
	UsedAsOutputNeuron = originalObject.UsedAsOutputNeuron;
	UsedAsBiasNeuron = originalObject.UsedAsBiasNeuron;
	UsedAsMemoryNeuron = originalObject.UsedAsMemoryNeuron;
	UsedAsRBFNeuron = originalObject.UsedAsRBFNeuron;

	NeuronInput = originalObject.NeuronInput;
	NeuronOutput = originalObject.NeuronOutput;
	NeuronOutput_LastCalculationStep = originalObject.NeuronOutput_LastCalculationStep;

	ErrorValue = originalObject.ErrorValue;
	ErrorFactor1 = originalObject.ErrorFactor1;
	ErrorFactor2 = originalObject.ErrorFactor2;

	LearningRate = originalObject.LearningRate;

	pActivationFunction = originalObject.pActivationFunction;

	NumOfOutputSynapses = originalObject.NumOfOutputSynapses;

	pOutputSynapseActivityStatusArray = new (std::nothrow) bool[NumOfOutputSynapses];
	pOutputSynapsePlasticityArray = new (std::nothrow) float[NumOfOutputSynapses];
	pOutputSynapseMinBlockingValueArray = new (std::nothrow) float[NumOfOutputSynapses];
	pOutputSynapseMaxBlockingValueArray = new (std::nothrow) float[NumOfOutputSynapses];
	pReceiverNeuronIDArray = new (std::nothrow) uint32_t[NumOfOutputSynapses];

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		pOutputSynapseActivityStatusArray[i] = originalObject.pOutputSynapseActivityStatusArray[i];
		pOutputSynapsePlasticityArray[i] = originalObject.pOutputSynapsePlasticityArray[i];
		pOutputSynapseMinBlockingValueArray[i] = originalObject.pOutputSynapseMinBlockingValueArray[i];
		pOutputSynapseMaxBlockingValueArray[i] = originalObject.pOutputSynapseMaxBlockingValueArray[i];
		pReceiverNeuronIDArray[i] = originalObject.pReceiverNeuronIDArray[i];
	}

	RBFInputCounter = 0;
	RBFCentroidDistanceSqSum = 0.0f;

	NumOfRBFCentroidValues = originalObject.NumOfRBFCentroidValues;

	pRBFCentroidValueArray = new (std::nothrow) float[NumOfRBFCentroidValues];

	for (uint32_t i = 0; i < NumOfRBFCentroidValues; i++)
		pRBFCentroidValueArray[i] = originalObject.pRBFCentroidValueArray[i];
}

void CNeuron::Clone_Data(const CNeuron &originalObject)
{
	Dropout = originalObject.Dropout;

	UsedAsInputNeuron = originalObject.UsedAsInputNeuron;
	UsedAsHiddenNeuron = originalObject.UsedAsHiddenNeuron;
	UsedAsOutputNeuron = originalObject.UsedAsOutputNeuron;
	UsedAsBiasNeuron = originalObject.UsedAsBiasNeuron;
	UsedAsMemoryNeuron = originalObject.UsedAsMemoryNeuron;
	UsedAsRBFNeuron = originalObject.UsedAsRBFNeuron;

	NeuronInput = originalObject.NeuronInput;
	NeuronOutput = originalObject.NeuronOutput;
	NeuronOutput_LastCalculationStep = originalObject.NeuronOutput_LastCalculationStep;

	ErrorValue = originalObject.ErrorValue;
	ErrorFactor1 = originalObject.ErrorFactor1;
	ErrorFactor2 = originalObject.ErrorFactor2;

	LearningRate = originalObject.LearningRate;

	pActivationFunction = originalObject.pActivationFunction;

	NumOfOutputSynapses = originalObject.NumOfOutputSynapses;
	

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		pOutputSynapseActivityStatusArray[i] = originalObject.pOutputSynapseActivityStatusArray[i];
		pOutputSynapsePlasticityArray[i] = originalObject.pOutputSynapsePlasticityArray[i];
		pOutputSynapseMinBlockingValueArray[i] = originalObject.pOutputSynapseMinBlockingValueArray[i];
		pOutputSynapseMaxBlockingValueArray[i] = originalObject.pOutputSynapseMaxBlockingValueArray[i];
		pReceiverNeuronIDArray[i] = originalObject.pReceiverNeuronIDArray[i];
	}

	RBFInputCounter = 0;
	RBFCentroidDistanceSqSum = 0.0f;

	NumOfRBFCentroidValues = originalObject.NumOfRBFCentroidValues;

	for (uint32_t i = 0; i < NumOfRBFCentroidValues; i++)
		pRBFCentroidValueArray[i] = originalObject.pRBFCentroidValueArray[i];
}


CLongTermMemoryNeuron::CLongTermMemoryNeuron()
{}

CLongTermMemoryNeuron::~CLongTermMemoryNeuron()
{
	delete[] pSynapsePlasticityArray;
	pSynapsePlasticityArray = nullptr;
}

void CLongTermMemoryNeuron::Init_Neuron(uint32_t numOfMemorySynapses)
{
	delete[] pSynapsePlasticityArray;
	pSynapsePlasticityArray = nullptr;

	Activity = 0.0f;

	Counter = 0.0f;
	InvCounter = 1.0f;

	NumOfMemorySynapses = numOfMemorySynapses;
	NumOfMemorySynapsesPlus1 = numOfMemorySynapses + 1;

	pSynapsePlasticityArray = new (std::nothrow) float[NumOfMemorySynapsesPlus1];

	for (uint32_t i = 0; i < NumOfMemorySynapsesPlus1; i++)
		pSynapsePlasticityArray[i] = 0.0f;
}

void CLongTermMemoryNeuron::Connect_With_Brain(CNeuron* pNeuronArray)
{
	pUsedNeuronArray = pNeuronArray;
}

void CLongTermMemoryNeuron::Reduce_PlasticityValues(float decreaseValue, float minPlasticityValue)
{
	for (uint32_t i = 0; i < NumOfMemorySynapses; i++)
	{
		pSynapsePlasticityArray[i] -= decreaseValue;
		pSynapsePlasticityArray[i] = max(minPlasticityValue, pSynapsePlasticityArray[i]);
	}
}

void CLongTermMemoryNeuron::Reset_Memory(void)
{
	Counter = 0.0f;
	InvCounter = 1.0f;

	for (uint32_t i = 0; i < NumOfMemorySynapsesPlus1; i++)
		pSynapsePlasticityArray[i] = 0.0f;
}

void CLongTermMemoryNeuron::Add_MemoryValue(int32_t synapseID, float value)
{
	pSynapsePlasticityArray[synapseID] += value;
}

void CLongTermMemoryNeuron::Set_MemoryValue(int32_t synapseID, float value)
{
	pSynapsePlasticityArray[synapseID] = value;
}

float CLongTermMemoryNeuron::Get_MemoryValue(int32_t synapseID)
{
	return pSynapsePlasticityArray[synapseID];
}

void CLongTermMemoryNeuron::Update_Memory(int32_t synapseID, int32_t inputNeuronID, float learningRate)
{
	if (synapseID == 0)
	{
		Counter += 1.0f;
		InvCounter = 1.0f / Counter;
	}

	pSynapsePlasticityArray[synapseID] += learningRate*pUsedNeuronArray[inputNeuronID].NeuronOutput;
}




void CLongTermMemoryNeuron::Transfer_Plasticity_To_DestinationNeuron(int32_t synapseID, int32_t destinationNeuronID, int32_t destinationNeuronSynapseID, float plasticityMultiplier)
{
	pUsedNeuronArray[destinationNeuronID].pOutputSynapsePlasticityArray[destinationNeuronSynapseID] = plasticityMultiplier * pSynapsePlasticityArray[synapseID];
}

void CLongTermMemoryNeuron::Transfer_Plasticity_To_DestinationNeuron(int32_t synapseID, int32_t destinationNeuronID, int32_t destinationNeuronSynapseID)
{
	float plasticityMultiplier = InvCounter / static_cast<float>(NumOfMemorySynapses);
	pUsedNeuronArray[destinationNeuronID].pOutputSynapsePlasticityArray[destinationNeuronSynapseID] = plasticityMultiplier * pSynapsePlasticityArray[synapseID];
}






void CLongTermMemoryNeuron::Propagate_Memory(int32_t synapseID, int32_t receiverNeuronID)
{
	pUsedNeuronArray[receiverNeuronID].NeuronInput += Activity * pSynapsePlasticityArray[synapseID];
}


void CLongTermMemoryNeuron::Reset_Activity(void)
{
	Activity = 0.0f;
}

void CLongTermMemoryNeuron::Set_Activity(float value)
{
	Activity = value;
}


C2State2DCellularAutomatonRules::C2State2DCellularAutomatonRules()
{
	for (int32_t i = 0; i < 8; i++)
	{
		BirthRuleArray[i] = 0;
		SurvivingRuleArray[i] = 0;
	}
}

void C2State2DCellularAutomatonRules::Reset(void)
{
	NumBirthRules = 0;
	NumSurvivingRules = 0;

	for (int32_t i = 0; i < 8; i++)
	{
		BirthRuleArray[i] = 0;
		SurvivingRuleArray[i] = 0;
	}
}

C2DCellularAutomata::C2DCellularAutomata()
{}

C2DCellularAutomataF::C2DCellularAutomataF()
{}

C2DCellularAutomata::~C2DCellularAutomata()
{
	delete[] pCellMap1;
	pCellMap1 = nullptr;

	delete[] pCellMap2;
	pCellMap2 = nullptr;
}

C2DCellularAutomataF::~C2DCellularAutomataF()
{
	delete[] pCellMap1;
	pCellMap1 = nullptr;

	delete[] pCellMap2;
	pCellMap2 = nullptr;
}

void C2DCellularAutomata::Set_CellValue(int32_t cellIID, int32_t value)
{
	PtrToLastUpdatedCellMap[cellIID] = value;
}

void C2DCellularAutomataF::Set_CellValue(int32_t cellIID, float value)
{
	PtrToLastUpdatedCellMap[cellIID] = value;
}

void C2DCellularAutomata::Set_CellValue(int32_t cellPosX, int32_t cellPosY, int32_t value)
{
	PtrToLastUpdatedCellMap[cellPosX + cellPosY * NumCellsXDir] = value;
}

void C2DCellularAutomataF::Set_CellValue(int32_t cellPosX, int32_t cellPosY, float value)
{
	PtrToLastUpdatedCellMap[cellPosX + cellPosY * NumCellsXDir] = value;
}

int32_t C2DCellularAutomata::Get_CellValue(int32_t cellIID)
{
	return PtrToLastUpdatedCellMap[cellIID];
}

int32_t C2DCellularAutomata::Get_PrevCellValue(int32_t cellIID)
{
	if(PtrToLastUpdatedCellMap = pCellMap1)
		return pCellMap2[cellIID];
	else
		return pCellMap1[cellIID];
}


float C2DCellularAutomataF::Get_CellValue(int32_t cellIID)
{
	return PtrToLastUpdatedCellMap[cellIID];
}

float C2DCellularAutomataF::Get_PrevCellValue(int32_t cellIID)
{
	if (PtrToLastUpdatedCellMap = pCellMap1)
		return pCellMap2[cellIID];
	else
		return pCellMap1[cellIID];
}


int32_t C2DCellularAutomata::Get_CellValue(int32_t cellPosX, int32_t cellPosY)
{
	return PtrToLastUpdatedCellMap[cellPosX + cellPosY * NumCellsXDir];
}

int32_t C2DCellularAutomata::Get_PrevCellValue(int32_t cellPosX, int32_t cellPosY)
{
	if (PtrToLastUpdatedCellMap = pCellMap1)
		return pCellMap2[cellPosX + cellPosY * NumCellsXDir];
	else
		return pCellMap1[cellPosX + cellPosY * NumCellsXDir];
}

float C2DCellularAutomataF::Get_CellValue(int32_t cellPosX, int32_t cellPosY)
{
	return PtrToLastUpdatedCellMap[cellPosX + cellPosY * NumCellsXDir];
}

float C2DCellularAutomataF::Get_PrevCellValue(int32_t cellPosX, int32_t cellPosY)
{
	if (PtrToLastUpdatedCellMap = pCellMap1)
		return pCellMap2[cellPosX + cellPosY * NumCellsXDir];
	else
		return pCellMap1[cellPosX + cellPosY * NumCellsXDir];
}

void C2DCellularAutomata::Get_PtrToLastUpdatedCellMap(int32_t **ppOut)
{
	*ppOut = PtrToLastUpdatedCellMap;
}

void C2DCellularAutomataF::Get_PtrToLastUpdatedCellMap(float **ppOut)
{
	*ppOut = PtrToLastUpdatedCellMap;
}

void C2DCellularAutomata::Init_CellularAutomata(int32_t numCellsXDir, int32_t numCellsYDir)
{
	delete[] pCellMap1;
	pCellMap1 = nullptr;

	delete[] pCellMap2;
	pCellMap2 = nullptr;

	NumCellsXDir = numCellsXDir;
	NumCellsYDir = numCellsYDir;

	NumCellsXDirMinus1 = numCellsXDir - 1;
	NumCellsYDirMinus1 = numCellsYDir - 1;

	NumCells = numCellsXDir * numCellsYDir;

	pCellMap1 = new int32_t[NumCells];
	pCellMap2 = new int32_t[NumCells];

	int32_t ix, iy, id;

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			id = ix + iy * NumCellsXDir;

			pCellMap1[id] = Value_DeadCell;
			pCellMap2[id] = Value_DeadCell;
		}
	}

	PtrToLastUpdatedCellMap = pCellMap1;
}

void C2DCellularAutomataF::Init_CellularAutomata(int32_t numCellsXDir, int32_t numCellsYDir)
{
	delete[] pCellMap1;
	pCellMap1 = nullptr;

	delete[] pCellMap2;
	pCellMap2 = nullptr;

	NumCellsXDir = numCellsXDir;
	NumCellsYDir = numCellsYDir;

	NumCellsXDirMinus1 = numCellsXDir - 1;
	NumCellsYDirMinus1 = numCellsYDir - 1;

	NumCells = numCellsXDir * numCellsYDir;

	pCellMap1 = new float[NumCells];
	pCellMap2 = new float[NumCells];

	int32_t ix, iy, id;

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			id = ix + iy * NumCellsXDir;

			pCellMap1[id] = Value_DeadCell;
			pCellMap2[id] = Value_DeadCell;
		}
	}

	PtrToLastUpdatedCellMap = pCellMap1;
}

void C2DCellularAutomata::Reset_CellMap(int32_t cellValue)
{
	int32_t ix, iy, id;

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			id = ix + iy * NumCellsXDir;

			pCellMap1[id] = cellValue;
			pCellMap2[id] = cellValue;
		}
	}

	PtrToLastUpdatedCellMap = pCellMap1;
}

void C2DCellularAutomataF::Reset_CellMap(float cellValue)
{
	int32_t ix, iy, id;

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			id = ix + iy * NumCellsXDir;

			pCellMap1[id] = cellValue;
			pCellMap2[id] = cellValue;
		}
	}

	PtrToLastUpdatedCellMap = pCellMap1;
}

void C2DCellularAutomata::Kill_All_Cells(void)
{
	int32_t ix, iy, id;

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			id = ix + iy * NumCellsXDir;

			pCellMap1[id] = Value_DeadCell;
			pCellMap2[id] = Value_DeadCell;
		}
	}

	PtrToLastUpdatedCellMap = pCellMap1;
}

void C2DCellularAutomataF::Kill_All_Cells(void)
{
	int32_t ix, iy, id;

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			id = ix + iy * NumCellsXDir;

			pCellMap1[id] = Value_DeadCell;
			pCellMap2[id] = Value_DeadCell;
		}
	}

	PtrToLastUpdatedCellMap = pCellMap1;
}

void C2DCellularAutomata::Init_CellMap(CRandomNumbersNN *pRandomNumbers, int32_t minXPos, int32_t maxXPos, int32_t minYPos, int32_t maxYPos, int32_t densityValue, int32_t invDensity)
{
	/*minXPos = max(minXPos, 0);
	maxXPos = min(maxXPos, NumCellsXDir);

	minYPos = max(minYPos, 0);
	maxYPos = min(maxYPos, NumCellsYDir);*/

	int32_t ix, iy, id;

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			id = ix + iy * NumCellsXDir;

			pCellMap1[id] = Value_DeadCell;
			pCellMap2[id] = Value_DeadCell;
		}
	}

	for (iy = minYPos; iy < maxYPos; iy++)
	{
		for (ix = minXPos; ix < maxXPos; ix++)
		{
			if (pRandomNumbers->Get_IntegerNumber(0, invDensity) < densityValue)
			{
				id = ix + iy * NumCellsXDir;

				pCellMap1[id] = Value_LivingCell;
			}
		}
	}

	PtrToLastUpdatedCellMap = pCellMap1;
}

void C2DCellularAutomataF::Init_CellMap(CRandomNumbersNN *pRandomNumbers, int32_t minXPos, int32_t maxXPos, int32_t minYPos, int32_t maxYPos, int32_t densityValue, int32_t invDensity)
{
	/*minXPos = max(minXPos, 0);
	maxXPos = min(maxXPos, NumCellsXDir);

	minYPos = max(minYPos, 0);
	maxYPos = min(maxYPos, NumCellsYDir);*/

	int32_t ix, iy, id;

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			id = ix + iy * NumCellsXDir;

			pCellMap1[id] = Value_DeadCell;
			pCellMap2[id] = Value_DeadCell;
		}
	}

	for (iy = minYPos; iy < maxYPos; iy++)
	{
		for (ix = minXPos; ix < maxXPos; ix++)
		{
			if (pRandomNumbers->Get_IntegerNumber(0, invDensity) < densityValue)
			{
				id = ix + iy * NumCellsXDir;

				pCellMap1[id] = Value_LivingCell;
			}
		}
	}

	PtrToLastUpdatedCellMap = pCellMap1;
}

void C2DCellularAutomata::Init_CellMap(CRandomNumbersNN *pRandomNumbers, int32_t densityValue, int32_t invDensity)
{
	int32_t ix, iy, id;

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			id = ix + iy * NumCellsXDir;

			pCellMap1[id] = Value_DeadCell;
			pCellMap2[id] = Value_DeadCell;
		}
	}

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			if (pRandomNumbers->Get_IntegerNumber(0, invDensity) < densityValue)
			{
				id = ix + iy * NumCellsXDir;

				pCellMap1[id] = Value_LivingCell;
			}
		}
	}

	PtrToLastUpdatedCellMap = pCellMap1;
}

void C2DCellularAutomataF::Init_CellMap(CRandomNumbersNN *pRandomNumbers, int32_t densityValue, int32_t invDensity)
{
	int32_t ix, iy, id;

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			id = ix + iy * NumCellsXDir;

			pCellMap1[id] = Value_DeadCell;
			pCellMap2[id] = Value_DeadCell;
		}
	}

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			if (pRandomNumbers->Get_IntegerNumber(0, invDensity) < densityValue)
			{
				id = ix + iy * NumCellsXDir;

				pCellMap1[id] = Value_LivingCell;
			}
		}
	}

	PtrToLastUpdatedCellMap = pCellMap1;
}

void C2DCellularAutomata::Set_CellMapBoarderValue(int32_t value)
{
	int32_t ix;
	int32_t offset = NumCellsYDirMinus1 * NumCellsXDir;

	for (ix = 0; ix < NumCellsXDir; ix++)
	{
		PtrToLastUpdatedCellMap[ix] = value;
		PtrToLastUpdatedCellMap[ix + offset] = value;
	}

	int32_t iy, id;

	for (iy = 1; iy < NumCellsYDirMinus1; iy++)
	{
		id = iy * NumCellsXDir;
		PtrToLastUpdatedCellMap[id] = value;

		id += NumCellsXDirMinus1;
		PtrToLastUpdatedCellMap[id] = value;
	}
}

void C2DCellularAutomataF::Set_CellMapBoarderValue(float value)
{
	int32_t ix;
	int32_t offset = NumCellsYDirMinus1 * NumCellsXDir;

	for (ix = 0; ix < NumCellsXDir; ix++)
	{
		PtrToLastUpdatedCellMap[ix] = value;
		PtrToLastUpdatedCellMap[ix + offset] = value;
	}

	int32_t iy, id;

	for (iy = 1; iy < NumCellsYDirMinus1; iy++)
	{
		id = iy * NumCellsXDir;
		PtrToLastUpdatedCellMap[id] = value;

		id += NumCellsXDirMinus1;
		PtrToLastUpdatedCellMap[id] = value;
	}
}

void C2DCellularAutomata::Exchange_CellsValue(int32_t oldValue, int32_t newValue)
{
	int32_t ix, iy, id;

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			id = ix + iy * NumCellsXDir;

			if (PtrToLastUpdatedCellMap[id] == oldValue)
				PtrToLastUpdatedCellMap[id] = newValue;
		}
	}
}

void C2DCellularAutomataF::Exchange_CellsValue(float oldValue, float newValue)
{
	int32_t ix, iy, id;

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			id = ix + iy * NumCellsXDir;

			if (PtrToLastUpdatedCellMap[id] == oldValue)
				PtrToLastUpdatedCellMap[id] = newValue;
		}
	}
}

void C2DCellularAutomata::Exchange_LivingAndDeadCells(void)
{
	int32_t ix, iy, id;

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			id = ix + iy * NumCellsXDir;
			
			if (PtrToLastUpdatedCellMap[id] == Value_DeadCell)
				PtrToLastUpdatedCellMap[id] = Value_LivingCell;
			else
				PtrToLastUpdatedCellMap[id] = Value_DeadCell;
		}
	}
}

void C2DCellularAutomataF::Exchange_LivingAndDeadCells(void)
{
	int32_t ix, iy, id;

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			id = ix + iy * NumCellsXDir;

			if (PtrToLastUpdatedCellMap[id] == Value_DeadCell)
				PtrToLastUpdatedCellMap[id] = Value_LivingCell;
			else
				PtrToLastUpdatedCellMap[id] = Value_DeadCell;
		}
	}
}

void C2DCellularAutomata::Output_CellMap(void)
{
	int32_t ix, iy, id;

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			id = ix + iy * NumCellsXDir;
			cout << PtrToLastUpdatedCellMap[id] << " ";
		}

		cout << endl;
	}

	cout << endl << endl;
}

void C2DCellularAutomataF::Output_CellMap(void)
{
	int32_t ix, iy, id;

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			id = ix + iy * NumCellsXDir;
			cout << PtrToLastUpdatedCellMap[id] << " ";
		}

		cout << endl;
	}

	cout << endl << endl;
}

bool C2DCellularAutomata::Save_CellMap(const char* pFilename, int32_t valueLivingCell, int32_t valueDeadCell)
{
	std::ofstream WriteFile;

	// neue Datei erzeugen bzw. alte �berschreiben:
	WriteFile.open(pFilename);

	// neue Datei erzeugen bzw. Inhalt ans Ende einer bestehenden Datei schreiben: 
	//WriteFile.open(pFilename, ios::app);

	if (WriteFile.good() == false)
		return false;

	int32_t ix, iy, id;

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			id = ix + iy * NumCellsXDir;

			if (PtrToLastUpdatedCellMap[id] == Value_LivingCell)
				WriteFile << valueLivingCell << " ";
			else
				WriteFile << valueDeadCell << " ";
		}

		WriteFile << endl;
	}

	WriteFile.close();

	return true;
}

bool C2DCellularAutomataF::Save_CellMap(const char* pFilename, float valueLivingCell, float valueDeadCell)
{
	std::ofstream WriteFile;

	// neue Datei erzeugen bzw. alte �berschreiben:
	WriteFile.open(pFilename);

	// neue Datei erzeugen bzw. Inhalt ans Ende einer bestehenden Datei schreiben: 
	//WriteFile.open(pFilename, ios::app);

	if (WriteFile.good() == false)
		return false;

	int32_t ix, iy, id;

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			id = ix + iy * NumCellsXDir;

			if (PtrToLastUpdatedCellMap[id] == Value_LivingCell)
				WriteFile << valueLivingCell << " ";
			else
				WriteFile << valueDeadCell << " ";
		}

		WriteFile << endl;
	}

	WriteFile.close();

	return true;
}

bool C2DCellularAutomata::Save_CellMap(const char* pFilename)
{
	std::ofstream WriteFile;

	// neue Datei erzeugen bzw. alte �berschreiben:
	WriteFile.open(pFilename);

	// neue Datei erzeugen bzw. Inhalt ans Ende einer bestehenden Datei schreiben: 
	//WriteFile.open(pFilename, ios::app);

	if (WriteFile.good() == false)
		return false;

	int32_t ix, iy, id;

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			id = ix + iy * NumCellsXDir;

			WriteFile << PtrToLastUpdatedCellMap[id] << " ";
		}

		WriteFile <<  endl;
	}

	WriteFile.close();

	return true;
}

bool C2DCellularAutomataF::Save_CellMap(const char* pFilename)
{
	std::ofstream WriteFile;

	// neue Datei erzeugen bzw. alte �berschreiben:
	WriteFile.open(pFilename);

	// neue Datei erzeugen bzw. Inhalt ans Ende einer bestehenden Datei schreiben: 
	//WriteFile.open(pFilename, ios::app);

	if (WriteFile.good() == false)
		return false;

	int32_t ix, iy, id;

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			id = ix + iy * NumCellsXDir;

			WriteFile << PtrToLastUpdatedCellMap[id] << " ";
		}

		WriteFile << endl;
	}

	WriteFile.close();

	return true;
}

bool C2DCellularAutomata::Save_CellMapPattern(const char* pFilename, int32_t value)
{
	std::ofstream WriteFile;

	// neue Datei erzeugen bzw. alte �berschreiben:
	WriteFile.open(pFilename);

	// neue Datei erzeugen bzw. Inhalt ans Ende einer bestehenden Datei schreiben: 
	//WriteFile.open(pFilename, ios::app);

	if (WriteFile.good() == false)
		return false;

	int32_t ix, iy, id;

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			id = ix + iy * NumCellsXDir;
	
			WriteFile << value << " ";
			
		}

		WriteFile << endl;
	}

	WriteFile.close();

	return true;
}

bool C2DCellularAutomataF::Save_CellMapPattern(const char* pFilename, float value)
{
	std::ofstream WriteFile;

	// neue Datei erzeugen bzw. alte �berschreiben:
	WriteFile.open(pFilename);

	// neue Datei erzeugen bzw. Inhalt ans Ende einer bestehenden Datei schreiben: 
	//WriteFile.open(pFilename, ios::app);

	if (WriteFile.good() == false)
		return false;

	int32_t ix, iy, id;

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			id = ix + iy * NumCellsXDir;

			WriteFile << value << " ";

		}

		WriteFile << endl;
	}

	WriteFile.close();

	return true;
}

void C2DCellularAutomata::Smooth_BorderlessCellMap(int32_t smoothingValue)
{
	int32_t ix, iy;
	int32_t iix, iiy;
	int32_t id;

	int32_t numOfAdjacentCells_Alive;

	if (PtrToLastUpdatedCellMap == pCellMap1)
	{
		for (iy = 0; iy < NumCellsYDir; iy++)
		{
			for (ix = 0; ix < NumCellsXDir; ix++)
			{
				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						id = ((ix + iix) % NumCellsXDir) + ((iy + iiy) % NumCellsYDir) * NumCellsXDir;

						if (pCellMap1[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = (ix % NumCellsXDir) + (iy % NumCellsYDir) * NumCellsXDir;

				if (pCellMap1[id] == Value_BlockingCell)
				{
					pCellMap2[id] = Value_BlockingCell;
					continue;
				}

				pCellMap2[id] = pCellMap1[id];

				if (numOfAdjacentCells_Alive < smoothingValue)
					pCellMap2[id] = Value_DeadCell;
			}
		}

		PtrToLastUpdatedCellMap = pCellMap2;
	}
	else if (PtrToLastUpdatedCellMap == pCellMap2)
	{
		for (iy = 0; iy < NumCellsYDir; iy++)
		{
			for (ix = 0; ix < NumCellsXDir; ix++)
			{
				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						id = ((ix + iix) % NumCellsXDir) + ((iy + iiy) % NumCellsYDir) * NumCellsXDir;
						
						if (pCellMap2[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = (ix % NumCellsXDir) + (iy % NumCellsYDir) * NumCellsXDir;

				if (pCellMap2[id] == Value_BlockingCell)
				{
					pCellMap1[id] = Value_BlockingCell;
					continue;
				}

				pCellMap1[id] = pCellMap2[id];

				if (numOfAdjacentCells_Alive < smoothingValue)
					pCellMap1[id] = Value_DeadCell;
			}
		}

		PtrToLastUpdatedCellMap = pCellMap1;
	}
}

void C2DCellularAutomataF::Smooth_BorderlessCellMap(int32_t smoothingValue)
{
	int32_t ix, iy;
	int32_t iix, iiy;
	int32_t id;

	int32_t numOfAdjacentCells_Alive;

	if (PtrToLastUpdatedCellMap == pCellMap1)
	{
		for (iy = 0; iy < NumCellsYDir; iy++)
		{
			for (ix = 0; ix < NumCellsXDir; ix++)
			{
				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						id = ((ix + iix) % NumCellsXDir) + ((iy + iiy) % NumCellsYDir) * NumCellsXDir;

						if (pCellMap1[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = (ix % NumCellsXDir) + (iy % NumCellsYDir) * NumCellsXDir;

				if (pCellMap1[id] == Value_BlockingCell)
				{
					pCellMap2[id] = Value_BlockingCell;
					continue;
				}

				pCellMap2[id] = pCellMap1[id];

				if (numOfAdjacentCells_Alive < smoothingValue)
					pCellMap2[id] = Value_DeadCell;
			}
		}

		PtrToLastUpdatedCellMap = pCellMap2;
	}
	else if (PtrToLastUpdatedCellMap == pCellMap2)
	{
		for (iy = 0; iy < NumCellsYDir; iy++)
		{
			for (ix = 0; ix < NumCellsXDir; ix++)
			{
				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						id = ((ix + iix) % NumCellsXDir) + ((iy + iiy) % NumCellsYDir) * NumCellsXDir;

						if (pCellMap2[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = (ix % NumCellsXDir) + (iy % NumCellsYDir) * NumCellsXDir;

				if (pCellMap2[id] == Value_BlockingCell)
				{
					pCellMap1[id] = Value_BlockingCell;
					continue;
				}

				pCellMap1[id] = pCellMap2[id];

				if (numOfAdjacentCells_Alive < smoothingValue)
					pCellMap1[id] = Value_DeadCell;
			}
		}

		PtrToLastUpdatedCellMap = pCellMap1;
	}
}

void C2DCellularAutomata::Detect_Edges(int32_t valueEdgeCell)
{
	int32_t ix, iy;
	int32_t iix, iiy;
	int32_t id;

	int32_t numOfAdjacentCells_Alive;

	if (PtrToLastUpdatedCellMap == pCellMap1)
	{
		for (iy = 1; iy < NumCellsYDirMinus1; iy++)
		{
			for (ix = 1; ix < NumCellsXDirMinus1; ix++)
			{

				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						id = ix + iix + (iy + iiy) * NumCellsXDir;

						if (pCellMap1[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = ix + iy * NumCellsXDir;

				if (pCellMap1[id] == Value_BlockingCell)
				{
					pCellMap2[id] = Value_BlockingCell;
					continue;
				}

				if (pCellMap1[id] == Value_DeadCell)
				{
					pCellMap2[id] = Value_DeadCell;
					continue;
				}

				pCellMap2[id] = pCellMap1[id];

				if (numOfAdjacentCells_Alive < 8)
					pCellMap2[id] = valueEdgeCell;
			}
		}

		PtrToLastUpdatedCellMap = pCellMap2;
	}
	else if (PtrToLastUpdatedCellMap == pCellMap2)
	{
		for (iy = 1; iy < NumCellsYDirMinus1; iy++)
		{
			for (ix = 1; ix < NumCellsXDirMinus1; ix++)
			{

				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						id = ix + iix + (iy + iiy) * NumCellsXDir;

						if (pCellMap2[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = ix + iy * NumCellsXDir;

				if (pCellMap2[id] == Value_BlockingCell)
				{
					pCellMap1[id] = Value_BlockingCell;
					continue;
				}

				if (pCellMap2[id] == Value_DeadCell)
				{
					pCellMap1[id] = Value_DeadCell;
					continue;
				}

				pCellMap1[id] = pCellMap2[id];

				if (numOfAdjacentCells_Alive < 8)
					pCellMap1[id] = valueEdgeCell;
			}
		}

		PtrToLastUpdatedCellMap = pCellMap1;
	}
}

void C2DCellularAutomata::Detect_Edges2(int32_t valueNonEdgeCell)
{
	int32_t ix, iy;
	int32_t iix, iiy;
	int32_t id;

	int32_t numOfAdjacentCells_Alive;

	if (PtrToLastUpdatedCellMap == pCellMap1)
	{
		for (iy = 1; iy < NumCellsYDirMinus1; iy++)
		{
			for (ix = 1; ix < NumCellsXDirMinus1; ix++)
			{

				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						id = ix + iix + (iy + iiy) * NumCellsXDir;

						if (pCellMap1[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = ix + iy * NumCellsXDir;

				if (pCellMap1[id] == Value_BlockingCell)
				{
					pCellMap2[id] = Value_BlockingCell;
					continue;
				}

				if (pCellMap1[id] == Value_DeadCell)
				{
					pCellMap2[id] = Value_DeadCell;
					continue;
				}

				pCellMap2[id] = pCellMap1[id];

				if (numOfAdjacentCells_Alive == 8)
					pCellMap2[id] = valueNonEdgeCell;
			}
		}

		PtrToLastUpdatedCellMap = pCellMap2;
	}
	else if (PtrToLastUpdatedCellMap == pCellMap2)
	{
		for (iy = 1; iy < NumCellsYDirMinus1; iy++)
		{
			for (ix = 1; ix < NumCellsXDirMinus1; ix++)
			{

				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						id = ix + iix + (iy + iiy) * NumCellsXDir;

						if (pCellMap2[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = ix + iy * NumCellsXDir;

				if (pCellMap2[id] == Value_BlockingCell)
				{
					pCellMap1[id] = Value_BlockingCell;
					continue;
				}

				if (pCellMap2[id] == Value_DeadCell)
				{
					pCellMap1[id] = Value_DeadCell;
					continue;
				}

				pCellMap1[id] = pCellMap2[id];

				if (numOfAdjacentCells_Alive == 8)
					pCellMap1[id] = valueNonEdgeCell;
			}
		}

		PtrToLastUpdatedCellMap = pCellMap1;
	}
}

void C2DCellularAutomataF::Detect_Edges2(float valueNonEdgeCell)
{
	int32_t ix, iy;
	int32_t iix, iiy;
	int32_t id;

	int32_t numOfAdjacentCells_Alive;

	if (PtrToLastUpdatedCellMap == pCellMap1)
	{
		for (iy = 1; iy < NumCellsYDirMinus1; iy++)
		{
			for (ix = 1; ix < NumCellsXDirMinus1; ix++)
			{

				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						id = ix + iix + (iy + iiy) * NumCellsXDir;

						if (pCellMap1[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = ix + iy * NumCellsXDir;

				if (pCellMap1[id] == Value_BlockingCell)
				{
					pCellMap2[id] = Value_BlockingCell;
					continue;
				}

				if (pCellMap1[id] == Value_DeadCell)
				{
					pCellMap2[id] = Value_DeadCell;
					continue;
				}

				pCellMap2[id] = pCellMap1[id];

				if (numOfAdjacentCells_Alive == 8)
					pCellMap2[id] = valueNonEdgeCell;
			}
		}

		PtrToLastUpdatedCellMap = pCellMap2;
	}
	else if (PtrToLastUpdatedCellMap == pCellMap2)
	{
		for (iy = 1; iy < NumCellsYDirMinus1; iy++)
		{
			for (ix = 1; ix < NumCellsXDirMinus1; ix++)
			{

				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						id = ix + iix + (iy + iiy) * NumCellsXDir;

						if (pCellMap2[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = ix + iy * NumCellsXDir;

				if (pCellMap2[id] == Value_BlockingCell)
				{
					pCellMap1[id] = Value_BlockingCell;
					continue;
				}

				if (pCellMap2[id] == Value_DeadCell)
				{
					pCellMap1[id] = Value_DeadCell;
					continue;
				}

				pCellMap1[id] = pCellMap2[id];

				if (numOfAdjacentCells_Alive == 8)
					pCellMap1[id] = valueNonEdgeCell;
			}
		}

		PtrToLastUpdatedCellMap = pCellMap1;
	}
}

void C2DCellularAutomataF::Detect_Edges(float valueEdgeCell)
{
	int32_t ix, iy;
	int32_t iix, iiy;
	int32_t id;

	int32_t numOfAdjacentCells_Alive;

	if (PtrToLastUpdatedCellMap == pCellMap1)
	{
		for (iy = 1; iy < NumCellsYDirMinus1; iy++)
		{
			for (ix = 1; ix < NumCellsXDirMinus1; ix++)
			{

				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						id = ix + iix + (iy + iiy) * NumCellsXDir;

						if (pCellMap1[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = ix + iy * NumCellsXDir;

				if (pCellMap1[id] == Value_BlockingCell)
				{
					pCellMap2[id] = Value_BlockingCell;
					continue;
				}

				if (pCellMap1[id] == Value_DeadCell)
				{
					pCellMap2[id] = Value_DeadCell;
					continue;
				}

				pCellMap2[id] = pCellMap1[id];

				if (numOfAdjacentCells_Alive < 8)
					pCellMap2[id] = valueEdgeCell;
			}
		}

		PtrToLastUpdatedCellMap = pCellMap2;
	}
	else if (PtrToLastUpdatedCellMap == pCellMap2)
	{
		for (iy = 1; iy < NumCellsYDirMinus1; iy++)
		{
			for (ix = 1; ix < NumCellsXDirMinus1; ix++)
			{

				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						id = ix + iix + (iy + iiy) * NumCellsXDir;

						if (pCellMap2[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = ix + iy * NumCellsXDir;

				if (pCellMap2[id] == Value_BlockingCell)
				{
					pCellMap1[id] = Value_BlockingCell;
					continue;
				}

				if (pCellMap2[id] == Value_DeadCell)
				{
					pCellMap1[id] = Value_DeadCell;
					continue;
				}

				pCellMap1[id] = pCellMap2[id];

				if (numOfAdjacentCells_Alive < 8)
					pCellMap1[id] = valueEdgeCell;
			}
		}

		PtrToLastUpdatedCellMap = pCellMap1;
	}
}

void C2DCellularAutomata::Smooth_CellMap(int32_t smoothingValue)
{
	int32_t ix, iy;
	int32_t iix, iiy;
	int32_t id;

	int32_t numOfAdjacentCells_Alive;

	if (PtrToLastUpdatedCellMap == pCellMap1)
	{
		for (iy = 1; iy < NumCellsYDirMinus1; iy++)
		{
			for (ix = 1; ix < NumCellsXDirMinus1; ix++)
			{

				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						id = ix + iix + (iy + iiy) * NumCellsXDir;

						if (pCellMap1[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = ix + iy * NumCellsXDir;

				if (pCellMap1[id] == Value_BlockingCell)
				{
					pCellMap2[id] = Value_BlockingCell;
					continue;
				}

				pCellMap2[id] = pCellMap1[id];

				if (numOfAdjacentCells_Alive < smoothingValue)
					pCellMap2[id] = Value_DeadCell;
			}
		}

		PtrToLastUpdatedCellMap = pCellMap2;
	}
	else if (PtrToLastUpdatedCellMap == pCellMap2)
	{
		for (iy = 1; iy < NumCellsYDirMinus1; iy++)
		{
			for (ix = 1; ix < NumCellsXDirMinus1; ix++)
			{

				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						id = ix + iix + (iy + iiy) * NumCellsXDir;

						if (pCellMap2[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = ix + iy * NumCellsXDir;

				if (pCellMap2[id] == Value_BlockingCell)
				{
					pCellMap1[id] = Value_BlockingCell;
					continue;
				}

				pCellMap1[id] = pCellMap2[id];

				if (numOfAdjacentCells_Alive < smoothingValue)
					pCellMap1[id] = Value_DeadCell;
			}
		}

		PtrToLastUpdatedCellMap = pCellMap1;
	}
}

void C2DCellularAutomataF::Smooth_CellMap(int32_t smoothingValue)
{
	int32_t ix, iy;
	int32_t iix, iiy;
	int32_t id;

	int32_t numOfAdjacentCells_Alive;

	if (PtrToLastUpdatedCellMap == pCellMap1)
	{
		for (iy = 1; iy < NumCellsYDirMinus1; iy++)
		{
			for (ix = 1; ix < NumCellsXDirMinus1; ix++)
			{

				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						id = ix + iix + (iy + iiy) * NumCellsXDir;

						if (pCellMap1[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = ix + iy * NumCellsXDir;

				if (pCellMap1[id] == Value_BlockingCell)
				{
					pCellMap2[id] = Value_BlockingCell;
					continue;
				}

				pCellMap2[id] = pCellMap1[id];

				if (numOfAdjacentCells_Alive < smoothingValue)
					pCellMap2[id] = Value_DeadCell;
			}
		}

		PtrToLastUpdatedCellMap = pCellMap2;
	}
	else if (PtrToLastUpdatedCellMap == pCellMap2)
	{
		for (iy = 1; iy < NumCellsYDirMinus1; iy++)
		{
			for (ix = 1; ix < NumCellsXDirMinus1; ix++)
			{

				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						id = ix + iix + (iy + iiy) * NumCellsXDir;

						if (pCellMap2[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = ix + iy * NumCellsXDir;

				if (pCellMap2[id] == Value_BlockingCell)
				{
					pCellMap1[id] = Value_BlockingCell;
					continue;
				}

				pCellMap1[id] = pCellMap2[id];

				if (numOfAdjacentCells_Alive < smoothingValue)
					pCellMap1[id] = Value_DeadCell;
			}
		}

		PtrToLastUpdatedCellMap = pCellMap1;
	}
}

void C2DCellularAutomata::Update_CellMap(C2State2DCellularAutomatonRules *pRules)
{
	int32_t ix, iy;
	int32_t iix, iiy;
	int32_t i;
	int32_t id;

	int32_t numOfAdjacentCells_Alive;

	if (PtrToLastUpdatedCellMap == pCellMap1)
	{
		for (iy = 1; iy < NumCellsYDirMinus1; iy++)
		{
			for (ix = 1; ix < NumCellsXDirMinus1; ix++)
			{

				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						id = ix + iix + (iy + iiy) * NumCellsXDir;

						if (pCellMap1[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = ix + iy * NumCellsXDir;

				if (pCellMap1[id] == Value_BlockingCell)
				{
					pCellMap2[id] = Value_BlockingCell;
					continue;
				}

				// apply surviving rules:
				if (pCellMap1[id] == Value_LivingCell)
				{
					pCellMap2[id] = Value_DeadCell;

					for (i = 0; i < pRules->NumSurvivingRules; i++)
					{
						if (numOfAdjacentCells_Alive == pRules->SurvivingRuleArray[i])
						{
							pCellMap2[id] = Value_LivingCell;
							break;
						}
					}
				}

				// apply birth rules:
				else if (pCellMap1[id] == Value_DeadCell)
				{
					pCellMap2[id] = Value_DeadCell;

					for (i = 0; i < pRules->NumBirthRules; i++)
					{
						if (numOfAdjacentCells_Alive == pRules->BirthRuleArray[i])
						{
							pCellMap2[id] = Value_LivingCell;
							break;
						}
					}
				}
			}
		}

		PtrToLastUpdatedCellMap = pCellMap2;
	}
	else if (PtrToLastUpdatedCellMap == pCellMap2)
	{
		for (iy = 1; iy < NumCellsYDirMinus1; iy++)
		{
			for (ix = 1; ix < NumCellsXDirMinus1; ix++)
			{
				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						id = ix + iix + (iy + iiy) * NumCellsXDir;

						if (pCellMap2[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = ix + iy * NumCellsXDir;

				if (pCellMap2[id] == Value_BlockingCell)
				{
					pCellMap1[id] = Value_BlockingCell;
					continue;
				}

				// apply surviving rules:
				if (pCellMap2[id] == Value_LivingCell)
				{
					pCellMap1[id] = Value_DeadCell;

					for (i = 0; i < pRules->NumSurvivingRules; i++)
					{
						if (numOfAdjacentCells_Alive == pRules->SurvivingRuleArray[i])
						{
							pCellMap1[id] = Value_LivingCell;
							break;
						}
					}
				}

				// apply birth rules:
				else if (pCellMap2[id] == Value_DeadCell)
				{
					pCellMap1[id] = Value_DeadCell;

					for (i = 0; i < pRules->NumBirthRules; i++)
					{
						if (numOfAdjacentCells_Alive == pRules->BirthRuleArray[i])
						{
							pCellMap1[id] = Value_LivingCell;
							break;
						}
					}
				}
			}
		}

		PtrToLastUpdatedCellMap = pCellMap1;
	}
}

void C2DCellularAutomata::Update_BorderlessCellMap(C2State2DCellularAutomatonRules *pRules)
{
	int32_t ix, iy;
	int32_t iix, iiy;
	int32_t i;
	int32_t id;

	int32_t numOfAdjacentCells_Alive;

	if (PtrToLastUpdatedCellMap == pCellMap1)
	{
		for (iy = 0; iy < NumCellsYDir; iy++)
		{
			for (ix = 0; ix < NumCellsXDir; ix++)
			{

				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						
						id = ((ix + iix) % NumCellsXDir) + ((iy + iiy) % NumCellsYDir) * NumCellsXDir;

						if (pCellMap1[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = (ix % NumCellsXDir) + (iy % NumCellsYDir) * NumCellsXDir;

				if (pCellMap1[id] == Value_BlockingCell)
				{
					pCellMap2[id] = Value_BlockingCell;
					continue;
				}

				// apply surviving rules:
				if (pCellMap1[id] == Value_LivingCell)
				{
					pCellMap2[id] = Value_DeadCell;

					for (i = 0; i < pRules->NumSurvivingRules; i++)
					{
						if (numOfAdjacentCells_Alive == pRules->SurvivingRuleArray[i])
						{
							pCellMap2[id] = Value_LivingCell;
							break;
						}
					}
				}

				// apply birth rules:
				else if (pCellMap1[id] == Value_DeadCell)
				{
					pCellMap2[id] = Value_DeadCell;

					for (i = 0; i < pRules->NumBirthRules; i++)
					{
						if (numOfAdjacentCells_Alive == pRules->BirthRuleArray[i])
						{
							pCellMap2[id] = Value_LivingCell;
							break;
						}
					}
				}
			}
		}

		PtrToLastUpdatedCellMap = pCellMap2;
	}
	else if (PtrToLastUpdatedCellMap == pCellMap2)
	{
		for (iy = 0; iy < NumCellsYDir; iy++)
		{
			for (ix = 0; ix < NumCellsXDir; ix++)
			{
				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						id = ((ix + iix) % NumCellsXDir) + ((iy + iiy) % NumCellsYDir) * NumCellsXDir;

						if (pCellMap2[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = (ix % NumCellsXDir) + (iy % NumCellsYDir) * NumCellsXDir;

				if (pCellMap2[id] == Value_BlockingCell)
				{
					pCellMap1[id] = Value_BlockingCell;
					continue;
				}

				// apply surviving rules:
				if (pCellMap2[id] == Value_LivingCell)
				{
					pCellMap1[id] = Value_DeadCell;

					for (i = 0; i < pRules->NumSurvivingRules; i++)
					{
						if (numOfAdjacentCells_Alive == pRules->SurvivingRuleArray[i])
						{
							pCellMap1[id] = Value_LivingCell;
							break;
						}
					}
				}

				// apply birth rules:
				else if (pCellMap2[id] == Value_DeadCell)
				{
					pCellMap1[id] = Value_DeadCell;

					for (i = 0; i < pRules->NumBirthRules; i++)
					{
						if (numOfAdjacentCells_Alive == pRules->BirthRuleArray[i])
						{
							pCellMap1[id] = Value_LivingCell;
							break;
						}
					}
				}
			}
		}

		PtrToLastUpdatedCellMap = pCellMap1;
	}
}

void C2DCellularAutomataF::Update_BorderlessCellMap(C2State2DCellularAutomatonRules *pRules)
{
	int32_t ix, iy;
	int32_t iix, iiy;
	int32_t i;
	int32_t id;

	int32_t numOfAdjacentCells_Alive;

	if (PtrToLastUpdatedCellMap == pCellMap1)
	{
		for (iy = 0; iy < NumCellsYDir; iy++)
		{
			for (ix = 0; ix < NumCellsXDir; ix++)
			{

				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;


						id = ((ix + iix) % NumCellsXDir) + ((iy + iiy) % NumCellsYDir) * NumCellsXDir;

						if (pCellMap1[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = (ix % NumCellsXDir) + (iy % NumCellsYDir) * NumCellsXDir;

				if (pCellMap1[id] == Value_BlockingCell)
				{
					pCellMap2[id] = Value_BlockingCell;
					continue;
				}

				// apply surviving rules:
				if (pCellMap1[id] == Value_LivingCell)
				{
					pCellMap2[id] = Value_DeadCell;

					for (i = 0; i < pRules->NumSurvivingRules; i++)
					{
						if (numOfAdjacentCells_Alive == pRules->SurvivingRuleArray[i])
						{
							pCellMap2[id] = Value_LivingCell;
							break;
						}
					}
				}

				// apply birth rules:
				else if (pCellMap1[id] == Value_DeadCell)
				{
					pCellMap2[id] = Value_DeadCell;

					for (i = 0; i < pRules->NumBirthRules; i++)
					{
						if (numOfAdjacentCells_Alive == pRules->BirthRuleArray[i])
						{
							pCellMap2[id] = Value_LivingCell;
							break;
						}
					}
				}
			}
		}

		PtrToLastUpdatedCellMap = pCellMap2;
	}
	else if (PtrToLastUpdatedCellMap == pCellMap2)
	{
		for (iy = 0; iy < NumCellsYDir; iy++)
		{
			for (ix = 0; ix < NumCellsXDir; ix++)
			{
				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						id = ((ix + iix) % NumCellsXDir) + ((iy + iiy) % NumCellsYDir) * NumCellsXDir;

						if (pCellMap2[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = (ix % NumCellsXDir) + (iy % NumCellsYDir) * NumCellsXDir;

				if (pCellMap2[id] == Value_BlockingCell)
				{
					pCellMap1[id] = Value_BlockingCell;
					continue;
				}

				// apply surviving rules:
				if (pCellMap2[id] == Value_LivingCell)
				{
					pCellMap1[id] = Value_DeadCell;

					for (i = 0; i < pRules->NumSurvivingRules; i++)
					{
						if (numOfAdjacentCells_Alive == pRules->SurvivingRuleArray[i])
						{
							pCellMap1[id] = Value_LivingCell;
							break;
						}
					}
				}

				// apply birth rules:
				else if (pCellMap2[id] == Value_DeadCell)
				{
					pCellMap1[id] = Value_DeadCell;

					for (i = 0; i < pRules->NumBirthRules; i++)
					{
						if (numOfAdjacentCells_Alive == pRules->BirthRuleArray[i])
						{
							pCellMap1[id] = Value_LivingCell;
							break;
						}
					}
				}
			}
		}

		PtrToLastUpdatedCellMap = pCellMap1;
	}
}

void C2DCellularAutomataF::Update_CellMap(C2State2DCellularAutomatonRules *pRules)
{
	int32_t ix, iy;
	int32_t iix, iiy;
	int32_t i;
	int32_t id;

	int32_t numOfAdjacentCells_Alive;

	if (PtrToLastUpdatedCellMap == pCellMap1)
	{
		for (iy = 1; iy < NumCellsYDirMinus1; iy++)
		{
			for (ix = 1; ix < NumCellsXDirMinus1; ix++)
			{

				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						id = ix + iix + (iy + iiy) * NumCellsXDir;

						if (pCellMap1[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = ix + iy * NumCellsXDir;

				if (pCellMap1[id] == Value_BlockingCell)
				{
					pCellMap2[id] = Value_BlockingCell;
					continue;
				}

				// apply surviving rules:
				if (pCellMap1[id] == Value_LivingCell)
				{
					pCellMap2[id] = Value_DeadCell;

					for (i = 0; i < pRules->NumSurvivingRules; i++)
					{
						if (numOfAdjacentCells_Alive == pRules->SurvivingRuleArray[i])
						{
							pCellMap2[id] = Value_LivingCell;
							break;
						}
					}
				}

				// apply birth rules:
				else if (pCellMap1[id] == Value_DeadCell)
				{
					pCellMap2[id] = Value_DeadCell;

					for (i = 0; i < pRules->NumBirthRules; i++)
					{
						if (numOfAdjacentCells_Alive == pRules->BirthRuleArray[i])
						{
							pCellMap2[id] = Value_LivingCell;
							break;
						}
					}
				}
			}
		}

		PtrToLastUpdatedCellMap = pCellMap2;
	}
	else if (PtrToLastUpdatedCellMap == pCellMap2)
	{
		for (iy = 1; iy < NumCellsYDirMinus1; iy++)
		{
			for (ix = 1; ix < NumCellsXDirMinus1; ix++)
			{
				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						id = ix + iix + (iy + iiy) * NumCellsXDir;

						if (pCellMap2[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = ix + iy * NumCellsXDir;

				if (pCellMap2[id] == Value_BlockingCell)
				{
					pCellMap1[id] = Value_BlockingCell;
					continue;
				}

				// apply surviving rules:
				if (pCellMap2[id] == Value_LivingCell)
				{
					pCellMap1[id] = Value_DeadCell;

					for (i = 0; i < pRules->NumSurvivingRules; i++)
					{
						if (numOfAdjacentCells_Alive == pRules->SurvivingRuleArray[i])
						{
							pCellMap1[id] = Value_LivingCell;
							break;
						}
					}
				}

				// apply birth rules:
				else if (pCellMap2[id] == Value_DeadCell)
				{
					pCellMap1[id] = Value_DeadCell;

					for (i = 0; i < pRules->NumBirthRules; i++)
					{
						if (numOfAdjacentCells_Alive == pRules->BirthRuleArray[i])
						{
							pCellMap1[id] = Value_LivingCell;
							break;
						}
					}
				}
			}
		}

		PtrToLastUpdatedCellMap = pCellMap1;
	}
}


CNeuralNetHiddenLayer::CNeuralNetHiddenLayer()
{}

CNeuralNetHiddenLayer::~CNeuralNetHiddenLayer()
{
	delete[] pNeuronIDArray;
	pNeuronIDArray = nullptr;
}

void CNeuralNetHiddenLayer::Init_Layer(uint32_t idOfFirstNeuron, uint32_t numOfNeurons, bool additionalBiasNeuron)
{
	delete[] pNeuronIDArray;
	pNeuronIDArray = nullptr;

	AdditionalBiasNeuron = additionalBiasNeuron;

	NumOfNeurons = numOfNeurons;

	pNeuronIDArray = new (std::nothrow) uint32_t[numOfNeurons];

	for (uint32_t i = 0; i < numOfNeurons; i++)
		pNeuronIDArray[i] = i + idOfFirstNeuron;

	if (additionalBiasNeuron == true)
		BiasNeuronID = idOfFirstNeuron + numOfNeurons;
}

void CNeuralNetHiddenLayer::Reset(void)
{
	delete[] pNeuronIDArray;
	pNeuronIDArray = nullptr;

	AdditionalBiasNeuron = false;
	NumOfNeurons = 0;
}


CNeuralNet::CNeuralNet()
{}

CNeuralNet::~CNeuralNet()
{
	delete[] pNeuronArray;
	pNeuronArray = nullptr;

	delete[] pNumInternalReservoirConnectionsArray;
	pNumInternalReservoirConnectionsArray = nullptr;

	delete[] pActivationSequenceArray;
	pActivationSequenceArray = nullptr;
}

void CNeuralNet::Init_ActivationSequenceArray(uint32_t numOfActivationSequenceArrayEntries)
{
	delete[] pActivationSequenceArray;
	pActivationSequenceArray = nullptr;

	NumOfActivationSequenceArrayEntries = numOfActivationSequenceArrayEntries;

	pActivationSequenceArray = new (std::nothrow) uint32_t[numOfActivationSequenceArrayEntries];

	for (uint32_t i = 0; i < numOfActivationSequenceArrayEntries; i++)
		pActivationSequenceArray[i] = 0;
}

void CNeuralNet::Init_ActivationSequenceArray(uint32_t numOfActivationSequenceArrayEntries, uint32_t *pSequenceArray)
{
	delete[] pActivationSequenceArray;
	pActivationSequenceArray = nullptr;

	NumOfActivationSequenceArrayEntries = numOfActivationSequenceArrayEntries;

	pActivationSequenceArray = new (std::nothrow) uint32_t[numOfActivationSequenceArrayEntries];

	for (uint32_t i = 0; i < numOfActivationSequenceArrayEntries; i++)
		pActivationSequenceArray[i] = pSequenceArray[i];
}

void CNeuralNet::Update_ActivationSequenceArray(uint32_t neuronID, uint32_t entryID)
{
	pActivationSequenceArray[entryID] = neuronID;
}

void CNeuralNet::Disable_Random_InputNeuron_OutputSynapses(uint64_t newSeed, float mutationRate)
{
	RandomNumbers.Change_Seed(newSeed);

	for (uint32_t i = 0; i < NumInputNeurons; i++)
		pNeuronArray[i].Disable_Random_OutputSynapses(&RandomNumbers, mutationRate);

	if (AdditionalInputBiasNeuron == true)
		pNeuronArray[InputBiasNeuronID].Disable_Random_OutputSynapses(&RandomNumbers, mutationRate);
}

void CNeuralNet::Disable_Random_HiddenLayer1Neuron_OutputSynapses(uint64_t newSeed, float mutationRate)
{
	if (HiddenLayer1Used == false)
		return;

	RandomNumbers.Change_Seed(newSeed);

	uint32_t id;
	uint32_t numOfNeurons = HiddenLayer1.NumOfNeurons;

	for (uint32_t i = 0; i < numOfNeurons; i++)
	{
		id = HiddenLayer1.pNeuronIDArray[i];
		pNeuronArray[id].Disable_Random_OutputSynapses(&RandomNumbers, mutationRate);
	}

	if (HiddenLayer1.AdditionalBiasNeuron == true)
		pNeuronArray[HiddenLayer1.BiasNeuronID].Disable_Random_OutputSynapses(&RandomNumbers, mutationRate);
}

void CNeuralNet::Disable_Random_HiddenLayer2Neuron_OutputSynapses(uint64_t newSeed, float probabilityValue)
{
	if (HiddenLayer2Used == false)
		return;

	RandomNumbers.Change_Seed(newSeed);

	uint32_t id;
	uint32_t numOfNeurons = HiddenLayer2.NumOfNeurons;

	for (uint32_t i = 0; i < numOfNeurons; i++)
	{
		id = HiddenLayer2.pNeuronIDArray[i];
		pNeuronArray[id].Disable_Random_OutputSynapses(&RandomNumbers, probabilityValue);
	}

	if (HiddenLayer2.AdditionalBiasNeuron == true)
		pNeuronArray[HiddenLayer2.BiasNeuronID].Disable_Random_OutputSynapses(&RandomNumbers, probabilityValue);
}

void CNeuralNet::Disable_Random_HiddenLayer3Neuron_OutputSynapses(uint64_t newSeed, float mutationRate)
{
	if (HiddenLayer3Used == false)
		return;

	RandomNumbers.Change_Seed(newSeed);

	uint32_t id;
	uint32_t numOfNeurons = HiddenLayer3.NumOfNeurons;

	for (uint32_t i = 0; i < numOfNeurons; i++)
	{
		id = HiddenLayer3.pNeuronIDArray[i];
		pNeuronArray[id].Disable_Random_OutputSynapses(&RandomNumbers, mutationRate);
	}

	if (HiddenLayer3.AdditionalBiasNeuron == true)
		pNeuronArray[HiddenLayer3.BiasNeuronID].Disable_Random_OutputSynapses(&RandomNumbers, mutationRate);
}

void CNeuralNet::Enable_Disabled_InputNeuron_OutputSynapses(uint64_t newSeed, float minPlasticityValue, float maxPlasticityValue)
{
	RandomNumbers.Change_Seed(newSeed);

	for (uint32_t i = 0; i < NumInputNeurons; i++)
		pNeuronArray[i].Enable_Disabled_OutputSynapses(&RandomNumbers, minPlasticityValue, maxPlasticityValue);

	if (AdditionalInputBiasNeuron == true)
		pNeuronArray[InputBiasNeuronID].Enable_Disabled_OutputSynapses(&RandomNumbers, minPlasticityValue, maxPlasticityValue);
}

void CNeuralNet::Enable_Disabled_InputNeuron_OutputSynapses(uint64_t newSeed, float minPlasticityValue, float maxPlasticityValue, float mutationRate)
{
	RandomNumbers.Change_Seed(newSeed);

	for (uint32_t i = 0; i < NumInputNeurons; i++)
		pNeuronArray[i].Enable_Disabled_OutputSynapses(&RandomNumbers, minPlasticityValue, maxPlasticityValue, mutationRate);

	if (AdditionalInputBiasNeuron == true)
		pNeuronArray[InputBiasNeuronID].Enable_Disabled_OutputSynapses(&RandomNumbers, minPlasticityValue, maxPlasticityValue, mutationRate);
}

void CNeuralNet::Enable_Disabled_HiddenLayer1Neuron_OutputSynapses(uint64_t newSeed, float minPlasticityValue, float maxPlasticityValue)
{
	if (HiddenLayer1Used == false)
		return;

	RandomNumbers.Change_Seed(newSeed);

	uint32_t id;
	uint32_t numOfNeurons = HiddenLayer1.NumOfNeurons;

	for (uint32_t i = 0; i < numOfNeurons; i++)
	{
		id = HiddenLayer1.pNeuronIDArray[i];
		pNeuronArray[id].Enable_Disabled_OutputSynapses(&RandomNumbers, minPlasticityValue, maxPlasticityValue);
	}

	if (HiddenLayer1.AdditionalBiasNeuron == true)
		pNeuronArray[HiddenLayer1.BiasNeuronID].Enable_Disabled_OutputSynapses(&RandomNumbers, minPlasticityValue, maxPlasticityValue);
}

void CNeuralNet::Enable_Disabled_HiddenLayer1Neuron_OutputSynapses(uint64_t newSeed, float minPlasticityValue, float maxPlasticityValue, float mutationRate)
{
	if (HiddenLayer1Used == false)
		return;

	RandomNumbers.Change_Seed(newSeed);

	uint32_t id;
	uint32_t numOfNeurons = HiddenLayer1.NumOfNeurons;

	for (uint32_t i = 0; i < numOfNeurons; i++)
	{
		id = HiddenLayer1.pNeuronIDArray[i];
		pNeuronArray[id].Enable_Disabled_OutputSynapses(&RandomNumbers, minPlasticityValue, maxPlasticityValue, mutationRate);
	}

	if (HiddenLayer1.AdditionalBiasNeuron == true)
		pNeuronArray[HiddenLayer1.BiasNeuronID].Enable_Disabled_OutputSynapses(&RandomNumbers, minPlasticityValue, maxPlasticityValue, mutationRate);
}

void CNeuralNet::Enable_Disabled_HiddenLayer2Neuron_OutputSynapses(uint64_t newSeed, float minPlasticityValue, float maxPlasticityValue)
{
	if (HiddenLayer2Used == false)
		return;

	RandomNumbers.Change_Seed(newSeed);

	uint32_t id;
	uint32_t numOfNeurons = HiddenLayer2.NumOfNeurons;

	for (uint32_t i = 0; i < numOfNeurons; i++)
	{
		id = HiddenLayer2.pNeuronIDArray[i];
		pNeuronArray[id].Enable_Disabled_OutputSynapses(&RandomNumbers, minPlasticityValue, maxPlasticityValue);
	}

	if (HiddenLayer2.AdditionalBiasNeuron == true)
		pNeuronArray[HiddenLayer2.BiasNeuronID].Enable_Disabled_OutputSynapses(&RandomNumbers, minPlasticityValue, maxPlasticityValue);
}

void CNeuralNet::Enable_Disabled_HiddenLayer2Neuron_OutputSynapses(uint64_t newSeed, float minPlasticityValue, float maxPlasticityValue, float mutationRate)
{
	if (HiddenLayer2Used == false)
		return;

	RandomNumbers.Change_Seed(newSeed);

	uint32_t id;
	uint32_t numOfNeurons = HiddenLayer2.NumOfNeurons;

	for (uint32_t i = 0; i < numOfNeurons; i++)
	{
		id = HiddenLayer2.pNeuronIDArray[i];
		pNeuronArray[id].Enable_Disabled_OutputSynapses(&RandomNumbers, minPlasticityValue, maxPlasticityValue, mutationRate);
	}

	if (HiddenLayer2.AdditionalBiasNeuron == true)
		pNeuronArray[HiddenLayer2.BiasNeuronID].Enable_Disabled_OutputSynapses(&RandomNumbers, minPlasticityValue, maxPlasticityValue, mutationRate);
}

void CNeuralNet::Enable_Disabled_HiddenLayer3Neuron_OutputSynapses(uint64_t newSeed, float minPlasticityValue, float maxPlasticityValue)
{
	if (HiddenLayer3Used == false)
		return;

	RandomNumbers.Change_Seed(newSeed);

	uint32_t id;
	uint32_t numOfNeurons = HiddenLayer3.NumOfNeurons;

	for (uint32_t i = 0; i < numOfNeurons; i++)
	{
		id = HiddenLayer3.pNeuronIDArray[i];
		pNeuronArray[id].Enable_Disabled_OutputSynapses(&RandomNumbers, minPlasticityValue, maxPlasticityValue);
	}

	if (HiddenLayer3.AdditionalBiasNeuron == true)
		pNeuronArray[HiddenLayer3.BiasNeuronID].Enable_Disabled_OutputSynapses(&RandomNumbers, minPlasticityValue, maxPlasticityValue);
}

void CNeuralNet::Enable_Disabled_HiddenLayer3Neuron_OutputSynapses(uint64_t newSeed, float minPlasticityValue, float maxPlasticityValue, float mutationRate)
{
	if (HiddenLayer3Used == false)
		return;

	RandomNumbers.Change_Seed(newSeed);

	uint32_t id;
	uint32_t numOfNeurons = HiddenLayer3.NumOfNeurons;

	for (uint32_t i = 0; i < numOfNeurons; i++)
	{
		id = HiddenLayer3.pNeuronIDArray[i];
		pNeuronArray[id].Enable_Disabled_OutputSynapses(&RandomNumbers, minPlasticityValue, maxPlasticityValue, mutationRate);
	}

	if (HiddenLayer3.AdditionalBiasNeuron == true)
		pNeuronArray[HiddenLayer3.BiasNeuronID].Enable_Disabled_OutputSynapses(&RandomNumbers, minPlasticityValue, maxPlasticityValue, mutationRate);
}

void CNeuralNet::Init_NeuralNet(uint32_t numOfNeurons)
{
	HiddenLayer1.Reset();
	HiddenLayer2.Reset();
	HiddenLayer3.Reset();

	delete[] pNeuronArray;
	pNeuronArray = nullptr;

	delete[] pNumInternalReservoirConnectionsArray;
	pNumInternalReservoirConnectionsArray = nullptr;

	NumOfUsedNeurons = 0;
	NumOfNeurons = numOfNeurons;

	ReservorComputing = false;

	pNeuronArray = new (std::nothrow) CNeuron[numOfNeurons];

	for (uint32_t i = 0; i < numOfNeurons; i++)
		pNeuronArray[i].Connect_With_Brain(pNeuronArray);
}

void CNeuralNet::Round_OutputWeights(float precision)
{
	float invPrecision = 1.0f / precision;

	for (uint32_t i = 0; i < NumOfNeurons; i++)
		pNeuronArray[i].Round_OutputWeights(precision, invPrecision);
}

void CNeuralNet::Remove_Unused_Connections(void)
{
	for (uint32_t i = 0; i < NumOfNeurons; i++)
		pNeuronArray[i].Remove_Unused_Connections();
}

void CNeuralNet::Deactivate_Unused_Neurons(void)
{
	if (ReservorComputing == true)
		return;

	for (uint32_t i = NumInputNeurons; i < NumOfNeurons; i++)
		pNeuronArray[i].Dropout = true;

	if (AdditionalInputBiasNeuron == true)
		pNeuronArray[InputBiasNeuronID].Dropout = false;

	if (HiddenLayer1Used == true)
	{
		if (HiddenLayer1.AdditionalBiasNeuron == true)
			pNeuronArray[HiddenLayer1.BiasNeuronID].Dropout = false;
	}

	if (HiddenLayer2Used == true)
	{
		if (HiddenLayer2.AdditionalBiasNeuron == true)
			pNeuronArray[HiddenLayer2.BiasNeuronID].Dropout = false;
	}

	if (HiddenLayer3Used == true)
	{
		if (HiddenLayer3.AdditionalBiasNeuron == true)
			pNeuronArray[HiddenLayer3.BiasNeuronID].Dropout = false;
	}

	for (uint32_t i = 0; i < NumOfNeurons; i++)
	{
		uint32_t numConnections = pNeuronArray[i].NumOfOutputSynapses;

		for (uint32_t j = 0; j < numConnections; j++)
		{
			pNeuronArray[pNeuronArray[i].pReceiverNeuronIDArray[j]].Dropout = false;
		}
	}
}

void CNeuralNet::Set_Activationfunction_OutputLayerNeuron(pActivationFunc pFunc, uint32_t id_InsideLayer)
{
	uint32_t id = id_InsideLayer + FirstOutputNeuronID;
	pNeuronArray[id].Set_ActivationFunction(pFunc);
}

void CNeuralNet::Set_Activationfunction_HiddenLayer1Neuron(pActivationFunc pFunc, uint32_t id_InsideLayer)
{
	uint32_t id = HiddenLayer1.pNeuronIDArray[id_InsideLayer];
	pNeuronArray[id].Set_ActivationFunction(pFunc);
}

void CNeuralNet::Set_Activationfunction_HiddenLayer2Neuron(pActivationFunc pFunc, uint32_t id_InsideLayer)
{
	uint32_t id = HiddenLayer2.pNeuronIDArray[id_InsideLayer];
	pNeuronArray[id].Set_ActivationFunction(pFunc);
}

void CNeuralNet::Set_Activationfunction_HiddenLayer3Neuron(pActivationFunc pFunc, uint32_t id_InsideLayer)
{
	uint32_t id = HiddenLayer3.pNeuronIDArray[id_InsideLayer];
	pNeuronArray[id].Set_ActivationFunction(pFunc);
}

void CNeuralNet::Set_Activationfunction_ReservorNeuron(pActivationFunc pFunc, uint32_t id_InsideReservoir)
{
	uint32_t id = FirstReservoirNeuronID + id_InsideReservoir;
	pNeuronArray[id].Set_ActivationFunction(pFunc);
}


void CNeuralNet::Set_DropoutState_HiddenLayer1Neuron(bool state, uint32_t id_InsideLayer)
{
	uint32_t id = HiddenLayer1.pNeuronIDArray[id_InsideLayer];
	pNeuronArray[id].Set_DropoutState(state);
}

void CNeuralNet::Set_DropoutState_HiddenLayer2Neuron(bool state, uint32_t id_InsideLayer)
{
	uint32_t id = HiddenLayer2.pNeuronIDArray[id_InsideLayer];
	pNeuronArray[id].Set_DropoutState(state);
}

void CNeuralNet::Set_DropoutState_HiddenLayer3Neuron(bool state, uint32_t id_InsideLayer)
{
	uint32_t id = HiddenLayer3.pNeuronIDArray[id_InsideLayer];
	pNeuronArray[id].Set_DropoutState(state);
}

void CNeuralNet::Set_DropoutState_ReservorNeuron(bool state, uint32_t id_InsideReservoir)
{
	uint32_t id = FirstReservoirNeuronID + id_InsideReservoir;
	pNeuronArray[id].Set_DropoutState(state);
}

void CNeuralNet::Init_TwoLayerNetwork(uint32_t numInputNeurons, float minPlasticityValue_InputLayer, float maxPlasticityValue_InputLayer, float inputNeuronLearningRate, bool additionalInputBiasNeuron, uint32_t numOutputNeurons, pActivationFunc pOutputNeuronActivationFunc, float outputNeuronErrorFactor1, float outputNeuronErrorFactor2)
{
	HiddenLayer1.Reset();
	HiddenLayer2.Reset();
	HiddenLayer3.Reset();

	/*for (uint32_t i = 0; i < NumOfNeurons; i++)
	{
	pNeuronArray[i].NumOfOutputSynapses = 0;
	pNeuronArray[i].NumOfOutputSynapsesMax = 0;
	}*/

	ReservorComputing = false;

	AdditionalInputBiasNeuron = additionalInputBiasNeuron;

	NumInputNeurons = numInputNeurons;
	NumOutputNeurons = numOutputNeurons;

	if (additionalInputBiasNeuron == false)
		FirstOutputNeuronID = NumInputNeurons;
	else
	{
		InputBiasNeuronID = NumInputNeurons;
		FirstOutputNeuronID = NumInputNeurons + 1;

		pNeuronArray[InputBiasNeuronID].Use_As_BiasNeuron();
		pNeuronArray[InputBiasNeuronID].Set_BiasNeuronOutput(-1.0f);
		pNeuronArray[InputBiasNeuronID].Set_LearningRate(inputNeuronLearningRate);
	}

	uint32_t i, j, id;

	for (i = 0; i < NumInputNeurons; i++)
	{
		pNeuronArray[i].Use_As_InputNeuron();
		pNeuronArray[i].Set_LearningRate(inputNeuronLearningRate);
	}

	for (i = 0; i < NumOutputNeurons; i++)
	{
		id = i + FirstOutputNeuronID;

		pNeuronArray[id].Use_As_OutputNeuron();
		pNeuronArray[id].Set_ActivationFunction(pOutputNeuronActivationFunc);
		pNeuronArray[id].Set_ErrorFactors(outputNeuronErrorFactor1, outputNeuronErrorFactor2);
	}

	if (additionalInputBiasNeuron == false)
		NumOfUsedNeurons = NumInputNeurons + NumOutputNeurons;
	else
		NumOfUsedNeurons = NumInputNeurons + NumOutputNeurons + 1;


	for (i = 0; i < NumInputNeurons; i++)
	{
		pNeuronArray[i].Init_OutputSynapses(NumOutputNeurons);
		pNeuronArray[i].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticityValue_InputLayer, maxPlasticityValue_InputLayer);

		for (j = 0; j < NumOutputNeurons; j++)
			pNeuronArray[i].Connect_With_ReceiverNeuron(j + FirstOutputNeuronID, /*synapseID:*/ j);
	}

	if (additionalInputBiasNeuron == true)
	{
		pNeuronArray[InputBiasNeuronID].Init_OutputSynapses(NumOutputNeurons);
		pNeuronArray[InputBiasNeuronID].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticityValue_InputLayer, maxPlasticityValue_InputLayer);

		for (j = 0; j < NumOutputNeurons; j++)
			pNeuronArray[InputBiasNeuronID].Connect_With_ReceiverNeuron(j + FirstOutputNeuronID, /*synapseID:*/ j);
	}
}

void CNeuralNet::Calculate_Output_TwoLayerNetwork(float *pOutputValueArray, const float *pInputValueArray)
{
	uint32_t i, id;

	for (i = 0; i < NumInputNeurons; i++)
	{
		pNeuronArray[i].Set_Input(pInputValueArray[i]);
		pNeuronArray[i].Propagate_SynapticOutput();
	}

	if (AdditionalInputBiasNeuron == true)
		pNeuronArray[InputBiasNeuronID].Propagate_SynapticOutput();

	for (i = 0; i < NumOutputNeurons; i++)
	{
		id = i + FirstOutputNeuronID;

		pNeuronArray[id].Calculate_NeuronOutput();

		pOutputValueArray[i] = pNeuronArray[id].Get_NeuronOutput();
		//pOutputValueArray[i] = pNeuronArray[id].NeuronOutput;
	}
}

void CNeuralNet::Calculate_Output_TwoLayerNetwork(float *pOutputValue, const float *pInputValueArray, uint32_t idOfOutputNeuron)
{
	for (uint32_t i = 0; i < NumInputNeurons; i++)
	{
		pNeuronArray[i].Set_Input(pInputValueArray[i]);

		pNeuronArray[i].Propagate_SynapticOutput(idOfOutputNeuron);
	}

	if (AdditionalInputBiasNeuron == true)
		pNeuronArray[InputBiasNeuronID].Propagate_SynapticOutput(idOfOutputNeuron);

	uint32_t id = idOfOutputNeuron + FirstOutputNeuronID;

	pNeuronArray[id].Calculate_NeuronOutput();

	*pOutputValue = pNeuronArray[id].Get_NeuronOutput();
	//*pOutputValue = pNeuronArray[id].NeuronOutput;
}

void CNeuralNet::Calculate_Output_TwoLayerNetwork(float *pOutputValueArray)
{
	uint32_t i, id;

	for (i = 0; i < NumOutputNeurons; i++)
	{
		id = i + FirstOutputNeuronID;

		pNeuronArray[id].Calculate_NeuronOutput();

		pOutputValueArray[i] = pNeuronArray[id].Get_NeuronOutput();
		//pOutputValueArray[i] = pNeuronArray[id].NeuronOutput;
	}
}

float CNeuralNet::Learning_TwoLayerNetwork(const float *pDesiredOutputValueArray)
{
	uint32_t id;

	float error = 0.0f;

	for (uint32_t i = 0; i < NumOutputNeurons; i++)
	{
		id = FirstOutputNeuronID + i;

		error += pNeuronArray[id].Calculate_Error(pDesiredOutputValueArray[i]);
	}

	if (AdditionalInputBiasNeuron == true)
		pNeuronArray[InputBiasNeuronID].Adjust_OutputSynapses_AfterErrorCalculations();

	for (uint32_t i = 0; i < NumInputNeurons; i++)
		pNeuronArray[i].Adjust_OutputSynapses_AfterErrorCalculations();


	return error;
}

float CNeuralNet::Learning_TwoLayerNetwork(float desiredOutputValue, uint32_t idOfOutputNeuron)
{
	uint32_t id = idOfOutputNeuron + FirstOutputNeuronID;

	float error = pNeuronArray[id].Calculate_Error(desiredOutputValue);

	if (AdditionalInputBiasNeuron == true)
		pNeuronArray[InputBiasNeuronID].Adjust_OutputSynapse_AfterErrorCalculations(idOfOutputNeuron);

	for (uint32_t i = 0; i < NumInputNeurons; i++)
		pNeuronArray[i].Adjust_OutputSynapse_AfterErrorCalculations(idOfOutputNeuron);

	return error;
}

void CNeuralNet::Init_Input_And_OutputNeurons(uint32_t numInputNeurons, float inputNeuronLearningRate, bool additionalInputBiasNeuron, uint32_t numOutputNeurons, pActivationFunc pOutputNeuronActivationFunc, float outputNeuronErrorFactor1, float outputNeuronErrorFactor2)
{
	HiddenLayer1.Reset();
	HiddenLayer2.Reset();
	HiddenLayer3.Reset();

	/*for (uint32_t i = 0; i < NumOfNeurons; i++)
	{
	pNeuronArray[i].NumOfOutputSynapses = 0;
	pNeuronArray[i].NumOfOutputSynapsesMax = 0;
	}*/

	ReservorComputing = false;

	AdditionalInputBiasNeuron = additionalInputBiasNeuron;

	NumInputNeurons = numInputNeurons;
	NumOutputNeurons = numOutputNeurons;

	if (additionalInputBiasNeuron == false)
		FirstOutputNeuronID = NumInputNeurons;
	else
	{
		InputBiasNeuronID = NumInputNeurons;
		FirstOutputNeuronID = NumInputNeurons + 1;

		pNeuronArray[InputBiasNeuronID].Use_As_BiasNeuron();
		pNeuronArray[InputBiasNeuronID].Set_BiasNeuronOutput(-1.0f);
		pNeuronArray[InputBiasNeuronID].Set_LearningRate(inputNeuronLearningRate);
	}

	uint32_t i, id;

	for (i = 0; i < NumInputNeurons; i++)
	{
		pNeuronArray[i].Use_As_InputNeuron();
		pNeuronArray[i].Set_LearningRate(inputNeuronLearningRate);
	}

	for (i = 0; i < NumOutputNeurons; i++)
	{
		id = i + FirstOutputNeuronID;

		pNeuronArray[id].Use_As_OutputNeuron();
		pNeuronArray[id].Set_ActivationFunction(pOutputNeuronActivationFunc);
		pNeuronArray[id].Set_ErrorFactors(outputNeuronErrorFactor1, outputNeuronErrorFactor2);
	}

	if (additionalInputBiasNeuron == false)
		NumOfUsedNeurons = NumInputNeurons + NumOutputNeurons;
	else
		NumOfUsedNeurons = NumInputNeurons + NumOutputNeurons + 1;
}

void CNeuralNet::Init_ReservoirComputing_FullyConnectedReservoir(uint32_t numInputNeurons, uint32_t numReservoirConnectionsPerInputNeuron, uint32_t *pReservoirNeuronsWithInputConnection_IDArray, float inputNeuronLearningRate, bool additionalInputBiasNeuron, uint32_t numReservoirNeurons, pActivationFunc pReservoirNeuronActivationFunc, float reservoirNeuronLearningRate, float minPlasticityValue_ReservoirNeurons, float maxPlasticityValue_ReservoirNeurons, uint32_t numOutputNeurons, uint32_t numReservoirConnectionsPerOutputNeuron, uint32_t *pReservoirNeuronsWithOutputConnection_IDArray, pActivationFunc pOutputNeuronActivationFunc, float outputNeuronErrorFactor1, float outputNeuronErrorFactor2)
{
	HiddenLayer1.Reset();
	HiddenLayer2.Reset();
	HiddenLayer3.Reset();

	uint32_t i, j, id;

	ReservorComputing = true;

	NumInputNeurons = numInputNeurons;
	NumOutputNeurons = numOutputNeurons;
	NumReservoirNeurons = numReservoirNeurons;

	delete[] pNumInternalReservoirConnectionsArray;
	pNumInternalReservoirConnectionsArray = nullptr;

	pNumInternalReservoirConnectionsArray = new (std::nothrow) uint32_t[numReservoirNeurons];

	for (i = 0; i < numReservoirNeurons; i++)
		pNumInternalReservoirConnectionsArray[i] = NumReservoirNeurons - 1;

	AdditionalInputBiasNeuron = additionalInputBiasNeuron;

	NumReservoirConnectionsPerInputNeuron = numReservoirConnectionsPerInputNeuron;
	NumReservoirConnectionsPerOutputNeuron = numReservoirConnectionsPerOutputNeuron;

	if (additionalInputBiasNeuron == false)
	{
		FirstReservoirNeuronID = NumInputNeurons;
		FirstOutputNeuronID = FirstReservoirNeuronID + NumReservoirNeurons;
		NumOfUsedNeurons = NumInputNeurons + NumReservoirNeurons + NumOutputNeurons;
	}
	else
	{
		InputBiasNeuronID = NumInputNeurons;
		FirstReservoirNeuronID = NumInputNeurons + 1;
		FirstOutputNeuronID = FirstReservoirNeuronID + NumReservoirNeurons;
		NumOfUsedNeurons = NumInputNeurons + NumReservoirNeurons + NumOutputNeurons + 1;
	}



	for (i = 0; i < NumInputNeurons; i++)
	{
		pNeuronArray[i].Use_As_InputNeuron();
		pNeuronArray[i].Set_LearningRate(inputNeuronLearningRate);
		pNeuronArray[i].Init_OutputSynapses(NumReservoirConnectionsPerInputNeuron);

		for (j = 0; j < NumReservoirConnectionsPerInputNeuron; j++)
		{
			pNeuronArray[i].Set_OutputSynapsePlasticity(1.0f, /*SynapseID:*/ j);
			pNeuronArray[i].Connect_With_ReceiverNeuron(pReservoirNeuronsWithInputConnection_IDArray[j], /*SynapseID:*/ j);
		}

	}

	if (additionalInputBiasNeuron == true)
	{
		pNeuronArray[InputBiasNeuronID].Use_As_BiasNeuron();
		pNeuronArray[InputBiasNeuronID].Set_BiasNeuronOutput(-1.0f);
		pNeuronArray[InputBiasNeuronID].Set_LearningRate(inputNeuronLearningRate);
		pNeuronArray[InputBiasNeuronID].Init_OutputSynapses(NumReservoirConnectionsPerInputNeuron);

		for (j = 0; j < NumReservoirConnectionsPerInputNeuron; j++)
		{
			pNeuronArray[InputBiasNeuronID].Set_OutputSynapsePlasticity(1.0f, /*SynapseID:*/  j);
			pNeuronArray[InputBiasNeuronID].Connect_With_ReceiverNeuron(pReservoirNeuronsWithInputConnection_IDArray[j], /*SynapseID:*/ j);
		}
	}

	for (i = 0; i < NumOutputNeurons; i++)
	{
		id = i + FirstOutputNeuronID;

		pNeuronArray[id].Use_As_OutputNeuron();
		pNeuronArray[id].Set_ActivationFunction(pOutputNeuronActivationFunc);
		pNeuronArray[id].Set_ErrorFactors(outputNeuronErrorFactor1, outputNeuronErrorFactor2);
	}


	bool additionalOutputConnection;
	uint32_t synapseIDCounter;

	for (i = 0; i < NumReservoirNeurons; i++)
	{
		id = FirstReservoirNeuronID + i;

		pNeuronArray[id].Use_As_MemoryNeuron();

		additionalOutputConnection = false;

		for (j = 0; j < NumReservoirConnectionsPerOutputNeuron; j++)
		{
			if (pReservoirNeuronsWithOutputConnection_IDArray[j] == id)
			{
				additionalOutputConnection = true;
				break;
			}
		}

		if (additionalOutputConnection == true)
			pNeuronArray[id].Init_OutputSynapses(pNumInternalReservoirConnectionsArray[i] + NumOutputNeurons);
		else
			pNeuronArray[id].Init_OutputSynapses(pNumInternalReservoirConnectionsArray[i]);


		pNeuronArray[id].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticityValue_ReservoirNeurons, maxPlasticityValue_ReservoirNeurons);
		pNeuronArray[id].Set_LearningRate(reservoirNeuronLearningRate);
		pNeuronArray[id].Set_ActivationFunction(pReservoirNeuronActivationFunc);


		synapseIDCounter = 0;

		for (j = 0; j < NumReservoirNeurons; j++)
		{
			if (i == j)
				continue;

			pNeuronArray[id].Connect_With_ReceiverNeuron(FirstReservoirNeuronID + j, synapseIDCounter);
			synapseIDCounter++;
		}

		if (additionalOutputConnection == true)
		{
			for (j = 0; j < NumOutputNeurons; j++)
			{
				pNeuronArray[id].Connect_With_ReceiverNeuron(FirstOutputNeuronID + j, synapseIDCounter);
				synapseIDCounter++;
			}
		}
	}
}

void CNeuralNet::Init_ReservoirComputing(uint32_t numInputNeurons, uint32_t numReservoirConnectionsPerInputNeuron, uint32_t *pReservoirNeuronsWithInputConnection_IDArray, float inputNeuronLearningRate, bool additionalInputBiasNeuron, uint32_t numReservoirNeurons, uint32_t minNumOfReservoirConnections, uint32_t maxNumOfReservoirConnections, pActivationFunc pReservoirNeuronActivationFunc, float reservoirNeuronLearningRate, float minPlasticityValue_ReservoirNeurons, float maxPlasticityValue_ReservoirNeurons, uint32_t numOutputNeurons, uint32_t numReservoirConnectionsPerOutputNeuron, uint32_t *pReservoirNeuronsWithOutputConnection_IDArray, pActivationFunc pOutputNeuronActivationFunc, float outputNeuronErrorFactor1, float outputNeuronErrorFactor2)
{
	HiddenLayer1.Reset();
	HiddenLayer2.Reset();
	HiddenLayer3.Reset();

	uint32_t i, j, k, id;

	ReservorComputing = true;

	NumInputNeurons = numInputNeurons;
	NumOutputNeurons = numOutputNeurons;
	NumReservoirNeurons = numReservoirNeurons;

	delete[] pNumInternalReservoirConnectionsArray;
	pNumInternalReservoirConnectionsArray = nullptr;

	pNumInternalReservoirConnectionsArray = new (std::nothrow) uint32_t[numReservoirNeurons];

	for (i = 0; i < numReservoirNeurons; i++)
		pNumInternalReservoirConnectionsArray[i] = NumReservoirNeurons - 1;

	AdditionalInputBiasNeuron = additionalInputBiasNeuron;

	NumReservoirConnectionsPerInputNeuron = numReservoirConnectionsPerInputNeuron;
	NumReservoirConnectionsPerOutputNeuron = numReservoirConnectionsPerOutputNeuron;

	if (additionalInputBiasNeuron == false)
	{
		FirstReservoirNeuronID = NumInputNeurons;
		FirstOutputNeuronID = FirstReservoirNeuronID + NumReservoirNeurons;
		NumOfUsedNeurons = NumInputNeurons + NumReservoirNeurons + NumOutputNeurons;
	}
	else
	{
		InputBiasNeuronID = NumInputNeurons;
		FirstReservoirNeuronID = NumInputNeurons + 1;
		FirstOutputNeuronID = FirstReservoirNeuronID + NumReservoirNeurons;
		NumOfUsedNeurons = NumInputNeurons + NumReservoirNeurons + NumOutputNeurons + 1;
	}



	for (i = 0; i < NumInputNeurons; i++)
	{
		pNeuronArray[i].Use_As_InputNeuron();
		pNeuronArray[i].Set_LearningRate(inputNeuronLearningRate);
		pNeuronArray[i].Init_OutputSynapses(NumReservoirConnectionsPerInputNeuron);

		for (j = 0; j < NumReservoirConnectionsPerInputNeuron; j++)
		{
			pNeuronArray[i].Set_OutputSynapsePlasticity(1.0f, /*SynapseID:*/ j);
			pNeuronArray[i].Connect_With_ReceiverNeuron(pReservoirNeuronsWithInputConnection_IDArray[j], /*SynapseID:*/ j);
		}

	}

	if (additionalInputBiasNeuron == true)
	{
		pNeuronArray[InputBiasNeuronID].Use_As_BiasNeuron();
		pNeuronArray[InputBiasNeuronID].Set_BiasNeuronOutput(-1.0f);
		pNeuronArray[InputBiasNeuronID].Set_LearningRate(inputNeuronLearningRate);
		pNeuronArray[InputBiasNeuronID].Init_OutputSynapses(NumReservoirConnectionsPerInputNeuron);

		for (j = 0; j < NumReservoirConnectionsPerInputNeuron; j++)
		{
			pNeuronArray[InputBiasNeuronID].Set_OutputSynapsePlasticity(1.0f, /*SynapseID:*/  j);
			pNeuronArray[InputBiasNeuronID].Connect_With_ReceiverNeuron(pReservoirNeuronsWithInputConnection_IDArray[j], /*SynapseID:*/ j);
		}
	}

	for (i = 0; i < NumOutputNeurons; i++)
	{
		id = i + FirstOutputNeuronID;

		pNeuronArray[id].Use_As_OutputNeuron();
		pNeuronArray[id].Set_ActivationFunction(pOutputNeuronActivationFunc);
		pNeuronArray[id].Set_ErrorFactors(outputNeuronErrorFactor1, outputNeuronErrorFactor2);
	}

	maxNumOfReservoirConnections++;

	bool alreadyExistingConnection;
	bool additionalOutputConnection;
	uint32_t synapseIDCounter;
	uint32_t randomID;

	for (i = 0; i < NumReservoirNeurons; i++)
	{
		id = FirstReservoirNeuronID + i;

		pNeuronArray[id].Use_As_MemoryNeuron();

		additionalOutputConnection = false;

		for (j = 0; j < NumReservoirConnectionsPerOutputNeuron; j++)
		{
			if (pReservoirNeuronsWithOutputConnection_IDArray[j] == id)
			{
				additionalOutputConnection = true;
				break;
			}
		}

		pNumInternalReservoirConnectionsArray[i] = RandomNumbers.Get_UnsignedIntegerNumber(minNumOfReservoirConnections, maxNumOfReservoirConnections);

		if (additionalOutputConnection == true)
			pNeuronArray[id].Init_OutputSynapses(pNumInternalReservoirConnectionsArray[i] + NumOutputNeurons);
		else
			pNeuronArray[id].Init_OutputSynapses(pNumInternalReservoirConnectionsArray[i]);


		//pNeuronArray[id].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticityValue_ReservoirNeurons, maxPlasticityValue_ReservoirNeurons);
		pNeuronArray[id].Set_LearningRate(reservoirNeuronLearningRate);
		pNeuronArray[id].Set_ActivationFunction(pReservoirNeuronActivationFunc);

		synapseIDCounter = 0;

		for (j = 0; j < NumReservoirNeurons; j++)
		{
			do
			{
				randomID = RandomNumbers.Get_UnsignedIntegerNumber(0, NumReservoirNeurons);
			} while (randomID == i);

			alreadyExistingConnection = false;

			for (k = 0; k < synapseIDCounter; k++)
			{
				if (pNeuronArray[id].pReceiverNeuronIDArray[k] == randomID)
				{
					alreadyExistingConnection = true;
					//std::cout << "alreadyExistingConnection" << std::endl;
					break;
				}
			}

			if (alreadyExistingConnection == false)
			{
				pNeuronArray[id].Connect_With_ReceiverNeuron(FirstReservoirNeuronID + randomID, synapseIDCounter);

				pNeuronArray[id].Set_OutputSynapsePlasticity(RandomNumbers.Get_FloatNumber(minPlasticityValue_ReservoirNeurons, maxPlasticityValue_ReservoirNeurons), synapseIDCounter);

				synapseIDCounter++;

				if (synapseIDCounter >= pNumInternalReservoirConnectionsArray[i])
					break;
			}
		}

		pNumInternalReservoirConnectionsArray[i] = synapseIDCounter;

		if (additionalOutputConnection == true)
		{
			for (j = 0; j < NumOutputNeurons; j++)
			{
				pNeuronArray[id].Connect_With_ReceiverNeuron(FirstOutputNeuronID + j, synapseIDCounter);

				pNeuronArray[id].Set_OutputSynapsePlasticity(RandomNumbers.Get_FloatNumber(minPlasticityValue_ReservoirNeurons, maxPlasticityValue_ReservoirNeurons), synapseIDCounter);

				synapseIDCounter++;
			}
		}

		//pNeuronArray[id].NumOfOutputSynapses = synapseIDCounter;
		pNeuronArray[id].Remove_Unused_Connections();


	}
}

void CNeuralNet::Init_HiddenLayer1(uint32_t numOfNeurons, bool additionalBiasNeuron, bool connectWithOutputLayer, pActivationFunc pFunc, float minPlasticityValue_HiddenLayer1, float maxPlasticityValue_HiddenLayer1, float minPlasticityValue_InputLayer, float maxPlasticityValue_InputLayer, float learningRate, float errorFactor1, float errorFactor2)
{
	HiddenLayer1Used = true;

	HiddenLayer1.Init_Layer(NumOfUsedNeurons, numOfNeurons, additionalBiasNeuron);

	if (HiddenLayer1.AdditionalBiasNeuron == false)
		NumOfUsedNeurons += HiddenLayer1.NumOfNeurons;
	else
		NumOfUsedNeurons += (HiddenLayer1.NumOfNeurons + 1);

	uint32_t numOfNeuronsHL1 = HiddenLayer1.NumOfNeurons;

	uint32_t i, j, id;

	for (i = 0; i < numOfNeuronsHL1; i++)
	{
		id = HiddenLayer1.pNeuronIDArray[i];

		pNeuronArray[id].Use_As_HiddenNeuron();
		pNeuronArray[id].Set_ActivationFunction(pFunc);
		pNeuronArray[id].Set_LearningRate(learningRate);
		pNeuronArray[id].Set_ErrorFactors(errorFactor1, errorFactor2);
	}

	if (HiddenLayer1.AdditionalBiasNeuron == true)
	{
		id = HiddenLayer1.BiasNeuronID;

		pNeuronArray[id].Use_As_BiasNeuron();
		pNeuronArray[id].Set_BiasNeuronOutput(-1.0f);
		pNeuronArray[id].Set_LearningRate(learningRate);
	}

	RandomNumbers.Change_Seed(1);

	if (connectWithOutputLayer == true)
	{
		for (i = 0; i < numOfNeuronsHL1; i++)
		{
			id = HiddenLayer1.pNeuronIDArray[i];

			pNeuronArray[id].Init_OutputSynapses(NumOutputNeurons);
			pNeuronArray[id].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticityValue_HiddenLayer1, maxPlasticityValue_HiddenLayer1);

			for (j = 0; j < NumOutputNeurons; j++)
				pNeuronArray[id].Connect_With_ReceiverNeuron(j + FirstOutputNeuronID, /*synapseID:*/ j);
		}

		if (HiddenLayer1.AdditionalBiasNeuron == true)
		{
			id = HiddenLayer1.BiasNeuronID;

			pNeuronArray[id].Init_OutputSynapses(NumOutputNeurons);
			pNeuronArray[id].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticityValue_HiddenLayer1, maxPlasticityValue_HiddenLayer1);

			for (j = 0; j < NumOutputNeurons; j++)
				pNeuronArray[id].Connect_With_ReceiverNeuron(j + FirstOutputNeuronID, /*synapseID:*/ j);
		}
	}

	// Inputneuronen mit Layer 1 verkn�pfen:


	RandomNumbers.Change_Seed(1);

	for (i = 0; i < NumInputNeurons; i++)
	{
		pNeuronArray[i].Init_OutputSynapses(numOfNeuronsHL1);
		pNeuronArray[i].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticityValue_InputLayer, maxPlasticityValue_InputLayer);

		for (j = 0; j < numOfNeuronsHL1; j++)
		{
			pNeuronArray[i].Connect_With_ReceiverNeuron(HiddenLayer1.pNeuronIDArray[j], /*synapseID:*/ j);
		}
	}

	if (AdditionalInputBiasNeuron == true)
	{
		pNeuronArray[InputBiasNeuronID].Init_OutputSynapses(numOfNeuronsHL1);
		pNeuronArray[InputBiasNeuronID].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticityValue_InputLayer, maxPlasticityValue_InputLayer);

		for (j = 0; j < numOfNeuronsHL1; j++)
			pNeuronArray[InputBiasNeuronID].Connect_With_ReceiverNeuron(HiddenLayer1.pNeuronIDArray[j], /*synapseID:*/ j);
	}
}

void CNeuralNet::Init_HiddenLayer2(uint32_t numOfNeurons, bool additionalBiasNeuron, bool connectWithOutputLayer, pActivationFunc pFunc, float minPlasticityValue_HiddenLayer2, float maxPlasticityValue_HiddenLayer2, float minPlasticityValue_HiddenLayer1, float maxPlasticityValue_HiddenLayer1, float learningRate, float errorFactor1, float errorFactor2)
{
	HiddenLayer2Used = true;

	HiddenLayer2.Init_Layer(NumOfUsedNeurons, numOfNeurons, additionalBiasNeuron);

	if (HiddenLayer2.AdditionalBiasNeuron == false)
		NumOfUsedNeurons += HiddenLayer2.NumOfNeurons;
	else
		NumOfUsedNeurons += (HiddenLayer2.NumOfNeurons + 1);

	uint32_t numOfNeuronsHL2 = HiddenLayer2.NumOfNeurons;

	uint32_t i, j, id;

	for (i = 0; i < numOfNeuronsHL2; i++)
	{
		id = HiddenLayer2.pNeuronIDArray[i];

		pNeuronArray[id].Use_As_HiddenNeuron();
		pNeuronArray[id].Set_ActivationFunction(pFunc);
		pNeuronArray[id].Set_LearningRate(learningRate);
		pNeuronArray[id].Set_ErrorFactors(errorFactor1, errorFactor2);
	}

	if (HiddenLayer2.AdditionalBiasNeuron == true)
	{
		id = HiddenLayer2.BiasNeuronID;

		pNeuronArray[id].Use_As_BiasNeuron();
		pNeuronArray[id].Set_BiasNeuronOutput(-1.0f);
		pNeuronArray[id].Set_LearningRate(learningRate);
	}


	if (connectWithOutputLayer == true)
	{
		for (i = 0; i < numOfNeuronsHL2; i++)
		{
			id = HiddenLayer2.pNeuronIDArray[i];

			pNeuronArray[id].Init_OutputSynapses(NumOutputNeurons);
			pNeuronArray[id].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticityValue_HiddenLayer2, maxPlasticityValue_HiddenLayer2);

			for (j = 0; j < NumOutputNeurons; j++)
				pNeuronArray[id].Connect_With_ReceiverNeuron(j + FirstOutputNeuronID, /*synapseID:*/ j);
		}

		if (HiddenLayer2.AdditionalBiasNeuron == true)
		{
			id = HiddenLayer2.BiasNeuronID;

			pNeuronArray[id].Init_OutputSynapses(NumOutputNeurons);
			pNeuronArray[id].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticityValue_HiddenLayer2, maxPlasticityValue_HiddenLayer2);

			for (j = 0; j < NumOutputNeurons; j++)
				pNeuronArray[id].Connect_With_ReceiverNeuron(j + FirstOutputNeuronID, /*synapseID:*/ j);
		}
	}

	// Hiddenlayer1 mit Hiddenlayer2 verkn�pfen:

	uint32_t numOfNeuronsHL1 = HiddenLayer1.NumOfNeurons;

	for (i = 0; i < numOfNeuronsHL1; i++)
	{
		id = HiddenLayer1.pNeuronIDArray[i];

		pNeuronArray[id].Init_OutputSynapses(numOfNeuronsHL2);
		pNeuronArray[id].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticityValue_HiddenLayer1, maxPlasticityValue_HiddenLayer1);

		for (j = 0; j < numOfNeuronsHL2; j++)
			pNeuronArray[id].Connect_With_ReceiverNeuron(HiddenLayer2.pNeuronIDArray[j], /*synapseID:*/ j);
	}

	if (HiddenLayer1.AdditionalBiasNeuron == true)
	{
		id = HiddenLayer1.BiasNeuronID;

		pNeuronArray[id].Init_OutputSynapses(numOfNeuronsHL2);
		pNeuronArray[id].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticityValue_HiddenLayer1, maxPlasticityValue_HiddenLayer1);

		for (j = 0; j < numOfNeuronsHL2; j++)
			pNeuronArray[id].Connect_With_ReceiverNeuron(HiddenLayer2.pNeuronIDArray[j], /*synapseID:*/ j);
	}

}

void CNeuralNet::Init_HiddenLayer3(uint32_t numOfNeurons, bool additionalBiasNeuron, pActivationFunc pFunc, float minPlasticityValue_HiddenLayer3, float maxPlasticityValue_HiddenLayer3, float minPlasticityValue_HiddenLayer2, float maxPlasticityValue_HiddenLayer2, float learningRate, float errorFactor1, float errorFactor2)
{
	HiddenLayer3Used = true;

	HiddenLayer3.Init_Layer(NumOfUsedNeurons, numOfNeurons, additionalBiasNeuron);

	if (HiddenLayer3.AdditionalBiasNeuron == false)
		NumOfUsedNeurons += HiddenLayer3.NumOfNeurons;
	else
		NumOfUsedNeurons += (HiddenLayer3.NumOfNeurons + 1);

	uint32_t numOfNeuronsHL3 = HiddenLayer3.NumOfNeurons;

	uint32_t i, j, id;

	for (i = 0; i < numOfNeuronsHL3; i++)
	{
		id = HiddenLayer3.pNeuronIDArray[i];

		pNeuronArray[id].Use_As_HiddenNeuron();
		pNeuronArray[id].Set_ActivationFunction(pFunc);
		pNeuronArray[id].Set_LearningRate(learningRate);
		pNeuronArray[id].Set_ErrorFactors(errorFactor1, errorFactor2);
	}

	if (HiddenLayer3.AdditionalBiasNeuron == true)
	{
		id = HiddenLayer3.BiasNeuronID;

		pNeuronArray[id].Use_As_BiasNeuron();
		pNeuronArray[id].Set_BiasNeuronOutput(-1.0f);
		pNeuronArray[id].Set_LearningRate(learningRate);
	}

	for (i = 0; i < numOfNeuronsHL3; i++)
	{
		id = HiddenLayer3.pNeuronIDArray[i];

		pNeuronArray[id].Init_OutputSynapses(NumOutputNeurons);
		pNeuronArray[id].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticityValue_HiddenLayer3, maxPlasticityValue_HiddenLayer3);

		for (j = 0; j < NumOutputNeurons; j++)
			pNeuronArray[id].Connect_With_ReceiverNeuron(j + FirstOutputNeuronID, /*synapseID:*/ j);
	}

	if (HiddenLayer3.AdditionalBiasNeuron == true)
	{
		id = HiddenLayer3.BiasNeuronID;

		pNeuronArray[id].Init_OutputSynapses(NumOutputNeurons);
		pNeuronArray[id].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticityValue_HiddenLayer3, maxPlasticityValue_HiddenLayer3);

		for (j = 0; j < NumOutputNeurons; j++)
			pNeuronArray[id].Connect_With_ReceiverNeuron(j + FirstOutputNeuronID, /*synapseID:*/ j);
	}


	// Hiddenlayer2 mit Hiddenlayer3 verkn�pfen:

	uint32_t numOfNeuronsHL2 = HiddenLayer2.NumOfNeurons;

	for (i = 0; i < numOfNeuronsHL2; i++)
	{
		id = HiddenLayer2.pNeuronIDArray[i];

		pNeuronArray[id].Init_OutputSynapses(numOfNeuronsHL3);
		pNeuronArray[id].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticityValue_HiddenLayer2, maxPlasticityValue_HiddenLayer2);

		for (j = 0; j < numOfNeuronsHL3; j++)
			pNeuronArray[id].Connect_With_ReceiverNeuron(HiddenLayer3.pNeuronIDArray[j], /*synapseID:*/ j);
	}

	if (HiddenLayer2.AdditionalBiasNeuron == true)
	{
		id = HiddenLayer2.BiasNeuronID;

		pNeuronArray[id].Init_OutputSynapses(numOfNeuronsHL3);
		pNeuronArray[id].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticityValue_HiddenLayer2, maxPlasticityValue_HiddenLayer2);

		for (j = 0; j < numOfNeuronsHL3; j++)
			pNeuronArray[id].Connect_With_ReceiverNeuron(HiddenLayer3.pNeuronIDArray[j], /*synapseID:*/ j);
	}

}

void CNeuralNet::RandomChange_OutputSynapsePlasticities(uint64_t newSeed, float minPlasticity, float maxPlasticity)
{
	RandomNumbers.Change_Seed(newSeed);

	for (uint32_t i = 0; i < NumOfUsedNeurons; i++)
		pNeuronArray[i].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticity, maxPlasticity);
}

void CNeuralNet::RandomChange_OutputSynapsePlasticities(uint64_t newSeed, float minPlasticity, float maxPlasticity, float mutationRate)
{
	RandomNumbers.Change_Seed(newSeed);

	uint32_t j, numOfOutputSynapses;

	for (uint32_t i = 0; i < NumOfUsedNeurons; i++)
	{
		numOfOutputSynapses = pNeuronArray[i].NumOfOutputSynapses;

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pNeuronArray[i].pOutputSynapsePlasticityArray[j] = RandomNumbers.Get_FloatNumber(minPlasticity, maxPlasticity);
		}
	}
}

void CNeuralNet::RandomChange_OutputSynapsePlasticities2(uint64_t newSeed, float minPlasticityVariance, float maxPlasticityVariance)
{
	RandomNumbers.Change_Seed(newSeed);

	uint32_t j, numOfOutputSynapses;

	for (uint32_t i = 0; i < NumOfUsedNeurons; i++)
	{
		numOfOutputSynapses = pNeuronArray[i].NumOfOutputSynapses;

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[i].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber_IncludingZero(minPlasticityVariance, maxPlasticityVariance);
		}
	}
}

void CNeuralNet::RandomChange_OutputSynapsePlasticities2(uint64_t newSeed, float minPlasticityVariance, float maxPlasticityVariance, float mutationRate)
{
	RandomNumbers.Change_Seed(newSeed);

	uint32_t j, numOfOutputSynapses;

	for (uint32_t i = 0; i < NumOfUsedNeurons; i++)
	{
		numOfOutputSynapses = pNeuronArray[i].NumOfOutputSynapses;

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pNeuronArray[i].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber_IncludingZero(minPlasticityVariance, maxPlasticityVariance);
		}
	}
}

void CNeuralNet::RandomChange_OutputSynapsePlasticities_InputLayer(uint64_t newSeed, float minPlasticity, float maxPlasticity)
{
	RandomNumbers.Change_Seed(newSeed);

	for (uint32_t i = 0; i < NumInputNeurons; i++)
		pNeuronArray[i].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticity, maxPlasticity);

	if (AdditionalInputBiasNeuron == true)
		pNeuronArray[InputBiasNeuronID].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticity, maxPlasticity);
}

void CNeuralNet::RandomChange_OutputSynapsePlasticities_InputLayer(uint64_t newSeed, float minPlasticity, float maxPlasticity, float mutationRate)
{
	RandomNumbers.Change_Seed(newSeed);

	uint32_t j, numOfOutputSynapses;

	for (uint32_t i = 0; i < NumInputNeurons; i++)
	{
		numOfOutputSynapses = pNeuronArray[i].NumOfOutputSynapses;

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pNeuronArray[i].pOutputSynapsePlasticityArray[j] = RandomNumbers.Get_FloatNumber(minPlasticity, maxPlasticity);
		}
	}



	if (AdditionalInputBiasNeuron == true)
	{
		numOfOutputSynapses = pNeuronArray[InputBiasNeuronID].NumOfOutputSynapses;

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pNeuronArray[InputBiasNeuronID].pOutputSynapsePlasticityArray[j] = RandomNumbers.Get_FloatNumber(minPlasticity, maxPlasticity);
		}
	}
}

void CNeuralNet::RandomChange_OutputSynapsePlasticities2_InputLayer(uint64_t newSeed, float minPlasticityVariance, float maxPlasticityVariance, float mutationRate)
{
	RandomNumbers.Change_Seed(newSeed);

	uint32_t j, numOfOutputSynapses;

	for (uint32_t i = 0; i < NumInputNeurons; i++)
	{
		numOfOutputSynapses = pNeuronArray[i].NumOfOutputSynapses;

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pNeuronArray[i].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber_IncludingZero(minPlasticityVariance, maxPlasticityVariance);
		}
	}



	if (AdditionalInputBiasNeuron == true)
	{
		numOfOutputSynapses = pNeuronArray[InputBiasNeuronID].NumOfOutputSynapses;

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pNeuronArray[InputBiasNeuronID].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber_IncludingZero(minPlasticityVariance, maxPlasticityVariance);
		}
	}
}

void CNeuralNet::RandomChange_OutputSynapsePlasticities2_InputLayer(uint64_t newSeed, float minPlasticityVariance, float maxPlasticityVariance)
{
	RandomNumbers.Change_Seed(newSeed);

	uint32_t j, numOfOutputSynapses;

	for (uint32_t i = 0; i < NumInputNeurons; i++)
	{
		numOfOutputSynapses = pNeuronArray[i].NumOfOutputSynapses;

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[i].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber_IncludingZero(minPlasticityVariance, maxPlasticityVariance);
		}
	}



	if (AdditionalInputBiasNeuron == true)
	{
		numOfOutputSynapses = pNeuronArray[InputBiasNeuronID].NumOfOutputSynapses;

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[InputBiasNeuronID].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber_IncludingZero(minPlasticityVariance, maxPlasticityVariance);
		}
	}
}



void CNeuralNet::RandomChange_OutputSynapsePlasticities_HiddenLayer1(uint64_t newSeed, float minPlasticity, float maxPlasticity)
{
	if (HiddenLayer1Used == false)
		return;

	RandomNumbers.Change_Seed(newSeed);

	uint32_t numOfNeurons = HiddenLayer1.NumOfNeurons;

	uint32_t id;

	for (uint32_t i = 0; i < numOfNeurons; i++)
	{
		id = HiddenLayer1.pNeuronIDArray[i];

		pNeuronArray[id].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticity, maxPlasticity);
	}

	if (HiddenLayer1.AdditionalBiasNeuron == true)
		pNeuronArray[HiddenLayer1.BiasNeuronID].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticity, maxPlasticity);
}

void CNeuralNet::RandomChange_OutputSynapsePlasticities_HiddenLayer1(uint64_t newSeed, float minPlasticity, float maxPlasticity, float mutationRate)
{
	if (HiddenLayer1Used == false)
		return;

	RandomNumbers.Change_Seed(newSeed);

	uint32_t numOfNeurons = HiddenLayer1.NumOfNeurons;

	uint32_t j, numOfOutputSynapses;

	uint32_t id;

	for (uint32_t i = 0; i < numOfNeurons; i++)
	{
		id = HiddenLayer1.pNeuronIDArray[i];

		numOfOutputSynapses = pNeuronArray[id].NumOfOutputSynapses;

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pNeuronArray[id].pOutputSynapsePlasticityArray[j] = RandomNumbers.Get_FloatNumber(minPlasticity, maxPlasticity);
		}
	}

	if (HiddenLayer1.AdditionalBiasNeuron == true)
	{
		numOfOutputSynapses = pNeuronArray[HiddenLayer1.BiasNeuronID].NumOfOutputSynapses;

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pNeuronArray[HiddenLayer1.BiasNeuronID].pOutputSynapsePlasticityArray[j] = RandomNumbers.Get_FloatNumber(minPlasticity, maxPlasticity);
		}
	}
}

void CNeuralNet::RandomChange_OutputSynapsePlasticities2_HiddenLayer1(uint64_t newSeed, float minPlasticityVariance, float maxPlasticityVariance, float mutationRate)
{
	if (HiddenLayer1Used == false)
		return;

	RandomNumbers.Change_Seed(newSeed);

	uint32_t numOfNeurons = HiddenLayer1.NumOfNeurons;

	uint32_t j, numOfOutputSynapses;

	uint32_t id;

	for (uint32_t i = 0; i < numOfNeurons; i++)
	{
		id = HiddenLayer1.pNeuronIDArray[i];

		numOfOutputSynapses = pNeuronArray[id].NumOfOutputSynapses;

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pNeuronArray[id].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber_IncludingZero(minPlasticityVariance, maxPlasticityVariance);
		}
	}

	if (HiddenLayer1.AdditionalBiasNeuron == true)
	{
		numOfOutputSynapses = pNeuronArray[HiddenLayer1.BiasNeuronID].NumOfOutputSynapses;

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pNeuronArray[HiddenLayer1.BiasNeuronID].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber_IncludingZero(minPlasticityVariance, maxPlasticityVariance);
		}
	}
}

void CNeuralNet::RandomChange_OutputSynapsePlasticities2_HiddenLayer1(uint64_t newSeed, float minPlasticityVariance, float maxPlasticityVariance)
{
	if (HiddenLayer1Used == false)
		return;

	RandomNumbers.Change_Seed(newSeed);

	uint32_t numOfNeurons = HiddenLayer1.NumOfNeurons;

	uint32_t j, numOfOutputSynapses;

	uint32_t id;

	for (uint32_t i = 0; i < numOfNeurons; i++)
	{
		id = HiddenLayer1.pNeuronIDArray[i];

		numOfOutputSynapses = pNeuronArray[id].NumOfOutputSynapses;

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[id].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber_IncludingZero(minPlasticityVariance, maxPlasticityVariance);
		}
	}

	if (HiddenLayer1.AdditionalBiasNeuron == true)
	{
		numOfOutputSynapses = pNeuronArray[HiddenLayer1.BiasNeuronID].NumOfOutputSynapses;

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[HiddenLayer1.BiasNeuronID].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber_IncludingZero(minPlasticityVariance, maxPlasticityVariance);
		}
	}
}

void CNeuralNet::RandomChange_OutputSynapsePlasticities_HiddenLayer2(uint64_t newSeed, float minPlasticity, float maxPlasticity)
{
	if (HiddenLayer2Used == false)
		return;

	RandomNumbers.Change_Seed(newSeed);


	uint32_t numOfNeurons = HiddenLayer2.NumOfNeurons;

	uint32_t id;

	for (uint32_t i = 0; i < numOfNeurons; i++)
	{
		id = HiddenLayer2.pNeuronIDArray[i];

		pNeuronArray[id].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticity, maxPlasticity);
	}

	if (HiddenLayer2.AdditionalBiasNeuron == true)
		pNeuronArray[HiddenLayer2.BiasNeuronID].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticity, maxPlasticity);
}

void CNeuralNet::RandomChange_OutputSynapsePlasticities_HiddenLayer2(uint64_t newSeed, float minPlasticity, float maxPlasticity, float mutationRate)
{
	if (HiddenLayer2Used == false)
		return;

	RandomNumbers.Change_Seed(newSeed);


	uint32_t numOfNeurons = HiddenLayer2.NumOfNeurons;

	uint32_t j, numOfOutputSynapses;

	uint32_t id;

	for (uint32_t i = 0; i < numOfNeurons; i++)
	{
		id = HiddenLayer2.pNeuronIDArray[i];

		numOfOutputSynapses = pNeuronArray[id].NumOfOutputSynapses;

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pNeuronArray[id].pOutputSynapsePlasticityArray[j] = RandomNumbers.Get_FloatNumber(minPlasticity, maxPlasticity);
		}
	}

	if (HiddenLayer2.AdditionalBiasNeuron == true)
	{
		numOfOutputSynapses = pNeuronArray[HiddenLayer2.BiasNeuronID].NumOfOutputSynapses;

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pNeuronArray[HiddenLayer2.BiasNeuronID].pOutputSynapsePlasticityArray[j] = RandomNumbers.Get_FloatNumber(minPlasticity, maxPlasticity);
		}
	}
}

void CNeuralNet::RandomChange_OutputSynapsePlasticities2_HiddenLayer2(uint64_t newSeed, float minPlasticityVariance, float maxPlasticityVariance, float mutationRate)
{
	if (HiddenLayer2Used == false)
		return;

	RandomNumbers.Change_Seed(newSeed);


	uint32_t numOfNeurons = HiddenLayer2.NumOfNeurons;

	uint32_t j, numOfOutputSynapses;

	uint32_t id;

	for (uint32_t i = 0; i < numOfNeurons; i++)
	{
		id = HiddenLayer2.pNeuronIDArray[i];

		numOfOutputSynapses = pNeuronArray[id].NumOfOutputSynapses;

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pNeuronArray[id].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber_IncludingZero(minPlasticityVariance, maxPlasticityVariance);
		}
	}

	if (HiddenLayer2.AdditionalBiasNeuron == true)
	{
		numOfOutputSynapses = pNeuronArray[HiddenLayer2.BiasNeuronID].NumOfOutputSynapses;

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pNeuronArray[HiddenLayer2.BiasNeuronID].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber_IncludingZero(minPlasticityVariance, maxPlasticityVariance);
		}
	}
}

void CNeuralNet::RandomChange_OutputSynapsePlasticities2_HiddenLayer2(uint64_t newSeed, float minPlasticityVariance, float maxPlasticityVariance)
{
	if (HiddenLayer2Used == false)
		return;

	RandomNumbers.Change_Seed(newSeed);


	uint32_t numOfNeurons = HiddenLayer2.NumOfNeurons;

	uint32_t j, numOfOutputSynapses;

	uint32_t id;

	for (uint32_t i = 0; i < numOfNeurons; i++)
	{
		id = HiddenLayer2.pNeuronIDArray[i];

		numOfOutputSynapses = pNeuronArray[id].NumOfOutputSynapses;

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[id].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber_IncludingZero(minPlasticityVariance, maxPlasticityVariance);
		}
	}

	if (HiddenLayer2.AdditionalBiasNeuron == true)
	{
		numOfOutputSynapses = pNeuronArray[HiddenLayer2.BiasNeuronID].NumOfOutputSynapses;

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[HiddenLayer2.BiasNeuronID].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber_IncludingZero(minPlasticityVariance, maxPlasticityVariance);
		}
	}
}

void CNeuralNet::RandomChange_OutputSynapsePlasticities_HiddenLayer3(uint64_t newSeed, float minPlasticity, float maxPlasticity)
{
	if (HiddenLayer3Used == false)
		return;

	RandomNumbers.Change_Seed(newSeed);

	uint32_t numOfNeurons = HiddenLayer3.NumOfNeurons;

	uint32_t id;

	for (uint32_t i = 0; i < numOfNeurons; i++)
	{
		id = HiddenLayer3.pNeuronIDArray[i];

		pNeuronArray[id].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticity, maxPlasticity);
	}

	if (HiddenLayer3.AdditionalBiasNeuron == true)
		pNeuronArray[HiddenLayer3.BiasNeuronID].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticity, maxPlasticity);
}

void CNeuralNet::RandomChange_OutputSynapsePlasticities_HiddenLayer3(uint64_t newSeed, float minPlasticity, float maxPlasticity, float mutationRate)
{
	if (HiddenLayer3Used == false)
		return;

	RandomNumbers.Change_Seed(newSeed);

	uint32_t numOfNeurons = HiddenLayer3.NumOfNeurons;

	uint32_t j, numOfOutputSynapses;

	uint32_t id;

	for (uint32_t i = 0; i < numOfNeurons; i++)
	{
		id = HiddenLayer3.pNeuronIDArray[i];

		numOfOutputSynapses = pNeuronArray[id].NumOfOutputSynapses;

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pNeuronArray[id].pOutputSynapsePlasticityArray[j] = RandomNumbers.Get_FloatNumber(minPlasticity, maxPlasticity);
		}
	}

	if (HiddenLayer3.AdditionalBiasNeuron == true)
	{
		numOfOutputSynapses = pNeuronArray[HiddenLayer3.BiasNeuronID].NumOfOutputSynapses;

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pNeuronArray[HiddenLayer3.BiasNeuronID].pOutputSynapsePlasticityArray[j] = RandomNumbers.Get_FloatNumber(minPlasticity, maxPlasticity);
		}
	}
}

void CNeuralNet::RandomChange_OutputSynapsePlasticities2_HiddenLayer3(uint64_t newSeed, float minPlasticityVariance, float maxPlasticityVariance, float mutationRate)
{
	if (HiddenLayer3Used == false)
		return;

	RandomNumbers.Change_Seed(newSeed);

	uint32_t numOfNeurons = HiddenLayer3.NumOfNeurons;

	uint32_t j, numOfOutputSynapses;

	uint32_t id;

	for (uint32_t i = 0; i < numOfNeurons; i++)
	{
		id = HiddenLayer3.pNeuronIDArray[i];

		numOfOutputSynapses = pNeuronArray[id].NumOfOutputSynapses;

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pNeuronArray[id].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber_IncludingZero(minPlasticityVariance, maxPlasticityVariance);
		}
	}

	if (HiddenLayer3.AdditionalBiasNeuron == true)
	{
		numOfOutputSynapses = pNeuronArray[HiddenLayer3.BiasNeuronID].NumOfOutputSynapses;

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pNeuronArray[HiddenLayer3.BiasNeuronID].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber_IncludingZero(minPlasticityVariance, maxPlasticityVariance);
		}
	}
}

void CNeuralNet::RandomChange_OutputSynapsePlasticities2_HiddenLayer3(uint64_t newSeed, float minPlasticityVariance, float maxPlasticityVariance)
{
	if (HiddenLayer3Used == false)
		return;

	RandomNumbers.Change_Seed(newSeed);

	uint32_t numOfNeurons = HiddenLayer3.NumOfNeurons;

	uint32_t j, numOfOutputSynapses;

	uint32_t id;

	for (uint32_t i = 0; i < numOfNeurons; i++)
	{
		id = HiddenLayer3.pNeuronIDArray[i];

		numOfOutputSynapses = pNeuronArray[id].NumOfOutputSynapses;

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[id].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber_IncludingZero(minPlasticityVariance, maxPlasticityVariance);
		}
	}

	if (HiddenLayer3.AdditionalBiasNeuron == true)
	{
		numOfOutputSynapses = pNeuronArray[HiddenLayer3.BiasNeuronID].NumOfOutputSynapses;

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[HiddenLayer3.BiasNeuronID].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber_IncludingZero(minPlasticityVariance, maxPlasticityVariance);
		}
	}
}

void CNeuralNet::RandomChange_OutputSynapsePlasticities_ReservoirNeurons(uint64_t newSeed, float minPlasticity, float maxPlasticity)
{
	RandomNumbers.Change_Seed(newSeed);

	uint32_t id, j, numOfOutputSynapses, receiverID;

	for (uint32_t i = 0; i < NumReservoirNeurons; i++)
	{
		id = FirstReservoirNeuronID + i;

		numOfOutputSynapses = pNeuronArray[id].NumOfOutputSynapses;

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			receiverID = pNeuronArray[id].pReceiverNeuronIDArray[i];

			if (pNeuronArray[receiverID].UsedAsMemoryNeuron != true)
				continue;

			pNeuronArray[id].pOutputSynapsePlasticityArray[i] += RandomNumbers.Get_FloatNumber(minPlasticity, maxPlasticity);
		}
	}
}

void CNeuralNet::RandomChange_OutputSynapsePlasticities_ReservoirNeurons(uint64_t newSeed, float minPlasticity, float maxPlasticity, float mutationRate)
{
	RandomNumbers.Change_Seed(newSeed);

	uint32_t id, j, numOfOutputSynapses, receiverID;

	for (uint32_t i = 0; i < NumReservoirNeurons; i++)
	{
		if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
			continue;

		id = FirstReservoirNeuronID + i;

		numOfOutputSynapses = pNeuronArray[id].NumOfOutputSynapses;

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			receiverID = pNeuronArray[id].pReceiverNeuronIDArray[i];

			if (pNeuronArray[receiverID].UsedAsMemoryNeuron != true)
				continue;

			pNeuronArray[id].pOutputSynapsePlasticityArray[i] = RandomNumbers.Get_FloatNumber(minPlasticity, maxPlasticity);
		}
	}
}

void CNeuralNet::RandomChange_OutputSynapsePlasticities2_ReservoirNeurons(uint64_t newSeed, float minPlasticityVariance, float maxPlasticityVariance, float mutationRate)
{
	RandomNumbers.Change_Seed(newSeed);

	uint32_t id, j, numOfOutputSynapses, receiverID;

	for (uint32_t i = 0; i < NumReservoirNeurons; i++)
	{
		if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
			continue;

		id = FirstReservoirNeuronID + i;

		numOfOutputSynapses = pNeuronArray[id].NumOfOutputSynapses;

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			receiverID = pNeuronArray[id].pReceiverNeuronIDArray[i];

			if (pNeuronArray[receiverID].UsedAsMemoryNeuron != true)
				continue;

			pNeuronArray[id].pOutputSynapsePlasticityArray[i] += RandomNumbers.Get_FloatNumber_IncludingZero(minPlasticityVariance, maxPlasticityVariance);
		}
	}
}

void CNeuralNet::RandomChange_OutputSynapsePlasticities2_ReservoirNeurons(uint64_t newSeed, float minPlasticityVariance, float maxPlasticityVariance)
{
	RandomNumbers.Change_Seed(newSeed);

	uint32_t id, j, numOfOutputSynapses, receiverID;

	for (uint32_t i = 0; i < NumReservoirNeurons; i++)
	{
		id = FirstReservoirNeuronID + i;

		numOfOutputSynapses = pNeuronArray[id].NumOfOutputSynapses;

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			receiverID = pNeuronArray[id].pReceiverNeuronIDArray[i];

			if (pNeuronArray[receiverID].UsedAsMemoryNeuron != true)
				continue;

			pNeuronArray[id].pOutputSynapsePlasticityArray[i] += RandomNumbers.Get_FloatNumber_IncludingZero(minPlasticityVariance, maxPlasticityVariance);
		}
	}
}

void CNeuralNet::Clone_OutputSynapsePlasticities(CNeuralNet *pOriginalBrain)
{
	uint32_t j, numOfOutputSynapses;

	for (uint32_t i = 0; i < NumOfUsedNeurons; i++)
	{
		numOfOutputSynapses = pNeuronArray[i].NumOfOutputSynapses;

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[i].pOutputSynapseActivityStatusArray[j] = pOriginalBrain->pNeuronArray[i].pOutputSynapseActivityStatusArray[j];
			pNeuronArray[i].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[i].pOutputSynapsePlasticityArray[j];
		}
	}
}

void CNeuralNet::Clone_OutputSynapsePlasticities(CNeuralNet *pOriginalBrain, float variance, uint64_t newSeed)
{
	RandomNumbers.Change_Seed(newSeed);

	uint32_t j, numOfOutputSynapses;

	for (uint32_t i = 0; i < NumOfUsedNeurons; i++)
	{
		numOfOutputSynapses = pNeuronArray[i].NumOfOutputSynapses;

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[i].pOutputSynapseActivityStatusArray[j] = pOriginalBrain->pNeuronArray[i].pOutputSynapseActivityStatusArray[j];
			pNeuronArray[i].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[i].pOutputSynapsePlasticityArray[j];
			pNeuronArray[i].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-variance, variance);
		}
	}
}

void CNeuralNet::Clone_OutputSynapsePlasticities(CNeuralNet *pOriginalBrain, float variance, float mutationRate, uint64_t newSeed)
{
	RandomNumbers.Change_Seed(newSeed);

	uint32_t j, numOfOutputSynapses;

	for (uint32_t i = 0; i < NumOfUsedNeurons; i++)
	{
		numOfOutputSynapses = pNeuronArray[i].NumOfOutputSynapses;

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[i].pOutputSynapseActivityStatusArray[j] = pOriginalBrain->pNeuronArray[i].pOutputSynapseActivityStatusArray[j];
			pNeuronArray[i].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[i].pOutputSynapsePlasticityArray[j];

			if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pNeuronArray[i].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-variance, variance);
		}
	}
}

void CNeuralNet::Clone_OutputSynapsePlasticities(CNeuralNet *pOriginalBrain, float minVariance, float maxVariance, float mutationRate, uint64_t newSeed)
{
	RandomNumbers.Change_Seed(newSeed);

	uint32_t j, numOfOutputSynapses;

	for (uint32_t i = 0; i < NumOfUsedNeurons; i++)
	{
		numOfOutputSynapses = pNeuronArray[i].NumOfOutputSynapses;

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[i].pOutputSynapseActivityStatusArray[j] = pOriginalBrain->pNeuronArray[i].pOutputSynapseActivityStatusArray[j];
			pNeuronArray[i].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[i].pOutputSynapsePlasticityArray[j];

			if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pNeuronArray[i].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(minVariance, maxVariance);
		}
	}
}

void CNeuralNet::Clone_OutputSynapsePlasticities2(CNeuralNet *pOriginalBrain, float varianceMemoryNeurons, uint64_t newSeed)
{
	RandomNumbers.Change_Seed(newSeed);

	uint32_t j, numOfOutputSynapses;

	for (uint32_t i = 0; i < NumOfUsedNeurons; i++)
	{
		numOfOutputSynapses = pNeuronArray[i].NumOfOutputSynapses;

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[i].pOutputSynapseActivityStatusArray[j] = pOriginalBrain->pNeuronArray[i].pOutputSynapseActivityStatusArray[j];
			pNeuronArray[i].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[i].pOutputSynapsePlasticityArray[j];

			if (pNeuronArray[i].UsedAsMemoryNeuron != true)
				continue;

			pNeuronArray[i].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-varianceMemoryNeurons, varianceMemoryNeurons);
		}
	}
}

void CNeuralNet::Clone_OutputSynapsePlasticities2(CNeuralNet *pOriginalBrain, float varianceMemoryNeurons, float mutationRate, uint64_t newSeed)
{
	RandomNumbers.Change_Seed(newSeed);

	uint32_t j, numOfOutputSynapses;

	for (uint32_t i = 0; i < NumOfUsedNeurons; i++)
	{
		numOfOutputSynapses = pNeuronArray[i].NumOfOutputSynapses;

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[i].pOutputSynapseActivityStatusArray[j] = pOriginalBrain->pNeuronArray[i].pOutputSynapseActivityStatusArray[j];
			pNeuronArray[i].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[i].pOutputSynapsePlasticityArray[j];

			if (pNeuronArray[i].UsedAsMemoryNeuron != true)
				continue;

			if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pNeuronArray[i].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-varianceMemoryNeurons, varianceMemoryNeurons);
		}
	}
}

void CNeuralNet::Clone_OutputSynapsePlasticities3(CNeuralNet *pOriginalBrain, float varianceNonMemoryNeurons, uint64_t newSeed)
{
	RandomNumbers.Change_Seed(newSeed);

	uint32_t j, numOfOutputSynapses;

	for (uint32_t i = 0; i < NumOfUsedNeurons; i++)
	{
		numOfOutputSynapses = pNeuronArray[i].NumOfOutputSynapses;

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[i].pOutputSynapseActivityStatusArray[j] = pOriginalBrain->pNeuronArray[i].pOutputSynapseActivityStatusArray[j];
			pNeuronArray[i].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[i].pOutputSynapsePlasticityArray[j];

			if (pNeuronArray[i].UsedAsMemoryNeuron == true)
				continue;

			pNeuronArray[i].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-varianceNonMemoryNeurons, varianceNonMemoryNeurons);
		}
	}
}

void CNeuralNet::Clone_OutputSynapsePlasticities3(CNeuralNet *pOriginalBrain, float varianceNonMemoryNeurons, float mutationRate, uint64_t newSeed)
{
	RandomNumbers.Change_Seed(newSeed);

	uint32_t j, numOfOutputSynapses;

	for (uint32_t i = 0; i < NumOfUsedNeurons; i++)
	{
		numOfOutputSynapses = pNeuronArray[i].NumOfOutputSynapses;

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[i].pOutputSynapseActivityStatusArray[j] = pOriginalBrain->pNeuronArray[i].pOutputSynapseActivityStatusArray[j];
			pNeuronArray[i].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[i].pOutputSynapsePlasticityArray[j];

			if (pNeuronArray[i].UsedAsMemoryNeuron == true)
				continue;

			if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pNeuronArray[i].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-varianceNonMemoryNeurons, varianceNonMemoryNeurons);
		}
	}
}

void CNeuralNet::Clone_OutputSynapsePlasticities_InputLayer(CNeuralNet *pOriginalBrain, float variance, uint64_t newSeed)
{
	RandomNumbers.Change_Seed(newSeed);

	uint32_t j, numOfOutputSynapses;

	//float weight1, weight2;

	//float newPlasticity;


	uint32_t numInputNeurons = min(NumInputNeurons, pOriginalBrain->NumInputNeurons);

	for (uint32_t i = 0; i < numInputNeurons; i++)
	{
		numOfOutputSynapses = min(pNeuronArray[i].NumOfOutputSynapses, pOriginalBrain->pNeuronArray[i].NumOfOutputSynapses);

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[i].pOutputSynapseActivityStatusArray[j] = pOriginalBrain->pNeuronArray[i].pOutputSynapseActivityStatusArray[j];
			pNeuronArray[i].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[i].pOutputSynapsePlasticityArray[j];
			pNeuronArray[i].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-variance, variance);
		}
	}

	if (AdditionalInputBiasNeuron == true)
	{
		uint32_t biasNeuronID = InputBiasNeuronID;
		uint32_t biasNeuronID1 = pOriginalBrain->InputBiasNeuronID;


		numOfOutputSynapses = min(pNeuronArray[biasNeuronID].NumOfOutputSynapses, pOriginalBrain->pNeuronArray[biasNeuronID1].NumOfOutputSynapses);

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[biasNeuronID1].pOutputSynapsePlasticityArray[j];
			pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-variance, variance);
		}
	}
}

void CNeuralNet::Clone_OutputSynapsePlasticities_InputLayer(CNeuralNet *pOriginalBrain, float variance, float mutationRate, uint64_t newSeed)
{
	RandomNumbers.Change_Seed(newSeed);

	uint32_t j, numOfOutputSynapses;

	//float weight1, weight2;

	//float newPlasticity;


	uint32_t numInputNeurons = min(NumInputNeurons, pOriginalBrain->NumInputNeurons);

	for (uint32_t i = 0; i < numInputNeurons; i++)
	{
		numOfOutputSynapses = min(pNeuronArray[i].NumOfOutputSynapses, pOriginalBrain->pNeuronArray[i].NumOfOutputSynapses);

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[i].pOutputSynapseActivityStatusArray[j] = pOriginalBrain->pNeuronArray[i].pOutputSynapseActivityStatusArray[j];
			pNeuronArray[i].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[i].pOutputSynapsePlasticityArray[j];

			if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pNeuronArray[i].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-variance, variance);
		}
	}

	if (AdditionalInputBiasNeuron == true)
	{
		uint32_t biasNeuronID = InputBiasNeuronID;
		uint32_t biasNeuronID1 = pOriginalBrain->InputBiasNeuronID;


		numOfOutputSynapses = min(pNeuronArray[biasNeuronID].NumOfOutputSynapses, pOriginalBrain->pNeuronArray[biasNeuronID1].NumOfOutputSynapses);

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[biasNeuronID].pOutputSynapseActivityStatusArray[j] = pOriginalBrain->pNeuronArray[biasNeuronID1].pOutputSynapseActivityStatusArray[j];
			pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[biasNeuronID1].pOutputSynapsePlasticityArray[j];

			if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-variance, variance);
		}
	}
}

void CNeuralNet::Clone_OutputSynapsePlasticities_InputLayer(CNeuralNet *pOriginalBrain, float minVariance, float maxVariance, float mutationRate, uint64_t newSeed)
{
	RandomNumbers.Change_Seed(newSeed);

	uint32_t j, numOfOutputSynapses;

	//float weight1, weight2;

	//float newPlasticity;


	uint32_t numInputNeurons = min(NumInputNeurons, pOriginalBrain->NumInputNeurons);

	for (uint32_t i = 0; i < numInputNeurons; i++)
	{
		numOfOutputSynapses = min(pNeuronArray[i].NumOfOutputSynapses, pOriginalBrain->pNeuronArray[i].NumOfOutputSynapses);

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[i].pOutputSynapseActivityStatusArray[j] = pOriginalBrain->pNeuronArray[i].pOutputSynapseActivityStatusArray[j];
			pNeuronArray[i].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[i].pOutputSynapsePlasticityArray[j];

			if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pNeuronArray[i].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(minVariance, maxVariance);
		}
	}

	if (AdditionalInputBiasNeuron == true)
	{
		uint32_t biasNeuronID = InputBiasNeuronID;
		uint32_t biasNeuronID1 = pOriginalBrain->InputBiasNeuronID;


		numOfOutputSynapses = min(pNeuronArray[biasNeuronID].NumOfOutputSynapses, pOriginalBrain->pNeuronArray[biasNeuronID1].NumOfOutputSynapses);

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[biasNeuronID].pOutputSynapseActivityStatusArray[j] = pOriginalBrain->pNeuronArray[biasNeuronID1].pOutputSynapseActivityStatusArray[j];
			pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[biasNeuronID1].pOutputSynapsePlasticityArray[j];

			if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(minVariance, maxVariance);
		}
	}
}

void CNeuralNet::Clone_OutputSynapsePlasticities_HiddenLayer1(CNeuralNet *pOriginalBrain, float variance, uint64_t newSeed)
{
	if (HiddenLayer1Used == false)
		return;

	RandomNumbers.Change_Seed(newSeed);

	uint32_t j, id, id1, numOfOutputSynapses;

	uint32_t numOfNeurons = min(HiddenLayer1.NumOfNeurons, pOriginalBrain->HiddenLayer1.NumOfNeurons);

	for (uint32_t i = 0; i < numOfNeurons; i++)
	{
		id = HiddenLayer1.pNeuronIDArray[i];
		id1 = pOriginalBrain->HiddenLayer1.pNeuronIDArray[i];

		numOfOutputSynapses = min(pNeuronArray[id].NumOfOutputSynapses, pOriginalBrain->pNeuronArray[id1].NumOfOutputSynapses);

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[id].pOutputSynapseActivityStatusArray[j] = pOriginalBrain->pNeuronArray[id1].pOutputSynapseActivityStatusArray[j];
			pNeuronArray[id].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[id1].pOutputSynapsePlasticityArray[j];
			pNeuronArray[id].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-variance, variance);
		}
	}

	if (HiddenLayer1.AdditionalBiasNeuron == true)
	{
		uint32_t biasNeuronID = HiddenLayer1.BiasNeuronID;
		uint32_t biasNeuronID1 = pOriginalBrain->HiddenLayer1.BiasNeuronID;

		numOfOutputSynapses = min(pNeuronArray[biasNeuronID].NumOfOutputSynapses, pOriginalBrain->pNeuronArray[biasNeuronID1].NumOfOutputSynapses);

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[biasNeuronID].pOutputSynapseActivityStatusArray[j] = pOriginalBrain->pNeuronArray[biasNeuronID1].pOutputSynapseActivityStatusArray[j];
			pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[biasNeuronID1].pOutputSynapsePlasticityArray[j];
			pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-variance, variance);
		}
	}
}

void CNeuralNet::Clone_OutputSynapsePlasticities_HiddenLayer1(CNeuralNet *pOriginalBrain, float variance, float mutationRate, uint64_t newSeed)
{
	if (HiddenLayer1Used == false)
		return;

	RandomNumbers.Change_Seed(newSeed);

	uint32_t j, id, id1, numOfOutputSynapses;

	uint32_t numOfNeurons = min(HiddenLayer1.NumOfNeurons, pOriginalBrain->HiddenLayer1.NumOfNeurons);

	for (uint32_t i = 0; i < numOfNeurons; i++)
	{
		id = HiddenLayer1.pNeuronIDArray[i];
		id1 = pOriginalBrain->HiddenLayer1.pNeuronIDArray[i];

		numOfOutputSynapses = min(pNeuronArray[id].NumOfOutputSynapses, pOriginalBrain->pNeuronArray[id1].NumOfOutputSynapses);

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[id].pOutputSynapseActivityStatusArray[j] = pOriginalBrain->pNeuronArray[id1].pOutputSynapseActivityStatusArray[j];
			pNeuronArray[id].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[id1].pOutputSynapsePlasticityArray[j];

			if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pNeuronArray[id].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-variance, variance);
		}
	}

	if (HiddenLayer1.AdditionalBiasNeuron == true)
	{
		uint32_t biasNeuronID = HiddenLayer1.BiasNeuronID;
		uint32_t biasNeuronID1 = pOriginalBrain->HiddenLayer1.BiasNeuronID;

		numOfOutputSynapses = min(pNeuronArray[biasNeuronID].NumOfOutputSynapses, pOriginalBrain->pNeuronArray[biasNeuronID1].NumOfOutputSynapses);

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[biasNeuronID].pOutputSynapseActivityStatusArray[j] = pOriginalBrain->pNeuronArray[biasNeuronID1].pOutputSynapseActivityStatusArray[j];
			pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[biasNeuronID1].pOutputSynapsePlasticityArray[j];

			if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-variance, variance);
		}
	}
}

void CNeuralNet::Clone_OutputSynapsePlasticities_HiddenLayer1(CNeuralNet *pOriginalBrain, float minVariance, float maxVariance, float mutationRate, uint64_t newSeed)
{
	if (HiddenLayer1Used == false)
		return;

	RandomNumbers.Change_Seed(newSeed);

	uint32_t j, id, id1, numOfOutputSynapses;

	uint32_t numOfNeurons = min(HiddenLayer1.NumOfNeurons, pOriginalBrain->HiddenLayer1.NumOfNeurons);

	for (uint32_t i = 0; i < numOfNeurons; i++)
	{
		id = HiddenLayer1.pNeuronIDArray[i];
		id1 = pOriginalBrain->HiddenLayer1.pNeuronIDArray[i];

		numOfOutputSynapses = min(pNeuronArray[id].NumOfOutputSynapses, pOriginalBrain->pNeuronArray[id1].NumOfOutputSynapses);

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[id].pOutputSynapseActivityStatusArray[j] = pOriginalBrain->pNeuronArray[id1].pOutputSynapseActivityStatusArray[j];
			pNeuronArray[id].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[id1].pOutputSynapsePlasticityArray[j];

			if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pNeuronArray[id].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(minVariance, maxVariance);
		}
	}

	if (HiddenLayer1.AdditionalBiasNeuron == true)
	{
		uint32_t biasNeuronID = HiddenLayer1.BiasNeuronID;
		uint32_t biasNeuronID1 = pOriginalBrain->HiddenLayer1.BiasNeuronID;

		numOfOutputSynapses = min(pNeuronArray[biasNeuronID].NumOfOutputSynapses, pOriginalBrain->pNeuronArray[biasNeuronID1].NumOfOutputSynapses);

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[biasNeuronID].pOutputSynapseActivityStatusArray[j] = pOriginalBrain->pNeuronArray[biasNeuronID1].pOutputSynapseActivityStatusArray[j];
			pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[biasNeuronID1].pOutputSynapsePlasticityArray[j];

			if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(minVariance, maxVariance);
		}
	}
}

void CNeuralNet::Clone_OutputSynapsePlasticities_HiddenLayer2(CNeuralNet *pOriginalBrain, float variance, uint64_t newSeed)
{
	if (HiddenLayer2Used == false)
		return;

	RandomNumbers.Change_Seed(newSeed);

	uint32_t j, id, id1, numOfOutputSynapses;

	uint32_t numOfNeurons = min(HiddenLayer2.NumOfNeurons, pOriginalBrain->HiddenLayer2.NumOfNeurons);

	for (uint32_t i = 0; i < numOfNeurons; i++)
	{
		id = HiddenLayer2.pNeuronIDArray[i];
		id1 = pOriginalBrain->HiddenLayer2.pNeuronIDArray[i];

		numOfOutputSynapses = min(pNeuronArray[id].NumOfOutputSynapses, pOriginalBrain->pNeuronArray[id1].NumOfOutputSynapses);

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[id].pOutputSynapseActivityStatusArray[j] = pOriginalBrain->pNeuronArray[id1].pOutputSynapseActivityStatusArray[j];
			pNeuronArray[id].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[id1].pOutputSynapsePlasticityArray[j];
			pNeuronArray[id].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-variance, variance);
		}
	}

	if (HiddenLayer2.AdditionalBiasNeuron == true)
	{
		uint32_t biasNeuronID = HiddenLayer2.BiasNeuronID;
		uint32_t biasNeuronID1 = pOriginalBrain->HiddenLayer2.BiasNeuronID;

		numOfOutputSynapses = min(pNeuronArray[biasNeuronID].NumOfOutputSynapses, pOriginalBrain->pNeuronArray[biasNeuronID1].NumOfOutputSynapses);

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[biasNeuronID].pOutputSynapseActivityStatusArray[j] = pOriginalBrain->pNeuronArray[biasNeuronID1].pOutputSynapseActivityStatusArray[j];
			pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[biasNeuronID1].pOutputSynapsePlasticityArray[j];
			pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-variance, variance);
		}
	}
}

void CNeuralNet::Clone_OutputSynapsePlasticities_HiddenLayer2(CNeuralNet *pOriginalBrain, float variance, float mutationRate, uint64_t newSeed)
{
	if (HiddenLayer2Used == false)
		return;

	RandomNumbers.Change_Seed(newSeed);

	uint32_t j, id, id1, numOfOutputSynapses;

	uint32_t numOfNeurons = min(HiddenLayer2.NumOfNeurons, pOriginalBrain->HiddenLayer2.NumOfNeurons);

	for (uint32_t i = 0; i < numOfNeurons; i++)
	{
		id = HiddenLayer2.pNeuronIDArray[i];
		id1 = pOriginalBrain->HiddenLayer2.pNeuronIDArray[i];

		numOfOutputSynapses = min(pNeuronArray[id].NumOfOutputSynapses, pOriginalBrain->pNeuronArray[id1].NumOfOutputSynapses);

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[id].pOutputSynapseActivityStatusArray[j] = pOriginalBrain->pNeuronArray[id1].pOutputSynapseActivityStatusArray[j];
			pNeuronArray[id].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[id1].pOutputSynapsePlasticityArray[j];

			if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pNeuronArray[id].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-variance, variance);
		}
	}

	if (HiddenLayer2.AdditionalBiasNeuron == true)
	{
		uint32_t biasNeuronID = HiddenLayer2.BiasNeuronID;
		uint32_t biasNeuronID1 = pOriginalBrain->HiddenLayer2.BiasNeuronID;

		numOfOutputSynapses = min(pNeuronArray[biasNeuronID].NumOfOutputSynapses, pOriginalBrain->pNeuronArray[biasNeuronID1].NumOfOutputSynapses);

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[biasNeuronID].pOutputSynapseActivityStatusArray[j] = pOriginalBrain->pNeuronArray[biasNeuronID1].pOutputSynapseActivityStatusArray[j];
			pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[biasNeuronID1].pOutputSynapsePlasticityArray[j];

			if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-variance, variance);
		}
	}
}

void CNeuralNet::Clone_OutputSynapsePlasticities_HiddenLayer2(CNeuralNet *pOriginalBrain, float minVariance, float maxVariance, float mutationRate, uint64_t newSeed)
{
	if (HiddenLayer2Used == false)
		return;

	RandomNumbers.Change_Seed(newSeed);

	uint32_t j, id, id1, numOfOutputSynapses;

	uint32_t numOfNeurons = min(HiddenLayer2.NumOfNeurons, pOriginalBrain->HiddenLayer2.NumOfNeurons);

	for (uint32_t i = 0; i < numOfNeurons; i++)
	{
		id = HiddenLayer2.pNeuronIDArray[i];
		id1 = pOriginalBrain->HiddenLayer2.pNeuronIDArray[i];

		numOfOutputSynapses = min(pNeuronArray[id].NumOfOutputSynapses, pOriginalBrain->pNeuronArray[id1].NumOfOutputSynapses);

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[id].pOutputSynapseActivityStatusArray[j] = pOriginalBrain->pNeuronArray[id1].pOutputSynapseActivityStatusArray[j];
			pNeuronArray[id].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[id1].pOutputSynapsePlasticityArray[j];

			if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pNeuronArray[id].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(minVariance, maxVariance);
		}
	}

	if (HiddenLayer2.AdditionalBiasNeuron == true)
	{
		uint32_t biasNeuronID = HiddenLayer2.BiasNeuronID;
		uint32_t biasNeuronID1 = pOriginalBrain->HiddenLayer2.BiasNeuronID;

		numOfOutputSynapses = min(pNeuronArray[biasNeuronID].NumOfOutputSynapses, pOriginalBrain->pNeuronArray[biasNeuronID1].NumOfOutputSynapses);

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[biasNeuronID].pOutputSynapseActivityStatusArray[j] = pOriginalBrain->pNeuronArray[biasNeuronID1].pOutputSynapseActivityStatusArray[j];
			pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[biasNeuronID1].pOutputSynapsePlasticityArray[j];

			if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(minVariance, maxVariance);
		}
	}
}

void CNeuralNet::Clone_OutputSynapsePlasticities_HiddenLayer3(CNeuralNet *pOriginalBrain, float variance, uint64_t newSeed)
{
	if (HiddenLayer3Used == false)
		return;

	RandomNumbers.Change_Seed(newSeed);

	uint32_t j, id, id1, numOfOutputSynapses;

	uint32_t numOfNeurons = min(HiddenLayer3.NumOfNeurons, pOriginalBrain->HiddenLayer3.NumOfNeurons);

	for (uint32_t i = 0; i < numOfNeurons; i++)
	{
		id = HiddenLayer3.pNeuronIDArray[i];
		id1 = pOriginalBrain->HiddenLayer3.pNeuronIDArray[i];

		numOfOutputSynapses = min(pNeuronArray[id].NumOfOutputSynapses, pOriginalBrain->pNeuronArray[id1].NumOfOutputSynapses);

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[id].pOutputSynapseActivityStatusArray[j] = pOriginalBrain->pNeuronArray[id1].pOutputSynapseActivityStatusArray[j];
			pNeuronArray[id].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[id1].pOutputSynapsePlasticityArray[j];
			pNeuronArray[id].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-variance, variance);
		}
	}

	if (HiddenLayer3.AdditionalBiasNeuron == true)
	{
		uint32_t biasNeuronID = HiddenLayer3.BiasNeuronID;
		uint32_t biasNeuronID1 = pOriginalBrain->HiddenLayer3.BiasNeuronID;

		numOfOutputSynapses = min(pNeuronArray[biasNeuronID].NumOfOutputSynapses, pOriginalBrain->pNeuronArray[biasNeuronID1].NumOfOutputSynapses);

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[biasNeuronID].pOutputSynapseActivityStatusArray[j] = pOriginalBrain->pNeuronArray[biasNeuronID1].pOutputSynapseActivityStatusArray[j];
			pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[biasNeuronID1].pOutputSynapsePlasticityArray[j];
			pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-variance, variance);
		}
	}
}

void CNeuralNet::Clone_OutputSynapsePlasticities_HiddenLayer3(CNeuralNet *pOriginalBrain, float variance, float mutationRate, uint64_t newSeed)
{
	if (HiddenLayer3Used == false)
		return;

	RandomNumbers.Change_Seed(newSeed);

	uint32_t j, id, id1, numOfOutputSynapses;

	uint32_t numOfNeurons = min(HiddenLayer3.NumOfNeurons, pOriginalBrain->HiddenLayer3.NumOfNeurons);

	for (uint32_t i = 0; i < numOfNeurons; i++)
	{
		id = HiddenLayer3.pNeuronIDArray[i];
		id1 = pOriginalBrain->HiddenLayer3.pNeuronIDArray[i];

		numOfOutputSynapses = min(pNeuronArray[id].NumOfOutputSynapses, pOriginalBrain->pNeuronArray[id1].NumOfOutputSynapses);

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[id].pOutputSynapseActivityStatusArray[j] = pOriginalBrain->pNeuronArray[id1].pOutputSynapseActivityStatusArray[j];
			pNeuronArray[id].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[id1].pOutputSynapsePlasticityArray[j];

			if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pNeuronArray[id].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-variance, variance);
		}
	}

	if (HiddenLayer3.AdditionalBiasNeuron == true)
	{
		uint32_t biasNeuronID = HiddenLayer3.BiasNeuronID;
		uint32_t biasNeuronID1 = pOriginalBrain->HiddenLayer3.BiasNeuronID;

		numOfOutputSynapses = min(pNeuronArray[biasNeuronID].NumOfOutputSynapses, pOriginalBrain->pNeuronArray[biasNeuronID1].NumOfOutputSynapses);

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[biasNeuronID].pOutputSynapseActivityStatusArray[j] = pOriginalBrain->pNeuronArray[biasNeuronID1].pOutputSynapseActivityStatusArray[j];
			pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[biasNeuronID1].pOutputSynapsePlasticityArray[j];

			if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-variance, variance);
		}
	}
}

void CNeuralNet::Clone_OutputSynapsePlasticities_HiddenLayer3(CNeuralNet *pOriginalBrain, float minVariance, float maxVariance, float mutationRate, uint64_t newSeed)
{
	if (HiddenLayer3Used == false)
		return;

	RandomNumbers.Change_Seed(newSeed);

	uint32_t j, id, id1, numOfOutputSynapses;

	uint32_t numOfNeurons = min(HiddenLayer3.NumOfNeurons, pOriginalBrain->HiddenLayer3.NumOfNeurons);

	for (uint32_t i = 0; i < numOfNeurons; i++)
	{
		id = HiddenLayer3.pNeuronIDArray[i];
		id1 = pOriginalBrain->HiddenLayer3.pNeuronIDArray[i];

		numOfOutputSynapses = min(pNeuronArray[id].NumOfOutputSynapses, pOriginalBrain->pNeuronArray[id1].NumOfOutputSynapses);

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[id].pOutputSynapseActivityStatusArray[j] = pOriginalBrain->pNeuronArray[id1].pOutputSynapseActivityStatusArray[j];
			pNeuronArray[id].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[id1].pOutputSynapsePlasticityArray[j];

			if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pNeuronArray[id].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(minVariance, maxVariance);
		}
	}

	if (HiddenLayer3.AdditionalBiasNeuron == true)
	{
		uint32_t biasNeuronID = HiddenLayer3.BiasNeuronID;
		uint32_t biasNeuronID1 = pOriginalBrain->HiddenLayer3.BiasNeuronID;

		numOfOutputSynapses = min(pNeuronArray[biasNeuronID].NumOfOutputSynapses, pOriginalBrain->pNeuronArray[biasNeuronID1].NumOfOutputSynapses);

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[biasNeuronID].pOutputSynapseActivityStatusArray[j] = pOriginalBrain->pNeuronArray[biasNeuronID1].pOutputSynapseActivityStatusArray[j];
			pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[biasNeuronID1].pOutputSynapsePlasticityArray[j];

			if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(minVariance, maxVariance);
		}
	}
}

void CNeuralNet::Combine_OutputSynapsePlasticities_InputLayer(CNeuralNet *pParentBrain1, CNeuralNet *pParentBrain2, float minWeight1, uint64_t newSeed)
{
	RandomNumbers.Change_Seed(newSeed);

	uint32_t j, numOfOutputSynapses;

	float weight1, weight2;

	float newPlasticity;

	uint32_t numInputNeurons = min(NumInputNeurons, pParentBrain1->NumInputNeurons);
	numInputNeurons = min(numInputNeurons, pParentBrain2->NumInputNeurons);

	for (uint32_t i = 0; i < numInputNeurons; i++)
	{
		numOfOutputSynapses = min(pNeuronArray[i].NumOfOutputSynapses, pParentBrain1->pNeuronArray[i].NumOfOutputSynapses);
		numOfOutputSynapses = min(numOfOutputSynapses, pParentBrain2->pNeuronArray[i].NumOfOutputSynapses);

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[i].pOutputSynapseActivityStatusArray[j] = false;

			if (pParentBrain1->pNeuronArray[i].pOutputSynapseActivityStatusArray[j] == true ||
				pParentBrain2->pNeuronArray[i].pOutputSynapseActivityStatusArray[j] == true)
				pNeuronArray[i].pOutputSynapseActivityStatusArray[j] = true;

			weight1 = RandomNumbers.Get_FloatNumber(minWeight1, 1.0f);
			weight2 = 1.0f - weight1;
			newPlasticity = weight1*pParentBrain1->pNeuronArray[i].pOutputSynapsePlasticityArray[j];
			newPlasticity += weight2*pParentBrain2->pNeuronArray[i].pOutputSynapsePlasticityArray[j];

			pNeuronArray[i].pOutputSynapsePlasticityArray[j] = newPlasticity;
		}
	}

	if (AdditionalInputBiasNeuron == true)
	{
		uint32_t biasNeuronID = InputBiasNeuronID;
		uint32_t biasNeuronID1 = pParentBrain1->InputBiasNeuronID;
		uint32_t biasNeuronID2 = pParentBrain2->InputBiasNeuronID;

		numOfOutputSynapses = min(pNeuronArray[biasNeuronID].NumOfOutputSynapses, pParentBrain1->pNeuronArray[biasNeuronID1].NumOfOutputSynapses);
		numOfOutputSynapses = min(numOfOutputSynapses, pParentBrain2->pNeuronArray[biasNeuronID2].NumOfOutputSynapses);

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[biasNeuronID].pOutputSynapseActivityStatusArray[j] = false;

			if (pParentBrain1->pNeuronArray[biasNeuronID1].pOutputSynapseActivityStatusArray[j] == true ||
				pParentBrain2->pNeuronArray[biasNeuronID2].pOutputSynapseActivityStatusArray[j] == true)
				pNeuronArray[biasNeuronID].pOutputSynapseActivityStatusArray[j] = true;

			weight1 = RandomNumbers.Get_FloatNumber(minWeight1, 1.0f);
			weight2 = 1.0f - weight1;
			newPlasticity = weight1*pParentBrain1->pNeuronArray[biasNeuronID1].pOutputSynapsePlasticityArray[j];
			newPlasticity += weight2*pParentBrain2->pNeuronArray[biasNeuronID2].pOutputSynapsePlasticityArray[j];

			pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] = newPlasticity;
		}
	}
}

void CNeuralNet::Combine_OutputSynapsePlasticities_HiddenLayer1(CNeuralNet *pParentBrain1, CNeuralNet *pParentBrain2, float minWeight1, uint64_t newSeed)
{
	if (HiddenLayer1Used == false)
		return;

	RandomNumbers.Change_Seed(newSeed);

	uint32_t j, id, id1, id2, numOfOutputSynapses;

	float weight1, weight2;

	float newPlasticity;

	//uint32_t numOfNeurons = HiddenLayer1.NumOfNeurons;

	uint32_t numOfNeurons = min(HiddenLayer1.NumOfNeurons, pParentBrain1->HiddenLayer1.NumOfNeurons);
	numOfNeurons = min(numOfNeurons, pParentBrain2->HiddenLayer1.NumOfNeurons);



	for (uint32_t i = 0; i < numOfNeurons; i++)
	{
		id = HiddenLayer1.pNeuronIDArray[i];
		id1 = pParentBrain1->HiddenLayer1.pNeuronIDArray[i];
		id2 = pParentBrain2->HiddenLayer1.pNeuronIDArray[i];

		numOfOutputSynapses = min(pNeuronArray[id].NumOfOutputSynapses, pParentBrain1->pNeuronArray[id1].NumOfOutputSynapses);
		numOfOutputSynapses = min(numOfOutputSynapses, pParentBrain2->pNeuronArray[id2].NumOfOutputSynapses);

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[id].pOutputSynapseActivityStatusArray[j] = false;

			if (pParentBrain1->pNeuronArray[id1].pOutputSynapseActivityStatusArray[j] == true ||
				pParentBrain2->pNeuronArray[id2].pOutputSynapseActivityStatusArray[j] == true)
				pNeuronArray[id].pOutputSynapseActivityStatusArray[j] = true;

			weight1 = RandomNumbers.Get_FloatNumber(minWeight1, 1.0f);
			weight2 = 1.0f - weight1;
			newPlasticity = weight1*pParentBrain1->pNeuronArray[id1].pOutputSynapsePlasticityArray[j];
			newPlasticity += weight2*pParentBrain2->pNeuronArray[id2].pOutputSynapsePlasticityArray[j];

			pNeuronArray[id].pOutputSynapsePlasticityArray[j] = newPlasticity;
		}
	}

	if (HiddenLayer1.AdditionalBiasNeuron == true)
	{
		uint32_t biasNeuronID = HiddenLayer1.BiasNeuronID;
		uint32_t biasNeuronID1 = pParentBrain1->HiddenLayer1.BiasNeuronID;
		uint32_t biasNeuronID2 = pParentBrain2->HiddenLayer1.BiasNeuronID;

		numOfOutputSynapses = min(pNeuronArray[biasNeuronID].NumOfOutputSynapses, pParentBrain1->pNeuronArray[biasNeuronID1].NumOfOutputSynapses);
		numOfOutputSynapses = min(numOfOutputSynapses, pParentBrain2->pNeuronArray[biasNeuronID2].NumOfOutputSynapses);

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[biasNeuronID].pOutputSynapseActivityStatusArray[j] = false;

			if (pParentBrain1->pNeuronArray[biasNeuronID1].pOutputSynapseActivityStatusArray[j] == true ||
				pParentBrain2->pNeuronArray[biasNeuronID2].pOutputSynapseActivityStatusArray[j] == true)
				pNeuronArray[biasNeuronID].pOutputSynapseActivityStatusArray[j] = true;

			weight1 = RandomNumbers.Get_FloatNumber(minWeight1, 1.0f);
			weight2 = 1.0f - weight1;
			newPlasticity = weight1*pParentBrain1->pNeuronArray[biasNeuronID1].pOutputSynapsePlasticityArray[j];
			newPlasticity += weight2*pParentBrain2->pNeuronArray[biasNeuronID2].pOutputSynapsePlasticityArray[j];

			pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] = newPlasticity;
		}
	}
}

void CNeuralNet::Combine_OutputSynapsePlasticities_HiddenLayer2(CNeuralNet *pParentBrain1, CNeuralNet *pParentBrain2, float minWeight1, uint64_t newSeed)
{
	if (HiddenLayer2Used == false)
		return;

	RandomNumbers.Change_Seed(newSeed);

	uint32_t j, id, id1, id2, numOfOutputSynapses;

	float weight1, weight2;

	float newPlasticity;

	//uint32_t numOfNeurons = HiddenLayer2.NumOfNeurons;

	uint32_t numOfNeurons = min(HiddenLayer2.NumOfNeurons, pParentBrain1->HiddenLayer2.NumOfNeurons);
	numOfNeurons = min(numOfNeurons, pParentBrain2->HiddenLayer2.NumOfNeurons);



	for (uint32_t i = 0; i < numOfNeurons; i++)
	{
		id = HiddenLayer2.pNeuronIDArray[i];
		id1 = pParentBrain1->HiddenLayer2.pNeuronIDArray[i];
		id2 = pParentBrain2->HiddenLayer2.pNeuronIDArray[i];

		numOfOutputSynapses = min(pNeuronArray[id].NumOfOutputSynapses, pParentBrain1->pNeuronArray[id1].NumOfOutputSynapses);
		numOfOutputSynapses = min(numOfOutputSynapses, pParentBrain2->pNeuronArray[id2].NumOfOutputSynapses);

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[id].pOutputSynapseActivityStatusArray[j] = false;

			if (pParentBrain1->pNeuronArray[id1].pOutputSynapseActivityStatusArray[j] == true ||
				pParentBrain2->pNeuronArray[id2].pOutputSynapseActivityStatusArray[j] == true)
				pNeuronArray[id].pOutputSynapseActivityStatusArray[j] = true;

			weight1 = RandomNumbers.Get_FloatNumber(minWeight1, 1.0f);
			weight2 = 1.0f - weight1;
			newPlasticity = weight1*pParentBrain1->pNeuronArray[id1].pOutputSynapsePlasticityArray[j];
			newPlasticity += weight2*pParentBrain2->pNeuronArray[id2].pOutputSynapsePlasticityArray[j];

			pNeuronArray[id].pOutputSynapsePlasticityArray[j] = newPlasticity;
		}
	}



	if (HiddenLayer2.AdditionalBiasNeuron == true)
	{
		uint32_t biasNeuronID = HiddenLayer2.BiasNeuronID;
		uint32_t biasNeuronID1 = pParentBrain1->HiddenLayer2.BiasNeuronID;
		uint32_t biasNeuronID2 = pParentBrain2->HiddenLayer2.BiasNeuronID;

		numOfOutputSynapses = min(pNeuronArray[biasNeuronID].NumOfOutputSynapses, pParentBrain1->pNeuronArray[biasNeuronID1].NumOfOutputSynapses);
		numOfOutputSynapses = min(numOfOutputSynapses, pParentBrain2->pNeuronArray[biasNeuronID2].NumOfOutputSynapses);

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[biasNeuronID].pOutputSynapseActivityStatusArray[j] = false;

			if (pParentBrain1->pNeuronArray[biasNeuronID1].pOutputSynapseActivityStatusArray[j] == true ||
				pParentBrain2->pNeuronArray[biasNeuronID2].pOutputSynapseActivityStatusArray[j] == true)
				pNeuronArray[biasNeuronID].pOutputSynapseActivityStatusArray[j] = true;

			weight1 = RandomNumbers.Get_FloatNumber(minWeight1, 1.0f);
			weight2 = 1.0f - weight1;
			newPlasticity = weight1*pParentBrain1->pNeuronArray[biasNeuronID1].pOutputSynapsePlasticityArray[j];
			newPlasticity += weight2*pParentBrain2->pNeuronArray[biasNeuronID2].pOutputSynapsePlasticityArray[j];

			pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] = newPlasticity;
		}
	}
}

void CNeuralNet::Combine_OutputSynapsePlasticities_HiddenLayer3(CNeuralNet *pParentBrain1, CNeuralNet *pParentBrain2, float minWeight1, uint64_t newSeed)
{
	if (HiddenLayer3Used == false)
		return;

	RandomNumbers.Change_Seed(newSeed);

	uint32_t j, id, id1, id2, numOfOutputSynapses;

	float weight1, weight2;

	float newPlasticity;

	//uint32_t numOfNeurons = HiddenLayer3.NumOfNeurons;

	uint32_t numOfNeurons = min(HiddenLayer3.NumOfNeurons, pParentBrain1->HiddenLayer3.NumOfNeurons);
	numOfNeurons = min(numOfNeurons, pParentBrain2->HiddenLayer3.NumOfNeurons);



	for (uint32_t i = 0; i < numOfNeurons; i++)
	{
		id = HiddenLayer3.pNeuronIDArray[i];
		id1 = pParentBrain1->HiddenLayer3.pNeuronIDArray[i];
		id2 = pParentBrain2->HiddenLayer3.pNeuronIDArray[i];

		numOfOutputSynapses = min(pNeuronArray[id].NumOfOutputSynapses, pParentBrain1->pNeuronArray[id1].NumOfOutputSynapses);
		numOfOutputSynapses = min(numOfOutputSynapses, pParentBrain2->pNeuronArray[id2].NumOfOutputSynapses);

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[id].pOutputSynapseActivityStatusArray[j] = false;

			if (pParentBrain1->pNeuronArray[id1].pOutputSynapseActivityStatusArray[j] == true ||
				pParentBrain2->pNeuronArray[id2].pOutputSynapseActivityStatusArray[j] == true)
				pNeuronArray[id].pOutputSynapseActivityStatusArray[j] = true;

			weight1 = RandomNumbers.Get_FloatNumber(minWeight1, 1.0f);
			weight2 = 1.0f - weight1;
			newPlasticity = weight1*pParentBrain1->pNeuronArray[id1].pOutputSynapsePlasticityArray[j];
			newPlasticity += weight2*pParentBrain2->pNeuronArray[id2].pOutputSynapsePlasticityArray[j];

			pNeuronArray[id].pOutputSynapsePlasticityArray[j] = newPlasticity;
		}
	}



	if (HiddenLayer3.AdditionalBiasNeuron == true)
	{
		uint32_t biasNeuronID = HiddenLayer3.BiasNeuronID;
		uint32_t biasNeuronID1 = pParentBrain1->HiddenLayer3.BiasNeuronID;
		uint32_t biasNeuronID2 = pParentBrain2->HiddenLayer3.BiasNeuronID;

		numOfOutputSynapses = min(pNeuronArray[biasNeuronID].NumOfOutputSynapses, pParentBrain1->pNeuronArray[biasNeuronID1].NumOfOutputSynapses);
		numOfOutputSynapses = min(numOfOutputSynapses, pParentBrain2->pNeuronArray[biasNeuronID2].NumOfOutputSynapses);

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[biasNeuronID].pOutputSynapseActivityStatusArray[j] = false;

			if (pParentBrain1->pNeuronArray[biasNeuronID1].pOutputSynapseActivityStatusArray[j] == true ||
				pParentBrain2->pNeuronArray[biasNeuronID2].pOutputSynapseActivityStatusArray[j] == true)
				pNeuronArray[biasNeuronID].pOutputSynapseActivityStatusArray[j] = true;

			weight1 = RandomNumbers.Get_FloatNumber(minWeight1, 1.0f);
			weight2 = 1.0f - weight1;
			newPlasticity = weight1*pParentBrain1->pNeuronArray[biasNeuronID1].pOutputSynapsePlasticityArray[j];
			newPlasticity += weight2*pParentBrain2->pNeuronArray[biasNeuronID2].pOutputSynapsePlasticityArray[j];

			pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] = newPlasticity;
		}
	}
}

void CNeuralNet::Combine_OutputSynapsePlasticities_ReservoirNeurons(CNeuralNet *pParentBrain1, CNeuralNet *pParentBrain2, float minWeight1, uint64_t newSeed)
{
	RandomNumbers.Change_Seed(newSeed);

	uint32_t j, id, numOfOutputSynapses, receiverID;

	float weight1, weight2;

	float newPlasticity;

	for (uint32_t i = 0; i < NumReservoirNeurons; i++)
	{
		id = FirstReservoirNeuronID + i;

		numOfOutputSynapses = pNeuronArray[id].NumOfOutputSynapses;

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			receiverID = pNeuronArray[id].pReceiverNeuronIDArray[i];

			if (pNeuronArray[receiverID].UsedAsMemoryNeuron != true)
				continue;

			weight1 = RandomNumbers.Get_FloatNumber(minWeight1, 1.0f);
			weight2 = 1.0f - weight1;
			newPlasticity = weight1*pParentBrain1->pNeuronArray[id].pOutputSynapsePlasticityArray[j];
			newPlasticity += weight2*pParentBrain2->pNeuronArray[id].pOutputSynapsePlasticityArray[j];

			pNeuronArray[id].pOutputSynapsePlasticityArray[j] = newPlasticity;
		}
	}
}

void CNeuralNet::Combine_OutputSynapsePlasticities(CNeuralNet *pParentBrain1, CNeuralNet *pParentBrain2, float minWeight1, uint64_t newSeed)
{
	RandomNumbers.Change_Seed(newSeed);

	uint32_t j, numOfOutputSynapses;

	float weight1, weight2;

	float newPlasticity;

	for (uint32_t i = 0; i < NumOfUsedNeurons; i++)
	{
		numOfOutputSynapses = pNeuronArray[i].NumOfOutputSynapses;

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[i].pOutputSynapseActivityStatusArray[j] = false;

			if (pParentBrain1->pNeuronArray[i].pOutputSynapseActivityStatusArray[j] == true ||
				pParentBrain2->pNeuronArray[i].pOutputSynapseActivityStatusArray[j] == true)
				pNeuronArray[i].pOutputSynapseActivityStatusArray[j] = true;

			weight1 = RandomNumbers.Get_FloatNumber(minWeight1, 1.0f);
			weight2 = 1.0f - weight1;
			newPlasticity = weight1*pParentBrain1->pNeuronArray[i].pOutputSynapsePlasticityArray[j];
			newPlasticity += weight2*pParentBrain2->pNeuronArray[i].pOutputSynapsePlasticityArray[j];

			pNeuronArray[i].pOutputSynapsePlasticityArray[j] = newPlasticity;
		}
	}
}

void CNeuralNet::Calculate_Output_UseActivationSequence(float *pOutputValueArray, const float *pInputValueArray)
{
	for (uint32_t i = 0; i < NumInputNeurons; i++)
		pNeuronArray[i].Set_Input(pInputValueArray[i]);

	uint32_t id;


	for (uint32_t i = 0; i < NumOfActivationSequenceArrayEntries; i++)
	{
		id = pActivationSequenceArray[i];

		if (pNeuronArray[id].UsedAsBiasNeuron == false && pNeuronArray[id].UsedAsInputNeuron == false)
			pNeuronArray[id].Calculate_NeuronOutput();

		if (pNeuronArray[id].UsedAsOutputNeuron == false)
			pNeuronArray[id].Propagate_SynapticOutput();
	}

	for (uint32_t i = 0; i < NumOutputNeurons; i++)
	{
		id = i + FirstOutputNeuronID;

		pOutputValueArray[i] = pNeuronArray[id].Get_NeuronOutput();
	}
}

float CNeuralNet::Calculate_Output_With_Error_UseActivationSequence(float *pOutputValueArray, const float *pInputValueArray)
{
	for (uint32_t i = 0; i < NumInputNeurons; i++)
		pNeuronArray[i].Set_Input(pInputValueArray[i]);

	uint32_t id;

	for (uint32_t i = 0; i < NumOfActivationSequenceArrayEntries; i++)
	{
		id = pActivationSequenceArray[i];

		if (pNeuronArray[id].UsedAsBiasNeuron == false && pNeuronArray[id].UsedAsInputNeuron == false)
			pNeuronArray[id].Calculate_NeuronOutput();

		if (pNeuronArray[id].UsedAsOutputNeuron == false)
			pNeuronArray[id].Propagate_SynapticOutput();
	}

	for (uint32_t i = 0; i < NumOutputNeurons; i++)
	{
		id = i + FirstOutputNeuronID;
		pOutputValueArray[i] = pNeuronArray[id].Get_NeuronOutput();
	}

	float error = 0.0f;

	for (uint32_t i = 0; i < NumOutputNeurons; i++)
	{
		id = FirstOutputNeuronID + i;
		error += pNeuronArray[id].Calculate_Error(pInputValueArray[i]);
	}

	return error;
}

void CNeuralNet::Set_InputNeuronValues_And_Propagate_Them(const float *pInputValueArray)
{
	for (uint32_t i = 0; i < NumInputNeurons; i++)
	{
		pNeuronArray[i].Set_Input(pInputValueArray[i]);
		pNeuronArray[i].Propagate_SynapticOutput();
	}

	if (AdditionalInputBiasNeuron == true)
		pNeuronArray[InputBiasNeuronID].Propagate_SynapticOutput();
}

void CNeuralNet::Set_InputNeuronValues_And_Propagate_Them(const float *pInputValueArray, uint32_t offset, uint32_t numValues)
{
	uint32_t neuronIdMax = offset + numValues;

	uint32_t counter = 0;

	for (uint32_t i = offset; i < neuronIdMax; i++)
	{
		pNeuronArray[i].Set_Input(pInputValueArray[counter]);
		pNeuronArray[i].Propagate_SynapticOutput();
		counter++;
	}

	if (AdditionalInputBiasNeuron == true && offset == 0)
		pNeuronArray[InputBiasNeuronID].Propagate_SynapticOutput();
}

void CNeuralNet::Set_InputValues_HiddenLayer1(const float *pInputValueArray)
{
	if (HiddenLayer1Used == false)
		return;

	uint32_t numOfNeurons = HiddenLayer1.NumOfNeurons;

	uint32_t i, id;

	for (i = 0; i < numOfNeurons; i++)
	{
		id = HiddenLayer1.pNeuronIDArray[i];
		pNeuronArray[id].Set_NeuronInput(pInputValueArray[i]);
	}
}

void CNeuralNet::Set_InputValues_HiddenLayer1(float value)
{
	if (HiddenLayer1Used == false)
		return;

	uint32_t numOfNeurons = HiddenLayer1.NumOfNeurons;

	uint32_t i, id;

	for (i = 0; i < numOfNeurons; i++)
	{
		id = HiddenLayer1.pNeuronIDArray[i];
		pNeuronArray[id].Set_NeuronInput(value);
	}
}

void CNeuralNet::Set_InputValues_HiddenLayer1(float value, uint32_t id_InsideLayer)
{
	if (HiddenLayer1Used == false)
		return;

	uint32_t id = HiddenLayer1.pNeuronIDArray[id_InsideLayer];
	pNeuronArray[id].Set_NeuronInput(value);
}

void CNeuralNet::Get_Output(float *pOutputValueArray)
{
	uint32_t id;

	for (uint32_t i = 0; i < NumOutputNeurons; i++)
	{
		id = i + FirstOutputNeuronID;

		pOutputValueArray[i] = pNeuronArray[id].Get_NeuronOutput();
		//pOutputValueArray[i] = pNeuronArray[id].NeuronOutput;
	}
}

void CNeuralNet::Calculate_Output(float *pOutputValueArray, const float *pInputValueArray)
{
	uint32_t i, id;

	for (i = 0; i < NumInputNeurons; i++)
	{
		pNeuronArray[i].Set_Input(pInputValueArray[i]);
		pNeuronArray[i].Propagate_SynapticOutput();
	}

	if (AdditionalInputBiasNeuron == true)
		pNeuronArray[InputBiasNeuronID].Propagate_SynapticOutput();

	if (HiddenLayer1Used == true)
	{
		uint32_t numOfNeurons = HiddenLayer1.NumOfNeurons;

		for (i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer1.pNeuronIDArray[i];

			pNeuronArray[id].Calculate_NeuronOutput();
			pNeuronArray[id].Propagate_SynapticOutput();
		}

		if (HiddenLayer1.AdditionalBiasNeuron == true)
			pNeuronArray[HiddenLayer1.BiasNeuronID].Propagate_SynapticOutput();
	}

	if (HiddenLayer2Used == true)
	{
		uint32_t numOfNeurons = HiddenLayer2.NumOfNeurons;

		for (i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer2.pNeuronIDArray[i];

			pNeuronArray[id].Calculate_NeuronOutput();
			pNeuronArray[id].Propagate_SynapticOutput();
		}

		if (HiddenLayer2.AdditionalBiasNeuron == true)
			pNeuronArray[HiddenLayer2.BiasNeuronID].Propagate_SynapticOutput();
	}

	if (HiddenLayer3Used == true)
	{
		uint32_t numOfNeurons = HiddenLayer3.NumOfNeurons;

		for (i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer3.pNeuronIDArray[i];

			pNeuronArray[id].Calculate_NeuronOutput();
			pNeuronArray[id].Propagate_SynapticOutput();
		}

		if (HiddenLayer3.AdditionalBiasNeuron == true)
			pNeuronArray[HiddenLayer3.BiasNeuronID].Propagate_SynapticOutput();
	}

	for (i = 0; i < NumOutputNeurons; i++)
	{
		id = i + FirstOutputNeuronID;

		pNeuronArray[id].Calculate_NeuronOutput();

		pOutputValueArray[i] = pNeuronArray[id].Get_NeuronOutput();
		//pOutputValueArray[i] = pNeuronArray[id].NeuronOutput;
	}
}

float CNeuralNet::Calculate_Output2(const float *pInputValueArray, uint32_t idOfOutputNeuron)
{
	uint32_t i, id;

	for (i = 0; i < NumInputNeurons; i++)
	{
		pNeuronArray[i].Set_Input(pInputValueArray[i]);
		pNeuronArray[i].Propagate_SynapticOutput();
	}

	if (AdditionalInputBiasNeuron == true)
		pNeuronArray[InputBiasNeuronID].Propagate_SynapticOutput();

	if (HiddenLayer1Used == true)
	{
		uint32_t numOfNeurons = HiddenLayer1.NumOfNeurons;

		for (i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer1.pNeuronIDArray[i];

			pNeuronArray[id].Calculate_NeuronOutput();
			pNeuronArray[id].Propagate_SynapticOutput();
		}

		if (HiddenLayer1.AdditionalBiasNeuron == true)
			pNeuronArray[HiddenLayer1.BiasNeuronID].Propagate_SynapticOutput();
	}

	if (HiddenLayer2Used == true)
	{
		uint32_t numOfNeurons = HiddenLayer2.NumOfNeurons;

		for (i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer2.pNeuronIDArray[i];

			pNeuronArray[id].Calculate_NeuronOutput();
			pNeuronArray[id].Propagate_SynapticOutput();
		}

		if (HiddenLayer2.AdditionalBiasNeuron == true)
			pNeuronArray[HiddenLayer2.BiasNeuronID].Propagate_SynapticOutput();
	}

	if (HiddenLayer3Used == true)
	{
		uint32_t numOfNeurons = HiddenLayer3.NumOfNeurons;

		for (i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer3.pNeuronIDArray[i];

			pNeuronArray[id].Calculate_NeuronOutput();
			pNeuronArray[id].Propagate_SynapticOutput();
		}

		if (HiddenLayer3.AdditionalBiasNeuron == true)
			pNeuronArray[HiddenLayer3.BiasNeuronID].Propagate_SynapticOutput();
	}

	for (i = 0; i < NumOutputNeurons; i++)
	{
		if (i == idOfOutputNeuron)
			continue;

		id = i + FirstOutputNeuronID;

		pNeuronArray[id].Reset_NeuronInput();
	}


	id = idOfOutputNeuron + FirstOutputNeuronID;

	pNeuronArray[id].Calculate_NeuronOutput();

	//return pNeuronArray[id].Get_NeuronOutput();
	return pNeuronArray[id].NeuronOutput;

}

void CNeuralNet::Calculate_Output_IgnoreInputNeurons(float *pOutputValueArray)
{
	uint32_t i, id;

	if (HiddenLayer1Used == true)
	{
		uint32_t numOfNeurons = HiddenLayer1.NumOfNeurons;

		for (i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer1.pNeuronIDArray[i];

			pNeuronArray[id].Calculate_NeuronOutput();
			pNeuronArray[id].Propagate_SynapticOutput();
		}

		if (HiddenLayer1.AdditionalBiasNeuron == true)
			pNeuronArray[HiddenLayer1.BiasNeuronID].Propagate_SynapticOutput();
	}

	if (HiddenLayer2Used == true)
	{
		uint32_t numOfNeurons = HiddenLayer2.NumOfNeurons;

		for (i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer2.pNeuronIDArray[i];

			pNeuronArray[id].Calculate_NeuronOutput();
			pNeuronArray[id].Propagate_SynapticOutput();
		}

		if (HiddenLayer2.AdditionalBiasNeuron == true)
			pNeuronArray[HiddenLayer2.BiasNeuronID].Propagate_SynapticOutput();
	}

	if (HiddenLayer3Used == true)
	{
		uint32_t numOfNeurons = HiddenLayer3.NumOfNeurons;

		for (i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer3.pNeuronIDArray[i];

			pNeuronArray[id].Calculate_NeuronOutput();
			pNeuronArray[id].Propagate_SynapticOutput();
		}

		if (HiddenLayer3.AdditionalBiasNeuron == true)
			pNeuronArray[HiddenLayer3.BiasNeuronID].Propagate_SynapticOutput();
	}

	for (i = 0; i < NumOutputNeurons; i++)
	{
		id = i + FirstOutputNeuronID;

		pNeuronArray[id].Calculate_NeuronOutput();

		pOutputValueArray[i] = pNeuronArray[id].Get_NeuronOutput();
		//pOutputValueArray[i] = pNeuronArray[id].NeuronOutput;
	}
}

float CNeuralNet::Calculate_Output_With_Error(float *pOutputValueArray, const float *pInputValueArray)
{
	uint32_t i, id;

	for (i = 0; i < NumInputNeurons; i++)
	{
		pNeuronArray[i].Set_Input(pInputValueArray[i]);
		pNeuronArray[i].Propagate_SynapticOutput();
	}

	if (AdditionalInputBiasNeuron == true)
		pNeuronArray[InputBiasNeuronID].Propagate_SynapticOutput();

	if (HiddenLayer1Used == true)
	{
		uint32_t numOfNeurons = HiddenLayer1.NumOfNeurons;

		for (i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer1.pNeuronIDArray[i];

			pNeuronArray[id].Calculate_NeuronOutput();
			pNeuronArray[id].Propagate_SynapticOutput();
		}

		if (HiddenLayer1.AdditionalBiasNeuron == true)
			pNeuronArray[HiddenLayer1.BiasNeuronID].Propagate_SynapticOutput();
	}

	if (HiddenLayer2Used == true)
	{
		uint32_t numOfNeurons = HiddenLayer2.NumOfNeurons;

		for (i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer2.pNeuronIDArray[i];

			pNeuronArray[id].Calculate_NeuronOutput();
			pNeuronArray[id].Propagate_SynapticOutput();
		}

		if (HiddenLayer2.AdditionalBiasNeuron == true)
			pNeuronArray[HiddenLayer2.BiasNeuronID].Propagate_SynapticOutput();
	}

	if (HiddenLayer3Used == true)
	{
		uint32_t numOfNeurons = HiddenLayer3.NumOfNeurons;

		for (i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer3.pNeuronIDArray[i];

			pNeuronArray[id].Calculate_NeuronOutput();
			pNeuronArray[id].Propagate_SynapticOutput();
		}

		if (HiddenLayer3.AdditionalBiasNeuron == true)
			pNeuronArray[HiddenLayer3.BiasNeuronID].Propagate_SynapticOutput();
	}

	for (i = 0; i < NumOutputNeurons; i++)
	{
		id = i + FirstOutputNeuronID;

		pNeuronArray[id].Calculate_NeuronOutput();

		pOutputValueArray[i] = pNeuronArray[id].Get_NeuronOutput();
		//pOutputValueArray[i] = pNeuronArray[id].NeuronOutput;
	}

	float error = 0.0f;

	for (i = 0; i < NumOutputNeurons; i++)
	{
		id = FirstOutputNeuronID + i;
		error += pNeuronArray[id].Calculate_Error(pInputValueArray[i]);
	}

	return error;
}

void CNeuralNet::Calculate_Error(float *pErrorValueArray, const float *pDesiredOutputValueArray)
{
	uint32_t id;

	for (uint32_t i = 0; i < NumOutputNeurons; i++)
	{
		id = i + FirstOutputNeuronID;

		pErrorValueArray[i] = pNeuronArray[id].Calculate_Error(pDesiredOutputValueArray[i]);
	}
}

float CNeuralNet::Calculate_Error(const float *pDesiredOutputValueArray)
{
	float error = 0.0f;

	uint32_t id;

	for (uint32_t i = 0; i < NumOutputNeurons; i++)
	{
		id = FirstOutputNeuronID + i;

		error += pNeuronArray[id].Calculate_Error(pDesiredOutputValueArray[i]);
	}

	return error;
}

float CNeuralNet::Learning_UseActivationSequence(const float *pDesiredOutputValueArray)
{
	uint32_t id;

	float error = 0.0f;


	for (uint32_t i = 0; i < NumOutputNeurons; i++)
	{
		id = FirstOutputNeuronID + i;

		error += pNeuronArray[id].Calculate_Error(pDesiredOutputValueArray[i]);
	}

	for (uint32_t i = NumOfActivationSequenceArrayEntries - 1; i >= 1; i--)
	{
		id = pActivationSequenceArray[i];

		if (pNeuronArray[id].UsedAsBiasNeuron == true)
			continue;
		if (pNeuronArray[id].UsedAsOutputNeuron == true)
			continue;
		if (pNeuronArray[id].UsedAsInputNeuron == true)
			continue;

		pNeuronArray[id].Calculate_Error();
	}

	for (uint32_t i = 0; i < NumOfActivationSequenceArrayEntries; i++)
	{
		id = pActivationSequenceArray[i];

		if (pNeuronArray[id].UsedAsOutputNeuron == false)
			pNeuronArray[id].Adjust_OutputSynapses_AfterErrorCalculations();
	}

	return error;
}

float CNeuralNet::Backpropagate_Error_UseActivationSequence(const float *pDesiredOutputValueArray)
{
	uint32_t id;

	float error = 0.0f;


	for (uint32_t i = 0; i < NumOutputNeurons; i++)
	{
		id = FirstOutputNeuronID + i;

		error += pNeuronArray[id].Calculate_Error(pDesiredOutputValueArray[i]);
	}

	for (uint32_t i = NumOfActivationSequenceArrayEntries - 1; i >= 1; i--)
	{
		id = pActivationSequenceArray[i];

		if (pNeuronArray[id].UsedAsBiasNeuron == true)
			continue;
		if (pNeuronArray[id].UsedAsOutputNeuron == true)
			continue;
		if (pNeuronArray[id].UsedAsInputNeuron == true)
			continue;

		pNeuronArray[id].Calculate_Error();
	}

	/*for (uint32_t i = 0; i < NumOfActivationSequenceArrayEntries; i++)
	{
	id = pActivationSequenceArray[i];

	if (pNeuronArray[id].UsedAsOutputNeuron == false)
	pNeuronArray[id].Adjust_OutputSynapses_AfterErrorCalculations();
	}*/

	return error;
}

void CNeuralNet::Adjust_Weights_After_Backpropagation_UseActivationSequence(void)
{
	uint32_t id;

	for (uint32_t i = 0; i < NumOfActivationSequenceArrayEntries; i++)
	{
		id = pActivationSequenceArray[i];

		if (pNeuronArray[id].UsedAsOutputNeuron == false)
			pNeuronArray[id].Adjust_OutputSynapses_AfterErrorCalculations();
	}
}

float CNeuralNet::Learning(const float *pDesiredOutputValueArray)
{
	uint32_t i;
	uint32_t id;

	float error = 0.0f;

	for (i = 0; i < NumOutputNeurons; i++)
	{
		id = FirstOutputNeuronID + i;

		error += pNeuronArray[id].Calculate_Error(pDesiredOutputValueArray[i]);
	}

	if (HiddenLayer3Used == true)
	{
		uint32_t numOfNeurons = HiddenLayer3.NumOfNeurons;

		for (i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer3.pNeuronIDArray[i];
			pNeuronArray[id].Calculate_Error();
		}
	}

	if (HiddenLayer2Used == true)
	{
		uint32_t numOfNeurons = HiddenLayer2.NumOfNeurons;

		for (i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer2.pNeuronIDArray[i];
			pNeuronArray[id].Calculate_Error();
		}
	}

	if (HiddenLayer1Used == true)
	{
		uint32_t numOfNeurons = HiddenLayer1.NumOfNeurons;

		for (i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer1.pNeuronIDArray[i];
			pNeuronArray[id].Calculate_Error();
		}
	}


	if (HiddenLayer1Used == true)
	{
		uint32_t numOfNeurons = HiddenLayer1.NumOfNeurons;

		for (i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer1.pNeuronIDArray[i];
			pNeuronArray[id].Adjust_OutputSynapses_AfterErrorCalculations();
		}

		if (HiddenLayer1.AdditionalBiasNeuron == true)
			pNeuronArray[HiddenLayer1.BiasNeuronID].Adjust_OutputSynapses_AfterErrorCalculations();
	}

	if (HiddenLayer2Used == true)
	{
		uint32_t numOfNeurons = HiddenLayer2.NumOfNeurons;

		for (i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer2.pNeuronIDArray[i];
			pNeuronArray[id].Adjust_OutputSynapses_AfterErrorCalculations();
		}

		if (HiddenLayer2.AdditionalBiasNeuron == true)
			pNeuronArray[HiddenLayer2.BiasNeuronID].Adjust_OutputSynapses_AfterErrorCalculations();
	}

	if (HiddenLayer3Used == true)
	{
		uint32_t numOfNeurons = HiddenLayer3.NumOfNeurons;

		for (i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer3.pNeuronIDArray[i];
			pNeuronArray[id].Adjust_OutputSynapses_AfterErrorCalculations();
		}

		if (HiddenLayer3.AdditionalBiasNeuron == true)
			pNeuronArray[HiddenLayer3.BiasNeuronID].Adjust_OutputSynapses_AfterErrorCalculations();
	}


	if (AdditionalInputBiasNeuron == true)
		pNeuronArray[InputBiasNeuronID].Adjust_OutputSynapses_AfterErrorCalculations();

	for (i = 0; i < NumInputNeurons; i++)
		pNeuronArray[i].Adjust_OutputSynapses_AfterErrorCalculations();


	return error;
}

float CNeuralNet::Backpropagate_Error(const float *pDesiredOutputValueArray)
{
	uint32_t i;
	uint32_t id;

	float error = 0.0f;

	for (i = 0; i < NumOutputNeurons; i++)
	{
		id = FirstOutputNeuronID + i;

		error += pNeuronArray[id].Calculate_Error(pDesiredOutputValueArray[i]);
	}

	if (HiddenLayer3Used == true)
	{
		uint32_t numOfNeurons = HiddenLayer3.NumOfNeurons;

		for (i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer3.pNeuronIDArray[i];
			pNeuronArray[id].Calculate_Error();
		}
	}

	if (HiddenLayer2Used == true)
	{
		uint32_t numOfNeurons = HiddenLayer2.NumOfNeurons;

		for (i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer2.pNeuronIDArray[i];
			pNeuronArray[id].Calculate_Error();
		}
	}

	if (HiddenLayer1Used == true)
	{
		uint32_t numOfNeurons = HiddenLayer1.NumOfNeurons;

		for (i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer1.pNeuronIDArray[i];
			pNeuronArray[id].Calculate_Error();
		}
	}


	/*
	if (HiddenLayer1Used == true)
	{
	uint32_t numOfNeurons = HiddenLayer1.NumOfNeurons;

	for (i = 0; i < numOfNeurons; i++)
	{
	id = HiddenLayer1.pNeuronIDArray[i];
	pNeuronArray[id].Adjust_OutputSynapses_AfterErrorCalculations();
	}

	if (HiddenLayer1.AdditionalBiasNeuron == true)
	pNeuronArray[HiddenLayer1.BiasNeuronID].Adjust_OutputSynapses_AfterErrorCalculations();
	}

	if (HiddenLayer2Used == true)
	{
	uint32_t numOfNeurons = HiddenLayer2.NumOfNeurons;

	for (i = 0; i < numOfNeurons; i++)
	{
	id = HiddenLayer2.pNeuronIDArray[i];
	pNeuronArray[id].Adjust_OutputSynapses_AfterErrorCalculations();
	}

	if (HiddenLayer2.AdditionalBiasNeuron == true)
	pNeuronArray[HiddenLayer2.BiasNeuronID].Adjust_OutputSynapses_AfterErrorCalculations();
	}

	if (HiddenLayer3Used == true)
	{
	uint32_t numOfNeurons = HiddenLayer3.NumOfNeurons;

	for (i = 0; i < numOfNeurons; i++)
	{
	id = HiddenLayer3.pNeuronIDArray[i];
	pNeuronArray[id].Adjust_OutputSynapses_AfterErrorCalculations();
	}

	if (HiddenLayer3.AdditionalBiasNeuron == true)
	pNeuronArray[HiddenLayer3.BiasNeuronID].Adjust_OutputSynapses_AfterErrorCalculations();
	}


	if (AdditionalInputBiasNeuron == true)
	pNeuronArray[InputBiasNeuronID].Adjust_OutputSynapses_AfterErrorCalculations();

	for (uint32_t i = 0; i < NumInputNeurons; i++)
	pNeuronArray[i].Adjust_OutputSynapses_AfterErrorCalculations();
	*/

	return error;
}

void CNeuralNet::Adjust_Weights_After_Backpropagation(void)
{
	uint32_t i;
	uint32_t id;

	if (HiddenLayer1Used == true)
	{
		uint32_t numOfNeurons = HiddenLayer1.NumOfNeurons;

		for (i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer1.pNeuronIDArray[i];
			pNeuronArray[id].Adjust_OutputSynapses_AfterErrorCalculations();
		}

		if (HiddenLayer1.AdditionalBiasNeuron == true)
			pNeuronArray[HiddenLayer1.BiasNeuronID].Adjust_OutputSynapses_AfterErrorCalculations();
	}

	if (HiddenLayer2Used == true)
	{
		uint32_t numOfNeurons = HiddenLayer2.NumOfNeurons;

		for (i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer2.pNeuronIDArray[i];
			pNeuronArray[id].Adjust_OutputSynapses_AfterErrorCalculations();
		}

		if (HiddenLayer2.AdditionalBiasNeuron == true)
			pNeuronArray[HiddenLayer2.BiasNeuronID].Adjust_OutputSynapses_AfterErrorCalculations();
	}

	if (HiddenLayer3Used == true)
	{
		uint32_t numOfNeurons = HiddenLayer3.NumOfNeurons;

		for (i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer3.pNeuronIDArray[i];
			pNeuronArray[id].Adjust_OutputSynapses_AfterErrorCalculations();
		}

		if (HiddenLayer3.AdditionalBiasNeuron == true)
			pNeuronArray[HiddenLayer3.BiasNeuronID].Adjust_OutputSynapses_AfterErrorCalculations();
	}


	if (AdditionalInputBiasNeuron == true)
		pNeuronArray[InputBiasNeuronID].Adjust_OutputSynapses_AfterErrorCalculations();

	for (i = 0; i < NumInputNeurons; i++)
		pNeuronArray[i].Adjust_OutputSynapses_AfterErrorCalculations();
}

float CNeuralNet::Learning(float desiredOutputValue, uint32_t idOfOutputNeuron)
{
	uint32_t id = idOfOutputNeuron + FirstOutputNeuronID;
	float error = pNeuronArray[id].Calculate_Error(desiredOutputValue);



	uint32_t i;


	if (HiddenLayer3Used == true)
	{
		uint32_t numOfNeurons = HiddenLayer3.NumOfNeurons;

		for (i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer3.pNeuronIDArray[i];
			pNeuronArray[id].Calculate_Error();
		}
	}

	if (HiddenLayer2Used == true)
	{
		uint32_t numOfNeurons = HiddenLayer2.NumOfNeurons;

		for (i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer2.pNeuronIDArray[i];
			pNeuronArray[id].Calculate_Error();
		}
	}

	if (HiddenLayer1Used == true)
	{
		uint32_t numOfNeurons = HiddenLayer1.NumOfNeurons;

		for (i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer1.pNeuronIDArray[i];
			pNeuronArray[id].Calculate_Error();
		}
	}


	if (HiddenLayer1Used == true)
	{
		uint32_t numOfNeurons = HiddenLayer1.NumOfNeurons;

		for (i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer1.pNeuronIDArray[i];
			pNeuronArray[id].Adjust_OutputSynapses_AfterErrorCalculations();
		}

		if (HiddenLayer1.AdditionalBiasNeuron == true)
			pNeuronArray[HiddenLayer1.BiasNeuronID].Adjust_OutputSynapses_AfterErrorCalculations();
	}

	if (HiddenLayer2Used == true)
	{
		uint32_t numOfNeurons = HiddenLayer2.NumOfNeurons;

		for (i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer2.pNeuronIDArray[i];
			pNeuronArray[id].Adjust_OutputSynapses_AfterErrorCalculations();
		}

		if (HiddenLayer2.AdditionalBiasNeuron == true)
			pNeuronArray[HiddenLayer2.BiasNeuronID].Adjust_OutputSynapses_AfterErrorCalculations();
	}

	if (HiddenLayer3Used == true)
	{
		uint32_t numOfNeurons = HiddenLayer3.NumOfNeurons;

		for (i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer3.pNeuronIDArray[i];
			pNeuronArray[id].Adjust_OutputSynapses_AfterErrorCalculations();
		}

		if (HiddenLayer3.AdditionalBiasNeuron == true)
			pNeuronArray[HiddenLayer3.BiasNeuronID].Adjust_OutputSynapses_AfterErrorCalculations();
	}


	if (AdditionalInputBiasNeuron == true)
		pNeuronArray[InputBiasNeuronID].Adjust_OutputSynapses_AfterErrorCalculations();

	for (i = 0; i < NumInputNeurons; i++)
		pNeuronArray[i].Adjust_OutputSynapses_AfterErrorCalculations();


	return error;
}

float CNeuralNet::Backpropagate_Error(float desiredOutputValue, uint32_t idOfOutputNeuron)
{
	uint32_t id = idOfOutputNeuron + FirstOutputNeuronID;
	float error = pNeuronArray[id].Calculate_Error(desiredOutputValue);

	uint32_t i;


	if (HiddenLayer3Used == true)
	{
		uint32_t numOfNeurons = HiddenLayer3.NumOfNeurons;

		for (i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer3.pNeuronIDArray[i];
			pNeuronArray[id].Calculate_Error();
		}
	}

	if (HiddenLayer2Used == true)
	{
		uint32_t numOfNeurons = HiddenLayer2.NumOfNeurons;

		for (i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer2.pNeuronIDArray[i];
			pNeuronArray[id].Calculate_Error();
		}
	}

	if (HiddenLayer1Used == true)
	{
		uint32_t numOfNeurons = HiddenLayer1.NumOfNeurons;

		for (i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer1.pNeuronIDArray[i];
			pNeuronArray[id].Calculate_Error();
		}
	}


	/*
	if (HiddenLayer1Used == true)
	{
	uint32_t numOfNeurons = HiddenLayer1.NumOfNeurons;

	for (i = 0; i < numOfNeurons; i++)
	{
	id = HiddenLayer1.pNeuronIDArray[i];
	pNeuronArray[id].Adjust_OutputSynapses_AfterErrorCalculations();
	}

	if (HiddenLayer1.AdditionalBiasNeuron == true)
	pNeuronArray[HiddenLayer1.BiasNeuronID].Adjust_OutputSynapses_AfterErrorCalculations();
	}

	if (HiddenLayer2Used == true)
	{
	uint32_t numOfNeurons = HiddenLayer2.NumOfNeurons;

	for (i = 0; i < numOfNeurons; i++)
	{
	id = HiddenLayer2.pNeuronIDArray[i];
	pNeuronArray[id].Adjust_OutputSynapses_AfterErrorCalculations();
	}

	if (HiddenLayer2.AdditionalBiasNeuron == true)
	pNeuronArray[HiddenLayer2.BiasNeuronID].Adjust_OutputSynapses_AfterErrorCalculations();
	}

	if (HiddenLayer3Used == true)
	{
	uint32_t numOfNeurons = HiddenLayer3.NumOfNeurons;

	for (i = 0; i < numOfNeurons; i++)
	{
	id = HiddenLayer3.pNeuronIDArray[i];
	pNeuronArray[id].Adjust_OutputSynapses_AfterErrorCalculations();
	}

	if (HiddenLayer3.AdditionalBiasNeuron == true)
	pNeuronArray[HiddenLayer3.BiasNeuronID].Adjust_OutputSynapses_AfterErrorCalculations();
	}


	if (AdditionalInputBiasNeuron == true)
	pNeuronArray[InputBiasNeuronID].Adjust_OutputSynapses_AfterErrorCalculations();

	for (i = 0; i < NumInputNeurons; i++)
	pNeuronArray[i].Adjust_OutputSynapses_AfterErrorCalculations();
	*/

	return error;
}


// Nur die Plastizit�tswerte der mit den Output-Neuronen verbundenen Synapsen werden modifiziert:
float CNeuralNet::ExtremeLearning(const float *pDesiredOutputValueArray)
{
	float error = 0.0f;

	uint32_t i;
	uint32_t id;


	for (i = 0; i < NumOutputNeurons; i++)
	{
		id = FirstOutputNeuronID + i;

		error += pNeuronArray[id].Calculate_Error(pDesiredOutputValueArray[i]);
	}

	if (HiddenLayer3Used == true)
	{
		uint32_t numOfNeurons = HiddenLayer3.NumOfNeurons;

		for (i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer3.pNeuronIDArray[i];
			pNeuronArray[id].Adjust_OutputSynapses_AfterErrorCalculations();
		}

		if (HiddenLayer3.AdditionalBiasNeuron == true)
			pNeuronArray[HiddenLayer3.BiasNeuronID].Adjust_OutputSynapses_AfterErrorCalculations();
	}

	else if (HiddenLayer2Used == true && HiddenLayer3Used == false)
	{
		uint32_t numOfNeurons = HiddenLayer2.NumOfNeurons;

		for (i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer2.pNeuronIDArray[i];
			pNeuronArray[id].Adjust_OutputSynapses_AfterErrorCalculations();
		}

		if (HiddenLayer2.AdditionalBiasNeuron == true)
			pNeuronArray[HiddenLayer2.BiasNeuronID].Adjust_OutputSynapses_AfterErrorCalculations();
	}

	else if (HiddenLayer1Used == true && HiddenLayer2Used == false && HiddenLayer3Used == false)
	{
		uint32_t numOfNeurons = HiddenLayer1.NumOfNeurons;

		for (i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer1.pNeuronIDArray[i];
			pNeuronArray[id].Adjust_OutputSynapses_AfterErrorCalculations();
		}

		if (HiddenLayer1.AdditionalBiasNeuron == true)
			pNeuronArray[HiddenLayer1.BiasNeuronID].Adjust_OutputSynapses_AfterErrorCalculations();
	}

	return error;
}

// Nur die Plastizit�tswerte der mit den Output-Neuronen verbundenen Synapsen werden modifiziert:
float CNeuralNet::ExtremeLearning(float desiredOutputValue, uint32_t idOfOutputNeuron)
{

	uint32_t id = idOfOutputNeuron + FirstOutputNeuronID;
	float error = pNeuronArray[id].Calculate_Error(desiredOutputValue);

	uint32_t i;


	if (HiddenLayer3Used == true)
	{
		uint32_t numOfNeurons = HiddenLayer3.NumOfNeurons;

		for (i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer3.pNeuronIDArray[i];
			pNeuronArray[id].Adjust_OutputSynapse_AfterErrorCalculations(idOfOutputNeuron);
		}

		if (HiddenLayer3.AdditionalBiasNeuron == true)
			pNeuronArray[HiddenLayer3.BiasNeuronID].Adjust_OutputSynapse_AfterErrorCalculations(idOfOutputNeuron);
	}

	else if (HiddenLayer2Used == true && HiddenLayer3Used == false)
	{
		uint32_t numOfNeurons = HiddenLayer2.NumOfNeurons;

		for (i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer2.pNeuronIDArray[i];
			pNeuronArray[id].Adjust_OutputSynapse_AfterErrorCalculations(idOfOutputNeuron);
		}

		if (HiddenLayer2.AdditionalBiasNeuron == true)
			pNeuronArray[HiddenLayer2.BiasNeuronID].Adjust_OutputSynapse_AfterErrorCalculations(idOfOutputNeuron);
	}

	else if (HiddenLayer1Used == true && HiddenLayer2Used == false && HiddenLayer3Used == false)
	{
		uint32_t numOfNeurons = HiddenLayer1.NumOfNeurons;

		for (i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer1.pNeuronIDArray[i];
			pNeuronArray[id].Adjust_OutputSynapse_AfterErrorCalculations(idOfOutputNeuron);
		}

		if (HiddenLayer1.AdditionalBiasNeuron == true)
			pNeuronArray[HiddenLayer1.BiasNeuronID].Adjust_OutputSynapse_AfterErrorCalculations(idOfOutputNeuron);
	}

	return error;
}

void CNeuralNet::Reset_Memory_Of_ReservoirNeurons(void)
{
	uint32_t id;

	for (uint32_t i = 0; i < NumReservoirNeurons; i++)
	{
		id = FirstReservoirNeuronID + i;
		pNeuronArray[id].Reset_NeuronInput();
		pNeuronArray[id].Reset_NeuronOutput();
	}
}

void CNeuralNet::Calculate_Output_ReservoirComputing(float *pOutputValueArray, const float *pInputValueArray, uint32_t numAdditionalRecurrentCycles)
{
	uint32_t i, j, id;

	for (i = 0; i < NumInputNeurons; i++)
	{
		pNeuronArray[i].Set_Input(pInputValueArray[i]);
		pNeuronArray[i].Propagate_SynapticOutput();
	}

	if (AdditionalInputBiasNeuron == true)
		pNeuronArray[InputBiasNeuronID].Propagate_SynapticOutput();

	for (uint32_t k = 0; k < numAdditionalRecurrentCycles; k++)
	{
		for (i = 0; i < NumReservoirNeurons; i++)
		{
			id = FirstReservoirNeuronID + i;
			pNeuronArray[id].Calculate_NeuronOutput_And_Retain_Input();

			for (j = 0; j < pNumInternalReservoirConnectionsArray[i]; j++)
				pNeuronArray[id].Propagate_SynapticOutput(j);
		}
	}

	for (i = 0; i < NumReservoirNeurons; i++)
	{
		id = FirstReservoirNeuronID + i;
		pNeuronArray[id].Calculate_NeuronOutput_And_Retain_Input();
		pNeuronArray[id].Propagate_SynapticOutput();
	}

	for (i = 0; i < NumOutputNeurons; i++)
	{
		id = i + FirstOutputNeuronID;

		pNeuronArray[id].Calculate_NeuronOutput();

		pOutputValueArray[i] = pNeuronArray[id].Get_NeuronOutput();
		//pOutputValueArray[i] = pNeuronArray[id].NeuronOutput;
	}
}

void CNeuralNet::Update_InputNeurons_Prior_ReservorUpdate(const float *pInputValueArray)
{
	for (uint32_t i = 0; i < NumInputNeurons; i++)
	{
		pNeuronArray[i].Set_Input(pInputValueArray[i]);
		pNeuronArray[i].Propagate_SynapticOutput();
	}

	if (AdditionalInputBiasNeuron == true)
		pNeuronArray[InputBiasNeuronID].Propagate_SynapticOutput();
}

void CNeuralNet::Update_ReservoirNeurons(void)
{
	uint32_t j, id;

	for (uint32_t i = 0; i < NumReservoirNeurons; i++)
	{
		id = FirstReservoirNeuronID + i;
		pNeuronArray[id].Calculate_NeuronOutput_And_Retain_Input();

		for (j = 0; j < pNumInternalReservoirConnectionsArray[i]; j++)
			pNeuronArray[id].Propagate_SynapticOutput(j);
	}
}

void CNeuralNet::Update_OutputNeurons_After_ReservorUpdate(float *pOutputValueArray)
{
	uint32_t i, id;

	for (i = 0; i < NumReservoirNeurons; i++)
	{
		id = FirstReservoirNeuronID + i;
		pNeuronArray[id].Calculate_NeuronOutput_And_Retain_Input();
		pNeuronArray[id].Propagate_SynapticOutput();
	}

	for (i = 0; i < NumOutputNeurons; i++)
	{
		id = i + FirstOutputNeuronID;

		pNeuronArray[id].Calculate_NeuronOutput();

		pOutputValueArray[i] = pNeuronArray[id].Get_NeuronOutput();
		//pOutputValueArray[i] = pNeuronArray[id].NeuronOutput;
	}
}

float CNeuralNet::Learning_ReservoirComputing(const float *pDesiredOutputValueArray)
{
	uint32_t i, j, id;

	float error = 0.0f;

	for (i = 0; i < NumOutputNeurons; i++)
	{
		id = FirstOutputNeuronID + i;

		error += pNeuronArray[id].Calculate_Error(pDesiredOutputValueArray[i]);
	}


	for (i = 0; i < NumReservoirNeurons; i++)
	{
		id = FirstReservoirNeuronID + i;

		//pNeuronArray[id].Adjust_OutputSynapses_AfterErrorCalculations();

		if (pNeuronArray[id].NumOfOutputSynapses > pNumInternalReservoirConnectionsArray[i])
		{
			for (j = 0; j < NumOutputNeurons; j++)
			{
				pNeuronArray[id].Adjust_OutputSynapse_AfterErrorCalculations(pNumInternalReservoirConnectionsArray[i] + j);
			}
		}
	}

	return error;
}





C2DPatternDetector::C2DPatternDetector()
{}

C2DPatternDetector::~C2DPatternDetector()
{
	delete[] pValueArray;
	pValueArray = nullptr;
}

void C2DPatternDetector::Initialize(uint32_t sizeXDir, uint32_t sizeYDir)
{
	delete[] pValueArray;
	pValueArray = nullptr;

	SizeXDir = sizeXDir;
	SizeYDir = sizeYDir;
	Size = sizeXDir * sizeYDir;

	pValueArray = new (std::nothrow) float[Size];


	for (uint32_t i = 0; i < Size; i++)
	{
		pValueArray[i] = 0.0f;
	}
}

bool C2DPatternDetector::Load_Data(const char* pFilename)
{
	std::ifstream ReadFile;

	// eine existierende Datei zum Lesen �ffnen:
	ReadFile.open(pFilename);

	if (ReadFile.good() == false)
		return false;

	uint32_t sizeXDir, sizeYDir;

	ReadFile >> sizeXDir;
	ReadFile >> sizeYDir;

	Initialize(sizeXDir, sizeYDir);

	for (uint32_t i = 0; i < Size; i++)
		ReadFile >> pValueArray[i];


	ReadFile.close();

	return true;
}

bool C2DPatternDetector::Save_Data(const char* pFilename)
{
	std::ofstream WriteFile;

	// neue Datei erzeugen bzw. alte �berschreiben:
	WriteFile.open(pFilename);

	// neue Datei erzeugen bzw. Inhalt ans Ende einer bestehenden Datei schreiben:
	//WriteFile.open(pFilename, ios::app);

	if (WriteFile.good() == false)
		return false;

	WriteFile << SizeXDir << "  ";
	WriteFile << SizeYDir << "  ";

	for (uint32_t i = 0; i < Size; i++)
		WriteFile << pValueArray[i] << "  ";

	WriteFile.close();

	return true;
}

bool C2DPatternDetector::Load_Binary_Data_From_Bitmap(const char* pDescFilename /*not the bitmap*/, bool binaryImageData, bool use_0_And_1_Values)
{
	std::ifstream ReadFile;

	// eine existierende Datei zum Lesen �ffnen:
	ReadFile.open(pDescFilename);

	if (ReadFile.good() == false)
		return false;

	uint32_t sizeXDir, sizeYDir;

	ReadFile >> sizeXDir;
	ReadFile >> sizeYDir;

	Initialize(sizeXDir, sizeYDir);

	char bitmapFileName[256];

	ReadFile >> bitmapFileName;

	uint8_t *pImageData = nullptr;

	pImageData = Read_Bitmap_BGR(bitmapFileName);

	Get_BinaryImageData_BlueChannel(pValueArray, pImageData, sizeXDir, sizeYDir, use_0_And_1_Values);

	//Output_BinaryImageData(pValueArray, sizeXDir, sizeYDir);
	//getchar();

	delete[] pImageData;
	pImageData = nullptr;

	ReadFile.close();

	return true;
}

bool C2DPatternDetector::Load_Data_From_Bitmap(const char* pDescFilename /*not the bitmap*/, float dataBiasValue)
{
	std::ifstream ReadFile;

	// eine existierende Datei zum Lesen �ffnen:
	ReadFile.open(pDescFilename);

	if (ReadFile.good() == false)
		return false;

	uint32_t sizeXDir, sizeYDir;

	ReadFile >> sizeXDir;
	ReadFile >> sizeYDir;

	Initialize(sizeXDir, sizeYDir);

	char bitmapFileName[256];

	ReadFile >> bitmapFileName;

	uint8_t *pImageData = nullptr;

	pImageData = Read_Bitmap_BGR(bitmapFileName);


	Get_ImageData_BlueChannel(pValueArray, pImageData, sizeXDir, sizeYDir, dataBiasValue);

	//Output_BinaryImageData(pValueArray, sizeXDir, sizeYDir);
	//getchar();

	delete[] pImageData;
	pImageData = nullptr;

	ReadFile.close();

	return true;
}

bool C2DPatternDetector::Search_Pattern(int32_t *pOutPatternCount, int32_t *pOutPatternPosXArray, int32_t *pOutPatternPosYArray, int32_t maxPosArrayElements, const float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, float minActivationValue)
{
	*pOutPatternCount = 0;


	if (SizeXDir == inputMapSizeX && SizeYDir == inputMapSizeY)
	{
		float inputValue, kernelValue, productValue, outputValue;

		float sumOfProductValues = 0.0f;

		for (uint32_t i = 0; i < Size; i++)
		{
			inputValue = pInputMap[i];
			kernelValue = pValueArray[i];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		if (sumOfProductValues < minActivationValue)
			return false;
		else
		{
			pOutPatternPosXArray[0] = SizeXDir / 2;
			pOutPatternPosYArray[0] = SizeYDir / 2;
			*pOutPatternCount = 1;
			return true;
		}
	}

	int32_t posArrayCounter = 0;

	int32_t halfKernelSizeX = SizeXDir / 2;
	int32_t halfKernelSizeY = SizeYDir / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputMapSizeX - halfKernelSizeX;
	int32_t iyInputMax = inputMapSizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;
	int32_t kernelID;


	float inputValue, kernelValue, productValue, sumOfProductValues, outputValue;

	bool returnValue = false;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = 0.0f;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputMapSizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * SizeXDir;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputMap[ixInput + ixKernel + iiyInput];

					kernelID = ixKernel + halfKernelSizeX + iiyKernel;

					kernelValue = pValueArray[kernelID];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			if (sumOfProductValues >= minActivationValue)
			{
				returnValue = true;

				pOutPatternPosXArray[posArrayCounter] = ixInput;
				pOutPatternPosYArray[posArrayCounter] = iyInput;

				posArrayCounter++;

				if (posArrayCounter >= maxPosArrayElements)
					return returnValue;
			}
		}
	}


	return returnValue;
}

bool C2DPatternDetector::Search_Pattern(int32_t *pOutPatternCount, int32_t *pOutPatternPosXArray, int32_t *pOutPatternPosYArray, int32_t maxPosArrayElements, const float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, float activationValue, float minTolerance, float maxTolerance)
{
	*pOutPatternCount = 0;

	float minActivationValue = activationValue + minTolerance;
	float maxActivationValue = activationValue + maxTolerance;

	if (SizeXDir == inputMapSizeX && SizeYDir == inputMapSizeY)
	{
		float inputValue, kernelValue, productValue, outputValue;

		float sumOfProductValues = 0.0f;

		for (uint32_t i = 0; i < Size; i++)
		{
			inputValue = pInputMap[i];
			kernelValue = pValueArray[i];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		if (sumOfProductValues < minActivationValue && sumOfProductValues > maxActivationValue)
			return false;
		else
		{
			pOutPatternPosXArray[0] = SizeXDir / 2;
			pOutPatternPosYArray[0] = SizeYDir / 2;
			*pOutPatternCount = 1;
			return true;
		}
	}

	int32_t posArrayCounter = 0;

	int32_t halfKernelSizeX = SizeXDir / 2;
	int32_t halfKernelSizeY = SizeYDir / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputMapSizeX - halfKernelSizeX;
	int32_t iyInputMax = inputMapSizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;
	int32_t kernelID;


	float inputValue, kernelValue, productValue, sumOfProductValues, outputValue;

	bool returnValue = false;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = 0.0f;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputMapSizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * SizeXDir;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputMap[ixInput + ixKernel + iiyInput];

					kernelID = ixKernel + halfKernelSizeX + iiyKernel;

					kernelValue = pValueArray[kernelID];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			if (sumOfProductValues >= minActivationValue && sumOfProductValues <= maxActivationValue)
			{
				returnValue = true;

				pOutPatternPosXArray[posArrayCounter] = ixInput;
				pOutPatternPosYArray[posArrayCounter] = iyInput;

				posArrayCounter++;

				if (posArrayCounter >= maxPosArrayElements)
					return returnValue;
			}
		}
	}


	return returnValue;
}




C2DLocalReceptiveField::C2DLocalReceptiveField()
{}

C2DLocalReceptiveField::~C2DLocalReceptiveField()
{
	delete[] pValueArray;
	pValueArray = nullptr;

	delete[] pInputErrorValueArray;
	pInputErrorValueArray = nullptr;

	delete[] pSumOfInputValuesArray;
	pSumOfInputValuesArray = nullptr;
}

void C2DLocalReceptiveField::Initialize(uint32_t sizeXDir, uint32_t sizeYDir)
{
	FittingValue = -1000000.0f;

	SumOfOutputValues = 0.0f;

	OutputErrorValue = 0.0f;

	Bias = 0.0f;

	delete[] pValueArray;
	pValueArray = nullptr;

	delete[] pInputErrorValueArray;
	pInputErrorValueArray = nullptr;

	delete[] pSumOfInputValuesArray;
	pSumOfInputValuesArray = nullptr;

	SizeXDir = sizeXDir;
	SizeYDir = sizeYDir;
	Size = sizeXDir * sizeYDir;

	pValueArray = new (std::nothrow) float[Size];
	pInputErrorValueArray = new (std::nothrow) float[Size];
	pSumOfInputValuesArray = new (std::nothrow) float[Size];

	for (uint32_t i = 0; i < Size; i++)
	{
		pValueArray[i] = 0.0f;
		pInputErrorValueArray[i] = 0.0f;
		pSumOfInputValuesArray[i] = 0.0f;
	}
}

bool C2DLocalReceptiveField::Load_Data(const char* pFilename)
{
	std::ifstream ReadFile;

	// eine existierende Datei zum Lesen �ffnen:
	ReadFile.open(pFilename);

	if (ReadFile.good() == false)
		return false;

	uint32_t sizeXDir, sizeYDir;

	ReadFile >> sizeXDir;
	ReadFile >> sizeYDir;

	Initialize(sizeXDir, sizeYDir);

	for (uint32_t i = 0; i < Size; i++)
		ReadFile >> pValueArray[i];


	ReadFile.close();

	return true;
}

bool C2DLocalReceptiveField::Load_Binary_Data_From_Bitmap(const char* pDescFilename /*not the bitmap*/, bool binaryImageData, bool use_0_And_1_Values)
{
	std::ifstream ReadFile;

	// eine existierende Datei zum Lesen �ffnen:
	ReadFile.open(pDescFilename);

	if (ReadFile.good() == false)
		return false;

	uint32_t sizeXDir, sizeYDir;

	ReadFile >> sizeXDir;
	ReadFile >> sizeYDir;

	Initialize(sizeXDir, sizeYDir);

	char bitmapFileName[256];

	ReadFile >> bitmapFileName;

	uint8_t *pImageData = nullptr;

	pImageData = Read_Bitmap_BGR(bitmapFileName);

	Get_BinaryImageData_BlueChannel(pValueArray, pImageData, sizeXDir, sizeYDir, use_0_And_1_Values);

	//Output_BinaryImageData(pValueArray, sizeXDir, sizeYDir);
	//getchar();

	delete[] pImageData;
	pImageData = nullptr;

	ReadFile.close();

	return true;
}

bool C2DLocalReceptiveField::Load_Data_From_Bitmap(const char* pDescFilename /*not the bitmap*/, float dataBiasValue)
{
	std::ifstream ReadFile;

	// eine existierende Datei zum Lesen �ffnen:
	ReadFile.open(pDescFilename);

	if (ReadFile.good() == false)
		return false;

	uint32_t sizeXDir, sizeYDir;

	ReadFile >> sizeXDir;
	ReadFile >> sizeYDir;

	Initialize(sizeXDir, sizeYDir);

	char bitmapFileName[256];

	ReadFile >> bitmapFileName;

	uint8_t *pImageData = nullptr;

	pImageData = Read_Bitmap_BGR(bitmapFileName);


	Get_ImageData_BlueChannel(pValueArray, pImageData, sizeXDir, sizeYDir, dataBiasValue);

	//Output_BinaryImageData(pValueArray, sizeXDir, sizeYDir);
	//getchar();

	delete[] pImageData;
	pImageData = nullptr;

	ReadFile.close();

	return true;
}

bool C2DLocalReceptiveField::Save_Data(const char* pFilename)
{
	std::ofstream WriteFile;

	// neue Datei erzeugen bzw. alte �berschreiben:
	WriteFile.open(pFilename);

	// neue Datei erzeugen bzw. Inhalt ans Ende einer bestehenden Datei schreiben:
	//WriteFile.open(pFilename, ios::app);

	if (WriteFile.good() == false)
		return false;

	WriteFile << SizeXDir << "  ";
	WriteFile << SizeYDir << "  ";

	for (uint32_t i = 0; i < Size; i++)
		WriteFile << pValueArray[i] << "  ";

	WriteFile.close();

	return true;
}

void C2DLocalReceptiveField::Reset_ErrorValues(void)
{
	OutputErrorValue = 0.0f;

	for (uint32_t i = 0; i < Size; i++)
		pInputErrorValueArray[i] = 0.0f;
}

void C2DLocalReceptiveField::Reset_SumOfOutputAndInputValues(void)
{
	SumOfOutputValues = 0.0f;

	for (uint32_t i = 0; i < Size; i++)
		pSumOfInputValuesArray[i] = 0.0f;
}


void C2DLocalReceptiveField::Set_Value(float value, uint32_t index)
{
	pValueArray[index] = value;
}

void C2DLocalReceptiveField::Clear_Values(float value)
{
	for (uint32_t i = 0; i < Size; i++)
		pValueArray[i] = value;
}

void C2DLocalReceptiveField::Set_Bias(float value)
{
	Bias = value;
}

// Achtung: Werte von 0 lassen sich mittels Backpropagation-Training nicht ver�ndern! 
void C2DLocalReceptiveField::Generate_RandomValues(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float minBiasValue, float maxBiasValue, bool includingZeroValues)
{
	if (includingZeroValues == true)
	{
		for (uint32_t i = 0; i < Size; i++)
			pValueArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minValue, maxValue);

		Bias = pRandomNumbers->Get_FloatNumber_IncludingZero(minBiasValue, maxBiasValue);
	}
	else
	{
		for (uint32_t i = 0; i < Size; i++)
			pValueArray[i] = pRandomNumbers->Get_FloatNumber(minValue, maxValue);

		Bias = pRandomNumbers->Get_FloatNumber(minBiasValue, maxBiasValue);
	}
}

// Achtung: Werte von 0 lassen sich mittels Backpropagation-Training nicht ver�ndern! 
void C2DLocalReceptiveField::Generate_RandomValues(CRandomNumbersNN *pRandomNumbers, int32_t minValue, int32_t maxValue, float minBiasValue, float maxBiasValue, bool includingZeroValues)
{
	if (includingZeroValues == true)
	{
		for (uint32_t i = 0; i < Size; i++)
			pValueArray[i] = pRandomNumbers->Get_IntegerNumber2(minValue, maxValue);

		Bias = pRandomNumbers->Get_FloatNumber_IncludingZero(minBiasValue, maxBiasValue);
	}
	else
	{

		for (uint32_t i = 0; i < Size; i++)
		{
			pValueArray[i] = pRandomNumbers->Get_IntegerNumber2(minValue, maxValue);

			if (pValueArray[i] == 0.0f)
			{
				pValueArray[i] = 1.0f;

				if (pRandomNumbers->Get_IntegerNumber2(1, 2) == 1)
					pValueArray[i] = -1.0f;
			}
		}

		Bias = pRandomNumbers->Get_FloatNumber(minBiasValue, maxBiasValue);
	}
}

void C2DLocalReceptiveField::Mutate_Values1(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float mutationRate)
{
	for (uint32_t i = 0; i < Size; i++)
	{
		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
			continue;

		pValueArray[i] = pRandomNumbers->Get_FloatNumber(minValue, maxValue);
	}
}

void C2DLocalReceptiveField::Mutate_Values2(CRandomNumbersNN *pRandomNumbers, float minVariance, float maxVariance, float mutationRate)
{
	for (uint32_t i = 0; i < Size; i++)
	{
		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
			continue;

		pValueArray[i] += pRandomNumbers->Get_FloatNumber(minVariance, maxVariance);
	}
}

void C2DLocalReceptiveField::Clone_Values(C2DLocalReceptiveField *pOriginalLRF)
{
	SumOfActivationValues = pOriginalLRF->SumOfActivationValues;
	MaxActivationValue = pOriginalLRF->MaxActivationValue;
	MinActivationValue = pOriginalLRF->MinActivationValue;
	FittingValue = pOriginalLRF->FittingValue;

	for (uint32_t i = 0; i < Size; i++)
		pValueArray[i] = pOriginalLRF->pValueArray[i];

	Bias = pOriginalLRF->Bias;
}

void C2DLocalReceptiveField::Clone_Values(C2DLocalReceptiveField *pOriginalLRF, CRandomNumbersNN *pRandomNumbers, float filterVariance, float biasVariance, float mutationRate)
{
	SumOfActivationValues = pOriginalLRF->SumOfActivationValues;
	MaxActivationValue = pOriginalLRF->MaxActivationValue;
	MinActivationValue = pOriginalLRF->MinActivationValue;
	FittingValue = pOriginalLRF->FittingValue;

	for (uint32_t i = 0; i < Size; i++)
	{
		pValueArray[i] = pOriginalLRF->pValueArray[i];

		pValueArray[i] += pRandomNumbers->Get_FloatNumber(filterVariance, filterVariance);
	}


	Bias = pOriginalLRF->Bias;
	Bias += biasVariance;
}

void C2DLocalReceptiveField::Combine_Values(C2DLocalReceptiveField *pParentLRF1, C2DLocalReceptiveField *pParentLRF2, CRandomNumbersNN *pRandomNumbers, float minWeight1)
{
	float weight1, weight2;
	float newValue;

	for (uint32_t i = 0; i < Size; i++)
	{
		weight1 = pRandomNumbers->Get_FloatNumber(minWeight1, 1.0f);
		weight2 = 1.0f - weight1;

		newValue = weight1*pParentLRF1->pValueArray[i];
		newValue += weight2*pParentLRF2->pValueArray[i];

		pValueArray[i] = newValue;
	}

	weight1 = pRandomNumbers->Get_FloatNumber(minWeight1, 1.0f);
	weight2 = 1.0f - weight1;

	newValue = weight1*pParentLRF1->Bias;
	newValue += weight2*pParentLRF2->Bias;

	Bias = newValue;
}

void C2DLocalReceptiveField::Reset_ActivationData(void)
{
	SumOfActivationValues = 0.0f;

	MaxActivationValue = -100000000.0f;
	MinActivationValue = 100000000.0f;
}


void C2DLocalReceptiveField::Update_ActivationData(float value)
{
	SumOfActivationValues += value;

	if (value > MaxActivationValue)
		MaxActivationValue = value;

	if (value < MinActivationValue)
		MinActivationValue = value;
}

void C2DLocalReceptiveField::Calculate_FittingValue(float fittingParam1, float fittingParam2)
{
	FittingValue = fittingParam1 * MaxActivationValue + fittingParam2 * SumOfActivationValues;
}

void C2DLocalReceptiveField::Calculate_FeatureMap(float *pFeatureMap, const float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, pActivationFunc pFunc)
{
	float weight = 1.0f / static_cast<float>(inputMapSizeX * inputMapSizeY);

	if (SizeXDir == inputMapSizeX && SizeYDir == inputMapSizeY)
	{
		float inputValue, kernelValue, productValue, outputValue;

		float sumOfProductValues = Bias;

		for (uint32_t i = 0; i < Size; i++)
		{
			inputValue = pInputMap[i];
			kernelValue = pValueArray[i];

			pSumOfInputValuesArray[i] += (weight*inputValue);

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		//sumOfProductValues /= static_cast<float>(Size);

		outputValue = pFunc(sumOfProductValues);

		SumOfOutputValues = (weight*outputValue);

		pFeatureMap[0] = outputValue;

		return;
	}

	int32_t halfKernelSizeX = SizeXDir / 2;
	int32_t halfKernelSizeY = SizeYDir / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputMapSizeX - halfKernelSizeX;
	int32_t iyInputMax = inputMapSizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;
	int32_t kernelID;


	float inputValue, kernelValue, productValue, sumOfProductValues, outputValue;



	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = Bias;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputMapSizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * SizeXDir;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputMap[ixInput + ixKernel + iiyInput];

					kernelID = ixKernel + halfKernelSizeX + iiyKernel;

					pSumOfInputValuesArray[kernelID] += (weight*inputValue);

					kernelValue = pValueArray[kernelID];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			//sumOfProductValues /= static_cast<float>(Size);

			outputValue = pFunc(sumOfProductValues);

			SumOfOutputValues += (weight*outputValue);

			pFeatureMap[counter] = outputValue;
			counter++;

		}
	}
}

void C2DLocalReceptiveField::Add_Feature_To_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, const float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY,
	int32_t strideX, int32_t strideY, pActivationFunc pFunc)
{
	int32_t halfKernelSizeX = SizeXDir / 2;
	int32_t halfKernelSizeY = SizeYDir / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputMapSizeX - halfKernelSizeX;
	int32_t iyInputMax = inputMapSizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;
	int32_t kernelID;

	float inputValue, kernelValue, productValue, sumOfProductValues, outputValue;

	float weight = 1.0f / static_cast<float>(inputMapSizeX * inputMapSizeY);

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = Bias;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputMapSizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * SizeXDir;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputMap[ixInput + ixKernel + iiyInput];

					kernelID = ixKernel + halfKernelSizeX + iiyKernel;

					pSumOfInputValuesArray[kernelID] += (weight * inputValue);

					kernelValue = pValueArray[kernelID];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			//sumOfProductValues /= static_cast<float>(Size);

			outputValue = pFunc(sumOfProductValues);

			SumOfOutputValues += (weight * outputValue);

			pFeatureMap[counter] += outputValue;
			counter++;

		}
	}
}

// Bei der Fehlerberecnung werden die Fehler der direkt nachgeschalteten C2DLocalReceptiveField-Instanzen ber�cksichtigt:
void C2DLocalReceptiveField::Begin_ErrorCalculation(C2DLocalReceptiveField *pPostLocalReceptiveField)
{
	Reset_ErrorValues();

	uint32_t postLRFSize = pPostLocalReceptiveField->Size;

	for (uint32_t i = 0; i < postLRFSize; i++)
		OutputErrorValue += pPostLocalReceptiveField->pInputErrorValueArray[i];
}

void C2DLocalReceptiveField::Continue_ErrorCalculation(C2DLocalReceptiveField *pPostLocalReceptiveField)
{
	uint32_t postLRFSize = pPostLocalReceptiveField->Size;

	for (uint32_t i = 0; i < postLRFSize; i++)
		OutputErrorValue += pPostLocalReceptiveField->pInputErrorValueArray[i];
}

void C2DLocalReceptiveField::Finish_ErrorCalculation(float inputErrorFactor1, float inputErrorFactor2, float outputErrorFactor1, float outputErrorFactor2)
{
	//std::cout << OutputErrorValue << std::endl;

	OutputErrorValue = OutputErrorValue * outputErrorFactor1 * exp(-outputErrorFactor2 * SumOfOutputValues * SumOfOutputValues);

	//std::cout << OutputErrorValue << std::endl;
	//std::cout << "-----------------" << std::endl;

	for (uint32_t i = 0; i < Size; i++)
		pInputErrorValueArray[i] = OutputErrorValue * /*synaptic plasticity:*/ pValueArray[i] * inputErrorFactor1 * exp(-inputErrorFactor2 * pSumOfInputValuesArray[i] * pSumOfInputValuesArray[i]);
}

// Train:

void C2DLocalReceptiveField::Adjust_LocalReceptiveField_AfterErrorCalculations(float learningRate)
{
	for (uint32_t i = 0; i < Size; i++)
		pValueArray[i] += learningRate * OutputErrorValue * pSumOfInputValuesArray[i];
}

void C2DLocalReceptiveField::Train_Final_LocalReceptiveField(CNeuralNet *pBrain, uint32_t firstReceiverNeuronID, uint32_t lastReceiverNeuronID, float learningRate, float receiverNeuronErrorFactor1, float receiverNeuronErrorFactor2, float inputErrorFactor1, float inputErrorFactor2, float outputErrorFactor1, float outputErrorFactor2)
{
	Reset_ErrorValues();

	for (uint32_t i = firstReceiverNeuronID; i < lastReceiverNeuronID; i++)
	{
		pBrain->pNeuronArray[i].Set_ErrorFactors(receiverNeuronErrorFactor1, receiverNeuronErrorFactor2);
		pBrain->pNeuronArray[i].Calculate_InputNeuronError();
	}


	for (uint32_t i = firstReceiverNeuronID; i < lastReceiverNeuronID; i++)
		OutputErrorValue += pBrain->pNeuronArray[i].ErrorValue;


	OutputErrorValue = OutputErrorValue * outputErrorFactor1 * exp(-(outputErrorFactor2 * SumOfOutputValues * SumOfOutputValues));

	for (uint32_t i = 0; i < Size; i++)
		pInputErrorValueArray[i] = OutputErrorValue * pValueArray[i] * inputErrorFactor1 * exp(-inputErrorFactor2 * pSumOfInputValuesArray[i] * pSumOfInputValuesArray[i]);

	for (uint32_t i = 0; i < Size; i++)
		pValueArray[i] += learningRate * OutputErrorValue * pSumOfInputValuesArray[i];
}






C1DLocalReceptiveField::C1DLocalReceptiveField()
{}

C1DLocalReceptiveField::~C1DLocalReceptiveField()
{
	delete[] pValueArray;
	pValueArray = nullptr;

	delete[] pInputErrorValueArray;
	pInputErrorValueArray = nullptr;

	delete[] pSumOfInputValuesArray;
	pSumOfInputValuesArray = nullptr;
}

void C1DLocalReceptiveField::Initialize(uint32_t size)
{
	SumOfOutputValues = 0.0f;

	OutputErrorValue = 0.0f;

	Bias = 0.0f;

	FittingValue = -1000000.0f;

	delete[] pValueArray;
	pValueArray = nullptr;

	delete[] pInputErrorValueArray;
	pInputErrorValueArray = nullptr;

	delete[] pSumOfInputValuesArray;
	pSumOfInputValuesArray = nullptr;

	Size = size;

	pValueArray = new (std::nothrow) float[Size];
	pInputErrorValueArray = new (std::nothrow) float[Size];
	pSumOfInputValuesArray = new (std::nothrow) float[Size];

	for (uint32_t i = 0; i < Size; i++)
	{
		pValueArray[i] = 0.0f;
		pInputErrorValueArray[i] = 0.0f;
		pSumOfInputValuesArray[i] = 0.0f;
	}
}

bool C1DLocalReceptiveField::Load_Data(const char* pFilename)
{
	std::ifstream ReadFile;

	// eine existierende Datei zum Lesen �ffnen:
	ReadFile.open(pFilename);

	if (ReadFile.good() == false)
		return false;

	uint32_t size;

	ReadFile >> size;


	Initialize(size);

	for (uint32_t i = 0; i < Size; i++)
		ReadFile >> pValueArray[i];


	ReadFile.close();

	return true;
}

bool C1DLocalReceptiveField::Save_Data(const char* pFilename)
{
	std::ofstream WriteFile;

	// neue Datei erzeugen bzw. alte �berschreiben:
	WriteFile.open(pFilename);

	// neue Datei erzeugen bzw. Inhalt ans Ende einer bestehenden Datei schreiben:
	//WriteFile.open(pFilename, ios::app);

	if (WriteFile.good() == false)
		return false;

	WriteFile << Size << "  ";


	for (uint32_t i = 0; i < Size; i++)
		WriteFile << pValueArray[i] << "  ";

	WriteFile.close();

	return true;
}

void C1DLocalReceptiveField::Reset_ErrorValues(void)
{
	OutputErrorValue = 0.0f;

	for (uint32_t i = 0; i < Size; i++)
		pInputErrorValueArray[i] = 0.0f;
}

void C1DLocalReceptiveField::Reset_SumOfOutputAndInputValues(void)
{
	SumOfOutputValues = 0.0f;

	for (uint32_t i = 0; i < Size; i++)
		pSumOfInputValuesArray[i] = 0.0f;
}

void C1DLocalReceptiveField::Set_Value(float value, uint32_t index)
{
	pValueArray[index] = value;
}

void C1DLocalReceptiveField::Clear_Values(float value)
{
	for (uint32_t i = 0; i < Size; i++)
		pValueArray[i] = value;
}

void C1DLocalReceptiveField::Set_Bias(float value)
{
	Bias = value;
}

// Achtung: Werte von 0 lassen sich mittels Backpropagation-Training nicht ver�ndern! 
void C1DLocalReceptiveField::Generate_RandomValues(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float minBiasValue, float maxBiasValue, bool includingZeroValues)
{
	if (includingZeroValues == true)
	{
		for (uint32_t i = 0; i < Size; i++)
			pValueArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minValue, maxValue);

		Bias = pRandomNumbers->Get_FloatNumber_IncludingZero(minBiasValue, maxBiasValue);
	}
	else
	{
		for (uint32_t i = 0; i < Size; i++)
			pValueArray[i] = pRandomNumbers->Get_FloatNumber(minValue, maxValue);

		Bias = pRandomNumbers->Get_FloatNumber(minBiasValue, maxBiasValue);
	}
}

// Achtung: Werte von 0 lassen sich mittels Backpropagation-Training nicht ver�ndern! 
void C1DLocalReceptiveField::Generate_RandomValues(CRandomNumbersNN *pRandomNumbers, int32_t minValue, int32_t maxValue, float minBiasValue, float maxBiasValue, bool includingZeroValues)
{
	if (includingZeroValues == true)
	{
		for (uint32_t i = 0; i < Size; i++)
			pValueArray[i] = pRandomNumbers->Get_IntegerNumber2(minValue, maxValue);

		Bias = pRandomNumbers->Get_FloatNumber_IncludingZero(minBiasValue, maxBiasValue);
	}
	else
	{
		for (uint32_t i = 0; i < Size; i++)
		{
			pValueArray[i] = pRandomNumbers->Get_IntegerNumber2(minValue, maxValue);

			if (pValueArray[i] == 0.0f)
			{
				pValueArray[i] = 1.0f;

				if (pRandomNumbers->Get_IntegerNumber2(1, 2) == 1)
					pValueArray[i] = -1.0f;
			}
		}

		Bias = pRandomNumbers->Get_FloatNumber(minBiasValue, maxBiasValue);
	}
}

void C1DLocalReceptiveField::Mutate_Values1(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float mutationRate)
{
	for (uint32_t i = 0; i < Size; i++)
	{
		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
			continue;

		pValueArray[i] = pRandomNumbers->Get_FloatNumber(minValue, maxValue);
	}
}

void C1DLocalReceptiveField::Mutate_Values2(CRandomNumbersNN *pRandomNumbers, float minVariance, float maxVariance, float mutationRate)
{
	for (uint32_t i = 0; i < Size; i++)
	{
		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
			continue;

		pValueArray[i] += pRandomNumbers->Get_FloatNumber(minVariance, maxVariance);
	}
}

void C1DLocalReceptiveField::Clone_Values(C1DLocalReceptiveField *pOriginalLRF)
{
	SumOfActivationValues = pOriginalLRF->SumOfActivationValues;
	MaxActivationValue = pOriginalLRF->MaxActivationValue;
	MinActivationValue = pOriginalLRF->MinActivationValue;

	for (uint32_t i = 0; i < Size; i++)
		pValueArray[i] = pOriginalLRF->pValueArray[i];

	Bias = pOriginalLRF->Bias;
}

void C1DLocalReceptiveField::Clone_Values(C1DLocalReceptiveField *pOriginalLRF, CRandomNumbersNN *pRandomNumbers, float filterVariance, float biasVariance, float mutationRate)
{
	SumOfActivationValues = pOriginalLRF->SumOfActivationValues;
	MaxActivationValue = pOriginalLRF->MaxActivationValue;
	MinActivationValue = pOriginalLRF->MinActivationValue;

	for (uint32_t i = 0; i < Size; i++)
	{
		pValueArray[i] = pOriginalLRF->pValueArray[i];

		pValueArray[i] += pRandomNumbers->Get_FloatNumber(filterVariance, filterVariance);
	}


	Bias = pOriginalLRF->Bias;
	Bias += biasVariance;
}

void C1DLocalReceptiveField::Combine_Values(C1DLocalReceptiveField *pParentLRF1, C1DLocalReceptiveField *pParentLRF2, CRandomNumbersNN *pRandomNumbers, float minWeight1)
{
	float weight1, weight2;
	float newValue;

	for (uint32_t i = 0; i < Size; i++)
	{
		weight1 = pRandomNumbers->Get_FloatNumber(minWeight1, 1.0f);
		weight2 = 1.0f - weight1;

		newValue = weight1*pParentLRF1->pValueArray[i];
		newValue += weight2*pParentLRF2->pValueArray[i];

		pValueArray[i] = newValue;
	}

	weight1 = pRandomNumbers->Get_FloatNumber(minWeight1, 1.0f);
	weight2 = 1.0f - weight1;

	newValue = weight1*pParentLRF1->Bias;
	newValue += weight2*pParentLRF2->Bias;

	Bias = newValue;
}

void C1DLocalReceptiveField::Reset_ActivationData(void)
{
	SumOfActivationValues = 0.0f;

	MaxActivationValue = -100000000.0f;
	MinActivationValue = 100000000.0f;
}

void C1DLocalReceptiveField::Update_ActivationData(float value)
{
	SumOfActivationValues += value;

	if (value > MaxActivationValue)
		MaxActivationValue = value;

	if (value < MinActivationValue)
		MinActivationValue = value;
}

void C1DLocalReceptiveField::Calculate_FittingValue(float fittingParam1, float fittingParam2)
{
	FittingValue = fittingParam1 * MaxActivationValue + fittingParam2 * SumOfActivationValues;
}

void C1DLocalReceptiveField::Calculate_FeatureMap(float *pFeatureMap, const float *pInputArray, int32_t inputArraySize, int32_t stride, pActivationFunc pFunc)
{
	float weight = 1.0f / static_cast<float>(inputArraySize);

	if (Size == inputArraySize)
	{
		float inputValue, kernelValue, productValue, outputValue;

		float sumOfProductValues = Bias;

		for (uint32_t i = 0; i < Size; i++)
		{
			inputValue = pInputArray[i];
			kernelValue = pValueArray[i];

			pSumOfInputValuesArray[i] += (weight*inputValue);

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		//sumOfProductValues /= static_cast<float>(Size);

		outputValue = pFunc(sumOfProductValues);

		SumOfOutputValues = (weight*outputValue);

		pFeatureMap[0] = outputValue;

		return;
	}

	int32_t halfKernelSize = Size / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel, kernelID;

	float inputValue, kernelValue, productValue, sumOfProductValues, outputValue;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = Bias;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];

			kernelID = iKernel + halfKernelSize;

			pSumOfInputValuesArray[kernelID] += (weight*inputValue);

			kernelValue = pValueArray[kernelID];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		sumOfProductValues /= static_cast<float>(Size);

		outputValue = pFunc(sumOfProductValues);

		SumOfOutputValues += (weight*outputValue);

		pFeatureMap[counter] = outputValue;
		counter++;
	}
}

void C1DLocalReceptiveField::Add_Feature_To_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputArraySize, int32_t stride, pActivationFunc pFunc)
{
	int32_t halfKernelSize = Size / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel, kernelID;

	float inputValue, kernelValue, productValue, sumOfProductValues, outputValue;

	float weight = 1.0f / static_cast<float>(inputArraySize);

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = Bias;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];

			kernelID = iKernel + halfKernelSize;

			pSumOfInputValuesArray[kernelID] += (weight*inputValue);

			kernelValue = pValueArray[kernelID];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		//sumOfProductValues /= static_cast<float>(Size);

		outputValue = pFunc(sumOfProductValues);

		SumOfOutputValues += (weight*outputValue);

		pFeatureMap[counter] += outputValue;
		counter++;
	}
}

// Bei der Fehlerberecnung werden die Fehler der direkt nachgeschalteten C1DLocalReceptiveField-Instanzen ber�cksichtigt:

void C1DLocalReceptiveField::Begin_ErrorCalculation(C1DLocalReceptiveField *pPostLocalReceptiveField)
{
	Reset_ErrorValues();

	uint32_t postLRFSize = pPostLocalReceptiveField->Size;

	for (uint32_t i = 0; i < postLRFSize; i++)
		OutputErrorValue += pPostLocalReceptiveField->pInputErrorValueArray[i];
}

void C1DLocalReceptiveField::Continue_ErrorCalculation(C1DLocalReceptiveField *pPostLocalReceptiveField)
{
	uint32_t postLRFSize = pPostLocalReceptiveField->Size;

	for (uint32_t i = 0; i < postLRFSize; i++)
		OutputErrorValue += pPostLocalReceptiveField->pInputErrorValueArray[i];
}

void C1DLocalReceptiveField::Finish_ErrorCalculation(float inputErrorFactor1, float inputErrorFactor2, float outputErrorFactor1, float outputErrorFactor2)
{
	OutputErrorValue = OutputErrorValue * outputErrorFactor1 * exp(-outputErrorFactor2 * SumOfOutputValues * SumOfOutputValues);

	for (uint32_t i = 0; i < Size; i++)
		pInputErrorValueArray[i] = OutputErrorValue * /*synaptic plasticity:*/ pValueArray[i] * inputErrorFactor1 * exp(-inputErrorFactor2 * pSumOfInputValuesArray[i] * pSumOfInputValuesArray[i]);
}

// Train:
void C1DLocalReceptiveField::Adjust_LocalReceptiveField_AfterErrorCalculations(float learningRate)
{
	for (uint32_t i = 0; i < Size; i++)
		pValueArray[i] += learningRate * OutputErrorValue * pSumOfInputValuesArray[i];
}

void C1DLocalReceptiveField::Train_Final_LocalReceptiveField(CNeuralNet *pBrain, uint32_t firstReceiverNeuronID, uint32_t lastReceiverNeuronID, float learningRate, float receiverNeuronErrorFactor1, float receiverNeuronErrorFactor2, float inputErrorFactor1, float inputErrorFactor2, float outputErrorFactor1, float outputErrorFactor2)
{
	Reset_ErrorValues();

	for (uint32_t i = firstReceiverNeuronID; i < lastReceiverNeuronID; i++)
	{
		pBrain->pNeuronArray[i].Set_ErrorFactors(receiverNeuronErrorFactor1, receiverNeuronErrorFactor2);
		pBrain->pNeuronArray[i].Calculate_InputNeuronError();
	}


	for (uint32_t i = firstReceiverNeuronID; i < lastReceiverNeuronID; i++)
		OutputErrorValue += pBrain->pNeuronArray[i].ErrorValue;

	OutputErrorValue = OutputErrorValue * outputErrorFactor1 * exp(-outputErrorFactor2 * SumOfOutputValues * SumOfOutputValues);

	for (uint32_t i = 0; i < Size; i++)
		pInputErrorValueArray[i] = OutputErrorValue * pValueArray[i] * inputErrorFactor1 * exp(-inputErrorFactor2 * pSumOfInputValuesArray[i] * pSumOfInputValuesArray[i]);

	for (uint32_t i = 0; i < Size; i++)
		pValueArray[i] += learningRate * OutputErrorValue * pSumOfInputValuesArray[i];
}





CImageDataPreprocessing::CImageDataPreprocessing(uint32_t imageSizeX, uint32_t imageSizeY, uint32_t numFeatureMaps, uint32_t lRFSizeX, uint32_t lRFSizeY, uint32_t stride, float minBiasValue, float maxBiasValue)
{
	if (lRFSizeX > 7)
		lRFSizeX = 7;

	if (lRFSizeY > 7)
		lRFSizeY = 7;

	NumFeatureMaps = numFeatureMaps;

	IdOfWorstFittedLRF = 0;
	IdOfBestFittedLRF = 0;

	Stride = stride;

	ImageSizeX = imageSizeX;
	ImageSizeY = imageSizeY;
	ImageSize = ImageSizeX * ImageSizeY;

	LRFSizeX = lRFSizeX;
	LRFSizeY = lRFSizeY;
	LRFSize = lRFSizeX * lRFSizeY;

	UnpooledFeatureMapSizeX = (imageSizeX - lRFSizeX) / stride + 1;
	//UnpooledFeatureMapSizeX = (imageSizeX + 2 * paddingSizeX - lRFSizeX) / stride + 1;

	UnpooledFeatureMapSizeY = (imageSizeY - lRFSizeY) / stride + 1;
	//UnpooledFeatureMapSizeY = (imageSizeY + 2 * paddingSizeY - lRFSizeY) / stride + 1;

	pUnpooledFeatureMapArray = new (std::nothrow) CImageDataF[numFeatureMaps];


	for (uint32_t i = 0; i < numFeatureMaps; i++)
		pUnpooledFeatureMapArray[i].Initialize(UnpooledFeatureMapSizeX, UnpooledFeatureMapSizeY);

	UnpooledFeatureMapSize = pUnpooledFeatureMapArray[0].Size;


	if (UnpooledFeatureMapSizeX % 2 == 0)
		FeatureMapSizeX = UnpooledFeatureMapSizeX / 2;
	else
		FeatureMapSizeX = UnpooledFeatureMapSizeX / 2 + 1;

	if (UnpooledFeatureMapSizeY % 2 == 0)
		FeatureMapSizeY = UnpooledFeatureMapSizeY / 2;
	else
		FeatureMapSizeY = UnpooledFeatureMapSizeY / 2 + 1;

	FeatureMapSize = FeatureMapSizeX * FeatureMapSizeY;

	pFeatureMapArray = new (std::nothrow) CImageDataF[numFeatureMaps];
	pLRFArray = new (std::nothrow) C2DLocalReceptiveField[numFeatureMaps];

	for (uint32_t i = 0; i < numFeatureMaps; i++)
	{
		pFeatureMapArray[i].Initialize(FeatureMapSizeX, FeatureMapSizeY);
		pLRFArray[i].Initialize(lRFSizeX, lRFSizeY);
	}


	TempLRF.Initialize(lRFSizeX, lRFSizeY);


	float *pTempVec1 = new (std::nothrow) float[lRFSizeX];
	float *pTempVec2 = new (std::nothrow) float[lRFSizeX];
	float *pTempVec3 = new (std::nothrow) float[lRFSizeX];

	uint32_t NumIterationsArray[7] = { 0, 0, 100000, 100000, 100000, 100000 , 100000 };

	for (uint32_t i = 0; i < numFeatureMaps; i++)
	{
		pLRFArray[i].Set_Bias(RandomNumbers.Get_FloatNumber_IncludingZero(minBiasValue, maxBiasValue));
		Approximate_OrthonormalMatrix(pLRFArray[i].pValueArray, lRFSizeX, lRFSizeY, &RandomNumbers, NumIterationsArray, pTempVec1, pTempVec2, pTempVec3);
	}

	TempLRF.Generate_RandomValues(&RandomNumbers, -1.0f, 1.0f, minBiasValue, maxBiasValue);

	delete[] pTempVec1;
	pTempVec1 = nullptr;

	delete[] pTempVec2;
	pTempVec2 = nullptr;

	delete[] pTempVec3;
	pTempVec3 = nullptr;
}

// Achtung: LRF-Werte von 0 lassen sich mittels Backpropagation-Training nicht ver�ndern! 
CImageDataPreprocessing::CImageDataPreprocessing(uint32_t imageSizeX, uint32_t imageSizeY, uint32_t numFeatureMaps, uint32_t lRFSizeX, uint32_t lRFSizeY, uint32_t stride, int32_t minLRFValue, int32_t maxLRFValue, float minBiasValue, float maxBiasValue, bool includingZeroValues)
{
	NumFeatureMaps = numFeatureMaps;

	IdOfWorstFittedLRF = 0;
	IdOfBestFittedLRF = 0;

	Stride = stride;

	ImageSizeX = imageSizeX;
	ImageSizeY = imageSizeY;
	ImageSize = ImageSizeX * ImageSizeY;

	LRFSizeX = lRFSizeX;
	LRFSizeY = lRFSizeY;
	LRFSize = lRFSizeX * lRFSizeY;

	UnpooledFeatureMapSizeX = (imageSizeX - lRFSizeX) / stride + 1;
	//UnpooledFeatureMapSizeX = (imageSizeX + 2 * paddingSizeX - lRFSizeX) / stride + 1;

	UnpooledFeatureMapSizeY = (imageSizeY - lRFSizeY) / stride + 1;
	//UnpooledFeatureMapSizeY = (imageSizeY + 2 * paddingSizeY - lRFSizeY) / stride + 1;

	pUnpooledFeatureMapArray = new (std::nothrow) CImageDataF[numFeatureMaps];


	for (uint32_t i = 0; i < numFeatureMaps; i++)
		pUnpooledFeatureMapArray[i].Initialize(UnpooledFeatureMapSizeX, UnpooledFeatureMapSizeY);


	UnpooledFeatureMapSize = pUnpooledFeatureMapArray[0].Size;




	if (UnpooledFeatureMapSizeX % 2 == 0)
		FeatureMapSizeX = UnpooledFeatureMapSizeX / 2;
	else
		FeatureMapSizeX = UnpooledFeatureMapSizeX / 2 + 1;

	if (UnpooledFeatureMapSizeY % 2 == 0)
		FeatureMapSizeY = UnpooledFeatureMapSizeY / 2;
	else
		FeatureMapSizeY = UnpooledFeatureMapSizeY / 2 + 1;

	FeatureMapSize = FeatureMapSizeX * FeatureMapSizeY;

	pFeatureMapArray = new (std::nothrow) CImageDataF[numFeatureMaps];
	pLRFArray = new (std::nothrow) C2DLocalReceptiveField[numFeatureMaps];

	for (uint32_t i = 0; i < numFeatureMaps; i++)
	{
		pFeatureMapArray[i].Initialize(FeatureMapSizeX, FeatureMapSizeY);
		pLRFArray[i].Initialize(lRFSizeX, lRFSizeY);
	}


	TempLRF.Initialize(lRFSizeX, lRFSizeY);

	for (uint32_t i = 0; i < numFeatureMaps; i++)
		pLRFArray[i].Generate_RandomValues(&RandomNumbers, minLRFValue, maxLRFValue, minBiasValue, maxBiasValue, includingZeroValues);

	TempLRF.Generate_RandomValues(&RandomNumbers, minLRFValue, maxLRFValue, minBiasValue, maxBiasValue, includingZeroValues);
}

// Achtung: LRF-Werte von 0 lassen sich mittels Backpropagation-Training nicht ver�ndern! 
CImageDataPreprocessing::CImageDataPreprocessing(uint32_t imageSizeX, uint32_t imageSizeY, uint32_t numFeatureMaps, uint32_t lRFSizeX, uint32_t lRFSizeY, uint32_t stride, float minLRFValue, float maxLRFValue, float minBiasValue, float maxBiasValue, bool includingZeroValues)
{
	NumFeatureMaps = numFeatureMaps;

	IdOfWorstFittedLRF = 0;
	IdOfBestFittedLRF = 0;

	Stride = stride;

	ImageSizeX = imageSizeX;
	ImageSizeY = imageSizeY;
	ImageSize = ImageSizeX * ImageSizeY;

	LRFSizeX = lRFSizeX;
	LRFSizeY = lRFSizeY;
	LRFSize = lRFSizeX * lRFSizeY;

	UnpooledFeatureMapSizeX = (imageSizeX - lRFSizeX) / stride + 1;
	//UnpooledFeatureMapSizeX = (imageSizeX + 2 * paddingSizeX - lRFSizeX) / stride + 1;

	UnpooledFeatureMapSizeY = (imageSizeY - lRFSizeY) / stride + 1;
	//UnpooledFeatureMapSizeY = (imageSizeY + 2 * paddingSizeY - lRFSizeY) / stride + 1;

	pUnpooledFeatureMapArray = new (std::nothrow) CImageDataF[numFeatureMaps];


	for (uint32_t i = 0; i < numFeatureMaps; i++)
		pUnpooledFeatureMapArray[i].Initialize(UnpooledFeatureMapSizeX, UnpooledFeatureMapSizeY);


	UnpooledFeatureMapSize = pUnpooledFeatureMapArray[0].Size;


	if (UnpooledFeatureMapSizeX % 2 == 0)
		FeatureMapSizeX = UnpooledFeatureMapSizeX / 2;
	else
		FeatureMapSizeX = UnpooledFeatureMapSizeX / 2 + 1;

	if (UnpooledFeatureMapSizeY % 2 == 0)
		FeatureMapSizeY = UnpooledFeatureMapSizeY / 2;
	else
		FeatureMapSizeY = UnpooledFeatureMapSizeY / 2 + 1;

	FeatureMapSize = FeatureMapSizeX * FeatureMapSizeY;

	pFeatureMapArray = new (std::nothrow) CImageDataF[numFeatureMaps];
	pLRFArray = new (std::nothrow) C2DLocalReceptiveField[numFeatureMaps];

	for (uint32_t i = 0; i < numFeatureMaps; i++)
	{
		pFeatureMapArray[i].Initialize(FeatureMapSizeX, FeatureMapSizeY);
		pLRFArray[i].Initialize(lRFSizeX, lRFSizeY);
	}


	TempLRF.Initialize(lRFSizeX, lRFSizeY);

	for (uint32_t i = 0; i < numFeatureMaps; i++)
		pLRFArray[i].Generate_RandomValues(&RandomNumbers, minLRFValue, maxLRFValue, minBiasValue, maxBiasValue, includingZeroValues);

	TempLRF.Generate_RandomValues(&RandomNumbers, minLRFValue, maxLRFValue, minBiasValue, maxBiasValue, includingZeroValues);
}

CImageDataPreprocessing::~CImageDataPreprocessing()
{
	delete[] pUnpooledFeatureMapArray;
	pUnpooledFeatureMapArray = nullptr;

	delete[] pFeatureMapArray;
	pFeatureMapArray = nullptr;

	delete[] pLRFArray;
	pLRFArray = nullptr;
}

void CImageDataPreprocessing::Init_Standard_LocalReceptiveFields(float minBiasValue, float maxBiasValue)
{
	uint32_t halfLRFSizeX = LRFSizeX / 2;
	uint32_t halfLRFSizeY = LRFSizeY / 2;

	for (uint32_t i = 0; i < NumFeatureMaps; i++)
	{
		for (uint32_t j = 0; j < LRFSize; j++)
			pLRFArray[i].pValueArray[j] = 0.0f;

		pLRFArray[i].pValueArray[halfLRFSizeX + halfLRFSizeY * LRFSizeX] = 1.0f;

		pLRFArray[i].Bias = RandomNumbers.Get_FloatNumber_IncludingZero(minBiasValue, maxBiasValue);
	}
}

void CImageDataPreprocessing::Init_LocalReceptiveField(float *pValueArray, uint32_t id)
{
	for (uint32_t j = 0; j < LRFSize; j++)
		pLRFArray[id].pValueArray[j] = pValueArray[j];
}

void CImageDataPreprocessing::Single_LocalReceptiveField_Evolution(float *pImageData, uint32_t idOfLRF, float minFilterValue, float maxFilterValue, float minBiasValue, float maxBiasValue, pActivationFunc pFunc, bool includingZeroValues)
{
	Calculate_FeatureMap(pUnpooledFeatureMapArray[idOfLRF].pValueArray, pImageData, ImageSizeX, ImageSizeY, pLRFArray[idOfLRF].pValueArray,
		LRFSizeX, LRFSizeY, Stride, Stride, pLRFArray[idOfLRF].Bias, pFunc);

#ifdef NormalizeImageData
	Normalize(pUnpooledFeatureMapArray[idOfLRF].pValueArray, UnpooledFeatureMapSize);
#endif

	pLRFArray[idOfLRF].Reset_ActivationData();

	for (uint32_t j = 0; j < UnpooledFeatureMapSize; j++)
		pLRFArray[idOfLRF].Update_ActivationData(pUnpooledFeatureMapArray[idOfLRF].pValueArray[j]);

	TempLRF.Clone_Values(&pLRFArray[idOfLRF]);

	pLRFArray[idOfLRF].Generate_RandomValues(&RandomNumbers, minFilterValue, maxFilterValue, minBiasValue, maxBiasValue, includingZeroValues);


	Calculate_FeatureMap(pUnpooledFeatureMapArray[idOfLRF].pValueArray, pImageData, ImageSizeX, ImageSizeY, pLRFArray[idOfLRF].pValueArray,
		LRFSizeX, LRFSizeY, Stride, Stride, pLRFArray[idOfLRF].Bias, pFunc);


#ifdef NormalizeImageData
	Normalize(pUnpooledFeatureMapArray[idOfLRF].pValueArray, UnpooledFeatureMapSize);
#endif

	pLRFArray[idOfLRF].Reset_ActivationData();

	for (uint32_t j = 0; j < UnpooledFeatureMapSize; j++)
		pLRFArray[idOfLRF].Update_ActivationData(pUnpooledFeatureMapArray[idOfLRF].pValueArray[j]);

	if (pLRFArray[idOfLRF].SumOfActivationValues < TempLRF.SumOfActivationValues)
		pLRFArray[idOfLRF].Clone_Values(&TempLRF);
}

void CImageDataPreprocessing::Single_LocalReceptiveField_Evolution(CImageDataF *pImageArray, uint32_t numImages, uint32_t idOfLRF, float minFilterValue, float maxFilterValue, float minBiasValue, float maxBiasValue, pActivationFunc pFunc, bool includingZeroValues)
{
	uint32_t imageSizeX = pImageArray[0].SizeXDir;
	uint32_t imageSizeY = pImageArray[0].SizeYDir;

	Calculate_FeatureMap(pUnpooledFeatureMapArray[idOfLRF].pValueArray, pImageArray[0].pValueArray, imageSizeX, imageSizeY, pLRFArray[idOfLRF].pValueArray,
		LRFSizeX, LRFSizeY, Stride, Stride, pLRFArray[idOfLRF].Bias, pFunc);

	for (uint32_t j = 1; j < numImages; j++)
	{
		Add_Feature_To_FeatureMap(pUnpooledFeatureMapArray[idOfLRF].pValueArray, pImageArray[j].pValueArray, imageSizeX, imageSizeY, pLRFArray[idOfLRF].pValueArray,
			LRFSizeX, LRFSizeY, Stride, Stride, pLRFArray[idOfLRF].Bias, pFunc);
	}

#ifdef NormalizeImageData
	Normalize(pUnpooledFeatureMapArray[idOfLRF].pValueArray, UnpooledFeatureMapSize);
#endif

	pLRFArray[idOfLRF].Reset_ActivationData();

	for (uint32_t j = 0; j < UnpooledFeatureMapSize; j++)
		pLRFArray[idOfLRF].Update_ActivationData(pUnpooledFeatureMapArray[idOfLRF].pValueArray[j]);

	TempLRF.Clone_Values(&pLRFArray[idOfLRF]);

	pLRFArray[idOfLRF].Generate_RandomValues(&RandomNumbers, minFilterValue, maxFilterValue, minBiasValue, maxBiasValue, includingZeroValues);


	Calculate_FeatureMap(pUnpooledFeatureMapArray[idOfLRF].pValueArray, pImageArray[0].pValueArray, imageSizeX, imageSizeY, pLRFArray[idOfLRF].pValueArray,
		LRFSizeX, LRFSizeY, Stride, Stride, pLRFArray[idOfLRF].Bias, pFunc);

	for (uint32_t j = 1; j < numImages; j++)
	{
		Add_Feature_To_FeatureMap(pUnpooledFeatureMapArray[idOfLRF].pValueArray, pImageArray[j].pValueArray, imageSizeX, imageSizeY, pLRFArray[idOfLRF].pValueArray,
			LRFSizeX, LRFSizeY, Stride, Stride, pLRFArray[idOfLRF].Bias, pFunc);
	}


#ifdef NormalizeImageData
	Normalize(pUnpooledFeatureMapArray[idOfLRF].pValueArray, UnpooledFeatureMapSize);
#endif

	pLRFArray[idOfLRF].Reset_ActivationData();

	for (uint32_t j = 0; j < UnpooledFeatureMapSize; j++)
		pLRFArray[idOfLRF].Update_ActivationData(pUnpooledFeatureMapArray[idOfLRF].pValueArray[j]);

	if (pLRFArray[idOfLRF].SumOfActivationValues < TempLRF.SumOfActivationValues)
		pLRFArray[idOfLRF].Clone_Values(&TempLRF);
}

void CImageDataPreprocessing::Single_LocalReceptiveField_Evolution(float *pImageData, uint32_t idOfLRF, int32_t minFilterValue, int32_t maxFilterValue, float minBiasValue, float maxBiasValue, pActivationFunc pFunc, bool includingZeroValues)
{
	Calculate_FeatureMap(pUnpooledFeatureMapArray[idOfLRF].pValueArray, pImageData, ImageSizeX, ImageSizeY, pLRFArray[idOfLRF].pValueArray,
		LRFSizeX, LRFSizeY, Stride, Stride, pLRFArray[idOfLRF].Bias, pFunc);

#ifdef NormalizeImageData
	Normalize(pUnpooledFeatureMapArray[idOfLRF].pValueArray, UnpooledFeatureMapSize);
#endif

	pLRFArray[idOfLRF].Reset_ActivationData();

	for (uint32_t j = 0; j < UnpooledFeatureMapSize; j++)
		pLRFArray[idOfLRF].Update_ActivationData(pUnpooledFeatureMapArray[idOfLRF].pValueArray[j]);

	TempLRF.Clone_Values(&pLRFArray[idOfLRF]);

	pLRFArray[idOfLRF].Generate_RandomValues(&RandomNumbers, minFilterValue, maxFilterValue, minBiasValue, maxBiasValue, includingZeroValues);

	Calculate_FeatureMap(pUnpooledFeatureMapArray[idOfLRF].pValueArray, pImageData, ImageSizeX, ImageSizeY, pLRFArray[idOfLRF].pValueArray,
		LRFSizeX, LRFSizeY, Stride, Stride, pLRFArray[idOfLRF].Bias, pFunc);

#ifdef NormalizeImageData
	Normalize(pUnpooledFeatureMapArray[idOfLRF].pValueArray, UnpooledFeatureMapSize);
#endif

	pLRFArray[idOfLRF].Reset_ActivationData();

	for (uint32_t j = 0; j < UnpooledFeatureMapSize; j++)
		pLRFArray[idOfLRF].Update_ActivationData(pUnpooledFeatureMapArray[idOfLRF].pValueArray[j]);

	if (pLRFArray[idOfLRF].SumOfActivationValues < TempLRF.SumOfActivationValues)
		pLRFArray[idOfLRF].Clone_Values(&TempLRF);
}

void CImageDataPreprocessing::Single_LocalReceptiveField_Evolution(CImageDataF *pImageArray, uint32_t numImages, uint32_t idOfLRF, int32_t minFilterValue, int32_t maxFilterValue, float minBiasValue, float maxBiasValue, pActivationFunc pFunc, bool includingZeroValues)
{
	uint32_t imageSizeX = pImageArray[0].SizeXDir;
	uint32_t imageSizeY = pImageArray[0].SizeYDir;

	Calculate_FeatureMap(pUnpooledFeatureMapArray[idOfLRF].pValueArray, pImageArray[0].pValueArray, imageSizeX, imageSizeY, pLRFArray[idOfLRF].pValueArray,
		LRFSizeX, LRFSizeY, Stride, Stride, pLRFArray[idOfLRF].Bias, pFunc);

	for (uint32_t j = 1; j < numImages; j++)
	{
		Add_Feature_To_FeatureMap(pUnpooledFeatureMapArray[idOfLRF].pValueArray, pImageArray[j].pValueArray, imageSizeX, imageSizeY, pLRFArray[idOfLRF].pValueArray,
			LRFSizeX, LRFSizeY, Stride, Stride, pLRFArray[idOfLRF].Bias, pFunc);
	}

#ifdef NormalizeImageData
	Normalize(pUnpooledFeatureMapArray[idOfLRF].pValueArray, UnpooledFeatureMapSize);
#endif

	pLRFArray[idOfLRF].Reset_ActivationData();

	for (uint32_t j = 0; j < UnpooledFeatureMapSize; j++)
		pLRFArray[idOfLRF].Update_ActivationData(pUnpooledFeatureMapArray[idOfLRF].pValueArray[j]);

	TempLRF.Clone_Values(&pLRFArray[idOfLRF]);

	pLRFArray[idOfLRF].Generate_RandomValues(&RandomNumbers, minFilterValue, maxFilterValue, minBiasValue, maxBiasValue, includingZeroValues);

	Calculate_FeatureMap(pUnpooledFeatureMapArray[idOfLRF].pValueArray, pImageArray[0].pValueArray, imageSizeX, imageSizeY, pLRFArray[idOfLRF].pValueArray,
		LRFSizeX, LRFSizeY, Stride, Stride, pLRFArray[idOfLRF].Bias, pFunc);

	for (uint32_t j = 1; j < numImages; j++)
	{
		Add_Feature_To_FeatureMap(pUnpooledFeatureMapArray[idOfLRF].pValueArray, pImageArray[j].pValueArray, imageSizeX, imageSizeY, pLRFArray[idOfLRF].pValueArray,
			LRFSizeX, LRFSizeY, Stride, Stride, pLRFArray[idOfLRF].Bias, pFunc);
	}

#ifdef NormalizeImageData
	Normalize(pUnpooledFeatureMapArray[0].pValueArray, UnpooledFeatureMapSize);
#endif

	pLRFArray[idOfLRF].Reset_ActivationData();

	for (uint32_t j = 0; j < UnpooledFeatureMapSize; j++)
		pLRFArray[idOfLRF].Update_ActivationData(pUnpooledFeatureMapArray[idOfLRF].pValueArray[j]);

	if (pLRFArray[idOfLRF].SumOfActivationValues < TempLRF.SumOfActivationValues)
		pLRFArray[idOfLRF].Clone_Values(&TempLRF);
}

void CImageDataPreprocessing::Prepare_LocalReceptiveField_Analysis(void)
{
	for (uint32_t i = 0; i < NumFeatureMaps; i++)
		pLRFArray[i].Reset_ActivationData();
}

void CImageDataPreprocessing::Display_LocalReceptiveField_Analysis(void)
{
	for (uint32_t i = 0; i < NumFeatureMaps; i++)
	{
		std::cout << "LRF ID: " << i << std::endl;
		std::cout << "FittingValue: " << pLRFArray[i].FittingValue << std::endl;
		std::cout << "SumOfActivationValues: " << pLRFArray[i].SumOfActivationValues << std::endl;
		std::cout << "MinActivationValue: " << pLRFArray[i].MinActivationValue << std::endl;
		std::cout << "MaxActivationValue: " << pLRFArray[i].MaxActivationValue << std::endl;
	}
}

void CImageDataPreprocessing::Analyze_LocalReceptiveFields(float *pImageData, pActivationFunc pFunc)
{
	for (uint32_t i = 0; i < NumFeatureMaps; i++)
	{
		Calculate_FeatureMap(pUnpooledFeatureMapArray[i].pValueArray, pImageData, ImageSizeX, ImageSizeY, pLRFArray[i].pValueArray,
			LRFSizeX, LRFSizeY, Stride, Stride, pLRFArray[i].Bias, pFunc);

		for (uint32_t j = 0; j < UnpooledFeatureMapSize; j++)
			pLRFArray[i].Update_ActivationData(pUnpooledFeatureMapArray[i].pValueArray[j]);

		/*
		#ifdef UseImageL2Pooling2x2
		L2Pooling2x2(pFeatureMapArray[i].pValueArray, pUnpooledFeatureMapArray[i].pValueArray, UnpooledFeatureMapSizeX, UnpooledFeatureMapSizeY);
		#else
		MaxPooling2x2(pFeatureMapArray[i].pValueArray, pUnpooledFeatureMapArray[i].pValueArray, UnpooledFeatureMapSizeX, UnpooledFeatureMapSizeY);
		#endif

		#ifdef NormalizeImageData
		Normalize(pFeatureMapArray[i].pValueArray, pFeatureMapArray[i].pValueArray, pFeatureMapArray[i].Size);
		#endif
		*/
	}
}

void CImageDataPreprocessing::Analyze_LocalReceptiveFields(CImageDataF *pImageArray, uint32_t numImages, pActivationFunc pFunc)
{
	uint32_t imageSizeX = pImageArray[0].SizeXDir;
	uint32_t imageSizeY = pImageArray[0].SizeYDir;

	for (uint32_t i = 0; i < NumFeatureMaps; i++)
	{

		Calculate_FeatureMap(pUnpooledFeatureMapArray[i].pValueArray, pImageArray[0].pValueArray, imageSizeX, imageSizeY, pLRFArray[i].pValueArray,
			LRFSizeX, LRFSizeY, Stride, Stride, pLRFArray[i].Bias, pFunc);

		for (uint32_t j = 1; j < numImages; j++)
		{
			Add_Feature_To_FeatureMap(pUnpooledFeatureMapArray[i].pValueArray, pImageArray[j].pValueArray, imageSizeX, imageSizeY, pLRFArray[i].pValueArray,
				LRFSizeX, LRFSizeY, Stride, Stride, pLRFArray[i].Bias, pFunc);
		}

		for (uint32_t k = 0; k < UnpooledFeatureMapSize; k++)
			pLRFArray[i].Update_ActivationData(pUnpooledFeatureMapArray[i].pValueArray[k]);

		/*
		#ifdef UseImageL2Pooling2x2
		L2Pooling2x2(pFeatureMapArray[i].pValueArray, pUnpooledFeatureMapArray[i].pValueArray, UnpooledFeatureMapSizeX, UnpooledFeatureMapSizeY);
		#else
		MaxPooling2x2(pFeatureMapArray[i].pValueArray, pUnpooledFeatureMapArray[i].pValueArray, UnpooledFeatureMapSizeX, UnpooledFeatureMapSizeY);
		#endif

		#ifdef NormalizeImageData
		Normalize(pFeatureMapArray[i].pValueArray, pFeatureMapArray[i].pValueArray, pFeatureMapArray[i].Size);
		#endif
		*/
	}
}

void CImageDataPreprocessing::Update_Evolution(float minValue, float maxValue, float minBiasValue, float maxBiasValue, float fittingParam1, float fittingParam2, bool includingZeroValues)
{
	for (uint32_t i = 0; i < NumFeatureMaps; i++)
		pLRFArray[i].Calculate_FittingValue(fittingParam1, fittingParam2);

	if (pLRFArray[IdOfWorstFittedLRF].FittingValue < TempLRF.FittingValue)
	{
		pLRFArray[IdOfWorstFittedLRF].Clone_Values(&TempLRF);
		TempLRF.FittingValue = -1000000.0f;
		return;
	}

	float minFittingValue = 100000000.0f;
	IdOfWorstFittedLRF = 0;

	float maxFittingValue = -100000000.0f;
	IdOfBestFittedLRF = 0;

	for (uint32_t i = 0; i < NumFeatureMaps; i++)
	{
		if (pLRFArray[i].FittingValue < minFittingValue)
		{
			minFittingValue = pLRFArray[i].FittingValue;
			IdOfWorstFittedLRF = i;
		}

		if (pLRFArray[i].FittingValue > maxFittingValue)
		{
			maxFittingValue = pLRFArray[i].FittingValue;
			IdOfBestFittedLRF = i;
		}
	}

	TempLRF.Clone_Values(&pLRFArray[IdOfWorstFittedLRF]);

	pLRFArray[IdOfWorstFittedLRF].Generate_RandomValues(&RandomNumbers, minValue, maxValue, minBiasValue, maxBiasValue, includingZeroValues);
}

void CImageDataPreprocessing::Update_Evolution(int32_t minValue, int32_t maxValue, float minBiasValue, float maxBiasValue, float fittingParam1, float fittingParam2, bool includingZeroValues)
{

	for (uint32_t i = 0; i < NumFeatureMaps; i++)
		pLRFArray[i].Calculate_FittingValue(fittingParam1, fittingParam2);

	if (pLRFArray[IdOfWorstFittedLRF].FittingValue < TempLRF.FittingValue)
	{
		pLRFArray[IdOfWorstFittedLRF].Clone_Values(&TempLRF);
		TempLRF.FittingValue = -1000000.0f;
		return;
	}

	float minFittingValue = 100000000.0f;
	IdOfWorstFittedLRF = 0;

	float maxFittingValue = -100000000.0f;
	IdOfBestFittedLRF = 0;

	for (uint32_t i = 0; i < NumFeatureMaps; i++)
	{
		if (pLRFArray[i].FittingValue < minFittingValue)
		{
			minFittingValue = pLRFArray[i].FittingValue;
			IdOfWorstFittedLRF = i;
		}

		if (pLRFArray[i].FittingValue > maxFittingValue)
		{
			maxFittingValue = pLRFArray[i].FittingValue;
			IdOfBestFittedLRF = i;
		}
	}

	TempLRF.Clone_Values(&pLRFArray[IdOfWorstFittedLRF]);

	pLRFArray[IdOfWorstFittedLRF].Generate_RandomValues(&RandomNumbers, minValue, maxValue, minBiasValue, maxBiasValue, includingZeroValues);
}

void CImageDataPreprocessing::Preprocess_Data(float *pImageData, pActivationFunc pFunc, uint32_t poolingType)
{
	for (uint32_t i = 0; i < NumFeatureMaps; i++)
	{
		pLRFArray[i].Reset_SumOfOutputAndInputValues();
		pLRFArray[i].Calculate_FeatureMap(pUnpooledFeatureMapArray[i].pValueArray, pImageData, ImageSizeX, ImageSizeY, Stride, Stride, pFunc);


		if (poolingType == UseImageMaxPooling2x2)
			MaxPooling2x2(pFeatureMapArray[i].pValueArray, pUnpooledFeatureMapArray[i].pValueArray, UnpooledFeatureMapSizeX, UnpooledFeatureMapSizeY);
		else if (poolingType == UseImageL2Pooling2x2)
			L2Pooling2x2(pFeatureMapArray[i].pValueArray, pUnpooledFeatureMapArray[i].pValueArray, UnpooledFeatureMapSizeX, UnpooledFeatureMapSizeY);




#ifdef NormalizeImageData
		if (poolingType == UseNoImagePooling)
			Normalize(pUnpooledFeatureMapArray[i].pValueArray, pUnpooledFeatureMapArray[i].pValueArray, UnpooledFeatureMapSize);
		else
			Normalize(pFeatureMapArray[i].pValueArray, pFeatureMapArray[i].pValueArray, FeatureMapSize);
#endif
	}
}


void CImageDataPreprocessing::Preprocess_Data(CImageDataF *pImageArray, uint32_t numImages, pActivationFunc pFunc, uint32_t poolingType)
{
	uint32_t imageSizeX = pImageArray[0].SizeXDir;
	uint32_t imageSizeY = pImageArray[0].SizeYDir;

	for (uint32_t i = 0; i < NumFeatureMaps; i++)
	{
		pLRFArray[i].Reset_SumOfOutputAndInputValues();
		pLRFArray[i].Calculate_FeatureMap(pUnpooledFeatureMapArray[i].pValueArray, pImageArray[0].pValueArray, imageSizeX, imageSizeY, Stride, Stride, pFunc);

		for (uint32_t j = 1; j < numImages; j++)
		{
			pLRFArray[i].Add_Feature_To_FeatureMap(pUnpooledFeatureMapArray[i].pValueArray, pImageArray[j].pValueArray, imageSizeX, imageSizeY, Stride, Stride, pFunc);
		}

		if (poolingType == UseImageMaxPooling2x2)
			MaxPooling2x2(pFeatureMapArray[i].pValueArray, pUnpooledFeatureMapArray[i].pValueArray, UnpooledFeatureMapSizeX, UnpooledFeatureMapSizeY);
		else if (poolingType == UseImageL2Pooling2x2)
			L2Pooling2x2(pFeatureMapArray[i].pValueArray, pUnpooledFeatureMapArray[i].pValueArray, UnpooledFeatureMapSizeX, UnpooledFeatureMapSizeY);




#ifdef NormalizeImageData
		if (poolingType == UseNoImagePooling)
			Normalize(pUnpooledFeatureMapArray[i].pValueArray, pUnpooledFeatureMapArray[i].pValueArray, UnpooledFeatureMapSize);
		else
			Normalize(pFeatureMapArray[i].pValueArray, pFeatureMapArray[i].pValueArray, FeatureMapSize);
#endif
	}
}

// pImageIDArray erm�glicht die Auswahl einzelner Images aus dem pImageArray:
void CImageDataPreprocessing::Preprocess_Data(CImageDataF *pImageArray, uint32_t *pImageIDArray, uint32_t numImages, pActivationFunc pFunc, uint32_t poolingType)
{
	uint32_t imageID = pImageIDArray[0];

	uint32_t imageSizeX = pImageArray[imageID].SizeXDir;
	uint32_t imageSizeY = pImageArray[imageID].SizeYDir;

	for (uint32_t i = 0; i < NumFeatureMaps; i++)
	{
		pLRFArray[i].Reset_SumOfOutputAndInputValues();
		pLRFArray[i].Calculate_FeatureMap(pUnpooledFeatureMapArray[i].pValueArray, pImageArray[imageID].pValueArray, imageSizeX, imageSizeY, Stride, Stride, pFunc);

		for (uint32_t j = 1; j < numImages; j++)
		{
			imageID = pImageIDArray[j];

			pLRFArray[i].Add_Feature_To_FeatureMap(pUnpooledFeatureMapArray[i].pValueArray, pImageArray[imageID].pValueArray, imageSizeX, imageSizeY, Stride, Stride, pFunc);
		}

		if (poolingType == UseImageMaxPooling2x2)
			MaxPooling2x2(pFeatureMapArray[i].pValueArray, pUnpooledFeatureMapArray[i].pValueArray, UnpooledFeatureMapSizeX, UnpooledFeatureMapSizeY);
		else if (poolingType == UseImageL2Pooling2x2)
			L2Pooling2x2(pFeatureMapArray[i].pValueArray, pUnpooledFeatureMapArray[i].pValueArray, UnpooledFeatureMapSizeX, UnpooledFeatureMapSizeY);




#ifdef NormalizeImageData
		if (poolingType == UseNoImagePooling)
			Normalize(pUnpooledFeatureMapArray[i].pValueArray, pUnpooledFeatureMapArray[i].pValueArray, UnpooledFeatureMapSize);
		else
			Normalize(pFeatureMapArray[i].pValueArray, pFeatureMapArray[i].pValueArray, FeatureMapSize);
#endif
	}
}

void CImageDataPreprocessing::Preprocess_Data(CNeuralNet *pBrain, float *pImageData, pActivationFunc pFunc, uint32_t poolingType)
{
	for (uint32_t i = 0; i < NumFeatureMaps; i++)
	{
		pLRFArray[i].Reset_SumOfOutputAndInputValues();
		pLRFArray[i].Calculate_FeatureMap(pUnpooledFeatureMapArray[i].pValueArray, pImageData, ImageSizeX, ImageSizeY, Stride, Stride, pFunc);

		if (poolingType == UseImageMaxPooling2x2)
			MaxPooling2x2(pFeatureMapArray[i].pValueArray, pUnpooledFeatureMapArray[i].pValueArray, UnpooledFeatureMapSizeX, UnpooledFeatureMapSizeY);
		else if (poolingType == UseImageL2Pooling2x2)
			L2Pooling2x2(pFeatureMapArray[i].pValueArray, pUnpooledFeatureMapArray[i].pValueArray, UnpooledFeatureMapSizeX, UnpooledFeatureMapSizeY);


#ifdef NormalizeImageData
		if (poolingType == UseNoImagePooling)
			Normalize(pUnpooledFeatureMapArray[i].pValueArray, pUnpooledFeatureMapArray[i].pValueArray, UnpooledFeatureMapSize);
		else
			Normalize(pFeatureMapArray[i].pValueArray, pFeatureMapArray[i].pValueArray, FeatureMapSize);
#endif
	}

	if (poolingType == UseNoImagePooling)
	{
		uint32_t offset = 0;
		uint32_t deltaOffset = UnpooledFeatureMapSize;

		pBrain->Set_InputNeuronValues_And_Propagate_Them(pUnpooledFeatureMapArray[0].pValueArray, offset, UnpooledFeatureMapSize);

		for (uint32_t i = 1; i < NumFeatureMaps; i++)
		{
			offset += deltaOffset;
			pBrain->Set_InputNeuronValues_And_Propagate_Them(pUnpooledFeatureMapArray[i].pValueArray, offset, UnpooledFeatureMapSize);
		}
	}
	else
	{
		uint32_t offset = 0;
		uint32_t deltaOffset = FeatureMapSize;

		pBrain->Set_InputNeuronValues_And_Propagate_Them(pFeatureMapArray[0].pValueArray, offset, FeatureMapSize);

		for (uint32_t i = 1; i < NumFeatureMaps; i++)
		{
			offset += deltaOffset;
			pBrain->Set_InputNeuronValues_And_Propagate_Them(pFeatureMapArray[i].pValueArray, offset, FeatureMapSize);
		}
	}
}


// pInOutNeuronIDOffset:
// Verweist beim Methodenaufruf auf die ID des ersten Neurons, an welches die Berechnungsergebnisse weitergeleitet werden sollen.
// Verweist nach dem Methodenaufruf auf die Nachfolge-ID des letzten Neurons, an welches die Berechnungsergebnisse weitergeleitet wurden. 
void CImageDataPreprocessing::Preprocess_Data(CNeuralNet *pBrain, float *pImageData, uint32_t *pInOutNeuronIDOffset, pActivationFunc pFunc, uint32_t poolingType)
{
	for (uint32_t i = 0; i < NumFeatureMaps; i++)
	{
		pLRFArray[i].Reset_SumOfOutputAndInputValues();
		pLRFArray[i].Calculate_FeatureMap(pUnpooledFeatureMapArray[i].pValueArray, pImageData, ImageSizeX, ImageSizeY, Stride, Stride, pFunc);


		if (poolingType == UseImageMaxPooling2x2)
			MaxPooling2x2(pFeatureMapArray[i].pValueArray, pUnpooledFeatureMapArray[i].pValueArray, UnpooledFeatureMapSizeX, UnpooledFeatureMapSizeY);
		else if (poolingType == UseImageL2Pooling2x2)
			L2Pooling2x2(pFeatureMapArray[i].pValueArray, pUnpooledFeatureMapArray[i].pValueArray, UnpooledFeatureMapSizeX, UnpooledFeatureMapSizeY);




#ifdef NormalizeImageData
		if (poolingType == UseNoImagePooling)
			Normalize(pUnpooledFeatureMapArray[i].pValueArray, pUnpooledFeatureMapArray[i].pValueArray, UnpooledFeatureMapSize);
		else
			Normalize(pFeatureMapArray[i].pValueArray, pFeatureMapArray[i].pValueArray, FeatureMapSize);
#endif
	}

	if (poolingType == UseNoImagePooling)
	{
		uint32_t offset = *pInOutNeuronIDOffset;
		uint32_t deltaOffset = UnpooledFeatureMapSize;

		pBrain->Set_InputNeuronValues_And_Propagate_Them(pUnpooledFeatureMapArray[0].pValueArray, offset, UnpooledFeatureMapSize);

		for (uint32_t i = 1; i < NumFeatureMaps; i++)
		{
			offset += deltaOffset;
			pBrain->Set_InputNeuronValues_And_Propagate_Them(pUnpooledFeatureMapArray[i].pValueArray, offset, UnpooledFeatureMapSize);
		}

		*pInOutNeuronIDOffset = offset + deltaOffset;
	}
	else
	{
		uint32_t offset = *pInOutNeuronIDOffset;
		uint32_t deltaOffset = FeatureMapSize;

		pBrain->Set_InputNeuronValues_And_Propagate_Them(pFeatureMapArray[0].pValueArray, offset, FeatureMapSize);

		for (uint32_t i = 1; i < NumFeatureMaps; i++)
		{
			offset += deltaOffset;
			pBrain->Set_InputNeuronValues_And_Propagate_Them(pFeatureMapArray[i].pValueArray, offset, FeatureMapSize);
		}

		*pInOutNeuronIDOffset = offset + deltaOffset;
	}
}

void CImageDataPreprocessing::Preprocess_Data(CNeuralNet *pBrain, CImageDataF *pImageArray, uint32_t numImages, pActivationFunc pFunc, uint32_t poolingType)
{
	uint32_t imageSizeX = pImageArray[0].SizeXDir;
	uint32_t imageSizeY = pImageArray[0].SizeYDir;

	for (uint32_t i = 0; i < NumFeatureMaps; i++)
	{
		pLRFArray[i].Reset_SumOfOutputAndInputValues();
		pLRFArray[i].Calculate_FeatureMap(pUnpooledFeatureMapArray[i].pValueArray, pImageArray[0].pValueArray, imageSizeX, imageSizeY, Stride, Stride, pFunc);

		for (uint32_t j = 1; j < numImages; j++)
		{
			pLRFArray[i].Add_Feature_To_FeatureMap(pUnpooledFeatureMapArray[i].pValueArray, pImageArray[j].pValueArray, imageSizeX, imageSizeY, Stride, Stride, pFunc);
		}

		if (poolingType == UseImageMaxPooling2x2)
			MaxPooling2x2(pFeatureMapArray[i].pValueArray, pUnpooledFeatureMapArray[i].pValueArray, UnpooledFeatureMapSizeX, UnpooledFeatureMapSizeY);
		else if (poolingType == UseImageL2Pooling2x2)
			L2Pooling2x2(pFeatureMapArray[i].pValueArray, pUnpooledFeatureMapArray[i].pValueArray, UnpooledFeatureMapSizeX, UnpooledFeatureMapSizeY);




#ifdef NormalizeImageData
		if (poolingType == UseNoImagePooling)
			Normalize(pUnpooledFeatureMapArray[i].pValueArray, pUnpooledFeatureMapArray[i].pValueArray, UnpooledFeatureMapSize);
		else
			Normalize(pFeatureMapArray[i].pValueArray, pFeatureMapArray[i].pValueArray, FeatureMapSize);
#endif
	}

	if (poolingType == UseNoImagePooling)
	{
		uint32_t offset = 0;
		uint32_t deltaOffset = UnpooledFeatureMapSize;

		pBrain->Set_InputNeuronValues_And_Propagate_Them(pUnpooledFeatureMapArray[0].pValueArray, offset, UnpooledFeatureMapSize);

		for (uint32_t i = 1; i < NumFeatureMaps; i++)
		{
			offset += deltaOffset;
			pBrain->Set_InputNeuronValues_And_Propagate_Them(pUnpooledFeatureMapArray[i].pValueArray, offset, UnpooledFeatureMapSize);
		}
	}
	else
	{
		uint32_t offset = 0;
		uint32_t deltaOffset = FeatureMapSize;

		pBrain->Set_InputNeuronValues_And_Propagate_Them(pFeatureMapArray[0].pValueArray, offset, FeatureMapSize);

		for (uint32_t i = 1; i < NumFeatureMaps; i++)
		{
			offset += deltaOffset;
			pBrain->Set_InputNeuronValues_And_Propagate_Them(pFeatureMapArray[i].pValueArray, offset, FeatureMapSize);
		}
	}
}

void CImageDataPreprocessing::Preprocess_Data(CNeuralNet *pBrain, CImageDataF *pImageArray, uint32_t numImages, uint32_t *pInOutNeuronIDOffset, pActivationFunc pFunc, uint32_t poolingType)
{
	uint32_t imageSizeX = pImageArray[0].SizeXDir;
	uint32_t imageSizeY = pImageArray[0].SizeYDir;

	for (uint32_t i = 0; i < NumFeatureMaps; i++)
	{
		pLRFArray[i].Reset_SumOfOutputAndInputValues();
		pLRFArray[i].Calculate_FeatureMap(pUnpooledFeatureMapArray[i].pValueArray, pImageArray[0].pValueArray, imageSizeX, imageSizeY, Stride, Stride, pFunc);

		for (uint32_t j = 1; j < numImages; j++)
		{
			pLRFArray[i].Add_Feature_To_FeatureMap(pUnpooledFeatureMapArray[i].pValueArray, pImageArray[j].pValueArray, imageSizeX, imageSizeY, Stride, Stride, pFunc);
		}

		if (poolingType == UseImageMaxPooling2x2)
			MaxPooling2x2(pFeatureMapArray[i].pValueArray, pUnpooledFeatureMapArray[i].pValueArray, UnpooledFeatureMapSizeX, UnpooledFeatureMapSizeY);
		else if (poolingType == UseImageL2Pooling2x2)
			L2Pooling2x2(pFeatureMapArray[i].pValueArray, pUnpooledFeatureMapArray[i].pValueArray, UnpooledFeatureMapSizeX, UnpooledFeatureMapSizeY);



#ifdef NormalizeImageData
		if (poolingType == UseNoImagePooling)
			Normalize(pUnpooledFeatureMapArray[i].pValueArray, pUnpooledFeatureMapArray[i].pValueArray, UnpooledFeatureMapSize);
		else
			Normalize(pFeatureMapArray[i].pValueArray, pFeatureMapArray[i].pValueArray, FeatureMapSize);
#endif
	}

	if (poolingType == UseNoImagePooling)
	{
		uint32_t offset = *pInOutNeuronIDOffset;
		uint32_t deltaOffset = UnpooledFeatureMapSize;

		pBrain->Set_InputNeuronValues_And_Propagate_Them(pUnpooledFeatureMapArray[0].pValueArray, offset, UnpooledFeatureMapSize);

		for (uint32_t i = 1; i < NumFeatureMaps; i++)
		{
			offset += deltaOffset;
			pBrain->Set_InputNeuronValues_And_Propagate_Them(pUnpooledFeatureMapArray[i].pValueArray, offset, UnpooledFeatureMapSize);
		}

		*pInOutNeuronIDOffset = offset + deltaOffset;
	}
	else
	{
		uint32_t offset = *pInOutNeuronIDOffset;
		uint32_t deltaOffset = FeatureMapSize;

		pBrain->Set_InputNeuronValues_And_Propagate_Them(pFeatureMapArray[0].pValueArray, offset, FeatureMapSize);

		for (uint32_t i = 1; i < NumFeatureMaps; i++)
		{
			offset += deltaOffset;
			pBrain->Set_InputNeuronValues_And_Propagate_Them(pFeatureMapArray[i].pValueArray, offset, FeatureMapSize);
		}

		*pInOutNeuronIDOffset = offset + deltaOffset;
	}
}

// pImageIDArray erm�glicht die Auswahl einzelner Images aus dem pImageArray:
void CImageDataPreprocessing::Preprocess_Data(CNeuralNet *pBrain, CImageDataF *pImageArray, uint32_t *pImageIDArray, uint32_t numImages, pActivationFunc pFunc, uint32_t poolingType)
{
	uint32_t imageID = pImageIDArray[0];

	uint32_t imageSizeX = pImageArray[imageID].SizeXDir;
	uint32_t imageSizeY = pImageArray[imageID].SizeYDir;

	for (uint32_t i = 0; i < NumFeatureMaps; i++)
	{
		pLRFArray[i].Reset_SumOfOutputAndInputValues();
		pLRFArray[i].Calculate_FeatureMap(pUnpooledFeatureMapArray[i].pValueArray, pImageArray[imageID].pValueArray, imageSizeX, imageSizeY, Stride, Stride, pFunc);

		for (uint32_t j = 1; j < numImages; j++)
		{
			imageID = pImageIDArray[j];

			pLRFArray[i].Add_Feature_To_FeatureMap(pUnpooledFeatureMapArray[i].pValueArray, pImageArray[imageID].pValueArray, imageSizeX, imageSizeY, Stride, Stride, pFunc);
		}

		if (poolingType == UseImageMaxPooling2x2)
			MaxPooling2x2(pFeatureMapArray[i].pValueArray, pUnpooledFeatureMapArray[i].pValueArray, UnpooledFeatureMapSizeX, UnpooledFeatureMapSizeY);
		else if (poolingType == UseImageL2Pooling2x2)
			L2Pooling2x2(pFeatureMapArray[i].pValueArray, pUnpooledFeatureMapArray[i].pValueArray, UnpooledFeatureMapSizeX, UnpooledFeatureMapSizeY);




#ifdef NormalizeImageData
		if (poolingType == UseNoImagePooling)
			Normalize(pUnpooledFeatureMapArray[i].pValueArray, pUnpooledFeatureMapArray[i].pValueArray, UnpooledFeatureMapSize);
		else
			Normalize(pFeatureMapArray[i].pValueArray, pFeatureMapArray[i].pValueArray, FeatureMapSize);
#endif
	}

	if (poolingType == UseNoImagePooling)
	{
		uint32_t offset = 0;
		uint32_t deltaOffset = UnpooledFeatureMapSize;

		pBrain->Set_InputNeuronValues_And_Propagate_Them(pUnpooledFeatureMapArray[0].pValueArray, offset, UnpooledFeatureMapSize);

		for (uint32_t i = 1; i < NumFeatureMaps; i++)
		{
			offset += deltaOffset;
			pBrain->Set_InputNeuronValues_And_Propagate_Them(pUnpooledFeatureMapArray[i].pValueArray, offset, UnpooledFeatureMapSize);
		}
	}
	else
	{
		uint32_t offset = 0;
		uint32_t deltaOffset = FeatureMapSize;

		pBrain->Set_InputNeuronValues_And_Propagate_Them(pFeatureMapArray[0].pValueArray, offset, FeatureMapSize);

		for (uint32_t i = 1; i < NumFeatureMaps; i++)
		{
			offset += deltaOffset;
			pBrain->Set_InputNeuronValues_And_Propagate_Them(pFeatureMapArray[i].pValueArray, offset, FeatureMapSize);
		}
	}
}

// pImageIDArray erm�glicht die Auswahl einzelner Images aus dem pImageArray:
void CImageDataPreprocessing::Preprocess_Data(CNeuralNet *pBrain, CImageDataF *pImageArray, uint32_t *pImageIDArray, uint32_t numImages, uint32_t *pInOutNeuronIDOffset, pActivationFunc pFunc, uint32_t poolingType)
{
	uint32_t imageID = pImageIDArray[0];

	uint32_t imageSizeX = pImageArray[imageID].SizeXDir;
	uint32_t imageSizeY = pImageArray[imageID].SizeYDir;

	for (uint32_t i = 0; i < NumFeatureMaps; i++)
	{
		pLRFArray[i].Reset_SumOfOutputAndInputValues();
		pLRFArray[i].Calculate_FeatureMap(pUnpooledFeatureMapArray[i].pValueArray, pImageArray[imageID].pValueArray, imageSizeX, imageSizeY, Stride, Stride, pFunc);

		for (uint32_t j = 1; j < numImages; j++)
		{
			imageID = pImageIDArray[j];

			pLRFArray[i].Add_Feature_To_FeatureMap(pUnpooledFeatureMapArray[i].pValueArray, pImageArray[imageID].pValueArray, imageSizeX, imageSizeY, Stride, Stride, pFunc);
		}

		if (poolingType == UseImageMaxPooling2x2)
			MaxPooling2x2(pFeatureMapArray[i].pValueArray, pUnpooledFeatureMapArray[i].pValueArray, UnpooledFeatureMapSizeX, UnpooledFeatureMapSizeY);
		else if (poolingType == UseImageL2Pooling2x2)
			L2Pooling2x2(pFeatureMapArray[i].pValueArray, pUnpooledFeatureMapArray[i].pValueArray, UnpooledFeatureMapSizeX, UnpooledFeatureMapSizeY);



#ifdef NormalizeImageData
		if (poolingType == UseNoImagePooling)
			Normalize(pUnpooledFeatureMapArray[i].pValueArray, pUnpooledFeatureMapArray[i].pValueArray, UnpooledFeatureMapSize);
		else
			Normalize(pFeatureMapArray[i].pValueArray, pFeatureMapArray[i].pValueArray, FeatureMapSize);
#endif
	}

	if (poolingType == UseNoImagePooling)
	{
		uint32_t offset = *pInOutNeuronIDOffset;
		uint32_t deltaOffset = UnpooledFeatureMapSize;

		pBrain->Set_InputNeuronValues_And_Propagate_Them(pUnpooledFeatureMapArray[0].pValueArray, offset, UnpooledFeatureMapSize);

		for (uint32_t i = 1; i < NumFeatureMaps; i++)
		{
			offset += deltaOffset;
			pBrain->Set_InputNeuronValues_And_Propagate_Them(pUnpooledFeatureMapArray[i].pValueArray, offset, UnpooledFeatureMapSize);
		}

		*pInOutNeuronIDOffset = offset + deltaOffset;
	}
	else
	{
		uint32_t offset = *pInOutNeuronIDOffset;
		uint32_t deltaOffset = FeatureMapSize;

		pBrain->Set_InputNeuronValues_And_Propagate_Them(pFeatureMapArray[0].pValueArray, offset, FeatureMapSize);

		for (uint32_t i = 1; i < NumFeatureMaps; i++)
		{
			offset += deltaOffset;
			pBrain->Set_InputNeuronValues_And_Propagate_Them(pFeatureMapArray[i].pValueArray, offset, FeatureMapSize);
		}

		*pInOutNeuronIDOffset = offset + deltaOffset;
	}
}

void CImageDataPreprocessing::Train_Final_LocalReceptiveFields(CNeuralNet *pBrain, float learningRate, float receiverNeuronErrorFactor1, float receiverNeuronErrorFactor2, float inputErrorFactor1, float inputErrorFactor2, float outputErrorFactor1, float outputErrorFactor2)
{
	uint32_t firstReceiverNeuronID, lastReceiverNeuronID;

	uint32_t offset = 0;
	uint32_t deltaOffset = FeatureMapSize;

	for (uint32_t i = 0; i < NumFeatureMaps; i++)
	{
		firstReceiverNeuronID = offset;
		lastReceiverNeuronID = offset + deltaOffset;

		pLRFArray[i].Train_Final_LocalReceptiveField(pBrain, firstReceiverNeuronID, lastReceiverNeuronID, learningRate, receiverNeuronErrorFactor1, receiverNeuronErrorFactor2, inputErrorFactor1, inputErrorFactor2, outputErrorFactor1, outputErrorFactor2);

		offset += deltaOffset;
	}
}

void CImageDataPreprocessing::Train_Final_LocalReceptiveFields(CNeuralNet *pBrain, uint32_t *pInOutNeuronIDOffset, float learningRate, float receiverNeuronErrorFactor1, float receiverNeuronErrorFactor2, float inputErrorFactor1, float inputErrorFactor2, float outputErrorFactor1, float outputErrorFactor2)
{
	uint32_t firstReceiverNeuronID, lastReceiverNeuronID;

	uint32_t offset = *pInOutNeuronIDOffset;
	uint32_t deltaOffset = FeatureMapSize;

	for (uint32_t i = 0; i < NumFeatureMaps; i++)
	{
		firstReceiverNeuronID = offset;
		lastReceiverNeuronID = offset + deltaOffset;

		pLRFArray[i].Train_Final_LocalReceptiveField(pBrain, firstReceiverNeuronID, lastReceiverNeuronID, learningRate, receiverNeuronErrorFactor1, receiverNeuronErrorFactor2, inputErrorFactor1, inputErrorFactor2, outputErrorFactor1, outputErrorFactor2);

		offset += deltaOffset;
	}

	*pInOutNeuronIDOffset = offset;
}

void CImageDataPreprocessing::Train_LocalReceptiveFields(CImageDataPreprocessing* pPostDataPreprocessingStep, float learningRate, float inputErrorFactor1, float inputErrorFactor2, float outputErrorFactor1, float outputErrorFactor2)
{
	uint32_t numFeatureMapsInsidePostStep = pPostDataPreprocessingStep->NumFeatureMaps;

	for (uint32_t i = 0; i < NumFeatureMaps; i++)
	{
		pLRFArray[i].Begin_ErrorCalculation(&pPostDataPreprocessingStep->pLRFArray[0]);

		for (uint32_t j = 1; j < numFeatureMapsInsidePostStep; j++)
			pLRFArray[i].Continue_ErrorCalculation(&pPostDataPreprocessingStep->pLRFArray[j]);

		pLRFArray[i].Finish_ErrorCalculation(inputErrorFactor1, inputErrorFactor2, outputErrorFactor1, outputErrorFactor2);
		pLRFArray[i].Adjust_LocalReceptiveField_AfterErrorCalculations(learningRate);
	}
}

void CImageDataPreprocessing::Train_LocalReceptiveFields(CImageDataPreprocessing* pPostDataPreprocessingStep, uint32_t *pLRF_IDArray, uint32_t numOfPostConnectedLRFs, float learningRate, float inputErrorFactor1, float inputErrorFactor2, float outputErrorFactor1, float outputErrorFactor2)
{
	//uint32_t numFeatureMapsInsidePostStep = pPostDataPreprocessingStep->NumFeatureMaps;

	uint32_t lRF_ID;

	for (uint32_t i = 0; i < NumFeatureMaps; i++)
	{
		lRF_ID = pLRF_IDArray[0];

		pLRFArray[i].Begin_ErrorCalculation(&pPostDataPreprocessingStep->pLRFArray[0]);

		//for (uint32_t j = 1; j < numFeatureMapsInsidePostStep; j++)
		for (uint32_t j = 1; j < numOfPostConnectedLRFs; j++)
		{
			lRF_ID = pLRF_IDArray[j];

			pLRFArray[i].Continue_ErrorCalculation(&pPostDataPreprocessingStep->pLRFArray[lRF_ID]);
		}

		pLRFArray[i].Finish_ErrorCalculation(inputErrorFactor1, inputErrorFactor2, outputErrorFactor1, outputErrorFactor2);
		pLRFArray[i].Adjust_LocalReceptiveField_AfterErrorCalculations(learningRate);
	}
}






CShortTermMemoryElement::CShortTermMemoryElement()
{}

CShortTermMemoryElement::~CShortTermMemoryElement()
{
	delete[] pNeuronArray;
	pNeuronArray = nullptr;
}

void CShortTermMemoryElement::Set_MemoryNeuronActivationFunction(pActivationFunc pFunc, uint32_t idOfMemeoryNeuron)
{
	pNeuronArray[FirstMemoryNeuronID + idOfMemeoryNeuron].Set_ActivationFunction(pFunc);
}


void CShortTermMemoryElement::Set_OutputNeuronActivationFunction(pActivationFunc pFunc, uint32_t idOfOutputNeuron)
{
	pNeuronArray[FirstOutputNeuronID + idOfOutputNeuron].Set_ActivationFunction(pFunc);
}

void CShortTermMemoryElement::Reset_Memory(void)
{
	uint32_t id;

	for (uint32_t i = 0; i < NumOfMemoryNeurons; i++)
	{
		id = i + FirstMemoryNeuronID;
		pNeuronArray[id].Reset_NeuronInput();
		pNeuronArray[id].Reset_NeuronOutput();
	}
}

float CShortTermMemoryElement::Get_Actual_Output(void)
{
	//return pNeuronArray[FirstOutputNeuronID].Get_NeuronOutput();
	return pNeuronArray[FirstOutputNeuronID].NeuronOutput;
}

void CShortTermMemoryElement::Get_Actual_Output(float *pOutputValueArray)
{
	int32_t id;

	for (int32_t i = 0; i < NumOfOutputNeurons; i++)
	{
		id = i + FirstOutputNeuronID;
		pOutputValueArray[i] = pNeuronArray[id].NeuronOutput;
	}
}

float CShortTermMemoryElement::Get_MemoryNeuronOutput(uint32_t idOfMemeoryNeuron)
{
	//return pNeuronArray[FirstMemoryNeuronID + idOfMemeoryNeuron].Get_NeuronOutput();
	return pNeuronArray[FirstMemoryNeuronID + idOfMemeoryNeuron].NeuronOutput;
}

void CShortTermMemoryElement::Initialize_SingleInput_SingleOutput(uint32_t numOfMemoryNeurons, pActivationFunc pFunc, float memoryDrecreaseFactor)
{
	delete[] pNeuronArray;
	pNeuronArray = nullptr;

	NumOfOutputNeurons = 1;

	NumOfMemoryNeurons = max(1, numOfMemoryNeurons);

	NumOfNeurons = 2; //InputNeuron + OutputNeuron
	NumOfNeurons += NumOfMemoryNeurons;

	pNeuronArray = new (std::nothrow) CNeuron[NumOfNeurons];

	for (uint32_t i = 0; i < NumOfNeurons; i++)
		pNeuronArray[i].Connect_With_Brain(pNeuronArray);

	FirstMemoryNeuronID = 1;
	FirstOutputNeuronID = 1 + NumOfMemoryNeurons;

	pNeuronArray[0].Use_As_InputNeuron();
	pNeuronArray[0].Init_OutputSynapses(2);

	pNeuronArray[0].Set_OutputSynapsePlasticity(1.0f, /*synapseID:*/ 0);
	pNeuronArray[0].Connect_With_ReceiverNeuron(FirstMemoryNeuronID, /*synapseID:*/ 0);

	pNeuronArray[0].Set_OutputSynapsePlasticity(1.0f, /*synapseID:*/ 1);
	pNeuronArray[0].Connect_With_ReceiverNeuron(FirstOutputNeuronID, /*synapseID:*/ 1);



	pNeuronArray[FirstOutputNeuronID].Use_As_OutputNeuron();
	pNeuronArray[FirstOutputNeuronID].Set_ActivationFunction(pFunc);

	if (NumOfMemoryNeurons == 1)
	{
		uint32_t id = FirstMemoryNeuronID;

		pNeuronArray[id].Use_As_MemoryNeuron();
		pNeuronArray[id].Set_ActivationFunction(pFunc);
		pNeuronArray[id].Init_OutputSynapses(1);

		pNeuronArray[id].Set_OutputSynapsePlasticity(1.0f * memoryDrecreaseFactor, /*synapseID:*/ 0);
		pNeuronArray[id].Connect_With_ReceiverNeuron(FirstOutputNeuronID, /*synapseID:*/ 0);
	}
	else //if (NumOfMemoryNeurons > 1)
	{
		uint32_t id;

		uint32_t numOfMemoryNeuronsMinus1 = NumOfMemoryNeurons - 1;

		float weightFactor = memoryDrecreaseFactor;

		for (uint32_t i = 0; i < NumOfMemoryNeurons; i++)
		{
			id = i + FirstMemoryNeuronID;

			pNeuronArray[id].Use_As_MemoryNeuron();
			pNeuronArray[id].Set_ActivationFunction(pFunc);


			if (i < numOfMemoryNeuronsMinus1)
			{
				pNeuronArray[id].Init_OutputSynapses(2);

				pNeuronArray[id].Set_OutputSynapsePlasticity(1.0f * weightFactor, /*synapseID:*/ 0);
				pNeuronArray[id].Connect_With_ReceiverNeuron(FirstOutputNeuronID, /*synapseID:*/ 0);

				pNeuronArray[id].Set_OutputSynapsePlasticity(1.0f, /*synapseID:*/ 1);
				pNeuronArray[id].Connect_With_ReceiverNeuron(/*memoryNeuronID:*/ id + 1, /*synapseID:*/ 1);
			}
			else //if (i == numOfMemoryNeuronsMinus1)
			{
				pNeuronArray[id].Init_OutputSynapses(1);

				pNeuronArray[id].Set_OutputSynapsePlasticity(1.0f * weightFactor, /*synapseID:*/ 0);
				pNeuronArray[id].Connect_With_ReceiverNeuron(FirstOutputNeuronID, /*synapseID:*/ 0);
			}

			weightFactor *= memoryDrecreaseFactor;
		}
	}
}

void CShortTermMemoryElement::Initialize_SingleInput_SingleOutput(uint32_t numOfMemoryNeurons, pActivationFunc pFunc1, pActivationFunc pFunc_LastMemoryNeuron, float memoryDrecreaseFactor)
{
	delete[] pNeuronArray;
	pNeuronArray = nullptr;

	NumOfOutputNeurons = 1;

	NumOfMemoryNeurons = max(1, numOfMemoryNeurons);

	NumOfNeurons = 2; //InputNeuron + OutputNeuron
	NumOfNeurons += NumOfMemoryNeurons;

	pNeuronArray = new (std::nothrow) CNeuron[NumOfNeurons];

	for (uint32_t i = 0; i < NumOfNeurons; i++)
		pNeuronArray[i].Connect_With_Brain(pNeuronArray);

	FirstMemoryNeuronID = 1;
	FirstOutputNeuronID = 1 + NumOfMemoryNeurons;

	pNeuronArray[0].Use_As_InputNeuron();
	pNeuronArray[0].Init_OutputSynapses(2);

	pNeuronArray[0].Set_OutputSynapsePlasticity(1.0f, /*synapseID:*/ 0);
	pNeuronArray[0].Connect_With_ReceiverNeuron(FirstMemoryNeuronID, /*synapseID:*/ 0);

	pNeuronArray[0].Set_OutputSynapsePlasticity(1.0f, /*synapseID:*/ 1);
	pNeuronArray[0].Connect_With_ReceiverNeuron(FirstOutputNeuronID, /*synapseID:*/ 1);



	pNeuronArray[FirstOutputNeuronID].Use_As_OutputNeuron();
	pNeuronArray[FirstOutputNeuronID].Set_ActivationFunction(pFunc1);

	if (NumOfMemoryNeurons == 1)
	{
		uint32_t id = FirstMemoryNeuronID;

		pNeuronArray[id].Use_As_MemoryNeuron();
		pNeuronArray[id].Set_ActivationFunction(pFunc_LastMemoryNeuron);
		pNeuronArray[id].Init_OutputSynapses(1);

		pNeuronArray[id].Set_OutputSynapsePlasticity(1.0f * memoryDrecreaseFactor, /*synapseID:*/ 0);
		pNeuronArray[id].Connect_With_ReceiverNeuron(FirstOutputNeuronID, /*synapseID:*/ 0);
	}
	else //if (NumOfMemoryNeurons > 1)
	{
		uint32_t id;

		uint32_t numOfMemoryNeuronsMinus1 = NumOfMemoryNeurons - 1;

		float weightFactor = memoryDrecreaseFactor;

		for (uint32_t i = 0; i < NumOfMemoryNeurons; i++)
		{
			id = i + FirstMemoryNeuronID;

			pNeuronArray[id].Use_As_MemoryNeuron();


			if (i < numOfMemoryNeuronsMinus1)
			{
				pNeuronArray[id].Set_ActivationFunction(pFunc1);

				pNeuronArray[id].Init_OutputSynapses(1);

				pNeuronArray[id].Set_OutputSynapsePlasticity(1.0f * weightFactor, /*synapseID:*/ 0);
				pNeuronArray[id].Connect_With_ReceiverNeuron(/*memoryNeuronID:*/ id + 1, /*synapseID:*/ 0);
			}
			else //if (i == numOfMemoryNeuronsMinus1)
			{
				pNeuronArray[id].Set_ActivationFunction(pFunc_LastMemoryNeuron);

				pNeuronArray[id].Init_OutputSynapses(1);

				pNeuronArray[id].Set_OutputSynapsePlasticity(1.0f * weightFactor, /*synapseID:*/ 0);
				pNeuronArray[id].Connect_With_ReceiverNeuron(FirstOutputNeuronID, /*synapseID:*/ 0);
			}

			weightFactor *= memoryDrecreaseFactor;
		}
	}
}

void CShortTermMemoryElement::Initialize_SingleInput_OutputArray(uint32_t numOfOutputNeurons, pActivationFunc pFunc, float memoryDrecreaseFactor)
{
	delete[] pNeuronArray;
	pNeuronArray = nullptr;

	NumOfOutputNeurons = max(2, numOfOutputNeurons);



	NumOfMemoryNeurons = NumOfOutputNeurons - 1;

	NumOfNeurons = 1; //InputNeuron
	NumOfNeurons += NumOfMemoryNeurons;
	NumOfNeurons += NumOfOutputNeurons;

	pNeuronArray = new (std::nothrow) CNeuron[NumOfNeurons];

	for (uint32_t i = 0; i < NumOfNeurons; i++)
		pNeuronArray[i].Connect_With_Brain(pNeuronArray);

	FirstMemoryNeuronID = 1;
	FirstOutputNeuronID = 1 + NumOfMemoryNeurons;

	pNeuronArray[0].Use_As_InputNeuron();
	pNeuronArray[0].Init_OutputSynapses(2);

	pNeuronArray[0].Set_OutputSynapsePlasticity(1.0f, /*synapseID:*/ 0);
	pNeuronArray[0].Connect_With_ReceiverNeuron(FirstMemoryNeuronID, /*synapseID:*/ 0);

	pNeuronArray[0].Set_OutputSynapsePlasticity(1.0f, /*synapseID:*/ 1);
	pNeuronArray[0].Connect_With_ReceiverNeuron(FirstOutputNeuronID, /*synapseID:*/ 1);

	uint32_t id;

	for (uint32_t i = 0; i < NumOfOutputNeurons; i++)
	{
		id = i + FirstOutputNeuronID;

		pNeuronArray[id].Use_As_OutputNeuron();
		pNeuronArray[id].Set_ActivationFunction(pFunc);
	}

	uint32_t numOfMemoryNeuronsMinus1 = NumOfMemoryNeurons - 1;

	float weightFactor = memoryDrecreaseFactor;

	for (uint32_t i = 0; i < NumOfMemoryNeurons; i++)
	{
		id = i + FirstMemoryNeuronID;

		pNeuronArray[id].Use_As_MemoryNeuron();
		pNeuronArray[id].Set_ActivationFunction(pFunc);

		if (i < numOfMemoryNeuronsMinus1)
		{
			pNeuronArray[id].Init_OutputSynapses(2);

			pNeuronArray[id].Set_OutputSynapsePlasticity(1.0f * weightFactor, /*synapseID:*/ 0);
			pNeuronArray[id].Connect_With_ReceiverNeuron(i + 1 + FirstOutputNeuronID, /*synapseID:*/ 0);

			pNeuronArray[id].Set_OutputSynapsePlasticity(1.0f, /*synapseID:*/ 1);
			pNeuronArray[id].Connect_With_ReceiverNeuron(/*memoryNeuronID:*/ id + 1, /*synapseID:*/ 1);
		}
		else //if (i == numOfMemoryNeuronsMinus1)
		{
			pNeuronArray[id].Init_OutputSynapses(1);

			pNeuronArray[id].Set_OutputSynapsePlasticity(1.0f * weightFactor, /*synapseID:*/ 0);
			pNeuronArray[id].Connect_With_ReceiverNeuron(i + 1 + FirstOutputNeuronID, /*synapseID:*/ 0);
		}

		weightFactor *= memoryDrecreaseFactor;
	}
}

float CShortTermMemoryElement::Calculate_Output(float inputValue)
{
	if (NumOfMemoryNeurons == 1)
	{
		//if (accumulateInput == false)
		pNeuronArray[FirstMemoryNeuronID].Calculate_NeuronOutput();
		//else
		//pNeuronArray[FirstMemoryNeuronID].Calculate_NeuronOutput_And_Retain_Input();

		pNeuronArray[FirstMemoryNeuronID].Propagate_SynapticOutput();


		pNeuronArray[0].Set_Input(inputValue);
		pNeuronArray[0].Propagate_SynapticOutput();

		pNeuronArray[FirstOutputNeuronID].Calculate_NeuronOutput();

		//return pNeuronArray[FirstOutputNeuronID].Get_NeuronOutput();
		return pNeuronArray[FirstOutputNeuronID].NeuronOutput;
	}
	else //if (NumOfMemoryNeurons > 1)
	{
		int32_t id;

		for (int32_t i = NumOfMemoryNeurons - 1; i > -1; i--)
		{
			id = i + FirstMemoryNeuronID;

			//if (accumulateInput == false)
			pNeuronArray[id].Calculate_NeuronOutput();
			//else
			//pNeuronArray[id].Calculate_NeuronOutput_And_Retain_Input();

			pNeuronArray[id].Propagate_SynapticOutput();
		}



		pNeuronArray[0].Set_Input(inputValue);
		pNeuronArray[0].Propagate_SynapticOutput();

		pNeuronArray[FirstOutputNeuronID].Calculate_NeuronOutput();

		//return pNeuronArray[FirstOutputNeuronID].Get_NeuronOutput();
		return pNeuronArray[FirstOutputNeuronID].NeuronOutput;
	}
}

void CShortTermMemoryElement::Calculate_Output(float *pOutputValueArray, float inputValue)
{
	int32_t id;


	for (int32_t i = NumOfMemoryNeurons - 1; i > -1; i--)
	{
		id = i + FirstMemoryNeuronID;

		pNeuronArray[id].Calculate_NeuronOutput();
		pNeuronArray[id].Propagate_SynapticOutput();
	}

	pNeuronArray[0].Set_Input(inputValue);
	pNeuronArray[0].Propagate_SynapticOutput();


	for (int32_t i = 0; i < NumOfOutputNeurons; i++)
	{
		id = i + FirstOutputNeuronID;

		pNeuronArray[id].Calculate_NeuronOutput();

		pOutputValueArray[i] = pNeuronArray[id].NeuronOutput;
	}
}



CNeuralNetPopulation::CNeuralNetPopulation()
{}

CNeuralNetPopulation::~CNeuralNetPopulation()
{
	delete[] pFitnessScoreArray;
	pFitnessScoreArray = nullptr;

	delete[] ppUsedNeuralNetArray;
	ppUsedNeuralNetArray = nullptr;
}

void CNeuralNetPopulation::Initialize(uint32_t populationSize, uint32_t numOfInputNeurons, uint32_t numOfOutputNeurons, uint32_t minNumOfHiddenNeuronsL1, uint32_t maxNumOfHiddenNeuronsL1, uint32_t minNumOfHiddenNeuronsL2, uint32_t maxNumOfHiddenNeuronsL2, pActivationFunc pOutputNeuronFunc, pActivationFunc pHiddenLayer1NeuronFunc, pActivationFunc pHiddenLayer2NeuronFunc)
{
	delete[] pFitnessScoreArray;
	pFitnessScoreArray = nullptr;

	delete[] ppUsedNeuralNetArray;
	ppUsedNeuralNetArray = nullptr;

	//pOutputNeuronActivationFunc = pOutputNeuronFunc;
	//pHiddenLayer1NeuronActivationFunc = pHiddenLayer1NeuronFunc;
	//pHiddenLayer2NeuronActivationFunc = pHiddenLayer2NeuronFunc;

	Set_Activationfunction_OutputLayerNeuron(pOutputNeuronFunc);
	Set_Activationfunction_HiddenLayer1Neuron(pHiddenLayer1NeuronFunc);
	Set_Activationfunction_HiddenLayer2Neuron(pHiddenLayer2NeuronFunc);
	

	PopulationSize = populationSize;
	PopulationSizePlus4 = populationSize + 4;

	pFitnessScoreArray = new (std::nothrow) float[PopulationSizePlus4];
	ppUsedNeuralNetArray = new (std::nothrow) CNeuralNet*[PopulationSizePlus4];
	
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		ppUsedNeuralNetArray[i] = nullptr;
		pFitnessScoreArray[i] = 0.0f;
	}

	NumOfInputNeurons = numOfInputNeurons;
	NumOfOutputNeurons = numOfOutputNeurons;

	MinNumOfHiddenNeuronsL1 = minNumOfHiddenNeuronsL1;
	MaxNumOfHiddenNeuronsL1 = maxNumOfHiddenNeuronsL1;

	MinNumOfHiddenNeuronsL2 = minNumOfHiddenNeuronsL2;
	MaxNumOfHiddenNeuronsL2 = maxNumOfHiddenNeuronsL2;

	for (uint32_t i = 0; i < constNumOfBestFittedBrains; i++)
	{
		IDArrayOfBestFittedBrains[i] = 0;
		FitnessArrayOfBestFittedBrains[i] = -100000000.0f;
	}

	for (uint32_t i = 0; i < constNumOfWorstFittedBrains; i++)
	{
		IDArrayOfWorstFittedBrains[i] = 0;
		FitnessArrayOfWorstFittedBrains[i] = 100000000.0f;
	}

	UseAdditionalMutatedBestBrain = false;
	UseAdditionalMutatedSecondBestBrain = false;
	UseAdditionalBestBrainsChild = false;

	for (uint32_t i = 0; i < constNumOfRandomBrainsChilds; i++)
		UseAdditionalRandomBrainsChild[i] = false;
}

void CNeuralNetPopulation::Update_Evolution_SecondBestBrainOnly_Ext(float minSynapticPlasticityVariance, float maxSynapticPlasticityVariance, float mutationRateL1, float mutationRateL2, float mutationRateL3)
{
	if (UseAdditionalMutatedSecondBestBrain == true)
		return;

	Reinitialize_NeuralNet(PopulationSize + 1, ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[1]]->HiddenLayer1.NumOfNeurons, ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[1]]->HiddenLayer2.NumOfNeurons);

	ppUsedNeuralNetArray[PopulationSize + 1]->Clone_OutputSynapsePlasticities_InputLayer(ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[1]], minSynapticPlasticityVariance, maxSynapticPlasticityVariance, mutationRateL1, Seed++);

	ppUsedNeuralNetArray[PopulationSize + 1]->Clone_OutputSynapsePlasticities_HiddenLayer1(ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[1]], minSynapticPlasticityVariance, maxSynapticPlasticityVariance, mutationRateL2, Seed++);

	ppUsedNeuralNetArray[PopulationSize + 1]->Clone_OutputSynapsePlasticities_HiddenLayer2(ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[1]], minSynapticPlasticityVariance, maxSynapticPlasticityVariance, mutationRateL3, Seed++);

	UseAdditionalMutatedSecondBestBrain = true;
}

void CNeuralNetPopulation::Update_Evolution_SecondBestBrainOnly_Ext(float minSynapticPlasticityVariance, float maxSynapticPlasticityVariance, float mutationRate)
{
	if (UseAdditionalMutatedSecondBestBrain == true)
		return;

	Reinitialize_NeuralNet(PopulationSize + 1, ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[1]]->HiddenLayer1.NumOfNeurons, ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[1]]->HiddenLayer2.NumOfNeurons);

	ppUsedNeuralNetArray[PopulationSize + 1]->Clone_OutputSynapsePlasticities(ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[1]], minSynapticPlasticityVariance, maxSynapticPlasticityVariance, mutationRate, Seed++);

	UseAdditionalMutatedSecondBestBrain = true;
}

void CNeuralNetPopulation::Update_Evolution_BestBrainOnly_Ext(float minSynapticPlasticityVariance, float maxSynapticPlasticityVariance, float mutationRateL1, float mutationRateL2, float mutationRateL3)
{
	if (UseAdditionalMutatedBestBrain == true)
		return;

	Reinitialize_NeuralNet(PopulationSize, ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[0]]->HiddenLayer1.NumOfNeurons, ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[0]]->HiddenLayer2.NumOfNeurons);

	ppUsedNeuralNetArray[PopulationSize]->Clone_OutputSynapsePlasticities_InputLayer(ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[0]], minSynapticPlasticityVariance, maxSynapticPlasticityVariance, mutationRateL1, Seed++);

	ppUsedNeuralNetArray[PopulationSize]->Clone_OutputSynapsePlasticities_HiddenLayer1(ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[0]], minSynapticPlasticityVariance, maxSynapticPlasticityVariance, mutationRateL2, Seed++);

	ppUsedNeuralNetArray[PopulationSize]->Clone_OutputSynapsePlasticities_HiddenLayer2(ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[0]], minSynapticPlasticityVariance, maxSynapticPlasticityVariance, mutationRateL3, Seed++);

	UseAdditionalMutatedBestBrain = true;
}

void CNeuralNetPopulation::Update_Evolution_BestBrainOnly_Ext(float minSynapticPlasticityVariance, float maxSynapticPlasticityVariance, float mutationRate)
{
	if (UseAdditionalMutatedBestBrain == true)
		return;

	Reinitialize_NeuralNet(PopulationSize, ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[0]]->HiddenLayer1.NumOfNeurons, ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[0]]->HiddenLayer2.NumOfNeurons);

	ppUsedNeuralNetArray[PopulationSize]->Clone_OutputSynapsePlasticities(ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[0]], minSynapticPlasticityVariance, maxSynapticPlasticityVariance, mutationRate, Seed++);

	UseAdditionalMutatedBestBrain = true;
}

void CNeuralNetPopulation::Update_Evolution_BestBrainOnly(float minSynapticPlasticityVariance, float maxSynapticPlasticityVariance, float mutationRateL1, float mutationRateL2, float mutationRateL3)
{
	if (UseAdditionalMutatedBestBrain == true)
		return;

	ppUsedNeuralNetArray[PopulationSize]->Clone_OutputSynapsePlasticities_InputLayer(ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[0]], minSynapticPlasticityVariance, maxSynapticPlasticityVariance, mutationRateL1, Seed++);

	ppUsedNeuralNetArray[PopulationSize]->Clone_OutputSynapsePlasticities_HiddenLayer1(ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[0]], minSynapticPlasticityVariance, maxSynapticPlasticityVariance, mutationRateL2, Seed++);

	ppUsedNeuralNetArray[PopulationSize]->Clone_OutputSynapsePlasticities_HiddenLayer2(ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[0]], minSynapticPlasticityVariance, maxSynapticPlasticityVariance, mutationRateL3, Seed++);

	UseAdditionalMutatedBestBrain = true;
}

void CNeuralNetPopulation::Update_Evolution_SecondBestBrainOnly(float minSynapticPlasticityVariance, float maxSynapticPlasticityVariance, float mutationRateL1, float mutationRateL2, float mutationRateL3)
{
	if (UseAdditionalMutatedBestBrain == true)
		return;

	ppUsedNeuralNetArray[PopulationSize + 1]->Clone_OutputSynapsePlasticities_InputLayer(ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[1]], minSynapticPlasticityVariance, maxSynapticPlasticityVariance, mutationRateL1, Seed++);

	ppUsedNeuralNetArray[PopulationSize + 1]->Clone_OutputSynapsePlasticities_HiddenLayer1(ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[1]], minSynapticPlasticityVariance, maxSynapticPlasticityVariance, mutationRateL2, Seed++);

	ppUsedNeuralNetArray[PopulationSize + 1]->Clone_OutputSynapsePlasticities_HiddenLayer2(ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[1]], minSynapticPlasticityVariance, maxSynapticPlasticityVariance, mutationRateL3, Seed++);

	UseAdditionalMutatedBestBrain = true;
}

void CNeuralNetPopulation::Update_Evolution_BestBrainOnly(float minSynapticPlasticityVariance, float maxSynapticPlasticityVariance, float mutationRate)
{
	if (UseAdditionalMutatedBestBrain == true)
		return;

	ppUsedNeuralNetArray[PopulationSize]->Clone_OutputSynapsePlasticities(ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[0]], minSynapticPlasticityVariance, maxSynapticPlasticityVariance, mutationRate, Seed++);

	UseAdditionalMutatedBestBrain = true;
}

void CNeuralNetPopulation::Update_Evolution_SecondBestBrainOnly(float minSynapticPlasticityVariance, float maxSynapticPlasticityVariance, float mutationRate)
{
	if (UseAdditionalMutatedBestBrain == true)
		return;

	ppUsedNeuralNetArray[PopulationSize + 1]->Clone_OutputSynapsePlasticities(ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[1]], minSynapticPlasticityVariance, maxSynapticPlasticityVariance, mutationRate, Seed++);

	UseAdditionalMutatedBestBrain = true;
}

void CNeuralNetPopulation::Update_Evolution_SynapticPlasticityMutationsOnly(float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRateL1, float mutationRateL2, float mutationRateL3, bool extremeLearning)
{
	bool bestFittedBrains;
	uint32_t j;

	if (extremeLearning == false)
	{
		for (uint32_t i = 0; i < PopulationSize; i++)
		{
			bestFittedBrains = false;

			for (uint32_t j = 0; j < constNumOfBestFittedBrains; j++)
			{
				if (i == IDArrayOfBestFittedBrains[j])
				{
					bestFittedBrains = true;
					break;
				}
			}

			if (bestFittedBrains == false)
			{
				ppUsedNeuralNetArray[i]->RandomChange_OutputSynapsePlasticities_InputLayer(Seed++, minSynapticPlasticity, maxSynapticPlasticity, mutationRateL1);
				ppUsedNeuralNetArray[i]->RandomChange_OutputSynapsePlasticities_HiddenLayer1(Seed++, minSynapticPlasticity, maxSynapticPlasticity, mutationRateL2);
				ppUsedNeuralNetArray[i]->RandomChange_OutputSynapsePlasticities_HiddenLayer2(Seed++, minSynapticPlasticity, maxSynapticPlasticity, mutationRateL3);
			}
		}
	}
	else if (extremeLearning == true)
	{
		for (uint32_t i = 0; i < PopulationSize; i++)
		{
			bestFittedBrains = false;

			for (uint32_t j = 0; j < constNumOfBestFittedBrains; j++)
			{
				if (i == IDArrayOfBestFittedBrains[j])
				{
					bestFittedBrains = true;
					break;
				}
			}

			if (bestFittedBrains == false)
			{
				uint32_t numOfHiddenNeuronsL1 = ppUsedNeuralNetArray[i]->HiddenLayer1.NumOfNeurons;
				uint32_t numOfHiddenNeuronsL2 = ppUsedNeuralNetArray[i]->HiddenLayer2.NumOfNeurons;

				if (numOfHiddenNeuronsL2 == 0)
				{
					ppUsedNeuralNetArray[i]->RandomChange_OutputSynapsePlasticities_HiddenLayer1(Seed++, minSynapticPlasticity, maxSynapticPlasticity, mutationRateL2);
				}
				else
				{
					ppUsedNeuralNetArray[i]->RandomChange_OutputSynapsePlasticities_HiddenLayer2(Seed++, minSynapticPlasticity, maxSynapticPlasticity, mutationRateL3);
				}
			}
		}
	}
}

void CNeuralNetPopulation::Update_Evolution_SynapticPlasticityMutationsOnly(float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRate, bool extremeLearning)
{
	bool bestFittedBrains;
	

	if (extremeLearning == false)
	{
		for (uint32_t i = 0; i < PopulationSize; i++)
		{
			bestFittedBrains = false;

			for (uint32_t j = 0; j < constNumOfBestFittedBrains; j++)
			{
				if (i == IDArrayOfBestFittedBrains[j])
				{
					bestFittedBrains = true;
					break;
				}
			}

			if (bestFittedBrains == false)
			{
				ppUsedNeuralNetArray[i]->RandomChange_OutputSynapsePlasticities(Seed++, minSynapticPlasticity, maxSynapticPlasticity, mutationRate);
			}
		}
	}
	else if (extremeLearning == true)
	{
		for (uint32_t i = 0; i < PopulationSize; i++)
		{
			bestFittedBrains = false;

			for (uint32_t j = 0; j < constNumOfBestFittedBrains; j++)
			{
				if (i == IDArrayOfBestFittedBrains[j])
				{
					bestFittedBrains = true;
					break;
				}
			}

			if (bestFittedBrains == false)
			{
				uint32_t numOfHiddenNeuronsL1 = ppUsedNeuralNetArray[i]->HiddenLayer1.NumOfNeurons;
				uint32_t numOfHiddenNeuronsL2 = ppUsedNeuralNetArray[i]->HiddenLayer2.NumOfNeurons;

				if (numOfHiddenNeuronsL2 == 0)
				{
					ppUsedNeuralNetArray[i]->RandomChange_OutputSynapsePlasticities_HiddenLayer1(Seed++, minSynapticPlasticity, maxSynapticPlasticity, mutationRate);
				}
				else
				{
					ppUsedNeuralNetArray[i]->RandomChange_OutputSynapsePlasticities_HiddenLayer2(Seed++, minSynapticPlasticity, maxSynapticPlasticity, mutationRate);
				}
			}
		}
	}
}

void CNeuralNetPopulation::Update_Evolution_ConnectionTopologyMutationsOnly(float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRateL1, float mutationRateL2, float mutationRateL3, bool reduceNeuralConnections)
{
	if (reduceNeuralConnections == true)
	{
		bool bestFittedBrains;
		

		for (uint32_t i = 0; i < PopulationSize; i++)
		{
			bestFittedBrains = false;

			for (uint32_t j = 0; j < constNumOfBestFittedBrains; j++)
			{
				if (i == IDArrayOfBestFittedBrains[j])
				{
					bestFittedBrains = true;
					break;
				}
			}

			if (bestFittedBrains == false)
			{
				ppUsedNeuralNetArray[i]->Disable_Random_InputNeuron_OutputSynapses(Seed++, mutationRateL1);
				ppUsedNeuralNetArray[i]->Disable_Random_HiddenLayer1Neuron_OutputSynapses(Seed++, mutationRateL2);
				ppUsedNeuralNetArray[i]->Disable_Random_HiddenLayer2Neuron_OutputSynapses(Seed++, mutationRateL3);
			}
		}
	}
	else if (reduceNeuralConnections == false)
	{
		bool bestFittedBrains;
		

		for (uint32_t i = 0; i < PopulationSize; i++)
		{
			bestFittedBrains = false;

			for (uint32_t j = 0; j < constNumOfBestFittedBrains; j++)
			{
				if (i == IDArrayOfBestFittedBrains[j])
				{
					bestFittedBrains = true;
					break;
				}
			}

			if (bestFittedBrains == false)
			{
				ppUsedNeuralNetArray[i]->Enable_Disabled_InputNeuron_OutputSynapses(Seed++, minSynapticPlasticity, maxSynapticPlasticity, mutationRateL1);
				ppUsedNeuralNetArray[i]->Enable_Disabled_HiddenLayer1Neuron_OutputSynapses(Seed++, minSynapticPlasticity, maxSynapticPlasticity, mutationRateL2);
				ppUsedNeuralNetArray[i]->Enable_Disabled_HiddenLayer2Neuron_OutputSynapses(Seed++, minSynapticPlasticity, maxSynapticPlasticity, mutationRateL3);
			}
		}
	}
}

void CNeuralNetPopulation::Update_Evolution_Combine_TwoBrains_Ext(void)
{
	if (UseAdditionalRandomBrainsChild[0] == true)
		return;

	int32_t id1, id2;

	uint32_t numOfHiddenNeuronsL1_Brain1;
	uint32_t numOfHiddenNeuronsL2_Brain1;

	uint32_t numOfHiddenNeuronsL1_Brain2;
	uint32_t numOfHiddenNeuronsL2_Brain2;


	for (uint32_t i = 0; i < constNumPopulationSearchStepsMax; i++)
	{
		id1 = RandomNumbers.Get_IntegerNumber(0, PopulationSize);

		if (pFitnessScoreArray[id1] <= FitnessArrayOfWorstFittedBrains[constNumOfWorstFittedBrains - 1])
			continue;

		id2 = RandomNumbers.Get_IntegerNumber(0, PopulationSize);

		if (pFitnessScoreArray[id2] <= FitnessArrayOfWorstFittedBrains[constNumOfWorstFittedBrains - 1])
			continue;

		if (id1 == id2)
			continue;

		numOfHiddenNeuronsL1_Brain1 = ppUsedNeuralNetArray[id1]->HiddenLayer1.NumOfNeurons;
		numOfHiddenNeuronsL1_Brain2 = ppUsedNeuralNetArray[id2]->HiddenLayer1.NumOfNeurons;

		if (numOfHiddenNeuronsL1_Brain1 != numOfHiddenNeuronsL1_Brain2)
			continue;

		numOfHiddenNeuronsL2_Brain1 = ppUsedNeuralNetArray[id1]->HiddenLayer2.NumOfNeurons;
		numOfHiddenNeuronsL2_Brain2 = ppUsedNeuralNetArray[id2]->HiddenLayer2.NumOfNeurons;

		if (numOfHiddenNeuronsL2_Brain1 != numOfHiddenNeuronsL2_Brain2)
			continue;

		Reinitialize_NeuralNet(PopulationSize + 3, numOfHiddenNeuronsL1_Brain1, numOfHiddenNeuronsL2_Brain1);

		ppUsedNeuralNetArray[PopulationSize + 3]->Combine_OutputSynapsePlasticities(ppUsedNeuralNetArray[id1],
			ppUsedNeuralNetArray[id2], 0.0f, Seed++);

		UseAdditionalRandomBrainsChild[0] = true;
		break;
	}
}

void CNeuralNetPopulation::Update_Evolution_Combine_TwoBrains(void)
{
	if (UseAdditionalRandomBrainsChild[0] == true)
		return;

	int32_t id1, id2;

	for (uint32_t i = 0; i < constNumPopulationSearchStepsMax; i++)
	{
		id1 = RandomNumbers.Get_IntegerNumber(0, PopulationSize);

		if (pFitnessScoreArray[id1] <= FitnessArrayOfWorstFittedBrains[constNumOfWorstFittedBrains - 1])
			continue;

		id2 = RandomNumbers.Get_IntegerNumber(0, PopulationSize);

		if (pFitnessScoreArray[id2] <= FitnessArrayOfWorstFittedBrains[constNumOfWorstFittedBrains - 1])
			continue;

		if (id1 == id2)
			continue;

		ppUsedNeuralNetArray[PopulationSize + 3]->Combine_OutputSynapsePlasticities(ppUsedNeuralNetArray[id1],
			ppUsedNeuralNetArray[id2], 0.0f, Seed++);

		UseAdditionalRandomBrainsChild[0] = true;
		break;
	}
}

void CNeuralNetPopulation::Update_Evolution_Combine_BestTwoBrains_Ext(void)
{
	if (UseAdditionalBestBrainsChild == true)
		return;

	uint32_t numOfHiddenNeuronsL1 = ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[0]]->HiddenLayer1.NumOfNeurons;
	uint32_t numOfHiddenNeuronsL2 = ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[0]]->HiddenLayer2.NumOfNeurons;

	if (numOfHiddenNeuronsL1 == ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[1]]->HiddenLayer1.NumOfNeurons)
	{
		if (numOfHiddenNeuronsL2 == ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[1]]->HiddenLayer2.NumOfNeurons)
		{
			Reinitialize_NeuralNet(PopulationSize + 2, numOfHiddenNeuronsL1, numOfHiddenNeuronsL2);

			ppUsedNeuralNetArray[PopulationSize + 2]->Combine_OutputSynapsePlasticities(ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[0]],
				ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[1]], 0.0f, Seed++);

			UseAdditionalBestBrainsChild = true;
		}
	}

	if (UseAdditionalBestBrainsChild == false)
	{
		if (numOfHiddenNeuronsL1 == ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[2]]->HiddenLayer1.NumOfNeurons)
		{
			if (numOfHiddenNeuronsL2 == ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[2]]->HiddenLayer2.NumOfNeurons)
			{
				Reinitialize_NeuralNet(PopulationSize + 2, numOfHiddenNeuronsL1, numOfHiddenNeuronsL2);

				ppUsedNeuralNetArray[PopulationSize + 2]->Combine_OutputSynapsePlasticities(ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[0]],
					ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[2]], 0.0f, Seed++);

				UseAdditionalBestBrainsChild = true;
			}
		}
	}
}

void CNeuralNetPopulation::Update_Evolution_Combine_BestTwoBrains(void)
{
	if (UseAdditionalBestBrainsChild == true)
		return;

	ppUsedNeuralNetArray[PopulationSize + 2]->Combine_OutputSynapsePlasticities(ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[0]],
		ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[1]], 0.0f, Seed++);

	UseAdditionalBestBrainsChild = true;
}

void CNeuralNetPopulation::Update_Population_Ext(float *pFitnessValueArray)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		pFitnessScoreArray[i] = pFitnessValueArray[i];
	}

	for (uint32_t i = 0; i < constNumOfBestFittedBrains; i++)
	{
		IDArrayOfBestFittedBrains[i] = 0;
		FitnessArrayOfBestFittedBrains[i] = -100000000.0f;
	}

	for (uint32_t i = 0; i < constNumOfWorstFittedBrains; i++)
	{
		IDArrayOfWorstFittedBrains[i] = 0;
		FitnessArrayOfWorstFittedBrains[i] = 100000000.0f;
	}

	for (uint32_t i = 0; i < PopulationSize; i++)
	{
		for (uint32_t j = 0; j < constNumOfBestFittedBrains; j++)
		{
			if (pFitnessScoreArray[i] > FitnessArrayOfBestFittedBrains[j])
			{
				for (uint32_t k = constNumOfBestFittedBrains - 1; k > j; k--)
				{
					IDArrayOfBestFittedBrains[k] = IDArrayOfBestFittedBrains[k - 1];
					FitnessArrayOfBestFittedBrains[k] = FitnessArrayOfBestFittedBrains[k - 1];
				}

				FitnessArrayOfBestFittedBrains[j] = pFitnessScoreArray[i];
				IDArrayOfBestFittedBrains[j] = i;

				break;
			}
		}

		for (uint32_t j = 0; j < constNumOfWorstFittedBrains; j++)
		{
			if (pFitnessScoreArray[i] < FitnessArrayOfWorstFittedBrains[j])
			{
				for (uint32_t k = constNumOfWorstFittedBrains - 1; k > j; k--)
				{
					IDArrayOfWorstFittedBrains[k] = IDArrayOfWorstFittedBrains[k - 1];
					FitnessArrayOfWorstFittedBrains[k] = FitnessArrayOfWorstFittedBrains[k - 1];
				}

				FitnessArrayOfWorstFittedBrains[j] = pFitnessScoreArray[i];
				IDArrayOfWorstFittedBrains[j] = i;

				break;
			}
		}

	} // end of for (uint32_t i = 0; i < PopulationSize; i++)




	float fitnessValueOfBestFittedAdditionalBrain = -1000000.0f;
	int32_t idOfBestFittedAdditionalBrain = 0;

	for (int32_t i = 0; i < 4; i++)
	{
		if (pFitnessScoreArray[PopulationSize + i] > fitnessValueOfBestFittedAdditionalBrain)
		{
			fitnessValueOfBestFittedAdditionalBrain = pFitnessScoreArray[PopulationSize + i];
			idOfBestFittedAdditionalBrain = PopulationSize + i;
		}
	}

	uint32_t numOfHiddenNeuronsL1_Brain1 = ppUsedNeuralNetArray[idOfBestFittedAdditionalBrain]->HiddenLayer1.NumOfNeurons;
	uint32_t numOfHiddenNeuronsL2_Brain1 = ppUsedNeuralNetArray[idOfBestFittedAdditionalBrain]->HiddenLayer2.NumOfNeurons;

	if (pFitnessScoreArray[idOfBestFittedAdditionalBrain] > pFitnessScoreArray[IDArrayOfBestFittedBrains[0]])
	{
		Reinitialize_NeuralNet(IDArrayOfBestFittedBrains[0], numOfHiddenNeuronsL1_Brain1, numOfHiddenNeuronsL2_Brain1);
		ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[0]]->Clone_OutputSynapsePlasticities(ppUsedNeuralNetArray[idOfBestFittedAdditionalBrain]);
	}
	else if (pFitnessScoreArray[idOfBestFittedAdditionalBrain] > pFitnessScoreArray[IDArrayOfBestFittedBrains[1]])
	{
		Reinitialize_NeuralNet(IDArrayOfBestFittedBrains[1], numOfHiddenNeuronsL1_Brain1, numOfHiddenNeuronsL2_Brain1);
		ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[1]]->Clone_OutputSynapsePlasticities(ppUsedNeuralNetArray[idOfBestFittedAdditionalBrain]);
	}
	else if (pFitnessScoreArray[idOfBestFittedAdditionalBrain] > pFitnessScoreArray[IDArrayOfBestFittedBrains[2]])
	{
		Reinitialize_NeuralNet(IDArrayOfBestFittedBrains[2], numOfHiddenNeuronsL1_Brain1, numOfHiddenNeuronsL2_Brain1);
		ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[2]]->Clone_OutputSynapsePlasticities(ppUsedNeuralNetArray[idOfBestFittedAdditionalBrain]);
	}

	UseAdditionalMutatedBestBrain = false;
	UseAdditionalMutatedSecondBestBrain = false;
	UseAdditionalBestBrainsChild = false;

	for (uint32_t i = 0; i < constNumOfRandomBrainsChilds; i++)
		UseAdditionalRandomBrainsChild[i] = false;
}

void CNeuralNetPopulation::Update_Population(float *pFitnessValueArray)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		pFitnessScoreArray[i] = pFitnessValueArray[i];
	}

	for (uint32_t i = 0; i < constNumOfBestFittedBrains; i++)
	{
		IDArrayOfBestFittedBrains[i] = 0;
		FitnessArrayOfBestFittedBrains[i] = -100000000.0f;
	}

	for (uint32_t i = 0; i < constNumOfWorstFittedBrains; i++)
	{
		IDArrayOfWorstFittedBrains[i] = 0;
		FitnessArrayOfWorstFittedBrains[i] = 100000000.0f;
	}

	for (uint32_t i = 0; i < PopulationSize; i++)
	{
		for (uint32_t j = 0; j < constNumOfBestFittedBrains; j++)
		{
			if (pFitnessScoreArray[i] > FitnessArrayOfBestFittedBrains[j])
			{
				for (uint32_t k = constNumOfBestFittedBrains - 1; k > j; k--)
				{
					IDArrayOfBestFittedBrains[k] = IDArrayOfBestFittedBrains[k - 1];
					FitnessArrayOfBestFittedBrains[k] = FitnessArrayOfBestFittedBrains[k - 1];
				}

				FitnessArrayOfBestFittedBrains[j] = pFitnessScoreArray[i];
				IDArrayOfBestFittedBrains[j] = i;

				break;
			}
		}

		for (uint32_t j = 0; j < constNumOfWorstFittedBrains; j++)
		{
			if (pFitnessScoreArray[i] < FitnessArrayOfWorstFittedBrains[j])
			{
				for (uint32_t k = constNumOfWorstFittedBrains - 1; k > j; k--)
				{
					IDArrayOfWorstFittedBrains[k] = IDArrayOfWorstFittedBrains[k - 1];
					FitnessArrayOfWorstFittedBrains[k] = FitnessArrayOfWorstFittedBrains[k - 1];
				}

				FitnessArrayOfWorstFittedBrains[j] = pFitnessScoreArray[i];
				IDArrayOfWorstFittedBrains[j] = i;

				break;
			}
		}

	} // end of for (uint32_t i = 0; i < PopulationSize; i++)




	float fitnessScoreOfBestFittedAdditionalBrain = -1000000.0f;
	int32_t idOfBestFittedAdditionalBrain = 0;

	for (int32_t i = 0; i < 4; i++)
	{
		if (pFitnessScoreArray[PopulationSize + i] > fitnessScoreOfBestFittedAdditionalBrain)
		{
			fitnessScoreOfBestFittedAdditionalBrain = pFitnessScoreArray[PopulationSize + i];
			idOfBestFittedAdditionalBrain = PopulationSize + i;
		}
	}

	if (pFitnessScoreArray[idOfBestFittedAdditionalBrain] > pFitnessScoreArray[IDArrayOfBestFittedBrains[0]])
	{
		ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[0]]->Clone_OutputSynapsePlasticities(ppUsedNeuralNetArray[idOfBestFittedAdditionalBrain]);
	}
	else if (pFitnessScoreArray[idOfBestFittedAdditionalBrain] > pFitnessScoreArray[IDArrayOfBestFittedBrains[1]])
	{
		ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[1]]->Clone_OutputSynapsePlasticities(ppUsedNeuralNetArray[idOfBestFittedAdditionalBrain]);
	}
	else if (pFitnessScoreArray[idOfBestFittedAdditionalBrain] > pFitnessScoreArray[IDArrayOfBestFittedBrains[2]])
	{
		ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[2]]->Clone_OutputSynapsePlasticities(ppUsedNeuralNetArray[idOfBestFittedAdditionalBrain]);
	}

	UseAdditionalMutatedBestBrain = false;
	UseAdditionalMutatedSecondBestBrain = false;
	UseAdditionalBestBrainsChild = false;

	for (uint32_t i = 0; i < constNumOfRandomBrainsChilds; i++)
		UseAdditionalRandomBrainsChild[i] = false;
}

void CNeuralNetPopulation::RandomChange_ConnectionTopologies(float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRateL1, float mutationRateL2, float mutationRateL3, bool reduceNeuralConnections)
{
	if (reduceNeuralConnections == true)
	{
		for (uint32_t i = 0; i < PopulationSizePlus4; i++)
		{
			ppUsedNeuralNetArray[i]->Disable_Random_InputNeuron_OutputSynapses(Seed++, mutationRateL1);
			ppUsedNeuralNetArray[i]->Disable_Random_HiddenLayer1Neuron_OutputSynapses(Seed++, mutationRateL2);
			ppUsedNeuralNetArray[i]->Disable_Random_HiddenLayer2Neuron_OutputSynapses(Seed++, mutationRateL3);
		}
	}
	else //if (reduceNeuralConnections == false)
	{
		for (uint32_t i = 0; i < PopulationSizePlus4; i++)
		{
			ppUsedNeuralNetArray[i]->Enable_Disabled_InputNeuron_OutputSynapses(Seed++, minSynapticPlasticity, maxSynapticPlasticity, mutationRateL1);
			ppUsedNeuralNetArray[i]->Enable_Disabled_HiddenLayer1Neuron_OutputSynapses(Seed++, minSynapticPlasticity, maxSynapticPlasticity, mutationRateL2);
			ppUsedNeuralNetArray[i]->Enable_Disabled_HiddenLayer2Neuron_OutputSynapses(Seed++, minSynapticPlasticity, maxSynapticPlasticity, mutationRateL3);
		}
	}
}

void CNeuralNetPopulation::RandomChange_ConnectionTopologies(uint64_t seed, float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRateL1, float mutationRateL2, float mutationRateL3, bool reduceNeuralConnections)
{
	if (reduceNeuralConnections == true)
	{
		for (uint32_t i = 0; i < PopulationSizePlus4; i++)
		{
			ppUsedNeuralNetArray[i]->Disable_Random_InputNeuron_OutputSynapses(seed++, mutationRateL1);
			ppUsedNeuralNetArray[i]->Disable_Random_HiddenLayer1Neuron_OutputSynapses(seed++, mutationRateL2);
			ppUsedNeuralNetArray[i]->Disable_Random_HiddenLayer2Neuron_OutputSynapses(seed++, mutationRateL3);
		}
	}
	else //if (reduceNeuralConnections == false)
	{
		for (uint32_t i = 0; i < PopulationSizePlus4; i++)
		{
			ppUsedNeuralNetArray[i]->Enable_Disabled_InputNeuron_OutputSynapses(seed++, minSynapticPlasticity, maxSynapticPlasticity, mutationRateL1);
			ppUsedNeuralNetArray[i]->Enable_Disabled_HiddenLayer1Neuron_OutputSynapses(seed++, minSynapticPlasticity, maxSynapticPlasticity, mutationRateL2);
			ppUsedNeuralNetArray[i]->Enable_Disabled_HiddenLayer2Neuron_OutputSynapses(seed++, minSynapticPlasticity, maxSynapticPlasticity, mutationRateL3);
		}
	}
}

void CNeuralNetPopulation::RandomChange_OutputSynapsePlasticities(float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRate)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		ppUsedNeuralNetArray[i]->RandomChange_OutputSynapsePlasticities(Seed++, minSynapticPlasticity, maxSynapticPlasticity, mutationRate);
	}
}

void CNeuralNetPopulation::RandomChange_OutputSynapsePlasticities(float minSynapticPlasticity, float maxSynapticPlasticity)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		ppUsedNeuralNetArray[i]->RandomChange_OutputSynapsePlasticities(Seed++, minSynapticPlasticity, maxSynapticPlasticity);
	}
}

void CNeuralNetPopulation::RandomChange_OutputSynapsePlasticities(uint64_t seed, float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRate)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		ppUsedNeuralNetArray[i]->RandomChange_OutputSynapsePlasticities(seed++, minSynapticPlasticity, maxSynapticPlasticity, mutationRate);
	}
}

void CNeuralNetPopulation::RandomChange_OutputSynapsePlasticities(uint64_t seed, float minSynapticPlasticity, float maxSynapticPlasticity)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		ppUsedNeuralNetArray[i]->RandomChange_OutputSynapsePlasticities(seed++, minSynapticPlasticity, maxSynapticPlasticity);
	}
}

void CNeuralNetPopulation::Restore_ConnectionTopology_WorstFitted_Brain(float minSynapticPlasticity, float maxSynapticPlasticity)
{
	uint32_t id = IDArrayOfWorstFittedBrains[0];

	ppUsedNeuralNetArray[id]->Enable_Disabled_InputNeuron_OutputSynapses(Seed++, minSynapticPlasticity, maxSynapticPlasticity);
	ppUsedNeuralNetArray[id]->Enable_Disabled_HiddenLayer1Neuron_OutputSynapses(Seed++, minSynapticPlasticity, maxSynapticPlasticity);
	ppUsedNeuralNetArray[id]->Enable_Disabled_HiddenLayer2Neuron_OutputSynapses(Seed++, minSynapticPlasticity, maxSynapticPlasticity);
}

void CNeuralNetPopulation::Restore_ConnectionTopology_SecondWorstFitted_Brain(float minSynapticPlasticity, float maxSynapticPlasticity)
{
	uint32_t id = IDArrayOfWorstFittedBrains[1];

	ppUsedNeuralNetArray[id]->Enable_Disabled_InputNeuron_OutputSynapses(Seed++, minSynapticPlasticity, maxSynapticPlasticity);
	ppUsedNeuralNetArray[id]->Enable_Disabled_HiddenLayer1Neuron_OutputSynapses(Seed++, minSynapticPlasticity, maxSynapticPlasticity);
	ppUsedNeuralNetArray[id]->Enable_Disabled_HiddenLayer2Neuron_OutputSynapses(Seed++, minSynapticPlasticity, maxSynapticPlasticity);
}

void CNeuralNetPopulation::Restore_ConnectionTopology_ThirdWorstFitted_Brain(float minSynapticPlasticity, float maxSynapticPlasticity)
{
	uint32_t id = IDArrayOfWorstFittedBrains[2];

	ppUsedNeuralNetArray[id]->Enable_Disabled_InputNeuron_OutputSynapses(Seed++, minSynapticPlasticity, maxSynapticPlasticity);
	ppUsedNeuralNetArray[id]->Enable_Disabled_HiddenLayer1Neuron_OutputSynapses(Seed++, minSynapticPlasticity, maxSynapticPlasticity);
	ppUsedNeuralNetArray[id]->Enable_Disabled_HiddenLayer2Neuron_OutputSynapses(Seed++, minSynapticPlasticity, maxSynapticPlasticity);
}

void CNeuralNetPopulation::Replace_WorstFitted_Brain(float probabilityValue)
{
	if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > probabilityValue)
		return;

	if (MinNumOfHiddenNeuronsL1 == 0 && MaxNumOfHiddenNeuronsL1 == 0 && MinNumOfHiddenNeuronsL2 == 0 && MaxNumOfHiddenNeuronsL2 == 0)
		return;

	uint32_t numOfHiddenNeuronsL1 = RandomNumbers.Get_UnsignedIntegerNumber2(MinNumOfHiddenNeuronsL1, MaxNumOfHiddenNeuronsL1);
	uint32_t numOfHiddenNeuronsL2 = RandomNumbers.Get_UnsignedIntegerNumber2(MinNumOfHiddenNeuronsL2, MaxNumOfHiddenNeuronsL2);

	Reinitialize_NeuralNet(IDArrayOfWorstFittedBrains[0], numOfHiddenNeuronsL1, numOfHiddenNeuronsL2);
}

void CNeuralNetPopulation::Replace_SecondWorstFitted_Brain(float probabilityValue)
{
	if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > probabilityValue)
		return;

	if (MinNumOfHiddenNeuronsL1 == 0 && MaxNumOfHiddenNeuronsL1 == 0 && MinNumOfHiddenNeuronsL2 == 0 && MaxNumOfHiddenNeuronsL2 == 0)
		return;

	uint32_t numOfHiddenNeuronsL1 = RandomNumbers.Get_UnsignedIntegerNumber2(MinNumOfHiddenNeuronsL1, MaxNumOfHiddenNeuronsL1);
	uint32_t numOfHiddenNeuronsL2 = RandomNumbers.Get_UnsignedIntegerNumber2(MinNumOfHiddenNeuronsL2, MaxNumOfHiddenNeuronsL2);

	Reinitialize_NeuralNet(IDArrayOfWorstFittedBrains[1], numOfHiddenNeuronsL1, numOfHiddenNeuronsL2);
}

void CNeuralNetPopulation::Replace_ThirdWorstFitted_Brain(float probabilityValue)
{
	if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > probabilityValue)
		return;

	if (MinNumOfHiddenNeuronsL1 == 0 && MaxNumOfHiddenNeuronsL1 == 0 && MinNumOfHiddenNeuronsL2 == 0 && MaxNumOfHiddenNeuronsL2 == 0)
		return;

	uint32_t numOfHiddenNeuronsL1 = RandomNumbers.Get_UnsignedIntegerNumber2(MinNumOfHiddenNeuronsL1, MaxNumOfHiddenNeuronsL1);
	uint32_t numOfHiddenNeuronsL2 = RandomNumbers.Get_UnsignedIntegerNumber2(MinNumOfHiddenNeuronsL2, MaxNumOfHiddenNeuronsL2);

	Reinitialize_NeuralNet(IDArrayOfWorstFittedBrains[2], numOfHiddenNeuronsL1, numOfHiddenNeuronsL2);
}


void CNeuralNetPopulation::Set_Activationfunction_OutputLayerNeuron(pActivationFunc pFunc)
{
	pOutputNeuronActivationFunc = pFunc;
}

void CNeuralNetPopulation::Set_Activationfunction_HiddenLayer1Neuron(pActivationFunc pFunc)
{
	pHiddenLayer1NeuronActivationFunc = pFunc;
}

void CNeuralNetPopulation::Set_Activationfunction_HiddenLayer2Neuron(pActivationFunc pFunc)
{
	pHiddenLayer2NeuronActivationFunc = pFunc;
}

void CNeuralNetPopulation::Change_Seed(uint64_t seed)
{
	Seed = seed;
}

void CNeuralNetPopulation::Round_OutputWeights(float precision)
{
	for (uint32_t i = 0; i < PopulationSize; i++)
	{
		ppUsedNeuralNetArray[i]->Round_OutputWeights(precision);
	}
}

CNeuralNet* CNeuralNetPopulation::Get_Best_Evolved_NeuralNet(void)
{
	return ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[0]];
}


void CNeuralNetPopulation::Get_Best_Evolved_NeuralNet_Ext(CNeuralNet* pOutNeuralNet)
{
	uint32_t numOfHiddenNeuronsL1 = ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[0]]->HiddenLayer1.NumOfNeurons;
	uint32_t numOfHiddenNeuronsL2 = ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[0]]->HiddenLayer2.NumOfNeurons;

	//HelperStuff::Add_To_Log(0, "numOfHiddenNeuronsL1", numOfHiddenNeuronsL1);
	//HelperStuff::Add_To_Log(0, "numOfHiddenNeuronsL2", numOfHiddenNeuronsL2);
	
	if (numOfHiddenNeuronsL2 == 0)
	{
		pOutNeuralNet->Init_Input_And_OutputNeurons(NumOfInputNeurons, 0.1f, false, NumOfOutputNeurons, pOutputNeuronActivationFunc);
		pOutNeuralNet->Init_HiddenLayer1(numOfHiddenNeuronsL1, false, true, pHiddenLayer1NeuronActivationFunc, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
	}
	else
	{
		pOutNeuralNet->Init_Input_And_OutputNeurons(NumOfInputNeurons, 0.1f, false, NumOfOutputNeurons, pOutputNeuronActivationFunc);
		pOutNeuralNet->Init_HiddenLayer1(numOfHiddenNeuronsL1, false, false, pHiddenLayer1NeuronActivationFunc, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
		pOutNeuralNet->Init_HiddenLayer2(numOfHiddenNeuronsL2, false, true, pHiddenLayer2NeuronActivationFunc, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
	}

	pOutNeuralNet->Clone_OutputSynapsePlasticities(ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[0]]);
}

void CNeuralNetPopulation::Get_HiddenNeuronNumbers_Of_Best_Evolved_NeuralNet(uint32_t *pNumOfHiddenNeuronsL1, uint32_t *pNumOfHiddenNeuronsL2)
{
	*pNumOfHiddenNeuronsL1 = ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[0]]->HiddenLayer1.NumOfNeurons;
	*pNumOfHiddenNeuronsL2 = ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[0]]->HiddenLayer2.NumOfNeurons;
}

void CNeuralNetPopulation::Reinitialize_NeuralNet(uint32_t brainID, uint32_t numOfHiddenNeuronsL1, uint32_t numOfHiddenNeuronsL2)
{
	if (numOfHiddenNeuronsL2 == 0)
	{
		ppUsedNeuralNetArray[brainID]->Init_Input_And_OutputNeurons(NumOfInputNeurons, 0.1f, false, NumOfOutputNeurons, pOutputNeuronActivationFunc);
		ppUsedNeuralNetArray[brainID]->Init_HiddenLayer1(numOfHiddenNeuronsL1, false, true, pHiddenLayer1NeuronActivationFunc, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
	}
	else
	{
		ppUsedNeuralNetArray[brainID]->Init_Input_And_OutputNeurons(NumOfInputNeurons, 0.1f, false, NumOfOutputNeurons, pOutputNeuronActivationFunc);
		ppUsedNeuralNetArray[brainID]->Init_HiddenLayer1(numOfHiddenNeuronsL1, false, false, pHiddenLayer1NeuronActivationFunc, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
		ppUsedNeuralNetArray[brainID]->Init_HiddenLayer2(numOfHiddenNeuronsL2, false, true, pHiddenLayer2NeuronActivationFunc, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
	}
}





