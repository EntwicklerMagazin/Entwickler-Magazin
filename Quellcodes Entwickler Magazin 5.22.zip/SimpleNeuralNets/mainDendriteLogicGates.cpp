#include <iostream>
#include "NeuralNet_V2.h"

using namespace std;





/*
int main(void)
{
	float InputArray1[2] = { 0.0f, 0.0f };
	float InputArray2[2] = { 1.0f, 0.0f };
	float InputArray3[2] = { 0.0f, 1.0f };
	float InputArray4[2] = { 1.0f, 1.0f };

	float activationValue;

	CNeuronV2 Neuron;

	Neuron.Set_ActivationFunction(FindMaximumDendriteActivation2);

	Neuron.Init_Dendrite_Arrays(4);

	Neuron.Select_UsedDendrites(0, 4);

	float RBF_CentroidValues_XOR[4];
	float RBF_Factors_XOR[4];

	RBF_CentroidValues_XOR[0] = 1.0f;
	RBF_Factors_XOR[0] = 100.0f;

	RBF_CentroidValues_XOR[1] = 0.0f;
	RBF_Factors_XOR[1] = 100.0f;

	RBF_CentroidValues_XOR[2] = 0.0f;
	RBF_Factors_XOR[2] = 100.0f;

	RBF_CentroidValues_XOR[3] = 1.0f;
	RBF_Factors_XOR[3] = 100.0f;

	Neuron.Set_Dendrite_Data(RBF_CentroidValues_XOR, RBF_Factors_XOR);

	Neuron.Set_And_Count_Dendrite_NeuronInput(InputArray1, 2);
	Neuron.Calculate_NeuronOutput();
	activationValue = Neuron.Get_NeuronOutput();

	cout << "input values: " << InputArray1[0] << " " << InputArray1[1] << endl;
	cout << "activation value: " << activationValue << endl << endl;

	Neuron.Set_And_Count_Dendrite_NeuronInput(InputArray2, 2);
	Neuron.Calculate_NeuronOutput();
	activationValue = Neuron.Get_NeuronOutput();

	cout << "input values: " << InputArray2[0] << " " << InputArray2[1] << endl;
	cout << "activation value: " << activationValue << endl << endl;

	Neuron.Set_And_Count_Dendrite_NeuronInput(InputArray3, 2);
	Neuron.Calculate_NeuronOutput();
	activationValue = Neuron.Get_NeuronOutput();

	cout << "input values: " << InputArray3[0] << " " << InputArray3[1] << endl;
	cout << "activation value: " << activationValue << endl << endl;

	Neuron.Set_And_Count_Dendrite_NeuronInput(InputArray4, 2);
	Neuron.Calculate_NeuronOutput();
	activationValue = Neuron.Get_NeuronOutput();

	cout << "input values: " << InputArray4[0] << " " << InputArray4[1] << endl;
	cout << "activation value: " << activationValue << endl << endl << endl;

	Neuron.Init_Dendrite_Arrays(6);

	Neuron.Select_UsedDendrites(0, 6);

	float RBF_CentroidValues_AND[6];
	float RBF_Factors_AND[6];

	RBF_CentroidValues_AND[0] = 1.0f;
	RBF_Factors_AND[0] = 100.0f;

	RBF_CentroidValues_AND[1] = 0.0f;
	RBF_Factors_AND[1] = 100.0f;

	RBF_CentroidValues_AND[2] = 0.0f;
	RBF_Factors_AND[2] = 100.0f;

	RBF_CentroidValues_AND[3] = 1.0f;
	RBF_Factors_AND[3] = 100.0f;

	RBF_CentroidValues_AND[4] = 1.0f;
	RBF_Factors_AND[4] = 100.0f;

	RBF_CentroidValues_AND[5] = 1.0f;
	RBF_Factors_AND[5] = 100.0f;

	Neuron.Set_Dendrite_Data(RBF_CentroidValues_AND, RBF_Factors_AND);


	Neuron.Set_And_Count_Dendrite_NeuronInput(InputArray1, 2);
	Neuron.Calculate_NeuronOutput();
	activationValue = Neuron.Get_NeuronOutput();

	cout << "input values: " << InputArray1[0] << " " << InputArray1[1] << endl;
	cout << "activation value: " << activationValue << endl << endl;

	Neuron.Set_And_Count_Dendrite_NeuronInput(InputArray2, 2);
	Neuron.Calculate_NeuronOutput();
	activationValue = Neuron.Get_NeuronOutput();

	cout << "input values: " << InputArray2[0] << " " << InputArray2[1] << endl;
	cout << "activation value: " << activationValue << endl << endl;

	Neuron.Set_And_Count_Dendrite_NeuronInput(InputArray3, 2);
	Neuron.Calculate_NeuronOutput();
	activationValue = Neuron.Get_NeuronOutput();

	cout << "input values: " << InputArray3[0] << " " << InputArray3[1] << endl;
	cout << "activation value: " << activationValue << endl << endl;

	Neuron.Set_And_Count_Dendrite_NeuronInput(InputArray4, 2);
	Neuron.Calculate_NeuronOutput();
	activationValue = Neuron.Get_NeuronOutput();

	cout << "input values: " << InputArray4[0] << " " << InputArray4[1] << endl;
	cout << "activation value: " << activationValue << endl << endl;

	getchar();
	return 0;
}
*/

/*
int main(void)
{
	int32_t TrainingPopulationSize = 50;
	int32_t NumTrainingGenerationsMax = 10000;

	float output;
	float desiredOutput;
	float errorSum;
	float error;

	float InputArray1[2] = { 0.0f, 0.0f };
	float InputArray2[2] = { 1.0f, 0.0f };
	float InputArray3[2] = { 0.0f, 1.0f };
	float InputArray4[2] = { 1.0f, 1.0f };


	CNeuronV2 *pNeuronArray = new (std::nothrow) CNeuronV2[TrainingPopulationSize];
	float *pFitnessScoreArray = new (std::nothrow) float[TrainingPopulationSize];

	CDendriteNeuronPopulation NeuronPopulation;

	NeuronPopulation.Initialize(TrainingPopulationSize);

	for (int32_t i = 0; i < TrainingPopulationSize; i++)
		NeuronPopulation.Set_Neuron(&pNeuronArray[i], i);
	
	NeuronPopulation.Set_ActivationFunction(FindMaximumDendriteActivation1);

	// Sicherstellen, dass das Neuron mehrere logische Verkn�pfungen erlernen kann:
	NeuronPopulation.Init_Or_Reinitialize_Dendrite_Arrays(18);
	NeuronPopulation.Randomize_Dendrite_Values(0.0f, 1.1f, 100.0f, 100.0f);

	NeuronPopulation.Select_UsedDendrites(0, 6);
	
	for (int32_t j = 0; j < NumTrainingGenerationsMax; j++)
	{
		NeuronPopulation.Reset_MinErrorSum_ActualGeneration();

		for (int32_t i = 0; i < TrainingPopulationSize; i++)
		{
			pFitnessScoreArray[i] = 0.0f;
			errorSum = 0.0f;

			pNeuronArray[i].Set_And_Count_Dendrite_NeuronInput(InputArray1, 2);
			pNeuronArray[i].Calculate_NeuronOutput();
			desiredOutput = 0.0f;
			error = pNeuronArray[i].Calculate_Error(desiredOutput);
			errorSum += error;
			pFitnessScoreArray[i] += 1.0f / (error + 0.01f);

			pNeuronArray[i].Set_And_Count_Dendrite_NeuronInput(InputArray2, 2);
			pNeuronArray[i].Calculate_NeuronOutput();
			desiredOutput = 1.0f;
			error = pNeuronArray[i].Calculate_Error(desiredOutput);
			errorSum += error;
			pFitnessScoreArray[i] += 1.0f / (error + 0.01f);

			pNeuronArray[i].Set_And_Count_Dendrite_NeuronInput(InputArray3, 2);
			pNeuronArray[i].Calculate_NeuronOutput();
			desiredOutput = 1.0f;
			error = pNeuronArray[i].Calculate_Error(desiredOutput);
			errorSum += error;
			pFitnessScoreArray[i] += 1.0f / (error + 0.01f);

			pNeuronArray[i].Set_And_Count_Dendrite_NeuronInput(InputArray4, 2);
			pNeuronArray[i].Calculate_NeuronOutput();
			desiredOutput = 0.0f;
			error = pNeuronArray[i].Calculate_Error(desiredOutput);
			errorSum += error;
			pFitnessScoreArray[i] += 1.0f / (error + 0.01f);


			NeuronPopulation.Update_MinErrorSum_ActualGeneration(errorSum);
		}

		NeuronPopulation.Update_Population(pFitnessScoreArray);

		if (NeuronPopulation.MinErrorSum_ActualGeneration < 0.001f)
		{
			cout << "actual generation: " << j << endl;
			cout << "training completed" << endl << endl;
			break;
		}


		NeuronPopulation.Update_BaseEvolution_Dendrite_Values(0, 5, -0.5f, 0.5f, 0.0f, 0.0f, 0.75f);
		NeuronPopulation.Update_Evolution_BestBrainOnly_Dendrite_Values(0, 5, -0.5f, 0.5f, 0.0f, 0.0f, 0.75f);
		NeuronPopulation.Update_Evolution_SecondBestBrainOnly_Dendrite_Values(0, 5, -0.5f, 0.5f, 0.0f, 0.0f, 0.75f);

		NeuronPopulation.Update_Evolution_Combine_BestTwoBrains();
		NeuronPopulation.Update_Evolution_Combine_TwoBrains();

		NeuronPopulation.Round_Dendrite_CentroidValues(0.1f, 0, 5);
		//NeuronPopulation.Round_Dendrite_CentroidValues(0.25f, 0, 5);
	}

	// Alle Individuen der Population sollen das Gelernte verinnerlichen:
	NeuronPopulation.Update_PopulationKnowledge(0, 5);


	NeuronPopulation.Select_UsedDendrites(6, 8);

	for (int32_t j = 0; j < NumTrainingGenerationsMax; j++)
	{
		NeuronPopulation.Reset_MinErrorSum_ActualGeneration();

		for (int32_t i = 0; i < TrainingPopulationSize; i++)
		{
			NeuronPopulation.pFitnessScoreArray[i] = 0.0f;
			errorSum = 0.0f;

			pNeuronArray[i].Set_And_Count_Dendrite_NeuronInput(InputArray1, 2);
			pNeuronArray[i].Calculate_NeuronOutput();
			desiredOutput = 0.0f;
			error = pNeuronArray[i].Calculate_Error(desiredOutput);
			errorSum += error;
			NeuronPopulation.pFitnessScoreArray[i] += 1.0f / (error + 0.01f);

			pNeuronArray[i].Set_And_Count_Dendrite_NeuronInput(InputArray2, 2);
			pNeuronArray[i].Calculate_NeuronOutput();
			desiredOutput = 1.0f;
			error = pNeuronArray[i].Calculate_Error(desiredOutput);
			errorSum += error;
			NeuronPopulation.pFitnessScoreArray[i] += 1.0f / (error + 0.01f);

			pNeuronArray[i].Set_And_Count_Dendrite_NeuronInput(InputArray3, 2);
			pNeuronArray[i].Calculate_NeuronOutput();
			desiredOutput = 1.0f;
			error = pNeuronArray[i].Calculate_Error(desiredOutput);
			errorSum += error;
			NeuronPopulation.pFitnessScoreArray[i] += 1.0f / (error + 0.01f);

			pNeuronArray[i].Set_And_Count_Dendrite_NeuronInput(InputArray4, 2);
			pNeuronArray[i].Calculate_NeuronOutput();
			desiredOutput = 1.0f;
			error = pNeuronArray[i].Calculate_Error(desiredOutput);
			errorSum += error;
			NeuronPopulation.pFitnessScoreArray[i] += 1.0f / (error + 0.01f);


			NeuronPopulation.Update_MinErrorSum_ActualGeneration(errorSum);
		}

		NeuronPopulation.Update_Population(nullptr);

		if (NeuronPopulation.MinErrorSum_ActualGeneration < 0.001f)
		{
			cout << "actual generation: " << j << endl;
			cout << "training completed" << endl << endl;
			break;
		}


		NeuronPopulation.Update_BaseEvolution_Dendrite_Values(6, 13, -0.6f, 0.6f, 0.0f, 0.0f, 0.75f);
		NeuronPopulation.Update_Evolution_BestBrainOnly_Dendrite_Values(6, 13, -0.6f, 0.6f, 0.0f, 0.0f, 0.75f);
		NeuronPopulation.Update_Evolution_SecondBestBrainOnly_Dendrite_Values(6, 13, -0.6f, 0.6f, 0.0f, 0.0f, 0.75f);

		NeuronPopulation.Update_Evolution_Combine_BestTwoBrains();
		NeuronPopulation.Update_Evolution_Combine_TwoBrains();

		NeuronPopulation.Round_Dendrite_CentroidValues(0.1f, 6, 13);
		//NeuronPopulation.Round_Dendrite_CentroidValues(0.25f, 6, 13);
	}

	NeuronPopulation.Update_PopulationKnowledge(6, 13);

	float activationValue;

	CNeuronV2 BestNeuron;
	NeuronPopulation.Get_Best_Evolved_Neuron(&BestNeuron);

	cout << endl;

	// test output:

	BestNeuron.Select_UsedDendrites(0, 6);

	BestNeuron.Set_And_Count_Dendrite_NeuronInput(InputArray1,  2);
	BestNeuron.Calculate_NeuronOutput();
	activationValue = BestNeuron.Get_NeuronOutput();

	cout << "input values: " << InputArray1[0] << " " << InputArray1[1] << endl;
	cout << "activation value: " << activationValue << endl << endl;

	BestNeuron.Set_And_Count_Dendrite_NeuronInput(InputArray2, 2);
	BestNeuron.Calculate_NeuronOutput();
	activationValue = BestNeuron.Get_NeuronOutput();

	cout << "input values: " << InputArray2[0] << " " << InputArray2[1] << endl;
	cout << "activation value: " << activationValue << endl << endl;

	BestNeuron.Set_And_Count_Dendrite_NeuronInput(InputArray3, 2);
	BestNeuron.Calculate_NeuronOutput();
	activationValue = BestNeuron.Get_NeuronOutput();

	cout << "input values: " << InputArray3[0] << " " << InputArray3[1] << endl;
	cout << "activation value: " << activationValue << endl << endl;

	BestNeuron.Set_And_Count_Dendrite_NeuronInput(InputArray4, 2);
	BestNeuron.Calculate_NeuronOutput();
	activationValue = BestNeuron.Get_NeuronOutput();

	cout << "input values: " << InputArray4[0] << " " << InputArray4[1] << endl;
	cout << "activation value: " << activationValue << endl << endl << endl;


	cout << endl;

	BestNeuron.Select_UsedDendrites(6, 8);

	BestNeuron.Set_And_Count_Dendrite_NeuronInput(InputArray1, 2);
	BestNeuron.Calculate_NeuronOutput();
	activationValue = BestNeuron.Get_NeuronOutput();

	cout << "input values: " << InputArray1[0] << " " << InputArray1[1] << endl;
	cout << "activation value: " << activationValue << endl << endl;

	BestNeuron.Set_And_Count_Dendrite_NeuronInput(InputArray2, 2);
	BestNeuron.Calculate_NeuronOutput();
	activationValue = BestNeuron.Get_NeuronOutput();

	cout << "input values: " << InputArray2[0] << " " << InputArray2[1] << endl;
	cout << "activation value: " << activationValue << endl << endl;

	BestNeuron.Set_And_Count_Dendrite_NeuronInput(InputArray3, 2);
	BestNeuron.Calculate_NeuronOutput();
	activationValue = BestNeuron.Get_NeuronOutput();

	cout << "input values: " << InputArray3[0] << " " << InputArray3[1] << endl;
	cout << "activation value: " << activationValue << endl << endl;

	BestNeuron.Set_And_Count_Dendrite_NeuronInput(InputArray4, 2);
	BestNeuron.Calculate_NeuronOutput();
	activationValue = BestNeuron.Get_NeuronOutput();

	cout << "input values: " << InputArray4[0] << " " << InputArray4[1] << endl;
	cout << "activation value: " << activationValue << endl << endl << endl;


	getchar();

	delete[] pFitnessScoreArray;
	pFitnessScoreArray = nullptr;

	delete[] pNeuronArray;
	pNeuronArray = nullptr;

	return 0;
}
*/

