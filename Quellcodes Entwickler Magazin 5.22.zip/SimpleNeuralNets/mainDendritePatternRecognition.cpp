#include <iostream>
#include "ConsoleHelperFunctions.h"
#include "NeuralNet_V2.h"

using namespace std;





// 32 Pixel * 32 Pixel = 1024 Pixel


inline void PatternRecognitionDendriticFunction_32_32(CNeuronV2 *pNeuron)
{
	pNeuron->Dendrite_InputCounter = 0;

	float *pInputArray = pNeuron->pDendrite_InputValueArray;

	for (int32_t i = 0; i < 1024; i++)
		pInputArray[i] = 2.0f * pInputArray[i] - 1.0f;

	

	int32_t counter = pNeuron->RandomSeedValue;
	float tempValue;

	for (int32_t i = 1024; i < 2048; i++)
	{
		tempValue = 0.0f;

		for (int32_t j = 0; j < 1024; j++)
		{
			tempValue += g_fRandomNumbersTable[counter] * pInputArray[j];
			counter++;

			if (counter > ConstRandomNumbersTableSize)
				counter = 0;
		}

		tempValue *= 2.0f;
		pNeuron->pDendrite_InputValueArray[i] = tempValue / (1.0f + abs(tempValue));
	}
}

inline void PatternRecognitionOutputFunction(CNeuronV2 *pNeuron)
{
	float output = 0.0f;

	int32_t numDendrites = pNeuron->Num_Of_Dendrite_Elements;

	for (int32_t i = 0; i < numDendrites; i++)
	{
		output += pNeuron->pDendrite_FactorArray[i] * pNeuron->pDendrite_InputValueArray_OtherNeuron[i];
	}

	output *= 2.0f;
	pNeuron->NeuronOutput = output / (1.0f + abs(output));
	pNeuron->NeuronInput = 0.0f;
}

inline void PatternRecognitionSimpleOutputFunction(CNeuronV2 *pNeuron)
{
	float output = 0.0f;

	int32_t numDendrites = pNeuron->Num_Of_Dendrite_Elements;

	for (int32_t i = 0; i < numDendrites; i++)
	{
		output += pNeuron->pDendrite_FactorArray[i] * pNeuron->pDendrite_InputValueArray[i];
	}

	pNeuron->NeuronOutput = output;
	pNeuron->NeuronInput = 0.0f;
}



inline void PatternRecognitionOutputFunction2(CNeuronV2 *pNeuron)
{
	float output = 0.0f;
	float tempValue;
	int32_t numDendrites = pNeuron->Num_Of_Dendrite_Elements;

	for (int32_t i = 0; i < numDendrites; i++)
	{
		tempValue = pNeuron->pDendrite_InputValueArray[i] - pNeuron->pDendrite_CentroidValueArray[i];
		tempValue *= tempValue;
		output += pNeuron->pDendrite_FactorArray[i] * tempValue;
	}

	pNeuron->NeuronOutput = 1.0f - tanh(0.025f * output);
	//pNeuron->NeuronOutput = 1.0f - tanh(0.05f * output);
	//output *= 0.05f;
	//pNeuron->NeuronOutput = 1.0f - output / (1.0f + abs(output));

	pNeuron->NeuronInput = 0.0f;
}

inline void PatternRecognitionOutputFunction3(CNeuronV2 *pNeuron)
{
	float output = 0.0f;
	float tempValue;
	int32_t numDendrites = pNeuron->Num_Of_Dendrite_Elements;

	for (int32_t i = 0; i < numDendrites; i++)
	{
		tempValue = pNeuron->pDendrite_InputValueArray[i] - pNeuron->pDendrite_CentroidValueArray[i];
		tempValue *= tempValue;
		output += pNeuron->pDendrite_FactorArray[i] * tempValue;
	}

	pNeuron->NeuronOutput = 1.0f - tanh(output);
	//pNeuron->NeuronOutput = exp(-output);

	pNeuron->NeuronInput = 0.0f;
}

inline void PatternRecognitionOutputFunction4(CNeuronV2 *pNeuron)
{
	float output = 0.0f;
	float tempValue;
	int32_t numDendrites = pNeuron->Num_Of_Dendrite_Elements;

	for (int32_t i = 0; i < numDendrites; i++)
	{
		tempValue = pNeuron->pDendrite_InputValueArray[i] - pNeuron->pDendrite_CentroidValueArray[i];
		tempValue *= tempValue;
		output += pNeuron->pDendrite_FactorArray[i] * tempValue;
	}

	
	pNeuron->NeuronOutput = 1.0f - tanh(0.1f * output);
	

	pNeuron->NeuronInput = 0.0f;
}



/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	Init_fRandomNumbersTable(&RandomNumbers, -1.0f, 1.0f);

	static float Image_B_1[32 * 32];
	static float Image_B_2[32 * 32];
	static float Image_B_3[32 * 32];
	static float Image_B_4[32 * 32];
	static float Image_B_5[32 * 32];
	static float Image_B_6[32 * 32];

	static float Image_8_1[32 * 32];
	static float Image_8_2[32 * 32];
	static float Image_8_3[32 * 32];
	static float Image_8_4[32 * 32];
	static float Image_8_5[32 * 32];
	static float Image_8_6[32 * 32];

	uint8_t *pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_4.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_4, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_5.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_5, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_6.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_6, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_4.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_4, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_5.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_5, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_6.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_6, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	CNeuronV2 PrecedingNeuron;
	CNeuronV2 Neuron1;
	CNeuronV2 Neuron2;

	PrecedingNeuron.Init_Dendrite_Arrays(64 * 64);
	PrecedingNeuron.Set_DendriticFunction(PatternRecognitionDendriticFunction_32_32);

	Neuron1.Init_Dendrite_Arrays(32 * 32);
	//Neuron1.Use_OtherNeuron_Dendrite_InputValueArray(PrecedingNeuron.pDendrite_InputValueArray);
	Neuron1.Use_OtherNeuron_Dendrite_InputValueArray(PrecedingNeuron.pDendrite_InputValueArray, 32 * 32);
	Neuron1.Set_ActivationFunction(PatternRecognitionOutputFunction);
	Neuron1.Randomize_Dendrite_Factors(&RandomNumbers, -0.2f, 0.2f);
	
	Neuron2.Init_Dendrite_Arrays(32 * 32);
	//Neuron2.Use_OtherNeuron_Dendrite_InputValueArray(PrecedingNeuron.pDendrite_InputValueArray);
	Neuron2.Use_OtherNeuron_Dendrite_InputValueArray(PrecedingNeuron.pDendrite_InputValueArray, 32 * 32);
	Neuron2.Set_ActivationFunction(PatternRecognitionOutputFunction);
	Neuron2.Randomize_Dendrite_Factors(&RandomNumbers, -0.2f, 0.2f);


	int32_t maxCount = 1000;
	int32_t epoch = 0;
	float errorSum1;
	float errorSum2;

	for (int32_t i = 0; i < maxCount; i++)
	{
		epoch++;
		errorSum1 = 0.0f;
		errorSum2 = 0.0f;

		
		PrecedingNeuron.Set_Dendrite_NeuronInput(0, 0, Image_B_1, 32, 32, 32, 32);
		PrecedingNeuron.Execute_DendriticCalculations();

		Neuron1.Calculate_NeuronOutput();
		errorSum1 += Neuron1.Adjust_Dendrite_Factors_ExternalInput(1.0f, 0.02f, 1.0f, 0.1f);

		Neuron2.Calculate_NeuronOutput();
		errorSum2 += Neuron2.Adjust_Dendrite_Factors_ExternalInput(-1.0f, 0.02f, 1.0f, 0.1f);

		//////////////

		PrecedingNeuron.Set_Dendrite_NeuronInput(0, 0, Image_B_2, 32, 32, 32, 32);
		PrecedingNeuron.Execute_DendriticCalculations();

		Neuron1.Calculate_NeuronOutput();
		errorSum1 += Neuron1.Adjust_Dendrite_Factors_ExternalInput(1.0f, 0.02f, 1.0f, 0.1f);

		Neuron2.Calculate_NeuronOutput();
		errorSum2 += Neuron2.Adjust_Dendrite_Factors_ExternalInput(-1.0f, 0.02f, 1.0f, 0.1f);

		//////////////

		PrecedingNeuron.Set_Dendrite_NeuronInput(0, 0, Image_8_1, 32, 32, 32, 32);
		PrecedingNeuron.Execute_DendriticCalculations();

		Neuron1.Calculate_NeuronOutput();
		errorSum1 += Neuron1.Adjust_Dendrite_Factors_ExternalInput(-1.0f, 0.02f, 1.0f, 0.1f);

		Neuron2.Calculate_NeuronOutput();
		errorSum2 += Neuron2.Adjust_Dendrite_Factors_ExternalInput(1.0f, 0.02f, 1.0f, 0.1f);

		//////////////

		PrecedingNeuron.Set_Dendrite_NeuronInput(0, 0, Image_8_2, 32, 32, 32, 32);
		PrecedingNeuron.Execute_DendriticCalculations();

		Neuron1.Calculate_NeuronOutput();
		errorSum1 += Neuron1.Adjust_Dendrite_Factors_ExternalInput(-1.0f, 0.02f, 1.0f, 0.1f);

		Neuron2.Calculate_NeuronOutput();
		errorSum2 += Neuron2.Adjust_Dendrite_Factors_ExternalInput(1.0f, 0.02f, 1.0f, 0.1f);


		if (errorSum1 < 0.0005f && errorSum2 < 0.0005f)
			break;
	}

	// training completed

	// training statistics:


	cout << "epoch: " << epoch << endl;
	cout << "error1: " << errorSum1 << " " << "error2: " << errorSum2 << endl << endl;

	cout << endl;

	PrecedingNeuron.Set_Dendrite_NeuronInput(0, 0, Image_B_1, 32, 32, 32, 32);
	PrecedingNeuron.Execute_DendriticCalculations();

	Neuron1.Calculate_NeuronOutput();
	Neuron2.Calculate_NeuronOutput();

	cout << Neuron1.NeuronOutput << " " << Neuron2.NeuronOutput << " ";

	if (Neuron1.NeuronOutput > Neuron2.NeuronOutput)
		cout << "=> B" << endl;
	else
		cout << "=> 8" << endl;

	//////////////

	PrecedingNeuron.Set_Dendrite_NeuronInput(0, 0, Image_B_2, 32, 32, 32, 32);
	PrecedingNeuron.Execute_DendriticCalculations();

	Neuron1.Calculate_NeuronOutput();
	Neuron2.Calculate_NeuronOutput();

	cout << Neuron1.NeuronOutput << " " << Neuron2.NeuronOutput << " ";

	if (Neuron1.NeuronOutput > Neuron2.NeuronOutput)
		cout << "=> B" << endl;
	else
		cout << "=> 8" << endl;

	//////////////

	PrecedingNeuron.Set_Dendrite_NeuronInput(0, 0, Image_B_3, 32, 32, 32, 32);
	PrecedingNeuron.Execute_DendriticCalculations();

	Neuron1.Calculate_NeuronOutput();
	Neuron2.Calculate_NeuronOutput();

	cout << Neuron1.NeuronOutput << " " << Neuron2.NeuronOutput << " ";

	if (Neuron1.NeuronOutput > Neuron2.NeuronOutput)
		cout << "=> B" << endl;
	else
		cout << "=> 8" << endl;

	//////////////

	PrecedingNeuron.Set_Dendrite_NeuronInput(0, 0, Image_B_4, 32, 32, 32, 32);
	PrecedingNeuron.Execute_DendriticCalculations();

	Neuron1.Calculate_NeuronOutput();
	Neuron2.Calculate_NeuronOutput();

	cout << Neuron1.NeuronOutput << " " << Neuron2.NeuronOutput << " ";

	if (Neuron1.NeuronOutput > Neuron2.NeuronOutput)
		cout << "=> B" << endl;
	else
		cout << "=> 8" << endl;

	//////////////

	PrecedingNeuron.Set_Dendrite_NeuronInput(0, 0, Image_B_5, 32, 32, 32, 32);
	PrecedingNeuron.Execute_DendriticCalculations();

	Neuron1.Calculate_NeuronOutput();
	Neuron2.Calculate_NeuronOutput();

	cout << Neuron1.NeuronOutput << " " << Neuron2.NeuronOutput << " ";

	if (Neuron1.NeuronOutput > Neuron2.NeuronOutput)
		cout << "=> B" << endl;
	else
		cout << "=> 8" << endl;

	//////////////

	PrecedingNeuron.Set_Dendrite_NeuronInput(0, 0, Image_B_6, 32, 32, 32, 32);
	PrecedingNeuron.Execute_DendriticCalculations();

	Neuron1.Calculate_NeuronOutput();
	Neuron2.Calculate_NeuronOutput();

	cout << Neuron1.NeuronOutput << " " << Neuron2.NeuronOutput << " ";

	if (Neuron1.NeuronOutput > Neuron2.NeuronOutput)
		cout << "=> B" << endl;
	else
		cout << "=> 8" << endl;

	//////////////

	PrecedingNeuron.Set_Dendrite_NeuronInput(0, 0, Image_8_1, 32, 32, 32, 32);
	PrecedingNeuron.Execute_DendriticCalculations();

	Neuron1.Calculate_NeuronOutput();
	Neuron2.Calculate_NeuronOutput();

	cout << Neuron1.NeuronOutput << " " << Neuron2.NeuronOutput << " ";

	if (Neuron1.NeuronOutput > Neuron2.NeuronOutput)
		cout << "=> B" << endl;
	else
		cout << "=> 8" << endl;

	//////////////

	PrecedingNeuron.Set_Dendrite_NeuronInput(0, 0, Image_8_2, 32, 32, 32, 32);
	PrecedingNeuron.Execute_DendriticCalculations();

	Neuron1.Calculate_NeuronOutput();
	Neuron2.Calculate_NeuronOutput();

	cout << Neuron1.NeuronOutput << " " << Neuron2.NeuronOutput << " ";

	if (Neuron1.NeuronOutput > Neuron2.NeuronOutput)
		cout << "=> B" << endl;
	else
		cout << "=> 8" << endl;

	//////////////

	PrecedingNeuron.Set_Dendrite_NeuronInput(0, 0, Image_8_3, 32, 32, 32, 32);
	PrecedingNeuron.Execute_DendriticCalculations();

	Neuron1.Calculate_NeuronOutput();
	Neuron2.Calculate_NeuronOutput();

	cout << Neuron1.NeuronOutput << " " << Neuron2.NeuronOutput << " ";

	if (Neuron1.NeuronOutput > Neuron2.NeuronOutput)
		cout << "=> B" << endl;
	else
		cout << "=> 8" << endl;

	//////////////

	PrecedingNeuron.Set_Dendrite_NeuronInput(0, 0, Image_8_4, 32, 32, 32, 32);
	PrecedingNeuron.Execute_DendriticCalculations();

	Neuron1.Calculate_NeuronOutput();
	Neuron2.Calculate_NeuronOutput();

	cout << Neuron1.NeuronOutput << " " << Neuron2.NeuronOutput << " ";

	if (Neuron1.NeuronOutput > Neuron2.NeuronOutput)
		cout << "=> B" << endl;
	else
		cout << "=> 8" << endl;

	//////////////

	PrecedingNeuron.Set_Dendrite_NeuronInput(0, 0, Image_8_5, 32, 32, 32, 32);
	PrecedingNeuron.Execute_DendriticCalculations();

	Neuron1.Calculate_NeuronOutput();
	Neuron2.Calculate_NeuronOutput();

	cout << Neuron1.NeuronOutput << " " << Neuron2.NeuronOutput << " ";

	if (Neuron1.NeuronOutput > Neuron2.NeuronOutput)
		cout << "=> B" << endl;
	else
		cout << "=> 8" << endl;

	//////////////

	PrecedingNeuron.Set_Dendrite_NeuronInput(0, 0, Image_8_6, 32, 32, 32, 32);
	PrecedingNeuron.Execute_DendriticCalculations();

	Neuron1.Calculate_NeuronOutput();
	Neuron2.Calculate_NeuronOutput();

	cout << Neuron1.NeuronOutput << " " << Neuron2.NeuronOutput << " ";

	if (Neuron1.NeuronOutput > Neuron2.NeuronOutput)
		cout << "=> B" << endl;
	else
		cout << "=> 8" << endl;

	//////////////

	getchar();
	return 0;
}
*/



/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	Init_fRandomNumbersTable(&RandomNumbers, -1.0f, 1.0f);

	static float Image_B_1[32 * 32];
	static float Image_B_2[32 * 32];
	static float Image_B_3[32 * 32];
	static float Image_B_4[32 * 32];
	static float Image_B_5[32 * 32];
	static float Image_B_6[32 * 32];

	static float Image_8_1[32 * 32];
	static float Image_8_2[32 * 32];
	static float Image_8_3[32 * 32];
	static float Image_8_4[32 * 32];
	static float Image_8_5[32 * 32];
	static float Image_8_6[32 * 32];

	uint8_t *pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_4.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_4, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_5.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_5, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_6.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_6, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_4.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_4, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_5.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_5, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_6.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_6, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	static float CombinedImage_B[32 * 32];
	static float CombinedImage_8[32 * 32];

	CCombinedData CombinedData;

	CombinedData.Reset_Data(CombinedImage_B, 0, 32 * 32);
	CombinedData.Add_Data(CombinedImage_B, Image_B_1, 0, 32 * 32);
	CombinedData.Add_Data(CombinedImage_B, Image_B_2, 0, 32 * 32);
	CombinedData.Add_Data(CombinedImage_B, Image_B_3, 0, 32 * 32);
	CombinedData.ModifyData(CombinedImage_B, 0.0f, -2.0f, 0, 32 * 32);

	CombinedData.Reset_Data(CombinedImage_8, 0, 32 * 32);
	CombinedData.Add_Data(CombinedImage_8, Image_8_1, 0, 32 * 32);
	CombinedData.Add_Data(CombinedImage_8, Image_8_2, 0, 32 * 32);
	CombinedData.Add_Data(CombinedImage_8, Image_8_4, 0, 32 * 32);
	CombinedData.ModifyData(CombinedImage_8, 0.0f, -2.0f, 0, 32 * 32);


	CNeuronV2 Neuron1;
	CNeuronV2 Neuron2;

	CNeuronEnsembleV2 NeuronEnsemble;
	NeuronEnsemble.Set_NumOfNeurons(10);
	NeuronEnsemble.Set_Neuron(&Neuron1, 0);
	NeuronEnsemble.Set_Neuron(&Neuron2, 1);

	Neuron1.Init_Dendrite_Arrays(32 * 32);
	Neuron1.Set_ActivationFunction(PatternRecognitionSimpleOutputFunction);
	Neuron1.Set_Dendrite_Factors(CombinedImage_B);
	

	Neuron2.Init_Dendrite_Arrays(32 * 32);
	Neuron2.Set_ActivationFunction(PatternRecognitionSimpleOutputFunction);
	Neuron2.Set_Dendrite_Factors(CombinedImage_8);
	

	

	cout << endl;

	int32_t IDofMaxOutputNeuron;
	
	Neuron1.Set_Dendrite_NeuronInput(0, 0, Image_B_1, 32, 32, 32, 32);
	Neuron2.Set_Dendrite_NeuronInput(0, 0, Image_B_1, 32, 32, 32, 32);

	Neuron1.Calculate_NeuronOutput();
	Neuron2.Calculate_NeuronOutput();

	cout << Neuron1.NeuronOutput << " " << Neuron2.NeuronOutput << " ";

	IDofMaxOutputNeuron = NeuronEnsemble.Get_ID_Of_NeuronWithMaxOutput();

	if (IDofMaxOutputNeuron == 0)
		cout << "=> B" << endl;
	else
		cout << "=> 8" << endl;

	//////////////

	
	Neuron1.Set_Dendrite_NeuronInput(0, 0, Image_B_2, 32, 32, 32, 32);
	Neuron2.Set_Dendrite_NeuronInput(0, 0, Image_B_2, 32, 32, 32, 32);

	Neuron1.Calculate_NeuronOutput();
	Neuron2.Calculate_NeuronOutput();

	cout << Neuron1.NeuronOutput << " " << Neuron2.NeuronOutput << " ";

	IDofMaxOutputNeuron = NeuronEnsemble.Get_ID_Of_NeuronWithMaxOutput();

	if (IDofMaxOutputNeuron == 0)
		cout << "=> B" << endl;
	else
		cout << "=> 8" << endl;

	//////////////


	Neuron1.Set_Dendrite_NeuronInput(0, 0, Image_B_3, 32, 32, 32, 32);
	Neuron2.Set_Dendrite_NeuronInput(0, 0, Image_B_3, 32, 32, 32, 32);

	Neuron1.Calculate_NeuronOutput();
	Neuron2.Calculate_NeuronOutput();

	cout << Neuron1.NeuronOutput << " " << Neuron2.NeuronOutput << " ";

	IDofMaxOutputNeuron = NeuronEnsemble.Get_ID_Of_NeuronWithMaxOutput();

	if (IDofMaxOutputNeuron == 0)
		cout << "=> B" << endl;
	else
		cout << "=> 8" << endl;

	//////////////

	
	Neuron1.Set_Dendrite_NeuronInput(0, 0, Image_B_4, 32, 32, 32, 32);
	Neuron2.Set_Dendrite_NeuronInput(0, 0, Image_B_4, 32, 32, 32, 32);

	Neuron1.Calculate_NeuronOutput();
	Neuron2.Calculate_NeuronOutput();

	cout << Neuron1.NeuronOutput << " " << Neuron2.NeuronOutput << " ";

	IDofMaxOutputNeuron = NeuronEnsemble.Get_ID_Of_NeuronWithMaxOutput();

	if (IDofMaxOutputNeuron == 0)
		cout << "=> B" << endl;
	else
		cout << "=> 8" << endl;

	//////////////

	Neuron1.Set_Dendrite_NeuronInput(0, 0, Image_B_5, 32, 32, 32, 32);
	Neuron2.Set_Dendrite_NeuronInput(0, 0, Image_B_5, 32, 32, 32, 32);

	Neuron1.Calculate_NeuronOutput();
	Neuron2.Calculate_NeuronOutput();

	cout << Neuron1.NeuronOutput << " " << Neuron2.NeuronOutput << " ";

	IDofMaxOutputNeuron = NeuronEnsemble.Get_ID_Of_NeuronWithMaxOutput();

	if (IDofMaxOutputNeuron == 0)
		cout << "=> B" << endl;
	else
		cout << "=> 8" << endl;

	//////////////

	Neuron1.Set_Dendrite_NeuronInput(0, 0, Image_B_6, 32, 32, 32, 32);
	Neuron2.Set_Dendrite_NeuronInput(0, 0, Image_B_6, 32, 32, 32, 32);

	Neuron1.Calculate_NeuronOutput();
	Neuron2.Calculate_NeuronOutput();

	cout << Neuron1.NeuronOutput << " " << Neuron2.NeuronOutput << " ";

	IDofMaxOutputNeuron = NeuronEnsemble.Get_ID_Of_NeuronWithMaxOutput();

	if (IDofMaxOutputNeuron == 0)
		cout << "=> B" << endl;
	else
		cout << "=> 8" << endl;

	//////////////

	Neuron1.Set_Dendrite_NeuronInput(0, 0, Image_8_1, 32, 32, 32, 32);
	Neuron2.Set_Dendrite_NeuronInput(0, 0, Image_8_1, 32, 32, 32, 32);

	Neuron1.Calculate_NeuronOutput();
	Neuron2.Calculate_NeuronOutput();

	cout << Neuron1.NeuronOutput << " " << Neuron2.NeuronOutput << " ";

	IDofMaxOutputNeuron = NeuronEnsemble.Get_ID_Of_NeuronWithMaxOutput();

	if (IDofMaxOutputNeuron == 0)
		cout << "=> B" << endl;
	else
		cout << "=> 8" << endl;

	//////////////

	Neuron1.Set_Dendrite_NeuronInput(0, 0, Image_8_2, 32, 32, 32, 32);
	Neuron2.Set_Dendrite_NeuronInput(0, 0, Image_8_2, 32, 32, 32, 32);

	Neuron1.Calculate_NeuronOutput();
	Neuron2.Calculate_NeuronOutput();

	cout << Neuron1.NeuronOutput << " " << Neuron2.NeuronOutput << " ";

	IDofMaxOutputNeuron = NeuronEnsemble.Get_ID_Of_NeuronWithMaxOutput();

	if (IDofMaxOutputNeuron == 0)
		cout << "=> B" << endl;
	else
		cout << "=> 8" << endl;

	//////////////

	
	Neuron1.Set_Dendrite_NeuronInput(0, 0, Image_8_3, 32, 32, 32, 32);
	Neuron2.Set_Dendrite_NeuronInput(0, 0, Image_8_3, 32, 32, 32, 32);

	Neuron1.Calculate_NeuronOutput();
	Neuron2.Calculate_NeuronOutput();

	cout << Neuron1.NeuronOutput << " " << Neuron2.NeuronOutput << " ";

	IDofMaxOutputNeuron = NeuronEnsemble.Get_ID_Of_NeuronWithMaxOutput();

	if (IDofMaxOutputNeuron == 0)
		cout << "=> B" << endl;
	else
		cout << "=> 8" << endl;

	//////////////

	Neuron1.Set_Dendrite_NeuronInput(0, 0, Image_8_4, 32, 32, 32, 32);
	Neuron2.Set_Dendrite_NeuronInput(0, 0, Image_8_4, 32, 32, 32, 32);

	Neuron1.Calculate_NeuronOutput();
	Neuron2.Calculate_NeuronOutput();

	cout << Neuron1.NeuronOutput << " " << Neuron2.NeuronOutput << " ";

	IDofMaxOutputNeuron = NeuronEnsemble.Get_ID_Of_NeuronWithMaxOutput();

	if (IDofMaxOutputNeuron == 0)
		cout << "=> B" << endl;
	else
		cout << "=> 8" << endl;

	//////////////

	Neuron1.Set_Dendrite_NeuronInput(0, 0, Image_8_5, 32, 32, 32, 32);
	Neuron2.Set_Dendrite_NeuronInput(0, 0, Image_8_5, 32, 32, 32, 32);

	Neuron1.Calculate_NeuronOutput();
	Neuron2.Calculate_NeuronOutput();

	cout << Neuron1.NeuronOutput << " " << Neuron2.NeuronOutput << " ";

	IDofMaxOutputNeuron = NeuronEnsemble.Get_ID_Of_NeuronWithMaxOutput();

	if (IDofMaxOutputNeuron == 0)
		cout << "=> B" << endl;
	else
		cout << "=> 8" << endl;

	//////////////

	Neuron1.Set_Dendrite_NeuronInput(0, 0, Image_8_6, 32, 32, 32, 32);
	Neuron2.Set_Dendrite_NeuronInput(0, 0, Image_8_6, 32, 32, 32, 32);

	Neuron1.Calculate_NeuronOutput();
	Neuron2.Calculate_NeuronOutput();

	cout << Neuron1.NeuronOutput << " " << Neuron2.NeuronOutput << " ";

	IDofMaxOutputNeuron = NeuronEnsemble.Get_ID_Of_NeuronWithMaxOutput();

	if (IDofMaxOutputNeuron == 0)
		cout << "=> B" << endl;
	else
		cout << "=> 8" << endl;

	//////////////

	getchar();
	return 0;
}
*/


/*
int main(void)
{
	static float Image_B_1[32 * 32];
	static float Image_B_2[32 * 32];
	static float Image_B_3[32 * 32];
	static float Image_B_4[32 * 32];
	static float Image_B_5[32 * 32];
	static float Image_B_6[32 * 32];

	static float Image_8_1[32 * 32];
	static float Image_8_2[32 * 32];
	static float Image_8_3[32 * 32];
	static float Image_8_4[32 * 32];
	static float Image_8_5[32 * 32];
	static float Image_8_6[32 * 32];

	uint8_t *pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_4.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_4, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_5.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_5, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_6.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_6, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_4.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_4, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_5.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_5, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_6.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_6, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;
	
	CNeuronV2 Neuron1;
	CNeuronV2 Neuron2;

	Neuron1.Init_Dendrite_Arrays(32 * 32);
	Neuron1.Set_ActivationFunction(PatternRecognitionOutputFunction2);

	Neuron2.Init_Dendrite_Arrays(32 * 32);
	Neuron2.Set_ActivationFunction(PatternRecognitionOutputFunction2);

	CNeuronEnsembleV2 NeuronEnsemble;
	NeuronEnsemble.Set_NumOfNeurons(2);
	NeuronEnsemble.Set_Neuron(&Neuron1, 0);
	NeuronEnsemble.Set_Neuron(&Neuron2, 1);

	
	Neuron1.Set_NumOfTrainingExamples(0);

	Neuron1.Add_Dendrite_CentroidValues(Image_B_1);
	Neuron1.Calculate_Dendrite_Factors_From_CentroidValues(0.0f, 0.025f, 4);

	Neuron1.Add_Dendrite_CentroidValues(Image_B_2);
	Neuron1.Calculate_Dendrite_Factors_From_CentroidValues(0.0f, 0.025f, 4);

	Neuron1.Add_Dendrite_CentroidValues(Image_B_3);
	Neuron1.Calculate_Dendrite_Factors_From_CentroidValues(0.0f, 0.025f, 4);

	//
	//Neuron1.Add_Dendrite_CentroidValues(Image_B_4);
	//Neuron1.Calculate_Dendrite_Factors_From_CentroidValues(0.5f, 0.025f, 4);

	//Neuron1.Add_Dendrite_CentroidValues(Image_B_5);
	//Neuron1.Calculate_Dendrite_Factors_From_CentroidValues(0.5f, 0.025f, 4);

	//Neuron1.Add_Dendrite_CentroidValues(Image_B_6);
	//Neuron1.Calculate_Dendrite_Factors_From_CentroidValues(0.5f, 0.025f, 4);
	//

	Neuron1.Set_Dendrite_Factor(0.5f, 0.0f, 0.0f);


	Neuron2.Set_NumOfTrainingExamples(0);

	Neuron2.Add_Dendrite_CentroidValues(Image_8_1);
	Neuron2.Calculate_Dendrite_Factors_From_CentroidValues(0.0f, 0.025f, 4);

	Neuron2.Add_Dendrite_CentroidValues(Image_8_2);
	Neuron2.Calculate_Dendrite_Factors_From_CentroidValues(0.0f, 0.025f, 4);

	Neuron2.Add_Dendrite_CentroidValues(Image_8_3);
	Neuron2.Calculate_Dendrite_Factors_From_CentroidValues(0.0f, 0.025f, 4);

	Neuron2.Add_Dendrite_CentroidValues(Image_8_4);
	Neuron2.Calculate_Dendrite_Factors_From_CentroidValues(0.0f, 0.025f, 4);

	//
	//Neuron2.Add_Dendrite_CentroidValues(Image_8_5);
	//Neuron2.Calculate_Dendrite_Factors_From_CentroidValues(0.5f, 0.025f, 4);

	//Neuron2.Add_Dendrite_CentroidValues(Image_8_6);
	//Neuron2.Calculate_Dendrite_Factors_From_CentroidValues(0.5f, 0.025f, 4);
	//

	Neuron2.Set_Dendrite_Factor(0.5f, 0.0f, 0.0f);

	int32_t IDofMaxOutputNeuron;

	cout << "bekannte B-Images" << endl;

	Neuron1.Set_Dendrite_NeuronInput(0, 0, Image_B_1, 32, 32, 32, 32);
	Neuron2.Set_Dendrite_NeuronInput(0, 0, Image_B_1, 32, 32, 32, 32);

	Neuron1.Calculate_NeuronOutput();
	Neuron2.Calculate_NeuronOutput();

	cout << "activation (B): " << Neuron1.NeuronOutput << " activation (8):" << Neuron2.NeuronOutput << endl;

	IDofMaxOutputNeuron = NeuronEnsemble.Get_ID_Of_NeuronWithMaxOutput();

	if (IDofMaxOutputNeuron == 0)
		cout << "=> B" << endl;
	else
		cout << "=> 8" << endl;

	//////////////

	Neuron1.Set_Dendrite_NeuronInput(0, 0, Image_B_2, 32, 32, 32, 32);
	Neuron2.Set_Dendrite_NeuronInput(0, 0, Image_B_2, 32, 32, 32, 32);

	Neuron1.Calculate_NeuronOutput();
	Neuron2.Calculate_NeuronOutput();

	cout << "activation (B): " << Neuron1.NeuronOutput << " activation (8):" << Neuron2.NeuronOutput << endl;

	IDofMaxOutputNeuron = NeuronEnsemble.Get_ID_Of_NeuronWithMaxOutput();

	if (IDofMaxOutputNeuron == 0)
		cout << "=> B" << endl;
	else
		cout << "=> 8" << endl;

	//////////////

	Neuron1.Set_Dendrite_NeuronInput(0, 0, Image_B_3, 32, 32, 32, 32);
	Neuron2.Set_Dendrite_NeuronInput(0, 0, Image_B_3, 32, 32, 32, 32);

	Neuron1.Calculate_NeuronOutput();
	Neuron2.Calculate_NeuronOutput();

	cout << "activation (B): " << Neuron1.NeuronOutput << " activation (8):" << Neuron2.NeuronOutput << endl;

	IDofMaxOutputNeuron = NeuronEnsemble.Get_ID_Of_NeuronWithMaxOutput();

	if (IDofMaxOutputNeuron == 0)
		cout << "=> B" << endl;
	else
		cout << "=> 8" << endl;

	//////////////

	cout << "unbekannte B-Images" << endl;

	//////////////

	Neuron1.Set_Dendrite_NeuronInput(0, 0, Image_B_4, 32, 32, 32, 32);
	Neuron2.Set_Dendrite_NeuronInput(0, 0, Image_B_4, 32, 32, 32, 32);

	Neuron1.Calculate_NeuronOutput();
	Neuron2.Calculate_NeuronOutput();

	cout << "activation (B): " << Neuron1.NeuronOutput << " activation (8):" << Neuron2.NeuronOutput << endl;

	IDofMaxOutputNeuron = NeuronEnsemble.Get_ID_Of_NeuronWithMaxOutput();

	if (IDofMaxOutputNeuron == 0)
		cout << "=> B" << endl;
	else
		cout << "=> 8" << endl;

	//////////////

	Neuron1.Set_Dendrite_NeuronInput(0, 0, Image_B_5, 32, 32, 32, 32);
	Neuron2.Set_Dendrite_NeuronInput(0, 0, Image_B_5, 32, 32, 32, 32);

	Neuron1.Calculate_NeuronOutput();
	Neuron2.Calculate_NeuronOutput();

	cout << "activation (B): " << Neuron1.NeuronOutput << " activation (8):" << Neuron2.NeuronOutput << endl;

	IDofMaxOutputNeuron = NeuronEnsemble.Get_ID_Of_NeuronWithMaxOutput();

	if (IDofMaxOutputNeuron == 0)
		cout << "=> B" << endl;
	else
		cout << "=> 8" << endl;

	//////////////

	Neuron1.Set_Dendrite_NeuronInput(0, 0, Image_B_6, 32, 32, 32, 32);
	Neuron2.Set_Dendrite_NeuronInput(0, 0, Image_B_6, 32, 32, 32, 32);

	Neuron1.Calculate_NeuronOutput();
	Neuron2.Calculate_NeuronOutput();

	cout << "activation (B): " << Neuron1.NeuronOutput << " activation (8):" << Neuron2.NeuronOutput << endl;

	IDofMaxOutputNeuron = NeuronEnsemble.Get_ID_Of_NeuronWithMaxOutput();

	if (IDofMaxOutputNeuron == 0)
		cout << "=> B" << endl;
	else
		cout << "=> 8" << endl;

	//////////////

	cout << "bekannte 8-Images" << endl;

	//////////////

	Neuron1.Set_Dendrite_NeuronInput(0, 0, Image_8_1, 32, 32, 32, 32);
	Neuron2.Set_Dendrite_NeuronInput(0, 0, Image_8_1, 32, 32, 32, 32);

	Neuron1.Calculate_NeuronOutput();
	Neuron2.Calculate_NeuronOutput();

	cout << "activation (B): " << Neuron1.NeuronOutput << " activation (8):" << Neuron2.NeuronOutput << endl;

	IDofMaxOutputNeuron = NeuronEnsemble.Get_ID_Of_NeuronWithMaxOutput();

	if (IDofMaxOutputNeuron == 0)
		cout << "=> B" << endl;
	else
		cout << "=> 8" << endl;

	//////////////

	Neuron1.Set_Dendrite_NeuronInput(0, 0, Image_8_2, 32, 32, 32, 32);
	Neuron2.Set_Dendrite_NeuronInput(0, 0, Image_8_2, 32, 32, 32, 32);

	Neuron1.Calculate_NeuronOutput();
	Neuron2.Calculate_NeuronOutput();

	cout << "activation (B): " << Neuron1.NeuronOutput << " activation (8):" << Neuron2.NeuronOutput << endl;

	IDofMaxOutputNeuron = NeuronEnsemble.Get_ID_Of_NeuronWithMaxOutput();

	if (IDofMaxOutputNeuron == 0)
		cout << "=> B" << endl;
	else
		cout << "=> 8" << endl;

	//////////////

	Neuron1.Set_Dendrite_NeuronInput(0, 0, Image_8_3, 32, 32, 32, 32);
	Neuron2.Set_Dendrite_NeuronInput(0, 0, Image_8_3, 32, 32, 32, 32);

	Neuron1.Calculate_NeuronOutput();
	Neuron2.Calculate_NeuronOutput();

	cout << "activation (B): " << Neuron1.NeuronOutput << " activation (8):" << Neuron2.NeuronOutput << endl;

	IDofMaxOutputNeuron = NeuronEnsemble.Get_ID_Of_NeuronWithMaxOutput();

	if (IDofMaxOutputNeuron == 0)
		cout << "=> B" << endl;
	else
		cout << "=> 8" << endl;

	//////////////

	Neuron1.Set_Dendrite_NeuronInput(0, 0, Image_8_4, 32, 32, 32, 32);
	Neuron2.Set_Dendrite_NeuronInput(0, 0, Image_8_4, 32, 32, 32, 32);

	Neuron1.Calculate_NeuronOutput();
	Neuron2.Calculate_NeuronOutput();

	cout << "activation (B): " << Neuron1.NeuronOutput << " activation (8):" << Neuron2.NeuronOutput << endl;

	IDofMaxOutputNeuron = NeuronEnsemble.Get_ID_Of_NeuronWithMaxOutput();

	if (IDofMaxOutputNeuron == 0)
		cout << "=> B" << endl;
	else
		cout << "=> 8" << endl;

	//////////////

	cout << "unbekannte 8-Images" << endl;

	//////////////

	Neuron1.Set_Dendrite_NeuronInput(0, 0, Image_8_5, 32, 32, 32, 32);
	Neuron2.Set_Dendrite_NeuronInput(0, 0, Image_8_5, 32, 32, 32, 32);

	Neuron1.Calculate_NeuronOutput();
	Neuron2.Calculate_NeuronOutput();

	cout << "activation (B): " << Neuron1.NeuronOutput << " activation (8):" << Neuron2.NeuronOutput << endl;

	IDofMaxOutputNeuron = NeuronEnsemble.Get_ID_Of_NeuronWithMaxOutput();

	if (IDofMaxOutputNeuron == 0)
		cout << "=> B" << endl;
	else
		cout << "=> 8" << endl;

	//////////////

	Neuron1.Set_Dendrite_NeuronInput(0, 0, Image_8_6, 32, 32, 32, 32);
	Neuron2.Set_Dendrite_NeuronInput(0, 0, Image_8_6, 32, 32, 32, 32);

	Neuron1.Calculate_NeuronOutput();
	Neuron2.Calculate_NeuronOutput();

	cout << "activation (B): " << Neuron1.NeuronOutput << " activation (8):" << Neuron2.NeuronOutput << endl;

	IDofMaxOutputNeuron = NeuronEnsemble.Get_ID_Of_NeuronWithMaxOutput();

	if (IDofMaxOutputNeuron == 0)
		cout << "=> B" << endl;
	else
		cout << "=> 8" << endl;

	//////////////

	getchar();
	return 0;
}
*/

/*
int main(void)
{
	static float Image_5_1[32 * 32];
	static float Image_6_1[32 * 32];
	static float Image_8_1[32 * 32];
	static float Image_B_1[32 * 32];
	static float Image_G_1[32 * 32];
	static float Image_S_1[32 * 32];

	static float Image_Object1[32 * 32];
	static float Image_Object3[32 * 32];
	static float Image_Object4[32 * 32];
	static float Image_Object5[32 * 32]; 

	
	uint8_t *pImageData = nullptr;

	
	pImageData = Read_Bitmap_BGR("Sample_5_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_5_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_6_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_G_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_S_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_Object1.bmp");

	Get_BinaryImageData_BlueChannel(Image_Object1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_Object3.bmp");

	Get_BinaryImageData_BlueChannel(Image_Object3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_Object4.bmp");

	Get_BinaryImageData_BlueChannel(Image_Object4, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_Object5.bmp");

	Get_BinaryImageData_BlueChannel(Image_Object5, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;


	


	CNeuronV2 Neuron;
	Neuron.Init_Dendrite_Arrays(32 * 32);
	Neuron.Set_ActivationFunction(PatternRecognitionOutputFunction2);


	Neuron.Set_NumOfTrainingExamples(0);


	//Neuron.Add_Dendrite_CentroidValues(Image_5_1);
	//Neuron.Calculate_Dendrite_Factors_From_CentroidValues(10.0f, 0.025f, 2);

	Neuron.Add_Dendrite_CentroidValues(Image_6_1);
	Neuron.Calculate_Dendrite_Factors_From_CentroidValues(10.0f, 0.025f, 2);

	Neuron.Add_Dendrite_CentroidValues(Image_8_1);
	Neuron.Calculate_Dendrite_Factors_From_CentroidValues(10.0f, 0.025f, 2);

	//Neuron.Add_Dendrite_CentroidValues(Image_B_1);
	//Neuron.Calculate_Dendrite_Factors_From_CentroidValues(10.0f, 0.025f, 2);

	Neuron.Add_Dendrite_CentroidValues(Image_G_1);
	Neuron.Calculate_Dendrite_Factors_From_CentroidValues(10.0f, 0.025f, 2);

	Neuron.Add_Dendrite_CentroidValues(Image_S_1);
	Neuron.Calculate_Dendrite_Factors_From_CentroidValues(10.0f, 0.025f, 2);

	
	//Neuron.Add_Dendrite_CentroidValues(Image_Object1);
	//Neuron.Calculate_Dendrite_Factors_From_CentroidValues(10.0f, 0.025f, 2);

	//Neuron.Add_Dendrite_CentroidValues(Image_Object3);
	//Neuron.Calculate_Dendrite_Factors_From_CentroidValues(10.0f, 0.025f, 2);

	Neuron.Add_Dendrite_CentroidValues(Image_Object4);
	Neuron.Calculate_Dendrite_Factors_From_CentroidValues(10.0f, 0.025f, 2);

	//Neuron.Add_Dendrite_CentroidValues(Image_Object5);
	//Neuron.Calculate_Dendrite_Factors_From_CentroidValues(10.0f, 0.025f, 2);




	Neuron.Set_Dendrite_NeuronInput(0, 0, Image_5_1, 32, 32, 32, 32);
	Neuron.Calculate_NeuronOutput();
	cout << "activationValue: " << Neuron.NeuronOutput << endl;

	Neuron.Set_Dendrite_NeuronInput(0, 0, Image_6_1, 32, 32, 32, 32);
	Neuron.Calculate_NeuronOutput();
	cout << "activationValue: " << Neuron.NeuronOutput << endl;

	Neuron.Set_Dendrite_NeuronInput(0, 0, Image_8_1, 32, 32, 32, 32);
	Neuron.Calculate_NeuronOutput();
	cout << "activationValue: " << Neuron.NeuronOutput << endl;

	Neuron.Set_Dendrite_NeuronInput(0, 0, Image_B_1, 32, 32, 32, 32);
	Neuron.Calculate_NeuronOutput();
	cout << "activationValue: " << Neuron.NeuronOutput << endl;

	Neuron.Set_Dendrite_NeuronInput(0, 0, Image_G_1, 32, 32, 32, 32);
	Neuron.Calculate_NeuronOutput();
	cout << "activationValue: " << Neuron.NeuronOutput << endl;

	Neuron.Set_Dendrite_NeuronInput(0, 0, Image_S_1, 32, 32, 32, 32);
	Neuron.Calculate_NeuronOutput();
	cout << "activationValue: " << Neuron.NeuronOutput << endl;


	

	Neuron.Set_Dendrite_NeuronInput(0, 0, Image_Object1, 32, 32, 32, 32);
	Neuron.Calculate_NeuronOutput();
	cout << "activationValue: " << Neuron.NeuronOutput << endl;

	Neuron.Set_Dendrite_NeuronInput(0, 0, Image_Object3, 32, 32, 32, 32);
	Neuron.Calculate_NeuronOutput();
	cout << "activationValue: " << Neuron.NeuronOutput << endl;

	Neuron.Set_Dendrite_NeuronInput(0, 0, Image_Object4, 32, 32, 32, 32);
	Neuron.Calculate_NeuronOutput();
	cout << "activationValue: " << Neuron.NeuronOutput << endl;

	Neuron.Set_Dendrite_NeuronInput(0, 0, Image_Object5, 32, 32, 32, 32);
	Neuron.Calculate_NeuronOutput();
	cout << "activationValue: " << Neuron.NeuronOutput << endl;


	getchar();
	return 0;
}
*/



/*
int main(void)
{
	static float Pattern1[] = { -1.0f, -1.0f,    0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f };      // -1, -1
	static float Pattern2[] = { 0.0f, 0.0f,     1.0f, -1.0f,     0.0f, 0.0f, 0.0f, 0.0f };  // +1, -1
	static float Pattern3[] = { 0.0f, 0.0f, 0.0f, 0.0f,   -1.0f, 1.0f,     0.0f, 0.0f };    // -1, +1
	static float Pattern4[] = { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,   1.0f, 1.0f };         // +1, +1


	CNeuronV2 Neuron;
	Neuron.Init_Dendrite_Arrays(8);
	Neuron.Set_ActivationFunction(PatternRecognitionOutputFunction4);

	Neuron.Set_NumOfTrainingExamples(0);

	Neuron.Add_Dendrite_CentroidValues(Pattern2);
	Neuron.Calculate_Dendrite_Factors_From_CentroidValues(10.0f, 0.025f, 2);

	Neuron.Add_Dendrite_CentroidValues(Pattern3);
	Neuron.Calculate_Dendrite_Factors_From_CentroidValues(10.0f, 0.025f, 2);



	Neuron.Set_Dendrite_NeuronInput(0, 0, Pattern1, 1, 8, 1, 8);
	Neuron.Calculate_NeuronOutput();
	cout << "activationValue: " << Neuron.NeuronOutput << endl;

	Neuron.Set_Dendrite_NeuronInput(0, 0, Pattern2, 1, 8, 1, 8);
	Neuron.Calculate_NeuronOutput();
	cout << "activationValue: " << Neuron.NeuronOutput << endl;

	Neuron.Set_Dendrite_NeuronInput(0, 0, Pattern3, 1, 8, 1, 8);
	Neuron.Calculate_NeuronOutput();
	cout << "activationValue: " << Neuron.NeuronOutput << endl;

	Neuron.Set_Dendrite_NeuronInput(0, 0, Pattern4, 1, 8, 1, 8);
	Neuron.Calculate_NeuronOutput();
	cout << "activationValue: " << Neuron.NeuronOutput << endl;


	getchar();
	return 0;
}
*/

/*
int main(void)
{
	static float Image_5_1[32 * 32];
	static float Image_6_1[32 * 32];
	static float Image_8_1[32 * 32];
	static float Image_B_1[32 * 32];
	static float Image_G_1[32 * 32];
	static float Image_S_1[32 * 32];

	static float Image_Object1[32 * 32];
	static float Image_Object2[32 * 32];
	static float Image_Object3[32 * 32];
	static float Image_Object4[32 * 32];
	static float Image_Object5[32 * 32]; 
	static float Image_Object6[32 * 32]; // 1024

	static float IntermediateVector[64 * 64]; // 4096


	uint8_t *pImageData = nullptr;


	pImageData = Read_Bitmap_BGR("Sample_5_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_5_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_6_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_G_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_S_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_Object1.bmp");

	Get_BinaryImageData_BlueChannel(Image_Object1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_Object2.bmp");

	Get_BinaryImageData_BlueChannel(Image_Object2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_Object3.bmp");

	Get_BinaryImageData_BlueChannel(Image_Object3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_Object4.bmp");

	Get_BinaryImageData_BlueChannel(Image_Object4, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_Object5.bmp");

	Get_BinaryImageData_BlueChannel(Image_Object5, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_Object6.bmp");

	Get_BinaryImageData_BlueChannel(Image_Object6, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;



	CNeuronV2 Neuron;
	Neuron.Init_Dendrite_Arrays(64 * 64);
	Neuron.Set_ActivationFunction(PatternRecognitionOutputFunction2);


	Neuron.Set_NumOfTrainingExamples(0);

	//Quadruple_InputVector(IntermediateVector, Image_5_1, 1024);
	//Neuron.Add_Dendrite_CentroidValues(IntermediateVector);
	//Neuron.Calculate_Dendrite_Factors_From_CentroidValues(10.0f, 0.025f, 2);

	Quadruple_InputVector(IntermediateVector, Image_6_1, 1024);
	Neuron.Add_Dendrite_CentroidValues(IntermediateVector);
	Neuron.Calculate_Dendrite_Factors_From_CentroidValues(10.0f, 0.025f, 2);

	Quadruple_InputVector(IntermediateVector, Image_8_1, 1024);
	Neuron.Add_Dendrite_CentroidValues(IntermediateVector);
	Neuron.Calculate_Dendrite_Factors_From_CentroidValues(10.0f, 0.025f, 2);

	//Quadruple_InputVector(IntermediateVector, Image_B_1, 1024);
	//Neuron.Add_Dendrite_CentroidValues(IntermediateVector);
	//Neuron.Calculate_Dendrite_Factors_From_CentroidValues(10.0f, 0.025f, 2);

	Quadruple_InputVector(IntermediateVector, Image_G_1, 1024);
	Neuron.Add_Dendrite_CentroidValues(IntermediateVector);
	Neuron.Calculate_Dendrite_Factors_From_CentroidValues(10.0f, 0.025f, 2);

	Quadruple_InputVector(IntermediateVector, Image_S_1, 1024);
	Neuron.Add_Dendrite_CentroidValues(IntermediateVector);
	Neuron.Calculate_Dendrite_Factors_From_CentroidValues(10.0f, 0.025f, 2);

	//Quadruple_InputVector(IntermediateVector, Image_Object1, 1024);
	//Neuron.Add_Dendrite_CentroidValues(IntermediateVector);
	//Neuron.Calculate_Dendrite_Factors_From_CentroidValues(10.0f, 0.025f, 2);

	//Quadruple_InputVector(IntermediateVector, Image_Object2, 1024);
	//Neuron.Add_Dendrite_CentroidValues(IntermediateVector);
	//Neuron.Calculate_Dendrite_Factors_From_CentroidValues(10.0f, 0.025f, 2);

	//Quadruple_InputVector(IntermediateVector, Image_Object3, 1024);
	//Neuron.Add_Dendrite_CentroidValues(IntermediateVector);
	//Neuron.Calculate_Dendrite_Factors_From_CentroidValues(10.0f, 0.025f, 2);

	Quadruple_InputVector(IntermediateVector, Image_Object4, 1024);
	Neuron.Add_Dendrite_CentroidValues(IntermediateVector);
	Neuron.Calculate_Dendrite_Factors_From_CentroidValues(10.0f, 0.025f, 2);

	//Quadruple_InputVector(IntermediateVector, Image_Object5, 1024);
	//Neuron.Add_Dendrite_CentroidValues(IntermediateVector);
	//Neuron.Calculate_Dendrite_Factors_From_CentroidValues(10.0f, 0.025f, 2);

	//Quadruple_InputVector(IntermediateVector, Image_Object6, 1024);
	//Neuron.Add_Dendrite_CentroidValues(IntermediateVector);
	//Neuron.Calculate_Dendrite_Factors_From_CentroidValues(10.0f, 0.025f, 2);


	Quadruple_InputVector(IntermediateVector, Image_5_1, 1024);
	Neuron.Set_Dendrite_NeuronInput(0, 0, IntermediateVector, 64, 64, 64, 64);
	Neuron.Calculate_NeuronOutput();
	cout << "activationValue: " << Neuron.NeuronOutput << endl;

	Quadruple_InputVector(IntermediateVector, Image_6_1, 1024);
	Neuron.Set_Dendrite_NeuronInput(0, 0, IntermediateVector, 64, 64, 64, 64);
	Neuron.Calculate_NeuronOutput();
	cout << "activationValue: " << Neuron.NeuronOutput << endl;

	Quadruple_InputVector(IntermediateVector, Image_8_1, 1024);
	Neuron.Set_Dendrite_NeuronInput(0, 0, IntermediateVector, 64, 64, 64, 64);
	Neuron.Calculate_NeuronOutput();
	cout << "activationValue: " << Neuron.NeuronOutput << endl;

	Quadruple_InputVector(IntermediateVector, Image_B_1, 1024);
	Neuron.Set_Dendrite_NeuronInput(0, 0, IntermediateVector, 64, 64, 64, 64);
	Neuron.Calculate_NeuronOutput();
	cout << "activationValue: " << Neuron.NeuronOutput << endl;

	Quadruple_InputVector(IntermediateVector, Image_G_1, 1024);
	Neuron.Set_Dendrite_NeuronInput(0, 0, IntermediateVector, 64, 64, 64, 64);
	Neuron.Calculate_NeuronOutput();
	cout << "activationValue: " << Neuron.NeuronOutput << endl;

	Quadruple_InputVector(IntermediateVector, Image_S_1, 1024);
	Neuron.Set_Dendrite_NeuronInput(0, 0, IntermediateVector, 64, 64, 64, 64);
	Neuron.Calculate_NeuronOutput();
	cout << "activationValue: " << Neuron.NeuronOutput << endl;



	Quadruple_InputVector(IntermediateVector, Image_Object1, 1024);
	Neuron.Set_Dendrite_NeuronInput(0, 0, IntermediateVector, 64, 64, 64, 64);
	Neuron.Calculate_NeuronOutput();
	cout << "activationValue: " << Neuron.NeuronOutput << endl;

	Quadruple_InputVector(IntermediateVector, Image_Object2, 1024);
	Neuron.Set_Dendrite_NeuronInput(0, 0, IntermediateVector, 64, 64, 64, 64);
	Neuron.Calculate_NeuronOutput();
	cout << "activationValue: " << Neuron.NeuronOutput << endl;

	Quadruple_InputVector(IntermediateVector, Image_Object3, 1024);
	Neuron.Set_Dendrite_NeuronInput(0, 0, IntermediateVector, 64, 64, 64, 64);
	Neuron.Calculate_NeuronOutput();
	cout << "activationValue: " << Neuron.NeuronOutput << endl;

	Quadruple_InputVector(IntermediateVector, Image_Object4, 1024);
	Neuron.Set_Dendrite_NeuronInput(0, 0, IntermediateVector, 64, 64, 64, 64);
	Neuron.Calculate_NeuronOutput();
	cout << "activationValue: " << Neuron.NeuronOutput << endl;

	Quadruple_InputVector(IntermediateVector, Image_Object5, 1024);
	Neuron.Set_Dendrite_NeuronInput(0, 0, IntermediateVector, 64, 64, 64, 64);
	Neuron.Calculate_NeuronOutput();
	cout << "activationValue: " << Neuron.NeuronOutput << endl;

	Quadruple_InputVector(IntermediateVector, Image_Object6, 1024);
	Neuron.Set_Dendrite_NeuronInput(0, 0, IntermediateVector, 64, 64, 64, 64);
	Neuron.Calculate_NeuronOutput();
	cout << "activationValue: " << Neuron.NeuronOutput << endl;

	getchar();
	return 0;
}
*/



/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	Init_fRandomNumbersTable(&RandomNumbers, -1.0f, 1.0f);

	static float Image_B_1[32 * 32];
	static float Image_B_2[32 * 32];
	static float Image_B_3[32 * 32];
	static float Image_B_4[32 * 32];
	static float Image_B_5[32 * 32];
	static float Image_B_6[32 * 32];

	static float Image_8_1[32 * 32];
	static float Image_8_2[32 * 32];
	static float Image_8_3[32 * 32];
	static float Image_8_4[32 * 32];
	static float Image_8_5[32 * 32];
	static float Image_8_6[32 * 32];

	static float Image_B_Part1[32 * 32];
	static float Image_B_Part2[32 * 32];
	static float Image_B_Part3[32 * 32];
	static float Image_B_Part4[32 * 32];
	static float Image_B_Part5[32 * 32];
	static float Image_B_Part6[32 * 32];

	uint8_t *pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_4.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_4, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_5.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_5, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_6.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_6, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_4.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_4, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_5.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_5, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_6.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_6, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;


	pImageData = Read_Bitmap_BGR("Sample_B_Part1.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_Part1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_Part2.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_Part2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_Part3.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_Part3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_Part4.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_Part4, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_Part5.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_Part5, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_Part6.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_Part6, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;


	CNeuronV2 Neuron;
	

	Neuron.Init_Dendrite_Arrays(32 * 32);
	Neuron.Set_ActivationFunction(PatternRecognitionOutputFunction3);
	
	Neuron.Set_NumOfTrainingExamples(0);

	Neuron.Add_Dendrite_CentroidValues(Image_B_Part1);
	Neuron.Calculate_Dendrite_Factors_From_CentroidValues(0.5f, 0.2f, 4);

	Neuron.Add_Dendrite_CentroidValues(Image_B_Part2);
	Neuron.Calculate_Dendrite_Factors_From_CentroidValues(0.5f, 0.2f, 4);

	Neuron.Add_Dendrite_CentroidValues(Image_B_Part3);
	Neuron.Calculate_Dendrite_Factors_From_CentroidValues(0.5f, 0.2f, 4);

	Neuron.Add_Dendrite_CentroidValues(Image_B_Part4);
	Neuron.Calculate_Dendrite_Factors_From_CentroidValues(0.5f, 0.2f, 4);

	Neuron.Add_Dendrite_CentroidValues(Image_B_Part5);
	Neuron.Calculate_Dendrite_Factors_From_CentroidValues(0.5f, 0.2f, 4);

	Neuron.Add_Dendrite_CentroidValues(Image_B_Part6);
	Neuron.Calculate_Dendrite_Factors_From_CentroidValues(0.5f, 0.2f, 4);
	
	Neuron.Set_Dendrite_Factor(0.0f, 0.0f, 0.95f);
	

	
	
	



	cout << "B-Images activations" << endl;

	Neuron.Set_Dendrite_NeuronInput(0, 0, Image_B_1, 32, 32, 32, 32);
	Neuron.Calculate_NeuronOutput();
	cout << Neuron.NeuronOutput << endl;

	//////////////

	Neuron.Set_Dendrite_NeuronInput(0, 0, Image_B_2, 32, 32, 32, 32);
	Neuron.Calculate_NeuronOutput();
	cout << Neuron.NeuronOutput << endl;

	//////////////

	Neuron.Set_Dendrite_NeuronInput(0, 0, Image_B_3, 32, 32, 32, 32);
	Neuron.Calculate_NeuronOutput();
	cout << Neuron.NeuronOutput << endl;

	//////////////

	Neuron.Set_Dendrite_NeuronInput(0, 0, Image_B_4, 32, 32, 32, 32);
	Neuron.Calculate_NeuronOutput();
	cout << Neuron.NeuronOutput << endl;

	//////////////

	Neuron.Set_Dendrite_NeuronInput(0, 0, Image_B_5, 32, 32, 32, 32);
	Neuron.Calculate_NeuronOutput();
	cout << Neuron.NeuronOutput << endl;

	//////////////

	Neuron.Set_Dendrite_NeuronInput(0, 0, Image_B_6, 32, 32, 32, 32);
	Neuron.Calculate_NeuronOutput();
	cout << Neuron.NeuronOutput << endl;

	//////////////

	cout << "8-Images activations" << endl;

	//////////////

	Neuron.Set_Dendrite_NeuronInput(0, 0, Image_8_1, 32, 32, 32, 32);
	Neuron.Calculate_NeuronOutput();
	cout << Neuron.NeuronOutput << endl;

	//////////////

	Neuron.Set_Dendrite_NeuronInput(0, 0, Image_8_2, 32, 32, 32, 32);
	Neuron.Calculate_NeuronOutput();
	cout << Neuron.NeuronOutput << endl;

	//////////////

	Neuron.Set_Dendrite_NeuronInput(0, 0, Image_8_3, 32, 32, 32, 32);
	Neuron.Calculate_NeuronOutput();
	cout << Neuron.NeuronOutput << endl;

	//////////////

	Neuron.Set_Dendrite_NeuronInput(0, 0, Image_8_4, 32, 32, 32, 32);
	Neuron.Calculate_NeuronOutput();
	cout << Neuron.NeuronOutput << endl;

	//////////////

	Neuron.Set_Dendrite_NeuronInput(0, 0, Image_8_5, 32, 32, 32, 32);
	Neuron.Calculate_NeuronOutput();
	cout << Neuron.NeuronOutput << endl;

	//////////////

	Neuron.Set_Dendrite_NeuronInput(0, 0, Image_8_6, 32, 32, 32, 32);
	Neuron.Calculate_NeuronOutput();
	cout << Neuron.NeuronOutput << endl;

	//////////////

	getchar();
	return 0;
}
*/