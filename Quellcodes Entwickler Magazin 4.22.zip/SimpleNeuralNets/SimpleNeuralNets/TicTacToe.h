// Schutz vor Mehrfachdeklarationen:
#ifndef _TicTacToe_H_
#define _TicTacToe_H_

#include "RandomNumbers.h"

static constexpr uint8_t ConstBoardSymbol_Empty = '*';
static constexpr uint8_t ConstBoardSymbol_Player1 = 'X';
static constexpr uint8_t ConstBoardSymbol_Player2 = 'O';

static constexpr uint32_t ConstNumBoardRows = 3;
static constexpr uint32_t ConstNumBoardColumns = 3; // more exact: ConstNumBoardColumnsPerRow
static constexpr uint32_t ConstNumBoardRowsMinus1 = ConstNumBoardRows - 1;
static constexpr uint32_t ConstNumBoardColumnsMinus1 = ConstNumBoardColumns - 1;
static constexpr uint32_t ConstBoardSize = ConstNumBoardRows * ConstNumBoardColumns;
static constexpr uint32_t ConstBoardSizeMinus1 = ConstBoardSize - 1;
static constexpr uint32_t ConstMaximumMoveCount = ConstBoardSize;
static constexpr uint32_t ConstBoardSize_2 = 2 * ConstBoardSize;
static constexpr uint32_t ConstBoardSize_3 = 3 * ConstBoardSize;
static constexpr uint32_t ConstNumMovesMax = ConstBoardSize;


struct CMove
{
	int32_t row = -1;
	int32_t column = -1;
};

class CGameState
{
public:

	uint32_t LastMove_Row, LastMove_Column, LastMove_Index;

	uint8_t Board[ConstNumBoardRows][ConstNumBoardColumns];

	uint32_t NumEmptyBoardPositions;

	// for neural net evaluation:
	float BoardDataArray[ConstBoardSize_2];
	float BoardDataArray2[ConstBoardSize_3];

	CGameState();
	~CGameState();

	// Kopierkonstruktor:
	CGameState(const CGameState &originalObject);

	// Zuweisungsoperator:
	CGameState& operator=(const CGameState &originalObject);

	bool operator==(CGameState &otherObject);

	void Get_BoardData(uint8_t pOutData[3][3]);

	void Reset_Bord(void);
	void Output(void);

	int32_t Evaluate_Player1(void);
	int32_t Evaluate_Player2(void);

	bool Check_If_Player1_Could_Win(void);
	bool Check_If_Player2_Could_Win(void);

	bool Make_Move(uint32_t row, uint32_t column, uint8_t player);
	bool Make_Move(uint32_t index, uint8_t player);

	void Reset_LastMove_RowColumn(void);
	void Reset_LastMove_Index(void);

};

class CRecordedGame
{
public:

	uint32_t NumMoves = 0;
	CMove MoveArray[ConstNumMovesMax];

	void Reset_Game(void);
	void Record_Move(int32_t row, int32_t column);	
};


bool Check_IfAnOtherMoveIsPossible(uint8_t board[3][3]);
int32_t MiniMaxEvaluatePlayer1(uint8_t Board[ConstNumBoardRows][ConstNumBoardColumns]);
int32_t MiniMaxEvaluatePlayer2(uint8_t Board[ConstNumBoardRows][ConstNumBoardColumns]);

// alpha: bester Wert, der bei einem Spielzug (Maximizer) erreicht werden kann
// beta: bester Wert, der bei einem gegnerischen Spielzug (Minimizer) erreicht werden kann
int32_t MiniMaxPlayer1Evaluation(uint8_t Board[ConstNumBoardRows][ConstNumBoardColumns], int32_t searchDepth, bool searchForMaximum, int32_t alpha, int32_t beta);
int32_t MiniMaxPlayer2Evaluation(uint8_t Board[ConstNumBoardRows][ConstNumBoardColumns], int32_t searchDepth, bool searchForMaximum, int32_t alpha, int32_t beta);
CMove Find_BestMovePlayer1(uint8_t Board[ConstNumBoardRows][ConstNumBoardColumns]);
CMove Find_BestMovePlayer2(uint8_t Board[ConstNumBoardRows][ConstNumBoardColumns]);


#endif