#include <iostream>
#include "Graph.h"
#include "ConsoleHelperFunctions.h"
#include "MathInlineFunctions.h"
#include "SparseVectorMatrix.h"
#include "Clustering.h"
#include "GeneticAlgorithms.h"

using namespace std;
using namespace HelperStuff;

#define KEYDOWN(vk_code) ((GetAsyncKeyState(vk_code) & 0x8000) ? 1 : 0)
#define KEYUP(vk_code)   ((GetAsyncKeyState(vk_code) & 0x8000) ? 0 : 1)

/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	static constexpr int32_t ConstNumOfPoints = 4;
	static constexpr int32_t ConstNumOfClusters = 2;

	static C2DPoint_InsideCluster PointArray[ConstNumOfPoints];
	static C2DClusterCentroid CentroidArray[ConstNumOfClusters];

	PointArray[0].x = 0.0f;
	PointArray[0].y = 0.0f;

	PointArray[1].x = 1.0f;
	PointArray[1].y = 0.0f;

	PointArray[2].x = 0.0f;
	PointArray[2].y = 1.0f;

	PointArray[3].x = 1.0f;
	PointArray[3].y = 1.0f;

	for (int32_t i = 0; i < ConstNumOfClusters; i++)
	{
		CentroidArray[i].centroidID = i;
	}

	CentroidArray[0].centroidID = 0;
	CentroidArray[0].centerX = PointArray[2].x;
	CentroidArray[0].centerY = PointArray[2].y;

	CentroidArray[1].centroidID = 1;
	CentroidArray[1].centerX = PointArray[3].x;
	CentroidArray[1].centerY = PointArray[3].y;

	//CentroidArray[0].centroidID = 0;
	//CentroidArray[0].centerX = -0.5f;
	//CentroidArray[0].centerY = -0.2f;

	//CentroidArray[1].centroidID = 1;
	//CentroidArray[1].centerX = 1.5f;
	//CentroidArray[1].centerY = 0.9f;



	Calculate_Clusters(CentroidArray, ConstNumOfClusters, PointArray, ConstNumOfPoints, 100);

	cout << fixed;
	//cout << defaultfloat;
	cout.precision(2);

	for (int32_t i = 0; i < ConstNumOfClusters; i++)
	{
		cout << "centerX: " << CentroidArray[i].centerX << " centerY: " << CentroidArray[i].centerY << endl;
	}

	cout << endl;

	for (int32_t i = 0; i < ConstNumOfPoints; i++)
	{
		cout << PointArray[i].clusterID << " ";
	}

	cout << endl;

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/




/*
int main(void)
{
	static constexpr int32_t ImageSizeX = 32;
	static constexpr int32_t ImageSizeY = 32;
	static constexpr int32_t ImageSizeXY = ImageSizeX * ImageSizeY;


	static float TestImage1[ImageSizeXY];

	uint8_t* pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("TestSample.bmp");

	Get_BinaryImageData_BlueChannel(TestImage1, pImageData, ImageSizeX, ImageSizeY);

	delete[] pImageData;
	pImageData = nullptr;

	int32_t NumOfNonZeroPixel = 0;

	for (int32_t i = 0; i < ImageSizeXY; i++)
	{
		if (TestImage1[i] > 0.0f)
		{
			NumOfNonZeroPixel++;
		}
	}

	static constexpr int32_t ConstNumOfClusters = 8;
	static C2DClusterCentroid CentroidArray[ConstNumOfClusters];
	static C2DClusterCentroid OptimizedCentroidArray[ConstNumOfClusters];

	C2DPoint_InsideCluster* pPixelArray = new (std::nothrow) C2DPoint_InsideCluster[NumOfNonZeroPixel];

	int32_t pixelCounter = 0;

	for (int32_t iy = 0; iy < ImageSizeY; iy++)
	{
		int32_t iiy = iy * ImageSizeX;

		for (int32_t ix = 0; ix < ImageSizeX; ix++)
		{
			int32_t id = ix + iiy;

			if (TestImage1[id] > 0.0f)
			{
				pPixelArray[pixelCounter].x = static_cast<float>(ix);
				pPixelArray[pixelCounter].y = static_cast<float>(iy);

				pixelCounter++;
			}
		}
	}

	CRandomNumbersNN RandomNumbers;

	for (int32_t i = 0; i < ConstNumOfClusters; i++)
	{
		OptimizedCentroidArray[i].centroidID = i;
		CentroidArray[i].centroidID = i;
	}

	float minVariance = 100000.0f;

	for (int32_t j = 0; j < 100; j++)
	{

		for (int32_t i = 0; i < ConstNumOfClusters; i++)
		{
			CentroidArray[i].centerX = RandomNumbers.Get_FloatNumber(5.0f, 26.0f);
			CentroidArray[i].centerY = RandomNumbers.Get_FloatNumber(5.0f, 26.0f);
		}

		Calculate_Clusters(CentroidArray, ConstNumOfClusters, pPixelArray, NumOfNonZeroPixel, 200);

		Calculate_ClusterRadiusSqs(CentroidArray, ConstNumOfClusters, pPixelArray, NumOfNonZeroPixel);

		float variance = Calculate_ClusterRadiusVariance(CentroidArray, ConstNumOfClusters);

		cout << "variance: " << variance << endl;

		if (variance < minVariance)
		{
			minVariance = variance;

			for (int32_t i = 0; i < ConstNumOfClusters; i++)
			{
				OptimizedCentroidArray[i].Set_Centroid(&CentroidArray[i]);
			}
		}
	} // end of for (int32_t j = 0; j < 30; j++)

	cout << endl << "Press Return: " << endl;
	getchar();
	cout << endl;

	for (int32_t i = 0; i < ConstNumOfClusters; i++)
	{
		int32_t ix = static_cast<int32_t>(OptimizedCentroidArray[i].centerX);
		int32_t iy = static_cast<int32_t>(OptimizedCentroidArray[i].centerY);

		TestImage1[ix + iy * ImageSizeX] = 8;
	}


	for (int32_t iy = 0; iy < ImageSizeY; iy++)
	{
		int32_t iiy = iy * ImageSizeX;

		for (int32_t ix = 0; ix < ImageSizeX; ix++)
		{
			int32_t id = ix + iiy;

			cout << TestImage1[id];
		}

		cout << endl;
	}

	cout << endl;

	delete[] pPixelArray;
	pPixelArray = nullptr;

	cout << "bye bye (Press Return)" << endl;
	getchar();

	return 0;
}
*/



static constexpr int32_t NumSurfaceMapElementsPerDir = 13;
static constexpr int32_t NumSurfaceMapElements = NumSurfaceMapElementsPerDir * NumSurfaceMapElementsPerDir;
static constexpr int32_t NumSurfaceMapElementsPerDirMinus1 = NumSurfaceMapElementsPerDir - 1;

static void Output_SurfaceMapData(char* pData)
{
	for (int32_t iy = 0; iy < NumSurfaceMapElementsPerDir; iy++)
	{
		int32_t iiy = iy * NumSurfaceMapElementsPerDir;

		for (int32_t ix = 0; ix < NumSurfaceMapElementsPerDir; ix++)
		{
			int32_t id = ix + iiy;
			cout << pData[id] << " ";
		}

		cout << endl;
	}

	cout << endl << endl;
}

static void Set_SurfaceMapData(char* pOutData, int32_t ix, int32_t iy, char sign)
{
	ix = max(0, ix);
	iy = max(0, iy);

	ix = min(NumSurfaceMapElementsPerDirMinus1, ix);
	iy = min(NumSurfaceMapElementsPerDirMinus1, iy);

	int32_t id = ix + iy * NumSurfaceMapElementsPerDir;
	pOutData[id] = sign;
}

static void Init_SurfaceMap(char* pOutData, char sign)
{
	uint32_t ix, iy, id;

	for (iy = 0; iy < NumSurfaceMapElementsPerDir; iy++)
	{
		for (ix = 0; ix < NumSurfaceMapElementsPerDir; ix++)
		{
			id = ix + iy * NumSurfaceMapElementsPerDir;
			pOutData[id] = sign;
		}
	}
}

static constexpr int32_t NumCities_TSP = 12;
static constexpr int32_t NumCities_TSP_Plus1 = NumCities_TSP + 1;

static constexpr int32_t NumCities_Path = 5;
static constexpr int32_t NumCities_Path_Plus1 = NumCities_Path + 1;

/*
int main(void)
{
	CRandomNumbersNN  RandomNumbers;

	static float CityPosXArray[NumCities_TSP];
	static float CityPosYArray[NumCities_TSP];


	float CenterX = static_cast<float>(NumSurfaceMapElementsPerDir / 2);
	float CenterY = static_cast<float>(NumSurfaceMapElementsPerDir / 2);
	float CenterZ = 0.0f;


	float deltaAngle = fConst2PI / static_cast<float>(NumCities_TSP);
	float radius = 5.0f;

	for (int32_t i = 0; i < NumCities_TSP; i++)
	{
		float angle = static_cast<float>(i) * deltaAngle;

		CityPosXArray[i] = CenterX + radius * sin(angle);
		CityPosYArray[i] = CenterY + radius * cos(angle);
	}

	//CityPosXArray[4] -= 1.0f;
	//CityPosYArray[4] -= 1.0f;
	//CityPosXArray[9] += 2.0f;


	// Visualisierung der einzelnen St�dte:

	static char SurfaceMap[NumSurfaceMapElements];

	Init_SurfaceMap(SurfaceMap, '*');

	for (int32_t i = 0; i < NumCities_TSP; i++)
	{
		char sign = 'X';
		Set_SurfaceMapData(SurfaceMap, CityPosXArray[i], CityPosYArray[i], sign);
	}

	Output_SurfaceMapData(SurfaceMap);

	// Visualisierung der einzelnen St�dte abgeschlossen

	CenterX = 0.0f;
	CenterY = 0.0f;
	CenterZ = 0.0f;

	for (int32_t i = 0; i < NumCities_TSP; i++)
	{
		CenterX += CityPosXArray[i];
		CenterY += CityPosYArray[i];
	}

	float tempfloat = 1.0f / static_cast<float>(NumCities_TSP);

	CenterX *= tempfloat;
	CenterY *= tempfloat;


	static constexpr int32_t NumGeneralNodes = 2*NumCities_TSP;

	static CGeneralNode GeneralNodeArray[NumGeneralNodes];

	deltaAngle = fConst2PI / static_cast<float>(NumGeneralNodes);
	radius = 3.0f;

	float featureArray[2];

	for (int32_t i = 0; i < NumGeneralNodes; i++)
	{
		float angle = static_cast<float>(i) * deltaAngle;

		GeneralNodeArray[i].Connect_With_NodeArray(GeneralNodeArray, NumGeneralNodes);
		GeneralNodeArray[i].Set_CircumferencePos(angle, radius);
		GeneralNodeArray[i].Init_FeatureValueArray(2);

		featureArray[0] = CenterX + radius * sin(angle);
		featureArray[1] = CenterY + radius * cos(angle);

		GeneralNodeArray[i].Set_Features(featureArray);
	}

	float inputArray[2];

	float maxError = 0.25f;

	float adaptionRate = 0.25f;
	float adaptionDistFactor = 0.975f;
	float adaptionIterationCountFactor = 0.025f;

	int32_t NumOfIterationSteps = 40;

	for (int32_t iteration = 0; iteration < NumOfIterationSteps; iteration++)
	{
		for (int32_t i = 0; i < NumGeneralNodes; i++)
		{
			GeneralNodeArray[i].Enable_CompetitionModus();
			GeneralNodeArray[i].Enable_AdaptionModus();
		}

		for (int32_t i = 0; i < NumCities_TSP; i++)
		{
			inputArray[0] = CityPosXArray[i];
			inputArray[1] = CityPosYArray[i];

			int32_t idOfBestMatchingNode = Get_IDOfBestMatchingNode(inputArray, GeneralNodeArray, NumGeneralNodes);
			GeneralNodeArray[idOfBestMatchingNode].Disable_CompetitionModus();

			for (int32_t j = 0; j < NumGeneralNodes; j++)
			{
				GeneralNodeArray[j].Adapt_Features_CircumferenceNodeSpace(idOfBestMatchingNode, adaptionRate, iteration, adaptionIterationCountFactor, adaptionDistFactor, inputArray);
			}

			//GeneralNodeArray[idOfBestMatchingNode].Disable_AdaptionModus();
		}
	}

	cout << endl;

	Init_SurfaceMap(SurfaceMap, '*');

	for (int32_t i = 0; i < NumGeneralNodes; i++)
	{
		char sign = 65 + i;

		for (int32_t j = 0; j < NumCities_TSP; j++)
		{
			if (abs(CityPosXArray[j] - GeneralNodeArray[i].pFeatureValueArray[0]) < maxError)
			{
				if (abs(CityPosYArray[j] - GeneralNodeArray[i].pFeatureValueArray[1]) < maxError)
				{
					GeneralNodeArray[i].pFeatureValueArray[0] = CityPosXArray[j];
					GeneralNodeArray[i].pFeatureValueArray[1] = CityPosYArray[j];
				}
			}
		}

		Set_SurfaceMapData(SurfaceMap, GeneralNodeArray[i].pFeatureValueArray[0], GeneralNodeArray[i].pFeatureValueArray[1], sign);
	}

	Output_SurfaceMapData(SurfaceMap);

	

	cout << "bye bye (Press Return)" << endl;
	getchar();

	return 0;
}
*/
