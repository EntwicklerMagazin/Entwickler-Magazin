#include <iostream>
#include "Graph.h"
#include "ConsoleHelperFunctions.h"
#include "MathInlineFunctions.h"
#include "SparseVectorMatrix.h"
//#include "Clustering.h"
#include "GeneticAlgorithms.h"
#include "FuzzyLogic.h"

using namespace std;
using namespace HelperStuff;

#define KEYDOWN(vk_code) ((GetAsyncKeyState(vk_code) & 0x8000) ? 1 : 0)
#define KEYUP(vk_code)   ((GetAsyncKeyState(vk_code) & 0x8000) ? 0 : 1)


/*
int main(void)
{
	static float DataVector[4];
	
	DataVector[0] = -0.1;
	DataVector[1] = 0.4;
	DataVector[2] = 0.3;
	DataVector[3] = 0.0;

	static int32_t DistributionVector[100];

	int32_t distributionVectorElements = Calc_DistributionVector(DistributionVector, 100, DataVector, 4, 10.0f);

	for (int32_t i = 0; i < distributionVectorElements; i++)
	{
		cout << DistributionVector[i] << " ";
	}

	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	
	static constexpr int32_t  ConstTrainingPopulationSize = 100;
	int32_t NumTrainingGenerationsMax = 2000;


	static constexpr int32_t NumInputOrOutputValues = 9;
	

	static float InputData[NumInputOrOutputValues];

	InputData[0] = -4.0f;
	InputData[1] = -3.0f;
	InputData[2] = -2.0f;
	InputData[3] = -1.0f;
	InputData[4] = 0.0f;
	InputData[5] = 1.0f;
	InputData[6] = 2.0f;
	InputData[7] = 3.0f;
	InputData[8] = 4.0f;


	static constexpr int32_t ConstNumOfGenes = 4;

	// Output = (a * Input * Input * Input + b * Input * Input + c * Input + offset)

	float a = 0.5f;
	float b = 1.65f;
	float c = -0.85f;
	float offset = 1.0f;


	static float CorrectOutputData[NumInputOrOutputValues];

	for (int32_t i = 0; i < NumInputOrOutputValues; i++)
	{
		float inputValue = InputData[i];

		CorrectOutputData[i] = a * inputValue * inputValue * inputValue +
			b * inputValue * inputValue +
			c * inputValue + offset;
	}

	static CSimpleFloatValueGenome GenomeArray[ConstTrainingPopulationSize];

	CSimpleFloatValueGenome BestGenome;
	BestGenome.Initialize(ConstNumOfGenes);

	CGeneralPopulation Population;
	Population.Set_GenomeValueCloningFunction(CSimpleFloatValueGenome_CloningFunction);


	Population.Initialize(ConstTrainingPopulationSize);

	
	for (int32_t i = 0; i < ConstTrainingPopulationSize; i++)
	{
		GenomeArray[i].Initialize(ConstNumOfGenes);
		Population.Set_Genome(&GenomeArray[i], i);
	}

	
	CSimpleReinitializationInfo ReinitializationInfo;
	ReinitializationInfo.minValue = -2.0f;
	ReinitializationInfo.maxValue = 2.0f;

	for (int32_t individual = 0; individual < ConstTrainingPopulationSize; individual++)
	{
		Reinitialization_Example2(&GenomeArray[individual], &RandomNumbers, &ReinitializationInfo);
	}

	CSimpleMutationInfo MutationInfo;

	MutationInfo.minValue = -0.1f;
	MutationInfo.maxValue = 0.1f;


	Population.Reset_Population();

	for (int32_t generation = 0; generation < NumTrainingGenerationsMax; generation++)
	{
		Population.Reset_MinErrorSum_ActualGeneration();

		for (int32_t individual = 0; individual < ConstTrainingPopulationSize; individual++)
		{
			float *pGeneArray = GenomeArray[individual].pGeneArray;

			float SumOfErrors = 0.000001f;

			for (int32_t i = 0; i < NumInputOrOutputValues; i++)
			{
				float inputValue = InputData[i];

				float outputValue = pGeneArray[0] * inputValue * inputValue * inputValue +
					pGeneArray[1] * inputValue * inputValue +
					pGeneArray[2] * inputValue + pGeneArray[3];

				float diff = outputValue - CorrectOutputData[i];
				SumOfErrors += diff * diff;
			}

			Population.Calculate_FitnessScore_FromError(individual, SumOfErrors);
			//Population.Set_FitnessScore(individual, 1.0f / SumOfErrors);
			Population.Update_MinErrorSum_ActualGeneration(SumOfErrors);
		}

		Population.Update_Population();

		if (generation % 50 == 0)
		{
			cout << "minErrorSum: " << Population.MinErrorSum_ActualGeneration << endl;
		}

		if (Population.MinErrorSum_ActualGeneration < 0.01f)
		{
			cout << endl;
			cout << "minErrorSum: " << Population.MinErrorSum_ActualGeneration << endl;
			cout << "actual generation: " << generation << endl;
			cout << "training completed" << endl << endl;
			break;
		}

		if (Population.MinErrorSum_ActualGeneration < 1.0f)
		{
			MutationInfo.minValue = -0.01f;
			MutationInfo.maxValue = 0.01f;
		}
		else if (Population.MinErrorSum_ActualGeneration < 0.5f)
		{
			MutationInfo.minValue = -0.005f;
			MutationInfo.maxValue = 0.005f;
		}

		Population.Update_BaseEvolution(Mutation_Example2, &MutationInfo);
		Population.Update_Evolution_BestGenomeOnly(Mutation_Example2, &MutationInfo);
		Population.Update_Evolution_SecondBestGenomeOnly(Mutation_Example2, &MutationInfo);
		Population.Update_Evolution_Combine_BestTwoGenomes(Recombination_Example2, nullptr);
		Population.Update_Evolution_Combine_TwoGenomes(Recombination_Example2, nullptr);
		Population.Update_Evolution_Combine_TwoGenomes(Recombination_Example2, nullptr);

		Population.Replace_WorstFitted_Genome(Reinitialization_Example2,  &RandomNumbers, &ReinitializationInfo);
	}

	Population.Get_Best_Evolved_Genome(&BestGenome);

	
	//getchar();


	for (int32_t i = 0; i < NumInputOrOutputValues; i++)
	{
		float *pGeneArray = BestGenome.pGeneArray;

		float inputValue = InputData[i];

		float outputValue = pGeneArray[0] * inputValue * inputValue * inputValue +
			pGeneArray[1] * inputValue * inputValue +
			pGeneArray[2] * inputValue + pGeneArray[3];

		cout << "output: " << outputValue << " correct output: " << CorrectOutputData[i] << endl;
	}


	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	static constexpr int32_t  ConstTrainingPopulationSize = 1000;
	int32_t NumTrainingGenerationsMax = 5000;

	static constexpr int32_t NumInputOrOutputValues = 9;

	static float InputData[NumInputOrOutputValues];

	InputData[0] = -4.0f;
	InputData[1] = -3.0f;
	InputData[2] = -2.0f;
	InputData[3] = -1.0f;
	InputData[4] = 0.0f;
	InputData[5] = 1.0f;
	InputData[6] = 2.0f;
	InputData[7] = 3.0f;
	InputData[8] = 4.0f;


	static constexpr int32_t ConstNumOfGenesMax = 5;

	// Output = (a * Input * Input * Input + b * Input * Input + c * Input + offset)

	float a = 0.5f;
	float b = 1.65f;
	//float c = -0.85f;
	float c = 0.0f;
	float offset = 1.0f;
	

	static float CorrectOutputData[NumInputOrOutputValues];

	for (int32_t i = 0; i < NumInputOrOutputValues; i++)
	{
		float inputValue = InputData[i];

		CorrectOutputData[i] = a * inputValue * inputValue * inputValue +
			b * inputValue * inputValue +
			c * inputValue + offset;
	}

	static CFloatValueGenome GenomeArray[ConstTrainingPopulationSize];

	CFloatValueGenome BestGenome;
	BestGenome.Initialize(ConstNumOfGenesMax);

	CGeneralPopulation Population;
	Population.Set_GenomeValueCloningFunction(CFloatValueGenome_CloningFunction);


	Population.Initialize(ConstTrainingPopulationSize);


	for (int32_t i = 0; i < ConstTrainingPopulationSize; i++)
	{
		GenomeArray[i].Initialize(ConstNumOfGenesMax);
		Population.Set_Genome(&GenomeArray[i], i);
	}

	
	CSimpleMultipleSpeciesReinitializationInfo ReinitializationInfo;
	ReinitializationInfo.Initialize(ConstNumOfGenesMax);
	ReinitializationInfo.minValue = -2.0f;
	ReinitializationInfo.maxValue = 2.0f;
	ReinitializationInfo.geneDeactivationRate = 0.75f;
	ReinitializationInfo.pGeneChangeableUsageArray[0] = true;
	ReinitializationInfo.pGeneChangeableUsageArray[1] = true;
	ReinitializationInfo.pGeneChangeableUsageArray[2] = true;
	ReinitializationInfo.pGeneChangeableUsageArray[3] = true;
	ReinitializationInfo.pGeneChangeableUsageArray[4] = false;
	

	for (int32_t individual = 0; individual < ConstTrainingPopulationSize; individual++)
	{
		Reinitialization_Example3(&GenomeArray[individual], &RandomNumbers, &ReinitializationInfo);
	}


	CSimpleMutationInfo MutationInfo;

	MutationInfo.minValue = -0.1f;
	MutationInfo.maxValue = 0.1f;
	MutationInfo.mutationRate = 1.0f;

	Population.Reset_Population();

	for (int32_t generation = 0; generation < NumTrainingGenerationsMax; generation++)
	{
		Population.Reset_MinErrorSum_ActualGeneration();

		for (int32_t individual = 0; individual < ConstTrainingPopulationSize; individual++)
		{
			float *pGeneArray = GenomeArray[individual].pGeneArray;
			bool *pGeneUsageArray = GenomeArray[individual].pGeneUsageArray;

			float SumOfErrors = 0.000001f;

			for (int32_t i = 0; i < NumInputOrOutputValues; i++)
			{
				float inputValue = InputData[i];

				float outputValue = 0.0f;

				if (pGeneUsageArray[0] == true)
					outputValue += pGeneArray[0] * inputValue * inputValue * inputValue * inputValue;

				if (pGeneUsageArray[1] == true)
					outputValue += pGeneArray[1] * inputValue * inputValue * inputValue;

				if (pGeneUsageArray[2] == true)
					outputValue += pGeneArray[2] * inputValue * inputValue;

				if (pGeneUsageArray[3] == true)
					outputValue += pGeneArray[3] * inputValue;
			
				outputValue += pGeneArray[4];
				
				float diff = outputValue - CorrectOutputData[i];
				SumOfErrors += diff * diff;
			}

			Population.Calculate_FitnessScore_FromError(individual, SumOfErrors);
			//Population.Set_FitnessScore(individual, 1.0f / SumOfErrors);
			Population.Update_MinErrorSum_ActualGeneration(SumOfErrors);
		}

		Population.Update_Population();

		if (generation % 200 == 0)
		{
			cout << "minErrorSum: " << Population.MinErrorSum_ActualGeneration << endl;
		}

		if (Population.MinErrorSum_ActualGeneration < 0.01f)
		{
			cout << endl;
			cout << "minErrorSum: " << Population.MinErrorSum_ActualGeneration << endl;
			cout << "actual generation: " << generation << endl;
			cout << "training completed" << endl << endl;
			break;
		}

		if (Population.MinErrorSum_ActualGeneration < 1.0f)
		{
			MutationInfo.minValue = -0.01f;
			MutationInfo.maxValue = 0.01f;
		}
		else if (Population.MinErrorSum_ActualGeneration < 0.5f)
		{
			MutationInfo.minValue = -0.005f;
			MutationInfo.maxValue = 0.005f;
		}

		Population.Update_BaseEvolution(Mutation_Example3, &MutationInfo);
		Population.Update_Evolution_BestGenomeOnly(Mutation_Example3, &MutationInfo);
		Population.Update_Evolution_SecondBestGenomeOnly(Mutation_Example3, &MutationInfo);
		Population.Update_Evolution_Combine_BestTwoGenomes(Recombination_Example4, nullptr);
		Population.Update_Evolution_Combine_TwoGenomes(Recombination_Example4, nullptr);
		Population.Update_Evolution_Combine_TwoGenomes(Recombination_Example4, nullptr);
		Population.Replace_WorstFitted_Genome(Reinitialization_Example3, &RandomNumbers, &ReinitializationInfo);
	}

	Population.Get_Best_Evolved_Genome(&BestGenome);


	//getchar();

	// show species:
	cout << "best fitted species: ";
	for (int32_t i = 0; i < ConstNumOfGenesMax; i++)
		cout << static_cast<int32_t>(BestGenome.pGeneUsageArray[i]) << " ";

	cout << endl;

	for (int32_t i = 0; i < NumInputOrOutputValues; i++)
	{
		float *pGeneArray = BestGenome.pGeneArray;
		bool *pGeneUsageArray = BestGenome.pGeneUsageArray;

		float inputValue = InputData[i];

		float outputValue = 0.0f;

		if (pGeneUsageArray[0] == true)
			outputValue += pGeneArray[0] * inputValue * inputValue * inputValue * inputValue;

		if (pGeneUsageArray[1] == true)
			outputValue += pGeneArray[1] * inputValue * inputValue * inputValue;

		if (pGeneUsageArray[2] == true)
			outputValue += pGeneArray[2] * inputValue * inputValue;

		if(pGeneUsageArray[3] == true)
			outputValue += pGeneArray[3] * inputValue;
	
		outputValue += pGeneArray[4];


		cout << "output: " << outputValue << " correct output: " << CorrectOutputData[i] << endl;
	}


	getchar();
	return 0;
}
*/





/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	static constexpr int32_t NumInputOrOutputValues = 21;

	static float InputData[NumInputOrOutputValues];

	InputData[0] = -2.0f;

	for (int32_t i = 1; i < NumInputOrOutputValues; i++)
	{
		InputData[i] = InputData[i - 1] + 0.2f;
	}


	static float CorrectOutputData[NumInputOrOutputValues];

	

	for (int32_t i = 0; i < NumInputOrOutputValues; i++)
	{
		
		CorrectOutputData[i] = sin(InputData[i]);
		CorrectOutputData[i] += sin(1.5f * InputData[i] + 0.5f) + 0.25f;

		//CorrectOutputData[i] += RandomNumbers.Get_FloatNumber(-0.1f, 0.1f);
	}


	static constexpr int32_t ConstNumOfCentroids = NumInputOrOutputValues;
	static float CentroidArray[ConstNumOfCentroids];

	for (int32_t i = 0; i < ConstNumOfCentroids; i++)
	{
		
		CentroidArray[i] = InputData[i];
	}


	static constexpr int32_t ConstNumOfGenes = ConstNumOfCentroids;

	float FunctionParamArray[ConstNumOfGenes];
	float rbfFactor = 0.5f;
	
	static constexpr int32_t  ConstTrainingPopulationSize = 100;
	int32_t NumTrainingGenerationsMax = 20000;


	static CSimpleFloatValueGenome GenomeArray[ConstTrainingPopulationSize];

	CSimpleFloatValueGenome BestGenome;
	BestGenome.Initialize(ConstNumOfGenes);

	CGeneralPopulation Population;
	Population.Set_GenomeValueCloningFunction(CSimpleFloatValueGenome_CloningFunction);


	Population.Initialize(ConstTrainingPopulationSize);


	for (int32_t i = 0; i < ConstTrainingPopulationSize; i++)
	{
		GenomeArray[i].Initialize(ConstNumOfGenes);
		Population.Set_Genome(&GenomeArray[i], i);
	}


	CSimpleReinitializationInfo ReinitializationInfo;
	ReinitializationInfo.minValue = -2.0f;
	ReinitializationInfo.maxValue = 2.0f;

	for (int32_t individual = 0; individual < ConstTrainingPopulationSize; individual++)
	{
		Reinitialization_Example2(&GenomeArray[individual], &RandomNumbers, &ReinitializationInfo);
	}

	CSimpleMutationInfo MutationInfo;

	MutationInfo.minValue = -0.01f;
	MutationInfo.maxValue = 0.01f;
	MutationInfo.mutationRate = 0.25f;


	Population.Reset_Population();

	for (int32_t generation = 0; generation < NumTrainingGenerationsMax; generation++)
	{
		Population.Reset_MinErrorSum_ActualGeneration();

		for (int32_t individual = 0; individual < ConstTrainingPopulationSize; individual++)
		{
			float* pGeneArray = GenomeArray[individual].pGeneArray;

			float SumOfErrors = 0.000001f;

			for (int32_t i = 0; i < NumInputOrOutputValues; i++)
			{
				if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > 0.8f)
					continue;

				float outputValue = GaussianRBF_1D(InputData[i], rbfFactor, CentroidArray, pGeneArray, ConstNumOfCentroids);

				float diff = outputValue - CorrectOutputData[i];
				SumOfErrors += diff * diff;
			}

			Population.Calculate_FitnessScore_FromError(individual, SumOfErrors);
			//Population.Set_FitnessScore(individual, 1.0f / SumOfErrors);
			Population.Update_MinErrorSum_ActualGeneration(SumOfErrors);
		}

		Population.Update_Population();

		if (generation % 500 == 0)
		{
			cout << "minErrorSum: " << Population.MinErrorSum_ActualGeneration << endl;
		}

		//if (Population.MinErrorSum_ActualGeneration < 0.005f)
		if (Population.MinErrorSum_ActualGeneration < 0.01f)
		{
			cout << endl;
			cout << "minErrorSum: " << Population.MinErrorSum_ActualGeneration << endl;
			cout << "actual generation: " << generation << endl;
			cout << "training completed" << endl << endl;
			break;
		}

		if (Population.MinErrorSum_ActualGeneration < 0.5f)
		{
			MutationInfo.minValue = -0.005f;
			MutationInfo.maxValue = 0.005f;
		}
		else if (Population.MinErrorSum_ActualGeneration < 0.1f)
		{
			MutationInfo.minValue = -0.0025f;
			MutationInfo.maxValue = 0.0025f;
		}


		Population.Update_BaseEvolution(Mutation_Example2, &MutationInfo);
		Population.Update_Evolution_BestGenomeOnly(Mutation_Example2, &MutationInfo);
		Population.Update_Evolution_SecondBestGenomeOnly(Mutation_Example2, &MutationInfo);
		//Population.Update_BaseEvolution(Mutation_Example2B, &MutationInfo);
		//Population.Update_Evolution_BestGenomeOnly(Mutation_Example2B, &MutationInfo);
		//Population.Update_Evolution_SecondBestGenomeOnly(Mutation_Example2B, &MutationInfo);
		Population.Update_Evolution_Combine_BestTwoGenomes(Recombination_Example2, nullptr);
		Population.Update_Evolution_Combine_TwoGenomes(Recombination_Example2, nullptr);
		Population.Update_Evolution_Combine_TwoGenomes(Recombination_Example2, nullptr);

		Population.Replace_WorstFitted_Genome(Reinitialization_Example2, &RandomNumbers, &ReinitializationInfo);
	}

	Population.Get_Best_Evolved_Genome(&BestGenome);


	//getchar();

	float* pGeneArray = BestGenome.pGeneArray;

	for (int32_t i = 0; i < NumInputOrOutputValues; i++)
	{
		float outputValue = GaussianRBF_1D(InputData[i], rbfFactor, CentroidArray, pGeneArray, ConstNumOfCentroids);

		cout << "output: " << outputValue << " correct output: " << CorrectOutputData[i] << endl;
	}


	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	static constexpr int32_t NumInputOrOutputValues = 21;

	static float InputData[NumInputOrOutputValues];

	InputData[0] = -2.0f;

	for (int32_t i = 1; i < NumInputOrOutputValues; i++)
	{
		InputData[i] = InputData[i - 1] + 0.2f;
	}


	static float CorrectOutputData[NumInputOrOutputValues];



	for (int32_t i = 0; i < NumInputOrOutputValues; i++)
	{

		CorrectOutputData[i] = sin(InputData[i]);
		CorrectOutputData[i] += sin(1.5f * InputData[i] + 0.5f) + 0.75f;

		//CorrectOutputData[i] += RandomNumbers.Get_FloatNumber(-0.1f, 0.1f);
	}


	
	static constexpr int32_t ConstNumOfRBFTerms = 4;
	static constexpr int32_t ConstNumOfGenes = 3 * ConstNumOfRBFTerms;

	
	static constexpr int32_t  ConstTrainingPopulationSize = 100;
	int32_t NumTrainingGenerationsMax = 30000;


	static CSimpleFloatValueGenome GenomeArray[ConstTrainingPopulationSize];

	CSimpleFloatValueGenome BestGenome;
	BestGenome.Initialize(ConstNumOfGenes);


	

	CGeneralPopulation Population;
	Population.Set_GenomeValueCloningFunction(CSimpleFloatValueGenome_CloningFunction);


	Population.Initialize(ConstTrainingPopulationSize);


	for (int32_t i = 0; i < ConstTrainingPopulationSize; i++)
	{
		GenomeArray[i].Initialize(ConstNumOfGenes);
		Population.Set_Genome(&GenomeArray[i], i);
	}


	CRBFReinitializationInfo ReinitializationInfo;

	ReinitializationInfo.minValue_FunctionParam = -2.0f;
	ReinitializationInfo.maxValue_FunctionParam = 2.0f;
	
	ReinitializationInfo.minValue_Centroid = InputData[0];
	ReinitializationInfo.maxValue_Centroid = InputData[NumInputOrOutputValues - 1];

	ReinitializationInfo.minValue_ExpFactor = 0.5f;
	ReinitializationInfo.maxValue_ExpFactor = 0.5f;
	

	for (int32_t individual = 0; individual < ConstTrainingPopulationSize; individual++)
	{
		Reinitialization_1DimRBFValues(&GenomeArray[individual], &RandomNumbers, &ReinitializationInfo);
	}

	CRBFMutationInfo MutationInfo;

	MutationInfo.minValue_FunctionParam = -0.01f;
	MutationInfo.maxValue_FunctionParam = 0.01f;
	MutationInfo.mutationRate_FunctionParam = 0.25f;

	MutationInfo.minValue_Centroid = -0.05f;
	MutationInfo.maxValue_Centroid = 0.05f;
	MutationInfo.mutationRate_Centroid = 0.25f;

	MutationInfo.minValue_ExpFactor = 0.0f;
	MutationInfo.maxValue_ExpFactor = 0.0f;
	MutationInfo.mutationRate_ExpFactor = 0.0f;


	Population.Reset_Population();

	for (int32_t generation = 0; generation < NumTrainingGenerationsMax; generation++)
	{
		Population.Reset_MinErrorSum_ActualGeneration();

		for (int32_t individual = 0; individual < ConstTrainingPopulationSize; individual++)
		{
			float* pGeneArray = GenomeArray[individual].pGeneArray;

			float* pRBFFactorArray = &pGeneArray[0];
			float* pFunctionParamArray = &pGeneArray[ConstNumOfRBFTerms];
			float* pCentroidArray = &pGeneArray[2 * ConstNumOfRBFTerms];
		
			float SumOfErrors = 0.000001f;

			for (int32_t i = 0; i < NumInputOrOutputValues; i++)
			{
				if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > 0.8f)
					continue;

				float outputValue = GaussianRBF(&InputData[i], pRBFFactorArray, pCentroidArray, pFunctionParamArray, ConstNumOfRBFTerms, 1);
				//float outputValue = GaussianRBF_1D(InputData[i], pRBFFactorArray, pCentroidArray, pFunctionParamArray, ConstNumOfRBFTerms);

				float diff = outputValue - CorrectOutputData[i];
				SumOfErrors += diff * diff;
			}

			Population.Calculate_FitnessScore_FromError(individual, SumOfErrors);
			//Population.Set_FitnessScore(individual, 1.0f / SumOfErrors);
			Population.Update_MinErrorSum_ActualGeneration(SumOfErrors);
		}

		Population.Update_Population();

		if (generation % 500 == 0)
		{
			cout << "minErrorSum: " << Population.MinErrorSum_ActualGeneration << endl;
		}

		//if (Population.MinErrorSum_ActualGeneration < 0.005f)
		if (Population.MinErrorSum_ActualGeneration < 0.01f)
		{
			cout << endl;
			cout << "minErrorSum: " << Population.MinErrorSum_ActualGeneration << endl;
			cout << "actual generation: " << generation << endl;
			cout << "training completed" << endl << endl;
			break;
		}

	
		Population.Update_BaseEvolution(Mutation_1DimRBFValues, &MutationInfo);
		Population.Update_Evolution_BestGenomeOnly(Mutation_1DimRBFValues, &MutationInfo);
		Population.Update_Evolution_SecondBestGenomeOnly(Mutation_1DimRBFValues, &MutationInfo);
		Population.Update_Evolution_Combine_BestTwoGenomes(Recombination_Example2, nullptr);
		Population.Update_Evolution_Combine_TwoGenomes(Recombination_Example2, nullptr);
		Population.Update_Evolution_Combine_TwoGenomes(Recombination_Example2, nullptr);

		Population.Replace_WorstFitted_Genome(Reinitialization_1DimRBFValues, &RandomNumbers, &ReinitializationInfo);
	}

	Population.Get_Best_Evolved_Genome(&BestGenome);


	//getchar();

	float* pGeneArray = BestGenome.pGeneArray;

	float* pRBFFactorArray = &pGeneArray[0];
	float* pFunctionParamArray = &pGeneArray[ConstNumOfRBFTerms];
	float* pCentroidArray = &pGeneArray[2 * ConstNumOfRBFTerms];

	for (int32_t i = 0; i < NumInputOrOutputValues; i++)
	{
		float outputValue = GaussianRBF_1D(InputData[i], pRBFFactorArray, pCentroidArray, pFunctionParamArray, ConstNumOfRBFTerms);

		cout << "output: " << outputValue << " correct output: " << CorrectOutputData[i] << endl;
	}


	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	static constexpr int32_t NumInputOrOutputValues = 20;

	static float InputData[NumInputOrOutputValues];
	static float CorrectOutputData[NumInputOrOutputValues];

	for (int32_t i = 0; i < NumInputOrOutputValues; i++)
	{
		InputData[i] = static_cast<float>(i) * 10.0f;
		CorrectOutputData[i] = 0.0f;
	}

	// Description for a fuzzy number:

	CorrectOutputData[0] = 0.1f;
	CorrectOutputData[1] = 0.2f;
	CorrectOutputData[2] = 0.6f;
	CorrectOutputData[3] = 0.8f;
	CorrectOutputData[4] = 1.0f;
	CorrectOutputData[5] = 1.0f;
	CorrectOutputData[6] = 1.0f;
	CorrectOutputData[7] = 0.5f;
	CorrectOutputData[8] = 0.2f;
	CorrectOutputData[9] = 0.1f;

	static constexpr int32_t ConstNumOfRBFTerms = 10;
	static constexpr int32_t ConstNumOfGenes = 3 * ConstNumOfRBFTerms;

	//CorrectOutputData[0] = 1.0f;
	//CorrectOutputData[1] = 1.0f;
	//CorrectOutputData[2] = 1.0f;
	//CorrectOutputData[3] = 1.0f;
	//CorrectOutputData[4] = 0.8f;
	//CorrectOutputData[5] = 0.2f;
	
	//static constexpr int32_t ConstNumOfRBFTerms = 5;
	//static constexpr int32_t ConstNumOfGenes = 3 * ConstNumOfRBFTerms;


	static constexpr int32_t  ConstTrainingPopulationSize = 100;
	int32_t NumTrainingGenerationsMax = 30000;


	static CSimpleFloatValueGenome GenomeArray[ConstTrainingPopulationSize];

	CSimpleFloatValueGenome BestGenome;
	BestGenome.Initialize(ConstNumOfGenes);




	CGeneralPopulation Population;
	Population.Set_GenomeValueCloningFunction(CSimpleFloatValueGenome_CloningFunction);


	Population.Initialize(ConstTrainingPopulationSize);


	for (int32_t i = 0; i < ConstTrainingPopulationSize; i++)
	{
		GenomeArray[i].Initialize(ConstNumOfGenes);
		Population.Set_Genome(&GenomeArray[i], i);
	}


	CRBFReinitializationInfo ReinitializationInfo;

	ReinitializationInfo.minValue_FunctionParam = -1.0f;
	ReinitializationInfo.maxValue_FunctionParam = 1.0f;

	ReinitializationInfo.minValue_Centroid = InputData[0];
	ReinitializationInfo.maxValue_Centroid = InputData[NumInputOrOutputValues - 1];

	ReinitializationInfo.minValue_ExpFactor = 0.001f; // bigger values => wrong interpretation
	ReinitializationInfo.maxValue_ExpFactor = 0.002f;

	for (int32_t individual = 0; individual < ConstTrainingPopulationSize; individual++)
	{
		Reinitialization_1DimRBFValues(&GenomeArray[individual], &RandomNumbers, &ReinitializationInfo);
	}

	CRBFMutationInfo MutationInfo;

	MutationInfo.minValue_FunctionParam = -0.01f;
	MutationInfo.maxValue_FunctionParam = 0.01f;
	MutationInfo.mutationRate_FunctionParam = 0.25f;

	MutationInfo.minValue_Centroid = -1.0f;
	MutationInfo.maxValue_Centroid = 1.0f;
	MutationInfo.mutationRate_Centroid = 0.25f;

	MutationInfo.minValue_ExpFactor = -0.0001f;
	MutationInfo.maxValue_ExpFactor = 0.0001f;
	MutationInfo.mutationRate_ExpFactor = 0.25f;


	Population.Reset_Population();

	for (int32_t generation = 0; generation < NumTrainingGenerationsMax; generation++)
	{
		Population.Reset_MinErrorSum_ActualGeneration();

		for (int32_t individual = 0; individual < ConstTrainingPopulationSize; individual++)
		{
			float* pGeneArray = GenomeArray[individual].pGeneArray;

			float* pRBFFactorArray = &pGeneArray[0];
			float* pFunctionParamArray = &pGeneArray[ConstNumOfRBFTerms];
			float* pCentroidArray = &pGeneArray[2 * ConstNumOfRBFTerms];

			float SumOfErrors = 0.000001f;

			for (int32_t i = 0; i < NumInputOrOutputValues; i++)
			{
				//float outputValue = GaussianRBF(&InputData[i], pRBFFactorArray, pCentroidArray, pFunctionParamArray, ConstNumOfRBFTerms, 1);
				float outputValue = GaussianRBF_1D(InputData[i], pRBFFactorArray, pCentroidArray, pFunctionParamArray, ConstNumOfRBFTerms);

				float diff = outputValue - CorrectOutputData[i];
				SumOfErrors += diff * diff;
			}

			Population.Calculate_FitnessScore_FromError(individual, SumOfErrors);
			//Population.Set_FitnessScore(individual, 1.0f / SumOfErrors);
			Population.Update_MinErrorSum_ActualGeneration(SumOfErrors);
		}

		Population.Update_Population();

		if (generation % 500 == 0)
		{
			cout << "minErrorSum: " << Population.MinErrorSum_ActualGeneration << endl;
		}

		if (Population.MinErrorSum_ActualGeneration < 0.005f)
		//if (Population.MinErrorSum_ActualGeneration < 0.01f)
		{
			cout << endl;
			cout << "minErrorSum: " << Population.MinErrorSum_ActualGeneration << endl;
			cout << "actual generation: " << generation << endl;
			cout << "training completed" << endl << endl;
			break;
		}


		Population.Update_BaseEvolution(Mutation_1DimRBFValues, &MutationInfo);
		Population.Update_Evolution_BestGenomeOnly(Mutation_1DimRBFValues, &MutationInfo);
		Population.Update_Evolution_SecondBestGenomeOnly(Mutation_1DimRBFValues, &MutationInfo);
		Population.Update_Evolution_Combine_BestTwoGenomes(Recombination_Example2, nullptr);
		Population.Update_Evolution_Combine_TwoGenomes(Recombination_Example2, nullptr);
		Population.Update_Evolution_Combine_TwoGenomes(Recombination_Example2, nullptr);

		Population.Replace_WorstFitted_Genome(Reinitialization_1DimRBFValues, &RandomNumbers, &ReinitializationInfo);
	}

	Population.Get_Best_Evolved_Genome(&BestGenome);

	cout << endl;

	//getchar();

	float* pGeneArray = BestGenome.pGeneArray;

	float* pRBFFactorArray = &pGeneArray[0];
	float* pFunctionParamArray = &pGeneArray[ConstNumOfRBFTerms];
	float* pCentroidArray = &pGeneArray[2 * ConstNumOfRBFTerms];

	CGaussianFuzzyElement FuzzyElement;
	FuzzyElement.Initialize(ConstNumOfRBFTerms, pRBFFactorArray, pFunctionParamArray, pCentroidArray);

	

	for (int32_t i = 0; i < NumInputOrOutputValues; i++)
	{
		//float outputValue = GaussianRBF_1D(InputData[i], pRBFFactorArray, pCentroidArray, pFunctionParamArray, ConstNumOfRBFTerms);
		float outputValue = FuzzyElement.Calculate_Membership(InputData[i]);

		cout << "output: " << outputValue << " correct output: " << CorrectOutputData[i] << endl;
	}

	getchar();

	cout << endl;

	for (int32_t i = 0; i < NumInputOrOutputValues; i++)
	{
		float inputValue = 5.0f + static_cast<float>(i) * 10.0f;
		//float outputValue = GaussianRBF_1D(inputValue, pRBFFactorArray, pCentroidArray, pFunctionParamArray, ConstNumOfRBFTerms);
		float outputValue = FuzzyElement.Calculate_Membership(inputValue);

		cout << "input: " << inputValue << " output: " << outputValue << endl;
	}

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	static constexpr int32_t NumInputOrOutputValues = 20;

	static float InputData[NumInputOrOutputValues];
	static float CorrectOutputData[NumInputOrOutputValues];

	for (int32_t i = 0; i < NumInputOrOutputValues; i++)
	{
		InputData[i] = static_cast<float>(i) * 10.0f;
		CorrectOutputData[i] = 0.0f;
	}

	// Description for a fuzzy number:

	CorrectOutputData[0] = 0.1f;
	CorrectOutputData[1] = 0.2f;
	CorrectOutputData[2] = 0.6f;
	CorrectOutputData[3] = 0.8f;
	CorrectOutputData[4] = 1.0f;
	CorrectOutputData[5] = 1.0f;
	CorrectOutputData[6] = 1.0f;
	CorrectOutputData[7] = 0.5f;
	CorrectOutputData[8] = 0.2f;
	CorrectOutputData[9] = 0.1f;

	static constexpr int32_t ConstNumOfRBFTerms = 3;
	static constexpr int32_t ConstNumOfGenes = 4 * ConstNumOfRBFTerms;

	//CorrectOutputData[0] = 1.0f;
	//CorrectOutputData[1] = 1.0f;
	//CorrectOutputData[2] = 1.0f;
	//CorrectOutputData[3] = 1.0f;
	//CorrectOutputData[4] = 0.8f;
	//CorrectOutputData[5] = 0.2f;

	//static constexpr int32_t ConstNumOfRBFTerms = 5;
	//static constexpr int32_t ConstNumOfGenes = 4 * ConstNumOfRBFTerms;


	static constexpr int32_t  ConstTrainingPopulationSize = 100;
	int32_t NumTrainingGenerationsMax = 30000;


	static CSimpleFloatValueGenome GenomeArray[ConstTrainingPopulationSize];

	CSimpleFloatValueGenome BestGenome;
	BestGenome.Initialize(ConstNumOfGenes);




	CGeneralPopulation Population;
	Population.Set_GenomeValueCloningFunction(CSimpleFloatValueGenome_CloningFunction);


	Population.Initialize(ConstTrainingPopulationSize);


	for (int32_t i = 0; i < ConstTrainingPopulationSize; i++)
	{
		GenomeArray[i].Initialize(ConstNumOfGenes);
		Population.Set_Genome(&GenomeArray[i], i);
	}


	CRBFReinitializationInfo ReinitializationInfo;

	ReinitializationInfo.minValue_FunctionParam = -1.0f;
	ReinitializationInfo.maxValue_FunctionParam = 1.0f;

	ReinitializationInfo.minValue_Centroid = InputData[0];
	ReinitializationInfo.maxValue_Centroid = InputData[NumInputOrOutputValues - 1];

	ReinitializationInfo.minValue_ExpFactor = 0.001f; // bigger values => wrong interpretation
	ReinitializationInfo.maxValue_ExpFactor = 0.002f;

	for (int32_t individual = 0; individual < ConstTrainingPopulationSize; individual++)
	{
		Reinitialization_1DimAsymmetricRBFValues(&GenomeArray[individual], &RandomNumbers, &ReinitializationInfo);
	}

	CRBFMutationInfo MutationInfo;

	MutationInfo.minValue_FunctionParam = -0.01f;
	MutationInfo.maxValue_FunctionParam = 0.01f;
	MutationInfo.mutationRate_FunctionParam = 0.25f;

	MutationInfo.minValue_Centroid = -1.0f;
	MutationInfo.maxValue_Centroid = 1.0f;
	MutationInfo.mutationRate_Centroid = 0.25f;

	MutationInfo.minValue_ExpFactor = -0.0001f;
	MutationInfo.maxValue_ExpFactor = 0.0001f;
	MutationInfo.mutationRate_ExpFactor = 0.25f;


	Population.Reset_Population();

	for (int32_t generation = 0; generation < NumTrainingGenerationsMax; generation++)
	{
		Population.Reset_MinErrorSum_ActualGeneration();

		for (int32_t individual = 0; individual < ConstTrainingPopulationSize; individual++)
		{
			float* pGeneArray = GenomeArray[individual].pGeneArray;

			float* pRBFFactorArray_LeftHalf = &pGeneArray[0];
			float* pRBFFactorArray_RightHalf = &pGeneArray[ConstNumOfRBFTerms];
			float* pFunctionParamArray = &pGeneArray[2 *ConstNumOfRBFTerms];
			float* pCentroidArray = &pGeneArray[3 * ConstNumOfRBFTerms];

			float SumOfErrors = 0.000001f;

			for (int32_t i = 0; i < NumInputOrOutputValues; i++)
			{
				//float outputValue = AsymmetricGaussianRBF(&InputData[i], pRBFFactorArray_LeftHalf, pRBFFactorArray_RightHalf, pCentroidArray, pFunctionParamArray, ConstNumOfRBFTerms, 1);
				float outputValue = AsymmetricGaussianRBF_1D(InputData[i], pRBFFactorArray_LeftHalf, pRBFFactorArray_RightHalf, pCentroidArray, pFunctionParamArray, ConstNumOfRBFTerms);

				float diff = outputValue - CorrectOutputData[i];
				SumOfErrors += diff * diff;
			}

			Population.Calculate_FitnessScore_FromError(individual, SumOfErrors);
			//Population.Set_FitnessScore(individual, 1.0f / SumOfErrors);
			Population.Update_MinErrorSum_ActualGeneration(SumOfErrors);
		}

		Population.Update_Population();

		if (generation % 500 == 0)
		{
			cout << "minErrorSum: " << Population.MinErrorSum_ActualGeneration << endl;
		}

		if (Population.MinErrorSum_ActualGeneration < 0.005f)
			//if (Population.MinErrorSum_ActualGeneration < 0.01f)
		{
			cout << endl;
			cout << "minErrorSum: " << Population.MinErrorSum_ActualGeneration << endl;
			cout << "actual generation: " << generation << endl;
			cout << "training completed" << endl << endl;
			break;
		}


		Population.Update_BaseEvolution(Mutation_1DimAsymmetricRBFValues, &MutationInfo);
		Population.Update_Evolution_BestGenomeOnly(Mutation_1DimAsymmetricRBFValues, &MutationInfo);
		Population.Update_Evolution_SecondBestGenomeOnly(Mutation_1DimAsymmetricRBFValues, &MutationInfo);
		Population.Update_Evolution_Combine_BestTwoGenomes(Recombination_Example2, nullptr);
		Population.Update_Evolution_Combine_TwoGenomes(Recombination_Example2, nullptr);
		Population.Update_Evolution_Combine_TwoGenomes(Recombination_Example2, nullptr);

		Population.Replace_WorstFitted_Genome(Reinitialization_1DimAsymmetricRBFValues, &RandomNumbers, &ReinitializationInfo);
	}

	Population.Get_Best_Evolved_Genome(&BestGenome);

	cout << endl;

	//getchar();

	float* pGeneArray = BestGenome.pGeneArray;

	float* pRBFFactorArray_LeftHalf = &pGeneArray[0];
	float* pRBFFactorArray_RightHalf = &pGeneArray[ConstNumOfRBFTerms];
	float* pFunctionParamArray = &pGeneArray[2 * ConstNumOfRBFTerms];
	float* pCentroidArray = &pGeneArray[3 * ConstNumOfRBFTerms];

	CAsymmetricGaussianFuzzyElement FuzzyElement;
	FuzzyElement.Initialize(ConstNumOfRBFTerms, pRBFFactorArray_LeftHalf, pRBFFactorArray_RightHalf, pFunctionParamArray, pCentroidArray);



	for (int32_t i = 0; i < NumInputOrOutputValues; i++)
	{
		//float outputValue = AsymmetricGaussianRBF_1D(InputData[i], pRBFFactorArray_LeftHalf, pRBFFactorArray_RightHalf, pCentroidArray, pFunctionParamArray, ConstNumOfRBFTerms);
		float outputValue = FuzzyElement.Calculate_Membership(InputData[i]);

		cout << "output: " << outputValue << " correct output: " << CorrectOutputData[i] << endl;
	}

	getchar();

	cout << endl;

	for (int32_t i = 0; i < NumInputOrOutputValues; i++)
	{
		float inputValue = 5.0f + static_cast<float>(i) * 10.0f;
		//float outputValue = AsymmetricGaussianRBF_1D(inputValue, pRBFFactorArray_LeftHalf, pRBFFactorArray_RightHalf, pCentroidArray, pFunctionParamArray, ConstNumOfRBFTerms);
		float outputValue = FuzzyElement.Calculate_Membership(inputValue);

		cout << "input: " << inputValue << " output: " << outputValue << endl;
	}

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/



/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	static constexpr int32_t NumInputOrOutputValues = 4;

	float CorrectOutputData[NumInputOrOutputValues];

	CorrectOutputData[0] = 0.5f;
	CorrectOutputData[1] = 1.0f;
	CorrectOutputData[2] = 1.0f;
	CorrectOutputData[3] = -2.0f;

	float Input1[2] = { 0.0f, 0.0f };
	float Input2[2] = { 1.0f, 0.0f };
	float Input3[2] = { 0.0f, 1.0f };
	float Input4[2] = { 1.0f, 1.0f };

	float *pInputData[NumInputOrOutputValues];

	pInputData[0] = Input1;
	pInputData[1] = Input2;
	pInputData[2] = Input3;
	pInputData[3] = Input4;


	//static constexpr int32_t ConstNumOfRBFTerms = 4;
	static constexpr int32_t ConstNumOfRBFTerms = 2;
	static constexpr int32_t ConstNumOfGenes = 4 * ConstNumOfRBFTerms; // 2 ExpFactors bzw. RBFFactors + 4 Centroid Values (2 per dimension) + 2 FunctionParams = 2 * 4 Genes


	static constexpr int32_t  ConstTrainingPopulationSize = 100;
	int32_t NumTrainingGenerationsMax = 30000;


	static CSimpleFloatValueGenome GenomeArray[ConstTrainingPopulationSize];

	CSimpleFloatValueGenome BestGenome;
	BestGenome.Initialize(ConstNumOfGenes);


	CGeneralPopulation Population;
	Population.Set_GenomeValueCloningFunction(CSimpleFloatValueGenome_CloningFunction);


	Population.Initialize(ConstTrainingPopulationSize);


	for (int32_t i = 0; i < ConstTrainingPopulationSize; i++)
	{
		GenomeArray[i].Initialize(ConstNumOfGenes);
		Population.Set_Genome(&GenomeArray[i], i);
	}


	CRBFReinitializationInfo ReinitializationInfo;

	ReinitializationInfo.minValue_FunctionParam = -2.0f;
	ReinitializationInfo.maxValue_FunctionParam = 2.0f;

	ReinitializationInfo.minValue_Centroid = 0.5f;
	ReinitializationInfo.maxValue_Centroid = 0.75f;

	ReinitializationInfo.minValue_ExpFactor = 4.0f;
	ReinitializationInfo.maxValue_ExpFactor = 4.0f;

	//ReinitializationInfo.minValue_ExpFactor = 10.0f;
	//ReinitializationInfo.maxValue_ExpFactor = 10.0f;

	for (int32_t individual = 0; individual < ConstTrainingPopulationSize; individual++)
	{
		Reinitialization_2DimRBFValues(&GenomeArray[individual], &RandomNumbers, &ReinitializationInfo);
	}

	CRBFMutationInfo MutationInfo;

	MutationInfo.minValue_FunctionParam = -0.01f;
	MutationInfo.maxValue_FunctionParam = 0.01f;
	MutationInfo.mutationRate_FunctionParam = 0.25f;

	MutationInfo.minValue_Centroid = -0.05f;
	MutationInfo.maxValue_Centroid = 0.05f;
	MutationInfo.mutationRate_Centroid = 0.25f;

	MutationInfo.minValue_ExpFactor = 0.0f;
	MutationInfo.maxValue_ExpFactor = 0.0f;
	MutationInfo.mutationRate_ExpFactor = 0.0f;


	Population.Reset_Population();

	for (int32_t generation = 0; generation < NumTrainingGenerationsMax; generation++)
	{
		Population.Reset_MinErrorSum_ActualGeneration();

		for (int32_t individual = 0; individual < ConstTrainingPopulationSize; individual++)
		{
			float* pGeneArray = GenomeArray[individual].pGeneArray;

			float* pRBFFactorArray = &pGeneArray[0];
			float* pFunctionParamArray = &pGeneArray[ConstNumOfRBFTerms];
			float* pCentroidArray = &pGeneArray[2 * ConstNumOfRBFTerms];

			float SumOfErrors = 0.000001f;

			for (int32_t i = 0; i < NumInputOrOutputValues; i++)
			{
				
				float outputValue = GaussianRBF(pInputData[i], pRBFFactorArray, pCentroidArray, pFunctionParamArray, ConstNumOfRBFTerms, 2);
				
				float diff = outputValue - CorrectOutputData[i];
				SumOfErrors += diff * diff;
			}

			Population.Calculate_FitnessScore_FromError(individual, SumOfErrors);
			//Population.Set_FitnessScore(individual, 1.0f / SumOfErrors);
			Population.Update_MinErrorSum_ActualGeneration(SumOfErrors);
		}

		Population.Update_Population();

		if (generation % 500 == 0)
		{
			cout << "minErrorSum: " << Population.MinErrorSum_ActualGeneration << endl;
		}

		//if (Population.MinErrorSum_ActualGeneration < 0.005f)
		if (Population.MinErrorSum_ActualGeneration < 0.01f)
		{
			cout << endl;
			cout << "minErrorSum: " << Population.MinErrorSum_ActualGeneration << endl;
			cout << "actual generation: " << generation << endl;
			cout << "training completed" << endl << endl;
			break;
		}


		Population.Update_BaseEvolution(Mutation_2DimRBFValues, &MutationInfo);
		Population.Update_Evolution_BestGenomeOnly(Mutation_2DimRBFValues, &MutationInfo);
		Population.Update_Evolution_SecondBestGenomeOnly(Mutation_2DimRBFValues, &MutationInfo);
		Population.Update_Evolution_Combine_BestTwoGenomes(Recombination_Example2, nullptr);
		Population.Update_Evolution_Combine_TwoGenomes(Recombination_Example2, nullptr);
		Population.Update_Evolution_Combine_TwoGenomes(Recombination_Example2, nullptr);

		Population.Replace_WorstFitted_Genome(Reinitialization_2DimRBFValues, &RandomNumbers, &ReinitializationInfo);
	}

	Population.Get_Best_Evolved_Genome(&BestGenome);


	//getchar();

	float* pGeneArray = BestGenome.pGeneArray;

	float* pRBFFactorArray = &pGeneArray[0];
	float* pFunctionParamArray = &pGeneArray[ConstNumOfRBFTerms];
	float* pCentroidArray = &pGeneArray[2 * ConstNumOfRBFTerms];

	for (int32_t i = 0; i < NumInputOrOutputValues; i++)
	{
		float outputValue = GaussianRBF(pInputData[i], pRBFFactorArray, pCentroidArray, pFunctionParamArray, ConstNumOfRBFTerms, 2);

		cout << "output: " << outputValue << " correct output: " << CorrectOutputData[i] << endl;
	}


	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	static constexpr int32_t NumInputOrOutputValues = 4;

	float CorrectOutputData[NumInputOrOutputValues];

	
	float Input1[2] = { 0.0f, 0.0f };
	float Input2[2] = { 1.0f, 0.0f };
	float Input3[2] = { 0.0f, 1.0f };
	float Input4[2] = { 1.0f, 1.0f };

	float CorrectOutput1[3] = { 0.0f, 0.0f, 0.0f };
	float CorrectOutput2[3] = { 1.0f, 0.0f, 1.0f };
	float CorrectOutput3[3] = { 1.0f, 0.0f, 1.0f };
	float CorrectOutput4[3] = { 0.0f, 1.0f, 1.0f };


	float* pInputData[NumInputOrOutputValues];

	pInputData[0] = Input1;
	pInputData[1] = Input2;
	pInputData[2] = Input3;
	pInputData[3] = Input4;

	float* pCorrectOutputData[NumInputOrOutputValues];

	pCorrectOutputData[0] = CorrectOutput1;
	pCorrectOutputData[1] = CorrectOutput2;
	pCorrectOutputData[2] = CorrectOutput3;
	pCorrectOutputData[3] = CorrectOutput4;


	static constexpr int32_t ConstNumOfRBFTerms = 6;
	static constexpr int32_t ConstNumOfGenes = 6 * ConstNumOfRBFTerms; // 6 ExpFactors bzw. RBFFactors + 12 Centroid Values (6 per dimension) + 18 FunctionParams (6 * 3) = 6 * 6 Genes


	static constexpr int32_t  ConstTrainingPopulationSize = 100;
	int32_t NumTrainingGenerationsMax = 30000;


	static CSimpleFloatValueGenome GenomeArray[ConstTrainingPopulationSize];

	CSimpleFloatValueGenome BestGenome;
	BestGenome.Initialize(ConstNumOfGenes);


	CGeneralPopulation Population;
	Population.Set_GenomeValueCloningFunction(CSimpleFloatValueGenome_CloningFunction);


	Population.Initialize(ConstTrainingPopulationSize);


	for (int32_t i = 0; i < ConstTrainingPopulationSize; i++)
	{
		GenomeArray[i].Initialize(ConstNumOfGenes);
		Population.Set_Genome(&GenomeArray[i], i);
	}


	CRBFReinitializationInfo ReinitializationInfo;

	ReinitializationInfo.minValue_FunctionParam = -2.0f;
	ReinitializationInfo.maxValue_FunctionParam = 2.0f;

	ReinitializationInfo.minValue_Centroid = 0.5f;
	ReinitializationInfo.maxValue_Centroid = 0.75f;

	ReinitializationInfo.minValue_ExpFactor = 4.0f;
	ReinitializationInfo.maxValue_ExpFactor = 4.0f;

	//ReinitializationInfo.minValue_ExpFactor = 0.5f;
	//ReinitializationInfo.maxValue_ExpFactor = 0.5f;

	for (int32_t individual = 0; individual < ConstTrainingPopulationSize; individual++)
	{
		Reinitialization_2DimRBFValues_3OutputValues(&GenomeArray[individual], &RandomNumbers, &ReinitializationInfo);
	}

	CRBFMutationInfo MutationInfo;

	MutationInfo.minValue_FunctionParam = -0.01f;
	MutationInfo.maxValue_FunctionParam = 0.01f;
	MutationInfo.mutationRate_FunctionParam = 0.25f;

	MutationInfo.minValue_Centroid = -0.05f;
	MutationInfo.maxValue_Centroid = 0.05f;
	MutationInfo.mutationRate_Centroid = 0.25f;

	MutationInfo.minValue_ExpFactor = 0.0f;
	MutationInfo.maxValue_ExpFactor = 0.0f;
	MutationInfo.mutationRate_ExpFactor = 0.0f;

	float outputValueArray[3];

	Population.Reset_Population();

	for (int32_t generation = 0; generation < NumTrainingGenerationsMax; generation++)
	{
		Population.Reset_MinErrorSum_ActualGeneration();

		for (int32_t individual = 0; individual < ConstTrainingPopulationSize; individual++)
		{
			float* pGeneArray = GenomeArray[individual].pGeneArray;

			float* pRBFFactorArray = &pGeneArray[0];
			float* pFunctionParamArray = &pGeneArray[ConstNumOfRBFTerms];
			float* pCentroidArray = &pGeneArray[4 * ConstNumOfRBFTerms];

			float SumOfErrors = 0.000001f;

			for (int32_t i = 0; i < NumInputOrOutputValues; i++)
			{
				GaussianRBF(outputValueArray, pInputData[i], pRBFFactorArray, pCentroidArray, pFunctionParamArray, ConstNumOfRBFTerms, 2, 3);

				for (int32_t j = 0; j < 3; j++)
				{
					float diff = outputValueArray[j] - pCorrectOutputData[i][j];
					SumOfErrors += diff * diff;
				}			
			}

			Population.Calculate_FitnessScore_FromError(individual, SumOfErrors);
			//Population.Set_FitnessScore(individual, 1.0f / SumOfErrors);
			Population.Update_MinErrorSum_ActualGeneration(SumOfErrors);
		}

		Population.Update_Population();

		if (generation % 500 == 0)
		{
			cout << "minErrorSum: " << Population.MinErrorSum_ActualGeneration << endl;
		}

		//if (Population.MinErrorSum_ActualGeneration < 0.005f)
		if (Population.MinErrorSum_ActualGeneration < 0.01f)
		{
			cout << endl;
			cout << "minErrorSum: " << Population.MinErrorSum_ActualGeneration << endl;
			cout << "actual generation: " << generation << endl;
			cout << "training completed" << endl << endl;
			break;
		}


		Population.Update_BaseEvolution(Mutation_2DimRBFValues_3OutputValues, &MutationInfo);
		Population.Update_Evolution_BestGenomeOnly(Mutation_2DimRBFValues_3OutputValues, &MutationInfo);
		Population.Update_Evolution_SecondBestGenomeOnly(Mutation_2DimRBFValues_3OutputValues, &MutationInfo);
		Population.Update_Evolution_Combine_BestTwoGenomes(Recombination_Example2, nullptr);
		Population.Update_Evolution_Combine_TwoGenomes(Recombination_Example2, nullptr);
		Population.Update_Evolution_Combine_TwoGenomes(Recombination_Example2, nullptr);

		Population.Replace_WorstFitted_Genome(Reinitialization_2DimRBFValues_3OutputValues, &RandomNumbers, &ReinitializationInfo);
	}

	Population.Get_Best_Evolved_Genome(&BestGenome);


	//getchar();

	float* pGeneArray = BestGenome.pGeneArray;

	float* pRBFFactorArray = &pGeneArray[0];
	float* pFunctionParamArray = &pGeneArray[ConstNumOfRBFTerms];
	float* pCentroidArray = &pGeneArray[4 * ConstNumOfRBFTerms];

	for (int32_t i = 0; i < NumInputOrOutputValues; i++)
	{
		GaussianRBF(outputValueArray, pInputData[i], pRBFFactorArray, pCentroidArray, pFunctionParamArray, ConstNumOfRBFTerms, 2, 3);

		cout << "outputs: " << outputValueArray[0] << " " << outputValueArray[1] << " " << outputValueArray[2] << endl;
		cout << "correct outputs: " << pCorrectOutputData[i][0] << " " << pCorrectOutputData[i][1] << " " << pCorrectOutputData[i][2] << endl;
	}


	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/




/*
// evolutionary RBF clustering
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	static constexpr int32_t ImageSizeX = 32;
	static constexpr int32_t ImageSizeY = 32;
	static constexpr int32_t ImageSizeXY = ImageSizeX * ImageSizeY;

	static float TestImage1[ImageSizeXY];

	uint8_t* pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("TestSample2.bmp");
	//pImageData = Read_Bitmap_BGR("TestSample.bmp");

	Get_BinaryImageData_BlueChannel(TestImage1, pImageData, ImageSizeX, ImageSizeY);

	delete[] pImageData;
	pImageData = nullptr;

	int32_t NumOfNonZeroPixel = 0;

	for (int32_t i = 0; i < ImageSizeXY; i++)
	{
		if (TestImage1[i] > 0.0f)
		{
			NumOfNonZeroPixel++;
		}
	}

	float* pPixelPosXArray = new float[NumOfNonZeroPixel];
	float* pPixelPosYArray = new float[NumOfNonZeroPixel];

	int32_t pixelCounter = 0;

	for (int32_t iy = 0; iy < ImageSizeY; iy++)
	{
		int32_t iiy = iy * ImageSizeX;

		for (int32_t ix = 0; ix < ImageSizeX; ix++)
		{
			int32_t id = ix + iiy;

			if (TestImage1[id] != 0.0f)
			{
				pPixelPosXArray[pixelCounter] = static_cast<float>(ix);
				pPixelPosYArray[pixelCounter] = static_cast<float>(iy);
				pixelCounter++;
			}	
		}
	}



	static constexpr int32_t ConstNumOfRBFTerms = 5;
	static constexpr int32_t ConstNumOfGenes = 3 * ConstNumOfRBFTerms; // 10 Centroid Values (5 2Dim-Centroids) + 5 RBFFactors (1 per 2Dim-Centroid) 
	
	static constexpr int32_t  ConstTrainingPopulationSize = 100;
	int32_t NumTrainingGenerationsMax = 3000;



	static CSimpleFloatValueGenome GenomeArray[ConstTrainingPopulationSize];

	CSimpleFloatValueGenome BestGenome;
	BestGenome.Initialize(ConstNumOfGenes);


	CGeneralPopulation Population;
	Population.Set_GenomeValueCloningFunction(CSimpleFloatValueGenome_CloningFunction);


	Population.Initialize(ConstTrainingPopulationSize);


	for (int32_t i = 0; i < ConstTrainingPopulationSize; i++)
	{
		GenomeArray[i].Initialize(ConstNumOfGenes);
		Population.Set_Genome(&GenomeArray[i], i);
	}


	CRBFReinitializationInfo ReinitializationInfo;

	// not needed for clustering:
	ReinitializationInfo.minValue_FunctionParam = 0.0f;
	ReinitializationInfo.maxValue_FunctionParam = 0.0f;

	ReinitializationInfo.minValue_Centroid = 0.0f;
	ReinitializationInfo.maxValue_Centroid = static_cast<float>(max(ImageSizeX, ImageSizeY));

	ReinitializationInfo.minValue_ExpFactor = 0.01f;
	ReinitializationInfo.maxValue_ExpFactor = 0.01f;


	for (int32_t individual = 0; individual < ConstTrainingPopulationSize; individual++)
	{
		Reinitialization_2DimRBFClustering(&GenomeArray[individual], &RandomNumbers, &ReinitializationInfo);
	}

	CRBFMutationInfo MutationInfo;

	// not needed for clustering:
	MutationInfo.minValue_FunctionParam = 0.0f;
	MutationInfo.maxValue_FunctionParam = 0.0f;
	MutationInfo.mutationRate_FunctionParam = 0.0f;

	MutationInfo.minValue_Centroid = -0.05f;
	MutationInfo.maxValue_Centroid = 0.05f;
	MutationInfo.mutationRate_Centroid = 0.25f;

	MutationInfo.minValue_ExpFactor = 0.0f;
	MutationInfo.maxValue_ExpFactor = 0.0f;
	MutationInfo.mutationRate_ExpFactor = 0.0f;


	Population.Reset_Population();

	for (int32_t generation = 0; generation < NumTrainingGenerationsMax; generation++)
	{
		Population.Reset_MinErrorSum_ActualGeneration();

		for (int32_t individual = 0; individual < ConstTrainingPopulationSize; individual++)
		{
			float* pGeneArray = GenomeArray[individual].pGeneArray;

			float* pRBFFactorArray = &pGeneArray[0];
			float* pCentroidXArray = &pGeneArray[ConstNumOfRBFTerms];
			float* pCentroidYArray = &pGeneArray[2 * ConstNumOfRBFTerms];

			float SumOfErrors = 0.000001f;

			for (int32_t i = 0; i < NumOfNonZeroPixel; i++)
			{
				float outputValue = GaussianMaxRBF_2D(pPixelPosXArray[i], pPixelPosYArray[i], pRBFFactorArray, pCentroidXArray, pCentroidYArray, ConstNumOfRBFTerms);
				
				float diff = 1.0f - outputValue;
				SumOfErrors += diff * diff;
			}

			Population.Calculate_FitnessScore_FromError(individual, SumOfErrors);
			//Population.Set_FitnessScore(individual, 1.0f / SumOfErrors);
			Population.Update_MinErrorSum_ActualGeneration(SumOfErrors);
		}

		Population.Update_Population();

		if (generation % 500 == 0)
		{
			cout << "minErrorSum: " << Population.MinErrorSum_ActualGeneration << endl;
		}

		//if (Population.MinErrorSum_ActualGeneration < 0.005f)
		//if (Population.MinErrorSum_ActualGeneration < 0.01f)
		//{
			//cout << endl;
			//cout << "minErrorSum: " << Population.MinErrorSum_ActualGeneration << endl;
			//cout << "actual generation: " << generation << endl;
			//cout << "training completed" << endl << endl;
			//break;
		//}

		Population.Update_BaseEvolution(Mutation_2DimRBFClustering, &MutationInfo);
		Population.Update_Evolution_BestGenomeOnly(Mutation_2DimRBFClustering, &MutationInfo);
		Population.Update_Evolution_SecondBestGenomeOnly(Mutation_2DimRBFClustering, &MutationInfo);
		Population.Update_Evolution_Combine_BestTwoGenomes(Recombination_Example2, nullptr);
		Population.Update_Evolution_Combine_TwoGenomes(Recombination_Example2, nullptr);
		Population.Update_Evolution_Combine_TwoGenomes(Recombination_Example2, nullptr);

		Population.Replace_WorstFitted_Genome(Reinitialization_2DimRBFClustering, &RandomNumbers, &ReinitializationInfo);
	}

	Population.Get_Best_Evolved_Genome(&BestGenome);

	cout << "Press Return" << endl;
	getchar();


	float* pGeneArray = BestGenome.pGeneArray;

	float* pCentroidXArray = &pGeneArray[ConstNumOfRBFTerms];
	float* pCentroidYArray = &pGeneArray[2 * ConstNumOfRBFTerms];


	for (int32_t i = 0; i < ConstNumOfRBFTerms; i++)
	{
		int32_t ix = static_cast<int32_t>(pCentroidXArray[i]);
		int32_t iy = static_cast<int32_t>(pCentroidYArray[i]);

		TestImage1[ix + iy * ImageSizeX] = 8;
	}


	
	for (int32_t iy = 0; iy < ImageSizeY; iy++)
	{
		int32_t iiy = iy * ImageSizeX;

		for (int32_t ix = 0; ix < ImageSizeX; ix++)
		{
			int32_t id = ix + iiy;

			if (TestImage1[id] != 0.0f)
				cout << TestImage1[id];
			else
				cout << " ";
		}

		cout << endl;
	}

	cout << endl;

	delete[] pPixelPosXArray;
	pPixelPosXArray = nullptr;

	delete[] pPixelPosYArray;
	pPixelPosYArray = nullptr;

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/


/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;


	static constexpr int32_t  ConstTrainingPopulationSize = 100;
	int32_t NumTrainingGenerationsMax = 2000;


	static constexpr int32_t NumInputOrOutputValues = 9;


	static float InputData[NumInputOrOutputValues];

	InputData[0] = -4.0f;
	InputData[1] = -3.0f;
	InputData[2] = -2.0f;
	InputData[3] = -1.0f;
	InputData[4] = 0.0f;
	InputData[5] = 1.0f;
	InputData[6] = 2.0f;
	InputData[7] = 3.0f;
	InputData[8] = 4.0f;


	static constexpr int32_t ConstNumOfGenesMax = 4;

	// Output = (a * Input * Input * Input + b * Input * Input + c * Input + offset)

	float a = 0.5f;
	float b = 1.65f;
	float c = -0.85f;
	float offset = 1.0f;


	static float CorrectOutputData[NumInputOrOutputValues];

	for (int32_t i = 0; i < NumInputOrOutputValues; i++)
	{
		float inputValue = InputData[i];

		CorrectOutputData[i] = a * inputValue * inputValue * inputValue +
			b * inputValue * inputValue +
			c * inputValue + offset;
	}

	CGeneBasedCalculations GeneBasedCalculations;

	// 1 Input Value + 1 Output Value
	GeneBasedCalculations.Initialize_DataArray(2);

	GeneBasedCalculations.Initialize_CalculationFunctionArray(4);
	GeneBasedCalculations.Set_CalculationFunction(0, Set_OutputValueBias);
	GeneBasedCalculations.Set_CalculationFunction(1, Add_PolynomialTerm_1Degree);
	GeneBasedCalculations.Set_CalculationFunction(2, Add_PolynomialTerm_2Degree);
	GeneBasedCalculations.Set_CalculationFunction(3, Add_PolynomialTerm_3Degree);

	// verwendete Kennungen (Identifier, abbr.: id):

	int32_t IDof_Set_OutputValueBias = 0;
	int32_t IDof_Add_PolynomialTerm_1Degree = 1;
	int32_t IDof_Add_PolynomialTerm_2Degree = 2;
	int32_t IDof_Add_PolynomialTerm_3Degree = 3;

	int32_t IDofInputValue = 0;
	int32_t IDofOutputValue = 1;

	

	CGenome BestGenome;
	BestGenome.Initialize(ConstNumOfGenesMax, 3, 1, 0);

	CGene tempGene;
	tempGene.Initialize(3, 1, 0);

	static CGenome GenomeArray[ConstTrainingPopulationSize];

	for (int32_t i = 0; i < ConstTrainingPopulationSize; i++)
	{
		GenomeArray[i].Initialize(ConstNumOfGenesMax, 3, 1, 0);

		Set_FunctionIdentifier_For_GeneBasedCalculations(&tempGene, IDof_Set_OutputValueBias); // bias bzw. offset => output Value
		Set_OutputIdentifier_For_GeneBasedCalculations(&tempGene, IDofOutputValue);

		GenomeArray[i].Set_SingleGeneData(&tempGene, 0);

		Set_FunctionIdentifier_For_GeneBasedCalculations(&tempGene, IDof_Add_PolynomialTerm_1Degree); // c * x => output Value
		Set_OutputIdentifier_For_GeneBasedCalculations(&tempGene, IDofOutputValue);
		Set_InputIdentifier_For_GeneBasedCalculations(&tempGene, IDofInputValue, 0);

		GenomeArray[i].Set_SingleGeneData(&tempGene, 1);

		Set_FunctionIdentifier_For_GeneBasedCalculations(&tempGene, IDof_Add_PolynomialTerm_2Degree); // b * x * x => output Value
		Set_OutputIdentifier_For_GeneBasedCalculations(&tempGene, IDofOutputValue);
		Set_InputIdentifier_For_GeneBasedCalculations(&tempGene, IDofInputValue, 0);

		GenomeArray[i].Set_SingleGeneData(&tempGene, 2);
		
		Set_FunctionIdentifier_For_GeneBasedCalculations(&tempGene, IDof_Add_PolynomialTerm_3Degree); // a * x * x * x => output Value
		Set_OutputIdentifier_For_GeneBasedCalculations(&tempGene, IDofOutputValue);
		Set_InputIdentifier_For_GeneBasedCalculations(&tempGene, IDofInputValue, 0);

		GenomeArray[i].Set_SingleGeneData(&tempGene, 3);
	}

	CGeneralPopulation Population;
	Population.Set_GenomeValueCloningFunction(CGenome_CloningFunction);

	Population.Initialize(ConstTrainingPopulationSize);

	for (int32_t i = 0; i < ConstTrainingPopulationSize; i++)
	{
		Population.Set_Genome(&GenomeArray[i], i);
	}

	CSimpleReinitializationInfo ReinitializationInfo;
	ReinitializationInfo.minValue = -2.0f;
	ReinitializationInfo.maxValue = 2.0f;

	CSimpleMutationInfo MutationInfo;
	MutationInfo.minValue = -0.1f;
	MutationInfo.maxValue = 0.1f;
	MutationInfo.mutationRate = 0.75f;


	for (int32_t individual = 0; individual < ConstTrainingPopulationSize; individual++)
	{
		Reinitialization_Example4(&GenomeArray[individual], &RandomNumbers, &ReinitializationInfo);
	}


	Population.Reset_Population();

	for (int32_t generation = 0; generation < NumTrainingGenerationsMax; generation++)
	{
		Population.Reset_MinErrorSum_ActualGeneration();

		for (int32_t individual = 0; individual < ConstTrainingPopulationSize; individual++)
		{
			float SumOfErrors = 0.000001f;

			for (int32_t i = 0; i < NumInputOrOutputValues; i++)
			{
				GeneBasedCalculations.Set_DataArrayValue(IDofInputValue, InputData[i]);
				GeneBasedCalculations.Execute_CalculationFunctions(&GenomeArray[individual]);

				float outputValue = GeneBasedCalculations.Get_DataArrayValue(IDofOutputValue);

				float diff = outputValue - CorrectOutputData[i];

				SumOfErrors += diff * diff;
			}

			Population.Calculate_FitnessScore_FromError(individual, SumOfErrors);
			//Population.Set_FitnessScore(individual, 1.0f / SumOfErrors);
			Population.Update_MinErrorSum_ActualGeneration(SumOfErrors);
		}

		Population.Update_Population();

		if (generation % 200 == 0)
		{
			cout << "minErrorSum: " << Population.MinErrorSum_ActualGeneration << endl;
		}

		if (Population.MinErrorSum_ActualGeneration < 0.005f)
		{
			cout << endl;
			cout << "minErrorSum: " << Population.MinErrorSum_ActualGeneration << endl;
			cout << "actual generation: " << generation << endl;
			cout << "training completed" << endl << endl;
			break;
		}

		if (Population.MinErrorSum_ActualGeneration < 1.0f)
		{
			MutationInfo.minValue = -0.01f;
			MutationInfo.maxValue = 0.01f;
		}
		else if (Population.MinErrorSum_ActualGeneration < 0.5f)
		{
			MutationInfo.minValue = -0.005f;
			MutationInfo.maxValue = 0.005f;
		}

		Population.Update_BaseEvolution(Mutation_Example4, &MutationInfo);
		Population.Update_Evolution_BestGenomeOnly(Mutation_Example4, &MutationInfo);
		Population.Update_Evolution_SecondBestGenomeOnly(Mutation_Example4, &MutationInfo);
		Population.Update_Evolution_Combine_BestTwoGenomes(Recombination_Example5, nullptr);
		Population.Update_Evolution_Combine_TwoGenomes(Recombination_Example5, nullptr);
		Population.Update_Evolution_Combine_TwoGenomes(Recombination_Example5, nullptr);
		Population.Replace_WorstFitted_Genome(Reinitialization_Example4, &RandomNumbers, &ReinitializationInfo);
	}

	Population.Get_Best_Evolved_Genome(&BestGenome);

	for (int32_t i = 0; i < NumInputOrOutputValues; i++)
	{
		GeneBasedCalculations.Set_DataArrayValue(IDofInputValue, InputData[i]);
		GeneBasedCalculations.Execute_CalculationFunctions(&BestGenome);

		float outputValue = GeneBasedCalculations.Get_DataArrayValue(IDofOutputValue);
		cout << "output: " << outputValue << " correct output: " << CorrectOutputData[i] << endl;
	}

	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;


	static constexpr int32_t  ConstTrainingPopulationSize = 500;
	int32_t NumTrainingGenerationsMax = 10000;


	static constexpr int32_t NumInputOrOutputValues = 9;


	static float InputData[NumInputOrOutputValues];

	InputData[0] = -4.0f;
	InputData[1] = -3.0f;
	InputData[2] = -2.0f;
	InputData[3] = -1.0f;
	InputData[4] = 0.0f;
	InputData[5] = 1.0f;
	InputData[6] = 2.0f;
	InputData[7] = 3.0f;
	InputData[8] = 4.0f;

	static constexpr int32_t ConstNumOfGenesMax = 5;
	static constexpr float fConstNumOfGenesMax = 5.0f;
	static constexpr float invConstNumOfGenesMax = 1.0f / fConstNumOfGenesMax;
	
	// Output = (a * Input * Input * Input * Input + b * Input * Input * Input + c * Input * Input + d * Input + offset)


	float a = -0.3f;
	//float a = 0.0f;
	//float b = 0.5f;
	float b = 1.25f;
	//float c = 1.65f;
	float c = 0.0f;
	//float d = -0.85f;
	float d = 0.0f;
	float offset = 1.0f;


	static float CorrectOutputData[NumInputOrOutputValues];

	for (int32_t i = 0; i < NumInputOrOutputValues; i++)
	{
		float inputValue = InputData[i];

		CorrectOutputData[i] = a * inputValue * inputValue * inputValue * inputValue +
			b * inputValue * inputValue * inputValue +
			c * inputValue * inputValue + d * inputValue + offset;
	}

	CGeneBasedCalculations GeneBasedCalculations;

	// 1 Input Value + 1 Output Value
	GeneBasedCalculations.Initialize_DataArray(2);

	GeneBasedCalculations.Initialize_CalculationFunctionArray(5);
	GeneBasedCalculations.Set_CalculationFunction(0, Set_OutputValueBias);
	GeneBasedCalculations.Set_CalculationFunction(1, Add_PolynomialTerm_1Degree);
	GeneBasedCalculations.Set_CalculationFunction(2, Add_PolynomialTerm_2Degree);
	GeneBasedCalculations.Set_CalculationFunction(3, Add_PolynomialTerm_3Degree);
	GeneBasedCalculations.Set_CalculationFunction(4, Add_PolynomialTerm_4Degree);

	// verwendete Kennungen (Identifier, abbr.: id):

	int32_t IDof_Set_OutputValueBias = 0;
	int32_t IDof_Add_PolynomialTerm_1Degree = 1;
	int32_t IDof_Add_PolynomialTerm_2Degree = 2;
	int32_t IDof_Add_PolynomialTerm_3Degree = 3;
	int32_t IDof_Add_PolynomialTerm_4Degree = 4;

	int32_t IDofInputValue = 0;
	int32_t IDofOutputValue = 1;

	

	CGenome BestGenome;
	BestGenome.Initialize(ConstNumOfGenesMax, 3, 1, 0);

	CGene tempGene;
	tempGene.Initialize(3, 1, 0);

	static CGenome GenomeArray[ConstTrainingPopulationSize];

	for (int32_t i = 0; i < ConstTrainingPopulationSize; i++)
	{
		GenomeArray[i].Initialize(ConstNumOfGenesMax, 3, 1, 0);

		Set_FunctionIdentifier_For_GeneBasedCalculations(&tempGene, IDof_Set_OutputValueBias); // bias bzw. offset => output Value
		Set_OutputIdentifier_For_GeneBasedCalculations(&tempGene, IDofOutputValue);

		GenomeArray[i].Set_SingleGeneData(&tempGene, 0);

		Set_FunctionIdentifier_For_GeneBasedCalculations(&tempGene, IDof_Add_PolynomialTerm_1Degree); // d * x => output Value
		Set_OutputIdentifier_For_GeneBasedCalculations(&tempGene, IDofOutputValue);
		Set_InputIdentifier_For_GeneBasedCalculations(&tempGene, IDofInputValue, 0);

		GenomeArray[i].Set_SingleGeneData(&tempGene, 1);

		Set_FunctionIdentifier_For_GeneBasedCalculations(&tempGene, IDof_Add_PolynomialTerm_2Degree); // c * x * x => output Value
		Set_OutputIdentifier_For_GeneBasedCalculations(&tempGene, IDofOutputValue);
		Set_InputIdentifier_For_GeneBasedCalculations(&tempGene, IDofInputValue, 0);

		GenomeArray[i].Set_SingleGeneData(&tempGene, 2);

		Set_FunctionIdentifier_For_GeneBasedCalculations(&tempGene, IDof_Add_PolynomialTerm_3Degree); // b * x * x * x => output Value
		Set_OutputIdentifier_For_GeneBasedCalculations(&tempGene, IDofOutputValue);
		Set_InputIdentifier_For_GeneBasedCalculations(&tempGene, IDofInputValue, 0);

		GenomeArray[i].Set_SingleGeneData(&tempGene, 3);

		Set_FunctionIdentifier_For_GeneBasedCalculations(&tempGene, IDof_Add_PolynomialTerm_4Degree); // a * x * x * x * x => output Value
		Set_OutputIdentifier_For_GeneBasedCalculations(&tempGene, IDofOutputValue);
		Set_InputIdentifier_For_GeneBasedCalculations(&tempGene, IDofInputValue, 0);

		GenomeArray[i].Set_SingleGeneData(&tempGene, 4);
	}

	CGeneralPopulation Population;
	Population.Set_GenomeValueCloningFunction(CGenome_CloningFunction);

	Population.Initialize(ConstTrainingPopulationSize);

	for (int32_t i = 0; i < ConstTrainingPopulationSize; i++)
	{
		Population.Set_Genome(&GenomeArray[i], i);
	}

	CSimpleMultipleSpeciesReinitializationInfo ReinitializationInfo;
	ReinitializationInfo.Initialize(ConstNumOfGenesMax);
	ReinitializationInfo.minValue = -2.0f;
	ReinitializationInfo.maxValue = 2.0f;
	ReinitializationInfo.geneDeactivationRate = 0.5f;
	//ReinitializationInfo.geneDeactivationRate = 0.75f;
	ReinitializationInfo.pGeneChangeableUsageArray[0] = false;
	ReinitializationInfo.pGeneChangeableUsageArray[1] = true;
	ReinitializationInfo.pGeneChangeableUsageArray[2] = true;
	ReinitializationInfo.pGeneChangeableUsageArray[3] = true;
	ReinitializationInfo.pGeneChangeableUsageArray[4] = true;

	CSimpleMutationInfo MutationInfo;
	MutationInfo.minValue = -0.1f;
	MutationInfo.maxValue = 0.1f;
	MutationInfo.mutationRate = 0.75f;

	CSimpleMutationInfo RecombinationMutationInfo;
	RecombinationMutationInfo.minValue = -0.1f;
	RecombinationMutationInfo.maxValue = 0.1f;
	RecombinationMutationInfo.mutationRate = 0.75f;



	for (int32_t individual = 0; individual < ConstTrainingPopulationSize; individual++)
	{
		Reinitialization_Example5(&GenomeArray[individual], &RandomNumbers, &ReinitializationInfo);
	}

	Population.Reset_Population();

	for (int32_t generation = 0; generation < NumTrainingGenerationsMax; generation++)
	{
		Population.Reset_MinErrorSum_ActualGeneration();

		for (int32_t individual = 0; individual < ConstTrainingPopulationSize; individual++)
		{
			float SumOfErrors = 0.000001f;

			for (int32_t i = 0; i < NumInputOrOutputValues; i++)
			{
				GeneBasedCalculations.Set_DataArrayValue(IDofInputValue, InputData[i]);
				GeneBasedCalculations.Execute_CalculationFunctionsExt(&GenomeArray[individual]);

				float outputValue = GeneBasedCalculations.Get_DataArrayValue(IDofOutputValue);

				float diff = outputValue - CorrectOutputData[i];
	
				SumOfErrors += diff * diff;
		
			}

			Population.Calculate_FitnessScore_FromError(individual, SumOfErrors);
			//Population.Set_FitnessScore(individual, 1.0f / SumOfErrors);
			Population.Update_MinErrorSum_ActualGeneration(SumOfErrors);
		}

		Population.Update_Population();

		if (generation % 200 == 0)
		{
			cout << "minErrorSum: " << Population.MinErrorSum_ActualGeneration << endl;
		}

		if (Population.MinErrorSum_ActualGeneration < 0.00125f)
		{
			cout << endl;
			cout << "minErrorSum: " << Population.MinErrorSum_ActualGeneration << endl;
			cout << "actual generation: " << generation << endl;
			cout << "training completed" << endl << endl;
			break;
		}

		if (Population.MinErrorSum_ActualGeneration < 1.0f)
		{
			MutationInfo.minValue = -0.01f;
			MutationInfo.maxValue = 0.01f;
		}
		else if (Population.MinErrorSum_ActualGeneration < 0.5f)
		{
			MutationInfo.minValue = -0.005f;
			MutationInfo.maxValue = 0.005f;
		}

		Population.Update_BaseEvolution(Mutation_Example4, &MutationInfo);
		Population.Update_Evolution_BestGenomeOnly(Mutation_Example4, &MutationInfo);
		Population.Update_Evolution_SecondBestGenomeOnly(Mutation_Example4, &MutationInfo);
		Population.Update_Evolution_Combine_BestTwoGenomes(Recombination_Example6, &RecombinationMutationInfo);
		Population.Update_Evolution_Combine_TwoGenomes(Recombination_Example6, &RecombinationMutationInfo);
		Population.Update_Evolution_Combine_TwoGenomes(Recombination_Example6, &RecombinationMutationInfo);
		Population.Replace_WorstFitted_Genome(Reinitialization_Example5, &RandomNumbers, &ReinitializationInfo);

		Population.Transform_Species_If_Possible_BestGenomeOnly(SpeciesTransformation_Example1, &RandomNumbers, nullptr);	
	}

	Population.Get_Best_Evolved_Genome(&BestGenome);

	// show species:
	cout << "best fitted species: ";
	for (int32_t i = 0; i < ConstNumOfGenesMax; i++)
		cout << static_cast<int32_t>(BestGenome.pGeneUsageArray[i]) << " ";

	cout << endl;

	for (int32_t i = 0; i < ConstNumOfGenesMax; i++)
	{
		if (BestGenome.pGeneUsageArray[i] == true)
		{
			cout << BestGenome.pGeneArray[i].pFValueArray[0] << endl;
		}
		else
		{
			cout << "---" << endl;
		}
	}

	cout << endl << endl;
	

	for (int32_t i = 0; i < NumInputOrOutputValues; i++)
	{
		GeneBasedCalculations.Set_DataArrayValue(IDofInputValue, InputData[i]);
		GeneBasedCalculations.Execute_CalculationFunctionsExt(&BestGenome);

		float outputValue = GeneBasedCalculations.Get_DataArrayValue(IDofOutputValue);
		cout << "output: " << outputValue << " correct output: " << CorrectOutputData[i] << endl;
	}

	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	static constexpr int32_t  ConstTrainingPopulationSize = 500;
	int32_t NumTrainingGenerationsMax = 4000;


	float InputArray1[2] = { 0.0f, 0.0f };
	float InputArray2[2] = { 1.0f, 0.0f };
	float InputArray3[2] = { 0.0f, 1.0f };
	float InputArray4[2] = { 1.0f, 1.0f };


	static constexpr int32_t ConstNumOfInputArrays = 4;

	float *pInputArrayPointer[ConstNumOfInputArrays];

	pInputArrayPointer[0] = InputArray1;
	pInputArrayPointer[1] = InputArray2;
	pInputArrayPointer[2] = InputArray3;
	pInputArrayPointer[3] = InputArray4;

	float DesiredXOROutputArray[ConstNumOfInputArrays] = { 0.0f, 1.0f, 1.0f, 0.0f };

	// Hinweise:
	// XOR: y = (x1 + x2) - (x1 * x2)  (nichtlineare Funktion)
	// AND: y = max(0, x1 + x2 - 1)    (lineare Funktion)
	// AND: y = x1 * x2                (nichtlineare Funktion)
	// OR:  y = min(1, x1 + x2)        (lineare Funktion)

	CGeneBasedCalculations GeneBasedCalculations;

	// 2 Input Values, 3 Neurons (6 Values)
	GeneBasedCalculations.Initialize_DataArray(8);

	GeneBasedCalculations.Initialize_CalculationFunctionArray(3);
	GeneBasedCalculations.Set_CalculationFunction(0, Set_OutputValueBias);
	GeneBasedCalculations.Set_CalculationFunction(1, Add_Weighted);
	GeneBasedCalculations.Set_CalculationFunction(2, TanH);

	// Set_OutputValueBias (Neuron 1), Add_Weighted (x1 => Neuron 1), Add_Weighted (x2 => Neuron 1),
	// Set_OutputValueBias (Neuron 2), Add_Weighted (x1 => Neuron 2), Add_Weighted (x2 => Neuron 2),
	// TanH (Neuron 1), TanH (Neuron 2),
	// Add_Weighted (Neuron 1 => Neuron 3), Add_Weighted (Neuron 2 => Neuron 3), TanH (Neuron 3),

	// verwendete Kennungen (Identifier, abbr.: id):

	int32_t IDof_Set_OutputValueBias = 0;
	int32_t IDof_Add_Weighted = 1;
	int32_t IDof_TanH = 2;

	int32_t IDofInputValue1 = 0;
	int32_t IDofInputValue2 = 1;

	int32_t IDofNeuron1InputValue = 2;
	int32_t IDofNeuron2InputValue = 3;
	int32_t IDofNeuron3InputValue = 4;

	int32_t IDofNeuron1OutputValue = 5;
	int32_t IDofNeuron2OutputValue = 6;
	int32_t IDofNeuron3OutputValue = 7;

	//int32_t IDofNeuron1InputValue = 2;
	//int32_t IDofNeuron1OutputValue = 3;

	//int32_t IDofNeuron2InputValue = 4;
	//int32_t IDofNeuron2OutputValue = 5;

	//int32_t IDofNeuron3InputValue = 6;
	//int32_t IDofNeuron3OutputValue = 7;

	static constexpr int32_t ConstNumOfGenesMax = 11;

	CGenome BestGenome;
	BestGenome.Initialize(ConstNumOfGenesMax, 3, 2, 0);

	CGene tempGene;
	tempGene.Initialize(3, 2, 0);

	static CGenome GenomeArray[ConstTrainingPopulationSize];

	for (int32_t i = 0; i < ConstTrainingPopulationSize; i++)
	{
		GenomeArray[i].Initialize(ConstNumOfGenesMax, 3, 2, 0);

		Set_FunctionIdentifier_For_GeneBasedCalculations(&tempGene, IDof_Set_OutputValueBias); // Bias => Neuron 1 (Input)
		Set_OutputIdentifier_For_GeneBasedCalculations(&tempGene, IDofNeuron1InputValue);

		GenomeArray[i].Set_SingleGeneData(&tempGene, 0);

		Set_FunctionIdentifier_For_GeneBasedCalculations(&tempGene, IDof_Add_Weighted); // x1 => Neuron 1 (Input)
		Set_OutputIdentifier_For_GeneBasedCalculations(&tempGene, IDofNeuron1InputValue);
		Set_InputIdentifier_For_GeneBasedCalculations(&tempGene, IDofInputValue1, 0);

		GenomeArray[i].Set_SingleGeneData(&tempGene, 1);

		Set_FunctionIdentifier_For_GeneBasedCalculations(&tempGene, IDof_Add_Weighted); // x2 => Neuron 1 (Input)
		Set_OutputIdentifier_For_GeneBasedCalculations(&tempGene, IDofNeuron1InputValue);
		Set_InputIdentifier_For_GeneBasedCalculations(&tempGene, IDofInputValue2, 0);

		GenomeArray[i].Set_SingleGeneData(&tempGene, 2);

		Set_FunctionIdentifier_For_GeneBasedCalculations(&tempGene, IDof_Set_OutputValueBias); // Bias => Neuron 2 (Input)
		Set_OutputIdentifier_For_GeneBasedCalculations(&tempGene, IDofNeuron2InputValue);

		GenomeArray[i].Set_SingleGeneData(&tempGene, 3);

		Set_FunctionIdentifier_For_GeneBasedCalculations(&tempGene, IDof_Add_Weighted); // x1 => Neuron 2 (Input)
		Set_OutputIdentifier_For_GeneBasedCalculations(&tempGene, IDofNeuron2InputValue);
		Set_InputIdentifier_For_GeneBasedCalculations(&tempGene, IDofInputValue1, 0);

		GenomeArray[i].Set_SingleGeneData(&tempGene, 4);

		Set_FunctionIdentifier_For_GeneBasedCalculations(&tempGene, IDof_Add_Weighted); // x2 => Neuron 2 (Input)
		Set_OutputIdentifier_For_GeneBasedCalculations(&tempGene, IDofNeuron2InputValue);
		Set_InputIdentifier_For_GeneBasedCalculations(&tempGene, IDofInputValue2, 0);

		GenomeArray[i].Set_SingleGeneData(&tempGene, 5);

		Set_FunctionIdentifier_For_GeneBasedCalculations(&tempGene, IDof_TanH); // Neuron 1 (Input) => Neuron 1 (Output)
		Set_OutputIdentifier_For_GeneBasedCalculations(&tempGene, IDofNeuron1OutputValue);
		Set_InputIdentifier_For_GeneBasedCalculations(&tempGene, IDofNeuron1InputValue, 0);

		GenomeArray[i].Set_SingleGeneData(&tempGene, 6);

		Set_FunctionIdentifier_For_GeneBasedCalculations(&tempGene, IDof_TanH); // Neuron 2 (Input) => Neuron 2 (Output)
		Set_OutputIdentifier_For_GeneBasedCalculations(&tempGene, IDofNeuron2OutputValue);
		Set_InputIdentifier_For_GeneBasedCalculations(&tempGene, IDofNeuron2InputValue, 0);

		GenomeArray[i].Set_SingleGeneData(&tempGene, 7);

		Set_FunctionIdentifier_For_GeneBasedCalculations(&tempGene, IDof_Add_Weighted); // Neuron 1 (Output) => Neuron 3 (Input)
		Set_OutputIdentifier_For_GeneBasedCalculations(&tempGene, IDofNeuron3InputValue);
		Set_InputIdentifier_For_GeneBasedCalculations(&tempGene, IDofNeuron1OutputValue, 0);

		GenomeArray[i].Set_SingleGeneData(&tempGene, 8);

		Set_FunctionIdentifier_For_GeneBasedCalculations(&tempGene, IDof_Add_Weighted); // Neuron 2 (Output) => Neuron 3 (Input)
		Set_OutputIdentifier_For_GeneBasedCalculations(&tempGene, IDofNeuron3InputValue);
		Set_InputIdentifier_For_GeneBasedCalculations(&tempGene, IDofNeuron2OutputValue, 0);

		GenomeArray[i].Set_SingleGeneData(&tempGene, 9);

		Set_FunctionIdentifier_For_GeneBasedCalculations(&tempGene, IDof_TanH); // Neuron 3 (Input) => Neuron 3 (Output)
		Set_OutputIdentifier_For_GeneBasedCalculations(&tempGene, IDofNeuron3OutputValue);
		Set_InputIdentifier_For_GeneBasedCalculations(&tempGene, IDofNeuron3InputValue, 0);

		GenomeArray[i].Set_SingleGeneData(&tempGene, 10);
	}

	CGeneralPopulation Population;
	Population.Set_GenomeValueCloningFunction(CGenome_CloningFunction);

	Population.Initialize(ConstTrainingPopulationSize);

	for (int32_t i = 0; i < ConstTrainingPopulationSize; i++)
	{
		Population.Set_Genome(&GenomeArray[i], i);
	}

	CSimpleReinitializationInfo ReinitializationInfo;
	ReinitializationInfo.minValue = -2.0f;
	ReinitializationInfo.maxValue = 2.0f;

	CSimpleMutationInfo MutationInfo;
	MutationInfo.minValue = -0.1f;
	MutationInfo.maxValue = 0.1f;
	MutationInfo.mutationRate = 0.75f;


	for (int32_t individual = 0; individual < ConstTrainingPopulationSize; individual++)
	{
		Reinitialization_Example4(&GenomeArray[individual], &RandomNumbers, &ReinitializationInfo);
	}


	Population.Reset_Population();

	for (int32_t generation = 0; generation < NumTrainingGenerationsMax; generation++)
	{
		Population.Reset_MinErrorSum_ActualGeneration();

		for (int32_t individual = 0; individual < ConstTrainingPopulationSize; individual++)
		{
			float SumOfErrors = 0.000001f;

			for (int32_t i = 0; i < ConstNumOfInputArrays; i++)
			{
				GeneBasedCalculations.Set_DataArrayValues(pInputArrayPointer[i], 0, 2);

				GeneBasedCalculations.Execute_CalculationFunctions(&GenomeArray[individual]);

				float outputValue = GeneBasedCalculations.Get_DataArrayValue(7);

				float diff = outputValue - DesiredXOROutputArray[i];
				
				SumOfErrors += diff * diff;
			}

			Population.Calculate_FitnessScore_FromError(individual, SumOfErrors);
			//Population.Set_FitnessScore(individual, 1.0f / SumOfErrors);
			Population.Update_MinErrorSum_ActualGeneration(SumOfErrors);
		}

		Population.Update_Population();

		if (generation % 200 == 0)
		{
			cout << "minErrorSum: " << Population.MinErrorSum_ActualGeneration << endl;
		}

		if (Population.MinErrorSum_ActualGeneration < 0.005f)
		{
			cout << endl;
			cout << "minErrorSum: " << Population.MinErrorSum_ActualGeneration << endl;
			cout << "actual generation: " << generation << endl;
			cout << "training completed" << endl << endl;
			break;
		}

		if (Population.MinErrorSum_ActualGeneration < 1.0f)
		{
			MutationInfo.minValue = -0.01f;
			MutationInfo.maxValue = 0.01f;
		}
		else if (Population.MinErrorSum_ActualGeneration < 0.5f)
		{
			MutationInfo.minValue = -0.005f;
			MutationInfo.maxValue = 0.005f;
		}

		Population.Update_BaseEvolution(Mutation_Example4, &MutationInfo);
		Population.Update_Evolution_BestGenomeOnly(Mutation_Example4, &MutationInfo);
		Population.Update_Evolution_SecondBestGenomeOnly(Mutation_Example4, &MutationInfo);
		Population.Update_Evolution_Combine_BestTwoGenomes(Recombination_Example5, nullptr);
		Population.Update_Evolution_Combine_TwoGenomes(Recombination_Example5, nullptr);
		Population.Update_Evolution_Combine_TwoGenomes(Recombination_Example5, nullptr);
		Population.Replace_WorstFitted_Genome(Reinitialization_Example4, &RandomNumbers, &ReinitializationInfo); 
	}

	Population.Get_Best_Evolved_Genome(&BestGenome);


	for (int32_t i = 0; i < ConstNumOfInputArrays; i++)
	{
		GeneBasedCalculations.Set_DataArrayValues(pInputArrayPointer[i], 0, 2);

		GeneBasedCalculations.Execute_CalculationFunctions(&BestGenome);

		float outputValue = GeneBasedCalculations.Get_DataArrayValue(7);
		cout << "output: " << outputValue << " correct output: " << DesiredXOROutputArray[i] << endl;
	}


	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	static constexpr int32_t  ConstTrainingPopulationSize = 500;
	int32_t NumTrainingGenerationsMax = 4000;


	float InputArray1[2] = { 0.0f, 0.0f };
	float InputArray2[2] = { 1.0f, 0.0f };
	float InputArray3[2] = { 0.0f, 1.0f };
	float InputArray4[2] = { 1.0f, 1.0f };


	static constexpr int32_t ConstNumOfInputArrays = 4;

	float *pInputArrayPointer[ConstNumOfInputArrays];

	pInputArrayPointer[0] = InputArray1;
	pInputArrayPointer[1] = InputArray2;
	pInputArrayPointer[2] = InputArray3;
	pInputArrayPointer[3] = InputArray4;

	float DesiredXOROutputArray[ConstNumOfInputArrays] = { 0.0f, 1.0f, 1.0f, 0.0f };

	CGeneBasedCalculations GeneBasedCalculations;

	// 2 Input Values, 3 Neurons (6 Values)
	GeneBasedCalculations.Initialize_DataArray(8);

	GeneBasedCalculations.Initialize_CalculationFunctionArray(3);
	GeneBasedCalculations.Set_CalculationFunction(0, Set_OutputValueBias);
	GeneBasedCalculations.Set_CalculationFunction(1, Add_Weighted_2DVecElements);
	GeneBasedCalculations.Set_CalculationFunction(2, TanH);

	// Set_OutputValueBias (Neuron 1), Add_Weighted_2DVecElements(x1, x2 => Neuron 1),
	// Set_OutputValueBias (Neuron 2), Add_Weighted_2DVecElements(x1, x2 => Neuron 2),
	// TanH (Neuron 1), TanH (Neuron 2),
	// Add_Weighted_2DVecElements(Neuron 1, Neuron 2 => Neuron 3), TanH (Neuron 3),

	// verwendete Kennungen (Identifier, abbr.: id):

	int32_t IDof_Set_OutputValueBias = 0;
	int32_t IDof_Add_Weighted_2DVecElements = 1;
	int32_t IDof_TanH = 2;

	int32_t IDofInputValue1 = 0;
	int32_t IDofInputValue2 = 1;

	int32_t IDofNeuron1InputValue = 2;
	int32_t IDofNeuron2InputValue = 3;
	int32_t IDofNeuron3InputValue = 4;

	int32_t IDofNeuron1OutputValue = 5;
	int32_t IDofNeuron2OutputValue = 6;
	int32_t IDofNeuron3OutputValue = 7;

	//int32_t IDofNeuron1InputValue = 2;
	//int32_t IDofNeuron1OutputValue = 3;

	//int32_t IDofNeuron2InputValue = 4;
	//int32_t IDofNeuron2OutputValue = 5;

	//int32_t IDofNeuron3InputValue = 6;
	//int32_t IDofNeuron3OutputValue = 7;

	static constexpr int32_t ConstNumOfGenesMax = 8;

	CGenome BestGenome;
	BestGenome.Initialize(ConstNumOfGenesMax, 4, 2, 0);

	CGene tempGene;
	tempGene.Initialize(4, 2, 0);

	static CGenome GenomeArray[ConstTrainingPopulationSize];

	for (int32_t i = 0; i < ConstTrainingPopulationSize; i++)
	{
		GenomeArray[i].Initialize(ConstNumOfGenesMax, 4, 2, 0);

		Set_FunctionIdentifier_For_GeneBasedCalculations(&tempGene, IDof_Set_OutputValueBias); // Bias => Neuron 1 (Input)
		Set_OutputIdentifier_For_GeneBasedCalculations(&tempGene, IDofNeuron1InputValue);

		GenomeArray[i].Set_SingleGeneData(&tempGene, 0);

		Set_FunctionIdentifier_For_GeneBasedCalculations(&tempGene, IDof_Add_Weighted_2DVecElements); // x1, x2 => Neuron 1 (Input)
		Set_OutputIdentifier_For_GeneBasedCalculations(&tempGene, IDofNeuron1InputValue);
		Set_InputIdentifier_For_GeneBasedCalculations(&tempGene, IDofInputValue1, 0);
		Set_InputIdentifier_For_GeneBasedCalculations(&tempGene, IDofInputValue2, 1);

		GenomeArray[i].Set_SingleGeneData(&tempGene, 1);

		Set_FunctionIdentifier_For_GeneBasedCalculations(&tempGene, IDof_Set_OutputValueBias); // Bias => Neuron 1 (Input)
		Set_OutputIdentifier_For_GeneBasedCalculations(&tempGene, IDofNeuron2InputValue);

		GenomeArray[i].Set_SingleGeneData(&tempGene, 2);

		Set_FunctionIdentifier_For_GeneBasedCalculations(&tempGene, IDof_Add_Weighted_2DVecElements); // x1, x2 => Neuron 2 (Input)
		Set_OutputIdentifier_For_GeneBasedCalculations(&tempGene, IDofNeuron2InputValue);
		Set_InputIdentifier_For_GeneBasedCalculations(&tempGene, IDofInputValue1, 0);
		Set_InputIdentifier_For_GeneBasedCalculations(&tempGene, IDofInputValue2, 1);

		GenomeArray[i].Set_SingleGeneData(&tempGene, 3);

		Set_FunctionIdentifier_For_GeneBasedCalculations(&tempGene, IDof_TanH); // Neuron 1 (Input) => Neuron 1 (Output)
		Set_OutputIdentifier_For_GeneBasedCalculations(&tempGene, IDofNeuron1OutputValue);
		Set_InputIdentifier_For_GeneBasedCalculations(&tempGene, IDofNeuron1InputValue, 0);

		GenomeArray[i].Set_SingleGeneData(&tempGene, 4);

		Set_FunctionIdentifier_For_GeneBasedCalculations(&tempGene, IDof_TanH); // Neuron 2 (Input) => Neuron 2 (Output)
		Set_OutputIdentifier_For_GeneBasedCalculations(&tempGene, IDofNeuron2OutputValue);
		Set_InputIdentifier_For_GeneBasedCalculations(&tempGene, IDofNeuron2InputValue, 0);

		GenomeArray[i].Set_SingleGeneData(&tempGene, 5);

		Set_FunctionIdentifier_For_GeneBasedCalculations(&tempGene, IDof_Add_Weighted_2DVecElements); // Neuron 1 (Output), Neuron 2 (Output) => Neuron 3 (Input)
		Set_OutputIdentifier_For_GeneBasedCalculations(&tempGene, IDofNeuron3InputValue);
		Set_InputIdentifier_For_GeneBasedCalculations(&tempGene, IDofNeuron1OutputValue, 0);
		Set_InputIdentifier_For_GeneBasedCalculations(&tempGene, IDofNeuron2OutputValue, 1);

		GenomeArray[i].Set_SingleGeneData(&tempGene, 6);

		Set_FunctionIdentifier_For_GeneBasedCalculations(&tempGene, IDof_TanH); // Neuron 3 (Input) => Neuron 3 (Output)
		Set_OutputIdentifier_For_GeneBasedCalculations(&tempGene, IDofNeuron3OutputValue);
		Set_InputIdentifier_For_GeneBasedCalculations(&tempGene, IDofNeuron3InputValue, 0);

		GenomeArray[i].Set_SingleGeneData(&tempGene, 7);
	}

	CGeneralPopulation Population;
	Population.Set_GenomeValueCloningFunction(CGenome_CloningFunction);

	Population.Initialize(ConstTrainingPopulationSize);

	for (int32_t i = 0; i < ConstTrainingPopulationSize; i++)
	{
		Population.Set_Genome(&GenomeArray[i], i);
	}

	CSimpleReinitializationInfo ReinitializationInfo;
	ReinitializationInfo.minValue = -2.0f;
	ReinitializationInfo.maxValue = 2.0f;

	CSimpleMutationInfo MutationInfo;
	MutationInfo.minValue = -0.1f;
	MutationInfo.maxValue = 0.1f;
	MutationInfo.mutationRate = 0.75f;


	for (int32_t individual = 0; individual < ConstTrainingPopulationSize; individual++)
	{
		Reinitialization_Example4(&GenomeArray[individual], &RandomNumbers, &ReinitializationInfo);
	}


	Population.Reset_Population();

	for (int32_t generation = 0; generation < NumTrainingGenerationsMax; generation++)
	{
		Population.Reset_MinErrorSum_ActualGeneration();

		for (int32_t individual = 0; individual < ConstTrainingPopulationSize; individual++)
		{
			float SumOfErrors = 0.000001f;

			for (int32_t i = 0; i < ConstNumOfInputArrays; i++)
			{
				GeneBasedCalculations.Set_DataArrayValues(pInputArrayPointer[i], 0, 2);

				GeneBasedCalculations.Execute_CalculationFunctions(&GenomeArray[individual]);

				float outputValue = GeneBasedCalculations.Get_DataArrayValue(7);

				float diff = outputValue - DesiredXOROutputArray[i];

				SumOfErrors += diff * diff;
			}

			Population.Calculate_FitnessScore_FromError(individual, SumOfErrors);
			//Population.Set_FitnessScore(individual, 1.0f / SumOfErrors);
			Population.Update_MinErrorSum_ActualGeneration(SumOfErrors);
		}

		Population.Update_Population();

		if (generation % 200 == 0)
		{
			cout << "minErrorSum: " << Population.MinErrorSum_ActualGeneration << endl;
		}

		if (Population.MinErrorSum_ActualGeneration < 0.0025f)
		{
			cout << endl;
			cout << "minErrorSum: " << Population.MinErrorSum_ActualGeneration << endl;
			cout << "actual generation: " << generation << endl;
			cout << "training completed" << endl << endl;
			break;
		}

		if (Population.MinErrorSum_ActualGeneration < 1.0f)
		{
			MutationInfo.minValue = -0.01f;
			MutationInfo.maxValue = 0.01f;
		}
		else if (Population.MinErrorSum_ActualGeneration < 0.5f)
		{
			MutationInfo.minValue = -0.005f;
			MutationInfo.maxValue = 0.005f;
		}

		Population.Update_BaseEvolution(Mutation_Example4, &MutationInfo);
		Population.Update_Evolution_BestGenomeOnly(Mutation_Example4, &MutationInfo);
		Population.Update_Evolution_SecondBestGenomeOnly(Mutation_Example4, &MutationInfo);
		Population.Update_Evolution_Combine_BestTwoGenomes(Recombination_Example5, nullptr);
		Population.Update_Evolution_Combine_TwoGenomes(Recombination_Example5, nullptr);
		Population.Update_Evolution_Combine_TwoGenomes(Recombination_Example5, nullptr);
		Population.Replace_WorstFitted_Genome(Reinitialization_Example4, &RandomNumbers, &ReinitializationInfo);
	}

	Population.Get_Best_Evolved_Genome(&BestGenome);


	for (int32_t i = 0; i < ConstNumOfInputArrays; i++)
	{
		GeneBasedCalculations.Set_DataArrayValues(pInputArrayPointer[i], 0, 2);

		GeneBasedCalculations.Execute_CalculationFunctions(&BestGenome);

		float outputValue = GeneBasedCalculations.Get_DataArrayValue(7);
		cout << "output: " << outputValue << " correct output: " << DesiredXOROutputArray[i] << endl;
	}


	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	static constexpr int32_t  ConstTrainingPopulationSize = 500;
	int32_t NumTrainingGenerationsMax = 4000;


	float InputArray1[2] = { 0.0f, 0.0f };
	float InputArray2[2] = { 1.0f, 0.0f };
	float InputArray3[2] = { 0.0f, 1.0f };
	float InputArray4[2] = { 1.0f, 1.0f };


	static constexpr int32_t ConstNumOfInputArrays = 4;

	float *pInputArrayPointer[ConstNumOfInputArrays];

	pInputArrayPointer[0] = InputArray1;
	pInputArrayPointer[1] = InputArray2;
	pInputArrayPointer[2] = InputArray3;
	pInputArrayPointer[3] = InputArray4;

	float DesiredXOROutputArray[ConstNumOfInputArrays] = { 0.0f, 1.0f, 1.0f, 0.0f };

	CGeneBasedCalculations GeneBasedCalculations;

	// 2 Input Values, 3 Neurons (6 Values)
	GeneBasedCalculations.Initialize_DataArray(8);

	GeneBasedCalculations.Initialize_CalculationFunctionArray(4);
	GeneBasedCalculations.Set_CalculationFunction(0, Calc_DiffSqSum_2DVecElements);
	GeneBasedCalculations.Set_CalculationFunction(1, Add_Weighted_2DVecElements);
	GeneBasedCalculations.Set_CalculationFunction(2, WeightedExpRBF);
	GeneBasedCalculations.Set_CalculationFunction(3, TanH);

	// Calc_DiffSqSum_2DVecElements(x1, x2 => Neuron 1),
	// Calc_DiffSqSum_2DVecElements(x1, x2 => Neuron 2),
	// WeightedExpRBF (Neuron 1), WeightedExpRBF (Neuron 2),
	// Add_Weighted_2DVecElements(Neuron 1, Neuron 2 => Neuron 3), TanH (Neuron 3),

	// verwendete Kennungen (Identifier, abbr.: id):

	int32_t IDof_Calc_DiffSqSum_2DVecElements = 0;
	int32_t IDof_Add_Weighted_2DVecElements = 1;
	int32_t IDof_WeightedExpRBF = 2;
	int32_t IDof_TanH = 3;

	int32_t IDofInputValue1 = 0;
	int32_t IDofInputValue2 = 1;

	int32_t IDofNeuron1InputValue = 2;
	int32_t IDofNeuron2InputValue = 3;
	int32_t IDofNeuron3InputValue = 4;

	int32_t IDofNeuron1OutputValue = 5;
	int32_t IDofNeuron2OutputValue = 6;
	int32_t IDofNeuron3OutputValue = 7;

	//int32_t IDofNeuron1InputValue = 2;
	//int32_t IDofNeuron1OutputValue = 3;

	//int32_t IDofNeuron2InputValue = 4;
	//int32_t IDofNeuron2OutputValue = 5;

	//int32_t IDofNeuron3InputValue = 6;
	//int32_t IDofNeuron3OutputValue = 7;


	static constexpr int32_t ConstNumOfGenesMax = 6;

	CGenome BestGenome;
	BestGenome.Initialize(ConstNumOfGenesMax, 4, 2, 0);

	CGene tempGene;
	tempGene.Initialize(4, 2, 0);

	static CGenome GenomeArray[ConstTrainingPopulationSize];

	for (int32_t i = 0; i < ConstTrainingPopulationSize; i++)
	{
		GenomeArray[i].Initialize(ConstNumOfGenesMax, 4, 2, 0);

		Set_FunctionIdentifier_For_GeneBasedCalculations(&tempGene, IDof_Calc_DiffSqSum_2DVecElements); // x1, x2 => Neuron 1 (Input)
		Set_OutputIdentifier_For_GeneBasedCalculations(&tempGene, IDofNeuron1InputValue);
		Set_InputIdentifier_For_GeneBasedCalculations(&tempGene, IDofInputValue1, 0);
		Set_InputIdentifier_For_GeneBasedCalculations(&tempGene, IDofInputValue2, 1);

		GenomeArray[i].Set_SingleGeneData(&tempGene, 0);

		Set_FunctionIdentifier_For_GeneBasedCalculations(&tempGene, IDof_Calc_DiffSqSum_2DVecElements); // x1, x2 => Neuron 2 (Input)
		Set_OutputIdentifier_For_GeneBasedCalculations(&tempGene, IDofNeuron2InputValue);
		Set_InputIdentifier_For_GeneBasedCalculations(&tempGene, IDofInputValue1, 0);
		Set_InputIdentifier_For_GeneBasedCalculations(&tempGene, IDofInputValue2, 1);

		GenomeArray[i].Set_SingleGeneData(&tempGene, 1);

		Set_FunctionIdentifier_For_GeneBasedCalculations(&tempGene, IDof_WeightedExpRBF); // Neuron 1 (Input) => Neuron 1 (Output)
		Set_OutputIdentifier_For_GeneBasedCalculations(&tempGene, IDofNeuron1OutputValue);
		Set_InputIdentifier_For_GeneBasedCalculations(&tempGene, IDofNeuron1InputValue, 0);
		
		GenomeArray[i].Set_SingleGeneData(&tempGene, 2);

		Set_FunctionIdentifier_For_GeneBasedCalculations(&tempGene, IDof_WeightedExpRBF); // Neuron 2 (Input) => Neuron 2 (Output)
		Set_OutputIdentifier_For_GeneBasedCalculations(&tempGene, IDofNeuron2OutputValue);
		Set_InputIdentifier_For_GeneBasedCalculations(&tempGene, IDofNeuron2InputValue, 0);

		GenomeArray[i].Set_SingleGeneData(&tempGene, 3);

		Set_FunctionIdentifier_For_GeneBasedCalculations(&tempGene, IDof_Add_Weighted_2DVecElements); // Neuron 1 (Output), Neuron 2 (Output) => Neuron 3 (Input)
		Set_OutputIdentifier_For_GeneBasedCalculations(&tempGene, IDofNeuron3InputValue);
		Set_InputIdentifier_For_GeneBasedCalculations(&tempGene, IDofNeuron1OutputValue, 0);
		Set_InputIdentifier_For_GeneBasedCalculations(&tempGene, IDofNeuron2OutputValue, 1);

		GenomeArray[i].Set_SingleGeneData(&tempGene, 4);

		Set_FunctionIdentifier_For_GeneBasedCalculations(&tempGene, IDof_TanH); // Neuron 3 (Input) => Neuron 3 (Output)
		Set_OutputIdentifier_For_GeneBasedCalculations(&tempGene, IDofNeuron3OutputValue);
		Set_InputIdentifier_For_GeneBasedCalculations(&tempGene, IDofNeuron3InputValue, 0);

		GenomeArray[i].Set_SingleGeneData(&tempGene, 5);
	}

	CGeneralPopulation Population;
	Population.Set_GenomeValueCloningFunction(CGenome_CloningFunction);

	Population.Initialize(ConstTrainingPopulationSize);

	for (int32_t i = 0; i < ConstTrainingPopulationSize; i++)
	{
		Population.Set_Genome(&GenomeArray[i], i);
	}

	CSimpleReinitializationInfo ReinitializationInfo;
	ReinitializationInfo.minValue = -2.0f;
	ReinitializationInfo.maxValue = 2.0f;

	CSimpleMutationInfo MutationInfo;
	MutationInfo.minValue = -0.1f;
	MutationInfo.maxValue = 0.1f;
	MutationInfo.mutationRate = 0.75f;


	for (int32_t individual = 0; individual < ConstTrainingPopulationSize; individual++)
	{
		Reinitialization_Example4(&GenomeArray[individual], &RandomNumbers, &ReinitializationInfo);
	}


	Population.Reset_Population();

	for (int32_t generation = 0; generation < NumTrainingGenerationsMax; generation++)
	{
		Population.Reset_MinErrorSum_ActualGeneration();

		for (int32_t individual = 0; individual < ConstTrainingPopulationSize; individual++)
		{
			float SumOfErrors = 0.000001f;

			for (int32_t i = 0; i < ConstNumOfInputArrays; i++)
			{
				GeneBasedCalculations.Set_DataArrayValues(pInputArrayPointer[i], 0, 2);

				GeneBasedCalculations.Execute_CalculationFunctions(&GenomeArray[individual]);

				float outputValue = GeneBasedCalculations.Get_DataArrayValue(7);

				float diff = outputValue - DesiredXOROutputArray[i];

				SumOfErrors += diff * diff;
			}

			Population.Calculate_FitnessScore_FromError(individual, SumOfErrors);
			//Population.Set_FitnessScore(individual, 1.0f / SumOfErrors);
			Population.Update_MinErrorSum_ActualGeneration(SumOfErrors);
		}

		Population.Update_Population();

		if (generation % 200 == 0)
		{
			cout << "minErrorSum: " << Population.MinErrorSum_ActualGeneration << endl;
		}

		if (Population.MinErrorSum_ActualGeneration < 0.0025f)
		{
			cout << endl;
			cout << "minErrorSum: " << Population.MinErrorSum_ActualGeneration << endl;
			cout << "actual generation: " << generation << endl;
			cout << "training completed" << endl << endl;
			break;
		}

		if (Population.MinErrorSum_ActualGeneration < 1.0f)
		{
			MutationInfo.minValue = -0.01f;
			MutationInfo.maxValue = 0.01f;
		}
		else if (Population.MinErrorSum_ActualGeneration < 0.5f)
		{
			MutationInfo.minValue = -0.005f;
			MutationInfo.maxValue = 0.005f;
		}

		Population.Update_BaseEvolution(Mutation_Example4, &MutationInfo);
		Population.Update_Evolution_BestGenomeOnly(Mutation_Example4, &MutationInfo);
		Population.Update_Evolution_SecondBestGenomeOnly(Mutation_Example4, &MutationInfo);
		Population.Update_Evolution_Combine_BestTwoGenomes(Recombination_Example5, nullptr);
		Population.Update_Evolution_Combine_TwoGenomes(Recombination_Example5, nullptr);
		Population.Update_Evolution_Combine_TwoOfTheBestGenomes(Recombination_Example5, nullptr);
		Population.Replace_WorstFitted_Genome(Reinitialization_Example4, &RandomNumbers, &ReinitializationInfo);
	}

	Population.Get_Best_Evolved_Genome(&BestGenome);


	for (int32_t i = 0; i < ConstNumOfInputArrays; i++)
	{
		GeneBasedCalculations.Set_DataArrayValues(pInputArrayPointer[i], 0, 2);

		GeneBasedCalculations.Execute_CalculationFunctions(&BestGenome);

		float outputValue = GeneBasedCalculations.Get_DataArrayValue(7);
		cout << "output: " << outputValue << " correct output: " << DesiredXOROutputArray[i] << endl;
	}


	getchar();
	return 0;
}
*/





static constexpr int32_t NumSurfaceMapElementsPerDir = 7;
static constexpr int32_t NumSurfaceMapElements = NumSurfaceMapElementsPerDir * NumSurfaceMapElementsPerDir;
static constexpr int32_t NumSurfaceMapElementsPerDirMinus1 = NumSurfaceMapElementsPerDir - 1;

static constexpr int32_t NumCities_TSP = 12;
static constexpr int32_t NumCities_TSP_Plus1 = NumCities_TSP + 1;


static constexpr int32_t NumWaypoints = 12;
static constexpr int32_t NumWaypointsMaxPerPath = 10;



static void Output_SurfaceMapData(char *pData)
{
	for (int32_t iy = 0; iy < NumSurfaceMapElementsPerDir; iy++)
	{
		int32_t iiy = iy * NumSurfaceMapElementsPerDir;

		for (int32_t ix = 0; ix < NumSurfaceMapElementsPerDir; ix++)
		{
			int32_t id = ix + iiy;
			cout << pData[id] << " ";
		}

		cout << endl;
	}

	cout << endl << endl;
}

static void Set_SurfaceMapData(char *pOutData, int32_t ix, int32_t iy, char sign)
{
	ix = max(0, ix);
	iy = max(0, iy);

	ix = min(NumSurfaceMapElementsPerDirMinus1, ix);
	iy = min(NumSurfaceMapElementsPerDirMinus1, iy);

	int32_t id = ix + iy * NumSurfaceMapElementsPerDir;
	pOutData[id] = sign;
}

static void Init_SurfaceMap(char *pOutData, char sign)
{
	uint32_t ix, iy, id;

	for (iy = 0; iy < NumSurfaceMapElementsPerDir; iy++)
	{
		for (ix = 0; ix < NumSurfaceMapElementsPerDir; ix++)
		{
			id = ix + iy * NumSurfaceMapElementsPerDir;
			pOutData[id] = sign;
		}
	}
}


static void Update_Fitnessvalues(CGraphNode *pGraphNodeArray, CGeneralPopulation *pPopulation)
{
	CSimpleIntegerValueGenome *pGenomeArray = static_cast<CSimpleIntegerValueGenome*>(pPopulation->ppGenomeArray[0]);

	int32_t populationSizePlusX = pPopulation->PopulationSizePlusX;
	int32_t numOfGenes = pGenomeArray[0].NumOfGenes;

	float distSq;

	for (int32_t i = 0; i < populationSizePlusX; i++)
	{
		distSq = pGraphNodeArray->Calculate_PathDistSq(pGenomeArray[i].pGeneArray, numOfGenes);
		pPopulation->Set_FitnessScore(i, 1.0f / distSq);
	}
}

static void Update_FitnessvaluesExt(CGraphNode *pGraphNodeArray, CWeightMatrix *pWeightMatrix, CGeneralPopulation *pPopulation)
{
	CSimpleIntegerValueGenome *pGenomeArray = static_cast<CSimpleIntegerValueGenome*>(pPopulation->ppGenomeArray[0]);

	int32_t populationSizePlusX = pPopulation->PopulationSizePlusX;
	int32_t numOfGenes = pGenomeArray[0].NumOfGenes;

	float distSq;

	for (int32_t i = 0; i < populationSizePlusX; i++)
	{
		distSq = pGraphNodeArray->Calculate_WeightedPathDistSq(pGenomeArray[i].pGeneArray, pWeightMatrix, numOfGenes);
		pPopulation->Set_FitnessScore(i, 1.0f / distSq);
	}
}

static void TSP_RecombinationFunction(void *pOffspring, void *pParent1, void *pParent2, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	CSimpleIntegerValueGenome *pOffspringGenome = static_cast<CSimpleIntegerValueGenome*>(pOffspring);
	CSimpleIntegerValueGenome *pParent1Genome = static_cast<CSimpleIntegerValueGenome*>(pParent1);
	CSimpleIntegerValueGenome *pParent2Genome = static_cast<CSimpleIntegerValueGenome*>(pParent2);

	static int32_t tempGeneArray[1000];

	int32_t numOfGenes = pOffspringGenome->NumOfGenes;
	int32_t numOfGenesMinus1 = numOfGenes - 1;

	int32_t *pInputGeneArray1 = pParent1Genome->pGeneArray;
	int32_t *pInputGeneArray2 = pParent2Genome->pGeneArray;
	int32_t *pOutputGeneArray = pOffspringGenome->pGeneArray;


	int32_t counter = 0;

	/* Route 1 von Individuum 1 mit Ausnahme des Zielpunkts zwischenspeichern: */
	for (int32_t i = 0; i < numOfGenesMinus1; i++)
	{
		tempGeneArray[counter] = pInputGeneArray1[i];
		counter++;
	}

	/* Route 2 von Individuum 2 mit Ausnahme des Startpunkts zwischenspeichern: */
	for (int32_t i = 1; i < numOfGenes; i++)
	{
		tempGeneArray[counter] = pInputGeneArray2[i];
		counter++;
	}


	counter--;

	for (int32_t i = 1; i < counter; i++)
	{
		/* entweder Wegpunkt von Route 1 deaktivieren (durch negatives Vorzeichen kennzeichnen): */
		if (pRandomNumbers->Get_IntegerNumber(1, 3) == 1)
		{
			for (int32_t j = 1; j < numOfGenesMinus1; j++)
			{
				if (tempGeneArray[j] == i)
				{
					tempGeneArray[j] = -i;
					break;
				}
			}
		}
		/* oder Wegpunkt von Route 2 deaktivieren (durch negatives Vorzeichen kennzeichnen): */
		else
		{
			for (int32_t j = numOfGenesMinus1; j < counter; j++)
			{
				if (tempGeneArray[j] == i)
				{
					tempGeneArray[j] = -i;
					break;
				}
			}
		}
	}

	/* Neue Route aus nicht deaktivierten Wegpunkten generieren: */

	pOutputGeneArray[0] = 0;
	pOutputGeneArray[numOfGenesMinus1] = 0;

	int32_t counter2 = 1;
	//counter--;
	for (int32_t i = 1; i < counter; i++)
	{
		/* pos. Vorzeichen => nicht deaktivierter Wegpunkt: */
		if (tempGeneArray[i] > 0)
		{
			pOutputGeneArray[counter2] = tempGeneArray[i];
			counter2++;
		}
	}
}


struct CPermutationInfo
{
	int32_t minGeneID = 0;
	int32_t maxGeneID = 0;
	int32_t permutationSteps = 0;
};

static void TSP_PermutationFunction(void *pInOutGenome, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	CSimpleIntegerValueGenome *pGenome = static_cast<CSimpleIntegerValueGenome*>(pInOutGenome);
	CPermutationInfo *pPermutationInfo = static_cast<CPermutationInfo*>(pParam);

	int32_t minGeneID = pPermutationInfo->minGeneID;
	int32_t maxGeneID = pPermutationInfo->maxGeneID;
	int32_t permutationSteps = pPermutationInfo->permutationSteps;

	pGenome->Permute_GeneData(pRandomNumbers, minGeneID, maxGeneID, permutationSteps);
}

struct CPermutationInfoExt
{
	int32_t minGeneID = 0;
	int32_t maxGeneID = 0;
	int32_t permutationSteps = 0;
	CGraphNode* pGraphNodeArray = nullptr;
};

static void TSP_PermutationFunctionExt(void* pInOutGenome, CRandomNumbersNN* pRandomNumbers, void* pParam)
{
	CSimpleIntegerValueGenome* pGenome = static_cast<CSimpleIntegerValueGenome*>(pInOutGenome);
	CPermutationInfoExt* pPermutationInfo = static_cast<CPermutationInfoExt*>(pParam);

	int32_t minGeneID = pPermutationInfo->minGeneID;
	int32_t maxGeneID = pPermutationInfo->maxGeneID;
	int32_t permutationSteps = pPermutationInfo->permutationSteps;
	CGraphNode* pGraphNodeArray = pPermutationInfo->pGraphNodeArray;

	int32_t* pGeneArray = pGenome->pGeneArray;

	for (int32_t i = 0; i < permutationSteps; i++)
	{
		float originalPathDistSq = pGraphNodeArray[0].Calculate_PathDistSq(pGeneArray, NumCities_TSP_Plus1);

		int32_t id1 = 0;
		int32_t id2 = 0;

		do
		{
			id1 = pRandomNumbers->Get_IntegerNumber2(minGeneID, maxGeneID);
			id2 = pRandomNumbers->Get_IntegerNumber2(minGeneID, maxGeneID);

			if (id1 != id2)
			{
				break;
			}

		} while (true);

		int32_t tempValue = pGeneArray[id1];

		pGeneArray[id1] = pGeneArray[id2];
		pGeneArray[id2] = tempValue;

		float newPathDistSq = pGraphNodeArray[0].Calculate_PathDistSq(pGeneArray, NumCities_TSP_Plus1);

		if (newPathDistSq > originalPathDistSq)
		{
			// �nderungen am Genom r�ckg�ngig machen:
			int32_t tempValue = pGeneArray[id1];

			pGeneArray[id1] = pGeneArray[id2];
			pGeneArray[id2] = tempValue;
		}
	} /* end of for (int32_t i = 0; i < permutationSteps; i++) */
}





static void TSP_PermutationFunctionTest(void* pInOutGenome, CRandomNumbersNN* pRandomNumbers, void* pParam)
{
	CSimpleIntegerValueGenome *pGenome = static_cast<CSimpleIntegerValueGenome*>(pInOutGenome);
	CGraphNode* pGraphNodeArray = static_cast<CGraphNode*>(pParam);

	int32_t* pGeneArray = pGenome->pGeneArray;

	float originalPathDistSq = pGraphNodeArray[0].Calculate_PathDistSq(pGeneArray, NumCities_TSP_Plus1);

	//if (pRandomNumbers->Get_IntegerNumber2(0, 4) < 3)
	{
		int32_t id1 = 0;
		int32_t id2 = 0;

		do
		{
			id1 = pRandomNumbers->Get_IntegerNumber(1, NumCities_TSP);
			id2 = pRandomNumbers->Get_IntegerNumber(1, NumCities_TSP);

			if (id1 != id2)
			{
				break;
			}

		} while (true);

		int32_t tempValue = pGeneArray[id1];

		pGeneArray[id1] = pGeneArray[id2];
		pGeneArray[id2] = tempValue;

		float newPathDistSq = pGraphNodeArray[0].Calculate_PathDistSq(pGeneArray, NumCities_TSP_Plus1);

		// �nderungen am Genom r�ckg�ngig machen:
		if (newPathDistSq > originalPathDistSq)
		{
			int32_t tempValue = pGeneArray[id1];

			pGeneArray[id1] = pGeneArray[id2];
			pGeneArray[id2] = tempValue;
		}

		return;
	} /* end of if (pRandomNumbers->Get_IntegerNumber2(0, 4) < 3) */
	
	float maxDistSq = 0.0f;
	int32_t geneID1 = 0;

	for (int32_t i = 1; i <= NumCities_TSP; i++)
	{
		int32_t id1 = i - 1;
		int32_t id2 = i;

		float distSq = pGraphNodeArray[id2].Get_DistanceSq_to_Other_Node(id1);

		if (distSq > maxDistSq)
		{
			maxDistSq = distSq;

			if (id2 != 0)
			{
				geneID1 = id2;
			}
			else
			{
				geneID1 = id1;
			}
		}
	}

	int32_t geneID2 = 0;

	do
	{
		geneID2 = pRandomNumbers->Get_IntegerNumber(1, NumCities_TSP);

		if (geneID2 != geneID1)
		{
			break;
		}
	} while (true);

	int32_t tempValue = pGeneArray[geneID1];

	pGeneArray[geneID1] = pGeneArray[geneID2];
	pGeneArray[geneID2] = tempValue;

	float newPathDistSq = pGraphNodeArray[0].Calculate_PathDistSq(pGeneArray, NumCities_TSP_Plus1);

	// �nderungen am Genom r�ckg�ngig machen:
	if (newPathDistSq > originalPathDistSq) 
	{
		int32_t tempValue = pGeneArray[geneID1];

		pGeneArray[geneID1] = pGeneArray[geneID2];
		pGeneArray[geneID2] = tempValue;
	}
}



static void Pathfinding_MutationFunction(void *pInOutGenome, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	CSimpleIntegerValueGenome *pGenome = static_cast<CSimpleIntegerValueGenome*>(pInOutGenome);

	int32_t numOfGenes = pGenome->NumOfGenes;

	int32_t iDofMutatedPathElement = pRandomNumbers->Get_IntegerNumber(1, numOfGenes - 1);

	int32_t *pGeneArray = pGenome->pGeneArray;

	int32_t startID = pGeneArray[0];
	int32_t destinationID = pGeneArray[numOfGenes - 1];

	do
	{
		int32_t waypontID = pRandomNumbers->Get_IntegerNumber(0, numOfGenes);

		if (waypontID == startID)
			continue;
		if (waypontID == destinationID)
			continue;
		if (waypontID == pGeneArray[iDofMutatedPathElement])
			continue;

		pGeneArray[iDofMutatedPathElement] = waypontID;
		break;

	} while (true);
}

static void Pathfinding_RecombinationFunction(void *pOffspring, void *pParent1, void *pParent2, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	CSimpleIntegerValueGenome *pOffspringGenome = static_cast<CSimpleIntegerValueGenome*>(pOffspring);
	CSimpleIntegerValueGenome *pParent1Genome = static_cast<CSimpleIntegerValueGenome*>(pParent1);
	CSimpleIntegerValueGenome *pParent2Genome = static_cast<CSimpleIntegerValueGenome*>(pParent2);


	int32_t *pGeneArray_Parent1 = pParent1Genome->pGeneArray;
	int32_t *pGeneArray_Parent2 = pParent2Genome->pGeneArray;
	int32_t *pGeneArray_Offspring = pOffspringGenome->pGeneArray;

	int32_t numOfGenes = pOffspringGenome->NumOfGenes;
	int32_t numOfGenesMinus1 = numOfGenes - 1;

	for (int32_t i = 0; i < numOfGenes; i++)
		pGeneArray_Offspring[i] = pGeneArray_Parent1[i];

	for (int32_t i = 1; i < numOfGenesMinus1; i++)
	{
		if (pRandomNumbers->Get_IntegerNumber2(1, 2) == 2)
			pGeneArray_Offspring[i] = pGeneArray_Parent2[i];
	}
}

static void Get_Path(int32_t *pOutPath, int32_t *pOutNumWaypoints, CSimpleIntegerValueGenome *pGenome)
{
	int32_t counter = 0;

	int32_t *pGeneArray = pGenome->pGeneArray;

	int32_t numOfGenesMinus1 = pGenome->NumOfGenes - 1;

	int32_t id1, id2;

	for (int32_t i = 0; i < numOfGenesMinus1; i++)
	{
		id1 = pGeneArray[i];
		id2 = pGeneArray[i + 1];

		if (id1 != id2)
		{
			pOutPath[counter] = id1;
			counter++;
		}
	}

	pOutPath[counter] = pGeneArray[numOfGenesMinus1];
	counter++;

	*pOutNumWaypoints = counter;
}

static void Get_Best_Path(int32_t *pOutPath, int32_t *pOutNumWaypoints, CGeneralPopulation *pPopulation)
{
	CSimpleIntegerValueGenome *pBestGenome = static_cast<CSimpleIntegerValueGenome*>(pPopulation->ppGenomeArray[pPopulation->IDArrayOfBestFittedGenomes[0]]);
	int32_t numOfGenes = pBestGenome->NumOfGenes;
	int32_t numOfGenesMinus1 = numOfGenes - 1;

	int32_t counter = 0;

	int32_t *pGeneArray = pBestGenome->pGeneArray;

	int32_t id1, id2;

	for (int32_t i = 0; i < numOfGenesMinus1; i++)
	{
		id1 = pGeneArray[i];
		id2 = pGeneArray[i + 1];

		if (id1 != id2)
		{
			pOutPath[counter] = id1;
			counter++;
		}
	}

	pOutPath[counter] = pGeneArray[numOfGenesMinus1];
	counter++;

	*pOutNumWaypoints = counter;
}


static void Get_Path(int32_t *pOutPath, CSimpleIntegerValueGenome *pGenome)
{
	int32_t numOfGenes = pGenome->NumOfGenes;

	for (int32_t i = 0; i < numOfGenes; i++)
		pOutPath[i] = pGenome->pGeneArray[i];
}

static void Get_Shortest_TSP_Path(int32_t *pOutPath, CGeneralPopulation *pPopulation)
{
	CSimpleIntegerValueGenome *pBestGenome = static_cast<CSimpleIntegerValueGenome*>(pPopulation->ppGenomeArray[pPopulation->IDArrayOfBestFittedGenomes[0]]);
	int32_t numOfGenes = pBestGenome->NumOfGenes;

	for (int32_t i = 0; i < numOfGenes; i++)
		pOutPath[i] = pBestGenome->pGeneArray[i];
}





/*
int main(void)
{
	CRandomNumbersWithoutRepetition RandomDestinationNumbers;
	RandomDestinationNumbers.Init_Numbers(NumCities_TSP - 1);

	CRandomNumbersNN  RandomNumbers;

	// Visualisierung der einzelnen St�dte:

	static char SurfaceMap[NumSurfaceMapElements];

	Init_SurfaceMap(SurfaceMap, '*');

	Set_SurfaceMapData(SurfaceMap, 2, 0, '0');
	Set_SurfaceMapData(SurfaceMap, 4, 0, '1');
	Set_SurfaceMapData(SurfaceMap, 0, 1, '2');
	Set_SurfaceMapData(SurfaceMap, 4, 2, '3');
	Set_SurfaceMapData(SurfaceMap, 0, 4, '4');
	Set_SurfaceMapData(SurfaceMap, 2, 3, '5');
	Set_SurfaceMapData(SurfaceMap, 3, 4, '6');
	Set_SurfaceMapData(SurfaceMap, 5, 5, '7');
	Set_SurfaceMapData(SurfaceMap, 6, 3, '8');
	Set_SurfaceMapData(SurfaceMap, 1, 6, '9');
	Set_SurfaceMapData(SurfaceMap, 6, 1, 'A');
	Set_SurfaceMapData(SurfaceMap, 3, 6, 'B');


	Output_SurfaceMapData(SurfaceMap);

	// Visualisierung der einzelnen St�dte abgeschlossen

	static CGraphNode GraphNodeArray[NumCities_TSP_Plus1];

	GraphNodeArray[0].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[0].Set_Position(2.0f, 0.0f, 0.0f);
	GraphNodeArray[1].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[1].Set_Position(4.0f, 0.0f, 0.0f);
	GraphNodeArray[2].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[2].Set_Position(0.0f, 1.0f, 0.0f);
	GraphNodeArray[3].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[3].Set_Position(4.0f, 2.0f, 0.0f);
	GraphNodeArray[4].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[4].Set_Position(0.0f, 4.0f, 0.0f);
	GraphNodeArray[5].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[5].Set_Position(2.0f, 3.0f, 0.0f);
	GraphNodeArray[6].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[6].Set_Position(3.0f, 4.0f, 0.0f);
	GraphNodeArray[7].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[7].Set_Position(5.0f, 5.0f, 0.0f);
	GraphNodeArray[8].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[8].Set_Position(6.0f, 3.0f, 0.0f);
	GraphNodeArray[9].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[9].Set_Position(1.0f, 6.0f, 0.0f);
	GraphNodeArray[10].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[10].Set_Position(6.0f, 1.0f, 0.0f);
	GraphNodeArray[11].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[11].Set_Position(3.0f, 6.0f, 0.0f);
	GraphNodeArray[12].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[12].Set_Position(2.0f, 0.0f, 0.0f);

	static int32_t InterimTravelDestinationList[NumCities_TSP - 1];

	static int32_t Path[NumCities_TSP_Plus1];
	// Anfang der Rundreise:
	Path[0] = 0;
	// Ziel der Rundreise:
	Path[NumCities_TSP] = 0;

	RandomDestinationNumbers.Reset_Numbers();

	int32_t lastDestinationID = 0;
	int32_t newDestinationID = 0;

	for (int32_t i = 1; i < NumCities_TSP; i++)
	{
		int32_t num = RandomDestinationNumbers.Get_ListOfPossibleNumbers(InterimTravelDestinationList);

		float minDistSq = 10000000.0f;

		int32_t belongingDestinationID = 0;

		for (int32_t j = 0; j < num; j++)
		{
			int32_t possibleNewDestinationID = InterimTravelDestinationList[j];

			float distSq = GraphNodeArray[lastDestinationID].Get_DistanceSq_to_Other_Node(possibleNewDestinationID);

			if (distSq < minDistSq)
			{
				minDistSq = distSq;
				belongingDestinationID = possibleNewDestinationID;
			}
		}

		newDestinationID = belongingDestinationID;
		RandomDestinationNumbers.Select_Number(newDestinationID);
		Path[i] = newDestinationID;

		lastDestinationID = newDestinationID;
	}

	float pathDistSq = GraphNodeArray[0].Calculate_PathDistSq(Path, NumCities_TSP_Plus1);
	cout << "pathDistSq: " << pathDistSq << endl;

	for (int32_t i = 0; i < NumCities_TSP_Plus1; i++)
	{
		cout << Path[i] << " ";
	}

	cout << endl << endl;

	cout << "bye bye (Press Return)" << endl;
	getchar();

	return 0;
}
*/




/*
int main(void)
{
	CRandomNumbersWithoutRepetition RandomDestinationNumbers;
	RandomDestinationNumbers.Init_Numbers(NumCities_TSP - 1);

	CRandomNumbersNN  RandomNumbers;

	// Visualisierung der einzelnen St�dte:

	static char SurfaceMap[NumSurfaceMapElements];

	Init_SurfaceMap(SurfaceMap, '*');

	Set_SurfaceMapData(SurfaceMap, 2, 0, '0');
	Set_SurfaceMapData(SurfaceMap, 4, 0, '1');
	Set_SurfaceMapData(SurfaceMap, 0, 1, '2');
	Set_SurfaceMapData(SurfaceMap, 4, 2, '3');
	Set_SurfaceMapData(SurfaceMap, 0, 4, '4');
	Set_SurfaceMapData(SurfaceMap, 2, 3, '5');
	Set_SurfaceMapData(SurfaceMap, 3, 4, '6');
	Set_SurfaceMapData(SurfaceMap, 5, 5, '7');
	Set_SurfaceMapData(SurfaceMap, 6, 3, '8');
	Set_SurfaceMapData(SurfaceMap, 1, 6, '9');
	Set_SurfaceMapData(SurfaceMap, 6, 1, 'A');
	Set_SurfaceMapData(SurfaceMap, 3, 6, 'B');


	Output_SurfaceMapData(SurfaceMap);

	// Visualisierung der einzelnen St�dte abgeschlossen

	static CGraphNode GraphNodeArray[NumCities_TSP_Plus1];

	GraphNodeArray[0].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[0].Set_Position(2.0f, 0.0f, 0.0f);
	GraphNodeArray[1].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[1].Set_Position(4.0f, 0.0f, 0.0f);
	GraphNodeArray[2].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[2].Set_Position(0.0f, 1.0f, 0.0f);
	GraphNodeArray[3].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[3].Set_Position(4.0f, 2.0f, 0.0f);
	GraphNodeArray[4].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[4].Set_Position(0.0f, 4.0f, 0.0f);
	GraphNodeArray[5].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[5].Set_Position(2.0f, 3.0f, 0.0f);
	GraphNodeArray[6].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[6].Set_Position(3.0f, 4.0f, 0.0f);
	GraphNodeArray[7].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[7].Set_Position(5.0f, 5.0f, 0.0f);
	GraphNodeArray[8].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[8].Set_Position(6.0f, 3.0f, 0.0f);
	GraphNodeArray[9].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[9].Set_Position(1.0f, 6.0f, 0.0f);
	GraphNodeArray[10].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[10].Set_Position(6.0f, 1.0f, 0.0f);
	GraphNodeArray[11].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[11].Set_Position(3.0f, 6.0f, 0.0f);
	GraphNodeArray[12].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[12].Set_Position(2.0f, 0.0f, 0.0f);

	static int32_t InterimTravelDestinationList[NumCities_TSP - 1];

	static int32_t Path[NumCities_TSP_Plus1];
	// Anfang der Rundreise:
	Path[0] = 0;
	// Ziel der Rundreise:
	Path[NumCities_TSP] = 0;

	int32_t NumOfPathSegments = NumCities_TSP * NumCities_TSP;

	static CGeneFitness GeneFitnessArray[NumCities_TSP * NumCities_TSP];

	//int32_t NumOfIterationSteps = 1000;
	//int32_t NumOfIterationSteps = 10000;
	int32_t NumOfIterationSteps = 25000;
	float ExplorationRate = 0.75f;
	//float ExplorationRate = 1.0f;

	for (int32_t iteration = 0; iteration < NumOfIterationSteps; iteration++)
	{
		//if (iteration > 100)
		//{
			//ExplorationRate = 0.75f;
		//}

		RandomDestinationNumbers.Reset_Numbers();

		int32_t lastDestinationID = 0;
		int32_t newDestinationID = 0;

		for (int32_t i = 1; i < NumCities_TSP; i++)
		{
			if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) < ExplorationRate)
			{
				newDestinationID = RandomDestinationNumbers.Get_Number();
				Path[i] = newDestinationID;
			}
			else
			{
				int32_t num = RandomDestinationNumbers.Get_ListOfPossibleNumbers(InterimTravelDestinationList);

				float maxFitness = 0.0f;
				int32_t belongingDestinationID = 0;

				for (int32_t j = 0; j < num; j++)
				{
					int32_t possibleNewDestinationID = InterimTravelDestinationList[j];

					int32_t newID = lastDestinationID + possibleNewDestinationID * NumCities_TSP;

					float savedFitness = GeneFitnessArray[newID].Fitness;


					if (savedFitness >= maxFitness)
					{
						maxFitness = savedFitness;
						belongingDestinationID = possibleNewDestinationID;
					}
				}

				newDestinationID = belongingDestinationID;
				RandomDestinationNumbers.Select_Number(newDestinationID);
				Path[i] = newDestinationID;
			}

			lastDestinationID = newDestinationID;

		} // end of for (int32_t i = 1; i < NumCities_TSP; i++) 

		float pathDistSq = GraphNodeArray[0].Calculate_PathDistSq(Path, NumCities_TSP_Plus1);
		float fitness = 1.0f / pathDistSq;

		//cout << "pathDistSq: " << pathDistSq << endl;
		//cout << "fitness: " << fitness << endl;

		// fitness update: 
		for (int32_t i = 1; i < NumCities_TSP_Plus1; i++)
		{
			int32_t id1 = Path[i - 1];
			int32_t id2 = Path[i];

			int32_t idA = id1 + NumCities_TSP * id2;
			int32_t idB = id2 + NumCities_TSP * id1;

			//GeneFitnessArray[idA].Update_Fitness(fitness);
			//GeneFitnessArray[idB].Update_Fitness(fitness);

			GeneFitnessArray[idA].Replace_With_HigherFitness_If_Possible(fitness);
			GeneFitnessArray[idB].Replace_With_HigherFitness_If_Possible(fitness);

		} // end of fitness update: 

	} // end of for (int32_t iteration = 0; iteration < NumOfIterationSteps; iteration++) 


	cout << endl << endl;

	RandomDestinationNumbers.Reset_Numbers();

	int32_t lastDestinationID = 0;
	int32_t newDestinationID = 0;

	for (int32_t i = 1; i < NumCities_TSP; i++)
	{
		int32_t num = RandomDestinationNumbers.Get_ListOfPossibleNumbers(InterimTravelDestinationList);

		float maxFitness = 0.0f;
		int32_t belongingDestinationID = 0;

		for (int32_t j = 0; j < num; j++)
		{
			int32_t possibleNewDestinationID = InterimTravelDestinationList[j];

			int32_t newID = lastDestinationID + possibleNewDestinationID * NumCities_TSP;

			float savedFitness = GeneFitnessArray[newID].Fitness;

			if (savedFitness >= maxFitness)
			{
				maxFitness = savedFitness;
				belongingDestinationID = possibleNewDestinationID;
			}
		}

		newDestinationID = belongingDestinationID;
		RandomDestinationNumbers.Select_Number(newDestinationID);
		Path[i] = newDestinationID;

		lastDestinationID = newDestinationID;

	} // end of for (int32_t i = 1; i < NumCities_TSP; i++)

	float pathDistSq = GraphNodeArray[0].Calculate_PathDistSq(Path, NumCities_TSP_Plus1);
	float Fitness = 1.0f / pathDistSq;

	cout << "pathDistSq: " << pathDistSq << endl;
	cout << "Fitness: " << Fitness << endl;

	for (int32_t i = 0; i < NumCities_TSP_Plus1; i++)
	{
		cout << Path[i] << " ";
	}

	cout << endl << endl;

	cout << "bye bye (Press Return)" << endl;
	getchar();

	return 0;
}
*/



/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	int32_t TrainingPopulationSize = 100;
	int32_t NumTrainingGenerationsMax = 20000;

	// Visualisierung der einzelnen St�dte:

	static char SurfaceMap[NumSurfaceMapElements];

	Init_SurfaceMap(SurfaceMap, '*');

	Set_SurfaceMapData(SurfaceMap, 2, 0, '0');
	Set_SurfaceMapData(SurfaceMap, 4, 0, '1');
	Set_SurfaceMapData(SurfaceMap, 0, 1, '2');
	Set_SurfaceMapData(SurfaceMap, 4, 2, '3');
	Set_SurfaceMapData(SurfaceMap, 0, 4, '4');
	Set_SurfaceMapData(SurfaceMap, 2, 3, '5');
	Set_SurfaceMapData(SurfaceMap, 3, 4, '6');
	Set_SurfaceMapData(SurfaceMap, 5, 5, '7');
	Set_SurfaceMapData(SurfaceMap, 6, 3, '8');
	Set_SurfaceMapData(SurfaceMap, 1, 6, '9');
	Set_SurfaceMapData(SurfaceMap, 6, 1, 'A');
	Set_SurfaceMapData(SurfaceMap, 3, 6, 'B');


	Output_SurfaceMapData(SurfaceMap);

	// Visualisierung der einzelnen St�dte abgeschlossen

	static CGraphNode GraphNodeArray[NumCities_TSP_Plus1];

	GraphNodeArray[0].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[0].Set_Position(2.0f, 0.0f, 0.0f);
	GraphNodeArray[1].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[1].Set_Position(4.0f, 0.0f, 0.0f);
	GraphNodeArray[2].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[2].Set_Position(0.0f, 1.0f, 0.0f);
	GraphNodeArray[3].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[3].Set_Position(4.0f, 2.0f, 0.0f);
	GraphNodeArray[4].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[4].Set_Position(0.0f, 4.0f, 0.0f);
	GraphNodeArray[5].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[5].Set_Position(2.0f, 3.0f, 0.0f);
	GraphNodeArray[6].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[6].Set_Position(3.0f, 4.0f, 0.0f);
	GraphNodeArray[7].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[7].Set_Position(5.0f, 5.0f, 0.0f);
	GraphNodeArray[8].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[8].Set_Position(6.0f, 3.0f, 0.0f);
	GraphNodeArray[9].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[9].Set_Position(1.0f, 6.0f, 0.0f);
	GraphNodeArray[10].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[10].Set_Position(6.0f, 1.0f, 0.0f);
	GraphNodeArray[11].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[11].Set_Position(3.0f, 6.0f, 0.0f);
	GraphNodeArray[12].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[12].Set_Position(2.0f, 0.0f, 0.0f);

	CSimpleIntegerValueGenome *pGenomeArray = new (std::nothrow) CSimpleIntegerValueGenome[TrainingPopulationSize];

	CGeneralPopulation Population;
	Population.Set_GenomeValueCloningFunction(CSimpleIntegerValueGenome_CloningFunction);



	Population.Initialize(TrainingPopulationSize);

	for (int32_t i = 0; i < TrainingPopulationSize; i++)
	{
		pGenomeArray[i].Initialize(NumCities_TSP_Plus1);
		Population.Set_Genome(&pGenomeArray[i], i);
	}

	Population.Reset_Population();

	static int32_t InitialPath[NumCities_TSP_Plus1];

	for (int32_t i = 0; i < NumCities_TSP; i++)
		InitialPath[i] = i;

	// Ziel der Rundreise:
	InitialPath[NumCities_TSP] = 0;

	for (int32_t i = 0; i < NumCities_TSP_Plus1; i++)
	{
		cout << InitialPath[i] << " ";
	}

	cout << endl;

	for (int32_t i = 0; i < TrainingPopulationSize; i++)
	{
		pGenomeArray[i].Set_GeneData(InitialPath);
		pGenomeArray[i].Permute_GeneData(&RandomNumbers, 1, NumCities_TSP_Plus1 - 2, 3);
	}

	CPermutationInfo PermutationInfo;
	PermutationInfo.minGeneID = 1;
	//PermutationInfo.maxGeneID = NumCities_TSP_Plus1 - 2;
	PermutationInfo.maxGeneID = NumCities_TSP - 1;
	PermutationInfo.permutationSteps = 1;

	CPermutationInfoExt PermutationInfoExt;
	PermutationInfoExt.minGeneID = 1;
	//PermutationInfoExt.maxGeneID = NumCities_TSP_Plus1 - 2;
	PermutationInfoExt.maxGeneID = NumCities_TSP - 1;
	PermutationInfoExt.permutationSteps = 1;
	PermutationInfoExt.pGraphNodeArray = GraphNodeArray;

	//for (int32_t i = 0; i < NumTrainingGenerationsMax; i++)
	for (int32_t i = 0; i < 100; i++)
	{
		Update_Fitnessvalues(GraphNodeArray, &Population);

		Population.Update_Population();

		//Population.Update_BaseEvolution2(TSP_PermutationFunction, &PermutationInfo);
		//Population.Update_Evolution_BestGenomeOnly2(TSP_PermutationFunction, &PermutationInfo);
		//Population.Update_Evolution_SecondBestGenomeOnly2(TSP_PermutationFunction, &PermutationInfo);

		Population.Update_BaseEvolution2(TSP_PermutationFunctionExt, &PermutationInfoExt);
		Population.Update_Evolution_BestGenomeOnly2(TSP_PermutationFunctionExt, &PermutationInfoExt);
		Population.Update_Evolution_SecondBestGenomeOnly2(TSP_PermutationFunctionExt, &PermutationInfoExt);

		Population.Update_Evolution_Combine_BestTwoGenomes(TSP_RecombinationFunction, nullptr);
		Population.Update_Evolution_Combine_TwoGenomes(TSP_RecombinationFunction, nullptr);
		Population.Update_Evolution_Combine_TwoOfTheBestGenomes(TSP_RecombinationFunction, nullptr);
	}

	static int32_t ShortestPath[NumCities_TSP_Plus1];

	Get_Shortest_TSP_Path(ShortestPath, &Population);

	float minPathDistSq = GraphNodeArray[0].Calculate_PathDistSq(ShortestPath, NumCities_TSP_Plus1);

	cout << endl << "minPathDistSq: " << minPathDistSq << endl;

	static int32_t RearrangedPath[NumCities_TSP_Plus1];

	Rearrange_TSP_Path(RearrangedPath, ShortestPath, NumCities_TSP_Plus1, 3);

	for (int32_t i = 0; i < NumCities_TSP_Plus1; i++)
	{
		cout << ShortestPath[i] << " ";
	}

	cout << endl;

	for (int32_t i = 0; i < NumCities_TSP_Plus1; i++)
	{
		cout << RearrangedPath[i] << " ";
	}

	cout << endl;


	delete[] pGenomeArray;
	pGenomeArray = nullptr;

	cout << "bye bye (Press Return)" << endl;
	getchar();


	return 0;
}
*/



/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	int32_t TrainingPopulationSize = 100;
	int32_t NumTrainingGenerationsMax = 5000;

	// Visualisierung der einzelnen St�dte:

	static char SurfaceMap[NumSurfaceMapElements];

	Init_SurfaceMap(SurfaceMap, '*');

	Set_SurfaceMapData(SurfaceMap, 2, 0, '0');
	Set_SurfaceMapData(SurfaceMap, 4, 0, '1');
	Set_SurfaceMapData(SurfaceMap, 0, 1, '2');
	Set_SurfaceMapData(SurfaceMap, 4, 2, '3');
	Set_SurfaceMapData(SurfaceMap, 0, 4, '4');
	Set_SurfaceMapData(SurfaceMap, 2, 3, '5');
	Set_SurfaceMapData(SurfaceMap, 3, 4, '6');
	Set_SurfaceMapData(SurfaceMap, 5, 5, '7');
	Set_SurfaceMapData(SurfaceMap, 6, 3, '8');
	Set_SurfaceMapData(SurfaceMap, 1, 6, '9');
	Set_SurfaceMapData(SurfaceMap, 6, 1, 'A');
	Set_SurfaceMapData(SurfaceMap, 3, 6, 'B');


	Output_SurfaceMapData(SurfaceMap);

	// Visualisierung der einzelnen St�dte abgeschlossen

	static CGraphNode GraphNodeArray[NumWaypoints];

	GraphNodeArray[0].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[0].Set_Position(2.0f, 0.0f, 0.0f);
	GraphNodeArray[1].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[1].Set_Position(4.0f, 0.0f, 0.0f);
	GraphNodeArray[2].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[2].Set_Position(0.0f, 1.0f, 0.0f);
	GraphNodeArray[3].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[3].Set_Position(4.0f, 2.0f, 0.0f);
	GraphNodeArray[4].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[4].Set_Position(0.0f, 4.0f, 0.0f);
	GraphNodeArray[5].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[5].Set_Position(2.0f, 3.0f, 0.0f);
	GraphNodeArray[6].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[6].Set_Position(3.0f, 4.0f, 0.0f);
	GraphNodeArray[7].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[7].Set_Position(5.0f, 5.0f, 0.0f);
	GraphNodeArray[8].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[8].Set_Position(6.0f, 3.0f, 0.0f);
	GraphNodeArray[9].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[9].Set_Position(1.0f, 6.0f, 0.0f);
	GraphNodeArray[10].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[10].Set_Position(6.0f, 1.0f, 0.0f);
	GraphNodeArray[11].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[11].Set_Position(3.0f, 6.0f, 0.0f);

	int32_t StartID = 1;
	int32_t DestinationID = 11;



	CWeightMatrix WeightMatrix;
	WeightMatrix.Init_Matrix(NumWaypoints, NumWaypoints, 1.0f);

	WeightMatrix.Set_Weight(StartID, DestinationID, 1000.0f);
	WeightMatrix.Set_Weight(DestinationID, StartID, 1000.0f);

	WeightMatrix.Set_Weight(0, 5, 1000.0f);
	WeightMatrix.Set_Weight(5, 0, 1000.0f);

	WeightMatrix.Set_Weight(0, 1, 1000.0f);
	WeightMatrix.Set_Weight(1, 0, 1000.0f);


	CSimpleIntegerValueGenome *pGenomeArray = new (std::nothrow) CSimpleIntegerValueGenome[TrainingPopulationSize];

	CGeneralPopulation Population;
	Population.Set_GenomeValueCloningFunction(CSimpleIntegerValueGenome_CloningFunction);

	Population.Initialize(TrainingPopulationSize);

	for (int32_t i = 0; i < TrainingPopulationSize; i++)
	{
		pGenomeArray[i].Initialize(NumWaypointsMaxPerPath);
		Population.Set_Genome(&pGenomeArray[i], i);
	}

	Population.Reset_Population();

	static int32_t InitialPath[NumWaypointsMaxPerPath];

	for (int32_t i = 0; i < NumWaypointsMaxPerPath; i++)
	{
		InitialPath[i] = StartID;
	}

	InitialPath[NumWaypointsMaxPerPath - 1] = DestinationID;


	for (int32_t i = 0; i < NumWaypointsMaxPerPath; i++)
	{
		cout << InitialPath[i] << " ";
	}

	cout << endl;

	for (int32_t i = 0; i < TrainingPopulationSize; i++)
	{
		pGenomeArray[i].Set_GeneData(InitialPath);
		Pathfinding_MutationFunction(&pGenomeArray[i], &RandomNumbers, nullptr);
	}

	for (int32_t i = 0; i < NumTrainingGenerationsMax; i++)
	{
		Update_FitnessvaluesExt(GraphNodeArray, &WeightMatrix, &Population);

		Population.Update_Population();

		Population.Update_BaseEvolution(Pathfinding_MutationFunction, nullptr);
		Population.Update_Evolution_BestGenomeOnly(Pathfinding_MutationFunction, nullptr);
		Population.Update_Evolution_SecondBestGenomeOnly(Pathfinding_MutationFunction, nullptr);
		Population.Update_Evolution_Combine_BestTwoGenomes(Pathfinding_RecombinationFunction, nullptr);
		Population.Update_Evolution_Combine_TwoGenomes(Pathfinding_RecombinationFunction, nullptr);
	}

	static int32_t BestPath[NumWaypointsMaxPerPath];
	int32_t NumWaypoints;

	Get_Best_Path(BestPath, &NumWaypoints, &Population);

	float minPathDistSq = GraphNodeArray[0].Calculate_PathDistSq(BestPath, NumWaypoints);

	cout << endl << "minPathDistSq: " << minPathDistSq << endl;

	for (int32_t i = 0; i < NumWaypoints; i++)
	{
		cout << BestPath[i] << " ";
	}

	cout << endl;



	delete[] pGenomeArray;
	pGenomeArray = nullptr;

	cout << "bye bye (Press Return)" << endl;
	getchar();

	return 0;
}
*/




/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	static constexpr int32_t NumInputOrOutputValues = 4;

	float CorrectOutputData[NumInputOrOutputValues];

	//CorrectOutputData[0] = -1.0f;
	//CorrectOutputData[1] = 0.5f;
	//CorrectOutputData[2] = 0.5f;
	//CorrectOutputData[3] = 0.0f;

	CorrectOutputData[0] = 0.0f;
	CorrectOutputData[1] = 1.0f;
	CorrectOutputData[2] = 1.0f;
	CorrectOutputData[3] = 0.0f;

	float Input1[2] = { 0.0f, 0.0f };
	float Input2[2] = { 1.0f, 0.0f };
	float Input3[2] = { 0.0f, 1.0f };
	float Input4[2] = { 1.0f, 1.0f };

	float* pInputData[NumInputOrOutputValues];

	pInputData[0] = Input1;
	pInputData[1] = Input2;
	pInputData[2] = Input3;
	pInputData[3] = Input4;


	CSimpleMutationInfo PlasticityMutationInfo;
	PlasticityMutationInfo.mutationRate = 0.5f;
	PlasticityMutationInfo.minValue = -0.01f;
	PlasticityMutationInfo.maxValue = 0.01f;

	CSimpleReinitializationInfo PlasticityReinitializationInfo;
	PlasticityReinitializationInfo.minValue = -2.0f;
	PlasticityReinitializationInfo.maxValue = 2.0f;

	CTopologyMutationInfo GrowthTopologyMutationInfo;
	GrowthTopologyMutationInfo.populationTopologyMutationRate = 0.01f;
	GrowthTopologyMutationInfo.genomeTopologyMutationRate = 0.1f;
	GrowthTopologyMutationInfo.minGeneReinitializationValue = -2.0f;
	GrowthTopologyMutationInfo.maxGeneReinitializationValue = 2.0f;

	CTopologyMutationInfo SimplificationTopologyMutationInfo;
	SimplificationTopologyMutationInfo.populationTopologyMutationRate = 0.0025f;
	SimplificationTopologyMutationInfo.genomeTopologyMutationRate = 0.1f;
	SimplificationTopologyMutationInfo.minGeneReinitializationValue = -2.0f;
	SimplificationTopologyMutationInfo.maxGeneReinitializationValue = 2.0f;

	

	int32_t GlobalSimulationTime = 0;

	//int32_t NumOfCalculationNodesMax = 10;
	int32_t NumOfCalculationNodesMax = 15;
	int32_t NumOfInputNodes = 2;
	int32_t NumOfOutputNodes = 1;
	

	static constexpr int32_t  ConstTrainingPopulationSize = 100;
	int32_t NumTrainingGenerationsMax = 20000;


	static CSimpleNeuralCalculationNet CalculationNetArray[ConstTrainingPopulationSize];

	CSimpleNeuralCalculationNet BestCalculationNet;
	BestCalculationNet.Initialize(1, NumOfCalculationNodesMax, NumOfInputNodes, NumOfOutputNodes);
	BestCalculationNet.Get_Access_To_iGlobalSimulationTime(&GlobalSimulationTime);
	BestCalculationNet.Set_MinTimePeriodBetweenTwoTopologyEvolutionSteps(200);
	BestCalculationNet.Set_ActivationFunction_HiddenNodes(TanHActivationID);
	BestCalculationNet.Set_ActivationFunction_OutputNodes(TanHActivationID);

	


	CGeneralPopulation Population;
	Population.Set_GenomeValueCloningFunction(CSimpleNeuralCalculationNet_CloningFunction);


	Population.Initialize(ConstTrainingPopulationSize);


	for (int32_t i = 0; i < ConstTrainingPopulationSize; i++)
	{
		CalculationNetArray[i].Initialize(i, NumOfCalculationNodesMax, NumOfInputNodes, NumOfOutputNodes);
		
		CalculationNetArray[i].Set_ActivationFunction_HiddenNodes(TanHActivationID);
		CalculationNetArray[i].Set_ActivationFunction_OutputNodes(TanHActivationID);
		

		CalculationNetArray[i].Get_Access_To_iGlobalSimulationTime(&GlobalSimulationTime);
		CalculationNetArray[i].Set_MinTimePeriodBetweenTwoTopologyEvolutionSteps(200);

		Population.Set_Genome(&CalculationNetArray[i], i);
	}


	for (int32_t individual = 0; individual < ConstTrainingPopulationSize; individual++)
	{
		ForwardBaseNetReinitialization_CSimpleNeuralCalculationNet(&CalculationNetArray[individual], &RandomNumbers, &PlasticityReinitializationInfo);
	}

	
	Population.Reset_Population();

	for (int32_t generation = 0; generation < NumTrainingGenerationsMax; generation++)
	{
		Population.Reset_MinErrorSum_ActualGeneration();

		for (int32_t individual = 0; individual < ConstTrainingPopulationSize; individual++)
		{
			CSimpleNeuralCalculationNet* pCalculationNet = &CalculationNetArray[individual];
	
			float SumOfErrors = 0.000001f;

			for (int32_t i = 0; i < NumInputOrOutputValues; i++)
			{
				pCalculationNet->Set_Input(pInputData[i], 2);
				pCalculationNet->Execute_Calculations();
				
				float outputValue;
				
				pCalculationNet->Get_Output(&outputValue, 1);
							
				float diff = outputValue - CorrectOutputData[i];
				SumOfErrors += diff * diff;
			}

			Population.Calculate_FitnessScore_FromError(individual, SumOfErrors);
			//Population.Set_FitnessScore(individual, 1.0f / SumOfErrors);
			Population.Update_MinErrorSum_ActualGeneration(SumOfErrors);
		}

		Population.Update_Population();

		if (generation % 500 == 0)
		{
			cout << "minErrorSum: " << Population.MinErrorSum_ActualGeneration << endl;
		}

		if (Population.MinErrorSum_ActualGeneration < 0.005f)
		//if (Population.MinErrorSum_ActualGeneration < 0.01f)
		{
			cout << endl;
			cout << "minErrorSum: " << Population.MinErrorSum_ActualGeneration << endl;
			cout << "actual generation: " << generation << endl;
			cout << "training completed" << endl << endl;
			break;
		}

		
			

		Population.Update_BaseEvolution(ForwardTopologyGrowthMutation_CSimpleNeuralCalculationNet, &GrowthTopologyMutationInfo);
		Population.Update_BaseEvolution(ForwardTopologySimplificationMutation_CSimpleNeuralCalculationNet, &SimplificationTopologyMutationInfo);
		Population.Update_BaseEvolution(PlasticityMutation_CSimpleNeuralCalculationNet, &PlasticityMutationInfo);

		Population.Update_Evolution_BestGenomeOnly(ForwardTopologySimplificationMutation_CSimpleNeuralCalculationNet, &SimplificationTopologyMutationInfo);
		Population.Update_Evolution_BestGenomeOnly(PlasticityMutation_CSimpleNeuralCalculationNet, &PlasticityMutationInfo);

		Population.Update_Evolution_SecondBestGenomeOnly(ForwardTopologySimplificationMutation_CSimpleNeuralCalculationNet, &SimplificationTopologyMutationInfo);
		Population.Update_Evolution_SecondBestGenomeOnly(PlasticityMutation_CSimpleNeuralCalculationNet, &PlasticityMutationInfo);

		Population.Update_Evolution_Combine_BestTwoGenomes(Recombination_CSimpleNeuralCalculationNet, nullptr);
		Population.Update_Evolution_Combine_TwoGenomes(Recombination_CSimpleNeuralCalculationNet, nullptr);

		GlobalSimulationTime++;
	}


	Population.Get_Best_Evolved_Genome(&BestCalculationNet);
	
	cout << endl << "show evolved neural net topology (Press Return): ";

	getchar();

	BestCalculationNet.Output_TopologyData();
	
	//cout << endl << "show evolved neural net test output (Press Return): ";
	cout << endl << "show cleaned up evolved neural net topology (Press Return): ";

	getchar();

	BestCalculationNet.CleanUp_Topology_After_EvolutionIsCompleted();
	BestCalculationNet.Output_TopologyData();
	
	cout << endl << "show evolved neural net test output (Press Return): ";

	getchar();

	cout << endl;

	

	for (int32_t i = 0; i < NumInputOrOutputValues; i++)
	{
		BestCalculationNet.Set_Input(pInputData[i], 2);
		BestCalculationNet.Execute_Calculations();

		float outputValue;

		BestCalculationNet.Get_Output(&outputValue, 1);

		cout << "output: " << outputValue << " correct output: " << CorrectOutputData[i] << endl;
	}

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	static constexpr int32_t NumInputOrOutputValues = 4;

	float CorrectOutputData[NumInputOrOutputValues];

	//float CorrectOutput1[2] = { 0.0f, 0.0f };
	//float CorrectOutput2[2] = { 1.0f, 0.0f };
	//float CorrectOutput3[2] = { 0.0f, 1.0f };
	//float CorrectOutput4[2] = { 1.0f, 1.0f };

	float CorrectOutput1[2] = { -0.5f, -0.5f };
	float CorrectOutput2[2] = { 0.5f, -0.5f };
	float CorrectOutput3[2] = { -0.5f, 0.5f };
	float CorrectOutput4[2] = { 0.5f, 0.5f };

	float* pCorrectOutputData[NumInputOrOutputValues];

	pCorrectOutputData[0] = CorrectOutput1;
	pCorrectOutputData[1] = CorrectOutput2;
	pCorrectOutputData[2] = CorrectOutput3;
	pCorrectOutputData[3] = CorrectOutput4;


	float Input1[2] = { 0.0f, 0.0f };
	float Input2[2] = { 1.0f, 0.0f };
	float Input3[2] = { 0.0f, 1.0f };
	float Input4[2] = { 1.0f, 1.0f };

	float* pInputData[NumInputOrOutputValues];

	pInputData[0] = Input1;
	pInputData[1] = Input2;
	pInputData[2] = Input3;
	pInputData[3] = Input4;


	CSimpleMutationInfo PlasticityMutationInfo;
	PlasticityMutationInfo.mutationRate = 0.5f;
	PlasticityMutationInfo.minValue = -0.01f;
	PlasticityMutationInfo.maxValue = 0.01f;

	CSimpleReinitializationInfo PlasticityReinitializationInfo;
	PlasticityReinitializationInfo.minValue = -2.0f;
	PlasticityReinitializationInfo.maxValue = 2.0f;

	CTopologyMutationInfo GrowthTopologyMutationInfo;
	GrowthTopologyMutationInfo.populationTopologyMutationRate = 0.09f;
	GrowthTopologyMutationInfo.genomeTopologyMutationRate = 0.1f;
	GrowthTopologyMutationInfo.minGeneReinitializationValue = -2.0f;
	GrowthTopologyMutationInfo.maxGeneReinitializationValue = 2.0f;

	CTopologyMutationInfo SimplificationTopologyMutationInfo;
	SimplificationTopologyMutationInfo.populationTopologyMutationRate = 0.01f;
	SimplificationTopologyMutationInfo.genomeTopologyMutationRate = 0.1f;
	SimplificationTopologyMutationInfo.minGeneReinitializationValue = -2.0f;
	SimplificationTopologyMutationInfo.maxGeneReinitializationValue = 2.0f;



	int32_t GlobalSimulationTime = 0;

	//int32_t NumOfCalculationNodesMax = 10;
	int32_t NumOfCalculationNodesMax = 15;
	int32_t NumOfInputNodes = 2;
	int32_t NumOfOutputNodes = 2;


	static constexpr int32_t  ConstTrainingPopulationSize = 100;
	int32_t NumTrainingGenerationsMax = 30000;


	static CSimpleNeuralCalculationNet CalculationNetArray[ConstTrainingPopulationSize];

	CSimpleNeuralCalculationNet BestCalculationNet;
	BestCalculationNet.Initialize(1, NumOfCalculationNodesMax, NumOfInputNodes, NumOfOutputNodes);
	BestCalculationNet.Get_Access_To_iGlobalSimulationTime(&GlobalSimulationTime);
	BestCalculationNet.Set_MinTimePeriodBetweenTwoTopologyEvolutionSteps(100);

	BestCalculationNet.Set_ActivationFunction_HiddenNodes(TanHActivationID);
	//BestCalculationNet.Set_ActivationFunction_OutputNodes(TanHActivationID);
	BestCalculationNet.Set_ActivationFunction_OutputNodes(LinearActivationID);
	


	CGeneralPopulation Population;
	Population.Set_GenomeValueCloningFunction(CSimpleNeuralCalculationNet_CloningFunction);


	Population.Initialize(ConstTrainingPopulationSize);


	for (int32_t i = 0; i < ConstTrainingPopulationSize; i++)
	{
		CalculationNetArray[i].Initialize(i, NumOfCalculationNodesMax, NumOfInputNodes, NumOfOutputNodes);

		CalculationNetArray[i].Set_ActivationFunction_HiddenNodes(TanHActivationID);
		//CalculationNetArray[i].Set_ActivationFunction_OutputNodes(TanHActivationID);
		CalculationNetArray[i].Set_ActivationFunction_OutputNodes(LinearActivationID);

		CalculationNetArray[i].Get_Access_To_iGlobalSimulationTime(&GlobalSimulationTime);
		CalculationNetArray[i].Set_MinTimePeriodBetweenTwoTopologyEvolutionSteps(100);

		Population.Set_Genome(&CalculationNetArray[i], i);
	}

	
	for (int32_t individual = 0; individual < ConstTrainingPopulationSize; individual++)
	{
		ForwardBaseNetReinitialization_CSimpleNeuralCalculationNet(&CalculationNetArray[individual], &RandomNumbers, &PlasticityReinitializationInfo);
	}

	Population.Reset_Population();

	for (int32_t generation = 0; generation < NumTrainingGenerationsMax; generation++)
	{
		Population.Reset_MinErrorSum_ActualGeneration();

		for (int32_t individual = 0; individual < ConstTrainingPopulationSize; individual++)
		{
			CSimpleNeuralCalculationNet* pCalculationNet = &CalculationNetArray[individual];

			float SumOfErrors = 0.000001f;

			for (int32_t i = 0; i < NumInputOrOutputValues; i++)
			{
				pCalculationNet->Set_Input(pInputData[i], 2);
				pCalculationNet->Execute_Calculations();

				float outputArray[2];

				pCalculationNet->Get_Output(outputArray, 2);

				float diff = outputArray[0] - pCorrectOutputData[i][0];
				SumOfErrors += diff * diff;
				diff = outputArray[1] - pCorrectOutputData[i][1];
				SumOfErrors += diff * diff;

			}

			Population.Calculate_FitnessScore_FromError(individual, SumOfErrors);
			//Population.Set_FitnessScore(individual, 1.0f / SumOfErrors);
			Population.Update_MinErrorSum_ActualGeneration(SumOfErrors);
		}

		Population.Update_Population();

		if (generation % 500 == 0)
		{
			cout << "minErrorSum: " << Population.MinErrorSum_ActualGeneration << endl;
		}

		if (Population.MinErrorSum_ActualGeneration < 0.0025f)
			//if (Population.MinErrorSum_ActualGeneration < 0.01f)
		{
			cout << endl;
			cout << "minErrorSum: " << Population.MinErrorSum_ActualGeneration << endl;
			cout << "actual generation: " << generation << endl;
			cout << "training completed" << endl << endl;
			break;
		}

		Population.Update_BaseEvolution(ForwardTopologyGrowthMutation_CSimpleNeuralCalculationNet, &GrowthTopologyMutationInfo);
		Population.Update_BaseEvolution(ForwardTopologySimplificationMutation_CSimpleNeuralCalculationNet, &SimplificationTopologyMutationInfo);
		Population.Update_BaseEvolution(PlasticityMutation_CSimpleNeuralCalculationNet, &PlasticityMutationInfo);

		Population.Update_Evolution_BestGenomeOnly(ForwardTopologySimplificationMutation_CSimpleNeuralCalculationNet, &SimplificationTopologyMutationInfo);
		Population.Update_Evolution_BestGenomeOnly(PlasticityMutation_CSimpleNeuralCalculationNet, &PlasticityMutationInfo);

		Population.Update_Evolution_SecondBestGenomeOnly(ForwardTopologySimplificationMutation_CSimpleNeuralCalculationNet, &SimplificationTopologyMutationInfo);
		Population.Update_Evolution_SecondBestGenomeOnly(PlasticityMutation_CSimpleNeuralCalculationNet, &PlasticityMutationInfo);

		Population.Update_Evolution_Combine_BestTwoGenomes(Recombination_CSimpleNeuralCalculationNet, nullptr);
		Population.Update_Evolution_Combine_TwoGenomes(Recombination_CSimpleNeuralCalculationNet, nullptr);

		GlobalSimulationTime++;
	}

	Population.Get_Best_Evolved_Genome(&BestCalculationNet);

	cout << endl << "show evolved neural net topology (Press Return): ";

	getchar();

	BestCalculationNet.Output_TopologyData();
	
	
	cout << endl << "show evolved neural net test output (Press Return): ";

	getchar();

	BestCalculationNet.CleanUp_Topology_After_EvolutionIsCompleted();
	BestCalculationNet.Output_TopologyData();
	
	cout << endl << "show evolved neural net test output (Press Return): ";

	getchar();

	cout << endl;

	for (int32_t i = 0; i < NumInputOrOutputValues; i++)
	{
		BestCalculationNet.Set_Input(pInputData[i], 2);
		BestCalculationNet.Execute_Calculations();

		float outputArray[2];

		BestCalculationNet.Get_Output(outputArray, 2);

		cout << "output1: " << outputArray[0] << " correct output1: " << pCorrectOutputData[i][0] << endl
			 << "output2: " << outputArray[1] << " correct output2: " << pCorrectOutputData[i][1] << endl << endl;
	}

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/


