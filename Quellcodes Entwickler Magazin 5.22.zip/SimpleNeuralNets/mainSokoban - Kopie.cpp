#include <iostream>
//#include <chrono>
#include <omp.h>
#include <thread>
#include "Sokoban.h"
#include "ConsoleHelperFunctions.h"
#include "SimpleNeuron.h"
#include "LogFile.h"

using namespace std;
using namespace chrono;
using namespace HelperStuff;

#define KEYDOWN(vk_code) ((GetAsyncKeyState(vk_code) & 0x8000) ? 1 : 0)
#define KEYUP(vk_code)   ((GetAsyncKeyState(vk_code) & 0x8000) ? 0 : 1)


//static COLOR_PALETTE g_GameBoardColorArray[7] = { blue, red, lightyello, lightgreen, lightaqua, lightpurple, lightpurple };
static COLOR_PALETTE g_GameBoardColorArray[7] = { blue, red, lightyello, lightgreen, graywhite, lightpurple, lightpurple };


static void Update_GameBoardGraphics(CWindowsConsole2DObject *pGameBoard, int8_t *pData)
{
	int32_t GameBoardSizeX = pGameBoard->NumCharactersPerRow;
	int32_t GameBoardSizeY = pGameBoard->NumCharactersPerColumn;

	int32_t id;

	for (int32_t iy = 0; iy < GameBoardSizeY; iy++)
	{
		for (int32_t ix = 0; ix < GameBoardSizeX; ix++)
		{
			id = ix + iy * GameBoardSizeX;

			pGameBoard->Set_Pixel(ix, iy, g_GameBoardColorArray[pData[id]]);
			//pGameBoard->Set_Pixel(ix, iy, g_GameBoardColorArray[static_cast<int32_t>(pData[id])]);
		}
	}
}

static void Set_ProcessPriority(unsigned long priority)
{
	HANDLE ProcessHandle = GetCurrentProcess();

	if (priority == 0)
		SetPriorityClass(ProcessHandle, NORMAL_PRIORITY_CLASS);
	else if (priority == 1)
		SetPriorityClass(ProcessHandle, ABOVE_NORMAL_PRIORITY_CLASS);
	else if (priority == 2)
		SetPriorityClass(ProcessHandle, HIGH_PRIORITY_CLASS);
	else
		SetPriorityClass(ProcessHandle, REALTIME_PRIORITY_CLASS);
}

#define KEY_C   0x43
#define KEY_P   0x50
#define KEY_R   0x52
#define KEY_S   0x53

#define KEY_0   0x30
#define KEY_1   0x31
#define KEY_2   0x32
#define KEY_3   0x33
#define KEY_4   0x34
#define KEY_5   0x35
#define KEY_6   0x36




///*
int main(void)
{
	//Set_ProcessPriority(2);

	Begin_Log(0, "start AI_Log",
		"AI_Log.txt");

	CRandomNumbersNN RandomNumbers;

	Set_Title("Sokoban");
	Set_ConsolePos(10, 10);
	Set_FontSize(10, 20);
	

	char inputBuffer[100];

	bool PlayingMode = true;
	bool DesignMode = false;
	bool AIMode = false;

	cout << "Playing (1) Or Puzzle Design (2) Or AI (3) Mode: ";

	int32_t tempInt = 0;
	cin.getline(inputBuffer, 100);
	tempInt = atoi(inputBuffer);

	if (tempInt == 2)
	{
		PlayingMode = false;
		DesignMode = true;
		AIMode = false;
	}
	else if (tempInt == 3)
	{
		PlayingMode = false;
		DesignMode = false;
		AIMode = true;
	}
	else
	{
		PlayingMode = true;
		DesignMode = false;
		AIMode = false;
	}

	char WorkInProgressPuzzle_Loading[100];
	char WorkInProgressPuzzle_Saving[100];

	char Puzzle_Unsolved[100];
	char Puzzle_Solved[100];

	if(DesignMode == true)
	{
		cout << "WorkInProgressPuzzle (Loading): ";
		cin.getline(inputBuffer, 100);
		sprintf(WorkInProgressPuzzle_Loading, "SokobanWorkInProgressPuzzles/%s.txt", inputBuffer);
		cout << "WorkInProgressPuzzle (Saving): ";
		cin.getline(inputBuffer, 100);
		sprintf(WorkInProgressPuzzle_Saving, "SokobanWorkInProgressPuzzles/%s.txt", inputBuffer);
	}
	else if(AIMode == true)
	{
		cout << "PuzzleName (AI-Solving): ";
		cin.getline(inputBuffer, 100);
		sprintf(Puzzle_Unsolved, "SokobanPuzzles/%s.txt", inputBuffer);
		sprintf(Puzzle_Solved, "SokobanPuzzles/%s_Solved.txt", inputBuffer);
	}
	
	// weitere Initialisierungsarbeiten, Konsoleneingaben, etc.
	CSokobanPuzzle *pSokobanPuzzle = nullptr;
	CSokobanPuzzles SokobanPuzzles;
	CSokobanPuzzle SokobanWorkInProgressPuzzle;
	CSokobanPuzzle UnsolvedSokobanPuzzle;
	CSokobanPuzzle SolvedSokobanPuzzle;
	CSimpleSokobanSolver SimpleSokobanSolver;

	if (PlayingMode == true)
	{
		SokobanPuzzles.Load_PuzzleInfos("SokobanPuzzleList.txt");
		SokobanPuzzles.Load_PlayerStatusInfo("SokobanPlayerStatus.txt");
		SokobanPuzzles.Initialize_Puzzle(&pSokobanPuzzle, SokobanPuzzles.IDofActualPlayedPuzzle);
	}
	else if (DesignMode == true)
	{
		SokobanWorkInProgressPuzzle.Load_Puzzle(WorkInProgressPuzzle_Loading);
		pSokobanPuzzle = &SokobanWorkInProgressPuzzle;
	}
	else if (AIMode == true)
	{
		UnsolvedSokobanPuzzle.Load_Puzzle(Puzzle_Unsolved);
		SolvedSokobanPuzzle.Load_Puzzle(Puzzle_Solved);
		
		SimpleSokobanSolver.Set_Puzzles(&UnsolvedSokobanPuzzle, &SolvedSokobanPuzzle);
	}
	

	int8_t *pActualGameStateData = nullptr;

	CGameStateRingBuffer GameStateRingBuffer;
	GameStateRingBuffer.Initialize(100, pSokobanPuzzle->SizeX, pSokobanPuzzle->SizeY);
	GameStateRingBuffer.Reset_ActualBufferElement();
	GameStateRingBuffer.Set_ActualBufferElementData(&pSokobanPuzzle->GameState);

	CGameStateValues OldGameState;
	OldGameState.Initialize(pSokobanPuzzle->SizeX, pSokobanPuzzle->SizeY);
	///////////////////////////////////

	CInputHandling InputHandling;
	InputHandling.Initialize();

	Clear_Terminal_And_Reset_CursorPos();

	CWindowsConsoleScreenBuffer WinConsole;
	WinConsole.Initialize(45, 40, false, BackgroundColor);

	if(PlayingMode == true)
		Set_Title("Sokoban (Playing Mode)");
	else if (DesignMode == true)
		Set_Title("Sokoban (Puzzle Design Mode)");
	else if (AIMode == true)
		Set_Title("Sokoban (AI Solver Mode)");

	Set_ConsolePos(10, 10);

	WinConsole.Set_CursorVisibilityAndSize(FALSE);
	//WinConsole.Set_Font(L"Consolas", 15, 15);
	//WinConsole.Set_Font(L"Consolas", 4, 4);
	//WinConsole.Set_Font(L"Consolas", 8, 8);
	WinConsole.Set_Font_Ext(L"Consolas", 90, 15, 15);


	//WinConsole.Set_BackgroundColor(RGB(100, 50, 25));
	WinConsole.Set_BackgroundColor(BackgroundColor);

	Set_CursorVisibilityAndSize(false);

	CSimpleNeuron DeadlockDetectionNeuron;
	DeadlockDetectionNeuron.Init_Dendrite_Arrays(3*3);
	DeadlockDetectionNeuron.Set_LocalReceptiveFieldSizeInfo(3, 3);
	DeadlockDetectionNeuron.Set_ActivationFunction(SokobanDeadlockRecognitionFunction);

	CSimpleNeuron CurrentlyLockedTileRecognitionNeuron;
	CurrentlyLockedTileRecognitionNeuron.Init_Dendrite_Arrays(3 * 3);
	CurrentlyLockedTileRecognitionNeuron.Set_LocalReceptiveFieldSizeInfo(3, 3);
	CurrentlyLockedTileRecognitionNeuron.Set_ActivationFunction(SokobanCurrentlyLockedTileRecognitionFunction);

	CSimpleNeuron PermanentlyLockedTileRecognitionNeuron;
	PermanentlyLockedTileRecognitionNeuron.Init_Dendrite_Arrays(3 * 3);
	PermanentlyLockedTileRecognitionNeuron.Set_LocalReceptiveFieldSizeInfo(3, 3);
	PermanentlyLockedTileRecognitionNeuron.Set_ActivationFunction(SokobanPermanentlyLockedTileRecognitionFunction);

	CSimpleNeuron MovableBoxRecognitionAndRemovingNeuron;
	MovableBoxRecognitionAndRemovingNeuron.Init_Dendrite_Arrays(3 * 3);
	MovableBoxRecognitionAndRemovingNeuron.Set_LocalReceptiveFieldSizeInfo(3, 3);
	MovableBoxRecognitionAndRemovingNeuron.Set_ActivationFunction(SokobanMovableBoxRecognitionAndRemovingFunction);

	CSimpleNeuron DeadEndRecognitionNeuron;
	DeadEndRecognitionNeuron.Init_Dendrite_Arrays(3 * 3);
	DeadEndRecognitionNeuron.Set_LocalReceptiveFieldSizeInfo(3, 3);
	DeadEndRecognitionNeuron.Set_ActivationFunction(SokobanDeadEndRecognitionFunction);

	int32_t NumOfDeadlocks = 0;

	
	char strBuffer[100];

	bool leftMouseButtonClick = false;
	bool middleMouseButtonClick = false; // undo move
	bool rightMouseButtonClick = false;

	float FrameTime = 1.0f;
	float FrameRate = 1.0f;

	int32_t GameBoardPosX_Left = 2;
	int32_t GameBoardPosY_Top = 3;

	int32_t PlayerPosX = 0;
	int32_t PlayerPosY = 0;

	int32_t OldPlayerPosX = 0;
	int32_t OldPlayerPosY = 0;

	int32_t PathFindingTestDestPosX = 0;
	int32_t PathFindingTestDestPosY = 0;
	
	int32_t NumOfPathSteps = 0;
	static int32_t PathTileIDArray[10000];

	bool ForwardPlaying = true; // true: die Boxen werden geschoben; false: die Boxen werden gezogen 

	CWindowsConsole2DObject GameBoard;
	GameBoard.Initialize(pSokobanPuzzle->SizeX, pSokobanPuzzle->SizeY);

	bool MovementKeysPressed = false;
	bool KEY_C_Pressed = false;
	bool KEY_P_Pressed = false;
	bool KEY_R_Pressed = false;
	bool KEY_S_Pressed = false;
	bool KEY_0_Pressed = false;
	bool KEY_1_Pressed = false;
	bool KEY_2_Pressed = false;
	bool KEY_3_Pressed = false;
	bool KEY_4_Pressed = false;
	bool KEY_5_Pressed = false;
	bool KEY_6_Pressed = false;

	bool PuzzleCompleted = false;
	bool PuzzleFailed = false;

	bool ReversePlayerMovement = false;

	int32_t BoxMovementCounter = 0;

#pragma omp parallel num_threads(2)
	{
		do
		{
			if (KEYDOWN(VK_ESCAPE) == true)
				break;

			int32_t threadID = omp_get_thread_num();

			if (threadID == 1)
			{
				InputHandling.Check_For_Input();
			}
			else if (threadID == 0) // master thread
			{
				//auto last_timepoint = std::chrono::steady_clock::now();
				auto last_timepoint = steady_clock::now();

				if (InputHandling.LeftMouseButtonPressed == true)
				{
					if (leftMouseButtonClick == false)
						leftMouseButtonClick = true;
					else
						leftMouseButtonClick = false;
				}

				if (InputHandling.MiddleMouseButtonPressed == true)
				{
					if (middleMouseButtonClick == false)
						middleMouseButtonClick = true;
					else
						middleMouseButtonClick = false;
				}

				if (InputHandling.RightMouseButtonPressed == true)
				{
					if (rightMouseButtonClick == false)
						rightMouseButtonClick = true;
					else
						rightMouseButtonClick = false;
				}

				InputHandling.Reset_MouseButtons();

				int32_t mousePosX = InputHandling.MousePosX;
				int32_t mousePosY = InputHandling.MousePosY;

				int32_t relativeMousePosX = mousePosX - GameBoardPosX_Left;
				int32_t relativeMousePosY = mousePosY - GameBoardPosY_Top;

				
				GameStateRingBuffer.Get_ActualBufferElement(&pActualGameStateData);
				
				if (DesignMode == true)
				{
					if (relativeMousePosX > 0 && relativeMousePosX < pSokobanPuzzle->SizeX - 1)
					{
						if (relativeMousePosY > 0 && relativeMousePosY < pSokobanPuzzle->SizeY - 1)
						{
							if (KEYDOWN(KEY_0) && KEY_0_Pressed == false)
							{
								KEY_0_Pressed = true;

								pActualGameStateData[relativeMousePosX + relativeMousePosY * pSokobanPuzzle->SizeX] = ConstGameBoard_Empty;
								GameStateRingBuffer.Set_ActualBufferElementData(pActualGameStateData);
								//GameStateRingBuffer.Set_PreviousBufferElementData(pActualGameStateData);
							}
							else if (KEYDOWN(KEY_1) && KEY_1_Pressed == false)
							{
								KEY_1_Pressed = true;

								pActualGameStateData[relativeMousePosX + relativeMousePosY * pSokobanPuzzle->SizeX] = ConstGameBoard_Wall;
								GameStateRingBuffer.Set_ActualBufferElementData(pActualGameStateData);
								//GameStateRingBuffer.Set_PreviousBufferElementData(pActualGameStateData);
							}
							else if (KEYDOWN(KEY_2) && KEY_2_Pressed == false)
							{
								KEY_2_Pressed = true;

								pActualGameStateData[relativeMousePosX + relativeMousePosY * pSokobanPuzzle->SizeX] = ConstGameBoard_Box;
								GameStateRingBuffer.Set_ActualBufferElementData(pActualGameStateData);
								//GameStateRingBuffer.Set_PreviousBufferElementData(pActualGameStateData);
							}
							else if (KEYDOWN(KEY_3) && KEY_3_Pressed == false)
							{
								KEY_3_Pressed = true;

								pActualGameStateData[relativeMousePosX + relativeMousePosY * pSokobanPuzzle->SizeX] = ConstGameBoard_Destination;
								GameStateRingBuffer.Set_ActualBufferElementData(pActualGameStateData);
								//GameStateRingBuffer.Set_PreviousBufferElementData(pActualGameStateData);
							}
							else if (KEYDOWN(KEY_4) && KEY_4_Pressed == false)
							{
								KEY_4_Pressed = true;

								pActualGameStateData[relativeMousePosX + relativeMousePosY * pSokobanPuzzle->SizeX] = ConstGameBoard_DestinationWithBox;
								GameStateRingBuffer.Set_ActualBufferElementData(pActualGameStateData);
								//GameStateRingBuffer.Set_PreviousBufferElementData(pActualGameStateData);
							}
							else if (KEYDOWN(KEY_5) && KEY_5_Pressed == false)
							{
								KEY_5_Pressed = true;

								pActualGameStateData[relativeMousePosX + relativeMousePosY * pSokobanPuzzle->SizeX] = ConstGameBoard_Player;
								GameStateRingBuffer.Set_ActualBufferElementData(pActualGameStateData);
								//GameStateRingBuffer.Set_PreviousBufferElementData(pActualGameStateData);
							}
							else if (KEYDOWN(KEY_6) && KEY_6_Pressed == false)
							{
								KEY_6_Pressed = true;

								pActualGameStateData[relativeMousePosX + relativeMousePosY * pSokobanPuzzle->SizeX] = ConstGameBoard_DestinationWithPlayer;
								GameStateRingBuffer.Set_ActualBufferElementData(pActualGameStateData);
								//GameStateRingBuffer.Set_PreviousBufferElementData(pActualGameStateData);
							}
						} // end of if (relativeMousePosY > 0 && relativeMousePosY < pSokobanPuzzle->SizeY - 1)
					} // end of if (relativeMousePosX > 0 && relativeMousePosX < pSokobanPuzzle->SizeX - 1)
				} // end of if (PuzzleDesignMode == true)
				

				OldGameState.Clone_GameStateValues(pActualGameStateData);
					
				OldPlayerPosX = OldPlayerPosY = 0;
				Get_PlayerPos(&OldPlayerPosX, &OldPlayerPosY, pActualGameStateData, pSokobanPuzzle->SizeX, pSokobanPuzzle->SizeY);

				// Pathfinding-Test
				if (KEYDOWN(KEY_C) && KEY_C_Pressed == false)
				{
					KEY_C_Pressed = true;
					NumOfPathSteps = 0;
				}

				// �berpr�fen, ob sich innerhalb eines Puzzles �berhaupt ein Spieler befindet:
				if (OldPlayerPosX > 0 && OldPlayerPosY > 0)
				{
					if (KEYDOWN(KEY_P) && KEY_P_Pressed == false)
					{
						KEY_P_Pressed = true;

						for (;;)
						{
							PathFindingTestDestPosX = RandomNumbers.Get_IntegerNumber2(1, pSokobanPuzzle->SizeX - 2);
							PathFindingTestDestPosY = RandomNumbers.Get_IntegerNumber2(1, pSokobanPuzzle->SizeY - 2);

							int8_t tileTypeNewPlayerPos = Get_TileType_Of_GamesWorldPos(PathFindingTestDestPosX, PathFindingTestDestPosY, pActualGameStateData, pSokobanPuzzle->SizeX);

							if (tileTypeNewPlayerPos == ConstGameBoard_Empty)
								break;
						}

						Add_To_Log(0, "StartPosX", OldPlayerPosX);
						Add_To_Log(0, "StartPosY", OldPlayerPosY);
						Add_To_Log(0, "DestPosX", PathFindingTestDestPosX);
						Add_To_Log(0, "DestPosY", PathFindingTestDestPosY);
						
						pSokobanPuzzle->Calculate_NeuralNetValueArray_MovementSpace(pActualGameStateData, 0);

						//Calculate_Path(PathTileIDArray, &NumOfPathSteps, OldPlayerPosX, OldPlayerPosY, PathFindingTestDestPosX, PathFindingTestDestPosY, pSokobanPuzzle, 0, 100);

						Calculate_Path_IncludingDiagonalMovement(PathTileIDArray, &NumOfPathSteps, OldPlayerPosX, OldPlayerPosY, PathFindingTestDestPosX, PathFindingTestDestPosY, pSokobanPuzzle, 0, 100);
					}
					
				} // end of if (OldPlayerPosX > 0 && OldPlayerPosY > 0)

				bool saveOldGameState = false;

				if (KEYDOWN(KEY_R) && KEY_R_Pressed == false)
				{
					KEY_R_Pressed = true;

					if (ReversePlayerMovement == true)
						ReversePlayerMovement = false;
					else
						ReversePlayerMovement = true;
				}

				
				

				
				if(ReversePlayerMovement == false)
				{ 
					if (KEYDOWN(VK_LEFT) && MovementKeysPressed == false)
					{ 
						MovementKeysPressed = true;

						if(OldPlayerPosX > 1) // Spielfeldbegrenzung unzug�nglich
						{ 
							int32_t newPossiblePlayerPosX = OldPlayerPosX - 1;
							int32_t newPossiblePlayerPosY = OldPlayerPosY;

							int8_t tileTypeNewPlayerPos = Get_TileType_Of_GamesWorldPos(newPossiblePlayerPosX, newPossiblePlayerPosY, pActualGameStateData, pSokobanPuzzle->SizeX);
								
							if (tileTypeNewPlayerPos == ConstGameBoard_Empty || tileTypeNewPlayerPos == ConstGameBoard_Destination)
							{
								saveOldGameState = Update_GamesWorld_AfterPlayerMovement(newPossiblePlayerPosX, newPossiblePlayerPosY, OldPlayerPosX, OldPlayerPosY, pActualGameStateData, pSokobanPuzzle->SizeX);
							}
							else if (tileTypeNewPlayerPos == ConstGameBoard_Box || tileTypeNewPlayerPos == ConstGameBoard_DestinationWithBox)
							{
								if (Check_PossibleBoxLeftMove(newPossiblePlayerPosX, newPossiblePlayerPosY, pActualGameStateData, pSokobanPuzzle->SizeX) == true)
								{
									int32_t newPossibleBoxPosX = OldPlayerPosX - 2;
									int32_t newPossibleBoxPosY = OldPlayerPosY;

									if (Set_BoxPos_If_Possible(newPossibleBoxPosX, newPossibleBoxPosY, pActualGameStateData, pSokobanPuzzle->SizeX) == true)
									{
										saveOldGameState = Update_GamesWorld_AfterPlayerMovement(newPossiblePlayerPosX, newPossiblePlayerPosY, OldPlayerPosX, OldPlayerPosY, pActualGameStateData, pSokobanPuzzle->SizeX);
									}
								}
							}
						}
					}
					else if (KEYDOWN(VK_RIGHT) && MovementKeysPressed == false)
					{
						MovementKeysPressed = true;

						if (OldPlayerPosX < pSokobanPuzzle->SizeX - 2) // Spielfeldbegrenzung unzug�nglich
						{
							int32_t newPossiblePlayerPosX = OldPlayerPosX + 1;
							int32_t newPossiblePlayerPosY = OldPlayerPosY;

							int8_t tileTypeNewPlayerPos = pActualGameStateData[newPossiblePlayerPosX + newPossiblePlayerPosY * pSokobanPuzzle->SizeX];

							if (tileTypeNewPlayerPos == ConstGameBoard_Empty || tileTypeNewPlayerPos == ConstGameBoard_Destination)
							{
								saveOldGameState = Update_GamesWorld_AfterPlayerMovement(newPossiblePlayerPosX, newPossiblePlayerPosY, OldPlayerPosX, OldPlayerPosY, pActualGameStateData, pSokobanPuzzle->SizeX);
							}
							else if (tileTypeNewPlayerPos == ConstGameBoard_Box || tileTypeNewPlayerPos == ConstGameBoard_DestinationWithBox)
							{
								if (Check_PossibleBoxRightMove(newPossiblePlayerPosX, newPossiblePlayerPosY, pActualGameStateData, pSokobanPuzzle->SizeX) == true)
								{
									int32_t newPossibleBoxPosX = OldPlayerPosX + 2;
									int32_t newPossibleBoxPosY = OldPlayerPosY;

									if (Set_BoxPos_If_Possible(newPossibleBoxPosX, newPossibleBoxPosY, pActualGameStateData, pSokobanPuzzle->SizeX) == true)
									{
										saveOldGameState = Update_GamesWorld_AfterPlayerMovement(newPossiblePlayerPosX, newPossiblePlayerPosY, OldPlayerPosX, OldPlayerPosY, pActualGameStateData, pSokobanPuzzle->SizeX);
									}
								}
							}
						}
					}
					else if (KEYDOWN(VK_UP) && MovementKeysPressed == false)
					{
						MovementKeysPressed = true;

						if (OldPlayerPosY > 1) // Spielfeldbegrenzung unzug�nglich
						{
							int32_t newPossiblePlayerPosX = OldPlayerPosX;
							int32_t newPossiblePlayerPosY = OldPlayerPosY - 1;

							int8_t tileTypeNewPlayerPos = pActualGameStateData[newPossiblePlayerPosX + newPossiblePlayerPosY * pSokobanPuzzle->SizeX];

							if (tileTypeNewPlayerPos == ConstGameBoard_Empty || tileTypeNewPlayerPos == ConstGameBoard_Destination)
							{
								saveOldGameState = Update_GamesWorld_AfterPlayerMovement(newPossiblePlayerPosX, newPossiblePlayerPosY, OldPlayerPosX, OldPlayerPosY, pActualGameStateData, pSokobanPuzzle->SizeX);
							}
							else if (tileTypeNewPlayerPos == ConstGameBoard_Box || tileTypeNewPlayerPos == ConstGameBoard_DestinationWithBox)
							{
								if (Check_PossibleBoxUpwardMove(newPossiblePlayerPosX, newPossiblePlayerPosY, pActualGameStateData, pSokobanPuzzle->SizeX) == true)
								{
									int32_t newPossibleBoxPosX = OldPlayerPosX;
									int32_t newPossibleBoxPosY = OldPlayerPosY - 2;

									if (Set_BoxPos_If_Possible(newPossibleBoxPosX, newPossibleBoxPosY, pActualGameStateData, pSokobanPuzzle->SizeX) == true)
									{
										saveOldGameState = Update_GamesWorld_AfterPlayerMovement(newPossiblePlayerPosX, newPossiblePlayerPosY, OldPlayerPosX, OldPlayerPosY, pActualGameStateData, pSokobanPuzzle->SizeX);
									}
								}
							}
						}
					}
					else if (KEYDOWN(VK_DOWN) && MovementKeysPressed == false)
					{
						MovementKeysPressed = true;

						if (OldPlayerPosY < pSokobanPuzzle->SizeY - 2) // Spielfeldbegrenzung unzug�nglich
						{
							int32_t newPossiblePlayerPosX = OldPlayerPosX;
							int32_t newPossiblePlayerPosY = OldPlayerPosY + 1;

							int8_t tileTypeNewPlayerPos = pActualGameStateData[newPossiblePlayerPosX + newPossiblePlayerPosY * pSokobanPuzzle->SizeX];

							if (tileTypeNewPlayerPos == ConstGameBoard_Empty || tileTypeNewPlayerPos == ConstGameBoard_Destination)
							{
								saveOldGameState = Update_GamesWorld_AfterPlayerMovement(newPossiblePlayerPosX, newPossiblePlayerPosY, OldPlayerPosX, OldPlayerPosY, pActualGameStateData, pSokobanPuzzle->SizeX);
							}
							else if (tileTypeNewPlayerPos == ConstGameBoard_Box || tileTypeNewPlayerPos == ConstGameBoard_DestinationWithBox)
							{
								if (Check_PossibleBoxDownwardMove(newPossiblePlayerPosX, newPossiblePlayerPosY, pActualGameStateData, pSokobanPuzzle->SizeX) == true)
								{
									int32_t newPossibleBoxPosX = OldPlayerPosX;
									int32_t newPossibleBoxPosY = OldPlayerPosY + 2;

									if (Set_BoxPos_If_Possible(newPossibleBoxPosX, newPossibleBoxPosY, pActualGameStateData, pSokobanPuzzle->SizeX) == true)
									{
										saveOldGameState = Update_GamesWorld_AfterPlayerMovement(newPossiblePlayerPosX, newPossiblePlayerPosY, OldPlayerPosX, OldPlayerPosY, pActualGameStateData, pSokobanPuzzle->SizeX);
									}
								}
							}
						}
					}
				} // end of if (ReversePlayerMovement == false)
				else if (ReversePlayerMovement == true)
				{
					int8_t tileTypeOldPlayerPos = Get_TileType_Of_GamesWorldPos(OldPlayerPosX, OldPlayerPosY, pActualGameStateData, pSokobanPuzzle->SizeX);

					if (KEYDOWN(VK_LEFT) && MovementKeysPressed == false)
					{
						MovementKeysPressed = true;

						if (OldPlayerPosX > 1) // Spielfeldbegrenzung unzug�nglich
						{
							int32_t newPossiblePlayerPosX = OldPlayerPosX - 1;
							int32_t newPossiblePlayerPosY = OldPlayerPosY;

							int8_t tileTypeNewPlayerPos = Get_TileType_Of_GamesWorldPos(newPossiblePlayerPosX, newPossiblePlayerPosY, pActualGameStateData, pSokobanPuzzle->SizeX);
								
							if (tileTypeNewPlayerPos == ConstGameBoard_Empty || tileTypeNewPlayerPos == ConstGameBoard_Destination)
							{
								Update_GamesWorld_AfterPlayerMovement(newPossiblePlayerPosX, newPossiblePlayerPosY, OldPlayerPosX, OldPlayerPosY, pActualGameStateData, pSokobanPuzzle->SizeX);
									
								int32_t oldPossibleBoxPosX = OldPlayerPosX + 1;
								int32_t oldPossibleBoxPosY = OldPlayerPosY;

								saveOldGameState = Pull_Box(oldPossibleBoxPosX, oldPossibleBoxPosY, OldPlayerPosX, OldPlayerPosY, tileTypeOldPlayerPos, pActualGameStateData, pSokobanPuzzle->SizeX);
							}					
						}
					}
					else if (KEYDOWN(VK_RIGHT) && MovementKeysPressed == false)
					{
						MovementKeysPressed = true;

						if (OldPlayerPosX < pSokobanPuzzle->SizeX - 2) // Spielfeldbegrenzung unzug�nglich
						{
							int32_t newPossiblePlayerPosX = OldPlayerPosX + 1;
							int32_t newPossiblePlayerPosY = OldPlayerPosY;

							int8_t tileTypeNewPlayerPos = pActualGameStateData[newPossiblePlayerPosX + newPossiblePlayerPosY * pSokobanPuzzle->SizeX];

							if (tileTypeNewPlayerPos == ConstGameBoard_Empty || tileTypeNewPlayerPos == ConstGameBoard_Destination)
							{
								Update_GamesWorld_AfterPlayerMovement(newPossiblePlayerPosX, newPossiblePlayerPosY, OldPlayerPosX, OldPlayerPosY, pActualGameStateData, pSokobanPuzzle->SizeX);

								int32_t oldPossibleBoxPosX = OldPlayerPosX - 1;
								int32_t oldPossibleBoxPosY = OldPlayerPosY;

								saveOldGameState = Pull_Box(oldPossibleBoxPosX, oldPossibleBoxPosY, OldPlayerPosX, OldPlayerPosY, tileTypeOldPlayerPos, pActualGameStateData, pSokobanPuzzle->SizeX);
							}
						}
					}
					else if (KEYDOWN(VK_UP) && MovementKeysPressed == false)
					{
						MovementKeysPressed = true;

						if (OldPlayerPosY > 1) // Spielfeldbegrenzung unzug�nglich
						{
							int32_t newPossiblePlayerPosX = OldPlayerPosX;
							int32_t newPossiblePlayerPosY = OldPlayerPosY - 1;

							int8_t tileTypeNewPlayerPos = pActualGameStateData[newPossiblePlayerPosX + newPossiblePlayerPosY * pSokobanPuzzle->SizeX];

							if (tileTypeNewPlayerPos == ConstGameBoard_Empty || tileTypeNewPlayerPos == ConstGameBoard_Destination)
							{
								Update_GamesWorld_AfterPlayerMovement(newPossiblePlayerPosX, newPossiblePlayerPosY, OldPlayerPosX, OldPlayerPosY, pActualGameStateData, pSokobanPuzzle->SizeX);

								int32_t oldPossibleBoxPosX = OldPlayerPosX;
								int32_t oldPossibleBoxPosY = OldPlayerPosY + 1;

								saveOldGameState = Pull_Box(oldPossibleBoxPosX, oldPossibleBoxPosY, OldPlayerPosX, OldPlayerPosY, tileTypeOldPlayerPos, pActualGameStateData, pSokobanPuzzle->SizeX);
							}
						}
					}
					else if (KEYDOWN(VK_DOWN) && MovementKeysPressed == false)
					{
						MovementKeysPressed = true;

						if (OldPlayerPosY < pSokobanPuzzle->SizeY - 2) // Spielfeldbegrenzung unzug�nglich
						{
							int32_t newPossiblePlayerPosX = OldPlayerPosX;
							int32_t newPossiblePlayerPosY = OldPlayerPosY + 1;

							int8_t tileTypeNewPlayerPos = pActualGameStateData[newPossiblePlayerPosX + newPossiblePlayerPosY * pSokobanPuzzle->SizeX];

							if (tileTypeNewPlayerPos == ConstGameBoard_Empty || tileTypeNewPlayerPos == ConstGameBoard_Destination)
							{
								Update_GamesWorld_AfterPlayerMovement(newPossiblePlayerPosX, newPossiblePlayerPosY, OldPlayerPosX, OldPlayerPosY, pActualGameStateData, pSokobanPuzzle->SizeX);

								int32_t oldPossibleBoxPosX = OldPlayerPosX;
								int32_t oldPossibleBoxPosY = OldPlayerPosY - 1;

								saveOldGameState = Pull_Box(oldPossibleBoxPosX, oldPossibleBoxPosY, OldPlayerPosX, OldPlayerPosY, tileTypeOldPlayerPos, pActualGameStateData, pSokobanPuzzle->SizeX);
							}
						}
					}
				}


				if (DesignMode == true)
				{
					if (KEYDOWN(KEY_S) && KEY_S_Pressed == false)
					{
						KEY_S_Pressed = true;
						pSokobanPuzzle->GameState.Clone_GameStateValues(pActualGameStateData);
						pSokobanPuzzle->Save_Puzzle(WorkInProgressPuzzle_Saving);
					}
				}
					
				if (KEYUP(VK_LEFT) && KEYUP(VK_RIGHT) && KEYUP(VK_UP) && KEYUP(VK_DOWN))
				{
					MovementKeysPressed = false;
				}

				if (KEYUP(KEY_C))
				{
					KEY_C_Pressed = false;
				}
				if (KEYUP(KEY_P))
				{
					KEY_P_Pressed = false;
				}
				if (KEYUP(KEY_R) )
				{
					KEY_R_Pressed = false;
				}
				if (KEYUP(KEY_S))
				{
					KEY_S_Pressed = false;
				}
				if (KEYUP(KEY_0))
				{
					KEY_0_Pressed = false;
				}
				if (KEYUP(KEY_1))
				{
					KEY_1_Pressed = false;
				}
				if (KEYUP(KEY_2))
				{
					KEY_2_Pressed = false;
				}
				if (KEYUP(KEY_3))
				{
					KEY_3_Pressed = false;
				}
				if (KEYUP(KEY_4))
				{
					KEY_4_Pressed = false;
				}
				if (KEYUP(KEY_5))
				{
					KEY_5_Pressed = false;
				}
				if (KEYUP(KEY_6))
				{
					KEY_6_Pressed = false;
				}

				if (saveOldGameState == true)
				{
					BoxMovementCounter++;

					GameStateRingBuffer.Increase_ActualBufferElement();
					GameStateRingBuffer.Get_ActualBufferElement(&pActualGameStateData);
					GameStateRingBuffer.Set_PreviousBufferElementData(&OldGameState);
				}

				if (rightMouseButtonClick == true && BoxMovementCounter > 0)// && GameFinished == false)
				{
					GameStateRingBuffer.Decrease_ActualBufferElement();
					BoxMovementCounter--;

					GameStateRingBuffer.Get_ActualBufferElement(&pActualGameStateData);
				}

				Get_PlayerPos(&PlayerPosX, &PlayerPosY, pActualGameStateData, pSokobanPuzzle->SizeX, pSokobanPuzzle->SizeY);

				PuzzleCompleted = Check_PossibleWin(pSokobanPuzzle->NumOfBoxesInsideGamesWorld, pActualGameStateData, pSokobanPuzzle->SizeX, pSokobanPuzzle->SizeY);

				if (PlayingMode == true)
				{
					if (PuzzleCompleted == true)
					{
						SokobanPuzzles.Update_PlayerStatusInfo();
						SokobanPuzzles.Initialize_Puzzle(&pSokobanPuzzle, SokobanPuzzles.IDofActualPlayedPuzzle);

						GameStateRingBuffer.Initialize(100, pSokobanPuzzle->SizeX, pSokobanPuzzle->SizeY);
						GameStateRingBuffer.Reset_ActualBufferElement();
						GameStateRingBuffer.Set_ActualBufferElementData(&pSokobanPuzzle->GameState);

						OldGameState.Initialize(pSokobanPuzzle->SizeX, pSokobanPuzzle->SizeY);

						GameBoard.Initialize(pSokobanPuzzle->SizeX, pSokobanPuzzle->SizeY);

						BoxMovementCounter = 0;

						PuzzleCompleted = false;
					}
				} // end of if (PlayingMode == true)


				NumOfDeadlocks = 0;

				if (PuzzleCompleted == false)
				{
					pSokobanPuzzle->Update_NeuralNetValueArray_Variant1(pActualGameStateData, 0);
					pSokobanPuzzle->Clone_FeatureMapValues(1, 0);

					Search_Pattern(&pSokobanPuzzle->FeatureMapArray[1], pSokobanPuzzle->FeatureMapArray[0].pDataArray, pSokobanPuzzle->SizeX, pSokobanPuzzle->SizeY, 1, 1, 1, pSokobanPuzzle->SizeX - 1, 1, pSokobanPuzzle->SizeY - 1, &DeadEndRecognitionNeuron);
					
					Search_Pattern(&pSokobanPuzzle->FeatureMapArray[0], pSokobanPuzzle->FeatureMapArray[1].pDataArray, pSokobanPuzzle->SizeX, pSokobanPuzzle->SizeY, 1, 1, 1, pSokobanPuzzle->SizeX - 1, 1, pSokobanPuzzle->SizeY - 1, &CurrentlyLockedTileRecognitionNeuron);

					Search_Pattern(&pSokobanPuzzle->FeatureMapArray[1], pSokobanPuzzle->FeatureMapArray[0].pDataArray, pSokobanPuzzle->SizeX, pSokobanPuzzle->SizeY, 1, 1, 1, pSokobanPuzzle->SizeX - 1, 1, pSokobanPuzzle->SizeY - 1, &MovableBoxRecognitionAndRemovingNeuron);

					Search_Pattern(&pSokobanPuzzle->FeatureMapArray[0], pSokobanPuzzle->FeatureMapArray[1].pDataArray, pSokobanPuzzle->SizeX, pSokobanPuzzle->SizeY, 1, 1, 1, pSokobanPuzzle->SizeX - 1, 1, pSokobanPuzzle->SizeY - 1, &PermanentlyLockedTileRecognitionNeuron);

					Search_Pattern(&NumOfDeadlocks, pSokobanPuzzle->FeatureMapArray[0].pDataArray, pSokobanPuzzle->SizeX, pSokobanPuzzle->SizeY, 1, 1, 1, pSokobanPuzzle->SizeX - 1, 1, pSokobanPuzzle->SizeY - 1, &DeadlockDetectionNeuron, 0.0f);
				}
				
				///////////

				GameStateRingBuffer.Get_ActualBufferElement(&pActualGameStateData);
				Update_GameBoardGraphics(&GameBoard, pActualGameStateData);

				if (NumOfPathSteps > 0)
				{
					for (int32_t i = 0; i < NumOfPathSteps; i++)
					{
						GameBoard.Set_Pixel(PathTileIDArray[i], gray);
					}
				}

				WinConsole.Clear_BackBuffer();

				WinConsole.Draw_2DObject_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top, GameBoard.pDataArray, GameBoard.NumCharactersPerRow, GameBoard.NumCharactersPerColumn);

				if (PuzzleCompleted == true)
				{
					sprintf(strBuffer, "Puzzle Completed");
					WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top - 2, strBuffer, lightyello, black);
				}

				if (ReversePlayerMovement == true)
				{
					sprintf(strBuffer, "Reverse Movement (R)");
					WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left + 20, GameBoardPosY_Top - 2, strBuffer, lightyello, black);
				}
				else
				{
					sprintf(strBuffer, "Normal Movement (R)");
					WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left + 20, GameBoardPosY_Top - 2, strBuffer, lightyello, black);
				}

				sprintf(strBuffer, "PlayerPos: %03d/%03d, Deadlocks: %d", PlayerPosX, PlayerPosY, NumOfDeadlocks);
				WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + pSokobanPuzzle->SizeY + 2, strBuffer, lightaqua, black);
				sprintf(strBuffer, "Box Movements: %03d", BoxMovementCounter);
				WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + pSokobanPuzzle->SizeY + 4, strBuffer, lightaqua, black);
					
				if (DesignMode == true)
				{
					sprintf(strBuffer, "Empty(0) Wall(1) Box(2) Destination(3)");
					WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + pSokobanPuzzle->SizeY + 7, strBuffer, lightgreen, black);
					sprintf(strBuffer, "Dest+Box(4) Player(5) Dest+Player(6)");
					WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + pSokobanPuzzle->SizeY + 9, strBuffer, lightgreen, black);
				}

				///////////

				leftMouseButtonClick = false;
				rightMouseButtonClick = false;
				middleMouseButtonClick = false;

				WinConsole.Present_BackBuffer();

				//Frame-Bremse:

				auto current_timepoint = steady_clock::now();

				//while (current_timepoint - last_timepoint < 250ms)
				//while (current_timepoint - last_timepoint < 50ms)
				while (current_timepoint - last_timepoint < 16ms)
						//while (current_timepoint - last_timepoint < 16666us) // 16.7 Millisekunden (ms)  bzw. 16666 Mikrosekunden (us): maximal 60 Frames pro Sekunde					
				{
					current_timepoint = steady_clock::now();
				}

				FrameTime = 0.000000001f * (current_timepoint - last_timepoint).count();
				FrameRate = 1.0f / FrameTime;
			
			} // end of else if (threadID == 0) // master thread
		} while (true);
	} // end of #pragma omp parallel num_threads(2)

	if (PlayingMode == true)
		SokobanPuzzles.Save_PlayerStatusInfo("SokobanPlayerStatus.txt");

	InputHandling.CleanUp();
	WinConsole.Clear_BackBuffer();
	WinConsole.Present_BackBuffer();
	WinConsole.CleanUp();

	Set_CursorVisibilityAndSize(true);
	Reset_CursorPos();
	Set_CursorPos(0, 0);

	cout << "bye bye (Press Return)" << endl;

	//getchar();

	return 0;
}
//*/