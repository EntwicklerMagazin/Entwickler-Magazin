#ifndef _GDIPlusFramework_H_
#define _GDIPlusFramework_H_  

#include <windows.h>
#include <gdiplus.h>
#include <iostream>

extern bool g_Running;
extern bool g_Pause;
extern bool g_LeftMouseButtonPressed;
extern bool g_RightMouseButtonPressed;
extern bool g_MiddleMouseButtonPressed;
extern int32_t g_MouseWheelRollingValue;
extern POINT g_ActualCursorPosition;


#define KEYDOWN(vk_code) ((GetAsyncKeyState(vk_code) & 0x8000) ? 1 : 0)
#define KEYUP(vk_code)   ((GetAsyncKeyState(vk_code) & 0x8000) ? 0 : 1)



// konvertiert CHAR-String in einen WCHAR-String:
int ConvertAnsiStringToWideCch(WCHAR* wstrDestination, const CHAR* strSource, int cchDestChar);

// Do not forget the SysFreeString()-Call after using the BSTR-String !!
BSTR ConvToBSTR(char* c);

void Conv_BSTR_To_Char(char* c, BSTR str);
void charToWChar(wchar_t* wtext, char* text);




class CGDIPlusWindow
{
public:

	uint32_t ScreenWidth = 100;
	uint32_t ScreenHeight = 100;

	uint32_t InitialX = 0;
	uint32_t InitialY = 0;

	HWND WindowHandle;
	HDC WindowDeviceContext;
	HDC BackBufferDeviceContext;

	HBITMAP BackBufferBitmap;
	HBITMAP OldBackBufferBitmap;

	Gdiplus::Graphics *pBackBufferGraphics = nullptr;

	Gdiplus::Graphics *pSceneGraphics = nullptr;
	Gdiplus::Bitmap *pSceneBitmap = nullptr;

	wchar_t WindowTitle[100];

	bool Initialized = false;

	Gdiplus::SolidBrush *pSolidBrush = nullptr;
	Gdiplus::Pen *pPen = nullptr;

	Gdiplus::FontFamily *pStandardFontFamily = nullptr;
	Gdiplus::Font *pStandardFont = nullptr;
	
	CGDIPlusWindow();
	~CGDIPlusWindow();

	// Verwendung des Kopierkonstruktors unterbinden: 
	CGDIPlusWindow(const CGDIPlusWindow &originalObject) = delete;

	// Verwendung des Zuweisungsoperators unterbinden: 
	CGDIPlusWindow& operator=(const CGDIPlusWindow &originalObject) = delete;

	void Set_WindowDimensions(uint32_t screenWidth, uint32_t screenHeight, uint32_t initialX = 0, uint32_t initialY = 0);
	void Set_WindowTitle(const char *pTitle);
	void Set_WindowTitle(const wchar_t *pTitle);
	void Set_StandardFont(const wchar_t *pString, float size, int32_t style = Gdiplus::FontStyleRegular, Gdiplus::Unit unit = Gdiplus::Unit::UnitPixel);
	void Initialize(HWND windowHandle);
	

	void Prepare_SceneUpdate(const Gdiplus::Color &color);
	void Prepare_SceneUpdate(void);

	void DrawLine(float startPosX, float startPosY, float endPosX, float endPosY, const Gdiplus::Color &color, float width);
	void DrawLineExt(float startPosX, float startPosY, float endPosX, float endPosY, const Gdiplus::Color &color, float width, Gdiplus::DashStyle dashStyle = Gdiplus::DashStyle::DashStyleSolid);

	void DrawString(const wchar_t *pString, float posX, float posY, const Gdiplus::Font *pFont, const Gdiplus::Brush *pBrush);
	void DrawString(const wchar_t *pString, const Gdiplus::PointF &PosXY, const Gdiplus::Font *pFont, const Gdiplus::Brush *pBrush);

	void DrawString(const wchar_t *pString, float posX, float posY, const Gdiplus::Font *pFont, const Gdiplus::Color &color);
	void DrawString(const wchar_t *pString, const Gdiplus::PointF &PosXY, const Gdiplus::Font *pFont, const Gdiplus::Color &color);

	void DrawString(const wchar_t *pString, float posX, float posY, const Gdiplus::Color &color);
	void DrawString(const wchar_t *pString, const Gdiplus::PointF &PosXY, const Gdiplus::Color &color);

	void DrawString(const char *pString, float posX, float posY, const Gdiplus::Font *pFont, const Gdiplus::Brush *pBrush);
	void DrawString(const char *pString, const Gdiplus::PointF &PosXY, const Gdiplus::Font *pFont, const Gdiplus::Brush *pBrush);

	void DrawString(const char *pString, float posX, float posY, const Gdiplus::Font *pFont, const Gdiplus::Color &color);
	void DrawString(const char *pString, const Gdiplus::PointF &PosXY, const Gdiplus::Font *pFont, const Gdiplus::Color &color);

	void DrawString(const char *pString, float posX, float posY, const Gdiplus::Color &color);
	void DrawString(const char *pString, const Gdiplus::PointF &PosXY, const Gdiplus::Color &color);

	void Transform_Object(float centerPosX, float centerPosY, float orientation, float scaleX, float scaleY);
	void Reset_ObjectTransformations(void);

	void Activate_Antialiasing(void);
	void Deactivate_Antialiasing(void);
	
	void Present_Scene(void);

private:

	Gdiplus::GdiplusStartupInput gdiplusStartupInput;
	ULONG_PTR gdiplusToken;
	
};

class CImageObject
{
public:

	int32_t Weight = 0;
	int32_t Height = 0;

	Gdiplus::Bitmap *pBitmap = nullptr;
	

	Gdiplus::ImageAttributes imAtt;
	Gdiplus::Rect DrawingRect;

	CGDIPlusWindow* pUsedGDIPlusWindow = nullptr;

	bool UseColorKey = false;

	CImageObject();
	~CImageObject();

	// Verwendung des Kopierkonstruktors unterbinden: 
	CImageObject(const CImageObject &originalObject) = delete;

	// Verwendung des Zuweisungsoperators unterbinden: 
	CImageObject& operator=(const CImageObject &originalObject) = delete;

	void Initialize(CGDIPlusWindow* pGDIPlusWindow, const char *pFilename, bool enableCenterTransformations, bool useColorKey = false);
	void Initialize(CGDIPlusWindow* pGDIPlusWindow, const wchar_t *pFilename, bool enableCenterTransformations, bool useColorKey = false);

	void Draw(void);
};

class CTexturedObject
{
public:

	int32_t Weight = 0;
	int32_t Height = 0;

	float fHalfWeight = 0.0f;
	float fHalfHeight = 0.0f;

	Gdiplus::TextureBrush *pTextureBrush = nullptr;

	Gdiplus::ImageAttributes imAtt;
	Gdiplus::Rect DrawingRect;

	CGDIPlusWindow* pUsedGDIPlusWindow = nullptr;

	CTexturedObject();
	~CTexturedObject();

	// Verwendung des Kopierkonstruktors unterbinden: 
	CTexturedObject(const CTexturedObject &originalObject) = delete;

	// Verwendung des Zuweisungsoperators unterbinden: 
	CTexturedObject& operator=(const CTexturedObject &originalObject) = delete;

	void Initialize(CGDIPlusWindow* pGDIPlusWindow, const char *pFilename, bool useColorKey = false);
	void Initialize(CGDIPlusWindow* pGDIPlusWindow, const wchar_t *pFilename, bool useColorKey = false);

	void Draw_Rectangle(float centerPosX, float centerPosY, float orientation, float scaleX, float scaleY);
	void Draw_Rectangle(float centerPosX, float centerPosY, float scaleX, float scaleY);
	void Draw_Rectangle(float centerPosX, float centerPosY);
};

#endif