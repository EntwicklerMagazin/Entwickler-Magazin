#include "GeneticAlgorithms.h"

using namespace std;


//-----------------------------------------------------------------------------
// CSimpleIntegerValueGenome
//-----------------------------------------------------------------------------

CSimpleIntegerValueGenome::CSimpleIntegerValueGenome()
{}

CSimpleIntegerValueGenome::~CSimpleIntegerValueGenome()
{
	delete[] pGeneArray;
	pGeneArray = nullptr;
}

void CSimpleIntegerValueGenome::Get_Access_To_iGlobalSimulationTime(int32_t *pGlobalSimulationTime)
{
	iPtrToGlobalSimulationTime = pGlobalSimulationTime;
}

void CSimpleIntegerValueGenome::Get_Access_To_fGlobalSimulationTime(float *pGlobalSimulationTime)
{
	fPtrToGlobalSimulationTime = pGlobalSimulationTime;
}

void CSimpleIntegerValueGenome::Initialize(int32_t numOfGenes)
{
	delete[] pGeneArray;
	pGeneArray = nullptr;

	NumOfGenes = numOfGenes;

	pGeneArray = new (std::nothrow) int32_t[NumOfGenes];

	for (int32_t i = 0; i < NumOfGenes; i++)
	{
		pGeneArray[i] = 0;
	}
}

void CSimpleIntegerValueGenome::Set_GeneData(int32_t *pData)
{
	for (int32_t i = 0; i < NumOfGenes; i++)
		pGeneArray[i] = pData[i];
}

void CSimpleIntegerValueGenome::Permute_GeneData(CRandomNumbersNN *pRandomNumbers, int32_t minGeneID, int32_t maxGeneID, int32_t permutationSteps)
{
	for (int32_t i = 0; i < permutationSteps; i++)
	{
		int32_t id1 = pRandomNumbers->Get_IntegerNumber2(minGeneID, maxGeneID);
		int32_t id2 = pRandomNumbers->Get_IntegerNumber2(minGeneID, maxGeneID);

		int32_t tempValue = pGeneArray[id1];

		pGeneArray[id1] = pGeneArray[id2];
		pGeneArray[id2] = tempValue;
	}
}

void CSimpleIntegerValueGenome_CloningFunction(void *pOutGenome, void *pInGenome)
{
	CSimpleIntegerValueGenome *pOriginalGenome = static_cast<CSimpleIntegerValueGenome*>(pInGenome);
	CSimpleIntegerValueGenome *pClonedGenome = static_cast<CSimpleIntegerValueGenome*>(pOutGenome);

	int32_t *pOriginalGeneArray = pOriginalGenome->pGeneArray;
	int32_t *pClonedGeneArray = pClonedGenome->pGeneArray;

	int32_t numOfGenes = pOriginalGenome->NumOfGenes;

	for (int32_t i = 0; i < numOfGenes; i++)
		pClonedGeneArray[i] = pOriginalGeneArray[i];
}

//-----------------------------------------------------------------------------
// CIntegerValueGenome
//-----------------------------------------------------------------------------

CIntegerValueGenome::CIntegerValueGenome()
{}

CIntegerValueGenome::~CIntegerValueGenome()
{
	delete[] pGeneArray;
	pGeneArray = nullptr;

	delete[] pGeneUsageArray;
	pGeneUsageArray = nullptr;

	delete[] pGeneChangeabilityArray;
	pGeneChangeabilityArray = nullptr;
}

void CIntegerValueGenome::Get_Access_To_iGlobalSimulationTime(int32_t *pGlobalSimulationTime)
{
	iPtrToGlobalSimulationTime = pGlobalSimulationTime;
}

void CIntegerValueGenome::Get_Access_To_fGlobalSimulationTime(float *pGlobalSimulationTime)
{
	fPtrToGlobalSimulationTime = pGlobalSimulationTime;
}

int32_t CIntegerValueGenome::Get_NumOfUsedGenes(void)
{
	int32_t sum = 0;

	for (int32_t i = 0; i < NumOfGenes; i++)
	{
		if(pGeneUsageArray[i] == true)
		{
			sum++;
		}
	}

	return sum;
}

float CIntegerValueGenome::Get_fNumOfUsedGenes(void)
{
	int32_t sum = 0;

	for (int32_t i = 0; i < NumOfGenes; i++)
	{
		if (pGeneUsageArray[i] == true)
		{
			sum++;
		}
	}

	return static_cast<float>(sum);
}

void CIntegerValueGenome::Initialize(int32_t numOfGenes)
{
	delete[] pGeneArray;
	pGeneArray = nullptr;

	delete[] pGeneUsageArray;
	pGeneUsageArray = nullptr;

	delete[] pGeneChangeabilityArray;
	pGeneChangeabilityArray = nullptr;

	NumOfGenes = numOfGenes;

	pGeneArray = new (std::nothrow) int32_t[NumOfGenes];
	pGeneUsageArray = new (std::nothrow) bool[NumOfGenes];
	pGeneChangeabilityArray = new (std::nothrow) bool[NumOfGenes];

	for (int32_t i = 0; i < NumOfGenes; i++)
	{
		pGeneArray[i] = 0;
		pGeneUsageArray[i] = true;
		pGeneChangeabilityArray[i] = true;
	}
}

void CIntegerValueGenome::Set_GeneUsageData(bool *pUsageData)
{
	for (int32_t i = 0; i < NumOfGenes; i++)
	{
		pGeneUsageArray[i] = pUsageData[i];
	}
}

void CIntegerValueGenome::Set_GeneChangeabilityData(bool *pChangeabilityData)
{
	for (int32_t i = 0; i < NumOfGenes; i++)
	{
		pGeneChangeabilityArray[i] = pChangeabilityData[i];
	}
}

void CIntegerValueGenome::Set_GeneData(int32_t *pData)
{
	for (int32_t i = 0; i < NumOfGenes; i++)
	{
		pGeneArray[i] = pData[i];
		//pGeneUsageArray[i] = true;
		//pGeneChangeabilityArray[i] = true;
	}
}



void CIntegerValueGenome::Permute_GeneData(CRandomNumbersNN *pRandomNumbers, int32_t minGeneID, int32_t maxGeneID, int32_t permutationSteps)
{
	for (int32_t i = 0; i < permutationSteps; i++)
	{
		int32_t id1 = pRandomNumbers->Get_IntegerNumber2(minGeneID, maxGeneID);
		int32_t id2 = pRandomNumbers->Get_IntegerNumber2(minGeneID, maxGeneID);

		int32_t tempValue = pGeneArray[id1];

		pGeneArray[id1] = pGeneArray[id2];
		pGeneArray[id2] = tempValue;

		bool tempBool = pGeneUsageArray[id1];
		pGeneUsageArray[id1] = pGeneUsageArray[id2];
		pGeneUsageArray[id2] = tempBool;

		tempBool = pGeneChangeabilityArray[id1];
		pGeneChangeabilityArray[id1] = pGeneChangeabilityArray[id2];
		pGeneChangeabilityArray[id2] = tempBool;
	}
}

void CIntegerValueGenome_CloningFunction(void *pOutGenome, void *pInGenome)
{
	CIntegerValueGenome *pOriginalGenome = static_cast<CIntegerValueGenome*>(pInGenome);
	CIntegerValueGenome *pClonedGenome = static_cast<CIntegerValueGenome*>(pOutGenome);

	int32_t *pOriginalGeneArray = pOriginalGenome->pGeneArray;
	int32_t *pClonedGeneArray = pClonedGenome->pGeneArray;

	bool *pOriginalGeneUsageArray = pOriginalGenome->pGeneUsageArray;
	bool *pClonedGeneUsageArray = pClonedGenome->pGeneUsageArray;

	bool *pOriginalGeneChangeabilityArray = pOriginalGenome->pGeneChangeabilityArray;
	bool *pClonedGeneChangeabilityArray = pClonedGenome->pGeneChangeabilityArray;

	int32_t numOfGenes = pOriginalGenome->NumOfGenes;

	for (int32_t i = 0; i < numOfGenes; i++)
	{
		pClonedGeneArray[i] = pOriginalGeneArray[i];
		pClonedGeneUsageArray[i] = pOriginalGeneUsageArray[i];
		pClonedGeneChangeabilityArray[i] = pOriginalGeneChangeabilityArray[i];
	}
}

//-----------------------------------------------------------------------------
// CSimpleFloatValueGenome
//-----------------------------------------------------------------------------

CSimpleFloatValueGenome::CSimpleFloatValueGenome()
{}

CSimpleFloatValueGenome::~CSimpleFloatValueGenome()
{
	delete[] pGeneArray;
	pGeneArray = nullptr;
}

void CSimpleFloatValueGenome::Get_Access_To_iGlobalSimulationTime(int32_t *pGlobalSimulationTime)
{
	iPtrToGlobalSimulationTime = pGlobalSimulationTime;
}

void CSimpleFloatValueGenome::Get_Access_To_fGlobalSimulationTime(float *pGlobalSimulationTime)
{
	fPtrToGlobalSimulationTime = pGlobalSimulationTime;
}

void CSimpleFloatValueGenome::Initialize(int32_t numOfGenes)
{
	delete[] pGeneArray;
	pGeneArray = nullptr;

	NumOfGenes = numOfGenes;

	pGeneArray = new (std::nothrow) float[NumOfGenes];

	for (int32_t i = 0; i < NumOfGenes; i++)
	{
		pGeneArray[i] = 0.0f;
	}
}

void CSimpleFloatValueGenome::Set_GeneData(float *pData)
{
	for (int32_t i = 0; i < NumOfGenes; i++)
		pGeneArray[i] = pData[i];
}

void CSimpleFloatValueGenome::Permute_GeneData(CRandomNumbersNN *pRandomNumbers, int32_t minGeneID, int32_t maxGeneID, int32_t permutationSteps)
{
	for (int32_t i = 0; i < permutationSteps; i++)
	{
		int32_t id1 = pRandomNumbers->Get_IntegerNumber2(minGeneID, maxGeneID);
		int32_t id2 = pRandomNumbers->Get_IntegerNumber2(minGeneID, maxGeneID);

		float tempValue = pGeneArray[id1];

		pGeneArray[id1] = pGeneArray[id2];
		pGeneArray[id2] = tempValue;
	}
}

void CSimpleFloatValueGenome_CloningFunction(void *pOutGenome, void *pInGenome)
{
	CSimpleFloatValueGenome *pOriginalGenome = static_cast<CSimpleFloatValueGenome*>(pInGenome);
	CSimpleFloatValueGenome *pClonedGenome = static_cast<CSimpleFloatValueGenome*>(pOutGenome);

	float *pOriginalGeneArray = pOriginalGenome->pGeneArray;
	float *pClonedGeneArray = pClonedGenome->pGeneArray;

	int32_t numOfGenes = pOriginalGenome->NumOfGenes;

	for (int32_t i = 0; i < numOfGenes; i++)
		pClonedGeneArray[i] = pOriginalGeneArray[i];
}

//-----------------------------------------------------------------------------
// CFloatValueGenome
//-----------------------------------------------------------------------------

CFloatValueGenome::CFloatValueGenome()
{}

CFloatValueGenome::~CFloatValueGenome()
{
	delete[] pGeneArray;
	pGeneArray = nullptr;

	delete[] pGeneUsageArray;
	pGeneUsageArray = nullptr;

	delete[] pGeneChangeabilityArray;
	pGeneChangeabilityArray = nullptr;
}

void CFloatValueGenome::Get_Access_To_iGlobalSimulationTime(int32_t *pGlobalSimulationTime)
{
	iPtrToGlobalSimulationTime = pGlobalSimulationTime;
}

void CFloatValueGenome::Get_Access_To_fGlobalSimulationTime(float *pGlobalSimulationTime)
{
	fPtrToGlobalSimulationTime = pGlobalSimulationTime;
}

int32_t CFloatValueGenome::Get_NumOfUsedGenes(void)
{
	int32_t sum = 0;

	for (int32_t i = 0; i < NumOfGenes; i++)
	{
		if (pGeneUsageArray[i] == true)
		{
			sum++;
		}
	}

	return sum;
}

float CFloatValueGenome::Get_fNumOfUsedGenes(void)
{
	int32_t sum = 0;

	for (int32_t i = 0; i < NumOfGenes; i++)
	{
		if (pGeneUsageArray[i] == true)
		{
			sum++;
		}
	}

	return static_cast<float>(sum);
}

void CFloatValueGenome::Initialize(int32_t numOfGenes)
{
	delete[] pGeneArray;
	pGeneArray = nullptr;

	delete[] pGeneUsageArray;
	pGeneUsageArray = nullptr;

	delete[] pGeneChangeabilityArray;
	pGeneChangeabilityArray = nullptr;

	NumOfGenes = numOfGenes;

	pGeneArray = new (std::nothrow) float[NumOfGenes];
	pGeneUsageArray = new (std::nothrow) bool[NumOfGenes];
	pGeneChangeabilityArray = new (std::nothrow) bool[NumOfGenes];

	for (int32_t i = 0; i < NumOfGenes; i++)
	{
		pGeneArray[i] = 0.0f;
		pGeneUsageArray[i] = true;
		pGeneChangeabilityArray[i] = true;
	}
}

void CFloatValueGenome::Set_GeneUsageData(bool *pUsageData)
{
	for (int32_t i = 0; i < NumOfGenes; i++)
	{
		pGeneUsageArray[i] = pUsageData[i];
	}
}

void CFloatValueGenome::Set_GeneChangeabilityData(bool *pChangeabilityData)
{
	for (int32_t i = 0; i < NumOfGenes; i++)
	{
		pGeneChangeabilityArray[i] = pChangeabilityData[i];
	}
}


void CFloatValueGenome::Set_GeneData(float *pData)
{
	for (int32_t i = 0; i < NumOfGenes; i++)
	{
		pGeneArray[i] = pData[i];
		//pGeneUsageArray[i] = true;
		//pGeneChangeabilityArray[i] = true;
	}
}



void CFloatValueGenome::Permute_GeneData(CRandomNumbersNN *pRandomNumbers, int32_t minGeneID, int32_t maxGeneID, int32_t permutationSteps)
{
	for (int32_t i = 0; i < permutationSteps; i++)
	{
		int32_t id1 = pRandomNumbers->Get_IntegerNumber2(minGeneID, maxGeneID);
		int32_t id2 = pRandomNumbers->Get_IntegerNumber2(minGeneID, maxGeneID);

		float tempValue = pGeneArray[id1];

		pGeneArray[id1] = pGeneArray[id2];
		pGeneArray[id2] = tempValue;

		bool tempBool = pGeneUsageArray[id1];
		pGeneUsageArray[id1] = pGeneUsageArray[id2];
		pGeneUsageArray[id2] = tempBool;

		tempBool = pGeneChangeabilityArray[id1];
		pGeneChangeabilityArray[id1] = pGeneChangeabilityArray[id2];
		pGeneChangeabilityArray[id2] = tempBool;
	}
}

void CFloatValueGenome_CloningFunction(void *pOutGenome, void *pInGenome)
{
	CFloatValueGenome *pOriginalGenome = static_cast<CFloatValueGenome*>(pInGenome);
	CFloatValueGenome *pClonedGenome = static_cast<CFloatValueGenome*>(pOutGenome);

	float *pOriginalGeneArray = pOriginalGenome->pGeneArray;
	float *pClonedGeneArray = pClonedGenome->pGeneArray;

	bool *pOriginalGeneUsageArray = pOriginalGenome->pGeneUsageArray;
	bool *pClonedGeneUsageArray = pClonedGenome->pGeneUsageArray;

	bool *pOriginalGeneChangeabilityArray = pOriginalGenome->pGeneChangeabilityArray;
	bool *pClonedGeneChangeabilityArray = pClonedGenome->pGeneChangeabilityArray;

	int32_t numOfGenes = pOriginalGenome->NumOfGenes;

	for (int32_t i = 0; i < numOfGenes; i++)
	{
		pClonedGeneArray[i] = pOriginalGeneArray[i];
		pClonedGeneUsageArray[i] = pOriginalGeneUsageArray[i];
		pClonedGeneChangeabilityArray[i] = pOriginalGeneChangeabilityArray[i];
	}
}

//-----------------------------------------------------------------------------
// CGene
//-----------------------------------------------------------------------------

CGene::CGene()
{

}

CGene::~CGene()
{
	delete[] pIValueArray;
	pIValueArray = nullptr;

	delete[] pFValueArray;
	pFValueArray = nullptr;

	delete[] pCValueArray;
	pCValueArray = nullptr;
}

void CGene::Initialize(int32_t numOfIntegerValues, int32_t numOfFloatValues, int32_t numOfCharValues)
{
	delete[] pIValueArray;
	pIValueArray = nullptr;

	delete[] pFValueArray;
	pFValueArray = nullptr;

	delete[] pCValueArray;
	pCValueArray = nullptr;

	NumOfIntegerValues = numOfIntegerValues;
	NumOfFloatValues = numOfFloatValues;
	NumOfCharValues = numOfCharValues;

	if (numOfIntegerValues > 0)
	{
		pIValueArray = new (std::nothrow) int32_t[NumOfIntegerValues];

		for (int32_t i = 0; i < NumOfIntegerValues; i++)
		{
			pIValueArray[i] = 0;
		}
	}

	if (numOfFloatValues > 0)
	{
		pFValueArray = new (std::nothrow) float[NumOfFloatValues];

		for (int32_t i = 0; i < NumOfFloatValues; i++)
		{
			pFValueArray[i] = 0.0f;
		}
	}

	if (numOfCharValues > 0)
	{
		pCValueArray = new (std::nothrow) char[NumOfCharValues];
	}
}

void CGene::Clone_Values(CGene *pOriginalObject)
{
	int32_t *pIValueArrayOriginalObject = pOriginalObject->pIValueArray;
	
	for (int32_t i = 0; i < NumOfIntegerValues; i++)
	{
		pIValueArray[i] = pIValueArrayOriginalObject[i];
	}

	float *pFValueArrayOriginalObject = pOriginalObject->pFValueArray;

	for (int32_t i = 0; i < NumOfFloatValues; i++)
	{
		pFValueArray[i] = pFValueArrayOriginalObject[i];
	}

	char *pCValueArrayOriginalObject = pOriginalObject->pCValueArray;

	for (int32_t i = 0; i < NumOfCharValues; i++)
	{
		pCValueArray[i] = pCValueArrayOriginalObject[i];
	}
}

//-----------------------------------------------------------------------------
// CChromosome
//-----------------------------------------------------------------------------

CChromosome::CChromosome()
{}

CChromosome::~CChromosome()
{}

void CChromosome::Set_Data1(int32_t numOfGenes, int32_t minGeneID)
{
	NumOfGenes = numOfGenes;
	MinGeneID = minGeneID;
	MaxGeneIDPlus1 = minGeneID + numOfGenes;
}

void CChromosome::Set_Data2(int32_t numOfGenes, int32_t minGeneID, int32_t maxGeneIDPlus1)
{
	NumOfGenes = numOfGenes;
	MinGeneID = minGeneID;
	MaxGeneIDPlus1 = maxGeneIDPlus1;
}

void CChromosome::Set_Data3(int32_t minGeneID, int32_t maxGeneIDPlus1)
{
	MinGeneID = minGeneID;
	MaxGeneIDPlus1 = maxGeneIDPlus1;
	NumOfGenes = maxGeneIDPlus1 - minGeneID;
}

//-----------------------------------------------------------------------------
// CGenome
//-----------------------------------------------------------------------------

CGenome::CGenome()
{}

CGenome::~CGenome()
{
	delete[] pGeneArray;
	pGeneArray = nullptr;

	delete[] pGeneUsageArray;
	pGeneUsageArray = nullptr;

	delete[] pGeneChangeabilityArray;
	pGeneChangeabilityArray = nullptr;

	delete[] pChromosomeArray;
	pChromosomeArray = nullptr;
}

void CGenome::Get_Access_To_iGlobalSimulationTime(int32_t *pGlobalSimulationTime)
{
	iPtrToGlobalSimulationTime = pGlobalSimulationTime;
}

void CGenome::Get_Access_To_fGlobalSimulationTime(float *pGlobalSimulationTime)
{
	fPtrToGlobalSimulationTime = pGlobalSimulationTime;
}


void  CGenome::Set_GeneData(CGene *pGenes)
{
	for (int32_t i = 0; i < NumOfGenes; i++)
	{
		pGeneArray[i].Clone_Values(&pGenes[i]);
	}
}

void CGenome::Set_SingleGeneData(CGene *pGene, int32_t geneArrayElementID)
{
	pGeneArray[geneArrayElementID].Clone_Values(pGene);
}

void CGenome::Set_GeneUsageData(bool *pUsageData)
{
	for (int32_t i = 0; i < NumOfGenes; i++)
	{
		pGeneUsageArray[i] = pUsageData[i];
	}
}

void CGenome::Set_GeneChangeabilityData(bool *pChangeabilityData)
{
	for (int32_t i = 0; i < NumOfGenes; i++)
	{
		pGeneChangeabilityArray[i] = pChangeabilityData[i];
	}
}

void CGenome::Initialize_Chromosomes_If_Necessary(int32_t numOfChromosomes)
{
	delete[] pChromosomeArray;
	pChromosomeArray = nullptr;

	NumOfChromosomes = numOfChromosomes;

	pChromosomeArray = new (std::nothrow) CChromosome[NumOfChromosomes];
}

void CGenome::Set_ChromosomeData1(int32_t chromosomeID, int32_t numOfGenes, int32_t minGeneID)
{
	pChromosomeArray[chromosomeID].Set_Data1(numOfGenes, minGeneID);
}

void CGenome::Set_ChromosomeData2(int32_t chromosomeID, int32_t numOfGenes, int32_t minGeneID, int32_t maxGeneIDPlus1)
{
	pChromosomeArray[chromosomeID].Set_Data2(numOfGenes, minGeneID, maxGeneIDPlus1);
}

void CGenome::Set_ChromosomeData3(int32_t chromosomeID, int32_t minGeneID, int32_t maxGeneIDPlus1)
{
	pChromosomeArray[chromosomeID].Set_Data3(minGeneID, maxGeneIDPlus1);
}

void CGenome::Permute_GeneData(CRandomNumbersNN *pRandomNumbers, int32_t minGeneID, int32_t maxGeneID, int32_t permutationSteps)
{
	for (int32_t i = 0; i < permutationSteps; i++)
	{
		int32_t id1 = pRandomNumbers->Get_IntegerNumber2(minGeneID, maxGeneID);
		int32_t id2 = pRandomNumbers->Get_IntegerNumber2(minGeneID, maxGeneID);

		TempGene.Clone_Values(&pGeneArray[id1]);
		

		pGeneArray[id1].Clone_Values(&pGeneArray[id2]);
		pGeneArray[id2].Clone_Values(&TempGene);

		bool tempBool = pGeneUsageArray[id1];
		pGeneUsageArray[id1] = pGeneUsageArray[id2];
		pGeneUsageArray[id2] = tempBool;

		tempBool = pGeneChangeabilityArray[id1];
		pGeneChangeabilityArray[id1] = pGeneChangeabilityArray[id2];
		pGeneChangeabilityArray[id2] = tempBool;
	}
}

int32_t CGenome::Get_NumOfUsedGenes(void)
{
	int32_t sum = 0;

	for (int32_t i = 0; i < NumOfGenes; i++)
	{
		if (pGeneUsageArray[i] == true)
		{
			sum++;
		}
	}

	return sum;
}

int32_t CGenome::Get_NumOfUsedGenes(int32_t chromosomeID)
{
	int32_t minGeneID = pChromosomeArray[chromosomeID].MinGeneID;
	int32_t maxGeneIDPlus1 = pChromosomeArray[chromosomeID].MaxGeneIDPlus1;

	int32_t sum = 0;

	for (int32_t i = minGeneID; i < maxGeneIDPlus1; i++)
	{
		if (pGeneUsageArray[i] == true)
		{
			sum++;
		}
	}

	return sum;
}

float CGenome::Get_fNumOfUsedGenes(void)
{
	int32_t sum = 0;

	for (int32_t i = 0; i < NumOfGenes; i++)
	{
		if (pGeneUsageArray[i] == true)
		{
			sum++;
		}
	}

	return static_cast<float>(sum);
}

float CGenome::Get_fNumOfUsedGenes(int32_t chromosomeID)
{
	int32_t minGeneID = pChromosomeArray[chromosomeID].MinGeneID;
	int32_t maxGeneIDPlus1 = pChromosomeArray[chromosomeID].MaxGeneIDPlus1;

	int32_t sum = 0;

	for (int32_t i = minGeneID; i < maxGeneIDPlus1; i++)
	{
		if (pGeneUsageArray[i] == true)
		{
			sum++;
		}
	}

	return static_cast<float>(sum);
}

void CGenome::Initialize(int32_t numOfGenes, int32_t numOfIntegerValuesPerGene, int32_t numOfFloatValuesPerGene, int32_t numOfCharValuesPerGene)
{
	delete[] pGeneArray;
	pGeneArray = nullptr;

	delete[] pGeneUsageArray;
	pGeneUsageArray = nullptr;

	delete[] pGeneChangeabilityArray;
	pGeneChangeabilityArray = nullptr;


	NumOfGenes = numOfGenes;

	pGeneArray = new (std::nothrow) CGene[NumOfGenes];
	pGeneUsageArray = new (std::nothrow) bool[NumOfGenes];
	pGeneChangeabilityArray = new (std::nothrow) bool[NumOfGenes];

	for (int32_t i = 0; i < NumOfGenes; i++)
	{
		pGeneArray[i].Initialize(numOfIntegerValuesPerGene, numOfFloatValuesPerGene, numOfCharValuesPerGene);
		pGeneUsageArray[i] = true;
		pGeneChangeabilityArray[i] = true;
	}

	TempGene.Initialize(numOfIntegerValuesPerGene, numOfFloatValuesPerGene, numOfCharValuesPerGene);
}

void CGenome_CloningFunction(void *pOutGenome, void *pInGenome)
{
	CGenome *pOriginalGenome = static_cast<CGenome*>(pInGenome);
	CGenome *pClonedGenome = static_cast<CGenome*>(pOutGenome);

	int32_t numOfGenes = pOriginalGenome->NumOfGenes;

	bool *pOriginalGeneUsageArray = pOriginalGenome->pGeneUsageArray;
	bool *pClonedGeneUsageArray = pClonedGenome->pGeneUsageArray;

	bool *pOriginalGeneChangeabilityArray = pOriginalGenome->pGeneChangeabilityArray;
	bool *pClonedGeneChangeabilityArray = pClonedGenome->pGeneChangeabilityArray;

	CGene *pClonedGeneArray = pClonedGenome->pGeneArray;
	CGene *pOriginalGeneArray = pOriginalGenome->pGeneArray;

	for (int32_t i = 0; i < numOfGenes; i++)
	{
		pClonedGeneUsageArray[i] = pOriginalGeneUsageArray[i];
		pClonedGeneChangeabilityArray[i] = pOriginalGeneChangeabilityArray[i];
		pClonedGeneArray[i].Clone_Values(&pOriginalGeneArray[i]);
	}
}

//-----------------------------------------------------------------------------
// CGeneBasedCalculations
//-----------------------------------------------------------------------------

CGeneBasedCalculations::CGeneBasedCalculations()
{}

CGeneBasedCalculations::~CGeneBasedCalculations()
{
	delete[] pDataArray;
	pDataArray = nullptr;

	delete[] pCalculationFunctionArray;
	pCalculationFunctionArray = nullptr;
}

void CGeneBasedCalculations::Initialize_DataArray(int32_t numOfDataValues)
{
	delete[] pDataArray;
	pDataArray = nullptr;

	NumOfDataValues = numOfDataValues;

	pDataArray = new (std::nothrow) float[numOfDataValues];

	for (int32_t i = 0; i < numOfDataValues; i++)
	{
		pDataArray[i] = 0.0f;
	}
}

void CGeneBasedCalculations::Initialize_CalculationFunctionArray(int32_t numOfFunctions)
{
	delete[] pCalculationFunctionArray;
	pCalculationFunctionArray = nullptr;

	NumOfCalculationFunctions = numOfFunctions;

	pCalculationFunctionArray = new (std::nothrow) pGeneBasedCalculationFunction[numOfFunctions];

	for (int32_t i = 0; i < numOfFunctions; i++)
	{
		pCalculationFunctionArray[i] = nullptr;
	}
}

void CGeneBasedCalculations::Set_CalculationFunction(int32_t functionID, pGeneBasedCalculationFunction pFunc)
{
	pCalculationFunctionArray[functionID] = pFunc;
}

void CGeneBasedCalculations::Execute_CalculationFunction(CGene *pGene)
{
	pCalculationFunctionArray[pGene->pIValueArray[0]](pGene, pDataArray);
}

void CGeneBasedCalculations::Execute_CalculationFunctions(CGenome *pGenome)
{
	CGene *pGeneArray = pGenome->pGeneArray;
	
	int32_t numOfGenes = pGenome->NumOfGenes;

	for (int32_t i = 0; i < numOfGenes; i++)
	{
		CGene *pGene = &pGeneArray[i];
		pCalculationFunctionArray[pGene->pIValueArray[0]](pGene, pDataArray);
	}
}

void CGeneBasedCalculations::Execute_CalculationFunctions(CGenome *pGenome, int32_t chromosomeID)
{
	CGene *pGeneArray = pGenome->pGeneArray;

	int32_t minGeneID = pGenome->pChromosomeArray[chromosomeID].MinGeneID;
	int32_t maxGeneIDPlus1 = pGenome->pChromosomeArray[chromosomeID].MaxGeneIDPlus1;
	
	for (int32_t i = minGeneID; i < maxGeneIDPlus1; i++)
	{
		CGene *pGene = &pGeneArray[i];
		pCalculationFunctionArray[pGene->pIValueArray[0]](pGene, pDataArray);
	}
}

void CGeneBasedCalculations::Execute_CalculationFunctionsExt(CGenome *pGenome)
{
	CGene *pGeneArray = pGenome->pGeneArray;
	bool *pGeneUsageArray = pGenome->pGeneUsageArray;

	int32_t numOfGenes = pGenome->NumOfGenes;

	for (int32_t i = 0; i < numOfGenes; i++)
	{
		if (pGeneUsageArray[i] == false)
		{
			continue;
		}

		CGene *pGene = &pGeneArray[i];
		pCalculationFunctionArray[pGene->pIValueArray[0]](pGene, pDataArray);
	}
}

void CGeneBasedCalculations::Execute_CalculationFunctionsExt(CGenome *pGenome, int32_t chromosomeID)
{
	CGene *pGeneArray = pGenome->pGeneArray;
	bool *pGeneUsageArray = pGenome->pGeneUsageArray;

	int32_t minGeneID = pGenome->pChromosomeArray[chromosomeID].MinGeneID;
	int32_t maxGeneIDPlus1 = pGenome->pChromosomeArray[chromosomeID].MaxGeneIDPlus1;

	for (int32_t i = minGeneID; i < maxGeneIDPlus1; i++)
	{
		if (pGeneUsageArray[i] == false)
		{
			continue;
		}

		CGene *pGene = &pGeneArray[i];
		pCalculationFunctionArray[pGene->pIValueArray[0]](pGene, pDataArray);
	}
}

void CGeneBasedCalculations::Reset_DataArrayValues(void)
{
	for (int32_t i = 0; i < NumOfDataValues; i++)
	{
		pDataArray[i] = 0.0f;
	}
}

void CGeneBasedCalculations::Set_DataArrayValue(int32_t dataArrayElementID, float value)
{
	pDataArray[dataArrayElementID] = value;
}

void CGeneBasedCalculations::Set_DataArrayValues(float *pInValueArray, int32_t firstDataArrayElementID, int32_t numOfValues)
{
	int32_t dataArrayID = firstDataArrayElementID;

	for (int32_t i = 0; i < numOfValues; i++)
	{
		pDataArray[dataArrayID] = pInValueArray[i];
		dataArrayID++;
	}
}

void CGeneBasedCalculations::Get_DataArrayValues(float *pOutValueArray, int32_t firstDataArrayElementID, int32_t numOfValues)
{
	int32_t dataArrayID = firstDataArrayElementID;

	for (int32_t i = 0; i < numOfValues; i++)
	{
		pOutValueArray[i] = pDataArray[dataArrayID];
		dataArrayID++;
	}
}

float CGeneBasedCalculations::Get_DataArrayValue(int32_t dataArrayElementID)
{
	return pDataArray[dataArrayElementID];
}

bool CGeneBasedCalculations::Set_DataArrayValues_UseLRFCenterPos(int32_t posX_center, int32_t posY_center, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, int32_t firstDataArrayElementID)
{
	int32_t dataArrayID = firstDataArrayElementID;

	if (inputMapSizeX == localReceptiveFieldSizeX && inputMapSizeY == localReceptiveFieldSizeY)
	{
		int32_t inputValueCounter = localReceptiveFieldSizeX * localReceptiveFieldSizeY;

		for (int32_t i = 0; i < inputValueCounter; i++)
		{
			pDataArray[dataArrayID] = pInputMap[i];
			dataArrayID++;
		}

		return true;
	}

	int32_t posX_left = posX_center - localReceptiveFieldSizeX / 2;
	int32_t posY_top = posY_center - localReceptiveFieldSizeY / 2;

	if (posX_left < 0)
		return false;
	if (posY_top < 0)
		return false;
	if (posX_left > inputMapSizeX - localReceptiveFieldSizeX)
		return false;
	if (posY_top > inputMapSizeY - localReceptiveFieldSizeY)
		return false;

	int32_t ixStart = posX_left;
	int32_t ixStopPlus1 = ixStart + localReceptiveFieldSizeX;

	int32_t iyStart = posY_top;
	int32_t iyStopPlus1 = iyStart + localReceptiveFieldSizeY;

	int32_t iiy;

	for (int32_t iy = iyStart; iy < iyStopPlus1; iy++)
	{
		iiy = iy * inputMapSizeX;

		for (int32_t ix = ixStart; ix < ixStopPlus1; ix++)
		{
			pDataArray[dataArrayID] = pInputMap[ix + iiy];
			dataArrayID++;
		}
	}

	return true;
}

bool CGeneBasedCalculations::Set_DataArrayValues_UseLRFTopLeftPos(int32_t posX_left, int32_t posY_top, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, int32_t firstDataArrayElementID)
{
	int32_t dataArrayID = firstDataArrayElementID;

	if (inputMapSizeX == localReceptiveFieldSizeX && inputMapSizeY == localReceptiveFieldSizeY)
	{
		int32_t inputValueCounter = localReceptiveFieldSizeX * localReceptiveFieldSizeY;

		for (int32_t i = 0; i < inputValueCounter; i++)
		{
			pDataArray[dataArrayID] = pInputMap[i];
			dataArrayID++;
		}

		return true;
	}

	if (posX_left < 0)
		return false;
	if (posY_top < 0)
		return false;
	if (posX_left > inputMapSizeX - localReceptiveFieldSizeX)
		return false;
	if (posY_top > inputMapSizeY - localReceptiveFieldSizeY)
		return false;

	int32_t ixStart = posX_left;
	int32_t ixStopPlus1 = ixStart + localReceptiveFieldSizeX;

	int32_t iyStart = posY_top;
	int32_t iyStopPlus1 = iyStart + localReceptiveFieldSizeY;

	int32_t iiy;

	for (int32_t iy = iyStart; iy < iyStopPlus1; iy++)
	{
		iiy = iy * inputMapSizeX;

		for (int32_t ix = ixStart; ix < ixStopPlus1; ix++)
		{
			pDataArray[dataArrayID] = pInputMap[ix + iiy];
			dataArrayID++;
		}
	}

	return true;
}


//-----------------------------------------------------------------------------
// CGeneralPopulation
//-----------------------------------------------------------------------------


CGeneralPopulation::CGeneralPopulation()
{
	for (int32_t i = 0; i < constNumOfBestFittedGenomes; i++)
	{
		IDArrayOfBestFittedGenomes[i] = 0;
		FitnessArrayOfBestFittedGenomes[i] = 0.0f;
	}

	for (int32_t i = 0; i < constNumOfWorstFittedGenomes; i++)
	{
		IDArrayOfWorstFittedGenomes[i] = 0;
		FitnessArrayOfWorstFittedGenomes[i] = 0.0f;
	}
}

CGeneralPopulation::~CGeneralPopulation()
{
	delete[] pFitnessScoreArray;
	pFitnessScoreArray = nullptr;

	delete[] ppGenomeArray;
	ppGenomeArray = nullptr;
}

void CGeneralPopulation::Set_GenomeValueCloningFunction(pGenomeValueCloning pFunc)
{
	GenomeValueCloningFunc = pFunc;
}

void CGeneralPopulation::Change_Seed(uint64_t seed)
{
	Seed = seed;
}

bool CGeneralPopulation::Initialize(int32_t populationSize)
{
	int32_t minPopulationSize = constNumOfBestFittedGenomes + constNumOfWorstFittedGenomes + constNumOfAdditionalGenomes + 10;
	//if (populationSize < minPopulationSize)
	//populationSize = minPopulationSize;

	for (int32_t i = 0; i < constNumOfBestFittedGenomes; i++)
	{
		IDArrayOfBestFittedGenomes[i] = 0;
		FitnessArrayOfBestFittedGenomes[i] = 0.0f;
	}

	for (int32_t i = 0; i < constNumOfWorstFittedGenomes; i++)
	{
		IDArrayOfWorstFittedGenomes[i] = 0;
		FitnessArrayOfWorstFittedGenomes[i] = 0.0f;
	}

	UseAdditionalMutatedBestGenome = false;
	UseAdditionalMutatedSecondBestGenome = false;
	UseAdditionalBestGenomesChild = false;

	RandomGenomesChildCounter = 0;

	for (int32_t i = 0; i < constNumOfRandomGenomesChildren; i++)
		UseAdditionalRandomGenomesChild[i] = false;

	delete[] pFitnessScoreArray;
	pFitnessScoreArray = nullptr;

	delete[] ppGenomeArray;
	ppGenomeArray = nullptr;

	//populationSize = max(populationSize, constNumOfAdditionalGenomes + 10);
	PopulationSizePlusX = populationSize;
	PopulationSize = PopulationSizePlusX - constNumOfAdditionalGenomes;

	pFitnessScoreArray = new (std::nothrow) float[PopulationSizePlusX];
	ppGenomeArray = new (std::nothrow) void*[PopulationSizePlusX];

	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFitnessScoreArray[i] = 0.0f;
		ppGenomeArray[i] = nullptr;
	}

	if (populationSize < minPopulationSize)
		return false;

	return true;
}

void CGeneralPopulation::Set_Genome(void *pInGenome, int32_t id)
{
	ppGenomeArray[id] = pInGenome;
}

void* CGeneralPopulation::Get_Best_Evolved_Genome(void)
{
	return ppGenomeArray[IDArrayOfBestFittedGenomes[0]];
}

void CGeneralPopulation::Get_Best_Evolved_Genome(void *pOutGenome)
{
	GenomeValueCloningFunc(pOutGenome, ppGenomeArray[IDArrayOfBestFittedGenomes[0]]);
}

void CGeneralPopulation::Reset_Population(void)
{
	for (int32_t i = 0; i < constNumOfBestFittedGenomes; i++)
	{
		IDArrayOfBestFittedGenomes[i] = 0;
		FitnessArrayOfBestFittedGenomes[i] = 0.0f;
	}

	for (int32_t i = 0; i < constNumOfWorstFittedGenomes; i++)
	{
		IDArrayOfWorstFittedGenomes[i] = 0;
		FitnessArrayOfWorstFittedGenomes[i] = 0.0f;
	}

	UseAdditionalMutatedBestGenome = false;
	UseAdditionalMutatedSecondBestGenome = false;
	UseAdditionalBestGenomesChild = false;

	RandomGenomesChildCounter = 0;

	for (int32_t i = 0; i < constNumOfRandomGenomesChildren; i++)
		UseAdditionalRandomGenomesChild[i] = false;


	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFitnessScoreArray[i] = 0.0f;
	}
}

void CGeneralPopulation::Reset_MinErrorSum_ActualGeneration(float value)
{
	MinErrorSum_LastGeneration = MinErrorSum_ActualGeneration;
	MinErrorSum_ActualGeneration = value;
}

void CGeneralPopulation::Update_MinErrorSum_ActualGeneration(float value)
{
	if (value < MinErrorSum_ActualGeneration)
		MinErrorSum_ActualGeneration = value;
}

void CGeneralPopulation::Calculate_FitnessScore_FromError(int32_t genomeID, float error)
{
	pFitnessScoreArray[genomeID] = 1.0f / (error + 0.01f);
}

void CGeneralPopulation::Set_FitnessScore(int32_t genomeID, float score)
{
	pFitnessScoreArray[genomeID] = score;
}

void CGeneralPopulation::Update_Population(void)
{
	for (int32_t i = 0; i < constNumOfBestFittedGenomes; i++)
	{
		IDArrayOfBestFittedGenomes[i] = 0;
		FitnessArrayOfBestFittedGenomes[i] = -100000000.0f;
	}

	for (int32_t i = 0; i < constNumOfWorstFittedGenomes; i++)
	{
		IDArrayOfWorstFittedGenomes[i] = 0;
		FitnessArrayOfWorstFittedGenomes[i] = 100000000.0f;
	}

	for (int32_t i = 0; i < PopulationSize; i++)
	{
		for (int32_t j = 0; j < constNumOfBestFittedGenomes; j++)
		{
			if (pFitnessScoreArray[i] > FitnessArrayOfBestFittedGenomes[j])
			{
				for (uint32_t k = constNumOfBestFittedGenomes - 1; k > j; k--)
				{
					IDArrayOfBestFittedGenomes[k] = IDArrayOfBestFittedGenomes[k - 1];
					FitnessArrayOfBestFittedGenomes[k] = FitnessArrayOfBestFittedGenomes[k - 1];
				}

				FitnessArrayOfBestFittedGenomes[j] = pFitnessScoreArray[i];
				IDArrayOfBestFittedGenomes[j] = i;

				break;
			}
		}

		for (int32_t j = 0; j < constNumOfWorstFittedGenomes; j++)
		{
			if (pFitnessScoreArray[i] < FitnessArrayOfWorstFittedGenomes[j])
			{
				for (int32_t k = constNumOfWorstFittedGenomes - 1; k > j; k--)
				{
					IDArrayOfWorstFittedGenomes[k] = IDArrayOfWorstFittedGenomes[k - 1];
					FitnessArrayOfWorstFittedGenomes[k] = FitnessArrayOfWorstFittedGenomes[k - 1];
				}

				FitnessArrayOfWorstFittedGenomes[j] = pFitnessScoreArray[i];
				IDArrayOfWorstFittedGenomes[j] = i;

				break;
			}
		}

	} // end of for (int32_t i = 0; i < PopulationSize; i++)



	float fitnessScoreOfBestFittedAdditionalGenome = -1000000.0f;
	int32_t idOfBestFittedAdditionalGenome = 0;

	for (int32_t i = 0; i < constNumOfAdditionalGenomes; i++)
	{
		if (pFitnessScoreArray[PopulationSize + i] > fitnessScoreOfBestFittedAdditionalGenome)
		{
			fitnessScoreOfBestFittedAdditionalGenome = pFitnessScoreArray[PopulationSize + i];
			idOfBestFittedAdditionalGenome = PopulationSize + i;
		}
	}

	if (pFitnessScoreArray[idOfBestFittedAdditionalGenome] > pFitnessScoreArray[IDArrayOfBestFittedGenomes[0]])
	{
		GenomeValueCloningFunc(ppGenomeArray[IDArrayOfBestFittedGenomes[0]], ppGenomeArray[idOfBestFittedAdditionalGenome]);
	}
	else if (pFitnessScoreArray[idOfBestFittedAdditionalGenome] > pFitnessScoreArray[IDArrayOfBestFittedGenomes[1]])
	{
		GenomeValueCloningFunc(ppGenomeArray[IDArrayOfBestFittedGenomes[1]], ppGenomeArray[idOfBestFittedAdditionalGenome]);
	}
	else if (pFitnessScoreArray[idOfBestFittedAdditionalGenome] > pFitnessScoreArray[IDArrayOfBestFittedGenomes[2]])
	{
		GenomeValueCloningFunc(ppGenomeArray[IDArrayOfBestFittedGenomes[2]], ppGenomeArray[idOfBestFittedAdditionalGenome]);
	}

	UseAdditionalMutatedBestGenome = false;
	UseAdditionalMutatedSecondBestGenome = false;
	UseAdditionalBestGenomesChild = false;

	RandomGenomesChildCounter = 0;

	for (int32_t i = 0; i < constNumOfRandomGenomesChildren; i++)
		UseAdditionalRandomGenomesChild[i] = false;
}

void CGeneralPopulation::Update_Population_Ext(void)
{
	for (int32_t i = 0; i < constNumOfBestFittedGenomes; i++)
	{
		IDArrayOfBestFittedGenomes[i] = 0;
		FitnessArrayOfBestFittedGenomes[i] = -100000000.0f;
	}

	for (int32_t i = 0; i < constNumOfWorstFittedGenomes; i++)
	{
		IDArrayOfWorstFittedGenomes[i] = 0;
		FitnessArrayOfWorstFittedGenomes[i] = 100000000.0f;
	}

	for (int32_t i = 0; i < PopulationSize; i++)
	{
		for (int32_t j = 0; j < constNumOfBestFittedGenomes; j++)
		{
			if (pFitnessScoreArray[i] > FitnessArrayOfBestFittedGenomes[j])
			{
				for (uint32_t k = constNumOfBestFittedGenomes - 1; k > j; k--)
				{
					IDArrayOfBestFittedGenomes[k] = IDArrayOfBestFittedGenomes[k - 1];
					FitnessArrayOfBestFittedGenomes[k] = FitnessArrayOfBestFittedGenomes[k - 1];
				}

				FitnessArrayOfBestFittedGenomes[j] = pFitnessScoreArray[i];
				IDArrayOfBestFittedGenomes[j] = i;

				break;
			}
		}

		for (int32_t j = 0; j < constNumOfWorstFittedGenomes; j++)
		{
			if (pFitnessScoreArray[i] < FitnessArrayOfWorstFittedGenomes[j])
			{
				for (int32_t k = constNumOfWorstFittedGenomes - 1; k > j; k--)
				{
					IDArrayOfWorstFittedGenomes[k] = IDArrayOfWorstFittedGenomes[k - 1];
					FitnessArrayOfWorstFittedGenomes[k] = FitnessArrayOfWorstFittedGenomes[k - 1];
				}

				FitnessArrayOfWorstFittedGenomes[j] = pFitnessScoreArray[i];
				IDArrayOfWorstFittedGenomes[j] = i;

				break;
			}
		}

	} // end of for (int32_t i = 0; i < PopulationSize; i++)




	float fitnessScoreOfBestFittedAdditionalGenome = -1000000.0f;
	int32_t idOfBestFittedAdditionalGenome = 0;

	for (int32_t i = 0; i < constNumOfAdditionalGenomes; i++)
	{
		if (pFitnessScoreArray[PopulationSize + i] > fitnessScoreOfBestFittedAdditionalGenome)
		{
			fitnessScoreOfBestFittedAdditionalGenome = pFitnessScoreArray[PopulationSize + i];
			idOfBestFittedAdditionalGenome = PopulationSize + i;
		}
	}

	for (int32_t i = constNumOfBestFittedGenomes - 1; i > -1; i--)
	{
		if (pFitnessScoreArray[idOfBestFittedAdditionalGenome] > pFitnessScoreArray[IDArrayOfBestFittedGenomes[i]])
		{
			GenomeValueCloningFunc(ppGenomeArray[IDArrayOfBestFittedGenomes[i]], ppGenomeArray[idOfBestFittedAdditionalGenome]);
			break;
		}
	}



	UseAdditionalMutatedBestGenome = false;
	UseAdditionalMutatedSecondBestGenome = false;
	UseAdditionalBestGenomesChild = false;

	RandomGenomesChildCounter = 0;

	for (int32_t i = 0; i < constNumOfRandomGenomesChildren; i++)
		UseAdditionalRandomGenomesChild[i] = false;
}

void CGeneralPopulation::Update_PopulationKnowledge(void)
{
	void *pBestGenome = ppGenomeArray[IDArrayOfBestFittedGenomes[0]];

	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		GenomeValueCloningFunc(ppGenomeArray[i], pBestGenome);
	}
}

void CGeneralPopulation::Update_Evolution_Combine_BestTwoGenomes(pGeneralRecombination pFunc, void *pParam)
{
	if (UseAdditionalBestGenomesChild == true)
		return;

	pFunc(ppGenomeArray[PopulationSize + 2], ppGenomeArray[IDArrayOfBestFittedGenomes[0]], ppGenomeArray[IDArrayOfBestFittedGenomes[1]], &RandomNumbers, pParam);

	UseAdditionalBestGenomesChild = true;
}



void CGeneralPopulation::Update_Evolution_Combine_BestTwoGenomes(pGeneralRecombination pFunc, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	if (UseAdditionalBestGenomesChild == true)
		return;

	pFunc(ppGenomeArray[PopulationSize + 2], ppGenomeArray[IDArrayOfBestFittedGenomes[0]], ppGenomeArray[IDArrayOfBestFittedGenomes[1]], pRandomNumbers, pParam);

	UseAdditionalBestGenomesChild = true;
}

void CGeneralPopulation::Update_Evolution_Combine_TwoGenomes(pGeneralRecombination pFunc, void *pParam)
{
	if (UseAdditionalRandomGenomesChild[RandomGenomesChildCounter] == true)
		return;

	int32_t id1, id2;

	for (int32_t i = 0; i < constNumPopulationSearchStepsMax; i++)
	{
		id1 = RandomNumbers.Get_IntegerNumber(0, PopulationSize);

		// die am schlechtesten angepassten Individuen d�rfen sich nicht vermehren:
		if (pFitnessScoreArray[id1] <= FitnessArrayOfWorstFittedGenomes[constNumOfWorstFittedGenomes - 1])
			continue;

		id2 = RandomNumbers.Get_IntegerNumber(0, PopulationSize);

		// die am schlechtesten angepassten Individuen d�rfen sich nicht vermehren:
		if (pFitnessScoreArray[id2] <= FitnessArrayOfWorstFittedGenomes[constNumOfWorstFittedGenomes - 1])
			continue;

		if (id1 == id2)
			continue;

		pFunc(ppGenomeArray[PopulationSize + 3 + RandomGenomesChildCounter], ppGenomeArray[id1], ppGenomeArray[id2], &RandomNumbers, pParam);


		UseAdditionalRandomGenomesChild[RandomGenomesChildCounter] = true;

		if (RandomGenomesChildCounter < constNumOfRandomGenomesChildren - 1)
			RandomGenomesChildCounter++;

		break;
	}
}

void CGeneralPopulation::Update_Evolution_Combine_TwoGenomes(pGeneralRecombination pFunc, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	if (UseAdditionalRandomGenomesChild[RandomGenomesChildCounter] == true)
		return;

	int32_t id1, id2;

	for (int32_t i = 0; i < constNumPopulationSearchStepsMax; i++)
	{
		id1 = pRandomNumbers->Get_IntegerNumber(0, PopulationSize);

		// die am schlechtesten angepassten Individuen d�rfen sich nicht vermehren:
		if (pFitnessScoreArray[id1] <= FitnessArrayOfWorstFittedGenomes[constNumOfWorstFittedGenomes - 1])
			continue;

		id2 = pRandomNumbers->Get_IntegerNumber(0, PopulationSize);

		// die am schlechtesten angepassten Individuen d�rfen sich nicht vermehren:
		if (pFitnessScoreArray[id2] <= FitnessArrayOfWorstFittedGenomes[constNumOfWorstFittedGenomes - 1])
			continue;

		if (id1 == id2)
			continue;

		pFunc(ppGenomeArray[PopulationSize + 3 + RandomGenomesChildCounter], ppGenomeArray[id1], ppGenomeArray[id2], pRandomNumbers, pParam);


		UseAdditionalRandomGenomesChild[RandomGenomesChildCounter] = true;

		if (RandomGenomesChildCounter < constNumOfRandomGenomesChildren - 1)
			RandomGenomesChildCounter++;

		break;
	}
}

void CGeneralPopulation::Update_Evolution_GenomeInterchange(pGeneralInterchange pFunc, void *pParam)
{
	int32_t id1, id2;

	for (int32_t i = 0; i < constNumPopulationSearchStepsMax; i++)
	{
		id1 = RandomNumbers.Get_IntegerNumber(0, PopulationSize);

		// die am schlechtesten angepassten Individuen werden nicht ber�cksichtigt:
		//if (pFitnessScoreArray[id1] <= FitnessArrayOfWorstFittedGenomes[constNumOfWorstFittedGenomes - 1])
			//continue;

		id2 = RandomNumbers.Get_IntegerNumber(0, PopulationSize);

		// die am schlechtesten angepassten Individuen werden nicht ber�cksichtigt:
		//if (pFitnessScoreArray[id2] <= FitnessArrayOfWorstFittedGenomes[constNumOfWorstFittedGenomes - 1])
			//continue;

		if (id1 == id2)
			continue;

		pFunc(ppGenomeArray[id1], ppGenomeArray[id2], &RandomNumbers, pParam);

		break;
	}
}

void CGeneralPopulation::Update_Evolution_GenomeInterchange(pGeneralInterchange pFunc, void *pInOutGlobalGenome, void *pParam)
{
	int32_t id;

	for (int32_t i = 0; i < constNumPopulationSearchStepsMax; i++)
	{
		id = RandomNumbers.Get_IntegerNumber(0, PopulationSize);

		// die am schlechtesten angepassten Individuen werden nicht ber�cksichtigt:
		//if (pFitnessScoreArray[id1] <= FitnessArrayOfWorstFittedGenomes[constNumOfWorstFittedGenomes - 1])
		//continue;

		pFunc(ppGenomeArray[id], pInOutGlobalGenome, &RandomNumbers, pParam);

		break;
	}
}

void CGeneralPopulation::Update_Evolution_GenomeInterchange(pGeneralInterchange pFunc, void *pInOutGlobalGenome, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	int32_t id;

	for (int32_t i = 0; i < constNumPopulationSearchStepsMax; i++)
	{
		id = RandomNumbers.Get_IntegerNumber(0, PopulationSize);

		// die am schlechtesten angepassten Individuen werden nicht ber�cksichtigt:
		//if (pFitnessScoreArray[id1] <= FitnessArrayOfWorstFittedGenomes[constNumOfWorstFittedGenomes - 1])
		//continue;

		pFunc(ppGenomeArray[id], pInOutGlobalGenome, pRandomNumbers, pParam);

		break;
	}
}

void CGeneralPopulation::Update_Evolution_GenomeInterchange(pGeneralInterchange pFunc, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	int32_t id1, id2;

	for (int32_t i = 0; i < constNumPopulationSearchStepsMax; i++)
	{
		id1 = RandomNumbers.Get_IntegerNumber(0, PopulationSize);

		// die am schlechtesten angepassten Individuen werden nicht ber�cksichtigt:
		//if (pFitnessScoreArray[id1] <= FitnessArrayOfWorstFittedGenomes[constNumOfWorstFittedGenomes - 1])
		//continue;

		id2 = RandomNumbers.Get_IntegerNumber(0, PopulationSize);

		// die am schlechtesten angepassten Individuen werden nicht ber�cksichtigt:
		//if (pFitnessScoreArray[id2] <= FitnessArrayOfWorstFittedGenomes[constNumOfWorstFittedGenomes - 1])
		//continue;

		if (id1 == id2)
			continue;

		pFunc(ppGenomeArray[id1], ppGenomeArray[id2], pRandomNumbers, pParam);

		break;
	}
}

void CGeneralPopulation::Update_BaseEvolution(pGeneralMutation pFunc, void *pParam)
{
	for (int32_t i = 0; i < PopulationSize; i++)
	{
		if (i == IDArrayOfBestFittedGenomes[0]) // best fitted
		{
			continue;
		}

		if (i == IDArrayOfBestFittedGenomes[1]) // second best fitted
		{
			continue;
		}

		pFunc(ppGenomeArray[i], &RandomNumbers, pParam);
	}

	/*bool bestFittedGenomes;

	for (int32_t i = 0; i < PopulationSize; i++)
	{
		bestFittedGenomes = false;

		for (int32_t j = 0; j < constNumOfBestFittedGenomes; j++)
		{
			if (i == IDArrayOfBestFittedGenomes[j])
			{
				bestFittedGenomes = true;
				break;
			}
		}

		if (bestFittedGenomes == false)
		{
			pFunc(ppGenomeArray[i], &RandomNumbers, pParam);
		}
	}*/
}

void CGeneralPopulation::Update_BaseEvolution(pGeneralMutation pFunc, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	for (int32_t i = 0; i < PopulationSize; i++)
	{
		if (i == IDArrayOfBestFittedGenomes[0]) // best fitted
		{
			continue;
		}

		if (i == IDArrayOfBestFittedGenomes[1]) // second best fitted
		{
			continue;
		}

		pFunc(ppGenomeArray[i], pRandomNumbers, pParam);
	}

	/*bool bestFittedGenomes;

	for (int32_t i = 0; i < PopulationSize; i++)
	{
		bestFittedGenomes = false;

		for (int32_t j = 0; j < constNumOfBestFittedGenomes; j++)
		{
			if (i == IDArrayOfBestFittedGenomes[j])
			{
				bestFittedGenomes = true;
				break;
			}
		}

		if (bestFittedGenomes == false)
		{
			pFunc(ppGenomeArray[i], pRandomNumbers, pParam);
		}
	}*/
}

void CGeneralPopulation::Update_BaseEvolution2(pGeneralPermutation pFunc, void *pParam)
{
	for (int32_t i = 0; i < PopulationSize; i++)
	{
		if (i == IDArrayOfBestFittedGenomes[0]) // best fitted
		{
			continue;
		}

		if (i == IDArrayOfBestFittedGenomes[1]) // second best fitted
		{
			continue;
		}

		pFunc(ppGenomeArray[i], &RandomNumbers, pParam);
	}

	/*bool bestFittedGenomes;

	for (int32_t i = 0; i < PopulationSize; i++)
	{
		bestFittedGenomes = false;

		for (int32_t j = 0; j < constNumOfBestFittedGenomes; j++)
		{
			if (i == IDArrayOfBestFittedGenomes[j])
			{
				bestFittedGenomes = true;
				break;
			}
		}

		if (bestFittedGenomes == false)
		{
			pFunc(ppGenomeArray[i], &RandomNumbers, pParam);
		}
	}*/
}

void CGeneralPopulation::Update_BaseEvolution2(pGeneralPermutation pFunc, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	for (int32_t i = 0; i < PopulationSize; i++)
	{
		if (i == IDArrayOfBestFittedGenomes[0]) // best fitted
		{
			continue;
		}

		if (i == IDArrayOfBestFittedGenomes[1]) // second best fitted
		{
			continue;
		}

		pFunc(ppGenomeArray[i], pRandomNumbers, pParam);
	}

	/*bool bestFittedGenomes;

	for (int32_t i = 0; i < PopulationSize; i++)
	{
		bestFittedGenomes = false;

		for (int32_t j = 0; j < constNumOfBestFittedGenomes; j++)
		{
			if (i == IDArrayOfBestFittedGenomes[j])
			{
				bestFittedGenomes = true;
				break;
			}
		}

		if (bestFittedGenomes == false)
		{
			pFunc(ppGenomeArray[i], pRandomNumbers, pParam);
		}
	}*/
}

void CGeneralPopulation::Update_Evolution_BestGenomeOnly(pGeneralMutation pFunc, void *pParam)
{
	if (UseAdditionalMutatedBestGenome == true)
		return;

	GenomeValueCloningFunc(ppGenomeArray[PopulationSize], ppGenomeArray[IDArrayOfBestFittedGenomes[0]]);

	pFunc(ppGenomeArray[PopulationSize], &RandomNumbers, pParam);

	UseAdditionalMutatedBestGenome = true;
}

void CGeneralPopulation::Update_Evolution_BestGenomeOnly(pGeneralMutation pFunc, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	if (UseAdditionalMutatedBestGenome == true)
		return;

	GenomeValueCloningFunc(ppGenomeArray[PopulationSize], ppGenomeArray[IDArrayOfBestFittedGenomes[0]]);

	pFunc(ppGenomeArray[PopulationSize], pRandomNumbers, pParam);

	UseAdditionalMutatedBestGenome = true;
}

void CGeneralPopulation::Update_Evolution_BestGenomeOnly2(pGeneralPermutation pFunc, void *pParam)
{
	if (UseAdditionalMutatedBestGenome == true)
		return;


	GenomeValueCloningFunc(ppGenomeArray[PopulationSize], ppGenomeArray[IDArrayOfBestFittedGenomes[0]]);

	pFunc(ppGenomeArray[PopulationSize], &RandomNumbers, pParam);

	UseAdditionalMutatedBestGenome = true;
}

void CGeneralPopulation::Update_Evolution_BestGenomeOnly2(pGeneralPermutation pFunc, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	if (UseAdditionalMutatedBestGenome == true)
		return;


	GenomeValueCloningFunc(ppGenomeArray[PopulationSize], ppGenomeArray[IDArrayOfBestFittedGenomes[0]]);

	pFunc(ppGenomeArray[PopulationSize], pRandomNumbers, pParam);

	UseAdditionalMutatedBestGenome = true;
}

void CGeneralPopulation::Update_Evolution_SecondBestGenomeOnly(pGeneralMutation pFunc, void *pParam)
{
	if (UseAdditionalMutatedSecondBestGenome == true)
		return;

	GenomeValueCloningFunc(ppGenomeArray[PopulationSize + 1], ppGenomeArray[IDArrayOfBestFittedGenomes[1]]);

	pFunc(ppGenomeArray[PopulationSize + 1], &RandomNumbers, pParam);

	UseAdditionalMutatedSecondBestGenome = true;
}

void CGeneralPopulation::Update_Evolution_SecondBestGenomeOnly(pGeneralMutation pFunc, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	if (UseAdditionalMutatedSecondBestGenome == true)
		return;

	GenomeValueCloningFunc(ppGenomeArray[PopulationSize + 1], ppGenomeArray[IDArrayOfBestFittedGenomes[1]]);

	pFunc(ppGenomeArray[PopulationSize + 1], pRandomNumbers, pParam);

	UseAdditionalMutatedSecondBestGenome = true;
}

void CGeneralPopulation::Update_Evolution_SecondBestGenomeOnly2(pGeneralPermutation pFunc, void *pParam)
{
	if (UseAdditionalMutatedSecondBestGenome == true)
		return;

	GenomeValueCloningFunc(ppGenomeArray[PopulationSize + 1], ppGenomeArray[IDArrayOfBestFittedGenomes[1]]);

	pFunc(ppGenomeArray[PopulationSize + 1], &RandomNumbers, pParam);

	UseAdditionalMutatedSecondBestGenome = true;
}

void CGeneralPopulation::Update_Evolution_SecondBestGenomeOnly2(pGeneralPermutation pFunc, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	if (UseAdditionalMutatedSecondBestGenome == true)
		return;

	GenomeValueCloningFunc(ppGenomeArray[PopulationSize + 1], ppGenomeArray[IDArrayOfBestFittedGenomes[1]]);

	pFunc(ppGenomeArray[PopulationSize + 1], pRandomNumbers, pParam);

	UseAdditionalMutatedSecondBestGenome = true;
}

void CGeneralPopulation::Transform_Species_If_Possible_BestGenomeOnly(pGeneralSpeciesTransformation pFunc, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	pFunc(ppGenomeArray[IDArrayOfBestFittedGenomes[0]], pRandomNumbers, pParam);
}

void CGeneralPopulation::Transform_Species_If_Possible_BestGenomeOnly(pGeneralSpeciesTransformation pFunc, void *pParam)
{
	pFunc(ppGenomeArray[IDArrayOfBestFittedGenomes[0]], &RandomNumbers, pParam);
}


void CGeneralPopulation::Replace_WorstFitted_Genome(pGeneralReinitialization pFunc, void *pParam)
{
	pFunc(ppGenomeArray[IDArrayOfWorstFittedGenomes[0]], &RandomNumbers, pParam);
}

void CGeneralPopulation::Replace_WorstFitted_Genome(pGeneralReinitialization2 pFunc, void *pInBaseGenome, void *pParam)
{
	pFunc(ppGenomeArray[IDArrayOfWorstFittedGenomes[0]], pInBaseGenome, &RandomNumbers, pParam);
}

void CGeneralPopulation::Replace_WorstFitted_Genome(pGeneralReinitialization pFunc, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	pFunc(ppGenomeArray[IDArrayOfWorstFittedGenomes[0]], pRandomNumbers, pParam);
}

void CGeneralPopulation::Replace_WorstFitted_Genome(pGeneralReinitialization2 pFunc, void *pInBaseGenome, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	pFunc(ppGenomeArray[IDArrayOfWorstFittedGenomes[0]], pInBaseGenome, pRandomNumbers, pParam);
}

void CGeneralPopulation::Replace_SecondWorstFitted_Genome(pGeneralReinitialization pFunc, void *pParam)
{
	pFunc(ppGenomeArray[IDArrayOfWorstFittedGenomes[1]], &RandomNumbers, pParam);
}

void CGeneralPopulation::Replace_SecondWorstFitted_Genome(pGeneralReinitialization2 pFunc, void *pInBaseGenome, void *pParam)
{
	pFunc(ppGenomeArray[IDArrayOfWorstFittedGenomes[1]], pInBaseGenome, &RandomNumbers, pParam);
}

void CGeneralPopulation::Replace_SecondWorstFitted_Genome(pGeneralReinitialization pFunc, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	pFunc(ppGenomeArray[IDArrayOfWorstFittedGenomes[1]], pRandomNumbers, pParam);
}

void CGeneralPopulation::Replace_SecondWorstFitted_Genome(pGeneralReinitialization2 pFunc, void *pInBaseGenome, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	pFunc(ppGenomeArray[IDArrayOfWorstFittedGenomes[1]], pInBaseGenome, pRandomNumbers, pParam);
}

void CGeneralPopulation::Replace_ThirdWorstFitted_Genome(pGeneralReinitialization pFunc, void *pParam)
{
	pFunc(ppGenomeArray[IDArrayOfWorstFittedGenomes[2]], &RandomNumbers, pParam);
}

void CGeneralPopulation::Replace_ThirdWorstFitted_Genome(pGeneralReinitialization2 pFunc, void *pInBaseGenome, void *pParam)
{
	pFunc(ppGenomeArray[IDArrayOfWorstFittedGenomes[2]], pInBaseGenome, &RandomNumbers, pParam);
}

void CGeneralPopulation::Replace_ThirdWorstFitted_Genome(pGeneralReinitialization pFunc, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	pFunc(ppGenomeArray[IDArrayOfWorstFittedGenomes[2]], pRandomNumbers, pParam);
}

void CGeneralPopulation::Replace_ThirdWorstFitted_Genome(pGeneralReinitialization2 pFunc, void *pInBaseGenome, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	pFunc(ppGenomeArray[IDArrayOfWorstFittedGenomes[2]], pInBaseGenome, pRandomNumbers, pParam);
}


void CGeneralPopulation::Modify_All_Genomes(pGeneralMutation pFunc, void *pParam)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFunc(ppGenomeArray[i], &RandomNumbers, pParam);
	}
}

void CGeneralPopulation::Modify_All_Genomes(pGeneralMutation pFunc, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFunc(ppGenomeArray[i], pRandomNumbers, pParam);
	}
}

void CGeneralPopulation::Modify_All_Genomes2(pGeneralPermutation pFunc, void *pParam)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFunc(ppGenomeArray[i], &RandomNumbers, pParam);
	}
}

void CGeneralPopulation::Modify_All_Genomes2(pGeneralPermutation pFunc, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFunc(ppGenomeArray[i], pRandomNumbers, pParam);
	}
}
