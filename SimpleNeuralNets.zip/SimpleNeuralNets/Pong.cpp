#include <iostream>
#include "Pong.h"

using namespace std;



#define KEYDOWN(vk_code) ((GetAsyncKeyState(vk_code) & 0x8000) ? 1 : 0)
#define KEYUP(vk_code)   ((GetAsyncKeyState(vk_code) & 0x8000) ? 0 : 1)

uint8_t g_GameBoard[ConstGameBoardSizeY][ConstGameBoardSizeX];
float g_fGameBoard[ConstGameBoardSizeY][ConstGameBoardSizeX];



/*
void Init_Or_Reset_GameBoardArray(uint8_t *pGameBoard, int32_t gameBoardSizeX, int32_t gameBoardSizeY, uint8_t emptyValue = ConstGameBoard_EmptyElement)
{
	int32_t counter = 0;

	int32_t gameBoardSizeXY = gameBoardSizeX * gameBoardSizeY;

	for (int32_t i = 0; i < gameBoardSizeXY; i++)
	{
		pGameBoard[counter] = emptyValue;
		counter++;
	}
}
*/

/*
void Init_Or_Reset_fGameBoardArray(float *pGameBoard, int32_t gameBoardSizeX, int32_t gameBoardSizeY, float emptyValue)
{
	int32_t counter = 0;

	int32_t gameBoardSizeXY = gameBoardSizeX * gameBoardSizeY;

	for (int32_t i = 0; i < gameBoardSizeXY; i++)
	{
		pGameBoard[counter] = emptyValue;
		counter++;
	}
}
*/

void Init_Or_Reset_fGameBoardArray(float emptyValue = fConstGameBoard_EmptyElement)
{
	for (uint32_t iy = 0; iy < ConstGameBoardSizeY; iy++)
	{
		for (uint32_t ix = 0; ix < ConstGameBoardSizeX; ix++)
		{
			g_fGameBoard[iy][ix] = emptyValue;
		}
	}
}

/*
void Init_GameBoardBorders(uint8_t *pGameBoard, int32_t gameBoardSizeX, int32_t gameBoardSizeY, uint8_t borderValue = ConstGameBoard_BorderElement)
{
	int32_t gameBoardSizeYMinus1 = gameBoardSizeY - 1;
	int32_t gameBoardSizeXMinus1 = gameBoardSizeX - 1;

	int32_t counter = 0;

	for (int32_t iy = 0; iy < gameBoardSizeY; iy++)
	{
		if (iy == 0 || iy == gameBoardSizeYMinus1)
		{
			for (int32_t ix = 0; ix < gameBoardSizeX; ix++)
			{
				pGameBoard[counter] = borderValue;
			}
		}
		else
		{
			for (int32_t ix = 0; ix < gameBoardSizeX; ix++)
			{
				if (ix == 0 || ix == gameBoardSizeXMinus1)
				{
					pGameBoard[counter] = borderValue;
				}
			}
		}

		counter++;
	}
}
*/

/*
void Init_fGameBoardBorders(float *pGameBoard, int32_t gameBoardSizeX, int32_t gameBoardSizeY, float borderValue)
{
	int32_t gameBoardSizeYMinus1 = gameBoardSizeY - 1;
	int32_t gameBoardSizeXMinus1 = gameBoardSizeX - 1;

	int32_t counter = 0;

	for (int32_t iy = 0; iy < gameBoardSizeY; iy++)
	{
		if (iy == 0 || iy == gameBoardSizeYMinus1)
		{
			for (int32_t ix = 0; ix < gameBoardSizeX; ix++)
			{
				pGameBoard[counter] = borderValue;
			}
		}
		else
		{
			for (int32_t ix = 0; ix < gameBoardSizeX; ix++)
			{
				if (ix == 0 || ix == gameBoardSizeXMinus1)
				{
					pGameBoard[counter] = borderValue;
				}
			}
		}

		counter++;
	}
}
*/

CBall::CBall()
{
	PosX = -10.0f;
	PosY = -10.0f;
	LastPosX = -10.0f;
	LastPosY = -10.0f;
	VelocityX = VelocityY = 0.0f;
}

CBall::CBall(float maxPlayBallSpeed)
{
	PosX = -10.0f;
	PosY = -10.0f;
	LastPosX = -10.0f;
	LastPosY = -10.0f;
	VelocityX = VelocityY = 0.0f;

	MaxPlayBallSpeed = maxPlayBallSpeed;
	//MaxPlayBallSpeed = max(1.0, maxPlayBallSpeed);
}

void CBall::Initialize(float maxPlayBallSpeed)
{
	PosX = -10.0f;
	PosY = -10.0f;
	LastPosX = -10.0f;
	LastPosY = -10.0f;
	VelocityX = VelocityY = 0.0f;

	MaxPlayBallSpeed = maxPlayBallSpeed;
	//MaxPlayBallSpeed = max(1.0, maxPlayBallSpeed);
}

CBall::CBall(int32_t posX, int32_t posY)
{
	PosX = static_cast<float>(posX);
	PosY = static_cast<float>(posY);
	LastPosX = PosX;
	LastPosY = PosY;
	VelocityX = VelocityY = 0.0f;
}

void CBall::Initialize(int32_t posX, int32_t posY)
{
	PosX = static_cast<float>(posX);
	PosY = static_cast<float>(posY);
	LastPosX = PosX;
	LastPosY = PosY;
	VelocityX = VelocityY = 0.0f;
}

CBall::CBall(int32_t posX, int32_t posY, float maxPlayBallSpeed)
{
	PosX = static_cast<float>(posX);
	PosY = static_cast<float>(posY);
	LastPosX = PosX;
	LastPosY = PosY;
	VelocityX = VelocityY = 0.0f;

	MaxPlayBallSpeed = maxPlayBallSpeed;
	//MaxPlayBallSpeed = max(1.0, maxPlayBallSpeed);
}

void CBall::Initialize(int32_t posX, int32_t posY, float maxPlayBallSpeed)
{
	PosX = static_cast<float>(posX);
	PosY = static_cast<float>(posY);
	LastPosX = PosX;
	LastPosY = PosY;
	VelocityX = VelocityY = 0.0f;

	MaxPlayBallSpeed = maxPlayBallSpeed;
	//MaxPlayBallSpeed = max(1.0, maxPlayBallSpeed);
}

CBall::~CBall()
{}

void CBall::Set_Pos(float x, float y)
{
	if (LastPosX != -10.0f || LastPosY == -10.0f)
	{
		// Alte Daten aus g_GameBoard l�schen:

		int32_t ix = static_cast<int32_t>(LastPosX);
		int32_t iy = static_cast<int32_t>(LastPosY);

		g_GameBoard[iy][ix] = ConstGameBoard_EmptyElement;
		g_fGameBoard[iy][ix] = fConstGameBoard_EmptyElement;
	}

	PosX = x;
	PosY = y;
	LastPosX = x;
	LastPosY = y;
}

void CBall::Set_Velocity(float velX, float velY)
{
	VelocityX = velX;
	VelocityY = velY;
}

void CBall::Movement(void)
{
	if (VelocityX < -MaxPlayBallSpeed)
		VelocityX = -MaxPlayBallSpeed;

	else if (VelocityX > MaxPlayBallSpeed)
		VelocityX = MaxPlayBallSpeed;

	PosX += VelocityX;
	PosY += VelocityY;
}

void CBall::Handle_Possible_WallCollisions(void)
{
	if (PosX <= 1.0f)
	{
		VelocityX *= -1.0f;
		PosX = 1.0f;
	}
	else if (PosX >= fConstGameBoardSizeXMinus2)
	{
		VelocityX *= -1.0f;
		PosX = fConstGameBoardSizeXMinus2;
	}
}

bool CBall::Check_Possible_UpperWallCollision(void)
{
	if (PosY < 1.0f)
		return true;

	return false;
}

bool CBall::Check_Possible_LowerWallCollision(void)
{
	if (PosY > fConstGameBoardSizeYMinus1)
		return true;

	return false;
}

void CBall::DrawIntoBuffer(uint8_t *pGameBoard, int32_t gameBoardSizeX, int32_t gameBoardSizeY)
{
	// Alte Daten aus GameBoard l�schen:

	int32_t ix = static_cast<int32_t>(LastPosX);
	int32_t iy = static_cast<int32_t>(LastPosY);

	pGameBoard[ix + iy * gameBoardSizeX] = ConstGameBoard_EmptyElement;

	// Neue Daten in g_GameBoard eintragen:

	ix = static_cast<int32_t>(PosX);
	iy = static_cast<int32_t>(PosY);

	pGameBoard[ix + iy * gameBoardSizeX] = ConstGameBoard_Ball;

	LastPosX = PosX;
	LastPosY = PosY;
}

void CBall::fDrawIntoBuffer(float *pGameBoard, int32_t gameBoardSizeX, int32_t gameBoardSizeY)
{
	// Neue Daten eintragen:

	int32_t ix = static_cast<int32_t>(PosX);
	int32_t iy = static_cast<int32_t>(PosY);

	pGameBoard[ix + iy * gameBoardSizeX] = fConstGameBoard_Ball;
}

void CBall::DrawIntoBuffer(void)
{
	// Alte Daten aus g_GameBoard l�schen:

	int32_t ix = static_cast<int32_t>(LastPosX);
	int32_t iy = static_cast<int32_t>(LastPosY);

	g_GameBoard[iy][ix] = ConstGameBoard_EmptyElement;

	// Neue Daten in g_GameBoard eintragen:

	ix = static_cast<int32_t>(PosX);
	iy = static_cast<int32_t>(PosY);

	g_GameBoard[iy][ix] = ConstGameBoard_Ball;

	LastPosX = PosX;
	LastPosY = PosY;
}

void CBall::fDrawIntoBuffer(void)
{
	// Neue Daten eintragen:

	int32_t ix = static_cast<int32_t>(PosX);
	int32_t iy = static_cast<int32_t>(PosY);

	g_fGameBoard[iy][ix] = fConstGameBoard_Ball;
}



CPaddle::CPaddle()
{}

CPaddle::CPaddle(int32_t horizontalHalfSize)
{
	horizontalHalfSize = max(3, horizontalHalfSize);

	PosX = -10.0f;
	PosY = -10.0f;
	LastPosX = -10.0f;
	LastPosY = -10.0f;
	VelocityX = 0.0f;
	LastVelocityX = 0.0f;
	HalfSizeX = horizontalHalfSize;
	fHalfSizeX = static_cast<float>(HalfSizeX);
	fHalfSizeXPlus1 = fHalfSizeX + 1.0f;
	fHalfSizeXPlus2 = fHalfSizeX + 2.0f;

	SizeX = 2 * HalfSizeX;
	fSizeX = static_cast<float>(SizeX);

	fSizeXPlus1 = 1.0f + fSizeX;
}

void CPaddle::Initialize(int32_t horizontalHalfSize)
{
	horizontalHalfSize = max(3, horizontalHalfSize);

	PosX = -10.0f;
	PosY = -10.0f;
	LastPosX = -10.0f;
	LastPosY = -10.0f;
	VelocityX = 0.0f;
	LastVelocityX = 0.0f;
	HalfSizeX = horizontalHalfSize;
	fHalfSizeX = static_cast<float>(HalfSizeX);
	fHalfSizeXPlus1 = fHalfSizeX + 1.0f;
	fHalfSizeXPlus2 = fHalfSizeX + 2.0f;
	SizeX = 2 * HalfSizeX;
	fSizeX = static_cast<float>(SizeX);

	fSizeXPlus1 = 1.0f + fSizeX;
}

CPaddle::CPaddle(int32_t posX, int32_t posY, int32_t horizontalHalfSize)
{
	horizontalHalfSize = max(3, horizontalHalfSize);

	PosX = static_cast<float>(posX);
	PosY = static_cast<float>(posY);
	LastPosX = PosX;
	LastPosY = PosY;
	VelocityX = 0.0f;
	LastVelocityX = 0.0f;
	HalfSizeX = horizontalHalfSize;
	fHalfSizeX = static_cast<float>(HalfSizeX);
	fHalfSizeXPlus1 = fHalfSizeX + 1.0f;
	fHalfSizeXPlus2 = fHalfSizeX + 2.0f;
	SizeX = 2 * HalfSizeX;
	fSizeX = static_cast<float>(SizeX);

	fSizeXPlus1 = 1.0f + fSizeX;
}

void CPaddle::Initialize(int32_t posX, int32_t posY, int32_t horizontalHalfSize)
{
	horizontalHalfSize = max(3, horizontalHalfSize);

	PosX = static_cast<float>(posX);
	PosY = static_cast<float>(posY);
	LastPosX = PosX;
	LastPosY = PosY;
	VelocityX = 0.0f;
	LastVelocityX = 0.0f;
	HalfSizeX = horizontalHalfSize;
	fHalfSizeX = static_cast<float>(HalfSizeX);
	fHalfSizeXPlus1 = fHalfSizeX + 1.0f;
	fHalfSizeXPlus2 = fHalfSizeX + 2.0f;
	SizeX = 2 * HalfSizeX;
	fSizeX = static_cast<float>(SizeX);

	fSizeXPlus1 = 1.0f + fSizeX;
}

CPaddle::~CPaddle()
{}

void CPaddle::Set_Pos(float posX, float posY)
{
	if (LastPosX != -10.0f || LastPosY == -10.0f)
	{
		// Alte Daten aus g_GameBoard l�schen:

		int32_t ixCenter = static_cast<int32_t>(LastPosX);
		int32_t iyCenter = static_cast<int32_t>(LastPosY);

		int32_t ixMin = ixCenter - HalfSizeX;
		int32_t ixMax = ixCenter + HalfSizeX + 1;

		for (int32_t i = ixMin; i < ixMax; i++)
		{
			g_GameBoard[iyCenter][i] = ConstGameBoard_EmptyElement;
			g_fGameBoard[iyCenter][i] = fConstGameBoard_EmptyElement;
		}
	}


	PosX = posX;
	PosY = posY;
	LastPosX = posX;
	LastPosY = posY;
}

void CPaddle::Set_Velocity(float velX)
{
	VelocityX = velX;
}


void CPaddle::HumanPlayer_SimpleMovement(float movementStep)
{
	if (GetAsyncKeyState(VK_LEFT))
	{
		PosX -= movementStep;
	}
	else if (GetAsyncKeyState(VK_RIGHT))
	{
		PosX += movementStep;
	}


	if (PosX < fHalfSizeXPlus1)
		PosX = fHalfSizeXPlus1;
	else if (PosX > fConstGameBoardSizeX - fHalfSizeXPlus2)
		PosX = fConstGameBoardSizeX - fHalfSizeXPlus2;
}

void CPaddle::HumanPlayer_Movement(float movementStep, float paddleDecelerationValue)
{
	LastVelocityX = VelocityX;

	if (GetAsyncKeyState(VK_LEFT))
	{
		VelocityX -= movementStep;
	}
	else if (GetAsyncKeyState(VK_RIGHT))
	{
		VelocityX += movementStep;
	}
	else
		VelocityX *= paddleDecelerationValue;

	VelocityX = min(MaxAIPlayerPaddleVelocityX, VelocityX);
	VelocityX = max(MinAIPlayerPaddleVelocityX, VelocityX);

	PosX += VelocityX;

	if (PosX < fHalfSizeXPlus1)
		PosX = fHalfSizeXPlus1;
	else if (PosX > fConstGameBoardSizeX - fHalfSizeXPlus2)
		PosX = fConstGameBoardSizeX - fHalfSizeXPlus2;
}

void CPaddle::Simple_MovementAI(CBall *pPlayBall, float paddleAccelerationValue, float paddleDecelerationValue)
{
	LastVelocityX = VelocityX;

	//Paddle in Richtung des Spielballs bewegen:

	VelocityX += paddleAccelerationValue * (pPlayBall->PosX - PosX);

	VelocityX = min(MaxAIPlayerPaddleVelocityX, VelocityX);
	VelocityX = max(MinAIPlayerPaddleVelocityX, VelocityX);
	VelocityX *= paddleDecelerationValue;

	PosX += VelocityX;

	if (PosX < fHalfSizeXPlus1)
		PosX = fHalfSizeXPlus1;
	else if (PosX > fConstGameBoardSizeX - fHalfSizeXPlus2)
		PosX = fConstGameBoardSizeX - fHalfSizeXPlus2;
}

void CPaddle::Handle_Possible_PlayBallCollision(CBall *pPlayBall, bool upperPaddle)
{
	if (pPlayBall->PosY >= PosY && pPlayBall->PosY <= PosY + 1.0f)
	{
		if (pPlayBall->PosX >= PosX - fHalfSizeX && pPlayBall->PosX <= PosX + fHalfSizeXPlus1)
		{
			pPlayBall->VelocityY *= -1.0f;
			pPlayBall->VelocityX += 0.3333f * (pPlayBall->PosX - PosX);

			if (upperPaddle == false)
				pPlayBall->PosY = PosY - 1.0f;
			else
				pPlayBall->PosY = PosY + 1.0f;

		}
	}
}

void CPaddle::DrawIntoBuffer(uint8_t *pGameBoard, int32_t gameBoardSizeX, int32_t gameBoardSizeY)
{
	// Alte Daten aus GameBoard l�schen:

	int32_t ixCenter = static_cast<int32_t>(LastPosX);
	int32_t iyCenter = static_cast<int32_t>(LastPosY);

	int32_t ixMin = ixCenter - HalfSizeX;
	int32_t ixMax = ixCenter + HalfSizeX + 1;

	iyCenter *= gameBoardSizeX;

	for (int32_t i = ixMin; i < ixMax; i++)
		pGameBoard[i + iyCenter] = ConstGameBoard_EmptyElement;
	

	// Neue Daten in g_GameBoard eintragen:

	ixCenter = static_cast<int32_t>(PosX);// -static_cast<int32_t>(HalfSizeX);
	iyCenter = static_cast<int32_t>(PosY);

	ixMin = ixCenter - HalfSizeX;
	ixMax = ixCenter + HalfSizeX + 1;

	for (int32_t i = ixMin; i < ixMax; i++)
		pGameBoard[i + iyCenter] = ConstGameBoard_PaddleElement;
	
	
	LastPosX = PosX;
	LastPosY = PosY;
}

void CPaddle::fDrawIntoBuffer(float *pGameBoard, int32_t gameBoardSizeX, int32_t gameBoardSizeY)
{
	// Neue Daten  eintragen:

	int32_t ixCenter = static_cast<int32_t>(PosX);// -static_cast<int32_t>(HalfSizeX);
	int32_t iyCenter = static_cast<int32_t>(PosY);

	//int32_t ixMin = ixCenter - HalfSizeX;
	//int32_t ixMax = ixCenter + HalfSizeX + 1;

	int32_t ixMin = ixCenter - 1;
	int32_t ixMax = ixCenter + 2;

	for (int32_t i = ixMin; i < ixMax; i++)
		pGameBoard[i + iyCenter] = fConstGameBoard_PaddleElement;
}

void CPaddle::fDrawIntoBuffer(void)
{
	// Neue Daten eintragen:

	int32_t ixCenter = static_cast<int32_t>(PosX);
	int32_t iyCenter = static_cast<int32_t>(PosY);

	//int32_t  ixMin = ixCenter - HalfSizeX;
	//int32_t  ixMax = ixCenter + HalfSizeX + 1;

	int32_t ixMin = ixCenter - 1;
	int32_t ixMax = ixCenter + 2;

	for (int32_t i = ixMin; i < ixMax; i++)
		g_fGameBoard[iyCenter][i] = fConstGameBoard_PaddleElement;
}

void CPaddle::DrawIntoBuffer(void)
{
	// Alte Daten aus g_GameBoard l�schen:

	int32_t ixCenter = static_cast<int32_t>(LastPosX);
	int32_t iyCenter = static_cast<int32_t>(LastPosY);

	int32_t ixMin = ixCenter - HalfSizeX;
	int32_t ixMax = ixCenter + HalfSizeX + 1;

	for (int32_t i = ixMin; i < ixMax; i++)	
		g_GameBoard[iyCenter][i] = ConstGameBoard_EmptyElement;
	

	// Neue Daten in g_GameBoard eintragen:

	ixCenter = static_cast<int32_t>(PosX);// -static_cast<int32_t>(HalfSizeX);
	iyCenter = static_cast<int32_t>(PosY);

	ixMin = ixCenter - HalfSizeX;
	ixMax = ixCenter + HalfSizeX + 1;

	for (int32_t i = ixMin; i < ixMax; i++)
		g_GameBoard[iyCenter][i] = ConstGameBoard_PaddleElement;
	

	LastPosX = PosX;
	LastPosY = PosY;
}


///////////////////////////////

CSimpleAIPlayer_Pong1::CSimpleAIPlayer_Pong1()
{
	PlayBallMovementX.Initialize_SingleInput_SingleOutput(5, LinearOutput, NegLinearOutput);
	PlayBallMovementY.Initialize_SingleInput_SingleOutput(5, LinearOutput, NegLinearOutput);


	PlayBallMovementX.Reset_Memory();
	PlayBallMovementY.Reset_Memory();

	PaddleDetector.Initialize(3, 3);

	//PaddleDetector.pValueArray[0] = -1.0f;
	//PaddleDetector.pValueArray[1] = -1.0f;
	//PaddleDetector.pValueArray[2] = -1.0f;

	PaddleDetector.pValueArray[0] = 0.0f;
	PaddleDetector.pValueArray[1] = 0.0f;
	PaddleDetector.pValueArray[2] = 0.0f;

	PaddleDetector.pValueArray[3] = 1.0f;
	PaddleDetector.pValueArray[4] = 1.0f;
	PaddleDetector.pValueArray[5] = 1.0f;

	//PaddleDetector.pValueArray[6] = -1.0f;
	//PaddleDetector.pValueArray[7] = -1.0f;
	//PaddleDetector.pValueArray[8] = -1.0f;

	PaddleDetector.pValueArray[6] = 0.0f;
	PaddleDetector.pValueArray[7] = 0.0f;
	PaddleDetector.pValueArray[8] = 0.0f;

	PlayBallDetector.Initialize(3, 3);

	PlayBallDetector.pValueArray[0] = 0.0f;
	PlayBallDetector.pValueArray[1] = 0.0f;
	PlayBallDetector.pValueArray[2] = 0.0f;

	//PlayBallDetector.pValueArray[3] = -1.0f;
	//PlayBallDetector.pValueArray[4] = 1.0f;
	//PlayBallDetector.pValueArray[5] = -1.0f;

	PlayBallDetector.pValueArray[3] = 0.0f;
	PlayBallDetector.pValueArray[4] = -1.0f;
	PlayBallDetector.pValueArray[5] = 0.0f;

	PlayBallDetector.pValueArray[6] = 0.0f;
	PlayBallDetector.pValueArray[7] = 0.0f;
	PlayBallDetector.pValueArray[8] = 0.0f;
}

CSimpleAIPlayer_Pong1::~CSimpleAIPlayer_Pong1()
{}

void CSimpleAIPlayer_Pong1::Initialize(CPaddle *pPaddle, CBall *pPlayBall, uint32_t numOfHiddenNeuronsL1, uint32_t numOfHiddenNeuronsL2, bool useNeuralNet)
{
	pUsedPaddle = pPaddle;
	pUsedPlayBall = pPlayBall;

	if (useNeuralNet == true)
	{
		if (numOfHiddenNeuronsL2 == 0)
		{
			Brain.Init_NeuralNet(7 + numOfHiddenNeuronsL1);
			Brain.Init_Input_And_OutputNeurons(4, 0.1f, false, 3, PongActivationFunctionOutput);
			Brain.Init_HiddenLayer1(numOfHiddenNeuronsL1, false, true, PongActivationFunctionOutput, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
		}
		else
		{
			Brain.Init_NeuralNet(7 + numOfHiddenNeuronsL1 + numOfHiddenNeuronsL2);
			Brain.Init_Input_And_OutputNeurons(4, 0.1f, false, 3, PongActivationFunctionOutput);
			Brain.Init_HiddenLayer1(numOfHiddenNeuronsL1, false, false, PongActivationFunctionOutput, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
			Brain.Init_HiddenLayer2(numOfHiddenNeuronsL2, false, true, PongActivationFunctionOutput, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
		}
	}
}

void CSimpleAIPlayer_Pong1::Initialize_Ext(CPaddle *pPaddle, CBall *pPlayBall, CRandomNumbersNN *pRandomNumbers, uint32_t minNumOfHiddenNeuronsL1, uint32_t maxNumOfHiddenNeuronsL1, uint32_t minNumOfHiddenNeuronsL2, uint32_t maxNumOfHiddenNeuronsL2, bool useNeuralNet)
{
	pUsedPaddle = pPaddle;
	pUsedPlayBall = pPlayBall;

	if (useNeuralNet == true)
	{
		if (maxNumOfHiddenNeuronsL2 == 0)
		{
			Brain.Init_NeuralNet(7 + maxNumOfHiddenNeuronsL1);
			Brain.Init_Input_And_OutputNeurons(4, 0.1f, false, 3, PongActivationFunctionOutput);
			Brain.Init_HiddenLayer1(pRandomNumbers->Get_UnsignedIntegerNumber2(minNumOfHiddenNeuronsL1, maxNumOfHiddenNeuronsL1), false, true, PongActivationFunctionOutput, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
		}
		else
		{
			Brain.Init_NeuralNet(7 + maxNumOfHiddenNeuronsL1 + maxNumOfHiddenNeuronsL2);

			uint32_t numOfHiddenNeuronsL2 = pRandomNumbers->Get_UnsignedIntegerNumber2(minNumOfHiddenNeuronsL2, maxNumOfHiddenNeuronsL2);

			if (numOfHiddenNeuronsL2 == 0)
			{
				Brain.Init_Input_And_OutputNeurons(4, 0.1f, false, 3, PongActivationFunctionOutput);
				Brain.Init_HiddenLayer1(pRandomNumbers->Get_UnsignedIntegerNumber2(minNumOfHiddenNeuronsL1, maxNumOfHiddenNeuronsL1), false, true, PongActivationFunctionOutput, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
			}
			else
			{
				Brain.Init_Input_And_OutputNeurons(4, 0.1f, false, 3, PongActivationFunctionOutput);
				Brain.Init_HiddenLayer1(pRandomNumbers->Get_UnsignedIntegerNumber2(minNumOfHiddenNeuronsL1, maxNumOfHiddenNeuronsL1), false, false, PongActivationFunctionOutput, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
				Brain.Init_HiddenLayer2(numOfHiddenNeuronsL2, false, true, PongActivationFunctionOutput, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
			}
		}
	}
}

void CSimpleAIPlayer_Pong1::GameObjectDetection_And_VelocityCalculations(void)
{
	int32_t patternCount;

	PlayBallDetector.Search_Pattern(&patternCount, &ScreenPlayBallPosX, &ScreenPlayBallPosY, 1, &g_fGameBoard[0][0], ConstGameBoardSizeX, ConstGameBoardSizeY, 1, 1, 1.0f);

	PlayBallMovementX.Calculate_Output(ScreenPlayBallPosX);
	PlayBallMovementY.Calculate_Output(ScreenPlayBallPosY);

	PaddleDetector.Search_Pattern(&patternCount, &ScreenPaddlePosX, &ScreenPaddlePosY, 1, &g_fGameBoard[0][0], ConstGameBoardSizeX, ConstGameBoardSizeY, 1, 1, 3.0f);
}

void CSimpleAIPlayer_Pong1::Reset_Memories(void)
{
	PlayBallMovementX.Reset_Memory();
	PlayBallMovementY.Reset_Memory();
}



float CSimpleAIPlayer_Pong1::Train_NeuralNet(float accuracyValue, bool extremeLearning)
{
	float InputData[4];
	float OutputData[3];
	float DesiredOutputData[3];
	
	float velXX = PlayBallMovementX.Get_Actual_Output();
	velXX *= velXX;

	float velYY = PlayBallMovementY.Get_Actual_Output();
	velYY *= velYY;

	float lengthSq = velXX + velYY;
	float invLength = 1.0f / (0.0001f + sqrt(lengthSq));

	float movementDirX = PlayBallMovementX.Get_Actual_Output() * invLength;
	float movementDirY = PlayBallMovementY.Get_Actual_Output() * invLength;

	float distX = static_cast<float>(ScreenPaddlePosX - 1 - ScreenPlayBallPosX);
	float distY = static_cast<float>(ScreenPaddlePosY - ScreenPlayBallPosY);

	float distXX = distX * distX;
	float distYY = distY * distY;

	lengthSq = distXX + distYY;
	invLength = 1.0f / (0.0001f + sqrt(lengthSq));

	float distX_normalized1 = distX * invLength;
	float distY_normalized1 = distY * invLength;

	distX = static_cast<float>(ScreenPaddlePosX - ScreenPlayBallPosX);
	distXX = distX * distX;
	

	lengthSq = distXX + distYY;
	invLength = 1.0f / (0.0001f + sqrt(lengthSq));

	float distX_normalized2 = distX * invLength;
	float distY_normalized2 = distY * invLength;

	distX = static_cast<float>(ScreenPaddlePosX + 1 - ScreenPlayBallPosX);
	
	distXX = distX * distX;
	
	lengthSq = distXX + distYY;
	invLength = 1.0f / (0.0001f + sqrt(lengthSq));

	float distX_normalized3 = distX * invLength;
	float distY_normalized3 = distY * invLength;


	float dotProduct = Check_PlayBallFlightDir(static_cast<float>(ScreenPaddlePosX), static_cast<float>(ScreenPaddlePosY), movementDirX, movementDirY);

	if (dotProduct > accuracyValue)
	{
		DesiredOutputData[0] = 0.0f;
		DesiredOutputData[1] = 1.0f;
		DesiredOutputData[2] = 0.0f;
	}
	else
	{
		float dotProduct2 = Check_PlayBallFlightDir(static_cast<float>(ScreenPaddlePosX + 1), static_cast<float>(ScreenPaddlePosY), movementDirX, movementDirY);

		if (dotProduct2 > dotProduct)
		{
			DesiredOutputData[0] = 0.0f;
			DesiredOutputData[1] = 0.0f;
			DesiredOutputData[2] = 1.0f;
		}
		else
		{
			DesiredOutputData[0] = 1.0f;
			DesiredOutputData[1] = 0.0f;
			DesiredOutputData[2] = 0.0f;
		}
	}

	

	movementDirX = PlayBallMovementX.Get_Actual_Output(); 
	movementDirY = PlayBallMovementY.Get_Actual_Output();
	
	lengthSq = movementDirX*movementDirX + movementDirY*movementDirY;
	invLength = 1.0f / (0.0001f + sqrt(lengthSq));

	movementDirX *= invLength;
	movementDirY *= invLength;

	InputData[0] = ScreenPaddlePosX - ScreenPlayBallPosX;
	InputData[1] = ScreenPaddlePosY - ScreenPlayBallPosY;
	InputData[2] = movementDirX;
	InputData[3] = movementDirY;

	Brain.Calculate_Output(OutputData, InputData);

	float error;

	if(extremeLearning == true)
		error = Brain.ExtremeLearning(DesiredOutputData);
	else
		error = Brain.Learning(DesiredOutputData);



	/*if (DesiredOutputData[0] == 1.0f && DesiredOutputData[1] == 0.0f && DesiredOutputData[2] == 0.0f)
	{
		if (OutputData[0] > OutputData[1] && OutputData[0] > OutputData[2])
			return 0.0f;
	}
	else if (DesiredOutputData[0] == 0.0f && DesiredOutputData[1] == 1.0f && DesiredOutputData[2] == 0.0f)
	{
		if (OutputData[1] > OutputData[0] && OutputData[1] > OutputData[2])
			return 0.0f;
	}

	else if (DesiredOutputData[0] == 0.0f && DesiredOutputData[1] == 0.0f && DesiredOutputData[2] == 1.0f)
	{
		if (OutputData[2] > OutputData[0] && OutputData[2] > OutputData[1])
			return 0.0f;
	}*/

	return error;
}




int32_t CSimpleAIPlayer_Pong1::Calculate_NeuralNetPaddleMovement(float paddleMovementStep, float paddleDecelerationValue, float accuracyValue)
{
	float InputData[4];
	float OutputData[3];
	float OldOutputData[3];

	

	float movementDirX = PlayBallMovementX.Get_Actual_Output();
	float movementDirY = PlayBallMovementY.Get_Actual_Output();

	float lengthSq = movementDirX*movementDirX + movementDirY*movementDirY;
	float invLength = 1.0f / (0.0001f + sqrt(lengthSq));

	movementDirX *= invLength;
	movementDirY *= invLength;

	InputData[0] = static_cast<float>(ScreenPaddlePosX - ScreenPlayBallPosX);
	InputData[1] = static_cast<float>(ScreenPaddlePosY - ScreenPlayBallPosY);
	InputData[2] = movementDirX;
	InputData[3] = movementDirY;


	Brain.Get_Output(OldOutputData);
	float maxValueOld = -1.0f;

	int32_t compValue1 = 0;

	if (OldOutputData[0] > maxValueOld)
	{
		maxValueOld = OldOutputData[0];
		compValue1 = 1;
	}
	if (OldOutputData[1] > maxValueOld)
	{
		maxValueOld = OldOutputData[1];
		compValue1 = 2;
	}
	if (OldOutputData[2] > maxValueOld)
	{
		maxValueOld = OldOutputData[2];
		compValue1 = 3;
	}

	Brain.Calculate_Output(OutputData, InputData);

	pUsedPaddle->LastVelocityX = pUsedPaddle->VelocityX;

	/*if (OutputData[0] < 0.75f && OutputData[2] < 0.75f)
	{
		pUsedPaddle->VelocityX = 0.0f;
		return 0;
	}*/

	//HelperStuff::Add_To_Log(0, "OutputData[0]", OutputData[0]);
	//HelperStuff::Add_To_Log(0, "OutputData[1]", OutputData[1]);
	//HelperStuff::Add_To_Log(0, "OutputData[2]", OutputData[2]);

	float maxValue = -1.0f;

	//maxValue = max(maxValue, OutputData[0]);
	//maxValue = max(maxValue, OutputData[1]);
	//maxValue = max(maxValue, OutputData[2]);

	int32_t compValue2 = 0;

	if (OutputData[0] > maxValue)
	{
		maxValue = OutputData[0];
		compValue2 = 1;
	}
	if (OutputData[1] > maxValue)
	{
		maxValue = OutputData[1];
		compValue2 = 2;
	}
	if (OutputData[2] > maxValue)
	{
		maxValue = OutputData[2];
		compValue2 = 3;
	}


	

	if (maxValue == OutputData[0])
	{
		pUsedPaddle->VelocityX -= paddleMovementStep;

		pUsedPaddle->VelocityX = min(pUsedPaddle->MaxAIPlayerPaddleVelocityX, pUsedPaddle->VelocityX);
		pUsedPaddle->VelocityX = max(pUsedPaddle->MinAIPlayerPaddleVelocityX, pUsedPaddle->VelocityX);
	}
	else if (maxValue == OutputData[1])
	{
		//pUsedPaddle->VelocityX *= paddleDecelerationValue;
		pUsedPaddle->VelocityX = 0.0f;
	}
	else if (maxValue == OutputData[2])
	{
		pUsedPaddle->VelocityX += paddleMovementStep;

		pUsedPaddle->VelocityX = min(pUsedPaddle->MaxAIPlayerPaddleVelocityX, pUsedPaddle->VelocityX);
		pUsedPaddle->VelocityX = max(pUsedPaddle->MinAIPlayerPaddleVelocityX, pUsedPaddle->VelocityX);
	}



	pUsedPaddle->PosX += pUsedPaddle->VelocityX;

	if (pUsedPaddle->PosX < pUsedPaddle->fHalfSizeXPlus1)
		pUsedPaddle->PosX = pUsedPaddle->fHalfSizeXPlus1;
	else if (pUsedPaddle->PosX > fConstGameBoardSizeX - pUsedPaddle->fHalfSizeXPlus2)
		pUsedPaddle->PosX = fConstGameBoardSizeX - pUsedPaddle->fHalfSizeXPlus2;

	if (compValue1 != compValue2)
		return -1;
	else
		return 1;
}

void CSimpleAIPlayer_Pong1::Calculate_PaddleMovement(float paddleMovementStep, float paddleDecelerationValue, float accuracyValue)
{
	float velXX = PlayBallMovementX.Get_Actual_Output();
	velXX *= velXX;

	float velYY = PlayBallMovementY.Get_Actual_Output();
	velYY *= velYY;

	float lengthSq = velXX + velYY;
	float invLength = 1.0f / (0.0001f + sqrt(lengthSq));

	float movementDirX = PlayBallMovementX.Get_Actual_Output() * invLength;
	float movementDirY = PlayBallMovementY.Get_Actual_Output() * invLength;

	float dotProduct = Check_PlayBallFlightDir(static_cast<float>(ScreenPaddlePosX), static_cast<float>(ScreenPaddlePosY), movementDirX, movementDirY);

	pUsedPaddle->LastVelocityX = pUsedPaddle->VelocityX;

	if (dotProduct > accuracyValue)
	{
		pUsedPaddle->VelocityX *= paddleDecelerationValue;
	}
	else
	{

		float dotProduct2 = Check_PlayBallFlightDir(static_cast<float>(ScreenPaddlePosX + 1), static_cast<float>(ScreenPaddlePosY), movementDirX, movementDirY);

		if (dotProduct2 > dotProduct)
		{
			pUsedPaddle->VelocityX += paddleMovementStep;

			pUsedPaddle->VelocityX = min(pUsedPaddle->MaxAIPlayerPaddleVelocityX, pUsedPaddle->VelocityX);
			pUsedPaddle->VelocityX = max(pUsedPaddle->MinAIPlayerPaddleVelocityX, pUsedPaddle->VelocityX);
		}
		else
		{
			pUsedPaddle->VelocityX -= paddleMovementStep;

			pUsedPaddle->VelocityX = min(pUsedPaddle->MaxAIPlayerPaddleVelocityX, pUsedPaddle->VelocityX);
			pUsedPaddle->VelocityX = max(pUsedPaddle->MinAIPlayerPaddleVelocityX, pUsedPaddle->VelocityX);
		}
	}

	/*pUsedPaddle->VelocityX += paddleMovementStep * (static_cast<float>(ScreenPlayBallPosX) - static_cast<float>(ScreenPaddlePosX));

	pUsedPaddle->VelocityX = min(pUsedPaddle->MaxAIPlayerPaddleVelocityX, pUsedPaddle->VelocityX);
	pUsedPaddle->VelocityX = max(pUsedPaddle->MinAIPlayerPaddleVelocityX, pUsedPaddle->VelocityX);
	pUsedPaddle->VelocityX *= paddleDecelerationValue;
	*/

	pUsedPaddle->PosX += pUsedPaddle->VelocityX;

	if (pUsedPaddle->PosX < pUsedPaddle->fHalfSizeXPlus1)
		pUsedPaddle->PosX = pUsedPaddle->fHalfSizeXPlus1;
	else if (pUsedPaddle->PosX > fConstGameBoardSizeX - pUsedPaddle->fHalfSizeXPlus2)
		pUsedPaddle->PosX = fConstGameBoardSizeX - pUsedPaddle->fHalfSizeXPlus2;
}

float CSimpleAIPlayer_Pong1::Calculate_FitnessScore(float accuracyValue, float neuralNetOutput1, float neuralNetOutput2, float neuralNetOutput3)
{
	float DesiredOutputData[3];

	float velXX = PlayBallMovementX.Get_Actual_Output();
	velXX *= velXX;

	float velYY = PlayBallMovementY.Get_Actual_Output();
	velYY *= velYY;

	float lengthSq = velXX + velYY;
	float invLength = 1.0f / (0.0001f + sqrt(lengthSq));

	float movementDirX = PlayBallMovementX.Get_Actual_Output() * invLength;
	float movementDirY = PlayBallMovementY.Get_Actual_Output() * invLength;

	float distX = static_cast<float>(ScreenPaddlePosX - 1 - ScreenPlayBallPosX);
	float distY = static_cast<float>(ScreenPaddlePosY - ScreenPlayBallPosY);

	float distXX = distX * distX;
	float distYY = distY * distY;

	lengthSq = distXX + distYY;
	invLength = 1.0f / (0.0001f + sqrt(lengthSq));

	float distX_normalized1 = distX * invLength;
	float distY_normalized1 = distY * invLength;

	distX = static_cast<float>(ScreenPaddlePosX - ScreenPlayBallPosX);
	distXX = distX * distX;


	lengthSq = distXX + distYY;
	invLength = 1.0f / (0.0001f + sqrt(lengthSq));

	float distX_normalized2 = distX * invLength;
	float distY_normalized2 = distY * invLength;

	distX = static_cast<float>(ScreenPaddlePosX + 1 - ScreenPlayBallPosX);

	distXX = distX * distX;

	lengthSq = distXX + distYY;
	invLength = 1.0f / (0.0001f + sqrt(lengthSq));

	float distX_normalized3 = distX * invLength;
	float distY_normalized3 = distY * invLength;


	float dotProduct = Check_PlayBallFlightDir(static_cast<float>(ScreenPaddlePosX), static_cast<float>(ScreenPaddlePosY), movementDirX, movementDirY);

	if (dotProduct > accuracyValue)
	{
		DesiredOutputData[0] = 0.0f;
		DesiredOutputData[1] = 1.0f;
		DesiredOutputData[2] = 0.0f;
	}
	else
	{
		float dotProduct2 = Check_PlayBallFlightDir(static_cast<float>(ScreenPaddlePosX + 1), static_cast<float>(ScreenPaddlePosY), movementDirX, movementDirY);

		if (dotProduct2 > dotProduct)
		{
			DesiredOutputData[0] = 0.0f;
			DesiredOutputData[1] = 0.0f;
			DesiredOutputData[2] = 1.0f;
		}
		else
		{
			DesiredOutputData[0] = 1.0f;
			DesiredOutputData[1] = 0.0f;
			DesiredOutputData[2] = 0.0f;
		}
	}

	if (DesiredOutputData[0] == 1.0f && DesiredOutputData[1] == 0.0f && DesiredOutputData[2] == 0.0f)
	{
		if (neuralNetOutput1 > neuralNetOutput2 && neuralNetOutput1 > neuralNetOutput3)
			return neuralNetOutput1;
	}
	else if (DesiredOutputData[0] == 0.0f && DesiredOutputData[1] == 1.0f && DesiredOutputData[2] == 0.0f)
	{
		if (neuralNetOutput2 > neuralNetOutput1 && neuralNetOutput2 > neuralNetOutput3)
			return neuralNetOutput2;
	}

	else if (DesiredOutputData[0] == 0.0f && DesiredOutputData[1] == 0.0f && DesiredOutputData[2] == 1.0f)
	{
		if (neuralNetOutput3 > neuralNetOutput1 && neuralNetOutput3 > neuralNetOutput2)
			return neuralNetOutput3;
	}

	return -1.0f;
}

float CSimpleAIPlayer_Pong1::Calculate_FitnessScore(void)
{
	float velXX = PlayBallMovementX.Get_Actual_Output();
	velXX *= velXX;

	float velYY = PlayBallMovementY.Get_Actual_Output();
	velYY *= velYY;

	float lengthSq = velXX + velYY;
	float invLength = 1.0f / (0.0001f + sqrt(lengthSq));

	float movementDirX = PlayBallMovementX.Get_Actual_Output() * invLength;
	float movementDirY = PlayBallMovementY.Get_Actual_Output() * invLength;

	return Check_PlayBallFlightDir(static_cast<float>(ScreenPaddlePosX), static_cast<float>(ScreenPaddlePosY), movementDirX, movementDirY);
}

float CSimpleAIPlayer_Pong1::Check_PlayBallFlightDir(float targetPosX, float targetPosY, float movementDirX, float movementDirY)
{
	float distX = targetPosX - static_cast<float>(ScreenPlayBallPosX);
	float distY = targetPosY - static_cast<float>(ScreenPlayBallPosY);

	float distXX = distX * distX;
	float distYY = distY * distY;

	float lengthSq = distXX + distYY;
	float invLength = 1.0f / (0.0001f + sqrt(lengthSq));

	float distX_normalized = distX * invLength;
	float distY_normalized = distY * invLength;

	// dotProduct:
	return distX_normalized * movementDirX + distY_normalized * movementDirY;
}


///////////////////////////////

CSimpleAIPlayer_Pong2::CSimpleAIPlayer_Pong2()
{
	PlayBallMovementX.Initialize_SingleInput_SingleOutput(5, LinearOutput, NegLinearOutput);
	PlayBallMovementY.Initialize_SingleInput_SingleOutput(5, LinearOutput, NegLinearOutput);


	PlayBallMovementX.Reset_Memory();
	PlayBallMovementY.Reset_Memory();

	PaddleDetector.Initialize(3, 3);

	//PaddleDetector.pValueArray[0] = -1.0f;
	//PaddleDetector.pValueArray[1] = -1.0f;
	//PaddleDetector.pValueArray[2] = -1.0f;

	PaddleDetector.pValueArray[0] = 0.0f;
	PaddleDetector.pValueArray[1] = 0.0f;
	PaddleDetector.pValueArray[2] = 0.0f;

	PaddleDetector.pValueArray[3] = 1.0f;
	PaddleDetector.pValueArray[4] = 1.0f;
	PaddleDetector.pValueArray[5] = 1.0f;

	//PaddleDetector.pValueArray[6] = -1.0f;
	//PaddleDetector.pValueArray[7] = -1.0f;
	//PaddleDetector.pValueArray[8] = -1.0f;

	PaddleDetector.pValueArray[6] = 0.0f;
	PaddleDetector.pValueArray[7] = 0.0f;
	PaddleDetector.pValueArray[8] = 0.0f;

	PlayBallDetector.Initialize(3, 3);

	PlayBallDetector.pValueArray[0] = 0.0f;
	PlayBallDetector.pValueArray[1] = 0.0f;
	PlayBallDetector.pValueArray[2] = 0.0f;

	//PlayBallDetector.pValueArray[3] = -1.0f;
	//PlayBallDetector.pValueArray[4] = 1.0f;
	//PlayBallDetector.pValueArray[5] = -1.0f;

	PlayBallDetector.pValueArray[3] = 0.0f;
	PlayBallDetector.pValueArray[4] = -1.0f;
	PlayBallDetector.pValueArray[5] = 0.0f;

	PlayBallDetector.pValueArray[6] = 0.0f;
	PlayBallDetector.pValueArray[7] = 0.0f;
	PlayBallDetector.pValueArray[8] = 0.0f;

	

}

CSimpleAIPlayer_Pong2::~CSimpleAIPlayer_Pong2()
{}





void CSimpleAIPlayer_Pong2::Initialize(CPaddle *pPaddle, CBall *pPlayBall, uint32_t numOfHiddenNeuronsL1, uint32_t numOfHiddenNeuronsL2, bool useNeuralNet)
{
	pUsedPaddle = pPaddle;
	pUsedPlayBall = pPlayBall;

	if (useNeuralNet == true)
	{
		if (numOfHiddenNeuronsL2 == 0)
		{
			Brain.Init_NeuralNet(9 + numOfHiddenNeuronsL1);
			Brain.Init_Input_And_OutputNeurons(6, 0.1f, false, 3, PongActivationFunctionOutput);
			Brain.Init_HiddenLayer1(numOfHiddenNeuronsL1, false, true, PongActivationFunctionOutput, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
		}
		else
		{
			Brain.Init_NeuralNet(9 + numOfHiddenNeuronsL1 + numOfHiddenNeuronsL2);
			Brain.Init_Input_And_OutputNeurons(6, 0.1f, false, 3, PongActivationFunctionOutput);
			Brain.Init_HiddenLayer1(numOfHiddenNeuronsL1, false, false, PongActivationFunctionOutput, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
			Brain.Init_HiddenLayer2(numOfHiddenNeuronsL2, false, true, PongActivationFunctionOutput, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
		}
	}
}

void CSimpleAIPlayer_Pong2::Initialize_Ext(CPaddle *pPaddle, CBall *pPlayBall, CRandomNumbersNN *pRandomNumbers, uint32_t minNumOfHiddenNeuronsL1, uint32_t maxNumOfHiddenNeuronsL1, uint32_t minNumOfHiddenNeuronsL2, uint32_t maxNumOfHiddenNeuronsL2, bool useNeuralNet)
{
	pUsedPaddle = pPaddle;
	pUsedPlayBall = pPlayBall;

	if (useNeuralNet == true)
	{
		if (maxNumOfHiddenNeuronsL2 == 0)
		{
			Brain.Init_NeuralNet(9 + maxNumOfHiddenNeuronsL1);
			Brain.Init_Input_And_OutputNeurons(6, 0.1f, false, 3, PongActivationFunctionOutput);
			Brain.Init_HiddenLayer1(pRandomNumbers->Get_UnsignedIntegerNumber2(minNumOfHiddenNeuronsL1, maxNumOfHiddenNeuronsL1), false, true, PongActivationFunctionOutput, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
		}
		else
		{
			Brain.Init_NeuralNet(9 + maxNumOfHiddenNeuronsL1 + maxNumOfHiddenNeuronsL2);

			uint32_t numOfHiddenNeuronsL2 = pRandomNumbers->Get_UnsignedIntegerNumber2(minNumOfHiddenNeuronsL2, maxNumOfHiddenNeuronsL2);

			if (numOfHiddenNeuronsL2 == 0)
			{
				Brain.Init_Input_And_OutputNeurons(6, 0.1f, false, 3, PongActivationFunctionOutput);
				Brain.Init_HiddenLayer1(pRandomNumbers->Get_UnsignedIntegerNumber2(minNumOfHiddenNeuronsL1, maxNumOfHiddenNeuronsL1), false, true, PongActivationFunctionOutput, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
			}
			else
			{
				Brain.Init_Input_And_OutputNeurons(6, 0.1f, false, 3, PongActivationFunctionOutput);
				Brain.Init_HiddenLayer1(pRandomNumbers->Get_UnsignedIntegerNumber2(minNumOfHiddenNeuronsL1, maxNumOfHiddenNeuronsL1), false, false, PongActivationFunctionOutput, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
				Brain.Init_HiddenLayer2(numOfHiddenNeuronsL2, false, true, PongActivationFunctionOutput, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
			}
		}
	}
}


void CSimpleAIPlayer_Pong2::GameObjectDetection_And_VelocityCalculations(void)
{
	int32_t patternCount;

	PlayBallDetector.Search_Pattern(&patternCount, &ScreenPlayBallPosX, &ScreenPlayBallPosY, 1, &g_fGameBoard[0][0], ConstGameBoardSizeX, ConstGameBoardSizeY, 1, 1, 1.0f);

	PlayBallMovementX.Calculate_Output(ScreenPlayBallPosX);
	PlayBallMovementY.Calculate_Output(ScreenPlayBallPosY);

	PaddleDetector.Search_Pattern(&patternCount, &ScreenPaddlePosX, &ScreenPaddlePosY, 1, &g_fGameBoard[0][0], ConstGameBoardSizeX, ConstGameBoardSizeY, 1, 1, 3.0f);
}

void CSimpleAIPlayer_Pong2::Reset_Memories(void)
{
	PlayBallMovementX.Reset_Memory();
	PlayBallMovementY.Reset_Memory();
}



float CSimpleAIPlayer_Pong2::Train_NeuralNet(float accuracyValue, bool extremeLearning)
{
	float InputData[6];
	float OutputData[3];
	float DesiredOutputData[3];

	float velXX = PlayBallMovementX.Get_Actual_Output();
	velXX *= velXX;

	float velYY = PlayBallMovementY.Get_Actual_Output();
	velYY *= velYY;

	float lengthSq = velXX + velYY;
	float invLength = 1.0f / (0.0001f + sqrt(lengthSq));

	float movementDirX = PlayBallMovementX.Get_Actual_Output() * invLength;
	float movementDirY = PlayBallMovementY.Get_Actual_Output() * invLength;

	float distX = static_cast<float>(ScreenPaddlePosX - 1 - ScreenPlayBallPosX);
	float distY = static_cast<float>(ScreenPaddlePosY - ScreenPlayBallPosY);

	float distXX = distX * distX;
	float distYY = distY * distY;

	lengthSq = distXX + distYY;
	invLength = 1.0f / (0.0001f + sqrt(lengthSq));

	float distX_normalized1 = distX * invLength;
	float distY_normalized1 = distY * invLength;

	distX = static_cast<float>(ScreenPaddlePosX - ScreenPlayBallPosX);
	distXX = distX * distX;


	lengthSq = distXX + distYY;
	invLength = 1.0f / (0.0001f + sqrt(lengthSq));

	float distX_normalized2 = distX * invLength;
	float distY_normalized2 = distY * invLength;

	distX = static_cast<float>(ScreenPaddlePosX + 1 - ScreenPlayBallPosX);

	distXX = distX * distX;

	lengthSq = distXX + distYY;
	invLength = 1.0f / (0.0001f + sqrt(lengthSq));

	float distX_normalized3 = distX * invLength;
	float distY_normalized3 = distY * invLength;


	float dotProduct = Check_PlayBallFlightDir(static_cast<float>(ScreenPaddlePosX), static_cast<float>(ScreenPaddlePosY), movementDirX, movementDirY);

	if (dotProduct > accuracyValue)
	{
		DesiredOutputData[0] = 0.0f;
		DesiredOutputData[1] = 1.0f;
		DesiredOutputData[2] = 0.0f;
	}
	else
	{
		float dotProduct2 = Check_PlayBallFlightDir(static_cast<float>(ScreenPaddlePosX + 1), static_cast<float>(ScreenPaddlePosY), movementDirX, movementDirY);

		if (dotProduct2 > dotProduct)
		{
			DesiredOutputData[0] = 0.0f;
			DesiredOutputData[1] = 0.0f;
			DesiredOutputData[2] = 1.0f;
		}
		else
		{
			DesiredOutputData[0] = 1.0f;
			DesiredOutputData[1] = 0.0f;
			DesiredOutputData[2] = 0.0f;
		}
	}



	movementDirX = PlayBallMovementX.Get_Actual_Output();
	movementDirY = PlayBallMovementY.Get_Actual_Output();

	lengthSq = movementDirX*movementDirX + movementDirY*movementDirY;
	invLength = 1.0f / (0.0001f + sqrt(lengthSq));

	movementDirX *= invLength;
	movementDirY *= invLength;

	InputData[0] = ScreenPaddlePosX;
	InputData[1] = ScreenPaddlePosY;
	InputData[2] = ScreenPlayBallPosX;
	InputData[3] = ScreenPlayBallPosY;
	InputData[4] = movementDirX;
	InputData[5] = movementDirY;

	Brain.Calculate_Output(OutputData, InputData);

	float error;

	if (extremeLearning == true)
		error = Brain.ExtremeLearning(DesiredOutputData);
	else
		error = Brain.Learning(DesiredOutputData);



	/*if (DesiredOutputData[0] == 1.0f && DesiredOutputData[1] == 0.0f && DesiredOutputData[2] == 0.0f)
	{
		if (OutputData[0] > OutputData[1] && OutputData[0] > OutputData[2])
			return 0.0f;
	}
	else if (DesiredOutputData[0] == 0.0f && DesiredOutputData[1] == 1.0f && DesiredOutputData[2] == 0.0f)
	{
		if (OutputData[1] > OutputData[0] && OutputData[1] > OutputData[2])
			return 0.0f;
	}

	else if (DesiredOutputData[0] == 0.0f && DesiredOutputData[1] == 0.0f && DesiredOutputData[2] == 1.0f)
	{
		if (OutputData[2] > OutputData[0] && OutputData[2] > OutputData[1])
			return 0.0f;
	}*/

	return error;
}




int32_t CSimpleAIPlayer_Pong2::Calculate_NeuralNetPaddleMovement(float paddleMovementStep, float paddleDecelerationValue, float accuracyValue)
{
	float InputData[6];
	float OutputData[3];
	float OldOutputData[3];



	float movementDirX = PlayBallMovementX.Get_Actual_Output();
	float movementDirY = PlayBallMovementY.Get_Actual_Output();

	float lengthSq = movementDirX*movementDirX + movementDirY*movementDirY;
	float invLength = 1.0f / (0.0001f + sqrt(lengthSq));

	movementDirX *= invLength;
	movementDirY *= invLength;

	InputData[0] = static_cast<float>(ScreenPaddlePosX);
	InputData[1] = static_cast<float>(ScreenPaddlePosY);
	InputData[2] = static_cast<float>(ScreenPlayBallPosX);
	InputData[3] = static_cast<float>(ScreenPlayBallPosY);
	InputData[4] = movementDirX;
	InputData[5] = movementDirY;


	Brain.Get_Output(OldOutputData);
	float maxValueOld = -1.0f;

	int32_t compValue1 = 0;

	if (OldOutputData[0] > maxValueOld)
	{
		maxValueOld = OldOutputData[0];
		compValue1 = 1;
	}
	if (OldOutputData[1] > maxValueOld)
	{
		maxValueOld = OldOutputData[1];
		compValue1 = 2;
	}
	if (OldOutputData[2] > maxValueOld)
	{
		maxValueOld = OldOutputData[2];
		compValue1 = 3;
	}

	Brain.Calculate_Output(OutputData, InputData);

	pUsedPaddle->LastVelocityX = pUsedPaddle->VelocityX;

	/*if (OutputData[0] < 0.75f && OutputData[2] < 0.75f)
	{
	pUsedPaddle->VelocityX = 0.0f;
	return 0;
	}*/

	//HelperStuff::Add_To_Log(0, "OutputData[0]", OutputData[0]);
	//HelperStuff::Add_To_Log(0, "OutputData[1]", OutputData[1]);
	//HelperStuff::Add_To_Log(0, "OutputData[2]", OutputData[2]);

	float maxValue = -1.0f;

	//maxValue = max(maxValue, OutputData[0]);
	//maxValue = max(maxValue, OutputData[1]);
	//maxValue = max(maxValue, OutputData[2]);

	int32_t compValue2 = 0;

	if (OutputData[0] > maxValue)
	{
		maxValue = OutputData[0];
		compValue2 = 1;
	}
	if (OutputData[1] > maxValue)
	{
		maxValue = OutputData[1];
		compValue2 = 2;
	}
	if (OutputData[2] > maxValue)
	{
		maxValue = OutputData[2];
		compValue2 = 3;
	}




	if (maxValue == OutputData[0])
	{
		pUsedPaddle->VelocityX -= paddleMovementStep;

		pUsedPaddle->VelocityX = min(pUsedPaddle->MaxAIPlayerPaddleVelocityX, pUsedPaddle->VelocityX);
		pUsedPaddle->VelocityX = max(pUsedPaddle->MinAIPlayerPaddleVelocityX, pUsedPaddle->VelocityX);
	}
	else if (maxValue == OutputData[1])
	{
		//pUsedPaddle->VelocityX *= paddleDecelerationValue;
		pUsedPaddle->VelocityX = 0.0f;
	}
	else if (maxValue == OutputData[2])
	{
		pUsedPaddle->VelocityX += paddleMovementStep;

		pUsedPaddle->VelocityX = min(pUsedPaddle->MaxAIPlayerPaddleVelocityX, pUsedPaddle->VelocityX);
		pUsedPaddle->VelocityX = max(pUsedPaddle->MinAIPlayerPaddleVelocityX, pUsedPaddle->VelocityX);
	}



	pUsedPaddle->PosX += pUsedPaddle->VelocityX;

	if (pUsedPaddle->PosX < pUsedPaddle->fHalfSizeXPlus1)
		pUsedPaddle->PosX = pUsedPaddle->fHalfSizeXPlus1;
	else if (pUsedPaddle->PosX > fConstGameBoardSizeX - pUsedPaddle->fHalfSizeXPlus2)
		pUsedPaddle->PosX = fConstGameBoardSizeX - pUsedPaddle->fHalfSizeXPlus2;

	if (compValue1 != compValue2)
		return -1;
	else
		return 1;
}

void CSimpleAIPlayer_Pong2::Calculate_PaddleMovement(float paddleMovementStep, float paddleDecelerationValue, float accuracyValue)
{
	//HelperStuff::Add_To_Log(0, "pUsedPlayBall->VelocityX", pUsedPlayBall->VelocityX);
	//HelperStuff::Add_To_Log(0, "PlayBallMovementX.Get_Actual_Output()", PlayBallMovementX.Get_Actual_Output());

	float velXX = PlayBallMovementX.Get_Actual_Output();
	velXX *= velXX;

	float velYY = PlayBallMovementY.Get_Actual_Output();
	velYY *= velYY;

	float lengthSq = velXX + velYY;
	float invLength = 1.0f / (0.0001f + sqrt(lengthSq));

	float movementDirX = PlayBallMovementX.Get_Actual_Output() * invLength;
	float movementDirY = PlayBallMovementY.Get_Actual_Output() * invLength;

	float dotProduct = Check_PlayBallFlightDir(static_cast<float>(ScreenPaddlePosX), static_cast<float>(ScreenPaddlePosY), movementDirX, movementDirY);

	pUsedPaddle->LastVelocityX = pUsedPaddle->VelocityX;

	if (dotProduct > accuracyValue)
	{
		pUsedPaddle->VelocityX *= paddleDecelerationValue;
	}
	else
	{

		float dotProduct2 = Check_PlayBallFlightDir(static_cast<float>(ScreenPaddlePosX + 1), static_cast<float>(ScreenPaddlePosY), movementDirX, movementDirY);

		if (dotProduct2 > dotProduct)
		{
			pUsedPaddle->VelocityX += paddleMovementStep;

			pUsedPaddle->VelocityX = min(pUsedPaddle->MaxAIPlayerPaddleVelocityX, pUsedPaddle->VelocityX);
			pUsedPaddle->VelocityX = max(pUsedPaddle->MinAIPlayerPaddleVelocityX, pUsedPaddle->VelocityX);
		}
		else
		{
			pUsedPaddle->VelocityX -= paddleMovementStep;

			pUsedPaddle->VelocityX = min(pUsedPaddle->MaxAIPlayerPaddleVelocityX, pUsedPaddle->VelocityX);
			pUsedPaddle->VelocityX = max(pUsedPaddle->MinAIPlayerPaddleVelocityX, pUsedPaddle->VelocityX);
		}
	}

	pUsedPaddle->PosX += pUsedPaddle->VelocityX;

	if (pUsedPaddle->PosX < pUsedPaddle->fHalfSizeXPlus1)
		pUsedPaddle->PosX = pUsedPaddle->fHalfSizeXPlus1;
	else if (pUsedPaddle->PosX > fConstGameBoardSizeX - pUsedPaddle->fHalfSizeXPlus2)
		pUsedPaddle->PosX = fConstGameBoardSizeX - pUsedPaddle->fHalfSizeXPlus2;
}

float CSimpleAIPlayer_Pong2::Calculate_FitnessScore(float accuracyValue, float neuralNetOutput1, float neuralNetOutput2, float neuralNetOutput3)
{
	float DesiredOutputData[3];

	float velXX = PlayBallMovementX.Get_Actual_Output();
	velXX *= velXX;

	float velYY = PlayBallMovementY.Get_Actual_Output();
	velYY *= velYY;

	float lengthSq = velXX + velYY;
	float invLength = 1.0f / (0.0001f + sqrt(lengthSq));

	float movementDirX = PlayBallMovementX.Get_Actual_Output() * invLength;
	float movementDirY = PlayBallMovementY.Get_Actual_Output() * invLength;

	float distX = static_cast<float>(ScreenPaddlePosX - 1 - ScreenPlayBallPosX);
	float distY = static_cast<float>(ScreenPaddlePosY - ScreenPlayBallPosY);

	float distXX = distX * distX;
	float distYY = distY * distY;

	lengthSq = distXX + distYY;
	invLength = 1.0f / (0.0001f + sqrt(lengthSq));

	float distX_normalized1 = distX * invLength;
	float distY_normalized1 = distY * invLength;

	distX = static_cast<float>(ScreenPaddlePosX - ScreenPlayBallPosX);
	distXX = distX * distX;


	lengthSq = distXX + distYY;
	invLength = 1.0f / (0.0001f + sqrt(lengthSq));

	float distX_normalized2 = distX * invLength;
	float distY_normalized2 = distY * invLength;

	distX = static_cast<float>(ScreenPaddlePosX + 1 - ScreenPlayBallPosX);

	distXX = distX * distX;

	lengthSq = distXX + distYY;
	invLength = 1.0f / (0.0001f + sqrt(lengthSq));

	float distX_normalized3 = distX * invLength;
	float distY_normalized3 = distY * invLength;


	float dotProduct = Check_PlayBallFlightDir(static_cast<float>(ScreenPaddlePosX), static_cast<float>(ScreenPaddlePosY), movementDirX, movementDirY);

	if (dotProduct > accuracyValue)
	{
		DesiredOutputData[0] = 0.0f;
		DesiredOutputData[1] = 1.0f;
		DesiredOutputData[2] = 0.0f;
	}
	else
	{
		float dotProduct2 = Check_PlayBallFlightDir(static_cast<float>(ScreenPaddlePosX + 1), static_cast<float>(ScreenPaddlePosY), movementDirX, movementDirY);

		if (dotProduct2 > dotProduct)
		{
			DesiredOutputData[0] = 0.0f;
			DesiredOutputData[1] = 0.0f;
			DesiredOutputData[2] = 1.0f;
		}
		else
		{
			DesiredOutputData[0] = 1.0f;
			DesiredOutputData[1] = 0.0f;
			DesiredOutputData[2] = 0.0f;
		}
	}

	if (DesiredOutputData[0] == 1.0f && DesiredOutputData[1] == 0.0f && DesiredOutputData[2] == 0.0f)
	{
		if (neuralNetOutput1 > neuralNetOutput2 && neuralNetOutput1 > neuralNetOutput3)
			return neuralNetOutput1;
	}
	else if (DesiredOutputData[0] == 0.0f && DesiredOutputData[1] == 1.0f && DesiredOutputData[2] == 0.0f)
	{
		if (neuralNetOutput2 > neuralNetOutput1 && neuralNetOutput2 > neuralNetOutput3)
			return neuralNetOutput2;
	}

	else if (DesiredOutputData[0] == 0.0f && DesiredOutputData[1] == 0.0f && DesiredOutputData[2] == 1.0f)
	{
		if (neuralNetOutput3 > neuralNetOutput1 && neuralNetOutput3 > neuralNetOutput2)
			return neuralNetOutput3;
	}

	return -1.0f;
}

float CSimpleAIPlayer_Pong2::Calculate_FitnessScore(void)
{
	float velXX = PlayBallMovementX.Get_Actual_Output();
	velXX *= velXX;

	float velYY = PlayBallMovementY.Get_Actual_Output();
	velYY *= velYY;

	float lengthSq = velXX + velYY;
	float invLength = 1.0f / (0.0001f + sqrt(lengthSq));

	float movementDirX = PlayBallMovementX.Get_Actual_Output() * invLength;
	float movementDirY = PlayBallMovementY.Get_Actual_Output() * invLength;

	return Check_PlayBallFlightDir(static_cast<float>(ScreenPaddlePosX), static_cast<float>(ScreenPaddlePosY), movementDirX, movementDirY);
}

float CSimpleAIPlayer_Pong2::Check_PlayBallFlightDir(float targetPosX, float targetPosY, float movementDirX, float movementDirY)
{
	float distX = targetPosX - static_cast<float>(ScreenPlayBallPosX);
	float distY = targetPosY - static_cast<float>(ScreenPlayBallPosY);

	float distXX = distX * distX;
	float distYY = distY * distY;

	float lengthSq = distXX + distYY;
	float invLength = 1.0f / (0.0001f + sqrt(lengthSq));

	float distX_normalized = distX * invLength;
	float distY_normalized = distY * invLength;

	// dotProduct:
	return distX_normalized * movementDirX + distY_normalized * movementDirY;
}

///////////////////////////////

CSimpleAIPlayerPopulation_Pong1::CSimpleAIPlayerPopulation_Pong1()
{}

CSimpleAIPlayerPopulation_Pong1::~CSimpleAIPlayerPopulation_Pong1()
{
	delete[] pFitnessScoreArray;
	pFitnessScoreArray = nullptr;

	delete[] pNumOfMovementChangeArray;
	pNumOfMovementChangeArray = nullptr;

	delete[] pHumanPlayerPaddleArray;
	pHumanPlayerPaddleArray = nullptr;

	delete[] pAIPlayerPaddleArray;
	pAIPlayerPaddleArray = nullptr;

	delete[] pPlayBallArray;
	pPlayBallArray = nullptr;

	delete[] pSimulatedHumanPlayerArray;
	pSimulatedHumanPlayerArray = nullptr;

	delete[] pAIPlayerArray;
	pAIPlayerArray = nullptr;
}











void CSimpleAIPlayerPopulation_Pong1::Initialize(uint32_t populationSize, uint32_t numOfHiddenNeuronsL1, uint32_t numOfHiddenNeuronsL2, float maxPlayBallSpeed)
{
	MinNumOfHiddenNeuronsL1 = 0;
	MaxNumOfHiddenNeuronsL1 = 0;
	MinNumOfHiddenNeuronsL2 = 0;
	MaxNumOfHiddenNeuronsL2 = 0;

	delete[] pFitnessScoreArray;
	pFitnessScoreArray = nullptr;

	delete[] pNumOfMovementChangeArray;
	pNumOfMovementChangeArray = nullptr;

	delete[] pHumanPlayerPaddleArray;
	pHumanPlayerPaddleArray = nullptr;

	delete[] pAIPlayerPaddleArray;
	pAIPlayerPaddleArray = nullptr;

	delete[] pPlayBallArray;
	pPlayBallArray = nullptr;

	delete[] pSimulatedHumanPlayerArray;
	pSimulatedHumanPlayerArray = nullptr;

	delete[] pAIPlayerArray;
	pAIPlayerArray = nullptr;

	PopulationSize = populationSize;

	populationSize += 4;
	PopulationSizePlus4 = populationSize;

	pHumanPlayerPaddleArray = new (std::nothrow) CPaddle[populationSize];
	pAIPlayerPaddleArray = new (std::nothrow) CPaddle[populationSize];
	pPlayBallArray = new (std::nothrow) CBall[populationSize];

	pSimulatedHumanPlayerArray = new (std::nothrow) CSimpleAIPlayer_Pong1[populationSize];
	pAIPlayerArray = new (std::nothrow) CSimpleAIPlayer_Pong1[populationSize];

	pFitnessScoreArray = new (std::nothrow) float[populationSize];

	pNumOfMovementChangeArray = new (std::nothrow) int32_t[populationSize];

	for (uint32_t i = 0; i < populationSize; i++)
	{
		pFitnessScoreArray[i] = 0.0f;
		pNumOfMovementChangeArray[i] = 0;

		pHumanPlayerPaddleArray[i].Initialize(4);
		pAIPlayerPaddleArray[i].Initialize(4);
		pPlayBallArray[i].Initialize(maxPlayBallSpeed);

		pSimulatedHumanPlayerArray[i].Initialize(&pHumanPlayerPaddleArray[i], &pPlayBallArray[i], 0, 0, false);
		pAIPlayerArray[i].Initialize(&pAIPlayerPaddleArray[i], &pPlayBallArray[i], numOfHiddenNeuronsL1, numOfHiddenNeuronsL2);
	}
}

void CSimpleAIPlayerPopulation_Pong1::Initialize_Ext(uint32_t populationSize, uint32_t minNumOfHiddenNeuronsL1, uint32_t maxNumOfHiddenNeuronsL1, uint32_t minNumOfHiddenNeuronsL2, uint32_t maxNumOfHiddenNeuronsL2, float maxPlayBallSpeed)
{
	CRandomNumbersNN randomNumbers;

	MinNumOfHiddenNeuronsL1 = minNumOfHiddenNeuronsL1;
	MaxNumOfHiddenNeuronsL1 = maxNumOfHiddenNeuronsL1;
	MinNumOfHiddenNeuronsL2 = minNumOfHiddenNeuronsL2;
	MaxNumOfHiddenNeuronsL2 = maxNumOfHiddenNeuronsL2;

	delete[] pFitnessScoreArray;
	pFitnessScoreArray = nullptr;

	delete[] pNumOfMovementChangeArray;
	pNumOfMovementChangeArray = nullptr;

	delete[] pHumanPlayerPaddleArray;
	pHumanPlayerPaddleArray = nullptr;

	delete[] pAIPlayerPaddleArray;
	pAIPlayerPaddleArray = nullptr;

	delete[] pPlayBallArray;
	pPlayBallArray = nullptr;

	delete[] pSimulatedHumanPlayerArray;
	pSimulatedHumanPlayerArray = nullptr;

	delete[] pAIPlayerArray;
	pAIPlayerArray = nullptr;

	PopulationSize = populationSize;

	populationSize += 4;
	PopulationSizePlus4 = populationSize;

	pHumanPlayerPaddleArray = new (std::nothrow) CPaddle[populationSize];
	pAIPlayerPaddleArray = new (std::nothrow) CPaddle[populationSize];
	pPlayBallArray = new (std::nothrow) CBall[populationSize];

	pSimulatedHumanPlayerArray = new (std::nothrow) CSimpleAIPlayer_Pong1[populationSize];
	pAIPlayerArray = new (std::nothrow) CSimpleAIPlayer_Pong1[populationSize];

	pFitnessScoreArray = new (std::nothrow) float[populationSize];

	pNumOfMovementChangeArray = new (std::nothrow) int32_t[populationSize];

	for (uint32_t i = 0; i < populationSize; i++)
	{
		pFitnessScoreArray[i] = 0.0f;
		pNumOfMovementChangeArray[i] = 0;

		pHumanPlayerPaddleArray[i].Initialize(4);
		pAIPlayerPaddleArray[i].Initialize(4);
		pPlayBallArray[i].Initialize(maxPlayBallSpeed);

		pSimulatedHumanPlayerArray[i].Initialize(&pHumanPlayerPaddleArray[i], &pPlayBallArray[i], 0, 0, false);
		pAIPlayerArray[i].Initialize_Ext(&pAIPlayerPaddleArray[i], &pPlayBallArray[i], &randomNumbers, minNumOfHiddenNeuronsL1, maxNumOfHiddenNeuronsL1, minNumOfHiddenNeuronsL2, maxNumOfHiddenNeuronsL2);
	}
}

void CSimpleAIPlayerPopulation_Pong1::Change_Seed(uint64_t seed)
{
	Seed = seed;
}



void CSimpleAIPlayerPopulation_Pong1::RandomChange_OutputSynapsePlasticities(uint64_t seed, float minSynapticPlasticity, float maxSynapticPlasticity)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		pAIPlayerArray[i].Brain.RandomChange_OutputSynapsePlasticities(seed++, minSynapticPlasticity, maxSynapticPlasticity);
	}
}

void CSimpleAIPlayerPopulation_Pong1::RandomChange_OutputSynapsePlasticities(uint64_t seed, float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRate)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		pAIPlayerArray[i].Brain.RandomChange_OutputSynapsePlasticities(seed++, minSynapticPlasticity, maxSynapticPlasticity, mutationRate);
	}
}

void CSimpleAIPlayerPopulation_Pong1::RandomChange_OutputSynapsePlasticities(float minSynapticPlasticity, float maxSynapticPlasticity)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		pAIPlayerArray[i].Brain.RandomChange_OutputSynapsePlasticities(Seed++, minSynapticPlasticity, maxSynapticPlasticity);
	}
}

void CSimpleAIPlayerPopulation_Pong1::RandomChange_OutputSynapsePlasticities(float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRate)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		pAIPlayerArray[i].Brain.RandomChange_OutputSynapsePlasticities(Seed++, minSynapticPlasticity, maxSynapticPlasticity, mutationRate);
	}
}







void CSimpleAIPlayerPopulation_Pong1::Init_Play_and_Evaluate_NewTrainingSequence(uint32_t trainingGameLengthMax, uint32_t numTrainingGames)
{
	float OutputData[3];

	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		pFitnessScoreArray[i] = 0.0f;
		pNumOfMovementChangeArray[i] = 0;
	}

	for (uint32_t j = 0; j < numTrainingGames; j++)
	{
		float playBallVelocityX = RandomNumbers.Get_FloatNumber(-1.0f, 1.0f);
		float playBallVelocityY = -1.0f;

		float velXX = playBallVelocityX * playBallVelocityX;
		float velYY = 1.0f;

		float lengthSq = velXX + velYY;
		float invLength = 1.0f / (0.0001f + sqrt(lengthSq));

		playBallVelocityX *= invLength;
		playBallVelocityY *= invLength;

		for (uint32_t i = 0; i < PopulationSizePlus4; i++)
		{
			pPlayBallArray[i].Set_Pos(0.5f * fConstGameBoardSizeX - 1.0f, 0.5f * fConstGameBoardSizeY);
			pPlayBallArray[i].Set_Velocity(playBallVelocityX, playBallVelocityY);

			pHumanPlayerPaddleArray[i].Set_Pos(0.5f * fConstGameBoardSizeX - 1.0f, fConstGameBoardSizeYMinus1 - 2.0f);
			pAIPlayerPaddleArray[i].Set_Pos(0.5f * fConstGameBoardSizeX - 1.0f, 2.0f);


			pHumanPlayerPaddleArray[i].Set_Velocity(0.0f);
			pAIPlayerPaddleArray[i].Set_Velocity(0.0f);

			pSimulatedHumanPlayerArray[i].Reset_Memories();
			pAIPlayerArray[i].Reset_Memories();

			Init_Or_Reset_fGameBoardArray();

			pPlayBallArray[i].fDrawIntoBuffer();
			pAIPlayerPaddleArray[i].fDrawIntoBuffer();
	
			for (uint32_t k = 0; k < trainingGameLengthMax; k++)
			{
				pAIPlayerArray[i].GameObjectDetection_And_VelocityCalculations();
				pSimulatedHumanPlayerArray[i].GameObjectDetection_And_VelocityCalculations();
				Init_Or_Reset_fGameBoardArray();

				// HumanPlayer:
				pSimulatedHumanPlayerArray[i].Calculate_PaddleMovement(0.5f, 0.0f, 0.99f);

				// NeuralNetPlayer:
				if (pAIPlayerArray[i].Calculate_NeuralNetPaddleMovement(0.5f, 0.0f, 0.99f) == -1)
					pNumOfMovementChangeArray[i]++;

				pPlayBallArray[i].Movement();

				pHumanPlayerPaddleArray[i].Handle_Possible_PlayBallCollision(&pPlayBallArray[i], false);
				pAIPlayerPaddleArray[i].Handle_Possible_PlayBallCollision(&pPlayBallArray[i], true);

				pPlayBallArray[i].fDrawIntoBuffer();
				pAIPlayerPaddleArray[i].fDrawIntoBuffer();

				pAIPlayerArray[i].Brain.Get_Output(OutputData);		
				pFitnessScoreArray[i] += pAIPlayerArray[i].Calculate_FitnessScore(0.99f, OutputData[0], OutputData[1], OutputData[2]);
				//pFitnessScoreArray[i] += pAIPlayerArray[i].Calculate_FitnessScore();

				if (pPlayBallArray[i].Check_Possible_LowerWallCollision() == true)
					break;
				else if (pPlayBallArray[i].Check_Possible_UpperWallCollision() == true)
					break;
			} // end of for (uint32_t k = 0; k < trainingGameLengthMax; k++)
		} // end of for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	} // end of for (uint32_t j = 0; j < numTrainingGames; j++)
}



void CSimpleAIPlayerPopulation_Pong1::RandomReduce_BrainConnections(uint64_t seed, float mutationRateL1, float mutationRateL2, float mutationRateL3)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		pAIPlayerArray[i].Brain.Disable_Random_InputNeuron_OutputSynapses(seed++, mutationRateL1);
		pAIPlayerArray[i].Brain.Disable_Random_HiddenLayer1Neuron_OutputSynapses(seed++, mutationRateL2);
		pAIPlayerArray[i].Brain.Disable_Random_HiddenLayer2Neuron_OutputSynapses(seed++, mutationRateL3);
	}
}

void CSimpleAIPlayerPopulation_Pong1::RandomReduce_BrainConnections(float mutationRateL1, float mutationRateL2, float mutationRateL3)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		pAIPlayerArray[i].Brain.Disable_Random_InputNeuron_OutputSynapses(Seed++, mutationRateL1);
		pAIPlayerArray[i].Brain.Disable_Random_HiddenLayer1Neuron_OutputSynapses(Seed++, mutationRateL2);
		pAIPlayerArray[i].Brain.Disable_Random_HiddenLayer2Neuron_OutputSynapses(Seed++, mutationRateL3);
	}
}







///////////////////////////////

CSimpleAIPlayerPopulation_Pong2::CSimpleAIPlayerPopulation_Pong2()
{}

CSimpleAIPlayerPopulation_Pong2::~CSimpleAIPlayerPopulation_Pong2()
{
	delete[] pFitnessScoreArray;
	pFitnessScoreArray = nullptr;

	delete[] pNumOfMovementChangeArray;
	pNumOfMovementChangeArray = nullptr;

	delete[] pHumanPlayerPaddleArray;
	pHumanPlayerPaddleArray = nullptr;

	delete[] pAIPlayerPaddleArray;
	pAIPlayerPaddleArray = nullptr;

	delete[] pPlayBallArray;
	pPlayBallArray = nullptr;

	delete[] pSimulatedHumanPlayerArray;
	pSimulatedHumanPlayerArray = nullptr;

	delete[] pAIPlayerArray;
	pAIPlayerArray = nullptr;
}














void CSimpleAIPlayerPopulation_Pong2::Initialize(uint32_t populationSize, uint32_t numOfHiddenNeuronsL1, uint32_t numOfHiddenNeuronsL2, float maxPlayBallSpeed)
{
	MinNumOfHiddenNeuronsL1 = 0;
	MaxNumOfHiddenNeuronsL1 = 0;
	MinNumOfHiddenNeuronsL2 = 0;
	MaxNumOfHiddenNeuronsL2 = 0;

	delete[] pFitnessScoreArray;
	pFitnessScoreArray = nullptr;

	delete[] pNumOfMovementChangeArray;
	pNumOfMovementChangeArray = nullptr;

	delete[] pHumanPlayerPaddleArray;
	pHumanPlayerPaddleArray = nullptr;

	delete[] pAIPlayerPaddleArray;
	pAIPlayerPaddleArray = nullptr;

	delete[] pPlayBallArray;
	pPlayBallArray = nullptr;

	delete[] pSimulatedHumanPlayerArray;
	pSimulatedHumanPlayerArray = nullptr;

	delete[] pAIPlayerArray;
	pAIPlayerArray = nullptr;

	
	PopulationSize = populationSize;

	populationSize += 4;
	PopulationSizePlus4 = populationSize;

	pHumanPlayerPaddleArray = new (std::nothrow) CPaddle[populationSize];
	pAIPlayerPaddleArray = new (std::nothrow) CPaddle[populationSize];
	pPlayBallArray = new (std::nothrow) CBall[populationSize];

	pSimulatedHumanPlayerArray = new (std::nothrow) CSimpleAIPlayer_Pong2[populationSize];
	pAIPlayerArray = new (std::nothrow) CSimpleAIPlayer_Pong2[populationSize];

	pFitnessScoreArray = new (std::nothrow) float[populationSize];

	pNumOfMovementChangeArray = new (std::nothrow) int32_t[populationSize];

	for (uint32_t i = 0; i < populationSize; i++)
	{
		pFitnessScoreArray[i] = 0.0f;
		pNumOfMovementChangeArray[i] = 0;

		pHumanPlayerPaddleArray[i].Initialize(4);
		pAIPlayerPaddleArray[i].Initialize(4);
		pPlayBallArray[i].Initialize(maxPlayBallSpeed);

		pSimulatedHumanPlayerArray[i].Initialize(&pHumanPlayerPaddleArray[i], &pPlayBallArray[i], 0, 0, false);
		pAIPlayerArray[i].Initialize(&pAIPlayerPaddleArray[i], &pPlayBallArray[i], numOfHiddenNeuronsL1, numOfHiddenNeuronsL2);
	}
}

void CSimpleAIPlayerPopulation_Pong2::Initialize_Ext(uint32_t populationSize, uint32_t minNumOfHiddenNeuronsL1, uint32_t maxNumOfHiddenNeuronsL1, uint32_t minNumOfHiddenNeuronsL2, uint32_t maxNumOfHiddenNeuronsL2, float maxPlayBallSpeed)
{
	CRandomNumbersNN randomNumbers;

	MinNumOfHiddenNeuronsL1 = minNumOfHiddenNeuronsL1;
	MaxNumOfHiddenNeuronsL1 = maxNumOfHiddenNeuronsL1;
	MinNumOfHiddenNeuronsL2 = minNumOfHiddenNeuronsL2;
	MaxNumOfHiddenNeuronsL2 = maxNumOfHiddenNeuronsL2;

	delete[] pFitnessScoreArray;
	pFitnessScoreArray = nullptr;

	delete[] pNumOfMovementChangeArray;
	pNumOfMovementChangeArray = nullptr;

	delete[] pHumanPlayerPaddleArray;
	pHumanPlayerPaddleArray = nullptr;

	delete[] pAIPlayerPaddleArray;
	pAIPlayerPaddleArray = nullptr;

	delete[] pPlayBallArray;
	pPlayBallArray = nullptr;

	delete[] pSimulatedHumanPlayerArray;
	pSimulatedHumanPlayerArray = nullptr;

	delete[] pAIPlayerArray;
	pAIPlayerArray = nullptr;

	PopulationSize = populationSize;

	populationSize += 4;
	PopulationSizePlus4 = populationSize;

	pHumanPlayerPaddleArray = new (std::nothrow) CPaddle[populationSize];
	pAIPlayerPaddleArray = new (std::nothrow) CPaddle[populationSize];
	pPlayBallArray = new (std::nothrow) CBall[populationSize];

	pSimulatedHumanPlayerArray = new (std::nothrow) CSimpleAIPlayer_Pong2[populationSize];
	pAIPlayerArray = new (std::nothrow) CSimpleAIPlayer_Pong2[populationSize];

	pFitnessScoreArray = new (std::nothrow) float[populationSize];

	pNumOfMovementChangeArray = new (std::nothrow) int32_t[populationSize];

	for (uint32_t i = 0; i < populationSize; i++)
	{
		pFitnessScoreArray[i] = 0.0f;
		pNumOfMovementChangeArray[i] = 0;

		pHumanPlayerPaddleArray[i].Initialize(4);
		pAIPlayerPaddleArray[i].Initialize(4);
		pPlayBallArray[i].Initialize(maxPlayBallSpeed);

		pSimulatedHumanPlayerArray[i].Initialize(&pHumanPlayerPaddleArray[i], &pPlayBallArray[i], 0, 0, false);
		pAIPlayerArray[i].Initialize_Ext(&pAIPlayerPaddleArray[i], &pPlayBallArray[i], &randomNumbers, minNumOfHiddenNeuronsL1, maxNumOfHiddenNeuronsL1, minNumOfHiddenNeuronsL2, maxNumOfHiddenNeuronsL2);
	}
}



void CSimpleAIPlayerPopulation_Pong2::Change_Seed(uint64_t seed)
{
	Seed = seed;
}



void CSimpleAIPlayerPopulation_Pong2::RandomChange_OutputSynapsePlasticities(uint64_t seed, float minSynapticPlasticity, float maxSynapticPlasticity)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		pAIPlayerArray[i].Brain.RandomChange_OutputSynapsePlasticities(seed++, minSynapticPlasticity, maxSynapticPlasticity);
	}
}

void CSimpleAIPlayerPopulation_Pong2::RandomChange_OutputSynapsePlasticities(uint64_t seed, float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRate)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		pAIPlayerArray[i].Brain.RandomChange_OutputSynapsePlasticities(seed++, minSynapticPlasticity, maxSynapticPlasticity, mutationRate);
	}
}

void CSimpleAIPlayerPopulation_Pong2::RandomChange_OutputSynapsePlasticities(float minSynapticPlasticity, float maxSynapticPlasticity)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		pAIPlayerArray[i].Brain.RandomChange_OutputSynapsePlasticities(Seed++, minSynapticPlasticity, maxSynapticPlasticity);
	}
}

void CSimpleAIPlayerPopulation_Pong2::RandomChange_OutputSynapsePlasticities(float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRate)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		pAIPlayerArray[i].Brain.RandomChange_OutputSynapsePlasticities(Seed++, minSynapticPlasticity, maxSynapticPlasticity, mutationRate);
	}
}

void CSimpleAIPlayerPopulation_Pong2::RandomReduce_BrainConnections(uint64_t seed, float mutationRateL1, float mutationRateL2, float mutationRateL3)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		pAIPlayerArray[i].Brain.Disable_Random_InputNeuron_OutputSynapses(seed++, mutationRateL1);
		pAIPlayerArray[i].Brain.Disable_Random_HiddenLayer1Neuron_OutputSynapses(seed++, mutationRateL2);
		pAIPlayerArray[i].Brain.Disable_Random_HiddenLayer2Neuron_OutputSynapses(seed++, mutationRateL3);
	}
}

void CSimpleAIPlayerPopulation_Pong2::RandomReduce_BrainConnections(float mutationRateL1, float mutationRateL2, float mutationRateL3)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		pAIPlayerArray[i].Brain.Disable_Random_InputNeuron_OutputSynapses(Seed++, mutationRateL1);
		pAIPlayerArray[i].Brain.Disable_Random_HiddenLayer1Neuron_OutputSynapses(Seed++, mutationRateL2);
		pAIPlayerArray[i].Brain.Disable_Random_HiddenLayer2Neuron_OutputSynapses(Seed++, mutationRateL3);
	}
}







void CSimpleAIPlayerPopulation_Pong2::Init_Play_and_Evaluate_NewTrainingSequence(uint32_t trainingGameLengthMax, uint32_t numTrainingGames)
{
	float OutputData[3];

	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		pFitnessScoreArray[i] = 0.0f;
		pNumOfMovementChangeArray[i] = 0;
	}


	for (uint32_t j = 0; j < numTrainingGames; j++)
	{
		float playBallVelocityX = RandomNumbers.Get_FloatNumber(-1.0f, 1.0f);
		float playBallVelocityY = -1.0f;

		float velXX = playBallVelocityX * playBallVelocityX;
		float velYY = 1.0f;

		float lengthSq = velXX + velYY;
		float invLength = 1.0f / (0.0001f + sqrt(lengthSq));

		playBallVelocityX *= invLength;
		playBallVelocityY *= invLength;

		for (uint32_t i = 0; i < PopulationSizePlus4; i++)
		{
			pPlayBallArray[i].Set_Pos(0.5f * fConstGameBoardSizeX - 1.0f, 0.5f * fConstGameBoardSizeY);
			pPlayBallArray[i].Set_Velocity(playBallVelocityX, playBallVelocityY);

			pHumanPlayerPaddleArray[i].Set_Pos(0.5f * fConstGameBoardSizeX - 1.0f, fConstGameBoardSizeYMinus1 - 2.0f);
			pAIPlayerPaddleArray[i].Set_Pos(0.5f * fConstGameBoardSizeX - 1.0f, 2.0f);


			pHumanPlayerPaddleArray[i].Set_Velocity(0.0f);
			pAIPlayerPaddleArray[i].Set_Velocity(0.0f);

			pSimulatedHumanPlayerArray[i].Reset_Memories();
			pAIPlayerArray[i].Reset_Memories();

			Init_Or_Reset_fGameBoardArray();

			pPlayBallArray[i].fDrawIntoBuffer();
			pAIPlayerPaddleArray[i].fDrawIntoBuffer();
	
			for (uint32_t k = 0; k < trainingGameLengthMax; k++)
			{
				pAIPlayerArray[i].GameObjectDetection_And_VelocityCalculations();
				pSimulatedHumanPlayerArray[i].GameObjectDetection_And_VelocityCalculations();
				Init_Or_Reset_fGameBoardArray();

				// HumanPlayer:
				pSimulatedHumanPlayerArray[i].Calculate_PaddleMovement(0.5f, 0.0f, 0.99f);

				// NeuralNetPlayer:
				if (pAIPlayerArray[i].Calculate_NeuralNetPaddleMovement(0.5f, 0.0f, 0.99f) == -1)
					pNumOfMovementChangeArray[i]++;

				pPlayBallArray[i].Movement();

				pHumanPlayerPaddleArray[i].Handle_Possible_PlayBallCollision(&pPlayBallArray[i], false);
				pAIPlayerPaddleArray[i].Handle_Possible_PlayBallCollision(&pPlayBallArray[i], true);

				pPlayBallArray[i].fDrawIntoBuffer();
				pAIPlayerPaddleArray[i].fDrawIntoBuffer();

				pAIPlayerArray[i].Brain.Get_Output(OutputData);
				pFitnessScoreArray[i] += pAIPlayerArray[i].Calculate_FitnessScore(0.99f, OutputData[0], OutputData[1], OutputData[2]);
				//pFitnessScoreArray[i] += pAIPlayerArray[i].Calculate_FitnessScore();

				if (pPlayBallArray[i].Check_Possible_LowerWallCollision() == true)
					break;
				else if (pPlayBallArray[i].Check_Possible_UpperWallCollision() == true)
					break;
			} // end of for (uint32_t k = 0; k < trainingGameLengthMax; k++)
		} // end of for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	} // end for (uint32_t j = 0; j < numTrainingGames; j++)
}


///////////////////////////////



void Init_New_Game(CPaddle *pPlayerPaddle, CPaddle *pAIPaddle, CBall *pPlayBall, float playBallVelocityX, float playBallVelocityY, bool *pStarted, int32_t *pPlayerScore, int32_t *pAIScore)
{
	pPlayBall->Set_Pos(0.5f * fConstGameBoardSizeX - 1.0f, 0.5f * fConstGameBoardSizeY);
	pPlayBall->Set_Velocity(playBallVelocityX, playBallVelocityY);


	pPlayerPaddle->Set_Pos(0.5f * fConstGameBoardSizeX - 1.0f, fConstGameBoardSizeYMinus1 - 2.0f);
	pAIPaddle->Set_Pos(0.5f * fConstGameBoardSizeX - 1.0f, 2.0f);


	pPlayerPaddle->Set_Velocity(0.0f);
	pAIPaddle->Set_Velocity(0.0f);

	*pStarted = false;
}

void Init_NeuralNetPopulation(CNeuralNetPopulation *pNeuralNetPopulation, CSimpleAIPlayerPopulation_Pong1 *pAIPlayerPopulation)
{
	for (uint32_t i = 0; i < pAIPlayerPopulation->PopulationSizePlus4; i++)
	{
		pNeuralNetPopulation->ppUsedNeuralNetArray[i] = &pAIPlayerPopulation->pAIPlayerArray[i].Brain;
	}
}

void Init_NeuralNetPopulation(CNeuralNetPopulation *pNeuralNetPopulation, CSimpleAIPlayerPopulation_Pong2 *pAIPlayerPopulation)
{
	for (uint32_t i = 0; i < pAIPlayerPopulation->PopulationSizePlus4; i++)
	{
		pNeuralNetPopulation->ppUsedNeuralNetArray[i] = &pAIPlayerPopulation->pAIPlayerArray[i].Brain;
	}
}







