#define index_page ""\
"<html>\n"\
    "<head>\n"\
	    "<title>LED Switch</title>\n"\
		"<meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>\n"\
        "<script>\n"\
        "function load(element,endPoint) { \n"\
           "var xhttp = new XMLHttpRequest(); \n"\
           "xhttp.onreadystatechange = function() {\n"\
               "if (this.readyState == 4 && this.status == 200) {\n"\
               "document.getElementById(element).innerHTML = this.responseText; \n"\
               "} \n"\
           "} \n"\
        "xhttp.open('GET', endPoint, true);\n"\
        "xhttp.send(); \n"\
        "} \n"\
		"function init(){ \n"\
		    "if (typeof lock == 'undefined'){load('data','led.cgi');lock=1;}\n"\
		"}\n"\
        "</script>\n"\
    "</head>\n"\
    "<body onload='init()'>\n"\
	    "<div id='data'  onclick=load('data','led.cgi') style='width:100px; border-width:2px;' >\n"\
	    "</div>\n"\
    "</body>\n"\
"</html>\n"

#define led_on "<a href='#'><svg width=100 height=100 xmlns='http://www.w3.org/2000/svg' version='1.1'>\n"\
            "<path d='M40,30 A10,10 0 0 1 60,30 L60,45 L 64,45 L64,50 L36,50 L36,45 L40,45Z'\n"\
            "style='fill:lawngreen; stroke:black; stroke-width:2px;' /> \n"\
            "<line x1=44 y1=50 x2=44 y2=100 style='stroke:black; stroke-width:2px;' />\n"\
            "<line x1=56 y1=50 x2=56 y2=90  style='stroke:black; stroke-width:2px;' />\n"\
        "<svg></a>"

#define led_off "<a href='#'><svg width=100 height=100 xmlns='http://www.w3.org/2000/svg' version='1.1'>\n"\
            "<path d='M40,30 A10,10 0 0 1 60,30 L60,45 L 64,45 L64,50 L36,50 L36,45 L40,45Z'\n"\
            "style='fill:gray; stroke:black; stroke-width:2px;' /> \n"\
            "<line x1=44 y1=50 x2=44 y2=100 style='stroke:black; stroke-width:2px;' />\n"\
            "<line x1=56 y1=50 x2=56 y2=90  style='stroke:black; stroke-width:2px;' />\n"\
        "<svg></a>"
