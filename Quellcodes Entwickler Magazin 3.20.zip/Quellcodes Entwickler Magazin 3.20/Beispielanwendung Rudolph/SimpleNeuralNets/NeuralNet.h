// Schutz vor Mehrfachdeklarationen:

#ifndef _NeuralNet_H_
#define _NeuralNet_H_

#include <iostream>
#include <fstream>

#ifndef max
#define max(a,b)    ( ((a) > (b)) ? (a) : (b) )
#endif

#ifndef min
#define min(a,b)    ( ((a) < (b)) ? (a) : (b) )
#endif

//sigmoid(x) = 0.5f + 0.25f*x - 1.0f/48.0f*x*x*x + 1.0f/480.0f*x*x*x*x*x
// tanh(x) = x - 1.0f/3.0f*x*x*x+2.0f/15.0f**x*x*x*x*x


inline float SigmoidActivationFunc(float neuronInput)
{
	// von 0.0f bis 1.0f:
	return 1.0f / (1.0f + exp(-neuronInput));
}

inline float ScaledSigmoidActivationFunc(float neuronInput)
{
	// von 0.0f bis 1.0f:
	return 1.0f / (1.0f + exp(-10.0f * neuronInput));
}

inline float SineActivationFunc(float neuronInput)
{
	// von -1.0f bis 1.0f:
	return sin(neuronInput);
}

inline float CosineActivationFunc(float neuronInput)
{
	// von -1.0f bis 1.0f:
	return cos(neuronInput);
}


inline float TanHActivationFunc(float neuronInput)
{
	// von -1.0f bis 1.0f:
	return tanh(neuronInput);
}

inline float ScaledTanHActivationFunc(float neuronInput)
{
	return tanh(0.1f * neuronInput);
}

inline float FastTanHReplacementActivationFunc(float neuronInput)
{
	// von -1.0f bis 1.0f:
	return neuronInput / (1.0f + abs(neuronInput));
}

inline float ReLUActivationFunc(float neuronInput)
{
	// von 0.0f bis unendlich:
	return max(0.0f, neuronInput);
}

inline float ClippedReLUActivationFunc(float neuronInput)
{
	if (neuronInput < 0.0f)
		return 0.0f;
	else
	{
		return min(1.0f, neuronInput);
	}
}

inline float LeakyReLUActivationFunc(float neuronInput)
{
	if (neuronInput < 0.0f)
		return 0.01f * neuronInput;
	else
		return neuronInput;
}

inline float ClippedLeakyReLUActivationFunc(float neuronInput)
{
	if (neuronInput < 0.0f)
		return max(-1.0f, 0.01f * neuronInput);
	else
	{
		return min(1.0f, neuronInput);
	}
}



inline float BinaryOutputActivationFunc1(float neuronInput)
{
	//if (neuronInput > 0.9999f)
	//return 1.0f;

	// less accuracy
	if (neuronInput > 0.9f)
		return 1.0f;

	return 0.0f;
}

inline float BinaryOutputActivationFunc2(float neuronInput)
{
	if (neuronInput > 0.4999f)
		return 1.0f;

	return 0.0f;
}


inline float ClippedLinearActivationFunc(float neuronInput)
{
	if (neuronInput > 1.0f)
		neuronInput = 1.0f;
	else if (neuronInput < -1.0f)
		neuronInput = -1.0f;

	return neuronInput;
}

inline float LinearActivationFunc(float neuronInput)
{
	return neuronInput;
}


inline float ConstantError(float neuronOutput)
{
	return 1.0f;
}

inline float LinearError(float neuronOutput)
{
	return neuronOutput;
}

inline float GaussianError(float neuronOutput)
{
	return exp(-(neuronOutput*neuronOutput));
}

inline float DerivedSigmoidError(float neuronOutput)
{
	return neuronOutput * (1.0f - neuronOutput);
}


// Definition eines Funktionszeiger-Typs:
typedef float(*pActivationFunc)(float inputActivity);

// Definition eines Funktionszeiger-Typs:
typedef float(*pErrorFunc)(float neuronOutput);




inline void Init_1DimArray(float *pInputOutputArray, /*numArrayElements:*/ uint32_t arraySize, float value)
{
	for (uint32_t i = 0; i < arraySize; i++)
		pInputOutputArray[i] = value;
}

inline void Copy_1DimArray(float *pOutputArray, const float *pInputArray, /*numArrayElements:*/ uint32_t arraySize)
{
	for (uint32_t i = 0; i < arraySize; i++)
		pOutputArray[i] = pInputArray[i];
}

inline void Init_2DimArray(float *pInputOutputArray, uint32_t arraySizeX, uint32_t arraySizeY, float value)
{
	uint32_t numArrayElements = arraySizeX * arraySizeY;

	for (uint32_t i = 0; i < numArrayElements; i++)
		pInputOutputArray[i] = value;
}

inline void Copy_2DimArray(float *pOutputArray, const float *pInputArray, uint32_t arraySizeX, uint32_t arraySizeY)
{
	uint32_t numArrayElements = arraySizeX * arraySizeY;

	for (uint32_t i = 0; i < numArrayElements; i++)
		pOutputArray[i] = pInputArray[i];
}


inline void Copy_FromInputToOutputArray(float *pOutputArray, const float *pInputArray, uint32_t inputArraySizeX, uint32_t inputArraySizeY, uint32_t copySizeX, uint32_t copySizeY, uint32_t inputArrayOffsetX, uint32_t inputArrayOffsetY)
{
	uint32_t ixInputMin = inputArrayOffsetX;
	uint32_t ixInputMax = min(inputArraySizeX,  ixInputMin + copySizeX);

	uint32_t iyInputMin = inputArrayOffsetY;
	uint32_t iyInputMax = min(inputArraySizeY, iyInputMin + copySizeY);

	uint32_t ixInput, iyInput, idInput;
	uint32_t counter = 0;

	for (iyInput = iyInputMin; iyInput < iyInputMax; iyInput++)
	{
		for (ixInput = ixInputMin; ixInput < ixInputMax; ixInput++)
		{
			idInput = ixInput + inputArraySizeX*iyInput;

			pOutputArray[counter] = pInputArray[idInput];
			counter++;
		}
	}
}

inline void Bisect_Resolution(float *pOutputArray, const float *pInputArray, uint32_t inputArraySizeX, uint32_t inputArraySizeY)
{
	uint32_t ixInput, iyInput, tempIy1, tempIy2, idInput;
	uint32_t counter = 0;

	float tempValue;

	for (iyInput = 0; iyInput < inputArraySizeY; iyInput += 2)
	{
		for (ixInput = 0; ixInput < inputArraySizeX; ixInput += 2)
		{
			tempIy1 = inputArraySizeX*iyInput;
			tempIy2 = inputArraySizeX*(iyInput + 1);

			idInput = ixInput + tempIy1;
			tempValue = pInputArray[idInput];

			idInput = idInput + 1;
			tempValue += pInputArray[idInput];

			idInput = ixInput + tempIy2;
			tempValue += pInputArray[idInput];

			idInput = idInput + 1;
			tempValue += pInputArray[idInput];

			tempValue *= 0.25f;

			pOutputArray[counter] = tempValue;
			counter++;
		}
	}
}

inline void MaxPooling2x2(float *pOutputArray, const float *pInputArray, uint32_t inputArraySizeX, uint32_t inputArraySizeY)
{
	uint32_t ixInput, iyInput, tempIy1, tempIy2, idInput;
	uint32_t counter = 0;

	float maxValue;

	for (iyInput = 0; iyInput < inputArraySizeY; iyInput += 2)
	{
		for (ixInput = 0; ixInput < inputArraySizeX; ixInput += 2)
		{
			tempIy1 = inputArraySizeX*iyInput;
			tempIy2 = inputArraySizeX*(iyInput + 1);

			idInput = ixInput + tempIy1;
			maxValue = pInputArray[idInput];

			idInput = idInput + 1;
			maxValue = max(maxValue, pInputArray[idInput]);

			idInput = ixInput + tempIy2;
			maxValue = max(maxValue, pInputArray[idInput]);

			idInput = idInput + 1;
			maxValue = max(maxValue, pInputArray[idInput]);

			pOutputArray[counter] = maxValue;
			counter++;
		}
	}
}

inline void L2Pooling2x2(float *pOutputArray, const float *pInputArray, uint32_t inputArraySizeX, uint32_t inputArraySizeY)
{
	uint32_t ixInput, iyInput, tempIy1, tempIy2, idInput;
	uint32_t counter = 0;

	float tempValue, tempValue2;

	for (iyInput = 0; iyInput < inputArraySizeY; iyInput += 2)
	{
		for (ixInput = 0; ixInput < inputArraySizeX; ixInput += 2)
		{
			tempIy1 = inputArraySizeX*iyInput;
			tempIy2 = inputArraySizeX*(iyInput + 1);

			idInput = ixInput + tempIy1;
			tempValue2 = pInputArray[idInput];
			tempValue = tempValue2 * tempValue2;

			idInput = idInput + 1;
			tempValue2 = pInputArray[idInput];
			tempValue += tempValue2 * tempValue2;

			idInput = ixInput + tempIy2;
			tempValue2 = pInputArray[idInput];
			tempValue += tempValue2 * tempValue2;

			idInput = idInput + 1;
			tempValue2 = pInputArray[idInput];
			tempValue += tempValue2 * tempValue2;

			pOutputArray[counter] = sqrt(tempValue);
			counter++;
		}
	}
}



inline void Calculate_FeatureMap(float *pFeatureMap, const float *pInputArray, int32_t inputArraySizeX, int32_t inputArraySizeY,
	const float *pKernelArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY)
{
	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput,iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;
	
	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = 0.0f;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] = sumOfProductValues;
			counter++;
	
		}
	}
}

inline void Add_Feature_To_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputArraySizeX, int32_t inputArraySizeY,
	const float *pKernelArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY)
{
	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = 0.0f;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] += sumOfProductValues;
			counter++;
		}
	}
}

inline void Calculate_FeatureMap(float *pFeatureMap, const float *pInputArray, int32_t inputSizeX, int32_t inputSizeY,
	int32_t paddingSizeX, int32_t paddingSizeY, const float *pKernelArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY)
{
	int32_t inputArraySizeX = inputSizeX + 2 * paddingSizeX;
	int32_t inputArraySizeY = inputSizeY + 2 * paddingSizeY;

	int32_t featureSizeX = (inputArraySizeX - kernelSizeX) / strideX;
	featureSizeX++;

	int32_t featureSizeY = (inputArraySizeY - kernelSizeY) / strideY;
	featureSizeY++;

	
	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = 0.0f;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelArray[ixKernel + halfKernelSizeX + iiyKernel];
					
					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] = sumOfProductValues;
			counter++;
		}
	}
}

inline void Add_Feature_To_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputSizeX, int32_t inputSizeY,
	int32_t paddingSizeX, int32_t paddingSizeY, const float *pKernelArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY)
{
	int32_t inputArraySizeX = inputSizeX + 2 * paddingSizeX;
	int32_t inputArraySizeY = inputSizeY + 2 * paddingSizeY;

	int32_t featureSizeX = (inputArraySizeX - kernelSizeX) / strideX;
	featureSizeX++;

	int32_t featureSizeY = (inputArraySizeY - kernelSizeY) / strideY;
	featureSizeY++;


	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = 0.0f;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] += sumOfProductValues;
			counter++;
		}
	}
}


inline void Modify_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, /*numArrayElements:*/ uint32_t arraySize, pActivationFunc pFunc)
{
	for (uint32_t i = 0; i < arraySize; i++)
		pFeatureMap[i] = pFunc(pFeatureMap[i]);
}

inline void Modify_FeatureMap(float *pOutputFeatureMap, const float *pInputFeatureMap, /*numArrayElements:*/ uint32_t arraySize, pActivationFunc pFunc)
{
	for (uint32_t i = 0; i < arraySize; i++)
		pOutputFeatureMap[i] = pFunc(pInputFeatureMap[i]);
}

inline void Modify_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, uint32_t arraySizeX, uint32_t arraySizeY, pActivationFunc pFunc)
{
	uint32_t numArrayElements = arraySizeX * arraySizeY;

	for (uint32_t i = 0; i < numArrayElements; i++)
		pFeatureMap[i] = pFunc(pFeatureMap[i]);
}

inline void Modify_FeatureMap(float *pOutputFeatureMap, const float *pInputFeatureMap, uint32_t arraySizeX, uint32_t arraySizeY, pActivationFunc pFunc)
{
	uint32_t numArrayElements = arraySizeX * arraySizeY;

	for (uint32_t i = 0; i < numArrayElements; i++)
		pOutputFeatureMap[i] = pFunc(pInputFeatureMap[i]);
}


inline void SoftMax(float* pOutputData, const float* pInputData, uint32_t numElements)
{
	float maxValue = pInputData[0];

	for (uint32_t i = 1; i < numElements; i++)
	{
		if (pInputData[i] > maxValue)
			maxValue = pInputData[i];
	}

	float tempfloat = 0.00000001f;

	for (uint32_t i = 0; i < numElements; i++)
		tempfloat += exp(pInputData[i] - maxValue);

	/*tempfloat = 1.0f / tempfloat;

	for (uint32_t i = 0; i < numElements; i++)
		pOutputData[i] = exp(pInputData[i] - maxValue)*tempfloat;*/

	float offset = maxValue + log(tempfloat);

	for (uint32_t i = 0; i < numElements; i++)
		pOutputData[i] = exp(pInputData[i] - offset);
}

inline void SoftMax(float* pInputOutputData, uint32_t numElements)
{
	float maxValue = pInputOutputData[0];

	for (uint32_t i = 1; i < numElements; i++)
	{
		if (pInputOutputData[i] > maxValue)
			maxValue = pInputOutputData[i];
	}

	float tempfloat = 0.00000001f;

	for (uint32_t i = 0; i < numElements; i++)
		tempfloat += exp(pInputOutputData[i] - maxValue);

	/*tempfloat = 1.0f / tempfloat;

	for (uint32_t i = 0; i < numElements; i++)
		pInputOutputData[i] = exp(pInputOutputData[i] - maxValue)*tempfloat;*/

	float offset = maxValue + log(tempfloat);

	for (uint32_t i = 0; i < numElements; i++)
		pInputOutputData[i] = exp(pInputOutputData[i] - offset);
}

inline void Normalize(float* pOutputData, const float* pInputData, uint32_t numElements)
{
	float tempfloat = 0.0f;

	for (uint32_t i = 0; i < numElements; i++)
		tempfloat += pInputData[i] * pInputData[i];

	if (tempfloat == 0.0f)
		return;

	tempfloat = sqrtf(tempfloat);
	tempfloat = 1.0f / tempfloat;

	for (uint32_t i = 0; i < numElements; i++)
		pOutputData[i] = tempfloat * pInputData[i];
}

inline void Normalize(float* pInputOutputData, uint32_t numElements)
{
	float tempfloat = 0.0f;

	for (uint32_t i = 0; i < numElements; i++)
		tempfloat += pInputOutputData[i] * pInputOutputData[i];

	if (tempfloat == 0.0f)
		return;

	tempfloat = sqrtf(tempfloat);
	tempfloat = 1.0f / tempfloat;

	for (uint32_t i = 0; i < numElements; i++)
		pInputOutputData[i] = tempfloat * pInputOutputData[i];
}


class CRandomNumbersNN
{
	/* Klassenelemente, die �ffentlich nicht
	einsehbar sind: */
private:

	/* Deklaration der ben�tigten Membervariablen und
	Konstanten. Ein �ffentlicher Zugriff ist im
	vorliegenden Fall nicht m�glich (weil nicht
	erforderlich): */

	uint64_t newValue = 1;

	static constexpr uint64_t constParkMillerModulus =
		2147483647;
	static constexpr uint64_t constParkMillerMultiplier =
		48271;
	static constexpr double fconstParkMillerModulus =
		2147483647.0;

	// �ffentlich einsehbare Klassenelemente:
public:

	// Konstruktor (Deklaration):
	CRandomNumbersNN();

	// Destruktor (Deklaration):
	~CRandomNumbersNN();

	/* Deklaration der �ffentlich aufrufbaren
	Memberfunktionen (Klassenmethoden): */

	/* Neuen Startwert f�r die Berechnung der
	Zufallszahlen festlegen: */
	void Change_Seed(uint64_t newSeed);

	/* Hinweis: Memberfunktionen lassen sich auch innerhalb
	einer Klassendeklarationen implementieren: */
	/*void Change_Seed( uint64_t newSeed)
	{
	newValue = newSeed;
	}*/

	/* Startwert f�r die Berechnung der Zufallszahlen
	auf 1 zur�cksetzen */
	void Reset_Seed(void);

	// zuf�llige 32-Bit-Flie�kommazahlen:
	float Get_FloatNumber(float low, float high);
	float Get_FloatNumber_IncludingZero(float low, float high);

	// zuf�llige 64-Bit-Flie�kommazahlen:
	double Get_DoubleNumber(double low, double high);
	double Get_DoubleNumber_IncludingZero(double low, double high);

	// zuf�llige 32-Bit-Ganzzahlen:
	int32_t Get_IntegerNumber(int32_t low,
		int32_t high_excluded);

	// zuf�llige positive 32-Bit-Ganzzahlen:
	uint32_t Get_UnsignedIntegerNumber(uint32_t low,
		uint32_t high_excluded);

}; // end of class CRandomNumbersNN








class CGeometricNeuron
{
public:

	int32_t NeuronID = -1;

	CGeometricNeuron *pUsedNeuronArray = nullptr;
	
	float Activity = 0.0f;
	float PosX = 0.0f;
	float PosY = 0.0f;
	float PosZ = 0.0f;

	int32_t NumConnections = 0;

	float *pSynapsePlasticityArray = nullptr;

	// Hinweis: pConnectionWeightArray[i] == 0.0f => related path is impassable
	float *pConnectionWeightArray = nullptr; 

	float *pDistanceArray = nullptr;
	int32_t *pReceiverNeuronIDArray = nullptr;

	int32_t ReceiverSynapseID = -1;
	int32_t ReceiverNeuronID = -1;

	CGeometricNeuron();
	~CGeometricNeuron();

	// Kopierkonstruktor l�schen: 
	CGeometricNeuron(const CGeometricNeuron &originalObject) = delete;

	// �berladenen Zuweisungsoperator l�schen: 
	CGeometricNeuron operator=(const CGeometricNeuron &originalObject) = delete;

	void Init_FullyConnectedNeuron(int32_t neuronID, int32_t numNeurons);
	void Init_Neuron(int32_t neuronID, int32_t numConnections);

	void Connect_With_ReceiverNeuron(int32_t neuronID, int32_t synapseID);
	void Connect_With_ReceiverNeurons(int32_t *pNeuronIDArray);

	void Set_ConnectionWeight(float weight, int32_t synapseID);

	void Connect_With_Brain(CGeometricNeuron* pNeuronArray);

	void Set_Position(float x, float y, float z);

	void Calculate_ConnectionDistances(void);
	void Calculate_ConnectionSquareDistances(void);

	void Reset_Activity(void);
	void Set_Activity(float value);

	void Propagate_Signal(int32_t receiverNeuronID);
	int32_t Propagate_Signal_To_NonActivatedNeuron(CRandomNumbersNN *pRandomNumbers);
	int32_t Propagate_Signal(CRandomNumbersNN *pRandomNumbers);
	int32_t Propagate_Signal_Randomly(CRandomNumbersNN *pRandomNumbers);
	int32_t Select_Connected_Neuron_Randomly(CRandomNumbersNN *pRandomNumbers);

	void Reset_PlasticityValues(void);
	void Update_PlasticityValues(float finalActivity, float learningRate);
	void Reduce_PlasticityValues(float decreaseValue, float minPlasticityValue = 0.0f);

	int32_t Get_ID_Of_Strongest_ConnectedNeuron(void);
};



class CGeometricNeuralNet
{
public:

	int32_t NumNeurons = 0;

	CGeometricNeuron *pNeuronArray = nullptr;

	CRandomNumbersNN RandomNumbers;

	float MinNonZeroPlasticityValue = 0.0f;
	float MaxPlasticityValue = 0.0f;

	CGeometricNeuralNet();
	~CGeometricNeuralNet();

	// Kopierkonstruktor l�schen: 
	CGeometricNeuralNet(const CGeometricNeuralNet &originalObject) = delete;

	// �berladenen Zuweisungsoperator l�schen: 
	CGeometricNeuralNet operator=(const CGeometricNeuralNet &originalObject) = delete;

	void Initialize_FullyConnected_NeuralNet(int32_t numNeurons);

	// Es werden noch keine neuronalen Verbindungen gekn�pft:
	void Initialize_NeuralNet(int32_t numNeurons);
	void Init_Neuron(int32_t neuronID, int32_t numConnections);

	void Connect_With_ReceiverNeuron(int32_t neuronID, int32_t receiverNeuronID, int32_t synapseID);

	// Hinweis: ConnectionWeight == 0.0f => related path is impassable
	void Set_ConnectionWeight(int32_t neuronID, float weight, int32_t synapseID);

	// Hinweis: ConnectionWeight == 0.0f => related path is impassable
	void Set_ConnectionWeight(int32_t neuronID, int32_t receiverNeuronID, float weight);

	float Find_MinNonZeroPlasticityValue(void);
	float Find_MaxPlasticityValue(void);

	void Set_Position(int32_t neuronID, float x, float y, float z);

	void Start_Training(void);

	// TSP: Travelling Salesman Problem
	void Train_NeuralNet_TSP(int32_t IDofFirstAndLastNeuron, float initialActivity, float learningRate);
	
	void Train_NeuralNet_PathFinding(int32_t IDofFirstNeuron, int32_t IDofLastNeuron, float initialActivity, float learningRate);

	void Random_PathFinding(int32_t IDofFirstNeuron, int32_t IDofLastNeuron, float initialActivity, float learningRate);
	
	void Reduce_PlasticityValues(float decreaseValue, float minPlasticityValue = 0.0f);

	// Ausgabe des neuronalen Pfades mit den st�rksten synaptischen Plastizit�ten (step by step):
	int32_t Get_ID_Of_Strongest_ConnectedNeuron(int32_t lastNeuronID);

	void Calculate_ConnectionDistances(void);
	void Calculate_ConnectionSquareDistances(void);
};





class CNeuron
{
public:

	CNeuron *pUsedNeuronArray = nullptr;

	bool UsedAsInputNeuron = true;
	bool UsedAsHiddenNeuron = false;
	bool UsedAsOutputNeuron = false;
	bool UsedAsBiasNeuron = false;
	bool UsedAsMemoryNeuron = false;

	float NeuronInput = 0.0f;
	float NeuronOutput = 0.0f;
	float NeuronOutput_LastCalculationStep = 0.0f;

	float ErrorValue = 0.0f;
	float ErrorFactor1 = 1.0f;
	float ErrorFactor2 = 1.0f;
	// Hinweis: Bei linearen Aktivierungsfunktionen sollte ErrorFactor2 kleiner als 1.0f sein (z. B. 0.5f oder 0.25f) 

	float LearningRate = 0.2f;

	pActivationFunc pActivationFunction = nullptr;
	pErrorFunc pUserDefErrorFunction = nullptr;

	uint32_t NumOfOutputSynapses = 0;
	uint32_t *pReceiverNeuronIDArray = nullptr;

	// auch bekannt als OutputWeightArray: 
	float *pOutputSynapsePlasticityArray = nullptr;

	// f�r bin�ren Output:
	float *pOutputSynapseMinBlockingValueArray = nullptr;
	float *pOutputSynapseMaxBlockingValueArray = nullptr;
	
	bool Dropout = false;

	CNeuron();
	~CNeuron();

	// Kopierkonstruktor l�schen: 
	CNeuron(const CNeuron &originalObject) = delete;

	// �berladenen Zuweisungsoperator l�schen: 
	CNeuron operator=(const CNeuron &originalObject) = delete;

	void Set_DropoutState(bool state);

	void Round_OutputWeights(float precision, float invPrecision);
	void Remove_Unused_Connections(void);

	void Clone(const CNeuron &originalObject);
	void Clone_Data(const CNeuron &originalObject);

	void Init_OutputSynapses(uint32_t numOfOutputSynapses);

	void Randomize_OutputSynapsePlasticities(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue);
	void Randomize_OutputSynapsePlasticities(CRandomNumbersNN *pRandomNumbers, float *pRandomValueArray, uint32_t numArrayElements);

	void Add_Randomized_OutputSynapsePlasticities(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float weight1, float weight2);
	void Add_Randomized_OutputSynapsePlasticities(CRandomNumbersNN *pRandomNumbers, float *pRandomValueArray, uint32_t numArrayElements, float weight1, float weight2);
	
	void Clone_OutputSynapsePlasticities(const CNeuron &originalObject);
	void Clone_OutputSynapsePlasticities(const CNeuron &originalObject, CRandomNumbersNN *pRandomNumbers, float variance);
	void Clone_OutputSynapsePlasticities(const CNeuron &originalObject, CRandomNumbersNN *pRandomNumbers, float minVariance, float maxVariance);
	void Combine_OutputSynapsePlasticities(CNeuron *pParentNeuron1, CNeuron *pParentNeuron2, CRandomNumbersNN *pRandomNumbers, float minWeight1);
	

	void Modify_OutputSynapsePlasticities(float multiplier);

	void Connect_With_Brain(CNeuron *pNeuronArray);
	void Connect_With_ReceiverNeuron(uint32_t neuronID, uint32_t synapseID);
	void Connect_With_ReceiverNeurons(uint32_t *pNeuronIDArray);

	void Use_As_InputNeuron(void);
	void Use_As_HiddenNeuron(void);
	void Use_As_OutputNeuron(void);
	void Use_As_BiasNeuron(void);
	void Use_As_MemoryNeuron(void);

	void Set_OutputSynapsePlasticity(float value, uint32_t synapseID);
	void Set_OutputSynapseBlockingValue(float minValue, float maxValue, uint32_t synapseID);
	void Set_LearningRate(float learningRate);
	void Set_ActivationFunction(pActivationFunc pFunc);
	void Set_UserDefErrorFunction(pErrorFunc pFunc);

	// Hinweis: Bei linearen Aktivierungsfunktionen sollte ErrorFactor2 kleiner als 1.0f sein (z. B. 0.5f, 0.25f, 0.01f) 
	void Set_ErrorFactors(float factor1, float factor2);
	
	// Funktioniert nur bei Input-Neuronen (Inputwert wird in der Variable NeuronOutput gespeichert): 
	void Set_Input(float value);
	void Add_Input(float value);

	void Reset_NeuronInput(void);
	float Get_NeuronInput(void);
	void Set_NeuronInput(float value);

	void Calculate_NeuronOutput(void);
	void Calculate_NeuronOutput_And_Retain_Input(void);
	void Calculate_NeuronOutput(float inputDecrease, float minInputValue);

	/* if (NeuronOutput < minOutputValue) => NeuronInput wird nicht ge�ndert */
	void Accumulate_NeuronInput_And_Calculate_NeuronOutput(float minOutputValue);

	/* if (NeuronOutput < minOutputValue) oder if (NeuronOutput > maxOutputValue) => NeuronInput wird nicht ge�ndert */
	void Accumulate_NeuronInput_And_Calculate_NeuronOutput(float minOutputValue, float maxOutputValue);

	/* if (NeuronOutput < minOutputValue) => NeuronInput wird nicht ge�ndert */
	void Accumulate_NeuronInput_And_Calculate_NeuronOutput(float minOutputValue, float inputDecrease, float minInputValue);

	/* if (NeuronOutput < minOutputValue) oder if (NeuronOutput > maxOutputValue) => NeuronInput wird nicht ge�ndert */
	void Accumulate_NeuronInput_And_Calculate_NeuronOutput(float minOutputValue, float maxOutputValue, float inputDecrease, float minInputValue);

	void Reset_NeuronOutput(void);

	// Weiterleitung des Signals an s�mtliche Receiver-Neuronen (nachgeschaltete Neuronen):
	void Propagate_SynapticOutput(void);
	void Propagate_MaximumSynapticOutput(void);
	void Propagate_MinimumSynapticOutput(void);
	void Propagate_MaximumAbsolutSynapticOutput(void);
	void Propagate_BinaryValue(void);

	void Propagate_SynapticOutput(uint32_t synapseID);
	void Propagate_MaximumSynapticOutput(uint32_t synapseID);
	void Propagate_MinimumSynapticOutput(uint32_t synapseID);
	void Propagate_MaximumAbsolutSynapticOutput(uint32_t synapseID);
	void Propagate_BinaryValue(uint32_t synapseID);

	float Get_NeuronOutput(void);
	void Set_NeuronOutput(float value);
	void Set_BiasNeuronOutput(float value);

	void Set_Error(float value);
	float Calculate_Error(float desiredNeuronOutput);
	float Calculate_Error_WithUserDefFunction(float desiredNeuronOutput);

	// Fehlerberechnung unter Ber�cksichtigung der bereits berechneten Fehler von s�mtlichen Receiver-Neuronen (nachgeschalteten Neuronen):
	void Calculate_Error(void);
	void Calculate_Error_WithUserDefFunction(void);

	// Anpassung der Synapsen-Pastizit�t unter Ber�cksichtigung der zuvor berechneten Fehlerwerte:
	void Adjust_OutputSynapses_AfterErrorCalculations(void);
	void Adjust_OutputSynapses_AfterErrorCalculationsExt(void);

	void Adjust_OutputSynapse_AfterErrorCalculations(uint32_t synapseID);
	void Adjust_OutputSynapse_AfterErrorCalculationsExt(uint32_t synapseID);

	void Adjust_OutputSynapse_AfterErrorCalculations2(uint32_t receiverNeuronID);
	void Adjust_OutputSynapse_AfterErrorCalculationsExt2(uint32_t synapseID);

	bool Save_OutputSynapsePlasticities(const char* pFilename);
	bool Load_OutputSynapsePlasticities(const char* pFilename);

};

class CLongTermMemoryNeuron
{
public:

	CNeuron *pUsedNeuronArray = nullptr;

	uint32_t NumOfMemorySynapses = 0;
	uint32_t NumOfMemorySynapsesPlus1 = 0;

	float *pSynapsePlasticityArray = nullptr;
	

	float Activity = 0.0f;

	float Counter = 0.0f;
	float InvCounter = 1.0f;

	CLongTermMemoryNeuron();
	~CLongTermMemoryNeuron();
	
	// Kopierkonstruktor l�schen: 
	CLongTermMemoryNeuron(const CLongTermMemoryNeuron &originalObject) = delete;

	// �berladenen Zuweisungsoperator l�schen: 
	CLongTermMemoryNeuron operator=(const CLongTermMemoryNeuron &originalObject) = delete;

	void Init_Neuron(uint32_t numOfMemorySynapses);

	void Connect_With_Brain(CNeuron* pNeuronArray);

	void Reset_Memory(void);

	void Add_MemoryValue(int32_t synapseID, float value);
	void Set_MemoryValue(int32_t synapseID, float value);
	float Get_MemoryValue(int32_t synapseID);

	void Update_Memory(int32_t synapseID, int32_t inputNeuronID, float learningRate = 1.0f);

	void Propagate_Memory(int32_t synapseID, int32_t receiverNeuronID);
	                                   
	void Transfer_Plasticity_To_DestinationNeuron(int32_t synapseID, int32_t destinationNeuronID, int32_t destinationNeuronSynapseID, float plasticityMultiplier);
	void Transfer_Plasticity_To_DestinationNeuron(int32_t synapseID, int32_t destinationNeuronID, int32_t destinationNeuronSynapseID);


	void Reset_Activity(void);
	void Set_Activity(float value);

	void Reduce_PlasticityValues(float decreaseValue, float minPlasticityValue);

};





class C2State2DCellularAutomatonRules
{
public:

	int32_t NumBirthRules = 0;
	int32_t BirthRuleArray[8];

	int32_t NumSurvivingRules = 0;
	int32_t SurvivingRuleArray[8];

	C2State2DCellularAutomatonRules();
	void Reset(void);
};


class C2DCellularAutomata
{
public:

	int32_t NumCellsXDir;
	int32_t NumCellsYDir;

	int32_t NumCellsXDirMinus1;
	int32_t NumCellsYDirMinus1;

	int32_t NumCells;

	int32_t *pCellMap1 = nullptr;
	int32_t *pCellMap2 = nullptr;

	int32_t *PtrToLastUpdatedCellMap = nullptr;

	static constexpr int32_t Value_BlockingCell = -1;
	static constexpr int32_t Value_DeadCell = 0;
	static constexpr int32_t Value_LivingCell = 1;

	C2DCellularAutomata();
	~C2DCellularAutomata();

	
	// Kopierkonstruktor l�schen:
	C2DCellularAutomata(const C2DCellularAutomata &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	C2DCellularAutomata& operator=(const C2DCellularAutomata &originalObject) = delete;

	void Set_CellValue(int32_t cellIID, int32_t value);
	void Set_CellValue(int32_t cellPosX, int32_t cellPosY, int32_t value);

	int32_t Get_CellValue(int32_t cellIID);
	int32_t Get_CellValue(int32_t cellPosX, int32_t cellPosY);

	int32_t Get_PrevCellValue(int32_t cellIID);
	int32_t Get_PrevCellValue(int32_t cellPosX, int32_t cellPosY);

	void Get_PtrToLastUpdatedCellMap(int32_t **ppOut);

	void Init_CellularAutomata(int32_t numCellsXDir, int32_t numCellsYDir);

	void Reset_CellMap(int32_t cellValue);
	void Kill_All_Cells(void);

	void Init_CellMap(CRandomNumbersNN *pRandomNumbers, int32_t densityValue, int32_t invDensity);
	void Init_CellMap(CRandomNumbersNN *pRandomNumbers, int32_t minXPos, int32_t maxXPos, int32_t minYPos, int32_t maxYPos, int32_t densityValue, int32_t invDensity);


	void Output_CellMap(void);

	bool Save_CellMap(const char* pFilename);
	bool Save_CellMap(const char* pFilename, int32_t valueLivingCell, int32_t valueDeadCell);
	bool Save_CellMapPattern(const char* pFilename, int32_t value);

	void Smooth_CellMap(int32_t smoothingValue);
	void Smooth_BorderlessCellMap(int32_t smoothingValue);

	void Detect_Edges(int32_t valueEdgeCell);
	void Detect_Edges2(int32_t valueNonEdgeCell);

	void Update_CellMap(C2State2DCellularAutomatonRules *pRules);
	void Update_BorderlessCellMap(C2State2DCellularAutomatonRules *pRules);

	void Set_CellMapBoarderValue(int32_t value);

	void Exchange_LivingAndDeadCells(void);
	void Exchange_CellsValue(int32_t oldValue, int32_t newValue);
};


class C2DCellularAutomataF
{
public:

	int32_t NumCellsXDir;
	int32_t NumCellsYDir;

	int32_t NumCellsXDirMinus1;
	int32_t NumCellsYDirMinus1;

	int32_t NumCells;

	float *pCellMap1 = nullptr;
	float *pCellMap2 = nullptr;

	float *PtrToLastUpdatedCellMap = nullptr;

	static constexpr float Value_BlockingCell = -1.0f;
	static constexpr float Value_DeadCell = 0.0f;
	static constexpr float Value_LivingCell = 1.0f;

	C2DCellularAutomataF();
	~C2DCellularAutomataF();


	// Kopierkonstruktor l�schen:
	C2DCellularAutomataF(const C2DCellularAutomataF &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	C2DCellularAutomataF& operator=(const C2DCellularAutomataF &originalObject) = delete;

	void Set_CellValue(int32_t cellIID, float value);
	void Set_CellValue(int32_t cellPosX, int32_t cellPosY, float value);

	float Get_CellValue(int32_t cellIID);
	float Get_CellValue(int32_t cellPosX, int32_t cellPosY);

	float Get_PrevCellValue(int32_t cellIID);
	float Get_PrevCellValue(int32_t cellPosX, int32_t cellPosY);

	void Get_PtrToLastUpdatedCellMap(float **ppOut);

	void Init_CellularAutomata(int32_t numCellsXDir, int32_t numCellsYDir);

	void Reset_CellMap(float cellValue);
	void Kill_All_Cells(void);

	void Init_CellMap(CRandomNumbersNN *pRandomNumbers, int32_t densityValue, int32_t invDensity);
	void Init_CellMap(CRandomNumbersNN *pRandomNumbers, int32_t minXPos, int32_t maxXPos, int32_t minYPos, int32_t maxYPos, int32_t densityValue, int32_t invDensity);

	void Output_CellMap(void);

	bool Save_CellMap(const char* pFilename);
	bool Save_CellMap(const char* pFilename, float valueLivingCell, float valueDeadCell);
	bool Save_CellMapPattern(const char* pFilename, float value);

	void Smooth_CellMap(int32_t smoothingValue);
	void Smooth_BorderlessCellMap(int32_t smoothingValue);

	void Detect_Edges(float valueEdgeCell);
	void Detect_Edges2(float valueNonEdgeCell);

	void Update_CellMap(C2State2DCellularAutomatonRules *pRules);
	void Update_BorderlessCellMap(C2State2DCellularAutomatonRules *pRules);

	void Set_CellMapBoarderValue(float value);

	void Exchange_LivingAndDeadCells(void);
	void Exchange_CellsValue(float oldValue, float newValue);
};



class CNeuralNetHiddenLayer
{
public:

	uint32_t NumOfNeurons = 0;
	uint32_t *pNeuronIDArray = nullptr;

	bool AdditionalBiasNeuron = false;
	uint32_t BiasNeuronID = 0;


	CNeuralNetHiddenLayer()
	{}

	~CNeuralNetHiddenLayer()
	{
		delete[] pNeuronIDArray;
		pNeuronIDArray = nullptr;
	}

	// Kopierkonstruktor l�schen:
	CNeuralNetHiddenLayer(const CNeuralNetHiddenLayer &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CNeuralNetHiddenLayer& operator=(const CNeuralNetHiddenLayer &originalObject) = delete;

	void Init_Layer(uint32_t idOfFirstNeuron, uint32_t numOfNeurons, bool additionalBiasNeuron)
	{
		delete[] pNeuronIDArray;
		pNeuronIDArray = nullptr;

		AdditionalBiasNeuron = additionalBiasNeuron;

		NumOfNeurons = numOfNeurons;

		pNeuronIDArray = new (std::nothrow) uint32_t[numOfNeurons];

		for (uint32_t i = 0; i < numOfNeurons; i++)
			pNeuronIDArray[i] = i + idOfFirstNeuron;

		if (additionalBiasNeuron == true)
			BiasNeuronID = idOfFirstNeuron + numOfNeurons;
	}

};


class CNeuralNet
{
public:

	uint32_t NumOfNeurons = 0;
	uint32_t NumOfUsedNeurons = 0;

	bool HiddenLayer1Used = false;
	bool HiddenLayer2Used = false;
	bool HiddenLayer3Used = false;
	bool ReservorComputing = false;

	CNeuralNetHiddenLayer HiddenLayer1;
	CNeuralNetHiddenLayer HiddenLayer2;
	CNeuralNetHiddenLayer HiddenLayer3;
	

	uint32_t NumInputNeurons = 0;
	uint32_t NumOutputNeurons = 0;
	uint32_t FirstOutputNeuronID = 0;

	uint32_t NumReservoirNeurons = 0;
	uint32_t FirstReservoirNeuronID = 0;
	uint32_t NumReservoirConnectionsPerInputNeuron = 0;
	uint32_t NumReservoirConnectionsPerOutputNeuron = 0;
	uint32_t *pNumInternalReservoirConnectionsArray = nullptr;

	bool AdditionalInputBiasNeuron = false;
	uint32_t InputBiasNeuronID = 0;

	CNeuron *pNeuronArray = nullptr;

	uint32_t NumOfActivationSequenceArrayEntries = 0;
	uint32_t *pActivationSequenceArray = nullptr;

	CRandomNumbersNN RandomNumbers;

	CNeuralNet()
	{}
	~CNeuralNet()
	{
		delete[] pNeuronArray;
		pNeuronArray = nullptr;

		delete[] pNumInternalReservoirConnectionsArray;
		pNumInternalReservoirConnectionsArray = nullptr;

		delete[] pActivationSequenceArray;
		pActivationSequenceArray = nullptr;
	}

	void Init_ActivationSequenceArray(uint32_t numOfActivationSequenceArrayEntries)
	{
		delete[] pActivationSequenceArray;
		pActivationSequenceArray = nullptr;

		NumOfActivationSequenceArrayEntries = numOfActivationSequenceArrayEntries;

		pActivationSequenceArray = new (std::nothrow) uint32_t[numOfActivationSequenceArrayEntries];

		for (uint32_t i = 0; i < numOfActivationSequenceArrayEntries; i++)
			pActivationSequenceArray[i] = 0;
	}

	void Init_ActivationSequenceArray(uint32_t numOfActivationSequenceArrayEntries, uint32_t *pSequenceArray)
	{
		delete[] pActivationSequenceArray;
		pActivationSequenceArray = nullptr;

		NumOfActivationSequenceArrayEntries = numOfActivationSequenceArrayEntries;

		pActivationSequenceArray = new (std::nothrow) uint32_t[numOfActivationSequenceArrayEntries];

		for (uint32_t i = 0; i < numOfActivationSequenceArrayEntries; i++)
			pActivationSequenceArray[i] = pSequenceArray[i];
	}

	void Update_ActivationSequenceArray(uint32_t neuronID, uint32_t entryID)
	{
		pActivationSequenceArray[entryID] = neuronID;
	}

	void Init_NeuralNet(uint32_t numOfNeurons)
	{
		delete[] pNeuronArray;
		pNeuronArray = nullptr;

		delete[] pNumInternalReservoirConnectionsArray;
		pNumInternalReservoirConnectionsArray = nullptr;

		NumOfUsedNeurons = 0;
		NumOfNeurons = numOfNeurons;

		ReservorComputing = false;

		pNeuronArray = new (std::nothrow) CNeuron[numOfNeurons];

		for (uint32_t i = 0; i < numOfNeurons; i++)
			pNeuronArray[i].Connect_With_Brain(pNeuronArray);
	}

	// Kopierkonstruktor l�schen:
	CNeuralNet(const CNeuralNet &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CNeuralNet& operator=(const CNeuralNet &originalObject) = delete;

	void Round_OutputWeights(float precision)
	{
		float invPrecision = 1.0f / precision;

		for (uint32_t i = 0; i < NumOfNeurons; i++)
			pNeuronArray[i].Round_OutputWeights(precision, invPrecision);
	}

	void Remove_Unused_Connections(void)
	{
		for (uint32_t i = 0; i < NumOfNeurons; i++)
			pNeuronArray[i].Remove_Unused_Connections();
	}

	void Deactivate_Unused_Neurons(void)
	{
		if (ReservorComputing == true)
			return;

		for (uint32_t i = NumInputNeurons; i < NumOfNeurons; i++)
			pNeuronArray[i].Dropout = true;

		if (AdditionalInputBiasNeuron == true)
			pNeuronArray[InputBiasNeuronID].Dropout = false;

		if (HiddenLayer1Used == true)
		{
			if (HiddenLayer1.AdditionalBiasNeuron == true)
				pNeuronArray[HiddenLayer1.BiasNeuronID].Dropout = false;	
		}

		if (HiddenLayer2Used == true)
		{
			if (HiddenLayer2.AdditionalBiasNeuron == true)
				pNeuronArray[HiddenLayer2.BiasNeuronID].Dropout = false;
		}

		if (HiddenLayer3Used == true)
		{
			if (HiddenLayer3.AdditionalBiasNeuron == true)
				pNeuronArray[HiddenLayer3.BiasNeuronID].Dropout = false;
		}

		for (uint32_t i = 0; i < NumOfNeurons; i++)
		{
			uint32_t numConnections = pNeuronArray[i].NumOfOutputSynapses;

			for (uint32_t j = 0; j < numConnections; j++)
			{
				pNeuronArray[pNeuronArray[i].pReceiverNeuronIDArray[j]].Dropout = false;
			}
		}	
	}


	

	void Set_Activationfunction_OutputLayerNeuron(pActivationFunc pFunc, uint32_t id_InsideLayer)
	{
		uint32_t id = id_InsideLayer + FirstOutputNeuronID;
		pNeuronArray[id].Set_ActivationFunction(pFunc);
	}

	void Set_Activationfunction_HiddenLayer1Neuron(pActivationFunc pFunc, uint32_t id_InsideLayer)
	{
		uint32_t id = HiddenLayer1.pNeuronIDArray[id_InsideLayer];
		pNeuronArray[id].Set_ActivationFunction(pFunc);
	}

	void Set_Activationfunction_HiddenLayer2Neuron(pActivationFunc pFunc, uint32_t id_InsideLayer)
	{
		uint32_t id = HiddenLayer2.pNeuronIDArray[id_InsideLayer];
		pNeuronArray[id].Set_ActivationFunction(pFunc);
	}

	void Set_Activationfunction_HiddenLayer3Neuron(pActivationFunc pFunc, uint32_t id_InsideLayer)
	{
		uint32_t id = HiddenLayer3.pNeuronIDArray[id_InsideLayer];
		pNeuronArray[id].Set_ActivationFunction(pFunc);
	}

	void Set_Activationfunction_ReservorNeuron(pActivationFunc pFunc, uint32_t id_InsideReservoir)
	{
		uint32_t id = FirstReservoirNeuronID + id_InsideReservoir;
		pNeuronArray[id].Set_ActivationFunction(pFunc);
	}

	void Set_DropoutState_HiddenLayer1Neuron(bool state, uint32_t id_InsideLayer)
	{
		uint32_t id = HiddenLayer1.pNeuronIDArray[id_InsideLayer];
		pNeuronArray[id].Set_DropoutState(state);
	}

	void Set_DropoutState_HiddenLayer2Neuron(bool state, uint32_t id_InsideLayer)
	{
		uint32_t id = HiddenLayer2.pNeuronIDArray[id_InsideLayer];
		pNeuronArray[id].Set_DropoutState(state);
	}

	void Set_DropoutState_HiddenLayer3Neuron(bool state, uint32_t id_InsideLayer)
	{
		uint32_t id = HiddenLayer3.pNeuronIDArray[id_InsideLayer];
		pNeuronArray[id].Set_DropoutState(state);
	}

	void Set_DropoutState_ReservorNeuron(bool state, uint32_t id_InsideReservoir)
	{
		uint32_t id = FirstReservoirNeuronID + id_InsideReservoir;
		pNeuronArray[id].Set_DropoutState(state);
	}

	void Init_TwoLayerNetwork(uint32_t numInputNeurons, float minPlasticityValue_InputLayer, float maxPlasticityValue_InputLayer, float inputNeuronLearningRate, bool additionalInputBiasNeuron, uint32_t numOutputNeurons, pActivationFunc pOutputNeuronActivationFunc, float outputNeuronErrorFactor1 = 1.0f, float outputNeuronErrorFactor2 = 1.0f)
	{
		ReservorComputing = false;

		AdditionalInputBiasNeuron = additionalInputBiasNeuron;

		NumInputNeurons = numInputNeurons;
		NumOutputNeurons = numOutputNeurons;

		if (additionalInputBiasNeuron == false)
			FirstOutputNeuronID = NumInputNeurons;
		else
		{
			InputBiasNeuronID = NumInputNeurons;
			FirstOutputNeuronID = NumInputNeurons + 1;

			pNeuronArray[InputBiasNeuronID].Use_As_BiasNeuron();
			pNeuronArray[InputBiasNeuronID].Set_BiasNeuronOutput(-1.0f);
			pNeuronArray[InputBiasNeuronID].Set_LearningRate(inputNeuronLearningRate);
		}

		uint32_t i, j, id;

		for (i = 0; i < NumInputNeurons; i++)
		{
			pNeuronArray[i].Use_As_InputNeuron();
			pNeuronArray[i].Set_LearningRate(inputNeuronLearningRate);
		}

		for (i = 0; i < NumOutputNeurons; i++)
		{
			id = i + FirstOutputNeuronID;

			pNeuronArray[id].Use_As_OutputNeuron();
			pNeuronArray[id].Set_ActivationFunction(pOutputNeuronActivationFunc);
			pNeuronArray[id].Set_ErrorFactors(outputNeuronErrorFactor1, outputNeuronErrorFactor2);
		}

		if (additionalInputBiasNeuron == false)
			NumOfUsedNeurons = NumInputNeurons + NumOutputNeurons;
		else
			NumOfUsedNeurons = NumInputNeurons + NumOutputNeurons + 1;

		
		for (i = 0; i < NumInputNeurons; i++)
		{
			pNeuronArray[i].Init_OutputSynapses(NumOutputNeurons);
			pNeuronArray[i].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticityValue_InputLayer, maxPlasticityValue_InputLayer);

			for (j = 0; j < NumOutputNeurons; j++)
				pNeuronArray[i].Connect_With_ReceiverNeuron(j + FirstOutputNeuronID, /*synapseID:*/ j);
		}

		if (additionalInputBiasNeuron == true)
		{
			pNeuronArray[InputBiasNeuronID].Init_OutputSynapses(NumOutputNeurons);
			pNeuronArray[InputBiasNeuronID].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticityValue_InputLayer, maxPlasticityValue_InputLayer);

			for (j = 0; j < NumOutputNeurons; j++)
				pNeuronArray[InputBiasNeuronID].Connect_With_ReceiverNeuron(j + FirstOutputNeuronID, /*synapseID:*/ j);
		}
	}

	void Calculate_Output_TwoLayerNetwork(float *pOutputValueArray, const float *pInputValueArray)
	{
		uint32_t i, id;

		for (i = 0; i < NumInputNeurons; i++)
		{
			pNeuronArray[i].Set_Input(pInputValueArray[i]);
			pNeuronArray[i].Propagate_SynapticOutput();
		}

		if (AdditionalInputBiasNeuron == true)
			pNeuronArray[InputBiasNeuronID].Propagate_SynapticOutput();

		for (i = 0; i < NumOutputNeurons; i++)
		{
			id = i + FirstOutputNeuronID;

			pNeuronArray[id].Calculate_NeuronOutput();

			pOutputValueArray[i] = pNeuronArray[id].Get_NeuronOutput();
			//pOutputValueArray[i] = pNeuronArray[id].NeuronOutput;
		}
	}

	float Learning_TwoLayerNetwork(const float *pDesiredOutputValueArray)
	{
		uint32_t i;
		uint32_t id;

		float error = 0.0f;

		for (i = 0; i < NumOutputNeurons; i++)
		{
			id = FirstOutputNeuronID + i;

			error += pNeuronArray[id].Calculate_Error(pDesiredOutputValueArray[i]);
		}

		if (AdditionalInputBiasNeuron == true)
			pNeuronArray[InputBiasNeuronID].Adjust_OutputSynapses_AfterErrorCalculations();

		for (uint32_t i = 0; i < NumInputNeurons; i++)
			pNeuronArray[i].Adjust_OutputSynapses_AfterErrorCalculations();


		return error;
	}


	void Init_Input_And_OutputNeurons(uint32_t numInputNeurons, float inputNeuronLearningRate, bool additionalInputBiasNeuron, uint32_t numOutputNeurons, pActivationFunc pOutputNeuronActivationFunc, float outputNeuronErrorFactor1 = 1.0f, float outputNeuronErrorFactor2 = 1.0f)
	{
		ReservorComputing = false;

		AdditionalInputBiasNeuron = additionalInputBiasNeuron;

		NumInputNeurons = numInputNeurons;
		NumOutputNeurons = numOutputNeurons;

		if(additionalInputBiasNeuron == false)
			FirstOutputNeuronID = NumInputNeurons;
		else
		{
			InputBiasNeuronID = NumInputNeurons;
			FirstOutputNeuronID = NumInputNeurons + 1; 

			pNeuronArray[InputBiasNeuronID].Use_As_BiasNeuron();
			pNeuronArray[InputBiasNeuronID].Set_BiasNeuronOutput(-1.0f);
			pNeuronArray[InputBiasNeuronID].Set_LearningRate(inputNeuronLearningRate);
		}

		uint32_t i, id;

		for (i = 0; i < NumInputNeurons; i++)
		{
			pNeuronArray[i].Use_As_InputNeuron();
			pNeuronArray[i].Set_LearningRate(inputNeuronLearningRate);
		}
		
		for (i = 0; i < NumOutputNeurons; i++)
		{
			id = i + FirstOutputNeuronID;

			pNeuronArray[id].Use_As_OutputNeuron();
			pNeuronArray[id].Set_ActivationFunction(pOutputNeuronActivationFunc);
			pNeuronArray[id].Set_ErrorFactors(outputNeuronErrorFactor1, outputNeuronErrorFactor2);
		}

		if (additionalInputBiasNeuron == false)
			NumOfUsedNeurons = NumInputNeurons + NumOutputNeurons;
		else
			NumOfUsedNeurons = NumInputNeurons + NumOutputNeurons + 1;
	}

	

	void Init_ReservoirComputing_FullyConnectedReservoir(uint32_t numInputNeurons, uint32_t numReservoirConnectionsPerInputNeuron, uint32_t *pReservoirNeuronsWithInputConnection_IDArray, float inputNeuronLearningRate, bool additionalInputBiasNeuron, uint32_t numReservoirNeurons, pActivationFunc pReservoirNeuronActivationFunc, float reservoirNeuronLearningRate, float minPlasticityValue_ReservoirNeurons, float maxPlasticityValue_ReservoirNeurons, uint32_t numOutputNeurons, uint32_t numReservoirConnectionsPerOutputNeuron, uint32_t *pReservoirNeuronsWithOutputConnection_IDArray, pActivationFunc pOutputNeuronActivationFunc, float outputNeuronErrorFactor1 = 1.0f, float outputNeuronErrorFactor2 = 1.0f)
	{
		uint32_t i, j, id;

		ReservorComputing = true;

		NumInputNeurons = numInputNeurons;
		NumOutputNeurons = numOutputNeurons;
		NumReservoirNeurons = numReservoirNeurons;

		delete[] pNumInternalReservoirConnectionsArray;
		pNumInternalReservoirConnectionsArray = nullptr;

		pNumInternalReservoirConnectionsArray = new (std::nothrow) uint32_t[numReservoirNeurons];

		for(i = 0; i < numReservoirNeurons; i++)
			pNumInternalReservoirConnectionsArray[i] = NumReservoirNeurons - 1;

		AdditionalInputBiasNeuron = additionalInputBiasNeuron;

		NumReservoirConnectionsPerInputNeuron = numReservoirConnectionsPerInputNeuron;
		NumReservoirConnectionsPerOutputNeuron = numReservoirConnectionsPerOutputNeuron;

		if (additionalInputBiasNeuron == false)
		{
			FirstReservoirNeuronID = NumInputNeurons;
			FirstOutputNeuronID = FirstReservoirNeuronID + NumReservoirNeurons;
			NumOfUsedNeurons = NumInputNeurons + NumReservoirNeurons + NumOutputNeurons;
		}
		else
		{
			InputBiasNeuronID = NumInputNeurons;
			FirstReservoirNeuronID = NumInputNeurons + 1;
			FirstOutputNeuronID = FirstReservoirNeuronID + NumReservoirNeurons;
			NumOfUsedNeurons = NumInputNeurons + NumReservoirNeurons + NumOutputNeurons + 1;
		}

		

		for (i = 0; i < NumInputNeurons; i++)
		{
			pNeuronArray[i].Use_As_InputNeuron();
			pNeuronArray[i].Set_LearningRate(inputNeuronLearningRate);
			pNeuronArray[i].Init_OutputSynapses(NumReservoirConnectionsPerInputNeuron);

			for (j = 0; j < NumReservoirConnectionsPerInputNeuron; j++)
			{
				pNeuronArray[i].Set_OutputSynapsePlasticity(1.0f, /*SynapseID:*/ j);
				pNeuronArray[i].Connect_With_ReceiverNeuron(pReservoirNeuronsWithInputConnection_IDArray[j], /*SynapseID:*/ j);
			}

		}

		if (additionalInputBiasNeuron == true)
		{
			pNeuronArray[InputBiasNeuronID].Use_As_BiasNeuron();
			pNeuronArray[InputBiasNeuronID].Set_BiasNeuronOutput(-1.0f);
			pNeuronArray[InputBiasNeuronID].Set_LearningRate(inputNeuronLearningRate);
			pNeuronArray[InputBiasNeuronID].Init_OutputSynapses(NumReservoirConnectionsPerInputNeuron);

			for (j = 0; j < NumReservoirConnectionsPerInputNeuron; j++)
			{
				pNeuronArray[InputBiasNeuronID].Set_OutputSynapsePlasticity(1.0f, /*SynapseID:*/  j);
				pNeuronArray[InputBiasNeuronID].Connect_With_ReceiverNeuron(pReservoirNeuronsWithInputConnection_IDArray[j], /*SynapseID:*/ j);
			}
		}

		for (i = 0; i < NumOutputNeurons; i++)
		{
			id = i + FirstOutputNeuronID;

			pNeuronArray[id].Use_As_OutputNeuron();
			pNeuronArray[id].Set_ActivationFunction(pOutputNeuronActivationFunc);
			pNeuronArray[id].Set_ErrorFactors(outputNeuronErrorFactor1, outputNeuronErrorFactor2);
		}


		bool additionalOutputConnection;
		uint32_t synapseIDCounter;

		for (i = 0; i < NumReservoirNeurons; i++)
		{
			id = FirstReservoirNeuronID + i;

			pNeuronArray[id].Use_As_MemoryNeuron();

			additionalOutputConnection = false;

			for (j = 0; j < NumReservoirConnectionsPerOutputNeuron; j++)
			{
				if (pReservoirNeuronsWithOutputConnection_IDArray[j] == id)
				{
					additionalOutputConnection = true;
					break;
				}
			}

			if (additionalOutputConnection == true)
				pNeuronArray[id].Init_OutputSynapses(pNumInternalReservoirConnectionsArray[i] + NumOutputNeurons);
			else
				pNeuronArray[id].Init_OutputSynapses(pNumInternalReservoirConnectionsArray[i]);


			pNeuronArray[id].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticityValue_ReservoirNeurons, maxPlasticityValue_ReservoirNeurons);
			pNeuronArray[id].Set_LearningRate(reservoirNeuronLearningRate);
			pNeuronArray[id].Set_ActivationFunction(pReservoirNeuronActivationFunc);


			synapseIDCounter = 0;

			for (j = 0; j < NumReservoirNeurons; j++)
			{
				if (i == j)
					continue;

				pNeuronArray[id].Connect_With_ReceiverNeuron(FirstReservoirNeuronID + j, synapseIDCounter);
				synapseIDCounter++;
			}

			if (additionalOutputConnection == true)
			{
				for (j = 0; j < NumOutputNeurons; j++)
				{
					pNeuronArray[id].Connect_With_ReceiverNeuron(FirstOutputNeuronID + j, synapseIDCounter);
					synapseIDCounter++;
				}
			}
		}


	}

	

	void Init_ReservoirComputing(uint32_t numInputNeurons, uint32_t numReservoirConnectionsPerInputNeuron, uint32_t *pReservoirNeuronsWithInputConnection_IDArray, float inputNeuronLearningRate, bool additionalInputBiasNeuron, uint32_t numReservoirNeurons, uint32_t minNumOfReservoirConnections, uint32_t maxNumOfReservoirConnections, pActivationFunc pReservoirNeuronActivationFunc, float reservoirNeuronLearningRate, float minPlasticityValue_ReservoirNeurons, float maxPlasticityValue_ReservoirNeurons, uint32_t numOutputNeurons, uint32_t numReservoirConnectionsPerOutputNeuron, uint32_t *pReservoirNeuronsWithOutputConnection_IDArray, pActivationFunc pOutputNeuronActivationFunc, float outputNeuronErrorFactor1 = 1.0f, float outputNeuronErrorFactor2 = 1.0f)
	{
		uint32_t i, j, k, id;

		ReservorComputing = true;

		NumInputNeurons = numInputNeurons;
		NumOutputNeurons = numOutputNeurons;
		NumReservoirNeurons = numReservoirNeurons;

		delete[] pNumInternalReservoirConnectionsArray;
		pNumInternalReservoirConnectionsArray = nullptr;

		pNumInternalReservoirConnectionsArray = new (std::nothrow) uint32_t[numReservoirNeurons];

		for (i = 0; i < numReservoirNeurons; i++)
			pNumInternalReservoirConnectionsArray[i] = NumReservoirNeurons - 1;

		AdditionalInputBiasNeuron = additionalInputBiasNeuron;

		NumReservoirConnectionsPerInputNeuron = numReservoirConnectionsPerInputNeuron;
		NumReservoirConnectionsPerOutputNeuron = numReservoirConnectionsPerOutputNeuron;

		if (additionalInputBiasNeuron == false)
		{
			FirstReservoirNeuronID = NumInputNeurons;
			FirstOutputNeuronID = FirstReservoirNeuronID + NumReservoirNeurons;
			NumOfUsedNeurons = NumInputNeurons + NumReservoirNeurons + NumOutputNeurons;
		}
		else
		{
			InputBiasNeuronID = NumInputNeurons;
			FirstReservoirNeuronID = NumInputNeurons + 1;
			FirstOutputNeuronID = FirstReservoirNeuronID + NumReservoirNeurons;
			NumOfUsedNeurons = NumInputNeurons + NumReservoirNeurons + NumOutputNeurons + 1;
		}

		

		for (i = 0; i < NumInputNeurons; i++)
		{
			pNeuronArray[i].Use_As_InputNeuron();
			pNeuronArray[i].Set_LearningRate(inputNeuronLearningRate);
			pNeuronArray[i].Init_OutputSynapses(NumReservoirConnectionsPerInputNeuron);

			for (j = 0; j < NumReservoirConnectionsPerInputNeuron; j++)
			{
				pNeuronArray[i].Set_OutputSynapsePlasticity(1.0f, /*SynapseID:*/ j);
				pNeuronArray[i].Connect_With_ReceiverNeuron(pReservoirNeuronsWithInputConnection_IDArray[j], /*SynapseID:*/ j);
			}

		}

		if (additionalInputBiasNeuron == true)
		{
			pNeuronArray[InputBiasNeuronID].Use_As_BiasNeuron();
			pNeuronArray[InputBiasNeuronID].Set_BiasNeuronOutput(-1.0f);
			pNeuronArray[InputBiasNeuronID].Set_LearningRate(inputNeuronLearningRate);
			pNeuronArray[InputBiasNeuronID].Init_OutputSynapses(NumReservoirConnectionsPerInputNeuron);

			for (j = 0; j < NumReservoirConnectionsPerInputNeuron; j++)
			{
				pNeuronArray[InputBiasNeuronID].Set_OutputSynapsePlasticity(1.0f, /*SynapseID:*/  j);
				pNeuronArray[InputBiasNeuronID].Connect_With_ReceiverNeuron(pReservoirNeuronsWithInputConnection_IDArray[j], /*SynapseID:*/ j);
			}
		}

		for (i = 0; i < NumOutputNeurons; i++)
		{
			id = i + FirstOutputNeuronID;

			pNeuronArray[id].Use_As_OutputNeuron();
			pNeuronArray[id].Set_ActivationFunction(pOutputNeuronActivationFunc);
			pNeuronArray[id].Set_ErrorFactors(outputNeuronErrorFactor1, outputNeuronErrorFactor2);
		}

		maxNumOfReservoirConnections++;

		bool alreadyExistingConnection;
		bool additionalOutputConnection;
		uint32_t synapseIDCounter;
		uint32_t randomID;

		for (i = 0; i < NumReservoirNeurons; i++)
		{
			id = FirstReservoirNeuronID + i;

			pNeuronArray[id].Use_As_MemoryNeuron();

			additionalOutputConnection = false;

			for (j = 0; j < NumReservoirConnectionsPerOutputNeuron; j++)
			{
				if (pReservoirNeuronsWithOutputConnection_IDArray[j] == id)
				{
					additionalOutputConnection = true;
					break;
				}
			}

			pNumInternalReservoirConnectionsArray[i] = RandomNumbers.Get_UnsignedIntegerNumber(minNumOfReservoirConnections, maxNumOfReservoirConnections);

			if (additionalOutputConnection == true)
				pNeuronArray[id].Init_OutputSynapses(pNumInternalReservoirConnectionsArray[i] + NumOutputNeurons);
			else
				pNeuronArray[id].Init_OutputSynapses(pNumInternalReservoirConnectionsArray[i]);


			//pNeuronArray[id].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticityValue_ReservoirNeurons, maxPlasticityValue_ReservoirNeurons);
			pNeuronArray[id].Set_LearningRate(reservoirNeuronLearningRate);
			pNeuronArray[id].Set_ActivationFunction(pReservoirNeuronActivationFunc);

			synapseIDCounter = 0;

			for (j = 0; j < NumReservoirNeurons; j++)
			{
				do
				{
					randomID = RandomNumbers.Get_UnsignedIntegerNumber(0, NumReservoirNeurons);
				}
				while (randomID == i);

				alreadyExistingConnection = false;

				for(k = 0; k < synapseIDCounter; k++)
				{
					if (pNeuronArray[id].pReceiverNeuronIDArray[k] == randomID)
					{
						alreadyExistingConnection = true;
						//std::cout << "alreadyExistingConnection" << std::endl;
						break;
					}
				}

				if (alreadyExistingConnection == false)
				{
					pNeuronArray[id].Connect_With_ReceiverNeuron(FirstReservoirNeuronID + randomID, synapseIDCounter);

					pNeuronArray[id].Set_OutputSynapsePlasticity(RandomNumbers.Get_FloatNumber(minPlasticityValue_ReservoirNeurons, maxPlasticityValue_ReservoirNeurons), synapseIDCounter);

					synapseIDCounter++;

					if (synapseIDCounter >= pNumInternalReservoirConnectionsArray[i])
						break;
				}
			}

			pNumInternalReservoirConnectionsArray[i] = synapseIDCounter;

			if (additionalOutputConnection == true)
			{
				for (j = 0; j < NumOutputNeurons; j++)
				{
					pNeuronArray[id].Connect_With_ReceiverNeuron(FirstOutputNeuronID + j, synapseIDCounter);

					pNeuronArray[id].Set_OutputSynapsePlasticity(RandomNumbers.Get_FloatNumber(minPlasticityValue_ReservoirNeurons, maxPlasticityValue_ReservoirNeurons), synapseIDCounter);

					synapseIDCounter++;
				}
			}

			//pNeuronArray[id].NumOfOutputSynapses = synapseIDCounter;
			pNeuronArray[id].Remove_Unused_Connections();
			

		}


	}

	void Init_HiddenLayer1(uint32_t numOfNeurons, bool additionalBiasNeuron, bool connectWithOutputLayer, pActivationFunc pFunc, float minPlasticityValue_HiddenLayer1, float maxPlasticityValue_HiddenLayer1, float minPlasticityValue_InputLayer, float maxPlasticityValue_InputLayer, float learningRate, float errorFactor1 = 1.0f, float errorFactor2 = 1.0f)
	{
		HiddenLayer1Used = true;

		HiddenLayer1.Init_Layer(NumOfUsedNeurons, numOfNeurons, additionalBiasNeuron);

		if (HiddenLayer1.AdditionalBiasNeuron == false)
			NumOfUsedNeurons += HiddenLayer1.NumOfNeurons;
		else
			NumOfUsedNeurons += (HiddenLayer1.NumOfNeurons + 1);

		uint32_t numOfNeuronsHL1 = HiddenLayer1.NumOfNeurons;

		uint32_t i, j, id;

		for (i = 0; i < numOfNeuronsHL1; i++)
		{
			id = HiddenLayer1.pNeuronIDArray[i];

			pNeuronArray[id].Use_As_HiddenNeuron();
			pNeuronArray[id].Set_ActivationFunction(pFunc);
			pNeuronArray[id].Set_LearningRate(learningRate);
			pNeuronArray[id].Set_ErrorFactors(errorFactor1, errorFactor2);
		}

		if (HiddenLayer1.AdditionalBiasNeuron == true)
		{
			id = HiddenLayer1.BiasNeuronID;

			pNeuronArray[id].Use_As_BiasNeuron();
			pNeuronArray[id].Set_BiasNeuronOutput(-1.0f);
			pNeuronArray[id].Set_LearningRate(learningRate);
		}

		RandomNumbers.Change_Seed(1);

		if (connectWithOutputLayer == true)
		{
			for (i = 0; i < numOfNeuronsHL1; i++)
			{ 
				id = HiddenLayer1.pNeuronIDArray[i];

				pNeuronArray[id].Init_OutputSynapses(NumOutputNeurons);
				pNeuronArray[id].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticityValue_HiddenLayer1, maxPlasticityValue_HiddenLayer1);
				
				for (j = 0; j < NumOutputNeurons; j++)
					pNeuronArray[id].Connect_With_ReceiverNeuron(j + FirstOutputNeuronID, /*synapseID:*/ j);
			}

			if (HiddenLayer1.AdditionalBiasNeuron == true)
			{
				id = HiddenLayer1.BiasNeuronID;

				pNeuronArray[id].Init_OutputSynapses(NumOutputNeurons);
				pNeuronArray[id].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticityValue_HiddenLayer1, maxPlasticityValue_HiddenLayer1);

				for (j = 0; j < NumOutputNeurons; j++)
					pNeuronArray[id].Connect_With_ReceiverNeuron(j + FirstOutputNeuronID, /*synapseID:*/ j);
			}
		}

		// Inputneuronen mit Layer 1 verkn�pfen:

	
		RandomNumbers.Change_Seed(1);

		for (i = 0; i < NumInputNeurons; i++)
		{
			pNeuronArray[i].Init_OutputSynapses(numOfNeuronsHL1);
			pNeuronArray[i].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticityValue_InputLayer, maxPlasticityValue_InputLayer);

			for (j = 0; j < numOfNeuronsHL1; j++)
			{
				pNeuronArray[i].Connect_With_ReceiverNeuron(HiddenLayer1.pNeuronIDArray[j], /*synapseID:*/ j);
			}
		}

		if (AdditionalInputBiasNeuron == true)
		{
			pNeuronArray[InputBiasNeuronID].Init_OutputSynapses(numOfNeuronsHL1);
			pNeuronArray[InputBiasNeuronID].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticityValue_InputLayer, maxPlasticityValue_InputLayer);

			for (j = 0; j < numOfNeuronsHL1; j++)
				pNeuronArray[InputBiasNeuronID].Connect_With_ReceiverNeuron(HiddenLayer1.pNeuronIDArray[j], /*synapseID:*/ j);
		}
	}
	
	void Init_HiddenLayer2(uint32_t numOfNeurons, bool additionalBiasNeuron, bool connectWithOutputLayer, pActivationFunc pFunc, float minPlasticityValue_HiddenLayer2, float maxPlasticityValue_HiddenLayer2, float minPlasticityValue_HiddenLayer1, float maxPlasticityValue_HiddenLayer1, float learningRate, float errorFactor1 = 1.0f, float errorFactor2 = 1.0f)
	{
		HiddenLayer2Used = true;

		HiddenLayer2.Init_Layer(NumOfUsedNeurons, numOfNeurons, additionalBiasNeuron);

		if (HiddenLayer2.AdditionalBiasNeuron == false)
			NumOfUsedNeurons += HiddenLayer2.NumOfNeurons;
		else
			NumOfUsedNeurons += (HiddenLayer2.NumOfNeurons + 1);

		uint32_t numOfNeuronsHL2 = HiddenLayer2.NumOfNeurons;

		uint32_t i, j, id;

		for (i = 0; i < numOfNeuronsHL2; i++)
		{
			id = HiddenLayer2.pNeuronIDArray[i];

			pNeuronArray[id].Use_As_HiddenNeuron();
			pNeuronArray[id].Set_ActivationFunction(pFunc);
			pNeuronArray[id].Set_LearningRate(learningRate);
			pNeuronArray[id].Set_ErrorFactors(errorFactor1, errorFactor2);
		}

		if (HiddenLayer2.AdditionalBiasNeuron == true)
		{
			id = HiddenLayer2.BiasNeuronID;

			pNeuronArray[id].Use_As_BiasNeuron();
			pNeuronArray[id].Set_BiasNeuronOutput(-1.0f);
			pNeuronArray[id].Set_LearningRate(learningRate);
		}

		
		if (connectWithOutputLayer == true)
		{
			for (i = 0; i < numOfNeuronsHL2; i++)
			{
				id = HiddenLayer2.pNeuronIDArray[i];

				pNeuronArray[id].Init_OutputSynapses(NumOutputNeurons);
				pNeuronArray[id].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticityValue_HiddenLayer2, maxPlasticityValue_HiddenLayer2);

				for (j = 0; j < NumOutputNeurons; j++)
					pNeuronArray[id].Connect_With_ReceiverNeuron(j + FirstOutputNeuronID, /*synapseID:*/ j);
			}

			if (HiddenLayer2.AdditionalBiasNeuron == true)
			{
				id = HiddenLayer2.BiasNeuronID;

				pNeuronArray[id].Init_OutputSynapses(NumOutputNeurons);
				pNeuronArray[id].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticityValue_HiddenLayer2, maxPlasticityValue_HiddenLayer2);

				for (j = 0; j < NumOutputNeurons; j++)
					pNeuronArray[id].Connect_With_ReceiverNeuron(j + FirstOutputNeuronID, /*synapseID:*/ j);
			}
		}

		// Hiddenlayer1 mit Hiddenlayer2 verkn�pfen:
		
		uint32_t numOfNeuronsHL1 = HiddenLayer1.NumOfNeurons;

		for (i = 0; i < numOfNeuronsHL1; i++)
		{
			id = HiddenLayer1.pNeuronIDArray[i];

			pNeuronArray[id].Init_OutputSynapses(numOfNeuronsHL2);
			pNeuronArray[id].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticityValue_HiddenLayer1, maxPlasticityValue_HiddenLayer1);

			for (j = 0; j < numOfNeuronsHL2; j++)
				pNeuronArray[id].Connect_With_ReceiverNeuron(HiddenLayer2.pNeuronIDArray[j], /*synapseID:*/ j);
		}

		if (HiddenLayer1.AdditionalBiasNeuron == true)
		{
			id = HiddenLayer1.BiasNeuronID;

			pNeuronArray[id].Init_OutputSynapses(numOfNeuronsHL2);
			pNeuronArray[id].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticityValue_HiddenLayer1, maxPlasticityValue_HiddenLayer1);

			for (j = 0; j < numOfNeuronsHL2; j++)
				pNeuronArray[id].Connect_With_ReceiverNeuron(HiddenLayer2.pNeuronIDArray[j], /*synapseID:*/ j);
		}
	
	}

	void Init_HiddenLayer3(uint32_t numOfNeurons, bool additionalBiasNeuron, pActivationFunc pFunc, float minPlasticityValue_HiddenLayer3, float maxPlasticityValue_HiddenLayer3, float minPlasticityValue_HiddenLayer2, float maxPlasticityValue_HiddenLayer2, float learningRate, float errorFactor1 = 1.0f, float errorFactor2 = 1.0f)
	{
		HiddenLayer3Used = true;

		HiddenLayer3.Init_Layer(NumOfUsedNeurons, numOfNeurons, additionalBiasNeuron);

		if (HiddenLayer3.AdditionalBiasNeuron == false)
			NumOfUsedNeurons += HiddenLayer3.NumOfNeurons;
		else
			NumOfUsedNeurons += (HiddenLayer3.NumOfNeurons + 1);

		uint32_t numOfNeuronsHL3 = HiddenLayer3.NumOfNeurons;

		uint32_t i, j, id;

		for (i = 0; i < numOfNeuronsHL3; i++)
		{
			id = HiddenLayer3.pNeuronIDArray[i];

			pNeuronArray[id].Use_As_HiddenNeuron();
			pNeuronArray[id].Set_ActivationFunction(pFunc);
			pNeuronArray[id].Set_LearningRate(learningRate);
			pNeuronArray[id].Set_ErrorFactors(errorFactor1, errorFactor2);
		}

		if (HiddenLayer3.AdditionalBiasNeuron == true)
		{
			id = HiddenLayer3.BiasNeuronID;

			pNeuronArray[id].Use_As_BiasNeuron();
			pNeuronArray[id].Set_BiasNeuronOutput(-1.0f);
			pNeuronArray[id].Set_LearningRate(learningRate);
		}

		for (i = 0; i < numOfNeuronsHL3; i++)
		{
			id = HiddenLayer3.pNeuronIDArray[i];

			pNeuronArray[id].Init_OutputSynapses(NumOutputNeurons);
			pNeuronArray[id].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticityValue_HiddenLayer3, maxPlasticityValue_HiddenLayer3);

			for (j = 0; j < NumOutputNeurons; j++)
				pNeuronArray[id].Connect_With_ReceiverNeuron(j + FirstOutputNeuronID, /*synapseID:*/ j);
		}

		if (HiddenLayer3.AdditionalBiasNeuron == true)
		{
			id = HiddenLayer3.BiasNeuronID;

			pNeuronArray[id].Init_OutputSynapses(NumOutputNeurons);
			pNeuronArray[id].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticityValue_HiddenLayer3, maxPlasticityValue_HiddenLayer3);

			for (j = 0; j < NumOutputNeurons; j++)
				pNeuronArray[id].Connect_With_ReceiverNeuron(j + FirstOutputNeuronID, /*synapseID:*/ j);
		}
		

		// Hiddenlayer2 mit Hiddenlayer3 verkn�pfen:

		uint32_t numOfNeuronsHL2 = HiddenLayer2.NumOfNeurons;

		for (i = 0; i < numOfNeuronsHL2; i++)
		{
			id = HiddenLayer2.pNeuronIDArray[i];

			pNeuronArray[id].Init_OutputSynapses(numOfNeuronsHL3);
			pNeuronArray[id].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticityValue_HiddenLayer2, maxPlasticityValue_HiddenLayer2);

			for (j = 0; j < numOfNeuronsHL3; j++)
				pNeuronArray[id].Connect_With_ReceiverNeuron(HiddenLayer3.pNeuronIDArray[j], /*synapseID:*/ j);
		}

		if (HiddenLayer2.AdditionalBiasNeuron == true)
		{
			id = HiddenLayer2.BiasNeuronID;

			pNeuronArray[id].Init_OutputSynapses(numOfNeuronsHL3);
			pNeuronArray[id].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticityValue_HiddenLayer2, maxPlasticityValue_HiddenLayer2);

			for (j = 0; j < numOfNeuronsHL3; j++)
				pNeuronArray[id].Connect_With_ReceiverNeuron(HiddenLayer3.pNeuronIDArray[j], /*synapseID:*/ j);
		}

	}
	
	

	void RandomChange_OutputSynapsePlasticities(uint64_t newSeed, float minPlasticity, float maxPlasticity)
	{
		RandomNumbers.Change_Seed(newSeed);

		for (uint32_t i = 0; i < NumOfUsedNeurons; i++)
			pNeuronArray[i].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticity, maxPlasticity);
	}

	void RandomChange_OutputSynapsePlasticities(uint64_t newSeed, float minPlasticity, float maxPlasticity, float mutationRate)
	{
		RandomNumbers.Change_Seed(newSeed);

		uint32_t j, numOfOutputSynapses;

		for (uint32_t i = 0; i < NumOfUsedNeurons; i++)
		{
			numOfOutputSynapses = pNeuronArray[i].NumOfOutputSynapses;

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
					continue;

				pNeuronArray[i].pOutputSynapsePlasticityArray[j] = RandomNumbers.Get_FloatNumber(minPlasticity, maxPlasticity);
			}
		}
	}

	void RandomChange_OutputSynapsePlasticities2(uint64_t newSeed, float minPlasticityVariance, float maxPlasticityVariance, float mutationRate)
	{
		RandomNumbers.Change_Seed(newSeed);

		uint32_t j, numOfOutputSynapses;

		for (uint32_t i = 0; i < NumOfUsedNeurons; i++)
		{
			numOfOutputSynapses = pNeuronArray[i].NumOfOutputSynapses;

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
					continue;

				pNeuronArray[i].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber_IncludingZero(minPlasticityVariance, maxPlasticityVariance);
			}
		}
	}

	void RandomChange_OutputSynapsePlasticities_InputLayer(uint64_t newSeed, float minPlasticity, float maxPlasticity)
	{
		RandomNumbers.Change_Seed(newSeed);

		for (uint32_t i = 0; i < NumInputNeurons; i++)
			pNeuronArray[i].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticity, maxPlasticity);

		if (AdditionalInputBiasNeuron == true)
			pNeuronArray[InputBiasNeuronID].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticity, maxPlasticity);
	}

	void RandomChange_OutputSynapsePlasticities_InputLayer(uint64_t newSeed, float minPlasticity, float maxPlasticity, float mutationRate)
	{
		RandomNumbers.Change_Seed(newSeed);

		uint32_t j, numOfOutputSynapses;

		for (uint32_t i = 0; i < NumInputNeurons; i++)
		{
			numOfOutputSynapses = pNeuronArray[i].NumOfOutputSynapses;

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
					continue;

				pNeuronArray[i].pOutputSynapsePlasticityArray[j] = RandomNumbers.Get_FloatNumber(minPlasticity, maxPlasticity);
			}
		}

		

		if (AdditionalInputBiasNeuron == true)
		{
			numOfOutputSynapses = pNeuronArray[InputBiasNeuronID].NumOfOutputSynapses;

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
					continue;

				pNeuronArray[InputBiasNeuronID].pOutputSynapsePlasticityArray[j] = RandomNumbers.Get_FloatNumber(minPlasticity, maxPlasticity);
			}
		}
	}

	void RandomChange_OutputSynapsePlasticities2_InputLayer(uint64_t newSeed, float minPlasticityVariance, float maxPlasticityVariance, float mutationRate)
	{
		RandomNumbers.Change_Seed(newSeed);

		uint32_t j, numOfOutputSynapses;

		for (uint32_t i = 0; i < NumInputNeurons; i++)
		{
			numOfOutputSynapses = pNeuronArray[i].NumOfOutputSynapses;

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
					continue;

				pNeuronArray[i].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber_IncludingZero(minPlasticityVariance, maxPlasticityVariance);
			}
		}



		if (AdditionalInputBiasNeuron == true)
		{
			numOfOutputSynapses = pNeuronArray[InputBiasNeuronID].NumOfOutputSynapses;

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
					continue;

				pNeuronArray[InputBiasNeuronID].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber_IncludingZero(minPlasticityVariance, maxPlasticityVariance);
			}
		}
	}

	void RandomChange_OutputSynapsePlasticities_HiddenLayer1(uint64_t newSeed, float minPlasticity, float maxPlasticity)
	{
		if (HiddenLayer1Used == false)
			return;

		RandomNumbers.Change_Seed(newSeed);

		uint32_t numOfNeurons = HiddenLayer1.NumOfNeurons;

		uint32_t id;

		for (uint32_t i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer1.pNeuronIDArray[i];

			pNeuronArray[id].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticity, maxPlasticity);
		}

		if (HiddenLayer1.AdditionalBiasNeuron == true)
			pNeuronArray[HiddenLayer1.BiasNeuronID].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticity, maxPlasticity);
	}

	void RandomChange_OutputSynapsePlasticities_HiddenLayer1(uint64_t newSeed, float minPlasticity, float maxPlasticity, float mutationRate)
	{
		if (HiddenLayer1Used == false)
			return;

		RandomNumbers.Change_Seed(newSeed);

		uint32_t numOfNeurons = HiddenLayer1.NumOfNeurons;

		uint32_t j, numOfOutputSynapses;

		uint32_t id;

		for (uint32_t i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer1.pNeuronIDArray[i];

			numOfOutputSynapses = pNeuronArray[id].NumOfOutputSynapses;

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
					continue;

				pNeuronArray[id].pOutputSynapsePlasticityArray[j] = RandomNumbers.Get_FloatNumber(minPlasticity, maxPlasticity);
			}
		}

		if (HiddenLayer1.AdditionalBiasNeuron == true)
		{
			numOfOutputSynapses = pNeuronArray[HiddenLayer1.BiasNeuronID].NumOfOutputSynapses;

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
					continue;

				pNeuronArray[HiddenLayer1.BiasNeuronID].pOutputSynapsePlasticityArray[j] = RandomNumbers.Get_FloatNumber(minPlasticity, maxPlasticity);
			}
		}
	}

	void RandomChange_OutputSynapsePlasticities2_HiddenLayer1(uint64_t newSeed, float minPlasticityVariance, float maxPlasticityVariance, float mutationRate)
	{
		if (HiddenLayer1Used == false)
			return;

		RandomNumbers.Change_Seed(newSeed);

		uint32_t numOfNeurons = HiddenLayer1.NumOfNeurons;

		uint32_t j, numOfOutputSynapses;

		uint32_t id;

		for (uint32_t i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer1.pNeuronIDArray[i];

			numOfOutputSynapses = pNeuronArray[id].NumOfOutputSynapses;

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
					continue;

				pNeuronArray[id].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber_IncludingZero(minPlasticityVariance, maxPlasticityVariance);
			}
		}

		if (HiddenLayer1.AdditionalBiasNeuron == true)
		{
			numOfOutputSynapses = pNeuronArray[HiddenLayer1.BiasNeuronID].NumOfOutputSynapses;

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
					continue;

				pNeuronArray[HiddenLayer1.BiasNeuronID].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber_IncludingZero(minPlasticityVariance, maxPlasticityVariance);
			}
		}
	}

	void RandomChange_OutputSynapsePlasticities_HiddenLayer2(uint64_t newSeed, float minPlasticity, float maxPlasticity)
	{
		if (HiddenLayer2Used == false)
			return;

		RandomNumbers.Change_Seed(newSeed);

		
		uint32_t numOfNeurons = HiddenLayer2.NumOfNeurons;

		uint32_t id;

		for (uint32_t i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer2.pNeuronIDArray[i];

			pNeuronArray[id].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticity, maxPlasticity);
		}

		if (HiddenLayer2.AdditionalBiasNeuron == true)
			pNeuronArray[HiddenLayer2.BiasNeuronID].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticity, maxPlasticity);
	}

	void RandomChange_OutputSynapsePlasticities_HiddenLayer2(uint64_t newSeed, float minPlasticity, float maxPlasticity, float mutationRate)
	{
		if (HiddenLayer2Used == false)
			return;

		RandomNumbers.Change_Seed(newSeed);


		uint32_t numOfNeurons = HiddenLayer2.NumOfNeurons;

		uint32_t j, numOfOutputSynapses;

		uint32_t id;

		for (uint32_t i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer2.pNeuronIDArray[i];

			numOfOutputSynapses = pNeuronArray[id].NumOfOutputSynapses;

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
					continue;

				pNeuronArray[id].pOutputSynapsePlasticityArray[j] = RandomNumbers.Get_FloatNumber(minPlasticity, maxPlasticity);
			}
		}

		if (HiddenLayer2.AdditionalBiasNeuron == true)
		{
			numOfOutputSynapses = pNeuronArray[HiddenLayer2.BiasNeuronID].NumOfOutputSynapses;

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
					continue;

				pNeuronArray[HiddenLayer2.BiasNeuronID].pOutputSynapsePlasticityArray[j] = RandomNumbers.Get_FloatNumber(minPlasticity, maxPlasticity);
			}
		}
	}

	void RandomChange_OutputSynapsePlasticities2_HiddenLayer2(uint64_t newSeed, float minPlasticityVariance, float maxPlasticityVariance, float mutationRate)
	{
		if (HiddenLayer2Used == false)
			return;

		RandomNumbers.Change_Seed(newSeed);


		uint32_t numOfNeurons = HiddenLayer2.NumOfNeurons;

		uint32_t j, numOfOutputSynapses;

		uint32_t id;

		for (uint32_t i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer2.pNeuronIDArray[i];

			numOfOutputSynapses = pNeuronArray[id].NumOfOutputSynapses;

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
					continue;

				pNeuronArray[id].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber_IncludingZero(minPlasticityVariance, maxPlasticityVariance);
			}
		}

		if (HiddenLayer2.AdditionalBiasNeuron == true)
		{
			numOfOutputSynapses = pNeuronArray[HiddenLayer2.BiasNeuronID].NumOfOutputSynapses;

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
					continue;

				pNeuronArray[HiddenLayer2.BiasNeuronID].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber_IncludingZero(minPlasticityVariance, maxPlasticityVariance);
			}
		}
	}

	void RandomChange_OutputSynapsePlasticities_HiddenLayer3(uint64_t newSeed, float minPlasticity, float maxPlasticity)
	{
		if (HiddenLayer3Used == false)
			return;

		RandomNumbers.Change_Seed(newSeed);

		uint32_t numOfNeurons = HiddenLayer3.NumOfNeurons;

		uint32_t id;

		for (uint32_t i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer3.pNeuronIDArray[i];

			pNeuronArray[id].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticity, maxPlasticity);
		}

		if (HiddenLayer3.AdditionalBiasNeuron == true)
			pNeuronArray[HiddenLayer3.BiasNeuronID].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticity, maxPlasticity);
	}

	void RandomChange_OutputSynapsePlasticities_HiddenLayer3(uint64_t newSeed, float minPlasticity, float maxPlasticity, float mutationRate)
	{
		if (HiddenLayer3Used == false)
			return;

		RandomNumbers.Change_Seed(newSeed);

		uint32_t numOfNeurons = HiddenLayer3.NumOfNeurons;

		uint32_t j, numOfOutputSynapses;

		uint32_t id;

		for (uint32_t i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer3.pNeuronIDArray[i];

			numOfOutputSynapses = pNeuronArray[id].NumOfOutputSynapses;

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
					continue;

				pNeuronArray[id].pOutputSynapsePlasticityArray[j] = RandomNumbers.Get_FloatNumber(minPlasticity, maxPlasticity);
			}
		}

		if (HiddenLayer3.AdditionalBiasNeuron == true)
		{
			numOfOutputSynapses = pNeuronArray[HiddenLayer3.BiasNeuronID].NumOfOutputSynapses;

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
					continue;

				pNeuronArray[HiddenLayer3.BiasNeuronID].pOutputSynapsePlasticityArray[j] = RandomNumbers.Get_FloatNumber(minPlasticity, maxPlasticity);
			}
		}
	}

	void RandomChange_OutputSynapsePlasticities2_HiddenLayer3(uint64_t newSeed, float minPlasticityVariance, float maxPlasticityVariance, float mutationRate)
	{
		if (HiddenLayer3Used == false)
			return;

		RandomNumbers.Change_Seed(newSeed);

		uint32_t numOfNeurons = HiddenLayer3.NumOfNeurons;

		uint32_t j, numOfOutputSynapses;

		uint32_t id;

		for (uint32_t i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer3.pNeuronIDArray[i];

			numOfOutputSynapses = pNeuronArray[id].NumOfOutputSynapses;

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
					continue;

				pNeuronArray[id].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber_IncludingZero(minPlasticityVariance, maxPlasticityVariance);
			}
		}

		if (HiddenLayer3.AdditionalBiasNeuron == true)
		{
			numOfOutputSynapses = pNeuronArray[HiddenLayer3.BiasNeuronID].NumOfOutputSynapses;

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
					continue;

				pNeuronArray[HiddenLayer3.BiasNeuronID].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber_IncludingZero(minPlasticityVariance, maxPlasticityVariance);
			}
		}
	}

	void RandomChange_OutputSynapsePlasticities_ReservoirNeurons(uint64_t newSeed, float minPlasticity, float maxPlasticity)
	{
		RandomNumbers.Change_Seed(newSeed);

		uint32_t id, j, numOfOutputSynapses, receiverID;

		for (uint32_t i = 0; i < NumReservoirNeurons; i++)
		{
			id = FirstReservoirNeuronID + i;

			numOfOutputSynapses = pNeuronArray[id].NumOfOutputSynapses;

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				receiverID = pNeuronArray[id].pReceiverNeuronIDArray[i];

				if (pNeuronArray[receiverID].UsedAsMemoryNeuron != true)
					continue;

				pNeuronArray[id].pOutputSynapsePlasticityArray[i] += RandomNumbers.Get_FloatNumber(minPlasticity, maxPlasticity);
			}
		}
	}

	void RandomChange_OutputSynapsePlasticities_ReservoirNeurons(uint64_t newSeed, float minPlasticity, float maxPlasticity, float mutationRate)
	{
		RandomNumbers.Change_Seed(newSeed);

		uint32_t id, j, numOfOutputSynapses, receiverID;

		for (uint32_t i = 0; i < NumReservoirNeurons; i++)
		{
			if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			id = FirstReservoirNeuronID + i;

			numOfOutputSynapses = pNeuronArray[id].NumOfOutputSynapses;

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				receiverID = pNeuronArray[id].pReceiverNeuronIDArray[i];

				if (pNeuronArray[receiverID].UsedAsMemoryNeuron != true)
					continue;

				pNeuronArray[id].pOutputSynapsePlasticityArray[i] = RandomNumbers.Get_FloatNumber(minPlasticity, maxPlasticity);
			}
		}
	}

	void RandomChange_OutputSynapsePlasticities2_ReservoirNeurons(uint64_t newSeed, float minPlasticityVariance, float maxPlasticityVariance, float mutationRate)
	{
		RandomNumbers.Change_Seed(newSeed);

		uint32_t id, j, numOfOutputSynapses, receiverID;

		for (uint32_t i = 0; i < NumReservoirNeurons; i++)
		{
			if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			id = FirstReservoirNeuronID + i;

			numOfOutputSynapses = pNeuronArray[id].NumOfOutputSynapses;

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				receiverID = pNeuronArray[id].pReceiverNeuronIDArray[i];

				if (pNeuronArray[receiverID].UsedAsMemoryNeuron != true)
					continue;

				pNeuronArray[id].pOutputSynapsePlasticityArray[i] += RandomNumbers.Get_FloatNumber_IncludingZero(minPlasticityVariance, maxPlasticityVariance);
			}
		}
	}


	void Clone_OutputSynapsePlasticities(CNeuralNet *pOriginalBrain)
	{
		uint32_t j, numOfOutputSynapses;

		for (uint32_t i = 0; i < NumOfUsedNeurons; i++)
		{
			numOfOutputSynapses = pNeuronArray[i].NumOfOutputSynapses;

			for (j = 0; j < numOfOutputSynapses; j++)
				pNeuronArray[i].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[i].pOutputSynapsePlasticityArray[j];
		}
	}

	void Clone_OutputSynapsePlasticities(CNeuralNet *pOriginalBrain, float variance, uint64_t newSeed)
	{
		RandomNumbers.Change_Seed(newSeed);

		uint32_t j, numOfOutputSynapses;

		for (uint32_t i = 0; i < NumOfUsedNeurons; i++)
		{
			numOfOutputSynapses = pNeuronArray[i].NumOfOutputSynapses;

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				pNeuronArray[i].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[i].pOutputSynapsePlasticityArray[j];
				pNeuronArray[i].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-variance, variance);
			}
		}
	}

	void Clone_OutputSynapsePlasticities(CNeuralNet *pOriginalBrain, float variance, float mutationRate, uint64_t newSeed)
	{
		RandomNumbers.Change_Seed(newSeed);

		uint32_t j, numOfOutputSynapses;

		for (uint32_t i = 0; i < NumOfUsedNeurons; i++)
		{
			numOfOutputSynapses = pNeuronArray[i].NumOfOutputSynapses;

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				pNeuronArray[i].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[i].pOutputSynapsePlasticityArray[j];

				if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
					continue;

				pNeuronArray[i].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-variance, variance);
			}
		}
	}


	void Clone_OutputSynapsePlasticities2(CNeuralNet *pOriginalBrain, float varianceMemoryNeurons, uint64_t newSeed)
	{
		RandomNumbers.Change_Seed(newSeed);

		uint32_t j, numOfOutputSynapses;

		for (uint32_t i = 0; i < NumOfUsedNeurons; i++)
		{
			numOfOutputSynapses = pNeuronArray[i].NumOfOutputSynapses;

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				pNeuronArray[i].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[i].pOutputSynapsePlasticityArray[j];

				if (pNeuronArray[i].UsedAsMemoryNeuron != true)
					continue;

				pNeuronArray[i].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-varianceMemoryNeurons, varianceMemoryNeurons);
			}
		}
	}

	void Clone_OutputSynapsePlasticities2(CNeuralNet *pOriginalBrain, float varianceMemoryNeurons, float mutationRate, uint64_t newSeed)
	{
		RandomNumbers.Change_Seed(newSeed);

		uint32_t j, numOfOutputSynapses;

		for (uint32_t i = 0; i < NumOfUsedNeurons; i++)
		{
			numOfOutputSynapses = pNeuronArray[i].NumOfOutputSynapses;

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				pNeuronArray[i].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[i].pOutputSynapsePlasticityArray[j];

				if (pNeuronArray[i].UsedAsMemoryNeuron != true)
					continue;

				if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
					continue;

				pNeuronArray[i].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-varianceMemoryNeurons, varianceMemoryNeurons);
			}
		}
	}

	void Clone_OutputSynapsePlasticities3(CNeuralNet *pOriginalBrain, float varianceNonMemoryNeurons, uint64_t newSeed)
	{
		RandomNumbers.Change_Seed(newSeed);

		uint32_t j, numOfOutputSynapses;

		for (uint32_t i = 0; i < NumOfUsedNeurons; i++)
		{
			numOfOutputSynapses = pNeuronArray[i].NumOfOutputSynapses;

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				pNeuronArray[i].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[i].pOutputSynapsePlasticityArray[j];

				if (pNeuronArray[i].UsedAsMemoryNeuron == true)
					continue;

				pNeuronArray[i].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-varianceNonMemoryNeurons, varianceNonMemoryNeurons);
			}
		}
	}

	void Clone_OutputSynapsePlasticities3(CNeuralNet *pOriginalBrain, float varianceNonMemoryNeurons, float mutationRate, uint64_t newSeed)
	{
		RandomNumbers.Change_Seed(newSeed);

		uint32_t j, numOfOutputSynapses;

		for (uint32_t i = 0; i < NumOfUsedNeurons; i++)
		{
			numOfOutputSynapses = pNeuronArray[i].NumOfOutputSynapses;

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				pNeuronArray[i].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[i].pOutputSynapsePlasticityArray[j];

				if (pNeuronArray[i].UsedAsMemoryNeuron == true)
					continue;

				if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
					continue;

				pNeuronArray[i].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-varianceNonMemoryNeurons, varianceNonMemoryNeurons);
			}
		}
	}


	

	void Clone_OutputSynapsePlasticities_InputLayer(CNeuralNet *pOriginalBrain, float variance, uint64_t newSeed)
	{
		RandomNumbers.Change_Seed(newSeed);

		uint32_t j, numOfOutputSynapses;

		//float weight1, weight2;

		//float newPlasticity;

		
		uint32_t numInputNeurons = min(NumInputNeurons, pOriginalBrain->NumInputNeurons);
		
		for (uint32_t i = 0; i < numInputNeurons; i++)
		{
			numOfOutputSynapses = min(pNeuronArray[i].NumOfOutputSynapses, pOriginalBrain->pNeuronArray[i].NumOfOutputSynapses);

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				pNeuronArray[i].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[i].pOutputSynapsePlasticityArray[j];
				pNeuronArray[i].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-variance, variance);
			}
		}

		if (AdditionalInputBiasNeuron == true)
		{
			uint32_t biasNeuronID = InputBiasNeuronID;
			uint32_t biasNeuronID1 = pOriginalBrain->InputBiasNeuronID;
			

			numOfOutputSynapses = min(pNeuronArray[biasNeuronID].NumOfOutputSynapses, pOriginalBrain->pNeuronArray[biasNeuronID1].NumOfOutputSynapses);
			
			for (j = 0; j < numOfOutputSynapses; j++)
			{
				pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[biasNeuronID1].pOutputSynapsePlasticityArray[j];
				pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-variance, variance);
			}
		}
	}

	void Clone_OutputSynapsePlasticities_InputLayer(CNeuralNet *pOriginalBrain, float variance, float mutationRate, uint64_t newSeed)
	{
		RandomNumbers.Change_Seed(newSeed);

		uint32_t j, numOfOutputSynapses;

		//float weight1, weight2;

		//float newPlasticity;


		uint32_t numInputNeurons = min(NumInputNeurons, pOriginalBrain->NumInputNeurons);

		for (uint32_t i = 0; i < numInputNeurons; i++)
		{
			numOfOutputSynapses = min(pNeuronArray[i].NumOfOutputSynapses, pOriginalBrain->pNeuronArray[i].NumOfOutputSynapses);

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				pNeuronArray[i].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[i].pOutputSynapsePlasticityArray[j];

				if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
					continue;

				pNeuronArray[i].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-variance, variance);
			}
		}

		if (AdditionalInputBiasNeuron == true)
		{
			uint32_t biasNeuronID = InputBiasNeuronID;
			uint32_t biasNeuronID1 = pOriginalBrain->InputBiasNeuronID;


			numOfOutputSynapses = min(pNeuronArray[biasNeuronID].NumOfOutputSynapses, pOriginalBrain->pNeuronArray[biasNeuronID1].NumOfOutputSynapses);

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[biasNeuronID1].pOutputSynapsePlasticityArray[j];

				if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
					continue;

				pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-variance, variance);
			}
		}
	}

	void Clone_OutputSynapsePlasticities_HiddenLayer1(CNeuralNet *pOriginalBrain, float variance, uint64_t newSeed)
	{
		if (HiddenLayer1Used == false)
			return;

		RandomNumbers.Change_Seed(newSeed);

		uint32_t j, id, id1, numOfOutputSynapses;

		uint32_t numOfNeurons = min(HiddenLayer1.NumOfNeurons, pOriginalBrain->HiddenLayer1.NumOfNeurons);

		for (uint32_t i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer1.pNeuronIDArray[i];
			id1 = pOriginalBrain->HiddenLayer1.pNeuronIDArray[i];

			numOfOutputSynapses = min(pNeuronArray[id].NumOfOutputSynapses, pOriginalBrain->pNeuronArray[id1].NumOfOutputSynapses);

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				pNeuronArray[id].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[id1].pOutputSynapsePlasticityArray[j];
				pNeuronArray[id].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-variance, variance);
			}
		}

		if (HiddenLayer1.AdditionalBiasNeuron == true)
		{
			uint32_t biasNeuronID = HiddenLayer1.BiasNeuronID;
			uint32_t biasNeuronID1 = pOriginalBrain->HiddenLayer1.BiasNeuronID;
		
			numOfOutputSynapses = min(pNeuronArray[biasNeuronID].NumOfOutputSynapses, pOriginalBrain->pNeuronArray[biasNeuronID1].NumOfOutputSynapses);
			
			for (j = 0; j < numOfOutputSynapses; j++)
			{
				pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[biasNeuronID1].pOutputSynapsePlasticityArray[j];
				pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-variance, variance);
			}
		}
	}

	void Clone_OutputSynapsePlasticities_HiddenLayer1(CNeuralNet *pOriginalBrain, float variance, float mutationRate, uint64_t newSeed)
	{
		if (HiddenLayer1Used == false)
			return;

		RandomNumbers.Change_Seed(newSeed);

		uint32_t j, id, id1, numOfOutputSynapses;

		uint32_t numOfNeurons = min(HiddenLayer1.NumOfNeurons, pOriginalBrain->HiddenLayer1.NumOfNeurons);

		for (uint32_t i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer1.pNeuronIDArray[i];
			id1 = pOriginalBrain->HiddenLayer1.pNeuronIDArray[i];

			numOfOutputSynapses = min(pNeuronArray[id].NumOfOutputSynapses, pOriginalBrain->pNeuronArray[id1].NumOfOutputSynapses);

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				pNeuronArray[id].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[id1].pOutputSynapsePlasticityArray[j];

				if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
					continue;

				pNeuronArray[id].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-variance, variance);
			}
		}

		if (HiddenLayer1.AdditionalBiasNeuron == true)
		{
			uint32_t biasNeuronID = HiddenLayer1.BiasNeuronID;
			uint32_t biasNeuronID1 = pOriginalBrain->HiddenLayer1.BiasNeuronID;

			numOfOutputSynapses = min(pNeuronArray[biasNeuronID].NumOfOutputSynapses, pOriginalBrain->pNeuronArray[biasNeuronID1].NumOfOutputSynapses);

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[biasNeuronID1].pOutputSynapsePlasticityArray[j];

				if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
					continue;

				pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-variance, variance);
			}
		}
	}

	void Clone_OutputSynapsePlasticities_HiddenLayer2(CNeuralNet *pOriginalBrain, float variance, uint64_t newSeed)
	{
		if (HiddenLayer2Used == false)
			return;

		RandomNumbers.Change_Seed(newSeed);

		uint32_t j, id, id1, numOfOutputSynapses;

		uint32_t numOfNeurons = min(HiddenLayer2.NumOfNeurons, pOriginalBrain->HiddenLayer2.NumOfNeurons);

		for (uint32_t i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer2.pNeuronIDArray[i];
			id1 = pOriginalBrain->HiddenLayer2.pNeuronIDArray[i];

			numOfOutputSynapses = min(pNeuronArray[id].NumOfOutputSynapses, pOriginalBrain->pNeuronArray[id1].NumOfOutputSynapses);

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				pNeuronArray[id].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[id1].pOutputSynapsePlasticityArray[j];
				pNeuronArray[id].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-variance, variance);
			}
		}

		if (HiddenLayer2.AdditionalBiasNeuron == true)
		{
			uint32_t biasNeuronID = HiddenLayer2.BiasNeuronID;
			uint32_t biasNeuronID1 = pOriginalBrain->HiddenLayer2.BiasNeuronID;

			numOfOutputSynapses = min(pNeuronArray[biasNeuronID].NumOfOutputSynapses, pOriginalBrain->pNeuronArray[biasNeuronID1].NumOfOutputSynapses);

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[biasNeuronID1].pOutputSynapsePlasticityArray[j];
				pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-variance, variance);
			}
		}
	}

	void Clone_OutputSynapsePlasticities_HiddenLayer2(CNeuralNet *pOriginalBrain, float variance, float mutationRate, uint64_t newSeed)
	{
		if (HiddenLayer2Used == false)
			return;

		RandomNumbers.Change_Seed(newSeed);

		uint32_t j, id, id1, numOfOutputSynapses;

		uint32_t numOfNeurons = min(HiddenLayer2.NumOfNeurons, pOriginalBrain->HiddenLayer2.NumOfNeurons);

		for (uint32_t i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer2.pNeuronIDArray[i];
			id1 = pOriginalBrain->HiddenLayer2.pNeuronIDArray[i];

			numOfOutputSynapses = min(pNeuronArray[id].NumOfOutputSynapses, pOriginalBrain->pNeuronArray[id1].NumOfOutputSynapses);

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				pNeuronArray[id].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[id1].pOutputSynapsePlasticityArray[j];

				if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
					continue;

				pNeuronArray[id].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-variance, variance);
			}
		}

		if (HiddenLayer2.AdditionalBiasNeuron == true)
		{
			uint32_t biasNeuronID = HiddenLayer2.BiasNeuronID;
			uint32_t biasNeuronID1 = pOriginalBrain->HiddenLayer2.BiasNeuronID;

			numOfOutputSynapses = min(pNeuronArray[biasNeuronID].NumOfOutputSynapses, pOriginalBrain->pNeuronArray[biasNeuronID1].NumOfOutputSynapses);

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[biasNeuronID1].pOutputSynapsePlasticityArray[j];

				if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
					continue;

				pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-variance, variance);
			}
		}
	}

	void Clone_OutputSynapsePlasticities_HiddenLayer3(CNeuralNet *pOriginalBrain, float variance, uint64_t newSeed)
	{
		if (HiddenLayer3Used == false)
			return;

		RandomNumbers.Change_Seed(newSeed);

		uint32_t j, id, id1, numOfOutputSynapses;

		uint32_t numOfNeurons = min(HiddenLayer3.NumOfNeurons, pOriginalBrain->HiddenLayer3.NumOfNeurons);

		for (uint32_t i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer3.pNeuronIDArray[i];
			id1 = pOriginalBrain->HiddenLayer3.pNeuronIDArray[i];

			numOfOutputSynapses = min(pNeuronArray[id].NumOfOutputSynapses, pOriginalBrain->pNeuronArray[id1].NumOfOutputSynapses);

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				pNeuronArray[id].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[id1].pOutputSynapsePlasticityArray[j];
				pNeuronArray[id].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-variance, variance);
			}
		}

		if (HiddenLayer3.AdditionalBiasNeuron == true)
		{
			uint32_t biasNeuronID = HiddenLayer3.BiasNeuronID;
			uint32_t biasNeuronID1 = pOriginalBrain->HiddenLayer3.BiasNeuronID;

			numOfOutputSynapses = min(pNeuronArray[biasNeuronID].NumOfOutputSynapses, pOriginalBrain->pNeuronArray[biasNeuronID1].NumOfOutputSynapses);

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[biasNeuronID1].pOutputSynapsePlasticityArray[j];
				pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-variance, variance);
			}
		}
	}

	void Clone_OutputSynapsePlasticities_HiddenLayer3(CNeuralNet *pOriginalBrain, float variance, float mutationRate, uint64_t newSeed)
	{
		if (HiddenLayer3Used == false)
			return;

		RandomNumbers.Change_Seed(newSeed);

		uint32_t j, id, id1, numOfOutputSynapses;

		uint32_t numOfNeurons = min(HiddenLayer3.NumOfNeurons, pOriginalBrain->HiddenLayer3.NumOfNeurons);

		for (uint32_t i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer3.pNeuronIDArray[i];
			id1 = pOriginalBrain->HiddenLayer3.pNeuronIDArray[i];

			numOfOutputSynapses = min(pNeuronArray[id].NumOfOutputSynapses, pOriginalBrain->pNeuronArray[id1].NumOfOutputSynapses);

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				pNeuronArray[id].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[id1].pOutputSynapsePlasticityArray[j];

				if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
					continue;

				pNeuronArray[id].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-variance, variance);
			}
		}

		if (HiddenLayer3.AdditionalBiasNeuron == true)
		{
			uint32_t biasNeuronID = HiddenLayer3.BiasNeuronID;
			uint32_t biasNeuronID1 = pOriginalBrain->HiddenLayer3.BiasNeuronID;

			numOfOutputSynapses = min(pNeuronArray[biasNeuronID].NumOfOutputSynapses, pOriginalBrain->pNeuronArray[biasNeuronID1].NumOfOutputSynapses);

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[biasNeuronID1].pOutputSynapsePlasticityArray[j];

				if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
					continue;

				pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-variance, variance);
			}
		}
	}
	

	void Combine_OutputSynapsePlasticities_InputLayer(CNeuralNet *pParentBrain1, CNeuralNet *pParentBrain2, float minWeight1, uint64_t newSeed)
	{
		RandomNumbers.Change_Seed(newSeed);

		uint32_t j, numOfOutputSynapses;

		float weight1, weight2;

		float newPlasticity;

		/*for (uint32_t i = 0; i < NumInputNeurons; i++)
		{
			numOfOutputSynapses = pNeuronArray[i].NumOfOutputSynapses;

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				weight1 = RandomNumbers.Get_FloatNumber(minWeight1, 1.0f);
				weight2 = 1.0f - weight1;
				newPlasticity = weight1*pParentBrain1->pNeuronArray[i].pOutputSynapsePlasticityArray[j];
				newPlasticity += weight2*pParentBrain2->pNeuronArray[i].pOutputSynapsePlasticityArray[j];

				pNeuronArray[i].pOutputSynapsePlasticityArray[j] = newPlasticity;
			}
		}

		if (AdditionalInputBiasNeuron == true)
		{
			numOfOutputSynapses = pNeuronArray[InputBiasNeuronID].NumOfOutputSynapses;

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				weight1 = RandomNumbers.Get_FloatNumber(minWeight1, 1.0f);
				weight2 = 1.0f - weight1;
				newPlasticity = weight1*pParentBrain1->pNeuronArray[InputBiasNeuronID].pOutputSynapsePlasticityArray[j];
				newPlasticity += weight2*pParentBrain2->pNeuronArray[InputBiasNeuronID].pOutputSynapsePlasticityArray[j];

				pNeuronArray[InputBiasNeuronID].pOutputSynapsePlasticityArray[j] = newPlasticity;
			}
		}*/

		uint32_t numInputNeurons = min(NumInputNeurons, pParentBrain1->NumInputNeurons);
		numInputNeurons = min(numInputNeurons, pParentBrain2->NumInputNeurons);

		for (uint32_t i = 0; i < numInputNeurons; i++)
		{
			numOfOutputSynapses = min(pNeuronArray[i].NumOfOutputSynapses, pParentBrain1->pNeuronArray[i].NumOfOutputSynapses);
			numOfOutputSynapses = min(numOfOutputSynapses, pParentBrain2->pNeuronArray[i].NumOfOutputSynapses);

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				weight1 = RandomNumbers.Get_FloatNumber(minWeight1, 1.0f);
				weight2 = 1.0f - weight1;
				newPlasticity = weight1*pParentBrain1->pNeuronArray[i].pOutputSynapsePlasticityArray[j];
				newPlasticity += weight2*pParentBrain2->pNeuronArray[i].pOutputSynapsePlasticityArray[j];

				pNeuronArray[i].pOutputSynapsePlasticityArray[j] = newPlasticity;
			}
		}

		if (AdditionalInputBiasNeuron == true)
		{
			uint32_t biasNeuronID = InputBiasNeuronID;
			uint32_t biasNeuronID1 = pParentBrain1->InputBiasNeuronID;
			uint32_t biasNeuronID2 = pParentBrain2->InputBiasNeuronID;

			numOfOutputSynapses = min(pNeuronArray[biasNeuronID].NumOfOutputSynapses, pParentBrain1->pNeuronArray[biasNeuronID1].NumOfOutputSynapses);
			numOfOutputSynapses = min(numOfOutputSynapses, pParentBrain2->pNeuronArray[biasNeuronID2].NumOfOutputSynapses);

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				weight1 = RandomNumbers.Get_FloatNumber(minWeight1, 1.0f);
				weight2 = 1.0f - weight1;
				newPlasticity = weight1*pParentBrain1->pNeuronArray[biasNeuronID1].pOutputSynapsePlasticityArray[j];
				newPlasticity += weight2*pParentBrain2->pNeuronArray[biasNeuronID2].pOutputSynapsePlasticityArray[j];

				pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] = newPlasticity;
			}
		}
	}

	void Combine_OutputSynapsePlasticities_HiddenLayer1(CNeuralNet *pParentBrain1, CNeuralNet *pParentBrain2, float minWeight1, uint64_t newSeed)
	{
		if (HiddenLayer1Used == false)
			return;

		RandomNumbers.Change_Seed(newSeed);

		uint32_t j, id, id1, id2, numOfOutputSynapses;

		float weight1, weight2;

		float newPlasticity;

		//uint32_t numOfNeurons = HiddenLayer1.NumOfNeurons;

		uint32_t numOfNeurons = min(HiddenLayer1.NumOfNeurons, pParentBrain1->HiddenLayer1.NumOfNeurons);
		numOfNeurons = min(numOfNeurons, pParentBrain2->HiddenLayer1.NumOfNeurons);

		/*for (uint32_t i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer1.pNeuronIDArray[i];

			numOfOutputSynapses = pNeuronArray[id].NumOfOutputSynapses;

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				weight1 = RandomNumbers.Get_FloatNumber(minWeight1, 1.0f);
				weight2 = 1.0f - weight1;
				newPlasticity = weight1*pParentBrain1->pNeuronArray[id].pOutputSynapsePlasticityArray[j];
				newPlasticity += weight2*pParentBrain2->pNeuronArray[id].pOutputSynapsePlasticityArray[j];

				pNeuronArray[id].pOutputSynapsePlasticityArray[j] = newPlasticity;
			}
		}*/

		for (uint32_t i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer1.pNeuronIDArray[i];
			id1 = pParentBrain1->HiddenLayer1.pNeuronIDArray[i];
			id2 = pParentBrain2->HiddenLayer1.pNeuronIDArray[i];

			numOfOutputSynapses = min(pNeuronArray[id].NumOfOutputSynapses, pParentBrain1->pNeuronArray[id1].NumOfOutputSynapses);
			numOfOutputSynapses = min(numOfOutputSynapses, pParentBrain2->pNeuronArray[id2].NumOfOutputSynapses);

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				weight1 = RandomNumbers.Get_FloatNumber(minWeight1, 1.0f);
				weight2 = 1.0f - weight1;
				newPlasticity = weight1*pParentBrain1->pNeuronArray[id1].pOutputSynapsePlasticityArray[j];
				newPlasticity += weight2*pParentBrain2->pNeuronArray[id2].pOutputSynapsePlasticityArray[j];

				pNeuronArray[id].pOutputSynapsePlasticityArray[j] = newPlasticity;
			}
		}

		/*if (HiddenLayer1.AdditionalBiasNeuron == true)
		{
			uint32_t biasNeuronID = HiddenLayer1.BiasNeuronID;

			numOfOutputSynapses = pNeuronArray[biasNeuronID].NumOfOutputSynapses;

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				weight1 = RandomNumbers.Get_FloatNumber(minWeight1, 1.0f);
				weight2 = 1.0f - weight1;
				newPlasticity = weight1*pParentBrain1->pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j];
				newPlasticity += weight2*pParentBrain2->pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j];

				pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] = newPlasticity;
			}
		}*/

		if (HiddenLayer1.AdditionalBiasNeuron == true)
		{
			uint32_t biasNeuronID = HiddenLayer1.BiasNeuronID;
			uint32_t biasNeuronID1 = pParentBrain1->HiddenLayer1.BiasNeuronID;
			uint32_t biasNeuronID2 = pParentBrain2->HiddenLayer1.BiasNeuronID;

			numOfOutputSynapses = min(pNeuronArray[biasNeuronID].NumOfOutputSynapses, pParentBrain1->pNeuronArray[biasNeuronID1].NumOfOutputSynapses);
			numOfOutputSynapses = min(numOfOutputSynapses, pParentBrain2->pNeuronArray[biasNeuronID2].NumOfOutputSynapses);

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				weight1 = RandomNumbers.Get_FloatNumber(minWeight1, 1.0f);
				weight2 = 1.0f - weight1;
				newPlasticity = weight1*pParentBrain1->pNeuronArray[biasNeuronID1].pOutputSynapsePlasticityArray[j];
				newPlasticity += weight2*pParentBrain2->pNeuronArray[biasNeuronID2].pOutputSynapsePlasticityArray[j];

				pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] = newPlasticity;
			}
		}
	}

	void Combine_OutputSynapsePlasticities_HiddenLayer2(CNeuralNet *pParentBrain1, CNeuralNet *pParentBrain2, float minWeight1, uint64_t newSeed)
	{
		if (HiddenLayer2Used == false)
			return;

		RandomNumbers.Change_Seed(newSeed);

		uint32_t j, id, id1, id2, numOfOutputSynapses;

		float weight1, weight2;

		float newPlasticity;

		//uint32_t numOfNeurons = HiddenLayer2.NumOfNeurons;

		uint32_t numOfNeurons = min(HiddenLayer2.NumOfNeurons, pParentBrain1->HiddenLayer2.NumOfNeurons);
		numOfNeurons = min(numOfNeurons, pParentBrain2->HiddenLayer2.NumOfNeurons);

		/*for (uint32_t i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer2.pNeuronIDArray[i];

			numOfOutputSynapses = pNeuronArray[id].NumOfOutputSynapses;

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				weight1 = RandomNumbers.Get_FloatNumber(minWeight1, 1.0f);
				weight2 = 1.0f - weight1;
				newPlasticity = weight1*pParentBrain1->pNeuronArray[id].pOutputSynapsePlasticityArray[j];
				newPlasticity += weight2*pParentBrain2->pNeuronArray[id].pOutputSynapsePlasticityArray[j];

				pNeuronArray[id].pOutputSynapsePlasticityArray[j] = newPlasticity;
			}
		}*/

		for (uint32_t i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer2.pNeuronIDArray[i];
			id1 = pParentBrain1->HiddenLayer2.pNeuronIDArray[i];
			id2 = pParentBrain2->HiddenLayer2.pNeuronIDArray[i];

			numOfOutputSynapses = min(pNeuronArray[id].NumOfOutputSynapses, pParentBrain1->pNeuronArray[id1].NumOfOutputSynapses);
			numOfOutputSynapses = min(numOfOutputSynapses, pParentBrain2->pNeuronArray[id2].NumOfOutputSynapses);

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				weight1 = RandomNumbers.Get_FloatNumber(minWeight1, 1.0f);
				weight2 = 1.0f - weight1;
				newPlasticity = weight1*pParentBrain1->pNeuronArray[id1].pOutputSynapsePlasticityArray[j];
				newPlasticity += weight2*pParentBrain2->pNeuronArray[id2].pOutputSynapsePlasticityArray[j];

				pNeuronArray[id].pOutputSynapsePlasticityArray[j] = newPlasticity;
			}
		}

		/*if (HiddenLayer2.AdditionalBiasNeuron == true)
		{
			uint32_t biasNeuronID = HiddenLayer2.BiasNeuronID;

			numOfOutputSynapses = pNeuronArray[biasNeuronID].NumOfOutputSynapses;

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				weight1 = RandomNumbers.Get_FloatNumber(minWeight1, 1.0f);
				weight2 = 1.0f - weight1;
				newPlasticity = weight1*pParentBrain1->pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j];
				newPlasticity += weight2*pParentBrain2->pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j];

				pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] = newPlasticity;
			}
		}*/

		if (HiddenLayer2.AdditionalBiasNeuron == true)
		{
			uint32_t biasNeuronID = HiddenLayer2.BiasNeuronID;
			uint32_t biasNeuronID1 = pParentBrain1->HiddenLayer2.BiasNeuronID;
			uint32_t biasNeuronID2 = pParentBrain2->HiddenLayer2.BiasNeuronID;

			numOfOutputSynapses = min(pNeuronArray[biasNeuronID].NumOfOutputSynapses, pParentBrain1->pNeuronArray[biasNeuronID1].NumOfOutputSynapses);
			numOfOutputSynapses = min(numOfOutputSynapses, pParentBrain2->pNeuronArray[biasNeuronID2].NumOfOutputSynapses);

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				weight1 = RandomNumbers.Get_FloatNumber(minWeight1, 1.0f);
				weight2 = 1.0f - weight1;
				newPlasticity = weight1*pParentBrain1->pNeuronArray[biasNeuronID1].pOutputSynapsePlasticityArray[j];
				newPlasticity += weight2*pParentBrain2->pNeuronArray[biasNeuronID2].pOutputSynapsePlasticityArray[j];

				pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] = newPlasticity;
			}
		}
	}

	void Combine_OutputSynapsePlasticities_HiddenLayer3(CNeuralNet *pParentBrain1, CNeuralNet *pParentBrain2, float minWeight1, uint64_t newSeed)
	{
		if (HiddenLayer3Used == false)
			return;

		RandomNumbers.Change_Seed(newSeed);

		uint32_t j, id, id1, id2, numOfOutputSynapses;

		float weight1, weight2;

		float newPlasticity;

		//uint32_t numOfNeurons = HiddenLayer3.NumOfNeurons;

		uint32_t numOfNeurons = min(HiddenLayer3.NumOfNeurons, pParentBrain1->HiddenLayer3.NumOfNeurons);
		numOfNeurons = min(numOfNeurons, pParentBrain2->HiddenLayer3.NumOfNeurons);

		/*for (uint32_t i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer3.pNeuronIDArray[i];

			numOfOutputSynapses = pNeuronArray[id].NumOfOutputSynapses;

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				weight1 = RandomNumbers.Get_FloatNumber(minWeight1, 1.0f);
				weight2 = 1.0f - weight1;
				newPlasticity = weight1*pParentBrain1->pNeuronArray[id].pOutputSynapsePlasticityArray[j];
				newPlasticity += weight2*pParentBrain2->pNeuronArray[id].pOutputSynapsePlasticityArray[j];

				pNeuronArray[id].pOutputSynapsePlasticityArray[j] = newPlasticity;
			}
		}*/

		for (uint32_t i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer3.pNeuronIDArray[i];
			id1 = pParentBrain1->HiddenLayer3.pNeuronIDArray[i];
			id2 = pParentBrain2->HiddenLayer3.pNeuronIDArray[i];

			numOfOutputSynapses = min(pNeuronArray[id].NumOfOutputSynapses, pParentBrain1->pNeuronArray[id1].NumOfOutputSynapses);
			numOfOutputSynapses = min(numOfOutputSynapses, pParentBrain2->pNeuronArray[id2].NumOfOutputSynapses);

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				weight1 = RandomNumbers.Get_FloatNumber(minWeight1, 1.0f);
				weight2 = 1.0f - weight1;
				newPlasticity = weight1*pParentBrain1->pNeuronArray[id1].pOutputSynapsePlasticityArray[j];
				newPlasticity += weight2*pParentBrain2->pNeuronArray[id2].pOutputSynapsePlasticityArray[j];

				pNeuronArray[id].pOutputSynapsePlasticityArray[j] = newPlasticity;
			}
		}

		/*if (HiddenLayer3.AdditionalBiasNeuron == true)
		{
			uint32_t biasNeuronID = HiddenLayer3.BiasNeuronID;

			numOfOutputSynapses = pNeuronArray[biasNeuronID].NumOfOutputSynapses;

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				weight1 = RandomNumbers.Get_FloatNumber(minWeight1, 1.0f);
				weight2 = 1.0f - weight1;
				newPlasticity = weight1*pParentBrain1->pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j];
				newPlasticity += weight2*pParentBrain2->pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j];

				pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] = newPlasticity;
			}
		}*/

		if (HiddenLayer3.AdditionalBiasNeuron == true)
		{
			uint32_t biasNeuronID = HiddenLayer3.BiasNeuronID;
			uint32_t biasNeuronID1 = pParentBrain1->HiddenLayer3.BiasNeuronID;
			uint32_t biasNeuronID2 = pParentBrain2->HiddenLayer3.BiasNeuronID;

			numOfOutputSynapses = min(pNeuronArray[biasNeuronID].NumOfOutputSynapses, pParentBrain1->pNeuronArray[biasNeuronID1].NumOfOutputSynapses);
			numOfOutputSynapses = min(numOfOutputSynapses, pParentBrain2->pNeuronArray[biasNeuronID2].NumOfOutputSynapses);

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				weight1 = RandomNumbers.Get_FloatNumber(minWeight1, 1.0f);
				weight2 = 1.0f - weight1;
				newPlasticity = weight1*pParentBrain1->pNeuronArray[biasNeuronID1].pOutputSynapsePlasticityArray[j];
				newPlasticity += weight2*pParentBrain2->pNeuronArray[biasNeuronID2].pOutputSynapsePlasticityArray[j];

				pNeuronArray[biasNeuronID].pOutputSynapsePlasticityArray[j] = newPlasticity;
			}
		}
	}

	void Combine_OutputSynapsePlasticities_ReservoirNeurons(CNeuralNet *pParentBrain1, CNeuralNet *pParentBrain2, float minWeight1, uint64_t newSeed)
	{
		RandomNumbers.Change_Seed(newSeed);

		uint32_t j, id, numOfOutputSynapses, receiverID;

		float weight1, weight2;

		float newPlasticity;

		for (uint32_t i = 0; i < NumReservoirNeurons; i++)
		{
			id = FirstReservoirNeuronID + i;

			numOfOutputSynapses = pNeuronArray[id].NumOfOutputSynapses;

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				receiverID = pNeuronArray[id].pReceiverNeuronIDArray[i];

				if (pNeuronArray[receiverID].UsedAsMemoryNeuron != true)
					continue;

				weight1 = RandomNumbers.Get_FloatNumber(minWeight1, 1.0f);
				weight2 = 1.0f - weight1;
				newPlasticity = weight1*pParentBrain1->pNeuronArray[id].pOutputSynapsePlasticityArray[j];
				newPlasticity += weight2*pParentBrain2->pNeuronArray[id].pOutputSynapsePlasticityArray[j];

				pNeuronArray[id].pOutputSynapsePlasticityArray[j] = newPlasticity;
			}
		}
	}

	void Combine_OutputSynapsePlasticities(CNeuralNet *pParentBrain1, CNeuralNet *pParentBrain2, float minWeight1, uint64_t newSeed)
	{
		RandomNumbers.Change_Seed(newSeed);

		uint32_t j, numOfOutputSynapses;

		float weight1, weight2;

		float newPlasticity;

		for (uint32_t i = 0; i < NumOfUsedNeurons; i++)
		{
			numOfOutputSynapses = pNeuronArray[i].NumOfOutputSynapses;

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				weight1 = RandomNumbers.Get_FloatNumber(minWeight1, 1.0f);
				weight2 = 1.0f - weight1;
				newPlasticity = weight1*pParentBrain1->pNeuronArray[i].pOutputSynapsePlasticityArray[j];
				newPlasticity += weight2*pParentBrain2->pNeuronArray[i].pOutputSynapsePlasticityArray[j];

				pNeuronArray[i].pOutputSynapsePlasticityArray[j] = newPlasticity;
			}
		}
	}


	
	void Calculate_Output_UseActivationSequence(float *pOutputValueArray, const float *pInputValueArray)
	{
		for (uint32_t i = 0; i < NumInputNeurons; i++)
			pNeuronArray[i].Set_Input(pInputValueArray[i]);
			
		uint32_t id;

		
		for (uint32_t i = 0; i < NumOfActivationSequenceArrayEntries; i++)
		{
			id = pActivationSequenceArray[i];

			if(pNeuronArray[id].UsedAsBiasNeuron == false && pNeuronArray[id].UsedAsInputNeuron == false)
				pNeuronArray[id].Calculate_NeuronOutput();

			if (pNeuronArray[id].UsedAsOutputNeuron == false)
				pNeuronArray[id].Propagate_SynapticOutput();
		}

		for (uint32_t i = 0; i < NumOutputNeurons; i++)
		{
			id = i + FirstOutputNeuronID;

			pOutputValueArray[i] = pNeuronArray[id].Get_NeuronOutput();
		}
	}

	float Calculate_Output_With_Error_UseActivationSequence(float *pOutputValueArray, const float *pInputValueArray)
	{
		for (uint32_t i = 0; i < NumInputNeurons; i++)
			pNeuronArray[i].Set_Input(pInputValueArray[i]);
			
		uint32_t id;

		for (uint32_t i = 0; i < NumOfActivationSequenceArrayEntries; i++)
		{
			id = pActivationSequenceArray[i];

			if (pNeuronArray[id].UsedAsBiasNeuron == false && pNeuronArray[id].UsedAsInputNeuron == false)
				pNeuronArray[id].Calculate_NeuronOutput();

			if (pNeuronArray[id].UsedAsOutputNeuron == false)
				pNeuronArray[id].Propagate_SynapticOutput();
		}

		for (uint32_t i = 0; i < NumOutputNeurons; i++)
		{
			id = i + FirstOutputNeuronID;
			pOutputValueArray[i] = pNeuronArray[id].Get_NeuronOutput();	
		}

		float error = 0.0f;

		for (uint32_t i = 0; i < NumOutputNeurons; i++)
		{
			id = FirstOutputNeuronID + i;
			error += pNeuronArray[id].Calculate_Error(pInputValueArray[i]);
		}

		return error;
	}



	void Set_InputValues_HiddenLayer1(const float *pInputValueArray)
	{
		if (HiddenLayer1Used == false)
			return;

		uint32_t numOfNeurons = HiddenLayer1.NumOfNeurons;

		uint32_t i, id;

		for (i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer1.pNeuronIDArray[i];
			pNeuronArray[id].Set_Input(pInputValueArray[i]);
		}
	}

	void Set_InputValues_HiddenLayer1(float value)
	{
		if (HiddenLayer1Used == false)
			return;

		uint32_t numOfNeurons = HiddenLayer1.NumOfNeurons;

		uint32_t i, id;

		for (i = 0; i < numOfNeurons; i++)
		{
			id = HiddenLayer1.pNeuronIDArray[i];
			pNeuronArray[id].Set_NeuronInput(value);
		}
	}


	void Calculate_Output(float *pOutputValueArray, const float *pInputValueArray)
	{
		uint32_t i, id;

		for (i = 0; i < NumInputNeurons; i++)
		{
			pNeuronArray[i].Set_Input(pInputValueArray[i]);
			pNeuronArray[i].Propagate_SynapticOutput();
		}

		if (AdditionalInputBiasNeuron == true)
			pNeuronArray[InputBiasNeuronID].Propagate_SynapticOutput();
		
		if(HiddenLayer1Used == true)
		{
			uint32_t numOfNeurons = HiddenLayer1.NumOfNeurons;

			for (i = 0; i < numOfNeurons; i++)
			{
				id = HiddenLayer1.pNeuronIDArray[i];

				pNeuronArray[id].Calculate_NeuronOutput();
				pNeuronArray[id].Propagate_SynapticOutput();
			}

			if(HiddenLayer1.AdditionalBiasNeuron == true)
				pNeuronArray[HiddenLayer1.BiasNeuronID].Propagate_SynapticOutput();
		}

		if (HiddenLayer2Used == true)
		{
			uint32_t numOfNeurons = HiddenLayer2.NumOfNeurons;

			for (i = 0; i < numOfNeurons; i++)
			{
				id = HiddenLayer2.pNeuronIDArray[i];

				pNeuronArray[id].Calculate_NeuronOutput();
				pNeuronArray[id].Propagate_SynapticOutput();
			}

			if (HiddenLayer2.AdditionalBiasNeuron == true)
				pNeuronArray[HiddenLayer2.BiasNeuronID].Propagate_SynapticOutput();
		}

		if (HiddenLayer3Used == true)
		{
			uint32_t numOfNeurons = HiddenLayer3.NumOfNeurons;

			for (i = 0; i < numOfNeurons; i++)
			{
				id = HiddenLayer3.pNeuronIDArray[i];

				pNeuronArray[id].Calculate_NeuronOutput();
				pNeuronArray[id].Propagate_SynapticOutput();
			}

			if (HiddenLayer3.AdditionalBiasNeuron == true)
				pNeuronArray[HiddenLayer3.BiasNeuronID].Propagate_SynapticOutput();
		}

		for (i = 0; i < NumOutputNeurons; i++)
		{
			id = i + FirstOutputNeuronID;

			pNeuronArray[id].Calculate_NeuronOutput();

			pOutputValueArray[i] = pNeuronArray[id].Get_NeuronOutput();
			//pOutputValueArray[i] = pNeuronArray[id].NeuronOutput;
		}
	}

	float Calculate_Output2(const float *pInputValueArray, uint32_t idOfOutputNeuron)
	{
		uint32_t i, id;

		for (i = 0; i < NumInputNeurons; i++)
		{
			pNeuronArray[i].Set_Input(pInputValueArray[i]);
			pNeuronArray[i].Propagate_SynapticOutput();
		}

		if (AdditionalInputBiasNeuron == true)
			pNeuronArray[InputBiasNeuronID].Propagate_SynapticOutput();

		if (HiddenLayer1Used == true)
		{
			uint32_t numOfNeurons = HiddenLayer1.NumOfNeurons;

			for (i = 0; i < numOfNeurons; i++)
			{
				id = HiddenLayer1.pNeuronIDArray[i];

				pNeuronArray[id].Calculate_NeuronOutput();
				pNeuronArray[id].Propagate_SynapticOutput();
			}

			if (HiddenLayer1.AdditionalBiasNeuron == true)
				pNeuronArray[HiddenLayer1.BiasNeuronID].Propagate_SynapticOutput();
		}

		if (HiddenLayer2Used == true)
		{
			uint32_t numOfNeurons = HiddenLayer2.NumOfNeurons;

			for (i = 0; i < numOfNeurons; i++)
			{
				id = HiddenLayer2.pNeuronIDArray[i];

				pNeuronArray[id].Calculate_NeuronOutput();
				pNeuronArray[id].Propagate_SynapticOutput();
			}

			if (HiddenLayer2.AdditionalBiasNeuron == true)
				pNeuronArray[HiddenLayer2.BiasNeuronID].Propagate_SynapticOutput();
		}

		if (HiddenLayer3Used == true)
		{
			uint32_t numOfNeurons = HiddenLayer3.NumOfNeurons;

			for (i = 0; i < numOfNeurons; i++)
			{
				id = HiddenLayer3.pNeuronIDArray[i];

				pNeuronArray[id].Calculate_NeuronOutput();
				pNeuronArray[id].Propagate_SynapticOutput();
			}

			if (HiddenLayer3.AdditionalBiasNeuron == true)
				pNeuronArray[HiddenLayer3.BiasNeuronID].Propagate_SynapticOutput();
		}

		for (i = 0; i < NumOutputNeurons; i++)
		{
			if (i == idOfOutputNeuron)
				continue;

			id = i + FirstOutputNeuronID;

			pNeuronArray[id].Reset_NeuronInput();
		}


		id = idOfOutputNeuron + FirstOutputNeuronID;

		pNeuronArray[id].Calculate_NeuronOutput();

		//return pNeuronArray[id].Get_NeuronOutput();
		return pNeuronArray[id].NeuronOutput;

	}

	void Calculate_Output_IgnoreInputNeurons(float *pOutputValueArray)
	{
		uint32_t i, id;

		if (HiddenLayer1Used == true)
		{
			uint32_t numOfNeurons = HiddenLayer1.NumOfNeurons;

			for (i = 0; i < numOfNeurons; i++)
			{
				id = HiddenLayer1.pNeuronIDArray[i];

				pNeuronArray[id].Calculate_NeuronOutput();
				pNeuronArray[id].Propagate_SynapticOutput();
			}

			if (HiddenLayer1.AdditionalBiasNeuron == true)
				pNeuronArray[HiddenLayer1.BiasNeuronID].Propagate_SynapticOutput();
		}

		if (HiddenLayer2Used == true)
		{
			uint32_t numOfNeurons = HiddenLayer2.NumOfNeurons;

			for (i = 0; i < numOfNeurons; i++)
			{
				id = HiddenLayer2.pNeuronIDArray[i];

				pNeuronArray[id].Calculate_NeuronOutput();
				pNeuronArray[id].Propagate_SynapticOutput();
			}

			if (HiddenLayer2.AdditionalBiasNeuron == true)
				pNeuronArray[HiddenLayer2.BiasNeuronID].Propagate_SynapticOutput();
		}

		if (HiddenLayer3Used == true)
		{
			uint32_t numOfNeurons = HiddenLayer3.NumOfNeurons;

			for (i = 0; i < numOfNeurons; i++)
			{
				id = HiddenLayer3.pNeuronIDArray[i];

				pNeuronArray[id].Calculate_NeuronOutput();
				pNeuronArray[id].Propagate_SynapticOutput();
			}

			if (HiddenLayer3.AdditionalBiasNeuron == true)
				pNeuronArray[HiddenLayer3.BiasNeuronID].Propagate_SynapticOutput();
		}

		for (i = 0; i < NumOutputNeurons; i++)
		{
			id = i + FirstOutputNeuronID;

			pNeuronArray[id].Calculate_NeuronOutput();

			pOutputValueArray[i] = pNeuronArray[id].Get_NeuronOutput();
			//pOutputValueArray[i] = pNeuronArray[id].NeuronOutput;
		}
	}

	float Calculate_Output_With_Error(float *pOutputValueArray, const float *pInputValueArray)
	{
		uint32_t i, id;

		for (i = 0; i < NumInputNeurons; i++)
		{
			pNeuronArray[i].Set_Input(pInputValueArray[i]);
			pNeuronArray[i].Propagate_SynapticOutput();
		}

		if (AdditionalInputBiasNeuron == true)
			pNeuronArray[InputBiasNeuronID].Propagate_SynapticOutput();

		if (HiddenLayer1Used == true)
		{
			uint32_t numOfNeurons = HiddenLayer1.NumOfNeurons;

			for (i = 0; i < numOfNeurons; i++)
			{
				id = HiddenLayer1.pNeuronIDArray[i];

				pNeuronArray[id].Calculate_NeuronOutput();
				pNeuronArray[id].Propagate_SynapticOutput();
			}

			if (HiddenLayer1.AdditionalBiasNeuron == true)
				pNeuronArray[HiddenLayer1.BiasNeuronID].Propagate_SynapticOutput();
		}

		if (HiddenLayer2Used == true)
		{
			uint32_t numOfNeurons = HiddenLayer2.NumOfNeurons;

			for (i = 0; i < numOfNeurons; i++)
			{
				id = HiddenLayer2.pNeuronIDArray[i];

				pNeuronArray[id].Calculate_NeuronOutput();
				pNeuronArray[id].Propagate_SynapticOutput();
			}

			if (HiddenLayer2.AdditionalBiasNeuron == true)
				pNeuronArray[HiddenLayer2.BiasNeuronID].Propagate_SynapticOutput();
		}

		if (HiddenLayer3Used == true)
		{
			uint32_t numOfNeurons = HiddenLayer3.NumOfNeurons;

			for (i = 0; i < numOfNeurons; i++)
			{
				id = HiddenLayer3.pNeuronIDArray[i];

				pNeuronArray[id].Calculate_NeuronOutput();
				pNeuronArray[id].Propagate_SynapticOutput();
			}

			if (HiddenLayer3.AdditionalBiasNeuron == true)
				pNeuronArray[HiddenLayer3.BiasNeuronID].Propagate_SynapticOutput();
		}

		for (i = 0; i < NumOutputNeurons; i++)
		{
			id = i + FirstOutputNeuronID;

			pNeuronArray[id].Calculate_NeuronOutput();

			pOutputValueArray[i] = pNeuronArray[id].Get_NeuronOutput();
			//pOutputValueArray[i] = pNeuronArray[id].NeuronOutput;
		}

		float error = 0.0f;

		for (i = 0; i < NumOutputNeurons; i++)
		{
			id = FirstOutputNeuronID + i;
			error += pNeuronArray[id].Calculate_Error(pInputValueArray[i]);
		}

		return error;
	}

	void Calculate_Error(float *pErrorValueArray, const float *pDesiredOutputValueArray)
	{
		uint32_t id;

		for (uint32_t i = 0; i < NumOutputNeurons; i++)
		{
			id = i + FirstOutputNeuronID;

			pErrorValueArray[i] = pNeuronArray[id].Calculate_Error(pDesiredOutputValueArray[i]);
		}
	}

	float Calculate_Error(const float *pDesiredOutputValueArray)
	{
		float error = 0.0f;

		uint32_t id;

		for (uint32_t i = 0; i < NumOutputNeurons; i++)
		{
			id = FirstOutputNeuronID + i;

			error += pNeuronArray[id].Calculate_Error(pDesiredOutputValueArray[i]);
		}

		return error;
	}

	float Learning_UseActivationSequence(const float *pDesiredOutputValueArray)
	{
		uint32_t i;
		uint32_t id;

		float error = 0.0f;

		
		for (i = 0; i < NumOutputNeurons; i++)
		{
			id = FirstOutputNeuronID + i;

			error += pNeuronArray[id].Calculate_Error(pDesiredOutputValueArray[i]);
		}

		for (uint32_t i = NumOfActivationSequenceArrayEntries - 1; i >= 1; i--)
		{
			id = pActivationSequenceArray[i];

			if (pNeuronArray[id].UsedAsBiasNeuron == true)
				continue;
			if (pNeuronArray[id].UsedAsOutputNeuron == true)
				continue;
			if (pNeuronArray[id].UsedAsInputNeuron == true)
				continue;

			pNeuronArray[id].Calculate_Error();
		}

		for (uint32_t i = 0; i < NumOfActivationSequenceArrayEntries; i++)
		{
			id = pActivationSequenceArray[i];

			if (pNeuronArray[id].UsedAsOutputNeuron == false)
				pNeuronArray[id].Adjust_OutputSynapses_AfterErrorCalculations();
		}

		return error;
	}
	

	float Learning(const float *pDesiredOutputValueArray)
	{
		uint32_t i;
		uint32_t id;

		float error = 0.0f;

		for (i = 0; i < NumOutputNeurons; i++)
		{
			id = FirstOutputNeuronID + i;

			error += pNeuronArray[id].Calculate_Error(pDesiredOutputValueArray[i]);
		}

		if (HiddenLayer3Used == true)
		{
			uint32_t numOfNeurons = HiddenLayer3.NumOfNeurons;

			for (i = 0; i < numOfNeurons; i++)
			{
				id = HiddenLayer3.pNeuronIDArray[i];
				pNeuronArray[id].Calculate_Error();
			}
		}

		if (HiddenLayer2Used == true)
		{
			uint32_t numOfNeurons = HiddenLayer2.NumOfNeurons;

			for (i = 0; i < numOfNeurons; i++)
			{
				id = HiddenLayer2.pNeuronIDArray[i];
				pNeuronArray[id].Calculate_Error();
			}
		}

		if (HiddenLayer1Used == true)
		{
			uint32_t numOfNeurons = HiddenLayer1.NumOfNeurons;

			for (i = 0; i < numOfNeurons; i++)
			{
				id = HiddenLayer1.pNeuronIDArray[i];
				pNeuronArray[id].Calculate_Error();
			}
		}


		if (HiddenLayer1Used == true)
		{
			uint32_t numOfNeurons = HiddenLayer1.NumOfNeurons;

			for (i = 0; i < numOfNeurons; i++)
			{
				id = HiddenLayer1.pNeuronIDArray[i];
				pNeuronArray[id].Adjust_OutputSynapses_AfterErrorCalculations();
			}

			if (HiddenLayer1.AdditionalBiasNeuron == true)
				pNeuronArray[HiddenLayer1.BiasNeuronID].Adjust_OutputSynapses_AfterErrorCalculations();
		}

		if (HiddenLayer2Used == true)
		{
			uint32_t numOfNeurons = HiddenLayer2.NumOfNeurons;

			for (i = 0; i < numOfNeurons; i++)
			{
				id = HiddenLayer2.pNeuronIDArray[i];
				pNeuronArray[id].Adjust_OutputSynapses_AfterErrorCalculations();
			}

			if (HiddenLayer2.AdditionalBiasNeuron == true)
				pNeuronArray[HiddenLayer2.BiasNeuronID].Adjust_OutputSynapses_AfterErrorCalculations();
		}

		if (HiddenLayer3Used == true)
		{
			uint32_t numOfNeurons = HiddenLayer3.NumOfNeurons;

			for (i = 0; i < numOfNeurons; i++)
			{
				id = HiddenLayer3.pNeuronIDArray[i];
				pNeuronArray[id].Adjust_OutputSynapses_AfterErrorCalculations();
			}

			if (HiddenLayer3.AdditionalBiasNeuron == true)
				pNeuronArray[HiddenLayer3.BiasNeuronID].Adjust_OutputSynapses_AfterErrorCalculations();
		}


		if (AdditionalInputBiasNeuron == true)
			pNeuronArray[InputBiasNeuronID].Adjust_OutputSynapses_AfterErrorCalculations();

		for (uint32_t i = 0; i < NumInputNeurons; i++)
			pNeuronArray[i].Adjust_OutputSynapses_AfterErrorCalculations();


		return error;
	}

	float Learning(float desiredOutputValue, uint32_t idOfOutputNeuron)
	{
		uint32_t id = idOfOutputNeuron + FirstOutputNeuronID;
		float error = pNeuronArray[id].Calculate_Error(desiredOutputValue);



		uint32_t i;
		

		if (HiddenLayer3Used == true)
		{
			uint32_t numOfNeurons = HiddenLayer3.NumOfNeurons;

			for (i = 0; i < numOfNeurons; i++)
			{
				id = HiddenLayer3.pNeuronIDArray[i];
				pNeuronArray[id].Calculate_Error();
			}
		}

		if (HiddenLayer2Used == true)
		{
			uint32_t numOfNeurons = HiddenLayer2.NumOfNeurons;

			for (i = 0; i < numOfNeurons; i++)
			{
				id = HiddenLayer2.pNeuronIDArray[i];
				pNeuronArray[id].Calculate_Error();
			}
		}

		if (HiddenLayer1Used == true)
		{
			uint32_t numOfNeurons = HiddenLayer1.NumOfNeurons;

			for (i = 0; i < numOfNeurons; i++)
			{
				id = HiddenLayer1.pNeuronIDArray[i];
				pNeuronArray[id].Calculate_Error();
			}
		}


		if (HiddenLayer1Used == true)
		{
			uint32_t numOfNeurons = HiddenLayer1.NumOfNeurons;

			for (i = 0; i < numOfNeurons; i++)
			{
				id = HiddenLayer1.pNeuronIDArray[i];
				pNeuronArray[id].Adjust_OutputSynapses_AfterErrorCalculations();
			}

			if (HiddenLayer1.AdditionalBiasNeuron == true)
				pNeuronArray[HiddenLayer1.BiasNeuronID].Adjust_OutputSynapses_AfterErrorCalculations();
		}

		if (HiddenLayer2Used == true)
		{
			uint32_t numOfNeurons = HiddenLayer2.NumOfNeurons;

			for (i = 0; i < numOfNeurons; i++)
			{
				id = HiddenLayer2.pNeuronIDArray[i];
				pNeuronArray[id].Adjust_OutputSynapses_AfterErrorCalculations();
			}

			if (HiddenLayer2.AdditionalBiasNeuron == true)
				pNeuronArray[HiddenLayer2.BiasNeuronID].Adjust_OutputSynapses_AfterErrorCalculations();
		}

		if (HiddenLayer3Used == true)
		{
			uint32_t numOfNeurons = HiddenLayer3.NumOfNeurons;

			for (i = 0; i < numOfNeurons; i++)
			{
				id = HiddenLayer3.pNeuronIDArray[i];
				pNeuronArray[id].Adjust_OutputSynapses_AfterErrorCalculations();
			}

			if (HiddenLayer3.AdditionalBiasNeuron == true)
				pNeuronArray[HiddenLayer3.BiasNeuronID].Adjust_OutputSynapses_AfterErrorCalculations();
		}


		if (AdditionalInputBiasNeuron == true)
			pNeuronArray[InputBiasNeuronID].Adjust_OutputSynapses_AfterErrorCalculations();

		for (uint32_t i = 0; i < NumInputNeurons; i++)
			pNeuronArray[i].Adjust_OutputSynapses_AfterErrorCalculations();


		return error;
	}

	// Nur die Plastizit�tswerte der mit den Output-Neuronen verbundenen Synapsen werden modifiziert:
	float ExtremeLearning(const float *pDesiredOutputValueArray)
	{
		float error = 0.0f;

		uint32_t i;
		uint32_t id;


		for (i = 0; i < NumOutputNeurons; i++)
		{
			id = FirstOutputNeuronID + i;

			error += pNeuronArray[id].Calculate_Error(pDesiredOutputValueArray[i]);
		}

		if (HiddenLayer3Used == true)
		{
			uint32_t numOfNeurons = HiddenLayer3.NumOfNeurons;
	
			for (i = 0; i < numOfNeurons; i++)
			{
				id = HiddenLayer3.pNeuronIDArray[i];
				pNeuronArray[id].Adjust_OutputSynapses_AfterErrorCalculations();
			}

			if (HiddenLayer3.AdditionalBiasNeuron == true)
				pNeuronArray[HiddenLayer3.BiasNeuronID].Adjust_OutputSynapses_AfterErrorCalculations();
		}

		else if (HiddenLayer2Used == true && HiddenLayer3Used == false)
		{
			uint32_t numOfNeurons = HiddenLayer2.NumOfNeurons;

			for (i = 0; i < numOfNeurons; i++)
			{
				id = HiddenLayer2.pNeuronIDArray[i];
				pNeuronArray[id].Adjust_OutputSynapses_AfterErrorCalculations();
			}

			if (HiddenLayer2.AdditionalBiasNeuron == true)
				pNeuronArray[HiddenLayer2.BiasNeuronID].Adjust_OutputSynapses_AfterErrorCalculations();
		}

		else if (HiddenLayer1Used == true && HiddenLayer2Used == false && HiddenLayer3Used == false)
		{
			uint32_t numOfNeurons = HiddenLayer1.NumOfNeurons;

			for (i = 0; i < numOfNeurons; i++)
			{
				id = HiddenLayer1.pNeuronIDArray[i];
				pNeuronArray[id].Adjust_OutputSynapses_AfterErrorCalculations();
			}

			if (HiddenLayer1.AdditionalBiasNeuron == true)
				pNeuronArray[HiddenLayer1.BiasNeuronID].Adjust_OutputSynapses_AfterErrorCalculations();
		}

		return error;
	}

	// Nur die Plastizit�tswerte der mit den Output-Neuronen verbundenen Synapsen werden modifiziert:
	float ExtremeLearning(float desiredOutputValue, uint32_t idOfOutputNeuron)
	{
		
		uint32_t id = idOfOutputNeuron + FirstOutputNeuronID;
		float error = pNeuronArray[id].Calculate_Error(desiredOutputValue);

		uint32_t i;
		

		if (HiddenLayer3Used == true)
		{
			uint32_t numOfNeurons = HiddenLayer3.NumOfNeurons;

			for (i = 0; i < numOfNeurons; i++)
			{
				id = HiddenLayer3.pNeuronIDArray[i];
				pNeuronArray[id].Adjust_OutputSynapse_AfterErrorCalculations(idOfOutputNeuron);
			}

			if (HiddenLayer3.AdditionalBiasNeuron == true)
				pNeuronArray[HiddenLayer3.BiasNeuronID].Adjust_OutputSynapse_AfterErrorCalculations(idOfOutputNeuron);
		}

		else if (HiddenLayer2Used == true && HiddenLayer3Used == false)
		{
			uint32_t numOfNeurons = HiddenLayer2.NumOfNeurons;

			for (i = 0; i < numOfNeurons; i++)
			{
				id = HiddenLayer2.pNeuronIDArray[i];
				pNeuronArray[id].Adjust_OutputSynapse_AfterErrorCalculations(idOfOutputNeuron);
			}

			if (HiddenLayer2.AdditionalBiasNeuron == true)
				pNeuronArray[HiddenLayer2.BiasNeuronID].Adjust_OutputSynapse_AfterErrorCalculations(idOfOutputNeuron);
		}

		else if (HiddenLayer1Used == true && HiddenLayer2Used == false && HiddenLayer3Used == false)
		{
			uint32_t numOfNeurons = HiddenLayer1.NumOfNeurons;

			for (i = 0; i < numOfNeurons; i++)
			{
				id = HiddenLayer1.pNeuronIDArray[i];
				pNeuronArray[id].Adjust_OutputSynapse_AfterErrorCalculations(idOfOutputNeuron);
			}

			if (HiddenLayer1.AdditionalBiasNeuron == true)
				pNeuronArray[HiddenLayer1.BiasNeuronID].Adjust_OutputSynapse_AfterErrorCalculations(idOfOutputNeuron);
		}

		return error;
	}

	void Reset_Memory_Of_ReservoirNeurons(void)
	{
		uint32_t id;

		for (uint32_t i = 0; i < NumReservoirNeurons; i++)
		{
			id = FirstReservoirNeuronID + i;
			pNeuronArray[id].Reset_NeuronInput();
			pNeuronArray[id].Reset_NeuronOutput();
		}
	}

	void Calculate_Output_ReservoirComputing(float *pOutputValueArray, const float *pInputValueArray, uint32_t numAdditionalRecurrentCycles = 0)
	{
		uint32_t i, j, id;
		
		for (i = 0; i < NumInputNeurons; i++)
		{
			pNeuronArray[i].Set_Input(pInputValueArray[i]);
			pNeuronArray[i].Propagate_SynapticOutput();
		}

		if (AdditionalInputBiasNeuron == true)
			pNeuronArray[InputBiasNeuronID].Propagate_SynapticOutput();

		for (uint32_t k = 0; k < numAdditionalRecurrentCycles; k++)
		{
			for (i = 0; i < NumReservoirNeurons; i++)
			{
				id = FirstReservoirNeuronID + i;
				pNeuronArray[id].Calculate_NeuronOutput_And_Retain_Input();

				for (j = 0; j < pNumInternalReservoirConnectionsArray[i]; j++)
					pNeuronArray[id].Propagate_SynapticOutput(j);
			}
		}

		for (i = 0; i < NumReservoirNeurons; i++)
		{
			id = FirstReservoirNeuronID + i;
			pNeuronArray[id].Calculate_NeuronOutput_And_Retain_Input();
			pNeuronArray[id].Propagate_SynapticOutput();
		}

		for (i = 0; i < NumOutputNeurons; i++)
		{
			id = i + FirstOutputNeuronID;

			pNeuronArray[id].Calculate_NeuronOutput();

			pOutputValueArray[i] = pNeuronArray[id].Get_NeuronOutput();
			//pOutputValueArray[i] = pNeuronArray[id].NeuronOutput;
		}
	}

	// Funktionen f�r schrittweises reservoir computing einf�gen!

	void Update_InputNeurons_Prior_ReservorUpdate(const float *pInputValueArray)
	{
		for (uint32_t i = 0; i < NumInputNeurons; i++)
		{
			pNeuronArray[i].Set_Input(pInputValueArray[i]);
			pNeuronArray[i].Propagate_SynapticOutput();
		}

		if (AdditionalInputBiasNeuron == true)
			pNeuronArray[InputBiasNeuronID].Propagate_SynapticOutput();
	}

	void Update_ReservoirNeurons(void)
	{
		uint32_t j, id;

		for (uint32_t i = 0; i < NumReservoirNeurons; i++)
		{
			id = FirstReservoirNeuronID + i;
			pNeuronArray[id].Calculate_NeuronOutput_And_Retain_Input();

			for (j = 0; j < pNumInternalReservoirConnectionsArray[i]; j++)
				pNeuronArray[id].Propagate_SynapticOutput(j);
		}
	}

	void Update_OutputNeurons_After_ReservorUpdate(float *pOutputValueArray)
	{
		uint32_t i, id;

		for (i = 0; i < NumReservoirNeurons; i++)
		{
			id = FirstReservoirNeuronID + i;
			pNeuronArray[id].Calculate_NeuronOutput_And_Retain_Input();
			pNeuronArray[id].Propagate_SynapticOutput();
		}

		for (i = 0; i < NumOutputNeurons; i++)
		{
			id = i + FirstOutputNeuronID;

			pNeuronArray[id].Calculate_NeuronOutput();

			pOutputValueArray[i] = pNeuronArray[id].Get_NeuronOutput();
			//pOutputValueArray[i] = pNeuronArray[id].NeuronOutput;
		}
	}

	float Learning_ReservoirComputing(const float *pDesiredOutputValueArray)
	{
		uint32_t i, j, id;

		float error = 0.0f;

		for (i = 0; i < NumOutputNeurons; i++)
		{
			id = FirstOutputNeuronID + i;

			error += pNeuronArray[id].Calculate_Error(pDesiredOutputValueArray[i]);
		}

	
		for (i = 0; i < NumReservoirNeurons; i++)
		{
			id = FirstReservoirNeuronID + i;

			//pNeuronArray[id].Adjust_OutputSynapses_AfterErrorCalculations();

			if (pNeuronArray[id].NumOfOutputSynapses > pNumInternalReservoirConnectionsArray[i])
			{
				for (j = 0; j < NumOutputNeurons; j++)
				{
					pNeuronArray[id].Adjust_OutputSynapse_AfterErrorCalculations(pNumInternalReservoirConnectionsArray[i] + j);
				}
			}
		}

		return error;
	}


}; // end of class CNeuralNet



#endif