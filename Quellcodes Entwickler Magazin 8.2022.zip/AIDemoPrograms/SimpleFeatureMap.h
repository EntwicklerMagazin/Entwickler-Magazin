// Schutz vor Mehrfachdeklarationen :

#ifndef _SimpleFeatureMap_H_
#define _SimpleFeatureMap_H_

#include <iostream>
#include <fstream>
#include "LogFile.h"
#include "RandomNumbers.h"
#include "MathInlineFunctions.h"

#ifndef max
#define max(a,b)    ( ((a) > (b)) ? (a) : (b) )
#endif

#ifndef min
#define min(a,b)    ( ((a) < (b)) ? (a) : (b) )
#endif

class CSimpleFeatureMap
{
public:

	int32_t Size = 0;
	int32_t SizeX = 0;
	int32_t SizeY = 0;

	float *pDataArray = nullptr;


	CSimpleFeatureMap();
	~CSimpleFeatureMap();

	// Kopierkonstruktor l�schen:
	CSimpleFeatureMap(const CSimpleFeatureMap  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CSimpleFeatureMap & operator=(const CSimpleFeatureMap  &originalObject) = delete;

	void Init_Map(int32_t size);
	void Init_Map(int32_t sizeX, int32_t sizeY);

	void Reset_Values(float value);

	void Get_FeaturePositions(float *pOutFeaturePosIDArray, int32_t numFeaturePositionsMax, float minFeatureValue);
	void Get_FeaturePositions(float *pOutFeaturePosXArray, float *pOutFeaturePosYArray, int32_t numFeaturePositionsMax, float minFeatureValue);

	void Get_FeaturePositions(int32_t *pOutFeaturePosIDArray, int32_t numFeaturePositionsMax, float minFeatureValue);
	void Get_FeaturePositions(int32_t *pOutFeaturePosXArray, int32_t *pOutFeaturePosYArray, int32_t numFeaturePositionsMax, float minFeatureValue);

	void Apply_ReLU_Activation(void);
	void Apply_TanH_Activation(void);
	void Apply_FastTanHReplacement_Activation(void);
	void Apply_Sigmoid_Activation(void);
	void Apply_LeakyReLU_Activation(float leakingValue);

	void Clone_Values(CSimpleFeatureMap *pOriginalObject);
	void Clone_Values_OMP(CSimpleFeatureMap *pOriginalObject);
	void Clone_Values_OMP_AllThreads(CSimpleFeatureMap *pOriginalObject);
};

#endif