// Schutz vor Mehrfachdeklarationen:

#ifndef _NeuralNet_H_
#define _NeuralNet_H_

#include <iostream>
#include <fstream>
#include "LogFile.h"
#include "RandomNumbers.h"
#include "NeuralNetInlineFunctions.h"


#ifndef max
#define max(a,b)    ( ((a) > (b)) ? (a) : (b) )
#endif

#ifndef min
#define min(a,b)    ( ((a) < (b)) ? (a) : (b) )
#endif

#define UseNoImagePooling      0
#define UseImageMaxPooling2x2  1
#define UseImageL2Pooling2x2   2


//sigmoid(x) = 0.5f + 0.25f*x - 1.0f/48.0f*x*x*x + 1.0f/480.0f*x*x*x*x*x
// tanh(x) = x - 1.0f/3.0f*x*x*x+2.0f/15.0f**x*x*x*x*x


inline float BiasValueOutput(float neuronInput)
{
	return 1.0f;
}

inline float NegBiasValueOutput(float neuronInput)
{
	return -1.0f;
}


inline float SigmoidActivationFunc(float neuronInput)
{
	// von 0.0f bis 1.0f:
	return 1.0f / (1.0f + exp(-neuronInput));
}

inline float ScaledSigmoidActivationFunc(float neuronInput)
{
	// von 0.0f bis 1.0f:
	return 1.0f / (1.0f + exp(-10.0f * neuronInput));
}

inline float SineActivationFunc(float neuronInput)
{
	// von -1.0f bis 1.0f:
	return sin(neuronInput);
}

inline float CosineActivationFunc(float neuronInput)
{
	// von -1.0f bis 1.0f:
	return cos(neuronInput);
}


inline float TanHActivationFunc(float neuronInput)
{
	// von -1.0f bis 1.0f:
	return tanh(neuronInput);
}

inline float ScaledTanHActivationFunc(float neuronInput)
{
	return tanh(0.1f * neuronInput);
}

inline float FastTanHReplacementActivationFunc(float neuronInput)
{
	// von -1.0f bis 1.0f:
	return neuronInput / (1.0f + abs(neuronInput));
}

inline float ReLUActivationFunc(float neuronInput)
{
	// von 0.0f bis unendlich:
	return max(0.0f, neuronInput);

	/*if (neuronInput < 0.0f)
	return 0.01f * neuronInput;
	else
	return neuronInput;*/
}

inline float ClippedReLUActivationFunc(float neuronInput)
{
	if (neuronInput < 0.0f)
		return 0.0f;
	else
	{
		return min(1.0f, neuronInput);
	}
}

inline float LeakyReLUActivationFunc(float neuronInput)
{
	if (neuronInput < 0.0f)
		return 0.01f * neuronInput;
	else
		return neuronInput;
}

inline float ClippedLeakyReLUActivationFunc(float neuronInput)
{
	if (neuronInput < 0.0f)
		return max(-1.0f, 0.01f * neuronInput);
	else
	{
		return min(1.0f, neuronInput);
	}
}



inline float BinaryOutputActivationFunc1(float neuronInput)
{
	//if (neuronInput > 0.9999f)
	//return 1.0f;

	// less accuracy
	if (neuronInput > 0.9f)
		return 1.0f;

	return 0.0f;
}

inline float BinaryOutputActivationFunc2(float neuronInput)
{
	if (neuronInput > 0.4999f)
		return 1.0f;

	return 0.0f;
}


inline float ClippedLinearActivationFunc(float neuronInput)
{
	if (neuronInput > 1.0f)
		neuronInput = 1.0f;
	else if (neuronInput < -1.0f)
		neuronInput = -1.0f;

	return neuronInput;
}

inline float LinearActivationFunc(float neuronInput)
{
	return neuronInput;
}

inline float NegLinearActivationFunc(float neuronInput)
{
	return -neuronInput;
}


inline float RBFActivationFunc(/*scaledRBFCentroidDistanceSqSum*/ float neuronInput)
{
	return exp(-neuronInput);
}

static float g_StepwiseNeuronOutputArray[100];

inline float StepwiseOutput(float neuronInput)
{
	float offset = 1.0f;

	int32_t id = 10.0f*(neuronInput + offset);

	id = max(id, 0);
	id = min(id, 99);

	return g_StepwiseNeuronOutputArray[id];
}


inline float ConstantError(float neuronOutput)
{
	return 1.0f;
}

inline float LinearError(float neuronOutput)
{
	return neuronOutput;
}

inline float GaussianError(float neuronOutput)
{
	return exp(-(neuronOutput*neuronOutput));
}

inline float DerivedSigmoidError(float neuronOutput)
{
	return neuronOutput * (1.0f - neuronOutput);
}


// Definition eines Funktionszeiger-Typs:
typedef float(*pActivationFunc)(float neuronInput);

// Definition eines Funktionszeiger-Typs:
typedef float(*pErrorFunc)(float neuronOutput);





inline void Calculate_FeatureMap(float *pFeatureMap, const float *pInputArray, int32_t inputArraySizeX, int32_t inputArraySizeY,
	const float *pKernelValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY)
{
	if (kernelSizeX == inputArraySizeX && kernelSizeY == inputArraySizeY)
	{
		int32_t Size = kernelSizeX * kernelSizeY;

		float inputValue, kernelValue, productValue;

		float sumOfProductValues = 0.0f;

		for (int32_t i = 0; i < Size; i++)
		{
			inputValue = pInputArray[i];
			kernelValue = pKernelValueArray[i];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[0] = sumOfProductValues;

		return;
	}


	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput,iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;
	
	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = 0.0f;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] = sumOfProductValues;
			counter++;
	
		}
	}
}

inline void Calculate_FeatureMap(float *pFeatureMap, const float *pInputArray, int32_t inputArraySizeX, int32_t inputArraySizeY,
	const float *pKernelValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY, pActivationFunc pFunc)
{
	if (kernelSizeX == inputArraySizeX && kernelSizeY == inputArraySizeY)
	{
		int32_t Size = kernelSizeX * kernelSizeY;

		float inputValue, kernelValue, productValue, outputValue;

		float sumOfProductValues = 0.0f;

		for (int32_t i = 0; i < Size; i++)
		{
			inputValue = pInputArray[i];
			kernelValue = pKernelValueArray[i];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		outputValue = pFunc(sumOfProductValues);

		pFeatureMap[0] = outputValue;

		return;
	}

	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = 0.0f;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] = pFunc(sumOfProductValues);
			counter++;

		}
	}
}


inline void Calculate_FeatureMap(float *pFeatureMap, const float *pInputArray, int32_t inputArraySize, 
	const float *pKernelValueArray, int32_t kernelSize, int32_t stride)
{
	if (kernelSize == inputArraySize)
	{
		float inputValue, kernelValue, productValue;

		float sumOfProductValues = 0.0f;

		for (int32_t i = 0; i < kernelSize; i++)
		{
			inputValue = pInputArray[i];
			kernelValue = pKernelValueArray[i];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[0] = sumOfProductValues;

		return;
	}

	int32_t halfKernelSize = kernelSize / 2;
	
	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = 0.0f;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] = sumOfProductValues;
		counter++;
	}
}

inline void Calculate_FeatureMap(float *pFeatureMap, const float *pInputArray, int32_t inputArraySize,
	const float *pKernelValueArray, int32_t kernelSize, int32_t stride, pActivationFunc pFunc)
{
	if (kernelSize == inputArraySize)
	{
		float inputValue, kernelValue, productValue, outputValue;

		float sumOfProductValues = 0.0f;

		for (int32_t i = 0; i < kernelSize; i++)
		{
			inputValue = pInputArray[i];
			kernelValue = pKernelValueArray[i];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		outputValue = pFunc(sumOfProductValues);

		pFeatureMap[0] = outputValue;

		return;
	}

	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = 0.0f;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] = pFunc(sumOfProductValues);
		counter++;
	}
}



inline void Calculate_FeatureMap2(float *pFeatureMap, const float *pInputArray, int32_t inputArraySizeX, int32_t inputArraySizeY,
	const float *pKernelBiasValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY)
{
	if (kernelSizeX == inputArraySizeX && kernelSizeY == inputArraySizeY)
	{
		int32_t Size = kernelSizeX * kernelSizeY;

		float bias = pKernelBiasValueArray[Size];

		float inputValue, kernelValue, productValue;

		float sumOfProductValues = bias;
		//float sumOfProductValues = 0.0f;

		for (int32_t i = 0; i < Size; i++)
		{
			inputValue = pInputArray[i];
			kernelValue = pKernelBiasValueArray[i];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[0] = sumOfProductValues;

		return;
	}

	int32_t kernelBiasEntryID = kernelSizeX * kernelSizeY;

	float bias = pKernelBiasValueArray[kernelBiasEntryID];

	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = bias;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelBiasValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] = sumOfProductValues;
			counter++;

		}
	}
}

inline void Calculate_FeatureMap2(float *pFeatureMap, const float *pInputArray, int32_t inputArraySizeX, int32_t inputArraySizeY,
	const float *pKernelBiasValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY, pActivationFunc pFunc)
{
	if (kernelSizeX == inputArraySizeX && kernelSizeY == inputArraySizeY)
	{
		int32_t Size = kernelSizeX * kernelSizeY;

		float inputValue, kernelValue, productValue, outputValue;

		float sumOfProductValues = pKernelBiasValueArray[Size];
		
		for (int32_t i = 0; i < Size; i++)
		{
			inputValue = pInputArray[i];
			kernelValue = pKernelBiasValueArray[i];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		outputValue = pFunc(sumOfProductValues);

		pFeatureMap[0] = outputValue;

		return;
	}

	int32_t kernelBiasEntryID = kernelSizeX * kernelSizeY;

	float bias = pKernelBiasValueArray[kernelBiasEntryID];

	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = bias;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelBiasValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] = pFunc(sumOfProductValues);
			counter++;

		}
	}
}


inline void Calculate_FeatureMap2(float *pFeatureMap, const float *pInputArray, int32_t inputArraySize,
	const float *pKernelBiasValueArray, int32_t kernelSize, int32_t stride)
{
	if (kernelSize == inputArraySize)
	{
		float inputValue, kernelValue, productValue;

		float sumOfProductValues = pKernelBiasValueArray[kernelSize];

		for (int32_t i = 0; i < kernelSize; i++)
		{
			inputValue = pInputArray[i];
			kernelValue = pKernelBiasValueArray[i];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[0] = sumOfProductValues;

		return;
	}

	int32_t kernelBiasEntryID = kernelSize;

	float bias = pKernelBiasValueArray[kernelBiasEntryID];

	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = bias;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelBiasValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] = sumOfProductValues;
		counter++;
	}
}

inline void Calculate_FeatureMap2(float *pFeatureMap, const float *pInputArray, int32_t inputArraySize,
	const float *pKernelBiasValueArray, int32_t kernelSize, int32_t stride, pActivationFunc pFunc)
{
	if (kernelSize == inputArraySize)
	{
		float inputValue, kernelValue, productValue, outputValue;

		float sumOfProductValues = pKernelBiasValueArray[kernelSize];

		for (int32_t i = 0; i < kernelSize; i++)
		{
			inputValue = pInputArray[i];
			kernelValue = pKernelBiasValueArray[i];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		outputValue = pFunc(sumOfProductValues);

		pFeatureMap[0] = outputValue;

		return;
	}

	int32_t kernelBiasEntryID = kernelSize;

	float bias = pKernelBiasValueArray[kernelBiasEntryID];

	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = bias;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelBiasValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] = pFunc(sumOfProductValues);
		counter++;
	}
}


inline void Calculate_FeatureMap(float *pFeatureMap, const float *pInputArray, int32_t inputArraySizeX, int32_t inputArraySizeY,
	const float *pKernelValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY, float bias)
{
	if (kernelSizeX == inputArraySizeX && kernelSizeY == inputArraySizeY)
	{
		int32_t Size = kernelSizeX * kernelSizeY;

		float inputValue, kernelValue, productValue;

		float sumOfProductValues = bias;
		

		for (int32_t i = 0; i < Size; i++)
		{
			inputValue = pInputArray[i];
			kernelValue = pKernelValueArray[i];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[0] = sumOfProductValues;

		return;
	}

	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = bias;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] = sumOfProductValues;
			counter++;

		}
	}
}

inline void Calculate_FeatureMap(float *pFeatureMap, const float *pInputArray, int32_t inputArraySizeX, int32_t inputArraySizeY,
	const float *pKernelValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY, float bias, pActivationFunc pFunc)
{
	if (kernelSizeX == inputArraySizeX && kernelSizeY == inputArraySizeY)
	{
		int32_t Size = kernelSizeX * kernelSizeY;

		float inputValue, kernelValue, productValue, outputValue;

		float sumOfProductValues = bias;
		

		for (int32_t i = 0; i < Size; i++)
		{
			inputValue = pInputArray[i];
			kernelValue = pKernelValueArray[i];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		outputValue = pFunc(sumOfProductValues);

		pFeatureMap[0] = outputValue;

		return;
	}

	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = bias;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] = pFunc(sumOfProductValues);
			counter++;

		}
	}
}


inline void Calculate_FeatureMap(float *pFeatureMap, const float *pInputArray, int32_t inputArraySize, 
	const float *pKernelValueArray, int32_t kernelSize, int32_t stride, float bias)
{
	if (kernelSize == inputArraySize)
	{
		float inputValue, kernelValue, productValue;

		float sumOfProductValues = bias;

		for (int32_t i = 0; i < kernelSize; i++)
		{
			inputValue = pInputArray[i];
			kernelValue = pKernelValueArray[i];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[0] = sumOfProductValues;

		return;
	}

	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = bias;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] = sumOfProductValues;
		counter++;
	}
}

inline void Calculate_FeatureMap(float *pFeatureMap, const float *pInputArray, int32_t inputArraySize,
	const float *pKernelValueArray, int32_t kernelSize, int32_t stride, float bias, pActivationFunc pFunc)
{
	if (kernelSize == inputArraySize)
	{
		float inputValue, kernelValue, productValue, outputValue;

		float sumOfProductValues = bias;

		for (int32_t i = 0; i < kernelSize; i++)
		{
			inputValue = pInputArray[i];
			kernelValue = pKernelValueArray[i];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		outputValue = pFunc(sumOfProductValues);

		pFeatureMap[0] = outputValue;

		return;
	}

	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = bias;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] = pFunc(sumOfProductValues);
		counter++;
	}
}



inline void Add_Feature_To_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputArraySizeX, int32_t inputArraySizeY,
	const float *pKernelValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY)
{
	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = 0.0f;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] += sumOfProductValues;
			counter++;
		}
	}
}

inline void Add_Feature_To_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputArraySizeX, int32_t inputArraySizeY,
	const float *pKernelValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY, pActivationFunc pFunc)
{
	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = 0.0f;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] += pFunc(sumOfProductValues);
			counter++;
		}
	}
}


inline void Add_Feature_To_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputArraySize,
	const float *pKernelValueArray, int32_t kernelSize, int32_t stride)
{
	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = 0.0f;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] += sumOfProductValues;
		counter++;
	}
}

inline void Add_Feature_To_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputArraySize,
	const float *pKernelValueArray, int32_t kernelSize, int32_t stride, pActivationFunc pFunc)
{
	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = 0.0f;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] += pFunc(sumOfProductValues);
		counter++;
	}
}

inline void Add_Feature_To_FeatureMap2(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputArraySizeX, int32_t inputArraySizeY,
	const float *pKernelBiasValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY)
{
	int32_t kernelBiasEntryID = kernelSizeX * kernelSizeY;

	float bias = pKernelBiasValueArray[kernelBiasEntryID];

	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = bias;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelBiasValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] += sumOfProductValues;
			counter++;
		}
	}
}

inline void Add_Feature_To_FeatureMap2(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputArraySizeX, int32_t inputArraySizeY,
	const float *pKernelBiasValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY, pActivationFunc pFunc)
{
	int32_t kernelBiasEntryID = kernelSizeX * kernelSizeY;

	float bias = pKernelBiasValueArray[kernelBiasEntryID];

	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = bias;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelBiasValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] += pFunc(sumOfProductValues);
			counter++;
		}
	}
}


inline void Add_Feature_To_FeatureMap2(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputArraySize, 
	const float *pKernelBiasValueArray, int32_t kernelSize,  int32_t stride)
{
	int32_t kernelBiasEntryID = kernelSize;

	float bias = pKernelBiasValueArray[kernelBiasEntryID];

	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = bias;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelBiasValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] += sumOfProductValues;
		counter++;
	}
}


inline void Add_Feature_To_FeatureMap2(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputArraySize,
	const float *pKernelBiasValueArray, int32_t kernelSize, int32_t stride, pActivationFunc pFunc)
{
	int32_t kernelBiasEntryID = kernelSize;

	float bias = pKernelBiasValueArray[kernelBiasEntryID];

	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = bias;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelBiasValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] += pFunc(sumOfProductValues);
		counter++;
	}
}


inline void Add_Feature_To_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputArraySizeX, int32_t inputArraySizeY,
	const float *pKernelValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY, float bias)
{
	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = bias;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] += sumOfProductValues;
			counter++;
		}
	}
}

inline void Add_Feature_To_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputArraySizeX, int32_t inputArraySizeY,
	const float *pKernelValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY, float bias, pActivationFunc pFunc)
{
	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = bias;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] += pFunc(sumOfProductValues);
			counter++;
		}
	}
}


inline void Add_Feature_To_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputArraySize,
	const float *pKernelValueArray, int32_t kernelSize, int32_t stride, float bias)
{
	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = bias;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] += sumOfProductValues;
		counter++;
	}
}

inline void Add_Feature_To_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputArraySize,
	const float *pKernelValueArray, int32_t kernelSize, int32_t stride, float bias, pActivationFunc pFunc)
{
	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = bias;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] += pFunc(sumOfProductValues);
		counter++;
	}
}


inline void Calculate_FeatureMap(float *pFeatureMap, const float *pInputArray, int32_t inputSizeX, int32_t inputSizeY,
	int32_t paddingSizeX, int32_t paddingSizeY, const float *pKernelValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY)
{
	int32_t inputArraySizeX = inputSizeX + 2 * paddingSizeX;
	int32_t inputArraySizeY = inputSizeY + 2 * paddingSizeY;

	int32_t featureSizeX = (inputArraySizeX - kernelSizeX) / strideX;
	featureSizeX++;

	int32_t featureSizeY = (inputArraySizeY - kernelSizeY) / strideY;
	featureSizeY++;

	
	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = 0.0f;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelValueArray[ixKernel + halfKernelSizeX + iiyKernel];
					
					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] = sumOfProductValues;
			counter++;
		}
	}
}

inline void Calculate_FeatureMap(float *pFeatureMap, const float *pInputArray, int32_t inputSizeX, int32_t inputSizeY,
	int32_t paddingSizeX, int32_t paddingSizeY, const float *pKernelValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY, pActivationFunc pFunc)
{
	int32_t inputArraySizeX = inputSizeX + 2 * paddingSizeX;
	int32_t inputArraySizeY = inputSizeY + 2 * paddingSizeY;

	int32_t featureSizeX = (inputArraySizeX - kernelSizeX) / strideX;
	featureSizeX++;

	int32_t featureSizeY = (inputArraySizeY - kernelSizeY) / strideY;
	featureSizeY++;


	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = 0.0f;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] = pFunc(sumOfProductValues);
			counter++;
		}
	}
}

inline void Calculate_FeatureMap(float *pFeatureMap, const float *pInputArray, int32_t inputSize,
	int32_t paddingSize, const float *pKernelValueArray, int32_t kernelSize,  int32_t stride)
{
	int32_t inputArraySize = inputSize + 2 * paddingSize;
	
	int32_t featureSize = (inputArraySize - kernelSize) / stride;
	featureSize++;

	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = 0.0f;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] = sumOfProductValues;
		counter++;
	}
}

inline void Calculate_FeatureMap(float *pFeatureMap, const float *pInputArray, int32_t inputSize,
	int32_t paddingSize, const float *pKernelValueArray, int32_t kernelSize, int32_t stride, pActivationFunc pFunc)
{
	int32_t inputArraySize = inputSize + 2 * paddingSize;

	int32_t featureSize = (inputArraySize - kernelSize) / stride;
	featureSize++;

	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = 0.0f;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] = pFunc(sumOfProductValues);
		counter++;
	}
}


inline void Calculate_FeatureMap2(float *pFeatureMap, const float *pInputArray, int32_t inputSizeX, int32_t inputSizeY,
	int32_t paddingSizeX, int32_t paddingSizeY, const float *pKernelBiasValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY)
{
	int32_t kernelBiasEntryID = kernelSizeX * kernelSizeY;

	float bias = pKernelBiasValueArray[kernelBiasEntryID];

	int32_t inputArraySizeX = inputSizeX + 2 * paddingSizeX;
	int32_t inputArraySizeY = inputSizeY + 2 * paddingSizeY;

	int32_t featureSizeX = (inputArraySizeX - kernelSizeX) / strideX;
	featureSizeX++;

	int32_t featureSizeY = (inputArraySizeY - kernelSizeY) / strideY;
	featureSizeY++;


	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = bias;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelBiasValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] = sumOfProductValues;
			counter++;
		}
	}
}

inline void Calculate_FeatureMap2(float *pFeatureMap, const float *pInputArray, int32_t inputSizeX, int32_t inputSizeY,
	int32_t paddingSizeX, int32_t paddingSizeY, const float *pKernelBiasValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY, pActivationFunc pFunc)
{
	int32_t kernelBiasEntryID = kernelSizeX * kernelSizeY;

	float bias = pKernelBiasValueArray[kernelBiasEntryID];

	int32_t inputArraySizeX = inputSizeX + 2 * paddingSizeX;
	int32_t inputArraySizeY = inputSizeY + 2 * paddingSizeY;

	int32_t featureSizeX = (inputArraySizeX - kernelSizeX) / strideX;
	featureSizeX++;

	int32_t featureSizeY = (inputArraySizeY - kernelSizeY) / strideY;
	featureSizeY++;


	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = bias;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelBiasValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] = pFunc(sumOfProductValues);
			counter++;
		}
	}
}

inline void Calculate_FeatureMap2(float *pFeatureMap, const float *pInputArray, int32_t inputSize, 
	int32_t paddingSize,  const float *pKernelBiasValueArray, int32_t kernelSize,  int32_t stride)
{
	int32_t kernelBiasEntryID = kernelSize;

	float bias = pKernelBiasValueArray[kernelBiasEntryID];

	int32_t inputArraySize = inputSize + 2 * paddingSize;

	int32_t featureSize = (inputArraySize - kernelSize) / stride;
	featureSize++;

	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = bias;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelBiasValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] = sumOfProductValues;
		counter++;
	}
}

inline void Calculate_FeatureMap2(float *pFeatureMap, const float *pInputArray, int32_t inputSize,
	int32_t paddingSize, const float *pKernelBiasValueArray, int32_t kernelSize, int32_t stride, pActivationFunc pFunc)
{
	int32_t kernelBiasEntryID = kernelSize;

	float bias = pKernelBiasValueArray[kernelBiasEntryID];

	int32_t inputArraySize = inputSize + 2 * paddingSize;

	int32_t featureSize = (inputArraySize - kernelSize) / stride;
	featureSize++;

	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = bias;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelBiasValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] = pFunc(sumOfProductValues);
		counter++;
	}
}

inline void Calculate_FeatureMap(float *pFeatureMap, const float *pInputArray, int32_t inputSizeX, int32_t inputSizeY,
	int32_t paddingSizeX, int32_t paddingSizeY, const float *pKernelValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY, float bias)
{
	int32_t inputArraySizeX = inputSizeX + 2 * paddingSizeX;
	int32_t inputArraySizeY = inputSizeY + 2 * paddingSizeY;

	int32_t featureSizeX = (inputArraySizeX - kernelSizeX) / strideX;
	featureSizeX++;

	int32_t featureSizeY = (inputArraySizeY - kernelSizeY) / strideY;
	featureSizeY++;


	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = bias;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] = sumOfProductValues;
			counter++;
		}
	}
}

inline void Calculate_FeatureMap(float *pFeatureMap, const float *pInputArray, int32_t inputSizeX, int32_t inputSizeY,
	int32_t paddingSizeX, int32_t paddingSizeY, const float *pKernelValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY, float bias, pActivationFunc pFunc)
{
	int32_t inputArraySizeX = inputSizeX + 2 * paddingSizeX;
	int32_t inputArraySizeY = inputSizeY + 2 * paddingSizeY;

	int32_t featureSizeX = (inputArraySizeX - kernelSizeX) / strideX;
	featureSizeX++;

	int32_t featureSizeY = (inputArraySizeY - kernelSizeY) / strideY;
	featureSizeY++;


	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = bias;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] = pFunc(sumOfProductValues);
			counter++;
		}
	}
}


inline void Calculate_FeatureMap(float *pFeatureMap, const float *pInputArray, int32_t inputSize,
	int32_t paddingSize, const float *pKernelValueArray, int32_t kernelSize, int32_t stride, float bias)
{
	int32_t inputArraySize = inputSize + 2 * paddingSize;

	int32_t featureSize = (inputArraySize - kernelSize) / stride;
	featureSize++;

	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = bias;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] = sumOfProductValues;
		counter++;
	}
}

inline void Calculate_FeatureMap(float *pFeatureMap, const float *pInputArray, int32_t inputSize,
	int32_t paddingSize, const float *pKernelValueArray, int32_t kernelSize, int32_t stride, float bias, pActivationFunc pFunc)
{
	int32_t inputArraySize = inputSize + 2 * paddingSize;

	int32_t featureSize = (inputArraySize - kernelSize) / stride;
	featureSize++;

	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = bias;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] = pFunc(sumOfProductValues);
		counter++;
	}
}


inline void Add_Feature_To_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputSizeX, int32_t inputSizeY,
	int32_t paddingSizeX, int32_t paddingSizeY, const float *pKernelValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY)
{
	int32_t inputArraySizeX = inputSizeX + 2 * paddingSizeX;
	int32_t inputArraySizeY = inputSizeY + 2 * paddingSizeY;

	int32_t featureSizeX = (inputArraySizeX - kernelSizeX) / strideX;
	featureSizeX++;

	int32_t featureSizeY = (inputArraySizeY - kernelSizeY) / strideY;
	featureSizeY++;


	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = 0.0f;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] += sumOfProductValues;
			counter++;
		}
	}
}

inline void Add_Feature_To_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputSizeX, int32_t inputSizeY,
	int32_t paddingSizeX, int32_t paddingSizeY, const float *pKernelValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY, pActivationFunc pFunc)
{
	int32_t inputArraySizeX = inputSizeX + 2 * paddingSizeX;
	int32_t inputArraySizeY = inputSizeY + 2 * paddingSizeY;

	int32_t featureSizeX = (inputArraySizeX - kernelSizeX) / strideX;
	featureSizeX++;

	int32_t featureSizeY = (inputArraySizeY - kernelSizeY) / strideY;
	featureSizeY++;


	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = 0.0f;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] += pFunc(sumOfProductValues);
			counter++;
		}
	}
}


inline void Add_Feature_To_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputSize,
	int32_t paddingSize, const float *pKernelValueArray, int32_t kernelSize, int32_t stride)
{
	int32_t inputArraySize = inputSize + 2 * paddingSize;

	int32_t featureSize = (inputArraySize - kernelSize) / stride;
	featureSize++;

	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = 0.0f;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] += sumOfProductValues;
		counter++;
	}

}

inline void Add_Feature_To_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputSize,
	int32_t paddingSize, const float *pKernelValueArray, int32_t kernelSize, int32_t stride, pActivationFunc pFunc)
{
	int32_t inputArraySize = inputSize + 2 * paddingSize;

	int32_t featureSize = (inputArraySize - kernelSize) / stride;
	featureSize++;

	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = 0.0f;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] += pFunc(sumOfProductValues);
		counter++;
	}

}


inline void Add_Feature_To_FeatureMap2(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputSizeX, int32_t inputSizeY,
	int32_t paddingSizeX, int32_t paddingSizeY, const float *pKernelBiasValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY)
{
	int32_t kernelBiasEntryID = kernelSizeX * kernelSizeY;

	float bias = pKernelBiasValueArray[kernelBiasEntryID];

	int32_t inputArraySizeX = inputSizeX + 2 * paddingSizeX;
	int32_t inputArraySizeY = inputSizeY + 2 * paddingSizeY;

	int32_t featureSizeX = (inputArraySizeX - kernelSizeX) / strideX;
	featureSizeX++;

	int32_t featureSizeY = (inputArraySizeY - kernelSizeY) / strideY;
	featureSizeY++;


	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = bias;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelBiasValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] += sumOfProductValues;
			counter++;
		}
	}
}

inline void Add_Feature_To_FeatureMap2(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputSizeX, int32_t inputSizeY,
	int32_t paddingSizeX, int32_t paddingSizeY, const float *pKernelBiasValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY, pActivationFunc pFunc)
{
	int32_t kernelBiasEntryID = kernelSizeX * kernelSizeY;

	float bias = pKernelBiasValueArray[kernelBiasEntryID];

	int32_t inputArraySizeX = inputSizeX + 2 * paddingSizeX;
	int32_t inputArraySizeY = inputSizeY + 2 * paddingSizeY;

	int32_t featureSizeX = (inputArraySizeX - kernelSizeX) / strideX;
	featureSizeX++;

	int32_t featureSizeY = (inputArraySizeY - kernelSizeY) / strideY;
	featureSizeY++;


	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = bias;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelBiasValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] += pFunc(sumOfProductValues);
			counter++;
		}
	}
}


inline void Add_Feature_To_FeatureMap2(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputSize,
	int32_t paddingSize, const float *pKernelBiasValueArray, int32_t kernelSize, int32_t stride)
{
	int32_t kernelBiasEntryID = kernelSize;

	float bias = pKernelBiasValueArray[kernelBiasEntryID];

	int32_t inputArraySize = inputSize + 2 * paddingSize;

	int32_t featureSize = (inputArraySize - kernelSize) / stride;
	featureSize++;

	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = bias;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelBiasValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] += sumOfProductValues;
		counter++;
	}
}

inline void Add_Feature_To_FeatureMap2(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputSize,
	int32_t paddingSize, const float *pKernelBiasValueArray, int32_t kernelSize, int32_t stride, pActivationFunc pFunc)
{
	int32_t kernelBiasEntryID = kernelSize;

	float bias = pKernelBiasValueArray[kernelBiasEntryID];

	int32_t inputArraySize = inputSize + 2 * paddingSize;

	int32_t featureSize = (inputArraySize - kernelSize) / stride;
	featureSize++;

	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = bias;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelBiasValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] += pFunc(sumOfProductValues);
		counter++;
	}
}


inline void Add_Feature_To_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputSizeX, int32_t inputSizeY,
	int32_t paddingSizeX, int32_t paddingSizeY, const float *pKernelValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY, float bias)
{
	int32_t inputArraySizeX = inputSizeX + 2 * paddingSizeX;
	int32_t inputArraySizeY = inputSizeY + 2 * paddingSizeY;

	int32_t featureSizeX = (inputArraySizeX - kernelSizeX) / strideX;
	featureSizeX++;

	int32_t featureSizeY = (inputArraySizeY - kernelSizeY) / strideY;
	featureSizeY++;


	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = bias;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] += sumOfProductValues;
			counter++;
		}
	}
}

inline void Add_Feature_To_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputSizeX, int32_t inputSizeY,
	int32_t paddingSizeX, int32_t paddingSizeY, const float *pKernelValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY, float bias, pActivationFunc pFunc)
{
	int32_t inputArraySizeX = inputSizeX + 2 * paddingSizeX;
	int32_t inputArraySizeY = inputSizeY + 2 * paddingSizeY;

	int32_t featureSizeX = (inputArraySizeX - kernelSizeX) / strideX;
	featureSizeX++;

	int32_t featureSizeY = (inputArraySizeY - kernelSizeY) / strideY;
	featureSizeY++;


	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = bias;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] += pFunc(sumOfProductValues);
			counter++;
		}
	}
}




inline void Add_Feature_To_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputSize, 
	int32_t paddingSize, const float *pKernelValueArray, int32_t kernelSize, int32_t stride, float bias)
{
	int32_t inputArraySize = inputSize + 2 * paddingSize;

	int32_t featureSize = (inputArraySize - kernelSize) / stride;
	featureSize++;

	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = bias;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] += sumOfProductValues;
		counter++;
	}
}

inline void Add_Feature_To_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputSize,
	int32_t paddingSize, const float *pKernelValueArray, int32_t kernelSize, int32_t stride, float bias, pActivationFunc pFunc)
{
	int32_t inputArraySize = inputSize + 2 * paddingSize;

	int32_t featureSize = (inputArraySize - kernelSize) / stride;
	featureSize++;

	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = bias;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] += pFunc(sumOfProductValues);
		counter++;
	}
}

////////////////////////////////


inline void Add_Bias(float* pOutputData, const float* pInputData, /*numArrayElements:*/ uint32_t arraySize, float bias)
{
	for (uint32_t i = 0; i < arraySize; i++)
		pOutputData[i] = pInputData[i] + bias;
}

inline void Add_Bias(float* pInputOutputData, /*numArrayElements:*/ uint32_t arraySize, float bias)
{
	for (uint32_t i = 0; i < arraySize; i++)
		pInputOutputData[i] = pInputOutputData[i] + bias;
}

inline void Add_Bias(float* pOutputData, const float* pInputData, uint32_t arraySizeX, uint32_t arraySizeY, float bias)
{
	uint32_t numArrayElements = arraySizeX * arraySizeY;

	for (uint32_t i = 0; i < numArrayElements; i++)
		pOutputData[i] = pInputData[i] + bias;
}

inline void Add_Bias(float* pInputOutputData, uint32_t arraySizeX, uint32_t arraySizeY, float bias)
{
	uint32_t numArrayElements = arraySizeX * arraySizeY;

	for (uint32_t i = 0; i < numArrayElements; i++)
		pInputOutputData[i] = pInputOutputData[i] + bias;
}



inline void Modify_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, /*numArrayElements:*/ uint32_t arraySize, pActivationFunc pFunc)
{
	for (uint32_t i = 0; i < arraySize; i++)
		pFeatureMap[i] = pFunc(pFeatureMap[i]);
}

inline void Modify_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, /*numArrayElements:*/ uint32_t arraySize, pActivationFunc pFunc, float bias)
{
	for (uint32_t i = 0; i < arraySize; i++)
		pFeatureMap[i] = pFunc(pFeatureMap[i] + bias);
}

inline void Modify_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, uint32_t arraySizeX, uint32_t arraySizeY, pActivationFunc pFunc)
{
	uint32_t numArrayElements = arraySizeX * arraySizeY;

	for (uint32_t i = 0; i < numArrayElements; i++)
		pFeatureMap[i] = pFunc(pFeatureMap[i]);
}

inline void Modify_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, uint32_t arraySizeX, uint32_t arraySizeY, pActivationFunc pFunc, float bias)
{
	uint32_t numArrayElements = arraySizeX * arraySizeY;

	for (uint32_t i = 0; i < numArrayElements; i++)
		pFeatureMap[i] = pFunc(pFeatureMap[i] + bias);
}

inline void Modify_FeatureMap(float *pOutputFeatureMap, const float *pInputFeatureMap, /*numArrayElements:*/ uint32_t arraySize, pActivationFunc pFunc)
{
	for (uint32_t i = 0; i < arraySize; i++)
		pOutputFeatureMap[i] = pFunc(pInputFeatureMap[i]);
}

inline void Modify_FeatureMap(float *pOutputFeatureMap, const float *pInputFeatureMap, /*numArrayElements:*/ uint32_t arraySize, pActivationFunc pFunc, float bias)
{
	for (uint32_t i = 0; i < arraySize; i++)
		pOutputFeatureMap[i] = pFunc(pInputFeatureMap[i] + bias);
}

inline void Modify_FeatureMap(float *pOutputFeatureMap, const float *pInputFeatureMap, uint32_t arraySizeX, uint32_t arraySizeY, pActivationFunc pFunc)
{
	uint32_t numArrayElements = arraySizeX * arraySizeY;

	for (uint32_t i = 0; i < numArrayElements; i++)
		pOutputFeatureMap[i] = pFunc(pInputFeatureMap[i]);
}

inline void Modify_FeatureMap(float *pOutputFeatureMap, const float *pInputFeatureMap, uint32_t arraySizeX, uint32_t arraySizeY, pActivationFunc pFunc, float bias)
{
	uint32_t numArrayElements = arraySizeX * arraySizeY;

	for (uint32_t i = 0; i < numArrayElements; i++)
		pOutputFeatureMap[i] = pFunc(pInputFeatureMap[i] + bias);
}









class CImageDataF
{
public:

	uint32_t SizeXDir;
	uint32_t SizeYDir;
	uint32_t Size;  // SizeXDir * SizeYDir

	float *pValueArray = nullptr;

	CImageDataF();
	~CImageDataF();

	// Kopierkonstruktor l�schen:
	CImageDataF(const CImageDataF &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CImageDataF& operator=(const CImageDataF &originalObject) = delete;

	void Initialize(uint32_t sizeXDir, uint32_t sizeYDir);
	void Clear(float value = 0.0f);

	// old resolution => new resolution
	// 32x32 => 16x16
	// 30x30 => 15x15
	// 15x15 => 8x8
	void Bisect_Resolution(float *pOutputArray);

	void MaxPoolingPooling2x2(float *pOutputArray);
	void L2Pooling2x2(float *pOutputArray);
};

class C1DimDataF
{
public:

	uint32_t Size; 

	float *pValueArray = nullptr;

	C1DimDataF();
	~C1DimDataF();

	// Kopierkonstruktor l�schen:
	C1DimDataF(const C1DimDataF &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	C1DimDataF& operator=(const C1DimDataF &originalObject) = delete;

	void Initialize(uint32_t size);
	void Clear(float value = 0.0f);
	void Bisect_Resolution(float *pOutputArray);
	void MaxPoolingPooling2x1(float *pOutputArray);
	void L2Pooling2x1(float *pOutputArray);
};



class C3DPathNeuron
{
public:

	int32_t NeuronID = -1;

	C3DPathNeuron *pUsedNeuronArray = nullptr;

	float PosX = 0.0f;
	float PosY = 0.0f;
	float PosZ = 0.0f;

	int32_t NumConnections = 0;

	// Hinweis: pConnectionWeightArray[i] == 0.0f => related path is impassable
	double *pConnectionWeightArray = nullptr;
	double *pSynapsePlasticityArray = nullptr;
	double *pDistanceFactorArray = nullptr;
	int32_t *pReceiverNeuronIDArray = nullptr;

	int32_t ReceiverSynapseID = -1;
	int32_t ReceiverNeuronID = -1;

	double Activity = 0.0;

	C3DPathNeuron();
	~C3DPathNeuron();

	// Kopierkonstruktor l�schen: 
	C3DPathNeuron(const C3DPathNeuron &originalObject) = delete;

	// �berladenen Zuweisungsoperator l�schen: 
	C3DPathNeuron operator=(const C3DPathNeuron &originalObject) = delete;

	void Clone_Neuron(C3DPathNeuron *pOriginalNeuron);
	void Combine_Neurons(C3DPathNeuron *pParentNeuron1, C3DPathNeuron *pParentNeuron2);
	void Combine_Neurons(C3DPathNeuron *pParentNeuron1, double weight1, C3DPathNeuron *pParentNeuron2, double weight2);

	void Connect_With_Brain(C3DPathNeuron* pNeuronArray);

	void Init_FullyConnectedNeuron(int32_t neuronID, int32_t numNeurons);
	void Init_Neuron(int32_t neuronID, int32_t numConnections);

	void Set_Position(float x, float y, float z);

	void Reset_Activity(void);
	void Set_Activity(float value);

	void Reset_PlasticityValues(void);
	void Update_PlasticityValues(double modificationValue, double learningRate);
	void Update_PlasticityValues_PreferShorterConnections(double modificationValue, double learningRate);
	void Reduce_PlasticityValues(double decreaseValue, double minPlasticityValue = 0.0);

	void Propagate_Signal(int32_t receiverNeuronID);
	int32_t Propagate_Signal_To_NonActivatedNeuron(CRandomNumbersNN *pRandomNumbers);
	int32_t Propagate_Signal(CRandomNumbersNN *pRandomNumbers);
	int32_t Propagate_Signal_Randomly(CRandomNumbersNN *pRandomNumbers);
	int32_t Select_Connected_Neuron_Randomly(CRandomNumbersNN *pRandomNumbers);

	int32_t Get_ID_Of_Strongest_ConnectedNeuron(void);

	// methods 1: 1/Distance; 2: 1/(Distance*Distance); 3: exp(-param1*Distance*Distance)
	void Calculate_ConnectionDistanceFactors(int32_t method, float param1);
	

	void Connect_With_ReceiverNeuron(int32_t neuronID, int32_t synapseID);
	void Connect_With_ReceiverNeurons(int32_t *pNeuronIDArray);

	void Set_ConnectionWeight(float weight, int32_t synapseID);
};

class C3DNeuralMap
{
public:

	int32_t NumNeurons = 0;

	C3DPathNeuron *pNeuronArray = nullptr;

	CRandomNumbersNN RandomNumbers;

	float MinPathDistance = 100000000.0f;

	double MinNonZeroPlasticityValue = 0.0f;
	double MaxPlasticityValue = 0.0f;

	int32_t *pTemp_TSP_Path = nullptr;

	C3DNeuralMap();
	~C3DNeuralMap();

	// Kopierkonstruktor l�schen: 
	C3DNeuralMap(const C3DNeuralMap &originalObject) = delete;

	// �berladenen Zuweisungsoperator l�schen: 
	C3DNeuralMap operator=(const C3DNeuralMap &originalObject) = delete;


	void Initialize_FullyConnected_NeuralNet(int32_t numNeurons);

	// Es werden noch keine neuronalen Verbindungen gekn�pft:
	void Initialize_NeuralNet(int32_t numNeurons);

	void Init_Neuron(int32_t neuronID, int32_t numConnections);

	void Reset_MinPathDistance(void);

	void Prepare_Training(void);

	void Set_Position(int32_t neuronID, float x, float y, float z);

	// methods 1: 1/Distance; 2: 1/(Distance*Distance); 3: exp(-param1*Distance*Distance)
	void Calculate_ConnectionDistanceFactors(int32_t method, float param1 = 1.0f);

	float Get_Distance(int32_t neuronID1, int32_t neuronID2);

	// TSP: Travelling Salesman Problem
	bool Check_TSP_Path_Legality(int32_t *pPathArray);
	

	float Get_Path_Length(int32_t *pPathArray, int32_t numPathElements);

	// TSP: Travelling Salesman Problem
	float Get_TSP_Path_Length(int32_t *pPathArray);

	//  TSP: Travelling Salesman Problem- Legality is not guaranteed!
	void Get_TSP_Path(int32_t *pOutPathArray, int32_t iDofFirstAndLastNeuron);
	// TSP: Travelling Salesman Problem
	void Init_Possible_TSP_Path(int32_t *pOutPathArray);
	// TSP: Travelling Salesman Problem
	void Init_Possible_TSP_Path(int32_t *pOutPathArray, int32_t iDofFirstAndLastNeuron);

	// TSP: Travelling Salesman Problem
	void Rearrange_TSP_Path(int32_t *pOutPathArray, int32_t *pInPathArray, int32_t iDofFirstAndLastNeuron);


	void Get_Path(int32_t *pOutPathArray, int32_t *pOutNumPathElements, int32_t numPathElementsMax, int32_t iDofFirstNeuron, int32_t iDofLastNeuron);

	// Ausgabe des neuronalen Pfades mit den st�rksten synaptischen Plastizit�ten (step by step):
	int32_t Get_ID_Of_Strongest_ConnectedNeuron(int32_t lastNeuronID);

	void Connect_With_ReceiverNeuron(int32_t neuronID, int32_t receiverNeuronID, int32_t synapseID);

	// Hinweis: ConnectionWeight == 0.0f => related path is impassable
	void Set_ConnectionWeight(int32_t neuronID, float weight, int32_t synapseID);

	// Hinweis: ConnectionWeight == 0.0f => related path is impassable
	void Set_ConnectionWeight(int32_t neuronID, int32_t receiverNeuronID, float weight);

	void Random_PathFinding(int32_t *pOutPathArray, int32_t *pOutNumPathElements, int32_t IDofFirstNeuron, int32_t IDofLastNeuron);

	void Train_NeuralNet_PathFinding(int32_t IDofFirstNeuron, int32_t IDofLastNeuron, float initialActivity, float learningRate, float plasticityReductionFactor, bool preferShorterConnections);
	void Init_NeuralNet_PathFinding_Training(int32_t *pInPathArray, int32_t IDofFirstNeuron, int32_t IDofLastNeuron, float initialActivity, float learningRate, float plasticityReductionFactor, bool preferShorterConnections);

	// TSP: Travelling Salesman Problem
	void Train_NeuralNet_TSP(int32_t IDofFirstAndLastNeuron, float initialActivity, float learningRate, float plasticityReductionFactor, bool preferShorterConnections);
	void Init_NeuralNet_TSP_Training(int32_t *pInPathArray, int32_t IDofFirstAndLastNeuron, float initialActivity, float learningRate, float plasticityReductionFactor, bool preferShorterConnections);

	float Find_MinNonZeroPlasticityValue(void);
	float Find_MaxPlasticityValue(void);

	void Reduce_PlasticityValues(float decreaseValue, float minPlasticityValue = 0.0f);

	void Clone_NeuralMap(C3DNeuralMap *pOriginaleMap);
	void Combine_NeuralMaps(C3DNeuralMap *pParentMap1, C3DNeuralMap *pParentMap2);
	void Combine_NeuralMaps(C3DNeuralMap *pParentMap1, double weight1, C3DNeuralMap *pParentMap2, double weight2);

	// TSP: Travelling Salesman Problem
	bool Mutate_TSP_Path(int32_t *pOutPathArray, int32_t *pInPathArray);
	// TSP: Travelling Salesman Problem
	void Mutate_TSP_Path(int32_t *pInOutPathArray);

	// TSP: Travelling Salesman Problem (erste und letzte Stadt muss die id=0 besitzen)
	void Combine_Two_TSP_Paths(int32_t *pOutPathArray, int32_t *pInPathArray1, int32_t *pInPathArray2);

	// TSP: Travelling Salesman Problem
	void Init_And_Mutate_TSP_Path(int32_t *pOutPathArray, int32_t *pTempPathArray1, int32_t *pTempPathArray2, int32_t iDofFirstAndLastNeuron, int32_t numIterations);
	
	
};




class CNeuron
{
public:

	CNeuron *pUsedNeuronArray = nullptr;

	bool UsedAsInputNeuron = true;
	bool UsedAsHiddenNeuron = false;
	bool UsedAsOutputNeuron = false;
	bool UsedAsBiasNeuron = false;
	bool UsedAsMemoryNeuron = false;
	bool UsedAsRBFNeuron = false;

	float NeuronInput = 0.0f;
	float NeuronOutput = 0.0f;
	float NeuronOutput_LastCalculationStep = 0.0f;

	float ErrorValue = 0.0f;
	float ErrorFactor1 = 1.0f;
	float ErrorFactor2 = 1.0f;
	// Hinweis: Bei linearen Aktivierungsfunktionen sollte ErrorFactor2 kleiner als 1.0f sein (z. B. 0.5f oder 0.25f) 

	float LearningRate = 0.2f;

	pActivationFunc pActivationFunction = nullptr;
	pErrorFunc pUserDefErrorFunction = nullptr;

	//uint32_t NumOfOutputSynapsesMax = 0;
	uint32_t NumOfOutputSynapses = 0;

	uint32_t *pReceiverNeuronIDArray = nullptr;

	bool *pOutputSynapseActivityStatusArray = nullptr;

	// auch bekannt als OutputWeightArray: 
	float *pOutputSynapsePlasticityArray = nullptr;

	// f�r bin�ren Output:
	float *pOutputSynapseMinBlockingValueArray = nullptr;
	float *pOutputSynapseMaxBlockingValueArray = nullptr;
	
	bool Dropout = false;

	uint32_t NumOfRBFCentroidValues = 0;
	float *pRBFCentroidValueArray = nullptr;
	float RBFCentroidDistanceSqSum = 0.0f;
	float RBF_Factor = 1.0f;

	uint32_t RBFInputCounter = 0;

	CNeuron();
	~CNeuron();

	// Kopierkonstruktor l�schen: 
	CNeuron(const CNeuron &originalObject) = delete;

	// �berladenen Zuweisungsoperator l�schen: 
	CNeuron operator=(const CNeuron &originalObject) = delete;

	void Init_RBFCentroid(uint32_t numOfRBFCentroidValues);
	void Set_RBFCentroidValues(float rBF_Factor, float *pValueArray);

	void Set_DropoutState(bool state);

	void Round_OutputWeights(float precision, float invPrecision);
	void Remove_Unused_Connections(void);

	void Clone(const CNeuron &originalObject);
	void Clone_Data(const CNeuron &originalObject);

	void Init_OutputSynapses(uint32_t numOfOutputSynapses);

	void Disable_Random_OutputSynapses(CRandomNumbersNN *pRandomNumbers, float probabilityValue);
	void Enable_Disabled_OutputSynapses(CRandomNumbersNN *pRandomNumbers, float minPlasticityValue, float maxPlasticityValue);
	void Enable_Disabled_OutputSynapses(CRandomNumbersNN *pRandomNumbers, float minPlasticityValue, float maxPlasticityValue, float probabilityValue);

	void Randomize_OutputSynapsePlasticities(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue);
	void Randomize_OutputSynapsePlasticities(CRandomNumbersNN *pRandomNumbers, float *pRandomValueArray, uint32_t numArrayElements);

	void Add_Randomized_OutputSynapsePlasticities(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float weight1, float weight2);
	void Add_Randomized_OutputSynapsePlasticities(CRandomNumbersNN *pRandomNumbers, float *pRandomValueArray, uint32_t numArrayElements, float weight1, float weight2);
	
	void Clone_OutputSynapsePlasticities(const CNeuron &originalObject);
	void Clone_OutputSynapsePlasticities(const CNeuron &originalObject, CRandomNumbersNN *pRandomNumbers, float variance);
	void Clone_OutputSynapsePlasticities(const CNeuron &originalObject, CRandomNumbersNN *pRandomNumbers, float minVariance, float maxVariance);
	void Combine_OutputSynapsePlasticities(CNeuron *pParentNeuron1, CNeuron *pParentNeuron2, CRandomNumbersNN *pRandomNumbers, float minWeight1);
	void Combine_OutputSynapsePlasticities(CNeuron *pParentNeuron1, CNeuron *pParentNeuron2, CRandomNumbersNN *pRandomNumbers);

	void Modify_OutputSynapsePlasticities(float multiplier);

	void Connect_With_Brain(CNeuron *pNeuronArray);
	void Connect_With_ReceiverNeuron(uint32_t neuronID, uint32_t synapseID);
	void Connect_With_ReceiverNeurons(uint32_t *pNeuronIDArray);

	void Use_As_InputNeuron(void);
	void Use_As_HiddenNeuron(void);
	void Use_As_OutputNeuron(void);
	void Use_As_BiasNeuron(void);
	void Use_As_MemoryNeuron(void);
	void Use_As_RBFNeuron(void);

	void Set_OutputSynapsePlasticity(float value, uint32_t synapseID);
	void Set_OutputSynapseBlockingValue(float minValue, float maxValue, uint32_t synapseID);
	void Set_LearningRate(float learningRate);
	void Set_ActivationFunction(pActivationFunc pFunc);
	void Set_UserDefErrorFunction(pErrorFunc pFunc);

	// Hinweis: Bei linearen Aktivierungsfunktionen sollte ErrorFactor2 kleiner als 1.0f sein (z. B. 0.5f, 0.25f, 0.01f) 
	void Set_ErrorFactors(float factor1, float factor2);
	
	// Funktioniert nur bei Input-Neuronen (Inputwert wird in der Variable NeuronOutput gespeichert): 
	void Set_Input(float value);
	void Add_Input(float value);

	void Reset_NeuronInput(void);
	float Get_NeuronInput(void);
	void Set_NeuronInput(float value);
	void Add_NeuronInput(float value);

	void Calculate_NeuronOutput(void);
	void Calculate_NeuronOutput(pActivationFunc pFunc);

	void Calculate_NeuronOutput_And_Retain_Input(void);
	void Calculate_NeuronOutput_And_Retain_Input(pActivationFunc pFunc);

	void Calculate_NeuronOutput(float inputDecrease, float minInputValue);
	void Calculate_NeuronOutput(pActivationFunc pFunc, float inputDecrease, float minInputValue);

	/* if (NeuronOutput < minOutputValue) => NeuronInput wird nicht ge�ndert */
	void Accumulate_NeuronInput_And_Calculate_NeuronOutput(float minOutputValue);
	/* if (NeuronOutput < minOutputValue) => NeuronInput wird nicht ge�ndert */
	void Accumulate_NeuronInput_And_Calculate_NeuronOutput(pActivationFunc pFunc, float minOutputValue);

	/* if (NeuronOutput < minOutputValue) oder if (NeuronOutput > maxOutputValue) => NeuronInput wird nicht ge�ndert */
	void Accumulate_NeuronInput_And_Calculate_NeuronOutput(float minOutputValue, float maxOutputValue);
	/* if (NeuronOutput < minOutputValue) oder if (NeuronOutput > maxOutputValue) => NeuronInput wird nicht ge�ndert */
	void Accumulate_NeuronInput_And_Calculate_NeuronOutput(pActivationFunc pFunc, float minOutputValue, float maxOutputValue);

	/* if (NeuronOutput < minOutputValue) => NeuronInput wird nicht ge�ndert */
	void Accumulate_NeuronInput_And_Calculate_NeuronOutput(float minOutputValue, float inputDecrease, float minInputValue);
	/* if (NeuronOutput < minOutputValue) => NeuronInput wird nicht ge�ndert */
	void Accumulate_NeuronInput_And_Calculate_NeuronOutput(pActivationFunc pFunc, float minOutputValue, float inputDecrease, float minInputValue);

	/* if (NeuronOutput < minOutputValue) oder if (NeuronOutput > maxOutputValue) => NeuronInput wird nicht ge�ndert */
	void Accumulate_NeuronInput_And_Calculate_NeuronOutput(float minOutputValue, float maxOutputValue, float inputDecrease, float minInputValue);
	/* if (NeuronOutput < minOutputValue) oder if (NeuronOutput > maxOutputValue) => NeuronInput wird nicht ge�ndert */
	void Accumulate_NeuronInput_And_Calculate_NeuronOutput(pActivationFunc pFunc, float minOutputValue, float maxOutputValue, float inputDecrease, float minInputValue);

	void Reset_NeuronOutput(void);

	// Weiterleitung des Signals an s�mtliche Receiver-Neuronen (nachgeschaltete Neuronen):
	void Propagate_SynapticOutput(void);
	void Propagate_MaximumSynapticOutput(void);
	void Propagate_MinimumSynapticOutput(void);
	void Propagate_MaximumAbsolutSynapticOutput(void);
	void Propagate_BinaryValue(void);

	void Propagate_SynapticOutput(uint32_t synapseID);
	void Propagate_MaximumSynapticOutput(uint32_t synapseID);
	void Propagate_MinimumSynapticOutput(uint32_t synapseID);
	void Propagate_MaximumAbsolutSynapticOutput(uint32_t synapseID);
	void Propagate_BinaryValue(uint32_t synapseID);

	void Update_NeuronInput(float value);

	float Get_NeuronOutput(void);
	void Set_NeuronOutput(float value);
	void Set_BiasNeuronOutput(float value);

	void Set_Error(float value);
	float Calculate_Error(float desiredNeuronOutput);
	float Calculate_Error_WithUserDefFunction(float desiredNeuronOutput);

	/* Fehlerberechnung (Input-Neuronen sind ausgenommen) unter Ber�cksichtigung der bereits berechneten Fehler von
	s�mtlichen Receiver-Neuronen (nachgeschalteten Neuronen): */
	void Calculate_Error(void);
	void Calculate_Error_WithUserDefFunction(void);

	/* Fehlerberechnung (Input-Neuronen sind ausgenommen) unter Ber�cksichtigung der bereits berechneten Fehler von
	s�mtlichen Receiver-Neuronen (nachgeschalteten Neuronen): */
	void Calculate_Error(float *pInErrorValueArray, float errorFactor1, float errorFactor2);

	void Calculate_InputNeuronError(void);
	void Calculate_InputNeuronError_WithUserDefFunction(void);

	// Anpassung der Synapsen-Pastizit�t unter Ber�cksichtigung der zuvor berechneten Fehlerwerte:
	void Adjust_OutputSynapses_AfterErrorCalculations(void);
	void Adjust_OutputSynapses_AfterErrorCalculationsExt(void);

	void Adjust_OutputSynapse_AfterErrorCalculations(uint32_t synapseID);
	void Adjust_OutputSynapse_AfterErrorCalculationsExt(uint32_t synapseID);

	void Adjust_OutputSynapse_AfterErrorCalculations2(uint32_t receiverNeuronID);
	void Adjust_OutputSynapse_AfterErrorCalculationsExt2(uint32_t synapseID);

	bool Save_OutputSynapsePlasticities(const char* pFilename);
	bool Load_OutputSynapsePlasticities(const char* pFilename);

	bool Save_ReceiverNeuronIDs_And_OutputSynapsePlasticities(const char* pFilename);
	bool Load_ReceiverNeuronIDs_And_OutputSynapsePlasticities(const char* pFilename);

	bool Save_ReceiverNeuronIDs_And_OutputSynapsePlasticities_Ext(const char* pFilename);
	bool Load_ReceiverNeuronIDs_And_OutputSynapsePlasticities_Ext(const char* pFilename);

	bool Save_RBFCentroidValues(const char* pFilename);
	bool Load_RBFCentroidValues(const char* pFilename);

	void Reset_ActivationFunction(void);
};

class CLongTermMemoryNeuron
{
public:

	CNeuron *pUsedNeuronArray = nullptr;

	uint32_t NumOfMemorySynapses = 0;
	uint32_t NumOfMemorySynapsesPlus1 = 0;

	float *pSynapsePlasticityArray = nullptr;
	

	float Activity = 0.0f;

	float Counter = 0.0f;
	float InvCounter = 1.0f;

	CLongTermMemoryNeuron();
	~CLongTermMemoryNeuron();
	
	// Kopierkonstruktor l�schen: 
	CLongTermMemoryNeuron(const CLongTermMemoryNeuron &originalObject) = delete;

	// �berladenen Zuweisungsoperator l�schen: 
	CLongTermMemoryNeuron operator=(const CLongTermMemoryNeuron &originalObject) = delete;

	void Init_Neuron(uint32_t numOfMemorySynapses);

	void Connect_With_Brain(CNeuron* pNeuronArray);

	void Reset_Memory(void);

	void Add_MemoryValue(int32_t synapseID, float value);
	void Set_MemoryValue(int32_t synapseID, float value);
	float Get_MemoryValue(int32_t synapseID);

	void Update_Memory(int32_t synapseID, int32_t inputNeuronID, float learningRate = 1.0f);

	void Propagate_Memory(int32_t synapseID, int32_t receiverNeuronID);
	                                   
	void Transfer_Plasticity_To_DestinationNeuron(int32_t synapseID, int32_t destinationNeuronID, int32_t destinationNeuronSynapseID, float plasticityMultiplier);
	void Transfer_Plasticity_To_DestinationNeuron(int32_t synapseID, int32_t destinationNeuronID, int32_t destinationNeuronSynapseID);


	void Reset_Activity(void);
	void Set_Activity(float value);

	void Reduce_PlasticityValues(float decreaseValue, float minPlasticityValue);

};





class C2State2DCellularAutomatonRules
{
public:

	int32_t NumBirthRules = 0;
	int32_t BirthRuleArray[8];

	int32_t NumSurvivingRules = 0;
	int32_t SurvivingRuleArray[8];

	C2State2DCellularAutomatonRules();
	void Reset(void);
};


class C2DCellularAutomata
{
public:

	int32_t NumCellsXDir;
	int32_t NumCellsYDir;

	int32_t NumCellsXDirMinus1;
	int32_t NumCellsYDirMinus1;

	int32_t NumCells;

	int32_t *pCellMap1 = nullptr;
	int32_t *pCellMap2 = nullptr;

	int32_t *PtrToLastUpdatedCellMap = nullptr;

	static constexpr int32_t Value_BlockingCell = -1;
	static constexpr int32_t Value_DeadCell = 0;
	static constexpr int32_t Value_LivingCell = 1;

	C2DCellularAutomata();
	~C2DCellularAutomata();

	
	// Kopierkonstruktor l�schen:
	C2DCellularAutomata(const C2DCellularAutomata &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	C2DCellularAutomata& operator=(const C2DCellularAutomata &originalObject) = delete;

	void Set_CellValue(int32_t cellIID, int32_t value);
	void Set_CellValue(int32_t cellPosX, int32_t cellPosY, int32_t value);

	int32_t Get_CellValue(int32_t cellIID);
	int32_t Get_CellValue(int32_t cellPosX, int32_t cellPosY);

	int32_t Get_PrevCellValue(int32_t cellIID);
	int32_t Get_PrevCellValue(int32_t cellPosX, int32_t cellPosY);

	void Get_PtrToLastUpdatedCellMap(int32_t **ppOut);

	void Init_CellularAutomata(int32_t numCellsXDir, int32_t numCellsYDir);

	void Reset_CellMap(int32_t cellValue);
	void Kill_All_Cells(void);

	void Init_CellMap(CRandomNumbersNN *pRandomNumbers, int32_t densityValue, int32_t invDensity);
	void Init_CellMap(CRandomNumbersNN *pRandomNumbers, int32_t minXPos, int32_t maxXPos, int32_t minYPos, int32_t maxYPos, int32_t densityValue, int32_t invDensity);


	void Output_CellMap(void);

	bool Save_CellMap(const char* pFilename);
	bool Save_CellMap(const char* pFilename, int32_t valueLivingCell, int32_t valueDeadCell);
	bool Save_CellMapPattern(const char* pFilename, int32_t value);

	void Smooth_CellMap(int32_t smoothingValue);
	void Smooth_BorderlessCellMap(int32_t smoothingValue);

	void Detect_Edges(int32_t valueEdgeCell);
	void Detect_Edges2(int32_t valueNonEdgeCell);

	void Update_CellMap(C2State2DCellularAutomatonRules *pRules);
	void Update_BorderlessCellMap(C2State2DCellularAutomatonRules *pRules);

	void Set_CellMapBorderValue(int32_t value);

	void Exchange_LivingAndDeadCells(void);
	void Exchange_CellsValue(int32_t oldValue, int32_t newValue);
};


class C2DCellularAutomataF
{
public:

	int32_t NumCellsXDir;
	int32_t NumCellsYDir;

	int32_t NumCellsXDirMinus1;
	int32_t NumCellsYDirMinus1;

	int32_t NumCells;

	float *pCellMap1 = nullptr;
	float *pCellMap2 = nullptr;

	float *PtrToLastUpdatedCellMap = nullptr;

	static constexpr float Value_BlockingCell = -1.0f;
	static constexpr float Value_DeadCell = 0.0f;
	static constexpr float Value_LivingCell = 1.0f;

	C2DCellularAutomataF();
	~C2DCellularAutomataF();


	// Kopierkonstruktor l�schen:
	C2DCellularAutomataF(const C2DCellularAutomataF &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	C2DCellularAutomataF& operator=(const C2DCellularAutomataF &originalObject) = delete;

	void Set_CellValue(int32_t cellIID, float value);
	void Set_CellValue(int32_t cellPosX, int32_t cellPosY, float value);

	float Get_CellValue(int32_t cellIID);
	float Get_CellValue(int32_t cellPosX, int32_t cellPosY);

	float Get_PrevCellValue(int32_t cellIID);
	float Get_PrevCellValue(int32_t cellPosX, int32_t cellPosY);

	void Get_PtrToLastUpdatedCellMap(float **ppOut);

	void Init_CellularAutomata(int32_t numCellsXDir, int32_t numCellsYDir);

	void Reset_CellMap(float cellValue);
	void Kill_All_Cells(void);

	void Init_CellMap(CRandomNumbersNN *pRandomNumbers, int32_t densityValue, int32_t invDensity);
	void Init_CellMap(CRandomNumbersNN *pRandomNumbers, int32_t minXPos, int32_t maxXPos, int32_t minYPos, int32_t maxYPos, int32_t densityValue, int32_t invDensity);

	void Output_CellMap(void);

	bool Save_CellMap(const char* pFilename);
	bool Save_CellMap(const char* pFilename, float valueLivingCell, float valueDeadCell);
	bool Save_CellMapPattern(const char* pFilename, float value);

	void Smooth_CellMap(int32_t smoothingValue);
	void Smooth_BorderlessCellMap(int32_t smoothingValue);

	void Detect_Edges(float valueEdgeCell);
	void Detect_Edges2(float valueNonEdgeCell);

	void Update_CellMap(C2State2DCellularAutomatonRules *pRules);
	void Update_BorderlessCellMap(C2State2DCellularAutomatonRules *pRules);

	void Set_CellMapBorderValue(float value);

	void Exchange_LivingAndDeadCells(void);
	void Exchange_CellsValue(float oldValue, float newValue);
};



class CNeuralNetHiddenLayer
{
public:

	uint32_t NumOfNeurons = 0;
	uint32_t *pNeuronIDArray = nullptr;

	bool AdditionalBiasNeuron = false;
	uint32_t BiasNeuronID = 0;

	CNeuralNetHiddenLayer();
	~CNeuralNetHiddenLayer();

	// Kopierkonstruktor l�schen:
	CNeuralNetHiddenLayer(const CNeuralNetHiddenLayer &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CNeuralNetHiddenLayer& operator=(const CNeuralNetHiddenLayer &originalObject) = delete;

	void Init_Layer(uint32_t idOfFirstNeuron, uint32_t numOfNeurons, bool additionalBiasNeuron);
	void Reset(void);
};


class CNeuralNet
{
public:

	uint32_t NumOfNeurons = 0;
	uint32_t NumOfUsedNeurons = 0;

	bool HiddenLayer1Used = false;
	bool HiddenLayer2Used = false;
	bool HiddenLayer3Used = false;
	bool ReservorComputing = false;

	CNeuralNetHiddenLayer HiddenLayer1;
	CNeuralNetHiddenLayer HiddenLayer2;
	CNeuralNetHiddenLayer HiddenLayer3;
	

	uint32_t NumInputNeurons = 0;
	uint32_t NumOutputNeurons = 0;
	uint32_t FirstOutputNeuronID = 0;

	uint32_t NumReservoirNeurons = 0;
	uint32_t FirstReservoirNeuronID = 0;
	uint32_t NumReservoirConnectionsPerInputNeuron = 0;
	uint32_t NumReservoirConnectionsPerOutputNeuron = 0;
	uint32_t *pNumInternalReservoirConnectionsArray = nullptr;

	bool AdditionalInputBiasNeuron = false;
	uint32_t InputBiasNeuronID = 0;

	CNeuron *pNeuronArray = nullptr;

	uint32_t NumOfActivationSequenceArrayEntries = 0;
	uint32_t *pActivationSequenceArray = nullptr;

	CRandomNumbersNN RandomNumbers;

	CNeuralNet();
	~CNeuralNet();

	// Kopierkonstruktor l�schen:
	CNeuralNet(const CNeuralNet &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CNeuralNet& operator=(const CNeuralNet &originalObject) = delete;

	void Init_ActivationSequenceArray(uint32_t numOfActivationSequenceArrayEntries);
	void Init_ActivationSequenceArray(uint32_t numOfActivationSequenceArrayEntries, uint32_t *pSequenceArray);	
	void Update_ActivationSequenceArray(uint32_t neuronID, uint32_t entryID);
	
	void Disable_Random_InputNeuron_OutputSynapses(uint64_t newSeed, float mutationRate);
	void Disable_Random_HiddenLayer1Neuron_OutputSynapses(uint64_t newSeed, float mutationRate);
	void Disable_Random_HiddenLayer2Neuron_OutputSynapses(uint64_t newSeed, float mutationRate);
	void Disable_Random_HiddenLayer3Neuron_OutputSynapses(uint64_t newSeed, float mutationRate);

	void Enable_Disabled_InputNeuron_OutputSynapses(uint64_t newSeed, float minPlasticityValue, float maxPlasticityValue);
	void Enable_Disabled_HiddenLayer1Neuron_OutputSynapses(uint64_t newSeed, float minPlasticityValue, float maxPlasticityValue);
	void Enable_Disabled_HiddenLayer2Neuron_OutputSynapses(uint64_t newSeed, float minPlasticityValue, float maxPlasticityValue);
	void Enable_Disabled_HiddenLayer3Neuron_OutputSynapses(uint64_t newSeed, float minPlasticityValue, float maxPlasticityValue);

	void Enable_Disabled_InputNeuron_OutputSynapses(uint64_t newSeed, float minPlasticityValue, float maxPlasticityValue, float mutationRate);
	void Enable_Disabled_HiddenLayer1Neuron_OutputSynapses(uint64_t newSeed, float minPlasticityValue, float maxPlasticityValue, float mutationRate);
	void Enable_Disabled_HiddenLayer2Neuron_OutputSynapses(uint64_t newSeed, float minPlasticityValue, float maxPlasticityValue, float mutationRate);
	void Enable_Disabled_HiddenLayer3Neuron_OutputSynapses(uint64_t newSeed, float minPlasticityValue, float maxPlasticityValue, float mutationRate);
	
	void Init_NeuralNet(uint32_t numOfNeurons);
	
	void Round_OutputWeights(float precision);
	void Remove_Unused_Connections(void);

	void Deactivate_Unused_Neurons(void);

	
	void Set_Activationfunction_OutputLayerNeuron(pActivationFunc pFunc, uint32_t id_InsideLayer);
	void Set_Activationfunction_HiddenLayer1Neuron(pActivationFunc pFunc, uint32_t id_InsideLayer);
	void Set_Activationfunction_HiddenLayer2Neuron(pActivationFunc pFunc, uint32_t id_InsideLayer);
	void Set_Activationfunction_HiddenLayer3Neuron(pActivationFunc pFunc, uint32_t id_InsideLayer);
	void Set_Activationfunction_ReservorNeuron(pActivationFunc pFunc, uint32_t id_InsideReservoir);

	void Set_InputLayer_LearningRate(float learningRate);
	void Set_HiddenLayer1_LearningRate(float learningRate);
	void Set_HiddenLayer2_LearningRate(float learningRate);
	void Set_HiddenLayer3_LearningRate(float learningRate);

	
	void Set_DropoutState_HiddenLayer1Neuron(bool state, uint32_t id_InsideLayer);
	void Set_DropoutState_HiddenLayer2Neuron(bool state, uint32_t id_InsideLayer);
	void Set_DropoutState_HiddenLayer3Neuron(bool state, uint32_t id_InsideLayer);
	void Set_DropoutState_ReservorNeuron(bool state, uint32_t id_InsideReservoir);

	void Init_TwoLayerNetwork(uint32_t numInputNeurons, float minPlasticityValue_InputLayer, float maxPlasticityValue_InputLayer, float inputNeuronLearningRate, bool additionalInputBiasNeuron, uint32_t numOutputNeurons, pActivationFunc pOutputNeuronActivationFunc, float outputNeuronErrorFactor1 = 1.0f, float outputNeuronErrorFactor2 = 1.0f);
	
	void Calculate_Output_TwoLayerNetwork(float *pOutputValueArray, const float *pInputValueArray);
	void Calculate_Output_TwoLayerNetwork(float *pOutputValue, const float *pInputValueArray, uint32_t idOfOutputNeuron);
	void Calculate_Output_TwoLayerNetwork(float *pOutputValueArray);

	float Learning_TwoLayerNetwork(const float *pDesiredOutputValueArray);

	float Learning_TwoLayerNetwork(float desiredOutputValue, uint32_t idOfOutputNeuron);

	void Init_Input_And_OutputNeurons(uint32_t numInputNeurons, float inputNeuronLearningRate, bool additionalInputBiasNeuron, uint32_t numOutputNeurons, pActivationFunc pOutputNeuronActivationFunc, float outputNeuronErrorFactor1 = 1.0f, float outputNeuronErrorFactor2 = 1.0f);

	
	void Init_ReservoirComputing_FullyConnectedReservoir(uint32_t numInputNeurons, uint32_t numReservoirConnectionsPerInputNeuron, uint32_t *pReservoirNeuronsWithInputConnection_IDArray, float inputNeuronLearningRate, bool additionalInputBiasNeuron, uint32_t numReservoirNeurons, pActivationFunc pReservoirNeuronActivationFunc, float reservoirNeuronLearningRate, float minPlasticityValue_ReservoirNeurons, float maxPlasticityValue_ReservoirNeurons, uint32_t numOutputNeurons, uint32_t numReservoirConnectionsPerOutputNeuron, uint32_t *pReservoirNeuronsWithOutputConnection_IDArray, pActivationFunc pOutputNeuronActivationFunc, float outputNeuronErrorFactor1 = 1.0f, float outputNeuronErrorFactor2 = 1.0f);

	void Init_ReservoirComputing(uint32_t numInputNeurons, uint32_t numReservoirConnectionsPerInputNeuron, uint32_t *pReservoirNeuronsWithInputConnection_IDArray, float inputNeuronLearningRate, bool additionalInputBiasNeuron, uint32_t numReservoirNeurons, uint32_t minNumOfReservoirConnections, uint32_t maxNumOfReservoirConnections, pActivationFunc pReservoirNeuronActivationFunc, float reservoirNeuronLearningRate, float minPlasticityValue_ReservoirNeurons, float maxPlasticityValue_ReservoirNeurons, uint32_t numOutputNeurons, uint32_t numReservoirConnectionsPerOutputNeuron, uint32_t *pReservoirNeuronsWithOutputConnection_IDArray, pActivationFunc pOutputNeuronActivationFunc, float outputNeuronErrorFactor1 = 1.0f, float outputNeuronErrorFactor2 = 1.0f);

	void Init_HiddenLayer1(uint32_t numOfNeurons, bool additionalBiasNeuron, bool connectWithOutputLayer, pActivationFunc pFunc, float minPlasticityValue_HiddenLayer1, float maxPlasticityValue_HiddenLayer1, float minPlasticityValue_InputLayer, float maxPlasticityValue_InputLayer, float learningRate, float errorFactor1 = 1.0f, float errorFactor2 = 1.0f);

	void Init_HiddenLayer2(uint32_t numOfNeurons, bool additionalBiasNeuron, bool connectWithOutputLayer, pActivationFunc pFunc, float minPlasticityValue_HiddenLayer2, float maxPlasticityValue_HiddenLayer2, float minPlasticityValue_HiddenLayer1, float maxPlasticityValue_HiddenLayer1, float learningRate, float errorFactor1 = 1.0f, float errorFactor2 = 1.0f);
	
	void Init_HiddenLayer3(uint32_t numOfNeurons, bool additionalBiasNeuron, pActivationFunc pFunc, float minPlasticityValue_HiddenLayer3, float maxPlasticityValue_HiddenLayer3, float minPlasticityValue_HiddenLayer2, float maxPlasticityValue_HiddenLayer2, float learningRate, float errorFactor1 = 1.0f, float errorFactor2 = 1.0f);

	void RandomChange_OutputSynapsePlasticities(uint64_t newSeed, float minPlasticity, float maxPlasticity);
	void RandomChange_OutputSynapsePlasticities(uint64_t newSeed, float minPlasticity, float maxPlasticity, float mutationRate);
	void RandomChange_OutputSynapsePlasticities2(uint64_t newSeed, float minPlasticityVariance, float maxPlasticityVariance);
	void RandomChange_OutputSynapsePlasticities2(uint64_t newSeed, float minPlasticityVariance, float maxPlasticityVariance, float mutationRate);

	void RandomChange_OutputSynapsePlasticities_InputLayer(uint64_t newSeed, float minPlasticity, float maxPlasticity);
	void RandomChange_OutputSynapsePlasticities_InputLayer(uint64_t newSeed, float minPlasticity, float maxPlasticity, float mutationRate);
	void RandomChange_OutputSynapsePlasticities2_InputLayer(uint64_t newSeed, float minPlasticityVariance, float maxPlasticityVariance);
	void RandomChange_OutputSynapsePlasticities2_InputLayer(uint64_t newSeed, float minPlasticityVariance, float maxPlasticityVariance, float mutationRate);

	void RandomChange_OutputSynapsePlasticities_HiddenLayer1(uint64_t newSeed, float minPlasticity, float maxPlasticity);
	void RandomChange_OutputSynapsePlasticities_HiddenLayer1(uint64_t newSeed, float minPlasticity, float maxPlasticity, float mutationRate);
	void RandomChange_OutputSynapsePlasticities2_HiddenLayer1(uint64_t newSeed, float minPlasticityVariance, float maxPlasticityVariance);
	void RandomChange_OutputSynapsePlasticities2_HiddenLayer1(uint64_t newSeed, float minPlasticityVariance, float maxPlasticityVariance, float mutationRate);
	
	void RandomChange_OutputSynapsePlasticities_HiddenLayer2(uint64_t newSeed, float minPlasticity, float maxPlasticity);
	void RandomChange_OutputSynapsePlasticities_HiddenLayer2(uint64_t newSeed, float minPlasticity, float maxPlasticity, float mutationRate);
	void RandomChange_OutputSynapsePlasticities2_HiddenLayer2(uint64_t newSeed, float minPlasticityVariance, float maxPlasticityVariance);
	void RandomChange_OutputSynapsePlasticities2_HiddenLayer2(uint64_t newSeed, float minPlasticityVariance, float maxPlasticityVariance, float mutationRate);
	
	void RandomChange_OutputSynapsePlasticities_HiddenLayer3(uint64_t newSeed, float minPlasticity, float maxPlasticity);
	void RandomChange_OutputSynapsePlasticities_HiddenLayer3(uint64_t newSeed, float minPlasticity, float maxPlasticity, float mutationRate);
	void RandomChange_OutputSynapsePlasticities2_HiddenLayer3(uint64_t newSeed, float minPlasticityVariance, float maxPlasticityVariance);
	void RandomChange_OutputSynapsePlasticities2_HiddenLayer3(uint64_t newSeed, float minPlasticityVariance, float maxPlasticityVariance, float mutationRate);
	
	void RandomChange_OutputSynapsePlasticities_ReservoirNeurons(uint64_t newSeed, float minPlasticity, float maxPlasticity);
	void RandomChange_OutputSynapsePlasticities_ReservoirNeurons(uint64_t newSeed, float minPlasticity, float maxPlasticity, float mutationRate);
	void RandomChange_OutputSynapsePlasticities2_ReservoirNeurons(uint64_t newSeed, float minPlasticityVariance, float maxPlasticityVariance);
	void RandomChange_OutputSynapsePlasticities2_ReservoirNeurons(uint64_t newSeed, float minPlasticityVariance, float maxPlasticityVariance, float mutationRate);

	
	void Clone_OutputSynapsePlasticities(CNeuralNet *pOriginalBrain);
	void Clone_OutputSynapsePlasticities(CNeuralNet *pOriginalBrain, float variance, uint64_t newSeed);
	void Clone_OutputSynapsePlasticities(CNeuralNet *pOriginalBrain, float variance, float mutationRate, uint64_t newSeed);
	void Clone_OutputSynapsePlasticities(CNeuralNet *pOriginalBrain, float minVariance, float maxVariance, float mutationRate, uint64_t newSeed);

	void Clone_OutputSynapsePlasticities2(CNeuralNet *pOriginalBrain, float varianceMemoryNeurons, uint64_t newSeed);
	void Clone_OutputSynapsePlasticities2(CNeuralNet *pOriginalBrain, float varianceMemoryNeurons, float mutationRate, uint64_t newSeed);
	
	void Clone_OutputSynapsePlasticities3(CNeuralNet *pOriginalBrain, float varianceNonMemoryNeurons, uint64_t newSeed);
	void Clone_OutputSynapsePlasticities3(CNeuralNet *pOriginalBrain, float varianceNonMemoryNeurons, float mutationRate, uint64_t newSeed);

	void Clone_OutputSynapsePlasticities_InputLayer(CNeuralNet *pOriginalBrain, float variance, uint64_t newSeed);
	void Clone_OutputSynapsePlasticities_InputLayer(CNeuralNet *pOriginalBrain, float variance, float mutationRate, uint64_t newSeed);
	void Clone_OutputSynapsePlasticities_InputLayer(CNeuralNet *pOriginalBrain, float minVariance, float maxVariance, float mutationRate, uint64_t newSeed);
	
	void Clone_OutputSynapsePlasticities_HiddenLayer1(CNeuralNet *pOriginalBrain, float variance, uint64_t newSeed);
	void Clone_OutputSynapsePlasticities_HiddenLayer1(CNeuralNet *pOriginalBrain, float variance, float mutationRate, uint64_t newSeed);
	void Clone_OutputSynapsePlasticities_HiddenLayer1(CNeuralNet *pOriginalBrain, float minVariance, float maxVariance, float mutationRate, uint64_t newSeed);

	void Clone_OutputSynapsePlasticities_HiddenLayer2(CNeuralNet *pOriginalBrain, float variance, uint64_t newSeed);
	void Clone_OutputSynapsePlasticities_HiddenLayer2(CNeuralNet *pOriginalBrain, float variance, float mutationRate, uint64_t newSeed);
	void Clone_OutputSynapsePlasticities_HiddenLayer2(CNeuralNet *pOriginalBrain, float minVariance, float maxVariance, float mutationRate, uint64_t newSeed);
	
	void Clone_OutputSynapsePlasticities_HiddenLayer3(CNeuralNet *pOriginalBrain, float variance, uint64_t newSeed);
	void Clone_OutputSynapsePlasticities_HiddenLayer3(CNeuralNet *pOriginalBrain, float variance, float mutationRate, uint64_t newSeed);
	void Clone_OutputSynapsePlasticities_HiddenLayer3(CNeuralNet *pOriginalBrain, float minVariance, float maxVariance, float mutationRate, uint64_t newSeed);

	void Combine_OutputSynapsePlasticities_InputLayer(CNeuralNet *pParentBrain1, CNeuralNet *pParentBrain2, float minWeight1, uint64_t newSeed);
	void Combine_OutputSynapsePlasticities_HiddenLayer1(CNeuralNet *pParentBrain1, CNeuralNet *pParentBrain2, float minWeight1, uint64_t newSeed);
	void Combine_OutputSynapsePlasticities_HiddenLayer2(CNeuralNet *pParentBrain1, CNeuralNet *pParentBrain2, float minWeight1, uint64_t newSeed);
	void Combine_OutputSynapsePlasticities_HiddenLayer3(CNeuralNet *pParentBrain1, CNeuralNet *pParentBrain2, float minWeight1, uint64_t newSeed);
	void Combine_OutputSynapsePlasticities_ReservoirNeurons(CNeuralNet *pParentBrain1, CNeuralNet *pParentBrain2, float minWeight1, uint64_t newSeed);

	void Combine_OutputSynapsePlasticities(CNeuralNet *pParentBrain1, CNeuralNet *pParentBrain2, float minWeight1, uint64_t newSeed);

	
	void Calculate_Output_UseActivationSequence(float *pOutputValueArray, const float *pInputValueArray);
	float Calculate_Output_With_Error_UseActivationSequence(float *pOutputValueArray, const float *pInputValueArray);
	
	void Set_InputNeuronValues_And_Propagate_Them(const float *pInputValueArray);
	void Set_InputNeuronValues_And_Propagate_Them(const float *pInputValueArray, uint32_t offset, uint32_t numValues);
	

	void Set_InputValues_HiddenLayer1(const float *pInputValueArray);
	void Set_InputValues_HiddenLayer1(float value);
	void Set_InputValues_HiddenLayer1(float value, uint32_t id_InsideLayer);
	
	void Get_Output(float *pOutputValueArray);

	void Calculate_Output(float *pOutputValueArray, const float *pInputValueArray);	
	float Calculate_Output2(const float *pInputValueArray, uint32_t idOfOutputNeuron);
	void Calculate_Output_IgnoreInputNeurons(float *pOutputValueArray);
	float Calculate_Output_With_Error(float *pOutputValueArray, const float *pInputValueArray);
	
	void Calculate_Error(float *pErrorValueArray, const float *pDesiredOutputValueArray);
	float Calculate_Error(const float *pDesiredOutputValueArray);

	float Learning_UseActivationSequence(const float *pDesiredOutputValueArray);

	float Backpropagate_Error_UseActivationSequence(const float *pDesiredOutputValueArray);
	void Adjust_Weights_After_Backpropagation_UseActivationSequence(void);

	float Learning(const float *pDesiredOutputValueArray);

	float Backpropagate_Error(const float *pDesiredOutputValueArray);
	void Adjust_Weights_After_Backpropagation(void);
	
	float Learning(float desiredOutputValue, uint32_t idOfOutputNeuron);
	
	float Backpropagate_Error(float desiredOutputValue, uint32_t idOfOutputNeuron);

	

	// Nur die Plastizit�tswerte der mit den Output-Neuronen verbundenen Synapsen werden modifiziert:
	float ExtremeLearning(const float *pDesiredOutputValueArray);

	// Nur die Plastizit�tswerte der mit den Output-Neuronen verbundenen Synapsen werden modifiziert:
	float ExtremeLearning(float desiredOutputValue, uint32_t idOfOutputNeuron);

	
	void Reset_Memory_Of_ReservoirNeurons(void);
	

	void Calculate_Output_ReservoirComputing(float *pOutputValueArray, const float *pInputValueArray, uint32_t numAdditionalRecurrentCycles = 0);

	
	void Update_InputNeurons_Prior_ReservorUpdate(const float *pInputValueArray);
	void Update_ReservoirNeurons(void);
	void Update_OutputNeurons_After_ReservorUpdate(float *pOutputValueArray);

	float Learning_ReservoirComputing(const float *pDesiredOutputValueArray);

}; // end of class CNeuralNet


class C2DPatternDetector
{
public:

	uint32_t SizeXDir;
	uint32_t SizeYDir;
	uint32_t Size;  // SizeXDir * SizeYDir

	float *pValueArray = nullptr;

	C2DPatternDetector();
	~C2DPatternDetector();

	// Kopierkonstruktor l�schen:
	C2DPatternDetector(const C2DPatternDetector &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	C2DPatternDetector& operator=(const C2DPatternDetector &originalObject) = delete;

	void Initialize(uint32_t sizeXDir, uint32_t sizeYDir);

	bool Load_Data(const char* pFilename);
	bool Save_Data(const char* pFilename);
	
	bool Load_Binary_Data_From_Bitmap(const char* pDescFilename /*not the bitmap*/, bool binaryImageData, bool use_0_And_1_Values = true);
	bool Load_Data_From_Bitmap(const char* pDescFilename /*not the bitmap*/, float dataBiasValue = 0.0f);

	// ok
	bool Search_Pattern(int32_t *pOutPatternCount, int32_t *pOutPatternPosXArray, int32_t *pOutPatternPosYArray, int32_t maxPosArrayElements, const float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, float minActivationValue);

	// ok
	bool Search_Pattern(int32_t *pOutPatternCount, int32_t *pOutPatternPosXArray, int32_t *pOutPatternPosYArray, int32_t maxPosArrayElements, const float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, float activationValue, float minTolerance, float maxTolerance);

	// ok
	bool Check_For_Pattern(int32_t patternTestPosX, int32_t patternTestPosY, const float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, float minActivationValue);
	
	// ok
	bool Check_For_Pattern(float *pOutActivationvalue, int32_t patternTestPosX, int32_t patternTestPosY, const float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, float minActivationValue);
	
	// ok
	bool Check_For_Pattern(int32_t patternTestPosX, int32_t patternTestPosY, const float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, float activationValue, float minTolerance, float maxTolerance);

	// ok
	bool Check_For_Pattern(float *pOutActivationvalue, int32_t patternTestPosX, int32_t patternTestPosY, const float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, float activationValue, float minTolerance, float maxTolerance);
};


// lokales rezeptives Feld als neuronales Netz:
// mehrere Input-Neuronen, die mit einem Output-Neuron verkn�pft sind

class C2DLocalReceptiveField // LocalReceptiveField: LRF
{
public:

	uint32_t SizeXDir;
	uint32_t SizeYDir;
	uint32_t Size;  // SizeXDir * SizeYDir

	float *pValueArray = nullptr;
	float *pInputErrorValueArray = nullptr;
	float *pSumOfInputValuesArray = nullptr;

	float SumOfOutputValues;
	float OutputErrorValue;
	float Bias;
	

	float SumOfActivationValues;
	float MaxActivationValue;
	float MinActivationValue;

	float FittingValue;

	C2DLocalReceptiveField();
	~C2DLocalReceptiveField();

	// Kopierkonstruktor l�schen:
	C2DLocalReceptiveField(const C2DLocalReceptiveField &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	C2DLocalReceptiveField& operator=(const C2DLocalReceptiveField &originalObject) = delete;

	void Initialize(uint32_t sizeXDir, uint32_t sizeYDir);

	bool Load_Data(const char* pFilename);
	
	bool Load_Binary_Data_From_Bitmap(const char* pDescFilename /*not the bitmap*/, bool binaryImageData, bool use_0_And_1_Values = true);
	bool Load_Data_From_Bitmap(const char* pDescFilename /*not the bitmap*/, float dataBiasValue = 0.0f);
	
	bool Save_Data(const char* pFilename);
	
	void Reset_ErrorValues(void);
	void Reset_SumOfOutputAndInputValues(void);
	void Set_Value(float value, uint32_t index);
	void Clear_Values(float value = 0.0f);
	void Set_Bias(float value);

	// Achtung: Werte von 0 lassen sich mittels Backpropagation-Training nicht ver�ndern! 
	void Generate_RandomValues(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float minBiasValue, float maxBiasValue, bool includingZeroValues = false);

	// Achtung: Werte von 0 lassen sich mittels Backpropagation-Training nicht ver�ndern! 
	void Generate_RandomValues(CRandomNumbersNN *pRandomNumbers, int32_t minValue, int32_t maxValue, float minBiasValue, float maxBiasValue, bool includingZeroValues = false);

	void Mutate_Values1(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float mutationRate);
	void Mutate_Values2(CRandomNumbersNN *pRandomNumbers, float minVariance, float maxVariance, float mutationRate);

	void Clone_Values(C2DLocalReceptiveField *pOriginalLRF);
	void Clone_Values(C2DLocalReceptiveField *pOriginalLRF, CRandomNumbersNN *pRandomNumbers, float filterVariance, float biasVariance, float mutationRate);

	void Combine_Values(C2DLocalReceptiveField *pParentLRF1, C2DLocalReceptiveField *pParentLRF2, CRandomNumbersNN *pRandomNumbers, float minWeight1);
	
	void Reset_ActivationData(void);
	void Update_ActivationData(float value);
	
	void Calculate_FittingValue(float fittingParam1, float fittingParam2);
	
	void Calculate_FeatureMap(float *pFeatureMap, const float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, pActivationFunc pFunc);
	
	void Add_Feature_To_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, const float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY,
		int32_t strideX, int32_t strideY, pActivationFunc pFunc);
	
	// Bei der Fehlerberecnung werden die Fehler der direkt nachgeschalteten C2DLocalReceptiveField-Instanzen ber�cksichtigt:
	void Begin_ErrorCalculation(C2DLocalReceptiveField *pPostLocalReceptiveField);
	void Continue_ErrorCalculation(C2DLocalReceptiveField *pPostLocalReceptiveField);
	void Finish_ErrorCalculation(float inputErrorFactor1, float inputErrorFactor2, float outputErrorFactor1, float outputErrorFactor2);
	
	// Train:

	void Adjust_LocalReceptiveField_AfterErrorCalculations(float learningRate);
	
	void Train_Final_LocalReceptiveField(CNeuralNet *pBrain, uint32_t firstReceiverNeuronID, uint32_t lastReceiverNeuronID, float learningRate, float receiverNeuronErrorFactor1, float receiverNeuronErrorFactor2, float inputErrorFactor1, float inputErrorFactor2, float outputErrorFactor1, float outputErrorFactor2);
};


// lokales rezeptives Feld als neuronales Netz:
// mehrere Input-Neuronen, die mit einem Output-Neuron verkn�ft sind

class C1DLocalReceptiveField // LocalReceptiveField: LRF
{
public:

	uint32_t Size;

	float *pValueArray = nullptr;
	float *pInputErrorValueArray = nullptr;
	float *pSumOfInputValuesArray = nullptr;

	float SumOfOutputValues;

	float OutputErrorValue;

	float Bias;
	

	float SumOfActivationValues;
	float MaxActivationValue;
	float MinActivationValue;

	float FittingValue;

	C1DLocalReceptiveField();
	~C1DLocalReceptiveField();

	// Kopierkonstruktor l�schen:
	C1DLocalReceptiveField(const C1DLocalReceptiveField &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	C1DLocalReceptiveField& operator=(const C1DLocalReceptiveField &originalObject) = delete;

	void Initialize(uint32_t size);

	bool Load_Data(const char* pFilename);

	bool Save_Data(const char* pFilename);

	void Reset_ErrorValues(void);

	void Reset_SumOfOutputAndInputValues(void);

	void Set_Value(float value, uint32_t index);
	void Clear_Values(float value = 0.0f);
	void Set_Bias(float value);

	// Achtung: Werte von 0 lassen sich mittels Backpropagation-Training nicht ver�ndern! 
	void Generate_RandomValues(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float minBiasValue, float maxBiasValue, bool includingZeroValues = false);

	// Achtung: Werte von 0 lassen sich mittels Backpropagation-Training nicht ver�ndern! 
	void Generate_RandomValues(CRandomNumbersNN *pRandomNumbers, int32_t minValue, int32_t maxValue, float minBiasValue, float maxBiasValue, bool includingZeroValues = false);

	void Mutate_Values1(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float mutationRate);
	void Mutate_Values2(CRandomNumbersNN *pRandomNumbers, float minVariance, float maxVariance, float mutationRate);

	void Clone_Values(C1DLocalReceptiveField *pOriginalLRF);
	void Clone_Values(C1DLocalReceptiveField *pOriginalLRF, CRandomNumbersNN *pRandomNumbers, float filterVariance, float biasVariance, float mutationRate);

	void Combine_Values(C1DLocalReceptiveField *pParentLRF1, C1DLocalReceptiveField *pParentLRF2, CRandomNumbersNN *pRandomNumbers, float minWeight1);

	void Reset_ActivationData(void);
	void Update_ActivationData(float value);

	void Calculate_FittingValue(float fittingParam1, float fittingParam2);
	void Calculate_FeatureMap(float *pFeatureMap, const float *pInputArray, int32_t inputArraySize, int32_t stride, pActivationFunc pFunc);

	void Add_Feature_To_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputArraySize, int32_t stride, pActivationFunc pFunc);

	// Bei der Fehlerberechnung werden die Fehler der direkt nachgeschalteten C1DLocalReceptiveField-Instanzen ber�cksichtigt:

	void Begin_ErrorCalculation(C1DLocalReceptiveField *pPostLocalReceptiveField);
	void Continue_ErrorCalculation(C1DLocalReceptiveField *pPostLocalReceptiveField);
	void Finish_ErrorCalculation(float inputErrorFactor1, float inputErrorFactor2, float outputErrorFactor1, float outputErrorFactor2);
	
	// Train:

	void Adjust_LocalReceptiveField_AfterErrorCalculations(float learningRate);
	
	void Train_Final_LocalReceptiveField(CNeuralNet *pBrain, uint32_t firstReceiverNeuronID, uint32_t lastReceiverNeuronID, float learningRate, float receiverNeuronErrorFactor1, float receiverNeuronErrorFactor2, float inputErrorFactor1, float inputErrorFactor2, float outputErrorFactor1, float outputErrorFactor2);
};



#define NormalizeImageData


class CImageDataPreprocessing
{
public:

	CRandomNumbersNN RandomNumbers;

	uint32_t Stride;
	uint32_t LRFSizeX; // LRF: Local Receptive Field
	uint32_t LRFSizeY;
	uint32_t LRFSize;

	uint32_t UnpooledFeatureMapSizeX;
	uint32_t UnpooledFeatureMapSizeY;
	uint32_t UnpooledFeatureMapSize;

	uint32_t FeatureMapSizeX;
	uint32_t FeatureMapSizeY;
	uint32_t FeatureMapSize;

	// Anzahl der lokalen rezeptiven Felder bzw. Feature-Maps:
	uint32_t NumFeatureMaps; 

	CImageDataF *pUnpooledFeatureMapArray = nullptr;
	CImageDataF *pFeatureMapArray = nullptr;
	C2DLocalReceptiveField *pLRFArray = nullptr;

	C2DLocalReceptiveField TempLRF;

	uint32_t ImageSizeX;
	uint32_t ImageSizeY;
	uint32_t ImageSize;

	uint32_t IdOfWorstFittedLRF = 0;
	uint32_t IdOfBestFittedLRF = 0;

	CImageDataPreprocessing(uint32_t imageSizeX, uint32_t imageSizeY, uint32_t numFeatureMaps, uint32_t lRFSizeX, uint32_t lRFSizeY, uint32_t stride, float minBiasValue, float maxBiasValue);

	// Achtung: LRF-Werte von 0 lassen sich mittels Backpropagation-Training nicht ver�ndern! 
	CImageDataPreprocessing(uint32_t imageSizeX, uint32_t imageSizeY, uint32_t numFeatureMaps, uint32_t lRFSizeX, uint32_t lRFSizeY, uint32_t stride, int32_t minLRFValue, int32_t maxLRFValue, float minBiasValue, float maxBiasValue, bool includingZeroValues = false);

	// Achtung: LRF-Werte von 0 lassen sich mittels Backpropagation-Training nicht ver�ndern! 
	CImageDataPreprocessing(uint32_t imageSizeX, uint32_t imageSizeY, uint32_t numFeatureMaps, uint32_t lRFSizeX, uint32_t lRFSizeY, uint32_t stride, float minLRFValue, float maxLRFValue, float minBiasValue, float maxBiasValue, bool includingZeroValues = false);

	
	~CImageDataPreprocessing();

	
	// Kopierkonstruktor l�schen:
	CImageDataPreprocessing(const CImageDataPreprocessing &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CImageDataPreprocessing& operator=(const CImageDataPreprocessing &originalObject) = delete;

	void Init_Standard_LocalReceptiveFields(float minBiasValue, float maxBiasValue);

	void Init_LocalReceptiveField(float *pValueArray, uint32_t id);

	void Single_LocalReceptiveField_Evolution(float *pImageData, uint32_t idOfLRF, float minFilterValue, float maxFilterValue, float minBiasValue, float maxBiasValue, pActivationFunc pFunc, bool includingZeroValues = true);

	void Single_LocalReceptiveField_Evolution(CImageDataF *pImageArray, uint32_t numImages, uint32_t idOfLRF, float minFilterValue, float maxFilterValue, float minBiasValue, float maxBiasValue, pActivationFunc pFunc, bool includingZeroValues = false);
	
	void Single_LocalReceptiveField_Evolution(float *pImageData, uint32_t idOfLRF, int32_t minFilterValue, int32_t maxFilterValue, float minBiasValue, float maxBiasValue, pActivationFunc pFunc, bool includingZeroValues = false);
	
	void Single_LocalReceptiveField_Evolution(CImageDataF *pImageArray, uint32_t numImages, uint32_t idOfLRF, int32_t minFilterValue, int32_t maxFilterValue, float minBiasValue, float maxBiasValue, pActivationFunc pFunc, bool includingZeroValues = false);

	void Prepare_LocalReceptiveField_Analysis(void);
	void Display_LocalReceptiveField_Analysis(void);
	
	void Analyze_LocalReceptiveFields(float *pImageData, pActivationFunc pFunc);
	void Analyze_LocalReceptiveFields(CImageDataF *pImageArray, uint32_t numImages, pActivationFunc pFunc);

	void Update_Evolution(float minValue, float maxValue, float minBiasValue, float maxBiasValue, float fittingParam1 = 0.1f, float fittingParam2 = 0.5f, bool includingZeroValues = false);
	
	void Update_Evolution(int32_t minValue, int32_t maxValue, float minBiasValue, float maxBiasValue, float fittingParam1 = 0.1f, float fittingParam2 = 0.5f, bool includingZeroValues = false);
	
	void Preprocess_Data(float *pImageData, pActivationFunc pFunc, uint32_t poolingType);
	
	void Preprocess_Data(CImageDataF *pImageArray, uint32_t numImages, pActivationFunc pFunc, uint32_t poolingType);

	// pImageIDArray erm�glicht die Auswahl einzelner Images aus dem pImageArray:
	void Preprocess_Data(CImageDataF *pImageArray, uint32_t *pImageIDArray, uint32_t numImages, pActivationFunc pFunc, uint32_t poolingType);

	void Preprocess_Data(CNeuralNet *pBrain, float *pImageData, pActivationFunc pFunc, uint32_t poolingType);

	// pInOutNeuronIDOffset:
	// Verweist beim Methodenaufruf auf die ID des ersten Neurons, an welches die Berechnungsergebnisse weitergeleitet werden sollen.
	// Verweist nach dem Methodenaufruf auf die Nachfolge-ID des letzten Neurons, an welches die Berechnungsergebnisse weitergeleitet wurden. 
	void Preprocess_Data(CNeuralNet *pBrain, float *pImageData, uint32_t *pInOutNeuronIDOffset, pActivationFunc pFunc, uint32_t poolingType);

	void Preprocess_Data(CNeuralNet *pBrain, CImageDataF *pImageArray, uint32_t numImages, pActivationFunc pFunc, uint32_t poolingType);

	void Preprocess_Data(CNeuralNet *pBrain, CImageDataF *pImageArray, uint32_t numImages, uint32_t *pInOutNeuronIDOffset, pActivationFunc pFunc, uint32_t poolingType);

	// pImageIDArray erm�glicht die Auswahl einzelner Images aus dem pImageArray:
	void Preprocess_Data(CNeuralNet *pBrain, CImageDataF *pImageArray, uint32_t *pImageIDArray, uint32_t numImages, pActivationFunc pFunc, uint32_t poolingType);

	// pImageIDArray erm�glicht die Auswahl einzelner Images aus dem pImageArray:
	void Preprocess_Data(CNeuralNet *pBrain, CImageDataF *pImageArray, uint32_t *pImageIDArray, uint32_t numImages, uint32_t *pInOutNeuronIDOffset, pActivationFunc pFunc, uint32_t poolingType);

	void Train_Final_LocalReceptiveFields(CNeuralNet *pBrain, float learningRate, float receiverNeuronErrorFactor1, float receiverNeuronErrorFactor2, float inputErrorFactor1, float inputErrorFactor2, float outputErrorFactor1, float outputErrorFactor2);

	void Train_Final_LocalReceptiveFields(CNeuralNet *pBrain, uint32_t *pInOutNeuronIDOffset, float learningRate, float receiverNeuronErrorFactor1, float receiverNeuronErrorFactor2, float inputErrorFactor1, float inputErrorFactor2, float outputErrorFactor1, float outputErrorFactor2);

	void Train_LocalReceptiveFields(CImageDataPreprocessing* pPostDataPreprocessingStep, float learningRate, float inputErrorFactor1, float inputErrorFactor2, float outputErrorFactor1, float outputErrorFactor2);

	void Train_LocalReceptiveFields(CImageDataPreprocessing* pPostDataPreprocessingStep, uint32_t *pLRF_IDArray, uint32_t numOfPostConnectedLRFs, float learningRate, float inputErrorFactor1, float inputErrorFactor2, float outputErrorFactor1, float outputErrorFactor2);
};

class CShortTermMemoryElement
{
public:

	uint32_t NumOfNeurons = 0;
	uint32_t NumOfMemoryNeurons = 0;
	uint32_t NumOfOutputNeurons = 0;

	CNeuron *pNeuronArray = nullptr;

	uint32_t FirstOutputNeuronID = 0;
	uint32_t FirstMemoryNeuronID = 0;
	
	CShortTermMemoryElement();
	~CShortTermMemoryElement();

	// Kopierkonstruktor l�schen:
	CShortTermMemoryElement(const CShortTermMemoryElement &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CShortTermMemoryElement& operator=(const CShortTermMemoryElement &originalObject) = delete;

	void Set_MemoryNeuronActivationFunction(pActivationFunc pFunc, uint32_t idOfMemeoryNeuron);
	void Set_OutputNeuronActivationFunction(pActivationFunc pFunc, uint32_t idOfOutputNeuron);

	void Reset_Memory(void);
	float Get_Actual_Output(void);
	void Get_Actual_Output(float *pOutputValueArray);
	float Get_MemoryNeuronOutput(uint32_t idOfMemeoryNeuron);

	
	void Initialize_SingleInput_SingleOutput(uint32_t numOfMemoryNeurons, pActivationFunc pFunc, float memoryDrecreaseFactor = 1.0f);
	void Initialize_SingleInput_SingleOutput(uint32_t numOfMemoryNeurons, pActivationFunc pFunc1, pActivationFunc pFunc_LastMemoryNeuron, float memoryDrecreaseFactor = 1.0f);
	void Initialize_SingleInput_OutputArray(uint32_t numOfOutputNeurons, pActivationFunc pFunc, float memoryDrecreaseFactor = 1.0f);
	
	float Calculate_Output(float inputValue);
	void Calculate_Output(float *pOutputValueArray, float inputValue);

	void Clone_Memory(CShortTermMemoryElement *pMemoryNetwork);
	void Permute_Memory_Randomly(CRandomNumbersNN *pRandomNumbers);
	void Permute_Memory(uint32_t id1, uint32_t id2);
};









class CNeuralNetPopulation
{
public:

	uint64_t Seed = 1;
	CRandomNumbersNN RandomNumbers;

	uint32_t PopulationSize;
	uint32_t PopulationSizePlus4;

	CNeuralNet **ppUsedNeuralNetArray = nullptr;

	float *pFitnessScoreArray = nullptr;

	static constexpr uint32_t constNumOfBestFittedBrains = 10;
	uint32_t IDArrayOfBestFittedBrains[constNumOfBestFittedBrains];
	float FitnessArrayOfBestFittedBrains[constNumOfBestFittedBrains];

	static constexpr uint32_t constNumOfWorstFittedBrains = 10;
	uint32_t IDArrayOfWorstFittedBrains[constNumOfWorstFittedBrains];
	float FitnessArrayOfWorstFittedBrains[constNumOfWorstFittedBrains];

	bool UseAdditionalMutatedBestBrain = false;
	bool UseAdditionalMutatedSecondBestBrain = false;
	bool UseAdditionalBestBrainsChild = false;

	static constexpr uint32_t constNumOfRandomBrainsChilds = 1;
	bool UseAdditionalRandomBrainsChild[constNumOfRandomBrainsChilds];

	static constexpr uint32_t constNumPopulationSearchStepsMax = 3;

	uint32_t NumOfInputNeurons = 0;
	uint32_t NumOfOutputNeurons = 0;

	uint32_t MinNumOfHiddenNeuronsL1 = 0;
	uint32_t MaxNumOfHiddenNeuronsL1 = 0;
	uint32_t MinNumOfHiddenNeuronsL2 = 0;
	uint32_t MaxNumOfHiddenNeuronsL2 = 0;

	pActivationFunc pOutputNeuronActivationFunc = nullptr;
	pActivationFunc pHiddenLayer1NeuronActivationFunc = nullptr;
	pActivationFunc pHiddenLayer2NeuronActivationFunc = nullptr;

	bool UseAdditionalInputLayerBias = false;
	bool UseAdditionalHiddenLayer1Bias = false;
	bool UseAdditionalHiddenLayer2Bias = false;

	CNeuralNetPopulation();
	~CNeuralNetPopulation();

	// Kopierkonstruktor l�schen:
	CNeuralNetPopulation(const CNeuralNetPopulation  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CNeuralNetPopulation & operator=(const CNeuralNetPopulation  &originalObject) = delete;

	void Initialize(uint32_t populationSize, uint32_t numOfInputNeurons, uint32_t numOfOutputNeurons, uint32_t minNumOfHiddenNeuronsL1, uint32_t maxNumOfHiddenNeuronsL1, uint32_t minNumOfHiddenNeuronsL2, uint32_t maxNumOfHiddenNeuronsL2, pActivationFunc pOutputNeuronFunc, pActivationFunc pHiddenLayer1NeuronFunc, pActivationFunc pHiddenLayer2NeuronFunc);

	void Set_NeuralNet(CNeuralNet *pNeuralNet, uint32_t id);

	void Set_Activationfunction_OutputLayerNeuron(pActivationFunc pFunc);
	void Set_Activationfunction_HiddenLayer1Neuron(pActivationFunc pFunc);
	void Set_Activationfunction_HiddenLayer2Neuron(pActivationFunc pFunc);

	void Use_AdditionalInputLayerBias(bool value);
	void Use_AdditionalHiddenLayer1Bias(bool value);
	void Use_AdditionalHiddenLayer2Bias(bool value);

	void Change_Seed(uint64_t seed);

	CNeuralNet* Get_Best_Evolved_NeuralNet(void);
	void Get_Best_Evolved_NeuralNet_Ext(CNeuralNet* pOutNeuralNet);
	void Get_HiddenNeuronNumbers_Of_Best_Evolved_NeuralNet(uint32_t *pNumOfHiddenNeuronsL1, uint32_t *pNumOfHiddenNeuronsL2);

	void Round_OutputWeights(float precision);

	void Replace_WorstFitted_Brain(float probabilityValue);
	void Replace_SecondWorstFitted_Brain(float probabilityValue);
	void Replace_ThirdWorstFitted_Brain(float probabilityValue);

	void Restore_ConnectionTopology_WorstFitted_Brain(float minSynapticPlasticity, float maxSynapticPlasticity);
	void Restore_ConnectionTopology_SecondWorstFitted_Brain(float minSynapticPlasticity, float maxSynapticPlasticity);
	void Restore_ConnectionTopology_ThirdWorstFitted_Brain(float minSynapticPlasticity, float maxSynapticPlasticity);

	void RandomChange_OutputSynapsePlasticities(uint64_t seed, float minSynapticPlasticity, float maxSynapticPlasticity);
	void RandomChange_OutputSynapsePlasticities(uint64_t seed, float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRate);

	void RandomChange_OutputSynapsePlasticities(float minSynapticPlasticity, float maxSynapticPlasticity);
	void RandomChange_OutputSynapsePlasticities(float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRate);

	void RandomChange_ConnectionTopologies(uint64_t seed, float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRateL1, float mutationRateL2, float mutationRateL3, bool reduceNeuralConnections);
	void RandomChange_ConnectionTopologies(float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRateL1, float mutationRateL2, float mutationRateL3, bool reduceNeuralConnections);


	void Update_Population(float *pFitnessValueArray);
	void Update_Population_Ext(float *pFitnessValueArray);

	void Update_Evolution_Combine_BestTwoBrains(void);
	void Update_Evolution_Combine_BestTwoBrains_Ext(void);

	void Update_Evolution_Combine_TwoBrains(void);
	void Update_Evolution_Combine_TwoBrains_Ext(void);

	void Update_Evolution_ConnectionTopologyMutationsOnly(float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRateL1, float mutationRateL2, float mutationRateL3, bool reduceNeuralConnections);

	void Update_Evolution_SynapticPlasticityMutationsOnly(float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRate, bool extremeLearning);

	void Update_Evolution_SynapticPlasticityMutationsOnly(float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRateL1, float mutationRateL2, float mutationRateL3, bool extremeLearning);

	void Update_Evolution_SynapticPlasticityMutationsOnly(float minSynapticPlasticityL1, float maxSynapticPlasticityL1, float mutationRateL1,
		float minSynapticPlasticityL2, float maxSynapticPlasticityL2, float mutationRateL2,
		float minSynapticPlasticityL3, float maxSynapticPlasticityL3, float mutationRateL3, bool extremeLearning);

	void Update_Evolution_BestBrainOnly(float minSynapticPlasticityVariance, float maxSynapticPlasticityVariance, float mutationRate);

	void Update_Evolution_BestBrainOnly(float minSynapticPlasticityVariance, float maxSynapticPlasticityVariance, float mutationRateL1, float mutationRateL2, float mutationRateL3);

	void Update_Evolution_BestBrainOnly_Ext(float minSynapticPlasticityVariance, float maxSynapticPlasticityVariance, float mutationRate);

	void Update_Evolution_BestBrainOnly_Ext(float minSynapticPlasticityVariance, float maxSynapticPlasticityVariance, float mutationRateL1, float mutationRateL2, float mutationRateL3);

	void Update_Evolution_SecondBestBrainOnly(float minSynapticPlasticityVariance, float maxSynapticPlasticityVariance, float mutationRate);

	void Update_Evolution_SecondBestBrainOnly(float minSynapticPlasticityVariance, float maxSynapticPlasticityVariance, float mutationRateL1, float mutationRateL2, float mutationRateL3);

	void Update_Evolution_SecondBestBrainOnly_Ext(float minSynapticPlasticityVariance, float maxSynapticPlasticityVariance, float mutationRate);

	void Update_Evolution_SecondBestBrainOnly_Ext(float minSynapticPlasticityVariance, float maxSynapticPlasticityVariance, float mutationRateL1, float mutationRateL2, float mutationRateL3);

private:

	void Reinitialize_NeuralNet(uint32_t brainID, uint32_t numOfHiddenNeuronsL1, uint32_t numOfHiddenNeuronsL2);
	
};


class CNeuralNetPopulationExt
{
public:

	uint64_t Seed = 1;
	CRandomNumbersNN RandomNumbers;

	uint32_t PopulationSize;
	uint32_t PopulationSizePlus4;

	CNeuralNet **ppUsedNeuralNetArray = nullptr;

	float *pFitnessScoreArray = nullptr;

	static constexpr uint32_t constNumOfBestFittedBrains = 10;
	uint32_t IDArrayOfBestFittedBrains[constNumOfBestFittedBrains];
	float FitnessArrayOfBestFittedBrains[constNumOfBestFittedBrains];

	static constexpr uint32_t constNumOfWorstFittedBrains = 10;
	uint32_t IDArrayOfWorstFittedBrains[constNumOfWorstFittedBrains];
	float FitnessArrayOfWorstFittedBrains[constNumOfWorstFittedBrains];

	bool UseAdditionalMutatedBestBrain = false;
	bool UseAdditionalMutatedSecondBestBrain = false;
	bool UseAdditionalBestBrainsChild = false;

	static constexpr uint32_t constNumOfRandomBrainsChilds = 1;
	bool UseAdditionalRandomBrainsChild[constNumOfRandomBrainsChilds];

	static constexpr uint32_t constNumPopulationSearchStepsMax = 3;

	uint32_t NumOfInputNeurons = 0;
	uint32_t NumOfOutputNeurons = 0;

	uint32_t MinNumOfHiddenNeuronsL1 = 0;
	uint32_t MaxNumOfHiddenNeuronsL1 = 0;
	uint32_t MinNumOfHiddenNeuronsL2 = 0;
	uint32_t MaxNumOfHiddenNeuronsL2 = 0;
	uint32_t MinNumOfHiddenNeuronsL3 = 0;
	uint32_t MaxNumOfHiddenNeuronsL3 = 0;

	pActivationFunc pOutputNeuronActivationFunc = nullptr;
	pActivationFunc pHiddenLayer1NeuronActivationFunc = nullptr;
	pActivationFunc pHiddenLayer2NeuronActivationFunc = nullptr;
	pActivationFunc pHiddenLayer3NeuronActivationFunc = nullptr;

	bool UseAdditionalInputLayerBias = false;
	bool UseAdditionalHiddenLayer1Bias = false;
	bool UseAdditionalHiddenLayer2Bias = false;
	bool UseAdditionalHiddenLayer3Bias = false;

	CNeuralNetPopulationExt();  
	~CNeuralNetPopulationExt(); 

	// Kopierkonstruktor l�schen:
	CNeuralNetPopulationExt(const CNeuralNetPopulationExt  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CNeuralNetPopulationExt & operator=(const CNeuralNetPopulationExt  &originalObject) = delete;

	void Initialize(uint32_t populationSize, uint32_t numOfInputNeurons, uint32_t numOfOutputNeurons, uint32_t minNumOfHiddenNeuronsL1, uint32_t maxNumOfHiddenNeuronsL1, uint32_t minNumOfHiddenNeuronsL2, uint32_t maxNumOfHiddenNeuronsL2, uint32_t minNumOfHiddenNeuronsL3, uint32_t maxNumOfHiddenNeuronsL3, pActivationFunc pOutputNeuronFunc, pActivationFunc pHiddenLayer1NeuronFunc, pActivationFunc pHiddenLayer2NeuronFunc, pActivationFunc pHiddenLayer3NeuronFunc); // ok

	void Set_NeuralNet(CNeuralNet *pNeuralNet, uint32_t id);

	void Set_Activationfunction_OutputLayerNeuron(pActivationFunc pFunc); // ok
	void Set_Activationfunction_HiddenLayer1Neuron(pActivationFunc pFunc); // ok
	void Set_Activationfunction_HiddenLayer2Neuron(pActivationFunc pFunc); // ok
	void Set_Activationfunction_HiddenLayer3Neuron(pActivationFunc pFunc); // ok

	void Use_AdditionalInputLayerBias(bool value);
	void Use_AdditionalHiddenLayer1Bias(bool value);
	void Use_AdditionalHiddenLayer2Bias(bool value);
	void Use_AdditionalHiddenLayer3Bias(bool value);

	void Change_Seed(uint64_t seed); // ok

	CNeuralNet* Get_Best_Evolved_NeuralNet(void); // ok
	void Get_Best_Evolved_NeuralNet_Ext(CNeuralNet* pOutNeuralNet); // ok
	void Get_HiddenNeuronNumbers_Of_Best_Evolved_NeuralNet(uint32_t *pNumOfHiddenNeuronsL1, uint32_t *pNumOfHiddenNeuronsL2, uint32_t *pNumOfHiddenNeuronsL3); // ok

	void Round_OutputWeights(float precision); // ok

	void Replace_WorstFitted_Brain(float probabilityValue); // ok
	void Replace_SecondWorstFitted_Brain(float probabilityValue); // ok
	void Replace_ThirdWorstFitted_Brain(float probabilityValue); // ok

	void Restore_ConnectionTopology_WorstFitted_Brain(float minSynapticPlasticity, float maxSynapticPlasticity); // ok
	void Restore_ConnectionTopology_SecondWorstFitted_Brain(float minSynapticPlasticity, float maxSynapticPlasticity); // ok
	void Restore_ConnectionTopology_ThirdWorstFitted_Brain(float minSynapticPlasticity, float maxSynapticPlasticity); // ok

	void RandomChange_OutputSynapsePlasticities(uint64_t seed, float minSynapticPlasticity, float maxSynapticPlasticity); // ok
	void RandomChange_OutputSynapsePlasticities(uint64_t seed, float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRate); // ok

	void RandomChange_OutputSynapsePlasticities(float minSynapticPlasticity, float maxSynapticPlasticity); // ok
	void RandomChange_OutputSynapsePlasticities(float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRate); // ok

	void RandomChange_ConnectionTopologies(uint64_t seed, float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRateL1, float mutationRateL2, float mutationRateL3, float mutationRateL4, bool reduceNeuralConnections); // ok
	void RandomChange_ConnectionTopologies(float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRateL1, float mutationRateL2, float mutationRateL3, float mutationRateL4, bool reduceNeuralConnections); // ok


	void Update_Population(float *pFitnessValueArray);   // ok
	void Update_Population_Ext(float *pFitnessValueArray); // ok

	void Update_Evolution_Combine_BestTwoBrains(void);  // ok
	void Update_Evolution_Combine_BestTwoBrains_Ext(void); // ok

	void Update_Evolution_Combine_TwoBrains(void);   // ok
	void Update_Evolution_Combine_TwoBrains_Ext(void); // ok

	void Update_Evolution_ConnectionTopologyMutationsOnly(float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRateL1, float mutationRateL2, float mutationRateL3, float mutationRateL4, bool reduceNeuralConnections); // ok

	void Update_Evolution_SynapticPlasticityMutationsOnly(float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRate, bool extremeLearning); // ok

	void Update_Evolution_SynapticPlasticityMutationsOnly(float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRateL1, float mutationRateL2, float mutationRateL3, float mutationRateL4, bool extremeLearning); // ok

	void Update_Evolution_SynapticPlasticityMutationsOnly(float minSynapticPlasticityL1, float maxSynapticPlasticityL1, float mutationRateL1,
		float minSynapticPlasticityL2, float maxSynapticPlasticityL2, float mutationRateL2,
		float minSynapticPlasticityL3, float maxSynapticPlasticityL3, float mutationRateL3,
		float minSynapticPlasticityL4, float maxSynapticPlasticityL4, float mutationRateL4, bool extremeLearning); // ok

	void Update_Evolution_BestBrainOnly(float minSynapticPlasticityVariance, float maxSynapticPlasticityVariance, float mutationRate); // ok

	void Update_Evolution_BestBrainOnly(float minSynapticPlasticityVariance, float maxSynapticPlasticityVariance, float mutationRateL1, float mutationRateL2, float mutationRateL3, float mutationRateL4); // ok

	void Update_Evolution_BestBrainOnly_Ext(float minSynapticPlasticityVariance, float maxSynapticPlasticityVariance, float mutationRate); // ok

	void Update_Evolution_BestBrainOnly_Ext(float minSynapticPlasticityVariance, float maxSynapticPlasticityVariance, float mutationRateL1, float mutationRateL2, float mutationRateL3, float mutationRateL4); // ok

	void Update_Evolution_SecondBestBrainOnly(float minSynapticPlasticityVariance, float maxSynapticPlasticityVariance, float mutationRate); // ok

	void Update_Evolution_SecondBestBrainOnly(float minSynapticPlasticityVariance, float maxSynapticPlasticityVariance, float mutationRateL1, float mutationRateL2, float mutationRateL3, float mutationRateL4); // ok

	void Update_Evolution_SecondBestBrainOnly_Ext(float minSynapticPlasticityVariance, float maxSynapticPlasticityVariance, float mutationRate); // ok

	void Update_Evolution_SecondBestBrainOnly_Ext(float minSynapticPlasticityVariance, float maxSynapticPlasticityVariance, float mutationRateL1, float mutationRateL2, float mutationRateL3, float mutationRateL4); // ok

private:

	void Reinitialize_NeuralNet(uint32_t brainID, uint32_t numOfHiddenNeuronsL1, uint32_t numOfHiddenNeuronsL2, uint32_t numOfHiddenNeuronsL3); // ok

};










/*class CNeuronV2
{
public:

	int32_t NeuronID = -1;

	CNeuronV2 *pUsedNeuronArray = nullptr;

	pActivationFunc pActivationFunction = nullptr;

	float PosX = 0.0f;
	float PosY = 0.0f;
	float PosZ = 0.0f;

	float NeuronInput = 0.0f;
	float NeuronOutput = 0.0f;
	float NeuronOutput_LastCalculationStep = 0.0f;

	// RBF: Radial Basis Function
	bool UsedAsRBFNeuron = false;

	uint32_t NumOfRBFCentroidValues = 0;
	float *pRBFCentroidValueArray = nullptr;
	float RBFCentroidDistanceSqSum = 0.0f;
	float RBF_Factor = 1.0f;

	uint32_t RBFInputCounter = 0;

	bool Dropout = false;

	float ErrorValue = 0.0f;
	float ErrorFactor1 = 1.0f;
	float ErrorFactor2 = 1.0f;
	// Hinweis: Bei linearen Aktivierungsfunktionen sollte ErrorFactor2 kleiner als 1.0f sein (z. B. 0.5f oder 0.25f) 

	float LearningRate = 0.2f;

	CNeuronV2();
	~CNeuronV2();

	// Kopierkonstruktor l�schen:
	CNeuronV2(const CNeuronV2  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CNeuronV2 & operator=(const CNeuronV2  &originalObject) = delete;

	void Set_NeuronID(int32_t id);

	void Connect_With_Brain(CNeuronV2* pNeuronArray);

	void Set_Position(float x, float y, float z);
	float Get_Distance_to_Other_Neuron(int32_t neuronID);
	float Get_InvDistance_to_Other_Neuron(int32_t neuronID);
	float Get_DistanceSq_to_Other_Neuron(int32_t neuronID);
	float Get_InvDistanceSq_to_Other_Neuron(int32_t neuronID);

	void Set_ActivationFunction(pActivationFunc pFunc);

	void Set_DropoutState(bool state);

	void Init_RBFCentroid(uint32_t numOfRBFCentroidValues);
	void Set_RBFCentroidValues(float rBF_Factor, float *pValueArray);

	void Reset_NeuronInput(void);
	void Reset_NeuronOutput(void);
	float Get_NeuronInput(void);
	void Set_NeuronInput(float value);
	void Add_NeuronInput(float value);

	void Set_LearningRate(float learningRate);

	// Hinweis: Bei linearen Aktivierungsfunktionen sollte ErrorFactor2 kleiner als 1.0f sein (z. B. 0.5f, 0.25f, 0.01f) 
	void Set_ErrorFactors(float factor1, float factor2);

	void Clone_Data(const CNeuronV2 &originalObject);
	void Clone(const CNeuronV2 &originalObject);

	void Update_NeuronInput(float value);

	void Use_As_RBFNeuron(void);
	void Use_As_StandardNeuron(void);

	void Calculate_NeuronOutput(void);
	void Calculate_NeuronOutput_Retain_NeuronInput(void);

	// Weiterleitung des Signals an s�mtliche Receiver-Neuronen (nachgeschaltete Neuronen):
	void Propagate_SynapticOutput(CNeuralConnections *pNeuralConnections);

	float Calculate_Error(float desiredNeuronOutput);

	
	void Calculate_Error(CNeuralConnections *pNeuralConnections);

	// Anpassung der Synapsen-Pastizit�t unter Ber�cksichtigung der zuvor berechneten Fehlerwerte:
	void Adjust_OutputSynapses_AfterErrorCalculations(CNeuralConnections *pNeuralConnections);
};
*/


class CNeuronLayer
{
public:

	int32_t NumOfNeurons = 0;
	CNeuron *pNeuronArray = nullptr;

	CNeuronLayer();
	~CNeuronLayer();

	// Kopierkonstruktor l�schen:
	CNeuronLayer(const CNeuronLayer  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CNeuronLayer & operator=(const CNeuronLayer  &originalObject) = delete;

	void Initialize(int32_t numOfNeurons);
};

// Definition eines Funktionszeiger-Typs:
typedef float(*pOutputActivationFunc)(float neuronInput);

class COutputLayer
{
public:

	int32_t NumOfElements = 0;

	float *pNeuronValueArray = nullptr;
	float *pModifiedNeuronValueArray = nullptr;
	float *pErrorValueArray = nullptr;

	pOutputActivationFunc pActivationFunction = nullptr;

	COutputLayer();
	~COutputLayer();

	// Kopierkonstruktor l�schen:
	COutputLayer(const COutputLayer  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	COutputLayer & operator=(const COutputLayer  &originalObject) = delete;

	void Set_ActivationFunction(pOutputActivationFunc pFunc);

	void Initialize(int32_t numOfElements);
	void Reset_InputValues(void);
	void Add_InputValues(float *pValueArray);
	void Add_InputValues(CNeuron *pNeuron);

	void Calculate_Output(pOutputActivationFunc pFunc);
	void Calculate_Output(void);

	void Calculate_Input(CNeuron *pNeuronArray, int32_t numOfNeurons);
	void Calculate_Input(CNeuronLayer *pNeuronLayer);

	float Calculate_ErrorValues(float *pInDesiredValueArray, float errorFactor1 = 1.0f, float errorFactor2 = 1.0f);
	float Calculate_ErrorValues(float *pOutVarianceArray, float *pInDesiredValueArray, float errorFactor1 = 1.0f, float errorFactor2 = 1.0f);

	void Calculate_PrecedingNeuronErrorValues(CNeuron *pNeuron, float errorFactor1 = 1.0f, float errorFactor2 = 1.0f);
	void Calculate_PrecedingNeuronErrorValues(CNeuron *pNeuronArray, int32_t numOfNeurons, float errorFactor1 = 1.0f, float errorFactor2 = 1.0f);
	void Calculate_PrecedingNeuronErrorValues(CNeuronLayer *pNeuronLayer, float errorFactor1 = 1.0f, float errorFactor2 = 1.0f);

	void Adjust_PrecedingNeuronOutputSynapses_AfterErrorCalculations(CNeuron *pNeuron, float learningRate);
	void Adjust_PrecedingNeuronOutputSynapses_AfterErrorCalculations(CNeuron *pNeuronArray, int32_t numOfNeurons, float learningRate);
	void Adjust_PrecedingNeuronOutputSynapses_AfterErrorCalculations(CNeuronLayer *pNeuronLayer, float learningRate);

	void Get_NeuronOutputValues(float *pOutValueArray);
	void Get_ModifiedNeuronOutputValues(float *pOutValueArray);

	float Get_NeuronOutputSum(float minValue, float maxValue);

	float Get_Output_Of_NeuronWithMaxOutput(void);
	float Get_Output_Of_NeuronWithMinOutput(void);

	void Get_ID_And_Output_Of_NeuronWithMaxOutput(int32_t *pOutNeuronID, float *pOutNeuronOutput);
	void Get_ID_And_Output_Of_NeuronWithMinOutput(int32_t *pOutNeuronID, float *pOutNeuronOutput);

	void Calculate_ProbabilityValues(void);
	void Calculate_NormalizedOutputValues(void);
	void Calculate_SoftmaxValues(void);
};


#endif