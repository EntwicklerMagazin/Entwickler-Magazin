#ifndef _MultiThreading_LockFree_H_
#define _MultiThreading_LockFree_H_

#include <iostream>
#include <thread>
#include <atomic>

static constexpr uint32_t
g_NumOfUsableLockFreeThreadsMax = 16;

class CLockFreeThreadManager
{
public:

	uint32_t ThreadID = 0;

	CLockFreeThreadManager() {}
	~CLockFreeThreadManager() {}

	/* Methoden, die aus dem Hauptprogramm-Thread
	heraus aufgerufen werden: */

	void Set_ThreadID(uint32_t id);
	void Unblock_Thread(void);
	void Stop_Thread(void);
	void Wait_For_Results(void);

	/* Methoden, die aus dem Worker-Thread heraus
	aufgerufen werden: */

	bool Wait_For_UnblockingSignal_And_Continue(void);
	void Task_Completed(void);
	void Set_BlockingStatus(bool status);
};

#endif
