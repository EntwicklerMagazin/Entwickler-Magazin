// Schutz vor Mehrfachdeklarationen:

#ifndef _MemoryManagement_H_
#define _MemoryManagement_H_

#include <iostream>

class C4ByteMemoryArray
{
public:

	static constexpr int32_t ConstNumOfBytesPerMemoryEntry = 4;

	int32_t MemoryArraySize = 0;
	char *pMemory = nullptr;

	C4ByteMemoryArray()
	{}

	~C4ByteMemoryArray()
	{
		delete[] pMemory;
		pMemory = nullptr;
	}

	// Kopierkonstruktor l�schen:
	C4ByteMemoryArray(const C4ByteMemoryArray &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	C4ByteMemoryArray & operator=(const C4ByteMemoryArray &originalObject) = delete;

	void Initialize(int32_t memoryArraySize)
	{
		delete[] pMemory;
		pMemory = nullptr;
		
		int32_t numMemoryEntries = memoryArraySize / ConstNumOfBytesPerMemoryEntry;

		MemoryArraySize = ConstNumOfBytesPerMemoryEntry * numMemoryEntries + ConstNumOfBytesPerMemoryEntry;

		pMemory = new (std::nothrow) char[MemoryArraySize];
	}

	void Set_Memory(float value, int32_t entryID)
	{
		memcpy(pMemory + entryID * ConstNumOfBytesPerMemoryEntry, &value, ConstNumOfBytesPerMemoryEntry);
	}

	void Set_Memory(int32_t value, int32_t entryID)
	{
		memcpy(pMemory + entryID * ConstNumOfBytesPerMemoryEntry, &value, ConstNumOfBytesPerMemoryEntry);		
	}

	void Get_Memory(float *pOutValue, int32_t entryID)
	{
		memcpy(pOutValue, pMemory + entryID * ConstNumOfBytesPerMemoryEntry, ConstNumOfBytesPerMemoryEntry);
	}

	void Get_Memory(int32_t *pOutValue, int32_t entryID)
	{
		memcpy(pOutValue, pMemory + entryID * ConstNumOfBytesPerMemoryEntry, ConstNumOfBytesPerMemoryEntry);
	}
};

class CExternal4ByteMemoryArray
{
public:

	static constexpr int32_t ConstNumOfBytesPerMemoryEntry = 4;

	int32_t MemoryArraySize = 0;
	char *pMemory = nullptr;

	CExternal4ByteMemoryArray()
	{}

	~CExternal4ByteMemoryArray()
	{}

	// Kopierkonstruktor l�schen:
	CExternal4ByteMemoryArray(const CExternal4ByteMemoryArray &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CExternal4ByteMemoryArray & operator=(const CExternal4ByteMemoryArray &originalObject) = delete;

	void Initialize(char *pExtrnalMemory, int32_t memoryArraySize)
	{
		MemoryArraySize = memoryArraySize;

		pMemory = pExtrnalMemory;
	}

	void Set_Memory(float value, int32_t entryID)
	{
		memcpy(pMemory + entryID * ConstNumOfBytesPerMemoryEntry, &value, ConstNumOfBytesPerMemoryEntry);
	}

	void Set_Memory(int32_t value, int32_t entryID)
	{
		memcpy(pMemory + entryID * ConstNumOfBytesPerMemoryEntry, &value, ConstNumOfBytesPerMemoryEntry);
	}

	void Get_Memory(float *pOutValue, int32_t entryID)
	{
		memcpy(pOutValue, pMemory + entryID * ConstNumOfBytesPerMemoryEntry, ConstNumOfBytesPerMemoryEntry);
	}

	void Get_Memory(int32_t *pOutValue, int32_t entryID)
	{
		memcpy(pOutValue, pMemory + entryID * ConstNumOfBytesPerMemoryEntry, ConstNumOfBytesPerMemoryEntry);
	}

};


class CSimpleMemoryManager
{
private:

	size_t *UnusedMemoryElementArray;

	/* Mit Hilfe der im UsageStatusArray gespeicherten Daten
	(true/false) l�sst sich sicherstellen, dass der Index
	eines freigegebenen Array-Elements nur ein einziges Mal
	im UnusedMemoryElementArray gespeichert werden kann: */
	bool *UsageStatusArray;

	size_t UnusedMemoryElementArrayID;

public:

	size_t NumMemoryElements;
	size_t NumMemoryElementsMinus1;

	CSimpleMemoryManager();
	~CSimpleMemoryManager();

	// Kopierkonstruktor l�schen:
	CSimpleMemoryManager(const CSimpleMemoryManager &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CSimpleMemoryManager& operator=(const CSimpleMemoryManager &originalObject) = delete;

	bool Initialize(size_t numMemoryElements);

	size_t Request_Unused_MemoryElementID(void);

	bool Free_Used_MemoryElement(size_t id);

	void Reset_Arrays(void);
};

struct CSimpleLinkedListElement
{
	bool Used;
	size_t PrevElementID;
	size_t NextElementID;

	CSimpleLinkedListElement() : Used(false), PrevElementID(0), NextElementID(0)
	{}

	~CSimpleLinkedListElement()
	{}
};

class CSimpleLinkedListManager
{
//private:
public:

	CSimpleLinkedListElement *LinkedListElementArray;

//public:

	size_t NumUsedListElements;
	size_t NumListElements;
	size_t NumListElementsMinus1;

	CSimpleLinkedListManager();
	~CSimpleLinkedListManager();

	// Kopierkonstruktor l�schen:
	CSimpleLinkedListManager(const CSimpleLinkedListManager &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CSimpleLinkedListManager& operator=(const CSimpleLinkedListManager &originalObject) = delete;

	bool Initialize(size_t numListElements);

	bool Init_New_ListElement(size_t elementID);

	bool Free_Used_ListElement(size_t elementID);

	size_t Get_Next_Used_ListElement(
		size_t previousListElementID
	/*first ID-Value must be 0*/);
};



class CRingBuffer
{
public:

	int32_t NumReceivedEntries;
	int32_t NumProcessedEntries;

	int32_t   NumEntriesInsideListMax;
	int32_t* EntryList;

	CRingBuffer();
	~CRingBuffer();

	// Kopierkonstruktor l�schen:
	CRingBuffer(const CRingBuffer &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CRingBuffer& operator=(const CRingBuffer &originalObject) = delete;

	void Init_Buffer(int32_t numEntriesInsideListMax);
	void Reset_Buffer(void);

	void Add_BufferEntry(int32_t value);
	bool Get_BufferEntry(int32_t* pValue);

};


class CIndexBasedDoubleLinkedListElement
{
public:

	int32_t id = 0;
	int32_t id_LeftElement = 0;
	int32_t id_RightElement = 0;

	bool inUse = false;

	void Set_ElementID(int32_t elementID)
	{
		id = elementID;
		id_LeftElement = id - 1;
		id_RightElement = id + 1;
	}
};


class COrderPreservingDoubleLinkedList
{
public:

	int32_t NumOfElements = 0;
	int32_t NumOfElementsPlus1 = 1;
	int32_t NumOfElementsPlus2 = 2;

	int32_t NumOfActiveElements = 0;

	CIndexBasedDoubleLinkedListElement *pListElementArray = nullptr;

	COrderPreservingDoubleLinkedList();
	~COrderPreservingDoubleLinkedList();

	// Kopierkonstruktor l�schen:
	COrderPreservingDoubleLinkedList(const COrderPreservingDoubleLinkedList  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	COrderPreservingDoubleLinkedList & operator=(const COrderPreservingDoubleLinkedList  &originalObject) = delete;

	void Initialize(int32_t numOfElements);

	void Deactivate_All_Elements(void);
	void Reactivate_All_Elements(void);

	void Deactivate_Element(int32_t id);
	void Reactivate_Element(int32_t id);

	int32_t Get_First_Active_ElementID(void);
	int32_t Get_Next_Active_ElementID(int32_t prevElementID);

	int32_t Get_Last_Active_ElementID(void);
	int32_t Get_Previous_Active_ElementID(int32_t nextElementID);

	int32_t Get_IDs_Of_Active_Elements(int32_t *pOutElementIDArray);
	int32_t Get_CorrectedIDs_Of_Active_Elements(int32_t *pOutElementIDArray);
};

class CIndexBasedSingleLinkedListElement
{
public:

	int32_t id = 0;
	int32_t id_RightElement = 0;

	bool inUse = false;

	void Set_ElementID(int32_t elementID)
	{
		id = elementID;
		id_RightElement = id + 1;
	}
};

class COrderPreservingSingleLinkedList
{
public:

	int32_t NumOfElements = 0;
	int32_t NumOfElementsPlus1 = 1;
	int32_t NumOfElementsPlus2 = 2;

	int32_t NumOfActiveElements = 0;

	CIndexBasedSingleLinkedListElement *pListElementArray = nullptr;

	COrderPreservingSingleLinkedList();
	~COrderPreservingSingleLinkedList();

	// Kopierkonstruktor l�schen:
	COrderPreservingSingleLinkedList(const COrderPreservingSingleLinkedList  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	COrderPreservingSingleLinkedList & operator=(const COrderPreservingSingleLinkedList  &originalObject) = delete;

	void Initialize(int32_t numOfElements);

	void Deactivate_All_Elements(void);
	void Reactivate_All_Elements(void);

	void Deactivate_Element(int32_t id);
	void Reactivate_Element(int32_t id);

	int32_t Get_First_Active_ElementID(void);
	int32_t Get_Next_Active_ElementID(int32_t prevElementID);

	int32_t Get_IDs_Of_Active_Elements(int32_t *pOutElementIDArray);
	int32_t Get_CorrectedIDs_Of_Active_Elements(int32_t *pOutElementIDArray);
};


#endif