#include <iostream>
#include <chrono>
#include <omp.h>
#include "NeuralNetInlineFunctions.h"

using namespace std;
using namespace chrono;

/*
int main(void)
{
	float mat[9] = { 1.0f, 1.0f, 8.0f,
		             6.0f, 4.0f, 7.0f,
		             3.0f, 2.0f, 1.0f };

	float matTranspose[9];

	TransposeMatrix2(matTranspose, mat, 3, 3);

	for (int32_t iy = 0; iy < 3; iy++)
	{
		for (int32_t ix = 0; ix < 3; ix++)
		{
			cout << matTranspose[ix + iy * 3] << " ";
		}
		cout << endl;
	}

	cout << endl;

	getchar();
	return 0;
}
*/

/*
int main(void)
{
	float mat[6] = { 1.0f, 7.0f,
		             6.0f, 4.0f,
		             3.0f, 2.0f };

	float matTranspose[6];

	TransposeMatrix2(matTranspose, mat, 2, 3);

	for (int32_t iy = 0; iy < 2; iy++)
	{
		for (int32_t ix = 0; ix < 3; ix++)
		{
			cout << matTranspose[ix + iy * 3] << " ";
		}
		cout << endl;
	}

	cout << endl;

	getchar();
	return 0;
}
*/

/*
int main(void)
{
	float mat[6] = { 1.0f, 7.0f, 6.0f,
		             4.0f, 3.0f, 2.0f };

	float matTranspose[6];

	TransposeMatrix2(matTranspose, mat, 3, 2);

	for (int32_t iy = 0; iy < 3; iy++)
	{
		for (int32_t ix = 0; ix < 2; ix++)
		{
			cout << matTranspose[ix + iy * 2] << " ";
		}
		cout << endl;
	}

	cout << endl;

	getchar();
	return 0;
}
*/



/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	static constexpr int32_t constVectorSize = 200;
	static constexpr int32_t constMatrixSize = constVectorSize * constVectorSize;


	static float mat1[constMatrixSize];
	static float mat2[constMatrixSize];
	static float mat3[constMatrixSize];
	static float matTranspose[constMatrixSize];

	for (int32_t i = 0; i < constMatrixSize; i++)
	{
		mat1[i] = RandomNumbers.Get_FloatNumber_IncludingZero(-1.0f, 1.0f);
		mat2[i] = RandomNumbers.Get_FloatNumber_IncludingZero(-1.0f, 1.0f);
	}

	TransposeMatrix(matTranspose, mat2, constVectorSize, constVectorSize);

	//auto last_timepoint = std::chrono::steady_clock::now();
	auto start_timepoint = steady_clock::now();


	//MatrixMultiplication(mat3, mat1, constVectorSize, constVectorSize, mat2, constVectorSize, constVectorSize);
	//MatrixMultiplication(mat3, mat1, matTranspose, constVectorSize, constVectorSize, constMatrixSize);
	MatrixMultiplication_OMP(mat3, mat1, matTranspose, constVectorSize, constVectorSize, constMatrixSize);

	auto end_timepoint = steady_clock::now();

	chrono::duration<float> duration = end_timepoint - start_timepoint;

	
	cout << duration.count() << endl;

	getchar();
	return 0;
}
*/

/*
int main(void)
{
	float mat1[9] = {1.0f, 2.0f, 3.0f,
	                 3.0f, 4.0f, 2.0f,
	                 3.0f, 2.0f, 1.0f};

	float mat2[9] = {1.0f, 1.0f, 8.0f,
	                 6.0f, 4.0f, 7.0f,
	                 3.0f, 2.0f, 1.0f};

	float mat3[9];
	float matTranspose[9];

	MatrixMultiplication(mat3, mat1, 3, 3, mat2, 3, 3);

	for (int32_t iy = 0; iy < 3; iy++)
	{
		for (int32_t ix = 0; ix < 3; ix++)
		{
			cout << mat3[ix + iy * 3] << " ";
		}
		cout << endl;
	}

	cout << endl;


	TransposeMatrix(matTranspose, mat2, 3, 3);
	//MatrixMultiplication(mat3, mat1, matTranspose, 3, 3, 9);
	MatrixMultiplication2(mat3, mat1, mat2, 3, 3, 9);

	for (int32_t iy = 0; iy < 3; iy++)
	{
		for (int32_t ix = 0; ix < 3; ix++)
		{
			cout << mat3[ix + iy * 3] << " ";
		}
		cout << endl;
	}

	cout << endl;


	getchar();
	return 0;
}
*/

/*
int main(void)
{
	float mat1[9] = { 1.0f, 2.0f, 3.0f,
		              3.0f, 4.0f, 2.0f,
		              3.0f, 2.0f, 1.0f };

	float mat2[6] = { 6.0f, 1.0f,
		              3.0f, 4.0f,
		              5.0f, 2.0f };

	float mat3[6];
	float matTranspose[6];

	MatrixMultiplication(mat3, mat1, 3, 3, mat2, 2, 3);

	for (int32_t iy = 0; iy < 3; iy++)
	{
		for (int32_t ix = 0; ix < 2; ix++)
		{
			cout << mat3[ix + iy * 2] << " ";
		}
		cout << endl;
	}

	cout << endl;

	TransposeMatrix(matTranspose, mat2, 2, 3);

	//MatrixMultiplication(mat3, mat1, matTranspose, 3, 2, 6);
	MatrixMultiplication2(mat3, mat1, mat2, 3, 2, 6);

	for (int32_t iy = 0; iy < 3; iy++)
	{
		for (int32_t ix = 0; ix < 2; ix++)
		{
			cout << mat3[ix + iy * 2] << " ";
		}
		cout << endl;
	}

	cout << endl;


	getchar();
	return 0;
}
*/

/*
int main(void)
{
	float mat1[9] = { 1.0f, 2.0f, 3.0f,
		              3.0f, 4.0f, 2.0f,
		              3.0f, 2.0f, 1.0f };

	float mat2[3] = { 3.0f,
		              4.0f,
		              2.0f};

	float mat3[3];
	float matTranspose[3];

	MatrixMultiplication(mat3, mat1, 3, 3, mat2, 1, 3);

	for (int32_t iy = 0; iy < 3; iy++)
	{
		for (int32_t ix = 0; ix < 1; ix++)
		{
			cout << mat3[ix + iy] << " ";
		}
		cout << endl;
	}

	cout << endl;


	TransposeMatrix(matTranspose, mat2, 1, 3);

	MatrixMultiplication(mat3, mat1, matTranspose, 3, 1, 3);

	for (int32_t iy = 0; iy < 3; iy++)
	{
		for (int32_t ix = 0; ix < 1; ix++)
		{
			cout << mat3[ix + iy] << " ";
		}
		cout << endl;
	}

	cout << endl;


	getchar();
	return 0;
}
*/

/*
int main(void)
{
	float mat1[6] = { 1.0f, 2.0f, 3.0f,
		              3.0f, 4.0f, 2.0f };

	float mat2[6] = { 5.0f, 1.0f,
		              3.0f, 4.0f,
		              6.0f, 2.0f };

	float mat3[4];
	float matTranspose[6];

	MatrixMultiplication(mat3, mat1, 3, 2, mat2, 2, 3);

	for (int32_t iy = 0; iy < 2; iy++)
	{
		for (int32_t ix = 0; ix < 2; ix++)
		{
			cout << mat3[ix + iy * 2] << " ";
		}
		cout << endl;
	}

	cout << endl;


	TransposeMatrix(matTranspose, mat2, 2, 3);

	for (int32_t iy = 0; iy < 2; iy++)
	{
		for (int32_t ix = 0; ix < 3; ix++)
		{
			cout << matTranspose[ix + iy * 3] << " ";
		}
		cout << endl;
	}

	cout << endl;


	for (int32_t i = 0; i < 4; i++)
	{
		mat3[i] = 0.0f;
	}

	MatrixMultiplication(mat3, mat1, matTranspose, 3, 2, 4);

	for (int32_t iy = 0; iy < 2; iy++)
	{
		for (int32_t ix = 0; ix < 2; ix++)
		{
			cout << mat3[ix + iy * 2] << " ";
		}
		cout << endl;
	}

	cout << endl;


	getchar();
	return 0;
}
*/

/*
int main(void)
{
	omp_set_num_threads(4);
	int32_t numCpuCores = omp_get_num_procs();
	cout << numCpuCores << endl;
	int32_t maxThreads = omp_get_max_threads();
	cout << maxThreads << endl << endl;

#pragma omp parallel
	{
		if (omp_get_thread_num() == 0)
			cout << "Greetings from the master thread!! " << endl;
	}


	getchar();
	return 0;
}
*/

/*
int main(void)
{
#pragma omp parallel
	{
		int32_t numThreads = omp_get_num_threads();
		int32_t threadID = omp_get_thread_num();

#pragma omp critical
		{
			cout << "threadID: " << threadID << " ----- " << numThreads << endl;
			//printf("threadID: %d (%d)\n", threadID, numThreads);

			if (threadID == 0)
				cout << "Greetings from the master thread!! " << endl;
		}
	}

	getchar();
	return 0;
}
*/

/*
int main(void)
{
#pragma omp parallel num_threads(2)
	{
		for (int32_t i = 0; i < 4; i++)
		{
			int32_t numThreads = omp_get_num_threads();
			int32_t threadID = omp_get_thread_num();

			if (threadID == 0)
			{
				//cout << "Greetings from the master thread!! " << endl;
				cout << "threadID: " << threadID << " ----- " << numThreads << endl;
				//printf("threadID: %d (%d)\n", threadID, numThreads);
				
			} // end of if (threadID == 0)
			else if (threadID == 1)
			{
				cout << "threadID: " << threadID << " ----- " << numThreads << endl;
				//printf("threadID: %d (%d)\n", threadID, numThreads);
				
			} // end of else if (threadID == 1)
		} // end of for (int32_t i = 0; i < 5; i++)
	}

	getchar();
	return 0;
}
*/

/*
int main(void)
{
#pragma omp parallel num_threads(2)
	{
		for (int32_t i = 0; i < 4; i++)
		{
			int32_t numThreads = omp_get_num_threads();
			int32_t threadID = omp_get_thread_num();

			if (threadID == 0)
			{
#pragma omp critical
				{
					cout << "Greetings from the master thread!! " << endl;
					cout << "threadID: " << threadID << " ----- " << numThreads << endl;
					//printf("threadID: %d (%d)\n", threadID, numThreads);
				}
			} // end of if (threadID == 0)
			else if (threadID == 1)
			{
#pragma omp critical
				{
					cout << "threadID: " << threadID << " ----- " << numThreads << endl;
					//printf("threadID: %d (%d)\n", threadID, numThreads);
				}
			} // end of else if (threadID == 1)
		} // end of for (int32_t i = 0; i < 5; i++)
	}

	getchar();
	return 0;
}
*/

/*
int main(void)
{
#pragma omp parallel num_threads(2)
	{
		for (int32_t i = 0; i < 4; i++)
		{
			int32_t numThreads = omp_get_num_threads();
			int32_t threadID = omp_get_thread_num();

#pragma omp critical
			{
				if (threadID == 0)
				{
					cout << "Greetings from the master thread!! " << endl;
					cout << "threadID: " << threadID << " ----- " << numThreads << endl;
					//printf("threadID: %d (%d)\n", threadID, numThreads);

				} // end of if (threadID == 0)
				else if (threadID == 1)
				{
					cout << "threadID: " << threadID << " ----- " << numThreads << endl;
					//printf("threadID: %d (%d)\n", threadID, numThreads);

				} // end of else if (threadID == 1)
			} // end of #pragma omp critical
		} // end of for (int32_t i = 0; i < 5; i++)
	}

	getchar();
	return 0;
}
*/


/*
int main(void)
{
#pragma omp parallel num_threads(4)
	{
		int32_t numThreads = omp_get_num_threads();
		int32_t threadID = omp_get_thread_num();

#pragma omp critical
		{
			cout << "threadID: " << threadID << " ----- " << numThreads << endl;
			//printf("threadID: %d (%d)\n", threadID, numThreads);

			if (threadID == 0)
				cout << "Greetings from the master thread!! " << endl;
		}
	}

	getchar();
	return 0;
}
*/

/*
int main(void)
{
	omp_set_num_threads(4);

#pragma omp parallel
	{
		int32_t numThreads = omp_get_num_threads();
		int32_t threadID = omp_get_thread_num();

#pragma omp critical
		{
			cout << "threadID: " << threadID << " ----- " << numThreads << endl;
			//printf("threadID: %d (%d)\n", threadID, numThreads);

			if (threadID == 0)
				cout << "Greetings from the master thread!! " << endl;
		}
	}

	getchar();
	return 0;
}
*/

/*
int main(void)
{
#pragma omp parallel for
	for (int32_t i = 0; i < 16; i++)
	{
		int32_t numThreads = omp_get_num_threads();
		int32_t threadID = omp_get_thread_num();

#pragma omp critical
		{
			printf("loopID: %d, threadID: %d (%d)\n", i, threadID, numThreads);
		}
	}

	getchar();
	return 0;
}
/*/



/*
int main(void)
{
#pragma omp parallel for num_threads(4)
	for (int32_t i = 0; i < 16; i++)
	{
		int32_t numThreads = omp_get_num_threads();
		int32_t threadID = omp_get_thread_num();

#pragma omp critical
		{
			printf("loopID: %d, threadID: %d (%d)\n", i, threadID, numThreads);
		}
	}

	getchar();
	return 0;
}
*/


/*
int main(void)
{
	int32_t sum1 = 0;
	int32_t sum2 = 0;

#pragma omp parallel for num_threads(4) shared(sum1, sum2) 
	for (int32_t i = 0; i < 16; i++)
	{
#pragma omp critical
		{
			sum1 += 1;
			sum2 += 2;
		}
	}

	cout << endl << "sum1: " << sum1 << endl;
	cout << "sum2: " << sum2 << endl;

	getchar();
	return 0;
}
*/

/*
int main(void)
{
	int32_t sum1 = 0;
	int32_t sum2 = 0;

#pragma omp parallel for num_threads(4) shared(sum1, sum2) 
	for (int32_t i = 0; i < 16; i++)
	{
#pragma omp atomic
		sum1 += 1;
#pragma omp atomic
		sum2 += 2;
	}

	cout << endl << "sum1: " << sum1 << endl;
	cout << "sum2: " << sum2 << endl;

	getchar();
	return 0;
}
*/

/*
int main(void)
{
	int32_t sum1 = 0;
	int32_t sum2 = 0;

#pragma omp parallel for num_threads(4) reduction(+: sum1, sum2)
	for (int32_t i = 0; i < 16; i++)
	{
		sum1 += 1;
		sum2 += 2;
	}

	cout << endl << "sum1: " << sum1 << endl;
	cout << "sum2: " << sum2 << endl;

	getchar();
	return 0;
}
*/


/*
int main(void)
{
	static int32_t ValueArray[12] = { 0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22 };

	int32_t SizeX = 4;
	int32_t SizeY = 3;
	int32_t SizeXY = SizeX * SizeY;

	// Parallelisierung der �u�eren for-Schleife;

//#pragma omp parallel for num_threads(2)
#pragma omp parallel for

	for (int32_t iy = 0; iy < SizeY; iy++)
	{
		int32_t iiy = iy * SizeX;

		for (int32_t ix = 0; ix < SizeX; ix++)
		{
			int32_t id = ix + iiy;
			int32_t value = ValueArray[id];
			printf("ix: %d, iy: %d, id: %d v: %d (%d)\n", ix, iy, id, value, omp_get_thread_num());
		}
	}

	printf("\n");

	getchar();

	// Parallelisierung sowohl der �u�eren als auch der inneren for-Schleife
//#pragma omp parallel for num_threads(2)
#pragma omp parallel for

	for (int32_t id = 0; id < SizeXY; id++)
	{
		int32_t ix = id % SizeX;

		//if (ix == 0)
			//continue;

		int32_t iy = id / SizeX;

		//if (iy == 0)
			//continue;

		int32_t value = ValueArray[id];
		printf("ix: %d, iy: %d, id: %d v: %d (%d)\n", ix, iy, id, value, omp_get_thread_num());
	}

	printf("\n");

    getchar();
    return 0;
}
*/


