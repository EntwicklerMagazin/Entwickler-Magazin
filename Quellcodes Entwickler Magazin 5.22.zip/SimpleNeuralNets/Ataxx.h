// Schutz vor Mehrfachdeklarationen:
#ifndef _Ataxx_H_
#define _Ataxx_H_

#include <iostream>
#include "NeuralNet_V2.h"
#include "SimpleNeuron.h"
#include "GameStateHandler.h"


/*
Begriffserkl�rungen:

Der Maximizer (Maximierer) f�hrt immer denjenigen Spielzug aus, der ihm die meisten Vorteile (hoher Punktgewinn) bringt.
Der Mimimizer (Minimierer, Gegner des Maximierers) f�hrt immer denjenigen Spielzug aus, der die Vorteile des Maximierers so gut wie m�glich
reduziert.
*/

/*
m�gliche Zusatzregel:
bewegungsunf�hige Steine wechsel Farbe oder werden neutral
*/

static constexpr int32_t ConstGameBoardSizePerDir = 7;
static constexpr int32_t ConstGameBoardSizePerDirMinus1 = ConstGameBoardSizePerDir - 1;
//static constexpr int32_t ConstGameBoardSizePerDirMinus2 = ConstGameBoardSizePerDir - 2;

static constexpr int32_t ConstGameBoardSizePerDir_PaddingSize1 = ConstGameBoardSizePerDir + 2;
static constexpr int32_t ConstGameBoardSizePerDir_PaddingSize2 = ConstGameBoardSizePerDir + 4;


static constexpr int32_t ConstGameBoardSize = ConstGameBoardSizePerDir * ConstGameBoardSizePerDir;

static constexpr int32_t ConstGameBoardSize_PaddingSize1 = ConstGameBoardSizePerDir_PaddingSize1 * ConstGameBoardSizePerDir_PaddingSize1;
static constexpr int32_t ConstGameBoardSize_PaddingSize2 = ConstGameBoardSizePerDir_PaddingSize2 * ConstGameBoardSizePerDir_PaddingSize2;


static constexpr int32_t ConstGameBoardSizeX2 = 2 * ConstGameBoardSize;

static constexpr int32_t ConstMemoryVectorSize = 7;
static constexpr int32_t ConstGameStateValuesPerMemoryValue = 14;

static constexpr int32_t ConstBinaryGameStateVectorSize = 98;


static constexpr int8_t ConstGameBoard_Empty = 0;
static constexpr int8_t ConstGameBoard_Player1 = 1;
static constexpr int8_t ConstGameBoard_Player2 = 2;
static constexpr int8_t ConstGameBoard_Obstacle = 3;


//static const int32_t ConstNumGameStateRecognitionNeuronEnsembles = 2 * 30;
static const int32_t ConstNumGameStateRecognitionNeuronEnsembles = 2 * 50;
//static const int32_t ConstNumGameStateRecognitionNeuronEnsembles = 2 * 70;
static const int32_t ConstNumGameStateRecognitionNeuronEnsemblesMinus1 = ConstNumGameStateRecognitionNeuronEnsembles - 1;


void Copy_GameData_Into_MemoryVector(float *pOutMemoryVector, int8_t *pInGameData);
void Copy_GameData_Into_BinaryGameStateVector(float *pOutBinaryGameStateVector, int8_t *pInGameData);





void Get_BinaryGameStateVector_From_MemoryVector(int8_t *pOutGameData, float *pInMemoryVector);
void Get_BinaryGameStateVector_From_MemoryVector(float *pOutGameData, float *pInMemoryVector);


// LRF: lokales rezeptives Feld

// Ermitteln, ob ein Spielstein vollst�ndig vor einem gegnerischen Angriff abgeschirmt ist (LRF-Gr��e: 3x3):
inline void AtaxxPatternRecognitionOutputFunction1A(CSimpleNeuron *pNeuron)
{
	float output = 0.0f;
	float tempValue;
	int32_t numDendrites = pNeuron->NumOfDendriteElements;

	for (int32_t i = 0; i < numDendrites; i++)
	{
		tempValue = pNeuron->pDendrite_DataArray[i] - pNeuron->pDendrite_CentroidValueArray[i];
		tempValue *= tempValue;

		output += pNeuron->pDendrite_FactorArray[i] * tempValue;
	}

	pNeuron->ActivationValue = exp(-output);
}

// Ermitteln, wie gut ein Spielstein vor einem gegnerischen Angriff abgeschirmt ist (LRF-Gr��e: 3x3):
inline void AtaxxPatternRecognitionOutputFunction1B(CSimpleNeuron *pNeuron)
{
	float output = 0.0f;
	
	int32_t numDendrites = pNeuron->NumOfDendriteElements;

	for (int32_t i = 0; i < numDendrites; i++)
	{
		output += pNeuron->pDendrite_FactorArray[i] * max(0.0f, pNeuron->pDendrite_DataArray[i]);
	}

	pNeuron->ActivationValue = output / 9.0f;

	//pNeuron->ActivationValue = 0.111f*output;
}

// Ermitteln, ob von einem Spielstein aus ein Klonzug ausgef�hrt werden kann (LRF-Gr��e: 3x3):
inline void AtaxxPatternRecognitionOutputFunction2(CSimpleNeuron *pNeuron)
{
	pNeuron->ActivationValue = 0.0f;

	// LRF-Center: no playable game-piece:
	if (pNeuron->pDendrite_DataArray[4] != 1.0f)
	{	
		return;
	}

	int32_t numDendrites = pNeuron->NumOfDendriteElements;

	for (int32_t i = 0; i < numDendrites; i++)
	{
		// clone-move possible:
		if (pNeuron->pDendrite_DataArray[i] == 0.0f)
		{
			pNeuron->ActivationValue = 1.0f;
			return;
		}
	}
}

// Ermitteln, wie viele eigene Spielsteine sich im Rahmen eines gegnerischen Klonzugs assimilieren lassen (LRF-Gr��e: 3x3):
inline void AtaxxPatternRecognitionOutputFunction3(CSimpleNeuron *pNeuron)
{
	// LRF-Center:
	float output = pNeuron->pDendrite_DataArray[4];

	/* Da die Anzahl der assimilierbaren Spielsteine kleiner als eins ist (es nichts zu assimilieren gibt),
	   kann die Funktion vorzeitig verlassen werden: */
	if (output < 1.0f)
	{
		return;
	}

	int32_t numDendrites = pNeuron->NumOfDendriteElements;

	for (int32_t i = 0; i < numDendrites; i++)
	{
		// gegnerischer Spielstein gefunden, der einen Klonzug auf das LRF-Center ausf�hren kann:
		if (pNeuron->pDendrite_DataArray[i] == -1.0f)
		{
			pNeuron->ActivationValue = max(output, pNeuron->ActivationValue);
			return;
		}
	}
}


// Ermitteln, wie viele eigene Spielsteine sich im Rahmen eines gegnerischen Sprungzugs assimilieren lassen (LRF-Gr��e: 5x5):
inline void AtaxxPatternRecognitionOutputFunction4(CSimpleNeuron *pNeuron)
{
	static int32_t IndexArray[16]  {0, 1, 2, 3, 4,
	                                5, 9,
	                                10, 14,
	                                15, 19,
	                                20, 21, 22, 23, 24};

	
	// LRF-Center:
	float output = pNeuron->pDendrite_DataArray[12];

	/* Da die Anzahl der assimilierbaren Spielsteine kleiner als eins ist (es nichts zu assimilieren gibt),
	kann die Funktion vorzeitig verlassen werden: */
	if (output < 1.0f)
	{
		return;
	}

	for (int32_t i = 0; i < 16; i++)
	{
		// gegnerischer Spielstein gefunden, der einen Sprungzug auf das LRF-Center ausf�hren kann:
		if (pNeuron->pDendrite_DataArray[IndexArray[i]] == -1.0f)
		{
			pNeuron->ActivationValue = max(output, pNeuron->ActivationValue);
			return;
		}
	}
}






inline void BinaryGameStateVectorEvaluationFunction(CSimpleNeuron *pNeuron)
{
	int32_t numDendrites = pNeuron->NumOfDendriteElements;

	float output = 0.0f;

	for (int32_t i = 0; i < numDendrites; i++)
	{
		output += pNeuron->pDendrite_CentroidValueArray[i] * pNeuron->pDendrite_DataArray[i];
	}

	pNeuron->ActivationValue = output;
}

inline void BinaryGameStateVectorEvaluationFunction2(CSimpleNeuron *pNeuron)
{
	int32_t numDendrites = pNeuron->NumOfDendriteElements;

	float output = 0.0f;

	float tempValue;

	for (int32_t i = 0; i < numDendrites; i++)
	{
		tempValue = pNeuron->pDendrite_DataArray[i] - pNeuron->pDendrite_CentroidValueArray[i];
		tempValue *= tempValue;
		output += pNeuron->pDendrite_FactorArray[i] * tempValue;
	}

	pNeuron->ActivationValue = exp(-output);
}

inline void BinaryGameStateVectorEdgeEvaluationFunction_Player1(CSimpleNeuron *pNeuron)
{
	float output = 0.0f;

	int32_t counter = 0;

	for (int32_t iy = 0; iy < ConstGameBoardSizePerDir; iy++)
	{
		for (int32_t ix = 0; ix < ConstGameBoardSizePerDir; ix++)
		{
			if (ix == 0 || ix == ConstGameBoardSizePerDirMinus1)
			{
				output += pNeuron->pDendrite_CentroidValueArray[counter] * pNeuron->pDendrite_DataArray[counter];
			}
			else if (iy == 0 || iy == ConstGameBoardSizePerDirMinus1)
			{
				output += pNeuron->pDendrite_CentroidValueArray[counter] * pNeuron->pDendrite_DataArray[counter];
			}

			counter++;
		}
	}

	pNeuron->ActivationValue = output;
}

inline void BinaryGameStateVectorEdgeEvaluationFunction_Player2(CSimpleNeuron *pNeuron)
{
	float output = 0.0f;

	int32_t counter = ConstGameBoardSize;

	for (int32_t iy = 0; iy < ConstGameBoardSizePerDir; iy++)
	{
		for (int32_t ix = 0; ix < ConstGameBoardSizePerDir; ix++)
		{
			if (ix == 0 || ix == ConstGameBoardSizePerDirMinus1)
			{
				output += pNeuron->pDendrite_CentroidValueArray[counter] * pNeuron->pDendrite_DataArray[counter];
			}
			else if (iy == 0 || iy == ConstGameBoardSizePerDirMinus1)
			{
				output += pNeuron->pDendrite_CentroidValueArray[counter] * pNeuron->pDendrite_DataArray[counter];
			}

			counter++;
		}
	}

	pNeuron->ActivationValue = output;
}



class CInitialAtaxxBoards
{
public:

	int32_t NumOfInitialAtaxxBoards = 0;
	CGameStateValues *pInitialGameStateArray = nullptr;

	CInitialAtaxxBoards();
	~CInitialAtaxxBoards();

	// Kopierkonstruktor l�schen:
	CInitialAtaxxBoards(const CInitialAtaxxBoards  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CInitialAtaxxBoards & operator=(const CInitialAtaxxBoards  &originalObject) = delete;

	bool Initialize(const char* pFilename);
};

class CAtaxxBoardEvaluator
{
public:

	CSimpleNeuron RecognitionNeuronArray[5];

	float AI_Param1 = 1.0f;
	float AI_Param2 = 1.5f;
	float AI_Param3 = 2.0f;
	float AI_Param4 = 1.0f;
	float AI_Param5 = 1.5f;
	float AI_Param6 = 1.0f;
	float AI_Param7 = 0.75f;

	CAtaxxBoardEvaluator();
	~CAtaxxBoardEvaluator();

	// Kopierkonstruktor l�schen:
	CAtaxxBoardEvaluator(const CAtaxxBoardEvaluator  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CAtaxxBoardEvaluator & operator=(const CAtaxxBoardEvaluator  &originalObject) = delete;

	float Evaluate_Player1(CGameStateValues *pGameState);
	float Evaluate_Player2(CGameStateValues *pGameState);

	static float NeuralNetGameStateVectorPaddingSize1[ConstGameBoardSize_PaddingSize1];
	static float NeuralNetGameStateVectorPaddingSize2[ConstGameBoardSize_PaddingSize2];

private:

	// Notwendig f�r die Analyse, welche Spielsteine vor einer m�glichen Assimilierung gesch�tzt sind: 
	void Copy_GameData_Into_Player1Analysis1_NeuralNetVector_PaddingSize1(int8_t *pInGameData);
	// Notwendig f�r die Analyse, welche Spielsteine vor einer m�glichen Assimilierung gesch�tzt sind: 
	void Copy_GameData_Into_Player2Analysis1_NeuralNetVector_PaddingSize1(int8_t *pInGameData);

	// Notwendig f�r die Analyse, ob ein Klonzug m�glich ist oder nicht:
	void Copy_GameData_Into_Player1Analysis2_NeuralNetVector_PaddingSize1(int8_t *pInGameData);
	// Notwendig f�r die Analyse, ob ein Klonzug m�glich ist oder nicht:
	void Copy_GameData_Into_Player2Analysis2_NeuralNetVector_PaddingSize1(int8_t *pInGameData);

	// Notwendig f�r die Analyse, wie viele Spielsteine nach einem gegnerischen Spielzug assimliert werden k�nnen: 
	void Copy_GameData_Into_Player1Analysis_NeuralNetVector_PaddingSize2(int8_t *pInGameData);
	// Notwendig f�r die Analyse, wie viele Spielsteine nach einem gegnerischen Spielzug assimliert werden k�nnen: 
	void Copy_GameData_Into_Player2Analysis_NeuralNetVector_PaddingSize2(int8_t *pInGameData);
};









extern int32_t g_MaxSearchDepth_Minimax;
extern int32_t g_MaxSearchDepth_MinimaxP1;
extern int32_t g_MaxSearchDepth_MinimaxP2;
                                                   
static constexpr int32_t ConstMaxEvaluationScore_Minimax = 1000000;
static constexpr int32_t ConstMinEvaluationScore_Minimax = -1000000;

void Init_GameBoard_WithoutObstacles(int8_t *pInOutGameData);
void Init_GameBoard(int8_t *pInOutGameData, CInitialAtaxxBoards *pInitialAtaxxBoards, int32_t boardID);

void Clone_GameBoard(int8_t *pOutGameData, int8_t *pInGameData);

void Calculate_Score(int32_t *pOutPlayer1Score, int32_t *pOutPlayer2Score, int8_t *pInGameData);
void Calculate_Player1Score(int32_t *pOutPlayer1Score, int8_t *pInGameData);
void Calculate_Player2Score(int32_t *pOutPlayer2Score, int8_t *pInGameData);

bool Check_PossiblePlayer1Move(int32_t oldX, int32_t oldY, int32_t newX, int32_t newY, int8_t *pInGameData);
bool Check_PossiblePlayer2Move(int32_t oldX, int32_t oldY, int32_t newX, int32_t newY, int8_t *pInGameData);

bool Check_PossiblePlayer1Moves(int8_t *pInGameData);
bool Check_PossiblePlayer2Moves(int8_t *pInGameData);

bool Check_For_PossibleMove(int8_t *pInGameData);

bool Check_PossiblePlayer1CloneMove(int32_t newX, int32_t newY, int8_t *pInGameData);
bool Check_PossiblePlayer2CloneMove(int32_t newX, int32_t newY, int8_t *pInGameData);

bool Check_PossiblePlayer1CloneMove(int32_t newPosID, int8_t *pInGameData);
bool Check_PossiblePlayer2CloneMove(int32_t newPosID, int8_t *pInGameData);

bool Get_PossiblePlayer1CloneMoveStartPos(int32_t *pOutStartX, int32_t *pOutStartY, int32_t newX, int32_t newY, int8_t *pInGameData);
bool Get_PossiblePlayer2CloneMoveStartPos(int32_t *pOutStartX, int32_t *pOutStartY, int32_t newX, int32_t newY, int8_t *pInGameData);

bool Get_PossiblePlayer1CloneMoveStartPos(int32_t *pOutStartX, int32_t *pOutStartY, int32_t newPosID, int8_t *pInGameData);
bool Get_PossiblePlayer2CloneMoveStartPos(int32_t *pOutStartX, int32_t *pOutStartY, int32_t newPosID, int8_t *pInGameData);






void Make_Player1Move(int32_t oldX, int32_t oldY, int32_t newX, int32_t newY, int8_t *pInOutGameData);
void Make_Player2Move(int32_t oldX, int32_t oldY, int32_t newX, int32_t newY, int8_t *pInOutGameData);

void Make_Player1CloneMove(int32_t newX, int32_t newY, int8_t *pInOutGameData);
void Make_Player2CloneMove(int32_t newX, int32_t newY, int8_t *pInOutGameData);



bool Random_Player1(int8_t *pActualGameStateData, CRandomNumbersNN *pRandomNumbers);
bool Random_Player2(int8_t *pActualGameStateData, CRandomNumbersNN *pRandomNumbers);

bool Random_Player1(CGameStateValues* pActualGameStateObject, CRandomNumbersNN *pRandomNumbers);
bool Random_Player2(CGameStateValues* pActualGameStateObject, CRandomNumbersNN *pRandomNumbers);

bool Random_Player1(CGameStateValues* pActualGameStateObject, CRandomNumbersNN *pRandomNumbers, int32_t movementCounter, CSingleRecognitionNeuronEnsemble *pGameStateRecognitionNeuronEnsembleArray);
bool Random_Player2(CGameStateValues* pActualGameStateObject, CRandomNumbersNN *pRandomNumbers, int32_t movementCounter, CSingleRecognitionNeuronEnsemble *pGameStateRecognitionNeuronEnsembleArray);

void Random_Player1_WithoutMovementTest(int8_t *pActualGameStateData, CRandomNumbersNN *pRandomNumbers);
void Random_Player2_WithoutMovementTest(int8_t *pActualGameStateData, CRandomNumbersNN *pRandomNumbers);

void Random_Player1_WithoutMovementTest(CGameStateValues* pActualGameStateObject, CRandomNumbersNN *pRandomNumbers);
void Random_Player2_WithoutMovementTest(CGameStateValues* pActualGameStateObject, CRandomNumbersNN *pRandomNumbers);


bool ExtRandom_Player1(float AIParamScoreWeight, CGameStateValues* pActualGameStateObject, CRandomNumbersNN *pRandomNumbers, int32_t movementCounter, CAtaxxBoardEvaluator *pAtaxxBoardEvaluator, CSingleRecognitionNeuronEnsemble *pGameStateRecognitionNeuronEnsembleArray, CSimpleNeuron *pAdditionalEvaluationNeuronArray);

bool ExtRandom_Player2(float AIParamScoreWeight, CGameStateValues* pActualGameStateObject, CRandomNumbersNN *pRandomNumbers, int32_t movementCounter, CAtaxxBoardEvaluator *pAtaxxBoardEvaluator, CSingleRecognitionNeuronEnsemble *pGameStateRecognitionNeuronEnsembleArray, CSimpleNeuron *pAdditionalEvaluationNeuronArray);


float Calculate_MinGameStateMemoryVariance(int32_t *pOutBelongingNeuronID, float *pInBinaryGameStateVector, CSingleRecognitionNeuronEnsemble *pGameStateRecognitionNeuronEnsembleArray);

bool ExtRandom_Player1(float AIParamScoreWeight, CGameStateValues* pActualGameStateObject, CRandomNumbersNN *pRandomNumbers, int32_t movementCounter, CAtaxxBoardEvaluator *pAtaxxBoardEvaluator, CSingleRecognitionNeuronEnsemble *pGameStateRecognitionNeuronEnsembleArray);

bool ExtRandom_Player2(float AIParamScoreWeight, CGameStateValues* pActualGameStateObject, CRandomNumbersNN *pRandomNumbers, int32_t movementCounter, CAtaxxBoardEvaluator *pAtaxxBoardEvaluator, CSingleRecognitionNeuronEnsemble *pGameStateRecognitionNeuronEnsembleArray);


int32_t Minimax_Player1MoveEvaluation(CGameStateValues* pInActualGameState, CSimpleGameStatePool *pGameStatePool, int32_t searchDepth, int32_t searchDepthMax, bool searchForMaximum, int32_t alpha, int32_t beta);


int32_t Minimax_Player2MoveEvaluation(CGameStateValues* pInActualGameState, CSimpleGameStatePool *pGameStatePool, int32_t searchDepth, int32_t searchDepthMax, bool searchForMaximum, int32_t alpha, int32_t beta);


void Minimax_Player1(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, CSimpleGameStatePool *pGameStatePool, int32_t maxSearchDepth);

void Minimax_Player2(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, CSimpleGameStatePool *pGameStatePool, int32_t maxSearchDepth);


void ExtMinimax_Player1(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, CSimpleGameStatePool *pGameStatePool, int32_t maxSearchDepth);

void ExtMinimax_Player2(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, CSimpleGameStatePool *pGameStatePool, int32_t maxSearchDepth);




void Generate_Random_GameMoveChain_Player1(int32_t maxDepth, CGameStateValues *pInActualGameStateObject, CExtendedGameStatePool *pGameStatePool, CRandomNumbersNN *pRandomNumbers);
void Generate_Random_GameMoveChain_Player2(int32_t maxDepth, CGameStateValues *pInActualGameStateObject, CExtendedGameStatePool *pGameStatePool, CRandomNumbersNN *pRandomNumbers);


void Evaluate_LeafGameStates_Player1View(CExtendedGameStatePool *pGameStatePool);
void Evaluate_LeafGameStates_Player2View(CExtendedGameStatePool *pGameStatePool);

void Evaluate_GameStates_Player1View(CExtendedGameStatePool *pGameStatePool);
void Evaluate_GameStates_Player2View(CExtendedGameStatePool *pGameStatePool);

void Evaluate_LeafGameStates_Player1View(CGameStatePool_SimpleGameTree *pGameStatePool);
void Evaluate_LeafGameStates_Player2View(CGameStatePool_SimpleGameTree *pGameStatePool);

void Evaluate_GameStates_Player1View(CGameStatePool_SimpleGameTree *pGameStatePool);
void Evaluate_GameStates_Player2View(CGameStatePool_SimpleGameTree *pGameStatePool);


void Test_Player1(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool *pGameStatePool, int32_t numTestGameStatesMaxPerDepthLayer, int32_t maxSearchDepth);

void Test_Player1(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool *pGameStatePool, int32_t numTestGameStatesMaxPerDepthLayer, int32_t maxSearchDepth, CRandomNumbersNN *pRandomNumbers, float movementProbability_SearchDepth2, float movementProbability_SearchDepth3, float movementProbability_SearchDepth4);

void Test_Player2(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool *pGameStatePool, int32_t numTestGameStatesMaxPerDepthLayer, int32_t maxSearchDepth);

void Test_Player2(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool *pGameStatePool, int32_t numTestGameStatesMaxPerDepthLayer, int32_t maxSearchDepth, CRandomNumbersNN *pRandomNumbers, float movementProbability_SearchDepth2, float movementProbability_SearchDepth3, float movementProbability_SearchDepth4);

// ok
void Test_TrainedPlayer1(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool *pGameStatePool, int32_t numTestGameStatesMaxPerDepthLayer, int32_t maxSearchDepth, int32_t movementCounter, CSingleRecognitionNeuronEnsemble *pGameStateRecognitionNeuronEnsembleArray, CSimpleNeuron *pAdditionalEvaluationNeuronArray = nullptr);

// ok
void Test_TrainedPlayer2(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool *pGameStatePool, int32_t numTestGameStatesMaxPerDepthLayer, int32_t maxSearchDepth, int32_t movementCounter, CSingleRecognitionNeuronEnsemble *pGameStateRecognitionNeuronEnsembleArray, CSimpleNeuron *pAdditionalEvaluationNeuronArray = nullptr);


// ok
void Test_LearningPlayer1(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool *pGameStatePool, int32_t numTestGameStatesMaxPerDepthLayer, int32_t maxSearchDepth, int32_t movementCounter, CSingleRecognitionNeuronEnsemble *pGameStateRecognitionNeuronEnsembleArray, CSimpleNeuron *pAdditionalEvaluationNeuronArray = nullptr);

// ok
void Test_LearningPlayer2(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool *pGameStatePool, int32_t numTestGameStatesMaxPerDepthLayer, int32_t maxSearchDepth, int32_t movementCounter, CSingleRecognitionNeuronEnsemble *pGameStateRecognitionNeuronEnsembleArray, CSimpleNeuron *pAdditionalEvaluationNeuronArray = nullptr);

/*
void Test_Player1(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool *pGameStatePool, CRandomNumbersNN *pRandomNumbers, int32_t numTestGameStatesMaxPerDepthLayer, int32_t numOfRandomGameMoveChainsMax, int32_t maxSearchDepth_Minimax);
void Test_Player2(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool *pGameStatePool, CRandomNumbersNN *pRandomNumbers, int32_t numTestGameStatesMaxPerDepthLayer, int32_t numOfRandomGameMoveChainsMax, int32_t maxSearchDepth_Minimax);
*/

#endif