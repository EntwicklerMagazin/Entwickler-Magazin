#include <iostream>
#include "NeuralNet.h"

using namespace std;

//#define EvolutionVariant1
//#define EvolutionVariant2
//#define EvolutionVariant3
#define EvolutionVariant4


inline float LinearOutput(float neuronInput)
{
	return neuronInput;
}

class CAdaptiveMultiplierBrain2
{
public:

	uint32_t NumInputNeurons = 1;
	uint32_t NumOutputNeurons = 1;

	uint32_t NumNeurons = NumInputNeurons + NumOutputNeurons;

	uint32_t InputNeuronID = 0;
	uint32_t OutputNeuronID = 1;

	CNeuron *pNeuronArray = nullptr;

	CRandomNumbersNN RandomNumbers;

	CAdaptiveMultiplierBrain2()
	{
		pNeuronArray = new (std::nothrow) CNeuron[NumNeurons];

		for (uint32_t i = 0; i < NumNeurons; i++)
			pNeuronArray[i].Connect_With_Brain(pNeuronArray);

		pNeuronArray[InputNeuronID].Use_As_InputNeuron();
		pNeuronArray[InputNeuronID].Init_OutputSynapses(NumOutputNeurons);
		pNeuronArray[InputNeuronID].Connect_With_ReceiverNeuron(OutputNeuronID, /*SynapseID:*/ 0);
		pNeuronArray[InputNeuronID].Randomize_OutputSynapsePlasticities(&RandomNumbers, -2.0f, 2.0f);
		pNeuronArray[InputNeuronID].Set_LearningRate(0.2f);

		pNeuronArray[OutputNeuronID].Use_As_OutputNeuron();
		pNeuronArray[OutputNeuronID].Set_ActivationFunction(LinearOutput);
		pNeuronArray[OutputNeuronID].Set_ErrorFactors(1.0f, 0.025f);	
	}

	~CAdaptiveMultiplierBrain2()
	{
		delete[] pNeuronArray;
		pNeuronArray = nullptr;
	}

	// Kopierkonstruktor l�schen:
	CAdaptiveMultiplierBrain2(const CAdaptiveMultiplierBrain2 &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CAdaptiveMultiplierBrain2& operator=(const CAdaptiveMultiplierBrain2 &originalObject) = delete;


	float Calculate_Output(float input)
	{
		pNeuronArray[InputNeuronID].Set_Input(input);
		pNeuronArray[InputNeuronID].Propagate_SynapticOutput();

		pNeuronArray[OutputNeuronID].Calculate_NeuronOutput();
		return pNeuronArray[OutputNeuronID].Get_NeuronOutput();
	}

	float Learning(float desiredOutput)
	{
		float error = pNeuronArray[OutputNeuronID].Calculate_Error(desiredOutput);

		pNeuronArray[InputNeuronID].Adjust_OutputSynapses_AfterErrorCalculations();

		return error;
	}

	float Calculate_Error(float desiredOutput)
	{
		return pNeuronArray[OutputNeuronID].Calculate_Error(desiredOutput);
	}

	void RandomChange_OutputSynapsePlasticities(uint64_t newSeed, float minPlasticity, float maxPlasticity, float mutationRate)
	{
		RandomNumbers.Change_Seed(newSeed);

		uint32_t numOfOutputSynapses = pNeuronArray[InputNeuronID].NumOfOutputSynapses;

		for (uint32_t i = 0; i < numOfOutputSynapses; i++)
		{
			if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pNeuronArray[InputNeuronID].pOutputSynapsePlasticityArray[i] = RandomNumbers.Get_FloatNumber(minPlasticity, maxPlasticity);
		}
	}

	void RandomChange_OutputSynapsePlasticities2(uint64_t newSeed, float minPlasticityVariance, float maxPlasticityVariance, float mutationRate)
	{
		RandomNumbers.Change_Seed(newSeed);

		uint32_t numOfOutputSynapses = pNeuronArray[InputNeuronID].NumOfOutputSynapses;

		for (uint32_t i = 0; i < numOfOutputSynapses; i++)
		{
			if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pNeuronArray[InputNeuronID].pOutputSynapsePlasticityArray[i] += RandomNumbers.Get_FloatNumber(minPlasticityVariance, maxPlasticityVariance);
		}
	}

	void Clone_OutputSynapsePlasticities(CAdaptiveMultiplierBrain2 *pOriginalBrain)
	{
		uint32_t numOfOutputSynapses = pNeuronArray[InputNeuronID].NumOfOutputSynapses;

		for (uint32_t j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[InputNeuronID].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[InputNeuronID].pOutputSynapsePlasticityArray[j];
		}

	}

	void Clone_OutputSynapsePlasticities(CAdaptiveMultiplierBrain2 *pOriginalBrain, float variance, float mutationRate, uint64_t newSeed)
	{
		RandomNumbers.Change_Seed(newSeed);

		uint32_t numOfOutputSynapses = pNeuronArray[InputNeuronID].NumOfOutputSynapses;

		for (uint32_t j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[InputNeuronID].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[InputNeuronID].pOutputSynapsePlasticityArray[j];

			if (RandomNumbers.Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pNeuronArray[InputNeuronID].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-variance, variance);
		}
	}

	void Combine_OutputSynapsePlasticities(CAdaptiveMultiplierBrain2 *pParentBrain1, CAdaptiveMultiplierBrain2 *pParentBrain2, float minWeight1, uint64_t newSeed)
	{
		RandomNumbers.Change_Seed(newSeed);

		float weight1, weight2;

		float newPlasticity;

		uint32_t numOfOutputSynapses = pNeuronArray[InputNeuronID].NumOfOutputSynapses;

		for (uint32_t j = 0; j < numOfOutputSynapses; j++)
		{
			weight1 = RandomNumbers.Get_FloatNumber(minWeight1, 1.0f);
			weight2 = 1.0f - weight1;
			newPlasticity = weight1*pParentBrain1->pNeuronArray[InputNeuronID].pOutputSynapsePlasticityArray[j];
			newPlasticity += weight2*pParentBrain2->pNeuronArray[InputNeuronID].pOutputSynapsePlasticityArray[j];

			pNeuronArray[InputNeuronID].pOutputSynapsePlasticityArray[j] = newPlasticity;
		}
	}

}; // end of class CAdaptiveMultiplierBrain2

/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	uint64_t seed = 1;

	static constexpr uint32_t PopulationSize = 10;

	static CAdaptiveMultiplierBrain2 BrainArray[PopulationSize];

	static float errorArray[PopulationSize];


	float minPlasticity = -1.0f;
	float maxPlasticity = 1.0f;

	for (uint32_t i = 0; i < PopulationSize; i++)
		BrainArray[i].RandomChange_OutputSynapsePlasticities(seed++, minPlasticity, maxPlasticity, 1.01f);
	

	float Input1 = 0.0f;
	float Input2 = 1.0f;
	float Input3 = 2.0f;
	float Input4 = 3.0f;

	// Steigung (slope) =>  Output = slope * Input 
	float slope = 4.0f;

	

	uint32_t IdOfBestFittedNet = 0;
	uint32_t IdOfSecondBestFittedNet = 0;
	uint32_t IdOfWorstFittedNet = 0;
	uint32_t IdOfSecondWorstFittedNet = 0;


	float minError;
	float maxError;
	float secondMinError;
	float secondMaxError;

	uint32_t numGenerationsMax = 300000;
	uint32_t generation = 0;

	// start evolution:

	for (uint32_t j = 0; j < numGenerationsMax; j++)
	{
		generation++;

		for (uint32_t i = 0; i < PopulationSize; i++)
		{
			errorArray[i] = 0.0f;

			BrainArray[i].Calculate_Output(Input1);
			errorArray[i] += BrainArray[i].Calculate_Error(slope * Input1);

			BrainArray[i].Calculate_Output(Input2);
			errorArray[i] += BrainArray[i].Calculate_Error(slope * Input2);

			BrainArray[i].Calculate_Output(Input3);
			errorArray[i] += BrainArray[i].Calculate_Error(slope * Input3);

			BrainArray[i].Calculate_Output(Input4);
			errorArray[i] += BrainArray[i].Calculate_Error(slope * Input4);

		} // end of for (uint32_t i = 0; i < PopulationSize; i++)

		IdOfBestFittedNet = 0;
		IdOfSecondBestFittedNet = 0;
		IdOfWorstFittedNet = 0;
		IdOfSecondWorstFittedNet = 0;

		minError = 1000000.0f;
		maxError = -1000000.0f;
		

		for (uint32_t i = 0; i < PopulationSize; i++)
		{
			if (errorArray[i] < minError)
			{
				secondMinError = minError;
				minError = errorArray[i];
				IdOfSecondBestFittedNet = IdOfBestFittedNet;
				IdOfBestFittedNet = i;
			}
			else
			{
				if (errorArray[i] < secondMinError)
				{
					secondMinError = errorArray[i];
					IdOfSecondBestFittedNet = i;
				}
			}

			if (errorArray[i] > maxError)
			{
				secondMaxError = maxError;
				maxError = errorArray[i];
				IdOfSecondWorstFittedNet = IdOfWorstFittedNet;
				IdOfWorstFittedNet = i;
			}
			else
			{
				if (errorArray[i] > secondMaxError)
				{
					secondMaxError = errorArray[i];
					IdOfSecondWorstFittedNet = i;
				}
			}
		}

		if (minError < 0.0001f)
			break;

#ifdef EvolutionVariant1

		minPlasticity = -10.0f;
		maxPlasticity = 10.0f;

		
		for (uint32_t i = 0; i < PopulationSize; i++)
		{
			if (i == IdOfBestFittedNet)
				continue;

			if (i == IdOfSecondBestFittedNet)
				continue;

			// Mutationen bei den nicht so gut angepassten Individuen:
			BrainArray[i].RandomChange_OutputSynapsePlasticities(seed++, minPlasticity, maxPlasticity, 1.0f);
		}

#endif
#ifdef EvolutionVariant2

		for (uint32_t i = 0; i < PopulationSize; i++)
		{
			if (i != IdOfBestFittedNet && i != IdOfSecondBestFittedNet &&  i != IdOfWorstFittedNet && i != IdOfSecondWorstFittedNet)
			{
				// Paarung der am besten angepassten Individuen:
				if (RandomNumbers.Get_IntegerNumber(2, 4) == 2)
					BrainArray[i].Combine_OutputSynapsePlasticities(&BrainArray[IdOfBestFittedNet], &BrainArray[IdOfSecondBestFittedNet], 0.0f, seed++);
				else // Mutationen:
					BrainArray[i].RandomChange_OutputSynapsePlasticities(seed++, minPlasticity, maxPlasticity, 1.0f);
				//BrainArray[i].Clone_OutputSynapsePlasticities(&BrainArray[IdOfBestFittedNet], 0.001f, 1.0f, seed++);
			}
		}

		// Die am schlechtesten angepassten Individuen sterben aus und werden
		// durch mehr oder weniger stark mutierte Klone des am besten angepassten
		// Individuums ersetzt: 

		BrainArray[IdOfWorstFittedNet].Clone_OutputSynapsePlasticities(&BrainArray[IdOfBestFittedNet], 0.001f, 1.0f, seed++);
		BrainArray[IdOfSecondWorstFittedNet].Clone_OutputSynapsePlasticities(&BrainArray[IdOfBestFittedNet], 0.001f, 1.0f, seed++);

#endif
#ifdef EvolutionVariant3

		for (uint32_t i = 0; i < PopulationSize; i++)
		{
			if (i != IdOfBestFittedNet && i != IdOfSecondBestFittedNet &&  i != IdOfWorstFittedNet && i != IdOfSecondWorstFittedNet)
			{
				// Paarung der am besten angepassten Individuen:

				if (RandomNumbers.Get_IntegerNumber(2, 4) == 2)
					BrainArray[i].Combine_OutputSynapsePlasticities(&BrainArray[IdOfBestFittedNet], &BrainArray[IdOfSecondBestFittedNet], 0.0f, seed++);
				else
				{
					if (RandomNumbers.Get_IntegerNumber(2, 5) == 2)  // Mutationen:
					{
						BrainArray[i].RandomChange_OutputSynapsePlasticities(seed++, minPlasticity, maxPlasticity, 1.0f);
						//BrainArray[i].Clone_OutputSynapsePlasticities(&BrainArray[IdOfBestFittedNet], 0.001f, 1.0f, seed++);
					}
					else // zuf�llige Paarungen:
					{
						BrainArray[i].Combine_OutputSynapsePlasticities(&BrainArray[RandomNumbers.Get_UnsignedIntegerNumber(0, PopulationSize)], &BrainArray[RandomNumbers.Get_UnsignedIntegerNumber(0, PopulationSize)], 0.0f, seed++);
					}
				}
			}
		}

		// Die am schlechtesten angepassten Individuen sterben aus und werden
		// durch mehr oder weniger stark mutierte Klone des am besten angepassten
		// Individuums ersetzt: 

		BrainArray[IdOfWorstFittedNet].Clone_OutputSynapsePlasticities(&BrainArray[IdOfBestFittedNet], 0.001f, 1.0f, seed++);
		BrainArray[IdOfSecondWorstFittedNet].Clone_OutputSynapsePlasticities(&BrainArray[IdOfBestFittedNet], 0.001f, 1.0f, seed++);

#endif
#ifdef EvolutionVariant4

		for (uint32_t i = 0; i < PopulationSize; i++)
		{
			if (i == IdOfBestFittedNet || i == IdOfSecondBestFittedNet)
			{
			}

			// Die am schlechtesten angepassten Individuen sterben aus und werden
			// durch mehr oder weniger stark mutierte Klone des am besten angepassten
			// Individuums ersetzt: 

			else if (i == IdOfWorstFittedNet)
			{
				BrainArray[IdOfWorstFittedNet].Clone_OutputSynapsePlasticities(&BrainArray[IdOfBestFittedNet], 0.001f, 1.0f, seed++);
			}
			else if (i == IdOfSecondWorstFittedNet)
			{
				BrainArray[IdOfSecondWorstFittedNet].Clone_OutputSynapsePlasticities(&BrainArray[IdOfBestFittedNet], 0.001f, 1.0f, seed++);
			}
			else
			{
				if (RandomNumbers.Get_IntegerNumber(2, 6) == 2)  // Mutationen:
				{
					BrainArray[i].RandomChange_OutputSynapsePlasticities(seed++, minPlasticity, maxPlasticity, 1.0f);
				}
				else
				{
					// Paarung der am besten angepassten Individuen:

					if (RandomNumbers.Get_IntegerNumber(2, 5) == 2)
					{
						BrainArray[i].Combine_OutputSynapsePlasticities(&BrainArray[IdOfBestFittedNet], &BrainArray[IdOfSecondBestFittedNet], 0.0f, seed++);
					}
					else // zuf�llige Paarungen:
					{
						BrainArray[i].Combine_OutputSynapsePlasticities(&BrainArray[RandomNumbers.Get_UnsignedIntegerNumber(0, PopulationSize)], &BrainArray[RandomNumbers.Get_UnsignedIntegerNumber(0, PopulationSize)], 0.0f, seed++);
					}
				}
			}
		}

#endif

	} // end of for (uint32_t j = 0; j < numGenerationsMax; j++)

	// evolution completed

	// evolution statistics:

	//for (uint32_t i = 0; i < PopulationSize; i++)
		//cout << "error: " << errorArray[i] << endl;

	cout << endl;

	cout << "simulated generations: " << generation << endl;
	cout << "minimum error: " << minError << endl;
	cout << "IdOfWorstFittedNet: " << IdOfWorstFittedNet << endl;
	cout << "IdOfSecondWorstFittedNet: " << IdOfSecondWorstFittedNet << endl;
	cout << "IdOfBestFittedNet: " << IdOfBestFittedNet << endl;
	cout << "IdOfSecondBestFittedNet: " << IdOfSecondBestFittedNet << endl << endl;

	CAdaptiveMultiplierBrain2 *pBestBrain = &BrainArray[IdOfBestFittedNet];

	// neural network tests:

	cout << "input : " << Input1 << endl;
	cout << "output: " << pBestBrain->Calculate_Output(Input1) << " --- desired output: " << slope * Input1 << endl;
	// => output: 0 (desired: 0)

	cout << "input : " << Input2 << endl;
	cout << "output: " << pBestBrain->Calculate_Output(Input2) << " --- desired output: " << slope * Input2 << endl;
	// => output: 3.99814 (desired: 4)

	cout << "input : " << Input3 << endl;
	cout << "output: " << pBestBrain->Calculate_Output(Input3) << " --- desired output: " << slope * Input3 << endl;
	// => output: 7.99628  (desired: 8)

	cout << "input : " << Input4 << endl;
	cout << "output: " << pBestBrain->Calculate_Output(Input4) << " --- desired output: " << slope * Input4 << endl;
	// => output: 11.9944 (desired: 12)

	cout << "test input: " << 10.0f << endl;
	cout << "output: " << pBestBrain->Calculate_Output(10.0f) << " --- desired output: " << slope * 10.0f << endl;
	// => output: 39.9814  (desired: 40)

	getchar();
	return 0;
}
*/