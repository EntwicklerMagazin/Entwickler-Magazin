#include <iostream>
#include "NeuralNet.h"

using namespace std;

//#define EvolutionVariant1
//#define EvolutionVariant2
//#define EvolutionVariant3
#define EvolutionVariant4

inline float LinearOutput(float neuronInput)
{
	return neuronInput;
}

inline float QuadraticOutput(float neuronInput)
{
	return neuronInput * neuronInput;
}

inline float CubicOutput(float neuronInput)
{
	return neuronInput * neuronInput * neuronInput;
}


class C1DimPolynomialFunctionApproxBrain2
{
public:

	uint32_t NumHiddenNeurons = 3;
	uint32_t NumBiasNeurons = 1;
	uint32_t NumOutputNeurons = 1;

	uint32_t NumNeurons = NumHiddenNeurons + NumBiasNeurons + NumOutputNeurons;

	
	uint32_t BiasNeuronID = NumHiddenNeurons;
	uint32_t OutputNeuronID = NumNeurons - 1;

	CNeuron *pNeuronArray = nullptr;

	CRandomNumbersNN RandomNumbers;

	C1DimPolynomialFunctionApproxBrain2()
	{
		pNeuronArray = new (std::nothrow) CNeuron[NumNeurons];

		uint32_t i;

		for (i = 0; i < NumNeurons; i++)
			pNeuronArray[i].Connect_With_Brain(pNeuronArray);

		for (i = 0; i < NumHiddenNeurons; i++)
		{
			pNeuronArray[i].Use_As_HiddenNeuron();
			pNeuronArray[i].Init_OutputSynapses(NumOutputNeurons);
			pNeuronArray[i].Connect_With_ReceiverNeuron(OutputNeuronID, /*SynapseID:*/ 0);
			pNeuronArray[i].Randomize_OutputSynapsePlasticities(&RandomNumbers, -0.0001f, 0.0001f);
			pNeuronArray[i].Set_LearningRate(0.0001f);

			if (i % 3 == 0)
				pNeuronArray[i].Set_ActivationFunction(LinearOutput);
			else if (i % 3 == 1)
				pNeuronArray[i].Set_ActivationFunction(QuadraticOutput);
			else if (i % 3 == 2)
				pNeuronArray[i].Set_ActivationFunction(CubicOutput);

		}

		pNeuronArray[BiasNeuronID].Use_As_BiasNeuron();
		pNeuronArray[BiasNeuronID].Set_BiasNeuronOutput(-1.0f);
		pNeuronArray[BiasNeuronID].Init_OutputSynapses(NumOutputNeurons);
		pNeuronArray[BiasNeuronID].Connect_With_ReceiverNeuron(OutputNeuronID, /*SynapseID:*/ 0);
		pNeuronArray[BiasNeuronID].Randomize_OutputSynapsePlasticities(&RandomNumbers, -0.0001f, 0.0001f);
		pNeuronArray[BiasNeuronID].Set_LearningRate(0.01f);

		pNeuronArray[OutputNeuronID].Use_As_OutputNeuron();
		pNeuronArray[OutputNeuronID].Set_ActivationFunction(LinearOutput);
		pNeuronArray[OutputNeuronID].Set_ErrorFactors(1.0f, 0.00025f);
	}

	~C1DimPolynomialFunctionApproxBrain2()
	{
		delete[] pNeuronArray;
		pNeuronArray = nullptr;
	}

	// Kopierkonstruktor l�schen:
	C1DimPolynomialFunctionApproxBrain2(const C1DimPolynomialFunctionApproxBrain2 &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	C1DimPolynomialFunctionApproxBrain2& operator=(const C1DimPolynomialFunctionApproxBrain2 &originalObject) = delete;

	float Calculate_Output(float input)
	{
		for (uint32_t i = 0; i < NumHiddenNeurons; i++)
		{
			pNeuronArray[i].Set_NeuronInput(input);
			pNeuronArray[i].Calculate_NeuronOutput();
			pNeuronArray[i].Propagate_SynapticOutput();

		}
		

		pNeuronArray[BiasNeuronID].Propagate_SynapticOutput();

		pNeuronArray[OutputNeuronID].Calculate_NeuronOutput();
		return pNeuronArray[OutputNeuronID].Get_NeuronOutput();
	}

	float Learning(float desiredOutput)
	{
		float error = pNeuronArray[OutputNeuronID].Calculate_Error(desiredOutput);

		pNeuronArray[BiasNeuronID].Adjust_OutputSynapses_AfterErrorCalculations();

		for (uint32_t i = 0; i < NumHiddenNeurons; i++)
		{
			pNeuronArray[i].Adjust_OutputSynapses_AfterErrorCalculations();
		}
		
		return error;
	}

	float Calculate_Error(float desiredOutput)
	{
		return pNeuronArray[OutputNeuronID].Calculate_Error(desiredOutput);
	}

	void RandomChange_OutputSynapsePlasticities(uint64_t newSeed, float minPlasticity, float maxPlasticity)
	{
		RandomNumbers.Change_Seed(newSeed);

		for (uint32_t i = 0; i < NumHiddenNeurons; i++)
		{
			pNeuronArray[i].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticity, maxPlasticity);
		}

		pNeuronArray[BiasNeuronID].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticity, maxPlasticity);
		
	}

	void Clone_OutputSynapsePlasticities(C1DimPolynomialFunctionApproxBrain2 *pOriginalBrain)
	{
		uint32_t numOfOutputSynapses = pNeuronArray[BiasNeuronID].NumOfOutputSynapses;

		for (uint32_t j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[BiasNeuronID].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[BiasNeuronID].pOutputSynapsePlasticityArray[j];
		}

		for (uint32_t i = 0; i < NumHiddenNeurons; i++)
		{
			numOfOutputSynapses = pNeuronArray[i].NumOfOutputSynapses;

			for (uint32_t j = 0; j < numOfOutputSynapses; j++)
			{
				pNeuronArray[i].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[i].pOutputSynapsePlasticityArray[j];
			}
		}
	}

	void Clone_OutputSynapsePlasticities(C1DimPolynomialFunctionApproxBrain2 *pOriginalBrain, float variance, uint64_t newSeed)
	{
		RandomNumbers.Change_Seed(newSeed);

		uint32_t numOfOutputSynapses = pNeuronArray[BiasNeuronID].NumOfOutputSynapses;

		for (uint32_t j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[BiasNeuronID].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[BiasNeuronID].pOutputSynapsePlasticityArray[j];
			pNeuronArray[BiasNeuronID].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-variance, variance);
		}

		for (uint32_t i = 0; i < NumHiddenNeurons; i++)
		{
			numOfOutputSynapses = pNeuronArray[i].NumOfOutputSynapses;

			for (uint32_t j = 0; j < numOfOutputSynapses; j++)
			{
				pNeuronArray[i].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[i].pOutputSynapsePlasticityArray[j];
				pNeuronArray[i].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-variance, variance);
			}
		}
	}

	void Combine_OutputSynapsePlasticities(C1DimPolynomialFunctionApproxBrain2 *pParentBrain1, C1DimPolynomialFunctionApproxBrain2 *pParentBrain2, float minWeight1, uint64_t newSeed)
	{
		RandomNumbers.Change_Seed(newSeed);

		float weight1, weight2;

		float newPlasticity;

		uint32_t numOfOutputSynapses = pNeuronArray[BiasNeuronID].NumOfOutputSynapses;

		for (uint32_t j = 0; j < numOfOutputSynapses; j++)
		{
			weight1 = RandomNumbers.Get_FloatNumber(minWeight1, 1.0f);
			weight2 = 1.0f - weight1;
			newPlasticity = weight1*pParentBrain1->pNeuronArray[BiasNeuronID].pOutputSynapsePlasticityArray[j];
			newPlasticity += weight2*pParentBrain2->pNeuronArray[BiasNeuronID].pOutputSynapsePlasticityArray[j];

			pNeuronArray[BiasNeuronID].pOutputSynapsePlasticityArray[j] = newPlasticity;
		}

		for (uint32_t i = 0; i < NumHiddenNeurons; i++)
		{
			numOfOutputSynapses = pNeuronArray[i].NumOfOutputSynapses;

			for (uint32_t j = 0; j < numOfOutputSynapses; j++)
			{
				weight1 = RandomNumbers.Get_FloatNumber(minWeight1, 1.0f);
				weight2 = 1.0f - weight1;
				newPlasticity = weight1*pParentBrain1->pNeuronArray[i].pOutputSynapsePlasticityArray[j];
				newPlasticity += weight2*pParentBrain2->pNeuronArray[i].pOutputSynapsePlasticityArray[j];

				pNeuronArray[i].pOutputSynapsePlasticityArray[j] = newPlasticity;
			}
		}
	}

}; // end of class C1DimPolynomialFunctionApproxBrain2


/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	uint64_t seed = 1;

	static constexpr uint32_t PopulationSize = 10;

	static C1DimPolynomialFunctionApproxBrain2 BrainArray[PopulationSize];

	static float errorArray[PopulationSize];


	float minPlasticity = -1.0f;
	float maxPlasticity = 1.0f;

	for (uint32_t i = 0; i < PopulationSize; i++)
		BrainArray[i].RandomChange_OutputSynapsePlasticities(seed++, minPlasticity, maxPlasticity);

	
	static constexpr uint32_t NumInputValues = 9;

	float InputData[NumInputValues];

	InputData[0] = -4.0f;
	InputData[1] = -3.0f;
	InputData[2] = -2.0f;
	InputData[3] = -1.0f;
	InputData[4] = 0.0f;
	InputData[5] = 1.0f;
	InputData[6] = 2.0f;
	InputData[7] = 3.0f;
	InputData[8] = 4.0f;


	// Output = (a * Input * Input * Input + b * Input * Input + c * Input + offset)


	float a = 0.5f;
	float b = 0.65f;
	float c = 0.85f;
	float offset = 1.0f;

	uint32_t IdOfBestFittedNet = 0;
	uint32_t IdOfSecondBestFittedNet = 0;
	uint32_t IdOfWorstFittedNet = 0;
	uint32_t IdOfSecondWorstFittedNet = 0;


	float minError;
	float maxError;
	float secondMinError;
	float secondMaxError;

	uint32_t numGenerationsMax = 300000;
	uint32_t generation = 0;

	// start evolution:

	for (uint32_t j = 0; j < numGenerationsMax; j++)
	{
		generation++;

		for (uint32_t i = 0; i < PopulationSize; i++)
		{
			errorArray[i] = 0.0f;

			for (uint32_t k = 0; k < NumInputValues; k++)
			{
				BrainArray[i].Calculate_Output(InputData[k]);

				float desiredOutput = a * InputData[k] * InputData[k] * InputData[k] + b * InputData[k] * InputData[k] + c * InputData[k] + offset;
				errorArray[i] += BrainArray[i].Calculate_Error(desiredOutput);
			}

		} // end of for (uint32_t i = 0; i < PopulationSize; i++)

		IdOfBestFittedNet = 0;
		IdOfSecondBestFittedNet = 0;
		IdOfWorstFittedNet = 0;
		IdOfSecondWorstFittedNet = 0;

		minError = 1000000.0f;
		maxError = -1000000.0f;


		for (uint32_t i = 0; i < PopulationSize; i++)
		{
			if (errorArray[i] < minError)
			{
				secondMinError = minError;
				minError = errorArray[i];
				IdOfSecondBestFittedNet = IdOfBestFittedNet;
				IdOfBestFittedNet = i;
			}
			else
			{
				if (errorArray[i] < secondMinError)
				{
					secondMinError = errorArray[i];
					IdOfSecondBestFittedNet = i;
				}
			}

			if (errorArray[i] > maxError)
			{
				secondMaxError = maxError;
				maxError = errorArray[i];
				IdOfSecondWorstFittedNet = IdOfWorstFittedNet;
				IdOfWorstFittedNet = i;
			}
			else
			{
				if (errorArray[i] > secondMaxError)
				{
					secondMaxError = errorArray[i];
					IdOfSecondWorstFittedNet = i;
				}
			}
		}

		if (minError < 0.001f)
			break;

#ifdef EvolutionVariant1

		for (uint32_t i = 0; i < PopulationSize; i++)
		{
			if (i != IdOfBestFittedNet && i != IdOfSecondBestFittedNet)
			{
				BrainArray[i].RandomChange_OutputSynapsePlasticities(seed++, minPlasticity, maxPlasticity);
			}
		}

#endif
#ifdef EvolutionVariant2

		for (uint32_t i = 0; i < PopulationSize; i++)
		{
			if (i != IdOfBestFittedNet && i != IdOfSecondBestFittedNet &&  i != IdOfWorstFittedNet && i != IdOfSecondWorstFittedNet)
			{
				if (RandomNumbers.Get_IntegerNumber(2, 4) == 2)
					BrainArray[i].Combine_OutputSynapsePlasticities(&BrainArray[IdOfBestFittedNet], &BrainArray[IdOfSecondBestFittedNet], 0.0f, seed++);
				else // Mutationen:
					BrainArray[i].RandomChange_OutputSynapsePlasticities(seed++, minPlasticity, maxPlasticity);
				//BrainArray[i].Clone_OutputSynapsePlasticities(&BrainArray[IdOfBestFittedNet], 0.001f, seed++);
			}
		}

		BrainArray[IdOfWorstFittedNet].Clone_OutputSynapsePlasticities(&BrainArray[IdOfBestFittedNet], 0.001f, seed++);
		BrainArray[IdOfSecondWorstFittedNet].Clone_OutputSynapsePlasticities(&BrainArray[IdOfBestFittedNet], 0.001f, seed++);

#endif
#ifdef EvolutionVariant3

		for (uint32_t i = 0; i < PopulationSize; i++)
		{
			if (i != IdOfBestFittedNet && i != IdOfSecondBestFittedNet &&  i != IdOfWorstFittedNet && i != IdOfSecondWorstFittedNet)
			{
				if (RandomNumbers.Get_IntegerNumber(2, 4) == 2)
					BrainArray[i].Combine_OutputSynapsePlasticities(&BrainArray[IdOfBestFittedNet], &BrainArray[IdOfSecondBestFittedNet], 0.0f, seed++);
				else
				{
					if (RandomNumbers.Get_IntegerNumber(2, 5) == 2)  // Mutationen:																
					{
						BrainArray[i].RandomChange_OutputSynapsePlasticities(seed++, minPlasticity, maxPlasticity);
						//BrainArray[i].Clone_OutputSynapsePlasticities(&BrainArray[IdOfBestFittedPlayer], 0.001f, seed++);
					}
					else
					{
						BrainArray[i].Combine_OutputSynapsePlasticities(&BrainArray[RandomNumbers.Get_UnsignedIntegerNumber(0, PopulationSize)], &BrainArray[RandomNumbers.Get_UnsignedIntegerNumber(0, PopulationSize)], 0.0f, seed++);
					}
				}
			}
		}

		BrainArray[IdOfWorstFittedNet].Clone_OutputSynapsePlasticities(&BrainArray[IdOfBestFittedNet], 0.001f, seed++);
		BrainArray[IdOfSecondWorstFittedNet].Clone_OutputSynapsePlasticities(&BrainArray[IdOfBestFittedNet], 0.001f, seed++);

#endif
#ifdef EvolutionVariant4

		for (uint32_t i = 0; i < PopulationSize; i++)
		{
			if (i == IdOfBestFittedNet || i == IdOfSecondBestFittedNet)
			{
			}
			else if (i == IdOfWorstFittedNet)
			{
				BrainArray[IdOfWorstFittedNet].Clone_OutputSynapsePlasticities(&BrainArray[IdOfBestFittedNet], 0.001f, seed++);
			}
			else if (i == IdOfSecondWorstFittedNet)
			{
				BrainArray[IdOfSecondWorstFittedNet].Clone_OutputSynapsePlasticities(&BrainArray[IdOfBestFittedNet], 0.001f, seed++);
			}
			else
			{
				if (RandomNumbers.Get_IntegerNumber(2, 6) == 2)  // Mutationen:
				{
					BrainArray[i].RandomChange_OutputSynapsePlasticities(seed++, minPlasticity, maxPlasticity);
				}
				else
				{
					if (RandomNumbers.Get_IntegerNumber(2, 5) == 2)
					{
						BrainArray[i].Combine_OutputSynapsePlasticities(&BrainArray[IdOfBestFittedNet], &BrainArray[IdOfSecondBestFittedNet], 0.0f, seed++);
					}
					else
					{
						BrainArray[i].Combine_OutputSynapsePlasticities(&BrainArray[RandomNumbers.Get_UnsignedIntegerNumber(0, PopulationSize)], &BrainArray[RandomNumbers.Get_UnsignedIntegerNumber(0, PopulationSize)], 0.0f, seed++);
					}
				}
			}
		}

#endif

	} // end of for (uint32_t j = 0; j < numGenerationsMax; j++)

	  // evolution completed

	  // evolution statistics:

	  //for (uint32_t i = 0; i < PopulationSize; i++)
	  //cout << "error: " << errorArray[i] << endl;

	cout << endl;

	cout << "simulated generations: " << generation << endl;
	cout << "minimum error: " << minError << endl;
	cout << "IdOfWorstFittedNet: " << IdOfWorstFittedNet << endl;
	cout << "IdOfSecondWorstFittedNet: " << IdOfSecondWorstFittedNet << endl;
	cout << "IdOfBestFittedNet: " << IdOfBestFittedNet << endl;
	cout << "IdOfSecondBestFittedNet: " << IdOfSecondBestFittedNet << endl << endl;

	C1DimPolynomialFunctionApproxBrain2 *pBestBrain = &BrainArray[IdOfBestFittedNet];

	// neural network tests:

	for (uint32_t j = 0; j < NumInputValues; j++)
	{
		cout << "input : " << InputData[j] << endl;
		cout << "output: " << pBestBrain->Calculate_Output(InputData[j]) << " --- desired output: " << a * InputData[j] * InputData[j] * InputData[j] + b * InputData[j] * InputData[j] + c * InputData[j] + offset << endl;
	}

	getchar();
	return 0;
}
*/