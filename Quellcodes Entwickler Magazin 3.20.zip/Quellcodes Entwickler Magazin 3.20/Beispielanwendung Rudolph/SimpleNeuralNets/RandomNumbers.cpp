#include "RandomNumbers.h"

//namespace HelperStuff
//{

// Konstruktor:
CRandomNumbers_ParkMillerMLKG::
CRandomNumbers_ParkMillerMLKG() : newValue(1)
{}

// Destruktor:
CRandomNumbers_ParkMillerMLKG::
~CRandomNumbers_ParkMillerMLKG()
{}

/* Neuen Startwert f�r die Berechnung der
Zufallszahlen festlegen */
void CRandomNumbers_ParkMillerMLKG::Change_Seed(
	uint64_t newSeed)
{
	newValue = newSeed;
}

/* Startwert f�r die Berechnung der Zufallszahlen
auf 1 zur�cksetzen */
void CRandomNumbers_ParkMillerMLKG::Reset_Seed(void)
{
	newValue = 1;
}

// zuf�llige 32-Bit-Flie�kommazahlen:
float CRandomNumbers_ParkMillerMLKG::
Get_FloatNumber(float low, float high)
{
	newValue = (newValue*constParkMillerMultiplier) %
		constParkMillerModulus;

	return low + (high - low)*
		((double)newValue / fconstParkMillerModulus);
}

// zuf�llige 64-Bit-Flie�kommazahlen:
double CRandomNumbers_ParkMillerMLKG::
Get_DoubleNumber(double low, double high)
{
	newValue = (newValue*constParkMillerMultiplier) %
		constParkMillerModulus;

	return low + (high - low)*
		((double)newValue / fconstParkMillerModulus);
}

// zuf�llige 32-Bit-Ganzzahlen:
int32_t CRandomNumbers_ParkMillerMLKG::
Get_IntegerNumber(int32_t low,
	int32_t high_excluded)
{
	newValue = (newValue*constParkMillerMultiplier) %
		constParkMillerModulus;

	int32_t tempVal = low + (high_excluded - low)*
		((double)newValue / fconstParkMillerModulus);

	if (tempVal < high_excluded)
		return tempVal;
	else
		return low;
}

// zuf�llige positive 32-Bit-Ganzzahlen:
uint32_t CRandomNumbers_ParkMillerMLKG::
Get_UnsignedIntegerNumber(uint32_t low,
	uint32_t high_excluded)
{
	newValue = (newValue*constParkMillerMultiplier) %
		constParkMillerModulus;

	uint32_t tempVal = low + (high_excluded - low)*
		((double)newValue / fconstParkMillerModulus);

	if (tempVal < high_excluded)
		return tempVal;
	else
		return low;
}

//} /* end of namespace HelperStuff */