#include <iostream>
//#include <chrono>
#include <thread>
#include "ConsoleHelperFunctions.h"
#include "RandomNumbers.h"
#include "NeuralNet.h"
#include "GravitationSamples.h"


using namespace std;
using namespace chrono;



#define KEYDOWN(vk_code) ((GetAsyncKeyState(vk_code) & 0x8000) ? 1 : 0)
#define KEYUP(vk_code)   ((GetAsyncKeyState(vk_code) & 0x8000) ? 0 : 1)



static char g_InputBuffer[100];


static void Set_ProcessPriority(unsigned long priority)
{
	HANDLE ProcessHandle = GetCurrentProcess();

	if (priority == 0)
		SetPriorityClass(ProcessHandle, NORMAL_PRIORITY_CLASS);
	else if (priority == 1)
		SetPriorityClass(ProcessHandle, ABOVE_NORMAL_PRIORITY_CLASS);
	else if (priority == 2)
		SetPriorityClass(ProcessHandle, HIGH_PRIORITY_CLASS);
	else
		SetPriorityClass(ProcessHandle, REALTIME_PRIORITY_CLASS);
}



/*
int main(void)
{
	//Set_ProcessPriority(2);

	HelperStuff::Begin_Log(0, "Begin_Log", "Logfile.txt");

	CRandomNumbersNN RandomNumbers;

	CWindowsConsoleScreenBuffer WinConsole;
	WinConsole.Initialize(ConstGameBoardSizeX, ConstGameBoardSizeY, false, BackgroundColor);

	
	Set_Title("NeuralNetGravitationSample4 (neuro-evolution running ... )");
	Set_ConsolePos(10, 10);

	WinConsole.Set_CursorVisibilityAndSize(FALSE);
	//WinConsole.Set_Font(L"Consolas", 15, 15);
	WinConsole.Set_Font(L"Consolas", 4, 4);
	//WinConsole.Set_Font(L"Consolas", 8, 8);
	//WinConsole.Set_Font_Ext(L"Consolas", 90, 10, 10);
	

	//WinConsole.Set_BackgroundColor(RGB(100, 50, 25));
	WinConsole.Set_BackgroundColor(BackgroundColor);

	Set_CursorVisibilityAndSize(false);

	
	float FrameTime = 0.0f;

	CWindowsConsole2DObject LandingPlatform;
	LandingPlatform.Initialize(7, 7);

	LandingPlatform.Set_Pixel(1, 0, lightred);
	LandingPlatform.Set_Pixel(5, 0, lightred);
	LandingPlatform.Set_Pixel(2, 1, lightred);
	LandingPlatform.Set_Pixel(4, 1, lightred);
	LandingPlatform.Set_Pixel(3, 2, lightred);
	LandingPlatform.Set_Pixel(2, 3, lightred);
	LandingPlatform.Set_Pixel(4, 3, lightred);
	LandingPlatform.Set_Pixel(1, 4, lightred);
	LandingPlatform.Set_Pixel(5, 4, lightred);
	LandingPlatform.Set_Pixel(0, 6, graywhite);
	LandingPlatform.Set_Pixel(1, 6, graywhite);
	LandingPlatform.Set_Pixel(2, 6, graywhite);
	LandingPlatform.Set_Pixel(3, 6, graywhite);
	LandingPlatform.Set_Pixel(4, 6, graywhite);
	LandingPlatform.Set_Pixel(5, 6, graywhite);
	LandingPlatform.Set_Pixel(6, 6, graywhite);

	CWindowsConsole2DObject LaunchingPlatform;
	LaunchingPlatform.Initialize(7, 7);

	LaunchingPlatform.Set_Pixel(3, 0, lightaqua);
	LaunchingPlatform.Set_Pixel(2, 1, lightaqua);
	LaunchingPlatform.Set_Pixel(4, 1, lightaqua);
	LaunchingPlatform.Set_Pixel(1, 2, lightaqua);
	LaunchingPlatform.Set_Pixel(5, 2, lightaqua);
	LaunchingPlatform.Set_Pixel(3, 3, lightaqua);
	LaunchingPlatform.Set_Pixel(3, 4, lightaqua);
	LaunchingPlatform.Set_Pixel(3, 5, lightaqua);
	LaunchingPlatform.Set_Pixel(0, 6, graywhite);
	LaunchingPlatform.Set_Pixel(1, 6, graywhite);
	LaunchingPlatform.Set_Pixel(2, 6, graywhite);
	LaunchingPlatform.Set_Pixel(3, 6, graywhite);
	LaunchingPlatform.Set_Pixel(4, 6, graywhite);
	LaunchingPlatform.Set_Pixel(5, 6, graywhite);
	LaunchingPlatform.Set_Pixel(6, 6, graywhite);

	CWindowsConsole2DObject LandingModule;
	LandingModule.Initialize(5, 5);

	LandingModule.Set_Pixel(2, 0, lightgreen);
	LandingModule.Set_Pixel(1, 1, lightgreen);
	LandingModule.Set_Pixel(2, 1, lightgreen);
	LandingModule.Set_Pixel(3, 1, lightgreen);

	LandingModule.Set_Pixel(0, 2, lightgreen);
	LandingModule.Set_Pixel(1, 2, lightgreen);
	LandingModule.Set_Pixel(2, 2, lightgreen);
	LandingModule.Set_Pixel(3, 2, lightgreen);
	LandingModule.Set_Pixel(4, 2, lightgreen);

	LandingModule.Set_Pixel(0, 3, lightgreen);
	LandingModule.Set_Pixel(1, 3, graywhite);
	LandingModule.Set_Pixel(2, 3, lightred);
	LandingModule.Set_Pixel(3, 3, graywhite);
	LandingModule.Set_Pixel(4, 3, lightgreen);

	LandingModule.Set_Pixel(1, 4, graywhite);
	LandingModule.Set_Pixel(3, 4, graywhite);

	
	CLandingModuleNavigationAIPopulation LandingModuleNavigationAIPopulation;
	
	int32_t NumTrainingGenerationsMax = 200;
	int32_t NumSimpleMutationGenerations = 20;
	int32_t NumTrainingGamesPerEpoch = 20;

	int32_t TrainingPopulationSize = 200;
	
	
	//int32_t NumOfHiddenNeuronsL1 = 8;
	int32_t NumOfHiddenNeuronsL1 = 10;
	//int32_t NumOfHiddenNeuronsL1 = 20;
	int32_t NumOfHiddenNeuronsL2 = 0;
	
	

	float MinSynapticPlasticity = -2.0f;
	float MaxSynapticPlasticity = 2.0f;

	float MinSynapticPlasticityVariance = -0.0001f;
	float MaxSynapticPlasticityVariance = 0.0001f;

	bool ExtremeLearning = false;
	//bool ExtremeLearning = true;

	float PlasticityMutationRate = 0.1f;

	float PlasticityMutationRateL1 = 0.0f;
	float PlasticityMutationRateL2 = 0.0f;
	float PlasticityMutationRateL3 = 0.0f;
	

	float TopologyMutationRateL1 = 0.0f;
	float TopologyMutationRateL2 = 0.0f;
	float TopologyMutationRateL3 = 0.0f;
	
	//float TopologyMutationRateL1 = 0.1f;
	//float TopologyMutationRateL2 = 0.1f;
	//float TopologyMutationRateL3 = 0.1f;
	
	
	float GravitationAccelerationX = 0.0f;
	float GravitationAccelerationY = 20.0f;

	float FuelConsumptionInvReward1 = 0.1f;
	float FuelConsumptionReward2 = 0.01f;
	float HorizontalVelocityInvPenalty = 0.001f;
	float VerticalVelocityInvPenalty = 0.001;
	float VelocityPenalty = 1.0f;
	float FlightDurationInvPenalty1 = 0.001f;
	//float FlightDurationInvPenalty1 = 0.0001f;
	float FlightDurationPenalty2 = 2.0f;
	float TargetDistanceInvReward1 = 0.1f;
	float TargetDistanceReward2 = 1.0f;

	LandingModuleNavigationAIPopulation.Initialize(TrainingPopulationSize, NumOfHiddenNeuronsL1, NumOfHiddenNeuronsL2);

	LandingModuleNavigationAIPopulation.RandomChange_OutputSynapsePlasticities(MinSynapticPlasticity, MaxSynapticPlasticity);

	if (TopologyMutationRateL1 != 0.0f || TopologyMutationRateL2 != 0.0f || TopologyMutationRateL3 != 0.0f)
	{
		LandingModuleNavigationAIPopulation.RandomReduce_BrainConnections(TopologyMutationRateL1, TopologyMutationRateL2, TopologyMutationRateL3);
	}



	CNeuralNetPopulation NeuralNetPopulation;

	NeuralNetPopulation.Initialize(LandingModuleNavigationAIPopulation.PopulationSize, LandingModuleNavigationAIPopulation.NumOfInputNeurons, LandingModuleNavigationAIPopulation.NumOfOutputNeurons, NumOfHiddenNeuronsL1, NumOfHiddenNeuronsL1, NumOfHiddenNeuronsL2, NumOfHiddenNeuronsL2, SqrtOutput, LinearOutput, LinearOutput);

	Init_NeuralNetPopulation(&NeuralNetPopulation, &LandingModuleNavigationAIPopulation);

	

	for (int32_t i = 0; i < NumSimpleMutationGenerations; i++)
	{
		LandingModuleNavigationAIPopulation.Init_Play_and_Evaluate_NewTrainingSequence(400, NumTrainingGamesPerEpoch, GravitationAccelerationX, GravitationAccelerationY, 0.015f, TargetDistanceInvReward1, TargetDistanceReward2, FuelConsumptionInvReward1, FuelConsumptionReward2, HorizontalVelocityInvPenalty, VerticalVelocityInvPenalty, VelocityPenalty, FlightDurationInvPenalty1, FlightDurationPenalty2);
		

		NeuralNetPopulation.Update_Population(LandingModuleNavigationAIPopulation.pFitnessScoreArray);


		if (PlasticityMutationRate != 0.0f)
		{
			NeuralNetPopulation.Update_Evolution_SynapticPlasticityMutationsOnly(MinSynapticPlasticity, MaxSynapticPlasticity, PlasticityMutationRate, ExtremeLearning);
		}
		else if (PlasticityMutationRate == 0.0f)
		{
			NeuralNetPopulation.Update_Evolution_SynapticPlasticityMutationsOnly(MinSynapticPlasticity, MaxSynapticPlasticity, PlasticityMutationRateL1, PlasticityMutationRateL2, PlasticityMutationRateL3, ExtremeLearning);
		}

		if (TopologyMutationRateL1 != 0.0f || TopologyMutationRateL2 != 0.0f || TopologyMutationRateL3 != 0.0f)
		{
			NeuralNetPopulation.Update_Evolution_ConnectionTopologyMutationsOnly(MinSynapticPlasticity, MaxSynapticPlasticity, TopologyMutationRateL1, TopologyMutationRateL2, TopologyMutationRateL3, true);
		}

		if (PlasticityMutationRate != 0.0f)
		{
			NeuralNetPopulation.Update_Evolution_BestBrainOnly(MinSynapticPlasticityVariance, MaxSynapticPlasticityVariance, PlasticityMutationRate);
			NeuralNetPopulation.Update_Evolution_SecondBestBrainOnly(MinSynapticPlasticityVariance, MaxSynapticPlasticityVariance, PlasticityMutationRate);
		}
		else if (PlasticityMutationRate == 0.0f)
		{
			NeuralNetPopulation.Update_Evolution_BestBrainOnly(MinSynapticPlasticityVariance, MaxSynapticPlasticityVariance, PlasticityMutationRateL1, PlasticityMutationRateL2, PlasticityMutationRateL3);
			NeuralNetPopulation.Update_Evolution_SecondBestBrainOnly(MinSynapticPlasticityVariance, MaxSynapticPlasticityVariance, PlasticityMutationRateL1, PlasticityMutationRateL2, PlasticityMutationRateL3);
		}

		if (TopologyMutationRateL1 != 0.0f || TopologyMutationRateL2 != 0.0f || TopologyMutationRateL3 != 0.0f)
		{
			NeuralNetPopulation.Restore_ConnectionTopology_WorstFitted_Brain(MinSynapticPlasticity, MaxSynapticPlasticity);
			NeuralNetPopulation.Restore_ConnectionTopology_SecondWorstFitted_Brain(MinSynapticPlasticity, MaxSynapticPlasticity);
			NeuralNetPopulation.Restore_ConnectionTopology_ThirdWorstFitted_Brain(MinSynapticPlasticity, MaxSynapticPlasticity);
		}
	}

	for (int32_t i = NumSimpleMutationGenerations; i < NumTrainingGenerationsMax; i++)
	{
		LandingModuleNavigationAIPopulation.Init_Play_and_Evaluate_NewTrainingSequence(400, NumTrainingGamesPerEpoch, GravitationAccelerationX, GravitationAccelerationY, 0.015f, TargetDistanceInvReward1, TargetDistanceReward2, FuelConsumptionInvReward1, FuelConsumptionReward2, HorizontalVelocityInvPenalty, VerticalVelocityInvPenalty, VelocityPenalty, FlightDurationInvPenalty1, FlightDurationPenalty2);
		

		NeuralNetPopulation.Update_Population(LandingModuleNavigationAIPopulation.pFitnessScoreArray);

		if (PlasticityMutationRate != 0.0f)
		{
			NeuralNetPopulation.Update_Evolution_SynapticPlasticityMutationsOnly(MinSynapticPlasticity, MaxSynapticPlasticity, PlasticityMutationRate, ExtremeLearning);
		}
		else if (PlasticityMutationRate == 0.0f)
		{
			NeuralNetPopulation.Update_Evolution_SynapticPlasticityMutationsOnly(MinSynapticPlasticity, MaxSynapticPlasticity, PlasticityMutationRateL1, PlasticityMutationRateL2, PlasticityMutationRateL3, ExtremeLearning);
		}



		if (TopologyMutationRateL1 != 0.0f || TopologyMutationRateL2 != 0.0f || TopologyMutationRateL3 != 0.0f)
		{
			NeuralNetPopulation.Update_Evolution_ConnectionTopologyMutationsOnly(MinSynapticPlasticity, MaxSynapticPlasticity, TopologyMutationRateL1, TopologyMutationRateL2, TopologyMutationRateL3, true);
		}

		if (PlasticityMutationRate != 0.0f)
		{
			NeuralNetPopulation.Update_Evolution_BestBrainOnly(MinSynapticPlasticityVariance, MaxSynapticPlasticityVariance, PlasticityMutationRate);
			NeuralNetPopulation.Update_Evolution_SecondBestBrainOnly(MinSynapticPlasticityVariance, MaxSynapticPlasticityVariance, PlasticityMutationRate);
		}
		else if (PlasticityMutationRate == 0.0f)
		{
			NeuralNetPopulation.Update_Evolution_BestBrainOnly(MinSynapticPlasticityVariance, MaxSynapticPlasticityVariance, PlasticityMutationRateL1, PlasticityMutationRateL2, PlasticityMutationRateL3);
			NeuralNetPopulation.Update_Evolution_SecondBestBrainOnly(MinSynapticPlasticityVariance, MaxSynapticPlasticityVariance, PlasticityMutationRateL1, PlasticityMutationRateL2, PlasticityMutationRateL3);
		}


		NeuralNetPopulation.Update_Evolution_Combine_BestTwoBrains();
		NeuralNetPopulation.Update_Evolution_Combine_TwoBrains();

		if (TopologyMutationRateL1 != 0.0f || TopologyMutationRateL2 != 0.0f || TopologyMutationRateL3 != 0.0f)
		{
			NeuralNetPopulation.Restore_ConnectionTopology_WorstFitted_Brain(MinSynapticPlasticity, MaxSynapticPlasticity);
			NeuralNetPopulation.Restore_ConnectionTopology_SecondWorstFitted_Brain(MinSynapticPlasticity, MaxSynapticPlasticity);
			NeuralNetPopulation.Restore_ConnectionTopology_ThirdWorstFitted_Brain(MinSynapticPlasticity, MaxSynapticPlasticity);
		}

		//NeuralNetPopulation.Round_OutputWeights(0.00001f);
	}

	Set_Title("NeuralNetGravitationSample4 (SPACE: Reset Landing Sequence)");

	CLandingModuleNavigationAI LandingModuleNavigationAI;
	LandingModuleNavigationAI.Initialize(NumOfHiddenNeuronsL1, NumOfHiddenNeuronsL2);
	LandingModuleNavigationAI.Brain.Clone_OutputSynapsePlasticities(NeuralNetPopulation.Get_Best_Evolved_NeuralNet());
	//NeuralNetPopulation.Get_Best_Evolved_NeuralNet_Ext(&LandingModuleNavigationAI.Brain);

	//RandomNumbers.Change_Seed(150);
	RandomNumbers.Change_Seed(10);

	CSimplePhysicsObject LandingModulePhysicsObject;

	int32_t iStartPosX = RandomNumbers.Get_IntegerNumber2(LandingModuleNavigationAIPopulation.iStartPosXMin, LandingModuleNavigationAIPopulation.iStartPosXMax);
	int32_t iStartPosY = RandomNumbers.Get_IntegerNumber2(LandingModuleNavigationAIPopulation.iStartPosYMin, LandingModuleNavigationAIPopulation.iStartPosYMax);

	int32_t iTargetPosX = RandomNumbers.Get_IntegerNumber2(LandingModuleNavigationAIPopulation.iTargetPosXMin, LandingModuleNavigationAIPopulation.iTargetPosXMax);
	int32_t iTargetPosY = RandomNumbers.Get_IntegerNumber2(LandingModuleNavigationAIPopulation.iTargetPosYMin, LandingModuleNavigationAIPopulation.iTargetPosYMax);

	float startPosX = static_cast<float>(iStartPosX);
	float startPosY = static_cast<float>(iStartPosY);
	float targetPosX = static_cast<float>(iTargetPosX);
	float targetPosY = static_cast<float>(iTargetPosY);

	float initalVelocityX = RandomNumbers.Get_FloatNumber_IncludingZero(LandingModuleNavigationAIPopulation.InitalVelocityXMin, LandingModuleNavigationAIPopulation.InitalVelocityXMax);
	float initalVelocityY = RandomNumbers.Get_FloatNumber_IncludingZero(LandingModuleNavigationAIPopulation.InitalVelocityYMin, LandingModuleNavigationAIPopulation.InitalVelocityYMax);

	LandingModulePhysicsObject.Reset_Values();

	LandingModulePhysicsObject.velX = initalVelocityX;
	LandingModulePhysicsObject.velY = initalVelocityY;

	LandingModulePhysicsObject.posX = startPosX;
	LandingModulePhysicsObject.posY = startPosY;

	float outputData[5];

	float ActualFuelCapacity = LandingModuleNavigationAIPopulation.FuelCapacityMax;
	float FuelConsumptionX = LandingModuleNavigationAIPopulation.FuelConsumptionX;
	float FuelConsumptionY = LandingModuleNavigationAIPopulation.FuelConsumptionY;
	float ManeuverAccelerationX = LandingModuleNavigationAIPopulation.ManeuverAccelerationX;
	float ManeuverAccelerationY = LandingModuleNavigationAIPopulation.ManeuverAccelerationY;

	int32_t counter = 0;

	do
	{
		//auto last_timepoint = std::chrono::steady_clock::now();
		auto last_timepoint = steady_clock::now();
		
		if (KEYDOWN(VK_ESCAPE) == true)
			break;

		LandingModuleNavigationAI.Calculate_PossibleCourseCorrection(outputData, &LandingModulePhysicsObject, targetPosX, targetPosY);

		float maxOutputValue = -100000.0f;
		uint32_t belongingArrayID = 0;

		for (uint32_t i = 0; i < LandingModuleNavigationAI.NumOfOutputNeurons; i++)
		{
			if(outputData[i] > maxOutputValue)
			{
				maxOutputValue = outputData[i];
				belongingArrayID = i;
			}
		}

		LandingModulePhysicsObject.accelX = GravitationAccelerationX;
		LandingModulePhysicsObject.accelY = GravitationAccelerationY;

		if (belongingArrayID != 0)
		{
			if (outputData[1] > outputData[2] && outputData[1] > 0.0f)
			{
				LandingModulePhysicsObject.accelY += outputData[1] * ManeuverAccelerationY;
				ActualFuelCapacity -= outputData[1] * FuelConsumptionY;
			}
			else if (outputData[2] > outputData[1] && outputData[2] > 0.0f)
			{
				LandingModulePhysicsObject.accelY -= outputData[2] * ManeuverAccelerationY;
				ActualFuelCapacity -= outputData[2] * FuelConsumptionY;
			}
			
			if (outputData[3] > outputData[4] && outputData[3] > 0.0f)
			{
				LandingModulePhysicsObject.accelX += outputData[3] * ManeuverAccelerationX;
				ActualFuelCapacity -= outputData[3] * FuelConsumptionX;
			}
			else if (outputData[4] > outputData[3] && outputData[4] > 0.0f)
			{
				LandingModulePhysicsObject.accelX -= outputData[4] * ManeuverAccelerationX;
				ActualFuelCapacity -= outputData[4] * FuelConsumptionX;
			}	
		}

		LandingModulePhysicsObject.Update(FrameTime);


			
		WinConsole.Clear_BackBuffer();

		int32_t posX_Left = iTargetPosX - LandingPlatform.NumCharactersPerRow / 2;
		int32_t posY_Top = iTargetPosY - LandingPlatform.NumCharactersPerColumn / 2;

		WinConsole.Draw_2DObject_Into_BackBuffer(posX_Left, posY_Top, LandingPlatform.pDataArray, LandingPlatform.NumCharactersPerRow, LandingPlatform.NumCharactersPerColumn);


		posX_Left = LandingModulePhysicsObject.posX - LandingModule.NumCharactersPerRow / 2;
		posY_Top = LandingModulePhysicsObject.posY - LandingModule.NumCharactersPerColumn / 2;

		WinConsole.Draw_2DObject_Into_BackBuffer(posX_Left, posY_Top, LandingModule.pDataArray, LandingModule.NumCharactersPerRow, LandingModule.NumCharactersPerColumn);
	
		

		WinConsole.Present_BackBuffer();

		counter++;

		if (GetAsyncKeyState(VK_SPACE) || GetAsyncKeyState(VK_RETURN) || counter > 400)
		{
			counter = 0;

			iStartPosX = RandomNumbers.Get_IntegerNumber2(LandingModuleNavigationAIPopulation.iStartPosXMin, LandingModuleNavigationAIPopulation.iStartPosXMax);
			iStartPosY = RandomNumbers.Get_IntegerNumber2(LandingModuleNavigationAIPopulation.iStartPosYMin, LandingModuleNavigationAIPopulation.iStartPosYMax);

			iTargetPosX = RandomNumbers.Get_IntegerNumber2(LandingModuleNavigationAIPopulation.iTargetPosXMin, LandingModuleNavigationAIPopulation.iTargetPosXMax);
			iTargetPosY = RandomNumbers.Get_IntegerNumber2(LandingModuleNavigationAIPopulation.iTargetPosYMin, LandingModuleNavigationAIPopulation.iTargetPosYMax);

			startPosX = static_cast<float>(iStartPosX);
			startPosY = static_cast<float>(iStartPosY);
			targetPosX = static_cast<float>(iTargetPosX);
			targetPosY = static_cast<float>(iTargetPosY);

			initalVelocityX = RandomNumbers.Get_FloatNumber_IncludingZero(LandingModuleNavigationAIPopulation.InitalVelocityXMin, LandingModuleNavigationAIPopulation.InitalVelocityXMax);
			initalVelocityY = RandomNumbers.Get_FloatNumber_IncludingZero(LandingModuleNavigationAIPopulation.InitalVelocityYMin, LandingModuleNavigationAIPopulation.InitalVelocityYMax);

			LandingModulePhysicsObject.Reset_Values();

			LandingModulePhysicsObject.velX = initalVelocityX;
			LandingModulePhysicsObject.velY = initalVelocityY;

			LandingModulePhysicsObject.posX = startPosX;
			LandingModulePhysicsObject.posY = startPosY;

			ActualFuelCapacity = LandingModuleNavigationAIPopulation.FuelCapacityMax;

			FuelConsumptionX = LandingModuleNavigationAIPopulation.FuelConsumptionX;
			FuelConsumptionY = LandingModuleNavigationAIPopulation.FuelConsumptionY;

			ManeuverAccelerationX = LandingModuleNavigationAIPopulation.ManeuverAccelerationX;
			ManeuverAccelerationY = LandingModuleNavigationAIPopulation.ManeuverAccelerationY;
		}

		//Frame-Bremse:

		auto current_timepoint = steady_clock::now();
		

		//while (current_timepoint - last_timepoint < 50ms)
		//while (current_timepoint - last_timepoint < 16ms)
		while (current_timepoint - last_timepoint < 16666us) // 16.7 Millisekunden (ms)  bzw. 16666 Mikrosekunden (us): maximal 60 Frames pro Sekunde					
		{
			current_timepoint = steady_clock::now();
			
		}

		//FrameTime = 0.000000001f * (current_timepoint - last_timepoint).count();
		//HelperStuff::Add_To_Log(0, "dt (s)", FrameTime);

		//FrameTime = 0.0125f;
		FrameTime = 0.015f;

	} while (true);

	WinConsole.Clear_BackBuffer();
	WinConsole.Present_BackBuffer();
	WinConsole.CleanUp();


	Set_CursorVisibilityAndSize(true);
	Reset_CursorPos();
	//Set_CursorPos(0, 0);

	cout << "bye bye (Press Return)" << endl;


	getchar();
	return 0;

}
*/



