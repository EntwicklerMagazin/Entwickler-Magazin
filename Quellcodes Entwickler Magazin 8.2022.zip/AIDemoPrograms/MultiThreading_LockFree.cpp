#include "MultiThreading_LockFree.h"

using namespace std;

static atomic_bool StopThread[
	g_NumOfUsableLockFreeThreadsMax];

static atomic_bool TaskCompleted[
	g_NumOfUsableLockFreeThreadsMax];

static atomic_bool ReadyToUnblockThread[
	g_NumOfUsableLockFreeThreadsMax];


void CLockFreeThreadManager::Set_ThreadID(uint32_t id)
{
	ThreadID = 0;

	if (id < g_NumOfUsableLockFreeThreadsMax)
		ThreadID = id;

	StopThread[ThreadID].store(false);
	TaskCompleted[ThreadID].store(false);
}


void CLockFreeThreadManager::Unblock_Thread(void)
{
	ReadyToUnblockThread[ThreadID].store(true);
	TaskCompleted[ThreadID].store(false);
}


void CLockFreeThreadManager::Stop_Thread(void)
{
	ReadyToUnblockThread[ThreadID].store(true);
	StopThread[ThreadID].store(true);
}

bool CLockFreeThreadManager::
Wait_For_UnblockingSignal_And_Continue(void)
{
	/* Die nachfolgende Schleife wird erst dann verlassen,
	wenn der Wert von ReadyToUnblockThread[ThreadID]
	gleich true ist: */
	while (ReadyToUnblockThread[ThreadID].load() == false)
	{
		this_thread::sleep_for(chrono::milliseconds(5));
	}

	ReadyToUnblockThread[ThreadID].store(false);

	if (StopThread[ThreadID].load() == true)
		return false;
	else
		return true;
}


void CLockFreeThreadManager::Set_BlockingStatus(bool status)
{
	ReadyToUnblockThread[ThreadID].store(status);
}


void CLockFreeThreadManager::Wait_For_Results(void)
{
	while (TaskCompleted[ThreadID].load() == false);
}


void CLockFreeThreadManager::Task_Completed(void)
{
	TaskCompleted[ThreadID].store(true);
}
