// Schutz vor Mehrfachdeklarationen :

#ifndef _SparseVectorMatrix_H_
#define _SparseVectorMatrix_H_

#pragma warning( disable: 4996)

#include <iostream>
#include "MemoryManagement.h"
#include "RandomNumbers.h"


// SparseVector Idee: schneller zugriff auf s�mtliche Vektorelemente != 0

class CSparseVector
{
public:

	int32_t Size = 0;
	
	int32_t NumOfNonZeroElements = 0;

	float *pValueArray = nullptr;
	int32_t *pNonZeroElementIndexArray = nullptr;

	CSparseVector();
	~CSparseVector();

	// Kopierkonstruktor l�schen:
	CSparseVector(const CSparseVector  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CSparseVector & operator=(const CSparseVector  &originalObject) = delete;

	void Initialize(int32_t size);

	void Set_Vector(float *pInVectorElementArray);
	void Get_Vector(float *pOutVectorElementArray);

	// return value: number of non-zero elements
	int32_t Get_IDs_Of_NonZero_Elements(int32_t* pOutElementIDArray);

};

class CSparseVector2
{

public:

	int32_t Size = 0;
	int32_t SizePlus1 = 1;
	int32_t SizePlus2 = 2;
	float *pValueArray = nullptr;

	COrderPreservingDoubleLinkedList NonZeroElementList;

	CSparseVector2();
	~CSparseVector2();

	// Kopierkonstruktor l�schen:
	CSparseVector2(const CSparseVector2  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CSparseVector2 & operator=(const CSparseVector2  &originalObject) = delete;

	void Initialize(int32_t size);

	void Set_Vector(float *pInVectorElementArray);
	void Get_Vector(float *pOutVectorElementArray);

	// return value: number of non-zero elements
	int32_t Get_IDs_Of_NonZero_Elements(int32_t *pOutElementIDArray);
};



class CSparseBinaryVector
{
public:

	int32_t Size = 0;
	
	int32_t NumOfNonZeroElements = 0;
	int32_t *pNonZeroElementIndexArray = nullptr;

	CSparseBinaryVector();
	~CSparseBinaryVector();

	// Kopierkonstruktor l�schen:
	CSparseBinaryVector(const CSparseBinaryVector  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CSparseBinaryVector & operator=(const CSparseBinaryVector  &originalObject) = delete;

	void Initialize(int32_t size);

	void Set_Vector(bool *pInVectorElementArray);
	void Get_Vector(bool *pOutVectorElementArray);	

	// return value: number of non-zero elements
	int32_t Get_IDs_Of_NonZero_Elements(int32_t* pOutElementIDArray);

};

class CSparseBinaryVector2
{

public:

	int32_t Size = 0;
	int32_t SizePlus1 = 1;
	int32_t SizePlus2 = 2;
	
	COrderPreservingDoubleLinkedList NonZeroElementList;

	CSparseBinaryVector2();
	~CSparseBinaryVector2();

	// Kopierkonstruktor l�schen:
	CSparseBinaryVector2(const CSparseBinaryVector2  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CSparseBinaryVector2 & operator=(const CSparseBinaryVector2  &originalObject) = delete;

	void Initialize(int32_t size);

	void Set_Vector(bool *pInVectorElementArray);
	void Get_Vector(bool *pOutVectorElementArray);

	// return value: number of non-zero elements
	int32_t Get_IDs_Of_NonZero_Elements(int32_t *pOutElementIDArray);
};


bool Check_ForCompleteIncongruence(CSparseBinaryVector *pVector1, CSparseBinaryVector *pVector2);
bool Combine_TwoVectors(CSparseBinaryVector *pOutVector, CSparseBinaryVector *pInVector1, CSparseBinaryVector *pInVector2, bool completeIncongruenceCheck);



class CSparseMatrix
{
public:

	int32_t NumOfRows = 0;
	int32_t NumOfColumns = 0;

	CSparseVector *pRowVectorArray = nullptr;

	CSparseMatrix();
	~CSparseMatrix();

	// Kopierkonstruktor l�schen:
	CSparseMatrix(const CSparseMatrix  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CSparseMatrix & operator=(const CSparseMatrix  &originalObject) = delete;

	void Initialize(int32_t numOfRows, int32_t numOfColumns);

	void Set_RowVector(float *pInVectorElementArray, int32_t rowID);
	void Get_RowVector(float *pOutVectorElementArray, int32_t rowID);
};

class CSparseBinaryMatrix
{
public:

	int32_t NumOfRows = 0;
	int32_t NumOfColumns = 0;

	CSparseBinaryVector *pRowVectorArray = nullptr;

	CSparseBinaryMatrix();
	~CSparseBinaryMatrix();

	// Kopierkonstruktor l�schen:
	CSparseBinaryMatrix(const CSparseBinaryMatrix  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CSparseBinaryMatrix & operator=(const CSparseBinaryMatrix  &originalObject) = delete;

	void Initialize(int32_t numOfRows, int32_t numOfColumns);

	void Set_RowVector(bool *pInVectorElementArray, int32_t rowID);
	void Get_RowVector(bool *pOutVectorElementArray, int32_t rowID);
};

// Constraint, zu Deutsch: Nebenbedingung 
class CPossibleExactCoverSolutionsPerConstraint
{
public:

	int32_t NumOfSolutionsMax = 0;
	int32_t ActualNumOfSolutions = 0;
	int32_t NumOfSolutionsMinus1 = 0;
	int32_t *pSolutionIDArray = nullptr;

	CPossibleExactCoverSolutionsPerConstraint();
	~CPossibleExactCoverSolutionsPerConstraint();

	// Kopierkonstruktor l�schen:
	CPossibleExactCoverSolutionsPerConstraint(const CPossibleExactCoverSolutionsPerConstraint  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CPossibleExactCoverSolutionsPerConstraint & operator=(const CPossibleExactCoverSolutionsPerConstraint  &originalObject) = delete;

	void Initialize_SolutionIDArray(void);
	void Initialize_SolutionIDArray(int32_t numOfSolutionsMax);

	void Add_SolutionID(int32_t id);

	int32_t Get_Another_PossibleSolutionID(void);

	void Delete_PreviousResults(void);

	void Permute_SolutionIDs(CRandomNumbersNN *pRandomNumbers);

	void Clone(CPossibleExactCoverSolutionsPerConstraint *pOriginalObject);
};

class CIterativeExactCoverSolver
{
public:

	int32_t NumOfRows_ProblemMatrix = 0;
	int32_t NumOfColumns_ProblemMatrix = 0;
	int32_t NumOfColumnsMinus1_ProblemMatrix = 0;
	
	/* Jede Nebenbedingung (Constraint) wird durch eine Spalte der Problem-Matrix repr�sentiert.
	   Jede Zeile der Problem-Matrix ist potenziell ein Teil der gesuchten L�sung (L�sungsvektor)
	   Die Summe aller L�sungsvektoren muss einen Vektor ergeben, dessen Elemente allesamt gleich true bzw. 1 sind.
	   Beispiel: L�sungsvektor1 (true, true, false, false) + L�sungsvektor2 (false, false, true, true) = (true, true, true, true) */
	CSparseBinaryMatrix ProblemMatrix;

	CPossibleExactCoverSolutionsPerConstraint *pSolutionsPerConstraintArray = nullptr;

	// Am Anfang der Sequenz wird die Nebenbedingung (Constraint) mit der kleinstm�glichen Anzahl an L�sungsvektoren abgearbeitet.
	// Am Ende der Sequenz wird die Nebenbedingung (Constraint) mit der gr��tm�glichen Anzahl an L�sungsvektoren abgearbeitet.
	int32_t *pConstraintAccessSequenceArray = nullptr;
	
	int32_t *pIDListOfSolutionRowVectors = nullptr;
	int32_t ActualNumberOfSolutionRowVectors = 0;

	int32_t *pCoverVector = nullptr;
	int32_t CoverVector_SumOfColumnValues = 0;

	bool *pSolutionIDUsageArray = nullptr;

	bool SolutionFound = false;

	CIterativeExactCoverSolver();
	~CIterativeExactCoverSolver();

	// Kopierkonstruktor l�schen:
	CIterativeExactCoverSolver(const CIterativeExactCoverSolver  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CIterativeExactCoverSolver & operator=(const CIterativeExactCoverSolver  &originalObject) = delete;

	void Initialize(int32_t numOfRows_ProblemMatrix, int32_t numOfColumns_ProblemMatrix);

	bool Prepare_Calculations(void);
	// zus�tzliche Verwendung des Arrays pConstraintAccessSequenceArray
	bool Prepare_Calculations_Use_ConstraintAccessSequence(void);
	

	void Prepare_For_ExactCoverSearchRestart(void);
	void Permute_SolutionIDs_For_ExactCoverSearchRestart(CRandomNumbersNN *pRandomNumbers);

	int32_t Check_For_PossibleSolution(void);
	int32_t Get_Solution_If_Possible(int32_t *pOutIDArrayOfSolutionRowVectors);
	int32_t Get_Solution(int32_t *pOutIDArrayOfSolutionRowVectors);

	bool Search_Solution(int32_t numOfIterationStepsMax, int32_t *pOutNumOfNecessaryIterationSteps);

	// zus�tzliche Verwendung des Arrays pConstraintAccessSequenceArray
	bool Search_Solution_Use_ConstraintAccessSequence(int32_t numOfIterationStepsMax, int32_t *pOutNumOfNecessaryIterationSteps);

	int32_t Add_SelectedRowVector_To_CoverVector_If_Possible(CSparseBinaryVector *pRowVector);
};





#endif