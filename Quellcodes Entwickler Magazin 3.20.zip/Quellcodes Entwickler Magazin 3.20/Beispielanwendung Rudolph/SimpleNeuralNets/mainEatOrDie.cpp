#include <iostream>
//#include <chrono>
#include <thread>
#include "ConsoleHelperFunctions.h"
#include "RandomNumbers.h"
#include "NeuralNet.h"

using namespace std;

//#define EvolutionVariant1
//#define EvolutionVariant2
#define EvolutionVariant3


#define KEYDOWN(vk_code) ((GetAsyncKeyState(vk_code) & 0x8000) ? 1 : 0)
#define KEYUP(vk_code)   ((GetAsyncKeyState(vk_code) & 0x8000) ? 0 : 1)

static CRandomNumbers_ParkMillerMLKG g_RandomNumbers_FeedUpdate;

static char g_InputBuffer[100];

static constexpr int32_t ConstMaxGameBoardDist = 15;

static constexpr int32_t ConstGameBoardSizeX = 15;
static constexpr int32_t ConstGameBoardSizeY = 15;

static constexpr int32_t ConstGameBoardSizeXMinus1 = 14;
static constexpr int32_t ConstGameBoardSizeYMinus1 = 14;


static int32_t g_GameBoard[ConstGameBoardSizeY][ConstGameBoardSizeX];
static int32_t g_GameBoardPathData[ConstGameBoardSizeY][ConstGameBoardSizeX];


static constexpr int32_t ConstGameBoard_EmptyElement = 0;
static constexpr int32_t ConstGameBoard_ObstacleElement = 1;
static constexpr int32_t ConstGameBoard_Lifeform = 2;
static constexpr int32_t ConstGameBoard_Feed = 3;
static constexpr int32_t ConstGameBoard_PathElement = 4;

static int32_t g_GameBoard_FeedPosX = 1;
static int32_t g_GameBoard_FeedPosY = 1;

//static int32_t g_MaxSimulationSteps = 100000;
static int32_t g_MaxSimulationSteps = 20000;

static uint64_t g_BirthPosSeed = 6545;
static uint64_t g_FeedPosSeed = 11458;








void Output_GameBoard(void)
{
	uint32_t ix, iy;

	for (iy = 0; iy < ConstGameBoardSizeY; iy++)
	{
		for (ix = 0; ix < ConstGameBoardSizeX; ix++)
		{
			if (g_GameBoard[iy][ix] == ConstGameBoard_EmptyElement)
				cout << "  ";
			else
				cout << g_GameBoard[iy][ix] << " ";	
		}

		cout << endl;
	}

	cout << endl << endl;
}

void Calculate_ObstacleDistances2(int32_t *pData, int32_t centerPosX, int32_t centerPosY, int32_t *pOutDist1, int32_t *pOutDist2, int32_t *pOutDist3, int32_t *pOutDist4)
{
	int32_t idCenterPos = centerPosX + centerPosY * ConstGameBoardSizeX;

	if(pData[idCenterPos] == ConstGameBoard_ObstacleElement)
	{
		*pOutDist1 = 0;
		*pOutDist2 = 0;
		*pOutDist3 = 0;
		*pOutDist4 = 0;
		

		return;
	}

	*pOutDist1 = 0;
	*pOutDist2 = 0;
	*pOutDist3 = 0;
	*pOutDist4 = 0;
	

	int32_t i, ix, iy, id, dist;

	dist = 0;
	ix = centerPosX;
	iy = centerPosY;

	for(i = 0; i < ConstMaxGameBoardDist; i++)
	{
		dist++;
		ix--;

		id = ix + iy * ConstGameBoardSizeX;

		if (pData[id] == ConstGameBoard_ObstacleElement)
		{
			*pOutDist1 = dist;
			break;
		}

	}

	dist = 0;
	ix = centerPosX;
	iy = centerPosY;

	for (i = 0; i < ConstMaxGameBoardDist; i++)
	{
		dist++;
		ix++;

		id = ix + iy * ConstGameBoardSizeX;

		if (pData[id] == ConstGameBoard_ObstacleElement)
		{
			*pOutDist2 = dist;
			break;
		}
	}

	dist = 0;
	ix = centerPosX;
	iy = centerPosY;

	for (i = 0; i < ConstMaxGameBoardDist; i++)
	{
		dist++;
		iy++;

		id = ix + iy * ConstGameBoardSizeY;

		if (pData[id] == ConstGameBoard_ObstacleElement)
		{
			*pOutDist3 = dist;
			break;
		}
	}

	dist = 0;
	ix = centerPosX;
	iy = centerPosY;

	for (i = 0; i < ConstMaxGameBoardDist; i++)
	{
		dist++;
		iy--;

		id = ix + iy * ConstGameBoardSizeX;

		if (pData[id] == ConstGameBoard_ObstacleElement)
		{
			*pOutDist4 = dist;
			break;
		}
	}

	if (*pOutDist1 > 1)
		*pOutDist1 = 2;
	if (*pOutDist2 > 1)
		*pOutDist2 = 2;
	if (*pOutDist3 > 1)
		*pOutDist3 = 2;
	if (*pOutDist4 > 1)
		*pOutDist4 = 2;

	

}

void Calculate_ObstacleDistances(int32_t centerPosX, int32_t centerPosY, int32_t *pOutDist1, int32_t *pOutDist2, int32_t *pOutDist3, int32_t *pOutDist4)
{
	if (g_GameBoard[centerPosY][centerPosX] == ConstGameBoard_ObstacleElement)
	{
		*pOutDist1 = 0;
		*pOutDist2 = 0;
		*pOutDist3 = 0;
		*pOutDist4 = 0;


		return;
	}

	*pOutDist1 = 0;
	*pOutDist2 = 0;
	*pOutDist3 = 0;
	*pOutDist4 = 0;


	int32_t i, ix, iy, dist;

	dist = 0;
	ix = centerPosX;
	iy = centerPosY;

	for (i = 0; i < ConstMaxGameBoardDist; i++)
	{
		dist++;
		ix--;

		if (g_GameBoard[iy][ix] == ConstGameBoard_ObstacleElement)
		{
			*pOutDist1 = dist;
			break;
		}

	}

	dist = 0;
	ix = centerPosX;
	iy = centerPosY;

	for (i = 0; i < ConstMaxGameBoardDist; i++)
	{
		dist++;
		ix++;

		if (g_GameBoard[iy][ix] == ConstGameBoard_ObstacleElement)
		{
			*pOutDist2 = dist;
			break;
		}
	}

	dist = 0;
	ix = centerPosX;
	iy = centerPosY;

	for (i = 0; i < ConstMaxGameBoardDist; i++)
	{
		dist++;
		iy++;

		if (g_GameBoard[iy][ix] == ConstGameBoard_ObstacleElement)
		{
			*pOutDist3 = dist;
			break;
		}
	}

	dist = 0;
	ix = centerPosX;
	iy = centerPosY;

	for (i = 0; i < ConstMaxGameBoardDist; i++)
	{
		dist++;
		iy--;

		if (g_GameBoard[iy][ix] == ConstGameBoard_ObstacleElement)
		{
			*pOutDist4 = dist;
			break;
		}
	}

	if (*pOutDist1 > 1)
		*pOutDist1 = 2;
	if (*pOutDist2 > 1)
		*pOutDist2 = 2;
	if (*pOutDist3 > 1)
		*pOutDist3 = 2;
	if (*pOutDist4 > 1)
		*pOutDist4 = 2;

	

}

void Init_Or_Reset_GameBoardArrays(int32_t emptyValue = ConstGameBoard_EmptyElement)
{
	for (uint32_t iy = 0; iy < ConstGameBoardSizeY; iy++)
	{
		for (uint32_t ix = 0; ix < ConstGameBoardSizeX; ix++)
		{
			g_GameBoard[iy][ix] = emptyValue;
			g_GameBoardPathData[iy][ix] = emptyValue;
		}
	}
}



void GameBoard_Reset_Feed(void)
{
	g_GameBoard[g_GameBoard_FeedPosY][g_GameBoard_FeedPosX] = ConstGameBoard_EmptyElement;
}

bool GameBoard_SearchForFeed(int32_t feedValue = ConstGameBoard_Feed)
{
	uint32_t ix, iy, id;

	for (iy = 0; iy < ConstGameBoardSizeY; iy++)
	{
		for (ix = 0; ix < ConstGameBoardSizeX; ix++)
		{
			if (g_GameBoard[iy][ix] == ConstGameBoard_Feed)
				return true;
		}
	}

	return false;
}

float GameBoard_UpdateFeed(int32_t feedValue = ConstGameBoard_Feed)
{
	if (GameBoard_SearchForFeed(feedValue) == true)
		return 0.0f;

	uint32_t ix = g_RandomNumbers_FeedUpdate.Get_UnsignedIntegerNumber(1, ConstGameBoardSizeXMinus1);
	uint32_t iy = g_RandomNumbers_FeedUpdate.Get_UnsignedIntegerNumber(1, ConstGameBoardSizeYMinus1);
	

	if (g_GameBoard[iy][ix] == ConstGameBoard_EmptyElement)
	{
		g_GameBoard[iy][ix] = ConstGameBoard_Feed;

		g_GameBoard_FeedPosX = ix;
		g_GameBoard_FeedPosY = iy;
	}
	else
	{
		do
		{
			ix = g_RandomNumbers_FeedUpdate.Get_UnsignedIntegerNumber(1, ConstGameBoardSizeXMinus1);
			iy = g_RandomNumbers_FeedUpdate.Get_UnsignedIntegerNumber(1, ConstGameBoardSizeYMinus1);
			

			if (g_GameBoard[iy][ix] == ConstGameBoard_EmptyElement)
			{
				g_GameBoard[iy][ix] = ConstGameBoard_Feed;

				g_GameBoard_FeedPosX = ix;
				g_GameBoard_FeedPosY = iy;

				break;
			}

		} while (true);
	}

	return 1.0f;
}



void Init_GameBoardBorders(int32_t borderValue = ConstGameBoard_ObstacleElement)
{
	for (uint32_t iy = 0; iy < ConstGameBoardSizeY; iy++)
	{
		if(iy == 0 || iy == ConstGameBoardSizeYMinus1)
		{
			for (uint32_t ix = 0; ix < ConstGameBoardSizeX; ix++)
			{
				g_GameBoard[iy][ix] = borderValue;
			}
		}
		else
		{
			for (uint32_t ix = 0; ix < ConstGameBoardSizeX; ix++)
			{
				if (ix == 0 || ix == ConstGameBoardSizeXMinus1)
				{
					g_GameBoard[iy][ix] = borderValue;
				}
			}
		}
	}
}





inline float ActivationFunction(float neuronInput)
{
	// von -1.0f bis 1.0f:
	return tanh(neuronInput);

	// von -1.0f bis 1.0f:
	//return neuronInput / (1.0f + abs(neuronInput));

	// von 0.0f bis 1.0f:
	//return 1.0f / (1.0f + exp(-neuronInput));
}







class CLifeform
{
public:

	CRandomNumbersNN RandomNumbers_BirthPos;

	int32_t PosX = ConstGameBoardSizeX / 2;
	int32_t PosY = ConstGameBoardSizeX / 2;

	int32_t OldPosX = ConstGameBoardSizeX / 2;
	int32_t OldPosY = ConstGameBoardSizeX / 2;

	int32_t OldPosX2 = ConstGameBoardSizeX / 2;
	int32_t OldPosY2 = ConstGameBoardSizeX / 2;
	

	bool Living = false;
	int32_t LivingPoints = 0; 

	int32_t NumOfWrongMovementSteps = 0;

	CNeuralNet Brain;
	
	CLifeform()
	{
		//Brain.Init_NeuralNet(12);
		//Brain.Init_Input_And_OutputNeurons(7, 0.1f, true, 1, ActivationFunction);
		//Brain.Init_HiddenLayer1(2, false, true, ActivationFunction, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);

		//Brain.Init_NeuralNet(15);
		//Brain.Init_Input_And_OutputNeurons(7, 0.1f, true, 1, ActivationFunction);
		//Brain.Init_HiddenLayer1(6, false, true, ActivationFunction, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);

		//Brain.Init_NeuralNet(25);
		//Brain.Init_Input_And_OutputNeurons(7, 0.1f, true, 1, ActivationFunction);
		//Brain.Init_HiddenLayer1(16, false, true, ActivationFunction, -0.0f, 0.0f, -0.0f, 0.0f, 0.1f);

		//Brain.Init_NeuralNet(15);
		//Brain.Init_Input_And_OutputNeurons(7, 0.1f, true, 1, ActivationFunction);
		//Brain.Init_HiddenLayer1(4, false, false, ActivationFunction, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
		//Brain.Init_HiddenLayer2(2, false, true, ActivationFunction, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);


		
		Brain.Init_NeuralNet(21);
		Brain.Init_Input_And_OutputNeurons(7, 0.1f, true, 1, ActivationFunction);
		Brain.Init_HiddenLayer1(6, false, false, ActivationFunction, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
		Brain.Init_HiddenLayer2(4, false, false, ActivationFunction, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
		Brain.Init_HiddenLayer3(2, false, ActivationFunction, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
	}

	void Init_Brain(void)
	{
		Brain.Init_NeuralNet(21);
		Brain.Init_Input_And_OutputNeurons(7, 0.1f, true, 1, ActivationFunction);
		Brain.Init_HiddenLayer1(6, false, false, ActivationFunction, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
		Brain.Init_HiddenLayer2(4, false, false, ActivationFunction, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
		Brain.Init_HiddenLayer3(2, false, ActivationFunction, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);	
	}


	
	
	void Update_LivingStatus(int32_t AdditionalFeedBasedLivingPoints = 20)
	{
		LivingPoints--;

		if (LivingPoints < 1)
		{
			Living = false;
			LivingPoints = 0;
			return;
		}

		Living = true;

		//int32_t id = PosX + PosY * ConstGameBoardSizeX;

		if(g_GameBoard[PosY][PosX] == ConstGameBoard_ObstacleElement)
		{
			Living = false;
			LivingPoints = 0;
		}	
		else if (g_GameBoard[PosY][PosX] == ConstGameBoard_Feed)
		{
			g_GameBoard[PosY][PosX] = ConstGameBoard_EmptyElement;
			LivingPoints += AdditionalFeedBasedLivingPoints;
		}

		LivingPoints = min(100.0f, LivingPoints);	
	}

	void Birth(bool randomBirthPos, int32_t livingPoints = 50)
	{
		Living = true;
		LivingPoints = livingPoints;

		if (randomBirthPos == true)
			Set_RandomPos();
		else
			Reset_Pos();

		
		NumOfWrongMovementSteps = 0;
	}

	void Set_BirthPosSeed_And_Birth(uint64_t randomBirthPosSeed, int32_t livingPoints = 50)
	{
		Living = true;
		LivingPoints = livingPoints;

		Set_RandomPos(randomBirthPosSeed);

		
		NumOfWrongMovementSteps = 0;
	}

	void Set_BirthPosSeed(uint64_t randomBirthPosSeed)
	{
		RandomNumbers_BirthPos.Change_Seed(randomBirthPosSeed);
	}

	void Death(void)
	{
		Living = false;
		LivingPoints = 0;
	}

	void Reset_Pos(void)
	{
		PosX = ConstGameBoardSizeX / 2;
		PosY = ConstGameBoardSizeX / 2;
		OldPosX = PosX;
		OldPosY = PosY;
		OldPosX2 = PosX;
		OldPosY2 = PosY;
	

		
		NumOfWrongMovementSteps = 0;
	}

	void Set_RandomPos(void)
	{
		PosX = RandomNumbers_BirthPos.Get_UnsignedIntegerNumber(1, ConstGameBoardSizeXMinus1);
		PosY = RandomNumbers_BirthPos.Get_UnsignedIntegerNumber(1, ConstGameBoardSizeYMinus1);

		//uint32_t id = PosX + PosY * ConstGameBoardSizeX;

		if (g_GameBoard[PosY][PosX] != ConstGameBoard_EmptyElement)
		{
			do
			{
				PosX = RandomNumbers_BirthPos.Get_UnsignedIntegerNumber(1, ConstGameBoardSizeXMinus1);
				PosY = RandomNumbers_BirthPos.Get_UnsignedIntegerNumber(1, ConstGameBoardSizeYMinus1);

				//id = PosX + PosY * ConstGameBoardSizeX;

				if (g_GameBoard[PosY][PosX] == ConstGameBoard_EmptyElement)
				{
					break;
				}

			} while (true);
		}
		
		

		OldPosX = PosX;
		OldPosY = PosY;
		OldPosX2 = PosX;
		OldPosY2 = PosY;
		

		
		NumOfWrongMovementSteps = 0;

	}

	void Set_RandomPos(uint64_t seed)
	{
		RandomNumbers_BirthPos.Change_Seed(seed);

		PosX = RandomNumbers_BirthPos.Get_UnsignedIntegerNumber(1, ConstGameBoardSizeXMinus1);
		PosY = RandomNumbers_BirthPos.Get_UnsignedIntegerNumber(1, ConstGameBoardSizeYMinus1);

		//uint32_t id = PosX + PosY * ConstGameBoardSizeX;

		if (g_GameBoard[PosY][PosX] != ConstGameBoard_EmptyElement)
		{
			do
			{
				PosX = RandomNumbers_BirthPos.Get_UnsignedIntegerNumber(1, ConstGameBoardSizeXMinus1);
				PosY = RandomNumbers_BirthPos.Get_UnsignedIntegerNumber(1, ConstGameBoardSizeYMinus1);

				//id = PosX + PosY * ConstGameBoardSizeX;

				if (g_GameBoard[PosY][PosX] == ConstGameBoard_EmptyElement)
				{
					break;
				}

			} while (true);
		}

		OldPosX = PosX;
		OldPosY = PosY;
		OldPosX2 = PosX;
		OldPosY2 = PosY;
		

		
		NumOfWrongMovementSteps = 0;
	}

	void Update_Pos(void)
	{
		int32_t dist1, dist2, dist3, dist4;
		int32_t testPosX[4];
		int32_t testPosY[4];
		float movementEvaluation;
		float feedDist, stepsX, stepsY;

		//float statusValue = 0.01f*static_cast<float>(LivingPoints);
		float statusValue = 0.1f*static_cast<float>(LivingPoints);
		
		float bestMovementEvaluation = -1000.0f;
		int32_t id = 0;

		float inputValueArray[7];
		float outputValueArray[1];

		testPosX[0] = PosX - 1;
		testPosY[0] = PosY;

		if (testPosX[0] != OldPosX || testPosY[0] != OldPosY)
		{
			Calculate_ObstacleDistances(testPosX[0], testPosY[0], &dist1, &dist2, &dist3, &dist4);

			stepsX = abs(testPosX[0] - g_GameBoard_FeedPosX);
			stepsY = abs(testPosY[0] - g_GameBoard_FeedPosY);
			feedDist = stepsX + stepsY;

			inputValueArray[0] = dist1;
			inputValueArray[1] = dist2;
			inputValueArray[2] = dist3;
			inputValueArray[3] = dist4;
			inputValueArray[4] = feedDist;
			inputValueArray[5] = statusValue;

			inputValueArray[6] = 0.0f;

			if (g_GameBoardPathData[testPosY[0]][testPosX[0]] == ConstGameBoard_PathElement || g_GameBoardPathData[testPosY[0]][testPosX[0]] == ConstGameBoard_Feed)
				inputValueArray[6] = 1.0f;

			Brain.Calculate_Output(outputValueArray, inputValueArray);
			movementEvaluation = outputValueArray[0];

			if (movementEvaluation > bestMovementEvaluation)
			{
				bestMovementEvaluation = movementEvaluation;
				id = 0;
			}
		}

		testPosX[1] = PosX + 1;
		testPosY[1] = PosY;

		
		if (testPosX[1] != OldPosX || testPosY[1] != OldPosY)
		{
			Calculate_ObstacleDistances(testPosX[1], testPosY[1], &dist1, &dist2, &dist3, &dist4);

			stepsX = abs(testPosX[1] - g_GameBoard_FeedPosX);
			stepsY = abs(testPosY[1] - g_GameBoard_FeedPosY);
			feedDist = stepsX + stepsY;

			inputValueArray[0] = dist1;
			inputValueArray[1] = dist2;
			inputValueArray[2] = dist3;
			inputValueArray[3] = dist4;
			inputValueArray[4] = feedDist;
			inputValueArray[5] = statusValue;

			inputValueArray[6] = 0.0f;

			if (g_GameBoardPathData[testPosY[1]][testPosX[1]] == ConstGameBoard_PathElement || g_GameBoardPathData[testPosY[1]][testPosX[1]] == ConstGameBoard_Feed)
				inputValueArray[6] = 1.0f;

			Brain.Calculate_Output(outputValueArray, inputValueArray);
			movementEvaluation = outputValueArray[0];

			if (movementEvaluation > bestMovementEvaluation)
			{
				bestMovementEvaluation = movementEvaluation;
				id = 1;
			}
		}

		testPosX[2] = PosX;
		testPosY[2] = PosY - 1;

		
		if (testPosX[2] != OldPosX || testPosY[2] != OldPosY)
		{
			Calculate_ObstacleDistances(testPosX[2], testPosY[2], &dist1, &dist2, &dist3, &dist4);

			stepsX = abs(testPosX[2] - g_GameBoard_FeedPosX);
			stepsY = abs(testPosY[2] - g_GameBoard_FeedPosY);
			feedDist = stepsX + stepsY;

			inputValueArray[0] = dist1;
			inputValueArray[1] = dist2;
			inputValueArray[2] = dist3;
			inputValueArray[3] = dist4;
			inputValueArray[4] = feedDist;
			inputValueArray[5] = statusValue;

			inputValueArray[6] = 0.0f;

			if (g_GameBoardPathData[testPosY[2]][testPosX[2]] == ConstGameBoard_PathElement || g_GameBoardPathData[testPosY[2]][testPosX[2]] == ConstGameBoard_Feed)
				inputValueArray[6] = 1.0f;

			Brain.Calculate_Output(outputValueArray, inputValueArray);
			movementEvaluation = outputValueArray[0];

			if (movementEvaluation > bestMovementEvaluation)
			{
				bestMovementEvaluation = movementEvaluation;
				id = 2;
			}
		}

		testPosX[3] = PosX;
		testPosY[3] = PosY + 1;

		
		if (testPosX[3] != OldPosX || testPosY[3] != OldPosY)
		{
			Calculate_ObstacleDistances(testPosX[3], testPosY[3], &dist1, &dist2, &dist3, &dist4);

			stepsX = abs(testPosX[3] - g_GameBoard_FeedPosX);
			stepsY = abs(testPosY[3] - g_GameBoard_FeedPosY);
			feedDist = stepsX + stepsY;

			inputValueArray[0] = dist1;
			inputValueArray[1] = dist2;
			inputValueArray[2] = dist3;
			inputValueArray[3] = dist4;
			inputValueArray[4] = feedDist;
			inputValueArray[5] = statusValue;

			inputValueArray[6] = 0.0f;

			if (g_GameBoardPathData[testPosY[3]][testPosX[3]] == ConstGameBoard_PathElement || g_GameBoardPathData[testPosY[3]][testPosX[3]] == ConstGameBoard_Feed)
				inputValueArray[6] = 1.0f;

			Brain.Calculate_Output(outputValueArray, inputValueArray);
			movementEvaluation = outputValueArray[0];

			if (movementEvaluation > bestMovementEvaluation)
			{
				bestMovementEvaluation = movementEvaluation;
				id = 3;
			}
		}
		
		OldPosX2 = OldPosX;
		OldPosY2 = OldPosY;

		OldPosX = PosX;
		OldPosY = PosY;

		PosX = testPosX[id];
		PosY = testPosY[id];
	}

	void Update_TrainingPos(int32_t *pOutFeedDistChange)
	{
		int32_t dist1, dist2, dist3, dist4;
		int32_t testPosX[4];
		int32_t testPosY[4];
		float movementEvaluation;
		float feedDist, stepsX, stepsY;

		//float statusValue = 0.01f*static_cast<float>(LivingPoints);
		float statusValue = 0.1f*static_cast<float>(LivingPoints);

		float bestMovementEvaluation = -1000.0f;
		int32_t id = 0;

		float inputValueArray[7];
		float outputValueArray[1];

		testPosX[0] = PosX - 1;
		testPosY[0] = PosY;

		if (testPosX[0] != OldPosX || testPosY[0] != OldPosY)
		{
			Calculate_ObstacleDistances(testPosX[0], testPosY[0], &dist1, &dist2, &dist3, &dist4);

			stepsX = abs(testPosX[0] - g_GameBoard_FeedPosX);
			stepsY = abs(testPosY[0] - g_GameBoard_FeedPosY);
			feedDist = stepsX + stepsY;

			inputValueArray[0] = dist1;
			inputValueArray[1] = dist2;
			inputValueArray[2] = dist3;
			inputValueArray[3] = dist4;
			inputValueArray[4] = feedDist;
			inputValueArray[5] = statusValue;

			inputValueArray[6] = 0.0f;

			if (g_GameBoardPathData[testPosY[0]][testPosX[0]] == ConstGameBoard_PathElement || g_GameBoardPathData[testPosY[0]][testPosX[0]] == ConstGameBoard_Feed)
				inputValueArray[6] = 1.0f;

			Brain.Calculate_Output(outputValueArray, inputValueArray);
			movementEvaluation = outputValueArray[0];

			if (movementEvaluation > bestMovementEvaluation)
			{
				bestMovementEvaluation = movementEvaluation;
				id = 0;
			}
		}

		testPosX[1] = PosX + 1;
		testPosY[1] = PosY;


		if (testPosX[1] != OldPosX || testPosY[1] != OldPosY)
		{
			Calculate_ObstacleDistances(testPosX[1], testPosY[1], &dist1, &dist2, &dist3, &dist4);

			stepsX = abs(testPosX[1] - g_GameBoard_FeedPosX);
			stepsY = abs(testPosY[1] - g_GameBoard_FeedPosY);
			feedDist = stepsX + stepsY;

			inputValueArray[0] = dist1;
			inputValueArray[1] = dist2;
			inputValueArray[2] = dist3;
			inputValueArray[3] = dist4;
			inputValueArray[4] = feedDist;
			inputValueArray[5] = statusValue;

			inputValueArray[6] = 0.0f;

			if (g_GameBoardPathData[testPosY[1]][testPosX[1]] == ConstGameBoard_PathElement || g_GameBoardPathData[testPosY[1]][testPosX[1]] == ConstGameBoard_Feed)
				inputValueArray[6] = 1.0f;

			Brain.Calculate_Output(outputValueArray, inputValueArray);
			movementEvaluation = outputValueArray[0];

			if (movementEvaluation > bestMovementEvaluation)
			{
				bestMovementEvaluation = movementEvaluation;
				id = 1;
			}
		}

		testPosX[2] = PosX;
		testPosY[2] = PosY - 1;


		if (testPosX[2] != OldPosX || testPosY[2] != OldPosY)
		{
			Calculate_ObstacleDistances(testPosX[2], testPosY[2], &dist1, &dist2, &dist3, &dist4);

			stepsX = abs(testPosX[2] - g_GameBoard_FeedPosX);
			stepsY = abs(testPosY[2] - g_GameBoard_FeedPosY);
			feedDist = stepsX + stepsY;

			inputValueArray[0] = dist1;
			inputValueArray[1] = dist2;
			inputValueArray[2] = dist3;
			inputValueArray[3] = dist4;
			inputValueArray[4] = feedDist;
			inputValueArray[5] = statusValue;

			inputValueArray[6] = 0.0f;

			if (g_GameBoardPathData[testPosY[2]][testPosX[2]] == ConstGameBoard_PathElement || g_GameBoardPathData[testPosY[2]][testPosX[2]] == ConstGameBoard_Feed)
				inputValueArray[6] = 1.0f;

			Brain.Calculate_Output(outputValueArray, inputValueArray);
			movementEvaluation = outputValueArray[0];

			if (movementEvaluation > bestMovementEvaluation)
			{
				bestMovementEvaluation = movementEvaluation;
				id = 2;
			}
		}

		testPosX[3] = PosX;
		testPosY[3] = PosY + 1;


		if (testPosX[3] != OldPosX || testPosY[3] != OldPosY)
		{
			Calculate_ObstacleDistances(testPosX[3], testPosY[3], &dist1, &dist2, &dist3, &dist4);

			stepsX = abs(testPosX[3] - g_GameBoard_FeedPosX);
			stepsY = abs(testPosY[3] - g_GameBoard_FeedPosY);
			feedDist = stepsX + stepsY;

			inputValueArray[0] = dist1;
			inputValueArray[1] = dist2;
			inputValueArray[2] = dist3;
			inputValueArray[3] = dist4;
			inputValueArray[4] = feedDist;
			inputValueArray[5] = statusValue;

			inputValueArray[6] = 0.0f;

			if (g_GameBoardPathData[testPosY[3]][testPosX[3]] == ConstGameBoard_PathElement || g_GameBoardPathData[testPosY[3]][testPosX[3]] == ConstGameBoard_Feed)
				inputValueArray[6] = 1.0f;

			Brain.Calculate_Output(outputValueArray, inputValueArray);
			movementEvaluation = outputValueArray[0];

			if (movementEvaluation > bestMovementEvaluation)
			{
				bestMovementEvaluation = movementEvaluation;
				id = 3;
			}
		}

		OldPosX2 = OldPosX;
		OldPosY2 = OldPosY;

		OldPosX = PosX;
		OldPosY = PosY;

		PosX = testPosX[id];
		PosY = testPosY[id];


		if (g_GameBoard[PosY][PosX] == ConstGameBoard_ObstacleElement)
			NumOfWrongMovementSteps += 10;
		

		if (PosX == OldPosX2 && PosY == OldPosY2)
			LivingPoints -= 2;
		

		stepsX = abs(OldPosX - g_GameBoard_FeedPosX);
		stepsY = abs(OldPosY - g_GameBoard_FeedPosY);

		if (stepsX < 2 && stepsY < 2)
		{
			if (PosX != g_GameBoard_FeedPosX || PosY != g_GameBoard_FeedPosY)
				NumOfWrongMovementSteps += 1;
				//LivingPoints -= 10;
			
		}


		float feedDistChange = (abs(OldPosX - g_GameBoard_FeedPosX) + abs(OldPosX - g_GameBoard_FeedPosY)) - (abs(PosX - g_GameBoard_FeedPosX) + abs(PosX - g_GameBoard_FeedPosY));

		if (feedDistChange > 0)
			*pOutFeedDistChange = 1;
		else
			*pOutFeedDistChange = -1;

	}

	void Update_Pos_Randomly(void)
	{
		int32_t randomValueX, randomValueY;

		OldPosX = PosX;
		OldPosY = PosY;

		do
		{
			randomValueX = RandomNumbers_BirthPos.Get_IntegerNumber(0, 3) - 1;
			randomValueY = RandomNumbers_BirthPos.Get_IntegerNumber(0, 3) - 1;

			if (randomValueX != 0 && randomValueY != 0)
				continue;

			PosX += randomValueX;
			PosX = max(PosX, 0);
			PosX = min(PosX, ConstGameBoardSizeXMinus1);

			PosY += randomValueY;
			PosY = max(PosY, 0);
			PosY = min(PosY, ConstGameBoardSizeYMinus1);

			if (OldPosX != PosX)
				break;
			else if (OldPosY != PosY)
				break;

			PosX = OldPosX;
			PosY = OldPosY;

		} while (true);
	}
};






void Simulate_Lifeform_During_Evolution(CLifeform *pLifeform, float *pOutFittingScore, float rewardValue1, float rewardValue2, float rewardValue3, float rewardValue4 = -100.0f)
{
	float feedCounter = 0.0f;

	GameBoard_Reset_Feed();
	g_RandomNumbers_FeedUpdate.Change_Seed(g_FeedPosSeed);
	

	feedCounter += GameBoard_UpdateFeed();

	pLifeform->Set_BirthPosSeed_And_Birth(g_BirthPosSeed);
	
	int32_t feedDistChange;

	float simulationScore = 0.0f;
	int32_t simulationSteps = 0;

	do
	{
		feedCounter += GameBoard_UpdateFeed();

		pLifeform->Update_TrainingPos(&feedDistChange);
		
		pLifeform->Update_LivingStatus();

		if (pLifeform->Living == false)
		{
			break;
		}
		else if (pLifeform->Living == true)
		{
			simulationSteps++;

			simulationScore += rewardValue1;

			if(feedDistChange > 0)
				simulationScore += rewardValue2;
		}

		if (simulationSteps >= g_MaxSimulationSteps)
		{
			break;
		}

	} while (true);

	
	*pOutFittingScore = simulationScore + rewardValue3*feedCounter + rewardValue4*pLifeform->NumOfWrongMovementSteps;
}


void Update_Evolution1(uint64_t seed, uint32_t numGenerationsMax, uint32_t populationSize, uint32_t numOfRandomEvolutionSteps, CLifeform *pLifeformArray, float *pFittingScoreArray, uint32_t *pIdOfBestFittedLifeform, uint32_t *pIdOfSecondBestFittedLifeform, uint32_t *pIdOfWorstFittedLifeform, uint32_t *pIdOfSecondWorstFittedLifeform, uint32_t *pSimulatedGenerations, float *pMaxFittingScore)
{
	CRandomNumbersNN RandomNumbers;

	uint64_t birthPosSeed, feedPosSeed;

	uint32_t idOfBestFittedLifeform = 0;
	uint32_t idOfSecondBestFittedLifeform = 0;
	uint32_t idOfWorstFittedLifeform = 0;
	uint32_t idOfSecondWorstFittedLifeform = 0;

	float minFittingScore, maxFittingScore;
	float secondMinFittingScore, secondMaxFittingScore;

	float fittingScore;

	uint32_t generation = 0;

	for (uint32_t j = 0; j < numGenerationsMax; j++)
	{
		generation++;

		uint32_t numOfRepetitions = 10;
		//uint32_t numOfRepetitions = RandomNumbers.Get_UnsignedIntegerNumber(0, 10);

		for (uint32_t i = 0; i < populationSize; i++)
		{
			birthPosSeed = 6545;
			feedPosSeed = 11458;

			pFittingScoreArray[i] = 0.0f;

			Simulate_Lifeform_During_Evolution(&pLifeformArray[i], &fittingScore, -0.5f, 2.0f, 50.0f, -100.0f);
			

			pFittingScoreArray[i] += 0.001f*fittingScore;

			for (uint32_t k = 0; k < numOfRepetitions; k++)
			{
				birthPosSeed++;
				feedPosSeed++;

				Simulate_Lifeform_During_Evolution(&pLifeformArray[i], &fittingScore, -0.5f, 2.0f, 50.0f, -100.0f);
			
				pFittingScoreArray[i] += 0.001f*fittingScore;
			}

			pFittingScoreArray[i] /= static_cast<float>(numOfRepetitions + 1);
		} /* end of for (uint32_t i = 0; i < populationSize; i++)*/

		idOfBestFittedLifeform = 0;
		idOfSecondBestFittedLifeform = 0;

		idOfWorstFittedLifeform = 0;
		idOfSecondWorstFittedLifeform = 0;

		minFittingScore = 100000000.0f;
		maxFittingScore = -100000000.0f;

		float sumOfFittingScores = 0.0f;

		for (uint32_t i = 0; i < populationSize; i++)
		{
			sumOfFittingScores += pFittingScoreArray[i];

			if (pFittingScoreArray[i] > maxFittingScore)
			{
				secondMaxFittingScore = maxFittingScore;
				maxFittingScore = pFittingScoreArray[i];

				idOfSecondBestFittedLifeform = idOfBestFittedLifeform;
				idOfBestFittedLifeform = i;
			}
			else
			{
				if (pFittingScoreArray[i] > secondMaxFittingScore)
				{
					secondMaxFittingScore = pFittingScoreArray[i];
					idOfSecondBestFittedLifeform = i;
				}
			}

			if (pFittingScoreArray[i] < minFittingScore)
			{
				secondMinFittingScore = minFittingScore;
				minFittingScore = pFittingScoreArray[i];
				idOfSecondWorstFittedLifeform = idOfWorstFittedLifeform;
				idOfWorstFittedLifeform = i;
			}
			else
			{
				if (pFittingScoreArray[i] < secondMinFittingScore)
				{
					secondMinFittingScore = pFittingScoreArray[i];
					idOfSecondWorstFittedLifeform = i;
				}
			}
		} /* end of for (uint32_t i = 0; i < populationSize; i++)*/

		
		if (j < numOfRandomEvolutionSteps)
		{
			for (uint32_t i = 0; i < populationSize; i++)
			{
				if (i != idOfBestFittedLifeform && i != idOfSecondBestFittedLifeform)
				{
					pLifeformArray[i].Brain.RandomChange_OutputSynapsePlasticities(seed++, -0.1f, 0.1f);
				}
			}
			//cout << "RandomEvolutionStep: " << endl;
		}
		else if (j >= numOfRandomEvolutionSteps)
		{

#ifdef EvolutionVariant1

			for (uint32_t i = 0; i < populationSize; i++)
			{
				if (i != idOfBestFittedLifeform && i != idOfSecondBestFittedLifeform &&  i != idOfWorstFittedLifeform && i != idOfSecondWorstFittedLifeform)
				{
					if (RandomNumbers.Get_IntegerNumber(2, 4) == 2)
						pLifeformArray[i].Brain.Combine_OutputSynapsePlasticities(&pLifeformArray[idOfBestFittedLifeform].Brain, &pLifeformArray[idOfSecondBestFittedLifeform].Brain, 0.0f, seed++);
					else
						pLifeformArray[i].Brain.RandomChange_OutputSynapsePlasticities(seed++, -0.1f, 0.1f);
					//pLifeformArray[i].Brain.Clone_OutputSynapsePlasticities(&pLifeformArray[idOfBestFittedLifeform].Brain, 0.001f, seed++);
				}
			}

			pLifeformArray[idOfWorstFittedLifeform].Brain.Clone_OutputSynapsePlasticities(&pLifeformArray[idOfBestFittedLifeform].Brain, 0.001f, seed++);
			pLifeformArray[idOfSecondWorstFittedLifeform].Brain.Clone_OutputSynapsePlasticities(&pLifeformArray[idOfBestFittedLifeform].Brain, 0.001f, seed++);

#endif
#ifdef EvolutionVariant2

			for (uint32_t i = 0; i < populationSize; i++)
			{
				if (i != idOfBestFittedLifeform && i != idOfSecondBestFittedLifeform &&  i != idOfWorstFittedLifeform && i != idOfSecondWorstFittedLifeform)
				{
					if (RandomNumbers.Get_IntegerNumber(2, 4) == 2)
						pLifeformArray[i].Brain.Combine_OutputSynapsePlasticities(&pLifeformArray[idOfBestFittedLifeform].Brain, &pLifeformArray[idOfSecondBestFittedLifeform].Brain, 0.0f, seed++);
					else
					{
						if (RandomNumbers.Get_IntegerNumber(2, 5) == 2)  // frisches Blut:
						//if (RandomNumbers.Get_IntegerNumber(2, 4) == 2)  // frisches Blut:
						{
							pLifeformArray[i].Brain.RandomChange_OutputSynapsePlasticities(seed++, -0.1f, 0.1f);
							//pLifeformArray[i].Brain.Clone_OutputSynapsePlasticities(&pLifeformArray[idOfBestFittedLifeform].Brain, 0.001f, seed++);
						}
						else
						{
							pLifeformArray[i].Brain.Combine_OutputSynapsePlasticities(&pLifeformArray[RandomNumbers.Get_UnsignedIntegerNumber(0, populationSize)].Brain, &pLifeformArray[RandomNumbers.Get_UnsignedIntegerNumber(0, populationSize)].Brain, 0.0f, seed++);
						}
					}
				}
			}

			pLifeformArray[idOfWorstFittedLifeform].Brain.Clone_OutputSynapsePlasticities(&pLifeformArray[idOfBestFittedLifeform].Brain, 0.001f, seed++);
			pLifeformArray[idOfSecondWorstFittedLifeform].Brain.Clone_OutputSynapsePlasticities(&pLifeformArray[idOfBestFittedLifeform].Brain, 0.001f, seed++);

#endif
#ifdef EvolutionVariant3

			for (uint32_t i = 0; i < populationSize; i++)
			{
				if (i == idOfBestFittedLifeform || i == idOfSecondBestFittedLifeform)
				{
				}
				else if (i == idOfWorstFittedLifeform)
				{
					pLifeformArray[idOfWorstFittedLifeform].Brain.Clone_OutputSynapsePlasticities(&pLifeformArray[idOfBestFittedLifeform].Brain, 0.001f, seed++);
				}
				else if (i == idOfSecondWorstFittedLifeform)
				{
					pLifeformArray[idOfSecondWorstFittedLifeform].Brain.Clone_OutputSynapsePlasticities(&pLifeformArray[idOfBestFittedLifeform].Brain, 0.001f, seed++);
				}
				else
				{
					if (RandomNumbers.Get_IntegerNumber(2, 6) == 2)  // frisches Blut:
					{
						pLifeformArray[i].Brain.RandomChange_OutputSynapsePlasticities(seed++, -0.1f, 0.1f);
					}
					else
					{
						if (RandomNumbers.Get_IntegerNumber(2, 5) == 2)
						{
							pLifeformArray[i].Brain.Combine_OutputSynapsePlasticities(&pLifeformArray[idOfBestFittedLifeform].Brain, &pLifeformArray[idOfSecondBestFittedLifeform].Brain, 0.0f, seed++);
						}
						else
						{
							pLifeformArray[i].Brain.Combine_OutputSynapsePlasticities(&pLifeformArray[RandomNumbers.Get_UnsignedIntegerNumber(0, populationSize)].Brain, &pLifeformArray[RandomNumbers.Get_UnsignedIntegerNumber(0, populationSize)].Brain, 0.0f, seed++);
						}
					}
				}
			}

#endif
			
		} // end of else if (j >= numOfRandomEvolutionSteps)
		

		//if(j % 100 == 0)
		{
			cout << "generation: " << generation << endl;
			cout << "actualMaxFittingScore: " << maxFittingScore << " sumOfScores: " << sumOfFittingScores << endl;
		}


		if (KEYDOWN(VK_F1) == true)
			break;

	} /*end of for (uint32_t j = 0; j < numGenerationsMax; j++)*/

	*pSimulatedGenerations = generation;
	*pMaxFittingScore = maxFittingScore;

	*pIdOfBestFittedLifeform = idOfBestFittedLifeform;
	*pIdOfSecondBestFittedLifeform = idOfSecondBestFittedLifeform;
	*pIdOfWorstFittedLifeform = idOfWorstFittedLifeform;
	*pIdOfSecondWorstFittedLifeform = idOfSecondWorstFittedLifeform;
}

void Update_Evolution2(uint64_t seed, uint32_t numGenerationsMax, uint32_t populationSize, uint32_t numOfRandomEvolutionSteps, CLifeform *pLifeformArray, float *pFittingScoreArray, uint32_t *pIdOfBestFittedLifeform, uint32_t *pIdOfSecondBestFittedLifeform, uint32_t *pIdOfWorstFittedLifeform, uint32_t *pIdOfSecondWorstFittedLifeform, uint32_t *pSimulatedGenerations, float *pMaxFittingScore)
{
	CRandomNumbersNN RandomNumbers;

	uint64_t birthPosSeed, feedPosSeed;

	uint32_t idOfBestFittedLifeform = 0;
	uint32_t idOfSecondBestFittedLifeform = 0;
	uint32_t idOfWorstFittedLifeform = 0;
	uint32_t idOfSecondWorstFittedLifeform = 0;

	float minFittingScore, maxFittingScore;
	float secondMinFittingScore, secondMaxFittingScore;

	float fittingScore;

	uint32_t generation = 0;

	birthPosSeed = 6545;
	feedPosSeed = 11458;


	for (uint32_t j = 0; j < numGenerationsMax; j++)
	{
		generation++;

		birthPosSeed++;
		feedPosSeed++;

		for (uint32_t i = 0; i < populationSize; i++)
		{
			pFittingScoreArray[i] = 0.0f;

			Simulate_Lifeform_During_Evolution(&pLifeformArray[i], &fittingScore, -0.5f, 2.0f, 50.0f, -100.0f);
			
			pFittingScoreArray[i] += 0.001f*fittingScore;

		} /* end of for (uint32_t i = 0; i < populationSize; i++)*/

		idOfBestFittedLifeform = 0;
		idOfSecondBestFittedLifeform = 0;

		idOfWorstFittedLifeform = 0;
		idOfSecondWorstFittedLifeform = 0;

		minFittingScore = 100000000.0f;
		maxFittingScore = -100000000.0f;

		float sumOfFittingScores = 0.0f;

		for (uint32_t i = 0; i < populationSize; i++)
		{
			sumOfFittingScores += pFittingScoreArray[i];

			if (pFittingScoreArray[i] > maxFittingScore)
			{
				secondMaxFittingScore = maxFittingScore;
				maxFittingScore = pFittingScoreArray[i];

				idOfSecondBestFittedLifeform = idOfBestFittedLifeform;
				idOfBestFittedLifeform = i;
			}
			else
			{
				if (pFittingScoreArray[i] > secondMaxFittingScore)
				{
					secondMaxFittingScore = pFittingScoreArray[i];
					idOfSecondBestFittedLifeform = i;
				}
			}

			if (pFittingScoreArray[i] < minFittingScore)
			{
				secondMinFittingScore = minFittingScore;
				minFittingScore = pFittingScoreArray[i];
				idOfSecondWorstFittedLifeform = idOfWorstFittedLifeform;
				idOfWorstFittedLifeform = i;
			}
			else
			{
				if (pFittingScoreArray[i] < secondMinFittingScore)
				{
					secondMinFittingScore = pFittingScoreArray[i];
					idOfSecondWorstFittedLifeform = i;
				}
			}
		} /* end of for (uint32_t i = 0; i < populationSize; i++)*/


		if (j < numOfRandomEvolutionSteps)
		{
			for (uint32_t i = 0; i < populationSize; i++)
			{
				if (i != idOfBestFittedLifeform && i != idOfSecondBestFittedLifeform)
				{
					pLifeformArray[i].Brain.RandomChange_OutputSynapsePlasticities(seed++, -0.1f, 0.1f);
				}

				if(i == idOfWorstFittedLifeform || i == idOfSecondWorstFittedLifeform)
				{
					pLifeformArray[i].Brain.Clone_OutputSynapsePlasticities(&pLifeformArray[idOfBestFittedLifeform].Brain, 0.001f, seed++);
				}
			}
			//cout << "RandomEvolutionStep: " << endl;
		}
		else if (j >= numOfRandomEvolutionSteps)
		{

#ifdef EvolutionVariant1

			for (uint32_t i = 0; i < populationSize; i++)
			{
				if (i != idOfBestFittedLifeform && i != idOfSecondBestFittedLifeform &&  i != idOfWorstFittedLifeform && i != idOfSecondWorstFittedLifeform)
				{
					if (RandomNumbers.Get_IntegerNumber(2, 4) == 2)
						pLifeformArray[i].Brain.Combine_OutputSynapsePlasticities(&pLifeformArray[idOfBestFittedLifeform].Brain, &pLifeformArray[idOfSecondBestFittedLifeform].Brain, 0.0f, seed++);
					else
						pLifeformArray[i].Brain.RandomChange_OutputSynapsePlasticities(seed++, -0.1f, 0.1f);
					//pLifeformArray[i].Brain.Clone_OutputSynapsePlasticities(&pLifeformArray[idOfBestFittedLifeform].Brain, 0.001f, seed++);
				}
			}

			pLifeformArray[idOfWorstFittedLifeform].Brain.Clone_OutputSynapsePlasticities(&pLifeformArray[idOfBestFittedLifeform].Brain, 0.001f, seed++);
			pLifeformArray[idOfSecondWorstFittedLifeform].Brain.Clone_OutputSynapsePlasticities(&pLifeformArray[idOfBestFittedLifeform].Brain, 0.001f, seed++);

#endif
#ifdef EvolutionVariant2

			for (uint32_t i = 0; i < populationSize; i++)
			{
				if (i != idOfBestFittedLifeform && i != idOfSecondBestFittedLifeform &&  i != idOfWorstFittedLifeform && i != idOfSecondWorstFittedLifeform)
				{
					if (RandomNumbers.Get_IntegerNumber(2, 4) == 2)
						pLifeformArray[i].Brain.Combine_OutputSynapsePlasticities(&pLifeformArray[idOfBestFittedLifeform].Brain, &pLifeformArray[idOfSecondBestFittedLifeform].Brain, 0.0f, seed++);
					else
					{
						if (RandomNumbers.Get_IntegerNumber(2, 5) == 2)  // frisches Blut:
																		 //if (RandomNumbers.Get_IntegerNumber(2, 4) == 2)  // frisches Blut:
						{
							pLifeformArray[i].Brain.RandomChange_OutputSynapsePlasticities(seed++, -0.1f, 0.1f);
							//pLifeformArray[i].Brain.Clone_OutputSynapsePlasticities(&pLifeformArray[idOfBestFittedLifeform].Brain, 0.001f, seed++);
						}
						else
						{
							pLifeformArray[i].Brain.Combine_OutputSynapsePlasticities(&pLifeformArray[RandomNumbers.Get_UnsignedIntegerNumber(0, populationSize)].Brain, &pLifeformArray[RandomNumbers.Get_UnsignedIntegerNumber(0, populationSize)].Brain, 0.0f, seed++);
						}
					}
				}
			}

			pLifeformArray[idOfWorstFittedLifeform].Brain.Clone_OutputSynapsePlasticities(&pLifeformArray[idOfBestFittedLifeform].Brain, 0.001f, seed++);
			pLifeformArray[idOfSecondWorstFittedLifeform].Brain.Clone_OutputSynapsePlasticities(&pLifeformArray[idOfBestFittedLifeform].Brain, 0.001f, seed++);

#endif
#ifdef EvolutionVariant3

			for (uint32_t i = 0; i < populationSize; i++)
			{
				if (i == idOfBestFittedLifeform || i == idOfSecondBestFittedLifeform)
				{
				}
				else if (i == idOfWorstFittedLifeform)
				{
					pLifeformArray[idOfWorstFittedLifeform].Brain.Clone_OutputSynapsePlasticities(&pLifeformArray[idOfBestFittedLifeform].Brain, 0.001f, seed++);
				}
				else if (i == idOfSecondWorstFittedLifeform)
				{
					pLifeformArray[idOfSecondWorstFittedLifeform].Brain.Clone_OutputSynapsePlasticities(&pLifeformArray[idOfBestFittedLifeform].Brain, 0.001f, seed++);
				}
				else
				{
					if (RandomNumbers.Get_IntegerNumber(2, 6) == 2)  // frisches Blut:
					{
						pLifeformArray[i].Brain.RandomChange_OutputSynapsePlasticities(seed++, -0.1f, 0.1f);
					}
					else
					{
						if (RandomNumbers.Get_IntegerNumber(2, 5) == 2)
						{
							pLifeformArray[i].Brain.Combine_OutputSynapsePlasticities(&pLifeformArray[idOfBestFittedLifeform].Brain, &pLifeformArray[idOfSecondBestFittedLifeform].Brain, 0.0f, seed++);
						}
						else
						{
							pLifeformArray[i].Brain.Combine_OutputSynapsePlasticities(&pLifeformArray[RandomNumbers.Get_UnsignedIntegerNumber(0, populationSize)].Brain, &pLifeformArray[RandomNumbers.Get_UnsignedIntegerNumber(0, populationSize)].Brain, 0.0f, seed++);
						}
					}
				}
			}

#endif

		} // end of else if (j >= numOfRandomEvolutionSteps)


		  //if(j % 100 == 0)
		{
			cout << "generation: " << generation << endl;
			cout << "actualMaxFittingScore: " << maxFittingScore << " sumOfScores: " << sumOfFittingScores << endl;
		}


		if (KEYDOWN(VK_F1) == true)
			break;

	} /*end of for (uint32_t j = 0; j < numGenerationsMax; j++)*/

	*pSimulatedGenerations = generation;
	*pMaxFittingScore = maxFittingScore;

	*pIdOfBestFittedLifeform = idOfBestFittedLifeform;
	*pIdOfSecondBestFittedLifeform = idOfSecondBestFittedLifeform;
	*pIdOfWorstFittedLifeform = idOfWorstFittedLifeform;
	*pIdOfSecondWorstFittedLifeform = idOfSecondWorstFittedLifeform;
}


void Init_GamesWorld1(void)
{
	g_GameBoard[6][4] = ConstGameBoard_ObstacleElement;
	g_GameBoard[6][5] = ConstGameBoard_ObstacleElement;
	g_GameBoard[6][6] = ConstGameBoard_ObstacleElement;
	g_GameBoard[6][7] = ConstGameBoard_ObstacleElement;
	g_GameBoard[6][8] = ConstGameBoard_ObstacleElement;

	g_GameBoardPathData[5][3] = ConstGameBoard_PathElement;
	g_GameBoardPathData[5][4] = ConstGameBoard_PathElement;
	g_GameBoardPathData[5][5] = ConstGameBoard_PathElement;
	g_GameBoardPathData[5][6] = ConstGameBoard_PathElement;
	g_GameBoardPathData[5][7] = ConstGameBoard_PathElement;
	g_GameBoardPathData[5][8] = ConstGameBoard_PathElement;
	g_GameBoardPathData[5][9] = ConstGameBoard_PathElement;

	g_GameBoardPathData[6][3] = ConstGameBoard_PathElement;
	g_GameBoardPathData[6][9] = ConstGameBoard_PathElement;

	g_GameBoardPathData[7][3] = ConstGameBoard_PathElement;
	g_GameBoardPathData[7][4] = ConstGameBoard_PathElement;
	g_GameBoardPathData[7][5] = ConstGameBoard_PathElement;
	g_GameBoardPathData[7][6] = ConstGameBoard_PathElement;
	g_GameBoardPathData[7][7] = ConstGameBoard_PathElement;
	g_GameBoardPathData[7][8] = ConstGameBoard_PathElement;
	g_GameBoardPathData[7][9] = ConstGameBoard_PathElement;
}

void Init_GamesWorld2(void)
{
	g_GameBoard[4][4] = ConstGameBoard_ObstacleElement;
	g_GameBoard[4][5] = ConstGameBoard_ObstacleElement;
	g_GameBoard[4][6] = ConstGameBoard_ObstacleElement;
	g_GameBoard[4][7] = ConstGameBoard_ObstacleElement;
	g_GameBoard[4][8] = ConstGameBoard_ObstacleElement;

	g_GameBoardPathData[3][3] = ConstGameBoard_PathElement;
	g_GameBoardPathData[3][4] = ConstGameBoard_PathElement;
	g_GameBoardPathData[3][5] = ConstGameBoard_PathElement;
	g_GameBoardPathData[3][6] = ConstGameBoard_PathElement;
	g_GameBoardPathData[3][7] = ConstGameBoard_PathElement;
	g_GameBoardPathData[3][8] = ConstGameBoard_PathElement;
	g_GameBoardPathData[3][9] = ConstGameBoard_PathElement;

	g_GameBoardPathData[4][3] = ConstGameBoard_PathElement;
	g_GameBoardPathData[4][9] = ConstGameBoard_PathElement;

	g_GameBoardPathData[5][3] = ConstGameBoard_PathElement;
	g_GameBoardPathData[5][4] = ConstGameBoard_PathElement;
	g_GameBoardPathData[5][5] = ConstGameBoard_PathElement;
	g_GameBoardPathData[5][6] = ConstGameBoard_PathElement;
	g_GameBoardPathData[5][7] = ConstGameBoard_PathElement;
	g_GameBoardPathData[5][8] = ConstGameBoard_PathElement;
	g_GameBoardPathData[5][9] = ConstGameBoard_PathElement;

	g_GameBoard[9][10] = ConstGameBoard_ObstacleElement;
	g_GameBoard[10][10] = ConstGameBoard_ObstacleElement;
	g_GameBoard[11][10] = ConstGameBoard_ObstacleElement;

	g_GameBoardPathData[8][9] = ConstGameBoard_PathElement;
	g_GameBoardPathData[9][9] = ConstGameBoard_PathElement;
	g_GameBoardPathData[10][9] = ConstGameBoard_PathElement;
	g_GameBoardPathData[11][9] = ConstGameBoard_PathElement;
	g_GameBoardPathData[12][9] = ConstGameBoard_PathElement;

	g_GameBoardPathData[8][10] = ConstGameBoard_PathElement;
	g_GameBoardPathData[12][10] = ConstGameBoard_PathElement;

	g_GameBoardPathData[8][11] = ConstGameBoard_PathElement;
	g_GameBoardPathData[9][11] = ConstGameBoard_PathElement;
	g_GameBoardPathData[10][11] = ConstGameBoard_PathElement;
	g_GameBoardPathData[11][11] = ConstGameBoard_PathElement;
	g_GameBoardPathData[12][11] = ConstGameBoard_PathElement;


	g_GameBoardPathData[7][2] = ConstGameBoard_PathElement;
	g_GameBoardPathData[7][3] = ConstGameBoard_PathElement;
	g_GameBoardPathData[7][4] = ConstGameBoard_PathElement;

	g_GameBoardPathData[8][2] = ConstGameBoard_PathElement;
	g_GameBoard[8][3] = ConstGameBoard_ObstacleElement;
	g_GameBoardPathData[8][4] = ConstGameBoard_PathElement;

	g_GameBoardPathData[9][3] = ConstGameBoard_PathElement;
	g_GameBoard[9][4] = ConstGameBoard_ObstacleElement;
	g_GameBoardPathData[9][5] = ConstGameBoard_PathElement;

	g_GameBoardPathData[10][4] = ConstGameBoard_PathElement;
	g_GameBoard[10][5] = ConstGameBoard_ObstacleElement;
	g_GameBoardPathData[10][6] = ConstGameBoard_PathElement;

	g_GameBoardPathData[11][5] = ConstGameBoard_PathElement;
	g_GameBoard[11][6] = ConstGameBoard_ObstacleElement;
	g_GameBoardPathData[11][7] = ConstGameBoard_PathElement;

	g_GameBoardPathData[12][5] = ConstGameBoard_PathElement;
	g_GameBoardPathData[12][6] = ConstGameBoard_PathElement;
	g_GameBoardPathData[12][7] = ConstGameBoard_PathElement;
}


/*
int main(void)
{
    uint32_t i;
	uint64_t seed = 1;
	
	CRandomNumbersNN RandomNumbers;

	Init_Or_Reset_GameBoardArrays();
	Init_GameBoardBorders();

	
	
	//Init_GamesWorld1();
	Init_GamesWorld2();
	


	
	static constexpr uint32_t PopulationSize = 10;

	static CLifeform LifeformArray[PopulationSize];

	
	static float FittingScoreArray[PopulationSize];

	for (i = 0; i < PopulationSize; i++)
	{
		LifeformArray[i].Brain.RandomChange_OutputSynapsePlasticities(seed++, -0.1f, 0.1f);
	}

	uint32_t IdOfBestFittedLifeform = 0;
	uint32_t IdOfSecondBestFittedLifeform = 0;
	uint32_t IdOfWorstFittedLifeform = 0;
	uint32_t IdOfSecondWorstFittedLifeform = 0;

	uint32_t numGenerationsMax = 2000;
	uint32_t numOfRandomEvolutionSteps = 0;

	uint32_t simulatedGenerations = 0;
	float maxFittingScore;


	cout << "F1: stop evolution (Press Return): ";
	getchar();

	cout << "NumGenerations: ";
	cin.getline(g_InputBuffer, 100);
	numGenerationsMax = atoi(g_InputBuffer);

	cout << "NumOfRandomEvolutionSteps: ";
	cin.getline(g_InputBuffer, 100);
	numOfRandomEvolutionSteps = atoi(g_InputBuffer);

	Update_Evolution2(seed, numGenerationsMax, PopulationSize, numOfRandomEvolutionSteps, LifeformArray, FittingScoreArray, &IdOfBestFittedLifeform, &IdOfSecondBestFittedLifeform, &IdOfWorstFittedLifeform, &IdOfSecondWorstFittedLifeform, &simulatedGenerations, &maxFittingScore);

	
	cout << endl;


	// evolution completed

	// evolution statistics:

	cout << "simulated generations: " << simulatedGenerations << endl;
	cout << "maxFittingScore: " << maxFittingScore << endl;
	cout << "IdOfWorstFittedLifeform: " << IdOfWorstFittedLifeform << endl;
	cout << "IdOfSecondWorstFittedLifeform: " << IdOfSecondWorstFittedLifeform << endl;
	cout << "IdOfBestFittedLifeform: " << IdOfBestFittedLifeform << endl;
	cout << "IdOfSecondBestFittedLifeform: " << IdOfSecondBestFittedLifeform << endl << endl;

	cout << "Press Return: ";
	getchar();

	
	Clear_Terminal_And_Reset_CursorPos();

	
	g_BirthPosSeed = 5;
	g_FeedPosSeed = 11;

	CLifeform BestFittedLifeform;
	BestFittedLifeform.Init_Brain();

	
	BestFittedLifeform.Brain.Clone_OutputSynapsePlasticities(&LifeformArray[IdOfBestFittedLifeform].Brain, 0.0f, seed++);


	// neural network tests:

	char strBuffer[100];

	GameBoard_Reset_Feed();
	Init_Or_Reset_GameBoardArrays();
	Init_GameBoardBorders();
	

	//Init_GamesWorld1();
	Init_GamesWorld2();
	
	
	
	
	g_RandomNumbers_FeedUpdate.Change_Seed(g_FeedPosSeed);
	BestFittedLifeform.Set_BirthPosSeed_And_Birth(g_BirthPosSeed);

	Set_CursorVisibilityAndSize(false);

	int32_t feedDistChange;

	do
	{
		Reset_CursorPos();
		GameBoard_UpdateFeed();

		BestFittedLifeform.Update_Pos();
		BestFittedLifeform.Update_LivingStatus();

		
		if (BestFittedLifeform.Living == false)
		{
			g_GameBoard[BestFittedLifeform.OldPosY][BestFittedLifeform.OldPosX] = ConstGameBoard_EmptyElement;
			break;
		}
		else if (BestFittedLifeform.Living == true)
		{
			g_GameBoard[BestFittedLifeform.OldPosY][BestFittedLifeform.OldPosX] = ConstGameBoard_EmptyElement;
			g_GameBoard[BestFittedLifeform.PosY][BestFittedLifeform.PosX] = ConstGameBoard_Lifeform;
		}


		Output_GameBoard();

		
		sprintf(strBuffer, "LivingPoints: %04d\n", BestFittedLifeform.LivingPoints);

		Set_CursorPos(2 * ConstGameBoardSizeX + 2, 0);
		cout << strBuffer;

		this_thread::sleep_for(chrono::milliseconds(100));

		if (KEYDOWN(VK_ESCAPE) == true)
			break;

	} while (true);

	Clear_Terminal_And_Reset_CursorPos();

	Set_CursorVisibilityAndSize(true);

	getchar();

	return 0;

}
*/









