#include <iostream>
#include "Ataxx.h"
#include "LogFile.h"
#include "ConsoleHelperFunctions.h"

using namespace std;
using namespace HelperStuff;



#define KEYDOWN(vk_code) ((GetAsyncKeyState(vk_code) & 0x8000) ? 1 : 0)
#define KEYUP(vk_code)   ((GetAsyncKeyState(vk_code) & 0x8000) ? 0 : 1)

int32_t g_MaxSearchDepth_Minimax = 1;
int32_t g_MaxSearchDepth_MinimaxP1 = 1;
int32_t g_MaxSearchDepth_MinimaxP2 = 1;



float tempMemoryVector[ConstMemoryVectorSize];
float tempBinaryGameStateVector[ConstBinaryGameStateVectorSize];



//int32_t alphaBetaPruningCounter = 0;


// Definition eines Funktionszeiger-Typs:
typedef bool(*pRandom_PlayerFunc)(CGameStateValues* pActualGameStateObject, CRandomNumbersNN *pRandomNumbers);

pRandom_PlayerFunc pRandom_PlayerFuncArray[2] = { Random_Player1, Random_Player2 };

typedef bool(*pCheck_PossiblePlayer1Or2MovesFunc)(int8_t *pInData);

pCheck_PossiblePlayer1Or2MovesFunc pCheck_PossiblePlayer1Or2MovesFuncArray[2] = { Check_PossiblePlayer1Moves, Check_PossiblePlayer2Moves };





float Calculate_MinGameStateMemoryVariance(int32_t *pOutBelongingNeuronID, float *pInBinaryGameStateVector, CSingleRecognitionNeuronEnsemble *pGameStateRecognitionNeuronEnsembleArray)
{
	static float binaryGameStateVector[ConstBinaryGameStateVectorSize];

	if (pGameStateRecognitionNeuronEnsembleArray->NumOfUsedMemoryNeurons == 0)
	{
		if (pOutBelongingNeuronID != nullptr)
			*pOutBelongingNeuronID = -1;

		return 100000000.0f;
	}


	float minVariance = 100000000.0f;
	
	CSimpleNeuron *pNeuron = pGameStateRecognitionNeuronEnsembleArray->pNeuronArray;

	int32_t maxIDPlus1 = min(pGameStateRecognitionNeuronEnsembleArray->NumOfUsedMemoryNeurons, pGameStateRecognitionNeuronEnsembleArray->NumOfNeurons);
	int32_t belongingNeuronID = 0;

	for (int32_t i = 0; i < maxIDPlus1; i++)
	{
		Get_BinaryGameStateVector_From_MemoryVector(binaryGameStateVector, pNeuron->pAdditionalMemoryValueArray);

		float variance = Calculate_VarianceSum(pInBinaryGameStateVector, binaryGameStateVector, ConstBinaryGameStateVectorSize);

		if (variance < minVariance)
		{
			belongingNeuronID = i;
			minVariance = variance;
		}
	}

	if (pOutBelongingNeuronID != nullptr)
		*pOutBelongingNeuronID = belongingNeuronID;

	return minVariance;
}


void Copy_GameData_Into_BinaryGameStateVector(float *pOutBinaryGameStateVector, int8_t *pInGameData)
{
	for (int32_t i = 0; i < ConstGameBoardSizeX2; i++)
	{
		pOutBinaryGameStateVector[i] = 0.0f;
	}

	int8_t GameDataValue;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		GameDataValue = pInGameData[i];

		if (GameDataValue == ConstGameBoard_Player1)
		{
			pOutBinaryGameStateVector[i] = 1.0f;
		}
		else if (GameDataValue == ConstGameBoard_Player2)
		{
			pOutBinaryGameStateVector[i + ConstGameBoardSize] = 1.0f;
		}
	}
}

void Copy_GameData_Into_MemoryVector(float *pOutMemoryVector, int8_t *pInGameData)
{
	static float tempBinaryVector[ConstGameBoardSizeX2];	
	
	for (int32_t i = 0; i < ConstGameBoardSizeX2; i++)
	{
		tempBinaryVector[i] = 0.0f;
	}

	int8_t GameDataValue;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		GameDataValue = pInGameData[i];

		if (GameDataValue == ConstGameBoard_Player1)
		{
			tempBinaryVector[i] = 1.0f;
		}
		else if (GameDataValue == ConstGameBoard_Player2)
		{
			tempBinaryVector[i + ConstGameBoardSize] = 1.0f;
		}
	}

	int32_t counter = 0;
	
	for (int32_t i = 0; i < ConstMemoryVectorSize; i++)
	{
		pOutMemoryVector[i] = BinaryToDecimal(&tempBinaryVector[counter], ConstGameStateValuesPerMemoryValue);
		counter += ConstGameStateValuesPerMemoryValue;
	}
}

void Get_BinaryGameStateVector_From_MemoryVector(int8_t *pOutGameData, float *pInMemoryVector)
{
	float tempBinaryDigitsVector[ConstGameStateValuesPerMemoryValue];

	int32_t counter = 0;

	for (int32_t i = 0; i < ConstMemoryVectorSize; i++)
	{
		DecimalToBinary(tempBinaryDigitsVector, ConstGameStateValuesPerMemoryValue, pInMemoryVector[i]);

		for (int32_t j = 0; j < ConstGameStateValuesPerMemoryValue; j++)
		{
			pOutGameData[counter] = static_cast<int8_t>(tempBinaryDigitsVector[j]);
			counter++;
		}
	}
	
}

void Get_BinaryGameStateVector_From_MemoryVector(float *pOutGameData, float *pInMemoryVector)
{
	float tempBinaryDigitsVector[ConstGameStateValuesPerMemoryValue];

	int32_t counter = 0;

	for (int32_t i = 0; i < ConstMemoryVectorSize; i++)
	{
		DecimalToBinary(tempBinaryDigitsVector, ConstGameStateValuesPerMemoryValue, pInMemoryVector[i]);

		for (int32_t j = 0; j < ConstGameStateValuesPerMemoryValue; j++)
		{
			pOutGameData[counter] = tempBinaryDigitsVector[j];
			counter++;
		}
	}

}






void Generate_Random_GameMoveChain_Player1(int32_t maxDepth, CGameStateValues *pInActualGameStateObject, CExtendedGameStatePool *pGameStatePool, CRandomNumbersNN *pRandomNumbers)
{
	CGameStateValues *pNewGameState = nullptr;
	int32_t NewGameStateObjectID = -1;

	do
	{
		int32_t nextPlayer = (pInActualGameStateObject->PlayerID + 1) % 2;

		int32_t depth = pInActualGameStateObject->DepthValue + 1;

		if (pGameStatePool->Get_UnusedGameStateObject(depth, &pNewGameState, &NewGameStateObjectID) == true)
		{
			pNewGameState->Clone_GameStateValues(pInActualGameStateObject);

			pRandom_PlayerFuncArray[nextPlayer](pNewGameState, pRandomNumbers);

			pNewGameState->IDofPrevGameState = pInActualGameStateObject->IDofGameState;

			if (pNewGameState->PlayerID == 0)
			{
				pNewGameState->Use_As_Minimizer();
			}
			else
			{
				pNewGameState->Use_As_Maximizer();
			}

			pInActualGameStateObject->LeafNode = false;

			if (depth >= maxDepth)
			{
				break;
			}

			pInActualGameStateObject = pNewGameState;
		}
		else
		{
			break;
		}
	} while (true);
}

void Generate_Random_GameMoveChain_Player2(int32_t maxDepth, CGameStateValues *pInActualGameStateObject, CExtendedGameStatePool *pGameStatePool, CRandomNumbersNN *pRandomNumbers)
{
	CGameStateValues *pNewGameState = nullptr;
	int32_t NewGameStateObjectID = -1;

	do
	{
		int32_t nextPlayer = (pInActualGameStateObject->PlayerID + 1) % 2;
		int32_t depth = pInActualGameStateObject->DepthValue + 1;

		if (pGameStatePool->Get_UnusedGameStateObject(depth, &pNewGameState, &NewGameStateObjectID) == true)
		{
			pNewGameState->Clone_GameStateValues(pInActualGameStateObject);

			pRandom_PlayerFuncArray[nextPlayer](pNewGameState, pRandomNumbers);

			pNewGameState->IDofPrevGameState = pInActualGameStateObject->IDofGameState;

			if (pNewGameState->PlayerID == 1)
			{
				pNewGameState->Use_As_Minimizer();
			}
			else
			{
				pNewGameState->Use_As_Maximizer();
			}

			pInActualGameStateObject->LeafNode = false;

			if (depth >= maxDepth)
			{
				break;
			}

			pInActualGameStateObject = pNewGameState;
		}
		else
		{
			break;
		}
	} while (true);
}







void Evaluate_LeafGameStates_Player1View(CExtendedGameStatePool *pGameStatePool)
{
	int32_t Player1Score, Player2Score;

	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;

	for (int32_t i = numOfDepthLayersMax - 1; i > -1; i--)
	{
		CSimpleLinkedListManager *pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[i];
		int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
		int32_t id = 0;

		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);

			if (pGameStatePool->pGameStateArray[id].LeafNode == false)
			{
				continue;
			}

			Calculate_Score(&Player1Score, &Player2Score, &pGameStatePool->pGameStateArray[id].pValueArray[0]);

			if (Player1Score > 0 && Player2Score == 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
			}
			else if (Player1Score == 0 && Player2Score > 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
			}
			else
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = Player1Score - Player2Score;
			}

		}
	}
}

void Evaluate_LeafGameStates_Player1View(CGameStatePool_SimpleGameTree *pGameStatePool)
{
	int32_t Player1Score, Player2Score;

	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;

	for (int32_t i = numOfDepthLayersMax - 1; i > -1; i--)
	{
		CSimpleGameTree_DepthLayerInfo *pDepthLayerInfo = &pGameStatePool->pDepthLayerInfoArray[i];
		int32_t NumObjectsUsed = pDepthLayerInfo->NumGameStatesUsed;
		int32_t id = 0;

		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			id = pDepthLayerInfo->pGameStateIDArray[j];

			if (pGameStatePool->pGameStateArray[id].LeafNode == false)
			{
				continue;
			}

			Calculate_Score(&Player1Score, &Player2Score, &pGameStatePool->pGameStateArray[id].pValueArray[0]);

			if (Player1Score > 0 && Player2Score == 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
			}
			else if (Player1Score == 0 && Player2Score > 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
			}
			else
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = Player1Score - Player2Score;
			}

		}
	}
}

void Evaluate_GameStates_Player1View(CExtendedGameStatePool *pGameStatePool)
{
	int32_t Player1Score, Player2Score;

	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;
	int32_t numOfDepthLayersMaxMinus1 = numOfDepthLayersMax - 1;

	for (int32_t i = 0; i < numOfDepthLayersMaxMinus1; i++)
	{
		CSimpleLinkedListManager *pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[i];
		int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
		int32_t id = 0;

		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);

			Calculate_Score(&Player1Score, &Player2Score, &pGameStatePool->pGameStateArray[id].pValueArray[0]);

			if (Player1Score > 0 && Player2Score == 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
			}
			else if (Player1Score == 0 && Player2Score > 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
			}
			else
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = Player1Score - Player2Score;
			}

		}
	}
}



void Evaluate_GameStates_Player1View(CGameStatePool_SimpleGameTree *pGameStatePool)
{
	int32_t Player1Score, Player2Score;

	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;
	int32_t numOfDepthLayersMaxMinus1 = numOfDepthLayersMax - 1;

	for (int32_t i = 0; i < numOfDepthLayersMaxMinus1; i++)
	{
		CSimpleGameTree_DepthLayerInfo *pDepthLayerInfo = &pGameStatePool->pDepthLayerInfoArray[i];
		int32_t NumObjectsUsed = pDepthLayerInfo->NumGameStatesUsed;
		int32_t id = 0;

		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			id = pDepthLayerInfo->pGameStateIDArray[j];

			Calculate_Score(&Player1Score, &Player2Score, &pGameStatePool->pGameStateArray[id].pValueArray[0]);

			if (Player1Score > 0 && Player2Score == 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
			}
			else if (Player1Score == 0 && Player2Score > 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
			}
			else
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = Player1Score - Player2Score;
			}

		}
	}
}



void Evaluate_LeafGameStates_Player2View(CExtendedGameStatePool *pGameStatePool)
{
	int32_t Player1Score, Player2Score;

	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;

	for (int32_t i = numOfDepthLayersMax - 1; i > -1; i--)
	{
		CSimpleLinkedListManager *pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[i];
		int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
		int32_t id = 0;

		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);

			if (pGameStatePool->pGameStateArray[id].LeafNode == false)
			{
				continue;
			}

			Calculate_Score(&Player1Score, &Player2Score, &pGameStatePool->pGameStateArray[id].pValueArray[0]);

			if (Player2Score > 0 && Player1Score == 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
			}
			else if (Player2Score == 0 && Player1Score > 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
			}
			else
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = Player2Score - Player1Score;
			}

		}
	}
}



void Evaluate_LeafGameStates_Player2View(CGameStatePool_SimpleGameTree *pGameStatePool)
{
	int32_t Player1Score, Player2Score;

	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;

	for (int32_t i = numOfDepthLayersMax - 1; i > -1; i--)
	{
		CSimpleGameTree_DepthLayerInfo *pDepthLayerInfo = &pGameStatePool->pDepthLayerInfoArray[i];
		int32_t NumObjectsUsed = pDepthLayerInfo->NumGameStatesUsed;
		int32_t id = 0;

		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			id = pDepthLayerInfo->pGameStateIDArray[j];

			if (pGameStatePool->pGameStateArray[id].LeafNode == false)
			{
				continue;
			}

			Calculate_Score(&Player1Score, &Player2Score, &pGameStatePool->pGameStateArray[id].pValueArray[0]);

			if (Player2Score > 0 && Player1Score == 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
			}
			else if (Player2Score == 0 && Player1Score > 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
			}
			else
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = Player2Score - Player1Score;
			}

		}
	}
}


void Evaluate_GameStates_Player2View(CExtendedGameStatePool *pGameStatePool)
{
	int32_t Player1Score, Player2Score;

	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;
	int32_t numOfDepthLayersMaxMinus1 = numOfDepthLayersMax - 1;

	for (int32_t i = 0; i < numOfDepthLayersMaxMinus1; i++)
	{
		CSimpleLinkedListManager *pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[i];
		int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
		int32_t id = 0;

		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);

			Calculate_Score(&Player1Score, &Player2Score, &pGameStatePool->pGameStateArray[id].pValueArray[0]);

			if (Player2Score > 0 && Player1Score == 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
			}
			else if (Player2Score == 0 && Player1Score > 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
			}
			else
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = Player2Score - Player1Score;
			}
		}
	}
}



void Evaluate_GameStates_Player2View(CGameStatePool_SimpleGameTree *pGameStatePool)
{
	int32_t Player1Score, Player2Score;

	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;
	int32_t numOfDepthLayersMaxMinus1 = numOfDepthLayersMax - 1;

	for (int32_t i = 0; i < numOfDepthLayersMaxMinus1; i++)
	{
		CSimpleGameTree_DepthLayerInfo *pDepthLayerInfo = &pGameStatePool->pDepthLayerInfoArray[i];
		int32_t NumObjectsUsed = pDepthLayerInfo->NumGameStatesUsed;
		int32_t id = 0;

		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			id = pDepthLayerInfo->pGameStateIDArray[j];

			Calculate_Score(&Player1Score, &Player2Score, &pGameStatePool->pGameStateArray[id].pValueArray[0]);

			if (Player2Score > 0 && Player1Score == 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
			}
			else if (Player2Score == 0 && Player1Score > 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
			}
			else
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = Player2Score - Player1Score;
			}
		}
	}
}








CInitialAtaxxBoards::CInitialAtaxxBoards()
{

}

CInitialAtaxxBoards::~CInitialAtaxxBoards()
{
	delete[] pInitialGameStateArray;
	pInitialGameStateArray = nullptr;
}

bool CInitialAtaxxBoards::Initialize(const char* pFilename)
{
	delete[] pInitialGameStateArray;
	pInitialGameStateArray = nullptr;

	std::ifstream ReadFile;

	// eine existierende Datei zum Lesen �ffnen:
	ReadFile.open(pFilename);

	if (ReadFile.good() == false)
		return false;

	char strBuffer[200];
	int32_t tempInt;

	ReadFile >> strBuffer;
	ReadFile >> NumOfInitialAtaxxBoards;

	pInitialGameStateArray = new (std::nothrow) CGameStateValues[NumOfInitialAtaxxBoards];

	for (int32_t i = 0; i < NumOfInitialAtaxxBoards; i++)
	{
		pInitialGameStateArray[i].Initialize(ConstGameBoardSizePerDir, ConstGameBoardSizePerDir);

		int8_t *pInitialBoardData = &pInitialGameStateArray[i].pValueArray[0];

		for (int32_t j = 0; j < ConstGameBoardSize; j++)
		{
			ReadFile >> tempInt;
			pInitialBoardData[j] = static_cast<int8_t>(tempInt);
		}
	}

	ReadFile.close();
	return true;
}


float CAtaxxBoardEvaluator::NeuralNetGameStateVectorPaddingSize1[] = {};
float CAtaxxBoardEvaluator::NeuralNetGameStateVectorPaddingSize2[] = {};

CAtaxxBoardEvaluator::CAtaxxBoardEvaluator()
{
	

	float LRF_CentroidValueArray[3 * 3] = { 1.0f, 1.0f, 1.0f,
		                                     1.0f, 1.0f, 1.0f,
		                                     1.0f, 1.0f, 1.0f };

	float LRF_FactorArray[3 * 3] = { 1.0f, 1.0f, 1.0f,
		                              1.0f, 1.0f, 1.0f,
		                              1.0f, 1.0f, 1.0f };

	RecognitionNeuronArray[0].Init_Dendrite_Arrays(3 * 3);
	RecognitionNeuronArray[0].Set_ActivationFunction(AtaxxPatternRecognitionOutputFunction1A);
	RecognitionNeuronArray[0].Set_LocalReceptiveFieldSizeInfo(3, 3);
	RecognitionNeuronArray[0].Set_Dendrite_Data(LRF_CentroidValueArray, LRF_FactorArray);

	RecognitionNeuronArray[1].Init_Dendrite_Arrays(3 * 3);
	RecognitionNeuronArray[1].Set_ActivationFunction(AtaxxPatternRecognitionOutputFunction1B);
	RecognitionNeuronArray[1].Set_LocalReceptiveFieldSizeInfo(3, 3);
	RecognitionNeuronArray[1].Set_Dendrite_Data(LRF_CentroidValueArray, LRF_FactorArray);

	RecognitionNeuronArray[2].Init_Dendrite_Arrays(3 * 3);
	RecognitionNeuronArray[2].Set_ActivationFunction(AtaxxPatternRecognitionOutputFunction2);
	RecognitionNeuronArray[2].Set_LocalReceptiveFieldSizeInfo(3, 3);
	
	RecognitionNeuronArray[3].Init_Dendrite_Arrays(3 * 3);
	RecognitionNeuronArray[3].Set_ActivationFunction(AtaxxPatternRecognitionOutputFunction3);
	RecognitionNeuronArray[3].Set_LocalReceptiveFieldSizeInfo(3, 3);

	RecognitionNeuronArray[4].Init_Dendrite_Arrays(5 * 5);
	RecognitionNeuronArray[4].Set_ActivationFunction(AtaxxPatternRecognitionOutputFunction4);
	RecognitionNeuronArray[4].Set_LocalReceptiveFieldSizeInfo(5, 5);
}




CAtaxxBoardEvaluator::~CAtaxxBoardEvaluator()
{
}

void CAtaxxBoardEvaluator::Copy_GameData_Into_Player1Analysis1_NeuralNetVector_PaddingSize1(int8_t *pInGameData)
{
	for (int32_t i = 0; i < ConstGameBoardSize_PaddingSize1; i++)
	{
		NeuralNetGameStateVectorPaddingSize1[i] = 1.0f;
	}

	int32_t minX = 1;
	int32_t maxXPlus1 = minX + ConstGameBoardSizePerDir;
	int32_t minY = 1;
	int32_t maxYPlus1 = minY + ConstGameBoardSizePerDir;
	int32_t id;

	for (int32_t iy = minY; iy < maxYPlus1; iy++)
	{
		for (int32_t ix = minX; ix < maxXPlus1; ix++)
		{
			id = ix + iy * ConstGameBoardSizePerDir_PaddingSize1;
			NeuralNetGameStateVectorPaddingSize1[id] = 0.0f;
		}
	}


	int8_t GameDataValue;
	int32_t counter = 0;

	for (int32_t iy = minY; iy < maxYPlus1; iy++)
	{
		for (int32_t ix = minX; ix < maxXPlus1; ix++)
		{
			id = ix + iy * ConstGameBoardSizePerDir_PaddingSize1;

			GameDataValue = pInGameData[counter];
			counter++;

			if (GameDataValue == ConstGameBoard_Player1)
			{
				NeuralNetGameStateVectorPaddingSize1[id] = 1.0f;
			}
			else if (GameDataValue == ConstGameBoard_Obstacle)
			{
				NeuralNetGameStateVectorPaddingSize1[id] = 1.0f;
			}
			else if (GameDataValue == ConstGameBoard_Player2)
			{
				NeuralNetGameStateVectorPaddingSize1[id] = -1.0f;
			}
		}
	}
}

void CAtaxxBoardEvaluator::Copy_GameData_Into_Player1Analysis2_NeuralNetVector_PaddingSize1(int8_t *pInGameData)
{
	for (int32_t i = 0; i < ConstGameBoardSize_PaddingSize1; i++)
	{
		NeuralNetGameStateVectorPaddingSize1[i] = 2.0f;
	}

	int32_t minX = 1;
	int32_t maxXPlus1 = minX + ConstGameBoardSizePerDir;
	int32_t minY = 1;
	int32_t maxYPlus1 = minY + ConstGameBoardSizePerDir;
	int32_t id;

	for (int32_t iy = minY; iy < maxYPlus1; iy++)
	{
		for (int32_t ix = minX; ix < maxXPlus1; ix++)
		{
			id = ix + iy * ConstGameBoardSizePerDir_PaddingSize1;
			NeuralNetGameStateVectorPaddingSize1[id] = 0.0f;
		}
	}


	int8_t GameDataValue;
	int32_t counter = 0;

	for (int32_t iy = minY; iy < maxYPlus1; iy++)
	{
		for (int32_t ix = minX; ix < maxXPlus1; ix++)
		{
			id = ix + iy * ConstGameBoardSizePerDir_PaddingSize1;

			GameDataValue = pInGameData[counter];
			counter++;

			if (GameDataValue == ConstGameBoard_Player1)
			{
				NeuralNetGameStateVectorPaddingSize1[id] = 1.0f;
			}
			else if (GameDataValue == ConstGameBoard_Obstacle)
			{
				NeuralNetGameStateVectorPaddingSize1[id] = 2.0f;
			}
			else if (GameDataValue == ConstGameBoard_Player2)
			{
				NeuralNetGameStateVectorPaddingSize1[id] = -1.0f;
			}
		}
	}
}

void CAtaxxBoardEvaluator::Copy_GameData_Into_Player2Analysis1_NeuralNetVector_PaddingSize1(int8_t *pInGameData)
{
	for (int32_t i = 0; i < ConstGameBoardSize_PaddingSize1; i++)
	{
		NeuralNetGameStateVectorPaddingSize1[i] = 1.0f;
	}

	int32_t minX = 1;
	int32_t maxXPlus1 = minX + ConstGameBoardSizePerDir;
	int32_t minY = 1;
	int32_t maxYPlus1 = minY + ConstGameBoardSizePerDir;
	int32_t id;

	for (int32_t iy = minY; iy < maxYPlus1; iy++)
	{
		for (int32_t ix = minX; ix < maxXPlus1; ix++)
		{
			id = ix + iy * ConstGameBoardSizePerDir_PaddingSize1;
			NeuralNetGameStateVectorPaddingSize1[id] = 0.0f;
		}
	}


	int8_t GameDataValue;
	int32_t counter = 0;

	for (int32_t iy = minY; iy < maxYPlus1; iy++)
	{
		for (int32_t ix = minX; ix < maxXPlus1; ix++)
		{
			id = ix + iy * ConstGameBoardSizePerDir_PaddingSize1;

			GameDataValue = pInGameData[counter];
			counter++;

			if (GameDataValue == ConstGameBoard_Player2)
			{
				NeuralNetGameStateVectorPaddingSize1[id] = 1.0f;
			}
			else if (GameDataValue == ConstGameBoard_Obstacle)
			{
				NeuralNetGameStateVectorPaddingSize1[id] = 1.0f;
			}
			else if (GameDataValue == ConstGameBoard_Player1)
			{
				NeuralNetGameStateVectorPaddingSize1[id] = -1.0f;
			}
		}
	}
}

void CAtaxxBoardEvaluator::Copy_GameData_Into_Player2Analysis2_NeuralNetVector_PaddingSize1(int8_t *pInGameData)
{
	for (int32_t i = 0; i < ConstGameBoardSize_PaddingSize1; i++)
	{
		NeuralNetGameStateVectorPaddingSize1[i] = 2.0f;
	}

	int32_t minX = 1;
	int32_t maxXPlus1 = minX + ConstGameBoardSizePerDir;
	int32_t minY = 1;
	int32_t maxYPlus1 = minY + ConstGameBoardSizePerDir;
	int32_t id;

	for (int32_t iy = minY; iy < maxYPlus1; iy++)
	{
		for (int32_t ix = minX; ix < maxXPlus1; ix++)
		{
			id = ix + iy * ConstGameBoardSizePerDir_PaddingSize1;
			NeuralNetGameStateVectorPaddingSize1[id] = 0.0f;
		}
	}


	int8_t GameDataValue;
	int32_t counter = 0;

	for (int32_t iy = minY; iy < maxYPlus1; iy++)
	{
		for (int32_t ix = minX; ix < maxXPlus1; ix++)
		{
			id = ix + iy * ConstGameBoardSizePerDir_PaddingSize1;

			GameDataValue = pInGameData[counter];
			counter++;

			if (GameDataValue == ConstGameBoard_Player2)
			{
				NeuralNetGameStateVectorPaddingSize1[id] = 1.0f;
			}
			else if (GameDataValue == ConstGameBoard_Obstacle)
			{
				NeuralNetGameStateVectorPaddingSize1[id] = 2.0f;
			}
			else if (GameDataValue == ConstGameBoard_Player1)
			{
				NeuralNetGameStateVectorPaddingSize1[id] = -1.0f;
			}
		}
	}
}

void CAtaxxBoardEvaluator::Copy_GameData_Into_Player1Analysis_NeuralNetVector_PaddingSize2(int8_t *pInGameData)
{
	for (int32_t i = 0; i < ConstGameBoardSize_PaddingSize2; i++)
	{
		NeuralNetGameStateVectorPaddingSize2[i] = 0.0f;
	}

	int32_t minX = 2;
	int32_t maxXPlus1 = minX + ConstGameBoardSizePerDir;
	int32_t minY = 2;
	int32_t maxYPlus1 = minY + ConstGameBoardSizePerDir;
	int32_t id, ix2, iy2, id2;
	int32_t minX2, minY2, maxX2Plus1, maxY2Plus1;
	float gamePieceCount;

	int8_t GameDataValue;
	int32_t counter = 0;

	for (int32_t iy = minY; iy < maxYPlus1; iy++)
	{
		for (int32_t ix = minX; ix < maxXPlus1; ix++)
		{
			id = ix + iy * ConstGameBoardSizePerDir_PaddingSize2;

			GameDataValue = pInGameData[counter];

			if (GameDataValue == ConstGameBoard_Empty)
			{
				ix2 = counter % ConstGameBoardSizePerDir;
				iy2 = counter / ConstGameBoardSizePerDir;

				minX2 = max(0, ix2 - 1);
				minY2 = max(0, iy2 - 1);
				maxX2Plus1 = min(ConstGameBoardSizePerDir, ix2 + 2);
				maxY2Plus1 = min(ConstGameBoardSizePerDir, iy2 + 2);

				gamePieceCount = 0.0f;

				for (iy2 = minY2; iy2 < maxY2Plus1; iy2++)
				{
					for (ix2 = minX2; ix2 < maxX2Plus1; ix2++)
					{
						id2 = ix2 + iy2 * ConstGameBoardSizePerDir;

						if (pInGameData[id2] == ConstGameBoard_Player1)
						{
							gamePieceCount += 1.0f;
						}
					}
				}

				NeuralNetGameStateVectorPaddingSize2[id] = gamePieceCount;
			} /* end of if (GameDataValue == ConstGameBoard_Empty) */
			else if (GameDataValue == ConstGameBoard_Player2)
			{
				NeuralNetGameStateVectorPaddingSize2[id] = -1.0f;
			}

			counter++;	
		}
	}
}

void CAtaxxBoardEvaluator::Copy_GameData_Into_Player2Analysis_NeuralNetVector_PaddingSize2(int8_t *pInGameData)
{
	for (int32_t i = 0; i < ConstGameBoardSize_PaddingSize2; i++)
	{
		NeuralNetGameStateVectorPaddingSize2[i] = 0.0f;
	}

	int32_t minX = 2;
	int32_t maxXPlus1 = minX + ConstGameBoardSizePerDir;
	int32_t minY = 2;
	int32_t maxYPlus1 = minY + ConstGameBoardSizePerDir;
	int32_t id, ix2, iy2, id2;
	int32_t minX2, minY2, maxX2Plus1, maxY2Plus1;
	float gamePieceCount;

	int8_t GameDataValue;
	int32_t counter = 0;

	for (int32_t iy = minY; iy < maxYPlus1; iy++)
	{
		for (int32_t ix = minX; ix < maxXPlus1; ix++)
		{
			id = ix + iy * ConstGameBoardSizePerDir_PaddingSize2;

			GameDataValue = pInGameData[counter];

			if (GameDataValue == ConstGameBoard_Empty)
			{
				ix2 = counter % ConstGameBoardSizePerDir;
				iy2 = counter / ConstGameBoardSizePerDir;

				minX2 = max(0, ix2 - 1);
				minY2 = max(0, iy2 - 1);
				maxX2Plus1 = min(ConstGameBoardSizePerDir, ix2 + 2);
				maxY2Plus1 = min(ConstGameBoardSizePerDir, iy2 + 2);

				gamePieceCount = 0.0f;

				for (iy2 = minY2; iy2 < maxY2Plus1; iy2++)
				{
					for (ix2 = minX2; ix2 < maxX2Plus1; ix2++)
					{
						id2 = ix2 + iy2 * ConstGameBoardSizePerDir;

						if (pInGameData[id2] == ConstGameBoard_Player2)
						{
							gamePieceCount += 1.0f;
						}
					}
				}

				NeuralNetGameStateVectorPaddingSize2[id] = gamePieceCount;
			} /* end of if (GameDataValue == ConstGameBoard_Empty) */
			else if (GameDataValue == ConstGameBoard_Player1)
			{
				NeuralNetGameStateVectorPaddingSize2[id] = -1.0f;
			}

			counter++;
		}
	}
}




float CAtaxxBoardEvaluator::Evaluate_Player1(CGameStateValues *pGameState)
{
	float outEvaluationScore = 0.0f;

	/* Je mehr eigene Spielsteine vollst�ndig vor einem gegnerischen Angriff abgeschirmt sind,
	um so besser die Bewertung der zu bewertenden Spielstellung: */

	Copy_GameData_Into_Player1Analysis1_NeuralNetVector_PaddingSize1(pGameState->pValueArray);

	int32_t outPatternCount1;

	Search_Pattern(&outPatternCount1, NeuralNetGameStateVectorPaddingSize1, 9, 9, 1, 1, 1, 8, 1, 8, &RecognitionNeuronArray[0], 0.999f);
	outEvaluationScore += AI_Param1 * static_cast<float>(outPatternCount1);

	float outValueSum;

	/* Je besser die eigenen Spielsteine vor einem gegnerischen Angriff abgeschirmt sind,
	um so besser die Bewertung der zu bewertenden Spielstellung: */

	Search_Pattern(&outPatternCount1, &outValueSum, NeuralNetGameStateVectorPaddingSize1, 9, 9, 1, 1, 1, 8, 1, 8, &RecognitionNeuronArray[1], 1.0f / 9.0f);

	if (outPatternCount1 > 0)
	{
		outValueSum /= static_cast<float>(outPatternCount1);
		outEvaluationScore += AI_Param2 * outValueSum;
	}

	/* Je mehr gegnerische  Spielsteine vollst�ndig vor einem Angriff abgeschirmt sind,
	um so schlechter die Bewertung der zu bewertenden Spielstellung: */

	Copy_GameData_Into_Player2Analysis1_NeuralNetVector_PaddingSize1(pGameState->pValueArray);

	Search_Pattern(&outPatternCount1, NeuralNetGameStateVectorPaddingSize1, 9, 9, 1, 1, 1, 8, 1, 8, &RecognitionNeuronArray[0], 0.999f);
	outEvaluationScore -= AI_Param1 * static_cast<float>(outPatternCount1);

	/* Je besser die gegnerischen Spielsteine vor einem Angriff abgeschirmt sind,
	um so schlechter die Bewertung der zu bewertenden Spielstellung: */

	Search_Pattern(&outPatternCount1, &outValueSum, NeuralNetGameStateVectorPaddingSize1, 9, 9, 1, 1, 1, 8, 1, 8, &RecognitionNeuronArray[1], 1.0f / 9.0f);

	if (outPatternCount1 > 0)
	{
		outValueSum /= static_cast<float>(outPatternCount1);
		outEvaluationScore -= AI_Param2 * outValueSum;
	}

	/* Wenn der Gegner keinen Klonzug mehr ausf�hren kann, sondern nur noch Sprungz�ge, verbessert das
	die Bewertung der zu bewertenden Spielstellung: */

	Copy_GameData_Into_Player2Analysis2_NeuralNetVector_PaddingSize1(pGameState->pValueArray);

	// ConstGameBoardSizePerDir_PaddingSize1: 9
	Search_Pattern(&outPatternCount1, NeuralNetGameStateVectorPaddingSize1, 9, 9, 1, 1, 1, 8, 1, 8, &RecognitionNeuronArray[2], 0.999f);

	// kein gegnerischer Klonzug m�glich:
	if (outPatternCount1 == 0)
		outEvaluationScore += AI_Param3;


	Copy_GameData_Into_Player1Analysis_NeuralNetVector_PaddingSize2(pGameState->pValueArray);

	/* Je mehr eigene Spielsteine sich im Rahmen eines m�glichen gegnerischen Klonzugs assimilieren lassen,
	um so schlechter die Bewertung der zu bewertenden Spielstellung: */

	RecognitionNeuronArray[3].ActivationValue = 0.0f;

	// ConstGameBoardSizePerDir_PaddingSize2: 11
	Search_Pattern(&outPatternCount1, NeuralNetGameStateVectorPaddingSize2, 11, 11, 1, 1, 2, 9, 2, 9, &RecognitionNeuronArray[3], 0.999f);


	/* Je mehr eigene Spielsteine sich im Rahmen eines m�glichen gegnerischen Sprungzugs assimilieren lassen,
	um so schlechter die Bewertung der zu bewertenden Spielstellung: */

	RecognitionNeuronArray[4].ActivationValue = 0.0f;

	int32_t outPatternCount2 = 0;
	Search_Pattern(&outPatternCount2, NeuralNetGameStateVectorPaddingSize2, 11, 11, 1, 1, 2, 9, 2, 9, &RecognitionNeuronArray[4], 0.999f);

	outEvaluationScore -= AI_Param4 * pow(RecognitionNeuronArray[3].ActivationValue, AI_Param5);
	outEvaluationScore -= AI_Param6 * pow(RecognitionNeuronArray[4].ActivationValue, AI_Param7);
	
	return outEvaluationScore;
}

float CAtaxxBoardEvaluator::Evaluate_Player2(CGameStateValues *pGameState)
{
	float outEvaluationScore = 0.0f;

	/* Je mehr eigene Spielsteine vollst�ndig vor einem gegnerischen Angriff abgeschirmt sind,
	um so besser die Bewertung der zu bewertenden Spielstellung: */

	Copy_GameData_Into_Player2Analysis1_NeuralNetVector_PaddingSize1(pGameState->pValueArray);

	int32_t outPatternCount1;

	Search_Pattern(&outPatternCount1, NeuralNetGameStateVectorPaddingSize1, 9, 9, 1, 1, 1, 8, 1, 8, &RecognitionNeuronArray[0], 0.999f);

	outEvaluationScore += AI_Param1 * static_cast<float>(outPatternCount1);

	float outValueSum;

	/* Je besser die eigenen Spielsteine vor einem gegnerischen Angriff abgeschirmt sind,
	um so besser die Bewertung der zu bewertenden Spielstellung: */

	Search_Pattern(&outPatternCount1, &outValueSum, NeuralNetGameStateVectorPaddingSize1, 9, 9, 1, 1, 1, 8, 1, 8, &RecognitionNeuronArray[1], 1.0f / 9.0f);

	if (outPatternCount1 > 0)
	{
		outValueSum /= static_cast<float>(outPatternCount1);
		outEvaluationScore += AI_Param2 * outValueSum;
	}

	/* Je mehr gegnerische  Spielsteine vollst�ndig vor einem Angriff abgeschirmt sind,
	um so schlechter die Bewertung der zu bewertenden Spielstellung: */

	Copy_GameData_Into_Player1Analysis1_NeuralNetVector_PaddingSize1(pGameState->pValueArray);

	Search_Pattern(&outPatternCount1, NeuralNetGameStateVectorPaddingSize1, 9, 9, 1, 1, 1, 8, 1, 8, &RecognitionNeuronArray[0], 0.999f);
	outEvaluationScore -= AI_Param1 * static_cast<float>(outPatternCount1);

	/* Je besser die gegnerischen Spielsteine vor einem Angriff abgeschirmt sind,
	um so schlechter die Bewertung der zu bewertenden Spielstellung: */

	Search_Pattern(&outPatternCount1, &outValueSum, NeuralNetGameStateVectorPaddingSize1, 9, 9, 1, 1, 1, 8, 1, 8, &RecognitionNeuronArray[1], 1.0f / 9.0f);

	if (outPatternCount1 > 0)
	{
		outValueSum /= static_cast<float>(outPatternCount1);
		outEvaluationScore -= AI_Param2 * outValueSum;
	}

	/* Wenn der Gegner keinen Klonzug mehr ausf�hren kann, sondern nur noch Sprungz�ge, verbessert das
	die Bewertung der zu bewertenden Spielstellung: */

	Copy_GameData_Into_Player1Analysis2_NeuralNetVector_PaddingSize1(pGameState->pValueArray);

	// ConstGameBoardSizePerDir_PaddingSize1: 9
	Search_Pattern(&outPatternCount1, NeuralNetGameStateVectorPaddingSize1, 9, 9, 1, 1, 1, 8, 1, 8, &RecognitionNeuronArray[2], 0.999f);

	// kein gegnerischer Klonzug m�glich:
	if (outPatternCount1 == 0)
		outEvaluationScore += AI_Param3;


	Copy_GameData_Into_Player2Analysis_NeuralNetVector_PaddingSize2(pGameState->pValueArray);

	/* Je mehr eigene Spielsteine sich im Rahmen eines m�glichen gegnerischen Klonzugs assimilieren lassen,
	um so schlechter die Bewertung der zu bewertenden Spielstellung: */

	RecognitionNeuronArray[3].ActivationValue = 0.0f;

	// ConstGameBoardSizePerDir_PaddingSize2: 11
	Search_Pattern(&outPatternCount1, NeuralNetGameStateVectorPaddingSize2, 11, 11, 1, 1, 2, 9, 2, 9, &RecognitionNeuronArray[3], 0.999f);

	/* Je mehr eigene Spielsteine sich im Rahmen eines m�glichen gegnerischen Sprungzugs assimilieren lassen,
	um so schlechter die Bewertung der zu bewertenden Spielstellung: */

	RecognitionNeuronArray[4].ActivationValue = 0.0f;

	int32_t outPatternCount2 = 0;
	Search_Pattern(&outPatternCount2, NeuralNetGameStateVectorPaddingSize2, 11, 11, 1, 1, 2, 9, 2, 9, &RecognitionNeuronArray[4], 0.999f);

	outEvaluationScore -= AI_Param4 * RecognitionNeuronArray[3].ActivationValue;
	outEvaluationScore -= AI_Param5 * RecognitionNeuronArray[4].ActivationValue;

	return outEvaluationScore;
}



void Init_GameBoard(int8_t *pInOutGameData, CInitialAtaxxBoards *pInitialAtaxxBoards, int32_t boardID)
{
	int8_t *pInitialBoardData = &pInitialAtaxxBoards->pInitialGameStateArray[boardID].pValueArray[0];

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		pInOutGameData[i] = pInitialBoardData[i];
	}
}

void Init_GameBoard_WithoutObstacles(int8_t *pInOutGameData)
{
	for (int32_t i = 0; i < ConstGameBoardSize; i++)
		pInOutGameData[i] = 0;

	int32_t ix1_Player1 = 0;
	int32_t iy1_Player1 = 0;

	int32_t id = ix1_Player1 + ConstGameBoardSizePerDir * iy1_Player1;
	pInOutGameData[id] = ConstGameBoard_Player1;

	int32_t ix2_Player1 = ConstGameBoardSizePerDir - 1;
	int32_t iy2_Player1 = ConstGameBoardSizePerDir - 1;

	id = ix2_Player1 + ConstGameBoardSizePerDir * iy2_Player1;
	pInOutGameData[id] = ConstGameBoard_Player1;

	int32_t ix1_Player2 = ConstGameBoardSizePerDir - 1;
	int32_t iy1_Player2 = 0;

	id = ix1_Player2 + ConstGameBoardSizePerDir * iy1_Player2;
	pInOutGameData[id] = ConstGameBoard_Player2;

	int32_t ix2_Player2 = 0;
	int32_t iy2_Player2 = ConstGameBoardSizePerDir - 1;

	id = ix2_Player2 + ConstGameBoardSizePerDir * iy2_Player2;
	pInOutGameData[id] = ConstGameBoard_Player2;
}

void Clone_GameBoard(int8_t *pOutGameData, int8_t *pInGameData)
{
	for (int32_t i = 0; i < ConstGameBoardSize; i++)
		pOutGameData[i] = pInGameData[i];
}

void Calculate_Score(int32_t *pOutPlayer1Score, int32_t *pOutPlayer2Score, int8_t *pInGameData)
{
	int32_t player1Score = 0;
	int32_t player2Score = 0;

	int8_t value;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		value = pInGameData[i];

		if (value == ConstGameBoard_Player1)
		{
			player1Score++;
		}
		else if (value == ConstGameBoard_Player2)
		{
			player2Score++;
		}
	}

	*pOutPlayer1Score = player1Score;
	*pOutPlayer2Score = player2Score;
}

void Calculate_Player1Score(int32_t *pOutPlayer1Score, int8_t *pInGameData)
{
	int32_t player1Score = 0;
	
	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pInGameData[i] == ConstGameBoard_Player1)
		{
			player1Score++;
		}
	}

	*pOutPlayer1Score = player1Score;
}

void Calculate_Player2Score(int32_t *pOutPlayer2Score, int8_t *pInGameData)
{
	
	int32_t player2Score = 0;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pInGameData[i] == ConstGameBoard_Player2)
		{
			player2Score++;
		}
	}

	
	*pOutPlayer2Score = player2Score;
}

bool Check_PossiblePlayer1CloneMove(int32_t destinationX, int32_t destinationY, int8_t *pInGameData)
{
	int32_t id = destinationX + ConstGameBoardSizePerDir * destinationY;

	if (pInGameData[id] != ConstGameBoard_Empty)
	{
		return false;
	}

	
	int32_t ixMin = max(0, destinationX - 1);
	int32_t iyMin = max(0, destinationY - 1);

	int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, destinationX + 2);
	int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, destinationY + 2);

	for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
	{
		int32_t iiy = ConstGameBoardSizePerDir * iy;

		for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
		{
			if (pInGameData[ix + iiy] == ConstGameBoard_Player1)
			{
				return true;
			}
		}
	}

	return false;
}

bool Get_PossiblePlayer1CloneMoveStartPos(int32_t *pOutStartX, int32_t *pOutStartY, int32_t newX, int32_t newY, int8_t *pInGameData)
{
	/*int32_t id = newX + ConstGameBoardSizePerDir * newY;

	if (pInGameData[id] != ConstGameBoard_Empty)
	{
	return false;
	}*/


	int32_t ixMin = max(0, newX - 1);
	int32_t iyMin = max(0, newY - 1);

	int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, newX + 2);
	int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, newY + 2);

	for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
	{
		int32_t iiy = ConstGameBoardSizePerDir * iy;

		for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
		{
			if (pInGameData[ix + iiy] == ConstGameBoard_Player1)
			{
				*pOutStartX = ix;
				*pOutStartY = iy;
				return true;
			}
		}
	}

	return false;
}

bool Check_PossiblePlayer1CloneMove(int32_t newPosID, int8_t *pInGameData)
{
	if (pInGameData[newPosID] != ConstGameBoard_Empty)
	{
		return false;
	}

	int32_t posX = newPosID % ConstGameBoardSizePerDir;
	int32_t posY = newPosID / ConstGameBoardSizePerDir;


	int32_t ixMin = max(0, posX - 1);
	int32_t iyMin = max(0, posY - 1);

	int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, posX + 2);
	int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, posY + 2);

	for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
	{
		int32_t iiy = ConstGameBoardSizePerDir * iy;

		for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
		{
			if (pInGameData[ix + iiy] == ConstGameBoard_Player1)
			{
				return true;
			}
		}
	}

	return false;
}

bool Get_PossiblePlayer1CloneMoveStartPos(int32_t *pOutStartX, int32_t *pOutStartY, int32_t newPosID, int8_t *pInGameData)
{
	/*if (pInGameData[newPosID] != ConstGameBoard_Empty)
	{
	return false;
	}*/

	int32_t posX = newPosID % ConstGameBoardSizePerDir;
	int32_t posY = newPosID / ConstGameBoardSizePerDir;


	int32_t ixMin = max(0, posX - 1);
	int32_t iyMin = max(0, posY - 1);

	int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, posX + 2);
	int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, posY + 2);

	for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
	{
		int32_t iiy = ConstGameBoardSizePerDir * iy;

		for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
		{
			if (pInGameData[ix + iiy] == ConstGameBoard_Player1)
			{
				*pOutStartX = ix;
				*pOutStartY = iy;
				return true;
			}
		}
	}

	return false;
}





bool Check_PossiblePlayer2CloneMove(int32_t destinationX, int32_t destinationY, int8_t *pInGameData)
{
	int32_t id = destinationX + ConstGameBoardSizePerDir * destinationY;

	if (pInGameData[id] != ConstGameBoard_Empty)
	{
		return false;
	}

	int32_t ixMin = max(0, destinationX - 1);
	int32_t iyMin = max(0, destinationY - 1);

	int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, destinationX + 2);
	int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, destinationY + 2);

	for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
	{
		int32_t iiy = ConstGameBoardSizePerDir * iy;

		for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
		{
			if (pInGameData[ix + iiy] == ConstGameBoard_Player2)
			{
				return true;
			}
		}
	}

	return false;

}

bool Get_PossiblePlayer2CloneMoveStartPos(int32_t *pOutStartX, int32_t *pOutStartY, int32_t newX, int32_t newY, int8_t *pInGameData)
{
	/*int32_t id = newX + ConstGameBoardSizePerDir * newY;

	if (pInGameData[id] != ConstGameBoard_Empty)
	{
	return false;
	}*/

	int32_t ixMin = max(0, newX - 1);
	int32_t iyMin = max(0, newY - 1);

	int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, newX + 2);
	int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, newY + 2);

	for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
	{
		int32_t iiy = ConstGameBoardSizePerDir * iy;

		for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
		{
			if (pInGameData[ix + iiy] == ConstGameBoard_Player2)
			{
				*pOutStartX = ix;
				*pOutStartY = iy;
				return true;
			}
		}
	}

	return false;

}

bool Check_PossiblePlayer2CloneMove(int32_t newPosID, int8_t *pInGameData)
{
	if (pInGameData[newPosID] != ConstGameBoard_Empty)
	{
		return false;
	}

	int32_t posX = newPosID % ConstGameBoardSizePerDir;
	int32_t posY = newPosID / ConstGameBoardSizePerDir;


	int32_t ixMin = max(0, posX - 1);
	int32_t iyMin = max(0, posY - 1);

	int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, posX + 2);
	int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, posY + 2);

	for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
	{
		int32_t iiy = ConstGameBoardSizePerDir * iy;

		for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
		{
			if (pInGameData[ix + iiy] == ConstGameBoard_Player2)
			{
				return true;
			}
		}
	}

	return false;
}

bool Get_PossiblePlayer2CloneMoveStartPos(int32_t *pOutOldX, int32_t *pOutOldY, int32_t newPosID, int8_t *pInGameData)
{
	/*if (pInGameData[newPosID] != ConstGameBoard_Empty)
	{
	return false;
	}*/

	int32_t posX = newPosID % ConstGameBoardSizePerDir;
	int32_t posY = newPosID / ConstGameBoardSizePerDir;


	int32_t ixMin = max(0, posX - 1);
	int32_t iyMin = max(0, posY - 1);

	int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, posX + 2);
	int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, posY + 2);

	for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
	{
		int32_t iiy = ConstGameBoardSizePerDir * iy;

		for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
		{
			if (pInGameData[ix + iiy] == ConstGameBoard_Player2)
			{
				*pOutOldX = ix;
				*pOutOldY = iy;
				return true;
			}
		}
	}

	return false;
}



bool Check_For_PossibleMove(int8_t *pInGameData)
{
	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pInGameData[i] == ConstGameBoard_Empty)
		{
			return true;
		}
	}

	return false;
}

bool Check_PossiblePlayer1Moves(int8_t *pInGameData)
{
	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pInGameData[i] == ConstGameBoard_Player1)
		{
			int32_t ixOld = i % ConstGameBoardSizePerDir;
			int32_t iyOld = i / ConstGameBoardSizePerDir;

			int32_t ixMin = max(0, ixOld - 2);
			int32_t iyMin = max(0, iyOld - 2);

			int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
			int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

			for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
			{
				for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
				{
					if (pInGameData[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
					{
						return true;
					}
				}
			}
		}
	}

	return false;
}

bool Check_PossiblePlayer2Moves(int8_t *pInGameData)
{
	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pInGameData[i] == ConstGameBoard_Player2)
		{
			int32_t ixOld = i % ConstGameBoardSizePerDir;
			int32_t iyOld = i / ConstGameBoardSizePerDir;

			int32_t ixMin = max(0, ixOld - 2);
			int32_t iyMin = max(0, iyOld - 2);

			int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
			int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

			for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
			{
				for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
				{
					if (pInGameData[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
					{
						return true;
					}
				}
			}
		}
	}

	return false;
}


bool Check_PossiblePlayer1Move(int32_t oldX, int32_t oldY, int32_t newX, int32_t newY, int8_t *pInGameData)
{
	if (abs(newX - oldX) > 2 || abs(newY - oldY) > 2)
	{
		return false;
	}

	if (pInGameData[oldX + ConstGameBoardSizePerDir * oldY] != ConstGameBoard_Player1)
	{
		return false;
	}

	if (pInGameData[newX + ConstGameBoardSizePerDir * newY] != ConstGameBoard_Empty)
	{
		return false;
	}

	return true;
}

bool Check_PossiblePlayer2Move(int32_t oldX, int32_t oldY, int32_t newX, int32_t newY, int8_t *pInGameData)
{
	if (abs(newX - oldX) > 2 || abs(newY - oldY) > 2)
	{
		return false;
	}

	if (pInGameData[oldX + ConstGameBoardSizePerDir * oldY] != ConstGameBoard_Player2)
	{
		return false;
	}

	if (pInGameData[newX + ConstGameBoardSizePerDir * newY] != ConstGameBoard_Empty)
	{
		return false;
	}

	return true;
}

void Make_Player1Move(int32_t oldX, int32_t oldY, int32_t newX, int32_t newY, int8_t *pInOutGameData)
{
	pInOutGameData[newX + ConstGameBoardSizePerDir * newY] = ConstGameBoard_Player1;

	int32_t minX = max(0, newX - 1);
	int32_t minY = max(0, newY - 1);

	//int32_t maxXPlus1 = 1 + min(ConstGameBoardSizePerDirMinus1, newX + 1);
	//int32_t maxYPlus1 = 1 + min(ConstGameBoardSizePerDirMinus1, newY + 1);
	int32_t maxXPlus1 = min(ConstGameBoardSizePerDir, newX + 2);
	int32_t maxYPlus1 = min(ConstGameBoardSizePerDir, newY + 2);

	int32_t id, iiy;

	for (int32_t iy = minY; iy < maxYPlus1; iy++)
	{
		iiy = ConstGameBoardSizePerDir * iy;

		for (int32_t ix = minX; ix < maxXPlus1; ix++)
		{
			id = ix + iiy;

			if (pInOutGameData[id] == ConstGameBoard_Player2)
			{
				pInOutGameData[id] = ConstGameBoard_Player1;
			}
		} /* end of for (int32_t ix = minY; ix < maxXPlus1; ix++) */
	} /* end of for (int32_t iy = minY; iy < maxYPlus1; iy++) */

	if (abs(newX - oldX) > 1 || abs(newY - oldY) > 1)
	{
		id = oldX + ConstGameBoardSizePerDir * oldY;
		pInOutGameData[id] = ConstGameBoard_Empty;
	}
}

void Make_Player1CloneMove(int32_t newX, int32_t newY, int8_t *pInOutGameData)
{
	pInOutGameData[newX + ConstGameBoardSizePerDir * newY] = ConstGameBoard_Player1;

	int32_t minX = max(0, newX - 1);
	int32_t minY = max(0, newY - 1);

	//int32_t maxXPlus1 = 1 + min(ConstGameBoardSizePerDirMinus1, newX + 1);
	//int32_t maxYPlus1 = 1 + min(ConstGameBoardSizePerDirMinus1, newY + 1);
	int32_t maxXPlus1 = min(ConstGameBoardSizePerDir, newX + 2);
	int32_t maxYPlus1 = min(ConstGameBoardSizePerDir, newY + 2);

	int32_t id, iiy;

	for (int32_t iy = minY; iy < maxYPlus1; iy++)
	{
		iiy = ConstGameBoardSizePerDir * iy;

		for (int32_t ix = minX; ix < maxXPlus1; ix++)
		{
			id = ix + iiy;

			if (pInOutGameData[id] == ConstGameBoard_Player2)
			{
				pInOutGameData[id] = ConstGameBoard_Player1;
			}
		} /* end of for (int32_t ix = minY; ix < maxXPlus1; ix++) */
	} /* end of for (int32_t iy = minY; iy < maxYPlus1; iy++) */
}



void Make_Player2Move(int32_t oldX, int32_t oldY, int32_t newX, int32_t newY, int8_t *pInOutGameData)
{
	pInOutGameData[newX + ConstGameBoardSizePerDir * newY] = ConstGameBoard_Player2;

	int32_t minX = max(0, newX - 1);
	int32_t minY = max(0, newY - 1);

	//int32_t maxXPlus1 = 1 + min(ConstGameBoardSizePerDirMinus1, newX + 1);
	//int32_t maxYPlus1 = 1 + min(ConstGameBoardSizePerDirMinus1, newY + 1);
	int32_t maxXPlus1 = min(ConstGameBoardSizePerDir, newX + 2);
	int32_t maxYPlus1 = min(ConstGameBoardSizePerDir, newY + 2);

	int32_t id, iiy;

	for (int32_t iy = minY; iy < maxYPlus1; iy++)
	{
		iiy = ConstGameBoardSizePerDir * iy;

		for (int32_t ix = minX; ix < maxXPlus1; ix++)
		{
			id = ix + iiy;

			if (pInOutGameData[id] == ConstGameBoard_Player1)
			{
				pInOutGameData[id] = ConstGameBoard_Player2;
			}
		} /* end of for (int32_t ix = minY; ix < maxXPlus1; ix++) */
	} /* end of for (int32_t iy = minY; iy < maxYPlus1; iy++) */
	
	if (abs(newX - oldX) > 1 || abs(newY - oldY) > 1)
	{
		id = oldX + ConstGameBoardSizePerDir * oldY;
		pInOutGameData[id] = ConstGameBoard_Empty;
	}
}

void Make_Player2CloneMove(int32_t newX, int32_t newY, int8_t *pInOutGameData)
{
	pInOutGameData[newX + ConstGameBoardSizePerDir * newY] = ConstGameBoard_Player2;

	int32_t minX = max(0, newX - 1);
	int32_t minY = max(0, newY - 1);

	//int32_t maxXPlus1 = 1 + min(ConstGameBoardSizePerDirMinus1, newX + 1);
	//int32_t maxYPlus1 = 1 + min(ConstGameBoardSizePerDirMinus1, newY + 1);
	int32_t maxXPlus1 = min(ConstGameBoardSizePerDir, newX + 2);
	int32_t maxYPlus1 = min(ConstGameBoardSizePerDir, newY + 2);

	int32_t id, iiy;

	for (int32_t iy = minY; iy < maxYPlus1; iy++)
	{
		iiy = ConstGameBoardSizePerDir * iy;

		for (int32_t ix = minX; ix < maxXPlus1; ix++)
		{
			id = ix + iiy;

			if (pInOutGameData[id] == ConstGameBoard_Player1)
			{
				pInOutGameData[id] = ConstGameBoard_Player2;
			}
		} /* end of for (int32_t ix = minY; ix < maxXPlus1; ix++) */
	} /* end of for (int32_t iy = minY; iy < maxYPlus1; iy++) */
}



bool Random_Player1(int8_t *pActualGameStateData, CRandomNumbersNN *pRandomNumbers)
{
	if (Check_PossiblePlayer1Moves(pActualGameStateData) == false)
	{
		return false;
	}

	int32_t oldX;
	int32_t oldY;
	int32_t newX;
	int32_t newY;

	int32_t id1;
	int32_t id2;

	//for (int32_t i = 0; i < 100000; i++)
	do
	{
		oldX = pRandomNumbers->Get_IntegerNumber(0, ConstGameBoardSizePerDir);
		oldY = pRandomNumbers->Get_IntegerNumber(0, ConstGameBoardSizePerDir);

		id1 = oldX + ConstGameBoardSizePerDir * oldY;

		if (pActualGameStateData[id1] != ConstGameBoard_Player1)
			continue;

		newX = oldX + pRandomNumbers->Get_IntegerNumber2(-2, 2);
		newY = oldY + pRandomNumbers->Get_IntegerNumber2(-2, 2);

		newX = max(newX, 0);
		newX = min(newX, ConstGameBoardSizePerDirMinus1);

		newY = max(newY, 0);
		newY = min(newY, ConstGameBoardSizePerDirMinus1);

		if(newX == oldX && newY == oldY)
			continue;

		id2 = newX + ConstGameBoardSizePerDir * newY;

		if (pActualGameStateData[id2] != ConstGameBoard_Empty)
			continue;

		// macht ein m�glicher Sprung-Z�ge Sinn?
		if (abs(newX - oldX) > 1 || abs(newY - oldY) > 1)
		{
			int32_t ixMin = max(0, newX - 1);
			int32_t iyMin = max(0, newY - 1);

			int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, newX + 2);
			int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, newY + 2);

			bool badMoveDecision = false;
			bool isolatedPos = true;

			int32_t iiy;
			int8_t gameStateValue;

			for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
			{
				iiy = ConstGameBoardSizePerDir * iy;

				for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
				{
					gameStateValue = pActualGameStateData[ix + iiy];

					if (gameStateValue == ConstGameBoard_Player1)
					{
						isolatedPos = false;
						badMoveDecision = true;
						break;
					}
					if (gameStateValue != ConstGameBoard_Empty)
					{
						isolatedPos = false;
					}
				}

				if (badMoveDecision == true)
				{
					break;
				}

			}

			if (badMoveDecision == true || isolatedPos == true)
			{
				continue;
			}
		} // end of if (abs(newX - oldX) > 1 || abs(newY - oldY) > 1)


		Make_Player1Move(oldX, oldY, newX, newY, pActualGameStateData);
		return true;
	} while (true);


	return false;
}

void Random_Player1_WithoutMovementTest(int8_t *pActualGameStateData, CRandomNumbersNN *pRandomNumbers)
{
	int32_t oldX;
	int32_t oldY;
	int32_t newX;
	int32_t newY;

	int32_t id1;
	int32_t id2;

	//for (int32_t i = 0; i < 100000; i++)
	do
	{
		oldX = pRandomNumbers->Get_IntegerNumber(0, ConstGameBoardSizePerDir);
		oldY = pRandomNumbers->Get_IntegerNumber(0, ConstGameBoardSizePerDir);

		id1 = oldX + ConstGameBoardSizePerDir * oldY;

		if (pActualGameStateData[id1] != ConstGameBoard_Player1)
			continue;

		newX = oldX + pRandomNumbers->Get_IntegerNumber2(-2, 2);
		newY = oldY + pRandomNumbers->Get_IntegerNumber2(-2, 2);

		newX = max(newX, 0);
		newX = min(newX, ConstGameBoardSizePerDirMinus1);

		newY = max(newY, 0);
		newY = min(newY, ConstGameBoardSizePerDirMinus1);

		if (newX == oldX && newY == oldY)
			continue;

		id2 = newX + ConstGameBoardSizePerDir * newY;

		if (pActualGameStateData[id2] != ConstGameBoard_Empty)
			continue;

		// macht ein m�glicher Sprung-Z�ge Sinn?
		if (abs(newX - oldX) > 1 || abs(newY - oldY) > 1)
		{
			int32_t ixMin = max(0, newX - 1);
			int32_t iyMin = max(0, newY - 1);

			int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, newX + 2);
			int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, newY + 2);

			bool badMoveDecision = false;
			bool isolatedPos = true;

			int32_t iiy;
			int8_t gameStateValue;

			for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
			{
				iiy = ConstGameBoardSizePerDir * iy;

				for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
				{
					gameStateValue = pActualGameStateData[ix + iiy];

					if (gameStateValue == ConstGameBoard_Player1)
					{
						isolatedPos = false;
						badMoveDecision = true;
						break;
					}
					if (gameStateValue != ConstGameBoard_Empty)
					{
						isolatedPos = false;
					}
				}

				if (badMoveDecision == true)
				{
					break;
				}

			}

			if (badMoveDecision == true || isolatedPos == true)
			{
				continue;
			}
		} // end of if (abs(newX - oldX) > 1 || abs(newY - oldY) > 1)

		Make_Player1Move(oldX, oldY, newX, newY, pActualGameStateData);
		return;
	} while (true);
}

bool Random_Player2(int8_t *pActualGameStateData, CRandomNumbersNN *pRandomNumbers)
{
	if (Check_PossiblePlayer2Moves(pActualGameStateData) == false)
	{
		return false;
	}

	int32_t oldX;
	int32_t oldY;
	int32_t newX;
	int32_t newY;

	int32_t id1;
	int32_t id2;

	//for (int32_t i = 0; i < 100000; i++)
	do
	{
		oldX = pRandomNumbers->Get_IntegerNumber(0, ConstGameBoardSizePerDir);
		oldY = pRandomNumbers->Get_IntegerNumber(0, ConstGameBoardSizePerDir);

		id1 = oldX + ConstGameBoardSizePerDir * oldY;

		if (pActualGameStateData[id1] != ConstGameBoard_Player2)
			continue;

		newX = oldX + pRandomNumbers->Get_IntegerNumber2(-2, 2);
		newY = oldY + pRandomNumbers->Get_IntegerNumber2(-2, 2);

		newX = max(newX, 0);
		newX = min(newX, ConstGameBoardSizePerDirMinus1);

		newY = max(newY, 0);
		newY = min(newY, ConstGameBoardSizePerDirMinus1);

		if (newX == oldX && newY == oldY)
			continue;

		id2 = newX + ConstGameBoardSizePerDir * newY;

		if (pActualGameStateData[id2] != ConstGameBoard_Empty)
			continue;

		// macht ein m�glicher Sprung-Z�ge Sinn?
		if (abs(newX - oldX) > 1 || abs(newY - oldY) > 1)
		{
			int32_t ixMin = max(0, newX - 1);
			int32_t iyMin = max(0, newY - 1);

			int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, newX + 2);
			int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, newY + 2);

			bool badMoveDecision = false;
			bool isolatedPos = true;

			int32_t iiy;
			int8_t gameStateValue;

			for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
			{
				iiy = ConstGameBoardSizePerDir * iy;

				for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
				{
					gameStateValue = pActualGameStateData[ix + iiy];

					if (gameStateValue == ConstGameBoard_Player2)
					{
						isolatedPos = false;
						badMoveDecision = true;
						break;
					}
					if (gameStateValue != ConstGameBoard_Empty)
					{
						isolatedPos = false;
					}
				}

				if (badMoveDecision == true)
				{
					break;
				}

			}

			if (badMoveDecision == true || isolatedPos == true)
			{
				continue;
			}
		} // end of if (abs(newX - oldX) > 1 || abs(newY - oldY) > 1)

		Make_Player2Move(oldX, oldY, newX, newY, pActualGameStateData);
		return true;
	} while (true);

	return false;
}

void Random_Player2_WithoutMovementTest(int8_t *pActualGameStateData, CRandomNumbersNN *pRandomNumbers)
{
	int32_t oldX;
	int32_t oldY;
	int32_t newX;
	int32_t newY;

	int32_t id1;
	int32_t id2;

	//for (int32_t i = 0; i < 100000; i++)
	do
	{
		oldX = pRandomNumbers->Get_IntegerNumber(0, ConstGameBoardSizePerDir);
		oldY = pRandomNumbers->Get_IntegerNumber(0, ConstGameBoardSizePerDir);

		id1 = oldX + ConstGameBoardSizePerDir * oldY;

		if (pActualGameStateData[id1] != ConstGameBoard_Player2)
			continue;

		newX = oldX + pRandomNumbers->Get_IntegerNumber2(-2, 2);
		newY = oldY + pRandomNumbers->Get_IntegerNumber2(-2, 2);

		newX = max(newX, 0);
		newX = min(newX, ConstGameBoardSizePerDirMinus1);

		newY = max(newY, 0);
		newY = min(newY, ConstGameBoardSizePerDirMinus1);

		if (newX == oldX && newY == oldY)
			continue;

		id2 = newX + ConstGameBoardSizePerDir * newY;

		if (pActualGameStateData[id2] != ConstGameBoard_Empty)
			continue;

		// macht ein m�glicher Sprung-Z�ge Sinn?
		if (abs(newX - oldX) > 1 || abs(newY - oldY) > 1)
		{
			int32_t ixMin = max(0, newX - 1);
			int32_t iyMin = max(0, newY - 1);

			int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, newX + 2);
			int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, newY + 2);

			bool badMoveDecision = false;
			bool isolatedPos = true;

			int32_t iiy;
			int8_t gameStateValue;

			for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
			{
				iiy = ConstGameBoardSizePerDir * iy;

				for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
				{
					gameStateValue = pActualGameStateData[ix + iiy];

					if (gameStateValue == ConstGameBoard_Player2)
					{
						isolatedPos = false;
						badMoveDecision = true;
						break;
					}
					if (gameStateValue != ConstGameBoard_Empty)
					{
						isolatedPos = false;
					}
				}

				if (badMoveDecision == true)
				{
					break;
				}

			}

			if (badMoveDecision == true || isolatedPos == true)
			{
				continue;
			}
		} // end of if (abs(newX - oldX) > 1 || abs(newY - oldY) > 1)

		Make_Player2Move(oldX, oldY, newX, newY, pActualGameStateData);
		return;
	} while (true);
}


bool Random_Player1(CGameStateValues* pActualGameStateObject, CRandomNumbersNN *pRandomNumbers)
{
	int8_t *pActualGameStateData = &pActualGameStateObject->pValueArray[0];

	if (Check_PossiblePlayer1Moves(pActualGameStateData) == false)
	{
		return false;
	}

	int32_t oldX;
	int32_t oldY;
	int32_t newX;
	int32_t newY;

	int32_t id1;
	int32_t id2;

	//for (int32_t i = 0; i < 100000; i++)
	do
	{
		oldX = pRandomNumbers->Get_IntegerNumber(0, ConstGameBoardSizePerDir);
		oldY = pRandomNumbers->Get_IntegerNumber(0, ConstGameBoardSizePerDir);

		id1 = oldX + ConstGameBoardSizePerDir * oldY;

		if (pActualGameStateData[id1] != ConstGameBoard_Player1)
			continue;

		newX = oldX + pRandomNumbers->Get_IntegerNumber2(-2, 2);
		newY = oldY + pRandomNumbers->Get_IntegerNumber2(-2, 2);

		newX = max(newX, 0);
		newX = min(newX, ConstGameBoardSizePerDirMinus1);

		newY = max(newY, 0);
		newY = min(newY, ConstGameBoardSizePerDirMinus1);

		if (newX == oldX && newY == oldY)
			continue;

		id2 = newX + ConstGameBoardSizePerDir * newY;

		if (pActualGameStateData[id2] != ConstGameBoard_Empty)
			continue;

		// macht ein m�glicher Sprung-Z�ge Sinn?
		if (abs(newX - oldX) > 1 || abs(newY - oldY) > 1)
		{
			int32_t ixMin = max(0, newX - 1);
			int32_t iyMin = max(0, newY - 1);

			int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, newX + 2);
			int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, newY + 2);

			bool badMoveDecision = false;
			bool isolatedPos = true;

			int32_t iiy;
			int8_t gameStateValue;

			for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
			{
				iiy = ConstGameBoardSizePerDir * iy;

				for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
				{
					gameStateValue = pActualGameStateData[ix + iiy];

					if (gameStateValue == ConstGameBoard_Player1)
					{
						isolatedPos = false;
						badMoveDecision = true;
						break;
					}
					if (gameStateValue != ConstGameBoard_Empty)
					{
						isolatedPos = false;
					}
				}

				if (badMoveDecision == true)
				{
					break;
				}

			}

			if (badMoveDecision == true || isolatedPos == true)
			{
				continue;
			}
		} // end of if (abs(newX - oldX) > 1 || abs(newY - oldY) > 1)

		Make_Player1Move(oldX, oldY, newX, newY, pActualGameStateData);
		pActualGameStateObject->PlayerID = 0;

		return true;
	} while (true);

	return false;
}

bool Random_Player1(CGameStateValues* pActualGameStateObject, CRandomNumbersNN *pRandomNumbers, int32_t movementCounter, CSingleRecognitionNeuronEnsemble *pGameStateRecognitionNeuronEnsembleArray)
{
	static CGameStateValues TestGameState(ConstGameBoardSizePerDir, ConstGameBoardSizePerDir);

	int8_t *pActualGameStateData = &pActualGameStateObject->pValueArray[0];
	
	if (Check_PossiblePlayer1Moves(pActualGameStateData) == false)
	{
		return false;
	}

	int32_t oldX;
	int32_t oldY;
	int32_t newX;
	int32_t newY;

	int32_t id1;
	int32_t id2;

	if (movementCounter < ConstNumGameStateRecognitionNeuronEnsembles)
	{
		for (int32_t i = 0; i < 10000; i++)
		{ 
			TestGameState.Clone_GameStateValues(pActualGameStateObject);

			oldX = pRandomNumbers->Get_IntegerNumber(0, ConstGameBoardSizePerDir);
			oldY = pRandomNumbers->Get_IntegerNumber(0, ConstGameBoardSizePerDir);

			id1 = oldX + ConstGameBoardSizePerDir * oldY;

			if (pActualGameStateData[id1] != ConstGameBoard_Player1)
				continue;

			newX = oldX + pRandomNumbers->Get_IntegerNumber2(-2, 2);
			newY = oldY + pRandomNumbers->Get_IntegerNumber2(-2, 2);

			newX = max(newX, 0);
			newX = min(newX, ConstGameBoardSizePerDirMinus1);

			newY = max(newY, 0);
			newY = min(newY, ConstGameBoardSizePerDirMinus1);

			if (newX == oldX && newY == oldY)
				continue;

			id2 = newX + ConstGameBoardSizePerDir * newY;

			if (pActualGameStateData[id2] != ConstGameBoard_Empty)
				continue;

			// macht ein m�glicher Sprung-Z�ge Sinn?
			if (abs(newX - oldX) > 1 || abs(newY - oldY) > 1)
			{
				int32_t ixMin = max(0, newX - 1);
				int32_t iyMin = max(0, newY - 1);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, newX + 2);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, newY + 2);

				bool badMoveDecision = false;
				bool isolatedPos = true;

				int32_t iiy;
				int8_t gameStateValue;

				for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
				{
					iiy = ConstGameBoardSizePerDir * iy;

					for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
					{
						gameStateValue = pActualGameStateData[ix + iiy];

						if (gameStateValue == ConstGameBoard_Player1)
						{
							isolatedPos = false;
							badMoveDecision = true;
							break;
						}
						if (gameStateValue != ConstGameBoard_Empty)
						{
							isolatedPos = false;
						}
					}

					if (badMoveDecision == true)
					{
						break;
					}

				}

				if (badMoveDecision == true || isolatedPos == true)
				{
					continue;
				}
			} // end of if (abs(newX - oldX) > 1 || abs(newY - oldY) > 1)

			Make_Player1Move(oldX, oldY, newX, newY, &TestGameState.pValueArray[0]);
			
			Copy_GameData_Into_MemoryVector(tempMemoryVector, &TestGameState.pValueArray[0]);


			//Add_To_Log(0, "movementCounter", movementCounter);
			//Add_To_Log(0, "NumOfUsedMemoryNeurons", pGameStateRecognitionNeuronEnsembleArray[movementCounter].NumOfUsedMemoryNeurons);
			
			
			if (pGameStateRecognitionNeuronEnsembleArray[movementCounter].Compare_DataWithMemory(tempMemoryVector) == -1)		
			{
				pGameStateRecognitionNeuronEnsembleArray[movementCounter].Set_AdditionalMemoryValues(tempMemoryVector);
				pActualGameStateObject->Clone_GameStateValues(&TestGameState);
				pActualGameStateObject->PlayerID = 0;

				return true;
			}
		}
	}

	//Add_To_Log(0, "Oppps", movementCounter);

	//for (int32_t i = 0; i < 100000; i++)
	do
	{
		oldX = pRandomNumbers->Get_IntegerNumber(0, ConstGameBoardSizePerDir);
		oldY = pRandomNumbers->Get_IntegerNumber(0, ConstGameBoardSizePerDir);

		id1 = oldX + ConstGameBoardSizePerDir * oldY;

		if (pActualGameStateData[id1] != ConstGameBoard_Player1)
			continue;

		newX = oldX + pRandomNumbers->Get_IntegerNumber2(-2, 2);
		newY = oldY + pRandomNumbers->Get_IntegerNumber2(-2, 2);

		newX = max(newX, 0);
		newX = min(newX, ConstGameBoardSizePerDirMinus1);

		newY = max(newY, 0);
		newY = min(newY, ConstGameBoardSizePerDirMinus1);

		if (newX == oldX && newY == oldY)
			continue;

		id2 = newX + ConstGameBoardSizePerDir * newY;

		if (pActualGameStateData[id2] != ConstGameBoard_Empty)
			continue;

		// macht ein m�glicher Sprung-Z�ge Sinn?
		if (abs(newX - oldX) > 1 || abs(newY - oldY) > 1)
		{
			int32_t ixMin = max(0, newX - 1);
			int32_t iyMin = max(0, newY - 1);

			int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, newX + 2);
			int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, newY + 2);

			bool badMoveDecision = false;
			bool isolatedPos = true;

			int32_t iiy;
			int8_t gameStateValue;

			for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
			{
				iiy = ConstGameBoardSizePerDir * iy;

				for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
				{
					gameStateValue = pActualGameStateData[ix + iiy];

					if (gameStateValue == ConstGameBoard_Player1)
					{
						isolatedPos = false;
						badMoveDecision = true;
						break;
					}
					if (gameStateValue != ConstGameBoard_Empty)
					{
						isolatedPos = false;
					}
				}

				if (badMoveDecision == true)
				{
					break;
				}

			}

			if (badMoveDecision == true || isolatedPos == true)
			{
				continue;
			}
		} // end of if (abs(newX - oldX) > 1 || abs(newY - oldY) > 1)

		if (movementCounter < ConstNumGameStateRecognitionNeuronEnsembles)
		{
			Copy_GameData_Into_MemoryVector(tempMemoryVector, pActualGameStateData);
			pGameStateRecognitionNeuronEnsembleArray[movementCounter].Set_AdditionalMemoryValues(tempMemoryVector);
		}

		Make_Player1Move(oldX, oldY, newX, newY, pActualGameStateData);
		pActualGameStateObject->PlayerID = 0;

		return true;
	} while (true);

	return false;
}


bool ExtRandom_Player1(float AIParamScoreWeight, CGameStateValues* pActualGameStateObject, CRandomNumbersNN *pRandomNumbers, int32_t movementCounter, CAtaxxBoardEvaluator *pAtaxxBoardEvaluator, CSingleRecognitionNeuronEnsemble *pGameStateRecognitionNeuronEnsembleArray, CSimpleNeuron *pAdditionalEvaluationNeuronArray)
{
	static CGameStateValues TestGameState(ConstGameBoardSizePerDir, ConstGameBoardSizePerDir);
	static CGameStateValues BestGameState(ConstGameBoardSizePerDir, ConstGameBoardSizePerDir);

	float OneMinusAIParamScoreWeight = 1.0f - AIParamScoreWeight;

	int8_t *pActualGameStateData = &pActualGameStateObject->pValueArray[0];

	if (Check_PossiblePlayer1Moves(pActualGameStateData) == false)
	{
		return false;
	}

	int32_t oldX;
	int32_t oldY;
	int32_t newX;
	int32_t newY;

	int32_t id1;
	int32_t id2;

	if (movementCounter < ConstNumGameStateRecognitionNeuronEnsembles)
	{
		/* Wenn m�glich einen bereits erlernten Spielzug ausf�hren (Ged�chtnis): */

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateData[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer1CloneMove(i, pActualGameStateData) == true)
				{
					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;


					TestGameState.Clone_GameStateValues(pActualGameStateObject);

					// Testzug ausf�hren:
					Make_Player1CloneMove(ixNew, iyNew, &TestGameState.pValueArray[0]);


					Copy_GameData_Into_MemoryVector(tempMemoryVector, &TestGameState.pValueArray[0]);

					// Ged�chtnis-Spielzug gefunden; Zug ausf�hren:
					if (pGameStateRecognitionNeuronEnsembleArray[movementCounter].Compare_DataWithMemory(tempMemoryVector) > -1)
					{
						pActualGameStateObject->Clone_GameStateValues(&TestGameState);
						pActualGameStateObject->PlayerID = 0;

						int32_t player1Score, player2Score;
						Calculate_Score(&player1Score, &player2Score, &pActualGameStateObject->pValueArray[0]);

						Add_To_Log(0, "movementCounter", movementCounter);
						Add_To_Log(0, "activationValue 1");
						Add_To_Log(0, "player1Score", player1Score);
						Add_To_Log(0, "player2Score", player2Score);
						return true;
					}
				}
			}
			else if (pActualGameStateData[i] == ConstGameBoard_Player1)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateData[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							/* �berpr�fen, ob ein Sprung-Zug �berhaupt sinnvoll ist: */
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateData[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player1)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} /* end of �berpr�fen, ob ein Sprung-Zug �berhaupt sinnvoll ist */


							  /* N�chsten Testzug vorbereiten und ausf�hren: */
							TestGameState.Clone_GameStateValues(pActualGameStateObject);
							Make_Player1Move(ixOld, iyOld, ixNew, iyNew, &TestGameState.pValueArray[0]);


							Copy_GameData_Into_MemoryVector(tempMemoryVector, &TestGameState.pValueArray[0]);

							// Ged�chtnis-Spielzug gefunden; Zug ausf�hren:
							if (pGameStateRecognitionNeuronEnsembleArray[movementCounter].Compare_DataWithMemory(tempMemoryVector) > -1)
							{
								pActualGameStateObject->Clone_GameStateValues(&TestGameState);
								pActualGameStateObject->PlayerID = 0;

								int32_t player1Score, player2Score;
								Calculate_Score(&player1Score, &player2Score, &pActualGameStateObject->pValueArray[0]);

								Add_To_Log(0, "movementCounter", movementCounter);
								Add_To_Log(0, "activationValue 1");
								Add_To_Log(0, "player1Score", player1Score);
								Add_To_Log(0, "player2Score", player2Score);
								return true;
							}
						} // end of if (pActualGameStateData[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
					} // end of for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
				} // end of for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		/* Einen m�glichst erfolgversprechenden Spielzug suchen und ausf�hren */

		int32_t player1Score, player2Score;
		float player1EvaluationScore;
		float maxEvaluationScore = -100000.0f;
		
		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateData[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer1CloneMove(i, pActualGameStateData) == true)
				{
					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;


					TestGameState.Clone_GameStateValues(pActualGameStateObject);

					// Testzug ausf�hren:
					Make_Player1CloneMove(ixNew, iyNew, &TestGameState.pValueArray[0]);

					Calculate_Score(&player1Score, &player2Score, &TestGameState.pValueArray[0]);
					player1EvaluationScore = pAtaxxBoardEvaluator->Evaluate_Player1(&TestGameState);
					

					float evaluationScore = AIParamScoreWeight * static_cast<float>(player1Score - player2Score) +
						OneMinusAIParamScoreWeight * player1EvaluationScore;
					

					Copy_GameData_Into_BinaryGameStateVector(tempBinaryGameStateVector, &TestGameState.pValueArray[0]);
					pAdditionalEvaluationNeuronArray[movementCounter].Set_Dendrite_NeuronInput(0, 0, tempBinaryGameStateVector, ConstBinaryGameStateVectorSize, 1, ConstBinaryGameStateVectorSize, 1);
					pAdditionalEvaluationNeuronArray[movementCounter].Calculate_NeuronOutput();

					
					evaluationScore *= pAdditionalEvaluationNeuronArray[movementCounter].ActivationValue;
					//evaluationScore = pAdditionalEvaluationNeuronArray[movementCounter].ActivationValue;

					if (evaluationScore > maxEvaluationScore)
					{
						//Add_To_Log(0, "evaluationScore", evaluationScore);
						maxEvaluationScore = evaluationScore;
						BestGameState.Clone_GameStateValues(&TestGameState);
						
					}
				}
			}
			else if (pActualGameStateData[i] == ConstGameBoard_Player1)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateData[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							/* �berpr�fen, ob ein Sprung-Zug �berhaupt sinnvoll ist: */
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateData[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player1)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} /* end of �berpr�fen, ob ein Sprung-Zug �berhaupt sinnvoll ist */


							  /* N�chsten Testzug vorbereiten und ausf�hren: */
							TestGameState.Clone_GameStateValues(pActualGameStateObject);
							Make_Player1Move(ixOld, iyOld, ixNew, iyNew, &TestGameState.pValueArray[0]);

							Calculate_Score(&player1Score, &player2Score, &TestGameState.pValueArray[0]);
							player1EvaluationScore = pAtaxxBoardEvaluator->Evaluate_Player1(&TestGameState);
							

							float evaluationScore = AIParamScoreWeight * static_cast<float>(player1Score - player2Score) +
									                OneMinusAIParamScoreWeight * player1EvaluationScore;
							

							Copy_GameData_Into_BinaryGameStateVector(tempBinaryGameStateVector, &TestGameState.pValueArray[0]);
							pAdditionalEvaluationNeuronArray[movementCounter].Set_Dendrite_NeuronInput(0, 0, tempBinaryGameStateVector, ConstBinaryGameStateVectorSize, 1, ConstBinaryGameStateVectorSize, 1);
							pAdditionalEvaluationNeuronArray[movementCounter].Calculate_NeuronOutput();

							
							evaluationScore *= pAdditionalEvaluationNeuronArray[movementCounter].ActivationValue;
							//evaluationScore = pAdditionalEvaluationNeuronArray[movementCounter].ActivationValue;

							if (evaluationScore > maxEvaluationScore)
							{
								//Add_To_Log(0, "evaluationScore", evaluationScore);
								maxEvaluationScore = evaluationScore;
								BestGameState.Clone_GameStateValues(&TestGameState);

							}
						} // end of if (pActualGameStateData[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
					} // end of for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
				} // end of for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		pActualGameStateObject->Clone_GameStateValues(&BestGameState);
		pActualGameStateObject->PlayerID = 0;

		

		return true;

	} // end of if (movementCounter < ConstNumGameStateRecognitionNeuronEnsembles)

	// Zufallszug generieren:

	do
	{
		oldX = pRandomNumbers->Get_IntegerNumber(0, ConstGameBoardSizePerDir);
		oldY = pRandomNumbers->Get_IntegerNumber(0, ConstGameBoardSizePerDir);

		id1 = oldX + ConstGameBoardSizePerDir * oldY;

		if (pActualGameStateData[id1] != ConstGameBoard_Player1)
			continue;

		newX = oldX + pRandomNumbers->Get_IntegerNumber2(-2, 2);
		newY = oldY + pRandomNumbers->Get_IntegerNumber2(-2, 2);

		newX = max(newX, 0);
		newX = min(newX, ConstGameBoardSizePerDirMinus1);

		newY = max(newY, 0);
		newY = min(newY, ConstGameBoardSizePerDirMinus1);

		if (newX == oldX && newY == oldY)
			continue;

		id2 = newX + ConstGameBoardSizePerDir * newY;

		if (pActualGameStateData[id2] != ConstGameBoard_Empty)
			continue;

		// macht ein m�glicher Sprung-Z�ge Sinn?
		if (abs(newX - oldX) > 1 || abs(newY - oldY) > 1)
		{
			int32_t ixMin = max(0, newX - 1);
			int32_t iyMin = max(0, newY - 1);

			int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, newX + 2);
			int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, newY + 2);

			bool badMoveDecision = false;
			bool isolatedPos = true;

			int32_t iiy;
			int8_t gameStateValue;

			for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
			{
				iiy = ConstGameBoardSizePerDir * iy;

				for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
				{
					gameStateValue = pActualGameStateData[ix + iiy];

					if (gameStateValue == ConstGameBoard_Player1)
					{
						isolatedPos = false;
						badMoveDecision = true;
						break;
					}
					if (gameStateValue != ConstGameBoard_Empty)
					{
						isolatedPos = false;
					}
				}

				if (badMoveDecision == true)
				{
					break;
				}

			}

			if (badMoveDecision == true || isolatedPos == true)
			{
				continue;
			}
		} // end of if (abs(newX - oldX) > 1 || abs(newY - oldY) > 1)

		Make_Player1Move(oldX, oldY, newX, newY, pActualGameStateData);
		pActualGameStateObject->PlayerID = 0;

		break;
	} while (true);

	return true;
}

bool ExtRandom_Player1(float AIParamScoreWeight, CGameStateValues* pActualGameStateObject, CRandomNumbersNN *pRandomNumbers, int32_t movementCounter, CAtaxxBoardEvaluator *pAtaxxBoardEvaluator, CSingleRecognitionNeuronEnsemble *pGameStateRecognitionNeuronEnsembleArray)
{
	static CGameStateValues TestGameState(ConstGameBoardSizePerDir, ConstGameBoardSizePerDir);
	static CGameStateValues BestGameState(ConstGameBoardSizePerDir, ConstGameBoardSizePerDir);

	float OneMinusAIParamScoreWeight = 1.0f - AIParamScoreWeight;

	int8_t *pActualGameStateData = &pActualGameStateObject->pValueArray[0];

	if (Check_PossiblePlayer1Moves(pActualGameStateData) == false)
	{
		return false;
	}

	int32_t oldX;
	int32_t oldY;
	int32_t newX;
	int32_t newY;

	int32_t id1;
	int32_t id2;

	if (movementCounter < ConstNumGameStateRecognitionNeuronEnsembles)
	{
		/* Wenn m�glich einen bereits erlernten Spielzug ausf�hren (Ged�chtnis): */

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateData[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer1CloneMove(i, pActualGameStateData) == true)
				{
					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;


					TestGameState.Clone_GameStateValues(pActualGameStateObject);

					// Testzug ausf�hren:
					Make_Player1CloneMove(ixNew, iyNew, &TestGameState.pValueArray[0]);


					Copy_GameData_Into_MemoryVector(tempMemoryVector, &TestGameState.pValueArray[0]);

					// Ged�chtnis-Spielzug gefunden; Zug ausf�hren:
					if (pGameStateRecognitionNeuronEnsembleArray[movementCounter].Compare_DataWithMemory(tempMemoryVector) > -1)
					{
						pActualGameStateObject->Clone_GameStateValues(&TestGameState);
						pActualGameStateObject->PlayerID = 0;

						int32_t player1Score, player2Score;
						Calculate_Score(&player1Score, &player2Score, &pActualGameStateObject->pValueArray[0]);

						Add_To_Log(0, "movementCounter", movementCounter);
						Add_To_Log(0, "activationValue 1");
						Add_To_Log(0, "player1Score", player1Score);
						Add_To_Log(0, "player2Score", player2Score);
						return true;
					}
				}
			}
			else if (pActualGameStateData[i] == ConstGameBoard_Player1)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateData[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							/* �berpr�fen, ob ein Sprung-Zug �berhaupt sinnvoll ist: */
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateData[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player1)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} /* end of �berpr�fen, ob ein Sprung-Zug �berhaupt sinnvoll ist */


							  /* N�chsten Testzug vorbereiten und ausf�hren: */
							TestGameState.Clone_GameStateValues(pActualGameStateObject);
							Make_Player1Move(ixOld, iyOld, ixNew, iyNew, &TestGameState.pValueArray[0]);


							Copy_GameData_Into_MemoryVector(tempMemoryVector, &TestGameState.pValueArray[0]);

							// Ged�chtnis-Spielzug gefunden; Zug ausf�hren:
							if (pGameStateRecognitionNeuronEnsembleArray[movementCounter].Compare_DataWithMemory(tempMemoryVector) > -1)
							{
								pActualGameStateObject->Clone_GameStateValues(&TestGameState);
								pActualGameStateObject->PlayerID = 0;

								int32_t player1Score, player2Score;
								Calculate_Score(&player1Score, &player2Score, &pActualGameStateObject->pValueArray[0]);

								Add_To_Log(0, "movementCounter", movementCounter);
								Add_To_Log(0, "activationValue 1");
								Add_To_Log(0, "player1Score", player1Score);
								Add_To_Log(0, "player2Score", player2Score);
								return true;
							}
						} // end of if (pActualGameStateData[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
					} // end of for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
				} // end of for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		  /* Einen m�glichst erfolgversprechenden Spielzug suchen und ausf�hren */

		int32_t player1Score, player2Score, memoryNeuronID;
		float player1EvaluationScore;
		float maxEvaluationScore = -100000.0f;


		

	
		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateData[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer1CloneMove(i, pActualGameStateData) == true)
				{
					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;


					TestGameState.Clone_GameStateValues(pActualGameStateObject);

					// Testzug ausf�hren:
					Make_Player1CloneMove(ixNew, iyNew, &TestGameState.pValueArray[0]);

					


					Calculate_Score(&player1Score, &player2Score, &TestGameState.pValueArray[0]);
					player1EvaluationScore = pAtaxxBoardEvaluator->Evaluate_Player1(&TestGameState);


					float evaluationScore = AIParamScoreWeight * static_cast<float>(player1Score - player2Score) +
						OneMinusAIParamScoreWeight * player1EvaluationScore;


					Copy_GameData_Into_BinaryGameStateVector(tempBinaryGameStateVector, &TestGameState.pValueArray[0]);
					

					evaluationScore /= Calculate_MinGameStateMemoryVariance(&memoryNeuronID, tempBinaryGameStateVector, &pGameStateRecognitionNeuronEnsembleArray[movementCounter]);
					

					if (evaluationScore > maxEvaluationScore)
					{
						//Add_To_Log(0, "evaluationScore", evaluationScore);
						maxEvaluationScore = evaluationScore;
						BestGameState.Clone_GameStateValues(&TestGameState);

					}

				
					

				}
			}
			else if (pActualGameStateData[i] == ConstGameBoard_Player1)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateData[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							/* �berpr�fen, ob ein Sprung-Zug �berhaupt sinnvoll ist: */
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateData[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player1)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} /* end of �berpr�fen, ob ein Sprung-Zug �berhaupt sinnvoll ist */


							  /* N�chsten Testzug vorbereiten und ausf�hren: */
							TestGameState.Clone_GameStateValues(pActualGameStateObject);
							Make_Player1Move(ixOld, iyOld, ixNew, iyNew, &TestGameState.pValueArray[0]);

							Calculate_Score(&player1Score, &player2Score, &TestGameState.pValueArray[0]);
							player1EvaluationScore = pAtaxxBoardEvaluator->Evaluate_Player1(&TestGameState);


							float evaluationScore = AIParamScoreWeight * static_cast<float>(player1Score - player2Score) +
								OneMinusAIParamScoreWeight * player1EvaluationScore;


							Copy_GameData_Into_BinaryGameStateVector(tempBinaryGameStateVector, &TestGameState.pValueArray[0]);
							

							evaluationScore /= Calculate_MinGameStateMemoryVariance(&memoryNeuronID, tempBinaryGameStateVector, &pGameStateRecognitionNeuronEnsembleArray[movementCounter]);
							

							if (evaluationScore > maxEvaluationScore)
							{
								//Add_To_Log(0, "evaluationScore", evaluationScore);
								maxEvaluationScore = evaluationScore;
								BestGameState.Clone_GameStateValues(&TestGameState);

							}

							

						} // end of if (pActualGameStateData[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
					} // end of for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
				} // end of for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		pActualGameStateObject->Clone_GameStateValues(&BestGameState);
		pActualGameStateObject->PlayerID = 0;



		return true;

	} // end of if (movementCounter < ConstNumGameStateRecognitionNeuronEnsembles)

	  // Zufallszug generieren:

	do
	{
		oldX = pRandomNumbers->Get_IntegerNumber(0, ConstGameBoardSizePerDir);
		oldY = pRandomNumbers->Get_IntegerNumber(0, ConstGameBoardSizePerDir);

		id1 = oldX + ConstGameBoardSizePerDir * oldY;

		if (pActualGameStateData[id1] != ConstGameBoard_Player1)
			continue;

		newX = oldX + pRandomNumbers->Get_IntegerNumber2(-2, 2);
		newY = oldY + pRandomNumbers->Get_IntegerNumber2(-2, 2);

		newX = max(newX, 0);
		newX = min(newX, ConstGameBoardSizePerDirMinus1);

		newY = max(newY, 0);
		newY = min(newY, ConstGameBoardSizePerDirMinus1);

		if (newX == oldX && newY == oldY)
			continue;

		id2 = newX + ConstGameBoardSizePerDir * newY;

		if (pActualGameStateData[id2] != ConstGameBoard_Empty)
			continue;

		// macht ein m�glicher Sprung-Z�ge Sinn?
		if (abs(newX - oldX) > 1 || abs(newY - oldY) > 1)
		{
			int32_t ixMin = max(0, newX - 1);
			int32_t iyMin = max(0, newY - 1);

			int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, newX + 2);
			int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, newY + 2);

			bool badMoveDecision = false;
			bool isolatedPos = true;

			int32_t iiy;
			int8_t gameStateValue;

			for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
			{
				iiy = ConstGameBoardSizePerDir * iy;

				for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
				{
					gameStateValue = pActualGameStateData[ix + iiy];

					if (gameStateValue == ConstGameBoard_Player1)
					{
						isolatedPos = false;
						badMoveDecision = true;
						break;
					}
					if (gameStateValue != ConstGameBoard_Empty)
					{
						isolatedPos = false;
					}
				}

				if (badMoveDecision == true)
				{
					break;
				}

			}

			if (badMoveDecision == true || isolatedPos == true)
			{
				continue;
			}
		} // end of if (abs(newX - oldX) > 1 || abs(newY - oldY) > 1)

		Make_Player1Move(oldX, oldY, newX, newY, pActualGameStateData);
		pActualGameStateObject->PlayerID = 0;

		break;
	} while (true);

	return true;
}



void Random_Player1_WithoutMovementTest(CGameStateValues* pActualGameStateObject, CRandomNumbersNN *pRandomNumbers)
{
	int8_t *pActualGameStateData = &pActualGameStateObject->pValueArray[0];

	int32_t oldX;
	int32_t oldY;
	int32_t newX;
	int32_t newY;

	int32_t id1;
	int32_t id2;

	//for (int32_t i = 0; i < 100000; i++)
	do
	{
		oldX = pRandomNumbers->Get_IntegerNumber(0, ConstGameBoardSizePerDir);
		oldY = pRandomNumbers->Get_IntegerNumber(0, ConstGameBoardSizePerDir);

		id1 = oldX + ConstGameBoardSizePerDir * oldY;

		if (pActualGameStateData[id1] != ConstGameBoard_Player1)
			continue;

		newX = oldX + pRandomNumbers->Get_IntegerNumber2(-2, 2);
		newY = oldY + pRandomNumbers->Get_IntegerNumber2(-2, 2);

		newX = max(newX, 0);
		newX = min(newX, ConstGameBoardSizePerDirMinus1);

		newY = max(newY, 0);
		newY = min(newY, ConstGameBoardSizePerDirMinus1);

		if (newX == oldX && newY == oldY)
			continue;

		id2 = newX + ConstGameBoardSizePerDir * newY;

		if (pActualGameStateData[id2] != ConstGameBoard_Empty)
			continue;

		// macht ein m�glicher Sprung-Z�ge Sinn?
		if (abs(newX - oldX) > 1 || abs(newY - oldY) > 1)
		{
			int32_t ixMin = max(0, newX - 1);
			int32_t iyMin = max(0, newY - 1);

			int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, newX + 2);
			int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, newY + 2);

			bool badMoveDecision = false;
			bool isolatedPos = true;

			int32_t iiy;
			int8_t gameStateValue;

			for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
			{
				iiy = ConstGameBoardSizePerDir * iy;

				for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
				{
					gameStateValue = pActualGameStateData[ix + iiy];

					if (gameStateValue == ConstGameBoard_Player1)
					{
						isolatedPos = false;
						badMoveDecision = true;
						break;
					}
					if (gameStateValue != ConstGameBoard_Empty)
					{
						isolatedPos = false;
					}
				}

				if (badMoveDecision == true)
				{
					break;
				}

			}

			if (badMoveDecision == true || isolatedPos == true)
			{
				continue;
			}
		} // end of if (abs(newX - oldX) > 1 || abs(newY - oldY) > 1)

		Make_Player1Move(oldX, oldY, newX, newY, pActualGameStateData);
		pActualGameStateObject->PlayerID = 0;

		return;
	} while (true);	
}


bool Random_Player2(CGameStateValues* pActualGameStateObject, CRandomNumbersNN *pRandomNumbers)
{
	int8_t *pActualGameStateData = &pActualGameStateObject->pValueArray[0];

	if (Check_PossiblePlayer2Moves(pActualGameStateData) == false)
	{
		return false;
	}

	int32_t oldX;
	int32_t oldY;
	int32_t newX;
	int32_t newY;

	int32_t id1;
	int32_t id2;

	//for (int32_t i = 0; i < 100000; i++)
	do
	{
		oldX = pRandomNumbers->Get_IntegerNumber(0, ConstGameBoardSizePerDir);
		oldY = pRandomNumbers->Get_IntegerNumber(0, ConstGameBoardSizePerDir);

		id1 = oldX + ConstGameBoardSizePerDir * oldY;

		if (pActualGameStateData[id1] != ConstGameBoard_Player2)
			continue;

		newX = oldX + pRandomNumbers->Get_IntegerNumber2(-2, 2);
		newY = oldY + pRandomNumbers->Get_IntegerNumber2(-2, 2);

		newX = max(newX, 0);
		newX = min(newX, ConstGameBoardSizePerDirMinus1);

		newY = max(newY, 0);
		newY = min(newY, ConstGameBoardSizePerDirMinus1);

		if (newX == oldX && newY == oldY)
			continue;

		id2 = newX + ConstGameBoardSizePerDir * newY;

		if (pActualGameStateData[id2] != ConstGameBoard_Empty)
			continue;

		// macht ein m�glicher Sprung-Z�ge Sinn?
		if (abs(newX - oldX) > 1 || abs(newY - oldY) > 1)
		{
			int32_t ixMin = max(0, newX - 1);
			int32_t iyMin = max(0, newY - 1);

			int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, newX + 2);
			int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, newY + 2);

			bool badMoveDecision = false;
			bool isolatedPos = true;

			int32_t iiy;
			int8_t gameStateValue;

			for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
			{
				iiy = ConstGameBoardSizePerDir * iy;

				for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
				{
					gameStateValue = pActualGameStateData[ix + iiy];

					if (gameStateValue == ConstGameBoard_Player2)
					{
						isolatedPos = false;
						badMoveDecision = true;
						break;
					}
					if (gameStateValue != ConstGameBoard_Empty)
					{
						isolatedPos = false;
					}
				}

				if (badMoveDecision == true)
				{
					break;
				}

			}

			if (badMoveDecision == true || isolatedPos == true)
			{
				continue;
			}
		} // end of if (abs(newX - oldX) > 1 || abs(newY - oldY) > 1)

		Make_Player2Move(oldX, oldY, newX, newY, pActualGameStateData);
		pActualGameStateObject->PlayerID = 1;

		return true;
	} while (true);

	return false;
}

bool Random_Player2(CGameStateValues* pActualGameStateObject, CRandomNumbersNN *pRandomNumbers, int32_t movementCounter, CSingleRecognitionNeuronEnsemble *pGameStateRecognitionNeuronEnsembleArray)
{
	static CGameStateValues TestGameState(ConstGameBoardSizePerDir, ConstGameBoardSizePerDir);

	int8_t *pActualGameStateData = &pActualGameStateObject->pValueArray[0];

	if (Check_PossiblePlayer2Moves(pActualGameStateData) == false)
	{
		return false;
	}

	int32_t oldX;
	int32_t oldY;
	int32_t newX;
	int32_t newY;

	int32_t id1;
	int32_t id2;

	if (movementCounter < ConstNumGameStateRecognitionNeuronEnsembles)
	{
		for (int32_t i = 0; i < 10000; i++)
		{
			TestGameState.Clone_GameStateValues(pActualGameStateObject);

			oldX = pRandomNumbers->Get_IntegerNumber(0, ConstGameBoardSizePerDir);
			oldY = pRandomNumbers->Get_IntegerNumber(0, ConstGameBoardSizePerDir);

			id1 = oldX + ConstGameBoardSizePerDir * oldY;

			if (pActualGameStateData[id1] != ConstGameBoard_Player2)
				continue;

			newX = oldX + pRandomNumbers->Get_IntegerNumber2(-2, 2);
			newY = oldY + pRandomNumbers->Get_IntegerNumber2(-2, 2);

			newX = max(newX, 0);
			newX = min(newX, ConstGameBoardSizePerDirMinus1);

			newY = max(newY, 0);
			newY = min(newY, ConstGameBoardSizePerDirMinus1);

			if (newX == oldX && newY == oldY)
				continue;

			id2 = newX + ConstGameBoardSizePerDir * newY;

			if (pActualGameStateData[id2] != ConstGameBoard_Empty)
				continue;

			// macht ein m�glicher Sprung-Z�ge Sinn?
			if (abs(newX - oldX) > 1 || abs(newY - oldY) > 1)
			{
				int32_t ixMin = max(0, newX - 1);
				int32_t iyMin = max(0, newY - 1);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, newX + 2);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, newY + 2);

				bool badMoveDecision = false;
				bool isolatedPos = true;

				int32_t iiy;
				int8_t gameStateValue;

				for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
				{
					iiy = ConstGameBoardSizePerDir * iy;

					for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
					{
						gameStateValue = pActualGameStateData[ix + iiy];

						if (gameStateValue == ConstGameBoard_Player2)
						{
							isolatedPos = false;
							badMoveDecision = true;
							break;
						}
						if (gameStateValue != ConstGameBoard_Empty)
						{
							isolatedPos = false;
						}
					}

					if (badMoveDecision == true)
					{
						break;
					}

				}

				if (badMoveDecision == true || isolatedPos == true)
				{
					continue;
				}
			} // end of if (abs(newX - oldX) > 1 || abs(newY - oldY) > 1)

			Make_Player2Move(oldX, oldY, newX, newY, &TestGameState.pValueArray[0]);

			Copy_GameData_Into_MemoryVector(tempMemoryVector, &TestGameState.pValueArray[0]);

			
			//Add_To_Log(0, "movementCounter", movementCounter);
			//Add_To_Log(0, "NumOfUsedMemoryNeurons", pGameStateRecognitionNeuronEnsembleArray[movementCounter].NumOfUsedMemoryNeurons);

			if (pGameStateRecognitionNeuronEnsembleArray[movementCounter].Compare_DataWithMemory(tempMemoryVector) == -1)
			{
				pGameStateRecognitionNeuronEnsembleArray[movementCounter].Set_AdditionalMemoryValues(tempMemoryVector);
				pActualGameStateObject->Clone_GameStateValues(&TestGameState);
				pActualGameStateObject->PlayerID = 1;

				return true;
			}
		}
	}

	//Add_To_Log(0, "Oppps", movementCounter);


	//for (int32_t i = 0; i < 100000; i++)
	do
	{
		oldX = pRandomNumbers->Get_IntegerNumber(0, ConstGameBoardSizePerDir);
		oldY = pRandomNumbers->Get_IntegerNumber(0, ConstGameBoardSizePerDir);

		id1 = oldX + ConstGameBoardSizePerDir * oldY;

		if (pActualGameStateData[id1] != ConstGameBoard_Player2)
			continue;

		newX = oldX + pRandomNumbers->Get_IntegerNumber2(-2, 2);
		newY = oldY + pRandomNumbers->Get_IntegerNumber2(-2, 2);

		newX = max(newX, 0);
		newX = min(newX, ConstGameBoardSizePerDirMinus1);

		newY = max(newY, 0);
		newY = min(newY, ConstGameBoardSizePerDirMinus1);

		if (newX == oldX && newY == oldY)
			continue;

		id2 = newX + ConstGameBoardSizePerDir * newY;

		if (pActualGameStateData[id2] != ConstGameBoard_Empty)
			continue;

		// macht ein m�glicher Sprung-Z�ge Sinn?
		if (abs(newX - oldX) > 1 || abs(newY - oldY) > 1)
		{
			int32_t ixMin = max(0, newX - 1);
			int32_t iyMin = max(0, newY - 1);

			int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, newX + 2);
			int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, newY + 2);

			bool badMoveDecision = false;
			bool isolatedPos = true;

			int32_t iiy;
			int8_t gameStateValue;

			for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
			{
				iiy = ConstGameBoardSizePerDir * iy;

				for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
				{
					gameStateValue = pActualGameStateData[ix + iiy];

					if (gameStateValue == ConstGameBoard_Player2)
					{
						isolatedPos = false;
						badMoveDecision = true;
						break;
					}
					if (gameStateValue != ConstGameBoard_Empty)
					{
						isolatedPos = false;
					}
				}

				if (badMoveDecision == true)
				{
					break;
				}

			}

			if (badMoveDecision == true || isolatedPos == true)
			{
				continue;
			}
		} // end of if (abs(newX - oldX) > 1 || abs(newY - oldY) > 1)

		if (movementCounter < ConstNumGameStateRecognitionNeuronEnsembles)
		{
			Copy_GameData_Into_MemoryVector(tempMemoryVector, pActualGameStateData);
			pGameStateRecognitionNeuronEnsembleArray[movementCounter].Set_AdditionalMemoryValues(tempMemoryVector);
		}

		Make_Player2Move(oldX, oldY, newX, newY, pActualGameStateData);
		pActualGameStateObject->PlayerID = 1;

		return true;
	} while (true);

	return false;
}

bool ExtRandom_Player2(float AIParamScoreWeight, CGameStateValues* pActualGameStateObject, CRandomNumbersNN *pRandomNumbers, int32_t movementCounter, CAtaxxBoardEvaluator *pAtaxxBoardEvaluator, CSingleRecognitionNeuronEnsemble *pGameStateRecognitionNeuronEnsembleArray, CSimpleNeuron *pAdditionalEvaluationNeuronArray)
{
	static CGameStateValues TestGameState(ConstGameBoardSizePerDir, ConstGameBoardSizePerDir);
	static CGameStateValues BestGameState(ConstGameBoardSizePerDir, ConstGameBoardSizePerDir);

	float OneMinusAIParamScoreWeight = 1.0f - AIParamScoreWeight;

	int8_t *pActualGameStateData = &pActualGameStateObject->pValueArray[0];

	if (Check_PossiblePlayer2Moves(pActualGameStateData) == false)
	{
		return false;
	}

	int32_t oldX;
	int32_t oldY;
	int32_t newX;
	int32_t newY;

	int32_t id1;
	int32_t id2;

	if (movementCounter < ConstNumGameStateRecognitionNeuronEnsembles)
	{
		/* Wenn m�glich einen bereits erlernten Spielzug ausf�hren (Ged�chtnis): */


		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateData[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer2CloneMove(i, pActualGameStateData) == true)
				{
					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;


					TestGameState.Clone_GameStateValues(pActualGameStateObject);

					// Testzug ausf�hren:
					Make_Player2CloneMove(ixNew, iyNew, &TestGameState.pValueArray[0]);


					Copy_GameData_Into_MemoryVector(tempMemoryVector, &TestGameState.pValueArray[0]);

					// Ged�chtnis-Spielzug gefunden; Zug ausf�hren:
					if (pGameStateRecognitionNeuronEnsembleArray[movementCounter].Compare_DataWithMemory(tempMemoryVector) > -1)
					{
						pActualGameStateObject->Clone_GameStateValues(&TestGameState);
						pActualGameStateObject->PlayerID = 1;

						int32_t player1Score, player2Score;
						Calculate_Score(&player1Score, &player2Score, &pActualGameStateObject->pValueArray[0]);

						Add_To_Log(0, "movementCounter", movementCounter);
						Add_To_Log(0, "activationValue 1");
						Add_To_Log(0, "player1Score", player1Score);
						Add_To_Log(0, "player2Score", player2Score);
						return true;
					}


				}
			}
			else if (pActualGameStateData[i] == ConstGameBoard_Player2)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateData[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							/* �berpr�fen, ob ein Sprung-Zug �berhaupt sinnvoll ist: */
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateData[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player2)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} /* end of �berpr�fen, ob ein Sprung-Zug �berhaupt sinnvoll ist */


							  /* N�chsten Testzug vorbereiten und ausf�hren: */
							TestGameState.Clone_GameStateValues(pActualGameStateObject);
							Make_Player2Move(ixOld, iyOld, ixNew, iyNew, &TestGameState.pValueArray[0]);


							Copy_GameData_Into_MemoryVector(tempMemoryVector, &TestGameState.pValueArray[0]);

							// Ged�chtnis-Spielzug gefunden; Zug ausf�hren:
							if (pGameStateRecognitionNeuronEnsembleArray[movementCounter].Compare_DataWithMemory(tempMemoryVector) > -1)
							{
								pActualGameStateObject->Clone_GameStateValues(&TestGameState);
								pActualGameStateObject->PlayerID = 1;

								int32_t player1Score, player2Score;
								Calculate_Score(&player1Score, &player2Score, &pActualGameStateObject->pValueArray[0]);

								Add_To_Log(0, "movementCounter", movementCounter);
								Add_To_Log(0, "activationValue 1");
								Add_To_Log(0, "player1Score", player1Score);
								Add_To_Log(0, "player2Score", player2Score);
								return true;
							}
						} // end of if (pActualGameStateData[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
					} // end of for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++) 
				} // end of for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++) 
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		/* Einen m�glichst erfolgversprechenden Spielzug suchen und ausf�hren */

		int32_t player1Score, player2Score;
		float player2EvaluationScore;
		float maxEvaluationScore = -100000.0f;

		

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateData[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer2CloneMove(i, pActualGameStateData) == true)
				{
					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;


					TestGameState.Clone_GameStateValues(pActualGameStateObject);

					// Testzug ausf�hren:
					Make_Player2CloneMove(ixNew, iyNew, &TestGameState.pValueArray[0]);

					Calculate_Score(&player1Score, &player2Score, &TestGameState.pValueArray[0]);
					player2EvaluationScore = pAtaxxBoardEvaluator->Evaluate_Player2(&TestGameState);

				
					float evaluationScore = AIParamScoreWeight * static_cast<float>(player2Score - player1Score) +
						OneMinusAIParamScoreWeight * player2EvaluationScore;
				
					Copy_GameData_Into_BinaryGameStateVector(tempBinaryGameStateVector, &TestGameState.pValueArray[0]);
					pAdditionalEvaluationNeuronArray[movementCounter].Set_Dendrite_NeuronInput(0, 0, tempBinaryGameStateVector, ConstBinaryGameStateVectorSize, 1, ConstBinaryGameStateVectorSize, 1);
					pAdditionalEvaluationNeuronArray[movementCounter].Calculate_NeuronOutput();

					evaluationScore *= pAdditionalEvaluationNeuronArray[movementCounter].ActivationValue;
					//evaluationScore = pAdditionalEvaluationNeuronArray[movementCounter].ActivationValue;
					

					if (evaluationScore > maxEvaluationScore)
					{
						//Add_To_Log(0, "evaluationScore", evaluationScore);
						maxEvaluationScore = evaluationScore;
						BestGameState.Clone_GameStateValues(&TestGameState);

					}
				}
			}
			else if (pActualGameStateData[i] == ConstGameBoard_Player2)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateData[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							/* �berpr�fen, ob ein Sprung-Zug �berhaupt sinnvoll ist: */
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateData[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player2)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} /* end of �berpr�fen, ob ein Sprung-Zug �berhaupt sinnvoll ist */


							  /* N�chsten Testzug vorbereiten und ausf�hren: */
							TestGameState.Clone_GameStateValues(pActualGameStateObject);
							Make_Player2Move(ixOld, iyOld, ixNew, iyNew, &TestGameState.pValueArray[0]);


							Calculate_Score(&player1Score, &player2Score, &TestGameState.pValueArray[0]);
							player2EvaluationScore = pAtaxxBoardEvaluator->Evaluate_Player2(&TestGameState);

							float evaluationScore = AIParamScoreWeight * static_cast<float>(player2Score - player1Score) +
								OneMinusAIParamScoreWeight * player2EvaluationScore;

							Copy_GameData_Into_BinaryGameStateVector(tempBinaryGameStateVector, &TestGameState.pValueArray[0]);
							pAdditionalEvaluationNeuronArray[movementCounter].Set_Dendrite_NeuronInput(0, 0, tempBinaryGameStateVector, ConstBinaryGameStateVectorSize, 1, ConstBinaryGameStateVectorSize, 1);
							pAdditionalEvaluationNeuronArray[movementCounter].Calculate_NeuronOutput();							

							
							evaluationScore *= pAdditionalEvaluationNeuronArray[movementCounter].ActivationValue;
							//evaluationScore = pAdditionalEvaluationNeuronArray[movementCounter].ActivationValue;
							

							if (evaluationScore > maxEvaluationScore)
							{
								//Add_To_Log(0, "evaluationScore", evaluationScore);
								maxEvaluationScore = evaluationScore;
								BestGameState.Clone_GameStateValues(&TestGameState);
							}
						} // end of if (pActualGameStateData[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
					} // end of for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++) 
				} // end of for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++) 
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		pActualGameStateObject->Clone_GameStateValues(&BestGameState);
		pActualGameStateObject->PlayerID = 1;

		


		/*Copy_GameData_Into_BinaryGameStateVector(tempBinaryGameStateVector, &BestGameState.pValueArray[0]);
		pAdditionalEvaluationNeuronArray[movementCounter].Set_Dendrite_NeuronInput(0, 0, tempBinaryGameStateVector, ConstBinaryGameStateVectorSize, 1, ConstBinaryGameStateVectorSize, 1);
		pAdditionalEvaluationNeuronArray[movementCounter].Calculate_NeuronOutput();
		Add_To_Log(0, "maxEvaluationScore", pAdditionalEvaluationNeuronArray[movementCounter].ActivationValue);*/
		

		return true;

	} // end of if (movementCounter < ConstNumGameStateRecognitionNeuronEnsembles)

	// Zufallszug generieren:

	do
	{
		oldX = pRandomNumbers->Get_IntegerNumber(0, ConstGameBoardSizePerDir);
		oldY = pRandomNumbers->Get_IntegerNumber(0, ConstGameBoardSizePerDir);

		id1 = oldX + ConstGameBoardSizePerDir * oldY;

		if (pActualGameStateData[id1] != ConstGameBoard_Player2)
			continue;

		newX = oldX + pRandomNumbers->Get_IntegerNumber2(-2, 2);
		newY = oldY + pRandomNumbers->Get_IntegerNumber2(-2, 2);

		newX = max(newX, 0);
		newX = min(newX, ConstGameBoardSizePerDirMinus1);

		newY = max(newY, 0);
		newY = min(newY, ConstGameBoardSizePerDirMinus1);

		if (newX == oldX && newY == oldY)
			continue;

		id2 = newX + ConstGameBoardSizePerDir * newY;

		if (pActualGameStateData[id2] != ConstGameBoard_Empty)
			continue;

		// macht ein m�glicher Sprung-Z�ge Sinn?
		if (abs(newX - oldX) > 1 || abs(newY - oldY) > 1)
		{
			int32_t ixMin = max(0, newX - 1);
			int32_t iyMin = max(0, newY - 1);

			int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, newX + 2);
			int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, newY + 2);

			bool badMoveDecision = false;
			bool isolatedPos = true;

			int32_t iiy;
			int8_t gameStateValue;

			for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
			{
				iiy = ConstGameBoardSizePerDir * iy;

				for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
				{
					gameStateValue = pActualGameStateData[ix + iiy];

					if (gameStateValue == ConstGameBoard_Player2)
					{
						isolatedPos = false;
						badMoveDecision = true;
						break;
					}
					if (gameStateValue != ConstGameBoard_Empty)
					{
						isolatedPos = false;
					}
				}

				if (badMoveDecision == true)
				{
					break;
				}

			}

			if (badMoveDecision == true || isolatedPos == true)
			{
				continue;
			}
		} // end of if (abs(newX - oldX) > 1 || abs(newY - oldY) > 1)

		Make_Player2Move(oldX, oldY, newX, newY, pActualGameStateData);
		pActualGameStateObject->PlayerID = 1;

		break;
	} while (true);

	return true;
}

bool ExtRandom_Player2(float AIParamScoreWeight, CGameStateValues* pActualGameStateObject, CRandomNumbersNN *pRandomNumbers, int32_t movementCounter, CAtaxxBoardEvaluator *pAtaxxBoardEvaluator, CSingleRecognitionNeuronEnsemble *pGameStateRecognitionNeuronEnsembleArray)
{
	static CGameStateValues TestGameState(ConstGameBoardSizePerDir, ConstGameBoardSizePerDir);
	static CGameStateValues BestGameState(ConstGameBoardSizePerDir, ConstGameBoardSizePerDir);

	float OneMinusAIParamScoreWeight = 1.0f - AIParamScoreWeight;

	int8_t *pActualGameStateData = &pActualGameStateObject->pValueArray[0];

	if (Check_PossiblePlayer2Moves(pActualGameStateData) == false)
	{
		return false;
	}

	int32_t oldX;
	int32_t oldY;
	int32_t newX;
	int32_t newY;

	int32_t id1;
	int32_t id2;

	if (movementCounter < ConstNumGameStateRecognitionNeuronEnsembles)
	{
		/* Wenn m�glich einen bereits erlernten Spielzug ausf�hren (Ged�chtnis): */


		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateData[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer2CloneMove(i, pActualGameStateData) == true)
				{
					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;


					TestGameState.Clone_GameStateValues(pActualGameStateObject);

					// Testzug ausf�hren:
					Make_Player2CloneMove(ixNew, iyNew, &TestGameState.pValueArray[0]);


					Copy_GameData_Into_MemoryVector(tempMemoryVector, &TestGameState.pValueArray[0]);

					// Ged�chtnis-Spielzug gefunden; Zug ausf�hren:
					if (pGameStateRecognitionNeuronEnsembleArray[movementCounter].Compare_DataWithMemory(tempMemoryVector) > -1)
					{
						pActualGameStateObject->Clone_GameStateValues(&TestGameState);
						pActualGameStateObject->PlayerID = 1;

						int32_t player1Score, player2Score;
						Calculate_Score(&player1Score, &player2Score, &pActualGameStateObject->pValueArray[0]);

						Add_To_Log(0, "movementCounter", movementCounter);
						Add_To_Log(0, "activationValue 1");
						Add_To_Log(0, "player1Score", player1Score);
						Add_To_Log(0, "player2Score", player2Score);
						return true;
					}


				}
			}
			else if (pActualGameStateData[i] == ConstGameBoard_Player2)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateData[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							/* �berpr�fen, ob ein Sprung-Zug �berhaupt sinnvoll ist: */
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateData[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player2)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} /* end of �berpr�fen, ob ein Sprung-Zug �berhaupt sinnvoll ist */


							  /* N�chsten Testzug vorbereiten und ausf�hren: */
							TestGameState.Clone_GameStateValues(pActualGameStateObject);
							Make_Player2Move(ixOld, iyOld, ixNew, iyNew, &TestGameState.pValueArray[0]);


							Copy_GameData_Into_MemoryVector(tempMemoryVector, &TestGameState.pValueArray[0]);

							// Ged�chtnis-Spielzug gefunden; Zug ausf�hren:
							if (pGameStateRecognitionNeuronEnsembleArray[movementCounter].Compare_DataWithMemory(tempMemoryVector) > -1)
							{
								pActualGameStateObject->Clone_GameStateValues(&TestGameState);
								pActualGameStateObject->PlayerID = 1;

								int32_t player1Score, player2Score;
								Calculate_Score(&player1Score, &player2Score, &pActualGameStateObject->pValueArray[0]);

								Add_To_Log(0, "movementCounter", movementCounter);
								Add_To_Log(0, "activationValue 1");
								Add_To_Log(0, "player1Score", player1Score);
								Add_To_Log(0, "player2Score", player2Score);
								return true;
							}
						} // end of if (pActualGameStateData[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
					} // end of for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++) 
				} // end of for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++) 
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		  /* Einen m�glichst erfolgversprechenden Spielzug suchen und ausf�hren */

		int32_t player1Score, player2Score, memoryNeuronID;
		float player2EvaluationScore;
		float maxEvaluationScore = -100000.0f;

		float minMemoryVariance = 100000000.0f;

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateData[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer2CloneMove(i, pActualGameStateData) == true)
				{
					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;


					TestGameState.Clone_GameStateValues(pActualGameStateObject);

					// Testzug ausf�hren:
					Make_Player2CloneMove(ixNew, iyNew, &TestGameState.pValueArray[0]);

					Calculate_Score(&player1Score, &player2Score, &TestGameState.pValueArray[0]);
					player2EvaluationScore = pAtaxxBoardEvaluator->Evaluate_Player2(&TestGameState);


					float evaluationScore = AIParamScoreWeight * static_cast<float>(player2Score - player1Score) +
						OneMinusAIParamScoreWeight * player2EvaluationScore;

					Copy_GameData_Into_BinaryGameStateVector(tempBinaryGameStateVector, &TestGameState.pValueArray[0]);
					

					evaluationScore /= Calculate_MinGameStateMemoryVariance(&memoryNeuronID, tempBinaryGameStateVector, &pGameStateRecognitionNeuronEnsembleArray[movementCounter]);
					


					if (evaluationScore > maxEvaluationScore)
					{
						//Add_To_Log(0, "evaluationScore", evaluationScore);
						maxEvaluationScore = evaluationScore;
						BestGameState.Clone_GameStateValues(&TestGameState);

					}

					
				}
			}
			else if (pActualGameStateData[i] == ConstGameBoard_Player2)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateData[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							/* �berpr�fen, ob ein Sprung-Zug �berhaupt sinnvoll ist: */
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateData[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player2)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} /* end of �berpr�fen, ob ein Sprung-Zug �berhaupt sinnvoll ist */


							  /* N�chsten Testzug vorbereiten und ausf�hren: */
							TestGameState.Clone_GameStateValues(pActualGameStateObject);
							Make_Player2Move(ixOld, iyOld, ixNew, iyNew, &TestGameState.pValueArray[0]);


							Calculate_Score(&player1Score, &player2Score, &TestGameState.pValueArray[0]);
							player2EvaluationScore = pAtaxxBoardEvaluator->Evaluate_Player2(&TestGameState);

							float evaluationScore = AIParamScoreWeight * static_cast<float>(player2Score - player1Score) +
								OneMinusAIParamScoreWeight * player2EvaluationScore;

							Copy_GameData_Into_BinaryGameStateVector(tempBinaryGameStateVector, &TestGameState.pValueArray[0]);
							

							evaluationScore /= Calculate_MinGameStateMemoryVariance(&memoryNeuronID, tempBinaryGameStateVector, &pGameStateRecognitionNeuronEnsembleArray[movementCounter]);
							

							if (evaluationScore > maxEvaluationScore)
							{
								//Add_To_Log(0, "evaluationScore", evaluationScore);
								maxEvaluationScore = evaluationScore;
								BestGameState.Clone_GameStateValues(&TestGameState);
							}

							
						} // end of if (pActualGameStateData[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
					} // end of for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++) 
				} // end of for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++) 
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		pActualGameStateObject->Clone_GameStateValues(&BestGameState);
		pActualGameStateObject->PlayerID = 1;




		/*Copy_GameData_Into_BinaryGameStateVector(tempBinaryGameStateVector, &BestGameState.pValueArray[0]);
		pAdditionalEvaluationNeuronArray[movementCounter].Set_Dendrite_NeuronInput(0, 0, tempBinaryGameStateVector, ConstBinaryGameStateVectorSize, 1, ConstBinaryGameStateVectorSize, 1);
		pAdditionalEvaluationNeuronArray[movementCounter].Calculate_NeuronOutput();
		Add_To_Log(0, "maxEvaluationScore", pAdditionalEvaluationNeuronArray[movementCounter].ActivationValue);*/


		return true;

	} // end of if (movementCounter < ConstNumGameStateRecognitionNeuronEnsembles)

	  // Zufallszug generieren:

	do
	{
		oldX = pRandomNumbers->Get_IntegerNumber(0, ConstGameBoardSizePerDir);
		oldY = pRandomNumbers->Get_IntegerNumber(0, ConstGameBoardSizePerDir);

		id1 = oldX + ConstGameBoardSizePerDir * oldY;

		if (pActualGameStateData[id1] != ConstGameBoard_Player2)
			continue;

		newX = oldX + pRandomNumbers->Get_IntegerNumber2(-2, 2);
		newY = oldY + pRandomNumbers->Get_IntegerNumber2(-2, 2);

		newX = max(newX, 0);
		newX = min(newX, ConstGameBoardSizePerDirMinus1);

		newY = max(newY, 0);
		newY = min(newY, ConstGameBoardSizePerDirMinus1);

		if (newX == oldX && newY == oldY)
			continue;

		id2 = newX + ConstGameBoardSizePerDir * newY;

		if (pActualGameStateData[id2] != ConstGameBoard_Empty)
			continue;

		// macht ein m�glicher Sprung-Z�ge Sinn?
		if (abs(newX - oldX) > 1 || abs(newY - oldY) > 1)
		{
			int32_t ixMin = max(0, newX - 1);
			int32_t iyMin = max(0, newY - 1);

			int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, newX + 2);
			int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, newY + 2);

			bool badMoveDecision = false;
			bool isolatedPos = true;

			int32_t iiy;
			int8_t gameStateValue;

			for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
			{
				iiy = ConstGameBoardSizePerDir * iy;

				for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
				{
					gameStateValue = pActualGameStateData[ix + iiy];

					if (gameStateValue == ConstGameBoard_Player2)
					{
						isolatedPos = false;
						badMoveDecision = true;
						break;
					}
					if (gameStateValue != ConstGameBoard_Empty)
					{
						isolatedPos = false;
					}
				}

				if (badMoveDecision == true)
				{
					break;
				}

			}

			if (badMoveDecision == true || isolatedPos == true)
			{
				continue;
			}
		} // end of if (abs(newX - oldX) > 1 || abs(newY - oldY) > 1)

		Make_Player2Move(oldX, oldY, newX, newY, pActualGameStateData);
		pActualGameStateObject->PlayerID = 1;

		break;
	} while (true);

	return true;
}




void Random_Player2_WithoutMovementTest(CGameStateValues* pActualGameStateObject, CRandomNumbersNN *pRandomNumbers)
{
	int8_t *pActualGameStateData = &pActualGameStateObject->pValueArray[0];

	int32_t oldX;
	int32_t oldY;
	int32_t newX;
	int32_t newY;

	int32_t id1;
	int32_t id2;

	//for (int32_t i = 0; i < 100000; i++)
	do
	{
		oldX = pRandomNumbers->Get_IntegerNumber(0, ConstGameBoardSizePerDir);
		oldY = pRandomNumbers->Get_IntegerNumber(0, ConstGameBoardSizePerDir);

		id1 = oldX + ConstGameBoardSizePerDir * oldY;

		if (pActualGameStateData[id1] != ConstGameBoard_Player2)
			continue;

		newX = oldX + pRandomNumbers->Get_IntegerNumber2(-2, 2);
		newY = oldY + pRandomNumbers->Get_IntegerNumber2(-2, 2);

		newX = max(newX, 0);
		newX = min(newX, ConstGameBoardSizePerDirMinus1);

		newY = max(newY, 0);
		newY = min(newY, ConstGameBoardSizePerDirMinus1);

		if (newX == oldX && newY == oldY)
			continue;

		id2 = newX + ConstGameBoardSizePerDir * newY;

		if (pActualGameStateData[id2] != ConstGameBoard_Empty)
			continue;

		// macht ein m�glicher Sprung-Z�ge Sinn?
		if (abs(newX - oldX) > 1 || abs(newY - oldY) > 1)
		{
			int32_t ixMin = max(0, newX - 1);
			int32_t iyMin = max(0, newY - 1);

			int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, newX + 2);
			int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, newY + 2);

			bool badMoveDecision = false;
			bool isolatedPos = true;

			int32_t iiy;
			int8_t gameStateValue;

			for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
			{
				iiy = ConstGameBoardSizePerDir * iy;

				for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
				{
					gameStateValue = pActualGameStateData[ix + iiy];

					if (gameStateValue == ConstGameBoard_Player2)
					{
						isolatedPos = false;
						badMoveDecision = true;
						break;
					}
					if (gameStateValue != ConstGameBoard_Empty)
					{
						isolatedPos = false;
					}
				}

				if (badMoveDecision == true)
				{
					break;
				}

			}

			if (badMoveDecision == true || isolatedPos == true)
			{
				continue;
			}
		} // end of if (abs(newX - oldX) > 1 || abs(newY - oldY) > 1)

		Make_Player2Move(oldX, oldY, newX, newY, pActualGameStateData);
		pActualGameStateObject->PlayerID = 1;

		return;
	} while (true);
}








int32_t Minimax_Player1MoveEvaluation(CGameStateValues* pInActualGameState, CSimpleGameStatePool *pGameStatePool, int32_t searchDepth, int32_t searchDepthMax, bool searchForMaximum, int32_t alpha, int32_t beta)
{
	int8_t *pActualGameStateValueArray = &pInActualGameState->pValueArray[0];

	int32_t Player1Score, Player2Score;

	Calculate_Score(&Player1Score, &Player2Score, pActualGameStateValueArray);

	if (Player1Score > 0 && Player2Score == 0)
	{
		return ConstMaxEvaluationScore_Minimax;
	}
	else if (Player1Score == 0 && Player2Score > 0)
	{
		return ConstMinEvaluationScore_Minimax;
	}

	int32_t evaluationScore = Player1Score - Player2Score;// -searchDepth;

	if (searchDepth == searchDepthMax)
	{
		return evaluationScore;
	}


	if (searchForMaximum == true)
	{
		if (Check_PossiblePlayer1Moves(pActualGameStateValueArray) == false)
		{
			return evaluationScore;
		}

		int32_t maxValue = ConstMinEvaluationScore_Minimax;
		//bool stopEvaluation = false;

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer1CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					CGameStateValues* pGameStateObjectAfterTestMove = nullptr;
					int32_t GameStateObjectID = -1;

					pGameStatePool->Get_UnusedGameStateObject(&pGameStateObjectAfterTestMove, &GameStateObjectID);

					if (pGameStateObjectAfterTestMove == nullptr)
					{
						return maxValue;
					}

					pGameStateObjectAfterTestMove->Clone_GameStateValues(pInActualGameState);

					Make_Player1CloneMove(ixNew, iyNew, &pGameStateObjectAfterTestMove->pValueArray[0]);

					// Evaluate test move:
					maxValue = max(maxValue, Minimax_Player1MoveEvaluation(pGameStateObjectAfterTestMove, pGameStatePool, searchDepth + 1, searchDepthMax, !searchForMaximum, alpha, beta));
					alpha = max(alpha, maxValue);

					pGameStatePool->Stop_Using_GameStateObject(GameStateObjectID);

					if (beta <= alpha)
					{
						//alphaBetaPruningCounter++;
						//Programmschleife verlassen, innerhalb derer s�mtliche Testz�ge durchgef�hrt warden:
						break;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player1)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?

							// next test move:

							CGameStateValues* pGameStateObjectAfterTestMove = nullptr;
							int32_t GameStateObjectID = -1;

							pGameStatePool->Get_UnusedGameStateObject(&pGameStateObjectAfterTestMove, &GameStateObjectID);

							if (pGameStateObjectAfterTestMove == nullptr)
							{
								return maxValue;
							}

							pGameStateObjectAfterTestMove->Clone_GameStateValues(pInActualGameState);

							Make_Player1Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObjectAfterTestMove->pValueArray[0]);

							// Evaluate test move:
							maxValue = max(maxValue, Minimax_Player1MoveEvaluation(pGameStateObjectAfterTestMove, pGameStatePool, searchDepth + 1, searchDepthMax, !searchForMaximum, alpha, beta));
							alpha = max(alpha, maxValue);

							pGameStatePool->Stop_Using_GameStateObject(GameStateObjectID);

							if (beta <= alpha)
							{
								//alphaBetaPruningCounter++;
								//Programmschleife verlassen, innerhalb derer s�mtliche Testz�ge durchgef�hrt warden:
								break;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		return maxValue;

	} // end of if (searchForMaximum == true)
	else if (searchForMaximum == false)
	{
		if (Check_PossiblePlayer2Moves(pActualGameStateValueArray) == false)
		{
			return evaluationScore;
		}

		int32_t minValue = ConstMaxEvaluationScore_Minimax;
		//bool stopEvaluation = false;

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer2CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					CGameStateValues* pGameStateObjectAfterTestMove = nullptr;
					int32_t GameStateObjectID = -1;

					pGameStatePool->Get_UnusedGameStateObject(&pGameStateObjectAfterTestMove, &GameStateObjectID);

					if (pGameStateObjectAfterTestMove == nullptr)
					{
						return minValue;
					}

					pGameStateObjectAfterTestMove->Clone_GameStateValues(pInActualGameState);

					Make_Player2CloneMove(ixNew, iyNew, &pGameStateObjectAfterTestMove->pValueArray[0]);

					// Evaluate test move:
					minValue = min(minValue, Minimax_Player1MoveEvaluation(pGameStateObjectAfterTestMove, pGameStatePool, searchDepth + 1, searchDepthMax, !searchForMaximum, alpha, beta));
					beta = min(beta, minValue);

					pGameStatePool->Stop_Using_GameStateObject(GameStateObjectID);

					if (beta <= alpha)
					{
						//alphaBetaPruningCounter++;
						//Programmschleife verlassen, innerhalb derer s�mtliche Testz�ge durchgef�hrt warden:
						break;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player2)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?

							// next test move:

							CGameStateValues* pGameStateObjectAfterTestMove = nullptr;
							int32_t GameStateObjectID = -1;

							pGameStatePool->Get_UnusedGameStateObject(&pGameStateObjectAfterTestMove, &GameStateObjectID);

							if (pGameStateObjectAfterTestMove == nullptr)
							{
								return minValue;
							}

							pGameStateObjectAfterTestMove->Clone_GameStateValues(pInActualGameState);

							Make_Player2Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObjectAfterTestMove->pValueArray[0]);

							// Evaluate test move:
							minValue = min(minValue, Minimax_Player1MoveEvaluation(pGameStateObjectAfterTestMove, pGameStatePool, searchDepth + 1, searchDepthMax, !searchForMaximum, alpha, beta));
							beta = min(beta, minValue);

							pGameStatePool->Stop_Using_GameStateObject(GameStateObjectID);

							if (beta <= alpha)
							{
								//alphaBetaPruningCounter++;
								//Programmschleife verlassen, innerhalb derer s�mtliche Testz�ge durchgef�hrt warden:
								break;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		return minValue;

	} // end of else if (searchForMaximum == false)

	//return 0;
}










int32_t Minimax_Player2MoveEvaluation(CGameStateValues* pInActualGameState, CSimpleGameStatePool *pGameStatePool, int32_t searchDepth, int32_t searchDepthMax, bool searchForMaximum, int32_t alpha, int32_t beta)
{
	int8_t *pActualGameStateValueArray = &pInActualGameState->pValueArray[0];

	int32_t Player1Score, Player2Score;

	Calculate_Score(&Player1Score, &Player2Score, pActualGameStateValueArray);

	if (Player2Score > 0 && Player1Score == 0)
	{
		return ConstMaxEvaluationScore_Minimax;
	}
	else if (Player2Score == 0 && Player1Score > 0)
	{
		return ConstMinEvaluationScore_Minimax;
	}

	int32_t evaluationScore = Player2Score - Player1Score;// -searchDepth;

	if (searchDepth == searchDepthMax)
	{
		return evaluationScore;
	}


	if (searchForMaximum == true)
	{
		if (Check_PossiblePlayer2Moves(pActualGameStateValueArray) == false)
		{
			return evaluationScore;
		}

		int32_t maxValue = ConstMinEvaluationScore_Minimax;
		//bool stopEvaluation = false;

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer2CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					CGameStateValues* pGameStateObjectAfterTestMove = nullptr;
					int32_t GameStateObjectID = -1;

					pGameStatePool->Get_UnusedGameStateObject(&pGameStateObjectAfterTestMove, &GameStateObjectID);

					if (pGameStateObjectAfterTestMove == nullptr)
					{
						return maxValue;
					}

					pGameStateObjectAfterTestMove->Clone_GameStateValues(pInActualGameState);

					Make_Player2CloneMove(ixNew, iyNew, &pGameStateObjectAfterTestMove->pValueArray[0]);

					// Evaluate test move:
					maxValue = max(maxValue, Minimax_Player2MoveEvaluation(pGameStateObjectAfterTestMove, pGameStatePool, searchDepth + 1, searchDepthMax, !searchForMaximum, alpha, beta));
					alpha = max(alpha, maxValue);

					pGameStatePool->Stop_Using_GameStateObject(GameStateObjectID);

					if (beta <= alpha)
					{
						//alphaBetaPruningCounter++;
						//Programmschleife verlassen, innerhalb derer s�mtliche Testz�ge durchgef�hrt warden:
						break;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player2)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?

							// next test move:

							CGameStateValues* pGameStateObjectAfterTestMove = nullptr;
							int32_t GameStateObjectID = -1;

							pGameStatePool->Get_UnusedGameStateObject(&pGameStateObjectAfterTestMove, &GameStateObjectID);

							if (pGameStateObjectAfterTestMove == nullptr)
							{
								return maxValue;
							}

							pGameStateObjectAfterTestMove->Clone_GameStateValues(pInActualGameState);

							Make_Player2Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObjectAfterTestMove->pValueArray[0]);

							// Evaluate test move:
							maxValue = max(maxValue, Minimax_Player2MoveEvaluation(pGameStateObjectAfterTestMove, pGameStatePool, searchDepth + 1, searchDepthMax, !searchForMaximum, alpha, beta));
							alpha = max(alpha, maxValue);

							pGameStatePool->Stop_Using_GameStateObject(GameStateObjectID);

							if (beta <= alpha)
							{
								//alphaBetaPruningCounter++;
								//Programmschleife verlassen, innerhalb derer s�mtliche Testz�ge durchgef�hrt warden:
								break;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		return maxValue;

	} // end of if (searchForMaximum == true)
	else if (searchForMaximum == false)
	{
		if (Check_PossiblePlayer1Moves(pActualGameStateValueArray) == false)
		{
			return evaluationScore;
		}

		int32_t minValue = ConstMaxEvaluationScore_Minimax;
		//bool stopEvaluation = false;

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer1CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					CGameStateValues* pGameStateObjectAfterTestMove = nullptr;
					int32_t GameStateObjectID = -1;

					pGameStatePool->Get_UnusedGameStateObject(&pGameStateObjectAfterTestMove, &GameStateObjectID);

					if (pGameStateObjectAfterTestMove == nullptr)
					{
						return minValue;
					}

					pGameStateObjectAfterTestMove->Clone_GameStateValues(pInActualGameState);

					Make_Player1CloneMove(ixNew, iyNew, &pGameStateObjectAfterTestMove->pValueArray[0]);

					// Evaluate test move:
					minValue = min(minValue, Minimax_Player2MoveEvaluation(pGameStateObjectAfterTestMove, pGameStatePool, searchDepth + 1, searchDepthMax, !searchForMaximum, alpha, beta));
					beta = min(beta, minValue);

					pGameStatePool->Stop_Using_GameStateObject(GameStateObjectID);

					if (beta <= alpha)
					{
						//alphaBetaPruningCounter++;
						//Programmschleife verlassen, innerhalb derer s�mtliche Testz�ge durchgef�hrt warden:
						break;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player1)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?

							// next test move:

							CGameStateValues* pGameStateObjectAfterTestMove = nullptr;
							int32_t GameStateObjectID = -1;

							pGameStatePool->Get_UnusedGameStateObject(&pGameStateObjectAfterTestMove, &GameStateObjectID);

							if (pGameStateObjectAfterTestMove == nullptr)
							{
								return minValue;
							}

							pGameStateObjectAfterTestMove->Clone_GameStateValues(pInActualGameState);

							Make_Player1Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObjectAfterTestMove->pValueArray[0]);

							// Evaluate test move:
							minValue = min(minValue, Minimax_Player2MoveEvaluation(pGameStateObjectAfterTestMove, pGameStatePool, searchDepth + 1, searchDepthMax, !searchForMaximum, alpha, beta));
							beta = min(beta, minValue);

							pGameStatePool->Stop_Using_GameStateObject(GameStateObjectID);

							if (beta <= alpha)
							{
								//alphaBetaPruningCounter++;
								//Programmschleife verlassen, innerhalb derer s�mtliche Testz�ge durchgef�hrt warden:
								break;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		return minValue;

	} // end of else if (searchForMaximum == false)

	 //return 0;
}




void Minimax_Player1(CGameStateValues *pOutNewGameState, CGameStateValues *pInActualGameState, CSimpleGameStatePool *pGameStatePool, int32_t maxSearchDepth)
{
	pGameStatePool->Stop_Using_AllGameStateObjects();

	pOutNewGameState->Clone_GameStateValues(pInActualGameState);

	int8_t *pActualGameStateValueArray = &pInActualGameState->pValueArray[0];

	int32_t bestEvaluation = ConstMinEvaluationScore_Minimax;


	//alphaBetaPruningCounter = 0;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
		{
			if (Check_PossiblePlayer1CloneMove(i, pActualGameStateValueArray) == true)
			{
				// next test move:

				int32_t ixNew = i % ConstGameBoardSizePerDir;
				int32_t iyNew = i / ConstGameBoardSizePerDir;

				CGameStateValues* pGameStateObjectAfterTestMove = nullptr;
				int32_t GameStateObjectID = -1;

				pGameStatePool->Get_UnusedGameStateObject(&pGameStateObjectAfterTestMove, &GameStateObjectID);

				pGameStateObjectAfterTestMove->Clone_GameStateValues(pInActualGameState);

				// test move:
				Make_Player1CloneMove(ixNew, iyNew, &pGameStateObjectAfterTestMove->pValueArray[0]);

				// evaluate test move:
				//int32_t Player1Score, Player2Score;
				//Calculate_Score(&Player1Score, &Player2Score, &pGameStateObjectAfterTestMove->pValueArray[0]);
				//int32_t actualEvaluation = Player1Score - Player2Score;

				// evaluate test move:
				int32_t actualEvaluation = Minimax_Player1MoveEvaluation(pGameStateObjectAfterTestMove, pGameStatePool, 0, maxSearchDepth, false, ConstMinEvaluationScore_Minimax, ConstMaxEvaluationScore_Minimax);


				if (actualEvaluation > bestEvaluation)
				{
					pOutNewGameState->Clone_GameStateValues(pGameStateObjectAfterTestMove);
					bestEvaluation = actualEvaluation;
				}

				pGameStatePool->Stop_Using_GameStateObject(GameStateObjectID);
			}
		}
		else if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		{
			int32_t ixOld = i % ConstGameBoardSizePerDir;
			int32_t iyOld = i / ConstGameBoardSizePerDir;

			int32_t ixMin = max(0, ixOld - 2);
			int32_t iyMin = max(0, iyOld - 2);

			int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
			int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

			for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
			{
				for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
				{
					// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
					if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
					{
						continue;
					}

					if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
					{
						// macht ein Sprung-Z�ge Sinn?
						{
							int32_t ixMin = max(0, ixNew - 1);
							int32_t iyMin = max(0, iyNew - 1);

							int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
							int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

							bool badMoveDecision = false;
							bool isolatedPos = true;

							int32_t iiy;
							int8_t gameStateValue;

							for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
							{
								iiy = ConstGameBoardSizePerDir * iy;

								for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
								{
									gameStateValue = pActualGameStateValueArray[ix + iiy];

									if (gameStateValue == ConstGameBoard_Player1)
									{
										isolatedPos = false;
										badMoveDecision = true;
										break;
									}
									if (gameStateValue != ConstGameBoard_Empty)
									{
										isolatedPos = false;
									}
								}

								if (badMoveDecision == true)
								{
									break;
								}

							}

							if (badMoveDecision == true || isolatedPos == true)
							{
								continue;
							}
						} // end of macht ein Sprung-Z�ge Sinn?
						// next test move:

						CGameStateValues* pGameStateObjectAfterTestMove = nullptr;
						int32_t GameStateObjectID = -1;

						pGameStatePool->Get_UnusedGameStateObject(&pGameStateObjectAfterTestMove, &GameStateObjectID);

						pGameStateObjectAfterTestMove->Clone_GameStateValues(pInActualGameState);

						// test move:
						Make_Player1Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObjectAfterTestMove->pValueArray[0]);

						// evaluate test move:
						//int32_t Player1Score, Player2Score;
						//Calculate_Score(&Player1Score, &Player2Score, &pGameStateObjectAfterTestMove->pValueArray[0]);
						//int32_t actualEvaluation = Player1Score - Player2Score;

						// evaluate test move:
						int32_t actualEvaluation = Minimax_Player1MoveEvaluation(pGameStateObjectAfterTestMove, pGameStatePool, 0, maxSearchDepth, false, ConstMinEvaluationScore_Minimax, ConstMaxEvaluationScore_Minimax);


						if (actualEvaluation > bestEvaluation)
						{
							pOutNewGameState->Clone_GameStateValues(pGameStateObjectAfterTestMove);
							bestEvaluation = actualEvaluation;
						}
					
						pGameStatePool->Stop_Using_GameStateObject(GameStateObjectID);			
					}
				}
			}
		} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
	} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	//Add_To_Log(0, "alphaBetaPruningCounter", alphaBetaPruningCounter);
}




void ExtMinimax_Player1(CGameStateValues *pOutNewGameState, CGameStateValues *pInActualGameState, CSimpleGameStatePool *pGameStatePool, int32_t maxSearchDepth)
{
	static constexpr int32_t ConstNumOfConsideredBestMoves = 4;

	static  C2DimMoveDesc BestMoveDescArray[ConstNumOfConsideredBestMoves];

	for (int32_t i = 0; i < ConstNumOfConsideredBestMoves; i++)
		BestMoveDescArray[i].Reset();

	C2DimMoveDesc MoveDesc;

	pGameStatePool->Stop_Using_AllGameStateObjects();

	pOutNewGameState->Clone_GameStateValues(pInActualGameState);

	int8_t *pActualGameStateValueArray = &pInActualGameState->pValueArray[0];

	int32_t bestEvaluation = ConstMinEvaluationScore_Minimax;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
		{
			int32_t ixOld;
			int32_t iyOld;

			if (Get_PossiblePlayer1CloneMoveStartPos(&ixOld, &iyOld, i, pActualGameStateValueArray) == true)
			{
				// next test move:

				int32_t ixNew = i % ConstGameBoardSizePerDir;
				int32_t iyNew = i / ConstGameBoardSizePerDir;

				CGameStateValues* pGameStateObjectAfterTestMove = nullptr;
				int32_t GameStateObjectID = -1;

				pGameStatePool->Get_UnusedGameStateObject(&pGameStateObjectAfterTestMove, &GameStateObjectID);

				pGameStateObjectAfterTestMove->Clone_GameStateValues(pInActualGameState);

				// test move:
				Make_Player1CloneMove(ixNew, iyNew, &pGameStateObjectAfterTestMove->pValueArray[0]);

				// evaluate test move:
				//int32_t Player1Score, Player2Score;
				//Calculate_Score(&Player1Score, &Player2Score, &pGameStateObjectAfterTestMove->pValueArray[0]);
				//int32_t actualEvaluation = Player1Score - Player2Score;

				// evaluate test move:
				int32_t actualEvaluation = Minimax_Player1MoveEvaluation(pGameStateObjectAfterTestMove, pGameStatePool, 0, maxSearchDepth, false, ConstMinEvaluationScore_Minimax, ConstMaxEvaluationScore_Minimax);

				MoveDesc.iEvaluation = actualEvaluation;
				MoveDesc.ix_Old = ixOld;
				MoveDesc.iy_Old = iyOld;
				MoveDesc.ix_New = ixNew;
				MoveDesc.iy_New = iyNew;

				Update_ListOfBestMoves_IntegerEvaluation(BestMoveDescArray, ConstNumOfConsideredBestMoves, &MoveDesc);

				if (actualEvaluation > bestEvaluation)
				{
					pOutNewGameState->Clone_GameStateValues(pGameStateObjectAfterTestMove);
					bestEvaluation = actualEvaluation;
				}

				pGameStatePool->Stop_Using_GameStateObject(GameStateObjectID);
			}
		}
		else if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		{
			int32_t ixOld = i % ConstGameBoardSizePerDir;
			int32_t iyOld = i / ConstGameBoardSizePerDir;

			int32_t ixMin = max(0, ixOld - 2);
			int32_t iyMin = max(0, iyOld - 2);

			int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
			int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

			for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
			{
				for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
				{
					// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
					if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
					{
						continue;
					}

					if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
					{
						// macht ein Sprung-Z�ge Sinn?
						{
							int32_t ixMin = max(0, ixNew - 1);
							int32_t iyMin = max(0, iyNew - 1);

							int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
							int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

							bool badMoveDecision = false;
							bool isolatedPos = true;

							int32_t iiy;
							int8_t gameStateValue;

							for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
							{
								iiy = ConstGameBoardSizePerDir * iy;

								for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
								{
									gameStateValue = pActualGameStateValueArray[ix + iiy];

									if (gameStateValue == ConstGameBoard_Player1)
									{
										isolatedPos = false;
										badMoveDecision = true;
										break;
									}
									if (gameStateValue != ConstGameBoard_Empty)
									{
										isolatedPos = false;
									}
								}

								if (badMoveDecision == true)
								{
									break;
								}

							}

							if (badMoveDecision == true || isolatedPos == true)
							{
								continue;
							}
						} // end of macht ein Sprung-Z�ge Sinn?
						// next test move:

						CGameStateValues* pGameStateObjectAfterTestMove = nullptr;
						int32_t GameStateObjectID = -1;

						pGameStatePool->Get_UnusedGameStateObject(&pGameStateObjectAfterTestMove, &GameStateObjectID);

						pGameStateObjectAfterTestMove->Clone_GameStateValues(pInActualGameState);

						// test move:
						Make_Player1Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObjectAfterTestMove->pValueArray[0]);

						// evaluate test move:
						//int32_t Player1Score, Player2Score;
						//Calculate_Score(&Player1Score, &Player2Score, &pGameStateObjectAfterTestMove->pValueArray[0]);
						//int32_t actualEvaluation = Player1Score - Player2Score;

						// evaluate test move:
						int32_t actualEvaluation = Minimax_Player1MoveEvaluation(pGameStateObjectAfterTestMove, pGameStatePool, 0, maxSearchDepth, false, ConstMinEvaluationScore_Minimax, ConstMaxEvaluationScore_Minimax);

						MoveDesc.iEvaluation = actualEvaluation;
						MoveDesc.ix_Old = ixOld;
						MoveDesc.iy_Old = iyOld;
						MoveDesc.ix_New = ixNew;
						MoveDesc.iy_New = iyNew;

						Update_ListOfBestMoves_IntegerEvaluation(BestMoveDescArray, ConstNumOfConsideredBestMoves, &MoveDesc);

						if (actualEvaluation > bestEvaluation)
						{
							pOutNewGameState->Clone_GameStateValues(pGameStateObjectAfterTestMove);
							bestEvaluation = actualEvaluation;
						}

						pGameStatePool->Stop_Using_GameStateObject(GameStateObjectID);
					}
				}
			}
		} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
	} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	//return;

	bestEvaluation = ConstMinEvaluationScore_Minimax;

	for (int32_t i = 0; i < ConstNumOfConsideredBestMoves; i++)
	{
		if (BestMoveDescArray[i].ix_Old < 0)
		{
			continue;
		}

		// next test move:

		CGameStateValues* pGameStateObjectAfterTestMove = nullptr;
		int32_t GameStateObjectID = -1;

		pGameStatePool->Get_UnusedGameStateObject(&pGameStateObjectAfterTestMove, &GameStateObjectID);

		pGameStateObjectAfterTestMove->Clone_GameStateValues(pInActualGameState);

		// test move:
		Make_Player1Move(BestMoveDescArray[i].ix_Old, BestMoveDescArray[i].iy_Old, BestMoveDescArray[i].ix_New, BestMoveDescArray[i].iy_New, &pGameStateObjectAfterTestMove->pValueArray[0]);

		// evaluate test move:
		int32_t actualEvaluation = Minimax_Player1MoveEvaluation(pGameStateObjectAfterTestMove, pGameStatePool, 0, maxSearchDepth + 2, false, ConstMinEvaluationScore_Minimax, ConstMaxEvaluationScore_Minimax);

		if (actualEvaluation > bestEvaluation)
		{
			pOutNewGameState->Clone_GameStateValues(pGameStateObjectAfterTestMove);
			bestEvaluation = actualEvaluation;
		}

		pGameStatePool->Stop_Using_GameStateObject(GameStateObjectID);
	} // end of for (int32_t i = 0; i < ConstNumOfConsideredBestMoves; i++)
}




void Minimax_Player2(CGameStateValues *pOutNewGameState, CGameStateValues *pInActualGameState, CSimpleGameStatePool *pGameStatePool, int32_t maxSearchDepth)
{
	pGameStatePool->Stop_Using_AllGameStateObjects();

	pOutNewGameState->Clone_GameStateValues(pInActualGameState);

	int8_t *pActualGameStateValueArray = &pInActualGameState->pValueArray[0];

	int32_t bestEvaluation = ConstMinEvaluationScore_Minimax;

	//alphaBetaPruningCounter = 0;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
		{
			if (Check_PossiblePlayer2CloneMove(i, pActualGameStateValueArray) == true)
			{
				// next test move:

				int32_t ixNew = i % ConstGameBoardSizePerDir;
				int32_t iyNew = i / ConstGameBoardSizePerDir;

				CGameStateValues* pGameStateObjectAfterTestMove = nullptr;
				int32_t GameStateObjectID = -1;

				pGameStatePool->Get_UnusedGameStateObject(&pGameStateObjectAfterTestMove, &GameStateObjectID);

				pGameStateObjectAfterTestMove->Clone_GameStateValues(pInActualGameState);

				// test move:
				Make_Player2CloneMove(ixNew, iyNew, &pGameStateObjectAfterTestMove->pValueArray[0]);



				// evaluate test move:
				int32_t actualEvaluation = Minimax_Player2MoveEvaluation(pGameStateObjectAfterTestMove, pGameStatePool, 0, maxSearchDepth, false, ConstMinEvaluationScore_Minimax, ConstMaxEvaluationScore_Minimax);


				if (actualEvaluation > bestEvaluation)
				{
					pOutNewGameState->Clone_GameStateValues(pGameStateObjectAfterTestMove);
					bestEvaluation = actualEvaluation;
				}

				pGameStatePool->Stop_Using_GameStateObject(GameStateObjectID);
			}
		}
		else if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
		{
			int32_t ixOld = i % ConstGameBoardSizePerDir;
			int32_t iyOld = i / ConstGameBoardSizePerDir;

			int32_t ixMin = max(0, ixOld - 2);
			int32_t iyMin = max(0, iyOld - 2);

			int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
			int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

			for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
			{
				for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
				{
					// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
					if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
					{
						continue;
					}

					if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
					{
						// macht ein Sprung-Z�ge Sinn?
						{
							int32_t ixMin = max(0, ixNew - 1);
							int32_t iyMin = max(0, iyNew - 1);

							int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
							int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

							bool badMoveDecision = false;
							bool isolatedPos = true;

							int32_t iiy;
							int8_t gameStateValue;

							for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
							{
								iiy = ConstGameBoardSizePerDir * iy;

								for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
								{
									gameStateValue = pActualGameStateValueArray[ix + iiy];

									if (gameStateValue == ConstGameBoard_Player2)
									{
										isolatedPos = false;
										badMoveDecision = true;
										break;
									}
									if (gameStateValue != ConstGameBoard_Empty)
									{
										isolatedPos = false;
									}
								}

								if (badMoveDecision == true)
								{
									break;
								}

							}

							if (badMoveDecision == true || isolatedPos == true)
							{
								continue;
							}
						} // end of macht ein Sprung-Z�ge Sinn?
						// next test move:

						CGameStateValues* pGameStateObjectAfterTestMove = nullptr;
						int32_t GameStateObjectID = -1;

						pGameStatePool->Get_UnusedGameStateObject(&pGameStateObjectAfterTestMove, &GameStateObjectID);

						pGameStateObjectAfterTestMove->Clone_GameStateValues(pInActualGameState);

						// test move:
						Make_Player2Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObjectAfterTestMove->pValueArray[0]);

						

						// evaluate test move:
						int32_t actualEvaluation = Minimax_Player2MoveEvaluation(pGameStateObjectAfterTestMove, pGameStatePool, 0, maxSearchDepth, false, ConstMinEvaluationScore_Minimax, ConstMaxEvaluationScore_Minimax);
					

						if (actualEvaluation > bestEvaluation)
						{
							pOutNewGameState->Clone_GameStateValues(pGameStateObjectAfterTestMove);
							bestEvaluation = actualEvaluation;
						}

						pGameStatePool->Stop_Using_GameStateObject(GameStateObjectID);
					}
				}
			}
		} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
	} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	//Add_To_Log(0, "alphaBetaPruningCounter", alphaBetaPruningCounter);
}




void ExtMinimax_Player2(CGameStateValues *pOutNewGameState, CGameStateValues *pInActualGameState, CSimpleGameStatePool *pGameStatePool, int32_t maxSearchDepth)
{
	static constexpr int32_t ConstNumOfConsideredBestMoves = 4;

	static C2DimMoveDesc BestMoveDescArray[ConstNumOfConsideredBestMoves];

	for (int32_t i = 0; i < ConstNumOfConsideredBestMoves; i++)
		BestMoveDescArray[i].Reset();

	C2DimMoveDesc MoveDesc;

	pGameStatePool->Stop_Using_AllGameStateObjects();

	pOutNewGameState->Clone_GameStateValues(pInActualGameState);

	int8_t *pActualGameStateValueArray = &pInActualGameState->pValueArray[0];

	int32_t bestEvaluation = ConstMinEvaluationScore_Minimax;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
		{
			int32_t ixOld;
			int32_t iyOld;

			if (Get_PossiblePlayer2CloneMoveStartPos(&ixOld, &iyOld, i, pActualGameStateValueArray) == true)
			{
				// next test move:

				int32_t ixNew = i % ConstGameBoardSizePerDir;
				int32_t iyNew = i / ConstGameBoardSizePerDir;

				CGameStateValues* pGameStateObjectAfterTestMove = nullptr;
				int32_t GameStateObjectID = -1;

				pGameStatePool->Get_UnusedGameStateObject(&pGameStateObjectAfterTestMove, &GameStateObjectID);

				pGameStateObjectAfterTestMove->Clone_GameStateValues(pInActualGameState);

				// test move:
				Make_Player2CloneMove(ixNew, iyNew, &pGameStateObjectAfterTestMove->pValueArray[0]);



				// evaluate test move:
				int32_t actualEvaluation = Minimax_Player2MoveEvaluation(pGameStateObjectAfterTestMove, pGameStatePool, 0, maxSearchDepth, false, ConstMinEvaluationScore_Minimax, ConstMaxEvaluationScore_Minimax);

				MoveDesc.iEvaluation = actualEvaluation;
				MoveDesc.ix_Old = ixOld;
				MoveDesc.iy_Old = iyOld;
				MoveDesc.ix_New = ixNew;
				MoveDesc.iy_New = iyNew;

				Update_ListOfBestMoves_IntegerEvaluation(BestMoveDescArray, ConstNumOfConsideredBestMoves, &MoveDesc);

				if (actualEvaluation > bestEvaluation)
				{
					pOutNewGameState->Clone_GameStateValues(pGameStateObjectAfterTestMove);
					bestEvaluation = actualEvaluation;
				}

				pGameStatePool->Stop_Using_GameStateObject(GameStateObjectID);
			}
		}
		else if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
		{
			int32_t ixOld = i % ConstGameBoardSizePerDir;
			int32_t iyOld = i / ConstGameBoardSizePerDir;

			int32_t ixMin = max(0, ixOld - 2);
			int32_t iyMin = max(0, iyOld - 2);

			int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
			int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

			for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
			{
				for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
				{
					// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
					if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
					{
						continue;
					}

					if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
					{
						// macht ein Sprung-Z�ge Sinn?
						{
							int32_t ixMin = max(0, ixNew - 1);
							int32_t iyMin = max(0, iyNew - 1);

							int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
							int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

							bool badMoveDecision = false;
							bool isolatedPos = true;

							int32_t iiy;
							int8_t gameStateValue;

							for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
							{
								iiy = ConstGameBoardSizePerDir * iy;

								for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
								{
									gameStateValue = pActualGameStateValueArray[ix + iiy];

									if (gameStateValue == ConstGameBoard_Player2)
									{
										isolatedPos = false;
										badMoveDecision = true;
										break;
									}
									if (gameStateValue != ConstGameBoard_Empty)
									{
										isolatedPos = false;
									}
								}

								if (badMoveDecision == true)
								{
									break;
								}

							}

							if (badMoveDecision == true || isolatedPos == true)
							{
								continue;
							}
						} // end of macht ein Sprung-Z�ge Sinn?
						// next test move:

						CGameStateValues* pGameStateObjectAfterTestMove = nullptr;
						int32_t GameStateObjectID = -1;

						pGameStatePool->Get_UnusedGameStateObject(&pGameStateObjectAfterTestMove, &GameStateObjectID);

						pGameStateObjectAfterTestMove->Clone_GameStateValues(pInActualGameState);

						// test move:
						Make_Player2Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObjectAfterTestMove->pValueArray[0]);

						

						// evaluate test move:
						int32_t actualEvaluation = Minimax_Player2MoveEvaluation(pGameStateObjectAfterTestMove, pGameStatePool, 0, maxSearchDepth, false, ConstMinEvaluationScore_Minimax, ConstMaxEvaluationScore_Minimax);

						MoveDesc.iEvaluation = actualEvaluation;
						MoveDesc.ix_Old = ixOld;
						MoveDesc.iy_Old = iyOld;
						MoveDesc.ix_New = ixNew;
						MoveDesc.iy_New = iyNew;

						Update_ListOfBestMoves_IntegerEvaluation(BestMoveDescArray, ConstNumOfConsideredBestMoves, &MoveDesc);

						if (actualEvaluation > bestEvaluation)
						{
							pOutNewGameState->Clone_GameStateValues(pGameStateObjectAfterTestMove);
							bestEvaluation = actualEvaluation;
						}

						pGameStatePool->Stop_Using_GameStateObject(GameStateObjectID);
					}
				}
			}
		} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
	} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	//return;

	bestEvaluation = ConstMinEvaluationScore_Minimax;

	for (int32_t i = 0; i < ConstNumOfConsideredBestMoves; i++)
	{
		if (BestMoveDescArray[i].ix_Old < 0)
		{
			continue;
		}

		// next test move:

		CGameStateValues* pGameStateObjectAfterTestMove = nullptr;
		int32_t GameStateObjectID = -1;

		pGameStatePool->Get_UnusedGameStateObject(&pGameStateObjectAfterTestMove, &GameStateObjectID);

		pGameStateObjectAfterTestMove->Clone_GameStateValues(pInActualGameState);

		// test move:
		Make_Player2Move(BestMoveDescArray[i].ix_Old, BestMoveDescArray[i].iy_Old, BestMoveDescArray[i].ix_New, BestMoveDescArray[i].iy_New, &pGameStateObjectAfterTestMove->pValueArray[0]);

		// evaluate test move:
		int32_t actualEvaluation = Minimax_Player2MoveEvaluation(pGameStateObjectAfterTestMove, pGameStatePool, 0, maxSearchDepth + 2, false, ConstMinEvaluationScore_Minimax, ConstMaxEvaluationScore_Minimax);

		if (actualEvaluation > bestEvaluation)
		{
			pOutNewGameState->Clone_GameStateValues(pGameStateObjectAfterTestMove);
			bestEvaluation = actualEvaluation;
		}

		pGameStatePool->Stop_Using_GameStateObject(GameStateObjectID);
	} // end of for (int32_t i = 0; i < ConstNumOfConsideredBestMoves; i++)
}




/*
void Test_Player1(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool *pGameStatePool, CRandomNumbersNN *pRandomNumbers, int32_t numTestGameStatesMaxPerDepthLayer, int32_t numOfRandomGameMoveChainsMax, int32_t maxSearchDepth_Minimax)
{
	pGameStatePool->Stop_Using_AllGameStateObjects();

	pOutNewGameState->Clone_GameStateValues(pInActualGameState);

	int8_t *pActualGameStateValueArray = &pInActualGameState->pValueArray[0];

	int32_t moveCounter = 0;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
		{
			if (Check_PossiblePlayer1CloneMove(i, pActualGameStateValueArray) == true)
			{
				int32_t ixNew = i % ConstGameBoardSizePerDir;
				int32_t iyNew = i / ConstGameBoardSizePerDir;

				CGameStateValues* pGameStateObject = nullptr;
				int32_t GameStateObjectID = -1;

				if (pGameStatePool->Get_UnusedGameStateObject(0, &pGameStateObject, &GameStateObjectID) == false)
				{
					goto TestMoveGenerationCompleted;
				}

				pGameStateObject->Clone_GameStateValues(pInActualGameState);

				// test move:
				Make_Player1CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
				pGameStateObject->PlayerID = 0;
				pGameStateObject->Use_As_Minimizer();
				moveCounter++;

				if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
				{
					goto Depth0_TestMoveGenerationCompleted;
				}
			}
		}
		else if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		{
			int32_t ixOld = i % ConstGameBoardSizePerDir;
			int32_t iyOld = i / ConstGameBoardSizePerDir;

			int32_t ixMin = max(0, ixOld - 2);
			int32_t iyMin = max(0, iyOld - 2);

			int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
			int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

			for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
			{
				for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
				{
					// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
					if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
					{
						continue;
					}

					if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
					{
						// next test move:

						CGameStateValues* pGameStateObject = nullptr;
						int32_t GameStateObjectID = -1;

						if (pGameStatePool->Get_UnusedGameStateObject(0, &pGameStateObject, &GameStateObjectID) == false)
						{
							goto TestMoveGenerationCompleted;
						}

						pGameStateObject->Clone_GameStateValues(pInActualGameState);

						// test move:
						Make_Player1Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);	
						pGameStateObject->PlayerID = 0;
						pGameStateObject->Use_As_Minimizer();
						moveCounter++;

						if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
						{
							goto Depth0_TestMoveGenerationCompleted;
						}
					}
				}
			}
		} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
	} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

Depth0_TestMoveGenerationCompleted:;

	if (maxSearchDepth_Minimax < 1)
	{
		goto TestMoveGenerationCompleted;
	}

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	
	for (int32_t i = 0; i < numOfRandomGameMoveChainsMax; i++)
	{
		bool movePossible = false;
		int32_t nextPlayer = -1;

		for (int32_t j = 0; j < 100; j++)
		{
			GameStateObjectID = pGameStatePool->Get_Random_GameStateID_LastDepthLayerExcluded(0, 0, 1000, pRandomNumbers);

			if (GameStateObjectID < 0)
			{
				continue;
			}

			pGameStateObject = &pGameStatePool->pGameStateArray[GameStateObjectID];
			nextPlayer = (pGameStateObject->PlayerID + 1) % 2;

			if (pGameStateObject->PlayerID != 0)
			{
				Add_To_Log(0, "pGameStateObject->PlayerID must be 0");
			}
			if (pGameStateObject->DepthValue != 0)
			{
				Add_To_Log(0, "pGameStateObject->DepthValue must be 0");
			}

			if (pCheck_PossiblePlayer1Or2MovesFuncArray[nextPlayer](&pGameStateObject->pValueArray[0]) == false)
			{
				continue;
			}
			else
			{
				movePossible = true;
				break;
			}
		}

		if (movePossible == true)
		{
			Generate_Random_GameMoveChain_Player1(maxSearchDepth_Minimax, pGameStateObject, pGameStatePool, pRandomNumbers);
		}
	} // end of for (int32_t i = 0; i < numOfRandomGameMoveChainsMax; i++)

	if (maxSearchDepth_Minimax > 1)
	{
		for (int32_t i = 0; i < numOfRandomGameMoveChainsMax; i++)
		{
			bool movePossible = false;
			int32_t nextPlayer = -1;

			for (int32_t j = 0; j < 100; j++)
			{
				GameStateObjectID = pGameStatePool->Get_Random_GameStateID_LastDepthLayerExcluded(1, 1, 1000, pRandomNumbers);

				if (GameStateObjectID < 0)
				{
					continue;
				}

				pGameStateObject = &pGameStatePool->pGameStateArray[GameStateObjectID];
				nextPlayer = (pGameStateObject->PlayerID + 1) % 2;

				if (pGameStateObject->PlayerID != 0)
				{
					Add_To_Log(0, "pGameStateObject->PlayerID must be 0");
				}
				if (pGameStateObject->DepthValue != 0)
				{
					Add_To_Log(0, "pGameStateObject->DepthValue must be 0");
				}

				if (pCheck_PossiblePlayer1Or2MovesFuncArray[nextPlayer](&pGameStateObject->pValueArray[0]) == false)
				{
					continue;
				}
				else
				{
					movePossible = true;
					break;
				}
			}

			if (movePossible == true)
			{
				Generate_Random_GameMoveChain_Player1(maxSearchDepth_Minimax, pGameStateObject, pGameStatePool, pRandomNumbers);
			}
		} // end of for (int32_t i = 0; i < numOfRandomGameMoveChainsMax; i++)
	}
	

TestMoveGenerationCompleted:;

	Calculate_LeafGameStates_Player1Evaluations(pGameStatePool);
	//Calculate_GameStates_Player1Evaluations(pGameStatePool);
	Backpropagate_IntegerEvaluationValues(pGameStatePool);

	
	pGameStatePool->Get_Best_GameState_IntergerEvaluation(&pGameStateObject, &GameStateObjectID);
	pOutNewGameState->Clone_GameStateValues(pGameStateObject);
}
*/

void Test_Player1(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool *pGameStatePool, int32_t numTestGameStatesMaxPerDepthLayer, int32_t maxSearchDepth)
{
	pGameStatePool->Stop_Using_AllGameStateObjects();

	pOutNewGameState->Clone_GameStateValues(pInActualGameState);

	int8_t *pActualGameStateValueArray = &pInActualGameState->pValueArray[0];

	int32_t moveCounter = 0;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
		{
			if (Check_PossiblePlayer1CloneMove(i, pActualGameStateValueArray) == true)
			{
				int32_t ixNew = i % ConstGameBoardSizePerDir;
				int32_t iyNew = i / ConstGameBoardSizePerDir;

				CGameStateValues* pGameStateObject = nullptr;
				int32_t GameStateObjectID = -1;

				if (pGameStatePool->Get_UnusedGameStateObject(0, &pGameStateObject, &GameStateObjectID) == false)
				{
					goto TestMoveGenerationCompleted;
				}

				pGameStateObject->Clone_GameStateValues(pInActualGameState);

				// test move:
				Make_Player1CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
				pGameStateObject->PlayerID = 0;
				pGameStateObject->Use_As_Minimizer();
				moveCounter++;

				if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
				{
					goto Depth0_TestMoveGenerationCompleted;
				}
			}
		}
		else if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		{
			int32_t ixOld = i % ConstGameBoardSizePerDir;
			int32_t iyOld = i / ConstGameBoardSizePerDir;

			int32_t ixMin = max(0, ixOld - 2);
			int32_t iyMin = max(0, iyOld - 2);

			int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
			int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

			for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
			{
				for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
				{
					// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
					if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
					{
						continue;
					}

					if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
					{
						// macht ein Sprung-Z�ge Sinn?
						{
							int32_t ixMin = max(0, ixNew - 1);
							int32_t iyMin = max(0, iyNew - 1);

							int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
							int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

							bool badMoveDecision = false;
							bool isolatedPos = true;

							int32_t iiy;
							int8_t gameStateValue;

							for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
							{
								iiy = ConstGameBoardSizePerDir * iy;

								for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
								{
									gameStateValue = pActualGameStateValueArray[ix + iiy];

									if (gameStateValue == ConstGameBoard_Player1)
									{
										isolatedPos = false;
										badMoveDecision = true;
										break;
									}
									if (gameStateValue != ConstGameBoard_Empty)
									{
										isolatedPos = false;
									}
								}

								if (badMoveDecision == true)
								{
									break;
								}

							}

							if (badMoveDecision == true || isolatedPos == true)
							{
								continue;
							}
						} // end of macht ein Sprung-Z�ge Sinn?
						

						// next test move:

						CGameStateValues* pGameStateObject = nullptr;
						int32_t GameStateObjectID = -1;

						if (pGameStatePool->Get_UnusedGameStateObject(0, &pGameStateObject, &GameStateObjectID) == false)
						{
							goto TestMoveGenerationCompleted;
						}

						pGameStateObject->Clone_GameStateValues(pInActualGameState);

						// test move:
						Make_Player1Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
						pGameStateObject->PlayerID = 0;
						pGameStateObject->Use_As_Minimizer();
						moveCounter++;

						if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
						{
							goto Depth0_TestMoveGenerationCompleted;
						}
					}
				}
			}
		} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
	} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

Depth0_TestMoveGenerationCompleted:;

	if (maxSearchDepth < 1)
	{
		goto TestMoveGenerationCompleted;
	}

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	CGameStateValues* pActualGameState = nullptr;
	pActualGameStateValueArray = nullptr;
	CSimpleLinkedListManager *pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[0];
	int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	int32_t id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer2CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(1, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player2CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
					pGameStateObject->PlayerID = 1;
					pGameStateObject->Use_As_Maximizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth1_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player2)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?

							// next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(1, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player2Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
							pGameStateObject->PlayerID = 1;
							pGameStateObject->Use_As_Maximizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth1_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth1_TestMoveGenerationCompleted:;

	if (maxSearchDepth < 2)
	{
		goto TestMoveGenerationCompleted;
	}

	pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[1];
	NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer1CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(2, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player1CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
					pGameStateObject->PlayerID = 0;
					pGameStateObject->Use_As_Minimizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth2_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player1)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?

							// next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(2, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player1Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
							pGameStateObject->PlayerID = 0;
							pGameStateObject->Use_As_Minimizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth2_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth2_TestMoveGenerationCompleted:;

	if (maxSearchDepth < 3)
	{
		goto TestMoveGenerationCompleted;
	}

	pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[2];
	NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer2CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(3, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player2CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
					pGameStateObject->PlayerID = 1;
					pGameStateObject->Use_As_Maximizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth3_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player2)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?

							// next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(3, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player2Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
							pGameStateObject->PlayerID = 1;
							pGameStateObject->Use_As_Maximizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth3_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth3_TestMoveGenerationCompleted:;

	if (maxSearchDepth < 4)
	{
		goto TestMoveGenerationCompleted;
	}

	pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[3];
	NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer1CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(4, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player1CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
					pGameStateObject->PlayerID = 0;
					pGameStateObject->Use_As_Minimizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth4_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player1)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?

							// next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(4, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player1Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
							pGameStateObject->PlayerID = 0;
							pGameStateObject->Use_As_Minimizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth4_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth4_TestMoveGenerationCompleted:;

	
TestMoveGenerationCompleted:;

	Evaluate_LeafGameStates_Player1View(pGameStatePool);
	Backpropagate_MinimaxIntegerEvaluationValues(pGameStatePool);


	pGameStatePool->Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID);
	pOutNewGameState->Clone_GameStateValues(pGameStateObject);
}

void Test_Player1(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool *pGameStatePool, int32_t numTestGameStatesMaxPerDepthLayer, int32_t maxSearchDepth, CRandomNumbersNN *pRandomNumbers, float movementProbability_SearchDepth2, float movementProbability_SearchDepth3, float movementProbability_SearchDepth4)
{
	pGameStatePool->Stop_Using_AllGameStateObjects();

	pOutNewGameState->Clone_GameStateValues(pInActualGameState);

	int8_t *pActualGameStateValueArray = &pInActualGameState->pValueArray[0];

	int32_t moveCounter = 0;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
		{
			if (Check_PossiblePlayer1CloneMove(i, pActualGameStateValueArray) == true)
			{
				int32_t ixNew = i % ConstGameBoardSizePerDir;
				int32_t iyNew = i / ConstGameBoardSizePerDir;

				CGameStateValues* pGameStateObject = nullptr;
				int32_t GameStateObjectID = -1;

				if (pGameStatePool->Get_UnusedGameStateObject(0, &pGameStateObject, &GameStateObjectID) == false)
				{
					goto TestMoveGenerationCompleted;
				}

				pGameStateObject->Clone_GameStateValues(pInActualGameState);

				// test move:
				Make_Player1CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
				pGameStateObject->PlayerID = 0;
				pGameStateObject->Use_As_Minimizer();
				moveCounter++;

				if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
				{
					goto Depth0_TestMoveGenerationCompleted;
				}
			}
		}
		else if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		{
			int32_t ixOld = i % ConstGameBoardSizePerDir;
			int32_t iyOld = i / ConstGameBoardSizePerDir;

			int32_t ixMin = max(0, ixOld - 2);
			int32_t iyMin = max(0, iyOld - 2);

			int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
			int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

			for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
			{
				for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
				{
					// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
					if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
					{
						continue;
					}

					if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
					{
						// macht ein Sprung-Z�ge Sinn?
						{
							int32_t ixMin = max(0, ixNew - 1);
							int32_t iyMin = max(0, iyNew - 1);

							int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
							int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

							bool badMoveDecision = false;
							bool isolatedPos = true;

							int32_t iiy;
							int8_t gameStateValue;

							for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
							{
								iiy = ConstGameBoardSizePerDir * iy;

								for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
								{
									gameStateValue = pActualGameStateValueArray[ix + iiy];

									if (gameStateValue == ConstGameBoard_Player1)
									{
										isolatedPos = false;
										badMoveDecision = true;
										break;
									}
									if (gameStateValue != ConstGameBoard_Empty)
									{
										isolatedPos = false;
									}
								}

								if (badMoveDecision == true)
								{
									break;
								}

							}

							if (badMoveDecision == true || isolatedPos == true)
							{
								continue;
							}
						} // end of macht ein Sprung-Z�ge Sinn?


						  // next test move:

						CGameStateValues* pGameStateObject = nullptr;
						int32_t GameStateObjectID = -1;

						if (pGameStatePool->Get_UnusedGameStateObject(0, &pGameStateObject, &GameStateObjectID) == false)
						{
							goto TestMoveGenerationCompleted;
						}

						pGameStateObject->Clone_GameStateValues(pInActualGameState);

						// test move:
						Make_Player1Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
						pGameStateObject->PlayerID = 0;
						pGameStateObject->Use_As_Minimizer();
						moveCounter++;

						if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
						{
							goto Depth0_TestMoveGenerationCompleted;
						}
					}
				}
			}
		} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
	} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

Depth0_TestMoveGenerationCompleted:;

	if (maxSearchDepth < 1)
	{
		goto TestMoveGenerationCompleted;
	}

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	CGameStateValues* pActualGameState = nullptr;
	pActualGameStateValueArray = nullptr;
	CSimpleLinkedListManager *pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[0];
	int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	int32_t id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer2CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(1, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player2CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
					pGameStateObject->PlayerID = 1;
					pGameStateObject->Use_As_Maximizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth1_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player2)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?

							  // next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(1, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player2Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
							pGameStateObject->PlayerID = 1;
							pGameStateObject->Use_As_Maximizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth1_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth1_TestMoveGenerationCompleted:;

	if (maxSearchDepth < 2)
	{
		goto TestMoveGenerationCompleted;
	}

	pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[1];
	NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f) > movementProbability_SearchDepth2)
				continue;

			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer1CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(2, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player1CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
					pGameStateObject->PlayerID = 0;
					pGameStateObject->Use_As_Minimizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth2_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player1)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?

							  // next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(2, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player1Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
							pGameStateObject->PlayerID = 0;
							pGameStateObject->Use_As_Minimizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth2_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth2_TestMoveGenerationCompleted:;

	if (maxSearchDepth < 3)
	{
		goto TestMoveGenerationCompleted;
	}

	pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[2];
	NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f) > movementProbability_SearchDepth3)
				continue;

			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer2CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(3, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player2CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
					pGameStateObject->PlayerID = 1;
					pGameStateObject->Use_As_Maximizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth3_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player2)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?

							  // next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(3, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player2Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
							pGameStateObject->PlayerID = 1;
							pGameStateObject->Use_As_Maximizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth3_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth3_TestMoveGenerationCompleted:;

	if (maxSearchDepth < 4)
	{
		goto TestMoveGenerationCompleted;
	}

	pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[3];
	NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f) > movementProbability_SearchDepth4)
				continue;

			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer1CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(4, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player1CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
					pGameStateObject->PlayerID = 0;
					pGameStateObject->Use_As_Minimizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth4_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player1)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?

							  // next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(4, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player1Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
							pGameStateObject->PlayerID = 0;
							pGameStateObject->Use_As_Minimizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth4_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth4_TestMoveGenerationCompleted:;


TestMoveGenerationCompleted:;

	Evaluate_LeafGameStates_Player1View(pGameStatePool);
	Backpropagate_MinimaxIntegerEvaluationValues(pGameStatePool);


	pGameStatePool->Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID);
	pOutNewGameState->Clone_GameStateValues(pGameStateObject);
}




void Test_TrainedPlayer1(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool *pGameStatePool, int32_t numTestGameStatesMaxPerDepthLayer, int32_t maxSearchDepth, int32_t movementCounter, CSingleRecognitionNeuronEnsemble *pGameStateRecognitionNeuronEnsembleArray, CSimpleNeuron *pAdditionalEvaluationNeuronArray)
{
	pGameStatePool->Stop_Using_AllGameStateObjects();

	pOutNewGameState->Clone_GameStateValues(pInActualGameState);

	int8_t *pActualGameStateValueArray = &pInActualGameState->pValueArray[0];

	int32_t moveCounter = 0;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
		{
			if (Check_PossiblePlayer1CloneMove(i, pActualGameStateValueArray) == true)
			{
				int32_t ixNew = i % ConstGameBoardSizePerDir;
				int32_t iyNew = i / ConstGameBoardSizePerDir;

				CGameStateValues* pGameStateObject = nullptr;
				int32_t GameStateObjectID = -1;

				if (pGameStatePool->Get_UnusedGameStateObject(0, &pGameStateObject, &GameStateObjectID) == false)
				{
					goto TestMoveGenerationCompleted;
				}

				pGameStateObject->Clone_GameStateValues(pInActualGameState);

				// test move:
				Make_Player1CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);

				/////////////
				if (movementCounter < ConstNumGameStateRecognitionNeuronEnsembles)
				{
					Copy_GameData_Into_MemoryVector(tempMemoryVector, &pGameStateObject->pValueArray[0]);
				
					if (pGameStateRecognitionNeuronEnsembleArray[movementCounter].Compare_DataWithMemory(tempMemoryVector) > -1)
					{
						pOutNewGameState->Clone_GameStateValues(pGameStateObject);
						Add_To_Log(0, "movementCounter", movementCounter);
						Add_To_Log(0, "activationValue 1");
						return;
					}
				}
				/////////////

				pGameStateObject->PlayerID = 0;
				pGameStateObject->Use_As_Minimizer();
				moveCounter++;

				if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
				{
					goto Depth0_TestMoveGenerationCompleted;
				}
			}
		}
		else if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		{
			int32_t ixOld = i % ConstGameBoardSizePerDir;
			int32_t iyOld = i / ConstGameBoardSizePerDir;

			int32_t ixMin = max(0, ixOld - 2);
			int32_t iyMin = max(0, iyOld - 2);

			int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
			int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

			for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
			{
				for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
				{
					// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
					if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
					{
						continue;
					}

					if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
					{
						// macht ein Sprung-Z�ge Sinn?
						{
							int32_t ixMin = max(0, ixNew - 1);
							int32_t iyMin = max(0, iyNew - 1);

							int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
							int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

							bool badMoveDecision = false;
							bool isolatedPos = true;

							int32_t iiy;
							int8_t gameStateValue;

							for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
							{
								iiy = ConstGameBoardSizePerDir * iy;

								for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
								{
									gameStateValue = pActualGameStateValueArray[ix + iiy];

									if (gameStateValue == ConstGameBoard_Player1)
									{
										isolatedPos = false;
										badMoveDecision = true;
										break;
									}
									if (gameStateValue != ConstGameBoard_Empty)
									{
										isolatedPos = false;
									}
								}

								if (badMoveDecision == true)
								{
									break;
								}

							}

							if (badMoveDecision == true || isolatedPos == true)
							{
								continue;
							}
						} // end of macht ein Sprung-Z�ge Sinn?


						  // next test move:

						CGameStateValues* pGameStateObject = nullptr;
						int32_t GameStateObjectID = -1;

						if (pGameStatePool->Get_UnusedGameStateObject(0, &pGameStateObject, &GameStateObjectID) == false)
						{
							goto TestMoveGenerationCompleted;
						}

						pGameStateObject->Clone_GameStateValues(pInActualGameState);

						// test move:
						Make_Player1Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);

						/////////////
						if (movementCounter < ConstNumGameStateRecognitionNeuronEnsembles)
						{
							Copy_GameData_Into_MemoryVector(tempMemoryVector, &pGameStateObject->pValueArray[0]);
							
							if (pGameStateRecognitionNeuronEnsembleArray[movementCounter].Compare_DataWithMemory(tempMemoryVector) > -1)
							{
								pOutNewGameState->Clone_GameStateValues(pGameStateObject);
								Add_To_Log(0, "movementCounter", movementCounter);
								Add_To_Log(0, "activationValue 1");
								return;
							}
						}
						/////////////

						pGameStateObject->PlayerID = 0;
						pGameStateObject->Use_As_Minimizer();
						moveCounter++;

						if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
						{
							goto Depth0_TestMoveGenerationCompleted;
						}
					}
				}
			}
		} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
	} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

Depth0_TestMoveGenerationCompleted:;

	if (maxSearchDepth < 1)
	{
		goto TestMoveGenerationCompleted;
	}

	CGameStateValues* pRootGameStateObject = nullptr;
	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	CGameStateValues* pActualGameState = nullptr;
	pActualGameStateValueArray = nullptr;
	CSimpleLinkedListManager *pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[0];
	int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	int32_t id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer2CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(1, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player2CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);

					

					pGameStateObject->PlayerID = 1;
					pGameStateObject->Use_As_Maximizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth1_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player2)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?

							  // next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(1, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player2Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);

							

							pGameStateObject->PlayerID = 1;
							pGameStateObject->Use_As_Maximizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth1_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth1_TestMoveGenerationCompleted:;

	if (maxSearchDepth < 2)
	{
		goto TestMoveGenerationCompleted;
	}

	pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[1];
	NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer1CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(2, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player1CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);

					pGameStateObject->PlayerID = 0;
					pGameStateObject->Use_As_Minimizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth2_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player1)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?

							  // next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(2, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player1Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
							

							pGameStateObject->PlayerID = 0;
							pGameStateObject->Use_As_Minimizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth2_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth2_TestMoveGenerationCompleted:;

	if (maxSearchDepth < 3)
	{
		goto TestMoveGenerationCompleted;
	}

	pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[2];
	NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer2CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(3, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player2CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);

					

					pGameStateObject->PlayerID = 1;
					pGameStateObject->Use_As_Maximizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth3_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player2)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?

							  // next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(3, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player2Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);

						

							pGameStateObject->PlayerID = 1;
							pGameStateObject->Use_As_Maximizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth3_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth3_TestMoveGenerationCompleted:;

	if (maxSearchDepth < 4)
	{
		goto TestMoveGenerationCompleted;
	}

	pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[3];
	NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer1CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(4, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player1CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);

					

					pGameStateObject->PlayerID = 0;
					pGameStateObject->Use_As_Minimizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth4_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player1)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?

							  // next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(4, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player1Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);

						

							pGameStateObject->PlayerID = 0;
							pGameStateObject->Use_As_Minimizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth4_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth4_TestMoveGenerationCompleted:;


TestMoveGenerationCompleted:;

	Evaluate_LeafGameStates_Player1View(pGameStatePool);
	Backpropagate_MinimaxIntegerEvaluationValues(pGameStatePool);


	pGameStatePool->Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID);
	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

	if (movementCounter < ConstNumGameStateRecognitionNeuronEnsembles)
	{
		Copy_GameData_Into_MemoryVector(tempMemoryVector, &pOutNewGameState->pValueArray[0]);

		if (pGameStateRecognitionNeuronEnsembleArray[movementCounter].Compare_DataWithMemory(tempMemoryVector) > -1)
		{
			Add_To_Log(0, "---movementCounter", movementCounter);
			Add_To_Log(0, "---activationValue 1");
		}
		else
		{
			if (pGameStateRecognitionNeuronEnsembleArray[movementCounter].Set_AdditionalMemoryValues(tempMemoryVector) == true)
			{
				if (pAdditionalEvaluationNeuronArray != nullptr)
				{
					Copy_GameData_Into_BinaryGameStateVector(tempBinaryGameStateVector, &pOutNewGameState->pValueArray[0]);
					pAdditionalEvaluationNeuronArray[movementCounter].Add_TrainingExample(tempBinaryGameStateVector);
					pAdditionalEvaluationNeuronArray[movementCounter].Calculate_Dendrite_Factors_From_CentroidValues(0.5f, 0.025f, 4);
				}
			}

			Add_To_Log(0, "---movementCounter", movementCounter);
			Add_To_Log(0, "---activationValue 0");
		}
	}
}




void Test_LearningPlayer1(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool *pGameStatePool, int32_t numTestGameStatesMaxPerDepthLayer, int32_t maxSearchDepth, int32_t movementCounter, CSingleRecognitionNeuronEnsemble *pGameStateRecognitionNeuronEnsembleArray, CSimpleNeuron *pAdditionalEvaluationNeuronArray)
{
	//Add_To_Log(0, "TotalMovementCounter", movementCounter);
	//movementCounter /= 2;
	//Add_To_Log(0, "Player1MovementCounter", movementCounter);

	pGameStatePool->Stop_Using_AllGameStateObjects();

	pOutNewGameState->Clone_GameStateValues(pInActualGameState);

	int8_t *pActualGameStateValueArray = &pInActualGameState->pValueArray[0];

	int32_t moveCounter = 0;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
		{
			if (Check_PossiblePlayer1CloneMove(i, pActualGameStateValueArray) == true)
			{
				int32_t ixNew = i % ConstGameBoardSizePerDir;
				int32_t iyNew = i / ConstGameBoardSizePerDir;

				CGameStateValues* pGameStateObject = nullptr;
				int32_t GameStateObjectID = -1;

				if (pGameStatePool->Get_UnusedGameStateObject(0, &pGameStateObject, &GameStateObjectID) == false)
				{
					goto TestMoveGenerationCompleted;
				}

				pGameStateObject->Clone_GameStateValues(pInActualGameState);

				// test move:
				Make_Player1CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
				pGameStateObject->PlayerID = 0;
				pGameStateObject->Use_As_Minimizer();
				moveCounter++;

				if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
				{
					goto Depth0_TestMoveGenerationCompleted;
				}
			}
		}
		else if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		{
			int32_t ixOld = i % ConstGameBoardSizePerDir;
			int32_t iyOld = i / ConstGameBoardSizePerDir;

			int32_t ixMin = max(0, ixOld - 2);
			int32_t iyMin = max(0, iyOld - 2);

			int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
			int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

			for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
			{
				for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
				{
					// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
					if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
					{
						continue;
					}

					if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
					{
						// macht ein Sprung-Z�ge Sinn?
						{
							int32_t ixMin = max(0, ixNew - 1);
							int32_t iyMin = max(0, iyNew - 1);

							int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
							int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

							bool badMoveDecision = false;
							bool isolatedPos = true;

							int32_t iiy;
							int8_t gameStateValue;

							for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
							{
								iiy = ConstGameBoardSizePerDir * iy;

								for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
								{
									gameStateValue = pActualGameStateValueArray[ix + iiy];

									if (gameStateValue == ConstGameBoard_Player1)
									{
										isolatedPos = false;
										badMoveDecision = true;
										break;
									}
									if (gameStateValue != ConstGameBoard_Empty)
									{
										isolatedPos = false;
									}
								}

								if (badMoveDecision == true)
								{
									break;
								}

							}

							if (badMoveDecision == true || isolatedPos == true)
							{
								continue;
							}
						} // end of macht ein Sprung-Z�ge Sinn?


						  // next test move:

						CGameStateValues* pGameStateObject = nullptr;
						int32_t GameStateObjectID = -1;

						if (pGameStatePool->Get_UnusedGameStateObject(0, &pGameStateObject, &GameStateObjectID) == false)
						{
							goto TestMoveGenerationCompleted;
						}

						pGameStateObject->Clone_GameStateValues(pInActualGameState);

						// test move:
						Make_Player1Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
						pGameStateObject->PlayerID = 0;
						pGameStateObject->Use_As_Minimizer();
						moveCounter++;

						if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
						{
							goto Depth0_TestMoveGenerationCompleted;
						}
					}
				}
			}
		} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
	} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

Depth0_TestMoveGenerationCompleted:;

	if (maxSearchDepth < 1)
	{
		goto TestMoveGenerationCompleted;
	}

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	CGameStateValues* pActualGameState = nullptr;
	pActualGameStateValueArray = nullptr;
	CSimpleLinkedListManager *pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[0];
	int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	int32_t id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer2CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(1, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player2CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
					pGameStateObject->PlayerID = 1;
					pGameStateObject->Use_As_Maximizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth1_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player2)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?

							  // next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(1, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player2Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
							pGameStateObject->PlayerID = 1;
							pGameStateObject->Use_As_Maximizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth1_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth1_TestMoveGenerationCompleted:;

	if (maxSearchDepth < 2)
	{
		goto TestMoveGenerationCompleted;
	}

	pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[1];
	NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer1CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(2, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player1CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
					pGameStateObject->PlayerID = 0;
					pGameStateObject->Use_As_Minimizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth2_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player1)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?

							  // next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(2, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player1Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
							pGameStateObject->PlayerID = 0;
							pGameStateObject->Use_As_Minimizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth2_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth2_TestMoveGenerationCompleted:;

	if (maxSearchDepth < 3)
	{
		goto TestMoveGenerationCompleted;
	}

	pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[2];
	NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer2CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(3, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player2CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
					pGameStateObject->PlayerID = 1;
					pGameStateObject->Use_As_Maximizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth3_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player2)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?

							  // next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(3, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player2Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
							pGameStateObject->PlayerID = 1;
							pGameStateObject->Use_As_Maximizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth3_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth3_TestMoveGenerationCompleted:;

	if (maxSearchDepth < 4)
	{
		goto TestMoveGenerationCompleted;
	}

	pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[3];
	NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer1CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(4, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player1CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
					pGameStateObject->PlayerID = 0;
					pGameStateObject->Use_As_Minimizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth4_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player1)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?

							  // next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(4, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player1Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
							pGameStateObject->PlayerID = 0;
							pGameStateObject->Use_As_Minimizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth4_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth4_TestMoveGenerationCompleted:;


TestMoveGenerationCompleted:;

	Evaluate_LeafGameStates_Player1View(pGameStatePool);
	Backpropagate_MinimaxIntegerEvaluationValues(pGameStatePool);


	pGameStatePool->Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID);
	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

	if(movementCounter < ConstNumGameStateRecognitionNeuronEnsembles)
	{
		Copy_GameData_Into_MemoryVector(tempMemoryVector, &pOutNewGameState->pValueArray[0]);
		
		if (pGameStateRecognitionNeuronEnsembleArray[movementCounter].Set_AdditionalMemoryValues(tempMemoryVector) == true)
		{
			if (pAdditionalEvaluationNeuronArray != nullptr)
			{
				Copy_GameData_Into_BinaryGameStateVector(tempBinaryGameStateVector, &pOutNewGameState->pValueArray[0]);
				pAdditionalEvaluationNeuronArray[movementCounter].Add_TrainingExample(tempBinaryGameStateVector);
				pAdditionalEvaluationNeuronArray[movementCounter].Calculate_Dendrite_Factors_From_CentroidValues(0.5f, 0.025f, 4);
			}
		}
	}
	else
	{
		Add_To_Log(0, "no learning!!!");
	}
}





/*
void Test_Player2(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool *pGameStatePool, CRandomNumbersNN *pRandomNumbers, int32_t numTestGameStatesMaxPerDepthLayer, int32_t numOfRandomGameMoveChainsMax, int32_t maxSearchDepth_Minimax)
{
	pGameStatePool->Stop_Using_AllGameStateObjects();

	pOutNewGameState->Clone_GameStateValues(pInActualGameState);

	int8_t *pActualGameStateValueArray = &pInActualGameState->pValueArray[0];

	int32_t moveCounter = 0;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
		{
			if (Check_PossiblePlayer2CloneMove(i, pActualGameStateValueArray) == true)
			{
				// next test move:

				int32_t ixNew = i % ConstGameBoardSizePerDir;
				int32_t iyNew = i / ConstGameBoardSizePerDir;

				CGameStateValues* pGameStateObject = nullptr;
				int32_t GameStateObjectID = -1;

				if (pGameStatePool->Get_UnusedGameStateObject(0, &pGameStateObject, &GameStateObjectID) == false)
				{
					goto TestMoveGenerationCompleted;
				}

				pGameStateObject->Clone_GameStateValues(pInActualGameState);

				// test move:
				Make_Player2CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
				pGameStateObject->PlayerID = 1;
				pGameStateObject->Use_As_Minimizer();
				moveCounter++;

				if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
				{
					goto Depth0_TestMoveGenerationCompleted;
				}
			}
		}
		else if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
		{
			int32_t ixOld = i % ConstGameBoardSizePerDir;
			int32_t iyOld = i / ConstGameBoardSizePerDir;

			int32_t ixMin = max(0, ixOld - 2);
			int32_t iyMin = max(0, iyOld - 2);

			int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
			int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

			for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
			{
				for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
				{
					// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
					if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
					{
						continue;
					}

					if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
					{
						// next test move:

						CGameStateValues* pGameStateObject = nullptr;
						int32_t GameStateObjectID = -1;

						if (pGameStatePool->Get_UnusedGameStateObject(0, &pGameStateObject, &GameStateObjectID) == false)
						{
							goto TestMoveGenerationCompleted;
						}

						pGameStateObject->Clone_GameStateValues(pInActualGameState);

						// test move:
						Make_Player2Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
						pGameStateObject->PlayerID = 1;
						pGameStateObject->Use_As_Minimizer();
						moveCounter++;

						if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
						{
							goto Depth0_TestMoveGenerationCompleted;
						}
					}
				}
			}
		} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
	} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

Depth0_TestMoveGenerationCompleted:;

	if (maxSearchDepth_Minimax < 1)
	{
		goto TestMoveGenerationCompleted;
	}

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	
	for (int32_t i = 0; i < numOfRandomGameMoveChainsMax; i++)
	{
		bool movePossible = false;
		int32_t nextPlayer = -1;

		for (int32_t j = 0; j < 100; j++)
		{
			GameStateObjectID = pGameStatePool->Get_Random_GameStateID_LastDepthLayerExcluded(0, 0, 1000, pRandomNumbers);

			if (GameStateObjectID < 0)
			{
				continue;
			}

			pGameStateObject = &pGameStatePool->pGameStateArray[GameStateObjectID];
			nextPlayer = (pGameStateObject->PlayerID + 1) % 2;

			if (pGameStateObject->PlayerID != 1)
			{
				Add_To_Log(0, "pGameStateObject->PlayerID must be 1");
			}
			if (pGameStateObject->DepthValue != 0)
			{
				Add_To_Log(0, "pGameStateObject->DepthValue must be 0");
			}

			if (pCheck_PossiblePlayer1Or2MovesFuncArray[nextPlayer](&pGameStateObject->pValueArray[0]) == false)
			{
				continue;
			}
			else
			{
				movePossible = true;
				break;
			}
		}

		if (movePossible == true)
		{
			Generate_Random_GameMoveChain_Player2(maxSearchDepth_Minimax, pGameStateObject, pGameStatePool, pRandomNumbers);
		}

	} // end of for (int32_t i = 0; i < numOfRandomGameMoveChainsMax; i++)

	if (maxSearchDepth_Minimax > 1)
	{
		for (int32_t i = 0; i < numOfRandomGameMoveChainsMax; i++)
		{
			bool movePossible = false;
			int32_t nextPlayer = -1;

			for (int32_t j = 0; j < 100; j++)
			{
				GameStateObjectID = pGameStatePool->Get_Random_GameStateID_LastDepthLayerExcluded(1, 1, 1000, pRandomNumbers);

				if (GameStateObjectID < 0)
				{
					continue;
				}

				pGameStateObject = &pGameStatePool->pGameStateArray[GameStateObjectID];
				nextPlayer = (pGameStateObject->PlayerID + 1) % 2;

				if (pGameStateObject->PlayerID != 1)
				{
					Add_To_Log(0, "pGameStateObject->PlayerID must be 1");
				}
				if (pGameStateObject->DepthValue != 0)
				{
					Add_To_Log(0, "pGameStateObject->DepthValue must be 0");
				}

				if (pCheck_PossiblePlayer1Or2MovesFuncArray[nextPlayer](&pGameStateObject->pValueArray[0]) == false)
				{
					continue;
				}
				else
				{
					movePossible = true;
					break;
				}
			}

			if (movePossible == true)
			{
				Generate_Random_GameMoveChain_Player2(maxSearchDepth_Minimax, pGameStateObject, pGameStatePool, pRandomNumbers);
			}

		} // end of for (int32_t i = 0; i < numOfRandomGameMoveChainsMax; i++)
	}
	

TestMoveGenerationCompleted:;

	Calculate_LeafGameStates_Player2Evaluations(pGameStatePool);
	//Calculate_GameStates_Player2Evaluations(pGameStatePool);
	Backpropagate_IntegerEvaluationValues(pGameStatePool);

	
	pGameStatePool->Get_Best_GameState_IntergerEvaluation(&pGameStateObject, &GameStateObjectID);

	//int32_t Player1Score, Player2Score;
	//Calculate_Score(&Player1Score, &Player2Score, &pGameStateObject->pValueArray[0]);
	//Add_To_Log(0, "BestPlayer1Score", Player1Score);
	//Add_To_Log(0, "BestPlayer2Score", Player2Score);
	//Add_To_Log(0, "BestEval", pGameStateObject->iEvaluation);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);
}
*/

void Test_Player2(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool *pGameStatePool, int32_t numTestGameStatesMaxPerDepthLayer,int32_t maxSearchDepth)
{
	pGameStatePool->Stop_Using_AllGameStateObjects();

	pOutNewGameState->Clone_GameStateValues(pInActualGameState);

	int8_t *pActualGameStateValueArray = &pInActualGameState->pValueArray[0];

	int32_t moveCounter = 0;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
		{
			if (Check_PossiblePlayer2CloneMove(i, pActualGameStateValueArray) == true)
			{
				// next test move:

				int32_t ixNew = i % ConstGameBoardSizePerDir;
				int32_t iyNew = i / ConstGameBoardSizePerDir;

				CGameStateValues* pGameStateObject = nullptr;
				int32_t GameStateObjectID = -1;

				if (pGameStatePool->Get_UnusedGameStateObject(0, &pGameStateObject, &GameStateObjectID) == false)
				{
					goto TestMoveGenerationCompleted;
				}

				pGameStateObject->Clone_GameStateValues(pInActualGameState);

				// test move:
				Make_Player2CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
				pGameStateObject->PlayerID = 1;
				pGameStateObject->Use_As_Minimizer();
				moveCounter++;

				if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
				{
					goto Depth0_TestMoveGenerationCompleted;
				}
			}
		}
		else if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
		{
			int32_t ixOld = i % ConstGameBoardSizePerDir;
			int32_t iyOld = i / ConstGameBoardSizePerDir;

			int32_t ixMin = max(0, ixOld - 2);
			int32_t iyMin = max(0, iyOld - 2);

			int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
			int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

			for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
			{
				for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
				{
					// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
					if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
					{
						continue;
					}

					if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
					{
						// macht ein Sprung-Z�ge Sinn?
						{
							int32_t ixMin = max(0, ixNew - 1);
							int32_t iyMin = max(0, iyNew - 1);

							int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
							int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

							bool badMoveDecision = false;
							bool isolatedPos = true;

							int32_t iiy;
							int8_t gameStateValue;

							for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
							{
								iiy = ConstGameBoardSizePerDir * iy;

								for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
								{
									gameStateValue = pActualGameStateValueArray[ix + iiy];

									if (gameStateValue == ConstGameBoard_Player2)
									{
										isolatedPos = false;
										badMoveDecision = true;
										break;
									}
									if (gameStateValue != ConstGameBoard_Empty)
									{
										isolatedPos = false;
									}
								}

								if (badMoveDecision == true)
								{
									break;
								}

							}

							if (badMoveDecision == true || isolatedPos == true)
							{
								continue;
							}
						} // end of macht ein Sprung-Z�ge Sinn?
						

						// next test move:

						CGameStateValues* pGameStateObject = nullptr;
						int32_t GameStateObjectID = -1;

						if (pGameStatePool->Get_UnusedGameStateObject(0, &pGameStateObject, &GameStateObjectID) == false)
						{
							goto TestMoveGenerationCompleted;
						}

						pGameStateObject->Clone_GameStateValues(pInActualGameState);

						// test move:
						Make_Player2Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
						pGameStateObject->PlayerID = 1;
						pGameStateObject->Use_As_Minimizer();
						moveCounter++;

						if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
						{
							goto Depth0_TestMoveGenerationCompleted;
						}
					}
				}
			}
		} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
	} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

Depth0_TestMoveGenerationCompleted:;

	if (maxSearchDepth < 1)
	{
		goto TestMoveGenerationCompleted;
	}

	CGameStateValues* pActualGameState = nullptr;
	pActualGameStateValueArray = nullptr;
	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	CSimpleLinkedListManager *pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[0];
	int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	int32_t id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer1CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(1, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player1CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
					pGameStateObject->PlayerID = 0;
					pGameStateObject->Use_As_Maximizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth1_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player1)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?

							// next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(1, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player1Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
							pGameStateObject->PlayerID = 0;
							pGameStateObject->Use_As_Maximizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth1_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth1_TestMoveGenerationCompleted:;

	if (maxSearchDepth < 2)
	{
		goto TestMoveGenerationCompleted;
	}

	pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[1];
	NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer2CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(2, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player2CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
					pGameStateObject->PlayerID = 1;
					pGameStateObject->Use_As_Minimizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth2_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player2)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?

							// next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(2, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player2Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
							pGameStateObject->PlayerID = 1;
							pGameStateObject->Use_As_Minimizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth2_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth2_TestMoveGenerationCompleted:;

	if (maxSearchDepth < 3)
	{
		goto TestMoveGenerationCompleted;
	}

	pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[2];
	NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer1CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(3, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player1CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
					pGameStateObject->PlayerID = 0;
					pGameStateObject->Use_As_Maximizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth3_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player1)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?

							// next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(3, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player1Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
							pGameStateObject->PlayerID = 0;
							pGameStateObject->Use_As_Maximizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth3_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth3_TestMoveGenerationCompleted:;

	if (maxSearchDepth < 4)
	{
		goto TestMoveGenerationCompleted;
	}

	pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[3];
	NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer2CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(4, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player2CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
					pGameStateObject->PlayerID = 1;
					pGameStateObject->Use_As_Minimizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth4_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player2)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?

							// next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(4, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player2Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
							pGameStateObject->PlayerID = 1;
							pGameStateObject->Use_As_Minimizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth4_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth4_TestMoveGenerationCompleted:;

	

TestMoveGenerationCompleted:;

	Evaluate_LeafGameStates_Player2View(pGameStatePool);
	Backpropagate_MinimaxIntegerEvaluationValues(pGameStatePool);


	pGameStatePool->Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID);

	//int32_t Player1Score, Player2Score;
	//Calculate_Score(&Player1Score, &Player2Score, &pGameStateObject->pValueArray[0]);
	//Add_To_Log(0, "BestPlayer1Score", Player1Score);
	//Add_To_Log(0, "BestPlayer2Score", Player2Score);
	//Add_To_Log(0, "BestEval", pGameStateObject->iEvaluation);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);
}

void Test_Player2(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool *pGameStatePool, int32_t numTestGameStatesMaxPerDepthLayer, int32_t maxSearchDepth, CRandomNumbersNN *pRandomNumbers, float movementProbability_SearchDepth2, float movementProbability_SearchDepth3, float movementProbability_SearchDepth4)
{
	pGameStatePool->Stop_Using_AllGameStateObjects();

	pOutNewGameState->Clone_GameStateValues(pInActualGameState);

	int8_t *pActualGameStateValueArray = &pInActualGameState->pValueArray[0];

	int32_t moveCounter = 0;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
		{
			if (Check_PossiblePlayer2CloneMove(i, pActualGameStateValueArray) == true)
			{
				// next test move:

				int32_t ixNew = i % ConstGameBoardSizePerDir;
				int32_t iyNew = i / ConstGameBoardSizePerDir;

				CGameStateValues* pGameStateObject = nullptr;
				int32_t GameStateObjectID = -1;

				if (pGameStatePool->Get_UnusedGameStateObject(0, &pGameStateObject, &GameStateObjectID) == false)
				{
					goto TestMoveGenerationCompleted;
				}

				pGameStateObject->Clone_GameStateValues(pInActualGameState);

				// test move:
				Make_Player2CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
				pGameStateObject->PlayerID = 1;
				pGameStateObject->Use_As_Minimizer();
				moveCounter++;

				if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
				{
					goto Depth0_TestMoveGenerationCompleted;
				}
			}
		}
		else if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
		{
			int32_t ixOld = i % ConstGameBoardSizePerDir;
			int32_t iyOld = i / ConstGameBoardSizePerDir;

			int32_t ixMin = max(0, ixOld - 2);
			int32_t iyMin = max(0, iyOld - 2);

			int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
			int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

			for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
			{
				for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
				{
					// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
					if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
					{
						continue;
					}

					if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
					{
						// macht ein Sprung-Z�ge Sinn?
						{
							int32_t ixMin = max(0, ixNew - 1);
							int32_t iyMin = max(0, iyNew - 1);

							int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
							int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

							bool badMoveDecision = false;
							bool isolatedPos = true;

							int32_t iiy;
							int8_t gameStateValue;

							for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
							{
								iiy = ConstGameBoardSizePerDir * iy;

								for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
								{
									gameStateValue = pActualGameStateValueArray[ix + iiy];

									if (gameStateValue == ConstGameBoard_Player2)
									{
										isolatedPos = false;
										badMoveDecision = true;
										break;
									}
									if (gameStateValue != ConstGameBoard_Empty)
									{
										isolatedPos = false;
									}
								}

								if (badMoveDecision == true)
								{
									break;
								}

							}

							if (badMoveDecision == true || isolatedPos == true)
							{
								continue;
							}
						} // end of macht ein Sprung-Z�ge Sinn?


						  // next test move:

						CGameStateValues* pGameStateObject = nullptr;
						int32_t GameStateObjectID = -1;

						if (pGameStatePool->Get_UnusedGameStateObject(0, &pGameStateObject, &GameStateObjectID) == false)
						{
							goto TestMoveGenerationCompleted;
						}

						pGameStateObject->Clone_GameStateValues(pInActualGameState);

						// test move:
						Make_Player2Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
						pGameStateObject->PlayerID = 1;
						pGameStateObject->Use_As_Minimizer();
						moveCounter++;

						if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
						{
							goto Depth0_TestMoveGenerationCompleted;
						}
					}
				}
			}
		} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
	} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

Depth0_TestMoveGenerationCompleted:;

	if (maxSearchDepth < 1)
	{
		goto TestMoveGenerationCompleted;
	}

	CGameStateValues* pActualGameState = nullptr;
	pActualGameStateValueArray = nullptr;
	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	CSimpleLinkedListManager *pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[0];
	int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	int32_t id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer1CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(1, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player1CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
					pGameStateObject->PlayerID = 0;
					pGameStateObject->Use_As_Maximizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth1_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player1)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?

							  // next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(1, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player1Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
							pGameStateObject->PlayerID = 0;
							pGameStateObject->Use_As_Maximizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth1_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth1_TestMoveGenerationCompleted:;

	if (maxSearchDepth < 2)
	{
		goto TestMoveGenerationCompleted;
	}

	pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[1];
	NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f) > movementProbability_SearchDepth2)
				continue;

			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer2CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(2, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player2CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
					pGameStateObject->PlayerID = 1;
					pGameStateObject->Use_As_Minimizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth2_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player2)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?

							  // next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(2, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player2Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
							pGameStateObject->PlayerID = 1;
							pGameStateObject->Use_As_Minimizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth2_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth2_TestMoveGenerationCompleted:;

	if (maxSearchDepth < 3)
	{
		goto TestMoveGenerationCompleted;
	}

	pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[2];
	NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f) > movementProbability_SearchDepth3)
				continue;

			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer1CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(3, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player1CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
					pGameStateObject->PlayerID = 0;
					pGameStateObject->Use_As_Maximizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth3_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player1)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?

							  // next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(3, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player1Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
							pGameStateObject->PlayerID = 0;
							pGameStateObject->Use_As_Maximizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth3_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth3_TestMoveGenerationCompleted:;

	if (maxSearchDepth < 4)
	{
		goto TestMoveGenerationCompleted;
	}

	pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[3];
	NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f) > movementProbability_SearchDepth4)
				continue;

			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer2CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(4, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player2CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
					pGameStateObject->PlayerID = 1;
					pGameStateObject->Use_As_Minimizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth4_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player2)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?

							  // next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(4, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player2Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
							pGameStateObject->PlayerID = 1;
							pGameStateObject->Use_As_Minimizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth4_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth4_TestMoveGenerationCompleted:;



TestMoveGenerationCompleted:;

	Evaluate_LeafGameStates_Player2View(pGameStatePool);
	Backpropagate_MinimaxIntegerEvaluationValues(pGameStatePool);


	pGameStatePool->Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID);

	//int32_t Player1Score, Player2Score;
	//Calculate_Score(&Player1Score, &Player2Score, &pGameStateObject->pValueArray[0]);
	//Add_To_Log(0, "BestPlayer1Score", Player1Score);
	//Add_To_Log(0, "BestPlayer2Score", Player2Score);
	//Add_To_Log(0, "BestEval", pGameStateObject->iEvaluation);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);
}




void Test_TrainedPlayer2(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool *pGameStatePool, int32_t numTestGameStatesMaxPerDepthLayer, int32_t maxSearchDepth, int32_t movementCounter, CSingleRecognitionNeuronEnsemble *pGameStateRecognitionNeuronEnsembleArray, CSimpleNeuron *pAdditionalEvaluationNeuronArray)
{
	

	pGameStatePool->Stop_Using_AllGameStateObjects();

	pOutNewGameState->Clone_GameStateValues(pInActualGameState);

	int8_t *pActualGameStateValueArray = &pInActualGameState->pValueArray[0];

	int32_t moveCounter = 0;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
		{
			if (Check_PossiblePlayer2CloneMove(i, pActualGameStateValueArray) == true)
			{
				// next test move:

				int32_t ixNew = i % ConstGameBoardSizePerDir;
				int32_t iyNew = i / ConstGameBoardSizePerDir;

				CGameStateValues* pGameStateObject = nullptr;
				int32_t GameStateObjectID = -1;

				if (pGameStatePool->Get_UnusedGameStateObject(0, &pGameStateObject, &GameStateObjectID) == false)
				{
					goto TestMoveGenerationCompleted;
				}

				pGameStateObject->Clone_GameStateValues(pInActualGameState);

				// test move:
				Make_Player2CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);

				/////////////
				if (movementCounter < ConstNumGameStateRecognitionNeuronEnsembles)
				{
					Copy_GameData_Into_MemoryVector(tempMemoryVector, &pGameStateObject->pValueArray[0]);

					/*{
						FILE* pfile = fopen("AI_Log.txt", "a");

						for (int32_t iy = 0; iy < 7; iy++)
						{
							for (int32_t ix = 0; ix < 7; ix++)
							{
								fprintf(pfile, "%I32d", (int32_t)pGameStateObject->pValueArray[ix + 7*iy]);
							}
							fprintf(pfile, "\n");
						}
						fprintf(pfile, "\n");
						fclose(pfile);
					}*/
				
					if (pGameStateRecognitionNeuronEnsembleArray[movementCounter].Compare_DataWithMemory(tempMemoryVector) > -1)
					{
						pOutNewGameState->Clone_GameStateValues(pGameStateObject);

						Add_To_Log(0, "movementCounter", movementCounter);
						Add_To_Log(0, "activationValue 1");
						return;
					}
				}
				/////////////


				pGameStateObject->PlayerID = 1;
				pGameStateObject->Use_As_Minimizer();
				moveCounter++;

				if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
				{
					goto Depth0_TestMoveGenerationCompleted;
				}
			}
		}
		else if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
		{
			int32_t ixOld = i % ConstGameBoardSizePerDir;
			int32_t iyOld = i / ConstGameBoardSizePerDir;

			int32_t ixMin = max(0, ixOld - 2);
			int32_t iyMin = max(0, iyOld - 2);

			int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
			int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

			for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
			{
				for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
				{
					// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
					if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
					{
						continue;
					}

					if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
					{
						// macht ein Sprung-Z�ge Sinn?
						{
							int32_t ixMin = max(0, ixNew - 1);
							int32_t iyMin = max(0, iyNew - 1);

							int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
							int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

							bool badMoveDecision = false;
							bool isolatedPos = true;

							int32_t iiy;
							int8_t gameStateValue;

							for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
							{
								iiy = ConstGameBoardSizePerDir * iy;

								for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
								{
									gameStateValue = pActualGameStateValueArray[ix + iiy];

									if (gameStateValue == ConstGameBoard_Player2)
									{
										isolatedPos = false;
										badMoveDecision = true;
										break;
									}
									if (gameStateValue != ConstGameBoard_Empty)
									{
										isolatedPos = false;
									}
								}

								if (badMoveDecision == true)
								{
									break;
								}

							}

							if (badMoveDecision == true || isolatedPos == true)
							{
								continue;
							}
						} // end of macht ein Sprung-Z�ge Sinn?


						  // next test move:

						CGameStateValues* pGameStateObject = nullptr;
						int32_t GameStateObjectID = -1;

						if (pGameStatePool->Get_UnusedGameStateObject(0, &pGameStateObject, &GameStateObjectID) == false)
						{
							goto TestMoveGenerationCompleted;
						}

						pGameStateObject->Clone_GameStateValues(pInActualGameState);

						// test move:
						Make_Player2Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);

						/////////////
						if (movementCounter < ConstNumGameStateRecognitionNeuronEnsembles)
						{
							Copy_GameData_Into_MemoryVector(tempMemoryVector, &pGameStateObject->pValueArray[0]);
													
							if (pGameStateRecognitionNeuronEnsembleArray[movementCounter].Compare_DataWithMemory(tempMemoryVector) > -1)
							{
								pOutNewGameState->Clone_GameStateValues(pGameStateObject);
								Add_To_Log(0, "movementCounter", movementCounter);
								Add_To_Log(0, "activationValue 1");
								return;
							}
						}
						/////////////

						pGameStateObject->PlayerID = 1;
						pGameStateObject->Use_As_Minimizer();
						moveCounter++;

						if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
						{
							goto Depth0_TestMoveGenerationCompleted;
						}
					}
				}
			}
		} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
	} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

Depth0_TestMoveGenerationCompleted:;

	if (maxSearchDepth < 1)
	{
		goto TestMoveGenerationCompleted;
	}

	CGameStateValues* pRootGameStateObject = nullptr;
	CGameStateValues* pActualGameState = nullptr;
	pActualGameStateValueArray = nullptr;
	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	CSimpleLinkedListManager *pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[0];
	int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	int32_t id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer1CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(1, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player1CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);

					

					pGameStateObject->PlayerID = 0;
					pGameStateObject->Use_As_Maximizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth1_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player1)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?

							  // next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(1, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player1Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);

							

							pGameStateObject->PlayerID = 0;
							pGameStateObject->Use_As_Maximizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth1_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth1_TestMoveGenerationCompleted:;

	if (maxSearchDepth < 2)
	{
		goto TestMoveGenerationCompleted;
	}

	pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[1];
	NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer2CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(2, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player2CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);

					

					pGameStateObject->PlayerID = 1;
					pGameStateObject->Use_As_Minimizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth2_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player2)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?

							  // next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(2, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player2Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);

							

							pGameStateObject->PlayerID = 1;
							pGameStateObject->Use_As_Minimizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth2_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth2_TestMoveGenerationCompleted:;

	if (maxSearchDepth < 3)
	{
		goto TestMoveGenerationCompleted;
	}

	pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[2];
	NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer1CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(3, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player1CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);

				

					pGameStateObject->PlayerID = 0;
					pGameStateObject->Use_As_Maximizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth3_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player1)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?

							  // next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(3, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player1Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);

							

							pGameStateObject->PlayerID = 0;
							pGameStateObject->Use_As_Maximizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth3_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth3_TestMoveGenerationCompleted:;

	if (maxSearchDepth < 4)
	{
		goto TestMoveGenerationCompleted;
	}

	pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[3];
	NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer2CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(4, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player2CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);

					

					pGameStateObject->PlayerID = 1;
					pGameStateObject->Use_As_Minimizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth4_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player2)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?

							  // next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(4, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player2Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);

							

							pGameStateObject->PlayerID = 1;
							pGameStateObject->Use_As_Minimizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth4_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth4_TestMoveGenerationCompleted:;



TestMoveGenerationCompleted:;

	Evaluate_LeafGameStates_Player2View(pGameStatePool);
	Backpropagate_MinimaxIntegerEvaluationValues(pGameStatePool);

	pGameStatePool->Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID);
	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

	if (movementCounter < ConstNumGameStateRecognitionNeuronEnsembles)
	{
		Copy_GameData_Into_MemoryVector(tempMemoryVector, &pOutNewGameState->pValueArray[0]);

		if (pGameStateRecognitionNeuronEnsembleArray[movementCounter].Compare_DataWithMemory(tempMemoryVector) > -1)
		{
			Add_To_Log(0, "---movementCounter", movementCounter);
			Add_To_Log(0, "---activationValue 1");
		}
		else
		{
			if (pGameStateRecognitionNeuronEnsembleArray[movementCounter].Set_AdditionalMemoryValues(tempMemoryVector) == true)
			{
				if (pAdditionalEvaluationNeuronArray != nullptr)
				{
					Copy_GameData_Into_BinaryGameStateVector(tempBinaryGameStateVector, &pOutNewGameState->pValueArray[0]);
					pAdditionalEvaluationNeuronArray[movementCounter].Add_TrainingExample(tempBinaryGameStateVector);
					pAdditionalEvaluationNeuronArray[movementCounter].Calculate_Dendrite_Factors_From_CentroidValues(0.5f, 0.025f, 4);
				}
			}

			Add_To_Log(0, "---movementCounter", movementCounter);
			Add_To_Log(0, "---activationValue 0");
		}
	}
}


void Test_LearningPlayer2(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool *pGameStatePool, int32_t numTestGameStatesMaxPerDepthLayer, int32_t maxSearchDepth, int32_t movementCounter, CSingleRecognitionNeuronEnsemble *pGameStateRecognitionNeuronEnsembleArray, CSimpleNeuron *pAdditionalEvaluationNeuronArray)
{
	//Add_To_Log(0, "TotalMovementCounter", movementCounter);
	//movementCounter /= 2;
	//Add_To_Log(0, "Player2MovementCounter", movementCounter);

	pGameStatePool->Stop_Using_AllGameStateObjects();

	pOutNewGameState->Clone_GameStateValues(pInActualGameState);

	int8_t *pActualGameStateValueArray = &pInActualGameState->pValueArray[0];

	int32_t moveCounter = 0;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
		{
			if (Check_PossiblePlayer2CloneMove(i, pActualGameStateValueArray) == true)
			{
				// next test move:

				int32_t ixNew = i % ConstGameBoardSizePerDir;
				int32_t iyNew = i / ConstGameBoardSizePerDir;

				CGameStateValues* pGameStateObject = nullptr;
				int32_t GameStateObjectID = -1;

				if (pGameStatePool->Get_UnusedGameStateObject(0, &pGameStateObject, &GameStateObjectID) == false)
				{
					goto TestMoveGenerationCompleted;
				}

				pGameStateObject->Clone_GameStateValues(pInActualGameState);

				// test move:
				Make_Player2CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
				pGameStateObject->PlayerID = 1;
				pGameStateObject->Use_As_Minimizer();
				moveCounter++;

				if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
				{
					goto Depth0_TestMoveGenerationCompleted;
				}
			}
		}
		else if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
		{
			int32_t ixOld = i % ConstGameBoardSizePerDir;
			int32_t iyOld = i / ConstGameBoardSizePerDir;

			int32_t ixMin = max(0, ixOld - 2);
			int32_t iyMin = max(0, iyOld - 2);

			int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
			int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

			for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
			{
				for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
				{
					// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
					if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
					{
						continue;
					}

					if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
					{
						// macht ein Sprung-Z�ge Sinn?
						{
							int32_t ixMin = max(0, ixNew - 1);
							int32_t iyMin = max(0, iyNew - 1);

							int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
							int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

							bool badMoveDecision = false;
							bool isolatedPos = true;

							int32_t iiy;
							int8_t gameStateValue;

							for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
							{
								iiy = ConstGameBoardSizePerDir * iy;

								for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
								{
									gameStateValue = pActualGameStateValueArray[ix + iiy];

									if (gameStateValue == ConstGameBoard_Player2)
									{
										isolatedPos = false;
										badMoveDecision = true;
										break;
									}
									if (gameStateValue != ConstGameBoard_Empty)
									{
										isolatedPos = false;
									}
								}

								if (badMoveDecision == true)
								{
									break;
								}

							}

							if (badMoveDecision == true || isolatedPos == true)
							{
								continue;
							}
						} // end of macht ein Sprung-Z�ge Sinn?


						  // next test move:

						CGameStateValues* pGameStateObject = nullptr;
						int32_t GameStateObjectID = -1;

						if (pGameStatePool->Get_UnusedGameStateObject(0, &pGameStateObject, &GameStateObjectID) == false)
						{
							goto TestMoveGenerationCompleted;
						}

						pGameStateObject->Clone_GameStateValues(pInActualGameState);

						// test move:
						Make_Player2Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
						pGameStateObject->PlayerID = 1;
						pGameStateObject->Use_As_Minimizer();
						moveCounter++;

						if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
						{
							goto Depth0_TestMoveGenerationCompleted;
						}
					}
				}
			}
		} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
	} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

Depth0_TestMoveGenerationCompleted:;

	if (maxSearchDepth < 1)
	{
		goto TestMoveGenerationCompleted;
	}

	CGameStateValues* pActualGameState = nullptr;
	pActualGameStateValueArray = nullptr;
	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	CSimpleLinkedListManager *pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[0];
	int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	int32_t id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer1CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(1, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player1CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
					pGameStateObject->PlayerID = 0;
					pGameStateObject->Use_As_Maximizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth1_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player1)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?

							  // next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(1, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player1Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
							pGameStateObject->PlayerID = 0;
							pGameStateObject->Use_As_Maximizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth1_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth1_TestMoveGenerationCompleted:;

	if (maxSearchDepth < 2)
	{
		goto TestMoveGenerationCompleted;
	}

	pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[1];
	NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer2CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(2, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player2CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
					pGameStateObject->PlayerID = 1;
					pGameStateObject->Use_As_Minimizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth2_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player2)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?

							  // next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(2, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player2Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
							pGameStateObject->PlayerID = 1;
							pGameStateObject->Use_As_Minimizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth2_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth2_TestMoveGenerationCompleted:;

	if (maxSearchDepth < 3)
	{
		goto TestMoveGenerationCompleted;
	}

	pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[2];
	NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer1CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(3, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player1CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
					pGameStateObject->PlayerID = 0;
					pGameStateObject->Use_As_Maximizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth3_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player1)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?

							  // next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(3, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player1Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
							pGameStateObject->PlayerID = 0;
							pGameStateObject->Use_As_Maximizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth3_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth3_TestMoveGenerationCompleted:;

	if (maxSearchDepth < 4)
	{
		goto TestMoveGenerationCompleted;
	}

	pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[3];
	NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer2CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(4, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player2CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
					pGameStateObject->PlayerID = 1;
					pGameStateObject->Use_As_Minimizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth4_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player2)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?

							  // next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(4, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player2Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
							pGameStateObject->PlayerID = 1;
							pGameStateObject->Use_As_Minimizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth4_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth4_TestMoveGenerationCompleted:;



TestMoveGenerationCompleted:;

	Evaluate_LeafGameStates_Player2View(pGameStatePool);
	Backpropagate_MinimaxIntegerEvaluationValues(pGameStatePool);


	pGameStatePool->Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID);

	//int32_t Player1Score, Player2Score;
	//Calculate_Score(&Player1Score, &Player2Score, &pGameStateObject->pValueArray[0]);
	//Add_To_Log(0, "BestPlayer1Score", Player1Score);
	//Add_To_Log(0, "BestPlayer2Score", Player2Score);
	//Add_To_Log(0, "BestEval", pGameStateObject->iEvaluation);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

	if (movementCounter < ConstNumGameStateRecognitionNeuronEnsembles)
	{
		Copy_GameData_Into_MemoryVector(tempMemoryVector, &pOutNewGameState->pValueArray[0]);

		if (pGameStateRecognitionNeuronEnsembleArray[movementCounter].Set_AdditionalMemoryValues(tempMemoryVector) == true)
		{
			if (pAdditionalEvaluationNeuronArray != nullptr)
			{
				Copy_GameData_Into_BinaryGameStateVector(tempBinaryGameStateVector, &pOutNewGameState->pValueArray[0]);

				pAdditionalEvaluationNeuronArray[movementCounter].Add_TrainingExample(tempBinaryGameStateVector);
				pAdditionalEvaluationNeuronArray[movementCounter].Calculate_Dendrite_Factors_From_CentroidValues(0.5f, 0.025f, 4);
			}
		}
	}
	else
	{
		Add_To_Log(0, "no learning!!!");
	}
}


