#include <iostream>
#include "Graph.h"
//#include "ConsoleHelperFunctions.h"
//#include "MathInlineFunctions.h"
//#include "SparseVectorMatrix.h"
//#include "Clustering.h"
//#include "GeneticAlgorithms.h"

using namespace std;
//using namespace HelperStuff;

#define KEYDOWN(vk_code) ((GetAsyncKeyState(vk_code) & 0x8000) ? 1 : 0)
#define KEYUP(vk_code)   ((GetAsyncKeyState(vk_code) & 0x8000) ? 0 : 1)

static constexpr int32_t NumSurfaceMapElementsPerDir = 7;
static constexpr int32_t NumSurfaceMapElements = NumSurfaceMapElementsPerDir * NumSurfaceMapElementsPerDir;
static constexpr int32_t NumSurfaceMapElementsPerDirMinus1 = NumSurfaceMapElementsPerDir - 1;

static constexpr int32_t NumCities_TSP = 12;
static constexpr int32_t NumCities_TSP_Plus1 = NumCities_TSP + 1;
static constexpr int32_t NumCities_TSP_Minus1 = NumCities_TSP - 1;
static constexpr int32_t NumCities_TSP_Minus2 = NumCities_TSP - 2;
static constexpr int32_t NumCities_TSP_Sq = NumCities_TSP* NumCities_TSP;

static void Output_SurfaceMapData(char* pData)
{
	for (int32_t iy = 0; iy < NumSurfaceMapElementsPerDir; iy++)
	{
		int32_t iiy = iy * NumSurfaceMapElementsPerDir;

		for (int32_t ix = 0; ix < NumSurfaceMapElementsPerDir; ix++)
		{
			int32_t id = ix + iiy;
			cout << pData[id] << " ";
		}

		cout << endl;
	}

	cout << endl << endl;
}

static void Set_SurfaceMapData(char* pOutData, int32_t ix, int32_t iy, char sign)
{
	ix = max(0, ix);
	iy = max(0, iy);

	ix = min(NumSurfaceMapElementsPerDirMinus1, ix);
	iy = min(NumSurfaceMapElementsPerDirMinus1, iy);

	int32_t id = ix + iy * NumSurfaceMapElementsPerDir;
	pOutData[id] = sign;
}

static void Init_SurfaceMap(char* pOutData, char sign)
{
	uint32_t ix, iy, id;

	for (iy = 0; iy < NumSurfaceMapElementsPerDir; iy++)
	{
		for (ix = 0; ix < NumSurfaceMapElementsPerDir; ix++)
		{
			id = ix + iy * NumSurfaceMapElementsPerDir;
			pOutData[id] = sign;
		}
	}
}



typedef void(*pTSPSwarmAgentPathGeneration)(int32_t *pInOutPath, int32_t numOfCities, CRandomNumbersWithoutRepetition *pRandomNumbersWithoutRepetition, CRandomNumbersNN *pRandomNumbers, void *pInOutParam);

struct CTSP_Parameters
{
	float* pDistanceValueArray = nullptr;
	float *pEvaluationValueArray = nullptr;
	int32_t* pVisitsNumberArray = nullptr;

	int32_t MinNumOfGreedyTrials = 0;
	int32_t MaxNumOfGreedyTrials = 0;

	int32_t MinNumOfExplorationTrials = 0;
	int32_t MaxNumOfExplorationTrials = 0;

	int32_t MinNumOfExploitationTrials = 0;
	int32_t MaxNumOfExploitationTrials = 0;
};


class CTSPSwarmAgent
{
public:

	pTSPSwarmAgentPathGeneration pPathGenerationFunc = nullptr;

	void Set_PathGenerationFunc(pTSPSwarmAgentPathGeneration pFunc)
	{
		pPathGenerationFunc = pFunc;
	}

	void Calculate_New_Path(int32_t* pInOutPath, int32_t numOfCities, CRandomNumbersWithoutRepetition* pRandomNumbersWithoutRepetition, CRandomNumbersNN* pRandomNumbers, void* pInOutParam)
	{
		pPathGenerationFunc(pInOutPath, numOfCities, pRandomNumbersWithoutRepetition, pRandomNumbers, pInOutParam);
	}
};

void Random_PathGeneration(int32_t* pInOutPath, int32_t numOfCities, CRandomNumbersWithoutRepetition* pRandomNumbersWithoutRepetition, CRandomNumbersNN* pRandomNumbers, void* pInOutParam)
{
	pRandomNumbersWithoutRepetition->Reset_Numbers();

	for (int32_t i = 1; i < numOfCities; i++)
	{
		pInOutPath[i] = pRandomNumbersWithoutRepetition->Get_Number();
	}
}

void Random_PathGenerationExt(int32_t* pInOutPath, int32_t numOfCities, CRandomNumbersWithoutRepetition* pRandomNumbersWithoutRepetition, CRandomNumbersNN* pRandomNumbers, void* pInOutParam)
{
	CTSP_Parameters* pParameters = static_cast<CTSP_Parameters*>(pInOutParam);

	float* pEvaluationValueArray = pParameters->pEvaluationValueArray;
	float* pDistanceValueArray = pParameters->pDistanceValueArray;
	int32_t* pVisitsNumberArray = pParameters->pVisitsNumberArray;

	pRandomNumbersWithoutRepetition->Reset_Numbers();

	for (int32_t i = 1; i < numOfCities; i++)
	{
		pInOutPath[i] = pRandomNumbersWithoutRepetition->Get_Number();
	}

	//---------------------------------------------

	float pathDist = 0.0f;

	for (int32_t i = 1; i < numOfCities; i++)
	{
		int32_t id = pInOutPath[i - 1] + numOfCities * pInOutPath[i];
		//int32_t id = pInOutPath[i] + numOfCities * pInOutPath[i - 1];
		pathDist += pDistanceValueArray[id];
	};

	int32_t id = pInOutPath[numOfCities - 1] + numOfCities * pInOutPath[0];
	//int32_t id = pInOutPath[0] + numOfCities * pInOutPath[numOfCities - 1];
	pathDist += pDistanceValueArray[id];

	//---------------------------------------------

	for (int32_t i = 1; i < numOfCities; i++)
	{
		int32_t id = pInOutPath[i - 1] + numOfCities * pInOutPath[i];

		pVisitsNumberArray[i] += 1;

		pEvaluationValueArray[id] = max(pEvaluationValueArray[id], 1.0f / pathDist);
	}

	id = pInOutPath[numOfCities - 1] + numOfCities * pInOutPath[0];

	pVisitsNumberArray[id] += 1;

	pEvaluationValueArray[id] = max(pEvaluationValueArray[id], 1.0f / pathDist);
}

void Greedy_PathGeneration(int32_t* pInOutPath, int32_t numOfCities, CRandomNumbersWithoutRepetition* pRandomNumbersWithoutRepetition, CRandomNumbersNN* pRandomNumbers, void* pInOutParam)
{
	CTSP_Parameters* pParameters = static_cast<CTSP_Parameters*>(pInOutParam);

	int32_t MinNumOfGreedyTrials = pParameters->MinNumOfGreedyTrials;
	int32_t MaxNumOfGreedyTrials = pParameters->MaxNumOfGreedyTrials;

	float* pDistanceValueArray = pParameters->pDistanceValueArray;

	int32_t numOfGreedyTrials = pRandomNumbers->Get_IntegerNumber2(MinNumOfGreedyTrials, MaxNumOfGreedyTrials);

	pRandomNumbersWithoutRepetition->Reset_Numbers();

	for (int32_t i = 1; i < numOfCities; i++)
	{
		int32_t lastCityID = pInOutPath[i - 1];
		int32_t bestPossibleNextCityID = pRandomNumbersWithoutRepetition->Get_Number();

		int32_t id = lastCityID + numOfCities * bestPossibleNextCityID;

		float shortestDist = pDistanceValueArray[id];

		pRandomNumbersWithoutRepetition->Undo_GetOrSelectNumber();


		for (int32_t j = 0; j < numOfGreedyTrials; j++)
		{
			int32_t possibleNextCityID = pRandomNumbersWithoutRepetition->Get_Number();

			int32_t id = lastCityID + numOfCities * possibleNextCityID;

			float dist = pDistanceValueArray[id];

			if (dist < shortestDist)
			{
				shortestDist = dist;
				bestPossibleNextCityID = possibleNextCityID;
			}

			pRandomNumbersWithoutRepetition->Undo_GetOrSelectNumber();
		}

		//cout << shortestDist << " (" << bestPossibleNextCityID << ")" << endl;

		pRandomNumbersWithoutRepetition->Select_Number(bestPossibleNextCityID);
		pInOutPath[i] = bestPossibleNextCityID;
	} // end of for (int32_t i = 1; i < numOfCities; i++)
}

void Greedy_PathGenerationExt(int32_t* pInOutPath, int32_t numOfCities, CRandomNumbersWithoutRepetition* pRandomNumbersWithoutRepetition, CRandomNumbersNN* pRandomNumbers, void* pInOutParam)
{
	CTSP_Parameters* pParameters = static_cast<CTSP_Parameters*>(pInOutParam);

	int32_t MinNumOfGreedyTrials = pParameters->MinNumOfGreedyTrials;
	int32_t MaxNumOfGreedyTrials = pParameters->MaxNumOfGreedyTrials;

	float* pEvaluationValueArray = pParameters->pEvaluationValueArray;
	float* pDistanceValueArray = pParameters->pDistanceValueArray;
	int32_t* pVisitsNumberArray = pParameters->pVisitsNumberArray;

	int32_t numOfGreedyTrials = pRandomNumbers->Get_IntegerNumber2(MinNumOfGreedyTrials, MaxNumOfGreedyTrials);

	pRandomNumbersWithoutRepetition->Reset_Numbers();

	for (int32_t i = 1; i < numOfCities; i++)
	{
		int32_t lastCityID = pInOutPath[i - 1];
		int32_t bestPossibleNextCityID = pRandomNumbersWithoutRepetition->Get_Number();

		int32_t id = lastCityID + numOfCities * bestPossibleNextCityID;

		float shortestDist = pDistanceValueArray[id];

		pRandomNumbersWithoutRepetition->Undo_GetOrSelectNumber();


		for (int32_t j = 0; j < numOfGreedyTrials; j++)
		{
			int32_t possibleNextCityID = pRandomNumbersWithoutRepetition->Get_Number();

			int32_t id = lastCityID + numOfCities * possibleNextCityID;

			float dist = pDistanceValueArray[id];

			if (dist < shortestDist)
			{
				shortestDist = dist;
				bestPossibleNextCityID = possibleNextCityID;
			}

			pRandomNumbersWithoutRepetition->Undo_GetOrSelectNumber();
		}

		//cout << shortestDist << " (" << bestPossibleNextCityID << ")" << endl;

		pRandomNumbersWithoutRepetition->Select_Number(bestPossibleNextCityID);
		pInOutPath[i] = bestPossibleNextCityID;
	} // end of for (int32_t i = 1; i < numOfCities; i++)

	//---------------------------------------------

	float pathDist = 0.0f;

	for (int32_t i = 1; i < numOfCities; i++)
	{
		int32_t id = pInOutPath[i - 1] + numOfCities * pInOutPath[i];
		//int32_t id = pInOutPath[i] + numOfCities * pInOutPath[i - 1];
		pathDist += pDistanceValueArray[id];
	};

	int32_t id = pInOutPath[numOfCities - 1] + numOfCities * pInOutPath[0];
	//int32_t id = pInOutPath[0] + numOfCities * pInOutPath[numOfCities - 1];
	pathDist += pDistanceValueArray[id];

	//---------------------------------------------

	for (int32_t i = 1; i < numOfCities; i++)
	{
		int32_t id = pInOutPath[i - 1] + numOfCities * pInOutPath[i];

		pVisitsNumberArray[i] += 1;

		pEvaluationValueArray[id] = max(pEvaluationValueArray[id], 1.0f / pathDist);
	}

	id = pInOutPath[numOfCities - 1] + numOfCities * pInOutPath[0];

	pVisitsNumberArray[id] += 1;

	pEvaluationValueArray[id] = max(pEvaluationValueArray[id], 1.0f / pathDist);
}

void Exploitative_PathGeneration(int32_t* pInOutPath, int32_t numOfCities, CRandomNumbersWithoutRepetition* pRandomNumbersWithoutRepetition, CRandomNumbersNN* pRandomNumbers, void* pInOutParam)
{
	CTSP_Parameters* pParameters = static_cast<CTSP_Parameters*>(pInOutParam);

	int32_t MinNumOfExploitationTrials = pParameters->MinNumOfExploitationTrials;
	int32_t MaxNumOfExploitationTrials = pParameters->MaxNumOfExploitationTrials;

	float* pEvaluationValueArray = pParameters->pEvaluationValueArray;

	int32_t numOfExploitationTrials = pRandomNumbers->Get_IntegerNumber2(MinNumOfExploitationTrials, MaxNumOfExploitationTrials);

	pRandomNumbersWithoutRepetition->Reset_Numbers();

	for (int32_t i = 1; i < numOfCities; i++)
	{
		int32_t lastCityID = pInOutPath[i - 1];
		int32_t bestPossibleNextCityID = pRandomNumbersWithoutRepetition->Get_Number();

		int32_t id = lastCityID + numOfCities * bestPossibleNextCityID;

		float maxEvaluationValue = pEvaluationValueArray[id];

		pRandomNumbersWithoutRepetition->Undo_GetOrSelectNumber();


		for (int32_t j = 0; j < numOfExploitationTrials; j++)
		{
			int32_t possibleNextCityID = pRandomNumbersWithoutRepetition->Get_Number();

			int32_t id = lastCityID + numOfCities * possibleNextCityID;

			float evaluationValue = pEvaluationValueArray[id];

			if (evaluationValue > maxEvaluationValue)
			{
				maxEvaluationValue = evaluationValue;
				bestPossibleNextCityID = possibleNextCityID;
			}

			pRandomNumbersWithoutRepetition->Undo_GetOrSelectNumber();
		}

		pRandomNumbersWithoutRepetition->Select_Number(bestPossibleNextCityID);
		pInOutPath[i] = bestPossibleNextCityID;
	} // end of for (int32_t i = 1; i < numOfCities; i++)
}

void Exploitative_PathGenerationExt(int32_t* pInOutPath, int32_t numOfCities, CRandomNumbersWithoutRepetition* pRandomNumbersWithoutRepetition, CRandomNumbersNN* pRandomNumbers, void* pInOutParam)
{
	CTSP_Parameters* pParameters = static_cast<CTSP_Parameters*>(pInOutParam);

	int32_t MinNumOfExploitationTrials = pParameters->MinNumOfExploitationTrials;
	int32_t MaxNumOfExploitationTrials = pParameters->MaxNumOfExploitationTrials;

	float* pEvaluationValueArray = pParameters->pEvaluationValueArray;
	float* pDistanceValueArray = pParameters->pDistanceValueArray;
	int32_t* pVisitsNumberArray = pParameters->pVisitsNumberArray;

	int32_t numOfExploitationTrials = pRandomNumbers->Get_IntegerNumber2(MinNumOfExploitationTrials, MaxNumOfExploitationTrials);

	pRandomNumbersWithoutRepetition->Reset_Numbers();

	for (int32_t i = 1; i < numOfCities; i++)
	{
		int32_t lastCityID = pInOutPath[i - 1];
		int32_t bestPossibleNextCityID = pRandomNumbersWithoutRepetition->Get_Number();

		int32_t id = lastCityID + numOfCities * bestPossibleNextCityID;

		float maxEvaluationValue = pEvaluationValueArray[id];

		pRandomNumbersWithoutRepetition->Undo_GetOrSelectNumber();


		for (int32_t j = 0; j < numOfExploitationTrials; j++)
		{
			int32_t possibleNextCityID = pRandomNumbersWithoutRepetition->Get_Number();

			int32_t id = lastCityID + numOfCities * possibleNextCityID;

			float evaluationValue = pEvaluationValueArray[id];

			if (evaluationValue > maxEvaluationValue)
			{
				maxEvaluationValue = evaluationValue;
				bestPossibleNextCityID = possibleNextCityID;
			}

			pRandomNumbersWithoutRepetition->Undo_GetOrSelectNumber();
		}

		pRandomNumbersWithoutRepetition->Select_Number(bestPossibleNextCityID);
		pInOutPath[i] = bestPossibleNextCityID;
	} // end of for (int32_t i = 1; i < numOfCities; i++)

	//---------------------------------------------

	float pathDist = 0.0f;

	for (int32_t i = 1; i < numOfCities; i++)
	{
		int32_t id = pInOutPath[i - 1] + numOfCities * pInOutPath[i];
		//int32_t id = pInOutPath[i] + numOfCities * pInOutPath[i - 1];
		pathDist += pDistanceValueArray[id];
	};

	int32_t id = pInOutPath[numOfCities - 1] + numOfCities * pInOutPath[0];
	//int32_t id = pInOutPath[0] + numOfCities * pInOutPath[numOfCities - 1];
	pathDist += pDistanceValueArray[id];

	//---------------------------------------------

	for (int32_t i = 1; i < numOfCities; i++)
	{
		int32_t id = pInOutPath[i - 1] + numOfCities * pInOutPath[i];

		pVisitsNumberArray[i] += 1;

		pEvaluationValueArray[id] = max(pEvaluationValueArray[id], 1.0f / pathDist);
	}

	id = pInOutPath[numOfCities - 1] + numOfCities * pInOutPath[0];

	pVisitsNumberArray[id] += 1;

	pEvaluationValueArray[id] = max(pEvaluationValueArray[id], 1.0f / pathDist);
}

void Follow_BestPath(int32_t* pInOutPath, int32_t numOfCities, CRandomNumbersWithoutRepetition* pRandomNumbersWithoutRepetition, CRandomNumbersNN* pRandomNumbers, void* pInOutParam)
{
	static int32_t InterimTravelDestinationList[100]; // 100: max number of cities 

	CTSP_Parameters* pParameters = static_cast<CTSP_Parameters*>(pInOutParam);

	float *pEvaluationValueArray = pParameters->pEvaluationValueArray;

	pRandomNumbersWithoutRepetition->Reset_Numbers();

	for (int32_t i = 1; i < numOfCities; i++)
	{
		int32_t lastCityID = pInOutPath[i - 1];

		int32_t num = pRandomNumbersWithoutRepetition->Get_ListOfPossibleNumbers(InterimTravelDestinationList);

		float maxEvaluationValue = -0.1f;
		int32_t belongingCityID = 0;

		for (int32_t j = 0; j < num; j++)
		{
			int32_t possibleNextCityID = InterimTravelDestinationList[j];

			int32_t id = lastCityID + numOfCities * possibleNextCityID;

			float evaluationValue = pEvaluationValueArray[id];

			if (evaluationValue > maxEvaluationValue)
			{
				maxEvaluationValue = evaluationValue;
				belongingCityID = possibleNextCityID;
			}
		}

		pInOutPath[i] = belongingCityID;
		pRandomNumbersWithoutRepetition->Select_Number(belongingCityID);

	} // end of for (int32_t i = 1; i < numOfCities; i++)

}


void Exploratory_PathGeneration(int32_t* pInOutPath, int32_t numOfCities, CRandomNumbersWithoutRepetition* pRandomNumbersWithoutRepetition, CRandomNumbersNN* pRandomNumbers, void* pInOutParam)
{
	CTSP_Parameters* pParameters = static_cast<CTSP_Parameters*>(pInOutParam);
	
	int32_t MinNumOfExplorationTrials = pParameters->MinNumOfExplorationTrials;
	int32_t MaxNumOfExplorationTrials = pParameters->MaxNumOfExplorationTrials;

	int32_t* pVisitsNumberArray = pParameters->pVisitsNumberArray;

	int32_t numOfExplorationTrials = pRandomNumbers->Get_IntegerNumber2(MinNumOfExplorationTrials, MaxNumOfExplorationTrials);

	pRandomNumbersWithoutRepetition->Reset_Numbers();

	for (int32_t i = 1; i < NumCities_TSP; i++)
	{
		int32_t lastCityID = pInOutPath[i - 1];
		int32_t bestPossibleNextCityID = pRandomNumbersWithoutRepetition->Get_Number();

		int32_t id = lastCityID + numOfCities * bestPossibleNextCityID;

		int32_t minVisitsNumber = pVisitsNumberArray[id];

		pRandomNumbersWithoutRepetition->Undo_GetOrSelectNumber();


		for (int32_t j = 0; j < numOfExplorationTrials; j++)
		{
			int32_t possibleNextCityID = pRandomNumbersWithoutRepetition->Get_Number();

			int32_t id = lastCityID + numOfCities * possibleNextCityID;

			int32_t visitsNumber = pVisitsNumberArray[id];

			if (visitsNumber < minVisitsNumber)
			{
				minVisitsNumber = visitsNumber;
				bestPossibleNextCityID = possibleNextCityID;
			}

			pRandomNumbersWithoutRepetition->Undo_GetOrSelectNumber();
		}

		pRandomNumbersWithoutRepetition->Select_Number(bestPossibleNextCityID);
		pInOutPath[i] = bestPossibleNextCityID;
	}
}

void Exploratory_PathGenerationExt(int32_t* pInOutPath, int32_t numOfCities, CRandomNumbersWithoutRepetition* pRandomNumbersWithoutRepetition, CRandomNumbersNN* pRandomNumbers, void* pInOutParam)
{
	CTSP_Parameters* pParameters = static_cast<CTSP_Parameters*>(pInOutParam);

	int32_t MinNumOfExplorationTrials = pParameters->MinNumOfExplorationTrials;
	int32_t MaxNumOfExplorationTrials = pParameters->MaxNumOfExplorationTrials;

	float* pEvaluationValueArray = pParameters->pEvaluationValueArray;
	float* pDistanceValueArray = pParameters->pDistanceValueArray;
	int32_t* pVisitsNumberArray = pParameters->pVisitsNumberArray;

	int32_t numOfExplorationTrials = pRandomNumbers->Get_IntegerNumber2(MinNumOfExplorationTrials, MaxNumOfExplorationTrials);

	pRandomNumbersWithoutRepetition->Reset_Numbers();

	for (int32_t i = 1; i < NumCities_TSP; i++)
	{
		int32_t lastCityID = pInOutPath[i - 1];
		int32_t bestPossibleNextCityID = pRandomNumbersWithoutRepetition->Get_Number();

		int32_t id = lastCityID + numOfCities * bestPossibleNextCityID;

		int32_t minVisitsNumber = pVisitsNumberArray[id];

		pRandomNumbersWithoutRepetition->Undo_GetOrSelectNumber();


		for (int32_t j = 0; j < numOfExplorationTrials; j++)
		{
			int32_t possibleNextCityID = pRandomNumbersWithoutRepetition->Get_Number();

			int32_t id = lastCityID + numOfCities * possibleNextCityID;

			int32_t visitsNumber = pVisitsNumberArray[id];

			if (visitsNumber < minVisitsNumber)
			{
				minVisitsNumber = visitsNumber;
				bestPossibleNextCityID = possibleNextCityID;
			}

			pRandomNumbersWithoutRepetition->Undo_GetOrSelectNumber();
		}

		pRandomNumbersWithoutRepetition->Select_Number(bestPossibleNextCityID);
		pInOutPath[i] = bestPossibleNextCityID;
	}

	//---------------------------------------------

	float pathDist = 0.0f;

	for (int32_t i = 1; i < numOfCities; i++)
	{
		int32_t id = pInOutPath[i - 1] + numOfCities * pInOutPath[i];
		//int32_t id = pInOutPath[i] + numOfCities * pInOutPath[i - 1];
		pathDist += pDistanceValueArray[id];
	};

	int32_t id = pInOutPath[numOfCities - 1] + numOfCities * pInOutPath[0];
	//int32_t id = pInOutPath[0] + numOfCities * pInOutPath[numOfCities - 1];
	pathDist += pDistanceValueArray[id];

	//---------------------------------------------

	for (int32_t i = 1; i < numOfCities; i++)
	{
		int32_t id = pInOutPath[i - 1] + numOfCities * pInOutPath[i];

		pVisitsNumberArray[i] += 1;

		pEvaluationValueArray[id] = max(pEvaluationValueArray[id], 1.0f / pathDist);
	}

	id = pInOutPath[numOfCities - 1] + numOfCities * pInOutPath[0];

	pVisitsNumberArray[id] += 1;

	pEvaluationValueArray[id] = max(pEvaluationValueArray[id], 1.0f / pathDist);
}


/*

// random path generation:

int main(void)
{
	CRandomNumbersWithoutRepetition RandomDestinationNumbers;
	RandomDestinationNumbers.Init_Numbers(NumCities_TSP - 1);

	CRandomNumbersNN  RandomNumbers;

	// Visualisierung der einzelnen St�dte:

	static char SurfaceMap[NumSurfaceMapElements];

	Init_SurfaceMap(SurfaceMap, '*');

	Set_SurfaceMapData(SurfaceMap, 2, 0, '0');
	Set_SurfaceMapData(SurfaceMap, 4, 0, '1');
	Set_SurfaceMapData(SurfaceMap, 0, 1, '2');
	Set_SurfaceMapData(SurfaceMap, 4, 2, '3');
	Set_SurfaceMapData(SurfaceMap, 0, 4, '4');
	Set_SurfaceMapData(SurfaceMap, 2, 3, '5');
	Set_SurfaceMapData(SurfaceMap, 3, 4, '6');
	Set_SurfaceMapData(SurfaceMap, 5, 5, '7');
	Set_SurfaceMapData(SurfaceMap, 6, 3, '8');
	Set_SurfaceMapData(SurfaceMap, 1, 6, '9');
	Set_SurfaceMapData(SurfaceMap, 6, 1, 'A');
	Set_SurfaceMapData(SurfaceMap, 3, 6, 'B');


	Output_SurfaceMapData(SurfaceMap);

	// Visualisierung der einzelnen St�dte abgeschlossen

	static CGraphNode GraphNodeArray[NumCities_TSP_Plus1];

	GraphNodeArray[0].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[0].Set_Position(2.0f, 0.0f, 0.0f);
	GraphNodeArray[1].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[1].Set_Position(4.0f, 0.0f, 0.0f);
	GraphNodeArray[2].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[2].Set_Position(0.0f, 1.0f, 0.0f);
	GraphNodeArray[3].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[3].Set_Position(4.0f, 2.0f, 0.0f);
	GraphNodeArray[4].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[4].Set_Position(0.0f, 4.0f, 0.0f);
	GraphNodeArray[5].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[5].Set_Position(2.0f, 3.0f, 0.0f);
	GraphNodeArray[6].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[6].Set_Position(3.0f, 4.0f, 0.0f);
	GraphNodeArray[7].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[7].Set_Position(5.0f, 5.0f, 0.0f);
	GraphNodeArray[8].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[8].Set_Position(6.0f, 3.0f, 0.0f);
	GraphNodeArray[9].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[9].Set_Position(1.0f, 6.0f, 0.0f);
	GraphNodeArray[10].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[10].Set_Position(6.0f, 1.0f, 0.0f);
	GraphNodeArray[11].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[11].Set_Position(3.0f, 6.0f, 0.0f);
	GraphNodeArray[12].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[12].Set_Position(2.0f, 0.0f, 0.0f);


	static float DistanceValueArray[NumCities_TSP_Sq];

	for (int32_t i = 0; i < NumCities_TSP_Sq; i++)
	{
		DistanceValueArray[i] = 0.0f;
	}

	for (int32_t sourceWaypointID = 0; sourceWaypointID < NumCities_TSP; sourceWaypointID++)
	{
		int32_t _sourceWaypointID = NumCities_TSP * sourceWaypointID;

		for (int32_t destinationWaypointID = 0; destinationWaypointID < NumCities_TSP; destinationWaypointID++)
		{
			if (sourceWaypointID == destinationWaypointID)
			{
				continue;
			}

			//float dist = GraphNodeArray[sourceWaypointID].Get_Distance_to_Other_Node(destinationWaypointID);
			float dist = GraphNodeArray[sourceWaypointID].Get_2DimDistance_to_Other_Node(destinationWaypointID);

			DistanceValueArray[destinationWaypointID + _sourceWaypointID] = dist;
			DistanceValueArray[sourceWaypointID + NumCities_TSP * destinationWaypointID] = dist;
		}
	}

	CTSP_Parameters TSP_Parameters;

	
	TSP_Parameters.pDistanceValueArray = DistanceValueArray;
	TSP_Parameters.MinNumOfGreedyTrials = 6;
	TSP_Parameters.MaxNumOfGreedyTrials = 20;


	static int32_t Path[NumCities_TSP_Plus1];
	// Anfang der Rundreise:
	Path[0] = 0;
	// Ziel der Rundreise:
	Path[NumCities_TSP] = 0;

	RandomDestinationNumbers.Reset_Numbers();

	for (int32_t i = 1; i < NumCities_TSP; i++)
	{
		Path[i] = RandomDestinationNumbers.Get_Number();
	}

	float pathDistSq = GraphNodeArray[0].Calculate_PathDistSq(Path, NumCities_TSP_Plus1);
	cout << "pathDistSq: " << pathDistSq << endl;

	
	for (int32_t i = 0; i < NumCities_TSP_Plus1; i++)
	{
		cout << Path[i] << " ";
	}

	cout << endl << endl;
	cout << "bye bye (Press Return)" << endl;
	getchar();

	return 0;
}
*/

/*

int main(void)
{
	CRandomNumbersWithoutRepetition RandomDestinationNumbers;
	RandomDestinationNumbers.Init_Numbers(NumCities_TSP - 1);

	CRandomNumbersNN  RandomNumbers;

	// Visualisierung der einzelnen St�dte:

	static char SurfaceMap[NumSurfaceMapElements];

	Init_SurfaceMap(SurfaceMap, '*');

	Set_SurfaceMapData(SurfaceMap, 2, 0, '0');
	Set_SurfaceMapData(SurfaceMap, 4, 0, '1');
	Set_SurfaceMapData(SurfaceMap, 0, 1, '2');
	Set_SurfaceMapData(SurfaceMap, 4, 2, '3');
	Set_SurfaceMapData(SurfaceMap, 0, 4, '4');
	Set_SurfaceMapData(SurfaceMap, 2, 3, '5');
	Set_SurfaceMapData(SurfaceMap, 3, 4, '6');
	Set_SurfaceMapData(SurfaceMap, 5, 5, '7');
	Set_SurfaceMapData(SurfaceMap, 6, 3, '8');
	Set_SurfaceMapData(SurfaceMap, 1, 6, '9');
	Set_SurfaceMapData(SurfaceMap, 6, 1, 'A');
	Set_SurfaceMapData(SurfaceMap, 3, 6, 'B');


	Output_SurfaceMapData(SurfaceMap);

	// Visualisierung der einzelnen St�dte abgeschlossen

	static CGraphNode GraphNodeArray[NumCities_TSP_Plus1];

	GraphNodeArray[0].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[0].Set_Position(2.0f, 0.0f, 0.0f);
	GraphNodeArray[1].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[1].Set_Position(4.0f, 0.0f, 0.0f);
	GraphNodeArray[2].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[2].Set_Position(0.0f, 1.0f, 0.0f);
	GraphNodeArray[3].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[3].Set_Position(4.0f, 2.0f, 0.0f);
	GraphNodeArray[4].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[4].Set_Position(0.0f, 4.0f, 0.0f);
	GraphNodeArray[5].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[5].Set_Position(2.0f, 3.0f, 0.0f);
	GraphNodeArray[6].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[6].Set_Position(3.0f, 4.0f, 0.0f);
	GraphNodeArray[7].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[7].Set_Position(5.0f, 5.0f, 0.0f);
	GraphNodeArray[8].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[8].Set_Position(6.0f, 3.0f, 0.0f);
	GraphNodeArray[9].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[9].Set_Position(1.0f, 6.0f, 0.0f);
	GraphNodeArray[10].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[10].Set_Position(6.0f, 1.0f, 0.0f);
	GraphNodeArray[11].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[11].Set_Position(3.0f, 6.0f, 0.0f);
	GraphNodeArray[12].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[12].Set_Position(2.0f, 0.0f, 0.0f);


	static float DistanceValueArray[NumCities_TSP_Sq];
	static float EvaluationValueArray[NumCities_TSP_Sq];
	static int32_t VisitsNumberArray[NumCities_TSP_Sq];

	for (int32_t i = 0; i < NumCities_TSP_Sq; i++)
	{
		DistanceValueArray[i] = 0.0f;
		EvaluationValueArray[i] = 0.0f;
		VisitsNumberArray[i] = 0;
	}

	for (int32_t sourceWaypointID = 0; sourceWaypointID < NumCities_TSP; sourceWaypointID++)
	{
		int32_t _sourceWaypointID = NumCities_TSP * sourceWaypointID;

		for (int32_t destinationWaypointID = 0; destinationWaypointID < NumCities_TSP; destinationWaypointID++)
		{
			if (sourceWaypointID == destinationWaypointID)
			{
				continue;
			}

			//float dist = GraphNodeArray[sourceWaypointID].Get_Distance_to_Other_Node(destinationWaypointID);
			float dist = GraphNodeArray[sourceWaypointID].Get_2DimDistance_to_Other_Node(destinationWaypointID);

			DistanceValueArray[destinationWaypointID + _sourceWaypointID] = dist;
			DistanceValueArray[sourceWaypointID + NumCities_TSP * destinationWaypointID] = dist;
		}
	}

	


	static int32_t Path[NumCities_TSP_Plus1];
	// Anfang der Rundreise:
	Path[0] = 0;
	// Ziel der Rundreise:
	Path[NumCities_TSP] = 0;

	int32_t NumSimulationStepsMax = 200;

	CTSP_Parameters TSP_Parameters;

	TSP_Parameters.pDistanceValueArray = DistanceValueArray;	
	TSP_Parameters.pEvaluationValueArray = EvaluationValueArray;
	TSP_Parameters.pVisitsNumberArray = VisitsNumberArray;

	TSP_Parameters.MinNumOfGreedyTrials = 6;
	TSP_Parameters.MaxNumOfGreedyTrials = 20;

	TSP_Parameters.MinNumOfExplorationTrials = 6;
	TSP_Parameters.MaxNumOfExplorationTrials = 20;

	TSP_Parameters.MinNumOfExploitationTrials = 6;
	TSP_Parameters.MaxNumOfExploitationTrials = 20;

	CTSPSwarmAgent SwarmAgent;
	//SwarmAgent.Set_PathGenerationFunc(Random_PathGenerationExt);
	//SwarmAgent.Set_PathGenerationFunc(Greedy_PathGenerationExt);
	SwarmAgent.Set_PathGenerationFunc(Exploitative_PathGenerationExt);

	for (int32_t simulationStep = 0; simulationStep < NumSimulationStepsMax; simulationStep++)
	{
		SwarmAgent.Calculate_New_Path(Path, NumCities_TSP, &RandomDestinationNumbers, &RandomNumbers, &TSP_Parameters);
	}

	CTSPSwarmAgent BestSwarmAgent;
	BestSwarmAgent.Set_PathGenerationFunc(Follow_BestPath);
	BestSwarmAgent.Calculate_New_Path(Path, NumCities_TSP, &RandomDestinationNumbers, &RandomNumbers, &TSP_Parameters);

	
	float pathDistSq = GraphNodeArray[0].Calculate_PathDistSq(Path, NumCities_TSP_Plus1);
	cout << "pathDistSq: " << pathDistSq << endl;

	for (int32_t i = 0; i < NumCities_TSP_Plus1; i++)
	{
		cout << Path[i] << " ";
	}
	
	cout << endl << endl;
	cout << "bye bye (Press Return)" << endl;
	getchar();

	return 0;
}
*/






