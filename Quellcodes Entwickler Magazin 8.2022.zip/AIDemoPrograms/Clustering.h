// Schutz vor Mehrfachdeklarationen :

#ifndef _Clustering_H_
#define _Clustering_H_

#pragma warning( disable: 4996)

#include <iostream>

class CNDPoint_InsideCluster
{
public:

	int32_t Size = 0;
	float *pValueArray = nullptr;
	int32_t clusterID = 0;

	float relatedValue = 0.0f;

	CNDPoint_InsideCluster();
	~CNDPoint_InsideCluster();
	
	// Kopierkonstruktor l�schen:
	CNDPoint_InsideCluster(const CNDPoint_InsideCluster  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CNDPoint_InsideCluster & operator=(const CNDPoint_InsideCluster  &originalObject) = delete;

	void Initialize(int32_t size);
	void Reset(void);
};

class C1DPoint_InsideCluster
{
public:

	float x = 0.0f;
	int32_t clusterID = 0;
	float relatedValue = 0.0f;

	void Reset(void);
};

class C2DPoint_InsideCluster
{
public:

	float x = 0.0f;
	float y = 0.0f;
	int32_t clusterID = 0;
	float relatedValue = 0.0f;

	void Reset(void);
};

class C3DPoint_InsideCluster
{
public:

	float x = 0.0f;
	float y = 0.0f;
	float z = 0.0f;
	int32_t clusterID = 0;
	float relatedValue = 0.0f;

	void Reset(void);
};

class CNDClusterCentroid
{
public:

	int32_t centroidID = 0;

	int32_t Size = 0;
	float *pCenterValueArray = nullptr;
	float *pOldCenterValueArray = nullptr;

	bool calculationsCompleted = false;

	// necessary for mean centroid calculation:
	int32_t NumOfSamples = 0;

	float ClusterRadiusSq = 0.0f;
	float SumOfDistancesSq_InsideCluster = 0.0f;

	float RBF_Constant = 1.0f;

	float relatedValue = 0.0f;

	CNDClusterCentroid();
	~CNDClusterCentroid();

	// Kopierkonstruktor l�schen:
	CNDClusterCentroid(const CNDClusterCentroid  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CNDClusterCentroid & operator=(const CNDClusterCentroid  &originalObject) = delete;

	void Initialize(int32_t size);

	void Set_RBF_Constant(float value);

	// RBF_Constant = value * ClusterRadiusSq:
	void Set_ClusterRadiusBased_RBF_Constant(float value);

	void Reset(void);
	void Reset_MeanCentroidCalculations(void);

	bool Calculate_NewCenter(CNDPoint_InsideCluster *pPointArray, int32_t numOfPoints);
	void Add_To_MeanCentroid(CNDClusterCentroid *pCentroid);
	void Set_Centroid(CNDClusterCentroid *pCentroid);

	void Calculate_ClusterRadiusSq(CNDPoint_InsideCluster *pPointArray, int32_t numOfPoints);
	void Calculate_SumOfDistancesSq_InsideCluster(CNDPoint_InsideCluster *pPointArray, int32_t numOfPoints);

	float Calculate_DistanceSq_To_Centroid(CNDPoint_InsideCluster *pPoint);

	// 0.0f to 1.0f (point pos. == centroid pos.):
	float Calculate_RBFValue(CNDPoint_InsideCluster *pPoint);
	// 0.0f to 1.0f (point pos. == centroid pos.):
	float Calculate_ClippedRBFValue(CNDPoint_InsideCluster *pPoint);
};



class C1DClusterCentroid
{
public:

	int32_t centroidID = 0;

	float centerX = 0.0f;
	float centerX_old = 0.0f;

	bool calculationsCompleted = false;

	// necessary for mean centroid calculation:
	int32_t NumOfSamples = 0;

	float ClusterRadiusSq = 0.0f;
	float SumOfDistancesSq_InsideCluster = 0.0f;

	float RBF_Constant = 1.0f;

	float relatedValue = 0.0f;

	void Set_RBF_Constant(float value);

	// RBF_Constant = value * ClusterRadiusSq:
	void Set_ClusterRadiusBased_RBF_Constant(float value);

	void Reset(void);
	void Reset_MeanCentroidCalculations(void);

	void Translate_OriginalCenterPos(float deltaX);
	void Undo_CenterPosTranslation(void);

	bool Calculate_NewCenter(C1DPoint_InsideCluster *pPointArray, int32_t numOfPoints);
	void Add_To_MeanCentroid(C1DClusterCentroid *pCentroid);
	void Set_Centroid(C1DClusterCentroid *pCentroid);

	void Calculate_ClusterRadiusSq(C1DPoint_InsideCluster *pPointArray, int32_t numOfPoints);
	void Calculate_SumOfDistancesSq_InsideCluster(C1DPoint_InsideCluster *pPointArray, int32_t numOfPoints);

	float Calculate_DistanceSq_To_Centroid(C1DPoint_InsideCluster *pPoint);
	float Calculate_DistanceSq_To_Centroid(float x);

	// 0.0f to 1.0f (point pos. == centroid pos.):
	float Calculate_RBFValue(C1DPoint_InsideCluster *pPoint);
	// 0.0f to 1.0f (point pos. == centroid pos.):
	float Calculate_RBFValue(float x);

	// 0.0f to 1.0f (point pos. == centroid pos.):
	float Calculate_ClippedRBFValue(C1DPoint_InsideCluster *pPoint);
	// 0.0f to 1.0f (point pos. == centroid pos.):
	float Calculate_ClippedRBFValue(float x);
};


class C2DClusterCentroid
{
public:

	int32_t centroidID = 0;

	float centerX = 0.0f;
	float centerY = 0.0f;
	float centerX_old = 0.0f;
	float centerY_old = 0.0f;

	bool calculationsCompleted = false;

	// necessary for mean centroid calculation:
	int32_t NumOfSamples = 0;

	float ClusterRadiusSq = 0.0f;
	float SumOfDistancesSq_InsideCluster = 0.0f;

	float RBF_Constant = 1.0f;

	float relatedValue = 0.0f;

	void Set_RBF_Constant(float value);

	// RBF_Constant = value * ClusterRadiusSq:
	void Set_ClusterRadiusBased_RBF_Constant(float value);

	void Reset(void);
	void Reset_MeanCentroidCalculations(void);

	void Translate_OriginalCenterPos(float deltaX, float deltaY);
	void Undo_CenterPosTranslation(void);

	bool Calculate_NewCenter(C2DPoint_InsideCluster *pPointArray, int32_t numOfPoints);
	void Add_To_MeanCentroid(C2DClusterCentroid *pCentroid);
	void Set_Centroid(C2DClusterCentroid *pCentroid);

	void Calculate_ClusterRadiusSq(C2DPoint_InsideCluster *pPointArray, int32_t numOfPoints);
	void Calculate_SumOfDistancesSq_InsideCluster(C2DPoint_InsideCluster *pPointArray, int32_t numOfPoints);

	float Calculate_DistanceSq_To_Centroid(C2DPoint_InsideCluster *pPoint);
	float Calculate_DistanceSq_To_Centroid(float x, float y);

	// 0.0f to 1.0f (point pos. == centroid pos.):
	float Calculate_RBFValue(C2DPoint_InsideCluster *pPoint);
	// 0.0f to 1.0f (point pos. == centroid pos.):
	float Calculate_RBFValue(float x, float y);

	// 0.0f to 1.0f (point pos. == centroid pos.):
	float Calculate_ClippedRBFValue(C2DPoint_InsideCluster *pPoint);
	// 0.0f to 1.0f (point pos. == centroid pos.):
	float Calculate_ClippedRBFValue(float x, float y);
};

class C3DClusterCentroid
{
public:

	int32_t centroidID = 0;

	float centerX = 0.0f;
	float centerY = 0.0f;
	float centerZ = 0.0f;
	float centerX_old = 0.0f;
	float centerY_old = 0.0f;
	float centerZ_old = 0.0f;

	bool calculationsCompleted = false;

	// necessary for mean centroid calculation:
	int32_t NumOfSamples = 0;

	float ClusterRadiusSq = 0.0f;
	float SumOfDistancesSq_InsideCluster = 0.0f;

	float RBF_Constant = 1.0f;

	float relatedValue = 0.0f;

	void Set_RBF_Constant(float value);

	// RBF_Constant = value * ClusterRadiusSq:
	void Set_ClusterRadiusBased_RBF_Constant(float value);

	void Reset(void);
	void Reset_MeanCentroidCalculations(void);

	void Translate_OriginalCenterPos(float deltaX, float deltaY, float deltaZ);
	void Undo_CenterPosTranslation(void);

	bool Calculate_NewCenter(C3DPoint_InsideCluster *pPointArray, int32_t numOfPoints);
	void Add_To_MeanCentroid(C3DClusterCentroid *pCentroid);
	void Set_Centroid(C3DClusterCentroid *pCentroid);

	void Calculate_ClusterRadiusSq(C3DPoint_InsideCluster *pPointArray, int32_t numOfPoints);
	void Calculate_SumOfDistancesSq_InsideCluster(C3DPoint_InsideCluster *pPointArray, int32_t numOfPoints);

	float Calculate_DistanceSq_To_Centroid(C3DPoint_InsideCluster *pPoint);
	float Calculate_DistanceSq_To_Centroid(float x, float y, float z);

	// 0.0f to 1.0f (point pos. == centroid pos.):
	float Calculate_RBFValue(C3DPoint_InsideCluster *pPoint);
	// 0.0f to 1.0f (point pos. == centroid pos.):
	float Calculate_RBFValue(float x, float y, float z);

	// 0.0f to 1.0f (point pos. == centroid pos.):
	float Calculate_ClippedRBFValue(C3DPoint_InsideCluster *pPoint);
	// 0.0f to 1.0f (point pos. == centroid pos.):
	float Calculate_ClippedRBFValue(float x, float y, float z);
};

class CClusterArray_SumOfRBFValues
{
public:

	int32_t NumOfClusters;
	float *pSumOfRBFValuesArray = nullptr;
	int32_t *pBestClusterCounterArray = nullptr;

	CClusterArray_SumOfRBFValues();
	~CClusterArray_SumOfRBFValues();

	// Kopierkonstruktor l�schen:
	CClusterArray_SumOfRBFValues(const CClusterArray_SumOfRBFValues  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CClusterArray_SumOfRBFValues & operator=(const CClusterArray_SumOfRBFValues  &originalObject) = delete;

	void Initialize(int32_t numOfClusters);
	void Reset_Data(void);

	float Get_MinRBFValueSum(void);
	float Get_MaxRBFValueSum(void);

	void Get_MinRBFValueSum_And_BelongingClusterID(float *pOutSum, int32_t *pOutClusterID);
	void Get_MaxRBFValueSum_And_BelongingClusterID(float *pOutSum, int32_t *pOutClusterID);
};

class CClusterPattern
{
public:

	int32_t NumOfIDs_MinPopulatedClusters;
	int32_t NumOfIDs_MaxPopulatedClusters;

	int32_t *pIDList_MinPopulatedClusters = nullptr;
	int32_t *pIDList_MaxPopulatedClusters = nullptr;

	CClusterPattern();
	~CClusterPattern();

	// Kopierkonstruktor l�schen:
	CClusterPattern(const CClusterPattern  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CClusterPattern & operator=(const CClusterPattern  &originalObject) = delete;

	void Initialize_IDList_Of_MinPopulatedClusters(int32_t numOfIDs);
	void Initialize_IDList_Of_MinPopulatedClusters(int32_t numOfIDs, int32_t *pIDList);

	void Initialize_IDList_Of_MaxPopulatedClusters(int32_t numOfIDs);
	void Initialize_IDList_Of_MaxPopulatedClusters(int32_t numOfIDs, int32_t *pIDList);

	bool Identify_Pattern(CClusterArray_SumOfRBFValues *pClusterArray_SumOfRBFValues, float upperThreshold_MinPopulatedClusters, float lowerThreshold_MaxPopulatedClusters);
	bool Identify_Pattern2(CClusterArray_SumOfRBFValues *pClusterArray_SumOfRBFValues, float upperThreshold_MinPopulatedClusters, float lowerThreshold_MaxPopulatedClusters);
};

void Translate_OriginalClusterCenterPositions(C1DClusterCentroid *pInOutCentroidArray, int32_t numOfClusters, float deltaX);
void Undo_ClusterCenterPosTranslations(C1DClusterCentroid *pInOutCentroidArray, int32_t numOfClusters);

void Translate_OriginalClusterCenterPositions(C2DClusterCentroid *pInOutCentroidArray, int32_t numOfClusters, float deltaX, float deltaY);
void Undo_ClusterCenterPosTranslations(C2DClusterCentroid *pInOutCentroidArray, int32_t numOfClusters);

void Translate_OriginalClusterCenterPositions(C3DClusterCentroid *pInOutCentroidArray, int32_t numOfClusters, float deltaX, float deltaY, float deltaZ);
void Undo_ClusterCenterPosTranslations(C3DClusterCentroid *pInOutCentroidArray, int32_t numOfClusters);

void Get_Best_RBFValue(CClusterArray_SumOfRBFValues *pClusterArray_SumOfRBFValues,
	CNDPoint_InsideCluster *pInPoint, CNDClusterCentroid *pInCentroidArray, int32_t numOfClusters);
void Get_Best_RBFValue(CClusterArray_SumOfRBFValues *pClusterArray_SumOfRBFValues,
	C3DPoint_InsideCluster *pInPoint, C3DClusterCentroid *pInCentroidArray, int32_t numOfClusters);
void Get_Best_RBFValue(CClusterArray_SumOfRBFValues *pClusterArray_SumOfRBFValues,
	C2DPoint_InsideCluster *pInPoint, C2DClusterCentroid *pInCentroidArray, int32_t numOfClusters);
void Get_Best_RBFValue(CClusterArray_SumOfRBFValues *pClusterArray_SumOfRBFValues,
	C1DPoint_InsideCluster *pInPoint, C1DClusterCentroid *pInCentroidArray, int32_t numOfClusters);

void Get_Best_ClippedRBFValue(CClusterArray_SumOfRBFValues *pClusterArray_SumOfRBFValues,
	CNDPoint_InsideCluster *pInPoint, CNDClusterCentroid *pInCentroidArray, int32_t numOfClusters);
void Get_Best_ClippedRBFValue(CClusterArray_SumOfRBFValues *pClusterArray_SumOfRBFValues,
	C3DPoint_InsideCluster *pInPoint, C3DClusterCentroid *pInCentroidArray, int32_t numOfClusters);
void Get_Best_ClippedRBFValue(CClusterArray_SumOfRBFValues *pClusterArray_SumOfRBFValues,
	C2DPoint_InsideCluster *pInPoint, C2DClusterCentroid *pInCentroidArray, int32_t numOfClusters);
void Get_Best_ClippedRBFValue(CClusterArray_SumOfRBFValues *pClusterArray_SumOfRBFValues,
	C1DPoint_InsideCluster *pInPoint, C1DClusterCentroid *pInCentroidArray, int32_t numOfClusters);

void Get_Best_RBFValue(CClusterArray_SumOfRBFValues *pClusterArray_SumOfRBFValues,
	float inCoordX, float inCoordY, float inCoordZ, C3DClusterCentroid *pInCentroidArray, int32_t numOfClusters);
void Get_Best_RBFValue(CClusterArray_SumOfRBFValues *pClusterArray_SumOfRBFValues,
	float inCoordX, float inCoordY, C2DClusterCentroid *pInCentroidArray, int32_t numOfClusters);
void Get_Best_RBFValue(CClusterArray_SumOfRBFValues *pClusterArray_SumOfRBFValues,
	float inCoordX, C1DClusterCentroid *pInCentroidArray, int32_t numOfClusters);

void Get_Best_ClippedRBFValue(CClusterArray_SumOfRBFValues *pClusterArray_SumOfRBFValues,
	float inCoordX, float inCoordY, float inCoordZ, C3DClusterCentroid *pInCentroidArray, int32_t numOfClusters);
void Get_Best_ClippedRBFValue(CClusterArray_SumOfRBFValues *pClusterArray_SumOfRBFValues,
	float inCoordX, float inCoordY, C2DClusterCentroid *pInCentroidArray, int32_t numOfClusters);
void Get_Best_ClippedRBFValue(CClusterArray_SumOfRBFValues *pClusterArray_SumOfRBFValues,
	float inCoordX, C1DClusterCentroid *pInCentroidArray, int32_t numOfClusters);


void Get_Best_RBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster, 
	CNDPoint_InsideCluster *pInPoint, CNDClusterCentroid *pInCentroidArray, int32_t numOfClusters);
void Get_Best_RBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster, 
	C3DPoint_InsideCluster *pInPoint, C3DClusterCentroid *pInCentroidArray, int32_t numOfClusters);
void Get_Best_RBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster, 
	C2DPoint_InsideCluster *pInPoint, C2DClusterCentroid *pInCentroidArray, int32_t numOfClusters);
void Get_Best_RBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster, 
	C1DPoint_InsideCluster *pInPoint, C1DClusterCentroid *pInCentroidArray, int32_t numOfClusters);

void Get_Best_ClippedRBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster,
	CNDPoint_InsideCluster *pInPoint, CNDClusterCentroid *pInCentroidArray, int32_t numOfClusters);
void Get_Best_ClippedRBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster,
	C3DPoint_InsideCluster *pInPoint, C3DClusterCentroid *pInCentroidArray, int32_t numOfClusters);
void Get_Best_ClippedRBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster,
	C2DPoint_InsideCluster *pInPoint, C2DClusterCentroid *pInCentroidArray, int32_t numOfClusters);
void Get_Best_ClippedRBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster,
	C1DPoint_InsideCluster *pInPoint, C1DClusterCentroid *pInCentroidArray, int32_t numOfClusters);


void Get_Best_RBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster, 
	float inCoordX, float inCoordY, float inCoordZ, C3DClusterCentroid *pInCentroidArray, int32_t numOfClusters);
void Get_Best_RBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster, 
	float inCoordX, float inCoordY, C2DClusterCentroid *pInCentroidArray, int32_t numOfClusters);
void Get_Best_RBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster, 
	float inCoordX, C1DClusterCentroid *pInCentroidArray, int32_t numOfClusters);

void Get_Best_ClippedRBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster,
	float inCoordX, float inCoordY, float inCoordZ, C3DClusterCentroid *pInCentroidArray, int32_t numOfClusters);
void Get_Best_ClippedRBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster,
	float inCoordX, float inCoordY, C2DClusterCentroid *pInCentroidArray, int32_t numOfClusters);
void Get_Best_ClippedRBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster,
	float inCoordX, C1DClusterCentroid *pInCentroidArray, int32_t numOfClusters);


void Get_Best_And_Worst_RBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster, float *pOutWorstRBFValue, int32_t *pOutIDofWorstCluster,
	CNDPoint_InsideCluster *pInPoint, CNDClusterCentroid *pInCentroidArray, int32_t numOfClusters);
void Get_Best_And_Worst_RBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster, float *pOutWorstRBFValue, int32_t *pOutIDofWorstCluster,
	C3DPoint_InsideCluster *pInPoint, C3DClusterCentroid *pInCentroidArray, int32_t numOfClusters);
void Get_Best_And_Worst_RBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster, float *pOutWorstRBFValue, int32_t *pOutIDofWorstCluster,
	C2DPoint_InsideCluster *pInPoint, C2DClusterCentroid *pInCentroidArray, int32_t numOfClusters);
void Get_Best_And_Worst_RBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster, float *pOutWorstRBFValue, int32_t *pOutIDofWorstCluster,
	C1DPoint_InsideCluster *pInPoint, C1DClusterCentroid *pInCentroidArray, int32_t numOfClusters);

void Get_Best_And_Worst_ClippedRBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster, float *pOutWorstRBFValue, int32_t *pOutIDofWorstCluster,
	CNDPoint_InsideCluster *pInPoint, CNDClusterCentroid *pInCentroidArray, int32_t numOfClusters);
void Get_Best_And_Worst_ClippedRBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster, float *pOutWorstRBFValue, int32_t *pOutIDofWorstCluster,
	C3DPoint_InsideCluster *pInPoint, C3DClusterCentroid *pInCentroidArray, int32_t numOfClusters);
void Get_Best_And_Worst_ClippedRBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster, float *pOutWorstRBFValue, int32_t *pOutIDofWorstCluster,
	C2DPoint_InsideCluster *pInPoint, C2DClusterCentroid *pInCentroidArray, int32_t numOfClusters);
void Get_Best_And_Worst_ClippedRBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster, float *pOutWorstRBFValue, int32_t *pOutIDofWorstCluster,
	C1DPoint_InsideCluster *pInPoint, C1DClusterCentroid *pInCentroidArray, int32_t numOfClusters);


void Get_Best_And_Worst_RBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster, float *pOutWorstRBFValue, int32_t *pOutIDofWorstCluster,
	float inCoordX, float inCoordY, float inCoordZ, C3DClusterCentroid *pInCentroidArray, int32_t numOfClusters);
void Get_Best_And_Worst_RBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster, float *pOutWorstRBFValue, int32_t *pOutIDofWorstCluster,
	float inCoordX, float inCoordY, C2DClusterCentroid *pInCentroidArray, int32_t numOfClusters);
void Get_Best_And_Worst_RBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster, float *pOutWorstRBFValue, int32_t *pOutIDofWorstCluster,
	float inCoordX, C1DClusterCentroid *pInCentroidArray, int32_t numOfClusters);

void Get_Best_And_Worst_ClippedRBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster, float *pOutWorstRBFValue, int32_t *pOutIDofWorstCluster,
	float inCoordX, float inCoordY, float inCoordZ, C3DClusterCentroid *pInCentroidArray, int32_t numOfClusters);
void Get_Best_And_Worst_ClippedRBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster, float *pOutWorstRBFValue, int32_t *pOutIDofWorstCluster,
	float inCoordX, float inCoordY, C2DClusterCentroid *pInCentroidArray, int32_t numOfClusters);
void Get_Best_And_Worst_ClippedRBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster, float *pOutWorstRBFValue, int32_t *pOutIDofWorstCluster,
	float inCoordX, C1DClusterCentroid *pInCentroidArray, int32_t numOfClusters);


void Add_To_MeanCentroids(CNDClusterCentroid *pOutMeanCentroidArray, CNDClusterCentroid *pInCentroidArray, int32_t numOfClusters);
void Add_To_MeanCentroids(C3DClusterCentroid *pOutMeanCentroidArray, C3DClusterCentroid *pInCentroidArray, int32_t numOfClusters);
void Add_To_MeanCentroids(C2DClusterCentroid *pOutMeanCentroidArray, C2DClusterCentroid *pInCentroidArray, int32_t numOfClusters);
void Add_To_MeanCentroids(C1DClusterCentroid *pOutMeanCentroidArray, C1DClusterCentroid *pInCentroidArray, int32_t numOfClusters);

void Calculate_ClusterRadiusSqs(CNDClusterCentroid *pOutCentroidArray, int32_t numOfClusters, CNDPoint_InsideCluster *pInPointArray, int32_t numOfPoints);
void Calculate_ClusterRadiusSqs(C3DClusterCentroid *pOutCentroidArray, int32_t numOfClusters, C3DPoint_InsideCluster *pInPointArray, int32_t numOfPoints);
void Calculate_ClusterRadiusSqs(C2DClusterCentroid *pOutCentroidArray, int32_t numOfClusters, C2DPoint_InsideCluster *pInPointArray, int32_t numOfPoints);
void Calculate_ClusterRadiusSqs(C1DClusterCentroid *pOutCentroidArray, int32_t numOfClusters, C1DPoint_InsideCluster *pInPointArray, int32_t numOfPoints);

float Calculate_ClusterRadiusVariance(CNDClusterCentroid *pCentroidArray, int32_t numOfClusters);
float Calculate_ClusterRadiusVariance(C1DClusterCentroid *pCentroidArray, int32_t numOfClusters);
float Calculate_ClusterRadiusVariance(C2DClusterCentroid *pCentroidArray, int32_t numOfClusters);
float Calculate_ClusterRadiusVariance(C3DClusterCentroid *pCentroidArray, int32_t numOfClusters);

float Calculate_SumOfDistancesSq_InsideAllClusters(CNDPoint_InsideCluster *pPointArray, int32_t numOfPoints, CNDClusterCentroid *pCentroidArray, int32_t numOfClusters);
float Calculate_SumOfDistancesSq_InsideAllClusters(C3DPoint_InsideCluster *pPointArray, int32_t numOfPoints, C3DClusterCentroid *pCentroidArray, int32_t numOfClusters);
float Calculate_SumOfDistancesSq_InsideAllClusters(C2DPoint_InsideCluster *pPointArray, int32_t numOfPoints, C2DClusterCentroid *pCentroidArray, int32_t numOfClusters);
float Calculate_SumOfDistancesSq_InsideAllClusters(C1DPoint_InsideCluster *pPointArray, int32_t numOfPoints, C1DClusterCentroid *pCentroidArray, int32_t numOfClusters);


typedef float(*pCalc_ClusterDist)(CNDClusterCentroid *pCluster, CNDPoint_InsideCluster *pPoint);


int32_t Calculate_Clusters(pCalc_ClusterDist pFunc, CNDClusterCentroid *pOutCentroidArray, int32_t numOfClusters, CNDPoint_InsideCluster *pInPointArray, int32_t numOfPoints, int32_t numIterationsMax);

int32_t Calculate_Clusters_OMP(pCalc_ClusterDist pFunc, CNDClusterCentroid *pOutCentroidArray, int32_t numOfClusters, CNDPoint_InsideCluster *pInPointArray, int32_t numOfPoints, int32_t numIterationsMax);

int32_t Calculate_Clusters(CNDClusterCentroid *pOutCentroidArray, int32_t numOfClusters, CNDPoint_InsideCluster *pInPointArray, int32_t numOfPoints, int32_t numIterationsMax);

int32_t Calculate_Clusters_OMP(CNDClusterCentroid *pOutCentroidArray, int32_t numOfClusters, CNDPoint_InsideCluster *pInPointArray, int32_t numOfPoints, int32_t numIterationsMax);

int32_t Calculate_Clusters(C1DClusterCentroid *pOutCentroidArray, int32_t numOfClusters, C1DPoint_InsideCluster *pInPointArray, int32_t numOfPoints, int32_t numIterationsMax);

int32_t Calculate_Clusters_OMP(C1DClusterCentroid *pOutCentroidArray, int32_t numOfClusters, C1DPoint_InsideCluster *pInPointArray, int32_t numOfPoints, int32_t numIterationsMax);

int32_t Calculate_Clusters(C2DClusterCentroid *pOutCentroidArray, int32_t numOfClusters, C2DPoint_InsideCluster *pInPointArray, int32_t numOfPoints, int32_t numIterationsMax);

int32_t Calculate_Clusters_OMP(C2DClusterCentroid *pOutCentroidArray, int32_t numOfClusters, C2DPoint_InsideCluster *pInPointArray, int32_t numOfPoints, int32_t numIterationsMax);

int32_t Calculate_Clusters(C3DClusterCentroid *pOutCentroidArray, int32_t numOfClusters, C3DPoint_InsideCluster *pInPointArray, int32_t numOfPoints, int32_t numIterationsMax);

int32_t Calculate_Clusters_OMP(C3DClusterCentroid *pOutCentroidArray, int32_t numOfClusters, C3DPoint_InsideCluster *pInPointArray, int32_t numOfPoints, int32_t numIterationsMax);





#endif