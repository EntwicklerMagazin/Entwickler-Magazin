#include <iostream>
#include <omp.h>

using namespace std;

/*
static void Set_ProcessPriority(unsigned long priority)
{
	HANDLE ProcessHandle = GetCurrentProcess();

	if (priority == 0)
		SetPriorityClass(ProcessHandle, NORMAL_PRIORITY_CLASS);
	else if (priority == 1)
		SetPriorityClass(ProcessHandle, ABOVE_NORMAL_PRIORITY_CLASS);
	else if (priority == 2)
		SetPriorityClass(ProcessHandle, HIGH_PRIORITY_CLASS);
	else
		SetPriorityClass(ProcessHandle, REALTIME_PRIORITY_CLASS);
}
*/


/*
int main(void)
{
	//omp_set_num_threads(4);
	int32_t numCpuCores = omp_get_num_procs();
	cout << numCpuCores << endl;
	int32_t maxThreads = omp_get_max_threads();
	cout << maxThreads << endl << endl;

#pragma omp parallel
	{
		if (omp_get_thread_num() == 0)
			cout << "Greetings from the master thread!! " << endl;
	}


	getchar();
	return 0;
}
*/

/*
int main(void)
{
#pragma omp parallel
	{
		int32_t numThreads = omp_get_num_threads();
		int32_t threadID = omp_get_thread_num();

#pragma omp critical
		{
			cout << "threadID: " << threadID << " ----- " << numThreads << endl;
			//printf("threadID: %d (%d)\n", threadID, numThreads);

			if (threadID == 0)
				cout << "Greetings from the master thread!! " << endl;
		}
	}

	getchar();
	return 0;
}
*/

/*
int main(void)
{
// 2 threads, 1 for-Loop per thread:
#pragma omp parallel num_threads(2)
	{
		for (int32_t i = 0; i < 4; i++)
		{
			int32_t numThreads = omp_get_num_threads();
			int32_t threadID = omp_get_thread_num();

			if (threadID == 0)
			{
				//cout << "Greetings from the master thread!! " << endl;
				cout << "threadID: " << threadID << " ----- " << numThreads << endl;
				//printf("threadID: %d (%d)\n", threadID, numThreads);
				
			} // end of if (threadID == 0)
			else if (threadID == 1)
			{
				cout << "threadID: " << threadID << " ----- " << numThreads << endl;
				//printf("threadID: %d (%d)\n", threadID, numThreads);
				
			} // end of else if (threadID == 1)
		} // end of for (int32_t i = 0; i < 5; i++)
	}

	getchar();
	return 0;
}
*/

/*
int main(void)
{
// 2 threads, 1 for-Loop per thread:
#pragma omp parallel num_threads(2)
	{
		for (int32_t i = 0; i < 4; i++)
		{
			int32_t numThreads = omp_get_num_threads();
			int32_t threadID = omp_get_thread_num();

			if (threadID == 0)
			{
#pragma omp critical
				{
					cout << "Greetings from the master thread!! " << endl;
					cout << "threadID: " << threadID << " ----- " << numThreads << endl;
					//printf("threadID: %d (%d)\n", threadID, numThreads);
				}
			} // end of if (threadID == 0)
			else if (threadID == 1)
			{
#pragma omp critical
				{
					cout << "threadID: " << threadID << " ----- " << numThreads << endl;
					//printf("threadID: %d (%d)\n", threadID, numThreads);
				}
			} // end of else if (threadID == 1)
		} // end of for (int32_t i = 0; i < 5; i++)
	}

	getchar();
	return 0;
}
*/

/*
int main(void)
{
// 2 threads, 1 for-Loop per thread:
#pragma omp parallel num_threads(2)
	{
		for (int32_t i = 0; i < 4; i++)
		{
			int32_t numThreads = omp_get_num_threads();
			int32_t threadID = omp_get_thread_num();

#pragma omp critical
			{
				if (threadID == 0)
				{
					cout << "Greetings from the master thread!! " << endl;
					cout << "threadID: " << threadID << " ----- " << numThreads << endl;
					//printf("threadID: %d (%d)\n", threadID, numThreads);

				} // end of if (threadID == 0)
				else if (threadID == 1)
				{
					cout << "threadID: " << threadID << " ----- " << numThreads << endl;
					//printf("threadID: %d (%d)\n", threadID, numThreads);

				} // end of else if (threadID == 1)
			} // end of #pragma omp critical
		} // end of for (int32_t i = 0; i < 5; i++)
	}

	getchar();
	return 0;
}
*/


/*
int main(void)
{
#pragma omp parallel num_threads(4)
	{
		int32_t numThreads = omp_get_num_threads();
		int32_t threadID = omp_get_thread_num();

#pragma omp critical
		{
			cout << "threadID: " << threadID << " ----- " << numThreads << endl;
			//printf("threadID: %d (%d)\n", threadID, numThreads);

			if (threadID == 0)
				cout << "Greetings from the master thread!! " << endl;
		}
	}

	getchar();
	return 0;
}
*/

/*
int main(void)
{
	omp_set_num_threads(4);

#pragma omp parallel
	{
		int32_t numThreads = omp_get_num_threads();
		int32_t threadID = omp_get_thread_num();

#pragma omp critical
		{
			cout << "threadID: " << threadID << " ----- " << numThreads << endl;
			//printf("threadID: %d (%d)\n", threadID, numThreads);

			if (threadID == 0)
				cout << "Greetings from the master thread!! " << endl;
		}
	}

	getchar();
	return 0;
}
*/

/*
int main(void)
{
#pragma omp parallel for
	for (int32_t i = 0; i < 16; i++)
	{
		int32_t numThreads = omp_get_num_threads();
		int32_t threadID = omp_get_thread_num();

#pragma omp critical
		{
			printf("loopID: %d, threadID: %d (%d)\n", i, threadID, numThreads);
		}
	}

	getchar();
	return 0;
}
*/



/*
int main(void)
{
#pragma omp parallel for num_threads(4)
	for (int32_t i = 0; i < 16; i++)
	{
		int32_t numThreads = omp_get_num_threads();
		int32_t threadID = omp_get_thread_num();

#pragma omp critical
		{
			printf("loopID: %d, threadID: %d (%d)\n", i, threadID, numThreads);
		}
	}

	getchar();
	return 0;
}
*/


/*
int main(void)
{
	int32_t sum1 = 0;
	int32_t sum2 = 0;

#pragma omp parallel for num_threads(4) shared(sum1, sum2) 
	for (int32_t i = 0; i < 16; i++)
	{
#pragma omp critical
		{
			sum1 += 1;
			sum2 += 2;
		}
	}

	cout << endl << "sum1: " << sum1 << endl;
	cout << "sum2: " << sum2 << endl;

	getchar();
	return 0;
}
*/

/*
int main(void)
{
	int32_t sum1 = 0;
	int32_t sum2 = 0;

#pragma omp parallel for num_threads(4) shared(sum1, sum2) 
	for (int32_t i = 0; i < 16; i++)
	{
#pragma omp atomic
		sum1 += 1;
#pragma omp atomic
		sum2 += 2;
	}

	cout << endl << "sum1: " << sum1 << endl;
	cout << "sum2: " << sum2 << endl;

	getchar();
	return 0;
}
*/

/*
int main(void)
{
	int32_t sum1 = 0;
	int32_t sum2 = 0;

#pragma omp parallel for num_threads(4) reduction(+: sum1, sum2)
	for (int32_t i = 0; i < 16; i++)
	{
		sum1 += 1;
		sum2 += 2;
	}

	cout << endl << "sum1: " << sum1 << endl;
	cout << "sum2: " << sum2 << endl;

	getchar();
	return 0;
}
*/


/*
int main(void)
{
	static int32_t ValueArray[12] = { 0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22 };

	int32_t SizeX = 4;
	int32_t SizeY = 3;
	int32_t SizeXY = SizeX * SizeY;

	// Parallelisierung der �u�eren for-Schleife;

//#pragma omp parallel for num_threads(2)
#pragma omp parallel for

	for (int32_t iy = 0; iy < SizeY; iy++)
	{
		int32_t iiy = iy * SizeX;

		for (int32_t ix = 0; ix < SizeX; ix++)
		{
			int32_t id = ix + iiy;
			int32_t value = ValueArray[id];
			printf("ix: %d, iy: %d, id: %d v: %d (%d)\n", ix, iy, id, value, omp_get_thread_num());
		}
	}

	printf("\n");

	getchar();

	// Parallelisierung sowohl der �u�eren als auch der inneren for-Schleife
//#pragma omp parallel for num_threads(2)
#pragma omp parallel for

	for (int32_t id = 0; id < SizeXY; id++)
	{
		int32_t ix = id % SizeX;

		//if (ix == 0)
			//continue;

		int32_t iy = id / SizeX;

		//if (iy == 0)
			//continue;

		int32_t value = ValueArray[id];
		printf("ix: %d, iy: %d, id: %d v: %d (%d)\n", ix, iy, id, value, omp_get_thread_num());
	}

	printf("\n");

    getchar();
    return 0;
}
*/


