// Schutz vor Mehrfachdeklarationen:
#ifndef _Pong_H_
#define _Pong_H_

#include <iostream>
#include "ConsoleHelperFunctions.h"
#include "RandomNumbers.h"
#include "NeuralNet.h"
#include "LogFile.h"




#ifndef max
#define max(a,b)    ( ((a) > (b)) ? (a) : (b) )
#endif

#ifndef min
#define min(a,b)    ( ((a) < (b)) ? (a) : (b) )
#endif

static constexpr int32_t ConstGameBoardSizeX = 36;
static constexpr int32_t ConstGameBoardSizeY = 40;


static constexpr float fConstGameBoardSizeX = 36.0f;
static constexpr float fConstGameBoardSizeY = 40.0f;

static constexpr int32_t ConstGameBoardSizeXMinus1 = 35;
static constexpr int32_t ConstGameBoardSizeYMinus1 = 39;

static constexpr float fConstGameBoardSizeXMinus1 = 35.0f;
static constexpr float fConstGameBoardSizeYMinus1 = 39.0f;

static constexpr float fConstGameBoardSizeXMinus2 = 34.0f;
static constexpr float fConstGameBoardSizeYMinus2 = 38.0f;


extern uint8_t g_GameBoard[ConstGameBoardSizeY][ConstGameBoardSizeX];
extern float g_fGameBoard[ConstGameBoardSizeY][ConstGameBoardSizeX];

static constexpr uint8_t ConstGameBoard_EmptyElement = 0;
static constexpr uint8_t ConstGameBoard_Ball = 1;
static constexpr uint8_t ConstGameBoard_PaddleElement = 2;
static constexpr uint8_t ConstGameBoard_BorderElement = 3;

static constexpr float fConstGameBoard_EmptyElement = 0.0f;
static constexpr float fConstGameBoard_Ball = -1.0f;
static constexpr float fConstGameBoard_PaddleElement = 1.0f;
static constexpr float fConstGameBoard_BorderElement = 0.0f;


inline float SigmoidOutput(float neuronInput)
{
	// von 0.0f bis 1.0f:
	return 1.0f / (1.0f + exp(-2.0f * neuronInput));
}

inline float TanHOutput(float neuronInput)
{
	// von -1.0f bis 1.0f:
	//return tanh(neuronInput);
	return tanh(0.5f*neuronInput);
}

inline float FastTanHReplacementOutput(float neuronInput)
{
	// von -1.0f bis 1.0f:
	return neuronInput / (1.0f + abs(neuronInput));	
}


inline float LinearOutput(float neuronInput)
{
	return neuronInput;
}

inline float NegLinearOutput(float neuronInput)
{
	return -neuronInput;
}

inline float ReLUOutput(float neuronInput)
{
	// von 0.0f bis unendlich:
	return max(0.0f, neuronInput);
}


inline float BinaryOutput(float neuronInput)
{
	//if (neuronInput > 0.9999f)
	//return 1.0f;

	// less accuracy
	if (neuronInput > 0.9f)
		return 1.0f;

	return 0.0f;
}

inline float DampenedLinearOutput(float neuronInput)
{
	return 0.5f*neuronInput;
}

// FastTanHReplacementOutput:
inline float PongActivationFunctionOutput(float neuronInput) 
{
	// von -1.0f bis 1.0f:
	return neuronInput / (1.0f + abs(neuronInput));
}



class CBall
{
public:

	float PosX, PosY;
	float LastPosX, LastPosY;
	float VelocityX, VelocityY;

	float MaxPlayBallSpeed = 1.0f;

	CBall();
	CBall(float maxPlayBallSpeed);
	CBall(int32_t posX, int32_t posY);
	CBall(int32_t posX, int32_t posY, float maxPlayBallSpeed);

	~CBall();

	// Kopierkonstruktor l�schen:
	CBall(const CBall &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CBall& operator=(const CBall &originalObject) = delete;

	void Initialize(float maxPlayBallSpeed);
	void Initialize(int32_t posX, int32_t posY);
	void Initialize(int32_t posX, int32_t posY, float maxPlayBallSpeed);

	void Set_Pos(float x, float y);
	void Set_Velocity(float velX, float velY);
	void Movement(void);

	void Handle_Possible_WallCollisions(void);
	bool Check_Possible_UpperWallCollision(void);
	bool Check_Possible_LowerWallCollision(void);

	void DrawIntoBuffer(void);
	void DrawIntoBuffer(uint8_t *pGameBoard, int32_t gameBoardSizeX, int32_t gameBoardSizeY);

	void fDrawIntoBuffer(void);
	void fDrawIntoBuffer(float *pGameBoard, int32_t gameBoardSizeX, int32_t gameBoardSizeY);
};

class CPaddle
{
public:

	float PosX, PosY;
	float LastPosX, LastPosY;
	float VelocityX;
	float LastVelocityX;
	int32_t HalfSizeX;
	int32_t SizeX;

	float fHalfSizeX;
	float fHalfSizeXPlus1;
	float fHalfSizeXPlus2;

	float fSizeX;
	float fSizeXPlus1;

	float MaxAIPlayerPaddleVelocityX = 2.0f;
	float MinAIPlayerPaddleVelocityX = -2.0f;

	CPaddle();
	CPaddle(int32_t horizontalHalfSize);
	CPaddle(int32_t posX, int32_t posY, int32_t horizontalHalfSize);

	~CPaddle();

	// Kopierkonstruktor l�schen:
	CPaddle(const CPaddle  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CPaddle & operator=(const CPaddle  &originalObject) = delete;

	void Initialize(int32_t horizontalHalfSize);
	void Initialize(int32_t posX, int32_t posY, int32_t horizontalHalfSize);


	void Set_Pos(float posX, float posY);
	void Set_Velocity(float velX);
	
	void HumanPlayer_SimpleMovement(float movementStep);
	void HumanPlayer_Movement(float movementStep, float paddleDecelerationValue);

	void Simple_MovementAI(CBall *pPlayBall, float paddleAccelerationValue, float paddleDecelerationValue);
	
	void Handle_Possible_PlayBallCollision(CBall *pPlayBall, bool upperPaddle);
	
	void DrawIntoBuffer(void);
	void DrawIntoBuffer(uint8_t *pGameBoard, int32_t gameBoardSizeX, int32_t gameBoardSizeY);

	void fDrawIntoBuffer(void);
	void fDrawIntoBuffer(float *pGameBoard, int32_t gameBoardSizeX, int32_t gameBoardSizeY);
};


class CSimpleAIPlayer_Pong1
{
public:

	CPaddle *pUsedPaddle = nullptr;
	CBall *pUsedPlayBall = nullptr;

	CNeuralNet Brain;

	static constexpr uint32_t NumOfInputNeurons = 4;
	static constexpr uint32_t NumOfOutputNeurons = 3;

	C2DPatternDetector PaddleDetector;
	C2DPatternDetector PlayBallDetector;

	int32_t ScreenPaddlePosX;
	int32_t ScreenPaddlePosY;

	int32_t ScreenPlayBallPosX;
	int32_t ScreenPlayBallPosY;

	CShortTermMemoryElement PlayBallMovementX;
	CShortTermMemoryElement PlayBallMovementY;

	CSimpleAIPlayer_Pong1();
	~CSimpleAIPlayer_Pong1();

	// Kopierkonstruktor l�schen:
	CSimpleAIPlayer_Pong1(const CSimpleAIPlayer_Pong1  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CSimpleAIPlayer_Pong1 & operator=(const CSimpleAIPlayer_Pong1  &originalObject) = delete;

	void Initialize(CPaddle *pPaddle, CBall *pPlayBall, uint32_t numOfHiddenNeuronsL1, uint32_t numOfHiddenNeuronsL2, bool useNeuralNet = true);

	void Initialize_Ext(CPaddle *pPaddle, CBall *pPlayBall, CRandomNumbersNN *pRandomNumbers, uint32_t minNumOfHiddenNeuronsL1, uint32_t maxNumOfHiddenNeuronsL1, uint32_t minNumOfHiddenNeuronsL2, uint32_t maxNumOfHiddenNeuronsL2, bool useNeuralNet = true);
	
	void GameObjectDetection_And_VelocityCalculations(void);

	void Reset_Memories(void);

	// Backpropagation-Training:
	float Train_NeuralNet(float accuracyValue, bool extremeLearning = true);

	int32_t Calculate_NeuralNetPaddleMovement(float paddleMovementStep, float paddleDecelerationValue, float accuracyValue);


	void Calculate_PaddleMovement(float paddleMovementStep, float paddleDecelerationValue, float accuracyValue);


	float Calculate_FitnessScore(void);
	float Calculate_FitnessScore(float accuracyValue, float neuralNetOutput1, float neuralNetOutput2, float neuralNetOutput3);

	float Check_PlayBallFlightDir(float targetPosX, float targetPosY, float movementDirX, float movementDirY);

};

class CSimpleAIPlayer_Pong2
{
public:

	CPaddle *pUsedPaddle = nullptr;
	CBall *pUsedPlayBall = nullptr;

	CNeuralNet Brain;

	static constexpr uint32_t NumOfInputNeurons = 6;
	static constexpr uint32_t NumOfOutputNeurons = 3;

	C2DPatternDetector PaddleDetector;
	C2DPatternDetector PlayBallDetector;

	int32_t ScreenPaddlePosX;
	int32_t ScreenPaddlePosY;

	int32_t ScreenPlayBallPosX;
	int32_t ScreenPlayBallPosY;

	CShortTermMemoryElement PlayBallMovementX;
	CShortTermMemoryElement PlayBallMovementY;


	CSimpleAIPlayer_Pong2();
	~CSimpleAIPlayer_Pong2();

	// Kopierkonstruktor l�schen:
	CSimpleAIPlayer_Pong2(const CSimpleAIPlayer_Pong2  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CSimpleAIPlayer_Pong2 & operator=(const CSimpleAIPlayer_Pong2  &originalObject) = delete;

	void Initialize(CPaddle *pPaddle, CBall *pPlayBall, uint32_t numOfHiddenNeuronsL1, uint32_t numOfHiddenNeuronsL2, bool useNeuralNet = true);

	void Initialize_Ext(CPaddle *pPaddle, CBall *pPlayBall, CRandomNumbersNN *pRandomNumbers, uint32_t minNumOfHiddenNeuronsL1, uint32_t maxNumOfHiddenNeuronsL1, uint32_t minNumOfHiddenNeuronsL2, uint32_t maxNumOfHiddenNeuronsL2, bool useNeuralNet = true);

	void GameObjectDetection_And_VelocityCalculations(void);

	void Reset_Memories(void);

	// Backpropagation-Training:
	float Train_NeuralNet(float accuracyValue, bool extremeLearning = false);

	int32_t Calculate_NeuralNetPaddleMovement(float paddleMovementStep, float paddleDecelerationValue, float accuracyValue);


	void Calculate_PaddleMovement(float paddleMovementStep, float paddleDecelerationValue, float accuracyValue);


	float Calculate_FitnessScore(void);
	float Calculate_FitnessScore(float accuracyValue, float neuralNetOutput1, float neuralNetOutput2, float neuralNetOutput3);

	float Check_PlayBallFlightDir(float targetPosX, float targetPosY, float movementDirX, float movementDirY);

};



class CSimpleAIPlayerPopulation_Pong1
{
public:

	uint64_t Seed = 1;
	CRandomNumbersNN RandomNumbers;

	uint32_t PopulationSize;
	uint32_t PopulationSizePlus4;

	CPaddle *pHumanPlayerPaddleArray = nullptr;
	CPaddle *pAIPlayerPaddleArray = nullptr;
	CBall *pPlayBallArray = nullptr;

	CSimpleAIPlayer_Pong1 *pSimulatedHumanPlayerArray = nullptr;
	CSimpleAIPlayer_Pong1 *pAIPlayerArray = nullptr;

	float *pFitnessScoreArray = nullptr;
	int32_t *pNumOfMovementChangeArray = nullptr;

	uint32_t MinNumOfHiddenNeuronsL1 = 0;
	uint32_t MaxNumOfHiddenNeuronsL1 = 0;
	uint32_t MinNumOfHiddenNeuronsL2 = 0;
	uint32_t MaxNumOfHiddenNeuronsL2 = 0;

	static constexpr uint32_t NumOfInputNeurons = 4;
	static constexpr uint32_t NumOfOutputNeurons = 3;

	CSimpleAIPlayerPopulation_Pong1();
	~CSimpleAIPlayerPopulation_Pong1();

	// Kopierkonstruktor l�schen:
	CSimpleAIPlayerPopulation_Pong1(const CSimpleAIPlayerPopulation_Pong1  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CSimpleAIPlayerPopulation_Pong1 & operator=(const CSimpleAIPlayerPopulation_Pong1  &originalObject) = delete;

	void Initialize(uint32_t populationSize, uint32_t numOfHiddenNeuronsL1, uint32_t numOfHiddenNeuronsL2, float maxPlayBallSpeed);

	void Initialize_Ext(uint32_t populationSize, uint32_t minNumOfHiddenNeuronsL1, uint32_t maxNumOfHiddenNeuronsL1, uint32_t minNumOfHiddenNeuronsL2, uint32_t maxNumOfHiddenNeuronsL2, float maxPlayBallSpeed);

	void Change_Seed(uint64_t seed);

	void RandomChange_OutputSynapsePlasticities(uint64_t seed, float minSynapticPlasticity, float maxSynapticPlasticity);
	void RandomChange_OutputSynapsePlasticities(uint64_t seed, float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRate);

	void RandomChange_OutputSynapsePlasticities(float minSynapticPlasticity, float maxSynapticPlasticity);
	void RandomChange_OutputSynapsePlasticities(float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRate);

	void RandomReduce_BrainConnections(uint64_t seed, float mutationRateL1, float mutationRateL2, float mutationRateL3);
	void RandomReduce_BrainConnections(float mutationRateL1, float mutationRateL2, float mutationRateL3);

	
	void Init_Play_and_Evaluate_NewTrainingSequence(uint32_t trainingGameLengthMax, uint32_t numTrainingGames);
};

class CSimpleAIPlayerPopulation_Pong2
{
public:

	uint64_t Seed = 1;
	CRandomNumbersNN RandomNumbers;

	uint32_t PopulationSize;
	uint32_t PopulationSizePlus4;

	CPaddle *pHumanPlayerPaddleArray = nullptr;
	CPaddle *pAIPlayerPaddleArray = nullptr;
	CBall *pPlayBallArray = nullptr;

	CSimpleAIPlayer_Pong2 *pSimulatedHumanPlayerArray = nullptr;
	CSimpleAIPlayer_Pong2 *pAIPlayerArray = nullptr;

	float *pFitnessScoreArray = nullptr;
	int32_t *pNumOfMovementChangeArray = nullptr;

	uint32_t MinNumOfHiddenNeuronsL1 = 0;
	uint32_t MaxNumOfHiddenNeuronsL1 = 0;
	uint32_t MinNumOfHiddenNeuronsL2 = 0;
	uint32_t MaxNumOfHiddenNeuronsL2 = 0;

	static constexpr uint32_t NumOfInputNeurons = 6;
	static constexpr uint32_t NumOfOutputNeurons = 3;

	CSimpleAIPlayerPopulation_Pong2();
	~CSimpleAIPlayerPopulation_Pong2();

	// Kopierkonstruktor l�schen:
	CSimpleAIPlayerPopulation_Pong2(const CSimpleAIPlayerPopulation_Pong2  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CSimpleAIPlayerPopulation_Pong2 & operator=(const CSimpleAIPlayerPopulation_Pong2  &originalObject) = delete;

	void Initialize(uint32_t populationSize, uint32_t numOfHiddenNeuronsL1, uint32_t numOfHiddenNeuronsL2, float maxPlayBallSpeed);

	void Initialize_Ext(uint32_t populationSize, uint32_t minNumOfHiddenNeuronsL1, uint32_t maxNumOfHiddenNeuronsL1, uint32_t minNumOfHiddenNeuronsL2, uint32_t maxNumOfHiddenNeuronsL2, float maxPlayBallSpeed);

	void Change_Seed(uint64_t seed);

	void RandomChange_OutputSynapsePlasticities(uint64_t seed, float minSynapticPlasticity, float maxSynapticPlasticity);
	void RandomChange_OutputSynapsePlasticities(uint64_t seed, float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRate);

	void RandomChange_OutputSynapsePlasticities(float minSynapticPlasticity, float maxSynapticPlasticity);
	void RandomChange_OutputSynapsePlasticities(float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRate);

	void RandomReduce_BrainConnections(uint64_t seed, float mutationRateL1, float mutationRateL2, float mutationRateL3);
	void RandomReduce_BrainConnections(float mutationRateL1, float mutationRateL2, float mutationRateL3);

	
	void Init_Play_and_Evaluate_NewTrainingSequence(uint32_t trainingGameLengthMax, uint32_t numTrainingGames);
};




void Init_New_Game(CPaddle *pPlayerPaddle, CPaddle *pAIPaddle, CBall *pPlayBall, float playBallVelocityX, float playBallVelocityY, bool *pStarted, int32_t *pPlayerScore, int32_t *pAIScore);
    
void Init_NeuralNetPopulation(CNeuralNetPopulation *pNeuralNetPopulation, CSimpleAIPlayerPopulation_Pong1 *pAIPlayerPopulation);
void Init_NeuralNetPopulation(CNeuralNetPopulation *pNeuralNetPopulation, CSimpleAIPlayerPopulation_Pong2 *pAIPlayerPopulation);





#endif