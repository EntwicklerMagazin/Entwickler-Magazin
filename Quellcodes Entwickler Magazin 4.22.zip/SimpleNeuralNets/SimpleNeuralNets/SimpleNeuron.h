// Schutz vor Mehrfachdeklarationen :

#ifndef _SimpleNeuron_H_
#define _SimpleNeuron_H_

#include <iostream>
#include <fstream>
#include "LogFile.h"
#include "RandomNumbers.h"
#include "NeuralNetInlineFunctions.h"
#include "SimpleFeatureMap.h"


#ifndef max
#define max(a,b)    ( ((a) > (b)) ? (a) : (b) )
#endif

#ifndef min
#define min(a,b)    ( ((a) < (b)) ? (a) : (b) )
#endif




static constexpr int32_t ConstNumOfPrecedingSimpleNeuronsMax = 20;


class CSimpleNeuron;
class CSimpleNeuralNetData;

void PrecedingNeuronLearning(CSimpleNeuron *pPrecedingNeuron, CSimpleNeuron *pSubsequentNeuron, float learningRate, float errorFactor1, float errorFactor2);
void PrecedingNeuronErrorCalculations(CSimpleNeuron *pPrecedingNeuron, CSimpleNeuron *pSubsequentNeuron, float errorFactor1, float errorFactor2);


void PrecedingNeuronLearning(CSimpleNeuron *pPrecedingNeuron, CSimpleNeuron *pSubsequentNeuronArray, int32_t numOfSubsequentNeurons, float learningRate, float errorFactor1, float errorFactor2);
void PrecedingNeuronErrorCalculations(CSimpleNeuron *pPrecedingNeuron, CSimpleNeuron *pSubsequentNeuronArray, int32_t numOfSubsequentNeurons, float errorFactor1, float errorFactor2);


void PrecedingNeuronLearning(CSimpleNeuron *pPrecedingNeuron, float learningRate);

void Calculate_InputDendritesErrorValues(CSimpleNeuron *pNeuron, float errorFactor1, float errorFactor2);


typedef void(*pActivationFunction)(CSimpleNeuron *pNeuron);
typedef void(*pDendriticFunction)(CSimpleNeuron *pNeuron);

typedef void(*pRecombinationFunction)(CSimpleNeuron *pOffspring, const CSimpleNeuron *pParent1, const CSimpleNeuron *pParent2, CRandomNumbersNN *pRandomNumbers, void *pParam);
typedef void(*pMutationFunction)(CSimpleNeuron *pInOutNeuron, CRandomNumbersNN *pRandomNumbers, void *pParam);
typedef void(*pPermutationFunction)(CSimpleNeuron *pInOutNeuron, CRandomNumbersNN *pRandomNumbers, void *pParam);
typedef void(*pReinitializationFunction)(CSimpleNeuron *pInOutNeuron, CRandomNumbersNN *pRandomNumbers, void *pParam);


typedef void(*pNetRecombinationFunction)(CSimpleNeuralNetData *pOffspring, const CSimpleNeuralNetData *pParent1, const CSimpleNeuralNetData *pParent2, CRandomNumbersNN *pRandomNumbers, void *pParam);
typedef void(*pNetMutationFunction)(CSimpleNeuralNetData *pInOutNeuralNet, CRandomNumbersNN *pRandomNumbers, void *pParam);
typedef void(*pNetPermutationFunction)(CSimpleNeuralNetData *pInOutNeuralNet, CRandomNumbersNN *pRandomNumbers, void *pParam);
typedef void(*pNetReinitializationFunction)(CSimpleNeuralNetData *pInOutNeuralNet, CRandomNumbersNN *pRandomNumbers, void *pParam);



class CSimpleNeuron
{
public:

	CSimpleNeuron *pUsedNeuronArray = nullptr;

	int32_t NeuronID = -1;

	int32_t NumOfDendriteElements = 0;
	int32_t MaxDendriteID = 0;

	float *pDendrite_DataArray = nullptr;
	float *pDendrite_CentroidValueArray = nullptr;
	float *pDendrite_FactorArray = nullptr;
	float *pDendrite_ErrorValueArray = nullptr;

	float *pDendrite_DataArray_OtherNeuron = nullptr;
	float *pDendrite_CentroidValueArray_OtherNeuron = nullptr;
	float *pDendrite_FactorArray_OtherNeuron = nullptr;

	int32_t NumOfUsedPrecedingNeurons = 0;
	CSimpleNeuron *pPrecedingNeuronArray[ConstNumOfPrecedingSimpleNeuronsMax];

	float *pDendrite_DataArray_OtherNeurons[ConstNumOfPrecedingSimpleNeuronsMax];
	float *pDendrite_CentroidValueArray_OtherNeurons[ConstNumOfPrecedingSimpleNeuronsMax];
	float *pDendrite_FactorArray_OtherNeurons[ConstNumOfPrecedingSimpleNeuronsMax];

	int32_t NumOfAdditionalMemoryValues = 0;
	float *pAdditionalMemoryValueArray = nullptr;

	float AdditionalInputValue = 0.0f;

	int32_t UsedDendritesMinID = 0;
	int32_t UsedDendritesMaxIDPlus1 = 0;

	int32_t NumOfTrainingExamples = 0;

	int32_t Dendrite_InputCounter = 0;

	pActivationFunction pActivationFunc = nullptr;
	float ActivationValue;

	pDendriticFunction pDendriticFunc = nullptr;

	

	float ErrorValue = 0.0f;
	float ErrorFactor1 = 1.0f;
	float ErrorFactor2 = 1.0f;
	// Hinweis: Bei linearen Aktivierungsfunktionen sollte ErrorFactor2 kleiner als 1.0f sein (z. B. 0.5f oder 0.25f) 

	float LearningRate = 0.2f;

	int32_t RandomSeedValue = 0;

	int32_t FirstInputDendriteID = 0;
	int32_t NumOfInputDendrites = 0;
	int32_t NumOfInputDendritesXDir = 0;
	int32_t NumOfInputDendritesYDir = 0;
	
	int32_t FirstOutputDendriteID = 0;
	int32_t NumOfOutputDendrites = 0;
	int32_t NumOfOutputDendritesXDir = 0;
	int32_t NumOfOutputDendritesYDir = 0;

	int32_t LocalReceptiveFieldSizeX = 0;
	int32_t LocalReceptiveFieldSizeY = 0;

	int32_t NumOfOutputSynapses = 0;
	int32_t *pReceiverNeuronIDArray = nullptr;
	float *pOutputSynapsePlasticityArray = nullptr;

	CSimpleNeuron();
	~CSimpleNeuron();

	// Kopierkonstruktor l�schen:
	CSimpleNeuron(const CSimpleNeuron  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CSimpleNeuron & operator=(const CSimpleNeuron  &originalObject) = delete;


	void Reset_NumOfUsedPrecedingNeurons(void);
	void Add_PrecedingNeuron(CSimpleNeuron *pNeuron);
	void Use_PrecedingNeuronActivationValues_As_InputValues(void);

	void Set_NeuronID(int32_t id);

	void Set_InputDendriteInfo(int32_t firstInputDendriteID, int32_t numOfInputDendrites);
	void Set_InputDendriteInfo(int32_t firstInputDendriteID, int32_t numOfInputDendritesXDir, int32_t numOfInputDendritesYDir);

	void Set_OutputDendriteInfo(int32_t firstOutputDendriteID, int32_t numOfOutputDendrites);
	void Set_OutputDendriteInfo(int32_t firstOutputDendriteID, int32_t numOfOutputDendritesXDir, int32_t numOfOutputDendritesYDir);

	void Set_LocalReceptiveFieldSizeInfo(int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY);

	
	void Connect_With_Brain(CSimpleNeuron *pNeuronArray);

	void Init_AdditionalMemoryValues(float *pMemoryValueArray, int32_t numOfAdditionalMemoryValues);
	void Init_AdditionalMemoryValues(int32_t numOfAdditionalMemoryValues);

	void Set_AdditionalMemoryValues(float *pMemoryValueArray);

	bool Compare_DataWithMemory(float *pDataArray);

	void Clone(CSimpleNeuron *pOriginalObject);
	void Clone_Values(CSimpleNeuron *pOriginalObject);

	void Init_Dendrite_Arrays(int32_t numOfDendriteElements);

	void Set_Dendrite_Data(float *pCentroidValueArray, float *pFactorArray);
	void Set_Dendrite_CentroidValues(float *pCentroidValueArray);
	void Set_Dendrite_Factors(float *pFactorArray);

	void Init_OutputSynapses(int32_t numOfOutputSynapses);
	void Init_OutputSynapses(int32_t numOfOutputSynapses, int32_t *pInReceiverNeuronIDArray, float *pInSynapsePlasticityArray);


	bool Load_Dendrite_Values(const char* pFilename, bool memoryAllocation = true);
	bool Save_Dendrite_Values(const char* pFilename);

	bool Load_Dendrite_Factors(const char* pFilename, bool memoryAllocation = true);
	bool Save_Dendrite_Factors(const char* pFilename);

	bool Load_Dendrite_Centroids(const char* pFilename, bool memoryAllocation = true);
	bool Save_Dendrite_Centroids(const char* pFilename);

	bool Load_AdditionalMemoryValues(const char* pFilename, bool memoryAllocation = true);
	bool Save_AdditionalMemoryValues(const char* pFilename);

	bool Load_OutputSynapsesData(const char* pFilename, bool memoryAllocation = true);
	bool Save_OutputSynapsesData(const char* pFilename);
	

	void Set_ActivationFunction(pActivationFunction pFunc);
	void Set_DendriticFunction(pDendriticFunction pFunc);

	void Reset_NumOfTrainingExamples(void);
	void Reset_NumOfTrainingExamples(int32_t minDendriteID, int32_t maxDendriteID);

	
	void Add_TrainingExample(float *pCentroidValueArray);
	void Add_TrainingExample(float *pCentroidValueArray, int32_t minDendriteID, int32_t maxDendriteID);

	/* Ein Aufruf der nachstehenden Methode bietet sich bsp. im Anschluss an einen Aufruf der Add_TrainingExample()-Methode an: */
	void Calculate_Dendrite_Factors_From_CentroidValues(float fallback_RBF_Factor = 0.0f, float centroidWeightFactor = 0.025f, int32_t centroidExponent = 2);
	/* Ein Aufruf der nachstehenden Methode bietet sich bsp. im Anschluss an einen Aufruf der Add_TrainingExample()-Methode an: */
	void Calculate_Dendrite_Factors_From_CentroidValues(int32_t minDendriteID, int32_t maxDendriteID, float fallback_RBF_Factor = 0.0f, float centroidWeightFactor = 0.025f, int32_t centroidExponent = 2);

	/* Hinweis: Wenn factor == 0.0f => Deaktivierung der betreffenden Dendriten. Dies ist bsp. f�r die Erkennung eines einzelnen Features (Merkmals) erforderlich. */
	void Set_Dendrite_Factor(float factor, float regardedCentroidValue);
	/* Hinweis: Wenn factor == 0.0f => Deaktivierung der betreffenden Dendriten. Dies ist bsp. f�r die Erkennung eines einzelnen Features (Merkmals) erforderlich. */
	void Set_Dendrite_Factor(float factor, float regardedCentroidValue, int32_t minDendriteID, int32_t maxDendriteID);
	/* Hinweis: Wenn factor == 0.0f => Deaktivierung der betreffenden Dendriten. Dies ist bsp. f�r die Erkennung eines einzelnen Features (Merkmals) erforderlich. */
	void Set_Dendrite_Factor(float factor, float lowerCentroidValueThreshold, float upperCentroidValueThreshold);
	/* Hinweis: Wenn factor == 0.0f => Deaktivierung der betreffenden Dendriten. Dies ist bsp. f�r die Erkennung eines einzelnen Features (Merkmals) erforderlich. */
	void Set_Dendrite_Factor(float factor, float lowerCentroidValueThreshold, float upperCentroidValueThreshold, int32_t minDendriteID, int32_t maxDendriteID);

	void Set_CentroidValue(float centroidValue, float lowerCentroidValueThreshold, float upperCentroidValueThreshold);
	
	void Set_CentroidValue(float centroidValue, float lowerCentroidValueThreshold, float upperCentroidValueThreshold, int32_t minDendriteID, int32_t maxDendriteID);

	void Set_AdditionalInputValue(float value);

	void Set_RandomSeedValue(int32_t newSeed);

	// Hinweis: Bei linearen (quadtatischen usw.) Aktivierungsfunktionen sollte ErrorFactor2 kleiner als 1.0f sein (z. B. 0.5f, 0.25f, 0.01f) 
	void Set_ErrorFactors(float factor1, float factor2);
	void Set_LearningRate(float learningRate);

	bool Set_Dendrite_NeuronInput(int32_t posX_left, int32_t posY_top, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY);

	bool Set_Dendrite_NeuronInput_UseCenterPos(int32_t posX_center, int32_t posY_center, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY);

	void Set_Dendrite_NeuronInput(float inputValue, int32_t dendriteID);
	void Set_Dendrite_NeuronInput(float *pInputValueArray, int32_t numOfInputvalues, int32_t usedDendritesMinID = 0);
	void Set_Dendrite_NeuronInput(float *pInputValueArray);

	void Get_Dendrite_NeuronOutput(float *pOutputValueArray);

	void Execute_DendriticCalculations(void);

	void Calculate_NeuronOutput(void);
	void Calculate_NeuronOutput_Ext(void);

	void Use_OtherNeuron_Dendrite_DataArray(float *pArray);
	void Use_OtherNeuron_Dendrite_DataArray(float *pArray, int32_t idFirstSourceDendrite);
	
	void Use_OtherNeuron_Dendrite_CentroidValueArray(float *pArray);
	void Use_OtherNeuron_Dendrite_CentroidValueArray(float *pArray, int32_t idFirstSourceDendrite);
	
	void Use_OtherNeuron_Dendrite_FactorArray(float *pArray);
	void Use_OtherNeuron_Dendrite_FactorArray(float *pArray, int32_t idFirstSourceDendrite);

	void Use_OtherNeuron_Dendrite_DataArray(int32_t connectionID, float *pArray);
	void Use_OtherNeuron_Dendrite_DataArray(int32_t connectionID, float *pArray, int32_t idFirstSourceDendrite);

	void Use_OtherNeuron_Dendrite_CentroidValueArray(int32_t connectionID, float *pArray);
	void Use_OtherNeuron_Dendrite_CentroidValueArray(int32_t connectionID, float *pArray, int32_t idFirstSourceDendrite);

	void Use_OtherNeuron_Dendrite_FactorArray(int32_t connectionID, float *pArray);
	void Use_OtherNeuron_Dendrite_FactorArray(int32_t connectionID, float *pArray, int32_t idFirstSourceDendrite);
	

	
	float Calculate_Error(float desiredNeuronOutput);
	float Calculate_Error(float desiredNeuronOutput, float errorFactor1, float errorFactor2);

	float Calculate_VarianceSq(float desiredNeuronOutput);

	/* Fehlerberechnung unter Ber�cksichtigung der bereits berechneten Fehler von
	s�mtlichen Receiver-Neuronen (nachgeschalteten Neuronen): */
	void Calculate_Error(void);
	void Calculate_Error(float errorFactor1, float errorFactor2);

	// Anpassung der Synapsen-Pastizit�t unter Ber�cksichtigung der zuvor berechneten Fehlerwerte:
	void Adjust_OutputSynapses_AfterErrorCalculations(void);
	void Adjust_OutputSynapses_AfterErrorCalculations(float learningRate);

	void Propagate_SynapticOutput(void);

	void SimpleAdjust_Dendrite_Factors_AfterErrorCalculations(float learningRate);
	
	void Adjust_Dendrite_Factors_AfterErrorCalculations(float learningRate);
	void Adjust_Dendrite_Factor_AfterErrorCalculations(float learningRate, int32_t dendriteID);
	void Adjust_Dendrite_Factors_AfterErrorCalculations(float learningRate, int32_t firstDendriteID, int32_t lastDendriteID);

	void Adjust_Dendrite_Factors_AfterErrorCalculations_ExternalInput(float learningRate);
	void Adjust_Dendrite_Factor_AfterErrorCalculations_ExternalInput(float learningRate, int32_t dendriteID);
	void Adjust_Dendrite_Factors_AfterErrorCalculations_ExternalInput(float learningRate, int32_t firstDendriteID, int32_t lastDendriteID);

	void Adjust_Dendrite_Factors_AfterErrorCalculations_ExternalInput(int32_t connectionID, float learningRate);
	void Adjust_Dendrite_Factor_AfterErrorCalculations_ExternalInput(int32_t connectionID, float learningRate, int32_t dendriteID);
	void Adjust_Dendrite_Factors_AfterErrorCalculations_ExternalInput(int32_t connectionID, float learningRate, int32_t firstDendriteID, int32_t lastDendriteID);

	
	
	

	float Adjust_Dendrite_Factors(float desiredNeuronOutput, float learningRate, float errorFactor1, float errorFactor2);
	float Adjust_Dendrite_Factors(float desiredNeuronOutput, float learningRate, float errorFactor1, float errorFactor2, int32_t firstDendriteID, int32_t lastDendriteID);

	float Adjust_Dendrite_Factors_ExternalInput(float desiredNeuronOutput, float learningRate, float errorFactor1, float errorFactor2);
	float Adjust_Dendrite_Factors_ExternalInput(float desiredNeuronOutput, float learningRate, float errorFactor1, float errorFactor2, int32_t firstDendriteID, int32_t lastDendriteID);

	float Adjust_Dendrite_Factors_ExternalInput(int32_t connectionID, float desiredNeuronOutput, float learningRate, float errorFactor1, float errorFactor2);
	float Adjust_Dendrite_Factors_ExternalInput(int32_t connectionID, float desiredNeuronOutput, float learningRate, float errorFactor1, float errorFactor2, int32_t firstDendriteID, int32_t lastDendriteID);


	void Round_Dendrite_Factors(float precision);
	void Round_Dendrite_CentroidValues(float precision);
	void Round_AdditionalMemoryValues(float precision);

	void Round_Dendrite_Factors(float precision, int32_t minDendriteID, int32_t maxDendriteID);
	void Round_Dendrite_CentroidValues(float precision, int32_t minDendriteID, int32_t maxDendriteID);
	void Round_AdditionalMemoryValues(float precision, int32_t minValueID, int32_t maxValueID);

	void Randomize_Dendrite_CentroidValues(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue);
	void Randomize_Dendrite_Factors(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue);
	void Randomize_Dendrite_CentroidValues(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, int32_t minDendriteID, int32_t maxDendriteID);
	void Randomize_Dendrite_Factors(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, int32_t minDendriteID, int32_t maxDendriteID);

	void Randomize_AdditionalMemoryValues(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue);
	void Randomize_AdditionalMemoryValues(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, int32_t minValueID, int32_t maxValueID);

	void Modify_Dendrite_CentroidValues(CRandomNumbersNN *pRandomNumbers, float minVariance, float maxVariance);
	void Modify_Dendrite_Factors(CRandomNumbersNN *pRandomNumbers, float minVariance, float maxVariance);
	void Modify_Dendrite_CentroidValues(CRandomNumbersNN *pRandomNumbers, float minVariance, float maxVariance, int32_t minDendriteID, int32_t maxDendriteID);
	void Modify_Dendrite_Factors(CRandomNumbersNN *pRandomNumbers, float minVariance, float maxVariance, int32_t minDendriteID, int32_t maxDendriteID);

	void Modify_AdditionalMemoryValues(CRandomNumbersNN *pRandomNumbers, float minVariance, float maxVariance);
	void Modify_AdditionalMemoryValues(CRandomNumbersNN *pRandomNumbers, float minVariance, float maxVariance, int32_t minValueID, int32_t maxValueID);

	void Randomize_Dendrite_CentroidValues(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float mutationRate);
	void Randomize_Dendrite_Factors(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float mutationRate);
	void Randomize_Dendrite_CentroidValues(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float mutationRate, int32_t minDendriteID, int32_t maxDendriteID);
	void Randomize_Dendrite_Factors(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float mutationRate, int32_t minDendriteID, int32_t maxDendriteID);

	void Randomize_AdditionalMemoryValues(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float mutationRate);
	void Randomize_AdditionalMemoryValues(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float mutationRate, int32_t minValueID, int32_t maxValueID);

	void Modify_Dendrite_CentroidValues(CRandomNumbersNN *pRandomNumbers, float minVariance, float maxVariance, float mutationRate);
	void Modify_Dendrite_Factors(CRandomNumbersNN *pRandomNumbers, float minVariance, float maxVariance, float mutationRate);
	void Modify_Dendrite_CentroidValues(CRandomNumbersNN *pRandomNumbers, float minVariance, float maxVariance, float mutationRate, int32_t minDendriteID, int32_t maxDendriteID);
	void Modify_Dendrite_Factors(CRandomNumbersNN *pRandomNumbers, float minVariance, float maxVariance, float mutationRate, int32_t minDendriteID, int32_t maxDendriteID);

	void Modify_AdditionalMemoryValues(CRandomNumbersNN *pRandomNumbers, float minVariance, float maxVariance, float mutationRate);
	void Modify_AdditionalMemoryValues(CRandomNumbersNN *pRandomNumbers, float minVariance, float maxVariance, float mutationRate, int32_t minValueID, int32_t maxValueID);

	void Permute_Dendrite_Values(CRandomNumbersNN *pRandomNumbers, int32_t permutationSteps);
	void Permute_Dendrite_Values(CRandomNumbersNN *pRandomNumbers, int32_t minDendriteID, int32_t maxDendriteID, int32_t permutationSteps);

	void Permute_Dendrite_CentroidValues(CRandomNumbersNN *pRandomNumbers, int32_t permutationSteps);
	void Permute_Dendrite_CentroidValues(CRandomNumbersNN *pRandomNumbers, int32_t minDendriteID, int32_t maxDendriteID, int32_t permutationSteps);

	void Permute_Dendrite_Factors(CRandomNumbersNN *pRandomNumbers, int32_t permutationSteps);
	void Permute_Dendrite_Factors(CRandomNumbersNN *pRandomNumbers, int32_t minDendriteID, int32_t maxDendriteID, int32_t permutationSteps);

	void Permute_AdditionalMemoryValues(CRandomNumbersNN *pRandomNumbers, int32_t permutationSteps);
	void Permute_AdditionalMemoryValues(CRandomNumbersNN *pRandomNumbers, int32_t minValueID, int32_t maxValueID, int32_t permutationSteps);

	void Mutate(pMutationFunction pFunc, CRandomNumbersNN *pRandomNumbers, void *pParam);
	void Reinitialize(pReinitializationFunction pFunc, CRandomNumbersNN *pRandomNumbers, void *pParam);
	void Permute(pPermutationFunction pFunc, CRandomNumbersNN *pRandomNumbers, void *pParam);
	void Recombination(pRecombinationFunction pFunc, CSimpleNeuron *pParent1, CSimpleNeuron *pParent2, CRandomNumbersNN *pRandomNumbers, void *pParam);
	
};



class CSimpleNeuralNetData
{
public:

	int32_t NumOfNeurons = 0;
	CSimpleNeuron **ppNeuronArray = nullptr;

	int32_t NumLRFNeurons_Layer1 = 0;
	int32_t NumLRFNeurons_Layer2 = 0;
	//int32_t NumLRFNeurons_Layer3 = 0;
	//int32_t NumLRFNeurons_Layer4 = 0;

	int32_t NumOfInputNeurons = 0;
	int32_t NumOfOutputNeurons = 0;
	int32_t NeuronCalculationSequenceLength = 0;
	int32_t *pNeuronCalculationSequenceArray = nullptr;

	float FitnessScore = 0.0f;

	CSimpleNeuralNetData();
	~CSimpleNeuralNetData();

	// Kopierkonstruktor l�schen:
	CSimpleNeuralNetData(const CSimpleNeuralNetData  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CSimpleNeuralNetData & operator=(const CSimpleNeuralNetData  &originalObject) = delete;

	void Init_Data(int32_t numOfNeurons);
	void Reset_Data(void);

	void Set_Neuron(CSimpleNeuron *pNeuron, int32_t neuronID);

	void Clone_Values(CSimpleNeuralNetData *pOriginalObject);

	void Init_NeuronCalculationSequence(int32_t neuronCalculationSequenceLength, int32_t numOfInputNeurons, int32_t numOfOutputNeurons);

	void Set_NeuronCalculationSequenceEntry(int32_t neuronID, int32_t entryID);

};


void Search_Pattern(int32_t *pOutPatternCount, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CSimpleNeuron *pDetectionNeuron, float minActivationValue);

void Search_Pattern(float *pOutPatternCount, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CSimpleNeuron *pDetectionNeuron, float minActivationValue);

void Search_Pattern(int32_t *pOutPatternCount, float *pOutValueSum, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CSimpleNeuron *pDetectionNeuron, float minActivationValue);

void Search_Pattern(float *pOutPatternCount, float *pOutValueSum, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CSimpleNeuron *pDetectionNeuron, float minActivationValue);

void Search_Pattern(int32_t *pOutPatternCount, int32_t *pOutPatternPosXArray, int32_t *pOutPatternPosYArray, int32_t numPatternPositionsMax, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CSimpleNeuron *pDetectionNeuron, float minActivationValue);

void Search_Pattern(float *pOutPatternCount, float *pOutPatternPosXArray, float *pOutPatternPosYArray, int32_t numPatternPositionsMax, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CSimpleNeuron *pDetectionNeuron, float minActivationValue);

void Search_Pattern(CSimpleFeatureMap *pFeatureMap, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CSimpleNeuron *pDetectionNeuron, bool addValuesToFeatureMap = false);

void Search_Patterns(CSimpleFeatureMap *pFeatureMapArray, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CSimpleNeuron *pDetectionNeuronArray, int32_t numPatterns, bool addValuesToFeatureMap = false);




void Search_Pattern(int32_t *pOutPatternCount, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CSimpleNeuron *pSectorExaminationNeuron, CSimpleNeuron *pDetectionNeuron, float minActivationValue);

void Search_Pattern(float *pOutPatternCount, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CSimpleNeuron *pSectorExaminationNeuron, CSimpleNeuron *pDetectionNeuron, float minActivationValue);

void Search_Pattern(int32_t *pOutPatternCount, float *pOutValueSum, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CSimpleNeuron *pSectorExaminationNeuron, CSimpleNeuron *pDetectionNeuron, float minActivationValue);

void Search_Pattern(float *pOutPatternCount, float *pOutValueSum, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CSimpleNeuron *pSectorExaminationNeuron, CSimpleNeuron *pDetectionNeuron, float minActivationValue);

void Search_Pattern(int32_t *pOutPatternCount, int32_t *pOutPatternPosXArray, int32_t *pOutPatternPosYArray, int32_t numPatternPositionsMax, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CSimpleNeuron *pSectorExaminationNeuron, CSimpleNeuron *pDetectionNeuron, float minActivationValue);

void Search_Pattern(float *pOutPatternCount, float *pOutPatternPosXArray, float *pOutPatternPosYArray, int32_t numPatternPositionsMax, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CSimpleNeuron *pSectorExaminationNeuron, CSimpleNeuron *pDetectionNeuron, float minActivationValue);

void Search_Pattern(CSimpleFeatureMap *pFeatureMap, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CSimpleNeuron *pSectorExaminationNeuron, CSimpleNeuron *pDetectionNeuron, bool addValuesToFeatureMap = false);

void Search_Patterns(CSimpleFeatureMap *pFeatureMapArray, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CSimpleNeuron *pSectorExaminationNeuron, CSimpleNeuron *pDetectionNeuronArray, int32_t numPatterns,  bool addValuesToFeatureMap = false);







class CSingleRecognitionNeuronEnsemble
{
public:

	int32_t NumOfNeurons = 0;
	CSimpleNeuron *pNeuronArray = nullptr;
	float *pActivationValueArray = nullptr;

	int32_t NumOfUsedMemoryNeurons = 0;

	CSingleRecognitionNeuronEnsemble();
	~CSingleRecognitionNeuronEnsemble();

	// Kopierkonstruktor l�schen:
	CSingleRecognitionNeuronEnsemble(const CSingleRecognitionNeuronEnsemble  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CSingleRecognitionNeuronEnsemble & operator=(const CSingleRecognitionNeuronEnsemble  &originalObject) = delete;

	void Init_NeuronArray(int32_t numOfNeurons, int32_t numOfDendriteElements, pActivationFunction pFunc);
	void Init_NeuronArray(int32_t numOfNeurons, int32_t numOfDendriteElements, int32_t numOfAdditionalMemoryValues, pActivationFunction pFunc);
	
	void Reset_NumOfUsedMemoryNeurons(void);

	void Reset_NumOfTrainingExamples(void);
	void Reset_NumOfTrainingExamples(int32_t minNeuronID, int32_t maxNeuronID);
	
	

	void Calculate_NeuronOutputs(void);
	void Calculate_NeuronOutputs(int32_t minNeuronID, int32_t maxNeuronID);

	void Calculate_NeuronOutputs_Ext(void);
	void Calculate_NeuronOutputs_Ext(int32_t minNeuronID, int32_t maxNeuronID);

	void Get_MaxActivationValue(float *pOutActivationValue, int32_t *pOutBelongingNeuronID);
	void Get_MinActivationValue(float *pOutActivationValue, int32_t *pOutBelongingNeuronID);

	void Get_MaxActivationValue(float *pOutActivationValue, int32_t *pOutBelongingNeuronID, int32_t minNeuronID, int32_t maxNeuronID);
	void Get_MinActivationValue(float *pOutActivationValue, int32_t *pOutBelongingNeuronID, int32_t minNeuronID, int32_t maxNeuronID);

	int32_t Get_ID_Of_MinimumTrainedNeuron(void);
	int32_t Get_ID_Of_MinimumTrainedNeuron(int32_t minNeuronID, int32_t maxNeuronID);

	int32_t Get_ID_Of_MaximumTrainedNeuron(void);
	int32_t Get_ID_Of_MaximumTrainedNeuron(int32_t minNeuronID, int32_t maxNeuronID);


	void Set_Dendrite_NeuronInput(int32_t posX_left, int32_t posY_top, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY);

	void Set_Dendrite_NeuronInput(int32_t posX_left, int32_t posY_top, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, int32_t minNeuronID, int32_t maxNeuronID);



	void Set_Dendrite_NeuronInput_UseCenterPos(int32_t posX_center, int32_t posY_center, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY);

	void Set_Dendrite_NeuronInput_UseCenterPos(int32_t posX_center, int32_t posY_center, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, int32_t minNeuronID, int32_t maxNeuronID);



	
	int32_t Add_Dendrite_CentroidValues_And_Calculate_Dendrite_Factors_From_CentroidValues(int32_t posX_left, int32_t posY_top, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float fallback_RBF_Factor, float centroidWeightFactor, int32_t centroidExponent, float upperActivationThreshold = 0.9f, float lowerActivationThreshold = 0.91f);


	int32_t Add_Dendrite_CentroidValues_And_Calculate_Dendrite_Factors_From_CentroidValues(int32_t posX_left, int32_t posY_top, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float fallback_RBF_Factor, float centroidWeightFactor, int32_t centroidExponent, int32_t minNeuronID, int32_t maxNeuronID, float upperActivationThreshold = 0.9f, float lowerActivationThreshold = 0.91f);



	int32_t Add_Dendrite_CentroidValues_And_Calculate_Dendrite_Factors_From_CentroidValues_UseCenterPos(int32_t posX_center, int32_t posY_center, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float fallback_RBF_Factor, float centroidWeightFactor, int32_t centroidExponent, float upperActivationThreshold = 0.9f, float lowerActivationThreshold = 0.91f);


	int32_t Add_Dendrite_CentroidValues_And_Calculate_Dendrite_Factors_From_CentroidValues_UseCenterPos(int32_t posX_center, int32_t posY_center, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float fallback_RBF_Factor, float centroidWeightFactor, int32_t centroidExponent, int32_t minNeuronID, int32_t maxNeuronID, float upperActivationThreshold = 0.9f, float lowerActivationThreshold = 0.91f);


	bool Set_AdditionalMemoryValues(float *pMemoryValueArray);
	int32_t Compare_DataWithMemory(float *pDataArray);

	bool Load_AdditionalMemoryValues(const char* pFilename);
	bool Save_AdditionalMemoryValues(const char* pFilename);

	bool Load_Dendrite_Values(const char* pFilename);
	bool Save_Dendrite_Values(const char* pFilename);

	bool Load_Dendrite_Factors(const char* pFilename);
	bool Save_Dendrite_Factors(const char* pFilename);
	
	bool Load_Dendrite_Centroids(const char* pFilename);
	bool Save_Dendrite_Centroids(const char* pFilename);
};



class CSimpleNeuronPopulation
{
public:

	uint64_t Seed = 1;
	CRandomNumbersNN RandomNumbers;

	int32_t PopulationSize;
	int32_t PopulationSizePlusX;

	static constexpr int32_t constNumOfAdditionalBrains = 5;
	static constexpr int32_t constNumOfRandomBrainsChildren = constNumOfAdditionalBrains - 3;

	CSimpleNeuron **ppNeuronArray = nullptr;
	float *pFitnessScoreArray = nullptr;

	static constexpr int32_t constNumOfBestFittedBrains = 10;
	int32_t IDArrayOfBestFittedBrains[constNumOfBestFittedBrains];
	float FitnessArrayOfBestFittedBrains[constNumOfBestFittedBrains];

	static constexpr int32_t constNumOfWorstFittedBrains = 10;
	int32_t IDArrayOfWorstFittedBrains[constNumOfWorstFittedBrains];
	float FitnessArrayOfWorstFittedBrains[constNumOfWorstFittedBrains];

	bool UseAdditionalMutatedBestBrain = false;
	bool UseAdditionalMutatedSecondBestBrain = false;
	bool UseAdditionalBestBrainsChild = false;
	bool UseAdditionalRandomBrainsChild[constNumOfRandomBrainsChildren];

	int32_t RandomBrainsChildCounter = 0;

	static constexpr int32_t constNumPopulationSearchStepsMax = 3;

	float MinErrorSum_ActualGeneration;

	CSimpleNeuronPopulation();
	~CSimpleNeuronPopulation();

	// Kopierkonstruktor l�schen:
	CSimpleNeuronPopulation(const CSimpleNeuronPopulation &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CSimpleNeuronPopulation& operator=(const CSimpleNeuronPopulation &originalObject) = delete;

	bool Initialize(int32_t populationSize);
	void Set_Neuron(CSimpleNeuron *pNeuron, int32_t id);

	void Init_Or_Reinitialize_Dendrite_Arrays(int32_t numOfDendriteElements);

	void Init_Or_Reinitialize_AdditionalMemoryValues(int32_t numOfAdditionalMemoryValues);



	void Set_ActivationFunction(pActivationFunction pFunc);
	void Set_DendriticFunction(pDendriticFunction pFunc);

	CSimpleNeuron* Get_Best_Evolved_Neuron(void);
	void Get_Best_Evolved_Neuron(CSimpleNeuron* pOutNeuron);

	void Change_Seed(uint64_t seed);

	void Reset_MinErrorSum_ActualGeneration(float value = 10000000.0f);
	void Update_MinErrorSum_ActualGeneration(float value);

	void Set_Dendrite_Data(int32_t neuronID, float *pCentroidValueArray, float *pFactorArray);
	void Set_Dendrite_Data(float *pCentroidValueArray, float *pFactorArray);

	void Set_Dendrite_CentroidValues(int32_t neuronID, float *pCentroidValueArray);
	void Set_Dendrite_CentroidValues(float *pCentroidValueArray);

	void Set_Dendrite_Factors(int32_t neuronID, float *pFactorArray);
	void Set_Dendrite_Factors(float *pFactorArray);

	void Set_AdditionalMemoryValues(int32_t neuronID, float *pMemoryValueArray);
	void Set_AdditionalMemoryValues(float *pMemoryValueArray);

	void Round_Dendrite_CentroidValues(float precision);
	void Round_Dendrite_Factors(float precision);
	void Round_AdditionalMemoryValues(float precision);

	void Round_Dendrite_CentroidValues(float precision, int32_t minDendriteID, int32_t maxDendriteID);
	void Round_Dendrite_Factors(float precision, int32_t minDendriteID, int32_t maxDendriteID);
	void Round_AdditionalMemoryValues(float precision, int32_t minValueID, int32_t maxValueID);

	void Randomize_Dendrite_CentroidValues(float minValue, float maxValue);
	void Randomize_Dendrite_Factors(float minValue, float maxValue);
	void Randomize_Dendrite_CentroidValues(float minValue, float maxValue, int32_t minDendriteID, int32_t maxDendriteID);
	void Randomize_Dendrite_Factors(float minValue, float maxValue, int32_t minDendriteID, int32_t maxDendriteID);

	void Randomize_AdditionalMemoryValues(float minValue, float maxValue);
	void Randomize_AdditionalMemoryValues(float minValue, float maxValue, int32_t minValueID, int32_t maxValueID);

	void Modify_Dendrite_CentroidValues(float minVariance, float maxVariance);
	void Modify_Dendrite_Factors(float minVariance, float maxVariance);
	void Modify_Dendrite_CentroidValues(float minVariance, float maxVariance, int32_t minDendriteID, int32_t maxDendriteID);
	void Modify_Dendrite_Factors(float minVariance, float maxVariance, int32_t minDendriteID, int32_t maxDendriteID);

	void Modify_AdditionalMemoryValues(float minVariance, float maxVariance);
	void Modify_AdditionalMemoryValues(float minVariance, float maxVariance, int32_t minValueID, int32_t maxValueID);

	void Randomize_Dendrite_CentroidValues(float minValue, float maxValue, float mutationRate);
	void Randomize_Dendrite_Factors(float minValue, float maxValue, float mutationRate);
	void Randomize_Dendrite_CentroidValues(float minValue, float maxValue, float mutationRate, int32_t minDendriteID, int32_t maxDendriteID);
	void Randomize_Dendrite_Factors(float minValue, float maxValue, float mutationRate, int32_t minDendriteID, int32_t maxDendriteID);

	void Randomize_AdditionalMemoryValues(float minValue, float maxValue, float mutationRate);
	void Randomize_AdditionalMemoryValues(float minValue, float maxValue, float mutationRate, int32_t minValueID, int32_t maxValueID);

	void Modify_Dendrite_CentroidValues(float minVariance, float maxVariance, float mutationRate);
	void Modify_Dendrite_Factors(float minVariance, float maxVariance, float mutationRate);
	void Modify_Dendrite_CentroidValues(float minVariance, float maxVariance, float mutationRate, int32_t minDendriteID, int32_t maxDendriteID);
	void Modify_Dendrite_Factors(float minVariance, float maxVariance, float mutationRate, int32_t minDendriteID, int32_t maxDendriteID);

	void Modify_AdditionalMemoryValues(float minVariance, float maxVariance, float mutationRate);
	void Modify_AdditionalMemoryValues(float minVariance, float maxVariance, float mutationRate, int32_t minValueID, int32_t maxValueID);
	
	void Reinitialize_Dendrite_Values(pReinitializationFunction pFunc, void *pParam);
	void Mutate_Dendrite_Values(pMutationFunction pFunc, void *pParam);
	void Permute_Dendrite_Values(pPermutationFunction pFunc, void *pParam);

	void Reinitialize_AdditionalMemoryValues(pReinitializationFunction pFunc, void *pParam);
	void Mutate_AdditionalMemoryValues(pMutationFunction pFunc, void *pParam);
	void Permute_AdditionalMemoryValues(pPermutationFunction pFunc, void *pParam);
	

	void Update_Evolution_Combine_BestTwoBrains(pRecombinationFunction pFunc, void *pParam);
	void Update_Evolution_Combine_TwoBrains(pRecombinationFunction pFunc, void *pParam);

	void Update_BaseEvolution(pMutationFunction pFunc, void *pParam);
	void Update_BaseEvolution2(pPermutationFunction pFunc, void *pParam);

	void Update_Evolution_BestBrainOnly(pMutationFunction pFunc, void *pParam);
	void Update_Evolution_BestBrainOnly2(pPermutationFunction pFunc, void *pParam);

	void Update_Evolution_SecondBestBrainOnly(pMutationFunction pFunc, void *pParam);
	void Update_Evolution_SecondBestBrainOnly2(pPermutationFunction pFunc, void *pParam);

	
	void Update_Population(float *pFitnessValueArray);
	void Update_Population(void);

	void Update_Population_Ext(float *pFitnessValueArray);
	void Update_Population_Ext(void);

	void Update_PopulationKnowledge(int32_t minDendriteID, int32_t maxDendriteID, int32_t minMemoryValueID, int32_t maxmemoryValueID);

	void Replace_WorstFitted_Brain(pReinitializationFunction pFunc, void *pParam);
	void Replace_SecondWorstFitted_Brain(pReinitializationFunction pFunc, void *pParam);
	void Replace_ThirdWorstFitted_Brain(pReinitializationFunction pFunc, void *pParam);

	void Replace_WorstFitted_Brain(uint64_t seed, pReinitializationFunction pFunc, void *pParam);
	void Replace_SecondWorstFitted_Brain(uint64_t seed, pReinitializationFunction pFunc, void *pParam);
	void Replace_ThirdWorstFitted_Brain(uint64_t seed, pReinitializationFunction pFunc, void *pParam);
	
};

class CSimpleNeuralNetPopulation
{
public:

	uint64_t Seed = 1;
	CRandomNumbersNN RandomNumbers;

	int32_t PopulationSize;
	int32_t PopulationSizePlusX;

	static constexpr int32_t constNumOfAdditionalBrains = 5;
	static constexpr int32_t constNumOfRandomBrainsChildren = constNumOfAdditionalBrains - 3;

	CSimpleNeuralNetData **ppSimpleNeuralNetDataArray = nullptr;
	float *pFitnessScoreArray = nullptr;

	static constexpr int32_t constNumOfBestFittedBrains = 10;
	int32_t IDArrayOfBestFittedBrains[constNumOfBestFittedBrains];
	float FitnessArrayOfBestFittedBrains[constNumOfBestFittedBrains];

	static constexpr int32_t constNumOfWorstFittedBrains = 10;
	int32_t IDArrayOfWorstFittedBrains[constNumOfWorstFittedBrains];
	float FitnessArrayOfWorstFittedBrains[constNumOfWorstFittedBrains];

	bool UseAdditionalMutatedBestBrain = false;
	bool UseAdditionalMutatedSecondBestBrain = false;
	bool UseAdditionalBestBrainsChild = false;
	bool UseAdditionalRandomBrainsChild[constNumOfRandomBrainsChildren];

	int32_t RandomBrainsChildCounter = 0;

	static constexpr int32_t constNumPopulationSearchStepsMax = 3;

	float MinErrorSum_ActualGeneration;

	CSimpleNeuralNetPopulation();
	~CSimpleNeuralNetPopulation();

	// Kopierkonstruktor l�schen:
	CSimpleNeuralNetPopulation(const CSimpleNeuralNetPopulation &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CSimpleNeuralNetPopulation& operator=(const CSimpleNeuralNetPopulation &originalObject) = delete;

	bool Initialize(int32_t populationSize);
	void Set_SimpleNeuralNet(CSimpleNeuralNetData *pNeuronNetData, int32_t id);

	void Calculate_FitnessScore_FromError(int32_t neuralNetID, float error);

	CSimpleNeuralNetData* Get_Best_Evolved_NeuralNet(void);
	void Get_Best_Evolved_NeuralNet(CSimpleNeuralNetData* pOutSimpleNeuralNet);

	void Change_Seed(uint64_t seed);

	void Reset_MinErrorSum_ActualGeneration(float value = 10000000.0f);
	void Update_MinErrorSum_ActualGeneration(float value);

	void Round_Dendrite_CentroidValues(float precision);
	void Round_Dendrite_Factors(float precision);
	void Round_AdditionalMemoryValues(float precision);

	void Randomize_Dendrite_CentroidValues(float minValue, float maxValue);
	void Randomize_Dendrite_Factors(float minValue, float maxValue);
	
	void Randomize_AdditionalMemoryValues(float minValue, float maxValue);
	
	void Modify_Dendrite_CentroidValues(float minVariance, float maxVariance);
	void Modify_Dendrite_Factors(float minVariance, float maxVariance);
	
	void Modify_AdditionalMemoryValues(float minVariance, float maxVariance);
	
	void Randomize_Dendrite_CentroidValues(float minValue, float maxValue, float mutationRate);
	void Randomize_Dendrite_Factors(float minValue, float maxValue, float mutationRate);
	
	void Randomize_AdditionalMemoryValues(float minValue, float maxValue, float mutationRate);
	
	void Modify_Dendrite_CentroidValues(float minVariance, float maxVariance, float mutationRate);
	void Modify_Dendrite_Factors(float minVariance, float maxVariance, float mutationRate);
	
	void Modify_AdditionalMemoryValues(float minVariance, float maxVariance, float mutationRate);
	

	void Reinitialize_Dendrite_Values(pNetReinitializationFunction pFunc, void *pParam);
	void Mutate_Dendrite_Values(pNetMutationFunction pFunc, void *pParam);
	void Permute_Dendrite_Values(pNetPermutationFunction pFunc, void *pParam);

	void Reinitialize_AdditionalMemoryValues(pNetReinitializationFunction pFunc, void *pParam);
	void Mutate_AdditionalMemoryValues(pNetMutationFunction pFunc, void *pParam);
	void Permute_AdditionalMemoryValues(pNetPermutationFunction pFunc, void *pParam);


	void Update_Evolution_Combine_BestTwoBrains(pNetRecombinationFunction pFunc, void *pParam);
	void Update_Evolution_Combine_TwoBrains(pNetRecombinationFunction pFunc, void *pParam);

	void Update_BaseEvolution(pNetMutationFunction pFunc, void *pParam);
	void Update_BaseEvolution2(pNetPermutationFunction pFunc, void *pParam);

	void Update_Evolution_BestBrainOnly(pNetMutationFunction pFunc, void *pParam);
	void Update_Evolution_BestBrainOnly2(pNetPermutationFunction pFunc, void *pParam);

	void Update_Evolution_SecondBestBrainOnly(pNetMutationFunction pFunc, void *pParam);
	void Update_Evolution_SecondBestBrainOnly2(pNetPermutationFunction pFunc, void *pParam);

	void Update_Population(void);
	void Update_Population_Ext(void);

	void Update_PopulationKnowledge(void);


	void Replace_WorstFitted_Brain(pNetReinitializationFunction pFunc, void *pParam);
	void Replace_SecondWorstFitted_Brain(pNetReinitializationFunction pFunc, void *pParam);
	void Replace_ThirdWorstFitted_Brain(pNetReinitializationFunction pFunc, void *pParam);

	void Replace_WorstFitted_Brain(uint64_t seed, pNetReinitializationFunction pFunc, void *pParam);
	void Replace_SecondWorstFitted_Brain(uint64_t seed, pNetReinitializationFunction pFunc, void *pParam);
	void Replace_ThirdWorstFitted_Brain(uint64_t seed, pNetReinitializationFunction pFunc, void *pParam);

};

class CSimpleNeuralNet_1HiddenLayer
{
public:

	int32_t NumOfInputValues = 0;
	int32_t NumOfOutputValues = 0;

	CSimpleNeuron PrecedingNeuron;

	CSimpleNeuron *pOutputNeuronArray = nullptr;

	CSimpleNeuralNet_1HiddenLayer();
	~CSimpleNeuralNet_1HiddenLayer();

	// Kopierkonstruktor l�schen:
	CSimpleNeuralNet_1HiddenLayer(const CSimpleNeuralNet_1HiddenLayer  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CSimpleNeuralNet_1HiddenLayer & operator=(const CSimpleNeuralNet_1HiddenLayer  &originalObject) = delete;

	void Get_SimpleNeuralNetData(CSimpleNeuralNetData *pOutData);
	

	void Init_PrecedingNeuron(int32_t numOfInputValues, int32_t numOfHiddenDendrites, pDendriticFunction pFunc, float *pMemoryValueArray, int32_t numOfAdditionalMemoryValues);

	void Init_PrecedingNeuron(int32_t numOfInputValues, int32_t numOfHiddenDendrites, pDendriticFunction pFunc, CRandomNumbersNN *pRandomNumbers, float minDendriteFactor, float maxDendriteFactor, float minDendriteAbsFactor = 0.0f, float maxDendriteAbsFactor = 0.5f);

	void Init_OutputNeuronArray(int32_t numOfOutputValues, int32_t numOfHiddenDendrites, pActivationFunction pFunc, CRandomNumbersNN *pRandomNumbers, float minDendriteFactor, float maxDendriteFactor);

	void Use_OtherNeuralNetOutput_As_Input(CSimpleNeuralNet_1HiddenLayer* pNeuralNet, int32_t firstInputDendriteID);

	void Calculate_Output(void);
	float CalculateAndReturn_MaxOutput(void);
	float CalculateAndReturn_MinOutput(void);
	void CalculateAndReturn_Output(float *pOutputValueArray);

	// simple extreme learning:
	float OutputNeurons_Adjust_Dendrite_Factors(float *pDesiredOutputValueArray, float learningRate, float errorFactor1, float errorFactor2);

	float OutputNeurons_ErrorCalculations(float *pDesiredOutputValueArray, float errorFactor1, float errorFactor2);

	float OutputNeurons_Calculate_VarianceSq(float *pDesiredOutputValueArray);

	void OutputNeurons_Adjust_Dendrite_Factors_AfterErrorCalculations(float learningRate);

	bool Load_Data(char *pFileName, pDendriticFunction pDendriticFunc, pActivationFunction pActivationFunc);
	bool Save_Data(char *pFileName);
};




class CSimpleNeuronAutoEncoder
{
public:

	int32_t NumOfInputOutputValues = 0;

	CSimpleNeuron PrecedingNeuron;

	CSimpleNeuron *pOutputNeuronArray = nullptr;

	CSimpleNeuron *pExternalSingleRecognitionNeuron = nullptr;

	CSimpleNeuronAutoEncoder();
	~CSimpleNeuronAutoEncoder();



	// Kopierkonstruktor l�schen:
	CSimpleNeuronAutoEncoder(const CSimpleNeuronAutoEncoder  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CSimpleNeuronAutoEncoder & operator=(const CSimpleNeuronAutoEncoder  &originalObject) = delete;

	void Get_SimpleNeuralNetData(CSimpleNeuralNetData *pOutData);
	

	void Set_ExternalSingleRecognitionNeuron(CSimpleNeuron *pNeuron);

	void Init_PrecedingNeuron(int32_t numOfInputOutputValues, int32_t numOfOfEncodingDendrites, pDendriticFunction pFunc, float *pMemoryValueArray, int32_t numOfAdditionalMemoryValues);

	void Init_PrecedingNeuron(int32_t numOfInputOutputValues, int32_t numOfOfEncodingDendrites, pDendriticFunction pFunc, CRandomNumbersNN *pRandomNumbers, float minDendriteFactor, float maxDendriteFactor, float minDendriteAbsFactor = 0.0f, float maxDendriteAbsFactor = 0.5f);

	void Init_OutputNeuronArray(int32_t numOfInputOutputValues, int32_t numOfEncodingDendrites, pActivationFunction pFunc, CRandomNumbersNN *pRandomNumbers, float minDendriteFactor, float maxDendriteFactor);

	void Init_OutputNeuronArray(int32_t numOfInputOutputValues, int32_t numOfEncodingDendrites, pActivationFunction pFunc);

	void Calculate_Output(void);
	float Calculate_Output_Return_InputOutputVarianceSq(void);
	float Calculate_Output_Return_VarianceSq(float *pDesiredOutputValueArray);

	void Calculate_Output(float *pOutputValueArray);
	float CalculateAndReturn_Output_Return_InputOutputVarianceSq(float *pOutputValueArray);
	float CalculateAndReturn_Output_Return_VarianceSq(float *pOutputValueArray, float *pDesiredOutputValueArray);


	// simple extreme learning:
	float OutputNeurons_Adjust_Dendrite_Factors(float learningRate, float errorFactor1, float errorFactor2);
	float OutputNeurons_Adjust_Dendrite_Factors(float *pDesiredOutputValueArray, float learningRate, float errorFactor1, float errorFactor2);

	float OutputNeurons_ErrorCalculations(float errorFactor1, float errorFactor2);
	float OutputNeurons_ErrorCalculations(float *pDesiredOutputValueArray, float errorFactor1, float errorFactor2);

	void OutputNeurons_Adjust_Dendrite_Factors_AfterErrorCalculations(float learningRate);	

	float OutputNeurons_Calculate_VarianceSq(float *pDesiredOutputValueArray);

	bool Load_Data(char *pFileName, pDendriticFunction pDendriticFunc, pActivationFunction pActivationFunc);
	bool Save_Data(char *pFileName);
};


class CSimpleDeepNeuralNet_Base
{
public:

	int32_t NumLRFNeurons_Layer1 = 5;


	CSimpleNeuron *pLRFNeuronArray_Layer1 = nullptr;  // z. B. LRF-Size: 5x5 + 1 Bias
	

	CSimpleFeatureMap *pFeatureMapArray_Layer1 = nullptr;
	CSimpleFeatureMap *pHalfResFeatureMapArray_Layer1 = nullptr;
	CSimpleFeatureMap *pQuarterResFeatureMapArray_Layer1 = nullptr;

	CSimpleNeuralNet_1HiddenLayer ProcessingNeuralNet;

	int32_t InputVectorSizeX = 0;
	int32_t InputVectorSizeY = 0;

	int32_t HalfInputVectorSizeX = 0;
	int32_t HalfInputVectorSizeY = 0;
	int32_t HalfInputVectorSizeXY = 0;

	int32_t QuarterInputVectorSizeX = 0;
	int32_t QuarterInputVectorSizeY = 0;
	int32_t QuarterInputVectorSizeXY = 0;

	int32_t ProcessingNeuralNet_NumOfInputValues = 0;
	int32_t ProcessingNeuralNet_NumOfHiddenDendrites = 0;
	int32_t ProcessingNeuralNet_NumOfOutputValues = 0;

	CSimpleDeepNeuralNet_Base();
	~CSimpleDeepNeuralNet_Base();

	// Kopierkonstruktor l�schen:
	CSimpleDeepNeuralNet_Base(const CSimpleDeepNeuralNet_Base  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CSimpleDeepNeuralNet_Base & operator=(const CSimpleDeepNeuralNet_Base  &originalObject) = delete;

	void Initialize(CRandomNumbersNN *pLRFRandomNumbers, CRandomNumbersNN *pNeuralNetRandomNumbers, int32_t numLRFNeurons_Layer1, int32_t LRFSizeX_Layer1, int32_t LRFSizeY_Layer1, float LRF_MinRandomFactor, float LRF_MaxRandomFactor, int32_t inputVectorSizeX, int32_t inputVectorSizeY, int32_t processingNeuralNet_NumOfHiddenDendrites, int32_t processingNeuralNet_NumOfOutputValues);

	void Get_SimpleNeuralNetData(CSimpleNeuralNetData *pOutData);


	void Calculate_Output(float *pInputMap, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1);

	float OutputNeurons_Calculate_VarianceSq(float *pDesiredOutputValueArray);

	void BackpropagationTraining(float *pInOutError, float *pDesiredOutputValuesArray);
};

class CSimpleDeepNeuralNet_Test1
{
public:

	int32_t NumLRFNeurons_Layer1 = 5;
	int32_t NumLRFNeurons_Layer2 = 3;

	CSimpleNeuron *pLRFNeuronArray_Layer1 = nullptr;  // z. B. LRF-Size: 5x5 + 1 Bias
	CSimpleNeuron *pLRFNeuronArray_Layer2 = nullptr;  // z. B.LRF-Size: 5x5 + 1 Bias

	CSimpleFeatureMap *pFeatureMapArray_Layer1 = nullptr;
	CSimpleFeatureMap *pHalfResFeatureMapArray_Layer1 = nullptr;

	CSimpleFeatureMap *pFeatureMapArray_Layer2 = nullptr;
	CSimpleFeatureMap *pHalfResFeatureMapArray_Layer2 = nullptr;

	CSimpleNeuralNet_1HiddenLayer ProcessingNeuralNet;

	int32_t InputVectorSizeX = 0;
	int32_t InputVectorSizeY = 0;

	int32_t HalfInputVectorSizeX = 0;
	int32_t HalfInputVectorSizeY = 0;

	int32_t QuarterInputVectorSizeX = 0;
	int32_t QuarterInputVectorSizeY = 0;

	int32_t QuarterInputVectorSizeXY = 0;

	int32_t ProcessingNeuralNet_NumOfInputValues = 0;
	int32_t ProcessingNeuralNet_NumOfHiddenDendrites = 0;
	int32_t ProcessingNeuralNet_NumOfOutputValues = 0;

	CSimpleDeepNeuralNet_Test1();
	~CSimpleDeepNeuralNet_Test1();

	// Kopierkonstruktor l�schen:
	CSimpleDeepNeuralNet_Test1(const CSimpleDeepNeuralNet_Test1  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CSimpleDeepNeuralNet_Test1 & operator=(const CSimpleDeepNeuralNet_Test1  &originalObject) = delete;

	void Initialize(CRandomNumbersNN *pLRFRandomNumbers, CRandomNumbersNN *pNeuralNetRandomNumbers, int32_t numLRFNeurons_Layer1, int32_t LRFSizeX_Layer1, int32_t LRFSizeY_Layer1, int32_t numLRFNeurons_Layer2, int32_t LRFSizeX_Layer2, int32_t LRFSizeY_Layer2, float LRF_MinRandomFactor, float LRF_MaxRandomFactor, int32_t inputVectorSizeX, int32_t inputVectorSizeY, int32_t processingNeuralNet_NumOfHiddenDendrites, int32_t processingNeuralNet_NumOfOutputValues);

	void Get_SimpleNeuralNetData(CSimpleNeuralNetData *pOutData);
	

	void Calculate_Output(float *pInputMap, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1);

	float OutputNeurons_Calculate_VarianceSq(float *pDesiredOutputValueArray);
};


class CCellularState
{
public:

	int32_t Type = -1;

	int32_t NumOfStaticValues = 0;
	float *pStaticValueArray = nullptr;
	float *pSharedStaticValueArray = nullptr;

	int32_t NumOfChangeableValues = 0;
	float *pChangeableValueArray = nullptr;

	int32_t NumOfTrainableValues = 0;
	float *pTrainableValueArray = nullptr;

	CCellularState();
	~CCellularState();

	// Kopierkonstruktor l�schen:
	CCellularState(const CCellularState  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CCellularState & operator=(const CCellularState  &originalObject) = delete;

	void Initialize(int32_t numOfStaticValues, int32_t numOfChangeableValues, int32_t numOfTrainableValues);
	void Initialize(int32_t numOfStaticValues, float *pExternalStaticValueArray, int32_t numOfChangeableValues, int32_t numOfTrainableValues);
	
	void Set_StaticValues(float *pValueArray);
	void Set_ChangeableValues(float *pValueArray);
	void Set_TrainableValues(float *pValueArray);

	void Set_StaticValues(float *pValueArray, int32_t minArrayID, int32_t maxArrayIDPlus1);
	void Set_ChangeableValues(float *pValueArray, int32_t minArrayID, int32_t maxArrayIDPlus1);
	void Set_TrainableValues(float *pValueArray, int32_t minArrayID, int32_t maxArrayIDPlus1);

	void Set_StaticValue(float value, int32_t arrayID);
	void Set_ChangeableValue(float value, int32_t arrayID);
	void Set_TrainableValue(float value, int32_t arrayID);

	void Clone_StateValues(CCellularState *pOriginalObject);

	void Clone_StaticValues(CCellularState *pOriginalObject);
	void Clone_ChangeableValues(CCellularState *pOriginalObject);
	void Clone_TrainableValues(CCellularState *pOriginalObject);

	

	
};

class CCellularData
{
public:

	CCellularState ActualState;
	CCellularState NewState;

	int32_t NumOfPrevStates = 0;
	int32_t NumOfPrevStatesMinus1 = 0;
	CCellularState *pPrevStateArray = nullptr;

	CCellularData();
	~CCellularData();

	// Kopierkonstruktor l�schen:
	CCellularData(const CCellularData  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CCellularData & operator=(const CCellularData  &originalObject) = delete;

	void Initialize(int32_t numOfStaticValues, int32_t numOfChangeableValues, int32_t numOfTrainableValues, int32_t numOfPrevStates);
	void Initialize(int32_t numOfStaticValues, float *pExternalStaticValueArray, int32_t numOfChangeableValues, int32_t numOfTrainableValues, int32_t numOfPrevStates);

	void Prepare_Update(void);

	void Set_ActualStaticValues(float *pValueArray);
	void Set_ActualChangeableValues(float *pValueArray);
	void Set_ActualTrainableValues(float *pValueArray);

	void Set_ActualStaticValues(float *pValueArray, int32_t minArrayID, int32_t maxArrayIDPlus1);
	void Set_ActualChangeableValues(float *pValueArray, int32_t minArrayID, int32_t maxArrayIDPlus1);
	void Set_ActualTrainableValues(float *pValueArray, int32_t minArrayID, int32_t maxArrayIDPlus1);

	void Set_ActualStaticValue(float value, int32_t arrayID);
	void Set_ActualChangeableValue(float value, int32_t arrayID);
	void Set_ActualTrainableValue(float value, int32_t arrayID);

	void Clone_StateValues(CCellularData *pOriginalObject);

	void Clone_StaticValues(CCellularData *pOriginalObject);
	void Clone_ChangeableValues(CCellularData *pOriginalObject);
	void Clone_TrainableValues(CCellularData *pOriginalObject);

	
};

class CCellularAutomaton
{
public:

	CCellularAutomaton *pUsedCellularAutomatonArray = nullptr;

	CCellularData *pCellInstance = nullptr;

	int32_t PosID = 0;
	int32_t PosX = 0;
	int32_t PosY = 0;
	int32_t PosZ = 0;

	int32_t PopulationSizeX = 0;
	int32_t PopulationSizeY = 0;
	int32_t PopulationSizeZ = 0;
	int32_t PopulationSizeXY = 0;

	CCellularAutomaton();
	~CCellularAutomaton();

	// Kopierkonstruktor l�schen:
	CCellularAutomaton(const CCellularAutomaton  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CCellularAutomaton & operator=(const CCellularAutomaton  &originalObject) = delete;

	void Set_PopulationSize(int32_t sizeX);
	void Set_PopulationSize(int32_t sizeX, int32_t sizeY);
	void Set_PopulationSize(int32_t sizeX, int32_t sizeY, int32_t sizeZ);

	void Set_Position(int32_t posX);
	void Set_Position(int32_t posX, int32_t posY);
	void Set_Position(int32_t posX, int32_t posY, int32_t posZ);

	void Set_1DimPositionFromID(int32_t posID);
	void Set_2DimPositionFromID(int32_t posID);
	void Set_3DimPositionFromID(int32_t posID);

	void Connect_With_Population(CCellularAutomaton *pCellularAutomatonArray);

	void Connect_With_CellInstance(CCellularData *pInstance);

	void Set_ActualStaticValue_PositionBased(float *pPositionBasedValueArray, int32_t staticValueArrayID);
	void Set_ActualChangeableValue_PositionBased(float *pPositionBasedValueArray, int32_t changeableValueArrayID);
	void Set_ActualTrainableValue_PositionBased(float *pPositionBasedValueArray, int32_t trainableValueArrayID);
};








#endif