#include "Physics.h"

using namespace std;

//float g_AirFrictionConstant = 0.0f;
float g_AirFrictionConstant = 0.0125f;

// same as linear
static void Identity(CNeuralCalculationUnit* pCalculationUnit)
{
	pCalculationUnit->OutputValue = pCalculationUnit->SumOfInputValues;
	pCalculationUnit->SumOfInputValues = 0.0f;
	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}

static void Quadric(CNeuralCalculationUnit* pCalculationUnit)
{
	float tempFloat = pCalculationUnit->SumOfInputValues;
	tempFloat *= tempFloat;
	pCalculationUnit->OutputValue = tempFloat;
	pCalculationUnit->SumOfInputValues = 0.0f;
	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}

static void Cubic(CNeuralCalculationUnit* pCalculationUnit)
{
	float tempFloat = pCalculationUnit->SumOfInputValues;
	pCalculationUnit->OutputValue = tempFloat * tempFloat * tempFloat;
	pCalculationUnit->SumOfInputValues = 0.0f;
	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}

static void TanH(CNeuralCalculationUnit* pCalculationUnit)
{
	// von -1.0f bis 1.0f:
	pCalculationUnit->OutputValue = tanh(pCalculationUnit->SumOfInputValues);
	pCalculationUnit->SumOfInputValues = 0.0f;
	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}

static void FastTanHReplacement(CNeuralCalculationUnit* pCalculationUnit)
{
	// von -1.0f bis 1.0f:
	pCalculationUnit->OutputValue = pCalculationUnit->SumOfInputValues / (1.0f + abs(pCalculationUnit->SumOfInputValues));
	pCalculationUnit->SumOfInputValues = 0.0f;
	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}

static void SqrtOutput(CNeuralCalculationUnit* pCalculationUnit)
{
	if (pCalculationUnit->SumOfInputValues < 0.0f)
	{
		pCalculationUnit->OutputValue = 0.0f;
		pCalculationUnit->SumOfInputValues = 0.0f;
		//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
		return;
	}

	pCalculationUnit->OutputValue = sqrt(pCalculationUnit->SumOfInputValues);
	pCalculationUnit->SumOfInputValues = 0.0f;
	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}


CSimplePhysicsObject::CSimplePhysicsObject()
{}

CSimplePhysicsObject::~CSimplePhysicsObject()
{}


void CSimplePhysicsObject::Reset_Values(void)
{
	Mass = 0.0f;
	PosX = PosY = PosZ = 0.0f;
	VelX = VelY = VelZ = 0.0f;
	VelX_LastFrame = VelY_LastFrame = VelZ_LastFrame = 0.0f;
	VelX_LastFrame2 = VelY_LastFrame2 = VelZ_LastFrame2 = 0.0f;
	AccelX = AccelY = AccelZ = 0.0f;
}

void CSimplePhysicsObject::Update(float timeStep)
{
	VelX_LastFrame2 = VelX_LastFrame;
	VelY_LastFrame2 = VelY_LastFrame;
	VelZ_LastFrame2 = VelZ_LastFrame;

	VelX_LastFrame = VelX;
	VelY_LastFrame = VelY;
	VelZ_LastFrame = VelZ;

	DeltaVelX = AccelX * timeStep;
	DeltaVelY = AccelY * timeStep;
	DeltaVelZ = AccelZ * timeStep;

	VelX += DeltaVelX;
	VelY += DeltaVelY;
	VelZ += DeltaVelZ;

	DeltaPosX = VelX * timeStep;
	DeltaPosY = VelY * timeStep;
	DeltaPosZ = VelZ * timeStep;

	PosX += DeltaPosX;
	PosY += DeltaPosY;
	PosZ += DeltaPosZ;
}


CSimpleArtilleryAI::CSimpleArtilleryAI()
{}

CSimpleArtilleryAI::~CSimpleArtilleryAI()
{}

void CSimpleArtilleryAI::Modify_CalculationNet(CNeuralCalculationNetDesc* pInCalculationNetDesc)
{
	CalculationNet.Modify(pInCalculationNetDesc, &CalculationFunctions);
}

void CSimpleArtilleryAI::Readout_CalculationNetData(CNeuralCalculationNetDesc* pOutCalculationNetDesc, bool memoryAllocation)
{
	CalculationNet.Readout_Data(pOutCalculationNetDesc, memoryAllocation);
}

void CSimpleArtilleryAI::Initialize(int32_t numOfHiddenUnitsL1, int32_t numOfHiddenUnitsL2, float minRandomPlasticity, float maxRandomPlasticity, uint64_t seed)
{
	CRandomNumbersNN RandomNumbers;
	RandomNumbers.Change_Seed(seed);

	CalculationFunctions.Initialize(3);
	CalculationFunctions.Set_Function(0, nullptr);
	CalculationFunctions.Set_Function(1, Identity);
	CalculationFunctions.Set_Function(2, FastTanHReplacement);
	
	
	int32_t NumOfCalculationUnits = NumOfInputUnits + numOfHiddenUnitsL1 + numOfHiddenUnitsL2 + NumOfOutputUnits;

	int32_t idOfFirstInputUnit = 0;
	int32_t idOfFirstHiddenUnitL1 = NumOfInputUnits;
	int32_t idOfFirstHiddenUnitL2 = idOfFirstHiddenUnitL1 + numOfHiddenUnitsL1;
	int32_t idOfFirstOutputUnit = idOfFirstHiddenUnitL2 + numOfHiddenUnitsL2;

	CalculationNet.Initialize(NumOfCalculationUnits, NumOfInputUnits, NumOfOutputUnits);
	CalculationNet.Set_InputUnit(0, 0);
	CalculationNet.Set_InputUnit(1, 1);
	CalculationNet.Set_InputUnit(2, 2);
	CalculationNet.Set_InputUnit(3, 3);
	CalculationNet.Set_OutputUnit(idOfFirstOutputUnit, 0);
	CalculationNet.Set_OutputUnit(idOfFirstOutputUnit + 1, 1);

	CCalculationUnitLayer InputLayer;
	CCalculationUnitLayer HiddenLayer1;
	CCalculationUnitLayer HiddenLayer2;
	CCalculationUnitLayer OutputLayer;

	InputLayer.Intialize(idOfFirstInputUnit, NumOfInputUnits);
	HiddenLayer1.Intialize(idOfFirstHiddenUnitL1, numOfHiddenUnitsL1);
	HiddenLayer2.Intialize(idOfFirstHiddenUnitL2, numOfHiddenUnitsL2);
	OutputLayer.Intialize(idOfFirstOutputUnit, NumOfOutputUnits);

	InputLayer.Set_CalculationFunctions(&CalculationNet, 1, &CalculationFunctions);
	//InputLayer.Set_CalculationFunctions(&CalculationNet, 1, Identity);

	//HiddenLayer1.Set_CalculationFunctions(&CalculationNet, 1, &CalculationFunctions);
	//HiddenLayer1.Set_CalculationFunctions(&CalculationNet, 1, Identity);

	
	//HiddenLayer2.Set_CalculationFunctions(&CalculationNet, 1, &CalculationFunctions);
	//HiddenLayer2.Set_CalculationFunctions(&CalculationNet, 1, Identity);

	HiddenLayer1.Set_CalculationFunctions(&CalculationNet, 2, &CalculationFunctions);
	//HiddenLayer1.Set_CalculationFunctions(&CalculationNet, 2, FastTanHReplacement);


	HiddenLayer2.Set_CalculationFunctions(&CalculationNet, 2, &CalculationFunctions);
	//HiddenLayer2.Set_CalculationFunctions(&CalculationNet, 2, FastTanHReplacement);

	

	//OutputLayer.Set_CalculationFunctions(&CalculationNet, 2, &CalculationFunctions);
	//OutputLayer.Set_CalculationFunctions(&CalculationNet, 2, FastTanHReplacement);

	OutputLayer.Set_CalculationFunctions(&CalculationNet, 1, &CalculationFunctions);
	//OutputLayer.Set_CalculationFunctions(&CalculationNet, 1, Identity);


	float* pPlasticityArray_InputToHidden1Layer = new (std::nothrow) float[NumOfInputUnits];
	float* pPlasticityArray_Hidden1ToHidden2Layer = new (std::nothrow) float[numOfHiddenUnitsL1];
	float* pPlasticityArray_Hidden2ToOutputLayer = new (std::nothrow) float[numOfHiddenUnitsL2];

	//for (int32_t i = idOfFirstHiddenUnitL1; i < idOfFirstHiddenUnitL2; i++)
	for (int32_t i = HiddenLayer1.FirstUnitID; i < HiddenLayer1.LastUnitIDPlus1; i++)
	{
		for (int32_t j = 0; j < NumOfInputUnits; j++)
		{
			pPlasticityArray_InputToHidden1Layer[j] = RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
		}

		HiddenLayer1.Set_IncomingPlasticityValues(&CalculationNet, &InputLayer, i, pPlasticityArray_InputToHidden1Layer);
	}

	//for (int32_t i = idOfFirstHiddenUnitL2; i < idOfFirstOutputUnit; i++)
	for (int32_t i = HiddenLayer2.FirstUnitID; i < HiddenLayer2.LastUnitIDPlus1; i++)
	{
		for (int32_t j = 0; j < numOfHiddenUnitsL1; j++)
		{
			pPlasticityArray_Hidden1ToHidden2Layer[j] = RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
		}

		HiddenLayer2.Set_IncomingPlasticityValues(&CalculationNet, &HiddenLayer1, i, pPlasticityArray_Hidden1ToHidden2Layer);
	}


	//for (int32_t i = idOfFirstOutputUnit; i < NumOfCalculationUnits; i++)
	for (int32_t i = OutputLayer.FirstUnitID; i < OutputLayer.LastUnitIDPlus1; i++)
	{
		for (int32_t j = 0; j < numOfHiddenUnitsL2; j++)
		{
			pPlasticityArray_Hidden2ToOutputLayer[j] = RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
		}

		OutputLayer.Set_IncomingPlasticityValues(&CalculationNet, &HiddenLayer2, i, pPlasticityArray_Hidden2ToOutputLayer);
	}

	
	delete[] pPlasticityArray_InputToHidden1Layer;
	pPlasticityArray_InputToHidden1Layer = nullptr;

	delete[] pPlasticityArray_Hidden1ToHidden2Layer;
	pPlasticityArray_Hidden1ToHidden2Layer = nullptr;

	delete[]  pPlasticityArray_Hidden2ToOutputLayer;
	pPlasticityArray_Hidden2ToOutputLayer = nullptr;
}

void CSimpleArtilleryAI::Initialize(int32_t numOfHiddenUnitsL1, float minRandomPlasticity, float maxRandomPlasticity, uint64_t seed)
{
	CRandomNumbersNN RandomNumbers;
	RandomNumbers.Change_Seed(seed);

	CalculationFunctions.Initialize(3);
	CalculationFunctions.Set_Function(0, nullptr);
	CalculationFunctions.Set_Function(1, Identity);
	CalculationFunctions.Set_Function(2, FastTanHReplacement);
	

	int32_t NumOfCalculationUnits = NumOfInputUnits + numOfHiddenUnitsL1 + NumOfOutputUnits;

	int32_t idOfFirstInputUnit = 0;
	int32_t idOfFirstHiddenUnitL1 = NumOfInputUnits;
	int32_t idOfFirstOutputUnit = idOfFirstHiddenUnitL1 + numOfHiddenUnitsL1;

	CalculationNet.Initialize(NumOfCalculationUnits, NumOfInputUnits, NumOfOutputUnits);
	CalculationNet.Set_InputUnit(0, 0);
	CalculationNet.Set_InputUnit(1, 1);
	CalculationNet.Set_InputUnit(2, 2);
	CalculationNet.Set_InputUnit(3, 3);
	CalculationNet.Set_OutputUnit(idOfFirstOutputUnit, 0);
	CalculationNet.Set_OutputUnit(idOfFirstOutputUnit + 1, 1);

	CCalculationUnitLayer InputLayer;
	CCalculationUnitLayer HiddenLayer1;
	CCalculationUnitLayer OutputLayer;

	InputLayer.Intialize(idOfFirstInputUnit, NumOfInputUnits);
	HiddenLayer1.Intialize(idOfFirstHiddenUnitL1, numOfHiddenUnitsL1);
	OutputLayer.Intialize(idOfFirstOutputUnit, NumOfOutputUnits);

	InputLayer.Set_CalculationFunctions(&CalculationNet, 1, &CalculationFunctions);
	//InputLayer.Set_CalculationFunctions(&CalculationNet, 1, Identity);

	//HiddenLayer1.Set_CalculationFunctions(&CalculationNet, 1, &CalculationFunctions);
	//HiddenLayer1.Set_CalculationFunctions(&CalculationNet, 1, Identity);

	HiddenLayer1.Set_CalculationFunctions(&CalculationNet, 2, &CalculationFunctions);
	//HiddenLayer1.Set_CalculationFunctions(&CalculationNet, 2, FastTanHReplacement);

	
	//OutputLayer.Set_CalculationFunctions(&CalculationNet, 2, &CalculationFunctions);
	//OutputLayer.Set_CalculationFunctions(&CalculationNet, 2, FastTanHReplacement);

	OutputLayer.Set_CalculationFunctions(&CalculationNet, 1, &CalculationFunctions);
	//OutputLayer.Set_CalculationFunctions(&CalculationNet, 1, Identity);


	float* pPlasticityArray_InputToHidden1Layer = new (std::nothrow) float[NumOfInputUnits];
	float* pPlasticityArray_Hidden1ToOutputLayer = new (std::nothrow) float[numOfHiddenUnitsL1];


	//for (int32_t i = idOfFirstHiddenUnitL1; i < idOfFirstHiddenUnitL2; i++)
	for (int32_t i = HiddenLayer1.FirstUnitID; i < HiddenLayer1.LastUnitIDPlus1; i++)
	{
		for (int32_t j = 0; j < NumOfInputUnits; j++)
		{
			pPlasticityArray_InputToHidden1Layer[j] = RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
		}

		HiddenLayer1.Set_IncomingPlasticityValues(&CalculationNet, &InputLayer, i, pPlasticityArray_InputToHidden1Layer);
	}

	
	//for (int32_t i = idOfFirstOutputUnit; i < NumOfCalculationUnits; i++)
	for (int32_t i = OutputLayer.FirstUnitID; i < OutputLayer.LastUnitIDPlus1; i++)
	{
		for (int32_t j = 0; j < numOfHiddenUnitsL1; j++)
		{
			pPlasticityArray_Hidden1ToOutputLayer[j] = RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
		}

		OutputLayer.Set_IncomingPlasticityValues(&CalculationNet, &HiddenLayer1, i, pPlasticityArray_Hidden1ToOutputLayer);
	}


	delete[] pPlasticityArray_InputToHidden1Layer;
	pPlasticityArray_InputToHidden1Layer = nullptr;

	delete[] pPlasticityArray_Hidden1ToOutputLayer;
	pPlasticityArray_Hidden1ToOutputLayer = nullptr;

}

void CSimpleArtilleryAI::Calculate_FiringSolution(float* pOutVelocityX, float* pOutVelocityY, float startPosX, float startPosY, float targetPosX, float targetPosY, float gravitationAccelerationX, float gravitationAccelerationY, float velocityScaleX, float velocityScaleY)
{
	float InputData[NumOfInputUnits];
	float OutputData[NumOfOutputUnits];

	/*InputData[0] = startPosX;
	InputData[1] = startPosY;
	InputData[2] = targetPosX;
	InputData[3] = targetPosY;
	InputData[4] = gravitationAccelerationX;
	InputData[5] = gravitationAccelerationY;*/


	InputData[0] = targetPosX - startPosX;
	InputData[1] = targetPosY - startPosY;
	InputData[2] = gravitationAccelerationX;
	InputData[3] = gravitationAccelerationY;

	CalculationNet.Set_InputValues(InputData);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(OutputData);

	*pOutVelocityX = OutputData[0];
	*pOutVelocityY = OutputData[1];
}




CArtilleryAI::CArtilleryAI()
{}

CArtilleryAI::~CArtilleryAI()
{}

void CArtilleryAI::Modify_CalculationNet(CNeuralCalculationNetDesc* pInCalculationNetDesc)
{
	CalculationNet.Modify(pInCalculationNetDesc, &CalculationFunctions);
}

void CArtilleryAI::Readout_CalculationNetData(CNeuralCalculationNetDesc* pOutCalculationNetDesc, bool memoryAllocation)
{
	CalculationNet.Readout_Data(pOutCalculationNetDesc, memoryAllocation);
}

void CArtilleryAI::Initialize(int32_t numOfHiddenUnitsL1, int32_t numOfHiddenUnitsL2, float minRandomPlasticity, float maxRandomPlasticity, uint64_t seed)
{
	CRandomNumbersNN RandomNumbers;
	RandomNumbers.Change_Seed(seed);

	CalculationFunctions.Initialize(3);
	CalculationFunctions.Set_Function(0, nullptr);
	CalculationFunctions.Set_Function(1, Identity);
	CalculationFunctions.Set_Function(2, FastTanHReplacement);

	int32_t NumOfCalculationUnits = NumOfInputUnits + numOfHiddenUnitsL1 + numOfHiddenUnitsL2 + NumOfOutputUnits;

	int32_t idOfFirstInputUnit = 0;
	int32_t idOfFirstHiddenUnitL1 = NumOfInputUnits;
	int32_t idOfFirstHiddenUnitL2 = idOfFirstHiddenUnitL1 + numOfHiddenUnitsL1;
	int32_t idOfFirstOutputUnit = idOfFirstHiddenUnitL2 + numOfHiddenUnitsL2;

	CalculationNet.Initialize(NumOfCalculationUnits, NumOfInputUnits, NumOfOutputUnits);
	CalculationNet.Set_InputUnit(0, 0);
	CalculationNet.Set_InputUnit(1, 1);
	CalculationNet.Set_InputUnit(2, 2);
	CalculationNet.Set_InputUnit(3, 3);
	CalculationNet.Set_OutputUnit(idOfFirstOutputUnit, 0);
	CalculationNet.Set_OutputUnit(idOfFirstOutputUnit + 1, 1);

	CCalculationUnitLayer InputLayer;
	CCalculationUnitLayer HiddenLayer1;
	CCalculationUnitLayer HiddenLayer2;
	CCalculationUnitLayer OutputLayer;

	InputLayer.Intialize(idOfFirstInputUnit, NumOfInputUnits);
	HiddenLayer1.Intialize(idOfFirstHiddenUnitL1, numOfHiddenUnitsL1);
	HiddenLayer2.Intialize(idOfFirstHiddenUnitL2, numOfHiddenUnitsL2);
	OutputLayer.Intialize(idOfFirstOutputUnit, NumOfOutputUnits);

	InputLayer.Set_CalculationFunctions(&CalculationNet, 1, &CalculationFunctions);
	//InputLayer.Set_CalculationFunctions(&CalculationNet, 1, Identity);

	HiddenLayer1.Set_CalculationFunctions(&CalculationNet, 1, &CalculationFunctions);
	//HiddenLayer1.Set_CalculationFunctions(&CalculationNet, 1, Identity);

	HiddenLayer2.Set_CalculationFunctions(&CalculationNet, 1, &CalculationFunctions);
	//HiddenLayer2.Set_CalculationFunctions(&CalculationNet, 1, Identity);

	OutputLayer.Set_CalculationFunctions(&CalculationNet, 2, &CalculationFunctions);
	//OutputLayer.Set_CalculationFunctions(&CalculationNet, 2, FastTanHReplacement);


	float* pPlasticityArray_InputToHidden1Layer = new (std::nothrow) float[NumOfInputUnits];
	float* pPlasticityArray_Hidden1ToHidden2Layer = new (std::nothrow) float[numOfHiddenUnitsL1];
	float* pPlasticityArray_Hidden2ToOutputLayer = new (std::nothrow) float[numOfHiddenUnitsL2];

	//for (int32_t i = idOfFirstHiddenUnitL1; i < idOfFirstHiddenUnitL2; i++)
	for (int32_t i = HiddenLayer1.FirstUnitID; i < HiddenLayer1.LastUnitIDPlus1; i++)
	{
		for (int32_t j = 0; j < NumOfInputUnits; j++)
		{
			pPlasticityArray_InputToHidden1Layer[j] = RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
		}

		HiddenLayer1.Set_IncomingPlasticityValues(&CalculationNet, &InputLayer, i, pPlasticityArray_InputToHidden1Layer);
	}

	//for (int32_t i = idOfFirstHiddenUnitL2; i < idOfFirstOutputUnit; i++)
	for (int32_t i = HiddenLayer2.FirstUnitID; i < HiddenLayer2.LastUnitIDPlus1; i++)
	{
		for (int32_t j = 0; j < numOfHiddenUnitsL1; j++)
		{
			pPlasticityArray_Hidden1ToHidden2Layer[j] = RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
		}

		HiddenLayer2.Set_IncomingPlasticityValues(&CalculationNet, &HiddenLayer1, i, pPlasticityArray_Hidden1ToHidden2Layer);
	}


	//for (int32_t i = idOfFirstOutputUnit; i < NumOfCalculationUnits; i++)
	for (int32_t i = OutputLayer.FirstUnitID; i < OutputLayer.LastUnitIDPlus1; i++)
	{
		for (int32_t j = 0; j < numOfHiddenUnitsL2; j++)
		{
			pPlasticityArray_Hidden2ToOutputLayer[j] = RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
		}

		OutputLayer.Set_IncomingPlasticityValues(&CalculationNet, &HiddenLayer2, i, pPlasticityArray_Hidden2ToOutputLayer);
	}

	delete[] pPlasticityArray_InputToHidden1Layer;
	pPlasticityArray_InputToHidden1Layer = nullptr;

	delete[] pPlasticityArray_Hidden1ToHidden2Layer;
	pPlasticityArray_Hidden1ToHidden2Layer = nullptr;

	delete[]  pPlasticityArray_Hidden2ToOutputLayer;
	pPlasticityArray_Hidden2ToOutputLayer = nullptr;
}

void CArtilleryAI::Initialize(int32_t numOfHiddenUnitsL1, float minRandomPlasticity, float maxRandomPlasticity, uint64_t seed)
{
	CRandomNumbersNN RandomNumbers;
	RandomNumbers.Change_Seed(seed);

	CalculationFunctions.Initialize(3);
	CalculationFunctions.Set_Function(0, nullptr);
	CalculationFunctions.Set_Function(1, Identity);
	CalculationFunctions.Set_Function(2, FastTanHReplacement);

	int32_t NumOfCalculationUnits = NumOfInputUnits + numOfHiddenUnitsL1 + NumOfOutputUnits;

	int32_t idOfFirstInputUnit = 0;
	int32_t idOfFirstHiddenUnitL1 = NumOfInputUnits;
	int32_t idOfFirstOutputUnit = idOfFirstHiddenUnitL1 + numOfHiddenUnitsL1;

	CalculationNet.Initialize(NumOfCalculationUnits, NumOfInputUnits, NumOfOutputUnits);
	CalculationNet.Set_InputUnit(0, 0);
	CalculationNet.Set_InputUnit(1, 1);
	CalculationNet.Set_InputUnit(2, 2);
	CalculationNet.Set_InputUnit(3, 3);
	CalculationNet.Set_OutputUnit(idOfFirstOutputUnit, 0);
	CalculationNet.Set_OutputUnit(idOfFirstOutputUnit + 1, 1);

	CCalculationUnitLayer InputLayer;
	CCalculationUnitLayer HiddenLayer1;
	CCalculationUnitLayer OutputLayer;

	InputLayer.Intialize(idOfFirstInputUnit, NumOfInputUnits);
	HiddenLayer1.Intialize(idOfFirstHiddenUnitL1, numOfHiddenUnitsL1);
	OutputLayer.Intialize(idOfFirstOutputUnit, NumOfOutputUnits);

	InputLayer.Set_CalculationFunctions(&CalculationNet, 1, &CalculationFunctions);
	//InputLayer.Set_CalculationFunctions(&CalculationNet, 1, Identity);

	HiddenLayer1.Set_CalculationFunctions(&CalculationNet, 1, &CalculationFunctions);
	//HiddenLayer1.Set_CalculationFunctions(&CalculationNet, 1, Identity);

	OutputLayer.Set_CalculationFunctions(&CalculationNet, 2, &CalculationFunctions);
	//OutputLayer.Set_CalculationFunctions(&CalculationNet, 2, FastTanHReplacement);


	float* pPlasticityArray_InputToHidden1Layer = new (std::nothrow) float[NumOfInputUnits];
	float* pPlasticityArray_Hidden1ToOutputLayer = new (std::nothrow) float[numOfHiddenUnitsL1];
	

	//for (int32_t i = idOfFirstHiddenUnitL1; i < idOfFirstHiddenUnitL2; i++)
	for (int32_t i = HiddenLayer1.FirstUnitID; i < HiddenLayer1.LastUnitIDPlus1; i++)
	{
		for (int32_t j = 0; j < NumOfInputUnits; j++)
		{
			pPlasticityArray_InputToHidden1Layer[j] = RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
		}

		HiddenLayer1.Set_IncomingPlasticityValues(&CalculationNet, &InputLayer, i, pPlasticityArray_InputToHidden1Layer);
	}

	
	//for (int32_t i = idOfFirstOutputUnit; i < NumOfCalculationUnits; i++)
	for (int32_t i = OutputLayer.FirstUnitID; i < OutputLayer.LastUnitIDPlus1; i++)
	{
		for (int32_t j = 0; j < numOfHiddenUnitsL1; j++)
		{
			pPlasticityArray_Hidden1ToOutputLayer[j] = RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
		}

		OutputLayer.Set_IncomingPlasticityValues(&CalculationNet, &HiddenLayer1, i, pPlasticityArray_Hidden1ToOutputLayer);
	}

	delete[] pPlasticityArray_InputToHidden1Layer;
	pPlasticityArray_InputToHidden1Layer = nullptr;

	delete[] pPlasticityArray_Hidden1ToOutputLayer;
	pPlasticityArray_Hidden1ToOutputLayer = nullptr;
}

void CArtilleryAI::Calculate_FiringSolution(float* pOutVelocityX, float* pOutVelocityY, float startPosX, float startPosY, float targetPosX, float targetPosY, float gravitationAccelerationX, float gravitationAccelerationY, float velocityScaleX, float velocityScaleY)
{
	/*float diffX = targetPosX - startPosX;
	float diffY = targetPosY - startPosY;

	float invDist = 1.0f / sqrt(diffX*diffX + diffY*diffY + 0.0001f);

	float dirX = invDist*diffX;
	float dirY = invDist*diffY;*/

	float InputData[NumOfInputUnits];
	float OutputData[NumOfOutputUnits];

	/*InputData[0] = startPosX;
	InputData[1] = startPosY;
	InputData[2] = targetPosX;
	InputData[3] = targetPosY;
	InputData[4] = dirX;
	InputData[5] = dirY;
	InputData[6] = gravitationAccelerationX;
	InputData[7] = gravitationAccelerationY;*/


	/*InputData[0] = startPosX;
	InputData[1] = startPosY;
	InputData[2] = targetPosX;
	InputData[3] = targetPosY;
	InputData[4] = gravitationAccelerationX;
	InputData[5] = gravitationAccelerationY;*/

	InputData[0] = targetPosX - startPosX;
	InputData[1] = targetPosY - startPosY;
	InputData[2] = gravitationAccelerationX;
	InputData[3] = gravitationAccelerationY;

	CalculationNet.Set_InputValues(InputData);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(OutputData);

	// Hinweis - OutputData-Werte liegen in einem Bereich von -1 bis +1:
	*pOutVelocityX = velocityScaleX * OutputData[0];
	*pOutVelocityY = velocityScaleY * OutputData[1];
}




COrbitalNavigationAI::COrbitalNavigationAI()
{}

COrbitalNavigationAI::~COrbitalNavigationAI()
{}

void COrbitalNavigationAI::Modify_CalculationNet(CNeuralCalculationNetDesc* pInCalculationNetDesc)
{
	CalculationNet.Modify(pInCalculationNetDesc, &CalculationFunctions);
}

void COrbitalNavigationAI::Readout_CalculationNetData(CNeuralCalculationNetDesc* pOutCalculationNetDesc, bool memoryAllocation)
{
	CalculationNet.Readout_Data(pOutCalculationNetDesc, memoryAllocation);
}

void COrbitalNavigationAI::Initialize(int32_t numOfHiddenUnitsL1, int32_t numOfHiddenUnitsL2, float minRandomPlasticity, float maxRandomPlasticity, uint64_t seed)
{
	CRandomNumbersNN RandomNumbers;
	RandomNumbers.Change_Seed(seed);

	CalculationFunctions.Initialize(4);
	CalculationFunctions.Set_Function(0, nullptr);
	CalculationFunctions.Set_Function(1, Identity);
	CalculationFunctions.Set_Function(2, FastTanHReplacement);
	CalculationFunctions.Set_Function(3, SqrtOutput);

	int32_t NumOfCalculationUnits = NumOfInputUnits + numOfHiddenUnitsL1 + numOfHiddenUnitsL2 + NumOfOutputUnits;

	int32_t idOfFirstInputUnit = 0;
	int32_t idOfFirstHiddenUnitL1 = NumOfInputUnits;
	int32_t idOfFirstHiddenUnitL2 = idOfFirstHiddenUnitL1 + numOfHiddenUnitsL1;
	int32_t idOfFirstOutputUnit = idOfFirstHiddenUnitL2 + numOfHiddenUnitsL2;

	CalculationNet.Initialize(NumOfCalculationUnits, NumOfInputUnits, NumOfOutputUnits);
	CalculationNet.Set_InputUnit(0, 0);
	CalculationNet.Set_InputUnit(1, 1);
	CalculationNet.Set_OutputUnit(idOfFirstOutputUnit, 0);
	
	CCalculationUnitLayer InputLayer;
	CCalculationUnitLayer HiddenLayer1;
	CCalculationUnitLayer HiddenLayer2;
	CCalculationUnitLayer OutputLayer;

	InputLayer.Intialize(idOfFirstInputUnit, NumOfInputUnits);
	HiddenLayer1.Intialize(idOfFirstHiddenUnitL1, numOfHiddenUnitsL1);
	HiddenLayer2.Intialize(idOfFirstHiddenUnitL2, numOfHiddenUnitsL2);
	OutputLayer.Intialize(idOfFirstOutputUnit, NumOfOutputUnits);

	InputLayer.Set_CalculationFunctions(&CalculationNet, 1, &CalculationFunctions);
	//InputLayer.Set_CalculationFunctions(&CalculationNet, 1, Identity);

	HiddenLayer1.Set_CalculationFunctions(&CalculationNet, 1, &CalculationFunctions);
	//HiddenLayer1.Set_CalculationFunctions(&CalculationNet, 1, Identity);

	HiddenLayer2.Set_CalculationFunctions(&CalculationNet, 1, &CalculationFunctions);
	//HiddenLayer2.Set_CalculationFunctions(&CalculationNet, 1, Identity);

	OutputLayer.Set_CalculationFunctions(&CalculationNet, 3, &CalculationFunctions);
	//OutputLayer.Set_CalculationFunctions(&CalculationNet, 3, SqrtOutput);


	

	float* pPlasticityArray_InputToHidden1Layer = new (std::nothrow) float[NumOfInputUnits];
	float* pPlasticityArray_Hidden1ToHidden2Layer = new (std::nothrow) float[numOfHiddenUnitsL1];
	float* pPlasticityArray_Hidden2ToOutputLayer = new (std::nothrow) float[numOfHiddenUnitsL2];
	
	//for (int32_t i = idOfFirstHiddenUnitL1; i < idOfFirstHiddenUnitL2; i++)
	for (int32_t i = HiddenLayer1.FirstUnitID; i < HiddenLayer1.LastUnitIDPlus1; i++)
	{
		for (int32_t j = 0; j < NumOfInputUnits; j++)
		{
			pPlasticityArray_InputToHidden1Layer[j] = RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
		}

		HiddenLayer1.Set_IncomingPlasticityValues(&CalculationNet, &InputLayer, i, pPlasticityArray_InputToHidden1Layer);
	}

	//for (int32_t i = idOfFirstHiddenUnitL2; i < idOfFirstOutputUnit; i++)
	for (int32_t i = HiddenLayer2.FirstUnitID; i < HiddenLayer2.LastUnitIDPlus1; i++)
	{
		for (int32_t j = 0; j < numOfHiddenUnitsL1; j++)
		{
			pPlasticityArray_Hidden1ToHidden2Layer[j] = RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
		}

		HiddenLayer2.Set_IncomingPlasticityValues(&CalculationNet, &HiddenLayer1, i, pPlasticityArray_Hidden1ToHidden2Layer);
	}


	//for (int32_t i = idOfFirstOutputUnit; i < NumOfCalculationUnits; i++)
	for (int32_t i = OutputLayer.FirstUnitID; i < OutputLayer.LastUnitIDPlus1; i++)
	{
		for (int32_t j = 0; j < numOfHiddenUnitsL2; j++)
		{
			pPlasticityArray_Hidden2ToOutputLayer[j] = RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
		}

		OutputLayer.Set_IncomingPlasticityValues(&CalculationNet, &HiddenLayer2, i, pPlasticityArray_Hidden2ToOutputLayer);
	}


	delete[] pPlasticityArray_InputToHidden1Layer;
	pPlasticityArray_InputToHidden1Layer = nullptr;

	delete[] pPlasticityArray_Hidden1ToHidden2Layer;
	pPlasticityArray_Hidden1ToHidden2Layer = nullptr;

	delete[]  pPlasticityArray_Hidden2ToOutputLayer;
	pPlasticityArray_Hidden2ToOutputLayer = nullptr;
}

void COrbitalNavigationAI::Initialize(int32_t numOfHiddenUnitsL1, float minRandomPlasticity, float maxRandomPlasticity, uint64_t seed)
{
	CRandomNumbersNN RandomNumbers;
	RandomNumbers.Change_Seed(seed);

	CalculationFunctions.Initialize(4);
	CalculationFunctions.Set_Function(0, nullptr);
	CalculationFunctions.Set_Function(1, Identity);
	CalculationFunctions.Set_Function(2, FastTanHReplacement);
	CalculationFunctions.Set_Function(3, SqrtOutput);

	int32_t NumOfCalculationUnits = NumOfInputUnits + numOfHiddenUnitsL1 + NumOfOutputUnits;

	int32_t idOfFirstInputUnit = 0;
	int32_t idOfFirstHiddenUnitL1 = NumOfInputUnits;
	int32_t idOfFirstOutputUnit = idOfFirstHiddenUnitL1 + numOfHiddenUnitsL1;

	CalculationNet.Initialize(NumOfCalculationUnits, NumOfInputUnits, NumOfOutputUnits);
	CalculationNet.Set_InputUnit(0, 0);
	CalculationNet.Set_InputUnit(1, 1);
	CalculationNet.Set_OutputUnit(idOfFirstOutputUnit, 0);

	CCalculationUnitLayer InputLayer;
	CCalculationUnitLayer HiddenLayer1;
	CCalculationUnitLayer OutputLayer;

	InputLayer.Intialize(idOfFirstInputUnit, NumOfInputUnits);
	HiddenLayer1.Intialize(idOfFirstHiddenUnitL1, numOfHiddenUnitsL1);
	OutputLayer.Intialize(idOfFirstOutputUnit, NumOfOutputUnits);

	InputLayer.Set_CalculationFunctions(&CalculationNet, 1, &CalculationFunctions);
	//InputLayer.Set_CalculationFunctions(&CalculationNet, 1, Identity);

	HiddenLayer1.Set_CalculationFunctions(&CalculationNet, 1, &CalculationFunctions);
	//HiddenLayer1.Set_CalculationFunctions(&CalculationNet, 1, Identity);

	OutputLayer.Set_CalculationFunctions(&CalculationNet, 3, &CalculationFunctions);
	//OutputLayer.Set_CalculationFunctions(&CalculationNet, 3, SqrtOutput);




	float* pPlasticityArray_InputToHidden1Layer = new (std::nothrow) float[NumOfInputUnits];
	float* pPlasticityArray_Hidden1ToOutputLayer = new (std::nothrow) float[numOfHiddenUnitsL1];
	

	//for (int32_t i = idOfFirstHiddenUnitL1; i < idOfFirstHiddenUnitL2; i++)
	for (int32_t i = HiddenLayer1.FirstUnitID; i < HiddenLayer1.LastUnitIDPlus1; i++)
	{
		for (int32_t j = 0; j < NumOfInputUnits; j++)
		{
			pPlasticityArray_InputToHidden1Layer[j] = RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
		}

		HiddenLayer1.Set_IncomingPlasticityValues(&CalculationNet, &InputLayer, i, pPlasticityArray_InputToHidden1Layer);
	}

	
	//for (int32_t i = idOfFirstOutputUnit; i < NumOfCalculationUnits; i++)
	for (int32_t i = OutputLayer.FirstUnitID; i < OutputLayer.LastUnitIDPlus1; i++)
	{
		for (int32_t j = 0; j < numOfHiddenUnitsL1; j++)
		{
			pPlasticityArray_Hidden1ToOutputLayer[j] = RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
		}

		OutputLayer.Set_IncomingPlasticityValues(&CalculationNet, &HiddenLayer1, i, pPlasticityArray_Hidden1ToOutputLayer);
	}


	delete[] pPlasticityArray_InputToHidden1Layer;
	pPlasticityArray_InputToHidden1Layer = nullptr;

	delete[] pPlasticityArray_Hidden1ToOutputLayer;
	pPlasticityArray_Hidden1ToOutputLayer = nullptr;
}

void COrbitalNavigationAI::Calculate_InitialOrbitalVelocity(float* pOutVelocityX, float* pOutVelocityY, float startPosX, float startPosY, float targetPosX, float targetPosY, float gravitySourcePosX, float gravitySourcePosY, float gravitySourceMass)
{
	float distX_Start = startPosX - gravitySourcePosX;
	float distY_Start = startPosY - gravitySourcePosY;

	float radiusStartPosition = sqrt(distX_Start * distX_Start + distY_Start * distY_Start);

	float distX_Target = targetPosX - gravitySourcePosX;
	float distY_Target = targetPosY - gravitySourcePosY;

	float a = sqrt(distX_Target * distX_Target + distY_Target * distY_Target);

	a += radiusStartPosition;
	a *= 0.5f;


	Normalize(&distX_Start, &distY_Start);

	float movementDirX, movementDirY, movementDirZ;

	CrossProduct(&movementDirX, &movementDirY, &movementDirZ, -distX_Start, -distY_Start, 0.0f, 0.0f, 0.0f, 1.0f);

	/*
	float radialVelocity = sqrt(gravitySourceMass*(2.0f / radiusStartPosition - 1.0f / a));

	*pOutVelocityX = movementDirX * radialVelocity;
	*pOutVelocityY = movementDirY * radialVelocity;
	*/


	float InputData[NumOfInputUnits];
	float OutputData[NumOfOutputUnits];


	InputData[0] = gravitySourceMass / radiusStartPosition;
	InputData[1] = gravitySourceMass / a;

	CalculationNet.Set_InputValues(InputData);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(OutputData);

	*pOutVelocityX = movementDirX * OutputData[0];
	*pOutVelocityY = movementDirY * OutputData[0];



	/*float InputData[NumOfInputNeurons];
	float OutputData[NumOfOutputNeurons];

	InputData[0] = gravitySourcePosX;
	InputData[1] = gravitySourcePosY;
	InputData[2] = startPosX;
	InputData[3] = startPosY;
	InputData[4] = targetPosX;
	InputData[5] = targetPosY;

	CalculationNet.Set_InputValues(InputData);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(OutputData);

	*pOutVelocityX = 100.0f*movementDirX * OutputData[0];
	*pOutVelocityY = 100.0f*movementDirY * OutputData[0];*/
}



CLandingModuleNavigationAI::CLandingModuleNavigationAI()
{}

CLandingModuleNavigationAI::~CLandingModuleNavigationAI()
{}

void CLandingModuleNavigationAI::Modify_CalculationNet(CNeuralCalculationNetDesc* pInCalculationNetDesc)
{
	CalculationNet.Modify(pInCalculationNetDesc, &CalculationFunctions);
}

void CLandingModuleNavigationAI::Readout_CalculationNetData(CNeuralCalculationNetDesc* pOutCalculationNetDesc, bool memoryAllocation)
{
	CalculationNet.Readout_Data(pOutCalculationNetDesc, memoryAllocation);
}

void CLandingModuleNavigationAI::Initialize(int32_t numOfHiddenUnitsL1, int32_t numOfHiddenUnitsL2, float minRandomPlasticity, float maxRandomPlasticity, uint64_t seed)
{
	CRandomNumbersNN RandomNumbers;
	RandomNumbers.Change_Seed(seed);

	CalculationFunctions.Initialize(3);
	CalculationFunctions.Set_Function(0, nullptr);
	CalculationFunctions.Set_Function(1, Identity);
	CalculationFunctions.Set_Function(2, FastTanHReplacement);

	int32_t NumOfCalculationUnits = NumOfInputUnits + numOfHiddenUnitsL1 + numOfHiddenUnitsL2 + NumOfOutputUnits;

	int32_t idOfFirstInputUnit = 0;
	int32_t idOfFirstHiddenUnitL1 = NumOfInputUnits;
	int32_t idOfFirstHiddenUnitL2 = idOfFirstHiddenUnitL1 + numOfHiddenUnitsL1;
	int32_t idOfFirstOutputUnit = idOfFirstHiddenUnitL2 + numOfHiddenUnitsL2;

	CalculationNet.Initialize(NumOfCalculationUnits, NumOfInputUnits, NumOfOutputUnits);
	CalculationNet.Set_InputUnit(0, 0);
	CalculationNet.Set_InputUnit(1, 1);
	CalculationNet.Set_InputUnit(2, 2);
	CalculationNet.Set_InputUnit(3, 3);
	CalculationNet.Set_InputUnit(4, 4);
	CalculationNet.Set_InputUnit(5, 5);
	CalculationNet.Set_InputUnit(6, 6);
	CalculationNet.Set_InputUnit(7, 7);
	CalculationNet.Set_OutputUnit(idOfFirstOutputUnit, 0);
	CalculationNet.Set_OutputUnit(idOfFirstOutputUnit + 1, 1);
	CalculationNet.Set_OutputUnit(idOfFirstOutputUnit + 2, 2);
	CalculationNet.Set_OutputUnit(idOfFirstOutputUnit + 3, 3);
	CalculationNet.Set_OutputUnit(idOfFirstOutputUnit + 1, 4);

	CCalculationUnitLayer InputLayer;
	CCalculationUnitLayer HiddenLayer1;
	CCalculationUnitLayer HiddenLayer2;
	CCalculationUnitLayer OutputLayer;

	InputLayer.Intialize(idOfFirstInputUnit, NumOfInputUnits);
	HiddenLayer1.Intialize(idOfFirstHiddenUnitL1, numOfHiddenUnitsL1);
	HiddenLayer2.Intialize(idOfFirstHiddenUnitL2, numOfHiddenUnitsL2);
	OutputLayer.Intialize(idOfFirstOutputUnit, NumOfOutputUnits);


	float* pPlasticityArray_InputToHidden1Layer = new (std::nothrow) float[NumOfInputUnits];
	float* pPlasticityArray_Hidden1ToHidden2Layer = new (std::nothrow) float[numOfHiddenUnitsL1];
	float* pPlasticityArray_Hidden2ToOutputLayer = new (std::nothrow) float[numOfHiddenUnitsL2];


	//for (int32_t i = idOfFirstHiddenUnitL1; i < idOfFirstHiddenUnitL2; i++)
	for (int32_t i = HiddenLayer1.FirstUnitID; i < HiddenLayer1.LastUnitIDPlus1; i++)
	{
		for (int32_t j = 0; j < NumOfInputUnits; j++)
		{
			pPlasticityArray_InputToHidden1Layer[j] = RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
		}

		HiddenLayer1.Set_IncomingPlasticityValues(&CalculationNet, &InputLayer, i, pPlasticityArray_InputToHidden1Layer);
	}

	//for (int32_t i = idOfFirstHiddenUnitL2; i < idOfFirstOutputUnit; i++)
	for (int32_t i = HiddenLayer2.FirstUnitID; i < HiddenLayer2.LastUnitIDPlus1; i++)
	{
		for (int32_t j = 0; j < numOfHiddenUnitsL1; j++)
		{
			pPlasticityArray_Hidden1ToHidden2Layer[j] = RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
		}

		HiddenLayer2.Set_IncomingPlasticityValues(&CalculationNet, &HiddenLayer1, i, pPlasticityArray_Hidden1ToHidden2Layer);
	}


	//for (int32_t i = idOfFirstOutputUnit; i < NumOfCalculationUnits; i++)
	for (int32_t i = OutputLayer.FirstUnitID; i < OutputLayer.LastUnitIDPlus1; i++)
	{
		for (int32_t j = 0; j < numOfHiddenUnitsL2; j++)
		{
			pPlasticityArray_Hidden2ToOutputLayer[j] = RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
		}

		OutputLayer.Set_IncomingPlasticityValues(&CalculationNet, &HiddenLayer2, i, pPlasticityArray_Hidden2ToOutputLayer);
	}


	delete[] pPlasticityArray_InputToHidden1Layer;
	pPlasticityArray_InputToHidden1Layer = nullptr;

	delete[] pPlasticityArray_Hidden1ToHidden2Layer;
	pPlasticityArray_Hidden1ToHidden2Layer = nullptr;

	delete[]  pPlasticityArray_Hidden2ToOutputLayer;
	pPlasticityArray_Hidden2ToOutputLayer = nullptr;
}

void CLandingModuleNavigationAI::Initialize(int32_t numOfHiddenUnitsL1, float minRandomPlasticity, float maxRandomPlasticity, uint64_t seed)
{
	CRandomNumbersNN RandomNumbers;
	RandomNumbers.Change_Seed(seed);

	CalculationFunctions.Initialize(3);
	CalculationFunctions.Set_Function(0, nullptr);
	CalculationFunctions.Set_Function(1, Identity);
	CalculationFunctions.Set_Function(2, FastTanHReplacement);

	int32_t NumOfCalculationUnits = NumOfInputUnits + numOfHiddenUnitsL1 + NumOfOutputUnits;

	int32_t idOfFirstInputUnit = 0;
	int32_t idOfFirstHiddenUnitL1 = NumOfInputUnits;
	int32_t idOfFirstOutputUnit = idOfFirstHiddenUnitL1 + numOfHiddenUnitsL1;

	CalculationNet.Initialize(NumOfCalculationUnits, NumOfInputUnits, NumOfOutputUnits);
	CalculationNet.Set_InputUnit(0, 0);
	CalculationNet.Set_InputUnit(1, 1);
	CalculationNet.Set_InputUnit(2, 2);
	CalculationNet.Set_InputUnit(3, 3);
	CalculationNet.Set_InputUnit(4, 4);
	CalculationNet.Set_InputUnit(5, 5);
	CalculationNet.Set_InputUnit(6, 6);
	CalculationNet.Set_InputUnit(7, 7);
	CalculationNet.Set_OutputUnit(idOfFirstOutputUnit, 0);
	CalculationNet.Set_OutputUnit(idOfFirstOutputUnit + 1, 1);
	CalculationNet.Set_OutputUnit(idOfFirstOutputUnit + 2, 2);
	CalculationNet.Set_OutputUnit(idOfFirstOutputUnit + 3, 3);
	CalculationNet.Set_OutputUnit(idOfFirstOutputUnit + 1, 4);

	CCalculationUnitLayer InputLayer;
	CCalculationUnitLayer HiddenLayer1;
	CCalculationUnitLayer OutputLayer;

	InputLayer.Intialize(idOfFirstInputUnit, NumOfInputUnits);
	HiddenLayer1.Intialize(idOfFirstHiddenUnitL1, numOfHiddenUnitsL1);
	OutputLayer.Intialize(idOfFirstOutputUnit, NumOfOutputUnits);


	float* pPlasticityArray_InputToHidden1Layer = new (std::nothrow) float[NumOfInputUnits];
	float* pPlasticityArray_Hidden1ToOutputLayer = new (std::nothrow) float[numOfHiddenUnitsL1];



	//for (int32_t i = idOfFirstHiddenUnitL1; i < idOfFirstHiddenUnitL2; i++)
	for (int32_t i = HiddenLayer1.FirstUnitID; i < HiddenLayer1.LastUnitIDPlus1; i++)
	{
		for (int32_t j = 0; j < NumOfInputUnits; j++)
		{
			pPlasticityArray_InputToHidden1Layer[j] = RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
		}

		HiddenLayer1.Set_IncomingPlasticityValues(&CalculationNet, &InputLayer, i, pPlasticityArray_InputToHidden1Layer);
	}

	
	//for (int32_t i = idOfFirstOutputUnit; i < NumOfCalculationUnits; i++)
	for (int32_t i = OutputLayer.FirstUnitID; i < OutputLayer.LastUnitIDPlus1; i++)
	{
		for (int32_t j = 0; j < numOfHiddenUnitsL1; j++)
		{
			pPlasticityArray_Hidden1ToOutputLayer[j] = RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
		}

		OutputLayer.Set_IncomingPlasticityValues(&CalculationNet, &HiddenLayer1, i, pPlasticityArray_Hidden1ToOutputLayer);
	}


	delete[] pPlasticityArray_InputToHidden1Layer;
	pPlasticityArray_InputToHidden1Layer = nullptr;

	delete[] pPlasticityArray_Hidden1ToOutputLayer;
	pPlasticityArray_Hidden1ToOutputLayer = nullptr;

}

void CLandingModuleNavigationAI::Calculate_PossibleCourseCorrection(float* pOutputData, CSimplePhysicsObject* pLandingModule, float targetPosX, float targetPosY)
{
	float InputData[NumOfInputUnits];


	InputData[0] = pLandingModule->VelX;
	InputData[1] = pLandingModule->VelY;
	InputData[2] = pLandingModule->VelX_LastFrame;
	InputData[3] = pLandingModule->VelY_LastFrame;
	InputData[4] = targetPosX - pLandingModule->PosX;
	InputData[5] = targetPosY - pLandingModule->PosY;
	InputData[6] = targetPosX - pLandingModule->PosX - pLandingModule->VelX;
	InputData[7] = targetPosY - pLandingModule->PosY - pLandingModule->VelY;

	CalculationNet.Set_InputValues(InputData);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(pOutputData);
}