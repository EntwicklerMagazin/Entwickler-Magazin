#include "Graph.h"

using namespace std;



CWeightMatrix::CWeightMatrix()
{}

CWeightMatrix::~CWeightMatrix()
{
	delete[] pWeightArray;
	pWeightArray = nullptr;
}

void CWeightMatrix::Init_Matrix(int32_t sizeX, int32_t sizeY, float initalWeight)
{
	SizeX = sizeX;
	SizeY = sizeY;
	Size = sizeX*sizeY;

	delete[] pWeightArray;
	pWeightArray = nullptr;

	pWeightArray = new (std::nothrow) float[Size];

	for (int32_t i = 0; i < Size; i++)
		pWeightArray[i] = initalWeight;
}

float CWeightMatrix::Get_Weight(int32_t ix, int32_t iy)
{
	return pWeightArray[ix + iy*SizeX];
}

void CWeightMatrix::Set_Weight(int32_t ix, int32_t iy, float weight)
{
	pWeightArray[ix + iy*SizeX] = weight;
}

CGraphNode::CGraphNode()
{}

CGraphNode::~CGraphNode()
{}

void CGraphNode::Connect_With_Graph(CGraphNode *pNodeArray)
{
	pUsedNodeArray = pNodeArray;
}

void CGraphNode::Set_Position(float x, float y, float z)
{
	PosX = x;
	PosY = y;
	PosZ = z;
}

float CGraphNode::Get_Distance_to_Other_Node(int32_t nodeID)
{
	float dx = PosX - pUsedNodeArray[nodeID].PosX;
	float dy = PosY - pUsedNodeArray[nodeID].PosY;
	float dz = PosZ - pUsedNodeArray[nodeID].PosZ;

	return sqrt(dx*dx + dy*dy + dz*dz);
}

float CGraphNode::Get_2DimDistance_to_Other_Node(int32_t nodeID)
{
	float dx = PosX - pUsedNodeArray[nodeID].PosX;
	float dy = PosY - pUsedNodeArray[nodeID].PosY;

	return sqrt(dx * dx + dy * dy);
}

float CGraphNode::Get_InvDistance_to_Other_Node(int32_t nodeID)
{
	float dx = PosX - pUsedNodeArray[nodeID].PosX;
	float dy = PosY - pUsedNodeArray[nodeID].PosY;
	float dz = PosZ - pUsedNodeArray[nodeID].PosZ;

	return 1.0f / sqrt(dx*dx + dy*dy + dz*dz + 0.0001f);
}

float CGraphNode::Get_Inv2DimDistance_to_Other_Node(int32_t nodeID)
{
	float dx = PosX - pUsedNodeArray[nodeID].PosX;
	float dy = PosY - pUsedNodeArray[nodeID].PosY;
	
	return 1.0f / sqrt(dx * dx + dy * dy + 0.0001f);
}

float CGraphNode::Get_DistanceSq_to_Other_Node(int32_t nodeID)
{
	float dx = PosX - pUsedNodeArray[nodeID].PosX;
	float dy = PosY - pUsedNodeArray[nodeID].PosY;
	float dz = PosZ - pUsedNodeArray[nodeID].PosZ;

	return dx*dx + dy*dy + dz*dz;
}

float CGraphNode::Get_2DimDistanceSq_to_Other_Node(int32_t nodeID)
{
	float dx = PosX - pUsedNodeArray[nodeID].PosX;
	float dy = PosY - pUsedNodeArray[nodeID].PosY;
	
	return dx * dx + dy * dy;
}

float CGraphNode::Get_InvDistanceSq_to_Other_Node(int32_t nodeID)
{
	float dx = PosX - pUsedNodeArray[nodeID].PosX;
	float dy = PosY - pUsedNodeArray[nodeID].PosY;
	float dz = PosZ - pUsedNodeArray[nodeID].PosZ;

	return 1.0f / (dx*dx + dy*dy + dz*dz + 0.0001f);
}

float CGraphNode::Get_Inv2DimDistanceSq_to_Other_Node(int32_t nodeID)
{
	float dx = PosX - pUsedNodeArray[nodeID].PosX;
	float dy = PosY - pUsedNodeArray[nodeID].PosY;
	
	return 1.0f / (dx * dx + dy * dy + 0.0001f);
}


float CGraphNode::Calculate_PathDistSq(int32_t *pPathArray, int32_t numNodes)
{
	float distSq = 0.0f;

	int32_t numNodesMinus1 = numNodes - 1;

	for(int32_t i = 0; i < numNodesMinus1; i++)
	{
		distSq += pUsedNodeArray[pPathArray[i]].Get_DistanceSq_to_Other_Node(pPathArray[i + 1]);
	}

	return distSq;
}



float CGraphNode::Calculate_PathDist(int32_t *pPathArray, int32_t numNodes)
{
	float dist = 0.0f;

	int32_t numNodesMinus1 = numNodes - 1;

	for (int32_t i = 0; i < numNodesMinus1; i++)
	{
		dist += pUsedNodeArray[pPathArray[i]].Get_Distance_to_Other_Node(pPathArray[i + 1]);
	}

	return dist;
}

float CGraphNode::Calculate_PathDistSq(float *pPathArray, int32_t numNodes)
{
	float distSq = 0.0f;

	int32_t numNodesMinus1 = numNodes - 1;

	for (int32_t i = 0; i < numNodesMinus1; i++)
	{
		distSq += pUsedNodeArray[static_cast<int32_t>(pPathArray[i])].Get_DistanceSq_to_Other_Node(static_cast<int32_t>(pPathArray[i + 1]));
	}

	return distSq;
}

float CGraphNode::Calculate_PathDist(float *pPathArray, int32_t numNodes)
{
	float dist = 0.0f;

	int32_t numNodesMinus1 = numNodes - 1;

	for (int32_t i = 0; i < numNodesMinus1; i++)
	{
		dist += pUsedNodeArray[static_cast<int32_t>(pPathArray[i])].Get_Distance_to_Other_Node(static_cast<int32_t>(pPathArray[i + 1]));
	}

	return dist;
}

float CGraphNode::Calculate_WeightedPathDistSq(int32_t *pPathArray, float *pWeightArray, int32_t numNodes)
{
	float distSq = 0.0f;

	int32_t numNodesMinus1 = numNodes - 1;

	for (int32_t i = 0; i < numNodesMinus1; i++)
	{
		distSq += pWeightArray[i] * pUsedNodeArray[pPathArray[i]].Get_DistanceSq_to_Other_Node(pPathArray[i + 1]);
	}

	return distSq;
}

float CGraphNode::Calculate_WeightedPathDistSq(int32_t *pPathArray, CWeightMatrix *pWeightMatrix, int32_t numNodes)
{
	float distSq = 0.0f;

	int32_t numNodesMinus1 = numNodes - 1;

	int32_t id1, id2;
	
	for (int32_t i = 0; i < numNodesMinus1; i++)
	{
		id1 = pPathArray[i];
		id2 = pPathArray[i + 1];

		distSq += pWeightMatrix->Get_Weight(id1, id2) * pUsedNodeArray[id1].Get_DistanceSq_to_Other_Node(id2);
	}

	return distSq;
}


float CGraphNode::Calculate_WeightedPathDist(int32_t *pPathArray, float *pWeightArray, int32_t numNodes)
{
	float dist = 0.0f;

	int32_t numNodesMinus1 = numNodes - 1;

	for (int32_t i = 0; i < numNodesMinus1; i++)
	{
		dist += pWeightArray[i] * pUsedNodeArray[pPathArray[i]].Get_Distance_to_Other_Node(pPathArray[i + 1]);
	}

	return dist;
}

float CGraphNode::Calculate_WeightedPathDist(int32_t *pPathArray, CWeightMatrix *pWeightMatrix, int32_t numNodes)
{
	float dist = 0.0f;

	int32_t numNodesMinus1 = numNodes - 1;

	int32_t id1, id2;

	for (int32_t i = 0; i < numNodesMinus1; i++)
	{
		id1 = pPathArray[i];
		id2 = pPathArray[i + 1];

		dist += pWeightMatrix->Get_Weight(id1, id2) * pUsedNodeArray[id1].Get_Distance_to_Other_Node(id2);
	}

	return dist;
}

float CGraphNode::Calculate_WeightedPathDistSq(float *pPathArray, float *pWeightArray, int32_t numNodes)
{
	float distSq = 0.0f;

	int32_t numNodesMinus1 = numNodes - 1;

	for (int32_t i = 0; i < numNodesMinus1; i++)
	{
		distSq += pWeightArray[i] * pUsedNodeArray[static_cast<int32_t>(pPathArray[i])].Get_DistanceSq_to_Other_Node(static_cast<int32_t>(pPathArray[i + 1]));
	}

	return distSq;
}

float CGraphNode::Calculate_WeightedPathDistSq(float *pPathArray, CWeightMatrix *pWeightMatrix, int32_t numNodes)
{
	float distSq = 0.0f;

	int32_t numNodesMinus1 = numNodes - 1;

	int32_t id1, id2;

	for (int32_t i = 0; i < numNodesMinus1; i++)
	{
		id1 = static_cast<int32_t>(pPathArray[i]);
		id2 = static_cast<int32_t>(pPathArray[i + 1]);

		distSq += pWeightMatrix->Get_Weight(id1, id2) * pUsedNodeArray[id1].Get_DistanceSq_to_Other_Node(id2);
	}

	return distSq;
}

float CGraphNode::Calculate_WeightedPathDist(float *pPathArray, float *pWeightArray, int32_t numNodes)
{
	float dist = 0.0f;

	int32_t numNodesMinus1 = numNodes - 1;

	for (int32_t i = 0; i < numNodesMinus1; i++)
	{
		dist += pWeightArray[i] * pUsedNodeArray[static_cast<int32_t>(pPathArray[i])].Get_Distance_to_Other_Node(static_cast<int32_t>(pPathArray[i + 1]));
	}

	return dist;
}

float CGraphNode::Calculate_WeightedPathDist(float *pPathArray, CWeightMatrix *pWeightMatrix, int32_t numNodes)
{
	float dist = 0.0f;

	int32_t numNodesMinus1 = numNodes - 1;

	int32_t id1, id2;

	for (int32_t i = 0; i < numNodesMinus1; i++)
	{
		id1 = static_cast<int32_t>(pPathArray[i]);
		id2 = static_cast<int32_t>(pPathArray[i + 1]);

		dist += pWeightMatrix->Get_Weight(id1, id2) * pUsedNodeArray[id1].Get_Distance_to_Other_Node(id2);
	}

	return dist;
}

void Rearrange_TSP_Path(int32_t *pOutPathArray,int32_t *pInPathArray, int32_t arraySize, int32_t iDofFirstAndLastWaypoint)
{
	int32_t id_InPathArray = 0;
	int32_t arraySizeMinus1 = arraySize - 1;

	for (int32_t i = 0; i < arraySize; i++)
	{
		if (pInPathArray[i] == iDofFirstAndLastWaypoint)
		{
			id_InPathArray = i;
			break;
		}
	}

	int32_t id_OutPathArray = 0;

	for (int32_t i = 0; i < arraySize; i++)
	{
		pOutPathArray[id_OutPathArray] = pInPathArray[id_InPathArray];

		id_OutPathArray++;

		id_InPathArray++;
		id_InPathArray = id_InPathArray % arraySizeMinus1;
	}
}

void Rearrange_TSP_Path(float *pOutPathArray, float *pInPathArray, int32_t arraySize, float iDofFirstAndLastWaypoint)
{
	int32_t id_InPathArray = 0;
	int32_t arraySizeMinus1 = arraySize - 1;

	for (int32_t i = 0; i < arraySize; i++)
	{
		if (pInPathArray[i] == iDofFirstAndLastWaypoint)
		{
			id_InPathArray = i;
			break;
		}
	}

	int32_t id_OutPathArray = 0;

	for (int32_t i = 0; i < arraySize; i++)
	{
		pOutPathArray[id_OutPathArray] = pInPathArray[id_InPathArray];

		id_OutPathArray++;

		id_InPathArray++;
		id_InPathArray = id_InPathArray % arraySizeMinus1;
	}
}

void Rearrange_TSP_Path(int32_t *pOutPathArray, float *pInPathArray, int32_t arraySize, float iDofFirstAndLastWaypoint)
{
	int32_t id_InPathArray = 0;
	int32_t arraySizeMinus1 = arraySize - 1;

	for (int32_t i = 0; i < arraySize; i++)
	{
		if (pInPathArray[i] == iDofFirstAndLastWaypoint)
		{
			id_InPathArray = i;
			break;
		}
	}

	int32_t id_OutPathArray = 0;

	for (int32_t i = 0; i < arraySize; i++)
	{
		pOutPathArray[id_OutPathArray] = static_cast<int32_t>(pInPathArray[id_InPathArray]);

		id_OutPathArray++;

		id_InPathArray++;
		id_InPathArray = id_InPathArray % arraySizeMinus1;
	}
}


/*
CGeneralNode::CGeneralNode()
{}

CGeneralNode::~CGeneralNode()
{
	delete[] pFeatureValueArray;
	pFeatureValueArray = nullptr;

	delete[] pAdjacentNodeMemoryArray;
	pAdjacentNodeMemoryArray = nullptr;

	delete[] pAdjacentNodeIDArray;
	pAdjacentNodeIDArray = nullptr;
}

void CGeneralNode::Init_FeatureValueArray(int32_t numOfFeatures)
{
	delete[] pFeatureValueArray;
	pFeatureValueArray = nullptr;

	NumOfFeatures = numOfFeatures;

	pFeatureValueArray = new (std::nothrow) float[numOfFeatures];

	for (int32_t i = 0; i < numOfFeatures; i++)
	{
		pFeatureValueArray[i] = 0.0f;
	}
}

void CGeneralNode::Connect_With_NodeArray(CGeneralNode* pNodeArray)
{
	pUsedNodeArray = pNodeArray;
}

void CGeneralNode::Set_Position(float x, float y, float z)
{
	PosX = x;
	PosY = y;
	PosZ = z;
}

float CGeneralNode::Get_Distance_to_Other_Node(int32_t nodeID)
{
	float dx = PosX - pUsedNodeArray[nodeID].PosX;
	float dy = PosY - pUsedNodeArray[nodeID].PosY;
	float dz = PosZ - pUsedNodeArray[nodeID].PosZ;

	return sqrt(dx * dx + dy * dy + dz * dz);
}

float CGeneralNode::Get_InvDistance_to_Other_Node(int32_t nodeID)
{
	float dx = PosX - pUsedNodeArray[nodeID].PosX;
	float dy = PosY - pUsedNodeArray[nodeID].PosY;
	float dz = PosZ - pUsedNodeArray[nodeID].PosZ;

	return 1.0f / sqrt(dx * dx + dy * dy + dz * dz + 0.0001f);
}

float CGeneralNode::Get_DistanceSq_to_Other_Node(int32_t nodeID)
{
	float dx = PosX - pUsedNodeArray[nodeID].PosX;
	float dy = PosY - pUsedNodeArray[nodeID].PosY;
	float dz = PosZ - pUsedNodeArray[nodeID].PosZ;

	return dx * dx + dy * dy + dz * dz;
}

float CGeneralNode::Get_InvDistanceSq_to_Other_Node(int32_t nodeID)
{
	float dx = PosX - pUsedNodeArray[nodeID].PosX;
	float dy = PosY - pUsedNodeArray[nodeID].PosY;
	float dz = PosZ - pUsedNodeArray[nodeID].PosZ;

	return 1.0f / (dx * dx + dy * dy + dz * dz + 0.0001f);
}

void CGeneralNode::Init_AdjacentNodes(int32_t numOfAdjacentNodesMax)
{
	delete[] pAdjacentNodeMemoryArray;
	pAdjacentNodeMemoryArray = nullptr;

	delete[] pAdjacentNodeIDArray;
	pAdjacentNodeIDArray = nullptr;

	NumOfAdjacentNodes = 0;

	NumOfAdjacentNodesMax = numOfAdjacentNodesMax;
	NumOfAdjacentNodesMaxPlus2 = numOfAdjacentNodesMax;

	pAdjacentNodeMemoryArray = new (std::nothrow) int32_t[NumOfAdjacentNodesMaxPlus2];

	for (int32_t i = 0; i < NumOfAdjacentNodesMaxPlus2; i++)
	{
		pAdjacentNodeMemoryArray[i] = 0;
	}

	pAdjacentNodeIDArray = new (std::nothrow) int32_t[NumOfAdjacentNodesMax];

	for (int32_t i = 0; i < NumOfAdjacentNodesMax; i++)
	{
		pAdjacentNodeIDArray[i] = 0;
	}

	AdjacentNodeMemoryManager.Initialize(NumOfAdjacentNodesMaxPlus2);
	AdjacentNodeLinkedListManager.Initialize(NumOfAdjacentNodesMaxPlus2);
}

bool CGeneralNode::Add_AdjacentNode(int32_t nodeID)
{
	int32_t memoryElementID = AdjacentNodeMemoryManager.Request_Unused_MemoryElementID();

	if (memoryElementID == 0)
		return false;

	if (AdjacentNodeLinkedListManager.Init_New_ListElement(memoryElementID) == false)
	{
		return false;
	}

	pAdjacentNodeMemoryArray[memoryElementID] = nodeID;

	NumOfAdjacentNodes++;

	Get_ListOfAdjacentNodeIDs(pAdjacentNodeIDArray);

	return true;
}

bool CGeneralNode::Remove_AdjacentNode(int32_t nodeID)
{
	int32_t memoryElementID = 0;

	for(int32_t i = 1; i < NumOfAdjacentNodesMaxPlus2; i++)
	{
		if (pAdjacentNodeMemoryArray[i] == nodeID)
		{
			pAdjacentNodeMemoryArray[i] = 0;
			memoryElementID = i;
			break;
		}
	}

	if (memoryElementID == 0)
	{
		return false;
	}

	if (AdjacentNodeLinkedListManager.Free_Used_ListElement(memoryElementID) == false)
	{
		return false;
	}

	if (AdjacentNodeMemoryManager.Free_Used_MemoryElement(memoryElementID) == false)
	{
		return false;
	}

	NumOfAdjacentNodes--;

	Get_ListOfAdjacentNodeIDs(pAdjacentNodeIDArray);

	return true;
}

void CGeneralNode::Output_Init_AdjacentNodeIDs(void)
{
	int32_t memoryElementID = 0;

	do
	{
		memoryElementID = AdjacentNodeLinkedListManager.Get_Next_Used_ListElement(memoryElementID);

		if (memoryElementID == 0)
		{
			break;
		}

		cout << pAdjacentNodeMemoryArray[memoryElementID] << endl;

	} while (true);
}

int32_t CGeneralNode::Get_ListOfAdjacentNodeIDs(int32_t* pOutIDArray)
{
	int32_t counter = 0;

	int32_t memoryElementID = 0;

	do
	{
		memoryElementID = AdjacentNodeLinkedListManager.Get_Next_Used_ListElement(memoryElementID);

		if (memoryElementID == 0)
		{
			break;
		}

		pOutIDArray[counter] = pAdjacentNodeMemoryArray[memoryElementID];
		counter++;

	} while (true);

	return counter;
}
*/


CGeneralNode::CGeneralNode()
{}

CGeneralNode::~CGeneralNode()
{
	delete[] pFeatureValueArray;
	pFeatureValueArray = nullptr;

	delete[] pAdjacentNodeMemoryArray;
	pAdjacentNodeMemoryArray = nullptr;

	delete[] pAdjacentNodeIDArray;
	pAdjacentNodeIDArray = nullptr;
}

void CGeneralNode::Init_FeatureValueArray(int32_t numOfFeatures)
{
	delete[] pFeatureValueArray;
	pFeatureValueArray = nullptr;

	NumOfFeatures = numOfFeatures;

	pFeatureValueArray = new (std::nothrow) float[numOfFeatures];

	for (int32_t i = 0; i < numOfFeatures; i++)
	{
		pFeatureValueArray[i] = 0.0f;
	}

	CompetitionModusEnabled = true;
	AdaptionModusEnabled = true;
}

void CGeneralNode::Set_Features(float *pFeatureArray)
{
	for (int32_t i = 0; i < NumOfFeatures; i++)
	{
		pFeatureValueArray[i] = pFeatureArray[i];
	}
}

void CGeneralNode::Get_Features(float *pOutFeatureArray)
{
	for (int32_t i = 0; i < NumOfFeatures; i++)
	{
		pOutFeatureArray[i] = pFeatureValueArray[i];
	}
}

void CGeneralNode::Disable_CompetitionModus(void)
{
	CompetitionModusEnabled = false;
}

void CGeneralNode::Enable_CompetitionModus(void)
{
	CompetitionModusEnabled = true;
}

void CGeneralNode::Disable_AdaptionModus(void)
{
	AdaptionModusEnabled = false;
}

void CGeneralNode::Enable_AdaptionModus(void)
{
	AdaptionModusEnabled = true;
}


void CGeneralNode::Connect_With_NodeArray(CGeneralNode* pNodeArray, int32_t numOfNodes)
{
	NumOfNodes = numOfNodes;
	pUsedNodeArray = pNodeArray;
}

void CGeneralNode::Set_Position(float x1)
{
	PosX1 = x1;
	PosX2 = 0.0f;
	PosX3 = 0.0f;
}

void CGeneralNode::Set_Position(float x1, float x2)
{
	PosX1 = x1;
	PosX2 = x2;
	PosX3 = 0.0f;
}

void CGeneralNode::Set_Position(float x1, float x2, float x3)
{
	PosX1 = x1;
	PosX2 = x2;
	PosX3 = x3;
}

void CGeneralNode::Set_CircumferencePos(float angle, float radius)
{
	PosX1 = angle;
	PosX2 = radius;
	PosX3 = 0.0f;
}

float CGeneralNode::Get_CircumferenceDistance_to_Other_Node(int32_t nodeID)
{
	float deltaAngle = abs(PosX1 - pUsedNodeArray[nodeID].PosX1);

	if (deltaAngle > fConstPI)
	{
		deltaAngle = fConst2PI - deltaAngle;
	}

	return PosX2 * deltaAngle; // PosX2: radius
}

float CGeneralNode::Get_CircumferenceDistanceSq_to_Other_Node(int32_t nodeID)
{
	float deltaAngle = abs(PosX1 - pUsedNodeArray[nodeID].PosX1);

	if (deltaAngle > fConstPI)
	{
		deltaAngle = fConst2PI - deltaAngle;
	}

	float dist = PosX2 * deltaAngle; // PosX2: radius
	return dist * dist;
}

float CGeneralNode::Get_3DimDistance_to_Other_Node(int32_t nodeID)
{
	float dx1 = PosX1 - pUsedNodeArray[nodeID].PosX1;
	float dx2 = PosX2 - pUsedNodeArray[nodeID].PosX2;
	float dx3 = PosX3 - pUsedNodeArray[nodeID].PosX3;

	return sqrt(dx1 * dx1 + dx2 * dx2 + dx3 * dx3);
}

float CGeneralNode::Get_2DimDistance_to_Other_Node(int32_t nodeID)
{
	float dx1 = PosX1 - pUsedNodeArray[nodeID].PosX1;
	float dx2 = PosX2 - pUsedNodeArray[nodeID].PosX2;

	return sqrt(dx1 * dx1 + dx2 * dx2);
}

float CGeneralNode::Get_1DimDistance_to_Other_Node(int32_t nodeID)
{
	float dx1 = PosX1 - pUsedNodeArray[nodeID].PosX1;
	
	return abs(dx1);
}

float CGeneralNode::Get_3DimDistanceSq_to_Other_Node(int32_t nodeID)
{
	float dx1 = PosX1 - pUsedNodeArray[nodeID].PosX1;
	float dx2 = PosX2 - pUsedNodeArray[nodeID].PosX2;
	float dx3 = PosX3 - pUsedNodeArray[nodeID].PosX3;

	return dx1 * dx1 + dx2 * dx2 + dx3 * dx3;
}

float CGeneralNode::Get_2DimDistanceSq_to_Other_Node(int32_t nodeID)
{
	float dx1 = PosX1 - pUsedNodeArray[nodeID].PosX1;
	float dx2 = PosX2 - pUsedNodeArray[nodeID].PosX2;
	
	return dx1 * dx1 + dx2 * dx2;
}

float CGeneralNode::Get_1DimDistanceSq_to_Other_Node(int32_t nodeID)
{
	float dx1 = PosX1 - pUsedNodeArray[nodeID].PosX1;

	return dx1 * dx1;
}

void CGeneralNode::Init_AdjacentNodes(int32_t numOfAdjacentNodesMax)
{
	delete[] pAdjacentNodeMemoryArray;
	pAdjacentNodeMemoryArray = nullptr;

	delete[] pAdjacentNodeIDArray;
	pAdjacentNodeIDArray = nullptr;

	NumOfAdjacentNodes = 0;

	NumOfAdjacentNodesMax = numOfAdjacentNodesMax;
	

	pAdjacentNodeMemoryArray = new (std::nothrow) int32_t[NumOfAdjacentNodesMax];
	pAdjacentNodeIDArray = new (std::nothrow) int32_t[NumOfAdjacentNodesMax];

	for (int32_t i = 0; i < NumOfAdjacentNodesMax; i++)
	{
		pAdjacentNodeMemoryArray[i] = -1;
		pAdjacentNodeIDArray[i] = 0;
	}
}

bool CGeneralNode::Add_AdjacentNode(int32_t nodeID)
{
	int32_t memoryElementID = -1;

	for (int32_t i = 0; i < NumOfAdjacentNodesMax; i++)
	{
		if (pAdjacentNodeMemoryArray[i] == -1)
		{
			memoryElementID = i;
			break;
		}
	}

	if (memoryElementID == -1)
	{
		return false;
	}

	pAdjacentNodeMemoryArray[memoryElementID] = nodeID;

	NumOfAdjacentNodes = 0;

	for (int32_t i = 0; i < NumOfAdjacentNodesMax; i++)
	{
		if (pAdjacentNodeMemoryArray[i] > -1)
		{
			pAdjacentNodeIDArray[NumOfAdjacentNodes] = pAdjacentNodeMemoryArray[i];
			NumOfAdjacentNodes++;
		}
	}

	return true;
}

bool CGeneralNode::Remove_AdjacentNode(int32_t nodeID)
{
	int32_t memoryElementID = -1;

	for (int32_t i = 0; i < NumOfAdjacentNodesMax; i++)
	{
		if (pAdjacentNodeMemoryArray[i] == nodeID)
		{
			pAdjacentNodeMemoryArray[i] = -1;
			memoryElementID = i;
			break;
		}
	}

	if (memoryElementID == -1)
	{
		return false;
	}

	NumOfAdjacentNodes = 0;

	for (int32_t i = 0; i < NumOfAdjacentNodesMax; i++)
	{
		if (pAdjacentNodeMemoryArray[i] > -1)
		{
			pAdjacentNodeIDArray[NumOfAdjacentNodes] = pAdjacentNodeMemoryArray[i];
			NumOfAdjacentNodes++;
		}
	}

	return true;
}

void CGeneralNode::Output_Init_AdjacentNodeIDs(void)
{
	for (int32_t i = 0; i < NumOfAdjacentNodes; i++)
	{
		cout << pAdjacentNodeIDArray[i] << endl;
	}
}

int32_t CGeneralNode::Get_ListOfAdjacentNodeIDs(int32_t* pOutIDArray)
{
	for (int32_t i = 0; i < NumOfAdjacentNodes; i++)
	{
		pOutIDArray[i] = pAdjacentNodeIDArray[i];
	}

	return NumOfAdjacentNodes;
}

float CGeneralNode::Calculate_FeatureDist(float* pInputArray)
{
	float Sum = 0.0f;

	for (int32_t i = 0; i < NumOfFeatures; i++)
	{
		float diff = pInputArray[i] - pFeatureValueArray[i];
		Sum += (diff * diff);
	}

	return sqrt(Sum);
}

void CGeneralNode::Adapt_Features(float adaptionRate, float* pInputArray)
{
	if (AdaptionModusEnabled == false)
	{
		return;
	}

	for (int32_t i = 0; i < NumOfFeatures; i++)
	{
		pFeatureValueArray[i] = pFeatureValueArray[i] + adaptionRate * (pInputArray[i] - pFeatureValueArray[i]);
	}
}

void CGeneralNode::Adapt_Features_3DNodeSpace(int32_t idOfBestMatchingNode, float adaptionRate, float adaptionDistFactor, float* pInputArray)
{
	if (AdaptionModusEnabled == false)
	{
		return;
	}

	if (NumOfAdjacentNodes > 0)
	{
		bool bestMatchingNodeFound = false;

		for (int32_t i = 0; i < NumOfAdjacentNodes; i++)
		{
			if (pAdjacentNodeIDArray[i] == idOfBestMatchingNode)
			{
				bestMatchingNodeFound = true;
				break;
			}
		}

		if (bestMatchingNodeFound == false)
		{
			return;
		}
	}

	float distSqToBestMatchingUnit = Get_3DimDistanceSq_to_Other_Node(idOfBestMatchingNode);
	adaptionRate *= exp(-adaptionDistFactor * distSqToBestMatchingUnit);

	for (int32_t i = 0; i < NumOfFeatures; i++)
	{
		pFeatureValueArray[i] = pFeatureValueArray[i] + adaptionRate * (pInputArray[i] - pFeatureValueArray[i]);
	}
}

void CGeneralNode::Adapt_Features_2DNodeSpace(int32_t idOfBestMatchingNode, float adaptionRate, float adaptionDistFactor, float* pInputArray)
{
	if (AdaptionModusEnabled == false)
	{
		return;
	}

	if (NumOfAdjacentNodes > 0)
	{
		bool bestMatchingNodeFound = false;

		for (int32_t i = 0; i < NumOfAdjacentNodes; i++)
		{
			if (pAdjacentNodeIDArray[i] == idOfBestMatchingNode)
			{
				bestMatchingNodeFound = true;
				break;
			}
		}

		if (bestMatchingNodeFound == false)
		{
			return;
		}
	}

	float distSqToBestMatchingUnit = Get_2DimDistanceSq_to_Other_Node(idOfBestMatchingNode);
	adaptionRate *= exp(-adaptionDistFactor * distSqToBestMatchingUnit);

	for (int32_t i = 0; i < NumOfFeatures; i++)
	{
		pFeatureValueArray[i] = pFeatureValueArray[i] + adaptionRate * (pInputArray[i] - pFeatureValueArray[i]);
	}
}

void CGeneralNode::Adapt_Features_1DNodeSpace(int32_t idOfBestMatchingNode, float adaptionRate, float adaptionDistFactor, float* pInputArray)
{
	if (AdaptionModusEnabled == false)
	{
		return;
	}

	if (NumOfAdjacentNodes > 0)
	{
		bool bestMatchingNodeFound = false;

		for (int32_t i = 0; i < NumOfAdjacentNodes; i++)
		{
			if (pAdjacentNodeIDArray[i] == idOfBestMatchingNode)
			{
				bestMatchingNodeFound = true;
				break;
			}
		}

		if (bestMatchingNodeFound == false)
		{
			return;
		}
	}

	float distSqToBestMatchingUnit = Get_1DimDistanceSq_to_Other_Node(idOfBestMatchingNode);
	adaptionRate *= exp(-adaptionDistFactor * distSqToBestMatchingUnit);

	for (int32_t i = 0; i < NumOfFeatures; i++)
	{
		pFeatureValueArray[i] = pFeatureValueArray[i] + adaptionRate * (pInputArray[i] - pFeatureValueArray[i]);
	}
}

void CGeneralNode::Adapt_Features_CircumferenceNodeSpace(int32_t idOfBestMatchingNode, float adaptionRate, float adaptionDistFactor, float* pInputArray)
{
	if (AdaptionModusEnabled == false)
	{
		return;
	}

	if (NumOfAdjacentNodes > 0)
	{
		bool bestMatchingNodeFound = false;

		for (int32_t i = 0; i < NumOfAdjacentNodes; i++)
		{
			if (pAdjacentNodeIDArray[i] == idOfBestMatchingNode)
			{
				bestMatchingNodeFound = true;
				break;
			}
		}

		if (bestMatchingNodeFound == false)
		{
			return;
		}
	}

	float distSqToBestMatchingUnit = Get_CircumferenceDistanceSq_to_Other_Node(idOfBestMatchingNode);
	adaptionRate *= exp(-adaptionDistFactor * distSqToBestMatchingUnit);

	for (int32_t i = 0; i < NumOfFeatures; i++)
	{
		pFeatureValueArray[i] = pFeatureValueArray[i] + adaptionRate * (pInputArray[i] - pFeatureValueArray[i]);
	}
}




void  CGeneralNode::Adapt_Features_3DNodeSpace(int32_t idOfBestMatchingNode, float adaptionRate, int32_t iterationCount, float adaptionIterationCountFactor, float adaptionDistFactor, float* pInputArray)
{
	if (AdaptionModusEnabled == false)
	{
		return;
	}

	if (NumOfAdjacentNodes > 0)
	{
		bool bestMatchingNodeFound = false;

		for (int32_t i = 0; i < NumOfAdjacentNodes; i++)
		{
			if (pAdjacentNodeIDArray[i] == idOfBestMatchingNode)
			{
				bestMatchingNodeFound = true;
				break;
			}
		}

		if (bestMatchingNodeFound == false)
		{
			return;
		}
	}

	float fIterationCount = static_cast<float>(iterationCount);

	float distSqToBestMatchingUnit = Get_3DimDistanceSq_to_Other_Node(idOfBestMatchingNode);
	//adaptionRate *= exp(-adaptionDistFactor * distSqToBestMatchingUnit);
	//adaptionRate *= exp(-adaptionIterationCountFactor * fIterationCount);

	adaptionRate *= exp(-(adaptionDistFactor * distSqToBestMatchingUnit + adaptionIterationCountFactor * fIterationCount));

	for (int32_t i = 0; i < NumOfFeatures; i++)
	{
		pFeatureValueArray[i] = pFeatureValueArray[i] + adaptionRate * (pInputArray[i] - pFeatureValueArray[i]);
	}
}

void  CGeneralNode::Adapt_Features_2DNodeSpace(int32_t idOfBestMatchingNode, float adjustmentRate, int32_t iterationCount, float adjustmentIterationCountFactor, float adjustmentDistFactor, float* pInputArray)
{
	if (AdaptionModusEnabled == false)
	{
		return;
	}

	if (NumOfAdjacentNodes > 0)
	{
		bool bestMatchingNodeFound = false;

		for (int32_t i = 0; i < NumOfAdjacentNodes; i++)
		{
			if (pAdjacentNodeIDArray[i] == idOfBestMatchingNode)
			{
				bestMatchingNodeFound = true;
				break;
			}
		}

		if (bestMatchingNodeFound == false)
		{
			return;
		}
	}

	float fIterationCount = static_cast<float>(iterationCount);

	float distSqToBestMatchingUnit = Get_2DimDistanceSq_to_Other_Node(idOfBestMatchingNode);
	//adjustmentRate *= exp(-adjustmentDistFactor * distSqToBestMatchingUnit);
	//adjustmentRate *= exp(-adjustmentIterationCountFactor * fIterationCount);

	adjustmentRate *= exp(-(adjustmentDistFactor * distSqToBestMatchingUnit + adjustmentIterationCountFactor * fIterationCount));

	for (int32_t i = 0; i < NumOfFeatures; i++)
	{
		pFeatureValueArray[i] = pFeatureValueArray[i] + adjustmentRate * (pInputArray[i] - pFeatureValueArray[i]);
	}
}

void  CGeneralNode::Adapt_Features_1DNodeSpace(int32_t idOfBestMatchingNode, float adaptionRate, int32_t iterationCount, float adaptionIterationCountFactor, float adaptionDistFactor, float* pInputArray)
{
	if (AdaptionModusEnabled == false)
	{
		return;
	}

	if (NumOfAdjacentNodes > 0)
	{
		bool bestMatchingNodeFound = false;

		for (int32_t i = 0; i < NumOfAdjacentNodes; i++)
		{
			if (pAdjacentNodeIDArray[i] == idOfBestMatchingNode)
			{
				bestMatchingNodeFound = true;
				break;
			}
		}

		if (bestMatchingNodeFound == false)
		{
			return;
		}
	}

	float fIterationCount = static_cast<float>(iterationCount);

	float distSqToBestMatchingUnit = Get_1DimDistanceSq_to_Other_Node(idOfBestMatchingNode);
	//adaptionRate *= exp(-adaptionDistFactor * distSqToBestMatchingUnit);
	//adaptionRate *= exp(-adaptionIterationCountFactor * fIterationCount);

	adaptionRate *= exp(-(adaptionDistFactor * distSqToBestMatchingUnit + adaptionIterationCountFactor * fIterationCount));

	for (int32_t i = 0; i < NumOfFeatures; i++)
	{
		pFeatureValueArray[i] = pFeatureValueArray[i] + adaptionRate * (pInputArray[i] - pFeatureValueArray[i]);
	}
}

void  CGeneralNode::Adapt_Features_CircumferenceNodeSpace(int32_t idOfBestMatchingNode, float adaptionRate, int32_t iterationCount, float adaptionIterationCountFactor, float adaptionDistFactor, float* pInputArray)
{
	if (AdaptionModusEnabled == false)
	{
		return;
	}

	if (NumOfAdjacentNodes > 0)
	{
		bool bestMatchingNodeFound = false;

		for (int32_t i = 0; i < NumOfAdjacentNodes; i++)
		{
			if (pAdjacentNodeIDArray[i] == idOfBestMatchingNode)
			{
				bestMatchingNodeFound = true;
				break;
			}
		}

		if (bestMatchingNodeFound == false)
		{
			return;
		}
	}

	float fIterationCount = static_cast<float>(iterationCount);

	float distSqToBestMatchingUnit = Get_CircumferenceDistanceSq_to_Other_Node(idOfBestMatchingNode);
	//adaptionRate *= exp(-adaptionDistFactor * distSqToBestMatchingUnit);
	//adaptionRate *= exp(-adaptionIterationCountFactor * fIterationCount);
	adaptionRate *= exp(-(adaptionDistFactor * distSqToBestMatchingUnit + adaptionIterationCountFactor * fIterationCount));

	for (int32_t i = 0; i < NumOfFeatures; i++)
	{
		pFeatureValueArray[i] = pFeatureValueArray[i] + adaptionRate * (pInputArray[i] - pFeatureValueArray[i]);
	}
}

int32_t Get_IDOfBestMatchingNode(float* pInputArray, CGeneralNode* pNodeArray, int32_t numOfNodes)
{
	float featureDist = 10000000.0f;
	int32_t idOfBestMatchingUnit = 0;

	for (int32_t i = 0; i < numOfNodes; i++)
	{
		if(pNodeArray[i].CompetitionModusEnabled == false)
		{
			continue;
		}

		float dist = pNodeArray[i].Calculate_FeatureDist(pInputArray);

		if (dist < featureDist)
		{
			featureDist = dist;
			idOfBestMatchingUnit = i;
		}
	}

	return idOfBestMatchingUnit;
}

int32_t Get_IDOfWorstMatchingNode(float* pInputArray, CGeneralNode* pNodeArray, int32_t numOfNodes)
{
	float featureDist = 0.0f;
	int32_t idOfWorstMatchingUnit = 0;

	for (int32_t i = 0; i < numOfNodes; i++)
	{
		if (pNodeArray[i].CompetitionModusEnabled == false)
		{
			continue;
		}

		float dist = pNodeArray[i].Calculate_FeatureDist(pInputArray);

		if (dist > featureDist)
		{
			featureDist = dist;
			idOfWorstMatchingUnit = i;
		}
	}

	return idOfWorstMatchingUnit;
}







