#include "GDIPlusFramework.h"


#pragma comment (lib,"Gdiplus.lib")

#pragma warning( disable: 4996)

//#define _CRT_NONSTDC_NO_WARNINGS


bool g_Running = false;
bool g_Pause = false;
bool g_LeftMouseButtonPressed = false;
bool g_RightMouseButtonPressed = false;
bool g_MiddleMouseButtonPressed = false; 
int32_t g_MouseWheelRollingValue = 0;
POINT g_ActualCursorPosition;



void charToWChar(wchar_t* wtext, char* text)
{
	size_t size = strlen(text) + 1;
	mbstowcs(wtext, text, size);
}

// konvertiert CHAR-String in einen WCHAR-String:
int ConvertAnsiStringToWideCch(WCHAR* wstrDestination, const CHAR* strSource, int cchDestChar)
{
	if (wstrDestination == NULL || strSource == NULL || cchDestChar < 1)
		return -1;

	int nResult = MultiByteToWideChar(CP_ACP, 0, strSource, -1,
		wstrDestination, cchDestChar);
	wstrDestination[cchDestChar - 1] = 0;

	if (nResult == 0)
		return -1;
	return 1;
}

/*
BSTR ConvToBSTR(char* c)
{
	OLECHAR*     svalue = NULL;
	BSTR         bstrValue = NULL;
	int          x = 0;

	if ((x = MultiByteToWideChar(CP_ACP, 0, c, -1, svalue, 0)) != 1)
	{
		svalue = (OLECHAR*)malloc(sizeof(OLECHAR) * x);
		if (MultiByteToWideChar(CP_ACP, 0, c, -1, svalue, x) == 0)
			svalue = L"";
	}
	else
	{
		svalue = L"";
	}

	bstrValue = SysAllocString(svalue);

	free(svalue);
	svalue = NULL;

	return bstrValue;
}
*/

void Conv_BSTR_To_Char(char* c, BSTR str)
{
	int len = SysStringLen(str);
	int bytes = WideCharToMultiByte(CP_ACP, 0, str, len, c, len, NULL, NULL);
	c[bytes] = '\0';
}

CGDIPlusWindow::CGDIPlusWindow()
{
	swprintf(WindowTitle, L"No Title");

	// Initialize GDI+.
	Gdiplus::GdiplusStartup(&gdiplusToken, &gdiplusStartupInput, NULL);
}


void CGDIPlusWindow::Set_WindowDimensions(uint32_t screenWidth, uint32_t screenHeight, uint32_t initialX, uint32_t initialY)
{
	ScreenWidth = screenWidth;
	ScreenHeight = screenHeight;

	InitialX = initialX;
	InitialY = initialY;
}

void CGDIPlusWindow::Set_WindowTitle(const char *pTitle)
{
	size_t size = strlen(pTitle) + 1;

	mbstowcs(WindowTitle, pTitle, size);
}
void CGDIPlusWindow::Set_WindowTitle(const wchar_t *pTitle)
{
	swprintf(WindowTitle, pTitle);
}

void CGDIPlusWindow::Set_StandardFont(const wchar_t *pString, float size, int32_t style, Gdiplus::Unit unit)
{
	delete pStandardFontFamily;
	pStandardFontFamily = nullptr;

	delete pStandardFont;
	pStandardFont = nullptr;

	pStandardFontFamily = new Gdiplus::FontFamily(pString);
	pStandardFont = new Gdiplus::Font(pStandardFontFamily, size, style, unit);
}

void CGDIPlusWindow::Initialize(HWND windowHandle)
{
	if (Initialized == true)
		return;

	WindowHandle = windowHandle;
	WindowDeviceContext = GetDC(WindowHandle);
	
	pSceneBitmap = new Gdiplus::Bitmap(ScreenWidth, ScreenHeight, PixelFormat32bppARGB);

	
	
	pSceneGraphics = new Gdiplus::Graphics(pSceneBitmap);
	
	//pSceneGraphics->SetCompositingMode(Gdiplus::CompositingModeSourceCopy);
	pSceneGraphics->SetCompositingQuality(Gdiplus::CompositingQualityHighSpeed);
	pSceneGraphics->SetPixelOffsetMode(Gdiplus::PixelOffsetModeNone);
	pSceneGraphics->SetSmoothingMode(Gdiplus::SmoothingModeNone);
	pSceneGraphics->SetInterpolationMode(Gdiplus::InterpolationModeDefault);

	BackBufferDeviceContext = CreateCompatibleDC(WindowDeviceContext);
	BackBufferBitmap = CreateCompatibleBitmap(WindowDeviceContext, pSceneBitmap->GetWidth(), pSceneBitmap->GetHeight());
	OldBackBufferBitmap = (HBITMAP)SelectObject(BackBufferDeviceContext, BackBufferBitmap);

	pBackBufferGraphics = new Gdiplus::Graphics(BackBufferDeviceContext);

	pSolidBrush = new Gdiplus::SolidBrush(Gdiplus::Color::White);
	pPen = new Gdiplus::Pen(Gdiplus::Color::White);
}


CGDIPlusWindow::~CGDIPlusWindow()
{
	if(Initialized == true)
	{
		ReleaseDC(WindowHandle, WindowDeviceContext);
		SelectObject(BackBufferDeviceContext, OldBackBufferBitmap);
		DeleteDC(BackBufferDeviceContext);
		DeleteObject(BackBufferBitmap);

		delete pBackBufferGraphics;
		pBackBufferGraphics = nullptr;

		delete pSceneGraphics;
		pSceneGraphics = nullptr;

		delete pSceneBitmap;
		pSceneBitmap = nullptr;

		delete pSolidBrush;
		pSolidBrush = nullptr;

		delete pPen;
		pPen = nullptr;

		delete pStandardFontFamily;
		pStandardFontFamily = nullptr;

		delete pStandardFont;
		pStandardFont = nullptr;
	}

	Gdiplus::GdiplusShutdown(gdiplusToken);

	/*MessageBox(
		NULL,
		L"CGDIPlusWindow Constructor OK!",
		L"Information",
		MB_OK
	);*/
}


void CGDIPlusWindow::Prepare_SceneUpdate(const Gdiplus::Color &color)
{
	pSceneGraphics->Clear(color);
}

void CGDIPlusWindow::Prepare_SceneUpdate(void)
{
	pSceneGraphics->Clear(Gdiplus::Color(255, 0, 0, 0));
}

void CGDIPlusWindow::Present_Scene(void)
{
	pBackBufferGraphics->DrawImage(pSceneBitmap, 0, 0);

	// Now copy the image to the screen
	BitBlt(WindowDeviceContext, 0, 0, pSceneBitmap->GetWidth(), pSceneBitmap->GetHeight(), BackBufferDeviceContext, 0, 0, SRCCOPY);
}

void CGDIPlusWindow::Transform_Object(float centerPosX, float centerPosY, float orientation, float scaleX, float scaleY)
{
	pSceneGraphics->TranslateTransform(centerPosX, centerPosY);
	pSceneGraphics->RotateTransform(orientation);
	pSceneGraphics->ScaleTransform(scaleX, scaleY);
}

void CGDIPlusWindow::Reset_ObjectTransformations(void)
{
	pSceneGraphics->ResetTransform();
}

void CGDIPlusWindow::Activate_Antialiasing(void)
{
	pSceneGraphics->SetSmoothingMode(Gdiplus::SmoothingModeHighQuality);
}

void CGDIPlusWindow::Deactivate_Antialiasing(void)
{
	pSceneGraphics->SetSmoothingMode(Gdiplus::SmoothingModeHighSpeed);
}

void CGDIPlusWindow::DrawLine(float startPosX, float startPosY, float endPosX, float endPosY, const Gdiplus::Color &color, float width)
{
	pPen->SetColor(color);
	pPen->SetWidth(width);
	pPen->SetDashStyle(Gdiplus::DashStyleSolid);

	pSceneGraphics->DrawLine(pPen, Gdiplus::PointF(startPosX, startPosY), Gdiplus::PointF(endPosX, endPosY));
}

void CGDIPlusWindow::DrawLineExt(float startPosX, float startPosY, float endPosX, float endPosY, const Gdiplus::Color &color, float width, Gdiplus::DashStyle dashStyle)
{
	pPen->SetColor(color);
	pPen->SetWidth(width);
	pPen->SetDashStyle(dashStyle);

	pSceneGraphics->DrawLine(pPen, Gdiplus::PointF(startPosX, startPosY), Gdiplus::PointF(endPosX, endPosY));
}



void CGDIPlusWindow::DrawString(const wchar_t *pString, const Gdiplus::PointF &PosXY, const Gdiplus::Font *pFont, const Gdiplus::Brush *pBrush)
{
	pSceneGraphics->DrawString(pString, -1, pFont, PosXY, pBrush);
}

void CGDIPlusWindow::DrawString(const wchar_t *pString, const Gdiplus::PointF &PosXY, const Gdiplus::Font *pFont, const Gdiplus::Color &color)
{
	pSolidBrush->SetColor(color);
	pSceneGraphics->DrawString(pString, -1, pFont, PosXY, pSolidBrush);
}

void CGDIPlusWindow::DrawString(const wchar_t *pString, const Gdiplus::PointF &PosXY, const Gdiplus::Color &color)
{
	pSolidBrush->SetColor(color);
	pSceneGraphics->DrawString(pString, -1, pStandardFont, PosXY, pSolidBrush);
}

void CGDIPlusWindow::DrawString(const wchar_t *pString, float posX, float posY, const Gdiplus::Font *pFont, const Gdiplus::Brush *pBrush)
{
	Gdiplus::PointF PosXY(posX, posY);
	pSceneGraphics->DrawString(pString, -1, pFont, PosXY, pBrush);
}

void CGDIPlusWindow::DrawString(const wchar_t *pString, float posX, float posY, const Gdiplus::Font *pFont, const Gdiplus::Color &color)
{
	Gdiplus::PointF PosXY(posX, posY);
	pSolidBrush->SetColor(color);
	pSceneGraphics->DrawString(pString, -1, pFont, PosXY, pSolidBrush);
}

void CGDIPlusWindow::DrawString(const wchar_t *pString, float posX, float posY, const Gdiplus::Color &color)
{
	Gdiplus::PointF PosXY(posX, posY);
	pSolidBrush->SetColor(color);
	pSceneGraphics->DrawString(pString, -1, pStandardFont, PosXY, pSolidBrush);
}

void CGDIPlusWindow::DrawString(const char *pString, const Gdiplus::PointF &PosXY, const Gdiplus::Font *pFont, const Gdiplus::Brush *pBrush)
{
	size_t size = strlen(pString) + 1;

	if (size > 255)
		return;

	wchar_t wtext[255];
	mbstowcs(wtext, pString, size);

	pSceneGraphics->DrawString(wtext, -1, pFont, PosXY, pBrush);
}

void CGDIPlusWindow::DrawString(const char *pString, const Gdiplus::PointF &PosXY, const Gdiplus::Font *pFont, const Gdiplus::Color &color)
{
	size_t size = strlen(pString) + 1;

	if (size > 255)
		return;

	wchar_t wtext[255];
	mbstowcs(wtext, pString, size);

	pSolidBrush->SetColor(color);
	pSceneGraphics->DrawString(wtext, -1, pFont, PosXY, pSolidBrush);
}

void CGDIPlusWindow::DrawString(const char *pString, const Gdiplus::PointF &PosXY, const Gdiplus::Color &color)
{
	size_t size = strlen(pString) + 1;

	if (size > 255)
		return;

	wchar_t wtext[255];
	mbstowcs(wtext, pString, size);

	pSolidBrush->SetColor(color);
	pSceneGraphics->DrawString(wtext, -1, pStandardFont, PosXY, pSolidBrush);
}

void CGDIPlusWindow::DrawString(const char *pString, float posX, float posY, const Gdiplus::Font *pFont, const Gdiplus::Brush *pBrush)
{
	size_t size = strlen(pString) + 1;

	if (size > 255)
		return;

	wchar_t wtext[255];

	mbstowcs(wtext, pString, size);

	Gdiplus::PointF PosXY(posX, posY);
	pSceneGraphics->DrawString(wtext, -1, pFont, PosXY, pBrush);
}

void CGDIPlusWindow::DrawString(const char *pString, float posX, float posY, const Gdiplus::Font *pFont, const Gdiplus::Color &color)
{
	size_t size = strlen(pString) + 1;

	if (size > 255)
		return;

	wchar_t wtext[255];

	mbstowcs(wtext, pString, size);


	Gdiplus::PointF PosXY(posX, posY);

	pSolidBrush->SetColor(color);
	pSceneGraphics->DrawString(wtext, -1, pFont, PosXY, pSolidBrush);
}

void CGDIPlusWindow::DrawString(const char *pString, float posX, float posY, const Gdiplus::Color &color)
{
	size_t size = strlen(pString) + 1;

	if (size > 255)
		return;

	wchar_t wtext[255];

	mbstowcs(wtext, pString, size);


	Gdiplus::PointF PosXY(posX, posY);

	pSolidBrush->SetColor(color);
	pSceneGraphics->DrawString(wtext, -1, pStandardFont, PosXY, pSolidBrush);
}


CImageObject::CImageObject()
{}

CImageObject::~CImageObject()
{
	if (pBitmap != nullptr)
	{
		delete pBitmap;
		pBitmap = nullptr;
	}
}

void CImageObject::Initialize(CGDIPlusWindow* pGDIPlusWindow, const char *pFilename, bool enableCenterTransformations, bool useColorKey)
{
	if (pBitmap != nullptr)
	{
		delete pBitmap;
		pBitmap = nullptr;
	}

	UseColorKey = useColorKey;

	pUsedGDIPlusWindow = pGDIPlusWindow;

	size_t size = strlen(pFilename) + 1;

	if (size > 255)
		return;

	wchar_t wFilename[255];

	mbstowcs(wFilename, pFilename, size);

	pBitmap = new Gdiplus::Bitmap(wFilename, PixelFormat32bppARGB);

	Weight = pBitmap->GetWidth();
	Height = pBitmap->GetHeight();

	
	// black => transparent
	imAtt.SetColorKey(
		Gdiplus::Color(0, 0, 0),
		Gdiplus::Color(1, 1, 1),
		Gdiplus::ColorAdjustTypeBitmap);

	if (enableCenterTransformations == true)
	{
		int32_t NegHalfWeight = -Weight / 2;
		int32_t NegHalfHeight = -Height / 2;

		DrawingRect.X = NegHalfWeight;
		DrawingRect.Y = NegHalfHeight;
		DrawingRect.Width = Weight;
		DrawingRect.Height = Height;
	}
	else
	{
		DrawingRect.X = 0;
		DrawingRect.Y = 0;
		DrawingRect.Width = Weight;
		DrawingRect.Height = Height;
	}
}

void CImageObject::Initialize(CGDIPlusWindow* pGDIPlusWindow, const wchar_t *pFilename, bool enableCenterTransformations, bool useColorKey)
{
	if (pBitmap != nullptr)
	{
		delete pBitmap;
		pBitmap = nullptr;
	}

	UseColorKey = useColorKey;

	pUsedGDIPlusWindow = pGDIPlusWindow;

	pBitmap = new Gdiplus::Bitmap(pFilename, PixelFormat32bppARGB);

	Weight = pBitmap->GetWidth();
	Height = pBitmap->GetHeight();

	
	// black => transparent
	imAtt.SetColorKey(
		Gdiplus::Color(0, 0, 0),
		Gdiplus::Color(1, 1, 1),
		Gdiplus::ColorAdjustTypeBitmap);

	if (enableCenterTransformations == true)
	{
		int32_t NegHalfWeight = -Weight / 2;
		int32_t NegHalfHeight = -Height / 2;

		DrawingRect.X = NegHalfWeight;
		DrawingRect.Y = NegHalfHeight;
		DrawingRect.Width = Weight;
		DrawingRect.Height = Height;
	}
	else
	{
		DrawingRect.X = 0;
		DrawingRect.Y = 0;
		DrawingRect.Width = Weight;
		DrawingRect.Height = Height;
	}
}

void CImageObject::Draw(void)
{
	if (UseColorKey == false)
	{
		pUsedGDIPlusWindow->pSceneGraphics->DrawImage(pBitmap, DrawingRect,  // dest rect
			0, 0, Weight, Height,          // source rect
			Gdiplus::UnitPixel);
	}
	else //if (UseColorKey == true)
	{
		pUsedGDIPlusWindow->pSceneGraphics->DrawImage(
			pBitmap,
			DrawingRect,  // dest rect
			0, 0, Weight, Height,          // source rect
			Gdiplus::UnitPixel,
			&imAtt);
	}
}

CTexturedObject::CTexturedObject()
{}

CTexturedObject::~CTexturedObject()
{
	if(pTextureBrush != nullptr)
	{
		delete pTextureBrush;
		pTextureBrush = nullptr;
	}
}

void CTexturedObject::Initialize(CGDIPlusWindow* pGDIPlusWindow, const char *pFilename, bool useColorKey)
{
	

	if (pTextureBrush != nullptr)
	{
		delete pTextureBrush;
		pTextureBrush = nullptr;
	}


	pUsedGDIPlusWindow = pGDIPlusWindow;

	size_t size = strlen(pFilename) + 1;

	if (size > 255)
		return;

	wchar_t wFilename[255];

	mbstowcs(wFilename, pFilename, size);

	Gdiplus::Bitmap Bitmap(wFilename, PixelFormat32bppARGB);

	Weight = Bitmap.GetWidth();
	Height = Bitmap.GetHeight();

	fHalfWeight = 0.5f * Weight;
	fHalfHeight = 0.5f * Height;

	if(useColorKey == false)
	{
		pTextureBrush = new Gdiplus::TextureBrush(&Bitmap);
		return;
	}

	// black => transparent
	imAtt.SetColorKey(
		Gdiplus::Color(0, 0, 0),
		Gdiplus::Color(1, 1, 1),
		Gdiplus::ColorAdjustTypeBitmap);



	DrawingRect.X = 0;
	DrawingRect.Y = 0;
	DrawingRect.Width = Weight;
	DrawingRect.Height = Height;

	pTextureBrush = new Gdiplus::TextureBrush(&Bitmap, DrawingRect, &imAtt);
}

void CTexturedObject::Initialize(CGDIPlusWindow* pGDIPlusWindow, const wchar_t *pFilename, bool useColorKey)
{
	if (pTextureBrush != nullptr)
	{
		delete pTextureBrush;
		pTextureBrush = nullptr;
	}

	pUsedGDIPlusWindow = pGDIPlusWindow;

	Gdiplus::Bitmap Bitmap(pFilename, PixelFormat32bppARGB);

	Weight = Bitmap.GetWidth();
	Height = Bitmap.GetHeight();

	fHalfWeight = 0.5f * Weight;
	fHalfHeight = 0.5f * Height;

	if (useColorKey == false)
	{
		pTextureBrush = new Gdiplus::TextureBrush(&Bitmap);
		return;
	}

	// black => transparent
	imAtt.SetColorKey(
		Gdiplus::Color(0, 0, 0),
		Gdiplus::Color(1, 1, 1),
		Gdiplus::ColorAdjustTypeBitmap);

	DrawingRect.X = 0;
	DrawingRect.Y = 0;
	DrawingRect.Width = Weight;
	DrawingRect.Height = Height;

	pTextureBrush = new Gdiplus::TextureBrush(&Bitmap, DrawingRect, &imAtt);
}

void CTexturedObject::Draw_Rectangle(float centerPosX, float centerPosY, float orientation, float scaleX, float scaleY)
{
	Gdiplus::Graphics *ptr = pUsedGDIPlusWindow->pSceneGraphics;

	float dx = fHalfWeight*scaleX;
	float dy = fHalfHeight*scaleY;

	centerPosX -= dx;
	centerPosY -= dy;

	float x = dx + centerPosX;
	float y = dy + centerPosY;

	ptr->TranslateTransform(x, y);
	ptr->RotateTransform(orientation);
	ptr->TranslateTransform(-x, -y);


	ptr->TranslateTransform(centerPosX, centerPosY);
	ptr->ScaleTransform(scaleX, scaleY);

	//Gdiplus::SolidBrush solidBrush(Gdiplus::Color::Green);
	ptr->FillRectangle(pTextureBrush, 0, 0, Weight, Height);
	
	pUsedGDIPlusWindow->Reset_ObjectTransformations();
}

void CTexturedObject::Draw_Rectangle(float centerPosX, float centerPosY, float scaleX, float scaleY)
{
	Gdiplus::Graphics *ptr = pUsedGDIPlusWindow->pSceneGraphics;

	float dx = fHalfWeight*scaleX;
	float dy = fHalfHeight*scaleY;

	ptr->TranslateTransform(centerPosX - dx, centerPosY - dy);
	ptr->ScaleTransform(scaleX, scaleY);

	//Gdiplus::SolidBrush solidBrush(Gdiplus::Color::Green);
	ptr->FillRectangle(pTextureBrush, 0, 0, Weight, Height);


	pUsedGDIPlusWindow->Reset_ObjectTransformations();
}

void CTexturedObject::Draw_Rectangle(float centerPosX, float centerPosY)
{
	Gdiplus::Graphics *ptr = pUsedGDIPlusWindow->pSceneGraphics;

	ptr->TranslateTransform(centerPosX - fHalfWeight, centerPosY - fHalfHeight);
	
	//Gdiplus::SolidBrush solidBrush(Gdiplus::Color::Green);
	ptr->FillRectangle(pTextureBrush, 0, 0, Weight, Height);

	pUsedGDIPlusWindow->Reset_ObjectTransformations();
}








/*

int DisplayResourceNAMessageBox()
{
int actionID = MessageBox(
NULL,
(LPCWSTR)L"Resource not available\nDo you want to try again?",
(LPCWSTR)L"Account Details",
MB_ICONWARNING | MB_CANCELTRYCONTINUE | MB_DEFBUTTON2
);



switch (actionID)
{
case IDCANCEL:
// TODO: add code
break;
case IDTRYAGAIN:
// TODO: add code
break;
case IDCONTINUE:
// TODO: add code
break;
}

return actionID;


}

int DisplayConfirmSaveAsMessageBox()
{
int actionID = MessageBox(
NULL,
L"temp.txt already exists.\nDo you want to replace it?",
L"Confirm Save As",
MB_ICONEXCLAMATION | MB_YESNO
);

if (actionID == IDYES)
{
// TODO: add code
}

return actionID;
}


*/



