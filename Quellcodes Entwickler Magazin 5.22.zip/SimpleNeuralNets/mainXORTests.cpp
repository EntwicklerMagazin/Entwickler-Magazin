#include <iostream>
#include "Graph.h"
#include "NeuralNet_V2.h"



using namespace std;


/*
struct CTestStruct
{
	float f;
    int32_t i;
};

void TestFunction1(void *pIn)
{
	CTestStruct *pInputValues = static_cast<CTestStruct*>(pIn);

	pInputValues->f = 7.0f;
	pInputValues->i = 11;
}

void* TestFunction2(void *pIn)
{
	CTestStruct *pInputValues = static_cast<CTestStruct*>(pIn);

	pInputValues->f = 7.0f;
	pInputValues->i = 11;

	return pIn;
}


int main(void)
{
	CTestStruct test;

	//TestFunction1(&test);

	//cout << test.f << endl;
	//cout << test.i << endl;

	CTestStruct *pTest = nullptr;

	pTest = static_cast<CTestStruct*>(TestFunction2(&test));

	cout << pTest->f << endl;
	cout << pTest->i << endl;

	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	CNeuralNetV2 Brain;
	Brain.Init_NeuralNet(7);
	Brain.Set_NumOfOutputValues(1);
	Brain.Set_NumOfInputValues(2);
	

	Brain.Set_OutputNeuron_ActivationFunction(TanHActivationFunction);

	Brain.Use_As_BiasNeuron(3, true);

	CNeuralConnections Connections_TowardsHiddenLayer;

	int32_t NeuronIDs_HiddenLayer[3];
	NeuronIDs_HiddenLayer[0] = 4;
	NeuronIDs_HiddenLayer[1] = 5;
	NeuronIDs_HiddenLayer[2] = 6;
	

	Connections_TowardsHiddenLayer.Init_Or_Set_NeuralConnections(NeuronIDs_HiddenLayer, 3);
	Brain.Init_OutputSynapses(1, 3, &Connections_TowardsHiddenLayer, -2.0f, 2.0f);
	
	//Connections_TowardsHiddenLayer.Init_Or_Set_NeuralConnections(NeuronIDs_HiddenLayer, 3, &RandomNumbers, -2.0f, 2.0f);
	//Brain.Init_OutputSynapses(1, &Connections_TowardsHiddenLayer);
	//Connections_TowardsHiddenLayer.Randomize_SynapticPlasticities(&RandomNumbers, -2.0f, 2.0f);
	//Brain.Init_OutputSynapses(2, &Connections_TowardsHiddenLayer);
	//Connections_TowardsHiddenLayer.Randomize_SynapticPlasticities(&RandomNumbers, -2.0f, 2.0f);
	//Brain.Init_OutputSynapses(3, &Connections_TowardsHiddenLayer);

	
	CNeuralConnections Connections_TowardsOutputLayer;

	int32_t NeuronIDs_OutputLayer[1];
	NeuronIDs_OutputLayer[0] = 0;

	Connections_TowardsOutputLayer.Init_Or_Set_NeuralConnections(NeuronIDs_OutputLayer, 1);
	Brain.Init_OutputSynapses(4, 6, &Connections_TowardsOutputLayer, -2.0f, 2.0f);

	//Connections_TowardsOutputLayer.Init_Or_Set_NeuralConnections(NeuronIDs_OutputLayer, 1, &RandomNumbers, -2.0f, 2.0f);
	//Brain.Init_OutputSynapses(4, &Connections_TowardsOutputLayer);
	//Connections_TowardsOutputLayer.Randomize_SynapticPlasticities(&RandomNumbers, -2.0f, 2.0f);
	//Brain.Init_OutputSynapses(5, &Connections_TowardsOutputLayer);
	//Connections_TowardsOutputLayer.Randomize_SynapticPlasticities(&RandomNumbers, -2.0f, 2.0f);
	//Brain.Init_OutputSynapses(6, &Connections_TowardsOutputLayer);
	
	Brain.Set_ActivationFunction(4, 6, TanHActivationFunction);
	
	CActivationSequence ActivationSequence;

	int32_t NeuronIDsBiasAndHiddenNeurons[4];

	// bias neuron
	NeuronIDsBiasAndHiddenNeurons[0] = 3;

	// hidden neurons
	NeuronIDsBiasAndHiddenNeurons[1] = 4;
	NeuronIDsBiasAndHiddenNeurons[2] = 5;
	NeuronIDsBiasAndHiddenNeurons[3] = 6;

	ActivationSequence.Init_Or_Set_ActivationSequence(NeuronIDsBiasAndHiddenNeurons, 4);

	Brain.Set_ActivationSequence(&ActivationSequence);

	// for extreme learning:
	CActivationSequence ActivationSequence_LastHiddenLayer;

	int32_t NeuronIDsHiddenNeurons[3];

	// hidden neurons
	NeuronIDsHiddenNeurons[0] = 4;
	NeuronIDsHiddenNeurons[1] = 5;
	NeuronIDsHiddenNeurons[2] = 6;

	ActivationSequence_LastHiddenLayer.Init_Or_Set_ActivationSequence(NeuronIDsHiddenNeurons, 3);

	Brain.Set_ActivationSequence_LastHiddenLayer(&ActivationSequence_LastHiddenLayer);
	
	

	float InputArray1[2] = { 0.0f, 0.0f };
	float Input1a = 0.0f;
	float Input1b = 0.0f;

	float InputArray2[2] = { 1.0f, 0.0f };
	float Input2a = 1.0f;
	float Input2b = 0.0f;

	float InputArray3[2] = { 0.0f, 1.0f };
	float Input3a = 0.0f;
	float Input3b = 1.0f;

	float InputArray4[2] = { 1.0f, 1.0f };
	float Input4a = 1.0f;
	float Input4b = 1.0f;

	float output;
	float desiredOutput;

	uint32_t maxCount = 1000000;
	uint32_t epoch = 0;
	float error;

	// start training:

	for (uint32_t i = 0; i < maxCount; i++)
	{
		epoch++;
		error = 0.0f;

		Brain.Calculate_Output(&output, InputArray1);
		desiredOutput = 0.0f;
		error += Brain.Learning(&desiredOutput);
		
		Brain.Calculate_Output(&output, InputArray2);
		desiredOutput = 1.0f;
		error += Brain.Learning(&desiredOutput);
		
		Brain.Calculate_Output(&output, InputArray3);
		desiredOutput = 1.0f;
		error += Brain.Learning(&desiredOutput);
			
		Brain.Calculate_Output(&output, InputArray4);
		desiredOutput = 0.0f;
		error += Brain.Learning(&desiredOutput);
			
		if (error < 0.001f)
			break;
	}

	// training completed

	// training statistics:

	cout << "epoch: " << epoch << endl;
	cout << "error: " << error << endl << endl;

	// neural network tests:

	Brain.Calculate_Output(&output, InputArray1);


	cout << "input : " << Input1a << " --- " << Input1b;
	cout << "  output: " << output << " --- desired output: " << 0.0f << endl;
	// => output: 0

	Brain.Calculate_Output(&output, InputArray2);


	cout << "input : " << Input2a << " --- " << Input2b;
	cout << "  output: " << output << " --- desired output: " << 1.0f << endl;
	// => output: 1

	Brain.Calculate_Output(&output, InputArray3);

	cout << "input : " << Input3a << " --- " << Input3b;
	cout << "  output: " << output << " --- desired output: " << 1.0f << endl;
	// => output: 1

	Brain.Calculate_Output(&output, InputArray4);

	cout << "input : " << Input4a << " --- " << Input4b;
	cout << "  output: " << output << " --- desired output: " << 0.0f << endl;
	// => output: 0


	getchar();
	return 0;

}
*/

/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	CNeuralNetV2 Brain;
	Brain.Init_NeuralNet(8);
	Brain.Set_NumOfOutputValues(1);
	Brain.Set_NumOfInputValues(2);


	Brain.Set_OutputNeuron_ActivationFunction(TanHActivationFunction);

	Brain.Use_As_BiasNeuron(3, true);

	CNeuralConnections Connections_TowardsHiddenLayer;

	int32_t NeuronIDs_HiddenLayer[4];
	NeuronIDs_HiddenLayer[0] = 4;
	NeuronIDs_HiddenLayer[1] = 5;
	NeuronIDs_HiddenLayer[2] = 6;
	NeuronIDs_HiddenLayer[3] = 7;


	Connections_TowardsHiddenLayer.Init_Or_Set_NeuralConnections(NeuronIDs_HiddenLayer, 4);
	Brain.Init_OutputSynapses(1, 3, &Connections_TowardsHiddenLayer, -2.0f, 2.0f);

	
	CNeuralConnections Connections_TowardsOutputLayer;

	int32_t NeuronIDs_OutputLayer[1];
	NeuronIDs_OutputLayer[0] = 0;

	Connections_TowardsOutputLayer.Init_Or_Set_NeuralConnections(NeuronIDs_OutputLayer, 1);
	Brain.Init_OutputSynapses(4, 7, &Connections_TowardsOutputLayer, -2.0f, 2.0f);

	
	Brain.Set_ActivationFunction(4, 7, TanHActivationFunction);

	CActivationSequence ActivationSequence;

	int32_t NeuronIDsBiasAndHiddenNeurons[5];

	// bias neuron
	NeuronIDsBiasAndHiddenNeurons[0] = 3;

	// hidden neurons
	NeuronIDsBiasAndHiddenNeurons[1] = 4;
	NeuronIDsBiasAndHiddenNeurons[2] = 5;
	NeuronIDsBiasAndHiddenNeurons[3] = 6;
	NeuronIDsBiasAndHiddenNeurons[4] = 7;

	ActivationSequence.Init_Or_Set_ActivationSequence(NeuronIDsBiasAndHiddenNeurons, 5);

	Brain.Set_ActivationSequence(&ActivationSequence);

	// for extreme learning:
	CActivationSequence ActivationSequence_LastHiddenLayer;

	int32_t NeuronIDsHiddenNeurons[4];

	// hidden neurons
	NeuronIDsHiddenNeurons[0] = 4;
	NeuronIDsHiddenNeurons[1] = 5;
	NeuronIDsHiddenNeurons[2] = 6;
	NeuronIDsHiddenNeurons[3] = 7;

	ActivationSequence_LastHiddenLayer.Init_Or_Set_ActivationSequence(NeuronIDsHiddenNeurons, 4);

	Brain.Set_ActivationSequence_LastHiddenLayer(&ActivationSequence_LastHiddenLayer);



	float InputArray1[2] = { 0.0f, 0.0f };
	float Input1a = 0.0f;
	float Input1b = 0.0f;

	float InputArray2[2] = { 1.0f, 0.0f };
	float Input2a = 1.0f;
	float Input2b = 0.0f;

	float InputArray3[2] = { 0.0f, 1.0f };
	float Input3a = 0.0f;
	float Input3b = 1.0f;

	float InputArray4[2] = { 1.0f, 1.0f };
	float Input4a = 1.0f;
	float Input4b = 1.0f;

	float output;
	float desiredOutput;

	uint32_t maxCount = 1000000;
	uint32_t epoch = 0;
	float error;

	// start training:

	for (uint32_t i = 0; i < maxCount; i++)
	{
		epoch++;
		error = 0.0f;

		Brain.Calculate_Output(&output, InputArray1);
		desiredOutput = 0.0f;
		//error += Brain.Learning(&desiredOutput);
		error += Brain.ExtremeLearning(&desiredOutput);
		//error += Brain.ExtremeLearning(desiredOutput, 0);

		Brain.Calculate_Output(&output, InputArray2);
		desiredOutput = 1.0f;
		//error += Brain.Learning(&desiredOutput);
		error += Brain.ExtremeLearning(&desiredOutput);
		//error += Brain.ExtremeLearning(desiredOutput, 0);

		Brain.Calculate_Output(&output, InputArray3);
		desiredOutput = 1.0f;
		//error += Brain.Learning(&desiredOutput);
		error += Brain.ExtremeLearning(&desiredOutput);
		//error += Brain.ExtremeLearning(desiredOutput, 0);

		Brain.Calculate_Output(&output, InputArray4);
		desiredOutput = 0.0f;
		//error += Brain.Learning(&desiredOutput);
		error += Brain.ExtremeLearning(&desiredOutput);
		//error += Brain.ExtremeLearning(desiredOutput, 0);

		if (error < 0.001f)
			break;

		// etwas Mutation (hilfreich, um einem eventuellen lokalen Fehlerminimum zu entkommen)
		// In unserem Fall wird der Lernvorgang sogar ein wenig beschleunigt!
		Brain.Modify_OutputSynapsePlasticities(4, 7, -0.001f, 0.001f);
	}

	

	// training completed

	// training statistics:

	cout << "epoch: " << epoch << endl;
	cout << "error: " << error << endl << endl;

	// neural network tests:

	Brain.Calculate_Output(&output, InputArray1);


	cout << "input : " << Input1a << " --- " << Input1b;
	cout << "  output: " << output << " --- desired output: " << 0.0f << endl;
	// => output: 0

	Brain.Calculate_Output(&output, InputArray2);


	cout << "input : " << Input2a << " --- " << Input2b;
	cout << "  output: " << output << " --- desired output: " << 1.0f << endl;
	// => output: 1

	Brain.Calculate_Output(&output, InputArray3);

	cout << "input : " << Input3a << " --- " << Input3b;
	cout << "  output: " << output << " --- desired output: " << 1.0f << endl;
	// => output: 1

	Brain.Calculate_Output(&output, InputArray4);

	cout << "input : " << Input4a << " --- " << Input4b;
	cout << "  output: " << output << " --- desired output: " << 0.0f << endl;
	// => output: 0


	getchar();
	return 0;

}
*/

inline void SimpleNeuralNetV2RecombinationFunction(CNeuralNetV2 *pOffspring, const CNeuralNetV2 *pParent1, const CNeuralNetV2 *pParent2, void *pParam)
{
	CEvolutionParameter *pParameter = static_cast<CEvolutionParameter*>(pParam);
	pOffspring->Combine_OutputSynapsePlasticities_RandomWeighted(pParameter->seed++, pParent1, pParent2);
}

inline void SimpleNeuralNetV2ReinitializationFunction(CNeuralNetV2 *pInOutNeuralNet, void *pParam)
{
	CEvolutionParameter *pParameter = static_cast<CEvolutionParameter*>(pParam);
	pInOutNeuralNet->Randomize_OutputSynapsePlasticities(pParameter->seed++, pParameter->minValue1, pParameter->maxValue1, pParameter->mutationRate);
}

inline void SimpleNeuralNetV2MutationFunction(CNeuralNetV2 *pInOutNeuralNet, void *pParam)
{
	CEvolutionParameter *pParameter = static_cast<CEvolutionParameter*>(pParam);
	pInOutNeuralNet->Modify_OutputSynapsePlasticities(pParameter->seed++, pParameter->minVariance1, pParameter->maxVariance1, pParameter->mutationRate);
}

/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	CNeuralNetV2 Brain;
	Brain.Init_NeuralNet(7);
	Brain.Set_NumOfOutputValues(1);
	Brain.Set_NumOfInputValues(2);


	Brain.Set_OutputNeuron_ActivationFunction(TanHActivationFunction);

	Brain.Use_As_BiasNeuron(3, true);

	CNeuralConnections Connections_TowardsHiddenLayer;

	int32_t NeuronIDs_HiddenLayer[3];
	NeuronIDs_HiddenLayer[0] = 4;
	NeuronIDs_HiddenLayer[1] = 5;
	NeuronIDs_HiddenLayer[2] = 6;


	Connections_TowardsHiddenLayer.Init_Or_Set_NeuralConnections(NeuronIDs_HiddenLayer, 3);
	Brain.Init_OutputSynapses(1, 3, &Connections_TowardsHiddenLayer, -2.0f, 2.0f);

	//Connections_TowardsHiddenLayer.Init_Or_Set_NeuralConnections(NeuronIDs_HiddenLayer, 3, &RandomNumbers, -2.0f, 2.0f);
	//Brain.Init_OutputSynapses(1, &Connections_TowardsHiddenLayer);
	//Connections_TowardsHiddenLayer.Randomize_SynapticPlasticities(&RandomNumbers, -2.0f, 2.0f);
	//Brain.Init_OutputSynapses(2, &Connections_TowardsHiddenLayer);
	//Connections_TowardsHiddenLayer.Randomize_SynapticPlasticities(&RandomNumbers, -2.0f, 2.0f);
	//Brain.Init_OutputSynapses(3, &Connections_TowardsHiddenLayer);


	CNeuralConnections Connections_TowardsOutputLayer;

	int32_t NeuronIDs_OutputLayer[1];
	NeuronIDs_OutputLayer[0] = 0;

	Connections_TowardsOutputLayer.Init_Or_Set_NeuralConnections(NeuronIDs_OutputLayer, 1);
	Brain.Init_OutputSynapses(4, 6, &Connections_TowardsOutputLayer, -2.0f, 2.0f);

	//Connections_TowardsOutputLayer.Init_Or_Set_NeuralConnections(NeuronIDs_OutputLayer, 1, &RandomNumbers, -2.0f, 2.0f);
	//Brain.Init_OutputSynapses(4, &Connections_TowardsOutputLayer);
	//Connections_TowardsOutputLayer.Randomize_SynapticPlasticities(&RandomNumbers, -2.0f, 2.0f);
	//Brain.Init_OutputSynapses(5, &Connections_TowardsOutputLayer);
	//Connections_TowardsOutputLayer.Randomize_SynapticPlasticities(&RandomNumbers, -2.0f, 2.0f);
	//Brain.Init_OutputSynapses(6, &Connections_TowardsOutputLayer);

	Brain.Set_ActivationFunction(4, 6, TanHActivationFunction);

	CActivationSequence ActivationSequence;

	int32_t NeuronIDsBiasAndHiddenNeurons[4];

	// bias neuron
	NeuronIDsBiasAndHiddenNeurons[0] = 3;

	// hidden neurons
	NeuronIDsBiasAndHiddenNeurons[1] = 4;
	NeuronIDsBiasAndHiddenNeurons[2] = 5;
	NeuronIDsBiasAndHiddenNeurons[3] = 6;

	ActivationSequence.Init_Or_Set_ActivationSequence(NeuronIDsBiasAndHiddenNeurons, 4);

	Brain.Set_ActivationSequence(&ActivationSequence);

	// for extreme learning:
	CActivationSequence ActivationSequence_LastHiddenLayer;

	int32_t NeuronIDsHiddenNeurons[3];

	// hidden neurons
	NeuronIDsHiddenNeurons[0] = 4;
	NeuronIDsHiddenNeurons[1] = 5;
	NeuronIDsHiddenNeurons[2] = 6;

	ActivationSequence_LastHiddenLayer.Init_Or_Set_ActivationSequence(NeuronIDsHiddenNeurons, 3);

	Brain.Set_ActivationSequence_LastHiddenLayer(&ActivationSequence_LastHiddenLayer);

	int32_t NumTrainingGenerationsMax = 10000;
	static constexpr uint32_t PopulationSize = 100;

	static CNeuralNetV2 BrainArray[PopulationSize];
	static float FitnessScoreArray[PopulationSize];

	CNeuralNetPopulationV2 NeuralNetPopulation;
	NeuralNetPopulation.Initialize(PopulationSize);

	for (int32_t i = 0; i < PopulationSize; i++)
	{
		BrainArray[i].Clone(&Brain);
		NeuralNetPopulation.Set_NeuralNet(&BrainArray[i], i);
	}

	uint64_t seed = 1;
	NeuralNetPopulation.Randomize_OutputSynapsePlasticities(seed, -2.0f, 2.0f);

	float InputArray1[2] = { 0.0f, 0.0f };
	float Input1a = 0.0f;
	float Input1b = 0.0f;

	float InputArray2[2] = { 1.0f, 0.0f };
	float Input2a = 1.0f;
	float Input2b = 0.0f;

	float InputArray3[2] = { 0.0f, 1.0f };
	float Input3a = 0.0f;
	float Input3b = 1.0f;

	float InputArray4[2] = { 1.0f, 1.0f };
	float Input4a = 1.0f;
	float Input4b = 1.0f;

	float output;
	float desiredOutput;
	float errorSum;
	float error;

	CEvolutionParameter EvolutionParameter;
	//EvolutionParameter.seed = 1;

	for (int32_t j = 0; j < NumTrainingGenerationsMax; j++)
	{
		NeuralNetPopulation.Reset_MinErrorSum_ActualGeneration();

		for (int32_t i = 0; i < PopulationSize; i++)
		{
			//NeuralNetPopulation.Learning(i);
			NeuralNetPopulation.Learning(i, 0.2f, 0.0f, 1.0f, 0.5f);

			FitnessScoreArray[i] = 0.0f;
			errorSum = 0.0f;
			
			BrainArray[i].Calculate_Output(&output, InputArray1);
			desiredOutput = 0.0f;
			error = BrainArray[i].Calculate_VarianceSq(&desiredOutput);
			errorSum += error;			
			
			BrainArray[i].Calculate_Output(&output, InputArray2);
			desiredOutput = 1.0f;
			error = BrainArray[i].Calculate_VarianceSq(&desiredOutput);
			errorSum += error;
					
			BrainArray[i].Calculate_Output(&output, InputArray3);
			desiredOutput = 1.0f;
			error = BrainArray[i].Calculate_VarianceSq(&desiredOutput);
			errorSum += error;			
			
			BrainArray[i].Calculate_Output(&output, InputArray4);
			desiredOutput = 0.0f;
			error = BrainArray[i].Calculate_VarianceSq(&desiredOutput);
			errorSum += error;
						
			FitnessScoreArray[i] += 1.0f / (errorSum + 0.01f);
		
			NeuralNetPopulation.Update_MinErrorSum_ActualGeneration(errorSum);
		}

		NeuralNetPopulation.Update_Population(FitnessScoreArray);

		if (NeuralNetPopulation.MinErrorSum_ActualGeneration < 0.001f)
		{
			cout << "actual generation: " << j << endl;
			cout << "training completed" << endl << endl;
			break;
		}

		EvolutionParameter.minValue1 = -10.0f;
		EvolutionParameter.maxValue1 = 10.0f;
		EvolutionParameter.minVariance1 = -0.1f;
		EvolutionParameter.maxVariance1 = 0.1f;
		EvolutionParameter.mutationRate = 0.5f;

		NeuralNetPopulation.Update_BaseEvolution(SimpleNeuralNetV2MutationFunction, &EvolutionParameter);
		NeuralNetPopulation.Update_Evolution_BestBrainOnly(SimpleNeuralNetV2MutationFunction, &EvolutionParameter);
		NeuralNetPopulation.Update_Evolution_SecondBestBrainOnly(SimpleNeuralNetV2MutationFunction, &EvolutionParameter);
		//NeuralNetPopulation.Update_Evolution_Combine_BestTwoBrains(SimpleNeuralNetV2RecombinationFunction, &EvolutionParameter);
		//NeuralNetPopulation.Update_Evolution_Combine_TwoBrains(SimpleNeuralNetV2RecombinationFunction, &EvolutionParameter);
	}

	
	CNeuralNetV2 BestBrain;
	NeuralNetPopulation.Get_Best_Evolved_NeuralNet(&BestBrain);

	// neural network tests:

	BestBrain.Calculate_Output(&output, InputArray1);


	cout << "input : " << Input1a << " --- " << Input1b;
	cout << "  output: " << output << " --- desired output: " << 0.0f << endl;
	// => output: 0

	BestBrain.Calculate_Output(&output, InputArray2);


	cout << "input : " << Input2a << " --- " << Input2b;
	cout << "  output: " << output << " --- desired output: " << 1.0f << endl;
	// => output: 1

	BestBrain.Calculate_Output(&output, InputArray3);

	cout << "input : " << Input3a << " --- " << Input3b;
	cout << "  output: " << output << " --- desired output: " << 1.0f << endl;
	// => output: 1

	BestBrain.Calculate_Output(&output, InputArray4);

	cout << "input : " << Input4a << " --- " << Input4b;
	cout << "  output: " << output << " --- desired output: " << 0.0f << endl;
	// => output: 0


	getchar();
	return 0;

}
*/

inline void SimpleRBFNeuralNetV2RecombinationFunction(CNeuralNetV2 *pOffspring, const CNeuralNetV2 *pParent1, const CNeuralNetV2 *pParent2, void *pParam)
{
	CEvolutionParameter *pParameter = static_cast<CEvolutionParameter*>(pParam);

	pOffspring->Combine_Dendrite_Data_RandomWeighted(pParameter->seed++, pParent1, pParent2);
	pOffspring->Round_Dendrite_CentroidValues(pParameter->precision_RBF_CentroidValues);
}

inline void SimpleRBFNeuralNetV2ReinitializationFunctionFunction(CNeuralNetV2 *pInOutNeuralNet, void *pParam)
{
	CEvolutionParameter *pParameter = static_cast<CEvolutionParameter*>(pParam);

	pInOutNeuralNet->Randomize_Dendrite_Values(pParameter->seed++, pParameter->minValue1, pParameter->maxValue1, 0.0f, 0.0f, pParameter->mutationRate);
	pInOutNeuralNet->Round_Dendrite_CentroidValues(pParameter->precision_RBF_CentroidValues);
}

inline void SimpleRBFNeuralNetV2MutationFunction(CNeuralNetV2 *pInOutNeuralNet, void *pParam)
{
	CEvolutionParameter *pParameter = static_cast<CEvolutionParameter*>(pParam);

	pInOutNeuralNet->Modify_Dendrite_Values(pParameter->seed++, pParameter->minVariance1, pParameter->maxVariance1, 0.0f, 0.0f, pParameter->mutationRate);
	pInOutNeuralNet->Round_Dendrite_CentroidValues(pParameter->precision_RBF_CentroidValues);
}

inline void RBFActivationFunction(CNeuronV2 *pNeuron)
{
	pNeuron->Dendrite_InputCounter = 0;
	pNeuron->NeuronOutput = exp(-pNeuron->NeuronInput);
	pNeuron->NeuronInput = 0.0f;
}

/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	CNeuralNetV2 Brain;
	Brain.Init_NeuralNet(5);
	Brain.Set_NumOfOutputValues(1);
	Brain.Set_NumOfInputValues(2);
	
	
	Brain.Set_OutputNeuron_ActivationFunction(LinearActivationFunction);

	CNeuralConnections Connections_TowardsHiddenLayer;

	int32_t NeuronIDs_HiddenLayer[2];
	NeuronIDs_HiddenLayer[0] = 3;
	NeuronIDs_HiddenLayer[1] = 4;
	

	Connections_TowardsHiddenLayer.Init_Or_Set_NeuralConnections(NeuronIDs_HiddenLayer, 2);
	Brain.Init_OutputSynapses(1, 2, &Connections_TowardsHiddenLayer, 1.0f, 1.0f);

	Brain.Init_DendriteNeuronIDArray(2);
	Brain.Set_DendriteNeuronIDs_And_Init_Dendrite_Arrays(NeuronIDs_HiddenLayer, 2);

	Brain.Randomize_Dendrite_Values(0.0f, 1.1f, 10.0f, 10.0f);

	Brain.Round_Dendrite_CentroidValues(0.5f);

	CNeuralConnections Connections_TowardsOutputLayer;

	int32_t NeuronIDs_OutputLayer[1];
	NeuronIDs_OutputLayer[0] = 0;

	Connections_TowardsOutputLayer.Init_Or_Set_NeuralConnections(NeuronIDs_OutputLayer, 1);
	Brain.Init_OutputSynapses(3, 4, &Connections_TowardsOutputLayer, 1.0f, 1.0f);

	
	Brain.Set_ActivationFunction(3, 4, RBFActivationFunction);

	CActivationSequence ActivationSequence;

	int32_t NeuronIDsHiddenNeurons[2];

	// hidden neurons
	NeuronIDsHiddenNeurons[0] = 3;
	NeuronIDsHiddenNeurons[1] = 4;
	

	ActivationSequence.Init_Or_Set_ActivationSequence(NeuronIDsHiddenNeurons, 2);

	Brain.Set_ActivationSequence(&ActivationSequence);

	// Input-Neuronen:
	Brain.Set_SynapticFunction(1, 2, RBF_SynapticFunction);

	int32_t NumTrainingGenerationsMax = 100000;
	static constexpr uint32_t PopulationSize = 100;

	static CNeuralNetV2 BrainArray[PopulationSize];
	static float FitnessScoreArray[PopulationSize];

	CNeuralNetPopulationV2 NeuralNetPopulation;
	NeuralNetPopulation.Initialize(PopulationSize);

	for (int32_t i = 0; i < PopulationSize; i++)
	{
		BrainArray[i].Clone(&Brain);
		BrainArray[i].Change_Seed(i);
		NeuralNetPopulation.Set_NeuralNet(&BrainArray[i], i);
	
		BrainArray[i].Randomize_Dendrite_Values(0.0f, 1.1f, 10.0f, 10.0f);
		BrainArray[i].Randomize_Dendrite_Values(0.0f, 1.1f, 10.0f, 10.0f);

		
		Brain.Round_Dendrite_CentroidValues(0.5f);
	}

	
	float InputArray1[2] = { 0.0f, 0.0f };
	float Input1a = 0.0f;
	float Input1b = 0.0f;

	float InputArray2[2] = { 1.0f, 0.0f };
	float Input2a = 1.0f;
	float Input2b = 0.0f;

	float InputArray3[2] = { 0.0f, 1.0f };
	float Input3a = 0.0f;
	float Input3b = 1.0f;

	float InputArray4[2] = { 1.0f, 1.0f };
	float Input4a = 1.0f;
	float Input4b = 1.0f;

	float output;
	float desiredOutput;
	float errorSum;
	float errorMax;
	float error;

	CEvolutionParameter EvolutionParameter;
	//EvolutionParameter.seed = 1;

	for (int32_t j = 0; j < NumTrainingGenerationsMax; j++)
	{
		NeuralNetPopulation.Reset_MinErrorSum_ActualGeneration();

		for (int32_t i = 0; i < PopulationSize; i++)
		{
			errorMax = 0.0f;

			BrainArray[i].Calculate_Output(&output, InputArray1);
			desiredOutput = 0.0f;
			error = BrainArray[i].Calculate_VarianceSq(&desiredOutput);

			//errorMax += error;

			if (error > errorMax)
				errorMax = error;

			BrainArray[i].Calculate_Output(&output, InputArray2);
			desiredOutput = 1.0f;
			error = BrainArray[i].Calculate_VarianceSq(&desiredOutput);
			
			//errorMax += error;

			if (error > errorMax)
				errorMax = error;

			BrainArray[i].Calculate_Output(&output, InputArray3);
			desiredOutput = 1.0f;
			error = BrainArray[i].Calculate_VarianceSq(&desiredOutput);

			//errorMax += error;

			if (error > errorMax)
				errorMax = error;

			BrainArray[i].Calculate_Output(&output, InputArray4);
			desiredOutput = 0.0f;
			error = BrainArray[i].Calculate_VarianceSq(&desiredOutput);

			//errorMax += error;

			if (error > errorMax)
				errorMax = error;

			FitnessScoreArray[i] = 1.0f / (errorMax + 0.01f);

			//NeuralNetPopulation.pFitnessScoreArray[i] = 1.0f / (errorMax + 0.01f);

			NeuralNetPopulation.Update_MinErrorSum_ActualGeneration(errorMax);
		}

		NeuralNetPopulation.Update_Population(FitnessScoreArray);

		//NeuralNetPopulation.Update_Population(nullptr);

		if (NeuralNetPopulation.MinErrorSum_ActualGeneration < 0.001f)
		{
			cout << "actual generation: " << j << endl;
			cout << "training completed" << endl << endl;
			break;
		}

		
		EvolutionParameter.minValue1 = 0.0f;
		EvolutionParameter.maxValue1 = 1.1f;
		EvolutionParameter.minVariance1 = -0.6f;
		EvolutionParameter.maxVariance1 = 0.6f;
		EvolutionParameter.mutationRate = 0.75f;
		EvolutionParameter.precision_RBF_CentroidValues = 0.05f;

		NeuralNetPopulation.Update_BaseEvolution(SimpleRBFNeuralNetV2MutationFunction, &EvolutionParameter);
		NeuralNetPopulation.Update_Evolution_BestBrainOnly(SimpleRBFNeuralNetV2MutationFunction, &EvolutionParameter);
		NeuralNetPopulation.Update_Evolution_SecondBestBrainOnly(SimpleRBFNeuralNetV2MutationFunction, &EvolutionParameter);
		NeuralNetPopulation.Update_Evolution_Combine_BestTwoBrains(SimpleRBFNeuralNetV2RecombinationFunction, &EvolutionParameter);
		NeuralNetPopulation.Update_Evolution_Combine_TwoBrains(SimpleRBFNeuralNetV2RecombinationFunction, &EvolutionParameter);
		NeuralNetPopulation.Update_Evolution_Combine_TwoBrains(SimpleRBFNeuralNetV2RecombinationFunction, &EvolutionParameter);
	}


	CNeuralNetV2 BestBrain;
	NeuralNetPopulation.Get_Best_Evolved_NeuralNet(&BestBrain);

	// neural network tests:

	BestBrain.Calculate_Output(&output, InputArray1);


	cout << "input : " << Input1a << " --- " << Input1b;
	cout << "  output: " << output << " --- desired output: " << 0.0f << endl;
	// => output: 0

	BestBrain.Calculate_Output(&output, InputArray2);


	cout << "input : " << Input2a << " --- " << Input2b;
	cout << "  output: " << output << " --- desired output: " << 1.0f << endl;
	// => output: 1

	BestBrain.Calculate_Output(&output, InputArray3);

	cout << "input : " << Input3a << " --- " << Input3b;
	cout << "  output: " << output << " --- desired output: " << 1.0f << endl;
	// => output: 1

	BestBrain.Calculate_Output(&output, InputArray4);

	cout << "input : " << Input4a << " --- " << Input4b;
	cout << "  output: " << output << " --- desired output: " << 0.0f << endl;
	// => output: 0


	getchar();
	return 0;

}
*/
