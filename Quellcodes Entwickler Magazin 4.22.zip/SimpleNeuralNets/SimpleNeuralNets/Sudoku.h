// Schutz vor Mehrfachdeklarationen :

#ifndef _Sudoku_H_
#define _Sudoku_H_

#include <iostream>
#include "RandomNumbers.h"

static constexpr int32_t SudokuSizePerDir = 9;
static constexpr int32_t SudokuSizeSq = SudokuSizePerDir *  SudokuSizePerDir;

void Output_Sudoku(int32_t *pInData);

int32_t Count_EmptySudokuCelles(int32_t *pInData);

bool Check_If_SudokuNumber_Could_Be_Correct(int32_t *pInOutData, int32_t row, int32_t column, int32_t number);

bool RecursiveSudokuSolver(int32_t *pInOutData, int32_t row, int32_t column);

bool Complete_SudokuRows_If_Possible(int32_t *pInOutData);
bool Complete_SudokuColumns_If_Possible(int32_t *pInOutData);
bool Complete_Sudoku3x3Arrays_If_Possible(int32_t *pInOutData);

bool Add_Value_If_Possible(int32_t *pInOutData);
bool Add_Value_If_Possible_Ext(int32_t *pInOutData);

int32_t Count_SudokuErrors(int32_t *pInData);

void SudokuTransposition(int32_t *pOutData, int32_t *pInData);
void SudokuPermutation(int32_t *pOutData, int32_t *pInData, int32_t number1, int32_t number2);
void HorizontalSudokuReflection(int32_t *pOutData, int32_t *pInData);
void VerticalSudokuReflection(int32_t *pOutData, int32_t *pInData);

void Swap_TwoSudokuRows(int32_t *pOutData, int32_t *pInData, int32_t blockRow1, int32_t blockRow2, int32_t blockID);
void Swap_TwoSudokuColumns(int32_t *pOutData, int32_t *pInData, int32_t blockColumn1, int32_t blockColumn2, int32_t blockID);

void Swap_TwoSudoku9x3Blocks(int32_t *pOutData, int32_t *pInData, int32_t block1ID, int32_t block2ID);
void Swap_TwoSudoku3x9Blocks(int32_t *pOutData, int32_t *pInData, int32_t block1ID, int32_t block2ID);



class CSudokuUpdateNode
{
public:

	int32_t GridID = 0;
	int32_t Number = 0;

	void Reset(void);
	void Reset_GridID(void);
	void Reset_Number(void);

	int32_t Try_To_Find_Correct_Number(int32_t *pInData);
};

class CSudokuUpdateNodeArray
{
public:

	int32_t NumOfNodes = 0;
	CSudokuUpdateNode *pNodeArray = nullptr;

	int32_t actualSearchDepth = 0;

	CSudokuUpdateNodeArray();
	~CSudokuUpdateNodeArray();

	// Kopierkonstruktor l�schen:
	CSudokuUpdateNodeArray(const CSudokuUpdateNodeArray &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CSudokuUpdateNodeArray & operator=(const CSudokuUpdateNodeArray &originalObject) = delete;

	void Initialize(int32_t *pInData);

	void Reset_NodeData(void);
	void Reset_NodeData_GridID_Only(void);
	void Reset_NodeData_Number_Only(void);

	int32_t Update_Node(int32_t *pInOutData);
};

class CSudokuUpdateNodeExt
{
public:

	int32_t GridID = 0;
	
	bool NumberSectionArray[10] = { false, false, false, false, false, false, false, false, false, false };

	void Reset(void);
	void Reset_GridID(void);
	void Reset_NumberSectionArray(void);

	int32_t Get_RandomUnusedNumber(CRandomNumbersNN *pRandomNumbers);

	int32_t Try_To_Find_Correct_Number(int32_t *pInData, CRandomNumbersNN *pRandomNumbers);
};

class CSudokuUpdateNodeArrayExt
{
public:

	int32_t NumOfNodes = 0;
	CSudokuUpdateNodeExt *pNodeArray = nullptr;

	int32_t ActualSearchDepth = 0;

	CSudokuUpdateNodeArrayExt();
	~CSudokuUpdateNodeArrayExt();

	// Kopierkonstruktor l�schen:
	CSudokuUpdateNodeArrayExt(const CSudokuUpdateNodeArrayExt &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CSudokuUpdateNodeArrayExt & operator=(const CSudokuUpdateNodeArrayExt &originalObject) = delete;

	void Initialize(int32_t *pInData);

	void Reset_NodeData(void);
	void Reset_NodeData_GridID_Only(void);
	void Reset_NodeData_NumberSectionArray_Only(void);

	int32_t Update_Node(int32_t *pInOutData, CRandomNumbersNN *pRandomNumbers);
};



#endif