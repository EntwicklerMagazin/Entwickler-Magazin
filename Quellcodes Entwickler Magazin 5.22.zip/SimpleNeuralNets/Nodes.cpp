#include "Nodes.h"

using namespace std;

CNode::CNode() {}
CNode::~CNode() {}

bool CNode::Check_For_RootNode(void)
{
	if (NodeID == PrevNodeID)
	{
		return true;
	}

	return false;
}

bool CNode::Check_For_RootNode_Get_PrevNodeID(int32_t *pOutPrevNodeID)
{
	*pOutPrevNodeID = PrevNodeID;

	if (NodeID == PrevNodeID)
	{
		return true;
	}

	return false;
}


CBackTrackingHelperClass::CBackTrackingHelperClass()
{}

CBackTrackingHelperClass::~CBackTrackingHelperClass()
{
	delete[] pNodeArray;
	pNodeArray = nullptr;
}

void CBackTrackingHelperClass::Initialize(int32_t numOfNodes)
{
	delete[] pNodeArray;
	pNodeArray = nullptr;

	NumOfNodes = numOfNodes;
	NumOfNodesMinus1 = numOfNodes - 1;

	pNodeArray = new (std::nothrow) CNode[numOfNodes];
	
	for (int32_t i = 0; i < numOfNodes; i++)
	{
		pNodeArray[i].NodeID = i;
	}

	for (int32_t i = 1; i < numOfNodes; i++)
	{
		pNodeArray[i].PrevNodeID = i - 1;
	}

	idOfNextUnusedNode = 0;
}

int32_t CBackTrackingHelperClass::Request_ID_Of_NextUnusedNode(void)
{
	if (idOfNextUnusedNode < NumOfNodesMinus1)
	{
		int32_t id = idOfNextUnusedNode;
		idOfNextUnusedNode++;
		return id;
	}

	return -1;
}

void CBackTrackingHelperClass::Free_PreviousRequested_Node(void)
{
	if (idOfNextUnusedNode > 0)
	{
		idOfNextUnusedNode--;
	}
}