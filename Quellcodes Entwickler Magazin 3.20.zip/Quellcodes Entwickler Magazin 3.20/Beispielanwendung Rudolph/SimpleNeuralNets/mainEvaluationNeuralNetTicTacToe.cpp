#include <iostream>
#include "TicTacToe.h"
#include "NeuralNet.h"
#include "ConsoleHelperFunctions.h"

#define HumanPlayer1
//#define HumanPlayer2

using namespace std;

#define KEYDOWN(vk_code) ((GetAsyncKeyState(vk_code) & 0x8000) ? 1 : 0)
#define KEYUP(vk_code)   ((GetAsyncKeyState(vk_code) & 0x8000) ? 0 : 1)

static uint32_t g_NumPlayer1Wins = 0;
static uint32_t g_NumPlayer2Wins = 0;
static uint32_t g_NumDraws = 0;

static char g_InputBuffer[100];

static CRandomNumbers_ParkMillerMLKG g_RandomNumbers;


static constexpr float minPlasticityVariance = -0.1f;
static constexpr float maxPlasticityVariance = 0.1f;


inline float ActivationFunction(float neuronInput)
{
	// von -1.0f bis 1.0f:
	//return tanh(neuronInput);

	// von -1.0f bis 1.0f:
	return neuronInput / (1.0f + abs(0.5f*neuronInput));
}


inline float TicTacToePlayingBrainActivation1(float neuronInput)
{
	return neuronInput / (1.0f + abs(0.5f * neuronInput));
}

inline float TicTacToePlayingBrainActivation2(float neuronInput)
{
	return 0.5f + 0.5f * neuronInput / (1.0f + abs(0.5f * neuronInput));
}

inline float TicTacToePlayingBrainActivation3(float neuronInput)
{
	return 1.0f / (1.0f + exp(-neuronInput));
}

inline float TicTacToePlayingBrainActivation4(float neuronInput)
{
	if (neuronInput < 0.0f)
		return 0.01f * neuronInput;
	else
		return neuronInput;
}


static void HumanPlayerMove(CGameState *pGameState, uint8_t player)
{
	if (pGameState->NumEmptyBoardPositions == 0)
		return;


	uint32_t row, column;

	bool moveCompleted = false;

	do
	{
		cout << "Player Move - select row: ";
		cin.getline(g_InputBuffer, 100);

		// C-String in eine Ganzzahl umrechnen:
		row = atoi(g_InputBuffer);

		cout << "Player Move - select column: ";
		cin.getline(g_InputBuffer, 100);

		// C-String in eine Ganzzahl umrechnen:
		column = atoi(g_InputBuffer);

		moveCompleted = pGameState->Make_Move(row, column, player);

		cout << endl;

	} while (moveCompleted == false);
}

static void AIPlayer_RandomMove(CGameState *pGameState, uint8_t player)
{
	if (pGameState->NumEmptyBoardPositions == 0)
		return;

	uint32_t row, column;

	bool moveCompleted = false;

	do
	{
		row = g_RandomNumbers.Get_UnsignedIntegerNumber(0, ConstNumBoardRows);
		column = g_RandomNumbers.Get_UnsignedIntegerNumber(0, ConstNumBoardColumns);

		moveCompleted = pGameState->Make_Move(row, column, player);

	} while (moveCompleted == false);
}

static bool AIPlayer_MakeWinMoveIsPossible(CGameState *pGameState, uint8_t player)
{
	if (pGameState->NumEmptyBoardPositions == 0)
		return false;

	uint32_t row, column;

	if (player == ConstBoardSymbol_Player1)
	{
		for (row = 0; row < ConstNumBoardRows; row++)
		{
			for (column = 0; column < ConstNumBoardColumns; column++)
			{
				if (pGameState->Board[row][column] == ConstBoardSymbol_Empty)
				{
					pGameState->Make_Move(row, column, player);

					if (pGameState->Evaluate_Player1() > 0.0f) // win move!
						return true;

					pGameState->Reset_LastMove_RowColumn();
				}
			}
		}
	}

	if (player == ConstBoardSymbol_Player2)
	{
		for (row = 0; row < ConstNumBoardRows; row++)
		{
			for (column = 0; column < ConstNumBoardColumns; column++)
			{
				if (pGameState->Board[row][column] == ConstBoardSymbol_Empty)
				{
					pGameState->Make_Move(row, column, player);

					if (pGameState->Evaluate_Player2() > 0.0f) // win move!
						return true;

					pGameState->Reset_LastMove_RowColumn();
				}
			}
		}
	}

	return false;
}

static void AIPlayer_RandomOrWinMove(CGameState *pGameState, uint8_t player)
{
	if (pGameState->NumEmptyBoardPositions == 0)
		return;

	uint32_t row, column;

	if (player == ConstBoardSymbol_Player1)
	{
		for (row = 0; row < ConstNumBoardRows; row++)
		{
			for (column = 0; column < ConstNumBoardColumns; column++)
			{
				if (pGameState->Board[row][column] == ConstBoardSymbol_Empty)
				{
					pGameState->Make_Move(row, column, player);

					if (pGameState->Evaluate_Player1() > 0.0f) // win move!
						return;

					pGameState->Reset_LastMove_RowColumn();
				}
			}
		}
	}

	if (player == ConstBoardSymbol_Player2)
	{
		for (row = 0; row < ConstNumBoardRows; row++)
		{
			for (column = 0; column < ConstNumBoardColumns; column++)
			{
				if (pGameState->Board[row][column] == ConstBoardSymbol_Empty)
				{
					pGameState->Make_Move(row, column, player);

					if (pGameState->Evaluate_Player2() > 0.0f) // win move!
						return;

					pGameState->Reset_LastMove_RowColumn();
				}
			}
		}
	}


	bool moveCompleted = false;

	do
	{
		row = g_RandomNumbers.Get_UnsignedIntegerNumber(0, ConstNumBoardRows);
		column = g_RandomNumbers.Get_UnsignedIntegerNumber(0, ConstNumBoardColumns);

		moveCompleted = pGameState->Make_Move(row, column, player);

	} while (moveCompleted == false);
}

static bool Check_If_Game_Is_Finished(CGameState *pGameState)
{
	float EvaluationValuePlayer1;
	float EvaluationValuePlayer2;


	EvaluationValuePlayer1 = pGameState->Evaluate_Player1();

	if (EvaluationValuePlayer1 > 0.0f)
	{
		cout << "Player 1 Winner!" << endl << endl;
		g_NumPlayer1Wins++;
		return true;
	}

	EvaluationValuePlayer2 = pGameState->Evaluate_Player2();

	if (EvaluationValuePlayer2 > 0.0f)
	{
		cout << "Player 2 Winner!" << endl << endl;
		g_NumPlayer2Wins++;
		return true;
	}

	if (pGameState->NumEmptyBoardPositions == 0)
	{
		if (EvaluationValuePlayer1 == 0.0f && EvaluationValuePlayer2 == 0.0f)
		{
			cout << "Draw" << endl << endl;
			g_NumDraws++;
			return true;
		}
	}

	return false;
}

static bool Check_If_TrainingGame_Is_Finished(float *pOutEvaluationValue, CGameState *pGameState)
{
	float EvaluationValuePlayer1;
	float EvaluationValuePlayer2;


	EvaluationValuePlayer1 = pGameState->Evaluate_Player1();

	if (EvaluationValuePlayer1 > 0.0f)
	{
		*pOutEvaluationValue = 3.0f;
		return true;
	}

	EvaluationValuePlayer2 = pGameState->Evaluate_Player2();

	if (EvaluationValuePlayer2 > 0.0f)
	{
		*pOutEvaluationValue = -3.0f;
		return true;
	}

	if (pGameState->NumEmptyBoardPositions == 0)
	{
		if (EvaluationValuePlayer1 == 0.0f && EvaluationValuePlayer2 == 0.0f)
		{
			*pOutEvaluationValue = 0.0f;
			return true;
		}
	}

	*pOutEvaluationValue = 0;

	return false;
}

class CAIPlayer
{
public:

	uint32_t NumWins = 0;
	uint32_t NumLosses = 0;
	uint32_t NumDraws = 0;

	float ErrorScore = 0.0000001f;
	float FittingScore = 0.0f;
	
	CNeuralNet Brain;

	CGameState *pSavedGameStates = nullptr;

	CAIPlayer()
	{
		pSavedGameStates = new (std::nothrow) CGameState[9];

		
		Brain.Init_NeuralNet(130);
		Brain.Init_Input_And_OutputNeurons(27, 0.1f, false, 1, ActivationFunction);
		Brain.Init_HiddenLayer1(60, false, false, ActivationFunction, minPlasticityVariance, maxPlasticityVariance, minPlasticityVariance, maxPlasticityVariance, 0.05f);
		Brain.Init_HiddenLayer2(42, false, true, ActivationFunction, minPlasticityVariance, maxPlasticityVariance, minPlasticityVariance, maxPlasticityVariance, 0.0125f);
	}

	~CAIPlayer()
	{
		delete[] pSavedGameStates;
		pSavedGameStates = nullptr;
	}

	// Kopierkonstruktor l�schen:
	CAIPlayer(const CAIPlayer &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CAIPlayer& operator=(const CAIPlayer &originalObject) = delete;

	void Reset_Statistics(void)
	{
		NumWins = 0;
		NumLosses = 0;
		NumDraws = 0;

		ErrorScore = 0.0000001f;
		FittingScore = 0.0f;
	}

	void Calculate_FittingScore(void)
	{
		//FittingScore = 10.0f / ErrorScore;

		FittingScore = 1000.0f - ErrorScore;
	}

	

	void Make_FirstPlayerMove(CGameState *pGameState)
	{
		if (pGameState->NumEmptyBoardPositions == 0)
			return;

		float brainOutputBest = -100000.0f;
		uint32_t columnBest = 0;
		uint32_t rowBest = 0;

		float brainOutput;

		for (int32_t i = 0; i < 3; i++)
		{
			for (int32_t j = 0; j < 3; j++)
			{
				if (pGameState->Board[i][j] == ConstBoardSymbol_Empty)
				{
					// Make a test move:
					pGameState->Make_Move(i, j, ConstBoardSymbol_Player1);

					// Evaluate test move:
					//Brain.Calculate_Output(&brainOutput, pGameState->BoardDataArray);
					Brain.Calculate_Output(&brainOutput, pGameState->BoardDataArray2);

					if (brainOutput > brainOutputBest)
					{
						brainOutputBest = brainOutput;
						columnBest = j;
						rowBest = i;
					}

					pGameState->Reset_LastMove_RowColumn();
				}
			}
		}

		pGameState->Make_Move(rowBest, columnBest, ConstBoardSymbol_Player1);
	}

	
	// Reinforcement Learning:
	void Play_FirstPlayerRandomGame_And_Learn(void)
	{
		CGameState  GameState;

		float evaluationValue;


		uint32_t moveCounter = 0;

		// Beginn eines neuen Spiels:
		do
		{
			Make_FirstPlayerMove(&GameState);

			pSavedGameStates[moveCounter] = GameState;
			moveCounter++;

			if (Check_If_TrainingGame_Is_Finished(&evaluationValue, &GameState) == true)
				break;

			if (GameState.Check_If_Player2_Could_Win() == true)
			{
				evaluationValue = -3.0f;
				break;
			}

			AIPlayer_RandomOrWinMove(&GameState, ConstBoardSymbol_Player2);

			pSavedGameStates[moveCounter] = GameState;
			moveCounter++;

			if (Check_If_TrainingGame_Is_Finished(&evaluationValue, &GameState) == true)
				break;
			
		}
		// Ende des laufenden Spiels:
		while (true);

		if (evaluationValue > 0)
		{
			NumWins++;

			float brainOutput;
			float desiredOutputValue = 1.0f;

			for (uint32_t i = 0; i < moveCounter; i += 2)
			{
				Brain.Calculate_Output(&brainOutput, pSavedGameStates[i].BoardDataArray2);
				Brain.Learning(&desiredOutputValue);
			}
		}
		else if (evaluationValue < 0)
		{
			NumLosses++;

			float brainOutput;
			//float desiredOutputValue = 0.0f;
			float desiredOutputValue = -1.0f;

			for (uint32_t i = 0; i < moveCounter; i += 2)
			{
				Brain.Calculate_Output(&brainOutput, pSavedGameStates[i].BoardDataArray2);
				Brain.Learning(&desiredOutputValue);
			}
		}

		else
		{
			NumDraws++;

			float brainOutput;
			float desiredOutputValue = 0.9f;

			for (uint32_t i = 0; i < moveCounter; i += 2)
			{
				Brain.Calculate_Output(&brainOutput, pSavedGameStates[i].BoardDataArray2);
				Brain.Learning(&desiredOutputValue);
			}
		}
	}

	void Make_SecondPlayerMove(CGameState *pGameState)
	{
		if (pGameState->NumEmptyBoardPositions == 0)
			return;

		float brainOutputBest = -100000.0f;
		uint32_t columnBest = 0;
		uint32_t rowBest = 0;

		float brainOutput;

		for (int32_t i = 0; i < 3; i++)
		{
			for (int32_t j = 0; j < 3; j++)
			{
				if (pGameState->Board[i][j] == ConstBoardSymbol_Empty)
				{
					// Make a test move:
					pGameState->Make_Move(i, j, ConstBoardSymbol_Player2);

					// Evaluate test move:
					//Brain.Calculate_Output(&brainOutput, pGameState->BoardDataArray);
					Brain.Calculate_Output(&brainOutput, pGameState->BoardDataArray2);

					if (brainOutput > brainOutputBest)
					{
						brainOutputBest = brainOutput;
						columnBest = j;
						rowBest = i;
					}

					pGameState->Reset_LastMove_RowColumn();
				}
			}
		}

		
		pGameState->Make_Move(rowBest, columnBest, ConstBoardSymbol_Player2);
	}

	// Reinforcement Learning:
	void Play_SecondPlayerRandomGame_And_Learn(void)
	{
		CGameState  GameState;

		float evaluationValue;

		uint32_t moveCounter = 0;

		// Beginn eines neuen Spiels:
		do
		{
			AIPlayer_RandomOrWinMove(&GameState, ConstBoardSymbol_Player1);

			pSavedGameStates[moveCounter] = GameState;
			moveCounter++;

			if (Check_If_TrainingGame_Is_Finished(&evaluationValue, &GameState) == true)
				break;

			Make_SecondPlayerMove(&GameState);

			pSavedGameStates[moveCounter] = GameState;
			moveCounter++;

			if (Check_If_TrainingGame_Is_Finished(&evaluationValue, &GameState) == true)
				break;

			if (GameState.Check_If_Player1_Could_Win() == true)
			{
				evaluationValue = 3.0f;
				break;
			}

		}
		// Ende des laufenden Spiels:
		while (true);

		if (evaluationValue < 0)
		{
			NumWins++;

			float brainOutput;
			float desiredOutputValue = 1.0f;

			for (uint32_t i = 1; i < moveCounter; i+=2)
			{
				Brain.Calculate_Output(&brainOutput, pSavedGameStates[i].BoardDataArray2);
				Brain.Learning(&desiredOutputValue);
			}
		
		}

		else if (evaluationValue > 0)
		{
			NumLosses++;

			float brainOutput;
			//float desiredOutputValue = 0.0f;
			float desiredOutputValue = -1.0f;

			for (uint32_t i = 1; i < moveCounter; i += 2)
			{
				Brain.Calculate_Output(&brainOutput, pSavedGameStates[i].BoardDataArray2);
				Brain.Learning(&desiredOutputValue);
			}
		}

		else
		{
			NumDraws++;

			float brainOutput;
			float desiredOutputValue = 0.9f;

			for (uint32_t i = 1; i < moveCounter; i += 2)
			{
				Brain.Calculate_Output(&brainOutput, pSavedGameStates[i].BoardDataArray2);
				Brain.Learning(&desiredOutputValue);
			}
		}

	}	
};













// Backpropagation Deep Learning
/*
int main(void)
{
	cout << "TIC TAC TOE" << endl << endl;

	CAIPlayer AIFirstPlayer;
	CAIPlayer AISecondPlayer;

	uint32_t maxcount = 300000;
	uint32_t epoch = 0;
	
	// start training:

	for (uint32_t i = 0; i < maxcount; i++)
	{
		epoch++;


		AIFirstPlayer.Play_FirstPlayerRandomGame_And_Learn();
		AISecondPlayer.Play_SecondPlayerRandomGame_And_Learn();
	
		
		if (epoch % 1000 == 0)
		{
			cout << "epoch: " << epoch << endl;

			
			cout << "AIFirstPlayerWins: " << AIFirstPlayer.NumWins << endl;
			cout << "AIFirstPlayerDraws: " << AIFirstPlayer.NumDraws << endl;
			cout << "AIFirstPlayerLosses: " << AIFirstPlayer.NumLosses << endl << endl;
			AIFirstPlayer.Reset_Statistics();
		
			cout << "AISecondPlayerWins: " << AISecondPlayer.NumWins << endl;
			cout << "AISecondPlayerDraws: " << AISecondPlayer.NumDraws << endl;
			cout << "AISecondPlayerLosses: " << AISecondPlayer.NumLosses << endl << endl;
			AISecondPlayer.Reset_Statistics();
		}
	}

	


	// training completed

	
	AIFirstPlayer.Brain.Round_OutputWeights(0.1f);
	AIFirstPlayer.Brain.Remove_Unused_Connections();
	AIFirstPlayer.Brain.Deactivate_Unused_Neurons();
	
	AISecondPlayer.Brain.Round_OutputWeights(0.1f);
	AISecondPlayer.Brain.Remove_Unused_Connections();
	AISecondPlayer.Brain.Deactivate_Unused_Neurons();


	CGameState GameState;

	while (true) // Game Loop
	{
		cout << endl << "Num Player 1 Wins: " << g_NumPlayer1Wins << endl;
		cout << "Num Player 2 Wins: " << g_NumPlayer2Wins << endl;
		cout << "Num Draws: " << g_NumDraws << endl << endl;

		GameState.Output();


		// Beginn eines neuen Spiels:
		do
		{
			cout << "Player 1 Move: " << endl << endl;

#ifdef HumanPlayer1
			HumanPlayerMove(&GameState, ConstBoardSymbol_Player1);
#else
			AIFirstPlayer.Make_FirstPlayerMove(&GameState);

#endif
			GameState.Output();

			if (Check_If_Game_Is_Finished(&GameState) == true)
				break;



			cout << "Player 2 Move: " << endl << endl;

#ifdef HumanPlayer2
			HumanPlayerMove(&GameState, ConstBoardSymbol_Player2);
#else
			AISecondPlayer.Make_SecondPlayerMove(&GameState);


#endif

			GameState.Output();

			if (Check_If_Game_Is_Finished(&GameState) == true)
				break;


		}
		// Ende des laufenden Spiels:
		while (true);


		cout << "New Game (0/1): ";
		cin.getline(g_InputBuffer, 100);

		cout << endl << endl;

		// C-String in eine Ganzzahl umrechnen:
		if (atoi(g_InputBuffer) != 1)
			break;

		GameState.Reset_Bord();
	} // end of while (true) // Game Loop

	cout << "Bye Bye";

	getchar();
	return 0;
}
*/






