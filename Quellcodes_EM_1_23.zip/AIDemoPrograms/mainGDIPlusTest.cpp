#include "mainGDIPlusTest.h"

using namespace std;


//#pragma comment( linker, "/subsystem:console" )

/*
#pragma comment( linker, "/subsystem:windows" )

// MS-Windows event handling function:
LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)									// Nachrichten auswerten
	{


		// wurde die Windows-Anwendung aktiviert oder deaktiviert?
	case WM_ACTIVATE:
	{
		// Wurde das Fenster minimiert?
		if (!HIWORD(wParam))
		{
			g_Running = true;
		}
		else
		{
			// Fenster minimiert!
			g_Running = false;
		}

		return 0;
	}

	case WM_MOUSEWHEEL:
		g_MouseWheelRollingValue = (signed short)HIWORD(wParam) / WHEEL_DELTA;
		//break;

		// Verhindern, dass sich der Bildschirmschoner aktiviert oder der Monitor
		// in den Energiesparmodus wechselt:
	case WM_SYSCOMMAND:
	{
		switch (wParam)
		{
		case SC_SCREENSAVE:
		case SC_MONITORPOWER:
			return 0;
		}
		break;
	}

	// Programm soll beendet werden ...
	case WM_CLOSE:
	{
		// Nachricht zum Beeenden des Programms senden:
		PostQuitMessage(0);
		return 0;
	}
	// Rezize not implemented yet!!!!
	//case WM_SIZE:
	//{
	// Resize the application to the new window size, except when
	// it was minimized.
	//if (wParam != SIZE_MINIMIZED)
	//{}
	//break;
	//}

	default:
		break;
	}

	// Pass All Unhandled Messages To DefWindowProc
	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}


int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR pCmdLine, INT iCmdShow)
{

	g_Running = true;
	bool done = false; // initialize loop condition variable

	HWND                hWnd;
	MSG                 msg;
	WNDCLASS            wndClass;


	CGDIPlusWindow GDIPlusWindow;
	CApplicationMain *pApplicationMain = new CApplicationMain(&GDIPlusWindow);



	wndClass.style = CS_HREDRAW | CS_VREDRAW;
	wndClass.lpfnWndProc = WndProc;
	wndClass.cbClsExtra = 0;
	wndClass.cbWndExtra = 0;
	wndClass.hInstance = hInstance;
	wndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	wndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	wndClass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	wndClass.lpszMenuName = NULL;
	wndClass.lpszClassName = GDIPlusWindow.WindowTitle;

	RegisterClass(&wndClass);

	hWnd = CreateWindow(
		GDIPlusWindow.WindowTitle,   // window class name
		GDIPlusWindow.WindowTitle,  // window caption
		WS_OVERLAPPEDWINDOW,      // window style
		GDIPlusWindow.InitialX,
		GDIPlusWindow.InitialY,
		GDIPlusWindow.ScreenWidth,
		GDIPlusWindow.ScreenHeight,
		NULL,                     // parent window handle
		NULL,                     // window menu handle
		hInstance,                // program instance handle
		NULL);                    // creation parameters




	ShowWindow(hWnd, iCmdShow);
	UpdateWindow(hWnd);



	GDIPlusWindow.Initialize(hWnd);


	while (!done)									// Loop That Runs While done=FALSE
	{
		if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))	// Is There A Message Waiting?
		{
			if (msg.message == WM_QUIT)				// Have We Received A Quit Message?
				done = true;					    // If So done=TRUE
			else									// If Not, Deal With Window Messages
			{
				TranslateMessage(&msg);				// Translate The Message
				DispatchMessage(&msg);				// Dispatch The Message
			}
		}
		else										// If There Are No Messages
		{
			if (g_Running)								// Program Active?
			{
				if (KEYDOWN(VK_ESCAPE))				    // Was ESC Pressed?
					done = true;						// ESC Signalled A Quit
				else
				{
					GetCursorPos(&g_ActualCursorPosition);
					ScreenToClient(hWnd, &g_ActualCursorPosition);

					g_LeftMouseButtonPressed = false;
					if ((GetKeyState(VK_LBUTTON) & 0x100) != 0)
						g_LeftMouseButtonPressed = true;

					g_MiddleMouseButtonPressed = false;
					if ((GetKeyState(VK_MBUTTON) & 0x100) != 0)
						g_MiddleMouseButtonPressed = true;

					g_RightMouseButtonPressed = false;
					if ((GetKeyState(VK_RBUTTON) & 0x100) != 0)
						g_RightMouseButtonPressed = true;

					pApplicationMain->main();

					g_MouseWheelRollingValue = 0;
				}
			}
		}
	} // end of while




	delete pApplicationMain;
	pApplicationMain = nullptr;

	return (int)msg.wParam;
} // end of WinMain()
*/


CApplicationMain::CApplicationMain(CGDIPlusWindow *pGDIPlusWindow)
{
	pUsedGDIPlusWindow = pGDIPlusWindow;
	pUsedGDIPlusWindow->Set_WindowDimensions(800, 600, 100, 100);
	pUsedGDIPlusWindow->Set_WindowTitle(L"GDIPlus Test Application");
	pUsedGDIPlusWindow->Set_StandardFont(L"Consolas", 24);

	pLinearGradientBrush = new Gdiplus::LinearGradientBrush(Gdiplus::PointF(0.0f, 0.0f), Gdiplus::PointF(0.0f, 20.0f), Gdiplus::Color(255, 0, 0), Gdiplus::Color(0, 255, 0));

	testImageObject.Initialize(pUsedGDIPlusWindow, "TestImage1.bmp", true, true);

	testTexturedObject.Initialize(pUsedGDIPlusWindow, "TestImage1.png");
}

CApplicationMain::~CApplicationMain()
{
	delete pLinearGradientBrush;
	pLinearGradientBrush = nullptr;
}


int CApplicationMain::main(void)
{
	static float angle = 0.0f;
	pUsedGDIPlusWindow->Prepare_SceneUpdate(Gdiplus::Color(0, 100, 255));



	if (g_LeftMouseButtonPressed == true)
	{
		for (uint32_t y = 0; y < 10; y++)
		{
			for (uint32_t x = 0; x < 10; x++)
			{

				testTexturedObject.Draw_Rectangle(10.0f + 70.0f*x, 10.0f + 70.0f*y, angle, 0.5f, 0.5f);
			}
		}
	}

	//testTexturedObject.Draw_Rectangle(32.0f, 32.0f, angle, 0.5f, 0.5f);


	//pUsedGDIPlusWindow->Transform_Object(32.0f, 32.0f, angle, 0.5f, 0.5f);
	//testImageObject.Draw();
	//pUsedGDIPlusWindow->Reset_ObjectTransformations();

	pUsedGDIPlusWindow->Activate_Antialiasing();
	pUsedGDIPlusWindow->DrawLineExt(10.0f, 200.0f, 780.0f, 200.0f, Gdiplus::Color::Red, 5.0f, Gdiplus::DashStyleDot);
	pUsedGDIPlusWindow->DrawLine(10.0f, 300.0f, 780.0f, 300.0f, Gdiplus::Color::Red, 5.0f);

	pUsedGDIPlusWindow->DrawLine(200.0f, 200.0f, 200.0f, 300.0f, Gdiplus::Color::Red, 5.0f);


	/*pUsedGDIPlusWindow->Transform_Object(75.0f, 75.0f, angle, 1.75f, 0.8f);


	pUsedGDIPlusWindow->SceneGraphics->FillRectangle(&solidBrush, -25.0f, -25.0f, 50.0f, 50.0f);

	pUsedGDIPlusWindow->Reset_ObjectTransformations();*/

	angle += 1.0f;




	pLinearGradientBrush = new Gdiplus::LinearGradientBrush(Gdiplus::PointF(0.0f, 15.0f + 0.0f), Gdiplus::PointF(0.0f, 15.0f + 20.0f), Gdiplus::Color(255, 0, 0), Gdiplus::Color(0, 255, 0));

	//pUsedGDIPlusWindow->DrawString(L"Hello World\nHello World!", 20.0f, 15.0f, pFont, pLinearGradientBrush);


	pUsedGDIPlusWindow->DrawString("Hello World\nHello World!", 20.0f, 15.0f, Gdiplus::Color(255, 250, 55));

	pUsedGDIPlusWindow->Present_Scene();

	return 0;
}



