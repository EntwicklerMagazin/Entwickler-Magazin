#include <iostream>
#include "NeuralNet.h"

using namespace std;



float g_Image1[16 * 16] =

{ 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
  0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
  0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
  0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
  0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
  0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
  0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
  0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
  0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
  0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
  0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
  0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
  0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
  0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
  0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
  0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f };

float g_Image2[16 * 16] =

{ 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
  0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
  0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
  0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
  0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
  0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
  0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
  0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
  0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
  0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
  0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
  0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
  0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
  0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
  0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
  0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f };


inline void Output_RawImageData(float *pImage, uint32_t sizeX, uint32_t sizeY)
{
	uint32_t iy, ix, id, iy2;

	for (iy = 0; iy < sizeY; iy++)
	{
		iy2 = iy * sizeX;

		for (ix = 0; ix < sizeX; ix++)
		{
			id = ix + iy2;

			cout << pImage[id] << " ";
		}

		cout << endl;
	}
}

inline void Output_PosImageData(float *pImage, uint32_t sizeX, uint32_t sizeY)
{
	uint32_t iy, ix, id, iy2;

	for (iy = 0; iy < sizeY; iy++)
	{
		iy2 = iy * sizeX;

		for (ix = 0; ix < sizeX; ix++)
		{
			id = ix + iy2;

			cout << max(0.0f, pImage[id]) << " ";
		}

		cout << endl;
	}
}


// edge detection:

float g_Filter1[3 * 3] =
{ -1.0f, -1.0f, -1.0f,
  -1.0f,  8.0f, -1.0f,
  -1.0f, -1.0f, -1.0f };

// horizontal line detection:

float g_Filter2[3 * 3] =
{ -1.0f, -1.0f, -1.0f,
   2.0f,  2.0f,  2.0f,
  -1.0f, -1.0f, -1.0f };

// vertical line detection:

float g_Filter3[3 * 3] =
{ -1.0f, 2.0f, -1.0f,
  -1.0f, 2.0f, -1.0f,
  -1.0f, 2.0f, -1.0f };

// diagonal line detection 1:

float g_Filter4[3 * 3] =
{  2.0f, -1.0f, -1.0f,
  -1.0f,  2.0f, -1.0f,
  -1.0f, -1.0f,  2.0f };

// diagonal line detection 2:

float g_Filter5[3 * 3] =
{ -1.0f, -1.0f,  2.0f,
  -1.0f,  2.0f, -1.0f,
   2.0f, -1.0f, -1.0f };


float g_FeatureMap[16 * 16];

float g_LowResMap[8 * 8];

/*
int main(void)
{
	Output_PosImageData(g_Image2, 16, 16);
	getchar();

	Bisect_Resolution(g_LowResMap, g_Image2, 16, 16);
	MaxPooling2x2(g_LowResMap, g_Image2, 16, 16);
	Output_PosImageData(g_LowResMap, 8, 8);
	getchar();

	MaxPooling2x2(g_LowResMap, g_Image2, 16, 16);
	Output_PosImageData(g_LowResMap, 8, 8);
	getchar();

	L2Pooling2x2(g_LowResMap, g_Image2, 16, 16);
	Output_PosImageData(g_LowResMap, 8, 8);
	getchar();

	Calculate_FeatureMap(g_FeatureMap, g_Image2, 14, 14, 1, 1, g_Filter1, 3, 3, 1, 1);
	Output_PosImageData(g_FeatureMap, 14, 14);
	getchar();

	Calculate_FeatureMap(g_FeatureMap, g_Image2, 16, 16, g_Filter2, 3, 3, 1, 1);
	Output_PosImageData(g_FeatureMap, 14, 14);
	getchar();

	Calculate_FeatureMap(g_FeatureMap, g_Image2, 16, 16, g_Filter3, 3, 3, 1, 1);
	Output_PosImageData(g_FeatureMap, 14, 14);
	getchar();

	Add_Feature_To_FeatureMap(g_FeatureMap, g_Image2, 16, 16, g_Filter2, 3, 3, 1, 1);
	Output_PosImageData(g_FeatureMap, 14, 14);
	getchar();

	return 0;
}
*/


