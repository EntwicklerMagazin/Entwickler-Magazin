#include <iostream>
#include "NeuralCalculationNet.h"
#include "Graph.h"
#include "ConsoleHelperFunctions.h"
//#include "NeuralNetInlineFunctions.h"
#include "SparseVectorMatrix.h"
#include "Clustering.h"
#include "GeneticAlgorithms.h"
#include "Sudoku.h"

using namespace std;
using namespace HelperStuff;

#define KEYDOWN(vk_code) ((GetAsyncKeyState(vk_code) & 0x8000) ? 1 : 0)
#define KEYUP(vk_code)   ((GetAsyncKeyState(vk_code) & 0x8000) ? 0 : 1)



///*
int main(void)
{

	// super leichtes Sudoku:
	// Hinweis: 0: hier muss die korrekte Ziffer ermittelt werden!
	
	static int32_t  SudokuPuzzle[SudokuSizeSq] = {
		1, 2, 3, 4, 5, 6, 7, 8, 9,
		4, 5, 6, 7, 8, 9, 1, 2, 0,
		7, 0, 9, 1, 2, 3, 4, 5, 6,
		2, 3, 4, 5, 6, 7, 8, 9, 1,
		5, 6, 7, 8, 9, 1, 2, 3, 4,
		8, 9, 1, 2, 3, 4, 5, 6, 7,
		3, 4, 5, 6, 7, 8, 9, 1, 2,
		6, 7, 8, 9, 1, 2, 0, 4, 5,
		9, 1, 2, 3, 4, 5, 6, 7, 8 };

	//Complete_SudokuRows_If_Possible(SudokuPuzzle);
	//Complete_SudokuColumns_If_Possible(SudokuPuzzle);
	//Complete_Sudoku3x3Blocks_If_Possible(SudokuPuzzle);

	do
	{
		bool numbersAdded = Complete_SudokuRows_If_Possible(SudokuPuzzle);

		if (numbersAdded == false)
		{
			numbersAdded = Complete_SudokuColumns_If_Possible(SudokuPuzzle);
		}

		if (numbersAdded == false)
		{
			numbersAdded = Complete_Sudoku3x3Blocks_If_Possible(SudokuPuzzle);
		}

		if (numbersAdded == false)
		{
			break;
		}

	} while (true);

		
	Output_Sudoku(SudokuPuzzle);

	cout << "sudoku errors: " << Count_SudokuErrors(SudokuPuzzle) << endl << endl;


	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
//*/

/*
int main(void)
{
	// sehr leichtes Sudoku:
	// Hinweis: 0: hier muss die korrekte Ziffer ermittelt werden!

	static int32_t SudokuPuzzle[SudokuSizeSq] = {
		0, 7, 8, 1, 0, 6, 0, 2, 0,
		2, 4, 0, 5, 3, 0, 0, 0, 6,
		6, 0, 0, 7, 0, 9, 8, 0, 0,
		8, 5, 3, 0, 0, 0, 9, 0, 2,
		0, 6, 0, 0, 0, 0, 0, 7, 0,
		1, 0, 7, 0, 0, 0, 4, 3, 5,
		0, 0, 6, 3, 0, 1, 0, 0, 4,
		7, 0, 0, 0, 9, 5, 0, 8, 1,
		0, 2, 0, 6, 0, 4, 3, 9, 0 };

	int32_t counter = 0;

	do
	{
		if (Add_SudokuNumber_If_Possible(SudokuPuzzle) == true)
		{
			counter++;
		}
		else
		{
			break;
		}

	} while (true);

	cout << "numbers found: " << counter << endl << endl;


	Output_Sudoku(SudokuPuzzle);

	cout << "sudoku errors: " << Count_SudokuErrors(SudokuPuzzle) << endl << endl;


	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/

/*
int main(void)
{
	// leichtes Sudoku:
	// Hinweis: 0: hier muss die korrekte Ziffer ermittelt werden!
	static int32_t SudokuPuzzle[SudokuSizeSq] = {
		0, 3, 9, 6, 0, 0, 2, 0, 0,
		4, 0, 8, 0, 0, 3, 0, 0, 9,
		1, 5, 0, 0, 0, 2, 0, 8, 4,
		0, 8, 0, 0, 0, 5, 0, 0, 3,
		2, 0, 0, 0, 0, 0, 0, 0, 8,
		3, 0, 0, 2, 0, 0, 0, 5, 0,
		8, 4, 0, 5, 0, 0, 0, 9, 1,
		9, 0, 0, 8, 0, 0, 5, 0, 2,
		0, 0, 3, 0, 0, 7, 8, 4, 0 };

	int32_t counter = 0;

	do
	{
		if (Add_SudokuNumber_If_Possible(SudokuPuzzle) == true)
		{
			counter++;
		}
		else
		{
			break;
		}

	} while (true);

	cout << "numbers found: " << counter << endl << endl;


	Output_Sudoku(SudokuPuzzle);

	cout << "sudoku errors: " << Count_SudokuErrors(SudokuPuzzle) << endl << endl;


	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/

/*
int main(void)
{
	// mittelschweres Sudoku:
	// Hinweis: 0: hier muss die korrekte Ziffer ermittelt werden!
	static int32_t SudokuPuzzle[SudokuSizeSq] = {
		0, 0, 0, 0, 0, 5, 0, 0, 0,
		8, 0, 0, 0, 0, 0, 2, 0, 6,
		2, 0, 0, 8, 7, 6, 0, 5, 0,
		0, 0, 4, 6, 0, 0, 0, 2, 5,
		0, 1, 0, 0, 0, 0, 0, 9, 0,
		9, 5, 0, 0, 0, 1, 3, 0, 0,
		0, 3, 0, 7, 2, 9, 0, 0, 1,
		4, 0, 6, 0, 0, 0, 0, 0, 9,
		0, 0, 0, 3, 0, 0, 0, 0, 0 };

	int32_t counter = 0;

	do
	{
		if (Add_SudokuNumber_If_Possible_Ext(SudokuPuzzle) == true)
		{
			counter++;
		}
		else
		{
			break;
		}

	} while (true);

	cout << "numbers found: " << counter << endl << endl;

	Output_Sudoku(SudokuPuzzle);

	getchar();

	CSudokuUpdateNodeArray SudokuUpdateNodeArray;
	SudokuUpdateNodeArray.Initialize(SudokuPuzzle);

	for (int32_t i = 0; i < 10000; i++)
	{
		if (SudokuUpdateNodeArray.Update_Node(SudokuPuzzle) == 2)
		{
			cout << "num of attempts: " << i << endl;
			break;
		}
	}

	cout << endl;
	Output_Sudoku(SudokuPuzzle);

	cout << "sudoku errors: " << Count_SudokuErrors(SudokuPuzzle) << endl << endl;

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/


/*
int main(void)
{
	// Hinweis: 0: hier muss die korrekte Ziffer ermittelt werden!
	static int32_t SudokuPuzzle[SudokuSizeSq] = {
		3, 0, 6, 5, 0, 8, 4, 0, 0,
		5, 2, 0, 0, 0, 0, 0, 0, 0,
		0, 8, 7, 0, 0, 0, 0, 3, 1,
		0, 0, 3, 0, 1, 0, 0, 8, 0,
		9, 0, 0, 8, 6, 3, 0, 0, 5,
		0, 5, 0, 0, 9, 0, 6, 0, 0,
		1, 3, 0, 0, 0, 0, 2, 5, 0,
		0, 0, 0, 0, 0, 0, 0, 7, 4,
		0, 0, 5, 2, 0, 6, 3, 0, 0 };

	if (RecursiveSudokuSolver(SudokuPuzzle, 0, 0) == true)
	{
		Output_Sudoku(SudokuPuzzle);
	}
	else
	{
		cout << "no solution  exists " << endl;
	}

	cout << endl << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/

/*
int main(void)
{
	// Hinweis: 0: hier muss die korrekte Ziffer ermittelt werden!
	static int32_t SudokuPuzzle[SudokuSizeSq] = {
		3, 0, 6, 5, 0, 8, 4, 0, 0,
		5, 2, 0, 0, 0, 0, 0, 0, 0,
		0, 8, 7, 0, 0, 0, 0, 3, 1,
		0, 0, 3, 0, 1, 0, 0, 8, 0,
		9, 0, 0, 8, 6, 3, 0, 0, 5,
		0, 5, 0, 0, 9, 0, 6, 0, 0,
		1, 3, 0, 0, 0, 0, 2, 5, 0,
		0, 0, 0, 0, 0, 0, 0, 7, 4,
		0, 0, 5, 2, 0, 6, 3, 0, 0 };


	int32_t counter = 0;

	do
	{
		if (Add_SudokuNumber_If_Possible_Ext(SudokuPuzzle) == true)
	{
		counter++;
	}
	else
	{
		break;
	}

	} while (true);

	cout << "numbers found: " << counter << endl << endl;

	CSudokuUpdateNodeArray SudokuUpdateNodeArray;
	SudokuUpdateNodeArray.Initialize(SudokuPuzzle);


	for (int32_t i = 0; i < 10000; i++)
	{
		if(SudokuUpdateNodeArray.Update_Node(SudokuPuzzle) == 2)
		{
			cout << "num of attempts: " << i << endl;
			break;
		}
	}

	cout << endl;
	Output_Sudoku(SudokuPuzzle);

	cout << "sudoku errors: " << Count_SudokuErrors(SudokuPuzzle) << endl << endl;


	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/





/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	// Hinweis: 0: hier muss die korrekte Ziffer ermittelt werden!
	static int32_t SudokuPuzzle[SudokuSizeSq] = {
		3, 0, 6, 5, 0, 8, 4, 0, 0,
		5, 2, 0, 0, 0, 0, 0, 0, 0,
		0, 8, 7, 0, 0, 0, 0, 3, 1,
		0, 0, 3, 0, 1, 0, 0, 8, 0,
		9, 0, 0, 8, 6, 3, 0, 0, 5,
		0, 5, 0, 0, 9, 0, 6, 0, 0,
		1, 3, 0, 0, 0, 0, 2, 5, 0,
		0, 0, 0, 0, 0, 0, 0, 7, 4,
		0, 0, 5, 2, 0, 6, 3, 0, 0 };

	int32_t counter = 0;

	do
	{
		if (Add_SudokuNumber_If_Possible(SudokuPuzzle) == true)
		{
			counter++;
		}
		else
		{
			break;
		}
	} while (true);

	cout << "numbers found: " << counter << endl << endl;

	CSudokuUpdateNodeArrayExt SudokuUpdateNodeArray;
	SudokuUpdateNodeArray.Initialize(SudokuPuzzle);


	for (int32_t i = 0; i < 10000; i++)
	{
		if (SudokuUpdateNodeArray.Update_Node(SudokuPuzzle, &RandomNumbers) == 2)
		{
			cout << "num of attempts: " << i << endl;
			break;
		}
	}

	cout << endl;
	Output_Sudoku(SudokuPuzzle);

	cout << "sudoku errors: " << Count_SudokuErrors(SudokuPuzzle) << endl << endl;


	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/



/*
int main(void)
{
	// Hinweis: 0: hier muss die korrekte Ziffer ermittelt werden!
	static int32_t BaseSudokuPuzzle[SudokuSizeSq] = {
		1, 2, 3, 4, 5, 6, 7, 8, 9,
		4, 5, 6, 7, 8, 9, 1, 2, 3,
		7, 8, 9, 1, 2, 3, 4, 5, 6,
		2, 3, 4, 5, 6, 7, 8, 9, 1,
		5, 6, 7, 8, 9, 1, 2, 3, 4,
		8, 9, 1, 2, 3, 4, 5, 6, 7,
		3, 4, 5, 6, 7, 8, 9, 1, 2,
		6, 7, 8, 9, 1, 2, 3, 4, 5,
		9, 1, 2, 3, 4, 5, 6, 7, 8 };

	Output_Sudoku(BaseSudokuPuzzle);

	cout << endl;

	static int32_t SudokuPuzzle1[SudokuSizeSq];

	//Swap_TwoSudokuRows(SudokuPuzzle1, BaseSudokuPuzzle, 0, 2, 0);
	//Swap_TwoSudokuColumns(SudokuPuzzle1, BaseSudokuPuzzle, 0, 2, 1);
	//SudokuTransposition(SudokuPuzzle1, BaseSudokuPuzzle);
	//VerticalSudokuReflection(SudokuPuzzle1, BaseSudokuPuzzle);

	//SudokuPermutation(SudokuPuzzle1, BaseSudokuPuzzle, 2, 6);

	Swap_TwoSudoku9x3Blocks(SudokuPuzzle1, BaseSudokuPuzzle, 0, 1);
	//Swap_TwoSudoku3x9Blocks(SudokuPuzzle1, BaseSudokuPuzzle, 1, 0);
	//Swap_TwoSudoku3x9Blocks(SudokuPuzzle1, BaseSudokuPuzzle, 1, 2);

	Output_Sudoku(SudokuPuzzle1);

	cout << endl;

	cout << "sudoku errors: " << Count_SudokuErrors(SudokuPuzzle1) << endl << endl;

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/

/*
// Erzeugung eines kompletten Sudoku-R�tsels:
int main(void)
{
	CRandomNumbersNN RandomNumbers;
	RandomNumbers.Change_Seed(45878);

	// Hinweis: 0: hier muss die korrekte Ziffer ermittelt werden!
	static int32_t SudokuPuzzle[SudokuSizeSq] = {
		0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0, 0 };


	CSudokuUpdateNodeArrayExt SudokuUpdateNodeArray;
	SudokuUpdateNodeArray.Initialize(SudokuPuzzle);


	for (int32_t i = 0; i < 10000; i++)
	{
		if (SudokuUpdateNodeArray.Update_Node(SudokuPuzzle, &RandomNumbers) == 2)
		{
			cout << "num of attempts: " << i << endl;
			break;
		}
	}

	cout << endl;
	Output_Sudoku(SudokuPuzzle);

	cout << "sudoku errors: " << Count_SudokuErrors(SudokuPuzzle) << endl << endl;


	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/

/*
int main(void)
{
	// Hinweis: 0: hier muss die korrekte Ziffer ermittelt werden!
	static int32_t SudokuPuzzle[SudokuSizeSq] = {
		0, 0, 0, 2, 0, 0, 9, 8, 0,
		9, 8, 1, 3, 0, 6, 0, 5, 0,
		0, 4, 7, 0, 0, 5, 0, 3, 0,
		7, 0, 8, 0, 0, 9, 2, 0, 0,
		0, 0, 0, 0, 2, 0, 0, 0, 0,
		0, 0, 5, 4, 0, 0, 6, 0, 1,
		0, 3, 0, 7, 0, 0, 8, 6, 0,
		0, 7, 0, 8, 0, 1, 4, 2, 5,
		0, 5, 2, 0, 0, 4, 0, 0, 0 };

	int32_t counter = 0;

	do
	{
		if (Add_SudokuNumber_If_Possible(SudokuPuzzle) == true)
		{
			counter++;
		}
		else
		{
			break;
		}

	} while (true);

	cout << "numbers found: " << counter << endl << endl;


	Output_Sudoku(SudokuPuzzle);

	cout << "sudoku errors: " << Count_SudokuErrors(SudokuPuzzle) << endl << endl;


	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	int32_t NumOfRows_ProblemMatrix = 7;
	int32_t NumOfColumns_ProblemMatrix = 7;

	static int32_t IDArrayOfSolutionRowVectors[7];

	static bool RowVector1[7] = { true, false, false, true, false, false, true };
	static bool RowVector2[7] = { true, false, false, true, false, false, false };
	static bool RowVector3[7] = { false, false, false, true, true, false, true };
	static bool RowVector4[7] = { false, false, true, false, true, true, false };
	static bool RowVector5[7] = { false, true, true, false, false, true, true };
	static bool RowVector6[7] = { false, true, false, false, false, false, true };
	static bool RowVector7[7] = { true, false, false, true, false, false, false };

	CIterativeExactCoverSolver ExactCoverSolver;
	ExactCoverSolver.Initialize(NumOfRows_ProblemMatrix, NumOfColumns_ProblemMatrix);

	ExactCoverSolver.ProblemMatrix.Set_RowVector(RowVector1, 0);
	ExactCoverSolver.ProblemMatrix.Set_RowVector(RowVector2, 1);
	ExactCoverSolver.ProblemMatrix.Set_RowVector(RowVector3, 2);
	ExactCoverSolver.ProblemMatrix.Set_RowVector(RowVector4, 3);
	ExactCoverSolver.ProblemMatrix.Set_RowVector(RowVector5, 4);
	ExactCoverSolver.ProblemMatrix.Set_RowVector(RowVector6, 5);
	ExactCoverSolver.ProblemMatrix.Set_RowVector(RowVector7, 6);


	cout << endl;

	bool tempRowVector[7];

	for (int32_t i = 0; i < NumOfRows_ProblemMatrix; i++)
	{
		ExactCoverSolver.ProblemMatrix.Get_RowVector(tempRowVector, i);

		for (int32_t j = 0; j < NumOfColumns_ProblemMatrix; j++)
		{
			cout << static_cast<int32_t>(tempRowVector[j]) << " ";
		}

	cout << endl;
	}

	cout << endl;

	getchar();

	ExactCoverSolver.Prepare_Calculations_Use_ConstraintAccessSequence();
	//ExactCoverSolver.Prepare_Calculations();

	cout << endl;

	for (int32_t i = 0; i < NumOfRows_ProblemMatrix; i++)
	{
		int32_t numPosSolutionsPerConstraint = ExactCoverSolver.pSolutionsPerConstraintArray[i].NumOfSolutionsMax;

		cout << "num actual solutions per constraint: " << ExactCoverSolver.pSolutionsPerConstraintArray[i].ActualNumOfSolutions << endl;

		for (int32_t j = 0; j < numPosSolutionsPerConstraint; j++)
		{
			cout << ExactCoverSolver.pSolutionsPerConstraintArray[i].pSolutionIDArray[j] << " ";
		}

		cout << endl;
	}

	getchar();


	for (int32_t i = 0; i < 20; i++)
	{
		int32_t numOfNecessaryIterationSteps;

		if (ExactCoverSolver.Search_Solution_Use_ConstraintAccessSequence(100, &numOfNecessaryIterationSteps) == true)
		//if (ExactCoverSolver.Search_Solution(100, &numOfNecessaryIterationSteps) == true)
		{
			int32_t numberOfSolutionRowVectors = ExactCoverSolver.Get_Solution(IDArrayOfSolutionRowVectors);

			cout << "num iterations: " << numOfNecessaryIterationSteps << endl;

			for (int32_t i = 0; i < numberOfSolutionRowVectors; i++)
			{
				cout << IDArrayOfSolutionRowVectors[i] << " ";
			}

			cout << endl;
			getchar();
		}

		ExactCoverSolver.Prepare_For_ExactCoverSearchRestart();
		ExactCoverSolver.Permute_SolutionIDs_For_ExactCoverSearchRestart(&RandomNumbers);
	}

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	int32_t NumOfRows_ProblemMatrix = 5;
	int32_t NumOfColumns_ProblemMatrix = 5;

	static int32_t IDArrayOfSolutionRowVectors[5];

	static bool RowVector1[5] = { true, false, false, false, true };
	static bool RowVector2[5] = { false, true, false, true, false };
	static bool RowVector3[5] = { false, true, true, false, false };
	static bool RowVector4[5] = { false, false, true, false, false };
	static bool RowVector5[5] = { true, false, false, true, true };


	CIterativeExactCoverSolver ExactCoverSolver;
	ExactCoverSolver.Initialize(NumOfRows_ProblemMatrix, NumOfColumns_ProblemMatrix);

	ExactCoverSolver.ProblemMatrix.Set_RowVector(RowVector1, 0);
	ExactCoverSolver.ProblemMatrix.Set_RowVector(RowVector2, 1);
	ExactCoverSolver.ProblemMatrix.Set_RowVector(RowVector3, 2);
	ExactCoverSolver.ProblemMatrix.Set_RowVector(RowVector4, 3);
	ExactCoverSolver.ProblemMatrix.Set_RowVector(RowVector5, 4);



	cout << endl;

	bool tempRowVector[7];

	for (int32_t i = 0; i < NumOfRows_ProblemMatrix; i++)
	{
		ExactCoverSolver.ProblemMatrix.Get_RowVector(tempRowVector, i);

		for (int32_t j = 0; j < NumOfColumns_ProblemMatrix; j++)
		{
			cout << static_cast<int32_t>(tempRowVector[j]) << " ";
		}

		cout << endl;
	}

	cout << endl;

	getchar();

	//ExactCoverSolver.Prepare_Calculations_Use_ConstraintAccessSequence();
	ExactCoverSolver.Prepare_Calculations();

	cout << endl;

	for (int32_t i = 0; i < NumOfRows_ProblemMatrix; i++)
	{
		int32_t numPosSolutionsPerConstraint = ExactCoverSolver.pSolutionsPerConstraintArray[i].NumOfSolutionsMax;

		cout << "num actual solutions per constraint: " << ExactCoverSolver.pSolutionsPerConstraintArray[i].ActualNumOfSolutions << endl;

		for (int32_t j = 0; j < numPosSolutionsPerConstraint; j++)
		{
			cout << ExactCoverSolver.pSolutionsPerConstraintArray[i].pSolutionIDArray[j] << " ";
		}

		cout << endl;
	}

	getchar();


	for (int32_t i = 0; i < 20; i++)
	{
		int32_t numOfNecessaryIterationSteps;

		//if (ExactCoverSolver.Search_Solution_Use_ConstraintAccessSequence(100, &numOfNecessaryIterationSteps) == true)
		if (ExactCoverSolver.Search_Solution(100, &numOfNecessaryIterationSteps) == true)
		{
			int32_t numberOfSolutionRowVectors = ExactCoverSolver.Get_Solution(IDArrayOfSolutionRowVectors);

			cout << "num iterations: " << numOfNecessaryIterationSteps << endl;

			for (int32_t i = 0; i < numberOfSolutionRowVectors; i++)
			{
				cout << IDArrayOfSolutionRowVectors[i] << " ";
			}

			cout << endl;
			getchar();
		}

		ExactCoverSolver.Prepare_For_ExactCoverSearchRestart();
		ExactCoverSolver.Permute_SolutionIDs_For_ExactCoverSearchRestart(&RandomNumbers);
	}

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/