#include <iostream>
#include "Graph.h"
#include "NeuralNet_V2.h"

using namespace std;


static constexpr uint32_t NumSurfaceMapElementsPerDir = 7;
static constexpr uint32_t NumSurfaceMapElements = 49;


static constexpr uint32_t NumCities_TSP = 12;
static constexpr uint32_t NumCities_TSP_Plus1 = NumCities_TSP + 1;


static constexpr uint32_t NumWaypoints = 12;
static constexpr uint32_t NumWaypointsMaxPerPath = 10;



inline void Output_SurfaceMapData(char *pData)
{
	uint32_t ix, iy, id;

	for (iy = 0; iy < NumSurfaceMapElementsPerDir; iy++)
	{
		for (ix = 0; ix < NumSurfaceMapElementsPerDir; ix++)
		{
			id = ix + iy * NumSurfaceMapElementsPerDir;
			cout << pData[id] << " ";
		}

		cout << endl;
	}

	cout << endl << endl;
}

inline void Set_SurfaceMapData(char *pOutData, uint32_t ix, uint32_t iy, char sign)
{
	uint32_t id = ix + iy * NumSurfaceMapElementsPerDir;
	pOutData[id] = sign;
}

inline void Init_SurfaceMap(char *pOutData, char sign)
{
	uint32_t ix, iy, id;

	for (iy = 0; iy < NumSurfaceMapElementsPerDir; iy++)
	{
		for (ix = 0; ix < NumSurfaceMapElementsPerDir; ix++)
		{
			id = ix + iy * NumSurfaceMapElementsPerDir;
			pOutData[id] = sign;
		}
	}
}

inline void Update_Fitnessvalues(CGraphNode *pGraphNodeArray, CDendriteNeuronPopulation *pNeuronPopulation)
{
	CNeuronV2 *pNeuronArray = pNeuronPopulation->ppNeuronArray[0];

	int32_t populationSizePlusX = pNeuronPopulation->PopulationSizePlusX;
	int32_t num_Of_Dendrite_Elements = pNeuronArray[0].Num_Of_Dendrite_Elements;

	float distSq;

	for (int32_t i = 0; i < populationSizePlusX; i++)
	{
		distSq = pGraphNodeArray->Calculate_PathDistSq(pNeuronArray[i].pDendrite_FactorArray, num_Of_Dendrite_Elements);
		// Fitnessvalue:
		pNeuronArray[i].Set_NeuronOutput(1.0f / distSq);
	}
}

inline void Update_FitnessvaluesExt(CGraphNode *pGraphNodeArray, CWeightMatrix *pWeightMatrix, CDendriteNeuronPopulation *pNeuronPopulation)
{
	CNeuronV2 *pNeuronArray = pNeuronPopulation->ppNeuronArray[0];

	int32_t populationSizePlusX = pNeuronPopulation->PopulationSizePlusX;
	int32_t num_Of_Dendrite_Elements = pNeuronArray[0].Num_Of_Dendrite_Elements;

	float distSq;

	for (int32_t i = 0; i < populationSizePlusX; i++)
	{
		distSq = pGraphNodeArray->Calculate_WeightedPathDistSq(pNeuronArray[i].pDendrite_FactorArray, pWeightMatrix, num_Of_Dendrite_Elements);
		// Fitnessvalue:
		pNeuronArray[i].Set_NeuronOutput(1.0f / distSq);
	}
}

inline void TSP_RecombinationFunction(CNeuronV2 *pOffspring, const CNeuronV2 *pParent1, const CNeuronV2 *pParent2, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	static float tempValueArray[1000];

	int32_t numVectorElements = pOffspring->Num_Of_Dendrite_Elements;
	int32_t numVectorElementsMinus1 = numVectorElements - 1;

	float *pInputVector1 = pParent1->pDendrite_FactorArray;
	float *pInputVector2 = pParent2->pDendrite_FactorArray;
	float *pOutputVector = pOffspring->pDendrite_FactorArray;


	int32_t counter = 0;

	/* Route 1 von Individuum 1 mit Ausnahme des Zielpunkts zwischenspeichern: */
	for (int32_t i = 0; i < numVectorElementsMinus1; i++)
	{
		tempValueArray[counter] = pInputVector1[i];
		counter++;
	}

	/* Route 2 von Individuum 2 mit Ausnahme des Startpunkts zwischenspeichern: */
	for (int32_t i = 1; i < numVectorElements; i++)
	{
		tempValueArray[counter] = pInputVector2[i];
		counter++;
	}


	counter--;

	for (int32_t i = 1; i < counter; i++)
	{
		/* entweder Wegpunkt von Route 1 deaktivieren (durch negatives Vorzeichen kennzeichnen): */
		if (pRandomNumbers->Get_IntegerNumber(1, 3) == 1)
		{
			for (int32_t j = 1; j < numVectorElementsMinus1; j++)
			{
				if (tempValueArray[j] == static_cast<float>(i))
				{
					tempValueArray[j] = static_cast<float>(-i);
					break;
				}
			}
		}
		/* oder Wegpunkt von Route 2 deaktivieren (durch negatives Vorzeichen kennzeichnen): */
		else
		{
			for (int32_t j = numVectorElementsMinus1; j < counter; j++)
			{
				if (tempValueArray[j] == static_cast<float>(i))
				{
					tempValueArray[j] = static_cast<float>(-i);
					break;
				}
			}
		}
	}

	/* Neue Route aus nicht deaktivierten Wegpunkten generieren: */

	pOutputVector[0] = 0.0f;
	pOutputVector[numVectorElementsMinus1] = 0.0f;

	int32_t counter2 = 1;
	//counter--;
	for (int32_t i = 1; i < counter; i++)
	{
		/* pos. Vorzeichen => nicht deaktivierter Wegpunkt: */
		if (tempValueArray[i] > 0.0f)
		{
			pOutputVector[counter2] = tempValueArray[i];
			counter2++;
		}
	}
}




inline void Pathfinding_MutationFunction(CNeuronV2 *pInOutNeuron, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	int32_t numDendrites = pInOutNeuron->Num_Of_Dendrite_Elements;

	int32_t iDofMutatedPathElement = pRandomNumbers->Get_IntegerNumber(1, numDendrites - 1);

	float *pDendrite_FactorArray = pInOutNeuron->pDendrite_FactorArray;

	int32_t startID = static_cast<int32_t>(pDendrite_FactorArray[0]);
	int32_t destinationID = static_cast<int32_t>(pDendrite_FactorArray[numDendrites - 1]);

	do
	{
		int32_t waypontID = pRandomNumbers->Get_IntegerNumber(0, numDendrites);

		if (waypontID == startID)
			continue;
		if (waypontID == destinationID)
			continue;
		if (waypontID == static_cast<int32_t>(pDendrite_FactorArray[iDofMutatedPathElement]))
			continue;

		pDendrite_FactorArray[iDofMutatedPathElement] = static_cast<float>(waypontID);
		break;

	} while (true);
}

inline void Pathfinding_RecombinationFunction(CNeuronV2 *pOffspring, const CNeuronV2 *pParent1, const CNeuronV2 *pParent2, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	float *pDendrite_FactorArray_Parent1 = pParent1->pDendrite_FactorArray;
	float *pDendrite_FactorArray_Parent2 = pParent2->pDendrite_FactorArray;
	float *pDendrite_FactorArray_Offspring = pOffspring->pDendrite_FactorArray;

	int32_t numDendrites = pOffspring->Num_Of_Dendrite_Elements;
	int32_t numDendritesMinus1 = numDendrites - 1;

	for (int32_t i = 0; i < numDendrites; i++)
		pDendrite_FactorArray_Offspring[i] = pDendrite_FactorArray_Parent1[i];

	for (int32_t i = 1; i < numDendritesMinus1; i++)
	{
		if (pRandomNumbers->Get_IntegerNumber2(1, 2) == 2)
			pDendrite_FactorArray_Offspring[i] = pDendrite_FactorArray_Parent2[i];			
	}
}

inline void Get_Path(int32_t *pOutPath, int32_t *pOutNumWaypoints, const CNeuronV2 *pNeuron)
{
	int32_t counter = 0;

	float *pDendrite_FactorArray = pNeuron->pDendrite_FactorArray;

	int32_t numDendritesMinus1 = pNeuron->Num_Of_Dendrite_Elements - 1;

	int32_t id1, id2;

	for (int32_t i = 0; i < numDendritesMinus1; i++)
	{
		id1 = static_cast<int32_t>(pDendrite_FactorArray[i]);
		id2 = static_cast<int32_t>(pDendrite_FactorArray[i + 1]);

		if (id1 != id2)
		{
			pOutPath[counter] = id1;
			counter++;
		}
	}

	pOutPath[counter] = static_cast<int32_t>(pDendrite_FactorArray[numDendritesMinus1]);
	counter++;

	*pOutNumWaypoints = counter;
}

inline void Get_Best_Path(int32_t *pOutPath, int32_t *pOutNumWaypoints, CDendriteNeuronPopulation *pPopulation)
{
	CNeuronV2 *pBestNeuron = pPopulation->ppNeuronArray[pPopulation->IDArrayOfBestFittedBrains[0]];
	int32_t num_Of_Dendrite_Elements = pBestNeuron->Num_Of_Dendrite_Elements;

	int32_t counter = 0;

	float *pDendrite_FactorArray = pBestNeuron->pDendrite_FactorArray;

	int32_t numDendritesMinus1 = pBestNeuron->Num_Of_Dendrite_Elements - 1;

	int32_t id1, id2;

	for (int32_t i = 0; i < numDendritesMinus1; i++)
	{
		id1 = static_cast<int32_t>(pDendrite_FactorArray[i]);
		id2 = static_cast<int32_t>(pDendrite_FactorArray[i + 1]);

		if (id1 != id2)
		{
			pOutPath[counter] = id1;
			counter++;
		}
	}

	pOutPath[counter] = static_cast<int32_t>(pDendrite_FactorArray[numDendritesMinus1]);
	counter++;

	*pOutNumWaypoints = counter;
}


inline void Get_Path(int32_t *pOutPath, CNeuronV2 *pNeuron)
{
	int32_t num_Of_Dendrite_Elements = pNeuron->Num_Of_Dendrite_Elements;

	for (int32_t i = 0; i < num_Of_Dendrite_Elements; i++)
		pOutPath[i] = static_cast<int32_t>(pNeuron->pDendrite_FactorArray[i]);
}

inline void Get_Shortest_TSP_Path(int32_t *pOutPath, CDendriteNeuronPopulation *pPopulation)
{
	CNeuronV2 *pBestNeuron = pPopulation->ppNeuronArray[pPopulation->IDArrayOfBestFittedBrains[0]];
	int32_t num_Of_Dendrite_Elements = pBestNeuron->Num_Of_Dendrite_Elements;

	for (int32_t i = 0; i < num_Of_Dendrite_Elements; i++)
		pOutPath[i] = static_cast<int32_t>(pBestNeuron->pDendrite_FactorArray[i]);
}




/*
int main(void)
{
	int32_t TrainingPopulationSize = 100;
	int32_t NumTrainingGenerationsMax = 20000;

	// Visualisierung der einzelnen St�dte:

	static char SurfaceMap[NumSurfaceMapElements];

	Init_SurfaceMap(SurfaceMap, '*');

	Set_SurfaceMapData(SurfaceMap, 2, 0, '0');
	Set_SurfaceMapData(SurfaceMap, 4, 0, '1');
	Set_SurfaceMapData(SurfaceMap, 0, 1, '2');
	Set_SurfaceMapData(SurfaceMap, 4, 2, '3');
	Set_SurfaceMapData(SurfaceMap, 0, 4, '4');
	Set_SurfaceMapData(SurfaceMap, 2, 3, '5');
	Set_SurfaceMapData(SurfaceMap, 3, 4, '6');
	Set_SurfaceMapData(SurfaceMap, 5, 5, '7');
	Set_SurfaceMapData(SurfaceMap, 6, 3, '8');
	Set_SurfaceMapData(SurfaceMap, 1, 6, '9');
	Set_SurfaceMapData(SurfaceMap, 6, 1, 'A');
	Set_SurfaceMapData(SurfaceMap, 3, 6, 'B');


	Output_SurfaceMapData(SurfaceMap);

	// Visualisierung der einzelnen St�dte abgeschlossen

	static CGraphNode GraphNodeArray[NumCities_TSP_Plus1];

	GraphNodeArray[0].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[0].Set_Position(2.0f, 0.0f, 0.0f);
	GraphNodeArray[1].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[1].Set_Position(4.0f, 0.0f, 0.0f);
	GraphNodeArray[2].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[2].Set_Position(0.0f, 1.0f, 0.0f);
	GraphNodeArray[3].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[3].Set_Position(4.0f, 2.0f, 0.0f);
	GraphNodeArray[4].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[4].Set_Position(0.0f, 4.0f, 0.0f);
	GraphNodeArray[5].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[5].Set_Position(2.0f, 3.0f, 0.0f);
	GraphNodeArray[6].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[6].Set_Position(3.0f, 4.0f, 0.0f);
	GraphNodeArray[7].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[7].Set_Position(5.0f, 5.0f, 0.0f);
	GraphNodeArray[8].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[8].Set_Position(6.0f, 3.0f, 0.0f);
	GraphNodeArray[9].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[9].Set_Position(1.0f, 6.0f, 0.0f);
	GraphNodeArray[10].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[10].Set_Position(6.0f, 1.0f, 0.0f);
	GraphNodeArray[11].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[11].Set_Position(3.0f, 6.0f, 0.0f);
	GraphNodeArray[12].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[12].Set_Position(2.0f, 0.0f, 0.0f);

	CNeuronV2 *pNeuronArray = new (std::nothrow) CNeuronV2[TrainingPopulationSize];

	CDendriteNeuronPopulation NeuronPopulation;

	NeuronPopulation.Initialize(TrainingPopulationSize);

	for (int32_t i = 0; i < TrainingPopulationSize; i++)
	{
		NeuronPopulation.Set_Neuron(&pNeuronArray[i], i);
	}

	NeuronPopulation.Init_Or_Reinitialize_Dendrite_Arrays(NumCities_TSP_Plus1);

	static float InitialPath[NumCities_TSP_Plus1];

	for (int32_t i = 0; i < NumCities_TSP; i++)
		InitialPath[i] = static_cast<float>(i);

	// Ziel der Rundreise:
	InitialPath[NumCities_TSP] = 0.0f;

	for (int32_t i = 0; i < NumCities_TSP_Plus1; i++)
	{
		cout << InitialPath[i] << " ";
	}

	cout << endl;

	NeuronPopulation.Set_Dendrite_Factors(InitialPath);

	NeuronPopulation.Permute_Dendrite_Values(1, NumCities_TSP_Plus1 - 2, 3);

	for (int32_t i = 0; i < NumTrainingGenerationsMax; i++)
	{
		Update_Fitnessvalues(GraphNodeArray, &NeuronPopulation);

		NeuronPopulation.Update_Population();

		NeuronPopulation.Update_BaseEvolution_Dendrite_Permutations(1, NumCities_TSP_Plus1 - 2, 1);
		NeuronPopulation.Update_Evolution_BestBrainOnly_Dendrite_Permutations(1, NumCities_TSP_Plus1 - 2, 1);
		NeuronPopulation.Update_Evolution_SecondBestBrainOnly_Dendrite_Permutations(1, NumCities_TSP_Plus1 - 2, 1);
		NeuronPopulation.Update_Evolution_Combine_BestTwoBrains(TSP_RecombinationFunction, nullptr);
		NeuronPopulation.Update_Evolution_Combine_TwoBrains(TSP_RecombinationFunction, nullptr);
		NeuronPopulation.Update_Evolution_Combine_TwoBrains(TSP_RecombinationFunction, nullptr);
	}

	static int32_t ShortestPath[NumCities_TSP_Plus1];

	Get_Shortest_TSP_Path(ShortestPath, &NeuronPopulation);

	float minPathDistSq = GraphNodeArray[0].Calculate_PathDistSq(ShortestPath, NumCities_TSP_Plus1);

	cout << endl << "minPathDistSq: " << minPathDistSq << endl;

	static int32_t RearrangedPath[NumCities_TSP_Plus1];

	Rearrange_TSP_Path(RearrangedPath, ShortestPath, NumCities_TSP_Plus1, 3);

	for (int32_t i = 0; i < NumCities_TSP_Plus1; i++)
	{
		cout << ShortestPath[i] << " ";
	}

	cout << endl;

	for (int32_t i = 0; i < NumCities_TSP_Plus1; i++)
	{
		cout << RearrangedPath[i] << " ";
	}

	cout << endl;


	getchar();

	delete[] pNeuronArray;
	pNeuronArray = nullptr;

	return 0;
}
*/

/*
int main(void)
{
	int32_t TrainingPopulationSize = 100;
	int32_t NumTrainingGenerationsMax = 5000;

	// Visualisierung der einzelnen St�dte:

	static char SurfaceMap[NumSurfaceMapElements];

	Init_SurfaceMap(SurfaceMap, '*');

	Set_SurfaceMapData(SurfaceMap, 2, 0, '0');
	Set_SurfaceMapData(SurfaceMap, 4, 0, '1');
	Set_SurfaceMapData(SurfaceMap, 0, 1, '2');
	Set_SurfaceMapData(SurfaceMap, 4, 2, '3');
	Set_SurfaceMapData(SurfaceMap, 0, 4, '4');
	Set_SurfaceMapData(SurfaceMap, 2, 3, '5');
	Set_SurfaceMapData(SurfaceMap, 3, 4, '6');
	Set_SurfaceMapData(SurfaceMap, 5, 5, '7');
	Set_SurfaceMapData(SurfaceMap, 6, 3, '8');
	Set_SurfaceMapData(SurfaceMap, 1, 6, '9');
	Set_SurfaceMapData(SurfaceMap, 6, 1, 'A');
	Set_SurfaceMapData(SurfaceMap, 3, 6, 'B');


	Output_SurfaceMapData(SurfaceMap);

	// Visualisierung der einzelnen St�dte abgeschlossen

	static CGraphNode GraphNodeArray[NumWaypoints];

	GraphNodeArray[0].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[0].Set_Position(2.0f, 0.0f, 0.0f);
	GraphNodeArray[1].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[1].Set_Position(4.0f, 0.0f, 0.0f);
	GraphNodeArray[2].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[2].Set_Position(0.0f, 1.0f, 0.0f);
	GraphNodeArray[3].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[3].Set_Position(4.0f, 2.0f, 0.0f);
	GraphNodeArray[4].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[4].Set_Position(0.0f, 4.0f, 0.0f);
	GraphNodeArray[5].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[5].Set_Position(2.0f, 3.0f, 0.0f);
	GraphNodeArray[6].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[6].Set_Position(3.0f, 4.0f, 0.0f);
	GraphNodeArray[7].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[7].Set_Position(5.0f, 5.0f, 0.0f);
	GraphNodeArray[8].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[8].Set_Position(6.0f, 3.0f, 0.0f);
	GraphNodeArray[9].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[9].Set_Position(1.0f, 6.0f, 0.0f);
	GraphNodeArray[10].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[10].Set_Position(6.0f, 1.0f, 0.0f);
	GraphNodeArray[11].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[11].Set_Position(3.0f, 6.0f, 0.0f);
	
	int32_t StartID = 1;
	int32_t DestinationID = 11;

	

	CWeightMatrix WeightMatrix;
	WeightMatrix.Init_Matrix(NumWaypoints, NumWaypoints, 1.0f);

	WeightMatrix.Set_Weight(StartID, DestinationID, 1000.0f);
	WeightMatrix.Set_Weight(DestinationID, StartID, 1000.0f);
	
	WeightMatrix.Set_Weight(0, 5, 1000.0f);
	WeightMatrix.Set_Weight(5, 0, 1000.0f);

	WeightMatrix.Set_Weight(0, 1, 1000.0f);
	WeightMatrix.Set_Weight(1, 0, 1000.0f);


	CNeuronV2 *pNeuronArray = new (std::nothrow) CNeuronV2[TrainingPopulationSize];

	CDendriteNeuronPopulation NeuronPopulation;

	NeuronPopulation.Initialize(TrainingPopulationSize);

	for (int32_t i = 0; i < TrainingPopulationSize; i++)
	{
		NeuronPopulation.Set_Neuron(&pNeuronArray[i], i);
	}

	NeuronPopulation.Init_Or_Reinitialize_Dendrite_Arrays(NumWaypointsMaxPerPath);

	static float InitialPath[NumWaypointsMaxPerPath];
	
	for (int32_t i = 0; i < NumWaypointsMaxPerPath; i++)
		InitialPath[i] = StartID;
	InitialPath[NumWaypointsMaxPerPath - 1] = DestinationID;


	for (int32_t i = 0; i < NumWaypointsMaxPerPath; i++)
	{
		cout << InitialPath[i] << " ";
	}

	cout << endl;

	

	NeuronPopulation.Set_Dendrite_Factors(InitialPath);

	NeuronPopulation.Mutate_Dendrite_Values(Pathfinding_MutationFunction, nullptr);

	for (int32_t i = 0; i < NumTrainingGenerationsMax; i++)
	{
		Update_FitnessvaluesExt(GraphNodeArray, &WeightMatrix, &NeuronPopulation);

		NeuronPopulation.Update_Population();

		NeuronPopulation.Update_BaseEvolution(Pathfinding_MutationFunction, nullptr);
		NeuronPopulation.Update_Evolution_BestBrainOnly(Pathfinding_MutationFunction, nullptr);
		NeuronPopulation.Update_Evolution_SecondBestBrainOnly(Pathfinding_MutationFunction, nullptr);
		NeuronPopulation.Update_Evolution_Combine_BestTwoBrains(Pathfinding_RecombinationFunction, nullptr);
		NeuronPopulation.Update_Evolution_Combine_TwoBrains(Pathfinding_RecombinationFunction, nullptr);
	}

	static int32_t BestPath[NumWaypointsMaxPerPath];
	int32_t NumWaypoints;

	Get_Best_Path(BestPath, &NumWaypoints, &NeuronPopulation);

	float minPathDistSq = GraphNodeArray[0].Calculate_PathDistSq(BestPath, NumWaypoints);

	cout << endl << "minPathDistSq: " << minPathDistSq << endl;

	for (int32_t i = 0; i < NumWaypoints; i++)
	{
		cout << BestPath[i] << " ";
	}

	cout << endl;

	getchar();

	delete[] pNeuronArray;
	pNeuronArray = nullptr;

	return 0;
}
*/

