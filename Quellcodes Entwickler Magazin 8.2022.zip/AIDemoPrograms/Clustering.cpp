#include "Clustering.h"

using namespace std;

//-----------------------------------------------------------------------------
// CNDPoint_InsideCluster
//-----------------------------------------------------------------------------

CNDPoint_InsideCluster::CNDPoint_InsideCluster()
{}

CNDPoint_InsideCluster::~CNDPoint_InsideCluster()
{
	delete[] pValueArray;
	pValueArray = nullptr;
}

void CNDPoint_InsideCluster::Initialize(int32_t size)
{
	delete[] pValueArray;
	pValueArray = nullptr;

	Size = size;

	pValueArray = new (std::nothrow) float[size];
}

void CNDPoint_InsideCluster::Reset(void)
{
	relatedValue = 0.0f;

	for (int32_t i = 0; i < Size; i++)
	{
		pValueArray[i] = 0.0f;
	}

	clusterID = 0;
}

//-----------------------------------------------------------------------------
// class CNDClusterCentroid
//-----------------------------------------------------------------------------

CNDClusterCentroid::CNDClusterCentroid()
{}

CNDClusterCentroid::~CNDClusterCentroid()
{
	delete[] pCenterValueArray;
	pCenterValueArray = nullptr;

	delete[] pOldCenterValueArray;
	pOldCenterValueArray = nullptr;
}

void CNDClusterCentroid::Initialize(int32_t size)
{
	delete[] pCenterValueArray;
	pCenterValueArray = nullptr;

	delete[] pOldCenterValueArray;
	pOldCenterValueArray = nullptr;

	Size = size;

	pCenterValueArray = new (std::nothrow) float[size];
	pOldCenterValueArray = new (std::nothrow) float[size];
}

void CNDClusterCentroid::Set_RBF_Constant(float value)
{
	RBF_Constant = value;
}

void CNDClusterCentroid::Set_ClusterRadiusBased_RBF_Constant(float value)
{
	RBF_Constant = value * ClusterRadiusSq;
}

void CNDClusterCentroid::Reset(void)
{
	relatedValue = 0.0f;

	for (int32_t i = 0; i < Size; i++)
	{
		pCenterValueArray[i] = 0.0f;
		pOldCenterValueArray[i] = 0.0f;
	}

	calculationsCompleted = false;
}

void CNDClusterCentroid::Reset_MeanCentroidCalculations(void)
{
	NumOfSamples = 0;
	
	for (int32_t i = 0; i < Size; i++)
	{
		pCenterValueArray[i] = 0.0f;
	}
}

void CNDClusterCentroid::Set_Centroid(CNDClusterCentroid *pCentroid)
{
	for (int32_t i = 0; i < Size; i++)
	{
		pCenterValueArray[i] = pCentroid->pCenterValueArray[i];
		pOldCenterValueArray[i] = pCenterValueArray[i];
	}

	NumOfSamples = 1;
}

float CNDClusterCentroid::Calculate_RBFValue(CNDPoint_InsideCluster *pPoint)
{
	float distSq = 0.0f;

	for (int32_t i = 0; i < Size; i++)
	{
		float delta = pCenterValueArray[i] - pPoint->pValueArray[i];
		delta *= delta;
		distSq += delta;
	}

	return exp(-RBF_Constant * distSq);
}

float CNDClusterCentroid::Calculate_ClippedRBFValue(CNDPoint_InsideCluster *pPoint)
{
	float distSq = 0.0f;

	for (int32_t i = 0; i < Size; i++)
	{
		float delta = pCenterValueArray[i] - pPoint->pValueArray[i];
		delta *= delta;
		distSq += delta;
	}

	if (distSq > ClusterRadiusSq)
	{
		return 0.0f;
	}


	return exp(-RBF_Constant * distSq);
}

float CNDClusterCentroid::Calculate_DistanceSq_To_Centroid(CNDPoint_InsideCluster *pPoint)
{
	float distSq = 0.0f;

	for (int32_t i = 0; i < Size; i++)
	{
		float delta = pCenterValueArray[i] - pPoint->pValueArray[i];
		delta *= delta;
		distSq += delta;
	}

	return distSq;
}



void CNDClusterCentroid::Add_To_MeanCentroid(CNDClusterCentroid *pCentroid)
{
	if (NumOfSamples == 0)
	{
		for (int32_t i = 0; i < Size; i++)
		{
			pCenterValueArray[i] = pCentroid->pCenterValueArray[i];
			pOldCenterValueArray[i] = pCenterValueArray[i];
		}

		NumOfSamples = 1;
		return;
	}

	NumOfSamples++;

	float weight = 1.0f / static_cast<float>(NumOfSamples);
	float oneMinusWeight = 1.0f - weight;

	for (int32_t i = 0; i < Size; i++)
	{
		pCenterValueArray[i] = oneMinusWeight * pCenterValueArray[i] + weight * pCentroid->pCenterValueArray[i];
		pOldCenterValueArray[i] = pCenterValueArray[i];
	}
}

void CNDClusterCentroid::Calculate_SumOfDistancesSq_InsideCluster(CNDPoint_InsideCluster *pPointArray, int32_t numOfPoints)
{
	SumOfDistancesSq_InsideCluster = 0.0f;

	for (int32_t i = 0; i < numOfPoints; i++)
	{
		if (centroidID != pPointArray[i].clusterID)
		{
			continue;
		}

		float *pValueArray = pPointArray[i].pValueArray;

		for (int32_t j = 0; j < Size; j++)
		{
			float delta = pCenterValueArray[j] - pValueArray[j];
			delta *= delta;
			SumOfDistancesSq_InsideCluster += delta;
		}

		/*float distanceSq = 0.0f;

		for (int32_t j = 0; j < Size; j++)
		{
			float delta = pCenterValueArray[j] - pPointArray[i].pValueArray[j];
			delta *= delta;
			distanceSq += delta;
		}

		SumOfDistancesSq_InsideCluster += distanceSq;*/
	}
}

void CNDClusterCentroid::Calculate_ClusterRadiusSq(CNDPoint_InsideCluster *pPointArray, int32_t numOfPoints)
{
	ClusterRadiusSq = 0.0f;

	for (int32_t i = 0; i < numOfPoints; i++)
	{
		if (centroidID != pPointArray[i].clusterID)
		{
			continue;
		}

		float *pValueArray = pPointArray[i].pValueArray;

		float radiusSq = 0.0f;

		for (int32_t j = 0; j < Size; j++)
		{
			float delta = pCenterValueArray[j] - pValueArray[j];
			delta *= delta;
			radiusSq += delta;
		}

		if (radiusSq > ClusterRadiusSq)
		{
			ClusterRadiusSq = radiusSq;
		}
	}
}

bool CNDClusterCentroid::Calculate_NewCenter(CNDPoint_InsideCluster * pPointArray, int32_t numOfPoints)
{
	if (calculationsCompleted == true)
	{
		return true;
	}

	for (int32_t j = 0; j < Size; j++)
	{
		pOldCenterValueArray[j] = pCenterValueArray[j];
		pCenterValueArray[j] = 0.0f;
	}

	int32_t counter = 0;

	for (int32_t i = 0; i < numOfPoints; i++)
	{
		if (centroidID != pPointArray[i].clusterID)
		{
			continue;
		}

		float *pValueArray = pPointArray[i].pValueArray;

		for (int32_t j = 0; j < Size; j++)
		{
			pCenterValueArray[j] += pValueArray[j];
		}

		counter++;
	}

	if (counter > 0)
	{
		float factor = 1.0f / static_cast<float>(counter);

		for (int32_t j = 0; j < Size; j++)
		{
			pCenterValueArray[j] *= factor;
		}
	}

	for (int32_t j = 0; j < Size; j++)
	{
		if (abs(pCenterValueArray[j] - pOldCenterValueArray[j]) > 0.01f)
		{
			return false;
		}
	}

	calculationsCompleted = true;
	return true;
}

//-----------------------------------------------------------------------------
// C1DPoint_InsideCluster
//-----------------------------------------------------------------------------

void C1DPoint_InsideCluster::Reset(void)
{
	x = 0.0f;
	clusterID = 0;
}

//-----------------------------------------------------------------------------
// C1DClusterCentroid
//-----------------------------------------------------------------------------

void C1DClusterCentroid::Set_RBF_Constant(float value)
{
	RBF_Constant = value;
}

void C1DClusterCentroid::Set_ClusterRadiusBased_RBF_Constant(float value)
{
	RBF_Constant = value * ClusterRadiusSq;
}

void C1DClusterCentroid::Reset(void)
{
	relatedValue = 0.0f;

	centerX = 0.0f;
	centerX_old = 0.0f;
	calculationsCompleted = false;
}

void C1DClusterCentroid::Reset_MeanCentroidCalculations(void)
{
	NumOfSamples = 0;
	centerX = 0.0f;
}

void C1DClusterCentroid::Translate_OriginalCenterPos(float deltaX)
{
	centerX_old = centerX;
	centerX += deltaX;
}

void C1DClusterCentroid::Undo_CenterPosTranslation(void)
{
	centerX = centerX_old;
}


void C1DClusterCentroid::Set_Centroid(C1DClusterCentroid *pCentroid)
{
	centerX = pCentroid->centerX;
	centerX_old = centerX;
	NumOfSamples = 1;
}

float C1DClusterCentroid::Calculate_RBFValue(C1DPoint_InsideCluster *pPoint)
{
	float delta = centerX - pPoint->x;
	delta *= delta;

	return exp(-RBF_Constant * delta);
}

float C1DClusterCentroid::Calculate_ClippedRBFValue(C1DPoint_InsideCluster *pPoint)
{
	float delta = centerX - pPoint->x;
	delta *= delta;

	if (delta > ClusterRadiusSq)
	{
		return 0.0f;
	}

	return exp(-RBF_Constant * delta);
}



float C1DClusterCentroid::Calculate_RBFValue(float x)
{
	float delta = centerX - x;
	delta *= delta;

	return exp(-RBF_Constant * delta);
}

float C1DClusterCentroid::Calculate_ClippedRBFValue(float x)
{
	float delta = centerX - x;
	delta *= delta;

	if (delta > ClusterRadiusSq)
	{
		return 0.0f;
	}

	return exp(-RBF_Constant * delta);
}

float C1DClusterCentroid::Calculate_DistanceSq_To_Centroid(C1DPoint_InsideCluster *pPoint)
{
	float delta = centerX - pPoint->x;
	delta *= delta;
	
	return delta;
}

float C1DClusterCentroid::Calculate_DistanceSq_To_Centroid(float x)
{
	float delta = centerX - x;
	delta *= delta;

	return delta;
}

void C1DClusterCentroid::Add_To_MeanCentroid(C1DClusterCentroid *pCentroid)
{
	if (NumOfSamples == 0)
	{
	
		centerX = pCentroid->centerX;
		centerX_old = centerX;
		NumOfSamples = 1;
		return;
	}

	NumOfSamples++;

	float weight = 1.0f / static_cast<float>(NumOfSamples);

	centerX = (1.0f - weight) * centerX + weight * pCentroid->centerX;
	centerX_old = centerX;
}

void C1DClusterCentroid::Calculate_SumOfDistancesSq_InsideCluster(C1DPoint_InsideCluster *pPointArray, int32_t numOfPoints)
{
	SumOfDistancesSq_InsideCluster = 0.0f;

	for (int32_t i = 0; i < numOfPoints; i++)
	{
		if (centroidID != pPointArray[i].clusterID)
		{
			continue;
		}

		float delta = centerX - pPointArray[i].x;
		delta *= delta;
		SumOfDistancesSq_InsideCluster += delta;

		/*float distanceSq = 0.0f;

		float delta = centerX - pPointArray[i].x;
		delta *= delta;
		distanceSq += delta;

		SumOfDistancesSq_InsideCluster += distanceSq;*/
	}
}

void C1DClusterCentroid::Calculate_ClusterRadiusSq(C1DPoint_InsideCluster * pPointArray, int32_t numOfPoints)
{
	ClusterRadiusSq = 0.0f;

	for (int32_t i = 0; i < numOfPoints; i++)
	{
		if (centroidID != pPointArray[i].clusterID)
		{
			continue;
		}

		float radiusSq = 0.0f;

		float delta = centerX - pPointArray[i].x;
		delta *= delta;
		radiusSq += delta;

		if (radiusSq > ClusterRadiusSq)
		{
			ClusterRadiusSq = radiusSq;
		}
	}
}

bool C1DClusterCentroid::Calculate_NewCenter(C1DPoint_InsideCluster * pPointArray, int32_t numOfPoints)
{
	if (calculationsCompleted == true)
	{
		return true;
	}

	centerX_old = centerX;

	centerX = 0;

	int32_t counter = 0;

	for (int32_t i = 0; i < numOfPoints; i++)
	{
		if (centroidID != pPointArray[i].clusterID)
		{
			continue;
		}

		centerX += pPointArray[i].x;

		counter++;
	}

	if (counter > 0)
	{
		float factor = 1.0f / static_cast<float>(counter);
		centerX *= factor;
	}

	if (abs(centerX - centerX_old) < 0.01f)
	{
		calculationsCompleted = true;
		return true;
	}

	return false;
}

//-----------------------------------------------------------------------------
// class C2DPoint_InsideCluster
//-----------------------------------------------------------------------------

void C2DPoint_InsideCluster::Reset(void)
{
	relatedValue = 0.0f;

	x = 0.0f;
	y = 0.0f;
	clusterID = 0;
}

//-----------------------------------------------------------------------------
// class C2DClusterCentroid
//-----------------------------------------------------------------------------

void C2DClusterCentroid::Set_RBF_Constant(float value)
{
	RBF_Constant = value;
}

void C2DClusterCentroid::Set_ClusterRadiusBased_RBF_Constant(float value)
{
	RBF_Constant = value * ClusterRadiusSq;
}

void C2DClusterCentroid::Reset(void)
{
	relatedValue = 0.0f;

	centerX = 0.0f;
	centerY = 0.0f;
	centerX_old = 0.0f;
	centerY_old = 0.0f;
	calculationsCompleted = false;
}

void C2DClusterCentroid::Reset_MeanCentroidCalculations(void)
{
	NumOfSamples = 0;
	centerX = 0.0f;
	centerY = 0.0f;
}

void C2DClusterCentroid::Translate_OriginalCenterPos(float deltaX, float deltaY)
{
	centerX_old = centerX;
	centerX += deltaX;

	centerY_old = centerY;
	centerY += deltaY;
}

void C2DClusterCentroid::Undo_CenterPosTranslation(void)
{
	centerX = centerX_old;
	centerY = centerY_old;
}

void C2DClusterCentroid::Set_Centroid(C2DClusterCentroid *pCentroid)
{
	centerX = pCentroid->centerX;
	centerY = pCentroid->centerY;
	centerX_old = centerX;
	centerY_old = centerY;
	NumOfSamples = 1;
}

float C2DClusterCentroid::Calculate_RBFValue(C2DPoint_InsideCluster *pPoint)
{
	float distSq = 0.0f;

	float delta = centerX - pPoint->x;
	delta *= delta;
	distSq += delta;

	delta = centerY - pPoint->y;
	delta *= delta;
	distSq += delta;

	return exp(-RBF_Constant * distSq);
}

float C2DClusterCentroid::Calculate_ClippedRBFValue(C2DPoint_InsideCluster *pPoint)
{
	float distSq = 0.0f;

	float delta = centerX - pPoint->x;
	delta *= delta;
	distSq += delta;

	delta = centerY - pPoint->y;
	delta *= delta;
	distSq += delta;

	if (distSq > ClusterRadiusSq)
	{
		return 0.0f;
	}

	return exp(-RBF_Constant * distSq);
}



float C2DClusterCentroid::Calculate_RBFValue(float x, float y)
{
	float distSq = 0.0f;

	float delta = centerX - x;
	delta *= delta;
	distSq += delta;

	delta = centerY - y;
	delta *= delta;
	distSq += delta;

	return exp(-RBF_Constant * distSq);
}

float C2DClusterCentroid::Calculate_ClippedRBFValue(float x, float y)
{
	float distSq = 0.0f;

	float delta = centerX - x;
	delta *= delta;
	distSq += delta;

	delta = centerY - y;
	delta *= delta;
	distSq += delta;

	if (distSq > ClusterRadiusSq)
	{
		return 0.0f;
	}

	return exp(-RBF_Constant * distSq);
}

float C2DClusterCentroid::Calculate_DistanceSq_To_Centroid(C2DPoint_InsideCluster *pPoint)
{
	float distSq = 0.0f;

	float delta = centerX - pPoint->x;
	delta *= delta;
	distSq += delta;

	delta = centerY - pPoint->y;
	delta *= delta;
	distSq += delta;

	return distSq;
}

float C2DClusterCentroid::Calculate_DistanceSq_To_Centroid(float x, float y)
{
	float distSq = 0.0f;

	float delta = centerX - x;
	delta *= delta;
	distSq += delta;

	delta = centerY - y;
	delta *= delta;
	distSq += delta;


	return distSq;
}

void C2DClusterCentroid::Add_To_MeanCentroid(C2DClusterCentroid *pCentroid)
{
	if (NumOfSamples == 0)
	{
		centerX = pCentroid->centerX;
		centerY = pCentroid->centerY;
		centerX_old = centerX;
		centerY_old = centerY;
		NumOfSamples = 1;
		return;
	}

	NumOfSamples++;

	float weight = 1.0f / static_cast<float>(NumOfSamples);
	float oneMinusWeight = 1.0f - weight;

	centerX = oneMinusWeight * centerX + weight * pCentroid->centerX;
	centerX_old = centerX;

	centerY = oneMinusWeight * centerY + weight * pCentroid->centerY;
	centerY_old = centerY;
}


void C2DClusterCentroid::Calculate_SumOfDistancesSq_InsideCluster(C2DPoint_InsideCluster *pPointArray, int32_t numOfPoints)
{
	SumOfDistancesSq_InsideCluster = 0.0f;

	for (int32_t i = 0; i < numOfPoints; i++)
	{
		if (centroidID != pPointArray[i].clusterID)
		{
			continue;
		}

		float delta = centerX - pPointArray[i].x;
		delta *= delta;
		SumOfDistancesSq_InsideCluster += delta;

		delta = centerY - pPointArray[i].y;
		delta *= delta;
		SumOfDistancesSq_InsideCluster += delta;

		/*float distanceSq = 0.0f;

		float delta = centerX - pPointArray[i].x;
		delta *= delta;
		distanceSq += delta;

		delta = centerY - pPointArray[i].y;
		delta *= delta;
		distanceSq += delta;

		SumOfDistancesSq_InsideCluster += distanceSq;*/
	}
}

void C2DClusterCentroid::Calculate_ClusterRadiusSq(C2DPoint_InsideCluster * pPointArray, int32_t numOfPoints)
{
	ClusterRadiusSq = 0.0f;

	for (int32_t i = 0; i < numOfPoints; i++)
	{
		if (centroidID != pPointArray[i].clusterID)
		{
			continue;
		}

		float radiusSq = 0.0f;

		float delta = centerX - pPointArray[i].x;
		delta *= delta;
		radiusSq += delta;

		delta = centerY - pPointArray[i].y;
		delta *= delta;
		radiusSq += delta;

		if (radiusSq > ClusterRadiusSq)
		{
			ClusterRadiusSq = radiusSq;
		}
	}
}

bool C2DClusterCentroid::Calculate_NewCenter(C2DPoint_InsideCluster * pPointArray, int32_t numOfPoints)
{
	if (calculationsCompleted == true)
	{
		return true;
	}

	centerX_old = centerX;
	centerY_old = centerY;

	centerX = 0;
	centerY = 0;

	int32_t counter = 0;

	for (int32_t i = 0; i < numOfPoints; i++)
	{
		if (centroidID != pPointArray[i].clusterID)
		{
			continue;
		}

		centerX += pPointArray[i].x;
		centerY += pPointArray[i].y;

		counter++;
	}

	if (counter > 0)
	{
		float factor = 1.0f / static_cast<float>(counter);
		centerX *= factor;
		centerY *= factor;
	}

	if (abs(centerX - centerX_old) < 0.01f && abs(centerY - centerY_old) < 0.01f)
	{
		calculationsCompleted = true;
		return true;
	}

	return false;
}

//-----------------------------------------------------------------------------
// class C3DPoint_InsideCluster
//-----------------------------------------------------------------------------

void C3DPoint_InsideCluster::Reset(void)
{
	relatedValue = 0.0f;

	x = 0.0f;
	y = 0.0f;
	z = 0.0f;
	clusterID = 0;
}

//-----------------------------------------------------------------------------
// class C3DClusterCentroid
//-----------------------------------------------------------------------------

void C3DClusterCentroid::Set_RBF_Constant(float value)
{
	RBF_Constant = value;
}

void C3DClusterCentroid::Set_ClusterRadiusBased_RBF_Constant(float value)
{
	RBF_Constant = value * ClusterRadiusSq;
}

void C3DClusterCentroid::Reset(void)
{
	relatedValue = 0.0f;

	centerX = 0.0f;
	centerY = 0.0f;
	centerZ = 0.0f;
	centerX_old = 0.0f;
	centerY_old = 0.0f;
	centerZ_old = 0.0f;
	calculationsCompleted = false;
}

void C3DClusterCentroid::Reset_MeanCentroidCalculations(void)
{
	NumOfSamples = 0;
	centerX = 0.0f;
	centerY = 0.0f;
	centerZ = 0.0f;
}

void C3DClusterCentroid::Translate_OriginalCenterPos(float deltaX, float deltaY, float deltaZ)
{
	centerX_old = centerX;
	centerX += deltaX;

	centerY_old = centerY;
	centerY += deltaY;

	centerZ_old = centerZ;
	centerZ += deltaZ;
}

void C3DClusterCentroid::Undo_CenterPosTranslation(void)
{
	centerX = centerX_old;
	centerY = centerY_old;
	centerZ = centerZ_old;
}

void C3DClusterCentroid::Set_Centroid(C3DClusterCentroid *pCentroid)
{
	centerX = pCentroid->centerX;
	centerY = pCentroid->centerY;
	centerZ = pCentroid->centerZ;
	centerX_old = centerX;
	centerY_old = centerY;
	centerZ_old = centerZ;
	NumOfSamples = 1;
}

float C3DClusterCentroid::Calculate_RBFValue(C3DPoint_InsideCluster *pPoint)
{
	float distSq = 0.0f;

	float delta = centerX - pPoint->x;
	delta *= delta;
	distSq += delta;

	delta = centerY - pPoint->y;
	delta *= delta;
	distSq += delta;

	delta = centerZ - pPoint->z;
	delta *= delta;
	distSq += delta;

	return exp(-RBF_Constant * distSq);
}

float C3DClusterCentroid::Calculate_ClippedRBFValue(C3DPoint_InsideCluster *pPoint)
{
	float distSq = 0.0f;

	float delta = centerX - pPoint->x;
	delta *= delta;
	distSq += delta;

	delta = centerY - pPoint->y;
	delta *= delta;
	distSq += delta;

	delta = centerZ - pPoint->z;
	delta *= delta;
	distSq += delta;

	if (distSq > ClusterRadiusSq)
	{
		return 0.0f;
	}

	return exp(-RBF_Constant * distSq);
}



float C3DClusterCentroid::Calculate_RBFValue(float x, float y, float z)
{
	float distSq = 0.0f;

	float delta = centerX - x;
	delta *= delta;
	distSq += delta;

	delta = centerY - y;
	delta *= delta;
	distSq += delta;

	delta = centerZ - z;
	delta *= delta;
	distSq += delta;

	return exp(-RBF_Constant * distSq);
}

float C3DClusterCentroid::Calculate_ClippedRBFValue(float x, float y, float z)
{
	float distSq = 0.0f;

	float delta = centerX - x;
	delta *= delta;
	distSq += delta;

	delta = centerY - y;
	delta *= delta;
	distSq += delta;

	delta = centerZ - z;
	delta *= delta;
	distSq += delta;

	if (distSq > ClusterRadiusSq)
	{
		return 0.0f;
	}

	return exp(-RBF_Constant * distSq);
}

float C3DClusterCentroid::Calculate_DistanceSq_To_Centroid(C3DPoint_InsideCluster *pPoint)
{
	float distSq = 0.0f;

	float delta = centerX - pPoint->x;
	delta *= delta;
	distSq += delta;

	delta = centerY - pPoint->y;
	delta *= delta;
	distSq += delta;

	delta = centerZ - pPoint->z;
	delta *= delta;
	distSq += delta;

	return distSq;
}

float C3DClusterCentroid::Calculate_DistanceSq_To_Centroid(float x, float y, float z)
{
	float distSq = 0.0f;

	float delta = centerX - x;
	delta *= delta;
	distSq += delta;

	delta = centerY - y;
	delta *= delta;
	distSq += delta;

	delta = centerZ - z;
	delta *= delta;
	distSq += delta;

	return distSq;
}

void C3DClusterCentroid::Add_To_MeanCentroid(C3DClusterCentroid *pCentroid)
{
	if (NumOfSamples == 0)
	{

		centerX = pCentroid->centerX;
		centerY = pCentroid->centerY;
		centerZ = pCentroid->centerZ;
		centerX_old = centerX;
		centerY_old = centerY;
		centerZ_old = centerZ;
		NumOfSamples = 1;
		return;
	}

	NumOfSamples++;

	float weight = 1.0f / static_cast<float>(NumOfSamples);
	float oneMinusWeight = 1.0f - weight;

	centerX = oneMinusWeight * centerX + weight * pCentroid->centerX;
	centerX_old = centerX;

	centerY = oneMinusWeight * centerY + weight * pCentroid->centerY;
	centerY_old = centerY;

	centerZ = oneMinusWeight * centerZ + weight * pCentroid->centerZ;
	centerZ_old = centerZ;
}

void C3DClusterCentroid::Calculate_SumOfDistancesSq_InsideCluster(C3DPoint_InsideCluster *pPointArray, int32_t numOfPoints)
{
	SumOfDistancesSq_InsideCluster = 0.0f;

	for (int32_t i = 0; i < numOfPoints; i++)
	{
		if (centroidID != pPointArray[i].clusterID)
		{
			continue;
		}

		float delta = centerX - pPointArray[i].x;
		delta *= delta;
		SumOfDistancesSq_InsideCluster += delta;

		delta = centerY - pPointArray[i].y;
		delta *= delta;
		SumOfDistancesSq_InsideCluster += delta;

		delta = centerZ - pPointArray[i].z;
		delta *= delta;
		SumOfDistancesSq_InsideCluster += delta;

		/*float distanceSq = 0.0f;

		float delta = centerX - pPointArray[i].x;
		delta *= delta;
		distanceSq += delta;

		delta = centerY - pPointArray[i].y;
		delta *= delta;
		distanceSq += delta;

		delta = centerZ - pPointArray[i].z;
		delta *= delta;
		distanceSq += delta;

		SumOfDistancesSq_InsideCluster += distanceSq;*/
	}
}

void C3DClusterCentroid::Calculate_ClusterRadiusSq(C3DPoint_InsideCluster * pPointArray, int32_t numOfPoints)
{
	ClusterRadiusSq = 0.0f;

	for (int32_t i = 0; i < numOfPoints; i++)
	{
		if (centroidID != pPointArray[i].clusterID)
		{
			continue;
		}

		float radiusSq = 0.0f;

		float delta = centerX - pPointArray[i].x;
		delta *= delta;
		radiusSq += delta;

		delta = centerY - pPointArray[i].y;
		delta *= delta;
		radiusSq += delta;

		delta = centerZ - pPointArray[i].z;
		delta *= delta;
		radiusSq += delta;
		
		if (radiusSq > ClusterRadiusSq)
		{
			ClusterRadiusSq = radiusSq;
		}
	}
}

bool C3DClusterCentroid::Calculate_NewCenter(C3DPoint_InsideCluster * pPointArray, int32_t numOfPoints)
{
	if (calculationsCompleted == true)
	{
		return true;
	}

	centerX_old = centerX;
	centerY_old = centerY;
	centerZ_old = centerZ;

	centerX = 0;
	centerY = 0;
	centerZ = 0;

	int32_t counter = 0;

	for (int32_t i = 0; i < numOfPoints; i++)
	{
		if (centroidID != pPointArray[i].clusterID)
		{
			continue;
		}

		centerX += pPointArray[i].x;
		centerY += pPointArray[i].y;
		centerZ += pPointArray[i].z;

		counter++;
	}

	if (counter > 0)
	{
		float factor = 1.0f / static_cast<float>(counter);
		centerX *= factor;
		centerY *= factor;
		centerZ *= factor;
	}

	if (abs(centerX - centerX_old) < 0.01f && abs(centerY - centerY_old) < 0.01f && abs(centerZ - centerZ_old) < 0.01f)
	{
		calculationsCompleted = true;
		return true;
	}

	return false;
}

//-----------------------------------------------------------------------------
// class CClusterArray_SumOfRBFValues
//-----------------------------------------------------------------------------

CClusterArray_SumOfRBFValues::CClusterArray_SumOfRBFValues()
{}

CClusterArray_SumOfRBFValues::~CClusterArray_SumOfRBFValues()
{
	delete[] pSumOfRBFValuesArray;
	pSumOfRBFValuesArray = nullptr;

	delete[]pBestClusterCounterArray;
	pBestClusterCounterArray = nullptr;
}

void CClusterArray_SumOfRBFValues::Initialize(int32_t numOfClusters)
{
	delete[] pSumOfRBFValuesArray;
	pSumOfRBFValuesArray = nullptr;

	delete[]pBestClusterCounterArray;
	pBestClusterCounterArray = nullptr;

	NumOfClusters = numOfClusters;

	pSumOfRBFValuesArray = new (std::nothrow) float[numOfClusters];
	pBestClusterCounterArray = new (std::nothrow) int32_t[numOfClusters];

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		pSumOfRBFValuesArray[i] = 0.0f;
		pBestClusterCounterArray[i] = 0;
	}
}

void CClusterArray_SumOfRBFValues::Reset_Data(void)
{
	for (int32_t i = 0; i < NumOfClusters; i++)
	{
		pSumOfRBFValuesArray[i] = 0.0f;
		pBestClusterCounterArray[i] = 0;
	}
}

float CClusterArray_SumOfRBFValues::Get_MinRBFValueSum(void)
{
	float minSum = 1000000.0f;

	for (int32_t i = 0; i < NumOfClusters; i++)
	{
		if (pSumOfRBFValuesArray[i] < minSum)
		{
			minSum = pSumOfRBFValuesArray[i];
		}
	}

	return minSum;
}

void CClusterArray_SumOfRBFValues::Get_MinRBFValueSum_And_BelongingClusterID(float *pOutSum, int32_t *pOutClusterID)
{
	float minSum = 1000000.0f;
	int32_t belongingID = 0;

	for (int32_t i = 0; i < NumOfClusters; i++)
	{
		if (pSumOfRBFValuesArray[i] < minSum)
		{
			minSum = pSumOfRBFValuesArray[i];
			belongingID = i;
		}
	}

	*pOutSum = minSum;
	*pOutClusterID = belongingID;
}


float CClusterArray_SumOfRBFValues::Get_MaxRBFValueSum(void)
{
	float maxSum = 0.0f;

	for (int32_t i = 0; i < NumOfClusters; i++)
	{
		if (pSumOfRBFValuesArray[i] > maxSum)
		{
			maxSum = pSumOfRBFValuesArray[i];
		}
	}

	return maxSum;
}

void CClusterArray_SumOfRBFValues::Get_MaxRBFValueSum_And_BelongingClusterID(float *pOutSum, int32_t *pOutClusterID)
{
	float maxSum = 0.0f;
	int32_t belongingID = 0;

	for (int32_t i = 0; i < NumOfClusters; i++)
	{
		if (pSumOfRBFValuesArray[i] > maxSum)
		{
			maxSum = pSumOfRBFValuesArray[i];
			belongingID = i;
		}
	}

	*pOutSum = maxSum;
	*pOutClusterID = belongingID;
}

//-----------------------------------------------------------------------------
// class CClusterPattern
//-----------------------------------------------------------------------------

CClusterPattern::CClusterPattern()
{}

CClusterPattern::~CClusterPattern()
{
	delete[] pIDList_MinPopulatedClusters;
	pIDList_MinPopulatedClusters = nullptr;

	delete[] pIDList_MaxPopulatedClusters;
	pIDList_MaxPopulatedClusters = nullptr;
}

void CClusterPattern::Initialize_IDList_Of_MinPopulatedClusters(int32_t numOfIDs)
{
	delete[] pIDList_MinPopulatedClusters;
	pIDList_MinPopulatedClusters = nullptr;

	NumOfIDs_MinPopulatedClusters = numOfIDs;

	pIDList_MinPopulatedClusters = new (std::nothrow) int32_t[numOfIDs];

	for (int32_t i = 0; i < numOfIDs; i++)
	{
		pIDList_MinPopulatedClusters[i] = 0;
	}

}

void CClusterPattern::Initialize_IDList_Of_MinPopulatedClusters(int32_t numOfIDs, int32_t *pIDList)
{
	delete[] pIDList_MinPopulatedClusters;
	pIDList_MinPopulatedClusters = nullptr;

	NumOfIDs_MinPopulatedClusters = numOfIDs;

	pIDList_MinPopulatedClusters = new (std::nothrow) int32_t[numOfIDs];

	for (int32_t i = 0; i < numOfIDs; i++)
	{
		pIDList_MinPopulatedClusters[i] = pIDList[i];
	}
}

void CClusterPattern::Initialize_IDList_Of_MaxPopulatedClusters(int32_t numOfIDs)
{
	delete[] pIDList_MaxPopulatedClusters;
	pIDList_MaxPopulatedClusters = nullptr;

	NumOfIDs_MaxPopulatedClusters = numOfIDs;

	pIDList_MaxPopulatedClusters = new (std::nothrow) int32_t[numOfIDs];

	for (int32_t i = 0; i < numOfIDs; i++)
	{
		pIDList_MaxPopulatedClusters[i] = 0;
	}
}

void CClusterPattern::Initialize_IDList_Of_MaxPopulatedClusters(int32_t numOfIDs, int32_t *pIDList)
{
	delete[] pIDList_MaxPopulatedClusters;
	pIDList_MaxPopulatedClusters = nullptr;

	NumOfIDs_MaxPopulatedClusters = numOfIDs;

	pIDList_MaxPopulatedClusters = new (std::nothrow) int32_t[numOfIDs];

	for (int32_t i = 0; i < numOfIDs; i++)
	{
		pIDList_MaxPopulatedClusters[i] = pIDList[i];
	}
}

bool CClusterPattern::Identify_Pattern(CClusterArray_SumOfRBFValues *pClusterArray_SumOfRBFValues, float upperThreshold_MinPopulatedClusters, float lowerThreshold_MaxPopulatedClusters)
{
	for (int32_t i = 0; i < NumOfIDs_MinPopulatedClusters; i++)
	{
		float value = pClusterArray_SumOfRBFValues->pSumOfRBFValuesArray[pIDList_MinPopulatedClusters[i]];

		if (value > upperThreshold_MinPopulatedClusters)
		{
			return false;
		}
	}

	for (int32_t i = 0; i < NumOfIDs_MaxPopulatedClusters; i++)
	{
		float value = pClusterArray_SumOfRBFValues->pSumOfRBFValuesArray[pIDList_MaxPopulatedClusters[i]];

		if (value < lowerThreshold_MaxPopulatedClusters)
		{
			return false;
		}
	}

	return true;
}

bool CClusterPattern::Identify_Pattern2(CClusterArray_SumOfRBFValues *pClusterArray_SumOfRBFValues, float upperThreshold_MinPopulatedClusters, float lowerThreshold_MaxPopulatedClusters)
{
	for (int32_t i = 0; i < NumOfIDs_MinPopulatedClusters; i++)
	{
		int32_t id = pIDList_MinPopulatedClusters[i];

		int32_t counter = pClusterArray_SumOfRBFValues->pBestClusterCounterArray[id];

		if (counter > 0)
		{
			float value = pClusterArray_SumOfRBFValues->pSumOfRBFValuesArray[id] / static_cast<float>(counter);

			if (value > upperThreshold_MinPopulatedClusters)
			{
				return false;
			}
		}
	}

	for (int32_t i = 0; i < NumOfIDs_MaxPopulatedClusters; i++)
	{
		int32_t id = pIDList_MaxPopulatedClusters[i];

		int32_t counter = pClusterArray_SumOfRBFValues->pBestClusterCounterArray[id];

		if (counter < 1)
		{
			return false;
		}

		float value = pClusterArray_SumOfRBFValues->pSumOfRBFValuesArray[id] / static_cast<float>(counter);

		if (value < lowerThreshold_MaxPopulatedClusters)
		{
			return false;
		}
	}

	return true;
}

void Translate_OriginalClusterCenterPositions(C1DClusterCentroid *pInOutCentroidArray, int32_t numOfClusters, float deltaX)
{
	for (int32_t i = 0; i < numOfClusters; i++)
	{
		pInOutCentroidArray[i].Translate_OriginalCenterPos(deltaX);
	}
}

void Undo_ClusterCenterPosTranslations(C1DClusterCentroid *pInOutCentroidArray, int32_t numOfClusters)
{
	for (int32_t i = 0; i < numOfClusters; i++)
	{
		pInOutCentroidArray[i].Undo_CenterPosTranslation();
	}
}

void Translate_OriginalClusterCenterPositions(C2DClusterCentroid *pInOutCentroidArray, int32_t numOfClusters, float deltaX, float deltaY)
{
	for (int32_t i = 0; i < numOfClusters; i++)
	{
		pInOutCentroidArray[i].Translate_OriginalCenterPos(deltaX, deltaY);
	}
}

void Undo_ClusterCenterPosTranslations(C2DClusterCentroid *pInOutCentroidArray, int32_t numOfClusters)
{
	for (int32_t i = 0; i < numOfClusters; i++)
	{
		pInOutCentroidArray[i].Undo_CenterPosTranslation();
	}
}

void Translate_OriginalClusterCenterPositions(C3DClusterCentroid *pInOutCentroidArray, int32_t numOfClusters, float deltaX, float deltaY, float deltaZ)
{
	for (int32_t i = 0; i < numOfClusters; i++)
	{
		pInOutCentroidArray[i].Translate_OriginalCenterPos(deltaX, deltaY, deltaZ);
	}
}

void Undo_ClusterCenterPosTranslations(C3DClusterCentroid *pInOutCentroidArray, int32_t numOfClusters)
{
	for (int32_t i = 0; i < numOfClusters; i++)
	{
		pInOutCentroidArray[i].Undo_CenterPosTranslation();
	}
}



void Get_Best_And_Worst_RBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster, float *pOutWorstRBFValue, int32_t *pOutIDofWorstCluster,
	float inCoordX, C1DClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	float bestRBFValue = 0.0f;
	float worstRBFValue = 1.0f;

	int32_t IDofBestCluster = 0;
	int32_t IDofWorstCluster = 0;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float rbfValue = pInCentroidArray[i].Calculate_RBFValue(inCoordX);

		if (rbfValue > bestRBFValue)
		{
			bestRBFValue = rbfValue;
			IDofBestCluster = i;
		}

		if (rbfValue < worstRBFValue)
		{
			worstRBFValue = rbfValue;
			IDofWorstCluster = i;
		}
	}

	*pOutBestRBFValue =bestRBFValue;
	*pOutWorstRBFValue = worstRBFValue;

	*pOutIDofBestCluster = IDofBestCluster;
	*pOutIDofWorstCluster = IDofWorstCluster;
}

void Get_Best_And_Worst_ClippedRBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster, float *pOutWorstRBFValue, int32_t *pOutIDofWorstCluster,
	float inCoordX, C1DClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	float bestRBFValue = 0.0f;
	float worstRBFValue = 1.0f;

	int32_t IDofBestCluster = 0;
	int32_t IDofWorstCluster = 0;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float rbfValue = pInCentroidArray[i].Calculate_ClippedRBFValue(inCoordX);

		if (rbfValue > bestRBFValue)
		{
			bestRBFValue = rbfValue;
			IDofBestCluster = i;
		}

		if (rbfValue < worstRBFValue)
		{
			worstRBFValue = rbfValue;
			IDofWorstCluster = i;
		}
	}

	*pOutBestRBFValue = bestRBFValue;
	*pOutWorstRBFValue = worstRBFValue;

	*pOutIDofBestCluster = IDofBestCluster;
	*pOutIDofWorstCluster = IDofWorstCluster;
}

void Get_Best_RBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster, 
	float inCoordX, C1DClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	float bestRBFValue = 0.0f;
	int32_t IDofBestCluster = 0;
	
	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float rbfValue = pInCentroidArray[i].Calculate_RBFValue(inCoordX);

		if (rbfValue > bestRBFValue)
		{
			bestRBFValue = rbfValue;
			IDofBestCluster = i;
		}
	}

	*pOutBestRBFValue = bestRBFValue;
	*pOutIDofBestCluster = IDofBestCluster;
}

void Get_Best_ClippedRBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster,
	float inCoordX, C1DClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	float bestRBFValue = 0.0f;
	int32_t IDofBestCluster = 0;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float rbfValue = pInCentroidArray[i].Calculate_ClippedRBFValue(inCoordX);

		if (rbfValue > bestRBFValue)
		{
			bestRBFValue = rbfValue;
			IDofBestCluster = i;
		}
	}

	*pOutBestRBFValue = bestRBFValue;
	*pOutIDofBestCluster = IDofBestCluster;
}

void Get_Best_And_Worst_RBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster, float *pOutWorstRBFValue, int32_t *pOutIDofWorstCluster,
	float inCoordX, float inCoordY, C2DClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	float bestRBFValue = 0.0f;
	float worstRBFValue = 1.0f;

	int32_t IDofBestCluster = 0;
	int32_t IDofWorstCluster = 0;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float rbfValue = pInCentroidArray[i].Calculate_RBFValue(inCoordX, inCoordY);

		if (rbfValue > bestRBFValue)
		{
			bestRBFValue = rbfValue;
			IDofBestCluster = i;
		}

		if (rbfValue < worstRBFValue)
		{
			worstRBFValue = rbfValue;
			IDofWorstCluster = i;
		}
	}

	*pOutBestRBFValue = bestRBFValue;
	*pOutWorstRBFValue = worstRBFValue;

	*pOutIDofBestCluster = IDofBestCluster;
	*pOutIDofWorstCluster = IDofWorstCluster;
}

void Get_Best_And_Worst_ClippedRBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster, float *pOutWorstRBFValue, int32_t *pOutIDofWorstCluster,
	float inCoordX, float inCoordY, C2DClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	float bestRBFValue = 0.0f;
	float worstRBFValue = 1.0f;

	int32_t IDofBestCluster = 0;
	int32_t IDofWorstCluster = 0;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float rbfValue = pInCentroidArray[i].Calculate_ClippedRBFValue(inCoordX, inCoordY);

		if (rbfValue > bestRBFValue)
		{
			bestRBFValue = rbfValue;
			IDofBestCluster = i;
		}

		if (rbfValue < worstRBFValue)
		{
			worstRBFValue = rbfValue;
			IDofWorstCluster = i;
		}
	}

	*pOutBestRBFValue = bestRBFValue;
	*pOutWorstRBFValue = worstRBFValue;

	*pOutIDofBestCluster = IDofBestCluster;
	*pOutIDofWorstCluster = IDofWorstCluster;
}

void Get_Best_RBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster, 
	float inCoordX, float inCoordY, C2DClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	float bestRBFValue = 0.0f;
	int32_t IDofBestCluster = 0;
	
	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float rbfValue = pInCentroidArray[i].Calculate_RBFValue(inCoordX, inCoordY);

		if (rbfValue > bestRBFValue)
		{
			bestRBFValue = rbfValue;
			IDofBestCluster = i;
		}
	}

	*pOutBestRBFValue = bestRBFValue;
	*pOutIDofBestCluster = IDofBestCluster;
}

void Get_Best_ClippedRBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster,
	float inCoordX, float inCoordY, C2DClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	float bestRBFValue = 0.0f;
	int32_t IDofBestCluster = 0;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float rbfValue = pInCentroidArray[i].Calculate_ClippedRBFValue(inCoordX, inCoordY);

		if (rbfValue > bestRBFValue)
		{
			bestRBFValue = rbfValue;
			IDofBestCluster = i;
		}
	}

	*pOutBestRBFValue = bestRBFValue;
	*pOutIDofBestCluster = IDofBestCluster;
}

void Get_Best_And_Worst_RBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster, float *pOutWorstRBFValue, int32_t *pOutIDofWorstCluster,
	float inCoordX, float inCoordY, float inCoordZ, C3DClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	float bestRBFValue = 0.0f;
	float worstRBFValue = 1.0f;

	int32_t IDofBestCluster = 0;
	int32_t IDofWorstCluster = 0;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float rbfValue = pInCentroidArray[i].Calculate_RBFValue(inCoordX, inCoordY, inCoordZ);

		if (rbfValue > bestRBFValue)
		{
			bestRBFValue = rbfValue;
			IDofBestCluster = i;
		}

		if (rbfValue < worstRBFValue)
		{
			worstRBFValue = rbfValue;
			IDofWorstCluster = i;
		}
	}

	*pOutBestRBFValue = bestRBFValue;
	*pOutWorstRBFValue = worstRBFValue;

	*pOutIDofBestCluster = IDofBestCluster;
	*pOutIDofWorstCluster = IDofWorstCluster;
}

void Get_Best_And_Worst_ClippedRBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster, float *pOutWorstRBFValue, int32_t *pOutIDofWorstCluster,
	float inCoordX, float inCoordY, float inCoordZ, C3DClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	float bestRBFValue = 0.0f;
	float worstRBFValue = 1.0f;

	int32_t IDofBestCluster = 0;
	int32_t IDofWorstCluster = 0;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float rbfValue = pInCentroidArray[i].Calculate_ClippedRBFValue(inCoordX, inCoordY, inCoordZ);

		if (rbfValue > bestRBFValue)
		{
			bestRBFValue = rbfValue;
			IDofBestCluster = i;
		}

		if (rbfValue < worstRBFValue)
		{
			worstRBFValue = rbfValue;
			IDofWorstCluster = i;
		}
	}

	*pOutBestRBFValue = bestRBFValue;
	*pOutWorstRBFValue = worstRBFValue;

	*pOutIDofBestCluster = IDofBestCluster;
	*pOutIDofWorstCluster = IDofWorstCluster;
}

void Get_Best_RBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster, 
	float inCoordX, float inCoordY, float inCoordZ, C3DClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	float bestRBFValue = 0.0f;
	int32_t IDofBestCluster = 0;
	
	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float rbfValue = pInCentroidArray[i].Calculate_RBFValue(inCoordX, inCoordY, inCoordZ);

		if (rbfValue > bestRBFValue)
		{
			bestRBFValue = rbfValue;
			IDofBestCluster = i;
		}
	}

	*pOutBestRBFValue = bestRBFValue;
	*pOutIDofBestCluster = IDofBestCluster;
}

void Get_Best_ClippedRBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster,
	float inCoordX, float inCoordY, float inCoordZ, C3DClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	float bestRBFValue = 0.0f;
	int32_t IDofBestCluster = 0;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float rbfValue = pInCentroidArray[i].Calculate_ClippedRBFValue(inCoordX, inCoordY, inCoordZ);

		if (rbfValue > bestRBFValue)
		{
			bestRBFValue = rbfValue;
			IDofBestCluster = i;
		}
	}

	*pOutBestRBFValue = bestRBFValue;
	*pOutIDofBestCluster = IDofBestCluster;
}

void Get_Best_And_Worst_RBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster, float *pOutWorstRBFValue, int32_t *pOutIDofWorstCluster,
	C3DPoint_InsideCluster *pInPoint, C3DClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	float bestRBFValue = 0.0f;
	float worstRBFValue = 1.0f;

	int32_t IDofBestCluster = 0;
	int32_t IDofWorstCluster = 0;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float rbfValue = pInCentroidArray[i].Calculate_RBFValue(pInPoint);

		if (rbfValue > bestRBFValue)
		{
			bestRBFValue = rbfValue;
			IDofBestCluster = i;
		}

		if (rbfValue < worstRBFValue)
		{
			worstRBFValue = rbfValue;
			IDofWorstCluster = i;
		}
	}

	*pOutBestRBFValue = bestRBFValue;
	*pOutWorstRBFValue = worstRBFValue;

	*pOutIDofBestCluster = IDofBestCluster;
	*pOutIDofWorstCluster = IDofWorstCluster;
}

void Get_Best_And_Worst_ClippedRBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster, float *pOutWorstRBFValue, int32_t *pOutIDofWorstCluster,
	C3DPoint_InsideCluster *pInPoint, C3DClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	float bestRBFValue = 0.0f;
	float worstRBFValue = 1.0f;

	int32_t IDofBestCluster = 0;
	int32_t IDofWorstCluster = 0;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float rbfValue = pInCentroidArray[i].Calculate_ClippedRBFValue(pInPoint);

		if (rbfValue > bestRBFValue)
		{
			bestRBFValue = rbfValue;
			IDofBestCluster = i;
		}

		if (rbfValue < worstRBFValue)
		{
			worstRBFValue = rbfValue;
			IDofWorstCluster = i;
		}
	}

	*pOutBestRBFValue = bestRBFValue;
	*pOutWorstRBFValue = worstRBFValue;

	*pOutIDofBestCluster = IDofBestCluster;
	*pOutIDofWorstCluster = IDofWorstCluster;
}

void Get_Best_RBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster,
	C3DPoint_InsideCluster *pInPoint, C3DClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	float bestRBFValue = 0.0f;
	int32_t IDofBestCluster = 0;
	

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float rbfValue = pInCentroidArray[i].Calculate_RBFValue(pInPoint);

		if (rbfValue > bestRBFValue)
		{
			bestRBFValue = rbfValue;
			IDofBestCluster = i;
		}
	}

	*pOutBestRBFValue = bestRBFValue;
	*pOutIDofBestCluster = IDofBestCluster;
}

void Get_Best_ClippedRBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster,
	C3DPoint_InsideCluster *pInPoint, C3DClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	float bestRBFValue = 0.0f;
	int32_t IDofBestCluster = 0;


	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float rbfValue = pInCentroidArray[i].Calculate_ClippedRBFValue(pInPoint);

		if (rbfValue > bestRBFValue)
		{
			bestRBFValue = rbfValue;
			IDofBestCluster = i;
		}
	}

	*pOutBestRBFValue = bestRBFValue;
	*pOutIDofBestCluster = IDofBestCluster;
}

void Get_Best_And_Worst_RBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster, float *pOutWorstRBFValue, int32_t *pOutIDofWorstCluster,
	C2DPoint_InsideCluster *pInPoint, C2DClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	float bestRBFValue = 0.0f;
	float worstRBFValue = 1.0f;

	int32_t IDofBestCluster = 0;
	int32_t IDofWorstCluster = 0;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float rbfValue = pInCentroidArray[i].Calculate_RBFValue(pInPoint);

		if (rbfValue > bestRBFValue)
		{
			bestRBFValue = rbfValue;
			IDofBestCluster = i;
		}

		if (rbfValue < worstRBFValue)
		{
			worstRBFValue = rbfValue;
			IDofWorstCluster = i;
		}
	}

	*pOutBestRBFValue = bestRBFValue;
	*pOutWorstRBFValue = worstRBFValue;

	*pOutIDofBestCluster = IDofBestCluster;
	*pOutIDofWorstCluster = IDofWorstCluster;
}

void Get_Best_And_Worst_ClippedRBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster, float *pOutWorstRBFValue, int32_t *pOutIDofWorstCluster,
	C2DPoint_InsideCluster *pInPoint, C2DClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	float bestRBFValue = 0.0f;
	float worstRBFValue = 1.0f;

	int32_t IDofBestCluster = 0;
	int32_t IDofWorstCluster = 0;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float rbfValue = pInCentroidArray[i].Calculate_ClippedRBFValue(pInPoint);

		if (rbfValue > bestRBFValue)
		{
			bestRBFValue = rbfValue;
			IDofBestCluster = i;
		}

		if (rbfValue < worstRBFValue)
		{
			worstRBFValue = rbfValue;
			IDofWorstCluster = i;
		}
	}

	*pOutBestRBFValue = bestRBFValue;
	*pOutWorstRBFValue = worstRBFValue;

	*pOutIDofBestCluster = IDofBestCluster;
	*pOutIDofWorstCluster = IDofWorstCluster;
}

void Get_Best_RBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster, 
	C2DPoint_InsideCluster *pInPoint, C2DClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	float bestRBFValue = 0.0f;
	int32_t IDofBestCluster = 0;
	
	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float rbfValue = pInCentroidArray[i].Calculate_RBFValue(pInPoint);

		if (rbfValue > bestRBFValue)
		{
			bestRBFValue = rbfValue;
			IDofBestCluster = i;
		}
	}

	*pOutBestRBFValue = bestRBFValue;
	*pOutIDofBestCluster = IDofBestCluster;
}

void Get_Best_ClippedRBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster,
	C2DPoint_InsideCluster *pInPoint, C2DClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	float bestRBFValue = 0.0f;
	int32_t IDofBestCluster = 0;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float rbfValue = pInCentroidArray[i].Calculate_ClippedRBFValue(pInPoint);

		if (rbfValue > bestRBFValue)
		{
			bestRBFValue = rbfValue;
			IDofBestCluster = i;
		}
	}

	*pOutBestRBFValue = bestRBFValue;
	*pOutIDofBestCluster = IDofBestCluster;
}

void Get_Best_And_Worst_RBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster, float *pOutWorstRBFValue, int32_t *pOutIDofWorstCluster,
	C1DPoint_InsideCluster *pInPoint, C1DClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	float bestRBFValue = 0.0f;
	float worstRBFValue = 1.0f;

	int32_t IDofBestCluster = 0;
	int32_t IDofWorstCluster = 0;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float rbfValue = pInCentroidArray[i].Calculate_RBFValue(pInPoint);

		if (rbfValue > bestRBFValue)
		{
			bestRBFValue = rbfValue;
			IDofBestCluster = i;
		}

		if (rbfValue < worstRBFValue)
		{
			worstRBFValue = rbfValue;
			IDofWorstCluster = i;
		}
	}

	*pOutBestRBFValue = bestRBFValue;
	*pOutWorstRBFValue = worstRBFValue;

	*pOutIDofBestCluster = IDofBestCluster;
	*pOutIDofWorstCluster = IDofWorstCluster;
}

void Get_Best_And_Worst_ClippedRBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster, float *pOutWorstRBFValue, int32_t *pOutIDofWorstCluster,
	C1DPoint_InsideCluster *pInPoint, C1DClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	float bestRBFValue = 0.0f;
	float worstRBFValue = 1.0f;

	int32_t IDofBestCluster = 0;
	int32_t IDofWorstCluster = 0;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float rbfValue = pInCentroidArray[i].Calculate_ClippedRBFValue(pInPoint);

		if (rbfValue > bestRBFValue)
		{
			bestRBFValue = rbfValue;
			IDofBestCluster = i;
		}

		if (rbfValue < worstRBFValue)
		{
			worstRBFValue = rbfValue;
			IDofWorstCluster = i;
		}
	}

	*pOutBestRBFValue = bestRBFValue;
	*pOutWorstRBFValue = worstRBFValue;

	*pOutIDofBestCluster = IDofBestCluster;
	*pOutIDofWorstCluster = IDofWorstCluster;
}

void Get_Best_RBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster,
	C1DPoint_InsideCluster *pInPoint, C1DClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	float bestRBFValue = 0.0f;
	int32_t IDofBestCluster = 0;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float rbfValue = pInCentroidArray[i].Calculate_RBFValue(pInPoint);

		if (rbfValue > bestRBFValue)
		{
			bestRBFValue = rbfValue;
			IDofBestCluster = i;
		}
	}

	*pOutBestRBFValue = bestRBFValue;
	*pOutIDofBestCluster = IDofBestCluster;
}

void Get_Best_ClippedRBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster,
	C1DPoint_InsideCluster *pInPoint, C1DClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	float bestRBFValue = 0.0f;
	int32_t IDofBestCluster = 0;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float rbfValue = pInCentroidArray[i].Calculate_ClippedRBFValue(pInPoint);

		if (rbfValue > bestRBFValue)
		{
			bestRBFValue = rbfValue;
			IDofBestCluster = i;
		}
	}

	*pOutBestRBFValue = bestRBFValue;
	*pOutIDofBestCluster = IDofBestCluster;
}

void Get_Best_And_Worst_RBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster, float *pOutWorstRBFValue, int32_t *pOutIDofWorstCluster,
	CNDPoint_InsideCluster *pInPoint, CNDClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	float bestRBFValue = 0.0f;
	float worstRBFValue = 1.0f;

	int32_t IDofBestCluster = 0;
	int32_t IDofWorstCluster = 0;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float rbfValue = pInCentroidArray[i].Calculate_RBFValue(pInPoint);

		if (rbfValue > bestRBFValue)
		{
			bestRBFValue = rbfValue;
			IDofBestCluster = i;
		}

		if (rbfValue < worstRBFValue)
		{
			worstRBFValue = rbfValue;
			IDofWorstCluster = i;
		}
	}

	*pOutBestRBFValue = bestRBFValue;
	*pOutWorstRBFValue = worstRBFValue;

	*pOutIDofBestCluster = IDofBestCluster;
	*pOutIDofWorstCluster = IDofWorstCluster;
}

void Get_Best_And_Worst_ClippedRBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster, float *pOutWorstRBFValue, int32_t *pOutIDofWorstCluster,
	CNDPoint_InsideCluster *pInPoint, CNDClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	float bestRBFValue = 0.0f;
	float worstRBFValue = 1.0f;

	int32_t IDofBestCluster = 0;
	int32_t IDofWorstCluster = 0;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float rbfValue = pInCentroidArray[i].Calculate_ClippedRBFValue(pInPoint);

		if (rbfValue > bestRBFValue)
		{
			bestRBFValue = rbfValue;
			IDofBestCluster = i;
		}

		if (rbfValue < worstRBFValue)
		{
			worstRBFValue = rbfValue;
			IDofWorstCluster = i;
		}
	}

	*pOutBestRBFValue = bestRBFValue;
	*pOutWorstRBFValue = worstRBFValue;

	*pOutIDofBestCluster = IDofBestCluster;
	*pOutIDofWorstCluster = IDofWorstCluster;
}

void Get_Best_RBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster, 
	CNDPoint_InsideCluster *pInPoint, CNDClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	float bestRBFValue = 0.0f;
	int32_t IDofBestCluster = 0;
	
	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float rbfValue = pInCentroidArray[i].Calculate_RBFValue(pInPoint);

		if (rbfValue > bestRBFValue)
		{
			bestRBFValue = rbfValue;
			IDofBestCluster = i;
		}

		
	}

	*pOutBestRBFValue = bestRBFValue;
	*pOutIDofBestCluster = IDofBestCluster;
}

void Get_Best_ClippedRBFValue(float *pOutBestRBFValue, int32_t *pOutIDofBestCluster,
	CNDPoint_InsideCluster *pInPoint, CNDClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	float bestRBFValue = 0.0f;
	int32_t IDofBestCluster = 0;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float rbfValue = pInCentroidArray[i].Calculate_ClippedRBFValue(pInPoint);

		if (rbfValue > bestRBFValue)
		{
			bestRBFValue = rbfValue;
			IDofBestCluster = i;
		}


	}

	*pOutBestRBFValue = bestRBFValue;
	*pOutIDofBestCluster = IDofBestCluster;
}

void Get_Best_RBFValue(CClusterArray_SumOfRBFValues *pClusterArray_SumOfRBFValues,
	CNDPoint_InsideCluster *pInPoint, CNDClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	float bestRBFValue = 0.0f;
	int32_t IDofBestCluster = 0;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float rbfValue = pInCentroidArray[i].Calculate_RBFValue(pInPoint);

		if (rbfValue > bestRBFValue)
		{
			bestRBFValue = rbfValue;
			IDofBestCluster = i;
		}


	}

	pClusterArray_SumOfRBFValues->pSumOfRBFValuesArray[IDofBestCluster] += bestRBFValue;
	pClusterArray_SumOfRBFValues->pBestClusterCounterArray[IDofBestCluster]++;
}

void Get_Best_ClippedRBFValue(CClusterArray_SumOfRBFValues *pClusterArray_SumOfRBFValues,
	CNDPoint_InsideCluster *pInPoint, CNDClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	float bestRBFValue = 0.0f;
	int32_t IDofBestCluster = 0;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float rbfValue = pInCentroidArray[i].Calculate_ClippedRBFValue(pInPoint);

		if (rbfValue > bestRBFValue)
		{
			bestRBFValue = rbfValue;
			IDofBestCluster = i;
		}


	}

	pClusterArray_SumOfRBFValues->pSumOfRBFValuesArray[IDofBestCluster] += bestRBFValue;
	pClusterArray_SumOfRBFValues->pBestClusterCounterArray[IDofBestCluster]++;
}

void Get_Best_RBFValue(CClusterArray_SumOfRBFValues *pClusterArray_SumOfRBFValues,
	C3DPoint_InsideCluster *pInPoint, C3DClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	float bestRBFValue = 0.0f;
	int32_t IDofBestCluster = 0;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float rbfValue = pInCentroidArray[i].Calculate_RBFValue(pInPoint);

		if (rbfValue > bestRBFValue)
		{
			bestRBFValue = rbfValue;
			IDofBestCluster = i;
		}


	}

	pClusterArray_SumOfRBFValues->pSumOfRBFValuesArray[IDofBestCluster] += bestRBFValue;
	pClusterArray_SumOfRBFValues->pBestClusterCounterArray[IDofBestCluster]++;
}

void Get_Best_ClippedRBFValue(CClusterArray_SumOfRBFValues *pClusterArray_SumOfRBFValues,
	C3DPoint_InsideCluster *pInPoint, C3DClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	float bestRBFValue = 0.0f;
	int32_t IDofBestCluster = 0;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float rbfValue = pInCentroidArray[i].Calculate_ClippedRBFValue(pInPoint);

		if (rbfValue > bestRBFValue)
		{
			bestRBFValue = rbfValue;
			IDofBestCluster = i;
		}


	}

	pClusterArray_SumOfRBFValues->pSumOfRBFValuesArray[IDofBestCluster] += bestRBFValue;
	pClusterArray_SumOfRBFValues->pBestClusterCounterArray[IDofBestCluster]++;
}

void Get_Best_RBFValue(CClusterArray_SumOfRBFValues *pClusterArray_SumOfRBFValues,
	C2DPoint_InsideCluster *pInPoint, C2DClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	float bestRBFValue = 0.0f;
	int32_t IDofBestCluster = 0;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float rbfValue = pInCentroidArray[i].Calculate_RBFValue(pInPoint);

		if (rbfValue > bestRBFValue)
		{
			bestRBFValue = rbfValue;
			IDofBestCluster = i;
		}


	}

	pClusterArray_SumOfRBFValues->pSumOfRBFValuesArray[IDofBestCluster] += bestRBFValue;
	pClusterArray_SumOfRBFValues->pBestClusterCounterArray[IDofBestCluster]++;
}

void Get_Best_ClippedRBFValue(CClusterArray_SumOfRBFValues *pClusterArray_SumOfRBFValues,
	C2DPoint_InsideCluster *pInPoint, C2DClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	float bestRBFValue = 0.0f;
	int32_t IDofBestCluster = 0;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float rbfValue = pInCentroidArray[i].Calculate_ClippedRBFValue(pInPoint);

		if (rbfValue > bestRBFValue)
		{
			bestRBFValue = rbfValue;
			IDofBestCluster = i;
		}


	}

	pClusterArray_SumOfRBFValues->pSumOfRBFValuesArray[IDofBestCluster] += bestRBFValue;
	pClusterArray_SumOfRBFValues->pBestClusterCounterArray[IDofBestCluster]++;
}

void Get_Best_RBFValue(CClusterArray_SumOfRBFValues *pClusterArray_SumOfRBFValues,
	C1DPoint_InsideCluster *pInPoint, C1DClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	float bestRBFValue = 0.0f;
	int32_t IDofBestCluster = 0;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float rbfValue = pInCentroidArray[i].Calculate_RBFValue(pInPoint);

		if (rbfValue > bestRBFValue)
		{
			bestRBFValue = rbfValue;
			IDofBestCluster = i;
		}


	}

	pClusterArray_SumOfRBFValues->pSumOfRBFValuesArray[IDofBestCluster] += bestRBFValue;
	pClusterArray_SumOfRBFValues->pBestClusterCounterArray[IDofBestCluster]++;
}

void Get_Best_ClippedRBFValue(CClusterArray_SumOfRBFValues *pClusterArray_SumOfRBFValues,
	C1DPoint_InsideCluster *pInPoint, C1DClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	float bestRBFValue = 0.0f;
	int32_t IDofBestCluster = 0;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float rbfValue = pInCentroidArray[i].Calculate_ClippedRBFValue(pInPoint);

		if (rbfValue > bestRBFValue)
		{
			bestRBFValue = rbfValue;
			IDofBestCluster = i;
		}


	}

	pClusterArray_SumOfRBFValues->pSumOfRBFValuesArray[IDofBestCluster] += bestRBFValue;
	pClusterArray_SumOfRBFValues->pBestClusterCounterArray[IDofBestCluster]++;
}

void Get_Best_RBFValue(CClusterArray_SumOfRBFValues *pClusterArray_SumOfRBFValues,
	float inCoordX, float inCoordY, float inCoordZ, C3DClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	float bestRBFValue = 0.0f;
	int32_t IDofBestCluster = 0;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float rbfValue = pInCentroidArray[i].Calculate_RBFValue(inCoordX, inCoordY, inCoordZ);

		if (rbfValue > bestRBFValue)
		{
			bestRBFValue = rbfValue;
			IDofBestCluster = i;
		}


	}

	pClusterArray_SumOfRBFValues->pSumOfRBFValuesArray[IDofBestCluster] += bestRBFValue;
	pClusterArray_SumOfRBFValues->pBestClusterCounterArray[IDofBestCluster]++;
}

void Get_Best_ClippedRBFValue(CClusterArray_SumOfRBFValues *pClusterArray_SumOfRBFValues,
	float inCoordX, float inCoordY, float inCoordZ, C3DClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	float bestRBFValue = 0.0f;
	int32_t IDofBestCluster = 0;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float rbfValue = pInCentroidArray[i].Calculate_ClippedRBFValue(inCoordX, inCoordY, inCoordZ);

		if (rbfValue > bestRBFValue)
		{
			bestRBFValue = rbfValue;
			IDofBestCluster = i;
		}


	}

	pClusterArray_SumOfRBFValues->pSumOfRBFValuesArray[IDofBestCluster] += bestRBFValue;
	pClusterArray_SumOfRBFValues->pBestClusterCounterArray[IDofBestCluster]++;
}

void Get_Best_RBFValue(CClusterArray_SumOfRBFValues *pClusterArray_SumOfRBFValues,
	float inCoordX, float inCoordY, C2DClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	float bestRBFValue = 0.0f;
	int32_t IDofBestCluster = 0;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float rbfValue = pInCentroidArray[i].Calculate_RBFValue(inCoordX, inCoordY);

		if (rbfValue > bestRBFValue)
		{
			bestRBFValue = rbfValue;
			IDofBestCluster = i;
		}


	}

	pClusterArray_SumOfRBFValues->pSumOfRBFValuesArray[IDofBestCluster] += bestRBFValue;
	pClusterArray_SumOfRBFValues->pBestClusterCounterArray[IDofBestCluster]++;
}

void Get_Best_ClippedRBFValue(CClusterArray_SumOfRBFValues *pClusterArray_SumOfRBFValues,
	float inCoordX, float inCoordY, C2DClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	float bestRBFValue = 0.0f;
	int32_t IDofBestCluster = 0;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float rbfValue = pInCentroidArray[i].Calculate_ClippedRBFValue(inCoordX, inCoordY);

		if (rbfValue > bestRBFValue)
		{
			bestRBFValue = rbfValue;
			IDofBestCluster = i;
		}


	}

	pClusterArray_SumOfRBFValues->pSumOfRBFValuesArray[IDofBestCluster] += bestRBFValue;
	pClusterArray_SumOfRBFValues->pBestClusterCounterArray[IDofBestCluster]++;
}

void Get_Best_RBFValue(CClusterArray_SumOfRBFValues *pClusterArray_SumOfRBFValues,
	float inCoordX, C1DClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	float bestRBFValue = 0.0f;
	int32_t IDofBestCluster = 0;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float rbfValue = pInCentroidArray[i].Calculate_RBFValue(inCoordX);

		if (rbfValue > bestRBFValue)
		{
			bestRBFValue = rbfValue;
			IDofBestCluster = i;
		}


	}

	pClusterArray_SumOfRBFValues->pSumOfRBFValuesArray[IDofBestCluster] += bestRBFValue;
	pClusterArray_SumOfRBFValues->pBestClusterCounterArray[IDofBestCluster]++;
}

void Get_Best_ClippedRBFValue(CClusterArray_SumOfRBFValues *pClusterArray_SumOfRBFValues,
	float inCoordX, C1DClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	float bestRBFValue = 0.0f;
	int32_t IDofBestCluster = 0;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float rbfValue = pInCentroidArray[i].Calculate_ClippedRBFValue(inCoordX);

		if (rbfValue > bestRBFValue)
		{
			bestRBFValue = rbfValue;
			IDofBestCluster = i;
		}


	}

	pClusterArray_SumOfRBFValues->pSumOfRBFValuesArray[IDofBestCluster] += bestRBFValue;
	pClusterArray_SumOfRBFValues->pBestClusterCounterArray[IDofBestCluster]++;
}


void Add_To_MeanCentroids(CNDClusterCentroid *pOutMeanCentroidArray, CNDClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	int32_t size = pInCentroidArray->Size;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float *pMeanCenterValueArray = pOutMeanCentroidArray[i].pCenterValueArray;

		float minDistanceSq = 1000000.0f;
		int32_t belongingID = 0;

		for (int32_t j = 0; j < numOfClusters; j++)
		{
			float *pCenterValueArray = pInCentroidArray[j].pCenterValueArray;

			float distSq = 0.0f;

			for (int32_t k = 0; k < size; k++)
			{
				float delta = pMeanCenterValueArray[k] - pCenterValueArray[k];
				delta *= delta;
				distSq += delta;
			}

			if (distSq < minDistanceSq)
			{
				minDistanceSq = distSq;
				belongingID = j;
			}
		}

		pOutMeanCentroidArray[i].Add_To_MeanCentroid(&pInCentroidArray[belongingID]);
	}
}

void Add_To_MeanCentroids(C3DClusterCentroid *pOutMeanCentroidArray, C3DClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float minDistanceSq = 1000000.0f;
		int32_t belongingID = 0;

		for (int32_t j = 0; j < numOfClusters; j++)
		{
			float distSq = 0.0f;

			float delta = pOutMeanCentroidArray[i].centerX - pInCentroidArray[j].centerX;
			delta *= delta;
			distSq += delta;

			delta = pOutMeanCentroidArray[i].centerY - pInCentroidArray[j].centerY;
			delta *= delta;
			distSq += delta;

			delta = pOutMeanCentroidArray[i].centerZ - pInCentroidArray[j].centerZ;
			delta *= delta;
			distSq += delta;
			
			if (distSq < minDistanceSq)
			{
				minDistanceSq = distSq;
				belongingID = j;
			}
		}

		pOutMeanCentroidArray[i].Add_To_MeanCentroid(&pInCentroidArray[belongingID]);
	}
}

void Add_To_MeanCentroids(C2DClusterCentroid *pOutMeanCentroidArray, C2DClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float minDistanceSq = 1000000.0f;
		int32_t belongingID = 0;

		for (int32_t j = 0; j < numOfClusters; j++)
		{
			float distSq = 0.0f;

			float delta = pOutMeanCentroidArray[i].centerX - pInCentroidArray[j].centerX;
			delta *= delta;
			distSq += delta;

			delta = pOutMeanCentroidArray[i].centerY - pInCentroidArray[j].centerY;
			delta *= delta;
			distSq += delta;

			if (distSq < minDistanceSq)
			{
				minDistanceSq = distSq;
				belongingID = j;
			}
		}

		pOutMeanCentroidArray[i].Add_To_MeanCentroid(&pInCentroidArray[belongingID]);
	}
}

void Add_To_MeanCentroids(C1DClusterCentroid *pOutMeanCentroidArray, C1DClusterCentroid *pInCentroidArray, int32_t numOfClusters)
{
	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float minDistanceSq = 1000000.0f;
		int32_t belongingID = 0;

		for (int32_t j = 0; j < numOfClusters; j++)
		{
			float distSq = 0.0f;

			float delta = pOutMeanCentroidArray[i].centerX - pInCentroidArray[j].centerX;
			delta *= delta;
			distSq += delta;

			if (distSq < minDistanceSq)
			{
				minDistanceSq = distSq;
				belongingID = j;
			}
		}

		pOutMeanCentroidArray[i].Add_To_MeanCentroid(&pInCentroidArray[belongingID]);
	}
}


void Calculate_ClusterRadiusSqs(CNDClusterCentroid *pOutCentroidArray, int32_t numOfClusters, CNDPoint_InsideCluster *pInPointArray, int32_t numOfPoints)
{
	for (int32_t i = 0; i < numOfClusters; i++)
	{
		pOutCentroidArray[i].Calculate_ClusterRadiusSq(pInPointArray, numOfPoints);
	}
}

void Calculate_ClusterRadiusSqs(C3DClusterCentroid *pOutCentroidArray, int32_t numOfClusters, C3DPoint_InsideCluster *pInPointArray, int32_t numOfPoints)
{
	for (int32_t i = 0; i < numOfClusters; i++)
	{
		pOutCentroidArray[i].Calculate_ClusterRadiusSq(pInPointArray, numOfPoints);
	}
}

void Calculate_ClusterRadiusSqs(C2DClusterCentroid *pOutCentroidArray, int32_t numOfClusters, C2DPoint_InsideCluster *pInPointArray, int32_t numOfPoints)
{
	for (int32_t i = 0; i < numOfClusters; i++)
	{
		pOutCentroidArray[i].Calculate_ClusterRadiusSq(pInPointArray, numOfPoints);
	}
}

void Calculate_ClusterRadiusSqs(C1DClusterCentroid *pOutCentroidArray, int32_t numOfClusters, C1DPoint_InsideCluster *pInPointArray, int32_t numOfPoints)
{
	for (int32_t i = 0; i < numOfClusters; i++)
	{
		pOutCentroidArray[i].Calculate_ClusterRadiusSq(pInPointArray, numOfPoints);
	}
}

float Calculate_SumOfDistancesSq_InsideAllClusters(CNDPoint_InsideCluster *pPointArray, int32_t numOfPoints, CNDClusterCentroid *pCentroidArray, int32_t numOfClusters)
{
	float sum = 0.0f;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		pCentroidArray[i].Calculate_SumOfDistancesSq_InsideCluster(pPointArray, numOfPoints);
		sum += pCentroidArray[i].SumOfDistancesSq_InsideCluster;
	}

	return sum;
}

float Calculate_SumOfDistancesSq_InsideAllClusters(C3DPoint_InsideCluster *pPointArray, int32_t numOfPoints, C3DClusterCentroid *pCentroidArray, int32_t numOfClusters)
{
	float sum = 0.0f;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		pCentroidArray[i].Calculate_SumOfDistancesSq_InsideCluster(pPointArray, numOfPoints);
		sum += pCentroidArray[i].SumOfDistancesSq_InsideCluster;
	}

	return sum;
}

float Calculate_SumOfDistancesSq_InsideAllClusters(C2DPoint_InsideCluster *pPointArray, int32_t numOfPoints, C2DClusterCentroid *pCentroidArray, int32_t numOfClusters)
{
	float sum = 0.0f;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		pCentroidArray[i].Calculate_SumOfDistancesSq_InsideCluster(pPointArray, numOfPoints);
		sum += pCentroidArray[i].SumOfDistancesSq_InsideCluster;
	}

	return sum;
}

float Calculate_SumOfDistancesSq_InsideAllClusters(C1DPoint_InsideCluster *pPointArray, int32_t numOfPoints, C1DClusterCentroid *pCentroidArray, int32_t numOfClusters)
{
	float sum = 0.0f;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		pCentroidArray[i].Calculate_SumOfDistancesSq_InsideCluster(pPointArray, numOfPoints);
		sum += pCentroidArray[i].SumOfDistancesSq_InsideCluster;
	}

	return sum;
}

float Calculate_ClusterRadiusVariance(CNDClusterCentroid *pCentroidArray, int32_t numOfClusters)
{
	float meanRangeSq = 0.0f;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		meanRangeSq += pCentroidArray[i].ClusterRadiusSq;
	}

	float invNumOfClusters = 1.0f / static_cast<float>(numOfClusters);

	meanRangeSq *= invNumOfClusters;

	float varianceSum = 0.0f;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float delta = meanRangeSq - pCentroidArray[i].ClusterRadiusSq;
		delta *= delta;
		varianceSum += delta;
	}

	return (varianceSum *= invNumOfClusters);
}

float Calculate_ClusterRadiusVariance(C1DClusterCentroid *pCentroidArray, int32_t numOfClusters)
{
	float meanRangeSq = 0.0f;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		meanRangeSq += pCentroidArray[i].ClusterRadiusSq;
	}

	float invNumOfClusters = 1.0f / static_cast<float>(numOfClusters);

	meanRangeSq *= invNumOfClusters;

	float varianceSum = 0.0f;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float delta = meanRangeSq - pCentroidArray[i].ClusterRadiusSq;
		delta *= delta;
		varianceSum += delta;
	}

	return (varianceSum *= invNumOfClusters);
}

float Calculate_ClusterRadiusVariance(C2DClusterCentroid *pCentroidArray, int32_t numOfClusters)
{
	float meanRangeSq = 0.0f;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		meanRangeSq += pCentroidArray[i].ClusterRadiusSq;
	}

	float invNumOfClusters = 1.0f / static_cast<float>(numOfClusters);

	meanRangeSq *= invNumOfClusters;

	float varianceSum = 0.0f;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float delta = meanRangeSq - pCentroidArray[i].ClusterRadiusSq;
		delta *= delta;
		varianceSum += delta;
	}

	return (varianceSum *= invNumOfClusters);
}

float Calculate_ClusterRadiusVariance(C3DClusterCentroid *pCentroidArray, int32_t numOfClusters)
{
	float meanRangeSq = 0.0f;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		meanRangeSq += pCentroidArray[i].ClusterRadiusSq;
	}

	float invNumOfClusters = 1.0f / static_cast<float>(numOfClusters);

	meanRangeSq *= invNumOfClusters;

	float varianceSum = 0.0f;

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		float delta = meanRangeSq - pCentroidArray[i].ClusterRadiusSq;
		delta *= delta;
		varianceSum += delta;
	}

	return (varianceSum *= invNumOfClusters);
}

void Assign_Points_To_Clusters(pCalc_ClusterDist pFunc, CNDPoint_InsideCluster *pPointArray, int32_t numOfPoints, CNDClusterCentroid *pCentroidArray, int32_t numOfClusters)
{
	for (int32_t pointID = 0; pointID < numOfPoints; pointID++)
	{
		float minDist = 1000000.0f;

		for (int32_t centroidID = 0; centroidID < numOfClusters; centroidID++)
		{
			float dist = pFunc(&pCentroidArray[centroidID], &pPointArray[pointID]);

			if (dist < minDist)
			{
				minDist = dist;
				pPointArray[pointID].clusterID = centroidID;
			}
		}
	}
}

void Assign_Points_To_Clusters_OMP(pCalc_ClusterDist pFunc, CNDPoint_InsideCluster *pPointArray, int32_t numOfPoints, CNDClusterCentroid *pCentroidArray, int32_t numOfClusters)
{
	//#pragma omp parallel for num_threads(2)
#pragma omp parallel for
	for (int32_t pointID = 0; pointID < numOfPoints; pointID++)
	{
		float minDist = 1000000.0f;

		for (int32_t centroidID = 0; centroidID < numOfClusters; centroidID++)
		{
			float dist = pFunc(&pCentroidArray[centroidID], &pPointArray[pointID]);

			if (dist < minDist)
			{
				minDist = dist;
				pPointArray[pointID].clusterID = centroidID;
			}
		}
	}
}

void Assign_Points_To_Clusters(CNDPoint_InsideCluster *pPointArray, int32_t numOfPoints, CNDClusterCentroid *pCentroidArray, int32_t numOfClusters)
{
	int32_t numOfDimensions = pCentroidArray[0].Size;

	for (int32_t pointID = 0; pointID < numOfPoints; pointID++)
	{
		float *pValueArray = pPointArray[pointID].pValueArray;

		float minDistSq = 1000000.0f;

		for (int32_t centroidID = 0; centroidID < numOfClusters; centroidID++)
		{
			float *pCenterValueArray = pCentroidArray[centroidID].pCenterValueArray;

			float distSq = 0.0f;

			for (int32_t i = 0; i < numOfDimensions; i++)
			{
				float delta = pCenterValueArray[i] - pValueArray[i];
				delta *= delta;
				distSq += delta;
			}

			if (distSq < minDistSq)
			{
				minDistSq = distSq;
				pPointArray[pointID].clusterID = centroidID;
			}
		}
	}
}

void Assign_Points_To_Clusters_OMP(CNDPoint_InsideCluster *pPointArray, int32_t numOfPoints, CNDClusterCentroid *pCentroidArray, int32_t numOfClusters)
{
	int32_t numOfDimensions = pCentroidArray[0].Size;

	//#pragma omp parallel for num_threads(2)
#pragma omp parallel for
	for (int32_t pointID = 0; pointID < numOfPoints; pointID++)
	{
		float *pValueArray = pPointArray[pointID].pValueArray;

		float minDistSq = 1000000.0f;

		for (int32_t centroidID = 0; centroidID < numOfClusters; centroidID++)
		{
			float *pCenterValueArray = pCentroidArray[centroidID].pCenterValueArray;

			float distSq = 0.0f;

			for (int32_t i = 0; i < numOfDimensions; i++)
			{
				float delta = pCenterValueArray[i] - pValueArray[i];
				delta *= delta;
				distSq += delta;
			}

			if (distSq < minDistSq)
			{
				minDistSq = distSq;
				pPointArray[pointID].clusterID = centroidID;
			}
		}
	}
}

void Assign_Points_To_Clusters(C1DPoint_InsideCluster *pPointArray, int32_t numOfPoints, C1DClusterCentroid *pCentroidArray, int32_t numOfClusters)
{
	for (int32_t pointID = 0; pointID < numOfPoints; pointID++)
	{
		float pointX = pPointArray[pointID].x;

		float minDistSq = 1000000.0f;

		for (int32_t centroidID = 0; centroidID < numOfClusters; centroidID++)
		{
			float dx = pCentroidArray[centroidID].centerX - pointX;

			float distSq = dx * dx;

			if (distSq < minDistSq)
			{
				minDistSq = distSq;
				pPointArray[pointID].clusterID = centroidID;
			}
		}
	}
}

void Assign_Points_To_Clusters_OMP(C1DPoint_InsideCluster *pPointArray, int32_t numOfPoints, C1DClusterCentroid *pCentroidArray, int32_t numOfClusters)
{
	//#pragma omp parallel for num_threads(2)
#pragma omp parallel for
	for (int32_t pointID = 0; pointID < numOfPoints; pointID++)
	{
		float pointX = pPointArray[pointID].x;

		float minDistSq = 1000000.0f;

		for (int32_t centroidID = 0; centroidID < numOfClusters; centroidID++)
		{
			float dx = pCentroidArray[centroidID].centerX - pointX;

			float distSq = dx * dx;

			if (distSq < minDistSq)
			{
				minDistSq = distSq;
				pPointArray[pointID].clusterID = centroidID;
			}
		}
	}
}

void Assign_Points_To_Clusters(C2DPoint_InsideCluster *pPointArray, int32_t numOfPoints, C2DClusterCentroid *pCentroidArray, int32_t numOfClusters)
{
	for (int32_t pointID = 0; pointID < numOfPoints; pointID++)
	{
		float pointX = pPointArray[pointID].x;
		float pointY = pPointArray[pointID].y;

		float minDistSq = 1000000.0f;

		for (int32_t centroidID = 0; centroidID < numOfClusters; centroidID++)
		{
			float dx = pCentroidArray[centroidID].centerX - pointX;
			float dy = pCentroidArray[centroidID].centerY - pointY;

			float distSq = dx * dx + dy * dy;

			//float distSq = abs(dx) + abs(dy);

			if (distSq < minDistSq)
			{
				minDistSq = distSq;
				pPointArray[pointID].clusterID = centroidID;
			}
		}
	}
}

void Assign_Points_To_Clusters_OMP(C2DPoint_InsideCluster *pPointArray, int32_t numOfPoints, C2DClusterCentroid *pCentroidArray, int32_t numOfClusters)
{
	//#pragma omp parallel for num_threads(2)
#pragma omp parallel for
	for (int32_t pointID = 0; pointID < numOfPoints; pointID++)
	{
		float pointX = pPointArray[pointID].x;
		float pointY = pPointArray[pointID].y;

		float minDistSq = 1000000.0f;

		for (int32_t centroidID = 0; centroidID < numOfClusters; centroidID++)
		{
			float dx = pCentroidArray[centroidID].centerX - pointX;
			float dy = pCentroidArray[centroidID].centerY - pointY;

			float distSq = dx * dx + dy * dy;

			if (distSq < minDistSq)
			{
				minDistSq = distSq;
				pPointArray[pointID].clusterID = centroidID;
			}
		}
	}
}

void Assign_Points_To_Clusters(C3DPoint_InsideCluster *pPointArray, int32_t numOfPoints, C3DClusterCentroid *pCentroidArray, int32_t numOfClusters)
{
	for (int32_t pointID = 0; pointID < numOfPoints; pointID++)
	{
		float pointX = pPointArray[pointID].x;
		float pointY = pPointArray[pointID].y;
		float pointZ = pPointArray[pointID].z;

		float minDistSq = 1000000.0f;

		for (int32_t centroidID = 0; centroidID < numOfClusters; centroidID++)
		{
			float dx = pCentroidArray[centroidID].centerX - pointX;
			float dy = pCentroidArray[centroidID].centerY - pointY;
			float dz = pCentroidArray[centroidID].centerZ - pointZ;

			float distSq = dx * dx + dy * dy + dz * dz;

			if (distSq < minDistSq)
			{
				minDistSq = distSq;
				pPointArray[pointID].clusterID = centroidID;
			}
		}
	}
}

void Assign_Points_To_Clusters_OMP(C3DPoint_InsideCluster *pPointArray, int32_t numOfPoints, C3DClusterCentroid *pCentroidArray, int32_t numOfClusters)
{
	//#pragma omp parallel for num_threads(2)
#pragma omp parallel for
	for (int32_t pointID = 0; pointID < numOfPoints; pointID++)
	{
		float pointX = pPointArray[pointID].x;
		float pointY = pPointArray[pointID].y;
		float pointZ = pPointArray[pointID].z;

		float minDistSq = 1000000.0f;

		for (int32_t centroidID = 0; centroidID < numOfClusters; centroidID++)
		{
			float dx = pCentroidArray[centroidID].centerX - pointX;
			float dy = pCentroidArray[centroidID].centerY - pointY;
			float dz = pCentroidArray[centroidID].centerZ - pointZ;

			float distSq = dx * dx + dy * dy + dz * dz;

			if (distSq < minDistSq)
			{
				minDistSq = distSq;
				pPointArray[pointID].clusterID = centroidID;
			}
		}
	}
}



int32_t Calculate_Clusters(pCalc_ClusterDist pFunc, CNDClusterCentroid *pOutCentroidArray, int32_t numOfClusters, CNDPoint_InsideCluster *pInPointArray, int32_t numOfPoints, int32_t numIterationsMax)
{
	for (int32_t i = 0; i < numOfClusters; i++)
	{
		pOutCentroidArray[i].calculationsCompleted = false;
	}

	Assign_Points_To_Clusters(pFunc, pInPointArray, numOfPoints, pOutCentroidArray, numOfClusters);

	for (int32_t iteration = 0; iteration < numIterationsMax; iteration++)
	{
		bool calculationsCompleted = true;

		for (int32_t i = 0; i < numOfClusters; i++)
		{
			if (pOutCentroidArray[i].Calculate_NewCenter(pInPointArray, numOfPoints) == false)
			{
				calculationsCompleted = false;
			}
		}

		if (calculationsCompleted == true)
		{
			return iteration + 1;
		}

		Assign_Points_To_Clusters(pFunc, pInPointArray, numOfPoints, pOutCentroidArray, numOfClusters);
	}

	return -1;
}

int32_t Calculate_Clusters_OMP(pCalc_ClusterDist pFunc, CNDClusterCentroid *pOutCentroidArray, int32_t numOfClusters, CNDPoint_InsideCluster *pInPointArray, int32_t numOfPoints, int32_t numIterationsMax)
{
	for (int32_t i = 0; i < numOfClusters; i++)
	{
		pOutCentroidArray[i].calculationsCompleted = false;
	}

	Assign_Points_To_Clusters_OMP(pFunc, pInPointArray, numOfPoints, pOutCentroidArray, numOfClusters);

	for (int32_t iteration = 0; iteration < numIterationsMax; iteration++)
	{
		bool calculationsCompleted = true;

		for (int32_t i = 0; i < numOfClusters; i++)
		{
			if (pOutCentroidArray[i].Calculate_NewCenter(pInPointArray, numOfPoints) == false)
			{
				calculationsCompleted = false;
			}
		}

		if (calculationsCompleted == true)
		{
			return iteration + 1;
		}

		Assign_Points_To_Clusters_OMP(pFunc, pInPointArray, numOfPoints, pOutCentroidArray, numOfClusters);
	}

	return -1;
}

int32_t Calculate_Clusters(CNDClusterCentroid *pOutCentroidArray, int32_t numOfClusters, CNDPoint_InsideCluster *pInPointArray, int32_t numOfPoints, int32_t numIterationsMax)
{
	for (int32_t i = 0; i < numOfClusters; i++)
	{
		pOutCentroidArray[i].calculationsCompleted = false;
	}

	Assign_Points_To_Clusters(pInPointArray, numOfPoints, pOutCentroidArray, numOfClusters);

	for (int32_t iteration = 0; iteration < numIterationsMax; iteration++)
	{
		bool calculationsCompleted = true;

		for (int32_t i = 0; i < numOfClusters; i++)
		{
			if (pOutCentroidArray[i].Calculate_NewCenter(pInPointArray, numOfPoints) == false)
			{
				calculationsCompleted = false;
			}
		}

		if (calculationsCompleted == true)
		{
			return iteration + 1;
		}

		Assign_Points_To_Clusters(pInPointArray, numOfPoints, pOutCentroidArray, numOfClusters);
	}

	return -1;
}

int32_t Calculate_Clusters_OMP(CNDClusterCentroid *pOutCentroidArray, int32_t numOfClusters, CNDPoint_InsideCluster *pInPointArray, int32_t numOfPoints, int32_t numIterationsMax)
{
	for (int32_t i = 0; i < numOfClusters; i++)
	{
		pOutCentroidArray[i].calculationsCompleted = false;
	}

	Assign_Points_To_Clusters_OMP(pInPointArray, numOfPoints, pOutCentroidArray, numOfClusters);

	for (int32_t iteration = 0; iteration < numIterationsMax; iteration++)
	{
		bool calculationsCompleted = true;

		for (int32_t i = 0; i < numOfClusters; i++)
		{
			if (pOutCentroidArray[i].Calculate_NewCenter(pInPointArray, numOfPoints) == false)
			{
				calculationsCompleted = false;
			}
		}

		if (calculationsCompleted == true)
		{
			return iteration + 1;
		}

		Assign_Points_To_Clusters_OMP(pInPointArray, numOfPoints, pOutCentroidArray, numOfClusters);
	}

	return -1;
}

int32_t Calculate_Clusters(C1DClusterCentroid *pOutCentroidArray, int32_t numOfClusters, C1DPoint_InsideCluster *pInPointArray, int32_t numOfPoints, int32_t numIterationsMax)
{
	for (int32_t i = 0; i < numOfClusters; i++)
	{
		pOutCentroidArray[i].calculationsCompleted = false;
	}

	Assign_Points_To_Clusters(pInPointArray, numOfPoints, pOutCentroidArray, numOfClusters);

	for (int32_t iteration = 0; iteration < numIterationsMax; iteration++)
	{
		bool calculationsCompleted = true;

		for (int32_t i = 0; i < numOfClusters; i++)
		{
			if (pOutCentroidArray[i].Calculate_NewCenter(pInPointArray, numOfPoints) == false)
			{
				calculationsCompleted = false;
			}
		}

		if (calculationsCompleted == true)
		{
			return iteration + 1;
		}

		Assign_Points_To_Clusters(pInPointArray, numOfPoints, pOutCentroidArray, numOfClusters);
	}

	return -1;
}

int32_t Calculate_Clusters_OMP(C1DClusterCentroid *pOutCentroidArray, int32_t numOfClusters, C1DPoint_InsideCluster *pInPointArray, int32_t numOfPoints, int32_t numIterationsMax)
{
	for (int32_t i = 0; i < numOfClusters; i++)
	{
		pOutCentroidArray[i].calculationsCompleted = false;
	}

	Assign_Points_To_Clusters_OMP(pInPointArray, numOfPoints, pOutCentroidArray, numOfClusters);

	for (int32_t iteration = 0; iteration < numIterationsMax; iteration++)
	{
		bool calculationsCompleted = true;

		for (int32_t i = 0; i < numOfClusters; i++)
		{
			if (pOutCentroidArray[i].Calculate_NewCenter(pInPointArray, numOfPoints) == false)
			{
				calculationsCompleted = false;
			}
		}

		if (calculationsCompleted == true)
		{
			return iteration + 1;
		}

		Assign_Points_To_Clusters_OMP(pInPointArray, numOfPoints, pOutCentroidArray, numOfClusters);
	}

	return -1;
}

int32_t Calculate_Clusters(C2DClusterCentroid *pOutCentroidArray, int32_t numOfClusters, C2DPoint_InsideCluster *pInPointArray, int32_t numOfPoints, int32_t numIterationsMax)
{

	for (int32_t i = 0; i < numOfClusters; i++)
	{
		pOutCentroidArray[i].calculationsCompleted = false;
	}

	Assign_Points_To_Clusters(pInPointArray, numOfPoints, pOutCentroidArray, numOfClusters);

	for (int32_t iteration = 0; iteration < numIterationsMax; iteration++)
	{
		bool calculationsCompleted = true;

		for (int32_t i = 0; i < numOfClusters; i++)
		{
			if (pOutCentroidArray[i].Calculate_NewCenter(pInPointArray, numOfPoints) == false)
			{
				calculationsCompleted = false;
			}
		}

		if (calculationsCompleted == true)
		{
			return iteration + 1;
		}

		Assign_Points_To_Clusters(pInPointArray, numOfPoints, pOutCentroidArray, numOfClusters);
	}

	return -1;
}

int32_t Calculate_Clusters(C3DClusterCentroid *pOutCentroidArray, int32_t numOfClusters, C3DPoint_InsideCluster *pInPointArray, int32_t numOfPoints, int32_t numIterationsMax)
{
	for (int32_t i = 0; i < numOfClusters; i++)
	{
		pOutCentroidArray[i].calculationsCompleted = false;
	}

	Assign_Points_To_Clusters(pInPointArray, numOfPoints, pOutCentroidArray, numOfClusters);

	for (int32_t iteration = 0; iteration < numIterationsMax; iteration++)
	{
		bool calculationsCompleted = true;

		for (int32_t i = 0; i < numOfClusters; i++)
		{
			if (pOutCentroidArray[i].Calculate_NewCenter(pInPointArray, numOfPoints) == false)
			{
				calculationsCompleted = false;
			}
		}

		if (calculationsCompleted == true)
		{
			return iteration + 1;
		}

		Assign_Points_To_Clusters(pInPointArray, numOfPoints, pOutCentroidArray, numOfClusters);
	}

	return -1;
}

int32_t Calculate_Clusters_OMP(C2DClusterCentroid *pOutCentroidArray, int32_t numOfClusters, C2DPoint_InsideCluster *pInPointArray, int32_t numOfPoints, int32_t numIterationsMax)
{
	for (int32_t i = 0; i < numOfClusters; i++)
	{
		pOutCentroidArray[i].calculationsCompleted = false;
	}

	Assign_Points_To_Clusters_OMP(pInPointArray, numOfPoints, pOutCentroidArray, numOfClusters);

	for (int32_t iteration = 0; iteration < numIterationsMax; iteration++)
	{
		bool calculationsCompleted = true;

		for (int32_t i = 0; i < numOfClusters; i++)
		{
			if (pOutCentroidArray[i].Calculate_NewCenter(pInPointArray, numOfPoints) == false)
			{
				calculationsCompleted = false;
			}
		}

		if (calculationsCompleted == true)
		{
			return iteration + 1;
		}

		Assign_Points_To_Clusters_OMP(pInPointArray, numOfPoints, pOutCentroidArray, numOfClusters);
	}

	return -1;
}

int32_t Calculate_Clusters_OMP(C3DClusterCentroid *pOutCentroidArray, int32_t numOfClusters, C3DPoint_InsideCluster *pInPointArray, int32_t numOfPoints, int32_t numIterationsMax)
{
	for (int32_t i = 0; i < numOfClusters; i++)
	{
		pOutCentroidArray[i].calculationsCompleted = false;
	}

	Assign_Points_To_Clusters_OMP(pInPointArray, numOfPoints, pOutCentroidArray, numOfClusters);

	for (int32_t iteration = 0; iteration < numIterationsMax; iteration++)
	{
		bool calculationsCompleted = true;

		for (int32_t i = 0; i < numOfClusters; i++)
		{
			if (pOutCentroidArray[i].Calculate_NewCenter(pInPointArray, numOfPoints) == false)
			{
				calculationsCompleted = false;
			}
		}

		if (calculationsCompleted == true)
		{
			return iteration + 1;
		}

		Assign_Points_To_Clusters_OMP(pInPointArray, numOfPoints, pOutCentroidArray, numOfClusters);
	}

	return -1;
}




