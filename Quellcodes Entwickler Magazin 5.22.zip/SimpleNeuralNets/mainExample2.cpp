#include <iostream>
#include "NeuralNet.h"

using namespace std;

inline float LinearOutput(float neuronInput)
{
	return neuronInput;
}

class CAdaptiveMultiplierBrain
{
public:

	uint32_t NumInputNeurons = 1;
	uint32_t NumOutputNeurons = 1;

	uint32_t NumNeurons = NumInputNeurons + NumOutputNeurons;

	uint32_t InputNeuronID = 0;
	uint32_t OutputNeuronID = 1;

	CNeuron *pNeuronArray = nullptr;

	CRandomNumbersNN RandomNumbers;

	CAdaptiveMultiplierBrain()
	{
		pNeuronArray = new (std::nothrow) CNeuron[NumNeurons];

		for (uint32_t i = 0; i < NumNeurons; i++)
			pNeuronArray[i].Connect_With_Brain(pNeuronArray);

		pNeuronArray[InputNeuronID].Use_As_InputNeuron();
		pNeuronArray[InputNeuronID].Init_OutputSynapses(NumOutputNeurons);
		pNeuronArray[InputNeuronID].Connect_With_ReceiverNeuron(OutputNeuronID, /*SynapseID:*/ 0);
		pNeuronArray[InputNeuronID].Randomize_OutputSynapsePlasticities(&RandomNumbers, -3.0f, 3.0f);
		pNeuronArray[InputNeuronID].Set_LearningRate(0.2f);

		pNeuronArray[OutputNeuronID].Use_As_OutputNeuron();
		pNeuronArray[OutputNeuronID].Set_ActivationFunction(LinearOutput);
		pNeuronArray[OutputNeuronID].Set_ErrorFactors(1.0f, 0.025f);	
	}

	~CAdaptiveMultiplierBrain()
	{
		delete[] pNeuronArray;
		pNeuronArray = nullptr;
	}

	// Kopierkonstruktor l�schen:
	CAdaptiveMultiplierBrain(const CAdaptiveMultiplierBrain &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CAdaptiveMultiplierBrain& operator=(const CAdaptiveMultiplierBrain &originalObject) = delete;

	float Calculate_Output(float input)
	{
		pNeuronArray[InputNeuronID].Set_Input(input);
		pNeuronArray[InputNeuronID].Propagate_SynapticOutput();

		pNeuronArray[OutputNeuronID].Calculate_NeuronOutput();
		return pNeuronArray[OutputNeuronID].Get_NeuronOutput();
	}

	float Learning(float desiredOutput)
	{
		float error = pNeuronArray[OutputNeuronID].Calculate_Error(desiredOutput);

		pNeuronArray[InputNeuronID].Adjust_OutputSynapses_AfterErrorCalculations();

		return error;
	}
}; // end of class CAdaptiveMultiplierBrain

/*
int main(void)
{
	CAdaptiveMultiplierBrain Brain;

	float Input1 = 0.0f;
	float Input2 = 1.0f;
	float Input3 = 2.0f;
	float Input4 = 3.0f;


	uint32_t maxCount = 10000;
	uint32_t epoch = 0;
	float error;

	// Steigung (slope) =>  Output = slope * Input 
	float slope = 4.0f;

	// start training:

	for (uint32_t i = 0; i < maxCount; i++)
	{
		epoch++;
		error = 0.0f;

		Brain.Calculate_Output(Input1);
		error += Brain.Learning(// desired output:
							    slope * Input1);

		Brain.Calculate_Output(Input2);
		error += Brain.Learning(slope * Input2);

		Brain.Calculate_Output(Input3);
		error += Brain.Learning(slope * Input3);

		Brain.Calculate_Output(Input4);
		error += Brain.Learning(slope * Input4);

		if (error < 0.00001f)
			break;
	}

	// training completed

	// training statistics:

	cout << "epoch: " << epoch << endl;
	cout << "error: " << error << endl << endl;

	// neural network tests:

	cout << "input : " << Input1 << endl;
	cout << "output: " << Brain.Calculate_Output(Input1) << " --- desired output: " << slope * Input1 << endl;
	// (desired output: 0)

	cout << "input : " << Input2 << endl;
	cout << "output: " << Brain.Calculate_Output(Input2) << " --- desired output: " << slope * Input2 << endl;
	// (desired output: 4)

	cout << "input : " << Input3 << endl;
	cout << "output: " << Brain.Calculate_Output(Input3) << " --- desired output: " << slope * Input3 << endl;
	// (desired output: 8)

	cout << "input : " << Input4 << endl;
	cout << "output: " << Brain.Calculate_Output(Input4) << " --- desired output: " << slope * Input4 << endl;
	// (desired output: 12)

	cout << "test input: " << 10.0f << endl;
	cout << "output: " << Brain.Calculate_Output(10.0f) << " --- desired output: " << slope * 10.0f << endl;
	// (desired output: 40)

	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CNeuralNet Brain;
	Brain.Init_NeuralNet(2);
	Brain.Init_TwoLayerNetwork(1, -3.0f, 3.0f, 0.2f, false, 1, LinearOutput, 1.0f, 0.025f);

	float Input1 = 0.0f;
	float Input2 = 1.0f;
	float Input3 = 2.0f;
	float Input4 = 3.0f;

	float output;
	float desiredOutput;

	uint32_t maxCount = 10000;
	uint32_t epoch = 0;
	float error;

	// Steigung (slope) =>  Output = slope * Input 
	float slope = 4.0f;

	// start training:

	for (uint32_t i = 0; i < maxCount; i++)
	{
		epoch++;
		error = 0.0f;

		Brain.Calculate_Output_TwoLayerNetwork(&output, &Input1);

		desiredOutput = slope * Input1;
		error += Brain.Learning_TwoLayerNetwork(&desiredOutput);

		Brain.Calculate_Output_TwoLayerNetwork(&output, &Input2);

		desiredOutput = slope * Input2;
		error += Brain.Learning_TwoLayerNetwork(&desiredOutput);

		Brain.Calculate_Output_TwoLayerNetwork(&output, &Input3);

		desiredOutput = slope * Input3;
		error += Brain.Learning_TwoLayerNetwork(&desiredOutput);

		Brain.Calculate_Output_TwoLayerNetwork(&output, &Input4);

		desiredOutput = slope * Input4;
		error += Brain.Learning_TwoLayerNetwork(&desiredOutput);

		if (error < 0.00001f)
			break;
	}

	// training completed

	// training statistics:

	cout << "epoch: " << epoch << endl;
	cout << "error: " << error << endl << endl;

	// neural network tests:

	Brain.Calculate_Output_TwoLayerNetwork(&output, &Input1);
	cout << "input : " << Input1 << endl;
	cout << "output: " << output << " --- desired output: " << slope * Input1 << endl;
	// (desired output: 0)

	Brain.Calculate_Output_TwoLayerNetwork(&output, &Input2);
	cout << "input : " << Input2 << endl;
	cout << "output: " << output << " --- desired output: " << slope * Input2 << endl;
	// (desired output: 4)

	Brain.Calculate_Output_TwoLayerNetwork(&output, &Input3);
	cout << "input : " << Input3 << endl;
	cout << "output: " << output << " --- desired output: " << slope * Input3 << endl;
	// (desired output: 8)

	Brain.Calculate_Output_TwoLayerNetwork(&output, &Input4);
	cout << "input : " << Input4 << endl;
	cout << "output: " << output << " --- desired output: " << slope * Input4 << endl;
	// (desired output: 12)

	float testInput = 10.0f;
	Brain.Calculate_Output_TwoLayerNetwork(&output, &testInput);

	cout << "test input: " << 10.0f << endl;
	cout << "output: " << output << " --- desired output: " << slope * 10.0f << endl;
	// (desired output: 40)

	getchar();
	return 0;
}
*/