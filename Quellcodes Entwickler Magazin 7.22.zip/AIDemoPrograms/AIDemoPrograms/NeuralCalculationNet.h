// Schutz vor Mehrfachdeklarationen :
#ifndef _NeuralCalculationNet_H_
#define _NeuralCalculationNet_H_

#pragma warning( disable: 4996)

#include <iostream>
#include <fstream>
#include "LogFile.h"
#include "RandomNumbers.h"
#include "MathInlineFunctions.h"
#include "SimpleFeatureMap.h"


#ifndef max
#define max(a,b)    ( ((a) > (b)) ? (a) : (b) )
#endif

#ifndef min
#define min(a,b)    ( ((a) < (b)) ? (a) : (b) )
#endif

#define StandardPropagationFunctionID 0
#define RBFPropagationFunctionID 1
#define LeftHalfRBFPropagationFunctionID 2
#define RightHalfRBFPropagationFunctionID 3

#define StandardMaxPropagationFunctionID 4
#define RBFMaxPropagationFunctionID 5
#define LeftHalfRBFMaxPropagationFunctionID 6
#define RightHalfRBFMaxPropagationFunctionID 7

#define StandardMinPropagationFunctionID 8
#define RBFMinPropagationFunctionID 9
#define LeftHalfRBFMinPropagationFunctionID 10
#define RightHalfRBFMinPropagationFunctionID 11


class CNeuralCalculationUnit;
class CNeuralConnection;
class CCalculationUnitLayer;

class CEvolutionParameter_NeuralCalculationNet
{
public:

	// some parameters:
	float value1 = 0.0f;
	float value2 = 0.0f;
	float value3 = 0.0f;
	float value4 = 0.0f;
	float value5 = 0.0f;
	float value6 = 0.0f;
	float value7 = 0.0f;
	float value8 = 0.0f;
	float value9 = 0.0f;

	CCalculationUnitLayer* pInputLayer = nullptr;
	CCalculationUnitLayer* pHiddenLayer1 = nullptr;
	CCalculationUnitLayer* pHiddenLayer2 = nullptr;
	CCalculationUnitLayer* pOutputLayer = nullptr;

	CEvolutionParameter_NeuralCalculationNet() {}
	~CEvolutionParameter_NeuralCalculationNet() {}
};




typedef void(*pNeuralCalculationFunction)(CNeuralCalculationUnit *pCalculationUnit);
typedef void(*pNeuralPropagationFunction)(CNeuralCalculationUnit* pDestinationCalculationUnit, CNeuralConnection* pConnection);

void StandardPropagationFunction(CNeuralCalculationUnit* pDestinationCalculationUnit, CNeuralConnection* pConnection);
void RBFPropagationFunction(CNeuralCalculationUnit* pDestinationCalculationUnit, CNeuralConnection* pConnection);
void LeftHalfRBFPropagationFunction(CNeuralCalculationUnit* pDestinationCalculationUnit, CNeuralConnection* pConnection);
void RightHalfRBFPropagationFunction(CNeuralCalculationUnit* pDestinationCalculationUnit, CNeuralConnection* pConnection);

void StandardMaxPropagationFunction(CNeuralCalculationUnit* pDestinationCalculationUnit, CNeuralConnection* pConnection);
void RBFMaxPropagationFunction(CNeuralCalculationUnit* pDestinationCalculationUnit, CNeuralConnection* pConnection);
void LeftHalfRBFMaxPropagationFunction(CNeuralCalculationUnit* pDestinationCalculationUnit, CNeuralConnection* pConnection);
void RightHalfRBFMaxPropagationFunction(CNeuralCalculationUnit* pDestinationCalculationUnit, CNeuralConnection* pConnection);

void StandardMinPropagationFunction(CNeuralCalculationUnit* pDestinationCalculationUnit, CNeuralConnection* pConnection);
void RBFMinPropagationFunction(CNeuralCalculationUnit* pDestinationCalculationUnit, CNeuralConnection* pConnection);
void LeftHalfRBFMinPropagationFunction(CNeuralCalculationUnit* pDestinationCalculationUnit, CNeuralConnection* pConnection);
void RightHalfRBFMinPropagationFunction(CNeuralCalculationUnit* pDestinationCalculationUnit, CNeuralConnection* pConnection);




/*
static void Identity(CNeuralCalculationUnit *pCalculationUnit)
{
	pCalculationUnit->OutputValue = pCalculationUnit->SumOfInputValues;
	pCalculationUnit->SumOfInputValues = 0.0f;
	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}

static void LinearClippedToOne(CNeuralCalculationUnit* pCalculationUnit)
{
	pCalculationUnit->OutputValue = min(pCalculationUnit->SumOfInputValues, 1.0f);
	pCalculationUnit->SumOfInputValues = 0.0f;
	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}

static void Maximum(CNeuralCalculationUnit* pCalculationUnit)
{
	pCalculationUnit->OutputValue = pCalculationUnit->SumOfInputValues;
	pCalculationUnit->SumOfInputValues = -1000000.0f;
	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}

static void Minimum(CNeuralCalculationUnit* pCalculationUnit)
{
	pCalculationUnit->OutputValue = pCalculationUnit->SumOfInputValues;
	pCalculationUnit->SumOfInputValues = 1000000.0f;
	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}

static void SumUp(CNeuralCalculationUnit *pCalculationUnit)
{
	pCalculationUnit->OutputValue += pCalculationUnit->SumOfInputValues;
	pCalculationUnit->SumOfInputValues = 0.0f;
	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}


static void SumUpExt(CNeuralCalculationUnit *pCalculationUnit)
{
	pCalculationUnit->OutputValue += pCalculationUnit->AdditionalCalcValueArray[0] * pCalculationUnit->SumOfInputValues;
	pCalculationUnit->SumOfInputValues = 0.0f;
	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}

static void Bias(CNeuralCalculationUnit *pCalculationUnit)
{
	pCalculationUnit->OutputValue = 1.0f;
	pCalculationUnit->SumOfInputValues = 0.0f;
	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}

static void NegBias(CNeuralCalculationUnit *pCalculationUnit)
{
	pCalculationUnit->OutputValue = -1.0f;
	pCalculationUnit->SumOfInputValues = 0.0f;
	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}

static void StdBinaryOutput(CNeuralCalculationUnit *pCalculationUnit)
{
	if (pCalculationUnit->SumOfInputValues > 0.0f)
	{
		pCalculationUnit->OutputValue = 1.0f;
		pCalculationUnit->SumOfInputValues = 0.0f;
		//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
		return;
	}

	pCalculationUnit->OutputValue = 0.0f;
	pCalculationUnit->SumOfInputValues = 0.0f;
}

static void BinaryOutput2(CNeuralCalculationUnit *pCalculationUnit)
{
	if (pCalculationUnit->SumOfInputValues > 0.999f)
	{
		pCalculationUnit->OutputValue = 1.0f;
		pCalculationUnit->SumOfInputValues = 0.0f;
		//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
		return;
	}

	pCalculationUnit->OutputValue = 0.0f;
	pCalculationUnit->SumOfInputValues = 0.0f;
}

static void Spiking(CNeuralCalculationUnit *pCalculationUnit)
{
	pCalculationUnit->OutputValue = 0.0f;

	if (pCalculationUnit->SumOfInputValues > 0.999f)
	{
		pCalculationUnit->OutputValue = 1.0f;
		pCalculationUnit->SumOfInputValues = 0.0f;
		//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
	}
	else
	{
		//pCalculationUnit->SumOfInputValues -= 0.1f;
		pCalculationUnit->SumOfInputValues -= pCalculationUnit->AdditionalCalcValueArray[0];
		pCalculationUnit->SumOfInputValues = max(pCalculationUnit->SumOfInputValues, 0.0f);
	}
}

static void LinearAccumulation(CNeuralCalculationUnit *pCalculationUnit)
{
	if (pCalculationUnit->SumOfInputValues > 0.999f)
	{
		pCalculationUnit->OutputValue = 1.0f;
		pCalculationUnit->SumOfInputValues = 0.0f;
		//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
		return;
	}

	pCalculationUnit->OutputValue = 0.0f;
}

static void OneTenthCounterStep(CNeuralCalculationUnit *pCalculationUnit)
{
	if (pCalculationUnit->SumOfInputValues > 0.999f)
	{
		pCalculationUnit->OutputValue = 1.0f;
		pCalculationUnit->SumOfInputValues = 0.0f;
		//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
		return;
	}

	pCalculationUnit->SumOfInputValues += 0.1f;
	pCalculationUnit->OutputValue = 0.0f;
}

static void BinaryRadialClusterCheck(CNeuralCalculationUnit* pCalculationUnit)
{
	pCalculationUnit->OutputValue = 0.0f;

	if (pCalculationUnit->SumOfInputValues < 1.0f)
	{
		pCalculationUnit->OutputValue = 1.0f;
		//pCalculationUnit->SumOfOutputValues += 1.0f;
	}

	pCalculationUnit->SumOfInputValues = 0.0f;
}

static void BinaryRadialClusterCheckSumUp(CNeuralCalculationUnit* pCalculationUnit)
{
	float tempFloat = 0.0f;

	if (pCalculationUnit->SumOfInputValues < 1.0f)
		tempFloat = 1.0f;


	pCalculationUnit->OutputValue += tempFloat;

	pCalculationUnit->SumOfInputValues = 0.0f;
	//pCalculationUnit->SumOfOutputValues += tempFloat;
}

static void ExpRBF(CNeuralCalculationUnit *pCalculationUnit)
{
	pCalculationUnit->OutputValue = exp(-pCalculationUnit->SumOfInputValues);
	pCalculationUnit->SumOfInputValues = 0.0f;
	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}

static void OneMinusExpRBF(CNeuralCalculationUnit* pCalculationUnit)
{
	pCalculationUnit->OutputValue = 1.0f - exp(-pCalculationUnit->SumOfInputValues);
	pCalculationUnit->SumOfInputValues = 0.0f;
	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}

static void ExpRBFSumUp(CNeuralCalculationUnit* pCalculationUnit)
{
	float tempFloat = exp(-pCalculationUnit->SumOfInputValues);
	pCalculationUnit->OutputValue += tempFloat;
	pCalculationUnit->SumOfInputValues = 0.0f;
	//pCalculationUnit->SumOfOutputValues += tempFloat;
}

static void ClippedExpRBF(CNeuralCalculationUnit* pCalculationUnit)
{
	pCalculationUnit->OutputValue = min(1.0f, pCalculationUnit->AdditionalCalcValueArray[0] * exp(-pCalculationUnit->SumOfInputValues));
	pCalculationUnit->SumOfInputValues = 0.0f;
	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}

static void ExpRBF2(CNeuralCalculationUnit* pCalculationUnit)
{
	float tempFloat = pCalculationUnit->SumOfInputValues - pCalculationUnit->AdditionalCalcValueArray[1];
	tempFloat *= tempFloat;
	tempFloat *= pCalculationUnit->AdditionalCalcValueArray[0];

	pCalculationUnit->OutputValue = exp(-tempFloat);
	pCalculationUnit->SumOfInputValues = 0.0f;

	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}

static void ClippedExpRBF2(CNeuralCalculationUnit* pCalculationUnit)
{
	float tempFloat = pCalculationUnit->SumOfInputValues - pCalculationUnit->AdditionalCalcValueArray[1];
	tempFloat *= tempFloat;
	tempFloat *= pCalculationUnit->AdditionalCalcValueArray[0];

	pCalculationUnit->OutputValue = min(1.0f, pCalculationUnit->AdditionalCalcValueArray[2] * exp(-tempFloat));
	pCalculationUnit->SumOfInputValues = 0.0f;

	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}


static void ReLU(CNeuralCalculationUnit *pCalculationUnit)
{
	pCalculationUnit->OutputValue = max(0.0f, pCalculationUnit->SumOfInputValues);
	pCalculationUnit->SumOfInputValues = 0.0f;
	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}
static void LeakyReLU(CNeuralCalculationUnit *pCalculationUnit)
{
	float sumOfInputValues = pCalculationUnit->SumOfInputValues;

	if (sumOfInputValues < 0.0f)
		pCalculationUnit->OutputValue = 0.01f * sumOfInputValues;
	else
		pCalculationUnit->OutputValue = sumOfInputValues;

	pCalculationUnit->SumOfInputValues = 0.0f;

	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}

static void Sigmoid(CNeuralCalculationUnit *pCalculationUnit)
{
	// von 0.0f bis 1.0f:
	pCalculationUnit->OutputValue = 1.0f / (1.0f + exp(-pCalculationUnit->SumOfInputValues));
	pCalculationUnit->SumOfInputValues = 0.0f;
	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}

static void ScaledSigmoid(CNeuralCalculationUnit *pCalculationUnit)
{
	// von 0.0f bis 1.0f:
	pCalculationUnit->OutputValue = 1.0f / (1.0f + exp(-10.0f * pCalculationUnit->SumOfInputValues));
	pCalculationUnit->SumOfInputValues = 0.0f;
	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}

static void TanH(CNeuralCalculationUnit *pCalculationUnit)
{
	// von -1.0f bis 1.0f:
	pCalculationUnit->OutputValue = tanh(pCalculationUnit->SumOfInputValues);
	pCalculationUnit->SumOfInputValues = 0.0f;
	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}

static void ScaledTanH(CNeuralCalculationUnit *pCalculationUnit)
{
	pCalculationUnit->OutputValue = tanh(0.1f * pCalculationUnit->SumOfInputValues);
	pCalculationUnit->SumOfInputValues = 0.0f;
	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}

static void FastTanHReplacement(CNeuralCalculationUnit *pCalculationUnit)
{
	// von -1.0f bis 1.0f:
	pCalculationUnit->OutputValue = pCalculationUnit->SumOfInputValues / (1.0f + abs(pCalculationUnit->SumOfInputValues));
	pCalculationUnit->SumOfInputValues = 0.0f;
	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}


static void MultiplyWith2(CNeuralCalculationUnit *pCalculationUnit)
{
	pCalculationUnit->OutputValue = 2.0f * pCalculationUnit->SumOfInputValues;
	pCalculationUnit->SumOfInputValues = 0.0f;
	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}

static void Multiply(CNeuralCalculationUnit* pCalculationUnit)
{
	pCalculationUnit->OutputValue = pCalculationUnit->AdditionalCalcValueArray[0] * pCalculationUnit->SumOfInputValues;
	pCalculationUnit->SumOfInputValues = 0.0f;
	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}

static void Quadric(CNeuralCalculationUnit* pCalculationUnit)
{
	float tempFloat = pCalculationUnit->SumOfInputValues;
	tempFloat *= tempFloat;
	pCalculationUnit->OutputValue = tempFloat;
	pCalculationUnit->SumOfInputValues = 0.0f;
	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}

static void Cubic(CNeuralCalculationUnit* pCalculationUnit)
{
	float tempFloat = pCalculationUnit->SumOfInputValues;
	pCalculationUnit->OutputValue = tempFloat * tempFloat * tempFloat;
	pCalculationUnit->SumOfInputValues = 0.0f;
	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}

*/






class CNeuralCalculationFunctions
{
public:

	int32_t NumOfFunctions = 0;

	pNeuralCalculationFunction *pFunctionArray = nullptr;

	CNeuralCalculationFunctions();
	~CNeuralCalculationFunctions();

	// Kopierkonstruktor l�schen:
	CNeuralCalculationFunctions(const CNeuralCalculationFunctions  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CNeuralCalculationFunctions & operator=(const CNeuralCalculationFunctions  &originalObject) = delete;

	void Initialize(int32_t numOfFunctions);
	void Set_Function(int32_t id, pNeuralCalculationFunction pFunc);
};

#define UsageStatus_CalculationUnit_Standard  1
#define UsageStatus_CalculationInputUnit      2
#define UsageStatus_CalculationOutputUnit     3

static constexpr int32_t NeuralCalcUnit_NumOfAdditionalCalcValues = 3;

class CNeuralCalculationUnit
{
public:

	int32_t UsageStatus = UsageStatus_CalculationUnit_Standard;

	int32_t FunctionID = 0;
	pNeuralCalculationFunction pCalculationFunction = nullptr;

	float ErrorFactor1 = 1.0f;
	float ErrorFactor2 = 1.0f;
	float LearningRate = 0.1f;

	float ErrorValue = 0.0f;
	float ErrorSumOfSubsequentUnits = 0.0f;

	float SumOfInputValues = 0.0f;
	float OutputValue = 0.0f;
	float SumOfOutputValues = 0.0f;

	float AdditionalCalcValueArray[NeuralCalcUnit_NumOfAdditionalCalcValues];

	int32_t PropagationFunctionID = 0;
	
	CNeuralCalculationUnit();
	~CNeuralCalculationUnit();

	// Kopierkonstruktor l�schen:
	CNeuralCalculationUnit(const CNeuralCalculationUnit  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CNeuralCalculationUnit & operator=(const CNeuralCalculationUnit  &originalObject) = delete;

	void Set_ErrorFactors(float errorFactor1, float errorFactor2);
	void Set_LearningRate(float learningRate);

	void Set_AdditionalCalculationValue(float value, int32_t valueID);

	void Set_CalculationFunction(int32_t functionID, pNeuralCalculationFunction pFunc);
	void Set_CalculationFunction(int32_t functionID, CNeuralCalculationFunctions *pFunctions);

	void Set_PropagationFunction(int32_t functionID);

	void Calculate_OutputValue(void);

	void Reset_CalculationValues(void);

	void Clone_Data(CNeuralCalculationUnit *pOriginalObject);

	float Calculate_Variance(float desiredOutput);

	float Calculate_Variance_And_Error(float desiredOutput, float errorFactor1, float errorFactor2);

	float Calculate_Variance_And_Error(float desiredOutput);

	
	
	/* Fehlerberechnung unter Ber�cksichtigung der bereits berechneten Fehler von
	s�mtlichen Receiver-Units (nachgeschalteten Units): */
	void Calculate_Error(void);
	void Calculate_Error(float errorFactor1, float errorFactor2);
};


class CNeuralConnection
{
public:

	float PlasticityValue = 1.0f;
	float CentroidValue = 0.0f;
	float RBFConstant = 0.0f;

	float TransmissionValue = 0.0f;

	CNeuralConnection();
	~CNeuralConnection();

	// Kopierkonstruktor l�schen:
	CNeuralConnection(const CNeuralConnection  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CNeuralConnection & operator=(const CNeuralConnection  &originalObject) = delete;

	void Modify_TransmissionValue_For_Propagation(void);

	void Modify_TransmissionValue_For_StandardPropagation(void);
	void Modify_TransmissionValue_For_RBFPropagation(void);
	void Modify_TransmissionValue_For_LeftHalfRBFPropagation(void);
	void Modify_TransmissionValue_For_RightHalfRBFPropagation(void);

	void Clone_Data(CNeuralConnection *pOriginalObject);
};

class CNeuralCalculationNetDesc
{
public:

	int32_t NumOfCalculationUnits = 0;
	int32_t NumOfNeuralConnections = 0;

	int32_t *pCalculationFunctionIDArray = nullptr;
	int32_t *pCalculationUnitUsageStatusArray = nullptr;

	float *pAdditionalCalcValueArray = nullptr;

	int32_t *pPropagationFunctionIDArray = nullptr;

	int32_t *pConnectionStatusArray = nullptr;
	float *pPlasticityValueArray = nullptr;
	float *pCentroidValueArray = nullptr;
	float *pRBFConstantArray = nullptr;

	float FitnessScore = 0.0f;

	CNeuralCalculationNetDesc();
	~CNeuralCalculationNetDesc();

	// Kopierkonstruktor l�schen:
	CNeuralCalculationNetDesc(const CNeuralCalculationNetDesc  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CNeuralCalculationNetDesc & operator=(const CNeuralCalculationNetDesc  &originalObject) = delete;

	void Initialize(int32_t numOfCalculationUnits);

	void Clone(CNeuralCalculationNetDesc *pOriginalObject);
	void Clone_Values(CNeuralCalculationNetDesc *pOriginalObject);

	bool Load_Data(const char* pFilename, bool memoryAllocation = true);
	bool Save_Data(const char* pFilename);
};

/*
static void ConstructionFunction_1DCentroidNetDesc(CNeuralCalculationNetDesc* pOutCalculationNetDesc, int32_t numOfCentroids, float rbfConstant, int32_t inputUnitCalcFuncID, int32_t hiddenUnitCalcFuncID, int32_t outputUnitCalcFuncID, bool initAdditionalCentroidOutputUnits)
{

	int32_t numOfInputUnits = 1;
	int32_t numOfHiddenUnits = numOfCentroids;
	int32_t numOfOutputUnits = 1;

	if (initAdditionalCentroidOutputUnits == true)
	{
		numOfOutputUnits += numOfCentroids;
	}

	int32_t numOfCalculationUnits = numOfInputUnits + numOfHiddenUnits + numOfOutputUnits;

	int32_t idOfFirstInputUnit = 0;
	int32_t idOfFirstHiddenUnit = numOfInputUnits;
	int32_t idOfFirstOutputUnit = idOfFirstHiddenUnit + numOfHiddenUnits;
	int32_t idOfFirstAdditionalOutputUnit = idOfFirstOutputUnit + 1;

	pOutCalculationNetDesc->Initialize(numOfCalculationUnits);

	for (int32_t i = 0; i < numOfInputUnits; i++)
	{
		pOutCalculationNetDesc->pCalculationFunctionIDArray[i] = inputUnitCalcFuncID;
		pOutCalculationNetDesc->pCalculationUnitUsageStatusArray[i] = UsageStatus_CalculationInputUnit;
	}

	for (int32_t i = 0; i < numOfHiddenUnits; i++)
	{
		int32_t unitID = i + idOfFirstHiddenUnit;
		pOutCalculationNetDesc->pCalculationFunctionIDArray[unitID] = hiddenUnitCalcFuncID;
		pOutCalculationNetDesc->pCalculationUnitUsageStatusArray[unitID] = UsageStatus_CalculationUnit_Standard;
	}

	for (int32_t i = 0; i < numOfOutputUnits; i++)
	{
		int32_t unitID = i + idOfFirstOutputUnit;
		pOutCalculationNetDesc->pCalculationFunctionIDArray[unitID] = outputUnitCalcFuncID;
		pOutCalculationNetDesc->pCalculationUnitUsageStatusArray[unitID] = UsageStatus_CalculationOutputUnit;
	}

	// InputNeurons -> HiddenNeurons
	for (int32_t iy = 0; iy < idOfFirstHiddenUnit; iy++)
	{
		for (int32_t ix = idOfFirstHiddenUnit; ix < idOfFirstOutputUnit; ix++)
		{
			int32_t id = ix + iy * numOfCalculationUnits;
			pOutCalculationNetDesc->pConnectionStatusArray[id] = 1;
			pOutCalculationNetDesc->pPlasticityValueArray[id] = 1.0f;
			pOutCalculationNetDesc->pRBFConstantArray[id] = rbfConstant;
			pOutCalculationNetDesc->pCentroidValueArray[id] = 0.0f;
		}
	}

	// HiddenNeurons -> first OutputNeuron
	//for (int32_t iy = idOfFirstHiddenUnit; iy < idOfFirstOutputUnit; iy++)
	//{
		//for (int32_t ix = idOfFirstOutputUnit; ix < idOfFirstAdditionalOutputUnit; ix++)
		//{
		//	int32_t id = ix + iy * numOfCalculationUnits;
			//pOutCalculationNetDesc->pConnectionStatusArray[id] = 1;
			//pOutCalculationNetDesc->pPlasticityValueArray[id] = 1.0f;
		//}
	//}

	if (initAdditionalCentroidOutputUnits == false)
	{
		for (int32_t iy = idOfFirstHiddenUnit; iy < idOfFirstOutputUnit; iy++)
		{
			int32_t ix = idOfFirstOutputUnit;

			int32_t id = ix + iy * numOfCalculationUnits;
			pOutCalculationNetDesc->pConnectionStatusArray[id] = 1;
			pOutCalculationNetDesc->pPlasticityValueArray[id] = 1.0f;
		}
	}
	else //if (initAdditionalCentroidOutputUnits == true)
	{
		int32_t counter = 1;

		for (int32_t iy = idOfFirstHiddenUnit; iy < idOfFirstOutputUnit; iy++)
		{
			int32_t ix = idOfFirstOutputUnit;

			int32_t id = ix + iy * numOfCalculationUnits;
			pOutCalculationNetDesc->pConnectionStatusArray[id] = 1;
			pOutCalculationNetDesc->pPlasticityValueArray[id] = 1.0f;

			id += counter;
			pOutCalculationNetDesc->pConnectionStatusArray[id] = 1;
			pOutCalculationNetDesc->pPlasticityValueArray[id] = 1.0f;
			counter++;
		}
	}

	
}

static void ConstructionFunction_2DCentroidNetDesc(CNeuralCalculationNetDesc* pOutCalculationNetDesc, int32_t numOfCentroids, float rbfConstant, int32_t inputUnitCalcFuncID, int32_t hiddenUnitCalcFuncID, int32_t outputUnitCalcFuncID, bool initAdditionalCentroidOutputUnits)
{
	int32_t numOfInputUnits = 2;
	int32_t numOfHiddenUnits = numOfCentroids;
	int32_t numOfOutputUnits = 1;

	if (initAdditionalCentroidOutputUnits == true)
	{
		numOfOutputUnits += numOfCentroids;
	}

	int32_t numOfCalculationUnits = numOfInputUnits + numOfHiddenUnits + numOfOutputUnits;

	int32_t idOfFirstInputUnit = 0;
	int32_t idOfFirstHiddenUnit = numOfInputUnits;
	int32_t idOfFirstOutputUnit = idOfFirstHiddenUnit + numOfHiddenUnits;
	int32_t idOfFirstAdditionalOutputUnit = idOfFirstOutputUnit + 1;

	pOutCalculationNetDesc->Initialize(numOfCalculationUnits);

	for (int32_t i = 0; i < numOfInputUnits; i++)
	{
		pOutCalculationNetDesc->pCalculationFunctionIDArray[i] = inputUnitCalcFuncID;
		pOutCalculationNetDesc->pCalculationUnitUsageStatusArray[i] = UsageStatus_CalculationInputUnit;
	}

	for (int32_t i = 0; i < numOfHiddenUnits; i++)
	{
		int32_t unitID = i + idOfFirstHiddenUnit;
		pOutCalculationNetDesc->pCalculationFunctionIDArray[unitID] = hiddenUnitCalcFuncID;
		pOutCalculationNetDesc->pCalculationUnitUsageStatusArray[unitID] = UsageStatus_CalculationUnit_Standard;
	}

	for (int32_t i = 0; i < numOfOutputUnits; i++)
	{
		int32_t unitID = i + idOfFirstOutputUnit;
		pOutCalculationNetDesc->pCalculationFunctionIDArray[unitID] = outputUnitCalcFuncID;
		pOutCalculationNetDesc->pCalculationUnitUsageStatusArray[unitID] = UsageStatus_CalculationOutputUnit;
	}

	// InputNeurons -> HiddenNeurons
	for (int32_t iy = 0; iy < idOfFirstHiddenUnit; iy++)
	{
		for (int32_t ix = idOfFirstHiddenUnit; ix < idOfFirstOutputUnit; ix++)
		{
			int32_t id = ix + iy * numOfCalculationUnits;
			pOutCalculationNetDesc->pConnectionStatusArray[id] = 1;
			pOutCalculationNetDesc->pPlasticityValueArray[id] = 1.0f;
			pOutCalculationNetDesc->pRBFConstantArray[id] = rbfConstant;
			pOutCalculationNetDesc->pCentroidValueArray[id] = 0.0f;
		}
	}

	// HiddenNeurons -> first OutputNeuron
	//for (int32_t iy = idOfFirstHiddenUnit; iy < idOfFirstOutputUnit; iy++)
	//{
		//for (int32_t ix = idOfFirstOutputUnit; ix < idOfFirstAdditionalOutputUnit; ix++)
	//	{
		//	int32_t id = ix + iy * numOfCalculationUnits;
		//	pOutCalculationNetDesc->pConnectionStatusArray[id] = 1;
		//	pOutCalculationNetDesc->pPlasticityValueArray[id] = 1.0f;
		//}
	//}

	if (initAdditionalCentroidOutputUnits == false)
	{
		for (int32_t iy = idOfFirstHiddenUnit; iy < idOfFirstOutputUnit; iy++)
		{
			int32_t ix = idOfFirstOutputUnit;

			int32_t id = ix + iy * numOfCalculationUnits;
			pOutCalculationNetDesc->pConnectionStatusArray[id] = 1;
			pOutCalculationNetDesc->pPlasticityValueArray[id] = 1.0f;
		}
	}
	else //if (initAdditionalCentroidOutputUnits == true)
	{
		int32_t counter = 1;

		for (int32_t iy = idOfFirstHiddenUnit; iy < idOfFirstOutputUnit; iy++)
		{
			int32_t ix = idOfFirstOutputUnit;

			int32_t id = ix + iy * numOfCalculationUnits;
			pOutCalculationNetDesc->pConnectionStatusArray[id] = 1;
			pOutCalculationNetDesc->pPlasticityValueArray[id] = 1.0f;

			id += counter;
			pOutCalculationNetDesc->pConnectionStatusArray[id] = 1;
			pOutCalculationNetDesc->pPlasticityValueArray[id] = 1.0f;
			counter++;
		}
	}

}

static void ConstructionFunction_3DCentroidNetDesc(CNeuralCalculationNetDesc* pOutCalculationNetDesc, int32_t numOfCentroids, float rbfConstant, int32_t inputUnitCalcFuncID, int32_t hiddenUnitCalcFuncID, int32_t outputUnitCalcFuncID, bool initAdditionalCentroidOutputUnits)
{
	int32_t numOfInputUnits = 3;
	int32_t numOfHiddenUnits = numOfCentroids;
	int32_t numOfOutputUnits = 1;

	if (initAdditionalCentroidOutputUnits == true)
	{
		numOfOutputUnits += numOfCentroids;
	}

	int32_t numOfCalculationUnits = numOfInputUnits + numOfHiddenUnits + numOfOutputUnits;

	int32_t idOfFirstInputUnit = 0;
	int32_t idOfFirstHiddenUnit = numOfInputUnits;
	int32_t idOfFirstOutputUnit = idOfFirstHiddenUnit + numOfHiddenUnits;
	int32_t idOfFirstAdditionalOutputUnit = idOfFirstOutputUnit + 1;

	pOutCalculationNetDesc->Initialize(numOfCalculationUnits);

	for (int32_t i = 0; i < numOfInputUnits; i++)
	{
		pOutCalculationNetDesc->pCalculationFunctionIDArray[i] = inputUnitCalcFuncID;
		pOutCalculationNetDesc->pCalculationUnitUsageStatusArray[i] = UsageStatus_CalculationInputUnit;
	}

	for (int32_t i = 0; i < numOfHiddenUnits; i++)
	{
		int32_t unitID = i + idOfFirstHiddenUnit;
		pOutCalculationNetDesc->pCalculationFunctionIDArray[unitID] = hiddenUnitCalcFuncID;
		pOutCalculationNetDesc->pCalculationUnitUsageStatusArray[unitID] = UsageStatus_CalculationUnit_Standard;
	}

	for (int32_t i = 0; i < numOfOutputUnits; i++)
	{
		int32_t unitID = i + idOfFirstOutputUnit;
		pOutCalculationNetDesc->pCalculationFunctionIDArray[unitID] = outputUnitCalcFuncID;
		pOutCalculationNetDesc->pCalculationUnitUsageStatusArray[unitID] = UsageStatus_CalculationOutputUnit;
	}
	// InputNeurons -> HiddenNeurons
	for (int32_t iy = 0; iy < idOfFirstHiddenUnit; iy++)
	{
		for (int32_t ix = idOfFirstHiddenUnit; ix < idOfFirstOutputUnit; ix++)
		{
			int32_t id = ix + iy * numOfCalculationUnits;
			pOutCalculationNetDesc->pConnectionStatusArray[id] = 1;
			pOutCalculationNetDesc->pPlasticityValueArray[id] = 1.0f;
			pOutCalculationNetDesc->pRBFConstantArray[id] = rbfConstant;
			pOutCalculationNetDesc->pCentroidValueArray[id] = 0.0f;
		}
	}

	// HiddenNeurons -> first OutputNeuron
	//for (int32_t iy = idOfFirstHiddenUnit; iy < idOfFirstOutputUnit; iy++)
	//{
		//for (int32_t ix = idOfFirstOutputUnit; ix < idOfFirstAdditionalOutputUnit; ix++)
		//{
			//int32_t id = ix + iy * numOfCalculationUnits;
			//pOutCalculationNetDesc->pConnectionStatusArray[id] = 1;
			//pOutCalculationNetDesc->pPlasticityValueArray[id] = 1.0f;
		//}
	//}

	if (initAdditionalCentroidOutputUnits == false)
	{
		for (int32_t iy = idOfFirstHiddenUnit; iy < idOfFirstOutputUnit; iy++)
		{
			int32_t ix = idOfFirstOutputUnit;

			int32_t id = ix + iy * numOfCalculationUnits;
			pOutCalculationNetDesc->pConnectionStatusArray[id] = 1;
			pOutCalculationNetDesc->pPlasticityValueArray[id] = 1.0f;
		}
	}
	else //if (initAdditionalCentroidOutputUnits == true)
	{
		int32_t counter = 1;

		for (int32_t iy = idOfFirstHiddenUnit; iy < idOfFirstOutputUnit; iy++)
		{
			int32_t ix = idOfFirstOutputUnit;

			int32_t id = ix + iy * numOfCalculationUnits;
			pOutCalculationNetDesc->pConnectionStatusArray[id] = 1;
			pOutCalculationNetDesc->pPlasticityValueArray[id] = 1.0f;

			id += counter;
			pOutCalculationNetDesc->pConnectionStatusArray[id] = 1;
			pOutCalculationNetDesc->pPlasticityValueArray[id] = 1.0f;
			counter++;
		}
	}


}
*/




class CNeuralCalculationNet
{
public:

	int32_t NumOfCalculationUnits = 0;
	int32_t NumOfNeuralConnections = 0;

	CNeuralCalculationUnit *pCalculationUnitArray = nullptr;
	CNeuralConnection *pConnectionArray = nullptr;

	CNeuralConnection **ppConnectionNet = nullptr;

	int32_t NumOfInputUnits = 0;
	int32_t NumOfOutputUnits = 0;

	int32_t *pInputUnitIDArray = nullptr;
	int32_t *pOutputUnitIDArray = nullptr;

	CNeuralCalculationNet();
	~CNeuralCalculationNet();

	// Kopierkonstruktor l�schen:
	CNeuralCalculationNet(const CNeuralCalculationNet  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CNeuralCalculationNet & operator=(const CNeuralCalculationNet  &originalObject) = delete;

	void Initialize(int32_t numOfCalculationUnits, int32_t numOfInputUnits, int32_t numOfOutputUnits);
	void Initialize(CNeuralCalculationNetDesc *pInDesc, CNeuralCalculationFunctions *pFunctions, int32_t numOfInputUnits, int32_t numOfOutputUnits);

	void Modify(CNeuralCalculationNetDesc *pInDesc, CNeuralCalculationFunctions *pFunctions);

	void Readout_Data(CNeuralCalculationNetDesc *pOutDesc, bool memoryAllocation = true);

	void Set_CalculationFunction(int32_t unitID, int32_t functionID, pNeuralCalculationFunction pFunc);
	void Set_CalculationFunction(int32_t unitID, int32_t functionID, CNeuralCalculationFunctions *pFunctions);

	void Set_PropagationFunction(int32_t unitID, int32_t functionID);

	void Deactivate_Connections_If_Possible(void);

	void Set_ConnectionValues(int32_t connectionID, float plasticityValue, float centroidValue = 0.0f, float rBFConstant = 0.0f);

	// ix: SubsequentCalculationUnitID | iy: CalculationUnitID
	void Set_ConnectionValues(int32_t ix, int32_t iy, float plasticityValue, float centroidValue = 0.0f, float rBFConstant = 0.0f);

	void Set_Connection_PlasticityValue(int32_t connectionID, float plasticityValue);
	float Get_Connection_PlasticityValue(int32_t connectionID);

	// ix: SubsequentCalculationUnitID | iy: CalculationUnitID
	void Set_Connection_PlasticityValue(int32_t ix, int32_t iy, float plasticityValue);
	float Get_Connection_PlasticityValue(int32_t ix, int32_t iy);

	void Set_Connection_CentroidValue(int32_t connectionID, float centroidValue);
	float Get_Connection_CentroidValue(int32_t connectionID);

	// ix: SubsequentCalculationUnitID | iy: CalculationUnitID
	void Set_Connection_CentroidValue(int32_t ix, int32_t iy, float centroidValue);
	float Get_Connection_CentroidValue(int32_t ix, int32_t iy);

	void Set_Connection_RBFConstant(int32_t connectionID, float rBFConstant);
	float Get_Connection_RBFConstant(int32_t connectionID);

	// ix: SubsequentCalculationUnitID | iy: CalculationUnitID
	void Set_Connection_RBFConstant(int32_t ix, int32_t iy, float rBFConstant);
	float Get_Connection_RBFConstant(int32_t ix, int32_t iy);

	void Activate_Connection(int32_t connectionID);

	// ix: SubsequentCalculationUnitID | iy: CalculationUnitID
	void Activate_Connection(int32_t ix, int32_t iy);

	void Deactivate_Connection(int32_t connectionID);

	// ix: SubsequentCalculationUnitID | iy: CalculationUnitID
	void Deactivate_Connection(int32_t ix, int32_t iy);

	void Execute_Calculations(void);

	float Calculate_OutputVarianceSum_And_OutputError(float *pDesiredOutputValueArray, float errorFactor1, float errorFactor2);
	float Calculate_OutputVarianceSum_And_OutputError(float *pDesiredOutputValueArray);

	float Calculate_OutputVarianceSum(float *pDesiredOutputValueArray);
	float Calculate_OutputVarianceSum(float *pDesiredOutputValueArray, int32_t firstOutputUnitID, int32_t numOfOutputUnits);

	void Learning(void);
	void Learning(float learningRate, float errorFactor1, float errorFactor2);

	void ExtremeLearning(void);
	void ExtremeLearning(float learningRate);

	void Clone_NeuralCalculationUnitValues(CNeuralCalculationNet *pOriginalObject);
	void Clone_NeuralConnectionValues(CNeuralCalculationNet *pOriginalObject);
	void Clone_ConnectionNet(CNeuralCalculationNet *pOriginalObject);

	void Set_CalculationUnit_AdditionalCalculationValue(int32_t unitID, float value, int32_t valueID);

	void Set_InputUnit_AdditionalCalculationValue(int32_t unitID, float value, int32_t valueID);
	void Set_OutputUnit_AdditionalCalculationValue(int32_t unitID, float value, int32_t valueID);

	void Set_InputUnits_AdditionalCalculationValue(float value, int32_t valueID);
	void Set_OutputUnits_AdditionalCalculationValue(float value, int32_t valueID);


	float Get_CalculationUnit_With_MinSumOfOutputValues(int32_t* pOutUnitID, int32_t* pInUnitIDArray, int32_t numOfUnits);
	float Get_CalculationUnit_With_MaxSumOfOutputValues(int32_t* pOutUnitID, int32_t* pInUnitIDArray, int32_t numOfUnits);

	void Reset_CalculationUnits_SumOfOutputValues(void);
	void Reset_CalculationUnits_SumOfOutputValues(int32_t *pUnitIDArray, int32_t numOfUnits);
	void Reset_CalculationUnits_SumOfOutputValues(int32_t minUnitID, int32_t maxUnitIdPlus1);

	void Reset_InputUnits_OutputValue(void);
	void Reset_OutputUnits_OutputValue(void);
	void Reset_CalculationUnit_OutputValue(int32_t unitID);
	void Reset_CalculationUnits_OutputValue(void);
	void Reset_CalculationUnits_OutputValue(int32_t* pUnitIDArray, int32_t numOfUnits);
	void Reset_CalculationUnits_OutputValue(int32_t minUnitID, int32_t maxUnitIdPlus1);

	void Reset_InputUnits_SumOfInputValues(void);
	void Reset_OutputUnits_SumOfInputValues(void);
	void Reset_CalculationUnit_SumOfInputValues(int32_t unitID);
	void Reset_CalculationUnits_SumOfInputValues(void);
	void Reset_CalculationUnits_SumOfInputValues(int32_t* pUnitIDArray, int32_t numOfUnits);
	void Reset_CalculationUnits_SumOfInputValues(int32_t minUnitID, int32_t maxUnitIdPlus1);

	void Reset_UsageStatus_Of_CalculationUnits(void);

	void Set_InputUnits(int32_t *pUnitIDArray);
	void Set_OutputUnits(int32_t *pUnitIDArray);

	void Set_InputUnit(int32_t unitID, int32_t inputUnitIDArrayIndex);
	void Set_OutputUnit(int32_t unitID, int32_t outputUnitIDArrayIndex);

	void Get_OutputValues(float *pOutputValueArray);
	void Get_SoftmaxOutputValues(float *pOutputValueArray);
	float Get_OutputValue(int32_t outputUnitIDArrayIndex);

	void Set_InputValue(float value);
	void Add_InputValue(float value);

	void Set_InputValue(float value, int32_t inputUnitIDArrayIndex);
	void Add_InputValue(float value, int32_t inputUnitIDArrayIndex);

	void Set_InputValues(float *pInputValueArray);
	void Add_InputValues(float *pInputValueArray);

	void Set_InputValues(float *pInputValueArray, int32_t firstArrayElementID);
	void Add_InputValues(float *pInputValueArray, int32_t firstArrayElementID);
	
	// LRF: local receptive field
	bool Set_InputValues_UseLRFCenterPos(int32_t posX_center, int32_t posY_center, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY);

	// LRF: local receptive field
	bool Set_InputValues_UseLRFTopLeftPos(int32_t posX_left, int32_t posY_top, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY);

	// LRF: local receptive field
	bool Add_InputValues_UseLRFCenterPos(int32_t posX_center, int32_t posY_center, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY);

	// LRF: local receptive field
	bool Add_InputValues_UseLRFTopLeftPos(int32_t posX_left, int32_t posY_top, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY);
};


class CProbabilityDistributionTable
{
public:

	int32_t NumOfTableValuesMax = 0;
	int32_t NumOfTableValuesUsed = 0;

	int32_t *pTableValueArray = nullptr;

	CProbabilityDistributionTable();
	~CProbabilityDistributionTable();

	// Kopierkonstruktor l�schen:
	CProbabilityDistributionTable(const CProbabilityDistributionTable& originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CProbabilityDistributionTable& operator=(const CProbabilityDistributionTable& originalObject) = delete;

	void Initialize(int32_t numOfTableValuesMax);

	int32_t Get_Value(CRandomNumbersNN* pRandomNumbers);
};

void Update_ProbabilityDistributionTable(CProbabilityDistributionTable *pOutTable, CNeuralCalculationNet *pCalculationNet, int32_t *pCalcUnitIDArray, int32_t NumOfCalcUnits);



class CCalculationUnitLayer
{
public:

	int32_t FirstUnitID = 0;
	int32_t LastUnitIDPlus1 = 0;
	int32_t NumOfLayerUnits = 0;

	void Intialize(int32_t firstUnitID, int32_t numOfLayerUnits);

	void Set_CalculationFunctions(CNeuralCalculationNet* pCalculationNet, int32_t functionID, pNeuralCalculationFunction pFunc);

	void Set_CalculationFunctions(CNeuralCalculationNet* pCalculationNet, int32_t functionID, CNeuralCalculationFunctions* pFunctions);

	void Set_CalculationFunctions(CNeuralCalculationNetDesc* pCalculationNetDesc, int32_t functionID);
	

	//Attention: Set_BiasUnit() must be called after Set_CalculationFunctions()!
	void Set_BiasUnit(CNeuralCalculationNet* pCalculationNet, int32_t calculationUnitID, int32_t functionID, pNeuralCalculationFunction pFunc);
	void Set_BiasUnit(CNeuralCalculationNetDesc* pCalculationNetDesc, int32_t calculationUnitID, int32_t functionID);
	
	//Attention: Set_BiasUnit() must be called after Set_CalculationFunctions()!
	void Set_BiasUnit(CNeuralCalculationNet* pCalculationNet, int32_t calculationUnitID, int32_t functionID, CNeuralCalculationFunctions* pFunctions);

	//Attention: Set_CalculationFunction() must be called after Set_CalculationFunctions()!
	void Set_CalculationFunction(CNeuralCalculationNet* pCalculationNet, int32_t calculationUnitID, int32_t functionID, pNeuralCalculationFunction pFunc);
	void Set_CalculationFunction(CNeuralCalculationNetDesc* pCalculationNetDesc, int32_t calculationUnitID, int32_t functionID);

	//Attention: Set_CalculationFunction() must be called after Set_CalculationFunctions()!
	void Set_CalculationFunction(CNeuralCalculationNet* pCalculationNet, int32_t calculationUnitID, int32_t functionID, CNeuralCalculationFunctions* pFunctions);

	void Set_PropagationFunction(CNeuralCalculationNet* pCalculationNet, int32_t calculationUnitID, int32_t functionID);
	void Set_PropagationFunction(CNeuralCalculationNetDesc* pCalculationNetDesc, int32_t calculationUnitID, int32_t functionID);

	void Set_PropagationFunctions(CNeuralCalculationNet* pCalculationNet, int32_t functionID);
	void Set_PropagationFunctions(CNeuralCalculationNetDesc* pCalculationNetDesc, int32_t functionID);


	void Set_LearningRate(CNeuralCalculationNet* pCalculationNet, float learningRate);
	void Set_ErrorFactors(CNeuralCalculationNet* pCalculationNet, float errorFactor1, float errorFactor2);

	void Set_IncomingValues(CNeuralCalculationNet* pCalculationNet, CCalculationUnitLayer* pPrecedentLayer, int32_t calculationUnitID, float* pPlasticityValues, float* pRBFConstants, float* pRBFCentroidValues);
	void Set_IncomingValues(CNeuralCalculationNetDesc* pCalculationNetDesc, CCalculationUnitLayer* pPrecedentLayer, int32_t calculationUnitID, float* pPlasticityValues, float* pRBFConstants, float* pRBFCentroidValues);


	void Set_IncomingPlasticityValues(CNeuralCalculationNet* pCalculationNet, CCalculationUnitLayer* pPrecedentLayer, int32_t calculationUnitID, float* pPlasticityValues);
	void Set_IncomingPlasticityValues(CNeuralCalculationNetDesc* pCalculationNetDesc, CCalculationUnitLayer* pPrecedentLayer, int32_t calculationUnitID, float* pPlasticityValues);

	void Set_IncomingRBFConstants(CNeuralCalculationNet* pCalculationNet, CCalculationUnitLayer* pPrecedentLayer, int32_t calculationUnitID, float* pRBFConstants);
	void Set_IncomingRBFConstants(CNeuralCalculationNetDesc* pCalculationNetDesc, CCalculationUnitLayer* pPrecedentLayer, int32_t calculationUnitID, float* pRBFConstants);
	
	void Set_IncomingRBFCentroidValues(CNeuralCalculationNet* pCalculationNet, CCalculationUnitLayer* pPrecedentLayer, int32_t calculationUnitID, float* pRBFCentroidValues);
	void Set_IncomingRBFCentroidValues(CNeuralCalculationNetDesc* pCalculationNetDesc, CCalculationUnitLayer* pPrecedentLayer, int32_t calculationUnitID, float* pRBFCentroidValues);
	
	void Set_IncomingRBFValues(CNeuralCalculationNet* pCalculationNet, CCalculationUnitLayer* pPrecedentLayer, int32_t calculationUnitID, float* pRBFConstants, float* pRBFCentroidValues);
	void Set_IncomingRBFValues(CNeuralCalculationNetDesc* pCalculationNetDesc, CCalculationUnitLayer* pPrecedentLayer, int32_t calculationUnitID, float* pRBFConstants, float* pRBFCentroidValues);

	void Set_RandomPlasticityValues(CNeuralCalculationNet* pCalculationNet, CCalculationUnitLayer* pSubsequentLayer, float minPlasticity, float maxPlasticity, CRandomNumbersNN* pRandomNumbers);
	void Set_RandomPlasticityValues(CNeuralCalculationNetDesc* pCalculationNetDesc, CCalculationUnitLayer* pSubsequentLayer, float minPlasticity, float maxPlasticity, CRandomNumbersNN* pRandomNumbers);

	void Set_RandomRBFValues(CNeuralCalculationNet* pCalculationNet, CCalculationUnitLayer* pSubsequentLayer, float rbfConstant, float minCentroidValue, float maxCentroidValue, CRandomNumbersNN* pRandomNumbers);
	void Set_RandomRBFValues(CNeuralCalculationNetDesc* pCalculationNetDesc, CCalculationUnitLayer* pSubsequentLayer, float rbfConstant, float minCentroidValue, float maxCentroidValue, CRandomNumbersNN* pRandomNumbers);

	void Set_RandomRBFValues(CNeuralCalculationNet* pCalculationNet, CCalculationUnitLayer* pSubsequentLayer, float minRbfConstant, float maxRbfConstant, float minCentroidValue, float maxCentroidValue, CRandomNumbersNN* pRandomNumbers);
	void Set_RandomRBFValues(CNeuralCalculationNetDesc* pCalculationNetDesc, CCalculationUnitLayer* pSubsequentLayer, float minRbfConstant, float maxRbfConstant, float minCentroidValue, float maxCentroidValue, CRandomNumbersNN* pRandomNumbers);

	void Activate_Connections(CNeuralCalculationNet* pCalculationNet, CCalculationUnitLayer* pSubsequentLayer);
	void Activate_Connections_If_Possible(CNeuralCalculationNet* pCalculationNet, CCalculationUnitLayer* pSubsequentLayer);
	void Activate_Connections(CNeuralCalculationNetDesc* pCalculationNetDesc, CCalculationUnitLayer* pSubsequentLayer);
	void Activate_Connections_If_Possible(CNeuralCalculationNetDesc* pCalculationNetDesc, CCalculationUnitLayer* pSubsequentLayer);

	void Deactivate_Connections(CNeuralCalculationNet* pCalculationNet, CCalculationUnitLayer* pSubsequentLayer);
	void Deactivate_Connections_If_Possible(CNeuralCalculationNet* pCalculationNet, CCalculationUnitLayer* pSubsequentLayer);
	void Deactivate_Connections(CNeuralCalculationNetDesc* pCalculationNetDesc, CCalculationUnitLayer* pSubsequentLayer);
	void Deactivate_Connections_If_Possible(CNeuralCalculationNetDesc* pCalculationNetDesc, CCalculationUnitLayer* pSubsequentLayer);
};





inline void CentroidNet_Get_SoftmaxClusterData(float *pOutputValueArray, CNeuralCalculationNet *pCalculationNet)
{
	int32_t numOfOutputUnits = pCalculationNet->NumOfOutputUnits;

	int32_t *pOutputUnitIDArray = pCalculationNet->pOutputUnitIDArray;

	CNeuralCalculationUnit *pCalculationUnitArray = pCalculationNet->pCalculationUnitArray;

	for (int32_t i = 1; i < numOfOutputUnits; i++)
	{
		pOutputValueArray[i] = pCalculationUnitArray[pOutputUnitIDArray[i]].OutputValue;
	}

	SoftMax(pOutputValueArray, numOfOutputUnits);
}

inline void CentroidNet_Get_ClusterMinMaxRelation(float *pOutputRelation, CNeuralCalculationNet *pCalculationNet)
{
	int32_t numOfOutputUnits = pCalculationNet->NumOfOutputUnits;

	int32_t *pOutputUnitIDArray = pCalculationNet->pOutputUnitIDArray;

	CNeuralCalculationUnit *pCalculationUnitArray = pCalculationNet->pCalculationUnitArray;

	float minValue = 1000000.0f;
	float maxValue = 0.0001f;

	for (int32_t i = 1; i < numOfOutputUnits; i++)
	{
		float tempValue = pCalculationUnitArray[pOutputUnitIDArray[i]].OutputValue;

		minValue = min(minValue, tempValue);
		maxValue = max(maxValue, tempValue);
	}
	
	*pOutputRelation = minValue / maxValue;
}


/*
inline void Set_Input_1DimCentroidNet(float pos, float value, CNeuralCalculationNet *pCalculationNet)
{
	pCalculationNet->Set_InputValue(pos);
	pCalculationNet->Set_OutputUnits_AdditionalCalculationValue(value, 0);
}

inline bool Set_Input_1DimCentroidNet(float pos, float value, CNeuralCalculationNet *pCalculationNet, float valueMinThreshold)
{
	if (value < valueMinThreshold)
	{
		return false;
	}

	pCalculationNet->Set_InputValue(pos);
	pCalculationNet->Set_OutputUnits_AdditionalCalculationValue(value, 0);

	true;
}

inline bool Set_Input_1DimCentroidNet(float pos, float value, CNeuralCalculationNet *pCalculationNet, float valueMinThreshold, float valueMaxThreshold)
{
	if (value < valueMinThreshold)
	{
		return false;
	}
	if (value > valueMaxThreshold)
	{
		return false;
	}

	pCalculationNet->Set_InputValue(pos);
	pCalculationNet->Set_OutputUnits_AdditionalCalculationValue(value, 0);

	true;
}


inline void Set_Input_2DimCentroidNet(float posX, float posY, float value, CNeuralCalculationNet *pCalculationNet)
{
	static float Pos2D[2];
	Pos2D[0] = posX;
	Pos2D[1] = posY;
	pCalculationNet->Set_InputValues(Pos2D);
	pCalculationNet->Set_OutputUnits_AdditionalCalculationValue(value, 0);
}

inline bool Set_Input_2DimCentroidNet(float posX, float posY, float value, CNeuralCalculationNet *pCalculationNet, float valueMinThreshold)
{
	static float Pos2D[2];

	if (value < valueMinThreshold)
	{
		return false;
	}

	Pos2D[0] = posX;
	Pos2D[1] = posY;
	pCalculationNet->Set_InputValues(Pos2D);
	pCalculationNet->Set_OutputUnits_AdditionalCalculationValue(value, 0);

	return true;
}

inline bool Set_Input_2DimCentroidNet(float posX, float posY, float value, CNeuralCalculationNet *pCalculationNet, float valueMinThreshold, float valueMaxThreshold)
{
	static float Pos2D[2];

	if (value < valueMinThreshold)
	{
		return false;
	}
	if (value > valueMaxThreshold)
	{
		return false;
	}

	Pos2D[0] = posX;
	Pos2D[1] = posY;
	pCalculationNet->Set_InputValues(Pos2D);
	pCalculationNet->Set_OutputUnits_AdditionalCalculationValue(value, 0);

	return true;
}

inline void Set_Input_3DimCentroidNet(float posX, float posY, float posZ, float value, CNeuralCalculationNet *pCalculationNet)
{
	static float Pos3D[3];
	Pos3D[0] = posX;
	Pos3D[1] = posY;
	Pos3D[2] = posZ;
	pCalculationNet->Set_InputValues(Pos3D);
	pCalculationNet->Set_OutputUnits_AdditionalCalculationValue(value, 0);
}

inline bool Set_Input_3DimCentroidNet(float posX, float posY, float posZ, float value, CNeuralCalculationNet *pCalculationNet, float valueMinThreshold)
{
	static float Pos3D[3];

	if (value < valueMinThreshold)
	{
		return false;
	}

	Pos3D[0] = posX;
	Pos3D[1] = posY;
	Pos3D[2] = posZ;
	pCalculationNet->Set_InputValues(Pos3D);
	pCalculationNet->Set_OutputUnits_AdditionalCalculationValue(value, 0);

	return true;
}

inline bool Set_Input_3DimCentroidNet(float posX, float posY, float posZ, float value, CNeuralCalculationNet *pCalculationNet, float valueMinThreshold, float valueMaxThreshold)
{
	static float Pos3D[3];

	if (value < valueMinThreshold)
	{
		return false;
	}
	if (value > valueMaxThreshold)
	{
		return false;
	}

	Pos3D[0] = posX;
	Pos3D[1] = posY;
	Pos3D[2] = posZ;
	pCalculationNet->Set_InputValues(Pos3D);
	pCalculationNet->Set_OutputUnits_AdditionalCalculationValue(value, 0);

	return true;
}
*/



typedef void(*pCalculationNetDesc_Recombination)(CNeuralCalculationNetDesc *pOffspring, const CNeuralCalculationNetDesc *pParent1, const CNeuralCalculationNetDesc *pParent2, CRandomNumbersNN *pRandomNumbers, void *pParam);
typedef void(*pCalculationNetDesc_Mutation)(CNeuralCalculationNetDesc *pInOutNetDesc, CRandomNumbersNN *pRandomNumbers, void *pParam);
typedef void(*pCalculationNetDesc_Permutation)(CNeuralCalculationNetDesc *pInOutNetDesc, CRandomNumbersNN *pRandomNumbers, void *pParam);
typedef void(*pCalculationNetDesc_Reinitialization)(CNeuralCalculationNetDesc *pInOutNetDesc, CRandomNumbersNN *pRandomNumbers, void *pParam);
typedef void(*pCalculationNetDesc_Reinitialization2)(CNeuralCalculationNetDesc* pInOutNetDesc, CNeuralCalculationNetDesc* pInBaseNetDesc, CRandomNumbersNN* pRandomNumbers, void* pParam);
typedef void(*pCalculationNetDesc_Transformation)(CNeuralCalculationNetDesc* pInOutNetDesc, CRandomNumbersNN* pRandomNumbers, void *pParam);



class CNeuralCalculationNetDescPopulation
{
public:

	uint64_t Seed = 1;
	CRandomNumbersNN RandomNumbers;

	int32_t PopulationSize;
	int32_t PopulationSizePlusX;

	static constexpr int32_t constNumOfAdditionalBrains = 5;
	static constexpr int32_t constNumOfRandomBrainsChildren = constNumOfAdditionalBrains - 3;

	CNeuralCalculationNetDesc **ppDescArray = nullptr;
	float *pFitnessScoreArray = nullptr;

	static constexpr int32_t constNumOfBestFittedBrains = 10;
	int32_t IDArrayOfBestFittedBrains[constNumOfBestFittedBrains];
	float FitnessArrayOfBestFittedBrains[constNumOfBestFittedBrains];

	static constexpr int32_t constNumOfWorstFittedBrains = 10;
	int32_t IDArrayOfWorstFittedBrains[constNumOfWorstFittedBrains];
	float FitnessArrayOfWorstFittedBrains[constNumOfWorstFittedBrains];

	bool UseAdditionalMutatedBestBrain = false;
	bool UseAdditionalMutatedSecondBestBrain = false;
	bool UseAdditionalBestBrainsChild = false;
	bool UseAdditionalRandomBrainsChild[constNumOfRandomBrainsChildren];

	int32_t RandomBrainsChildCounter = 0;

	static constexpr int32_t constNumPopulationSearchStepsMax = 3;

	float MinErrorSum_ActualGeneration;

	CNeuralCalculationNetDescPopulation();
	~CNeuralCalculationNetDescPopulation();

	// Kopierkonstruktor l�schen:
	CNeuralCalculationNetDescPopulation(const CNeuralCalculationNetDescPopulation &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CNeuralCalculationNetDescPopulation& operator=(const CNeuralCalculationNetDescPopulation &originalObject) = delete;

	void Change_Seed(uint64_t seed);

	bool Initialize(int32_t populationSize);
	void Set_NeuralCalculationNetDesc(CNeuralCalculationNetDesc *pInDesc, int32_t id);

	CNeuralCalculationNetDesc* Get_Best_Evolved_NeuralCalculationNetDesc(void);
	void Get_Best_Evolved_NeuralCalculationNetDesc(CNeuralCalculationNetDesc* pOutDesc);

	void Reset_Population(void);

	void Reset_MinErrorSum_ActualGeneration(float value = 10000000.0f);
	void Update_MinErrorSum_ActualGeneration(float value);

	void Reset_FitnessScore(int32_t descID);
	void Calculate_FitnessScore_FromError(int32_t descID, float error);
	void Set_FitnessScore(int32_t descID, float score);
	void Add_FitnessScore(int32_t descID, float score);
	float Calculate_Error_From_FitnessScore(int32_t descID);
	float Get_FitnessScore(int32_t descID);
	void Replace_With_MinFitnessScore(int32_t descID, float score);
	void Replace_With_MaxFitnessScore(int32_t descID, float score);

	void Update_Population(void);
	void Update_Population_Ext(void);

	void Update_PopulationKnowledge(void);

	void Update_Evolution_Combine_BestTwoBrains(pCalculationNetDesc_Recombination pFunc, void *pParam);
	void Update_Evolution_Combine_BestTwoBrains(pCalculationNetDesc_Recombination pFunc, CRandomNumbersNN* pRandomNumbers, void* pParam);

	void Update_Evolution_Combine_TwoBrains(pCalculationNetDesc_Recombination pFunc, void *pParam);
	void Update_Evolution_Combine_TwoBrains(pCalculationNetDesc_Recombination pFunc, CRandomNumbersNN* pRandomNumbers, void* pParam);

	void Update_Evolution_Combine_TwoOfTheBestGenomes(pCalculationNetDesc_Recombination pFunc, void* pParam);
	void Update_Evolution_Combine_TwoOfTheBestGenomes(pCalculationNetDesc_Recombination pFunc, CRandomNumbersNN* pRandomNumbers, void* pParam);

	void Update_BaseEvolution(pCalculationNetDesc_Mutation pFunc, void *pParam);
	void Update_BaseEvolution(pCalculationNetDesc_Mutation pFunc, CRandomNumbersNN* pRandomNumbers, void* pParam);

	void Update_BaseEvolution(int32_t numOfIndividuals, pCalculationNetDesc_Mutation pFunc, void* pParam);
	void Update_BaseEvolution(int32_t numOfIndividuals, pCalculationNetDesc_Mutation pFunc, CRandomNumbersNN* pRandomNumbers, void* pParam);

	void Update_BaseEvolution_SingleIndividual(pCalculationNetDesc_Mutation pFunc, void* pParam);
	void Update_BaseEvolution_SingleIndividual(pCalculationNetDesc_Mutation pFunc, CRandomNumbersNN* pRandomNumbers, void* pParam);

	void Update_BaseEvolution2(pCalculationNetDesc_Permutation pFunc, void *pParam);
	void Update_BaseEvolution2(pCalculationNetDesc_Permutation pFunc, CRandomNumbersNN* pRandomNumbers, void* pParam);

	void Update_BaseEvolution2(int32_t numOfIndividuals, pCalculationNetDesc_Permutation pFunc, void* pParam);
	void Update_BaseEvolution2(int32_t numOfIndividuals, pCalculationNetDesc_Permutation pFunc, CRandomNumbersNN* pRandomNumbers, void* pParam);

	void Update_BaseEvolution2_SingleIndividual(pCalculationNetDesc_Permutation pFunc, void* pParam);
	void Update_BaseEvolution2_SingleIndividual(pCalculationNetDesc_Permutation pFunc, CRandomNumbersNN* pRandomNumbers, void* pParam);

	void Update_Evolution_BestBrainOnly(pCalculationNetDesc_Mutation pFunc, void *pParam);
	void Update_Evolution_BestBrainOnly(pCalculationNetDesc_Mutation pFunc, CRandomNumbersNN* pRandomNumbers, void* pParam);

	void Update_Evolution_BestBrainOnly2(pCalculationNetDesc_Permutation pFunc, void *pParam);
	void Update_Evolution_BestBrainOnly2(pCalculationNetDesc_Permutation pFunc, CRandomNumbersNN* pRandomNumbers, void* pParam);

	void Update_Evolution_SecondBestBrainOnly(pCalculationNetDesc_Mutation pFunc, void *pParam);
	void Update_Evolution_SecondBestBrainOnly(pCalculationNetDesc_Mutation pFunc, CRandomNumbersNN* pRandomNumbers, void* pParam);

	void Update_Evolution_SecondBestBrainOnly2(pCalculationNetDesc_Permutation pFunc, void *pParam);
	void Update_Evolution_SecondBestBrainOnly2(pCalculationNetDesc_Permutation pFunc, CRandomNumbersNN* pRandomNumbers, void* pParam);

	
	void Replace_WorstFitted_Brain(pCalculationNetDesc_Reinitialization pFunc, void *pParam);
	void Replace_SecondWorstFitted_Brain(pCalculationNetDesc_Reinitialization pFunc, void* pParam);
	void Replace_ThirdWorstFitted_Brain(pCalculationNetDesc_Reinitialization pFunc, void* pParam);

	void Replace_WorstFitted_Brain(pCalculationNetDesc_Reinitialization pFunc, CRandomNumbersNN* pRandomNumbers, void* pParam);
	void Replace_SecondWorstFitted_Brain(pCalculationNetDesc_Reinitialization pFunc, CRandomNumbersNN* pRandomNumbers, void* pParam);
	void Replace_ThirdWorstFitted_Brain(pCalculationNetDesc_Reinitialization pFunc, CRandomNumbersNN* pRandomNumbers, void* pParam);

	void Replace_WorstFitted_Brain(pCalculationNetDesc_Reinitialization2 pFunc, CNeuralCalculationNetDesc* pInBaseNetDesc, void* pParam);
	void Replace_SecondWorstFitted_Brain(pCalculationNetDesc_Reinitialization2 pFunc, CNeuralCalculationNetDesc* pInBaseNetDesc, void* pParam);
	void Replace_ThirdWorstFitted_Brain(pCalculationNetDesc_Reinitialization2 pFunc, CNeuralCalculationNetDesc* pInBaseNetDesc, void* pParam);

	void Replace_WorstFitted_Brain(pCalculationNetDesc_Reinitialization2 pFunc, CNeuralCalculationNetDesc* pInBaseNetDesc, CRandomNumbersNN* pRandomNumbers, void* pParam);
	void Replace_SecondWorstFitted_Brain(pCalculationNetDesc_Reinitialization2 pFunc, CNeuralCalculationNetDesc* pInBaseNetDesc, CRandomNumbersNN* pRandomNumbers, void* pParam);
	void Replace_ThirdWorstFitted_Brain(pCalculationNetDesc_Reinitialization2 pFunc, CNeuralCalculationNetDesc* pInBaseNetDesc, CRandomNumbersNN* pRandomNumbers, void* pParam);

	void Modify_All_Brains(pCalculationNetDesc_Mutation pFunc, void *pParam);
	void Modify_All_Brains(pCalculationNetDesc_Mutation pFunc, CRandomNumbersNN* pRandomNumbers, void* pParam);

	void Modify_All_Brains2(pCalculationNetDesc_Permutation pFunc, void *pParam);
	void Modify_All_Brains2(pCalculationNetDesc_Permutation pFunc, CRandomNumbersNN* pRandomNumbers, void* pParam);

	// e. g. deactivation of unnecessary connetions:
	void Transform_Species_If_Possible_BestBrainOnly(pCalculationNetDesc_Transformation pFunc, void* pParam);
	void Transform_Species_If_Possible_BestBrainOnly(pCalculationNetDesc_Transformation pFunc, CRandomNumbersNN* pRandomNumbers, void* pParam);
};










class CInt32OutputVector
{
public:

	int32_t PatternCounter = 0;
	int32_t *pExternalPatternPosXArray = nullptr;
	int32_t *pExternalPatternPosYArray = nullptr;

	CInt32OutputVector() {}
	~CInt32OutputVector() {}

	// Kopierkonstruktor l�schen:
	CInt32OutputVector(const CInt32OutputVector &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CInt32OutputVector& operator=(const CInt32OutputVector &originalObject) = delete;

	void Reset_PatternCounter(void)
	{
		PatternCounter = 0;
	}
};

class CFloatOutputVector
{
public:

	int32_t PatternCounter = 0;
	float *pExternalPatternPosXArray = nullptr;
	float *pExternalPatternPosYArray = nullptr;

	CFloatOutputVector() {}
	~CFloatOutputVector() {}

	// Kopierkonstruktor l�schen:
	CFloatOutputVector(const CFloatOutputVector &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CFloatOutputVector& operator=(const CFloatOutputVector &originalObject) = delete;

	void Reset_PatternCounter(void)
	{
		PatternCounter = 0;
	}
};


void Search_Pattern(int32_t *pOutPatternCount, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CNeuralCalculationNet *pDetectionBrain, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float minActivationValue);

void Search_Pattern(float *pOutPatternCount, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CNeuralCalculationNet *pDetectionBrain, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float minActivationValue);

void Search_Pattern(int32_t *pOutPatternCount, int32_t *pOutPatternPosXArray, int32_t *pOutPatternPosYArray, int32_t numPatternPositionsMax, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CNeuralCalculationNet *pDetectionBrain, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float minActivationValue);

void Search_Pattern(float *pOutPatternCount, float *pOutPatternPosXArray, float *pOutPatternPosYArray, int32_t numPatternPositionsMax, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CNeuralCalculationNet *pDetectionBrain, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float minActivationValue);


void Search_Pattern(CSimpleFeatureMap *pOutFeatureMap, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CNeuralCalculationNet *pDetectionBrain, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float minActivationValue);

void Add_Pattern(CSimpleFeatureMap *pOutFeatureMap, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CNeuralCalculationNet *pDetectionBrain, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float minActivationValue);

////

void Search_Pattern(int32_t *pOutPatternCount, CSimpleFeatureMap *pInSectorMap, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CNeuralCalculationNet *pDetectionBrain, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float minActivationValue);

void Search_Pattern(int32_t *pOutPatternCount, int32_t *pOutPatternPosXArray, int32_t *pOutPatternPosYArray, int32_t numPatternPositionsMax, CSimpleFeatureMap *pInSectorMap, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CNeuralCalculationNet *pDetectionBrain, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float minActivationValue);

void Search_Pattern(float *pOutPatternCount, CSimpleFeatureMap *pInSectorMap, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CNeuralCalculationNet *pDetectionBrain, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float minActivationValue);

void Search_Pattern(float *pOutPatternCount, float *pOutPatternPosXArray, float *pOutPatternPosYArray, int32_t numPatternPositionsMax, CSimpleFeatureMap *pInSectorMap, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CNeuralCalculationNet *pDetectionBrain, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float minActivationValue);


void Search_Pattern(CSimpleFeatureMap *pOutFeatureMap, CSimpleFeatureMap *pInSectorMap, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CNeuralCalculationNet *pDetectionBrain, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float minActivationValue);

void Add_Pattern(CSimpleFeatureMap *pOutFeatureMap, CSimpleFeatureMap *pInSectorMap, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CNeuralCalculationNet *pDetectionBrain, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float minActivationValue);



/////////////////////////

void Search_Patterns(CInt32OutputVector *pOutVectorArray, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CNeuralCalculationNet *pDetectionBrain, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float minActivationValue);

void Search_Patterns(CFloatOutputVector *pOutVectorArray, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CNeuralCalculationNet *pDetectionBrain, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float minActivationValue);



void Search_Patterns(CInt32OutputVector *pOutVectorArray, CSimpleFeatureMap *pInSectorMap, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CNeuralCalculationNet *pDetectionBrain, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float minActivationValue);

void Search_Patterns(CFloatOutputVector *pOutVectorArray, CSimpleFeatureMap *pInSectorMap, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CNeuralCalculationNet *pDetectionBrain, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float minActivationValue);



void Search_Patterns(CSimpleFeatureMap *pOutFeatureMapArray, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CNeuralCalculationNet *pDetectionBrain, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float minActivationValue);

void Add_Patterns(CSimpleFeatureMap *pOutFeatureMapArray, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CNeuralCalculationNet *pDetectionBrain, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float minActivationValue);

void Search_Patterns(CSimpleFeatureMap *pOutFeatureMapArray, CSimpleFeatureMap *pInSectorMap, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CNeuralCalculationNet *pDetectionBrain, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float minActivationValue);

void Add_Patterns(CSimpleFeatureMap *pOutFeatureMapArray, CSimpleFeatureMap *pInSectorMap, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CNeuralCalculationNet *pDetectionBrain, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float minActivationValue);



/*
static void XORBrain_Reinitialization(CNeuralCalculationNetDesc* pInOutNetDesc, CRandomNumbersNN* pRandomNumbers, void* pParam)
{
	//CEvolutionParameter_NeuralCalculationNet *pParameter = static_cast<CEvolutionParameter_NeuralCalculationNet*>(pParam);

	float minRandomPlasticity = -2.0f;
	float maxRandomPlasticity = 2.0f;

	int32_t numOfNeuralConnections = pInOutNetDesc->NumOfNeuralConnections;

	for (int32_t i = 0; i < numOfNeuralConnections; i++)
	{
		if (pInOutNetDesc->pConnectionStatusArray[i] == 0.0f)
			continue;

		pInOutNetDesc->pPlasticityValueArray[i] = pRandomNumbers->Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
	}

}

static void XORBrainRBF_Reinitialization(CNeuralCalculationNetDesc* pInOutNetDesc, CRandomNumbersNN* pRandomNumbers, void* pParam)
{
	//CEvolutionParameter_NeuralCalculationNet *pParameter = static_cast<CEvolutionParameter_NeuralCalculationNet*>(pParam);

	float minRandomCentroidValue = -2.0f;
	float maxRandomCentroidValue = 2.0f;
	//float minRandomPlasticity = -2.0f;
	//float maxRandomPlasticity = 2.0f;

	int32_t numOfNeuralConnections = pInOutNetDesc->NumOfNeuralConnections;

	for (int32_t i = 0; i < numOfNeuralConnections; i++)
	{
		if (pInOutNetDesc->pConnectionStatusArray[i] == 0.0f)
			continue;

		if (pInOutNetDesc->pRBFConstantArray[i] == 0.0f)
		{
			//pInOutNetDesc->pPlasticityValueArray[i] = pRandomNumbers->Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
		}
		else
		{
			pInOutNetDesc->pCentroidValueArray[i] = pRandomNumbers->Get_FloatNumber(minRandomCentroidValue, maxRandomCentroidValue);
		}
	}

}

static void BrainRBF_Reinitialization(CNeuralCalculationNetDesc* pInOutNetDesc, CRandomNumbersNN* pRandomNumbers, void* pParam)
{
	//CEvolutionParameter_NeuralCalculationNet *pParameter = static_cast<CEvolutionParameter_NeuralCalculationNet*>(pParam);

	float minRandomCentroidValue = -2.0f;
	float maxRandomCentroidValue = 2.0f;
	float minRandomPlasticity = -1.0f;
	float maxRandomPlasticity = 1.0f;

	int32_t numOfNeuralConnections = pInOutNetDesc->NumOfNeuralConnections;

	for (int32_t i = 0; i < numOfNeuralConnections; i++)
	{
		if (pInOutNetDesc->pConnectionStatusArray[i] == 0.0f)
			continue;

		if (pInOutNetDesc->pRBFConstantArray[i] == 0.0f)
		{
			pInOutNetDesc->pPlasticityValueArray[i] = pRandomNumbers->Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
		}
		else
		{
			pInOutNetDesc->pCentroidValueArray[i] = pRandomNumbers->Get_FloatNumber(minRandomCentroidValue, maxRandomCentroidValue);
		}
	}

}


static void XORBrain_Mutation(CNeuralCalculationNetDesc* pInOutNetDesc, CRandomNumbersNN* pRandomNumbers, void* pParam)
{
	//CEvolutionParameter_NeuralCalculationNet *pParameter = static_cast<CEvolutionParameter_NeuralCalculationNet*>(pParam);

	float minDeltaPlasticity = -0.01f;
	float maxDeltaPlasticity = 0.01f;
	float mutationRate = 0.75f;

	int32_t numOfNeuralConnections = pInOutNetDesc->NumOfNeuralConnections;

	for (int32_t i = 0; i < numOfNeuralConnections; i++)
	{
		if (pInOutNetDesc->pConnectionStatusArray[i] == 0.0f)
			continue;

		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
			continue;

		pInOutNetDesc->pPlasticityValueArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minDeltaPlasticity, maxDeltaPlasticity);
	}

}

static void XORBrainRBF_Mutation(CNeuralCalculationNetDesc* pInOutNetDesc, CRandomNumbersNN* pRandomNumbers, void* pParam)
{
	//CEvolutionParameter_NeuralCalculationNet *pParameter = static_cast<CEvolutionParameter_NeuralCalculationNet*>(pParam);

	float minDeltaCentroidValue = -0.01f;
	float maxDeltaCentroidValue = 0.01f;
	//float minDeltaPlasticity = -0.01f;
	//float maxDeltaPlasticity = 0.01f;
	float mutationRate = 0.75f;

	int32_t numOfNeuralConnections = pInOutNetDesc->NumOfNeuralConnections;

	for (int32_t i = 0; i < numOfNeuralConnections; i++)
	{
		if (pInOutNetDesc->pConnectionStatusArray[i] == 0.0f)
			continue;

		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
			continue;

		if (pInOutNetDesc->pRBFConstantArray[i] == 0.0f)
		{
			//pInOutNetDesc->pPlasticityValueArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minDeltaPlasticity, maxDeltaPlasticity);
		}
		else
		{
			pInOutNetDesc->pCentroidValueArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minDeltaCentroidValue, maxDeltaCentroidValue);
		}

	}

}

static void BrainRBF_Mutation(CNeuralCalculationNetDesc* pInOutNetDesc, CRandomNumbersNN* pRandomNumbers, void* pParam)
{
	//CEvolutionParameter_NeuralCalculationNet *pParameter = static_cast<CEvolutionParameter_NeuralCalculationNet*>(pParam);

	float minDeltaCentroidValue = -0.01f;
	float maxDeltaCentroidValue = 0.01f;
	float minDeltaPlasticity = -0.01f;
	float maxDeltaPlasticity = 0.01f;
	float mutationRate = 0.75f;

	int32_t numOfNeuralConnections = pInOutNetDesc->NumOfNeuralConnections;

	for (int32_t i = 0; i < numOfNeuralConnections; i++)
	{
		if (pInOutNetDesc->pConnectionStatusArray[i] == 0.0f)
			continue;

		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
			continue;

		if (pInOutNetDesc->pRBFConstantArray[i] == 0.0f)
		{
			pInOutNetDesc->pPlasticityValueArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minDeltaPlasticity, maxDeltaPlasticity);
		}
		else
		{
			pInOutNetDesc->pCentroidValueArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minDeltaCentroidValue, maxDeltaCentroidValue);
		}
	}
}



static void XORBrain_Recombination(CNeuralCalculationNetDesc* pOffspring, const CNeuralCalculationNetDesc* pParent1, const CNeuralCalculationNetDesc* pParent2, CRandomNumbersNN* pRandomNumbers, void* pParam)
{
	//CEvolutionParameter_NeuralCalculationNet *pParameter = static_cast<CEvolutionParameter_NeuralCalculationNet*>(pParam);

	float crossoverRate = 0.75f;

	int32_t numOfNeuralConnections = pOffspring->NumOfNeuralConnections;

	if (pRandomNumbers->Get_IntegerNumber2(1, 2) == 1)
	{
		for (int32_t i = 0; i < numOfNeuralConnections; i++)
		{
			if (pOffspring->pConnectionStatusArray[i] == 0.0f)
				continue;

			pOffspring->pPlasticityValueArray[i] = pParent1->pPlasticityValueArray[i];
		}
	}
	else
	{
		for (int32_t i = 0; i < numOfNeuralConnections; i++)
		{
			if (pOffspring->pConnectionStatusArray[i] == 0.0f)
				continue;

			pOffspring->pPlasticityValueArray[i] = pParent2->pPlasticityValueArray[i];
		}
	}

	for (int32_t i = 0; i < numOfNeuralConnections; i++)
	{
		if (pOffspring->pConnectionStatusArray[i] == 0.0f)
			continue;

		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > crossoverRate)
			continue;

		float weight1 = pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f);
		float weight2 = 1.0f - weight1;

		pOffspring->pPlasticityValueArray[i] = weight1 * pParent1->pPlasticityValueArray[i] + weight2 * pParent2->pPlasticityValueArray[i];
	}
}

static void XORBrainRBF_Recombination(CNeuralCalculationNetDesc* pOffspring, const CNeuralCalculationNetDesc* pParent1, const CNeuralCalculationNetDesc* pParent2, CRandomNumbersNN* pRandomNumbers, void* pParam)
{
	//CEvolutionParameter_NeuralCalculationNet *pParameter = static_cast<CEvolutionParameter_NeuralCalculationNet*>(pParam);

	float crossoverRate = 0.75f;

	int32_t numOfNeuralConnections = pOffspring->NumOfNeuralConnections;

	if (pRandomNumbers->Get_IntegerNumber2(1, 2) == 1)
	{
		for (int32_t i = 0; i < numOfNeuralConnections; i++)
		{
			if (pOffspring->pConnectionStatusArray[i] == 0.0f)
				continue;

			pOffspring->pCentroidValueArray[i] = pParent1->pCentroidValueArray[i];
			//pOffspring->pPlasticityValueArray[i] = pParent1->pPlasticityValueArray[i];
		}
	}
	else
	{
		for (int32_t i = 0; i < numOfNeuralConnections; i++)
		{
			if (pOffspring->pConnectionStatusArray[i] == 0.0f)
				continue;

			pOffspring->pCentroidValueArray[i] = pParent2->pCentroidValueArray[i];
			//pOffspring->pPlasticityValueArray[i] = pParent2->pPlasticityValueArray[i];
		}
	}

	for (int32_t i = 0; i < numOfNeuralConnections; i++)
	{
		if (pOffspring->pConnectionStatusArray[i] == 0.0f)
			continue;

		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > crossoverRate)
			continue;

		float weight1 = pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f);
		float weight2 = 1.0f - weight1;

		pOffspring->pCentroidValueArray[i] = weight1 * pParent1->pCentroidValueArray[i] + weight2 * pParent2->pCentroidValueArray[i];
		//pOffspring->pPlasticityValueArray[i] = weight1 * pParent1->pPlasticityValueArray[i] + weight2 * pParent2->pPlasticityValueArray[i];
	}
}

static void BrainRBF_Recombination(CNeuralCalculationNetDesc* pOffspring, const CNeuralCalculationNetDesc* pParent1, const CNeuralCalculationNetDesc* pParent2, CRandomNumbersNN* pRandomNumbers, void* pParam)
{
	//CEvolutionParameter_NeuralCalculationNet *pParameter = static_cast<CEvolutionParameter_NeuralCalculationNet*>(pParam);

	float crossoverRate = 0.75f;

	int32_t numOfNeuralConnections = pOffspring->NumOfNeuralConnections;

	if (pRandomNumbers->Get_IntegerNumber2(1, 2) == 1)
	{
		for (int32_t i = 0; i < numOfNeuralConnections; i++)
		{
			if (pOffspring->pConnectionStatusArray[i] == 0.0f)
				continue;

			pOffspring->pCentroidValueArray[i] = pParent1->pCentroidValueArray[i];
			pOffspring->pPlasticityValueArray[i] = pParent1->pPlasticityValueArray[i];
		}
	}
	else
	{
		for (int32_t i = 0; i < numOfNeuralConnections; i++)
		{
			if (pOffspring->pConnectionStatusArray[i] == 0.0f)
				continue;

			pOffspring->pCentroidValueArray[i] = pParent2->pCentroidValueArray[i];
			pOffspring->pPlasticityValueArray[i] = pParent2->pPlasticityValueArray[i];
		}
	}

	for (int32_t i = 0; i < numOfNeuralConnections; i++)
	{
		if (pOffspring->pConnectionStatusArray[i] == 0.0f)
			continue;

		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > crossoverRate)
			continue;

		float weight1 = pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f);
		float weight2 = 1.0f - weight1;

		pOffspring->pCentroidValueArray[i] = weight1 * pParent1->pCentroidValueArray[i] + weight2 * pParent2->pCentroidValueArray[i];
		pOffspring->pPlasticityValueArray[i] = weight1 * pParent1->pPlasticityValueArray[i] + weight2 * pParent2->pPlasticityValueArray[i];
	}
}
*/

/*
// FFNN: feed forward neural network, firstLayerUnits: inputUnits and biasUnit
inline void Get_ConnectionID_2LayerFFNN(int32_t* pOutID, int32_t inputOrBiasUnitNumber, int32_t outputUnitNumber, int32_t numOfInputAndBiasUnits, int32_t numOfCalculationUnits)
{
	*pOutID = numOfInputAndBiasUnits + outputUnitNumber + inputOrBiasUnitNumber * numOfCalculationUnits;
}

// FFNN: feed forward neural network, firstLayerUnits: inputUnits and biasUnit
inline void Get_ID_Of_1To2LayerConnection_3LayerFFNN(int32_t* pOutID, int32_t inputOrBiasUnitNumber, int32_t hiddenLayerUnitNumber, int32_t numOfInputAndBiasUnits, int32_t numOfCalculationUnits)
{
	*pOutID = numOfInputAndBiasUnits + hiddenLayerUnitNumber + inputOrBiasUnitNumber * numOfCalculationUnits;
}

// FFNN: feed forward neural network, firstLayerUnits: inputUnits and biasUnit
inline void Get_ID_Of_2To3LayerConnection_3LayerFFNN(int32_t* pOutID, int32_t hiddenUnitNumber, int32_t outputUnitNumber, int32_t numOfInputAndBiasUnits, int32_t numOfInputAndBiasAndHiddenUnits, int32_t numOfCalculationUnits)
{
	*pOutID = numOfInputAndBiasAndHiddenUnits + outputUnitNumber + (numOfInputAndBiasUnits + hiddenUnitNumber) * numOfCalculationUnits;
}


inline void Get_1DimLayer2CentroidConnectionID(int32_t* pOutID, int32_t centroidNumber)
{
	*pOutID = 1 + centroidNumber;
}

inline void Get_2DimLayer2CentroidConnectionID(int32_t* pOutIDX, int32_t* pOutIDY, int32_t centroidNumber, int32_t numOfCalculationUnits)
{
	*pOutIDX = 2 + centroidNumber;
	*pOutIDY = numOfCalculationUnits + 2 + centroidNumber;
}

inline void Get_3DimLayer2CentroidConnectionID(int32_t* pOutIDX, int32_t* pOutIDY, int32_t* pOutIDZ, int32_t centroidNumber, int32_t numOfCalculationUnits)
{
	*pOutIDX = 3 + centroidNumber;
	*pOutIDY = numOfCalculationUnits + 3 + centroidNumber;
	*pOutIDZ = 2 * numOfCalculationUnits + 3 + centroidNumber;
}
*/


#endif