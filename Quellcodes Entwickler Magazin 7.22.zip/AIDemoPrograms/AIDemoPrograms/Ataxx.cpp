#include "Ataxx.h"

using namespace std;
using namespace HelperStuff;

#ifndef max
#define max(a,b)    ( ((a) > (b)) ? (a) : (b) )
#endif

#ifndef min
#define min(a,b)    ( ((a) < (b)) ? (a) : (b) )
#endif

#define PRUNING




CInitialAtaxxBoards::CInitialAtaxxBoards()
{

}

CInitialAtaxxBoards::~CInitialAtaxxBoards()
{
	delete[] pInitialGameStateArray;
	pInitialGameStateArray = nullptr;
}

bool CInitialAtaxxBoards::Initialize(const char* pFilename)
{
	delete[] pInitialGameStateArray;
	pInitialGameStateArray = nullptr;

	std::ifstream ReadFile;

	// eine existierende Datei zum Lesen �ffnen:
	ReadFile.open(pFilename);

	if (ReadFile.good() == false)
		return false;

	char strBuffer[200];
	int32_t tempInt;

	ReadFile >> strBuffer;
	ReadFile >> NumOfInitialAtaxxBoards;

	pInitialGameStateArray = new (std::nothrow) CGameStateValues[NumOfInitialAtaxxBoards];

	for (int32_t i = 0; i < NumOfInitialAtaxxBoards; i++)
	{
		pInitialGameStateArray[i].Initialize(ConstGameBoardSizePerDir, ConstGameBoardSizePerDir);

		int8_t* pInitialBoardData = &pInitialGameStateArray[i].pValueArray[0];

		for (int32_t j = 0; j < ConstGameBoardSize; j++)
		{
			ReadFile >> tempInt;
			pInitialBoardData[j] = static_cast<int8_t>(tempInt);
		}
	}

	ReadFile.close();
	return true;
}

void Init_AtaxxGameBoard_WithoutObstacles(int8_t* pInOutGameData)
{
	for (int32_t i = 0; i < ConstGameBoardSize; i++)
		pInOutGameData[i] = 0;

	int32_t ix1_Player1 = 0;
	int32_t iy1_Player1 = 0;

	int32_t id = ix1_Player1 + ConstGameBoardSizePerDir * iy1_Player1;
	pInOutGameData[id] = ConstGameBoard_Player1;

	int32_t ix2_Player1 = ConstGameBoardSizePerDir - 1;
	int32_t iy2_Player1 = ConstGameBoardSizePerDir - 1;

	id = ix2_Player1 + ConstGameBoardSizePerDir * iy2_Player1;
	pInOutGameData[id] = ConstGameBoard_Player1;

	int32_t ix1_Player2 = ConstGameBoardSizePerDir - 1;
	int32_t iy1_Player2 = 0;

	id = ix1_Player2 + ConstGameBoardSizePerDir * iy1_Player2;
	pInOutGameData[id] = ConstGameBoard_Player2;

	int32_t ix2_Player2 = 0;
	int32_t iy2_Player2 = ConstGameBoardSizePerDir - 1;

	id = ix2_Player2 + ConstGameBoardSizePerDir * iy2_Player2;
	pInOutGameData[id] = ConstGameBoard_Player2;
}

void Init_AtaxxGameBoard(int8_t* pInOutGameData, CInitialAtaxxBoards* pInitialAtaxxBoards, int32_t boardID)
{
	int8_t* pInitialBoardData = &pInitialAtaxxBoards->pInitialGameStateArray[boardID].pValueArray[0];

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		pInOutGameData[i] = pInitialBoardData[i];
	}
}

void Clone_AtaxxGameBoard(int8_t* pOutGameData, int8_t* pInGameData)
{
	for (int32_t i = 0; i < ConstGameBoardSize; i++)
		pOutGameData[i] = pInGameData[i];
}

void Calculate_AtaxxScore(int32_t* pOutPlayer1Score, int32_t* pOutPlayer2Score, int8_t* pInGameData)
{
	int32_t player1Score = 0;
	int32_t player2Score = 0;

	int8_t value;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		value = pInGameData[i];

		if (value == ConstGameBoard_Player1)
		{
			player1Score++;
		}
		else if (value == ConstGameBoard_Player2)
		{
			player2Score++;
		}
	}

	*pOutPlayer1Score = player1Score;
	*pOutPlayer2Score = player2Score;
}

void Calculate_AtaxxPlayer1Score(int32_t* pOutPlayer1Score, int8_t* pInGameData)
{
	int32_t player1Score = 0;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pInGameData[i] == ConstGameBoard_Player1)
		{
			player1Score++;
		}
	}

	*pOutPlayer1Score = player1Score;
}

void Calculate_AtaxxPlayer2Score(int32_t* pOutPlayer2Score, int8_t* pInGameData)
{

	int32_t player2Score = 0;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pInGameData[i] == ConstGameBoard_Player2)
		{
			player2Score++;
		}
	}


	*pOutPlayer2Score = player2Score;
}

bool Check_PossibleAtaxxPlayer1Move(int32_t oldX, int32_t oldY, int32_t newX, int32_t newY, int8_t* pInGameData)
{
	if (abs(newX - oldX) > 2 || abs(newY - oldY) > 2)
	{
		return false;
	}

	if (pInGameData[oldX + ConstGameBoardSizePerDir * oldY] != ConstGameBoard_Player1)
	{
		return false;
	}

	if (pInGameData[newX + ConstGameBoardSizePerDir * newY] != ConstGameBoard_Empty)
	{
		return false;
	}

	return true;
}

bool Check_PossibleAtaxxPlayer2Move(int32_t oldX, int32_t oldY, int32_t newX, int32_t newY, int8_t* pInGameData)
{
	if (abs(newX - oldX) > 2 || abs(newY - oldY) > 2)
	{
		return false;
	}

	if (pInGameData[oldX + ConstGameBoardSizePerDir * oldY] != ConstGameBoard_Player2)
	{
		return false;
	}

	if (pInGameData[newX + ConstGameBoardSizePerDir * newY] != ConstGameBoard_Empty)
	{
		return false;
	}

	return true;
}

bool Check_PossibleAtaxxPlayer1Moves(int8_t* pInGameData)
{
	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pInGameData[i] == ConstGameBoard_Player1)
		{
			int32_t ixOld = i % ConstGameBoardSizePerDir;
			int32_t iyOld = i / ConstGameBoardSizePerDir;

			int32_t ixMin = max(0, ixOld - 2);
			int32_t iyMin = max(0, iyOld - 2);

			int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
			int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

			for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
			{
				for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
				{
					if (pInGameData[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
					{
						return true;
					}
				}
			}
		}
	}

	return false;
}

bool Check_PossibleAtaxxPlayer2Moves(int8_t* pInGameData)
{
	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pInGameData[i] == ConstGameBoard_Player2)
		{
			int32_t ixOld = i % ConstGameBoardSizePerDir;
			int32_t iyOld = i / ConstGameBoardSizePerDir;

			int32_t ixMin = max(0, ixOld - 2);
			int32_t iyMin = max(0, iyOld - 2);

			int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
			int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

			for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
			{
				for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
				{
					if (pInGameData[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
					{
						return true;
					}
				}
			}
		}
	}

	return false;
}

bool Check_For_PossibleAtaxxMove(int8_t* pInGameData)
{
	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pInGameData[i] == ConstGameBoard_Empty)
		{
			return true;
		}
	}

	return false;
}

bool Check_PossibleAtaxxPlayer1CloneMove(int32_t destinationX, int32_t destinationY, int8_t* pInGameData)
{
	int32_t id = destinationX + ConstGameBoardSizePerDir * destinationY;

	if (pInGameData[id] != ConstGameBoard_Empty)
	{
		return false;
	}


	int32_t ixMin = max(0, destinationX - 1);
	int32_t iyMin = max(0, destinationY - 1);

	int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, destinationX + 2);
	int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, destinationY + 2);

	for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
	{
		int32_t iiy = ConstGameBoardSizePerDir * iy;

		for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
		{
			if (pInGameData[ix + iiy] == ConstGameBoard_Player1)
			{
				return true;
			}
		}
	}

	return false;
}

bool Check_PossibleAtaxxPlayer2CloneMove(int32_t destinationX, int32_t destinationY, int8_t* pInGameData)
{
	int32_t id = destinationX + ConstGameBoardSizePerDir * destinationY;

	if (pInGameData[id] != ConstGameBoard_Empty)
	{
		return false;
	}

	int32_t ixMin = max(0, destinationX - 1);
	int32_t iyMin = max(0, destinationY - 1);

	int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, destinationX + 2);
	int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, destinationY + 2);

	for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
	{
		int32_t iiy = ConstGameBoardSizePerDir * iy;

		for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
		{
			if (pInGameData[ix + iiy] == ConstGameBoard_Player2)
			{
				return true;
			}
		}
	}

	return false;

}

bool Check_PossibleAtaxxPlayer1CloneMove(int32_t newPosID, int8_t* pInGameData)
{
	if (pInGameData[newPosID] != ConstGameBoard_Empty)
	{
		return false;
	}

	int32_t posX = newPosID % ConstGameBoardSizePerDir;
	int32_t posY = newPosID / ConstGameBoardSizePerDir;


	int32_t ixMin = max(0, posX - 1);
	int32_t iyMin = max(0, posY - 1);

	int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, posX + 2);
	int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, posY + 2);

	for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
	{
		int32_t iiy = ConstGameBoardSizePerDir * iy;

		for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
		{
			if (pInGameData[ix + iiy] == ConstGameBoard_Player1)
			{
				return true;
			}
		}
	}

	return false;
}

bool Check_PossibleAtaxxPlayer2CloneMove(int32_t newPosID, int8_t* pInGameData)
{
	if (pInGameData[newPosID] != ConstGameBoard_Empty)
	{
		return false;
	}

	int32_t posX = newPosID % ConstGameBoardSizePerDir;
	int32_t posY = newPosID / ConstGameBoardSizePerDir;


	int32_t ixMin = max(0, posX - 1);
	int32_t iyMin = max(0, posY - 1);

	int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, posX + 2);
	int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, posY + 2);

	for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
	{
		int32_t iiy = ConstGameBoardSizePerDir * iy;

		for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
		{
			if (pInGameData[ix + iiy] == ConstGameBoard_Player2)
			{
				return true;
			}
		}
	}

	return false;
}

bool Get_PossibleAtaxxPlayer1CloneMoveStartPos(int32_t* pOutStartX, int32_t* pOutStartY, int32_t newX, int32_t newY, int8_t* pInGameData)
{
	/*int32_t id = newX + ConstGameBoardSizePerDir * newY;

	if (pInGameData[id] != ConstGameBoard_Empty)
	{
	return false;
	}*/


	int32_t ixMin = max(0, newX - 1);
	int32_t iyMin = max(0, newY - 1);

	int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, newX + 2);
	int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, newY + 2);

	for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
	{
		int32_t iiy = ConstGameBoardSizePerDir * iy;

		for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
		{
			if (pInGameData[ix + iiy] == ConstGameBoard_Player1)
			{
				*pOutStartX = ix;
				*pOutStartY = iy;
				return true;
			}
		}
	}

	return false;
}

bool Get_PossibleAtaxxPlayer2CloneMoveStartPos(int32_t* pOutStartX, int32_t* pOutStartY, int32_t newX, int32_t newY, int8_t* pInGameData)
{
	/*int32_t id = newX + ConstGameBoardSizePerDir * newY;

	if (pInGameData[id] != ConstGameBoard_Empty)
	{
	return false;
	}*/

	int32_t ixMin = max(0, newX - 1);
	int32_t iyMin = max(0, newY - 1);

	int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, newX + 2);
	int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, newY + 2);

	for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
	{
		int32_t iiy = ConstGameBoardSizePerDir * iy;

		for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
		{
			if (pInGameData[ix + iiy] == ConstGameBoard_Player2)
			{
				*pOutStartX = ix;
				*pOutStartY = iy;
				return true;
			}
		}
	}

	return false;

}

bool Get_PossibleAtaxxPlayer1CloneMoveStartPos(int32_t* pOutStartX, int32_t* pOutStartY, int32_t newPosID, int8_t* pInGameData)
{
	/*if (pInGameData[newPosID] != ConstGameBoard_Empty)
	{
	return false;
	}*/

	int32_t posX = newPosID % ConstGameBoardSizePerDir;
	int32_t posY = newPosID / ConstGameBoardSizePerDir;


	int32_t ixMin = max(0, posX - 1);
	int32_t iyMin = max(0, posY - 1);

	int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, posX + 2);
	int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, posY + 2);

	for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
	{
		int32_t iiy = ConstGameBoardSizePerDir * iy;

		for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
		{
			if (pInGameData[ix + iiy] == ConstGameBoard_Player1)
			{
				*pOutStartX = ix;
				*pOutStartY = iy;
				return true;
			}
		}
	}

	return false;
}

bool Get_PossibleAtaxxPlayer2CloneMoveStartPos(int32_t* pOutOldX, int32_t* pOutOldY, int32_t newPosID, int8_t* pInGameData)
{
	/*if (pInGameData[newPosID] != ConstGameBoard_Empty)
	{
	return false;
	}*/

	int32_t posX = newPosID % ConstGameBoardSizePerDir;
	int32_t posY = newPosID / ConstGameBoardSizePerDir;


	int32_t ixMin = max(0, posX - 1);
	int32_t iyMin = max(0, posY - 1);

	int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, posX + 2);
	int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, posY + 2);

	for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
	{
		int32_t iiy = ConstGameBoardSizePerDir * iy;

		for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
		{
			if (pInGameData[ix + iiy] == ConstGameBoard_Player2)
			{
				*pOutOldX = ix;
				*pOutOldY = iy;
				return true;
			}
		}
	}

	return false;
}

void Make_AtaxxPlayer1Move(int32_t oldX, int32_t oldY, int32_t newX, int32_t newY, int8_t* pInOutGameData)
{
	pInOutGameData[newX + ConstGameBoardSizePerDir * newY] = ConstGameBoard_Player1;

	int32_t minX = max(0, newX - 1);
	int32_t minY = max(0, newY - 1);

	//int32_t maxXPlus1 = 1 + min(ConstGameBoardSizePerDirMinus1, newX + 1);
	//int32_t maxYPlus1 = 1 + min(ConstGameBoardSizePerDirMinus1, newY + 1);
	int32_t maxXPlus1 = min(ConstGameBoardSizePerDir, newX + 2);
	int32_t maxYPlus1 = min(ConstGameBoardSizePerDir, newY + 2);

	int32_t id, iiy;

	for (int32_t iy = minY; iy < maxYPlus1; iy++)
	{
		iiy = ConstGameBoardSizePerDir * iy;

		for (int32_t ix = minX; ix < maxXPlus1; ix++)
		{
			id = ix + iiy;

			if (pInOutGameData[id] == ConstGameBoard_Player2)
			{
				pInOutGameData[id] = ConstGameBoard_Player1;
			}
		} /* end of for (int32_t ix = minY; ix < maxXPlus1; ix++) */
	} /* end of for (int32_t iy = minY; iy < maxYPlus1; iy++) */

	if (abs(newX - oldX) > 1 || abs(newY - oldY) > 1)
	{
		id = oldX + ConstGameBoardSizePerDir * oldY;
		pInOutGameData[id] = ConstGameBoard_Empty;
	}
}

void Make_AtaxxPlayer2Move(int32_t oldX, int32_t oldY, int32_t newX, int32_t newY, int8_t* pInOutGameData)
{
	pInOutGameData[newX + ConstGameBoardSizePerDir * newY] = ConstGameBoard_Player2;

	int32_t minX = max(0, newX - 1);
	int32_t minY = max(0, newY - 1);

	//int32_t maxXPlus1 = 1 + min(ConstGameBoardSizePerDirMinus1, newX + 1);
	//int32_t maxYPlus1 = 1 + min(ConstGameBoardSizePerDirMinus1, newY + 1);
	int32_t maxXPlus1 = min(ConstGameBoardSizePerDir, newX + 2);
	int32_t maxYPlus1 = min(ConstGameBoardSizePerDir, newY + 2);

	int32_t id, iiy;

	for (int32_t iy = minY; iy < maxYPlus1; iy++)
	{
		iiy = ConstGameBoardSizePerDir * iy;

		for (int32_t ix = minX; ix < maxXPlus1; ix++)
		{
			id = ix + iiy;

			if (pInOutGameData[id] == ConstGameBoard_Player1)
			{
				pInOutGameData[id] = ConstGameBoard_Player2;
			}
		} /* end of for (int32_t ix = minY; ix < maxXPlus1; ix++) */
	} /* end of for (int32_t iy = minY; iy < maxYPlus1; iy++) */

	if (abs(newX - oldX) > 1 || abs(newY - oldY) > 1)
	{
		id = oldX + ConstGameBoardSizePerDir * oldY;
		pInOutGameData[id] = ConstGameBoard_Empty;
	}
}

void Make_AtaxxPlayer1CloneMove(int32_t newX, int32_t newY, int8_t* pInOutGameData)
{
	pInOutGameData[newX + ConstGameBoardSizePerDir * newY] = ConstGameBoard_Player1;

	int32_t minX = max(0, newX - 1);
	int32_t minY = max(0, newY - 1);

	//int32_t maxXPlus1 = 1 + min(ConstGameBoardSizePerDirMinus1, newX + 1);
	//int32_t maxYPlus1 = 1 + min(ConstGameBoardSizePerDirMinus1, newY + 1);
	int32_t maxXPlus1 = min(ConstGameBoardSizePerDir, newX + 2);
	int32_t maxYPlus1 = min(ConstGameBoardSizePerDir, newY + 2);

	int32_t id, iiy;

	for (int32_t iy = minY; iy < maxYPlus1; iy++)
	{
		iiy = ConstGameBoardSizePerDir * iy;

		for (int32_t ix = minX; ix < maxXPlus1; ix++)
		{
			id = ix + iiy;

			if (pInOutGameData[id] == ConstGameBoard_Player2)
			{
				pInOutGameData[id] = ConstGameBoard_Player1;
			}
		} /* end of for (int32_t ix = minY; ix < maxXPlus1; ix++) */
	} /* end of for (int32_t iy = minY; iy < maxYPlus1; iy++) */
}

void Make_AtaxxPlayer2CloneMove(int32_t newX, int32_t newY, int8_t* pInOutGameData)
{
	pInOutGameData[newX + ConstGameBoardSizePerDir * newY] = ConstGameBoard_Player2;

	int32_t minX = max(0, newX - 1);
	int32_t minY = max(0, newY - 1);

	//int32_t maxXPlus1 = 1 + min(ConstGameBoardSizePerDirMinus1, newX + 1);
	//int32_t maxYPlus1 = 1 + min(ConstGameBoardSizePerDirMinus1, newY + 1);
	int32_t maxXPlus1 = min(ConstGameBoardSizePerDir, newX + 2);
	int32_t maxYPlus1 = min(ConstGameBoardSizePerDir, newY + 2);

	int32_t id, iiy;

	for (int32_t iy = minY; iy < maxYPlus1; iy++)
	{
		iiy = ConstGameBoardSizePerDir * iy;

		for (int32_t ix = minX; ix < maxXPlus1; ix++)
		{
			id = ix + iiy;

			if (pInOutGameData[id] == ConstGameBoard_Player1)
			{
				pInOutGameData[id] = ConstGameBoard_Player2;
			}
		} /* end of for (int32_t ix = minY; ix < maxXPlus1; ix++) */
	} /* end of for (int32_t iy = minY; iy < maxYPlus1; iy++) */
}




void Evaluate_GameState_AtaxxPlayer1View(int32_t gameStateID, CExtendedGameStatePool* pGameStatePool)
{
	/*if (pGameStatePool->pGameStateArray[gameStateID].LeafNode == false)
	{
		return;
	}*/

	int32_t Player1Score, Player2Score;

	Calculate_AtaxxScore(&Player1Score, &Player2Score, &pGameStatePool->pGameStateArray[gameStateID].pValueArray[0]);

	if (Player1Score > 0 && Player2Score == 0)
	{
		pGameStatePool->pGameStateArray[gameStateID].iEvaluation = ConstMaxEvaluationScore_Minimax;
	}
	else if (Player1Score == 0 && Player2Score > 0)
	{
		pGameStatePool->pGameStateArray[gameStateID].iEvaluation = ConstMinEvaluationScore_Minimax;
	}
	else
	{
		pGameStatePool->pGameStateArray[gameStateID].iEvaluation = Player1Score - Player2Score;
	}
}

void Check_AtaxxLeafGameStates(CExtendedGameStatePool* pGameStatePool)
{
	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;

	for (int32_t i = numOfDepthLayersMax - 1; i > -1; i--)
	{
		CSimpleLinkedListManager* pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[i];
		int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
		int32_t id = 0;

		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);

			if (i == 2 && pGameStatePool->pGameStateArray[id].LeafNode == true)
				Add_To_Log(0, "LeafNode ok ", id);

			if(i == 2 && pGameStatePool->pGameStateArray[id].LeafNode == false)
				Add_To_Log(0, "must be LeafNode");
			if (i != 2 && pGameStatePool->pGameStateArray[id].LeafNode == true)
				Add_To_Log(0, "shound not be LeafNode", i);
			
			/*if (pGameStatePool->pGameStateArray[id].LeafNode == true)
			{
				if (pGameStatePool->pGameStateArray[id].iEvaluation == -2000000)
				{
					Add_To_Log(0, "Problem1 (1)", id);
					Add_To_Log(0, "Problem1 (2)", i);
				}
			}
			else
			{
				if (pGameStatePool->pGameStateArray[id].iEvaluation != -2000000)
				{
					Add_To_Log(0, "Problem2 (1)", id);
					Add_To_Log(0, "Problem2 (2)", i);
				}
			}*/
		}
	}
}

void Evaluate_LeafGameStates_AtaxxPlayer1View(CExtendedGameStatePool* pGameStatePool, int32_t depth)
{
	int32_t Player1Score, Player2Score;

	CSimpleLinkedListManager* pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[depth];
	int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	int32_t id = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);

		if (pGameStatePool->pGameStateArray[id].LeafNode == false)
		{
			continue;
		}

		Calculate_AtaxxScore(&Player1Score, &Player2Score, &pGameStatePool->pGameStateArray[id].pValueArray[0]);

		if (Player1Score > 0 && Player2Score == 0)
		{
			pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
		}
		else if (Player1Score == 0 && Player2Score > 0)
		{
			pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
		}
		else
		{
			pGameStatePool->pGameStateArray[id].iEvaluation = Player1Score - Player2Score;
		}

	}
}

void Evaluate_LeafGameStates_AtaxxPlayer2View(CExtendedGameStatePool* pGameStatePool, int32_t depth)
{
	int32_t Player1Score, Player2Score;

	CSimpleLinkedListManager* pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[depth];
	int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	int32_t id = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);

		if (pGameStatePool->pGameStateArray[id].LeafNode == false)
		{
			continue;
		}

		Calculate_AtaxxScore(&Player1Score, &Player2Score, &pGameStatePool->pGameStateArray[id].pValueArray[0]);

		if (Player1Score > 0 && Player2Score == 0)
		{
			pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
		}
		else if (Player1Score == 0 && Player2Score > 0)
		{
			pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
		}
		else
		{
			pGameStatePool->pGameStateArray[id].iEvaluation = Player2Score - Player1Score;
		}

	}
}

void Evaluate_LeafGameStates_AtaxxPlayer1View(CExtendedGameStatePool* pGameStatePool)
{
	int32_t Player1Score, Player2Score;

	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;

	for (int32_t i = numOfDepthLayersMax - 1; i > -1; i--)
	{
		CSimpleLinkedListManager* pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[i];
		int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
		int32_t id = 0;

		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);

			if (pGameStatePool->pGameStateArray[id].LeafNode == false)
			{
				continue;
			}

			Calculate_AtaxxScore(&Player1Score, &Player2Score, &pGameStatePool->pGameStateArray[id].pValueArray[0]);

			if (Player1Score > 0 && Player2Score == 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
			}
			else if (Player1Score == 0 && Player2Score > 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
			}
			else
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = Player1Score - Player2Score;
			}

		}
	}
}

void Evaluate_LeafGameStates_AtaxxPlayer1View(CGameStatePool_SimpleGameTree* pGameStatePool)
{
	int32_t Player1Score, Player2Score;

	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;

	for (int32_t i = numOfDepthLayersMax - 1; i > -1; i--)
	{
		CSimpleGameTree_DepthLayerInfo* pDepthLayerInfo = &pGameStatePool->pDepthLayerInfoArray[i];
		int32_t NumObjectsUsed = pDepthLayerInfo->NumGameStatesUsed;
		int32_t id = 0;

		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			id = pDepthLayerInfo->pGameStateIDArray[j];

			if (pGameStatePool->pGameStateArray[id].LeafNode == false)
			{
				continue;
			}

			Calculate_AtaxxScore(&Player1Score, &Player2Score, &pGameStatePool->pGameStateArray[id].pValueArray[0]);

			if (Player1Score > 0 && Player2Score == 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
			}
			else if (Player1Score == 0 && Player2Score > 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
			}
			else
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = Player1Score - Player2Score;
			}

		}
	}
}

void Evaluate_GameStates_AtaxxPlayer1View(CExtendedGameStatePool* pGameStatePool)
{
	int32_t Player1Score, Player2Score;

	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;
	int32_t numOfDepthLayersMaxMinus1 = numOfDepthLayersMax - 1;

	for (int32_t i = 0; i < numOfDepthLayersMaxMinus1; i++)
	{
		CSimpleLinkedListManager* pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[i];
		int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
		int32_t id = 0;

		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);

			Calculate_AtaxxScore(&Player1Score, &Player2Score, &pGameStatePool->pGameStateArray[id].pValueArray[0]);

			if (Player1Score > 0 && Player2Score == 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
			}
			else if (Player1Score == 0 && Player2Score > 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
			}
			else
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = Player1Score - Player2Score;
			}

		}
	}
}

void Evaluate_GameStates_AtaxxPlayer1View(CGameStatePool_SimpleGameTree* pGameStatePool)
{
	int32_t Player1Score, Player2Score;

	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;
	int32_t numOfDepthLayersMaxMinus1 = numOfDepthLayersMax - 1;

	for (int32_t i = 0; i < numOfDepthLayersMaxMinus1; i++)
	{
		CSimpleGameTree_DepthLayerInfo* pDepthLayerInfo = &pGameStatePool->pDepthLayerInfoArray[i];
		int32_t NumObjectsUsed = pDepthLayerInfo->NumGameStatesUsed;
		int32_t id = 0;

		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			id = pDepthLayerInfo->pGameStateIDArray[j];

			Calculate_AtaxxScore(&Player1Score, &Player2Score, &pGameStatePool->pGameStateArray[id].pValueArray[0]);

			if (Player1Score > 0 && Player2Score == 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
			}
			else if (Player1Score == 0 && Player2Score > 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
			}
			else
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = Player1Score - Player2Score;
			}

		}
	}
}


void Evaluate_GameState_AtaxxPlayer2View(int32_t gameStateID, CExtendedGameStatePool* pGameStatePool)
{
	/*if (pGameStatePool->pGameStateArray[gameStateID].LeafNode == false)
	{
		return;
	}*/

	int32_t Player1Score, Player2Score;

	Calculate_AtaxxScore(&Player1Score, &Player2Score, &pGameStatePool->pGameStateArray[gameStateID].pValueArray[0]);

	if (Player2Score > 0 && Player1Score == 0)
	{
		pGameStatePool->pGameStateArray[gameStateID].iEvaluation = ConstMaxEvaluationScore_Minimax;
	}
	else if (Player2Score == 0 && Player1Score > 0)
	{
		pGameStatePool->pGameStateArray[gameStateID].iEvaluation = ConstMinEvaluationScore_Minimax;
	}
	else
	{
		pGameStatePool->pGameStateArray[gameStateID].iEvaluation = Player2Score - Player1Score;
	}
}


void Evaluate_LeafGameStates_AtaxxPlayer2View(CExtendedGameStatePool* pGameStatePool)
{
	int32_t Player1Score, Player2Score;

	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;

	for (int32_t i = numOfDepthLayersMax - 1; i > -1; i--)
	{
		CSimpleLinkedListManager* pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[i];
		int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
		int32_t id = 0;

		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);

			if (pGameStatePool->pGameStateArray[id].LeafNode == false)
			{
				continue;
			}

			Calculate_AtaxxScore(&Player1Score, &Player2Score, &pGameStatePool->pGameStateArray[id].pValueArray[0]);

			if (Player2Score > 0 && Player1Score == 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
			}
			else if (Player2Score == 0 && Player1Score > 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
			}
			else
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = Player2Score - Player1Score;
			}

		}
	}
}

void Evaluate_LeafGameStates_AtaxxPlayer2View(CGameStatePool_SimpleGameTree* pGameStatePool)
{
	int32_t Player1Score, Player2Score;

	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;

	for (int32_t i = numOfDepthLayersMax - 1; i > -1; i--)
	{
		CSimpleGameTree_DepthLayerInfo* pDepthLayerInfo = &pGameStatePool->pDepthLayerInfoArray[i];
		int32_t NumObjectsUsed = pDepthLayerInfo->NumGameStatesUsed;
		int32_t id = 0;

		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			id = pDepthLayerInfo->pGameStateIDArray[j];

			if (pGameStatePool->pGameStateArray[id].LeafNode == false)
			{
				continue;
			}

			Calculate_AtaxxScore(&Player1Score, &Player2Score, &pGameStatePool->pGameStateArray[id].pValueArray[0]);

			if (Player2Score > 0 && Player1Score == 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
			}
			else if (Player2Score == 0 && Player1Score > 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
			}
			else
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = Player2Score - Player1Score;
			}

		}
	}
}

void Evaluate_GameStates_AtaxxPlayer2View(CExtendedGameStatePool* pGameStatePool)
{
	int32_t Player1Score, Player2Score;

	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;
	int32_t numOfDepthLayersMaxMinus1 = numOfDepthLayersMax - 1;

	for (int32_t i = 0; i < numOfDepthLayersMaxMinus1; i++)
	{
		CSimpleLinkedListManager* pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[i];
		int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
		int32_t id = 0;

		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);

			Calculate_AtaxxScore(&Player1Score, &Player2Score, &pGameStatePool->pGameStateArray[id].pValueArray[0]);

			if (Player2Score > 0 && Player1Score == 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
			}
			else if (Player2Score == 0 && Player1Score > 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
			}
			else
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = Player2Score - Player1Score;
			}
		}
	}
}

void Evaluate_GameStates_AtaxxPlayer2View(CGameStatePool_SimpleGameTree* pGameStatePool)
{
	int32_t Player1Score, Player2Score;

	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;
	int32_t numOfDepthLayersMaxMinus1 = numOfDepthLayersMax - 1;

	for (int32_t i = 0; i < numOfDepthLayersMaxMinus1; i++)
	{
		CSimpleGameTree_DepthLayerInfo* pDepthLayerInfo = &pGameStatePool->pDepthLayerInfoArray[i];
		int32_t NumObjectsUsed = pDepthLayerInfo->NumGameStatesUsed;
		int32_t id = 0;

		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			id = pDepthLayerInfo->pGameStateIDArray[j];

			Calculate_AtaxxScore(&Player1Score, &Player2Score, &pGameStatePool->pGameStateArray[id].pValueArray[0]);

			if (Player2Score > 0 && Player1Score == 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
			}
			else if (Player2Score == 0 && Player1Score > 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
			}
			else
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = Player2Score - Player1Score;
			}
		}
	}
}







CAtaxxTestMove::CAtaxxTestMove()
{}

CAtaxxTestMove::~CAtaxxTestMove()
{}

void CAtaxxTestMove::Prepare_Move(int32_t boardPosID)
{
	BoardPosID = boardPosID;
}

int32_t CAtaxxTestMove::Player1Move_If_Possible(CGameStateValues** ppOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool* pGameStatePool, int32_t depthLayer, bool resultingGameStateIsMaximizer)
{
	ResultingGameStateObjectID = -1;

	if (BoardPosID >= ConstGameBoardSize)
	{
		*ppOutNewGameState = nullptr;
		return 0;
	}

	
	int8_t* pActualGameStateValueArray = &pInActualGameState->pValueArray[0];

	if (pActualGameStateValueArray[BoardPosID] == ConstGameBoard_Empty)
	{
		if (Check_PossibleAtaxxPlayer1CloneMove(BoardPosID, pActualGameStateValueArray) == true)
		{
			
			CGameStateValues* pOutNewGameState = nullptr;

			if (pGameStatePool->Get_UnusedGameStateObject(depthLayer, &pOutNewGameState, &ResultingGameStateObjectID) == false)
			{
				*ppOutNewGameState = nullptr;
				return -1;
			}

			int32_t ixNew = BoardPosID % ConstGameBoardSizePerDir;
			int32_t iyNew = BoardPosID / ConstGameBoardSizePerDir;

			pOutNewGameState->Clone_GameStateValues(pInActualGameState);

			// test move:
			Make_AtaxxPlayer1CloneMove(ixNew, iyNew, &pOutNewGameState->pValueArray[0]);
			pOutNewGameState->PlayerID = 0;
			pInActualGameState->LeafNode = false;
			pOutNewGameState->IDofPrevGameState = pInActualGameState->IDofGameState;
			
			if (resultingGameStateIsMaximizer == true)
			{
				pOutNewGameState->Use_As_Maximizer();
			}
			else
			{
				pOutNewGameState->Use_As_Minimizer();
			}

			*ppOutNewGameState = pOutNewGameState;
			return 1;

		} // end of if (Check_PossiblePlayer1CloneMove(BoardPosID, pActualGameStateValueArray) == true)
	} // end of if (pActualGameStateValueArray[BoardPosID] == ConstGameBoard_Empty)
	else if (pActualGameStateValueArray[BoardPosID] == ConstGameBoard_Player1)
	{
		int32_t ixOld = BoardPosID % ConstGameBoardSizePerDir;
		int32_t iyOld = BoardPosID / ConstGameBoardSizePerDir;

		int32_t ixMin = max(0, ixOld - 2);
		int32_t iyMin = max(0, iyOld - 2);

		int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
		int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

		for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
		{
			for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
			{
				// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
				if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
				{
					continue;
				}

				if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
				{
					
					CGameStateValues* pOutNewGameState = nullptr;

					if (pGameStatePool->Get_UnusedGameStateObject(depthLayer, &pOutNewGameState, &ResultingGameStateObjectID) == false)
					{
						*ppOutNewGameState = nullptr;
						return -1;
					}

				
					pOutNewGameState->Clone_GameStateValues(pInActualGameState);

					// test move:
					Make_AtaxxPlayer1Move(ixOld, iyOld, ixNew, iyNew, &pOutNewGameState->pValueArray[0]);
					pOutNewGameState->PlayerID = 0;
					pInActualGameState->LeafNode = false;
					pOutNewGameState->IDofPrevGameState = pInActualGameState->IDofGameState;

					if (resultingGameStateIsMaximizer == true)
					{
						pOutNewGameState->Use_As_Maximizer();
					}
					else
					{
						pOutNewGameState->Use_As_Minimizer();
					}

					*ppOutNewGameState = pOutNewGameState;
					return 2;
				}

			} // end of for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
		} // end of for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)

	} // end of else if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)

	// no move from BoardPosID found:
	*ppOutNewGameState = nullptr;
	return 0;
}

int32_t CAtaxxTestMove::Player1Move_If_Possible(CGameStateValues* pInActualGameState, CExtendedGameStatePool* pGameStatePool, int32_t depthLayer, bool resultingGameStateIsMaximizer)
{
	ResultingGameStateObjectID = -1;

	if (BoardPosID >= ConstGameBoardSize)
	{
		return 0;
	}

	int8_t* pActualGameStateValueArray = &pInActualGameState->pValueArray[0];

	if (pActualGameStateValueArray[BoardPosID] == ConstGameBoard_Empty)
	{
		if (Check_PossibleAtaxxPlayer1CloneMove(BoardPosID, pActualGameStateValueArray) == true)
		{
			
			CGameStateValues* pOutNewGameState = nullptr;

			if (pGameStatePool->Get_UnusedGameStateObject(depthLayer, &pOutNewGameState, &ResultingGameStateObjectID) == false)
			{
				return -1;
			}

			int32_t ixNew = BoardPosID % ConstGameBoardSizePerDir;
			int32_t iyNew = BoardPosID / ConstGameBoardSizePerDir;

			pOutNewGameState->Clone_GameStateValues(pInActualGameState);

			// test move:
			Make_AtaxxPlayer1CloneMove(ixNew, iyNew, &pOutNewGameState->pValueArray[0]);
			pOutNewGameState->PlayerID = 0;
			pInActualGameState->LeafNode = false;
			pOutNewGameState->IDofPrevGameState = pInActualGameState->IDofGameState;

			if (resultingGameStateIsMaximizer == true)
			{
				pOutNewGameState->Use_As_Maximizer();
			}
			else
			{
				pOutNewGameState->Use_As_Minimizer();
			}

			return 1;

		} // end of if (Check_PossiblePlayer1CloneMove(BoardPosID, pActualGameStateValueArray) == true)
	} // end of if (pActualGameStateValueArray[BoardPosID] == ConstGameBoard_Empty)
	else if (pActualGameStateValueArray[BoardPosID] == ConstGameBoard_Player1)
	{
		int32_t ixOld = BoardPosID % ConstGameBoardSizePerDir;
		int32_t iyOld = BoardPosID / ConstGameBoardSizePerDir;

		int32_t ixMin = max(0, ixOld - 2);
		int32_t iyMin = max(0, iyOld - 2);

		int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
		int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

		for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
		{
			for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
			{
				// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
				if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
				{
					continue;
				}

				if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
				{
					
					CGameStateValues* pOutNewGameState = nullptr;

					if (pGameStatePool->Get_UnusedGameStateObject(depthLayer, &pOutNewGameState, &ResultingGameStateObjectID) == false)
					{
						return -1;
					}

					pOutNewGameState->Clone_GameStateValues(pInActualGameState);

					// test move:
					Make_AtaxxPlayer1Move(ixOld, iyOld, ixNew, iyNew, &pOutNewGameState->pValueArray[0]);
					pOutNewGameState->PlayerID = 0;
					pInActualGameState->LeafNode = false;
					pOutNewGameState->IDofPrevGameState = pInActualGameState->IDofGameState;

					if (resultingGameStateIsMaximizer == true)
					{
						pOutNewGameState->Use_As_Maximizer();
					}
					else
					{
						pOutNewGameState->Use_As_Minimizer();
					}

					return 2;
				}

			} // end of for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
		} // end of for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)

	} // end of else if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)

	// no move from BoardPosID found:
	return 0;
}

int32_t CAtaxxTestMove::Player2Move_If_Possible(CGameStateValues** ppOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool* pGameStatePool, int32_t depthLayer, bool resultingGameStateIsMaximizer)
{
	ResultingGameStateObjectID = -1;

	if (BoardPosID >= ConstGameBoardSize)
	{
		*ppOutNewGameState = nullptr;
		return 0;
	}

	int8_t* pActualGameStateValueArray = &pInActualGameState->pValueArray[0];

	if (pActualGameStateValueArray[BoardPosID] == ConstGameBoard_Empty)
	{
		if (Check_PossibleAtaxxPlayer2CloneMove(BoardPosID, pActualGameStateValueArray) == true)
		{
			
			CGameStateValues* pOutNewGameState = nullptr;

			if (pGameStatePool->Get_UnusedGameStateObject(depthLayer, &pOutNewGameState, &ResultingGameStateObjectID) == false)
			{
				*ppOutNewGameState = nullptr;
				return -1;
			}

			int32_t ixNew = BoardPosID % ConstGameBoardSizePerDir;
			int32_t iyNew = BoardPosID / ConstGameBoardSizePerDir;

			pOutNewGameState->Clone_GameStateValues(pInActualGameState);

			// test move:
			Make_AtaxxPlayer2CloneMove(ixNew, iyNew, &pOutNewGameState->pValueArray[0]);
			pOutNewGameState->PlayerID = 1;
			pInActualGameState->LeafNode = false;
			pOutNewGameState->IDofPrevGameState = pInActualGameState->IDofGameState;

			if (resultingGameStateIsMaximizer == true)
			{
				pOutNewGameState->Use_As_Maximizer();
			}
			else
			{
				pOutNewGameState->Use_As_Minimizer();
			}

			*ppOutNewGameState = pOutNewGameState;
			return 1;

		} // end of if (Check_PossiblePlayer1CloneMove(BoardPosID, pActualGameStateValueArray) == true)
	} // end of if (pActualGameStateValueArray[BoardPosID] == ConstGameBoard_Empty)
	else if (pActualGameStateValueArray[BoardPosID] == ConstGameBoard_Player2)
	{
		int32_t ixOld = BoardPosID % ConstGameBoardSizePerDir;
		int32_t iyOld = BoardPosID / ConstGameBoardSizePerDir;

		int32_t ixMin = max(0, ixOld - 2);
		int32_t iyMin = max(0, iyOld - 2);

		int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
		int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

		for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
		{
			for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
			{
				// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
				if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
				{
					continue;
				}

				if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
				{
					
					CGameStateValues* pOutNewGameState = nullptr;

					if (pGameStatePool->Get_UnusedGameStateObject(depthLayer, &pOutNewGameState, &ResultingGameStateObjectID) == false)
					{
						*ppOutNewGameState = nullptr;
						return -1;
					}

					pOutNewGameState->Clone_GameStateValues(pInActualGameState);

					// test move:
					Make_AtaxxPlayer2Move(ixOld, iyOld, ixNew, iyNew, &pOutNewGameState->pValueArray[0]);
					pOutNewGameState->PlayerID = 1;
					pInActualGameState->LeafNode = false;
					pOutNewGameState->IDofPrevGameState = pInActualGameState->IDofGameState;

					if (resultingGameStateIsMaximizer == true)
					{
						pOutNewGameState->Use_As_Maximizer();
					}
					else
					{
						pOutNewGameState->Use_As_Minimizer();
					}

					*ppOutNewGameState = pOutNewGameState;
					return 2;
				}

			} // end of for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
		} // end of for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)

	} // end of else if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)

	// no move from BoardPosID found:
	*ppOutNewGameState = nullptr;
	return 0;
}

int32_t CAtaxxTestMove::Player2Move_If_Possible(CGameStateValues* pInActualGameState, CExtendedGameStatePool* pGameStatePool, int32_t depthLayer, bool resultingGameStateIsMaximizer)
{
	ResultingGameStateObjectID = -1;

	if (BoardPosID >= ConstGameBoardSize)
	{
		return 0;
	}

	
	int8_t* pActualGameStateValueArray = &pInActualGameState->pValueArray[0];

	if (pActualGameStateValueArray[BoardPosID] == ConstGameBoard_Empty)
	{
		if (Check_PossibleAtaxxPlayer2CloneMove(BoardPosID, pActualGameStateValueArray) == true)
		{
			
			CGameStateValues* pOutNewGameState = nullptr;

			if (pGameStatePool->Get_UnusedGameStateObject(depthLayer, &pOutNewGameState, &ResultingGameStateObjectID) == false)
			{
				return -1;
			}

			
			int32_t ixNew = BoardPosID % ConstGameBoardSizePerDir;
			int32_t iyNew = BoardPosID / ConstGameBoardSizePerDir;

			pOutNewGameState->Clone_GameStateValues(pInActualGameState);

			// test move:
			Make_AtaxxPlayer2CloneMove(ixNew, iyNew, &pOutNewGameState->pValueArray[0]);
			pOutNewGameState->PlayerID = 1;
			pInActualGameState->LeafNode = false;
			pOutNewGameState->IDofPrevGameState = pInActualGameState->IDofGameState;

			if (resultingGameStateIsMaximizer == true)
			{
				pOutNewGameState->Use_As_Maximizer();
			}
			else
			{
				pOutNewGameState->Use_As_Minimizer();
			}

			return 1;

		} // end of if (Check_PossiblePlayer1CloneMove(BoardPosID, pActualGameStateValueArray) == true)
	} // end of if (pActualGameStateValueArray[BoardPosID] == ConstGameBoard_Empty)
	else if (pActualGameStateValueArray[BoardPosID] == ConstGameBoard_Player2)
	{
		int32_t ixOld = BoardPosID % ConstGameBoardSizePerDir;
		int32_t iyOld = BoardPosID / ConstGameBoardSizePerDir;

		int32_t ixMin = max(0, ixOld - 2);
		int32_t iyMin = max(0, iyOld - 2);

		int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
		int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

		for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
		{
			for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
			{
				// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
				if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
				{
					continue;
				}

				if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
				{
					
					CGameStateValues* pOutNewGameState = nullptr;

					if (pGameStatePool->Get_UnusedGameStateObject(depthLayer, &pOutNewGameState, &ResultingGameStateObjectID) == false)
					{
						return -1;
					}
					

					pOutNewGameState->Clone_GameStateValues(pInActualGameState);

					// test move:
					Make_AtaxxPlayer2Move(ixOld, iyOld, ixNew, iyNew, &pOutNewGameState->pValueArray[0]);
					pOutNewGameState->PlayerID = 1;
					pInActualGameState->LeafNode = false;
					pOutNewGameState->IDofPrevGameState = pInActualGameState->IDofGameState;

					if (resultingGameStateIsMaximizer == true)
					{
						pOutNewGameState->Use_As_Maximizer();
					}
					else
					{
						pOutNewGameState->Use_As_Minimizer();
					}

					return 2;
				}

			} // end of for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
		} // end of for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)

	} // end of else if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)

	// no move from BoardPosID found:
	return 0;
}



CAtaxxBreadthFirstSearchAI::CAtaxxBreadthFirstSearchAI()
{}

CAtaxxBreadthFirstSearchAI::~CAtaxxBreadthFirstSearchAI()
{}

void CAtaxxBreadthFirstSearchAI::Change_Seed(uint64_t seed)
{
	RandomNumbers.Change_Seed(seed);
}

void CAtaxxBreadthFirstSearchAI::Initialize(int32_t numTestGameStatesMax, int32_t numTestGameStatesMaxPerDepthLayer, int32_t maxSearchDepth)
{
	MaxSearchDepth = maxSearchDepth;
	NumTestGameStatesMax = numTestGameStatesMax;	
	NumTestGameStatesMaxPerDepthLayer = numTestGameStatesMaxPerDepthLayer;

	GameStatePool.Initialize(MaxSearchDepth, NumTestGameStatesMax, ConstGameBoardSizePerDir, ConstGameBoardSizePerDir);
}

void CAtaxxBreadthFirstSearchAI::Execute_Player1AI(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState)
{
	if (Check_PossibleAtaxxPlayer1Moves(pInActualGameState->pValueArray) == false)
	{
		pOutNewGameState->Clone_Data(pInActualGameState);
		return;
	}
	
	GameStatePool.Stop_Using_AllGameStateObjects();


	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		AtaxxTestMove.BoardPosID = i;

		if (AtaxxTestMove.Player1Move_If_Possible(pInActualGameState, &GameStatePool, 0, false) == -1)
		{
			Add_To_Log(0, "game tree too large, searchDepth 1");
			goto GameTreeCreationFinished;
		}
	}
	
	for (int32_t searchDepth = 1; searchDepth < MaxSearchDepth; searchDepth++)
	{
		int32_t playerID = searchDepth % 2;

		int32_t movementCounter = 0;

		if (playerID == 0)
		{
			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			int32_t id = 0;
			int32_t movementCounter = 0;

			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				for (int32_t i = 0; i < ConstGameBoardSize; i++)
				{
					AtaxxTestMove.BoardPosID = i;

					if (AtaxxTestMove.Player1Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, false) == -1)
					{
						Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
						goto GameTreeCreationFinished;
					}

					movementCounter++;

					if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					{
						Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
						break;
					}
				}

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)
		}
		else // if (playerID == 1)
		{ 
			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			int32_t id = 0;
			

			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				for (int32_t i = 0; i < ConstGameBoardSize; i++)
				{
					AtaxxTestMove.BoardPosID = i;
					
					if (AtaxxTestMove.Player2Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, true) == -1)
					{
						Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
						goto GameTreeCreationFinished;
					}

					movementCounter++;

					if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					{
						Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
						break;
					}
				}

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)
		}

		if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
			break;

	} // end of for (int32_t searchDepth = 0; searchDepth < MaxSearchDepthPlus1; searchDepth++)
	
GameTreeCreationFinished:;

	Evaluate_LeafGameStates_AtaxxPlayer1View(&GameStatePool);
	Backpropagate_MinimaxIntegerEvaluationValues(&GameStatePool);

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID);
	pOutNewGameState->Clone_GameStateValues(pGameStateObject);
}

void CAtaxxBreadthFirstSearchAI::Execute_Player1AI(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, float* pSearchDepthMovementProbabilityArray)
{
	if (Check_PossibleAtaxxPlayer1Moves(pInActualGameState->pValueArray) == false)
	{
		pOutNewGameState->Clone_Data(pInActualGameState);
		return;
	}

	GameStatePool.Stop_Using_AllGameStateObjects();


	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		AtaxxTestMove.BoardPosID = i;
		
		if (AtaxxTestMove.Player1Move_If_Possible(pInActualGameState, &GameStatePool, 0, false) == -1)
		{
			Add_To_Log(0, "game tree too large, searchDepth 1");
			goto GameTreeCreationFinished;
		}
	}

	for (int32_t searchDepth = 1; searchDepth < MaxSearchDepth; searchDepth++)
	{
		int32_t playerID = searchDepth % 2;

		int32_t movementCounter = 0;

		if (playerID == 0)
		{
			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			int32_t id = 0;
			int32_t movementCounter = 0;

			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				if (RandomNumbers.Get_FloatNumber_IncludingZero(0.0f, 1.0) > pSearchDepthMovementProbabilityArray[searchDepth])
				{
					continue;
				}

				for (int32_t i = 0; i < ConstGameBoardSize; i++)
				{
					AtaxxTestMove.BoardPosID = i;
					
					if (AtaxxTestMove.Player1Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, false) == -1)
					{
						Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
						goto GameTreeCreationFinished;
					}

					movementCounter++;

					if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					{
						Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
						break;
					}
				}

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)
		}
		else // if (playerID == 1)
		{
			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			int32_t id = 0;


			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				if (RandomNumbers.Get_FloatNumber_IncludingZero(0.0f, 1.0) > pSearchDepthMovementProbabilityArray[searchDepth])
				{
					continue;
				}

				for (int32_t i = 0; i < ConstGameBoardSize; i++)
				{
					AtaxxTestMove.BoardPosID = i;
					
					if (AtaxxTestMove.Player2Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, true) == -1)
					{
						Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
						goto GameTreeCreationFinished;
					}

					movementCounter++;

					if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					{
						Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
						break;
					}
				}

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)
		}

		if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
			break;

	} // end of for (int32_t searchDepth = 0; searchDepth < MaxSearchDepthPlus1; searchDepth++)

GameTreeCreationFinished:;

	Evaluate_LeafGameStates_AtaxxPlayer1View(&GameStatePool);
	Backpropagate_MinimaxIntegerEvaluationValues(&GameStatePool);

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID);
	pOutNewGameState->Clone_GameStateValues(pGameStateObject);
}

void CAtaxxBreadthFirstSearchAI::Execute_Player2AI(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState)
{
	if (Check_PossibleAtaxxPlayer2Moves(pInActualGameState->pValueArray) == false)
	{
		pOutNewGameState->Clone_Data(pInActualGameState);
		return;
	}

	GameStatePool.Stop_Using_AllGameStateObjects();

	
	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		AtaxxTestMove.BoardPosID = i;
		
		if (AtaxxTestMove.Player2Move_If_Possible(pInActualGameState, &GameStatePool, 0, false) == -1)
		{
			Add_To_Log(0, "game tree too large, searchDepth 1");
			goto GameTreeCreationFinished;
		}
	}

	
	for (int32_t searchDepth = 1; searchDepth < MaxSearchDepth; searchDepth++)
	{
		int32_t playerID = (1 + searchDepth) % 2;

		int32_t movementCounter = 0;

		if (playerID == 0)
		{
			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			//Add_To_Log(0, "NumUsedListElements", NumObjectsUsed);

			int32_t id = 0;
			

			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				for (int32_t i = 0; i < ConstGameBoardSize; i++)
				{
					AtaxxTestMove.BoardPosID = i;

					if (AtaxxTestMove.Player1Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, true) == -1)
					{
						Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
						goto GameTreeCreationFinished;
					}

					if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					{
						Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
						break;
					}
				}

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)
		}
		else // if (playerID == 1)
		{
			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			//Add_To_Log(0, "NumUsedListElements", NumObjectsUsed);
			int32_t id = 0;
			int32_t movementCounter = 0;

			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				for (int32_t i = 0; i < ConstGameBoardSize; i++)
				{
					AtaxxTestMove.BoardPosID = i;

					if (AtaxxTestMove.Player2Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, false) == -1)
					{
						Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
						goto GameTreeCreationFinished;
					}

					movementCounter++;

					if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					{
						Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
						break;
					}
				}

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)
		}

		if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
			break;

	} // end of for (int32_t searchDepth = 0; searchDepth < MaxSearchDepthPlus1; searchDepth++)
	
GameTreeCreationFinished:;

	Evaluate_LeafGameStates_AtaxxPlayer2View(&GameStatePool);
	//Add_To_Log(0, "Evaluate_LeafGameStates_Player2View() ok");

	Backpropagate_MinimaxIntegerEvaluationValues(&GameStatePool);
	//Add_To_Log(0, "Backpropagate_MinimaxIntegerEvaluationValues() ok");

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID);

	//if(pGameStateObject == nullptr)
		//Add_To_Log(0, "pGameStateObject == nullptr");

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);
}

void CAtaxxBreadthFirstSearchAI::Execute_Player2AI(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, float* pSearchDepthMovementProbabilityArray)
{
	if (Check_PossibleAtaxxPlayer2Moves(pInActualGameState->pValueArray) == false)
	{
		pOutNewGameState->Clone_Data(pInActualGameState);
		return;
	}

	GameStatePool.Stop_Using_AllGameStateObjects();


	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		AtaxxTestMove.BoardPosID = i;
		
		if (AtaxxTestMove.Player2Move_If_Possible(pInActualGameState, &GameStatePool, 0, false) == -1)
		{
			Add_To_Log(0, "game tree too large, searchDepth 1");
			goto GameTreeCreationFinished;
		}
	}


	for (int32_t searchDepth = 1; searchDepth < MaxSearchDepth; searchDepth++)
	{
		int32_t playerID = (1 + searchDepth) % 2;

		int32_t movementCounter = 0;

		if (playerID == 0)
		{
			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			//Add_To_Log(0, "NumUsedListElements", NumObjectsUsed);

			int32_t id = 0;


			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				if (RandomNumbers.Get_FloatNumber_IncludingZero(0.0f, 1.0) > pSearchDepthMovementProbabilityArray[searchDepth])
				{
					continue;
				}

				for (int32_t i = 0; i < ConstGameBoardSize; i++)
				{
					AtaxxTestMove.BoardPosID = i;

					if (AtaxxTestMove.Player1Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, true) == -1)
					{
						Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
						goto GameTreeCreationFinished;
					}

					if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					{
						Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
						break;
					}
				}

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)
		}
		else // if (playerID == 1)
		{
			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			//Add_To_Log(0, "NumUsedListElements", NumObjectsUsed);
			int32_t id = 0;
			int32_t movementCounter = 0;

			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				if (RandomNumbers.Get_FloatNumber_IncludingZero(0.0f, 1.0) > pSearchDepthMovementProbabilityArray[searchDepth])
				{
					continue;
				}

				for (int32_t i = 0; i < ConstGameBoardSize; i++)
				{
					AtaxxTestMove.BoardPosID = i;

					if (AtaxxTestMove.Player2Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, false) == -1)
					{
						Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
						goto GameTreeCreationFinished;
					}

					movementCounter++;

					if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					{
						Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
						break;
					}
				}

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)
		}

		if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
			break;

	} // end of for (int32_t searchDepth = 0; searchDepth < MaxSearchDepthPlus1; searchDepth++)

GameTreeCreationFinished:;

	Evaluate_LeafGameStates_AtaxxPlayer2View(&GameStatePool);
	//Add_To_Log(0, "Evaluate_LeafGameStates_Player2View() ok");

	Backpropagate_MinimaxIntegerEvaluationValues(&GameStatePool);
	//Add_To_Log(0, "Backpropagate_MinimaxIntegerEvaluationValues() ok");

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID);

	//if(pGameStateObject == nullptr)
		//Add_To_Log(0, "pGameStateObject == nullptr");

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);
}


CAtaxxDepthFirstSearchAI::CAtaxxDepthFirstSearchAI()
{}

CAtaxxDepthFirstSearchAI::~CAtaxxDepthFirstSearchAI()
{
	delete[] pAtaxxTestMoveArray;
	pAtaxxTestMoveArray = nullptr;
}

void CAtaxxDepthFirstSearchAI::Initialize(int32_t numTestGameStatesMax, int32_t maxSearchDepth)
{
	MaxSearchDepth = max(2, maxSearchDepth);
	MaxSearchDepthMinus1 = MaxSearchDepth -1;
	NumTestGameStatesMax = numTestGameStatesMax;
	
	GameStatePool.Initialize(MaxSearchDepth + 1, NumTestGameStatesMax, ConstGameBoardSizePerDir, ConstGameBoardSizePerDir);

	delete[] pAtaxxTestMoveArray;
	pAtaxxTestMoveArray = nullptr;

	pAtaxxTestMoveArray = new (std::nothrow) CAtaxxTestMove[MaxSearchDepth + 1];
}

void CAtaxxDepthFirstSearchAI::Execute_Player1AI(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState)
{
	if (Check_PossibleAtaxxPlayer1Moves(pInActualGameState->pValueArray) == false)
	{
		pOutNewGameState->Clone_Data(pInActualGameState);
		return;
	}

	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t RootGameStateID = -1;
	CGameStateValues* pRootGameStateObject = nullptr;

	GameStatePool.Get_UnusedGameStateObject(0, &pRootGameStateObject, &RootGameStateID);
	pRootGameStateObject->Clone_GameStateValues(pInActualGameState);
	pRootGameStateObject->Use_As_Maximizer();

	CAtaxxTestMove* pAtaxxTestMove = &pAtaxxTestMoveArray[1];

	if (MaxSearchDepth == 2)
	{
		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			pAtaxxTestMove->BoardPosID = i;

			if (pAtaxxTestMove->Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pAtaxxTestMove->ResultingGameStateObjectID];

				bool TestMoveDepth2Failed = Player1AI_InnerEvalulationLoop(pGameStateObjectDepth1, 1, 2);

				if (TestMoveDepth2Failed == true)
				{
					Evaluate_GameState_AtaxxPlayer1View(pGameStateObjectDepth1->IDofGameState, &GameStatePool);
				}

				OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);
			}
		}
	} // end of if (MaxSearchDepth == 2)
	else if (MaxSearchDepth > 2)
	{
		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			pAtaxxTestMove->BoardPosID = i;

			if (pAtaxxTestMove->Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pAtaxxTestMove->ResultingGameStateObjectID];

				bool TestMoveDepth2Failed = Player1AI_OuterEvalulationLoop(pGameStateObjectDepth1, 1, 2);

				if (TestMoveDepth2Failed == true)
				{
					Evaluate_GameState_AtaxxPlayer1View(pGameStateObjectDepth1->IDofGameState, &GameStatePool);
				}

				OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);

				
			}
		}
	} // end of else if (MaxSearchDepth > 2)

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID, 1);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);
}

void CAtaxxDepthFirstSearchAI::Execute_Player2AI(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState)
{
	if (Check_PossibleAtaxxPlayer2Moves(pInActualGameState->pValueArray) == false)
	{
		pOutNewGameState->Clone_Data(pInActualGameState);
		return;
	}

	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t RootGameStateID = -1;
	CGameStateValues* pRootGameStateObject = nullptr;

	GameStatePool.Get_UnusedGameStateObject(0, &pRootGameStateObject, &RootGameStateID);
	pRootGameStateObject->Clone_GameStateValues(pInActualGameState);
	pRootGameStateObject->Use_As_Maximizer();

	CAtaxxTestMove* pAtaxxTestMove = &pAtaxxTestMoveArray[1];

	if (MaxSearchDepth == 2)
	{
		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			pAtaxxTestMove->BoardPosID = i;

			if (pAtaxxTestMove->Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pAtaxxTestMove->ResultingGameStateObjectID];

				bool TestMoveDepth2Failed = Player2AI_InnerEvalulationLoop(pGameStateObjectDepth1, 0, 2);

				if (TestMoveDepth2Failed == true)
				{
					Evaluate_GameState_AtaxxPlayer2View(pGameStateObjectDepth1->IDofGameState, &GameStatePool);
				}

				OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);
			}
		}
	} // end of if (MaxSearchDepth == 2)
	else if (MaxSearchDepth > 2)
	{
		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			pAtaxxTestMove->BoardPosID = i;

			if (pAtaxxTestMove->Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pAtaxxTestMove->ResultingGameStateObjectID];

				bool TestMoveDepth2Failed = Player2AI_OuterEvalulationLoop(pGameStateObjectDepth1, 0, 2);

				if (TestMoveDepth2Failed == true)
				{
					Evaluate_GameState_AtaxxPlayer2View(pGameStateObjectDepth1->IDofGameState, &GameStatePool);
				}

				OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);

			}
		}
	} // end of else if (MaxSearchDepth > 2)

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID, 1);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

}

bool CAtaxxDepthFirstSearchAI::Player1AI_OuterEvalulationLoop(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth)
{
	CAtaxxTestMove* pAtaxxTestMove = &pAtaxxTestMoveArray[depth];

	int32_t depthPlus1 = depth + 1;

	
	if (depth == MaxSearchDepthMinus1)
	{
		if (playerID == 0)
		{
			int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			for (int32_t i = 0; i < ConstGameBoardSize; i++)
			{
				pAtaxxTestMove->BoardPosID = i;

				if (pAtaxxTestMove->Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)
				{
					TestMovesFailed = false;

					int32_t resultingGameStateObjectID = pAtaxxTestMove->ResultingGameStateObjectID;
					CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

					bool TestMovesNextDepth = Player1AI_InnerEvalulationLoop(pResultingGameStateObject, 1, depthPlus1);
					
					if (TestMovesNextDepth == true)
					{
						Evaluate_GameState_AtaxxPlayer1View(resultingGameStateObjectID, &GameStatePool);
					}

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
					if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
					{
						//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
						break;
					}
#endif
				}
			}

			return TestMovesFailed;
		} // end of if (playerID == 0)
		else //if (playerID == 1)
		{
			int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			for (int32_t i = 0; i < ConstGameBoardSize; i++)
			{
				pAtaxxTestMove->BoardPosID = i;

				if (pAtaxxTestMove->Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)
				{
					TestMovesFailed = false;

					int32_t resultingGameStateObjectID = pAtaxxTestMove->ResultingGameStateObjectID;
					CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

					bool TestMovesNextDepth = Player1AI_InnerEvalulationLoop(pResultingGameStateObject, 0, depthPlus1);
					
					if (TestMovesNextDepth == true)
					{
						Evaluate_GameState_AtaxxPlayer1View(resultingGameStateObjectID, &GameStatePool);
					}

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
					if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
					{
						//Add_To_Log(0, "PrevMaximizerEvalValue >= pInActualGameState->iEvaluation");
						break;
					}
#endif
				}
			}

			return TestMovesFailed;
		} // end of else //if (playerID == 1)
	} // end of if (depth == MaxSearchDepthMinus1)
	else if (depth < MaxSearchDepthMinus1)
	{
		if (playerID == 0)
		{
			int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			for (int32_t i = 0; i < ConstGameBoardSize; i++)
			{
				pAtaxxTestMove->BoardPosID = i;

				if (pAtaxxTestMove->Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)
				{
					TestMovesFailed = false;

					int32_t resultingGameStateObjectID = pAtaxxTestMove->ResultingGameStateObjectID;
					CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

					bool TestMovesNextDepth = Player1AI_OuterEvalulationLoop(pResultingGameStateObject, 1, depthPlus1);
					
					if (TestMovesNextDepth == true)
					{
						Evaluate_GameState_AtaxxPlayer1View(resultingGameStateObjectID, &GameStatePool);
					}

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
					if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
					{
						//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
						break;
					}
#endif
				}
			}

			return TestMovesFailed;
		} // end of if (playerID == 0)
		else //if (playerID == 1)
		{
			int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			for (int32_t i = 0; i < ConstGameBoardSize; i++)
			{
				pAtaxxTestMove->BoardPosID = i;

				if (pAtaxxTestMove->Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)
				{
					TestMovesFailed = false;

					int32_t resultingGameStateObjectID = pAtaxxTestMove->ResultingGameStateObjectID;
					CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

					bool TestMovesNextDepth = Player1AI_OuterEvalulationLoop(pResultingGameStateObject, 0, depthPlus1);
					

					if (TestMovesNextDepth == true)
					{
						Evaluate_GameState_AtaxxPlayer1View(resultingGameStateObjectID, &GameStatePool);
					}

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
					if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
					{
						//Add_To_Log(0, "PrevMaximizerEvalValue >= pInActualGameState->iEvaluation");
						break;
					}
#endif
				}
			}

			return TestMovesFailed;
		} // end of else //if (playerID == 1)
	} // end of else if (depth < MaxSearchDepthMinus1)
	
	return false;
}

bool CAtaxxDepthFirstSearchAI::Player2AI_OuterEvalulationLoop(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth)
{
	CAtaxxTestMove* pAtaxxTestMove = &pAtaxxTestMoveArray[depth];

	int32_t depthPlus1 = depth + 1;


	if (depth == MaxSearchDepthMinus1)
	{
		if (playerID == 0)
		{
			int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			for (int32_t i = 0; i < ConstGameBoardSize; i++)
			{
				pAtaxxTestMove->BoardPosID = i;

				if (pAtaxxTestMove->Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)
				{
					TestMovesFailed = false;

					int32_t resultingGameStateObjectID = pAtaxxTestMove->ResultingGameStateObjectID;
					CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

					bool TestMovesNextDepth = Player2AI_InnerEvalulationLoop(pResultingGameStateObject, 1, depthPlus1);

					if (TestMovesNextDepth == true)
					{
						Evaluate_GameState_AtaxxPlayer2View(resultingGameStateObjectID, &GameStatePool);
					}

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
					if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
					{
						//Add_To_Log(0, "PrevMaximizerEvalValue >= pInActualGameState->iEvaluation");
						break;
					}
#endif
				}
			}

			return TestMovesFailed;
		} // end of if (playerID == 0)
		else //if (playerID == 1)
		{
			int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			for (int32_t i = 0; i < ConstGameBoardSize; i++)
			{
				pAtaxxTestMove->BoardPosID = i;

				if (pAtaxxTestMove->Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)
				{
					TestMovesFailed = false;

					int32_t resultingGameStateObjectID = pAtaxxTestMove->ResultingGameStateObjectID;
					CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

					bool TestMovesNextDepth = Player2AI_InnerEvalulationLoop(pResultingGameStateObject, 0, depthPlus1);

					if (TestMovesNextDepth == true)
					{
						Evaluate_GameState_AtaxxPlayer2View(resultingGameStateObjectID, &GameStatePool);
					}

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
					if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
					{
						//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
						break;
					}
#endif
				}
			}

			return TestMovesFailed;
		} // end of else //if (playerID == 1)
	} // end of if (depth == MaxSearchDepthMinus1)
	else if (depth < MaxSearchDepthMinus1)
	{
		if (playerID == 0)
		{
			int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			for (int32_t i = 0; i < ConstGameBoardSize; i++)
			{
				pAtaxxTestMove->BoardPosID = i;

				if (pAtaxxTestMove->Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)
				{
					TestMovesFailed = false;

					int32_t resultingGameStateObjectID = pAtaxxTestMove->ResultingGameStateObjectID;
					CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

					bool TestMovesNextDepth = Player2AI_OuterEvalulationLoop(pResultingGameStateObject, 1, depthPlus1);

					if (TestMovesNextDepth == true)
					{
						Evaluate_GameState_AtaxxPlayer2View(resultingGameStateObjectID, &GameStatePool);
					}

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
					if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
					{
						//Add_To_Log(0, "PrevMaximizerEvalValue >= pInActualGameState->iEvaluation");
						break;
					}
#endif
				}
			}

			return TestMovesFailed;
		} // end of if (playerID == 0)
		else //if (playerID == 1)
		{
			int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			for (int32_t i = 0; i < ConstGameBoardSize; i++)
			{
				pAtaxxTestMove->BoardPosID = i;

				if (pAtaxxTestMove->Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)
				{
					TestMovesFailed = false;

					int32_t resultingGameStateObjectID = pAtaxxTestMove->ResultingGameStateObjectID;
					CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

					bool TestMovesNextDepth = Player2AI_OuterEvalulationLoop(pResultingGameStateObject, 0, depthPlus1);

					if (TestMovesNextDepth == true)
					{
						Evaluate_GameState_AtaxxPlayer2View(resultingGameStateObjectID, &GameStatePool);
					}

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
					if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
					{
						//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
						break;
					}
#endif
				}
			}

			return TestMovesFailed;
		} // end of else //if (playerID == 1)
	} // end of else if (depth < MaxSearchDepthMinus1)

	return false;
}

bool CAtaxxDepthFirstSearchAI::Player1AI_InnerEvalulationLoop(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth)
{
	CAtaxxTestMove* pAtaxxTestMove = &pAtaxxTestMoveArray[depth];

	if (playerID == 0)
	{
		int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

		bool TestMovesFailed = true;

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			pAtaxxTestMove->BoardPosID = i;

			if (pAtaxxTestMove->Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)
			{
				TestMovesFailed = false;

				int32_t resultingGameStateObjectID = pAtaxxTestMove->ResultingGameStateObjectID;
				Evaluate_GameState_AtaxxPlayer1View(resultingGameStateObjectID, &GameStatePool);

				OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
				GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);	

#ifdef PRUNING
				if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
				{
					//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
					break;
				}
#endif
			}
		}

		return TestMovesFailed;

	} // end of if (playerID == 0)
	else //if (playerID == 1)
	{
		int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

		bool TestMovesFailed = true;

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			pAtaxxTestMove->BoardPosID = i;

			if (pAtaxxTestMove->Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)
			{
				TestMovesFailed = false;

				int32_t resultingGameStateObjectID = pAtaxxTestMove->ResultingGameStateObjectID;
				Evaluate_GameState_AtaxxPlayer1View(resultingGameStateObjectID, &GameStatePool);

				OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
				GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);
				
#ifdef PRUNING
				if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
				{
					//Add_To_Log(0, "PrevMaximizerEvalValue >= pInActualGameState->iEvaluation");
					break;
				}
#endif
			}
		}

		return TestMovesFailed;

	} // end of else //if (playerID == 1)

	return false;
}

bool CAtaxxDepthFirstSearchAI::Player2AI_InnerEvalulationLoop(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth)
{
	CAtaxxTestMove* pAtaxxTestMove = &pAtaxxTestMoveArray[depth];

	if (playerID == 0)
	{
		int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

		bool TestMovesFailed = true;

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			pAtaxxTestMove->BoardPosID = i;

			if (pAtaxxTestMove->Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)
			{
				TestMovesFailed = false;

				int32_t resultingGameStateObjectID = pAtaxxTestMove->ResultingGameStateObjectID;
				Evaluate_GameState_AtaxxPlayer2View(resultingGameStateObjectID, &GameStatePool);

				
				OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
				GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
				if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
				{
					//Add_To_Log(0, "PrevMaxEvalValue >= pInActualGameState->iEvaluation");
					break;
				}
#endif
			}
		}

		return TestMovesFailed;

	} // end of if (playerID == 0)
	else //if (playerID == 1)
	{
		int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

		bool TestMovesFailed = true;

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			pAtaxxTestMove->BoardPosID = i;

			if (pAtaxxTestMove->Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)
			{
				TestMovesFailed = false;

				int32_t resultingGameStateObjectID = pAtaxxTestMove->ResultingGameStateObjectID;
				Evaluate_GameState_AtaxxPlayer2View(resultingGameStateObjectID, &GameStatePool);

				OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
				GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
				if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
				{
					//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
					break;
				}
#endif
			}
		}

		return TestMovesFailed;

	} // end of else //if (playerID == 1)

	return false;
}


void CAtaxxDepthFirstSearchAI::Execute_Player1AI_SearchDepth2(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState)
{
	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t RootGameStateID = -1;
	CGameStateValues* pRootGameStateObject = nullptr;

	GameStatePool.Get_UnusedGameStateObject(0, &pRootGameStateObject, &RootGameStateID);
	pRootGameStateObject->Clone_GameStateValues(pInActualGameState);
	pRootGameStateObject->Use_As_Maximizer();

	CAtaxxTestMove* pAtaxxTestMoveDepth1 = &pAtaxxTestMoveArray[1];
	CAtaxxTestMove* pAtaxxTestMoveDepth2 = &pAtaxxTestMoveArray[2];

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		pAtaxxTestMoveDepth1->BoardPosID = i;

		if (pAtaxxTestMoveDepth1->Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
		{
			CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pAtaxxTestMoveDepth1->ResultingGameStateObjectID];

			bool TestMoveDepth2Failed = true;

			for (int32_t i = 0; i < ConstGameBoardSize; i++)
			{
				pAtaxxTestMoveDepth2->BoardPosID = i;

				if (pAtaxxTestMoveDepth2->Player2Move_If_Possible(pGameStateObjectDepth1, &GameStatePool, 2, true) > 0)
				{
					TestMoveDepth2Failed = false;

					int32_t resultingGameStateObjectID = pAtaxxTestMoveDepth2->ResultingGameStateObjectID;
					Evaluate_GameState_AtaxxPlayer1View(resultingGameStateObjectID, &GameStatePool);
					OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);
				}
			}

			if(TestMoveDepth2Failed == true)
			{
				Evaluate_GameState_AtaxxPlayer1View(pGameStateObjectDepth1->IDofGameState, &GameStatePool);
			}

			OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);
		}
	}

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID, 1);

	//Add_To_Log(0, "IntegerEvaluation", pGameStateObject->iEvaluation);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);
}

void CAtaxxDepthFirstSearchAI::Execute_Player2AI_SearchDepth2(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState)
{
	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t RootGameStateID = -1;
	CGameStateValues* pRootGameStateObject = nullptr;

	GameStatePool.Get_UnusedGameStateObject(0, &pRootGameStateObject, &RootGameStateID);
	pRootGameStateObject->Clone_GameStateValues(pInActualGameState);
	pRootGameStateObject->Use_As_Maximizer();

	CAtaxxTestMove* pAtaxxTestMoveDepth1 = &pAtaxxTestMoveArray[1];
	CAtaxxTestMove* pAtaxxTestMoveDepth2 = &pAtaxxTestMoveArray[2];

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		pAtaxxTestMoveDepth1->BoardPosID = i;

		if (pAtaxxTestMoveDepth1->Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
		{
			CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pAtaxxTestMoveDepth1->ResultingGameStateObjectID];

			bool TestMoveDepth2Failed = true;

			for (int32_t i = 0; i < ConstGameBoardSize; i++)
			{
				pAtaxxTestMoveDepth2->BoardPosID = i;

				if (pAtaxxTestMoveDepth2->Player1Move_If_Possible(pGameStateObjectDepth1, &GameStatePool, 2, true) > 0)
				{
					TestMoveDepth2Failed = false;

					int32_t resultingGameStateObjectID = pAtaxxTestMoveDepth2->ResultingGameStateObjectID;
					Evaluate_GameState_AtaxxPlayer2View(resultingGameStateObjectID, &GameStatePool);
					OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);
				}
			}

			if (TestMoveDepth2Failed == true)
			{
				Evaluate_GameState_AtaxxPlayer2View(pGameStateObjectDepth1->IDofGameState, &GameStatePool);
			}

			OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);
		}
	}

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID, 1);

	//Add_To_Log(0, "IntegerEvaluation", pGameStateObject->iEvaluation);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);
}

void CAtaxxDepthFirstSearchAI::Execute_Player1AI_SearchDepth3(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState)
{
	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t RootGameStateID = -1;
	CGameStateValues* pRootGameStateObject = nullptr;

	GameStatePool.Get_UnusedGameStateObject(0, &pRootGameStateObject, &RootGameStateID);
	pRootGameStateObject->Clone_GameStateValues(pInActualGameState);
	pRootGameStateObject->Use_As_Maximizer();

	CAtaxxTestMove* pAtaxxTestMoveDepth1 = &pAtaxxTestMoveArray[1];
	CAtaxxTestMove* pAtaxxTestMoveDepth2 = &pAtaxxTestMoveArray[2];
	CAtaxxTestMove* pAtaxxTestMoveDepth3 = &pAtaxxTestMoveArray[3];

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		pAtaxxTestMoveDepth1->BoardPosID = i;
		
		if(pAtaxxTestMoveDepth1->Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
		{
			CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pAtaxxTestMoveDepth1->ResultingGameStateObjectID];

			bool TestMoveDepth2Failed = true;

			for (int32_t i = 0; i < ConstGameBoardSize; i++)
			{
				pAtaxxTestMoveDepth2->BoardPosID = i;

				if (pAtaxxTestMoveDepth2->Player2Move_If_Possible(pGameStateObjectDepth1, &GameStatePool, 2, true) > 0)
				{ 
					TestMoveDepth2Failed = false;

					CGameStateValues* pGameStateObjectDepth2 = &GameStatePool.pGameStateArray[pAtaxxTestMoveDepth2->ResultingGameStateObjectID];

					bool TestMoveDepth3Failed = true;

					for (int32_t i = 0; i < ConstGameBoardSize; i++)
					{
						pAtaxxTestMoveDepth3->BoardPosID = i;

						if (pAtaxxTestMoveDepth3->Player1Move_If_Possible(pGameStateObjectDepth2, &GameStatePool, 3, false) > 0)
						{
							TestMoveDepth3Failed = false;

							int32_t resultingGameStateObjectID = pAtaxxTestMoveDepth3->ResultingGameStateObjectID;
							Evaluate_GameState_AtaxxPlayer1View(resultingGameStateObjectID, &GameStatePool);
							OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
							GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);
						}
					}

					if (TestMoveDepth3Failed == true)
					{
						Evaluate_GameState_AtaxxPlayer1View(pGameStateObjectDepth2->IDofGameState, &GameStatePool);
					}

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth2->IDofGameState, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(pGameStateObjectDepth2->IDofGameState);
				}
			}

			if (TestMoveDepth2Failed == true)
			{
				Evaluate_GameState_AtaxxPlayer1View(pGameStateObjectDepth1->IDofGameState, &GameStatePool);
			}

			OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);
		}
	}

	

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID, 1);

	//Add_To_Log(0, "IntegerEvaluation", pGameStateObject->iEvaluation);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

}

void CAtaxxDepthFirstSearchAI::Execute_Player1AI_SearchDepth4(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState)
{
	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t RootGameStateID = -1;
	CGameStateValues* pRootGameStateObject = nullptr;

	GameStatePool.Get_UnusedGameStateObject(0, &pRootGameStateObject, &RootGameStateID);
	pRootGameStateObject->Clone_GameStateValues(pInActualGameState);
	pRootGameStateObject->Use_As_Maximizer();

	CAtaxxTestMove* pAtaxxTestMoveDepth1 = &pAtaxxTestMoveArray[1];
	CAtaxxTestMove* pAtaxxTestMoveDepth2 = &pAtaxxTestMoveArray[2];
	CAtaxxTestMove* pAtaxxTestMoveDepth3 = &pAtaxxTestMoveArray[3];
	CAtaxxTestMove* pAtaxxTestMoveDepth4 = &pAtaxxTestMoveArray[4];

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		pAtaxxTestMoveDepth1->BoardPosID = i;

		if (pAtaxxTestMoveDepth1->Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
		{
			CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pAtaxxTestMoveDepth1->ResultingGameStateObjectID];

			bool TestMoveDepth2Failed = true;

			for (int32_t i = 0; i < ConstGameBoardSize; i++)
			{
				pAtaxxTestMoveDepth2->BoardPosID = i;

				if (pAtaxxTestMoveDepth2->Player2Move_If_Possible(pGameStateObjectDepth1, &GameStatePool, 2, true) > 0)
				{
					TestMoveDepth2Failed = false;

					CGameStateValues* pGameStateObjectDepth2 = &GameStatePool.pGameStateArray[pAtaxxTestMoveDepth2->ResultingGameStateObjectID];

					bool TestMoveDepth3Failed = true;

					for (int32_t i = 0; i < ConstGameBoardSize; i++)
					{
						pAtaxxTestMoveDepth3->BoardPosID = i;

						if (pAtaxxTestMoveDepth3->Player1Move_If_Possible(pGameStateObjectDepth2, &GameStatePool, 3, false) > 0)
						{
							TestMoveDepth3Failed = false;

							CGameStateValues* pGameStateObjectDepth3 = &GameStatePool.pGameStateArray[pAtaxxTestMoveDepth3->ResultingGameStateObjectID];

							bool TestMoveDepth4Failed = true;

							for (int32_t i = 0; i < ConstGameBoardSize; i++)
							{
								pAtaxxTestMoveDepth4->BoardPosID = i;

								if (pAtaxxTestMoveDepth4->Player2Move_If_Possible(pGameStateObjectDepth3, &GameStatePool, 4, true) > 0)
								{
									TestMoveDepth4Failed = false;

									int32_t resultingGameStateObjectID = pAtaxxTestMoveDepth4->ResultingGameStateObjectID;
									Evaluate_GameState_AtaxxPlayer1View(resultingGameStateObjectID, &GameStatePool);
									OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
									GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);
								}
							}

							if (TestMoveDepth4Failed == true)
							{
								Evaluate_GameState_AtaxxPlayer1View(pGameStateObjectDepth3->IDofGameState, &GameStatePool);
							}

							OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth3->IDofGameState, &GameStatePool);
							GameStatePool.Stop_Using_GameStateObject(pGameStateObjectDepth3->IDofGameState);
						}
					}

					if (TestMoveDepth3Failed == true)
					{
						Evaluate_GameState_AtaxxPlayer1View(pGameStateObjectDepth2->IDofGameState, &GameStatePool);
					}

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth2->IDofGameState, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(pGameStateObjectDepth2->IDofGameState);
				}
			}

			if (TestMoveDepth2Failed == true)
			{
				Evaluate_GameState_AtaxxPlayer1View(pGameStateObjectDepth1->IDofGameState, &GameStatePool);
			}

			OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);
		}
	}

	//Backpropagate_MinimaxIntegerEvaluationValues(&GameStatePool);

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID, 1);

	//Add_To_Log(0, "IntegerEvaluation", pGameStateObject->iEvaluation);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

}

void CAtaxxDepthFirstSearchAI::Execute_Player1AI_SearchDepth5(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState)
{
	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t RootGameStateID = -1;
	CGameStateValues* pRootGameStateObject = nullptr;

	GameStatePool.Get_UnusedGameStateObject(0, &pRootGameStateObject, &RootGameStateID);
	pRootGameStateObject->Clone_GameStateValues(pInActualGameState);
	pRootGameStateObject->Use_As_Maximizer();

	CAtaxxTestMove* pAtaxxTestMoveDepth1 = &pAtaxxTestMoveArray[1];
	CAtaxxTestMove* pAtaxxTestMoveDepth2 = &pAtaxxTestMoveArray[2];
	CAtaxxTestMove* pAtaxxTestMoveDepth3 = &pAtaxxTestMoveArray[3];
	CAtaxxTestMove* pAtaxxTestMoveDepth4 = &pAtaxxTestMoveArray[4];
	CAtaxxTestMove* pAtaxxTestMoveDepth5 = &pAtaxxTestMoveArray[5];

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		pAtaxxTestMoveDepth1->BoardPosID = i;

		if (pAtaxxTestMoveDepth1->Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
		{
			CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pAtaxxTestMoveDepth1->ResultingGameStateObjectID];

			bool TestMoveDepth2Failed = true;

			for (int32_t i = 0; i < ConstGameBoardSize; i++)
			{
				pAtaxxTestMoveDepth2->BoardPosID = i;

				if (pAtaxxTestMoveDepth2->Player2Move_If_Possible(pGameStateObjectDepth1, &GameStatePool, 2, true) > 0)
				{
					TestMoveDepth2Failed = false;

					CGameStateValues* pGameStateObjectDepth2 = &GameStatePool.pGameStateArray[pAtaxxTestMoveDepth2->ResultingGameStateObjectID];

					bool TestMoveDepth3Failed = true;

					for (int32_t i = 0; i < ConstGameBoardSize; i++)
					{
						pAtaxxTestMoveDepth3->BoardPosID = i;

						if (pAtaxxTestMoveDepth3->Player1Move_If_Possible(pGameStateObjectDepth2, &GameStatePool, 3, false) > 0)
						{
							TestMoveDepth3Failed = false;

							CGameStateValues* pGameStateObjectDepth3 = &GameStatePool.pGameStateArray[pAtaxxTestMoveDepth3->ResultingGameStateObjectID];

							bool TestMoveDepth4Failed = true;

							for (int32_t i = 0; i < ConstGameBoardSize; i++)
							{
								pAtaxxTestMoveDepth4->BoardPosID = i;

								if (pAtaxxTestMoveDepth4->Player2Move_If_Possible(pGameStateObjectDepth3, &GameStatePool, 4, true) > 0)
								{
									TestMoveDepth4Failed = false;

									CGameStateValues* pGameStateObjectDepth4 = &GameStatePool.pGameStateArray[pAtaxxTestMoveDepth4->ResultingGameStateObjectID];

									bool TestMoveDepth5Failed = true;

									for (int32_t i = 0; i < ConstGameBoardSize; i++)
									{
										pAtaxxTestMoveDepth5->BoardPosID = i;

										if (pAtaxxTestMoveDepth5->Player1Move_If_Possible(pGameStateObjectDepth4, &GameStatePool, 5, false) > 0)
										{ 
											TestMoveDepth5Failed = false;

											int32_t resultingGameStateObjectID = pAtaxxTestMoveDepth5->ResultingGameStateObjectID;
											Evaluate_GameState_AtaxxPlayer1View(resultingGameStateObjectID, &GameStatePool);
											OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
											GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);
										}
									}

									if (TestMoveDepth5Failed == true)
									{
										Evaluate_GameState_AtaxxPlayer1View(pGameStateObjectDepth4->IDofGameState, &GameStatePool);
									}

									OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth4->IDofGameState, &GameStatePool);
									GameStatePool.Stop_Using_GameStateObject(pGameStateObjectDepth4->IDofGameState);
									
								}
							}

							if (TestMoveDepth4Failed == true)
							{
								Evaluate_GameState_AtaxxPlayer1View(pGameStateObjectDepth3->IDofGameState, &GameStatePool);
							}

							OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth3->IDofGameState, &GameStatePool);
							GameStatePool.Stop_Using_GameStateObject(pGameStateObjectDepth3->IDofGameState);
						}
					}

					if (TestMoveDepth3Failed == true)
					{
						Evaluate_GameState_AtaxxPlayer1View(pGameStateObjectDepth2->IDofGameState, &GameStatePool);
					}

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth2->IDofGameState, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(pGameStateObjectDepth2->IDofGameState);
				}
			}

			if (TestMoveDepth2Failed == true)
			{
				Evaluate_GameState_AtaxxPlayer1View(pGameStateObjectDepth1->IDofGameState, &GameStatePool);
			}

			OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);
		}
	}

	//Backpropagate_MinimaxIntegerEvaluationValues(&GameStatePool);

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID, 1);

	//Add_To_Log(0, "IntegerEvaluation", pGameStateObject->iEvaluation);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

}

void CAtaxxDepthFirstSearchAI::Execute_Player1AI_SearchDepth6(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState)
{
	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t RootGameStateID = -1;
	CGameStateValues* pRootGameStateObject = nullptr;

	GameStatePool.Get_UnusedGameStateObject(0, &pRootGameStateObject, &RootGameStateID);
	pRootGameStateObject->Clone_GameStateValues(pInActualGameState);
	pRootGameStateObject->Use_As_Maximizer();

	CAtaxxTestMove* pAtaxxTestMoveDepth1 = &pAtaxxTestMoveArray[1];
	CAtaxxTestMove* pAtaxxTestMoveDepth2 = &pAtaxxTestMoveArray[2];
	CAtaxxTestMove* pAtaxxTestMoveDepth3 = &pAtaxxTestMoveArray[3];
	CAtaxxTestMove* pAtaxxTestMoveDepth4 = &pAtaxxTestMoveArray[4];
	CAtaxxTestMove* pAtaxxTestMoveDepth5 = &pAtaxxTestMoveArray[5];
	CAtaxxTestMove* pAtaxxTestMoveDepth6 = &pAtaxxTestMoveArray[6];

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		pAtaxxTestMoveDepth1->BoardPosID = i;

		if (pAtaxxTestMoveDepth1->Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
		{
			CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pAtaxxTestMoveDepth1->ResultingGameStateObjectID];

			bool TestMoveDepth2Failed = true;

			for (int32_t i = 0; i < ConstGameBoardSize; i++)
			{
				pAtaxxTestMoveDepth2->BoardPosID = i;

				if (pAtaxxTestMoveDepth2->Player2Move_If_Possible(pGameStateObjectDepth1, &GameStatePool, 2, true) > 0)
				{
					TestMoveDepth2Failed = false;

					CGameStateValues* pGameStateObjectDepth2 = &GameStatePool.pGameStateArray[pAtaxxTestMoveDepth2->ResultingGameStateObjectID];

					bool TestMoveDepth3Failed = true;

					for (int32_t i = 0; i < ConstGameBoardSize; i++)
					{
						pAtaxxTestMoveDepth3->BoardPosID = i;

						if (pAtaxxTestMoveDepth3->Player1Move_If_Possible(pGameStateObjectDepth2, &GameStatePool, 3, false) > 0)
						{
							TestMoveDepth3Failed = false;

							CGameStateValues* pGameStateObjectDepth3 = &GameStatePool.pGameStateArray[pAtaxxTestMoveDepth3->ResultingGameStateObjectID];

							bool TestMoveDepth4Failed = true;

							for (int32_t i = 0; i < ConstGameBoardSize; i++)
							{
								pAtaxxTestMoveDepth4->BoardPosID = i;

								if (pAtaxxTestMoveDepth4->Player2Move_If_Possible(pGameStateObjectDepth3, &GameStatePool, 4, true) > 0)
								{
									TestMoveDepth4Failed = false;

									CGameStateValues* pGameStateObjectDepth4 = &GameStatePool.pGameStateArray[pAtaxxTestMoveDepth4->ResultingGameStateObjectID];

									bool TestMoveDepth5Failed = true;

									for (int32_t i = 0; i < ConstGameBoardSize; i++)
									{
										pAtaxxTestMoveDepth5->BoardPosID = i;

										if (pAtaxxTestMoveDepth5->Player1Move_If_Possible(pGameStateObjectDepth4, &GameStatePool, 5, false) > 0)
										{
											TestMoveDepth5Failed = false;

											CGameStateValues* pGameStateObjectDepth5 = &GameStatePool.pGameStateArray[pAtaxxTestMoveDepth5->ResultingGameStateObjectID];

											bool TestMoveDepth6Failed = Player1AI_InnerEvalulationLoop(pGameStateObjectDepth5, 1, 6);

											/*bool TestMoveDepth6Failed = true;

											for (int32_t i = 0; i < ConstGameBoardSize; i++)
											{
												pAtaxxTestMoveDepth6->BoardPosID = i;

												if (pAtaxxTestMoveDepth6->Player2Move_If_Possible(pGameStateObjectDepth5, &GameStatePool, 6, true) > 0)
												{
													TestMoveDepth6Failed = false;

													int32_t resultingGameStateObjectID = pAtaxxTestMoveDepth6->ResultingGameStateObjectID;
													Evaluate_GameState_Player1View(resultingGameStateObjectID, &GameStatePool);
													OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
													GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);
												}
											}*/

											if (TestMoveDepth6Failed == true)
											{
												Evaluate_GameState_AtaxxPlayer1View(pGameStateObjectDepth5->IDofGameState, &GameStatePool);
											}

											OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth5->IDofGameState, &GameStatePool);
											GameStatePool.Stop_Using_GameStateObject(pGameStateObjectDepth5->IDofGameState);
											
										}
									}

									if (TestMoveDepth5Failed == true)
									{
										Evaluate_GameState_AtaxxPlayer1View(pGameStateObjectDepth4->IDofGameState, &GameStatePool);
									}

									OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth4->IDofGameState, &GameStatePool);
									GameStatePool.Stop_Using_GameStateObject(pGameStateObjectDepth4->IDofGameState);

								}
							}

							if (TestMoveDepth4Failed == true)
							{
								Evaluate_GameState_AtaxxPlayer1View(pGameStateObjectDepth3->IDofGameState, &GameStatePool);
							}

							OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth3->IDofGameState, &GameStatePool);
							GameStatePool.Stop_Using_GameStateObject(pGameStateObjectDepth3->IDofGameState);
						}
					}

					if (TestMoveDepth3Failed == true)
					{
						Evaluate_GameState_AtaxxPlayer1View(pGameStateObjectDepth2->IDofGameState, &GameStatePool);
					}

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth2->IDofGameState, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(pGameStateObjectDepth2->IDofGameState);
				}
			}

			if (TestMoveDepth2Failed == true)
			{
				Evaluate_GameState_AtaxxPlayer1View(pGameStateObjectDepth1->IDofGameState, &GameStatePool);
			}

			OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);
		}
	}

	//Backpropagate_MinimaxIntegerEvaluationValues(&GameStatePool);

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID, 1);

	//Add_To_Log(0, "IntegerEvaluation", pGameStateObject->iEvaluation);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

}

void CAtaxxDepthFirstSearchAI::Execute_Player2AI_SearchDepth6(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState)
{
	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t RootGameStateID = -1;
	CGameStateValues* pRootGameStateObject = nullptr;

	GameStatePool.Get_UnusedGameStateObject(0, &pRootGameStateObject, &RootGameStateID);
	pRootGameStateObject->Clone_GameStateValues(pInActualGameState);
	pRootGameStateObject->Use_As_Maximizer();

	CAtaxxTestMove* pAtaxxTestMoveDepth1 = &pAtaxxTestMoveArray[1];
	CAtaxxTestMove* pAtaxxTestMoveDepth2 = &pAtaxxTestMoveArray[2];
	CAtaxxTestMove* pAtaxxTestMoveDepth3 = &pAtaxxTestMoveArray[3];
	CAtaxxTestMove* pAtaxxTestMoveDepth4 = &pAtaxxTestMoveArray[4];
	CAtaxxTestMove* pAtaxxTestMoveDepth5 = &pAtaxxTestMoveArray[5];
	CAtaxxTestMove* pAtaxxTestMoveDepth6 = &pAtaxxTestMoveArray[6];

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		pAtaxxTestMoveDepth1->BoardPosID = i;

		if (pAtaxxTestMoveDepth1->Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
		{
			CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pAtaxxTestMoveDepth1->ResultingGameStateObjectID];

			bool TestMoveDepth2Failed = true;

			for (int32_t i = 0; i < ConstGameBoardSize; i++)
			{
				pAtaxxTestMoveDepth2->BoardPosID = i;

				if (pAtaxxTestMoveDepth2->Player1Move_If_Possible(pGameStateObjectDepth1, &GameStatePool, 2, true) > 0)
				{
					TestMoveDepth2Failed = false;

					CGameStateValues* pGameStateObjectDepth2 = &GameStatePool.pGameStateArray[pAtaxxTestMoveDepth2->ResultingGameStateObjectID];

					bool TestMoveDepth3Failed = true;

					for (int32_t i = 0; i < ConstGameBoardSize; i++)
					{
						pAtaxxTestMoveDepth3->BoardPosID = i;

						if (pAtaxxTestMoveDepth3->Player2Move_If_Possible(pGameStateObjectDepth2, &GameStatePool, 3, false) > 0)
						{
							TestMoveDepth3Failed = false;

							CGameStateValues* pGameStateObjectDepth3 = &GameStatePool.pGameStateArray[pAtaxxTestMoveDepth3->ResultingGameStateObjectID];

							bool TestMoveDepth4Failed = true;

							for (int32_t i = 0; i < ConstGameBoardSize; i++)
							{
								pAtaxxTestMoveDepth4->BoardPosID = i;

								if (pAtaxxTestMoveDepth4->Player1Move_If_Possible(pGameStateObjectDepth3, &GameStatePool, 4, true) > 0)
								{
									TestMoveDepth4Failed = false;

									CGameStateValues* pGameStateObjectDepth4 = &GameStatePool.pGameStateArray[pAtaxxTestMoveDepth4->ResultingGameStateObjectID];

									bool TestMoveDepth5Failed = true;

									for (int32_t i = 0; i < ConstGameBoardSize; i++)
									{
										pAtaxxTestMoveDepth5->BoardPosID = i;

										if (pAtaxxTestMoveDepth5->Player2Move_If_Possible(pGameStateObjectDepth4, &GameStatePool, 5, false) > 0)
										{
											TestMoveDepth5Failed = false;

											CGameStateValues* pGameStateObjectDepth5 = &GameStatePool.pGameStateArray[pAtaxxTestMoveDepth5->ResultingGameStateObjectID];

											bool TestMoveDepth6Failed = Player2AI_InnerEvalulationLoop(pGameStateObjectDepth5, 0, 6);

											/*bool TestMoveDepth6Failed = true;

											for (int32_t i = 0; i < ConstGameBoardSize; i++)
											{
												pAtaxxTestMoveDepth6->BoardPosID = i;

												if (pAtaxxTestMoveDepth6->Player1Move_If_Possible(pGameStateObjectDepth5, &GameStatePool, 6, true) > 0)
												{
													TestMoveDepth6Failed = false;

													int32_t resultingGameStateObjectID = pAtaxxTestMoveDepth6->ResultingGameStateObjectID;
													Evaluate_GameState_Player2View(resultingGameStateObjectID, &GameStatePool);
													OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
													GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);
												}
											}*/

											if (TestMoveDepth6Failed == true)
											{
												Evaluate_GameState_AtaxxPlayer2View(pGameStateObjectDepth5->IDofGameState, &GameStatePool);
											}

											OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth5->IDofGameState, &GameStatePool);
											GameStatePool.Stop_Using_GameStateObject(pGameStateObjectDepth5->IDofGameState);

										}
									}

									if (TestMoveDepth5Failed == true)
									{
										Evaluate_GameState_AtaxxPlayer2View(pGameStateObjectDepth4->IDofGameState, &GameStatePool);
									}

									OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth4->IDofGameState, &GameStatePool);
									GameStatePool.Stop_Using_GameStateObject(pGameStateObjectDepth4->IDofGameState);

								}
							}

							if (TestMoveDepth4Failed == true)
							{
								Evaluate_GameState_AtaxxPlayer2View(pGameStateObjectDepth3->IDofGameState, &GameStatePool);
							}

							OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth3->IDofGameState, &GameStatePool);
							GameStatePool.Stop_Using_GameStateObject(pGameStateObjectDepth3->IDofGameState);
						}
					}

					if (TestMoveDepth3Failed == true)
					{
						Evaluate_GameState_AtaxxPlayer2View(pGameStateObjectDepth2->IDofGameState, &GameStatePool);
					}

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth2->IDofGameState, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(pGameStateObjectDepth2->IDofGameState);
				}
			}

			if (TestMoveDepth2Failed == true)
			{
				Evaluate_GameState_AtaxxPlayer2View(pGameStateObjectDepth1->IDofGameState, &GameStatePool);
			}

			OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);
		}
	}

	//Backpropagate_MinimaxIntegerEvaluationValues(&GameStatePool);

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID, 1);

	//Add_To_Log(0, "IntegerEvaluation", pGameStateObject->iEvaluation);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

}

void CAtaxxDepthFirstSearchAI::Execute_Player2AI_SearchDepth5(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState)
{
	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t RootGameStateID = -1;
	CGameStateValues* pRootGameStateObject = nullptr;

	GameStatePool.Get_UnusedGameStateObject(0, &pRootGameStateObject, &RootGameStateID);
	pRootGameStateObject->Clone_GameStateValues(pInActualGameState);
	pRootGameStateObject->Use_As_Maximizer();

	CAtaxxTestMove* pAtaxxTestMoveDepth1 = &pAtaxxTestMoveArray[1];
	CAtaxxTestMove* pAtaxxTestMoveDepth2 = &pAtaxxTestMoveArray[2];
	CAtaxxTestMove* pAtaxxTestMoveDepth3 = &pAtaxxTestMoveArray[3];
	CAtaxxTestMove* pAtaxxTestMoveDepth4 = &pAtaxxTestMoveArray[4];
	CAtaxxTestMove* pAtaxxTestMoveDepth5 = &pAtaxxTestMoveArray[5];

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		pAtaxxTestMoveDepth1->BoardPosID = i;

		if (pAtaxxTestMoveDepth1->Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
		{
			CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pAtaxxTestMoveDepth1->ResultingGameStateObjectID];

			bool TestMoveDepth2Failed = true;

			for (int32_t i = 0; i < ConstGameBoardSize; i++)
			{
				pAtaxxTestMoveDepth2->BoardPosID = i;

				if (pAtaxxTestMoveDepth2->Player1Move_If_Possible(pGameStateObjectDepth1, &GameStatePool, 2, true) > 0)
				{
					TestMoveDepth2Failed = false;

					CGameStateValues* pGameStateObjectDepth2 = &GameStatePool.pGameStateArray[pAtaxxTestMoveDepth2->ResultingGameStateObjectID];

					bool TestMoveDepth3Failed = true;

					for (int32_t i = 0; i < ConstGameBoardSize; i++)
					{
						pAtaxxTestMoveDepth3->BoardPosID = i;

						if (pAtaxxTestMoveDepth3->Player2Move_If_Possible(pGameStateObjectDepth2, &GameStatePool, 3, false) > 0)
						{
							TestMoveDepth3Failed = false;

							CGameStateValues* pGameStateObjectDepth3 = &GameStatePool.pGameStateArray[pAtaxxTestMoveDepth3->ResultingGameStateObjectID];

							bool TestMoveDepth4Failed = true;

							for (int32_t i = 0; i < ConstGameBoardSize; i++)
							{
								pAtaxxTestMoveDepth4->BoardPosID = i;

								if (pAtaxxTestMoveDepth4->Player1Move_If_Possible(pGameStateObjectDepth3, &GameStatePool, 4, true) > 0)
								{
									TestMoveDepth4Failed = false;

									CGameStateValues* pGameStateObjectDepth4 = &GameStatePool.pGameStateArray[pAtaxxTestMoveDepth4->ResultingGameStateObjectID];

									bool TestMoveDepth5Failed = true;

									for (int32_t i = 0; i < ConstGameBoardSize; i++)
									{
										pAtaxxTestMoveDepth5->BoardPosID = i;

										if (pAtaxxTestMoveDepth5->Player2Move_If_Possible(pGameStateObjectDepth4, &GameStatePool, 5, false) > 0)
										{
											TestMoveDepth5Failed = false;

											int32_t resultingGameStateObjectID = pAtaxxTestMoveDepth5->ResultingGameStateObjectID;
											Evaluate_GameState_AtaxxPlayer2View(resultingGameStateObjectID, &GameStatePool);
											OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
											GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);
										}
									}

									if (TestMoveDepth5Failed == true)
									{
										Evaluate_GameState_AtaxxPlayer2View(pGameStateObjectDepth4->IDofGameState, &GameStatePool);
									}

									OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth4->IDofGameState, &GameStatePool);
									GameStatePool.Stop_Using_GameStateObject(pGameStateObjectDepth4->IDofGameState);

								}
							}

							if (TestMoveDepth4Failed == true)
							{
								Evaluate_GameState_AtaxxPlayer2View(pGameStateObjectDepth3->IDofGameState, &GameStatePool);
							}

							OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth3->IDofGameState, &GameStatePool);
							GameStatePool.Stop_Using_GameStateObject(pGameStateObjectDepth3->IDofGameState);
						}
					}

					if (TestMoveDepth3Failed == true)
					{
						Evaluate_GameState_AtaxxPlayer2View(pGameStateObjectDepth2->IDofGameState, &GameStatePool);
					}

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth2->IDofGameState, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(pGameStateObjectDepth2->IDofGameState);
				}
			}

			if (TestMoveDepth2Failed == true)
			{
				Evaluate_GameState_AtaxxPlayer2View(pGameStateObjectDepth1->IDofGameState, &GameStatePool);
			}

			OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);
		}
	}

	//Backpropagate_MinimaxIntegerEvaluationValues(&GameStatePool);

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID, 1);

	//Add_To_Log(0, "IntegerEvaluation", pGameStateObject->iEvaluation);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

}

void CAtaxxDepthFirstSearchAI::Execute_Player2AI_SearchDepth4(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState)
{
	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t RootGameStateID = -1;
	CGameStateValues* pRootGameStateObject = nullptr;

	GameStatePool.Get_UnusedGameStateObject(0, &pRootGameStateObject, &RootGameStateID);
	pRootGameStateObject->Clone_GameStateValues(pInActualGameState);
	pRootGameStateObject->Use_As_Maximizer();

	CAtaxxTestMove* pAtaxxTestMoveDepth1 = &pAtaxxTestMoveArray[1];
	CAtaxxTestMove* pAtaxxTestMoveDepth2 = &pAtaxxTestMoveArray[2];
	CAtaxxTestMove* pAtaxxTestMoveDepth3 = &pAtaxxTestMoveArray[3];
	CAtaxxTestMove* pAtaxxTestMoveDepth4 = &pAtaxxTestMoveArray[4];

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		pAtaxxTestMoveDepth1->BoardPosID = i;

		if (pAtaxxTestMoveDepth1->Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
		{
			CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pAtaxxTestMoveDepth1->ResultingGameStateObjectID];

			bool TestMoveDepth2Failed = true;

			for (int32_t i = 0; i < ConstGameBoardSize; i++)
			{
				pAtaxxTestMoveDepth2->BoardPosID = i;

				if (pAtaxxTestMoveDepth2->Player1Move_If_Possible(pGameStateObjectDepth1, &GameStatePool, 2, true) > 0)
				{
					TestMoveDepth2Failed = false;

					CGameStateValues* pGameStateObjectDepth2 = &GameStatePool.pGameStateArray[pAtaxxTestMoveDepth2->ResultingGameStateObjectID];

					bool TestMoveDepth3Failed = true;

					for (int32_t i = 0; i < ConstGameBoardSize; i++)
					{
						pAtaxxTestMoveDepth3->BoardPosID = i;

						if (pAtaxxTestMoveDepth3->Player2Move_If_Possible(pGameStateObjectDepth2, &GameStatePool, 3, false) > 0)
						{
							TestMoveDepth3Failed = false;

							CGameStateValues* pGameStateObjectDepth3 = &GameStatePool.pGameStateArray[pAtaxxTestMoveDepth3->ResultingGameStateObjectID];

							bool TestMoveDepth4Failed = true;

							for (int32_t i = 0; i < ConstGameBoardSize; i++)
							{
								pAtaxxTestMoveDepth4->BoardPosID = i;

								if (pAtaxxTestMoveDepth4->Player1Move_If_Possible(pGameStateObjectDepth3, &GameStatePool, 4, true) > 0)
								{
									TestMoveDepth4Failed = false;

									int32_t resultingGameStateObjectID = pAtaxxTestMoveDepth4->ResultingGameStateObjectID;
									Evaluate_GameState_AtaxxPlayer2View(resultingGameStateObjectID, &GameStatePool);
									OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
									GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);
								}
							}

							if (TestMoveDepth4Failed == true)
							{
								Evaluate_GameState_AtaxxPlayer2View(pGameStateObjectDepth3->IDofGameState, &GameStatePool);
							}

							OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth3->IDofGameState, &GameStatePool);
							GameStatePool.Stop_Using_GameStateObject(pGameStateObjectDepth3->IDofGameState);
						}
					}

					if (TestMoveDepth3Failed == true)
					{
						Evaluate_GameState_AtaxxPlayer2View(pGameStateObjectDepth2->IDofGameState, &GameStatePool);
					}

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth2->IDofGameState, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(pGameStateObjectDepth2->IDofGameState);
				}
			}

			if (TestMoveDepth2Failed == true)
			{
				Evaluate_GameState_AtaxxPlayer2View(pGameStateObjectDepth1->IDofGameState, &GameStatePool);
			}

			OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);
		}
	}

	

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID, 1);

	//Add_To_Log(0, "IntegerEvaluation", pGameStateObject->iEvaluation);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

}

void CAtaxxDepthFirstSearchAI::Execute_Player2AI_SearchDepth3(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState)
{
	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t RootGameStateID = -1;
	CGameStateValues* pRootGameStateObject = nullptr;

	GameStatePool.Get_UnusedGameStateObject(0, &pRootGameStateObject, &RootGameStateID);
	pRootGameStateObject->Clone_GameStateValues(pInActualGameState);
	pRootGameStateObject->Use_As_Maximizer();

	CAtaxxTestMove* pAtaxxTestMoveDepth1 = &pAtaxxTestMoveArray[1];
	CAtaxxTestMove* pAtaxxTestMoveDepth2 = &pAtaxxTestMoveArray[2];
	CAtaxxTestMove* pAtaxxTestMoveDepth3 = &pAtaxxTestMoveArray[3];

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		pAtaxxTestMoveDepth1->BoardPosID = i;

		if (pAtaxxTestMoveDepth1->Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
		{
			CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pAtaxxTestMoveDepth1->ResultingGameStateObjectID];

			bool TestMoveDepth2Failed = true;

			for (int32_t i = 0; i < ConstGameBoardSize; i++)
			{
				pAtaxxTestMoveDepth2->BoardPosID = i;

				if (pAtaxxTestMoveDepth2->Player1Move_If_Possible(pGameStateObjectDepth1, &GameStatePool, 2, true) > 0)
				{
					TestMoveDepth2Failed = false;

					CGameStateValues* pGameStateObjectDepth2 = &GameStatePool.pGameStateArray[pAtaxxTestMoveDepth2->ResultingGameStateObjectID];

					bool TestMoveDepth3Failed = true;

					for (int32_t i = 0; i < ConstGameBoardSize; i++)
					{
						pAtaxxTestMoveDepth3->BoardPosID = i;

						if (pAtaxxTestMoveDepth3->Player2Move_If_Possible(pGameStateObjectDepth2, &GameStatePool, 3, false) > 0)
						{
							TestMoveDepth3Failed = false;

							int32_t resultingGameStateObjectID = pAtaxxTestMoveDepth3->ResultingGameStateObjectID;
							Evaluate_GameState_AtaxxPlayer2View(resultingGameStateObjectID, &GameStatePool);
							OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
							GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);
						}
					}

					if (TestMoveDepth3Failed == true)
					{
						Evaluate_GameState_AtaxxPlayer2View(pGameStateObjectDepth2->IDofGameState, &GameStatePool);
					}

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth2->IDofGameState, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(pGameStateObjectDepth2->IDofGameState);
				}
			}

			if (TestMoveDepth2Failed == true)
			{
				Evaluate_GameState_AtaxxPlayer2View(pGameStateObjectDepth1->IDofGameState, &GameStatePool);
			}

			OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);
		}
	}

	

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID, 1);

	//Add_To_Log(0, "IntegerEvaluation", pGameStateObject->iEvaluation);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

}

////////////////////

void CAtaxxDepthFirstSearchAI::Execute_Player1AI_EarlyOut(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState)
{
	if (Check_PossibleAtaxxPlayer1Moves(pInActualGameState->pValueArray) == false)
	{
		pOutNewGameState->Clone_Data(pInActualGameState);
		return;
	}

	EarlyOutCounter = 0;

	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t RootGameStateID = -1;
	CGameStateValues* pRootGameStateObject = nullptr;

	GameStatePool.Get_UnusedGameStateObject(0, &pRootGameStateObject, &RootGameStateID);
	pRootGameStateObject->Clone_GameStateValues(pInActualGameState);
	pRootGameStateObject->Use_As_Maximizer();

	CAtaxxTestMove* pAtaxxTestMove = &pAtaxxTestMoveArray[1];

	if (MaxSearchDepth == 2)
	{
		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			pAtaxxTestMove->BoardPosID = i;

			if (pAtaxxTestMove->Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pAtaxxTestMove->ResultingGameStateObjectID];

				bool TestMoveDepth2Failed = Player1AI_InnerEvalulationLoop_EarlyOut(pGameStateObjectDepth1, 1, 2);

				if (TestMoveDepth2Failed == true)
				{
					Evaluate_GameState_AtaxxPlayer1View(pGameStateObjectDepth1->IDofGameState, &GameStatePool);
				}

				OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);

				if (pGameStateObjectDepth1->iEvaluation >= DesiredEvaluationValue)
				{
					EarlyOutCounter++;
					break;
				}
			}
		}
	} // end of if (MaxSearchDepth == 2)
	else if (MaxSearchDepth > 2)
	{
		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			pAtaxxTestMove->BoardPosID = i;

			if (pAtaxxTestMove->Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pAtaxxTestMove->ResultingGameStateObjectID];

				bool TestMoveDepth2Failed = Player1AI_OuterEvalulationLoop_EarlyOut(pGameStateObjectDepth1, 1, 2);

				if (TestMoveDepth2Failed == true)
				{
					Evaluate_GameState_AtaxxPlayer1View(pGameStateObjectDepth1->IDofGameState, &GameStatePool);
				}

				OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);

				if (pGameStateObjectDepth1->iEvaluation >= DesiredEvaluationValue)
				{
					EarlyOutCounter++;
					break;
				}

			}
		}
	} // end of else if (MaxSearchDepth > 2)

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID, 1);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

	Add_To_Log(0, "EarlyOutCounter", EarlyOutCounter);
}

void CAtaxxDepthFirstSearchAI::Execute_Player2AI_EarlyOut(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState)
{
	if (Check_PossibleAtaxxPlayer2Moves(pInActualGameState->pValueArray) == false)
	{
		pOutNewGameState->Clone_Data(pInActualGameState);
		return;
	}

	EarlyOutCounter = 0;

	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t RootGameStateID = -1;
	CGameStateValues* pRootGameStateObject = nullptr;

	GameStatePool.Get_UnusedGameStateObject(0, &pRootGameStateObject, &RootGameStateID);
	pRootGameStateObject->Clone_GameStateValues(pInActualGameState);
	pRootGameStateObject->Use_As_Maximizer();

	CAtaxxTestMove* pAtaxxTestMove = &pAtaxxTestMoveArray[1];

	if (MaxSearchDepth == 2)
	{
		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			pAtaxxTestMove->BoardPosID = i;

			if (pAtaxxTestMove->Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pAtaxxTestMove->ResultingGameStateObjectID];

				bool TestMoveDepth2Failed = Player2AI_InnerEvalulationLoop_EarlyOut(pGameStateObjectDepth1, 0, 2);

				if (TestMoveDepth2Failed == true)
				{
					Evaluate_GameState_AtaxxPlayer2View(pGameStateObjectDepth1->IDofGameState, &GameStatePool);
				}

				OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);

				if (pGameStateObjectDepth1->iEvaluation >= DesiredEvaluationValue)
				{
					EarlyOutCounter++;
					break;
				}
			}
		}
	} // end of if (MaxSearchDepth == 2)
	else if (MaxSearchDepth > 2)
	{
		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			pAtaxxTestMove->BoardPosID = i;

			if (pAtaxxTestMove->Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pAtaxxTestMove->ResultingGameStateObjectID];

				bool TestMoveDepth2Failed = Player2AI_OuterEvalulationLoop_EarlyOut(pGameStateObjectDepth1, 0, 2);

				if (TestMoveDepth2Failed == true)
				{
					Evaluate_GameState_AtaxxPlayer2View(pGameStateObjectDepth1->IDofGameState, &GameStatePool);
				}

				OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);

				if (pGameStateObjectDepth1->iEvaluation >= DesiredEvaluationValue)
				{
					EarlyOutCounter++;
					break;
				}

			}
		}
	} // end of else if (MaxSearchDepth > 2)

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID, 1);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

	Add_To_Log(0, "EarlyOutCounter", EarlyOutCounter);

}

bool CAtaxxDepthFirstSearchAI::Player1AI_OuterEvalulationLoop_EarlyOut(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth)
{
	CAtaxxTestMove* pAtaxxTestMove = &pAtaxxTestMoveArray[depth];

	int32_t depthPlus1 = depth + 1;


	if (depth == MaxSearchDepthMinus1)
	{
		if (playerID == 0)
		{
			int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			for (int32_t i = 0; i < ConstGameBoardSize; i++)
			{
				pAtaxxTestMove->BoardPosID = i;

				if (pAtaxxTestMove->Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)
				{
					TestMovesFailed = false;

					int32_t resultingGameStateObjectID = pAtaxxTestMove->ResultingGameStateObjectID;
					CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

					bool TestMovesNextDepth = Player1AI_InnerEvalulationLoop_EarlyOut(pResultingGameStateObject, 1, depthPlus1);

					if (TestMovesNextDepth == true)
					{
						Evaluate_GameState_AtaxxPlayer1View(resultingGameStateObjectID, &GameStatePool);
					}

					int32_t evalValue = GameStatePool.pGameStateArray[resultingGameStateObjectID].iEvaluation;

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

					if (evalValue >= DesiredEvaluationValue)
					{
						EarlyOutCounter++;
						break;
					}

#ifdef PRUNING
					if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
					{
						//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
						break;
					}
#endif
				}
			}

			return TestMovesFailed;
		} // end of if (playerID == 0)
		else //if (playerID == 1)
		{
			int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			for (int32_t i = 0; i < ConstGameBoardSize; i++)
			{
				pAtaxxTestMove->BoardPosID = i;

				if (pAtaxxTestMove->Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)
				{
					TestMovesFailed = false;

					int32_t resultingGameStateObjectID = pAtaxxTestMove->ResultingGameStateObjectID;
					CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

					bool TestMovesNextDepth = Player1AI_InnerEvalulationLoop_EarlyOut(pResultingGameStateObject, 0, depthPlus1);

					if (TestMovesNextDepth == true)
					{
						Evaluate_GameState_AtaxxPlayer1View(resultingGameStateObjectID, &GameStatePool);
					}

					
					OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
					if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
					{
						//Add_To_Log(0, "PrevMaximizerEvalValue >= pInActualGameState->iEvaluation");
						break;
					}
#endif
				}
			}

			return TestMovesFailed;
		} // end of else //if (playerID == 1)
	} // end of if (depth == MaxSearchDepthMinus1)
	else if (depth < MaxSearchDepthMinus1)
	{
		if (playerID == 0)
		{
			int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			for (int32_t i = 0; i < ConstGameBoardSize; i++)
			{
				pAtaxxTestMove->BoardPosID = i;

				if (pAtaxxTestMove->Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)
				{
					TestMovesFailed = false;

					int32_t resultingGameStateObjectID = pAtaxxTestMove->ResultingGameStateObjectID;
					CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

					bool TestMovesNextDepth = Player1AI_OuterEvalulationLoop_EarlyOut(pResultingGameStateObject, 1, depthPlus1);

					if (TestMovesNextDepth == true)
					{
						Evaluate_GameState_AtaxxPlayer1View(resultingGameStateObjectID, &GameStatePool);
					}

					int32_t evalValue = GameStatePool.pGameStateArray[resultingGameStateObjectID].iEvaluation;

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

					if (evalValue >= DesiredEvaluationValue)
					{
						EarlyOutCounter++;
						break;
					}
#ifdef PRUNING
					if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
					{
						//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
						break;
					}
#endif
				}
			}

			return TestMovesFailed;
		} // end of if (playerID == 0)
		else //if (playerID == 1)
		{
			int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			for (int32_t i = 0; i < ConstGameBoardSize; i++)
			{
				pAtaxxTestMove->BoardPosID = i;

				if (pAtaxxTestMove->Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)
				{
					TestMovesFailed = false;

					int32_t resultingGameStateObjectID = pAtaxxTestMove->ResultingGameStateObjectID;
					CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

					bool TestMovesNextDepth = Player1AI_OuterEvalulationLoop_EarlyOut(pResultingGameStateObject, 0, depthPlus1);


					if (TestMovesNextDepth == true)
					{
						Evaluate_GameState_AtaxxPlayer1View(resultingGameStateObjectID, &GameStatePool);
					}

					

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

					
#ifdef PRUNING
					if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
					{
						//Add_To_Log(0, "PrevMaximizerEvalValue >= pInActualGameState->iEvaluation");
						break;
					}
#endif
				}
			}

			return TestMovesFailed;
		} // end of else //if (playerID == 1)
	} // end of else if (depth < MaxSearchDepthMinus1)

	return false;
}

bool CAtaxxDepthFirstSearchAI::Player2AI_OuterEvalulationLoop_EarlyOut(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth)
{
	CAtaxxTestMove* pAtaxxTestMove = &pAtaxxTestMoveArray[depth];

	int32_t depthPlus1 = depth + 1;


	if (depth == MaxSearchDepthMinus1)
	{
		if (playerID == 0)
		{
			int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			for (int32_t i = 0; i < ConstGameBoardSize; i++)
			{
				pAtaxxTestMove->BoardPosID = i;

				if (pAtaxxTestMove->Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)
				{
					TestMovesFailed = false;

					int32_t resultingGameStateObjectID = pAtaxxTestMove->ResultingGameStateObjectID;
					CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

					bool TestMovesNextDepth = Player2AI_InnerEvalulationLoop_EarlyOut(pResultingGameStateObject, 1, depthPlus1);

					if (TestMovesNextDepth == true)
					{
						Evaluate_GameState_AtaxxPlayer2View(resultingGameStateObjectID, &GameStatePool);
					}

					
					OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

					
#ifdef PRUNING
					if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
					{
						//Add_To_Log(0, "PrevMaximizerEvalValue >= pInActualGameState->iEvaluation");
						break;
					}
#endif
				}
			}

			return TestMovesFailed;
		} // end of if (playerID == 0)
		else //if (playerID == 1)
		{
			int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			for (int32_t i = 0; i < ConstGameBoardSize; i++)
			{
				pAtaxxTestMove->BoardPosID = i;

				if (pAtaxxTestMove->Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)
				{
					TestMovesFailed = false;

					int32_t resultingGameStateObjectID = pAtaxxTestMove->ResultingGameStateObjectID;
					CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

					bool TestMovesNextDepth = Player2AI_InnerEvalulationLoop_EarlyOut(pResultingGameStateObject, 0, depthPlus1);

					if (TestMovesNextDepth == true)
					{
						Evaluate_GameState_AtaxxPlayer2View(resultingGameStateObjectID, &GameStatePool);
					}

					int32_t evalValue = GameStatePool.pGameStateArray[resultingGameStateObjectID].iEvaluation;

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

					if (evalValue >= DesiredEvaluationValue)
					{
						EarlyOutCounter++;
						break;
					}

#ifdef PRUNING
					if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
					{
						//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
						break;
					}
#endif
				}
			}

			return TestMovesFailed;
		} // end of else //if (playerID == 1)
	} // end of if (depth == MaxSearchDepthMinus1)
	else if (depth < MaxSearchDepthMinus1)
	{
		if (playerID == 0)
		{
			int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			for (int32_t i = 0; i < ConstGameBoardSize; i++)
			{
				pAtaxxTestMove->BoardPosID = i;

				if (pAtaxxTestMove->Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)
				{
					TestMovesFailed = false;

					int32_t resultingGameStateObjectID = pAtaxxTestMove->ResultingGameStateObjectID;
					CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

					bool TestMovesNextDepth = Player2AI_OuterEvalulationLoop_EarlyOut(pResultingGameStateObject, 1, depthPlus1);

					if (TestMovesNextDepth == true)
					{
						Evaluate_GameState_AtaxxPlayer2View(resultingGameStateObjectID, &GameStatePool);
					}

					
					OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

					
#ifdef PRUNING
					if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
					{
						//Add_To_Log(0, "PrevMaximizerEvalValue >= pInActualGameState->iEvaluation");
						break;
					}
#endif
				}
			}

			return TestMovesFailed;
		} // end of if (playerID == 0)
		else //if (playerID == 1)
		{
			int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			for (int32_t i = 0; i < ConstGameBoardSize; i++)
			{
				pAtaxxTestMove->BoardPosID = i;

				if (pAtaxxTestMove->Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)
				{
					TestMovesFailed = false;

					int32_t resultingGameStateObjectID = pAtaxxTestMove->ResultingGameStateObjectID;
					CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

					bool TestMovesNextDepth = Player2AI_OuterEvalulationLoop_EarlyOut(pResultingGameStateObject, 0, depthPlus1);

					if (TestMovesNextDepth == true)
					{
						Evaluate_GameState_AtaxxPlayer2View(resultingGameStateObjectID, &GameStatePool);
					}

					int32_t evalValue = GameStatePool.pGameStateArray[resultingGameStateObjectID].iEvaluation;

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

					if (evalValue >= DesiredEvaluationValue)
					{
						EarlyOutCounter++;
						break;
					}
#ifdef PRUNING
					if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
					{
						//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
						break;
					}
#endif
				}
			}

			return TestMovesFailed;
		} // end of else //if (playerID == 1)
	} // end of else if (depth < MaxSearchDepthMinus1)

	return false;
}

bool CAtaxxDepthFirstSearchAI::Player1AI_InnerEvalulationLoop_EarlyOut(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth)
{
	CAtaxxTestMove* pAtaxxTestMove = &pAtaxxTestMoveArray[depth];

	if (playerID == 0)
	{
		int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

		bool TestMovesFailed = true;

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			pAtaxxTestMove->BoardPosID = i;

			if (pAtaxxTestMove->Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)
			{
				TestMovesFailed = false;

				int32_t resultingGameStateObjectID = pAtaxxTestMove->ResultingGameStateObjectID;
				Evaluate_GameState_AtaxxPlayer1View(resultingGameStateObjectID, &GameStatePool);

				int32_t evalValue = GameStatePool.pGameStateArray[resultingGameStateObjectID].iEvaluation;

				OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
				GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

				if (evalValue >= DesiredEvaluationValue)
				{
					EarlyOutCounter++;
					break;
				}

#ifdef PRUNING
				if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
				{
					//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
					break;
				}
#endif
			}
		}

		return TestMovesFailed;

	} // end of if (playerID == 0)
	else //if (playerID == 1)
	{
		int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

		bool TestMovesFailed = true;

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			pAtaxxTestMove->BoardPosID = i;

			if (pAtaxxTestMove->Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)
			{
				TestMovesFailed = false;

				int32_t resultingGameStateObjectID = pAtaxxTestMove->ResultingGameStateObjectID;
				Evaluate_GameState_AtaxxPlayer1View(resultingGameStateObjectID, &GameStatePool);

				
				OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
				GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

				

#ifdef PRUNING
				if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
				{
					//Add_To_Log(0, "PrevMaximizerEvalValue >= pInActualGameState->iEvaluation");
					break;
				}
#endif
			}
		}

		return TestMovesFailed;

	} // end of else //if (playerID == 1)

	return false;
}

bool CAtaxxDepthFirstSearchAI::Player2AI_InnerEvalulationLoop_EarlyOut(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth)
{
	CAtaxxTestMove* pAtaxxTestMove = &pAtaxxTestMoveArray[depth];

	if (playerID == 0)
	{
		int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

		bool TestMovesFailed = true;

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			pAtaxxTestMove->BoardPosID = i;

			if (pAtaxxTestMove->Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)
			{
				TestMovesFailed = false;

				int32_t resultingGameStateObjectID = pAtaxxTestMove->ResultingGameStateObjectID;
				Evaluate_GameState_AtaxxPlayer2View(resultingGameStateObjectID, &GameStatePool);

				
				OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
				GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

				

#ifdef PRUNING
				if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
				{
					//Add_To_Log(0, "PrevMaxEvalValue >= pInActualGameState->iEvaluation");
					break;
				}
#endif
			}
		}

		return TestMovesFailed;

	} // end of if (playerID == 0)
	else //if (playerID == 1)
	{
		int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

		bool TestMovesFailed = true;

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			pAtaxxTestMove->BoardPosID = i;

			if (pAtaxxTestMove->Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)
			{
				TestMovesFailed = false;

				int32_t resultingGameStateObjectID = pAtaxxTestMove->ResultingGameStateObjectID;
				Evaluate_GameState_AtaxxPlayer2View(resultingGameStateObjectID, &GameStatePool);

				int32_t evalValue = GameStatePool.pGameStateArray[resultingGameStateObjectID].iEvaluation;

				OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
				GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

				if (evalValue >= DesiredEvaluationValue)
				{
					EarlyOutCounter++;
					break;
				}

#ifdef PRUNING
				if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
				{
					//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
					break;
				}
#endif
			}
		}

		return TestMovesFailed;

	} // end of else //if (playerID == 1)

	return false;
}











