// Schutz vor Mehrfachdeklarationen :

#ifndef _Nodes_H_
#define _Nodes_H_

#include <iostream>

class CNode
{
public:

	int32_t NodeID = 0;
	int32_t PrevNodeID = -1;

	void *pObject = nullptr;

	
	CNode();
	~CNode();

	// Kopierkonstruktor l�schen:
	CNode(const CNode  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CNode & operator=(const CNode  &originalObject) = delete;

	bool Check_For_RootNode(void);
	bool Check_For_RootNode_Get_PrevNodeID(int32_t *pOutPrevNodeID);

	
};

class CBackTrackingHelperClass
{
public:

	int32_t NumOfNodes = 0;
	int32_t NumOfNodesMinus1 = 0;
	CNode *pNodeArray = nullptr;

	int32_t idOfNextUnusedNode = 0;

	CBackTrackingHelperClass();
	~CBackTrackingHelperClass();

	// Kopierkonstruktor l�schen:
	CBackTrackingHelperClass(const  CBackTrackingHelperClass  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CBackTrackingHelperClass & operator=(const  CBackTrackingHelperClass  &originalObject) = delete;

	void Initialize(int32_t numOfNodes);

	int32_t Request_ID_Of_NextUnusedNode(void);
	void Free_PreviousRequested_Node(void);
};



#endif