#include "Sudoku.h"

using namespace std;

void Output_Sudoku(int32_t *pInData)
{
	for (int32_t iy = 0; iy < SudokuSizePerDir; iy++)
	{
		for (int32_t ix = 0; ix < SudokuSizePerDir; ix++)
		{
			int32_t id = ix + iy * SudokuSizePerDir;
			cout << pInData[id] << " ";
		}

		cout << endl;
	}
}

int32_t Count_EmptySudokuCells(int32_t *pInData)
{
	int32_t counter = 0;

	for (int32_t i = 0; i < SudokuSizeSq; i++)
	{
		if (pInData[i] == 0)
		{
			counter++;
		}
	}

	return counter;
}
int32_t Count_SudokuErrors(int32_t *pInData)
{
	//static int32_t TransposeSudokuMatrix[SudokuSizeSq];

	int32_t errorCount = 0;

	bool checkValueArray[10];
	checkValueArray[0] = true;

	/* Nacheinander die einzelnen Zeilen des Sudoku-R�tsels durchgehen
	und die Anzahl der fehlerhaften Eintr�ge aufsummieren: */

	for (int32_t iy = 0; iy < SudokuSizePerDir; iy++)
	{
		int32_t iiy = iy * SudokuSizePerDir;

		for (int32_t i = 1; i < 10; i++)
		{
			checkValueArray[i] = false;
		}

		for (int32_t ix = 0; ix < SudokuSizePerDir; ix++)
		{
			int32_t id = ix + iiy;

			int32_t cellValue = pInData[id];

			checkValueArray[cellValue] = true;
		}

		for (int32_t i = 1; i < 10; i++)
		{
			if (checkValueArray[i] == false)
			{
				errorCount++;
			}
		}
	} // end of for (int32_t iy = 0; iy < SudokuSizePerDir; iy++)

	  /* Nacheinander die einzelnen Spalten des Sudoku-R�tsels durchgehen
	  und die Anzahl der fehlerhaften Eintr�ge zu den im ersten Schritt
	  ermittelten Fehlern hinzuaddieren: */

	for (int32_t ix = 0; ix < SudokuSizePerDir; ix++)
	{
		for (int32_t i = 1; i < 10; i++)
		{
			checkValueArray[i] = false;
		}

		for (int32_t iy = 0; iy < SudokuSizePerDir; iy++)
		{
			int32_t id = ix + iy * SudokuSizePerDir;

			int32_t cellValue = pInData[id];

			checkValueArray[cellValue] = true;
		}

		for (int32_t i = 1; i < 10; i++)
		{
			if (checkValueArray[i] == false)
			{
				errorCount++;
			}
		}
	} // end of for (int32_t ix = 0; ix < SudokuSizePerDir; ix++)



	/*
	//Sudoku-R�tsel transponieren, damit sich die Fehler in den Sudoku-Spalten einfacher ermitteln lassen: 

	for (int32_t iy = 0; iy < SudokuSizePerDir; iy++)
	{
		int32_t iiy = iy * SudokuSizePerDir;

		for (int32_t ix = 0; ix < SudokuSizePerDir; ix++)
		{
			TransposeSudokuMatrix[iy + ix * SudokuSizePerDir] = pInData[ix + iiy];
		}
	}

	// Nacheinander die einzelnen Spalten des Sudoku-R�tsels (bzw. die
	// Zeilen des transponierten Sudoku-R�tsels) durchgehen
	// und die Anzahl der fehlerhaften Spalten zur Anzahl der fehlerhaften
	// Zeilen hinzuaddieren: 


	for (int32_t iy = 0; iy < SudokuSizePerDir; iy++)
	{
		int32_t iiy = iy * SudokuSizePerDir;

		bool checkValueArray[10];

		checkValueArray[0] = true;

		for (int32_t i = 1; i < 10; i++)
		{
			checkValueArray[i] = false;
		}

		for (int32_t ix = 0; ix < SudokuSizePerDir; ix++)
		{
			int32_t id = ix + iiy;

			int32_t cellValue = TransposeSudokuMatrix[id];

			checkValueArray[cellValue] = true;
		}

		for (int32_t i = 1; i < 10; i++)
		{
			if (checkValueArray[i] == false)
			{
				errorCount++;
				break;
			}
		}
	} // end of for (int32_t iy = 0; iy < SudokuSizePerDir; iy++)
	*/

	/* Die neun 3x3-Bl�cke auf m�gliche Fehler hin �berpr�fen und
	die Anzahl der fehlerhaften Eintr�ge zur Anzahl der zuvor
	ermittelten Fehler hinzuaddieren: */

	for (int32_t startRow = 0; startRow < SudokuSizePerDir; startRow += 3)
	{
		for (int32_t startColumn = 0; startColumn < SudokuSizePerDir; startColumn += 3)
		{
			int32_t ixMin = startColumn;
			int32_t ixMaxPlus1 = ixMin + 3;

			int32_t iyMin = startRow;
			int32_t iyMaxPlus1 = iyMin + 3;

			for (int32_t i = 1; i < 10; i++)
			{
				checkValueArray[i] = false;
			}
			
			for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
			{
				int32_t iiy = iy * SudokuSizePerDir;

				for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
				{
					int32_t id = ix + iiy;

					int32_t cellValue = pInData[id];

					checkValueArray[cellValue] = true;
				}
			}

			for (int32_t i = 1; i < 10; i++)
			{
				if (checkValueArray[i] == false)
				{
					errorCount++;
				}
			}

		} // end of for (int32_t startColumn = 0; startColumn < SudokuSizePerDir; startColumn += 3)
	} // end of for (int32_t startRow = 0; startRow < SudokuSizePerDir; startRow += 3)

	/* Anzahl der Fehler durch 3 teilen, da jedes fehlerhafte Feld sowohl
	Teil einer Zeile, Spalte wie auch eines 3x3-Blocks ist: */

	return errorCount / 3;
}

void SudokuTransposition(int32_t *pOutData, int32_t *pInData)
{
	for (int32_t iy = 0; iy < SudokuSizePerDir; iy++)
	{
		int32_t iiy = iy * SudokuSizePerDir;

		for (int32_t ix = 0; ix < SudokuSizePerDir; ix++)
		{
			pOutData[iy + ix * SudokuSizePerDir] = pInData[ix + iiy];
		}
	}
}

void HorizontalSudokuReflection(int32_t *pOutData, int32_t *pInData)
{
	for (int32_t iy = 0; iy < SudokuSizePerDir; iy++)
	{
		int32_t iiy = iy * SudokuSizePerDir;

		for (int32_t ix = 0; ix < SudokuSizePerDir; ix++)
		{
			pOutData[8 - ix + iiy] = pInData[ix + iiy];
		}
	}
}

void VerticalSudokuReflection(int32_t *pOutData, int32_t *pInData)
{
	for (int32_t iy = 0; iy < SudokuSizePerDir; iy++)
	{
		for (int32_t ix = 0; ix < SudokuSizePerDir; ix++)
		{
			pOutData[ix + (8 - iy) * SudokuSizePerDir] = pInData[ix + iy * SudokuSizePerDir];
		}
	}
}


void SudokuPermutation(int32_t *pOutData, int32_t *pInData, int32_t number1, int32_t number2)
{
	for (int32_t i = 0; i < SudokuSizeSq; i++)
	{
		int32_t cellValue = pInData[i];

		if (cellValue == number1)
		{
			cellValue = number2;
		}
		else if (cellValue == number2)
		{
			cellValue = number1;
		}

		pOutData[i] = cellValue;	
	}
}

void Swap_TwoSudoku3x3Blocks_HelperFunction(int32_t *pOutData, int32_t *pInData, int32_t block1ID, int32_t block2ID)
{
	int32_t ixMin_Block1 = 3 * (block1ID % 3);
	int32_t ixMaxPlus1_Block1 = ixMin_Block1 + 3;

	int32_t iyMin_Block1 = 3 * (block1ID / 3);
	int32_t iyMaxPlus1_Block1 = iyMin_Block1 + 3;

	int32_t ixMin_Block2 = 3 * (block2ID % 3);
	int32_t ixMaxPlus1_Block2 = ixMin_Block2 + 3;

	int32_t iyMin_Block2 = 3 * (block2ID / 3);
	int32_t iyMaxPlus1_Block2 = iyMin_Block2 + 3;

	for (int32_t i = 0; i < SudokuSizeSq; i++)
	{
		pOutData[i] = pInData[i];
	}

	int32_t blockValueArray[9];

	int32_t counter = 0;

	for (int32_t iy = iyMin_Block1; iy < iyMaxPlus1_Block1; iy++)
	{
		int32_t iiy = iy * SudokuSizePerDir;

		for (int32_t ix = ixMin_Block1; ix < ixMaxPlus1_Block1; ix++)
		{
			int32_t id = ix + iiy;
			blockValueArray[counter] = pInData[id];
			counter++;
		}
	}

	counter = 0;

	for (int32_t iy = iyMin_Block2; iy < iyMaxPlus1_Block2; iy++)
	{
		int32_t iiy = iy * SudokuSizePerDir;

		for (int32_t ix = ixMin_Block2; ix < ixMaxPlus1_Block2; ix++)
		{
			int32_t id = ix + iiy;
			pOutData[id] = blockValueArray[counter];
			counter++;
		}
	}

	//////////////////////////

	counter = 0;

	for (int32_t iy = iyMin_Block2; iy < iyMaxPlus1_Block2; iy++)
	{
		int32_t iiy = iy * SudokuSizePerDir;

		for (int32_t ix = ixMin_Block2; ix < ixMaxPlus1_Block2; ix++)
		{
			int32_t id = ix + iiy;
			blockValueArray[counter] = pInData[id];
			counter++;
		}
	}

	counter = 0;

	for (int32_t iy = iyMin_Block1; iy < iyMaxPlus1_Block1; iy++)
	{
		int32_t iiy = iy * SudokuSizePerDir;

		for (int32_t ix = ixMin_Block1; ix < ixMaxPlus1_Block1; ix++)
		{
			int32_t id = ix + iiy;
			pOutData[id] = blockValueArray[counter];
			counter++;
		}
	}
}



void Swap_TwoSudoku9x3Blocks(int32_t *pOutData, int32_t *pInData, int32_t block1ID, int32_t block2ID)
{
	block1ID = block1ID % 3; // 0, 1, 2
	block2ID = block2ID % 3; // 0, 1, 2

	int32_t ixMin_Block1 = 0;
	int32_t ixMaxPlus1_Block1 = SudokuSizePerDir;

	int32_t iyMin_Block1 = 3 * block1ID;
	int32_t iyMaxPlus1_Block1 = iyMin_Block1 + 3;

	int32_t ixMin_Block2 = 0;
	int32_t ixMaxPlus1_Block2 = SudokuSizePerDir;

	int32_t iyMin_Block2 = 3 * block2ID;
	int32_t iyMaxPlus1_Block2 = iyMin_Block2 + 3;

	for (int32_t i = 0; i < SudokuSizeSq; i++)
	{
		pOutData[i] = pInData[i];
	}

	int32_t blockValueArray[27];

	int32_t counter = 0;

	/* Zahlenwerte von Block1 (pInData) im blockValueArray
	zwischenspeichern: */

	for (int32_t iy = iyMin_Block1; iy < iyMaxPlus1_Block1; iy++)
	{
		int32_t iiy = iy * SudokuSizePerDir;

		for (int32_t ix = ixMin_Block1; ix < ixMaxPlus1_Block1; ix++)
		{
			int32_t id = ix + iiy;
			blockValueArray[counter] = pInData[id];
			counter++;
		}
	}

	counter = 0;

	/* Zahlenwerte aus dem blockValueArray in den Block2
	(pOutData) kopieren: */

	for (int32_t iy = iyMin_Block2; iy < iyMaxPlus1_Block2; iy++)
	{
		int32_t iiy = iy * SudokuSizePerDir;

		for (int32_t ix = ixMin_Block2; ix < ixMaxPlus1_Block2; ix++)
		{
			int32_t id = ix + iiy;
			pOutData[id] = blockValueArray[counter];
			counter++;
		}
	}

	

	counter = 0;

	/* Zahlenwerte von Block2 (pInData) im blockValueArray
	zwischenspeichern: */

	for (int32_t iy = iyMin_Block2; iy < iyMaxPlus1_Block2; iy++)
	{
		int32_t iiy = iy * SudokuSizePerDir;

		for (int32_t ix = ixMin_Block2; ix < ixMaxPlus1_Block2; ix++)
		{
			int32_t id = ix + iiy;
			blockValueArray[counter] = pInData[id];
			counter++;
		}
	}

	counter = 0;

	/* Zahlenwerte aus dem blockValueArray in den Block1
	(pOutData) kopieren: */

	for (int32_t iy = iyMin_Block1; iy < iyMaxPlus1_Block1; iy++)
	{
		int32_t iiy = iy * SudokuSizePerDir;

		for (int32_t ix = ixMin_Block1; ix < ixMaxPlus1_Block1; ix++)
		{
			int32_t id = ix + iiy;
			pOutData[id] = blockValueArray[counter];
			counter++;
		}
	}
}

void Swap_TwoSudoku3x9Blocks(int32_t *pOutData, int32_t *pInData, int32_t block1ID, int32_t block2ID)
{
	block1ID = block1ID % 3; // 0, 1, 2
	block2ID = block2ID % 3; // 0, 1, 2

	int32_t ixMin_Block1 = 3 * block1ID;
	int32_t ixMaxPlus1_Block1 = ixMin_Block1 + 3;

	int32_t iyMin_Block1 = 0;
	int32_t iyMaxPlus1_Block1 = SudokuSizePerDir;

	int32_t ixMin_Block2 = 3 * block2ID;
	int32_t ixMaxPlus1_Block2 = ixMin_Block2 + 3;

	int32_t iyMin_Block2 = 0;
	int32_t iyMaxPlus1_Block2 = SudokuSizePerDir;

	for (int32_t i = 0; i < SudokuSizeSq; i++)
	{
		pOutData[i] = pInData[i];
	}

	int32_t blockValueArray[27];

	int32_t counter = 0;

	/* Zahlenwerte von Block1 (pInData) im blockValueArray
	zwischenspeichern: */

	for (int32_t iy = iyMin_Block1; iy < iyMaxPlus1_Block1; iy++)
	{
		int32_t iiy = iy * SudokuSizePerDir;

		for (int32_t ix = ixMin_Block1; ix < ixMaxPlus1_Block1; ix++)
		{
			int32_t id = ix + iiy;
			blockValueArray[counter] = pInData[id];
			counter++;
		}
	}

	counter = 0;

	/* Zahlenwerte aus dem blockValueArray in den Block2
	(pOutData) kopieren: */

	for (int32_t iy = iyMin_Block2; iy < iyMaxPlus1_Block2; iy++)
	{
		int32_t iiy = iy * SudokuSizePerDir;

		for (int32_t ix = ixMin_Block2; ix < ixMaxPlus1_Block2; ix++)
		{
			int32_t id = ix + iiy;
			pOutData[id] = blockValueArray[counter];
			counter++;
		}
	}

	counter = 0;

	/* Zahlenwerte von Block2 (pInData) im blockValueArray
	zwischenspeichern: */

	for (int32_t iy = iyMin_Block2; iy < iyMaxPlus1_Block2; iy++)
	{
		int32_t iiy = iy * SudokuSizePerDir;

		for (int32_t ix = ixMin_Block2; ix < ixMaxPlus1_Block2; ix++)
		{
			int32_t id = ix + iiy;
			blockValueArray[counter] = pInData[id];
			counter++;
		}
	}

	counter = 0;

	/* Zahlenwerte aus dem blockValueArray in den Block1
	(pOutData) kopieren: */

	for (int32_t iy = iyMin_Block1; iy < iyMaxPlus1_Block1; iy++)
	{
		int32_t iiy = iy * SudokuSizePerDir;

		for (int32_t ix = ixMin_Block1; ix < ixMaxPlus1_Block1; ix++)
		{
			int32_t id = ix + iiy;
			pOutData[id] = blockValueArray[counter];
			counter++;
		}
	}
}

void Swap_TwoSudokuRows(int32_t *pOutData, int32_t *pInData, int32_t blockRow1, int32_t blockRow2, int32_t _9x3BlockID)
{
	/* Indexwerte der zu vertauschenden Zeilen berechnen: */

	_9x3BlockID = _9x3BlockID % 3; // 0, 1, 2
	
	int32_t row1 = 3 * _9x3BlockID + blockRow1 % 3; // 3 * _9x3BlockID + 0, 1, 2
	int32_t row2 = 3 * _9x3BlockID + blockRow2 % 3; // 3 * _9x3BlockID + 0, 1, 2

	for (int32_t i = 0; i < SudokuSizeSq; i++)
	{
		pOutData[i] = pInData[i];
	}

	
	int32_t minID_Row1 = row1 * SudokuSizePerDir;
	int32_t maxIDPlus1_Row1 = minID_Row1 + SudokuSizePerDir;

	int32_t minID_Row2 = row2 * SudokuSizePerDir;
	int32_t maxIDPlus1_Row2 = minID_Row2 + SudokuSizePerDir;


	int32_t rowValueArray[9];
	int32_t counter = 0;

	/* Zahlenwerte von Row1 (pInData) im rowValueArray
	zwischenspeichern: */


	for (int32_t i = minID_Row1; i < maxIDPlus1_Row1; i++)
	{
		rowValueArray[counter++] = pInData[i];
		//counter++;
	}

	counter = 0;

	/* Zahlenwerte aus dem rowValueArray in Row2
	(pOutData) kopieren: */

	for (int32_t i = minID_Row2; i < maxIDPlus1_Row2; i++)
	{
		pOutData[i] = rowValueArray[counter++];
		//counter++;
	}

	counter = 0;

	/* Zahlenwerte von Row2 (pInData) im rowValueArray
	zwischenspeichern: */

	for (int32_t i = minID_Row2; i < maxIDPlus1_Row2; i++)
	{
		rowValueArray[counter++] = pInData[i];
		//counter++;
	}

	counter = 0;

	/* Zahlenwerte aus dem rowValueArray in Row1
	(pOutData) kopieren: */

	for (int32_t i = minID_Row1; i < maxIDPlus1_Row1; i++)
	{
		pOutData[i] = rowValueArray[counter++];
		//counter++;
	}
}

void Swap_TwoSudokuColumns(int32_t *pOutData, int32_t *pInData, int32_t blockColumn1, int32_t blockColumn2, int32_t _3x9BlockID)
{
	/* Indexwerte der zu vertauschenden Spalten berechnen: */

	_3x9BlockID = _3x9BlockID % 3; // 0, 1, 2
	
	int32_t column1 = 3 * _3x9BlockID + blockColumn1 % 3; // 3 * _3x9BlockID + 0, 1, 2
	int32_t column2 = 3 * _3x9BlockID + blockColumn2 % 3; // 3 * _3x9BlockID + 0, 1, 2

	for (int32_t i = 0; i < SudokuSizeSq; i++)
	{
		pOutData[i] = pInData[i];
	}

	int32_t columnValueArray[9];
	int32_t counter = 0;

	/* Zahlenwerte von Column1 (pInData) im columnValueArray
	zwischenspeichern: */

	for (int32_t i = column1; i < SudokuSizeSq; i += SudokuSizePerDir)
	{
		columnValueArray[counter++] = pInData[i];
		//counter++;
	}

	counter = 0;

	/* Zahlenwerte aus dem columnValueArray in Column2
	(pOutData) kopieren: */

	for (int32_t i = column2; i < SudokuSizeSq; i += SudokuSizePerDir)
	{
		pOutData[i] = columnValueArray[counter++];
		//counter++;
	}
	
	counter = 0;

	/* Zahlenwerte von Column2 (pInData) im columnValueArray
	zwischenspeichern: */

	for (int32_t i = column2; i < SudokuSizeSq; i += SudokuSizePerDir)
	{
		columnValueArray[counter++] = pInData[i];
		//counter++;
	}

	counter = 0;

	/* Zahlenwerte aus dem columnValueArray in Column1
	(pOutData) kopieren: */

	for (int32_t i = column1; i < SudokuSizeSq; i += SudokuSizePerDir)
	{
		pOutData[i] = columnValueArray[counter++];
		//counter++;
	}
}


bool Complete_SudokuRows_If_Possible(int32_t *pInOutData)
{
	bool addValue = false;

	for (int32_t iy = 0; iy < SudokuSizePerDir; iy++)
	{
		int32_t iiy = iy * SudokuSizePerDir;

		int32_t emptyCellID = 0;
		int32_t emptyCellCounter = 0;
		int32_t sumOfCellValues = 0;

		for (int32_t ix = 0; ix < SudokuSizePerDir; ix++)
		{
			int32_t id = ix + iiy;

			int32_t cellValue = pInOutData[id];

			if (cellValue == 0)
			{
				emptyCellID = id;
				emptyCellCounter++;
			}
			//else
			//{
			sumOfCellValues += cellValue;
				//}
		} // end of for (int32_t ix = 0; ix < SudokuSizePerDir; ix++)

		if (emptyCellCounter == 1)
		{
			pInOutData[emptyCellID] = 45 - sumOfCellValues; // Hinweis: 1 + ... + 9 = 45
			addValue = true;
		}
	} // for (int32_t iy = 0; iy < SudokuSizePerDir; iy++)

	return addValue;
}

bool Complete_SudokuColumns_If_Possible(int32_t *pInOutData)
{
	bool addValue = false;

	for (int32_t ix = 0; ix < SudokuSizePerDir; ix++)
	{
		int32_t emptyCellID = 0;
		int32_t emptyCellCounter = 0;
		int32_t sumOfCellValues = 0;

		for (int32_t iy = 0; iy < SudokuSizePerDir; iy++)
		{
			int32_t id = ix + iy * SudokuSizePerDir;

			int32_t cellValue = pInOutData[id];

			if (cellValue == 0)
			{
				emptyCellID = id;
				emptyCellCounter++;
			}
			//else
			//{
			sumOfCellValues += cellValue;
				//}
		} // end of for (int32_t iy = 0; iy < SudokuSizePerDir; iy++)

		if (emptyCellCounter == 1)
		{
			pInOutData[emptyCellID] = 45 - sumOfCellValues; // Hinweis: 1 + ... + 9 = 45
			addValue = true;
		}
	} // end of for (int32_t ix = 0; ix < SudokuSizePerDir; ix++)

	return addValue;
}

bool OLDComplete_SudokuColumns_If_Possible(int32_t *pInOutData)
{
	static int32_t TransposeSudokuMatrix[SudokuSizeSq];

	bool addValue = false;

	for (int32_t iy = 0; iy < SudokuSizePerDir; iy++)
	{
		int32_t iiy = iy * SudokuSizePerDir;

		for (int32_t ix = 0; ix < SudokuSizePerDir; ix++)
		{
			TransposeSudokuMatrix[iy + ix * SudokuSizePerDir] = pInOutData[ix + iiy];
		}
	}

	for (int32_t iy = 0; iy < SudokuSizePerDir; iy++)
	{
		int32_t iiy = iy * SudokuSizePerDir;

		int32_t emptyTransposedCellX = 0;
		int32_t emptyTransposedCellY = 0;
		int32_t emptyCellCounter = 0;
		int32_t sumOfCellValues = 0;

		for (int32_t ix = 0; ix < SudokuSizePerDir; ix++)
		{
			int32_t id = ix + iiy;

			int32_t cellValue = TransposeSudokuMatrix[id];

			if (cellValue == 0)
			{
				emptyTransposedCellX = ix;
				emptyTransposedCellY = iy;
				emptyCellCounter++;
			}
			//else
			//{
			sumOfCellValues += cellValue;
				//}
		} // end of for (int32_t ix = 0; ix < SudokuSizePerDir; ix++)

		if (emptyCellCounter == 1)
		{
			pInOutData[emptyTransposedCellY + emptyTransposedCellX * SudokuSizePerDir] = 45 - sumOfCellValues; // Hinweis: 1 + ... + 9 = 45
			addValue = true;
		}
	} // end of for (int32_t iy = 0; iy < SudokuSizePerDir; iy++)

	return addValue;
}

bool Complete_Sudoku3x3Blocks_If_Possible(int32_t *pInOutData)
{
	bool addValue = false;

	for (int32_t startRow = 0; startRow < SudokuSizePerDir; startRow += 3)
	{
		for (int32_t startColumn = 0; startColumn < SudokuSizePerDir; startColumn += 3)
		{
			int32_t ixMin = startColumn;
			int32_t ixMaxPlus1 = ixMin + 3;

			int32_t iyMin = startRow;
			int32_t iyMaxPlus1 = iyMin + 3;

			int32_t emptyCellID = 0;
			int32_t emptyCellCounter = 0;
			int32_t sumOfCellValues = 0;

			for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
			{
				int32_t iiy = iy * SudokuSizePerDir;

				for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
				{
					int32_t id = ix + iiy;

					int32_t cellValue = pInOutData[id];

					if (cellValue == 0)
					{
						emptyCellID = id;
						emptyCellCounter++;
					}
					//else
					//{
					sumOfCellValues += cellValue;
					//}
				} // end of for (int32_t ix = ixMin; ix < ixMax; ix++)
			} // end of for (int32_t iy = iyMin; iy < iyMax; iy++)

			if (emptyCellCounter == 1)
			{
				pInOutData[emptyCellID] = 45 - sumOfCellValues; // Hinweis: 1 + ... + 9 = 45
				addValue = true;
			}
		} // end of for (int32_t startColumn = 0; startColumn < SudokuSizePerDir; startColumn += 3)
	} // end of for (int32_t startRow = 0; startRow < SudokuSizePerDir; startRow += 3)

	return addValue;
}

bool Add_SudokuNumber_If_Possible(int32_t *pInOutData)
{
	for (int32_t id = 0; id < SudokuSizeSq; id++)
	{
		int32_t cellValue = pInOutData[id];

		if (cellValue > 0)
		{
			continue;
		}

		int32_t row = id / SudokuSizePerDir;
		int32_t column = id % SudokuSizePerDir;

		int32_t possibleNumberCounter = 0;
		int32_t possibleNumber = 0;

		for (int32_t number = 1; number < 10; number++)
		{
			if (Check_If_SudokuNumber_Could_Be_Correct(pInOutData, row, column, number) == true)
			{
				possibleNumber = number;
				possibleNumberCounter++;
			}
		}

		if (possibleNumberCounter == 1)
		{
			pInOutData[id] = possibleNumber;
			return true;
		}
	} // end of for (int32_t id = 0; id < SudokuSizeSq; id++)

	return false;
}

bool Add_SudokuNumber_If_Possible_Ext(int32_t *pInOutData)
{
	for (int32_t id = 0; id < SudokuSizeSq; id++)
	{
		int32_t cellValue = pInOutData[id];

		if (cellValue > 0)
		{
			continue;
		}

		int32_t row = id / SudokuSizePerDir;
		int32_t column = id % SudokuSizePerDir;

		int32_t possibleNumberCounter = 0;
		int32_t possibleNumberArray[9];

		for (int32_t number = 1; number < 10; number++)
		{
			if (Check_If_SudokuNumber_Could_Be_Correct(pInOutData, row, column, number) == true)
			{
				possibleNumberArray[possibleNumberCounter] = number;
				possibleNumberCounter++;
			}
		}

		if (possibleNumberCounter == 1)
		{
			pInOutData[id] = possibleNumberArray[0];
			return true;
		}
		else if (possibleNumberCounter > 1)
		{
			for (int32_t i = 0; i < possibleNumberCounter; i++)
			{
				int32_t possibleNumber = possibleNumberArray[i];
			
				/* �berpr�fen, ob possibleNumber noch in irgendeiner anderen Zeile (j)
				   der betrachteten Spalte (column) stehen k�nnte. Sofern dies nicht m�glich ist
				   (uniquePos == true), k�nnen wir possibleNumber ins entsprechende
				   Sudoku-Feld (id) eintragen: */

				bool uniquePos = true;

				for (int32_t j = 0; j < SudokuSizePerDir; j++)
				{
					int32_t id2 = column + j * SudokuSizePerDir;

					if (id2 == id)
					{
						continue;
					}

					int32_t testValue = pInOutData[id2];

					if (testValue > 0)
					{
						continue;
					}

					if (Check_If_SudokuNumber_Could_Be_Correct(pInOutData, j, column, possibleNumber) == true)
					{
						uniquePos = false;
						break;
					}
				} // end of for (int32_t j = 0; j < SudokuSizePerDir; j++)

				if (uniquePos == true)
				{
					//cout << "1: " <<  "id: " << id << " " << possibleNumber << endl;
					//getchar();
					pInOutData[id] = possibleNumber;
					return true;
				}

				/* �berpr�fen, ob possibleNumber noch in irgendeiner anderen Spalte (j)
				   der betrachteten Zeile (row) stehen k�nnte. Sofern dies nicht m�glich ist
				   (uniquePos == true), k�nnen wir possibleNumber ins entsprechende
				   Sudoku-Feld (id) eintragen: */

				uniquePos = true;

				for (int32_t j = 0; j < SudokuSizePerDir; j++)
				{
					int32_t id2 = j + row * SudokuSizePerDir;

					if (id2 == id)
					{
						continue;
					}

					int32_t testValue = pInOutData[id2];

					if (testValue > 0)
					{
						continue;
					}

					if (Check_If_SudokuNumber_Could_Be_Correct(pInOutData, row, j, possibleNumber) == true)
					{
						uniquePos = false;
						break;
					}
				} // end of for (int32_t j = 0; j < SudokuSizePerDir; j++)

				if (uniquePos == true)
				{
					//cout << "2: " << "id: " << id << " " << possibleNumber << endl;
					//getchar();
					pInOutData[id] = possibleNumber;
					return true;
				}

				/* �berpr�fen, ob possibleNumber noch an irgendeiner anderen Stelle
				   des betrachteten 3x3-Bereichs stehen k�nnte. Sofern dies nicht m�glich ist
				   (uniquePos == true), k�nnen wir possibleNumber ins entsprechende
				   Sudoku-Feld (id) eintragen: */

				uniquePos = true;

				int32_t iyMin = row - row % 3;
				int32_t iyMaxPlus1 = iyMin + 3;
				int32_t ixMin = column - column % 3;
				int32_t ixMaxPlus1 = ixMin + 3;

				for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
				{
					int32_t iiy = iy * SudokuSizePerDir;

					for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
					{
						int32_t id2 = ix + iiy;

						if (id2 == id)
						{
							continue;
						}

						int32_t testValue = pInOutData[id2];

						if (testValue > 0)
						{
							continue;
						}

						if (Check_If_SudokuNumber_Could_Be_Correct(pInOutData, iy, ix, possibleNumber) == true)
						{
							uniquePos = false;
							break;
						}
					} // end of for (int32_t ix = startColumn; ix < stopColumnPlus1; ix++)
				} // end of for (int32_t iy = startRow; iy < stopRowPlus1; iy++)

				if (uniquePos == true)
				{
					//cout << "3: " << "id: " << id << " " << possibleNumber << endl;
					//getchar();
					pInOutData[id] = possibleNumber;
					return true;
				}

				//////////////////////
			} // end of for (int32_t i = 0; i < possibleNumberCounter; i++)
		} // end of else if (possibleNumberCounter > 1)
	} // end of for (int32_t id = 0; id < SudokuSizeSq; id++)

	return false;
}


bool Check_If_SudokuNumber_Could_Be_Correct(int32_t *pInData, int32_t row, int32_t column, int32_t number)
{
	int32_t _row = row * SudokuSizePerDir;

	/* �berpr�fen, ob vorgeschlagene Ziffer (number) bereits in
	Zeile (row) vorhanden ist: */

	for (int32_t ix = 0; ix < SudokuSizePerDir; ix++)
	{
		int32_t id = ix + _row;

		if (pInData[id] == number)
		{
			return false;
		}
	}

	/* �berpr�fen, ob vorgeschlagene Ziffer (number) bereits in
	Spalte (column) vorhanden ist: */

	for (int32_t id = column; id < SudokuSizeSq; id += SudokuSizePerDir)
	{
		if (pInData[id] == number)
		{
			return false;
		}
	}

	/*for (int32_t iy = 0; iy < SudokuSizePerDir; iy++)
	{
		int32_t id = column + iy * SudokuSizePerDir;

		if (pInData[id] == number)
		{
			return false;
		}
	}*/

	/* �berpr�fen, ob vorgeschlagene Ziffer (number) bereits im
	3x3-Block (column, row) vorhanden ist: */

	
	int32_t iyMin = row - row % 3;
	int32_t iyMaxPlus1 = iyMin + 3;
	int32_t ixMin = column - column % 3;
	int32_t ixMaxPlus1 = ixMin + 3;

	for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
	{
		int32_t iiy = iy * SudokuSizePerDir;

		for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
		{
			int32_t id = ix + iiy;

			if (pInData[id] == number)
			{
				return false;
			}
		}
	}

	return true;
}

bool RecursiveSudokuSolver(int32_t *pInOutData, int32_t row, int32_t column)
{
	if (row == SudokuSizePerDirMinus1 && column == SudokuSizePerDir)
	{
		return true;
	}

	if (column == SudokuSizePerDir)
	{
		row++;
		column = 0;
	}

	int32_t id = column + row * SudokuSizePerDir;

	if (pInOutData[id] > 0)
	{
		return RecursiveSudokuSolver(pInOutData, row, column + 1);
	}

	for (int32_t number = 1; number < SudokuSizePerDirPlus1; number++)
	{
		int32_t _row = row * SudokuSizePerDir;

		if (Check_If_SudokuNumber_Could_Be_Correct(pInOutData, row, column, number))
		{
			int32_t id = column + _row;
			//int32_t id = column + row * SudokuSizePerDir;

			pInOutData[id] = number;

			if (RecursiveSudokuSolver(pInOutData, row, column + 1) == true)
			{
				return true;
			}
		}

		// falsche Zahl aus dem Sudoku l�schen:
		int32_t id = column + row * SudokuSizePerDir;
		pInOutData[id] = 0;
	}
	return false;
}


void CSudokuUpdateNode::Reset(void)
{
	GridID = 0;
	Number = 0;
}

void CSudokuUpdateNode::Reset_GridID(void)
{
	GridID = 0;
}

void CSudokuUpdateNode::Reset_Number(void)
{
	Number = 0;
}

int32_t CSudokuUpdateNode::Try_To_Find_Correct_Number(int32_t *pInData)
{
	int32_t row = GridID / SudokuSizePerDir;
	int32_t column = GridID % SudokuSizePerDir;

	int32_t proposedNumber = 0;

	for (int32_t num = Number; num < 10; num++)
	{
		if (Check_If_SudokuNumber_Could_Be_Correct(pInData, row, column, num) == true)
		{
			proposedNumber = num;
			break;
		}
	}

	return proposedNumber;
}

CSudokuUpdateNodeArray::CSudokuUpdateNodeArray()
{}

CSudokuUpdateNodeArray::~CSudokuUpdateNodeArray()
{
	delete[] pNodeArray;
	pNodeArray = nullptr;
}

void CSudokuUpdateNodeArray::Initialize(int32_t *pInData)
{
	int32_t NumOfMissingNumbers = 0;

	for (int32_t i = 0; i < SudokuSizeSq; i++)
	{
		if (pInData[i] == 0)
		{
			NumOfMissingNumbers++;
		}
	}

	cout << "NumOfMissingNumbers: " << NumOfMissingNumbers << endl;
	//getchar();

	actualSearchDepth = 0;

	delete[] pNodeArray;
	pNodeArray = nullptr;

	NumOfNodes = NumOfMissingNumbers;

	if (NumOfMissingNumbers == 0)
	{
		return;
	}

	pNodeArray = new (std::nothrow) CSudokuUpdateNode[NumOfNodes];

	int32_t *pGridIDArray = new (std::nothrow) int32_t[NumOfNodes];

	int32_t counter = 0;

	for (int32_t i = 0; i < SudokuSizeSq; i++)
	{
		if (pInData[i] == 0)
		{
			pNodeArray[counter].GridID = i;
			pGridIDArray[counter] = i;
			counter++;
		}
	}

	
	int32_t *pBranchCounterArray = new (std::nothrow) int32_t[NumOfNodes];

	for (int32_t i = 0; i < NumOfNodes; i++)
	{
		int32_t row = pNodeArray[i].GridID / SudokuSizePerDir;
		int32_t column = pNodeArray[i].GridID % SudokuSizePerDir;

		pBranchCounterArray[i] = 0;

		for (int32_t num = 1; num < 10; num++)
		{
			if (Check_If_SudokuNumber_Could_Be_Correct(pInData, row, column, num) == true)
			{
				pBranchCounterArray[i]++;
			}
		}
	}

	// Testausgabe:
	/*
	for (int32_t i = 0; i < NumOfNodes; i++)
	{
		cout << pBranchCounterArray[i] << " ";
	}

	cout << endl << endl;
	*/
	// Testausgabe ende
	

	// Umstrukturierung:

	int32_t nodeCounter = 0;

	for (int32_t number = 1; number < 10; number++)
	{
		for (int32_t i = 0; i < NumOfNodes; i++)
		{
			if (pBranchCounterArray[i] == number)
			{
				pNodeArray[nodeCounter].GridID = pGridIDArray[i];
				nodeCounter++;
			}
		}
	}

	/////

	// Testausgabe:
	/*
	for (int32_t i = 0; i < NumOfNodes; i++)
	{
		int32_t row = pNodeArray[i].GridID / SudokuSizePerDir;
		int32_t column = pNodeArray[i].GridID % SudokuSizePerDir;

		pBranchCounterArray[i] = 0;

		for (int32_t num = 1; num < 10; num++)
		{
			if (Check_If_SudokuNumber_Could_Be_Correct(pInData, row, column, num) == true)
			{
				pBranchCounterArray[i]++;
			}
		}
	}


	for (int32_t i = 0; i < NumOfNodes; i++)
	{
		cout << pBranchCounterArray[i] << " ";
	}

	cout << endl << endl;
	*/
	// Testausgabe ende

	delete[] pBranchCounterArray;
	pBranchCounterArray = nullptr;

	delete[] pGridIDArray;
	pGridIDArray = nullptr;
}

void CSudokuUpdateNodeArray::Reset_NodeData(void)
{
	actualSearchDepth = 0;

	for (int32_t i = 0; i < NumOfNodes; i++)
	{
		pNodeArray[i].Reset();
	}
}

void CSudokuUpdateNodeArray::Reset_NodeData_GridID_Only(void)
{
	actualSearchDepth = 0;

	for (int32_t i = 0; i < NumOfNodes; i++)
	{
		pNodeArray[i].Reset_GridID();
	}
}

void CSudokuUpdateNodeArray::Reset_NodeData_Number_Only(void)
{
	actualSearchDepth = 0;

	for (int32_t i = 0; i < NumOfNodes; i++)
	{
		pNodeArray[i].Reset_Number();
	}
}



int32_t CSudokuUpdateNodeArray::Update_Node(int32_t *pInOutData)
{
	if (actualSearchDepth >= NumOfNodes)
	{
		cout << "sudoku solved" << endl;
		return 2;
	}

	//cout << "actualSearchDepth: " << actualSearchDepth << endl;

	int32_t proposedNumber = pNodeArray[actualSearchDepth].Try_To_Find_Correct_Number(pInOutData);

	if (proposedNumber > 0)
	{
		//cout << "proposedNumber: " << proposedNumber << endl;

		pNodeArray[actualSearchDepth].Number = proposedNumber;
		pInOutData[pNodeArray[actualSearchDepth].GridID] = proposedNumber;
		actualSearchDepth++;
		return 1;
	}
	else
	{
		//cout << "node update failed" << endl;
		pNodeArray[actualSearchDepth].Reset_Number();
		pInOutData[pNodeArray[actualSearchDepth].GridID] = 0;

		if (actualSearchDepth > 0)
		{
			actualSearchDepth--;
		}

		return 0;
	}
}


void CSudokuUpdateNodeExt::Reset_GridID(void)
{
	GridID = 0;
}

void CSudokuUpdateNodeExt::Reset_NumberSectionArray(void)
{
	for (int32_t i = 0; i < 10; i++)
	{
		NumberSectionArray[i] = false;
	}
}

void CSudokuUpdateNodeExt::Reset(void)
{
	GridID = 0;
	Reset_NumberSectionArray();
}

int32_t CSudokuUpdateNodeExt::Get_RandomUnusedNumber(CRandomNumbersNN *pRandomNumbers)
{
	bool allNumbersUsedAlready = true;

	for (int32_t i = 1; i < 10; i++)
	{
		if (NumberSectionArray[i] == false)
		{
			allNumbersUsedAlready = false;
			break;
		}
	}

	if (allNumbersUsedAlready == true)
	{
		return 0;
	}

	do
	{
		int32_t number = pRandomNumbers->Get_IntegerNumber2(1, 9);

		if (NumberSectionArray[number] == false)
		{
			NumberSectionArray[number] = true;
			return number;
		}

	} while (true);

	return 0;
}

int32_t CSudokuUpdateNodeExt::Try_To_Find_Correct_Number(int32_t *pInData, CRandomNumbersNN *pRandomNumbers)
{
	int32_t row = GridID / SudokuSizePerDir;
	int32_t column = GridID % SudokuSizePerDir;

	int32_t proposedNumber = 0;

	do
	{
		int32_t num = Get_RandomUnusedNumber(pRandomNumbers);

		if (num == 0)
		{
			return 0;
		}

		if (Check_If_SudokuNumber_Could_Be_Correct(pInData, row, column, num) == true)
		{
			return num;
		}

	} while (true);

	return 0;
}

CSudokuUpdateNodeArrayExt::CSudokuUpdateNodeArrayExt()
{}

CSudokuUpdateNodeArrayExt::~CSudokuUpdateNodeArrayExt()
{
	delete[] pNodeArray;
	pNodeArray = nullptr;
}



void CSudokuUpdateNodeArrayExt::Initialize(int32_t *pInData)
{
	int32_t NumOfMissingNumbers = 0;

	for (int32_t i = 0; i < SudokuSizeSq; i++)
	{
		if (pInData[i] == 0)
		{
			NumOfMissingNumbers++;
		}
	}

	cout << "NumOfMissingNumbers: " << NumOfMissingNumbers << endl;
	//getchar();

	ActualSearchDepth = 0;

	delete[] pNodeArray;
	pNodeArray = nullptr;

	NumOfNodes = NumOfMissingNumbers;

	if (NumOfMissingNumbers == 0)
	{
		return;
	}

	pNodeArray = new (std::nothrow) CSudokuUpdateNodeExt[NumOfNodes];

	int32_t *pGridIDArray = new (std::nothrow) int32_t[NumOfNodes];

	int32_t counter = 0;

	for (int32_t i = 0; i < SudokuSizeSq; i++)
	{
		if (pInData[i] == 0)
		{
			pNodeArray[counter].GridID = i;
			pGridIDArray[counter] = i;
			counter++;
		}
	}

	
	int32_t *pBranchCounterArray = new (std::nothrow) int32_t[NumOfNodes];

	for (int32_t i = 0; i < NumOfNodes; i++)
	{
		int32_t row = pNodeArray[i].GridID / SudokuSizePerDir;
		int32_t column = pNodeArray[i].GridID % SudokuSizePerDir;

		pBranchCounterArray[i] = 0;

		for (int32_t num = 1; num < 10; num++)
		{
			if (Check_If_SudokuNumber_Could_Be_Correct(pInData, row, column, num) == true)
			{
				pBranchCounterArray[i]++;
			}
		}
	}

	// Testausgabe:
	/*
	for (int32_t i = 0; i < NumOfNodes; i++)
	{
		cout << pBranchCounterArray[i] << " ";
	}

	cout << endl << endl;
	*/
	// Testausgabe ende

	// Umstrukturierung:

	int32_t nodeCounter = 0;
	
	for (int32_t number = 1; number < 10; number++)
	{
		for (int32_t i = 0; i < NumOfNodes; i++)
		{
			if (pBranchCounterArray[i] == number)
			{
				pNodeArray[nodeCounter].GridID = pGridIDArray[i];
				nodeCounter++;
			}
		}
	}

	/////

	// Testausgabe:
	/*
	for (int32_t i = 0; i < NumOfNodes; i++)
	{
		int32_t row = pNodeArray[i].GridID / SudokuSizePerDir;
		int32_t column = pNodeArray[i].GridID % SudokuSizePerDir;

		pBranchCounterArray[i] = 0;

		for (int32_t num = 1; num < 10; num++)
		{
			if (Check_If_SudokuNumber_Could_Be_Correct(pInData, row, column, num) == true)
			{
				pBranchCounterArray[i]++;
			}
		}
	}

	
	for (int32_t i = 0; i < NumOfNodes; i++)
	{
		cout << pBranchCounterArray[i] << " ";
	}

	cout << endl << endl;
	*/
	// Testausgabe ende

	delete[] pBranchCounterArray;
	pBranchCounterArray = nullptr;

	delete[] pGridIDArray;
	pGridIDArray = nullptr;
}

void CSudokuUpdateNodeArrayExt::Reset_NodeData(void)
{
	ActualSearchDepth = 0;

	for (int32_t i = 0; i < NumOfNodes; i++)
	{
		pNodeArray[i].Reset();
	}
}

void CSudokuUpdateNodeArrayExt::Reset_NodeData_GridID_Only(void)
{
	ActualSearchDepth = 0;

	for (int32_t i = 0; i < NumOfNodes; i++)
	{
		pNodeArray[i].Reset_GridID();
	}
}

void CSudokuUpdateNodeArrayExt::Reset_NodeData_NumberSectionArray_Only(void)
{
	ActualSearchDepth = 0;

	for (int32_t i = 0; i < NumOfNodes; i++)
	{
		pNodeArray[i].Reset_NumberSectionArray();
	}
}

int32_t CSudokuUpdateNodeArrayExt::Update_Node(int32_t *pInOutData, CRandomNumbersNN *pRandomNumbers)
{
	if (ActualSearchDepth >= NumOfNodes)
	{
		cout << "sudoku solved" << endl;
		return 2;
	}

	//cout << "actualSearchDepth: " << ActualSearchDepth << endl;

	int32_t proposedNumber = pNodeArray[ActualSearchDepth].Try_To_Find_Correct_Number(pInOutData, pRandomNumbers);

	if (proposedNumber > 0)
	{
		//cout << "proposedNumber: " << proposedNumber << endl;

		//pNodeArray[ActualSearchDepth].Number = proposedNumber;
		pInOutData[pNodeArray[ActualSearchDepth].GridID] = proposedNumber;
		ActualSearchDepth++;
		return 1;
	}
	else
	{
		//cout << "node update failed" << endl;
		pNodeArray[ActualSearchDepth].Reset_NumberSectionArray();
		pInOutData[pNodeArray[ActualSearchDepth].GridID] = 0;

		if (ActualSearchDepth > 0)
		{
			ActualSearchDepth--;
		}

		return 0;
	}
}