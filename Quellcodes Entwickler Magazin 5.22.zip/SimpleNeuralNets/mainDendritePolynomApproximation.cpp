#include <iostream>
#include "NeuralNet_V2.h"

using namespace std;


inline void PolynomApproximationDendriticFunction_4Param(CNeuronV2 *pNeuron)
{
	pNeuron->Dendrite_InputCounter = 0;

	float input = pNeuron->NeuronInput;
	float input2 = input * input;
	float input3 = input * input * input;

	pNeuron->pDendrite_InputValueArray[0] = 1.0f;
	pNeuron->pDendrite_InputValueArray[1] = input;
	pNeuron->pDendrite_InputValueArray[2] = input2;
	pNeuron->pDendrite_InputValueArray[3] = input3;

	pNeuron->NeuronInput = 0.0f;
}

inline void PolynomApproximationOutputFunction_4Param(CNeuronV2 *pNeuron)
{
	float output = pNeuron->pDendrite_FactorArray[0] * pNeuron->pDendrite_InputValueArray[0];
	output += pNeuron->pDendrite_FactorArray[1] * pNeuron->pDendrite_InputValueArray[1];
	output += pNeuron->pDendrite_FactorArray[2] * pNeuron->pDendrite_InputValueArray[2];
	output += pNeuron->pDendrite_FactorArray[3] * pNeuron->pDendrite_InputValueArray[3];


	pNeuron->NeuronOutput = output;
}

inline void PolynomApproximationDendriticFunction_7Param(CNeuronV2 *pNeuron)
{
	pNeuron->Dendrite_InputCounter = 0;

	float input = pNeuron->NeuronInput;
	float input2 = input * input;
	float input3 = input * input * input;

	pNeuron->pDendrite_InputValueArray[0] = 1.0f;
	pNeuron->pDendrite_InputValueArray[1] = input;
	pNeuron->pDendrite_InputValueArray[2] = input2;
	pNeuron->pDendrite_InputValueArray[3] = input3;

	pNeuron->pDendrite_InputValueArray[4] = input;
	pNeuron->pDendrite_InputValueArray[5] = input2;
	pNeuron->pDendrite_InputValueArray[6] = input3;

	pNeuron->NeuronInput = 0.0f;
}

inline void PolynomApproximationOutputFunction_7Param(CNeuronV2 *pNeuron)
{
	float output = pNeuron->pDendrite_FactorArray[0] * pNeuron->pDendrite_InputValueArray[0];
	output += pNeuron->pDendrite_FactorArray[1] * pNeuron->pDendrite_InputValueArray[1];
	output += pNeuron->pDendrite_FactorArray[2] * pNeuron->pDendrite_InputValueArray[2];
	output += pNeuron->pDendrite_FactorArray[3] * pNeuron->pDendrite_InputValueArray[3];
	output += pNeuron->pDendrite_FactorArray[4] * pNeuron->pDendrite_InputValueArray[4];
	output += pNeuron->pDendrite_FactorArray[5] * pNeuron->pDendrite_InputValueArray[5];
	output += pNeuron->pDendrite_FactorArray[6] * pNeuron->pDendrite_InputValueArray[6];

	pNeuron->NeuronOutput = output;
}





inline void PolynomApproximationOutputFunction1(CNeuronV2 *pNeuron)
{
	pNeuron->Dendrite_InputCounter = 0;

	float input = pNeuron->NeuronInput;
	float input2 = input * input;
	float input3 = input * input * input;

	pNeuron->pDendrite_InputValueArray[0] = 1.0f;
	pNeuron->pDendrite_InputValueArray[1] = input;
	pNeuron->pDendrite_InputValueArray[2] = input2;
	pNeuron->pDendrite_InputValueArray[3] = input3;

	
	float output = pNeuron->pDendrite_FactorArray[0];
	output += input * pNeuron->pDendrite_FactorArray[1];
	output += input2 * pNeuron->pDendrite_FactorArray[2];
	output += input3 * pNeuron->pDendrite_FactorArray[3];


	pNeuron->NeuronOutput = output;
	pNeuron->NeuronInput = 0.0f;
}

inline void PolynomApproximationOutputFunction1_g4(CNeuronV2 *pNeuron)
{
	pNeuron->Dendrite_InputCounter = 0;

	float input = pNeuron->NeuronInput;
	float input2 = input * input;
	float input3 = input * input * input;
	float input4 = input * input * input * input;

	pNeuron->pDendrite_InputValueArray[0] = 1.0f;
	pNeuron->pDendrite_InputValueArray[1] = input;
	pNeuron->pDendrite_InputValueArray[2] = input2;
	pNeuron->pDendrite_InputValueArray[3] = input3;
	pNeuron->pDendrite_InputValueArray[4] = input4;

	float output = pNeuron->pDendrite_FactorArray[0];
	output += input * pNeuron->pDendrite_FactorArray[1];
	output += input2 * pNeuron->pDendrite_FactorArray[2];
	output += input3 * pNeuron->pDendrite_FactorArray[3];
	output += input4 * pNeuron->pDendrite_FactorArray[4];

	pNeuron->NeuronOutput = output;
	pNeuron->NeuronInput = 0.0f;
}


inline void PolynomApproximationOutputFunction2(CNeuronV2 *pNeuron)
{
	pNeuron->Dendrite_InputCounter = 0;

	float input = pNeuron->NeuronInput;
	float input2 = input * input;
	float input3 = input * input * input;

	pNeuron->pDendrite_InputValueArray[0] = 1.0f;
	pNeuron->pDendrite_InputValueArray[1] = input;
	pNeuron->pDendrite_InputValueArray[2] = input2;
	pNeuron->pDendrite_InputValueArray[3] = input3;

	pNeuron->pDendrite_InputValueArray[4] = input;
	pNeuron->pDendrite_InputValueArray[5] = input2;
	pNeuron->pDendrite_InputValueArray[6] = input3;

	float output = pNeuron->pDendrite_FactorArray[0];
	output += input * pNeuron->pDendrite_FactorArray[1];
	output += input2 * pNeuron->pDendrite_FactorArray[2];
	output += input3 * pNeuron->pDendrite_FactorArray[3];

	
	output += input * pNeuron->pDendrite_FactorArray[4];
	output += input2 * pNeuron->pDendrite_FactorArray[5];
	output += input3 * pNeuron->pDendrite_FactorArray[6];

	pNeuron->NeuronOutput = output;
	pNeuron->NeuronInput = 0.0f;
}

inline void PolynomApproximationOutputFunction3(CNeuronV2 *pNeuron)
{
	pNeuron->Dendrite_InputCounter = 0;

	float input = pNeuron->NeuronInput;
	float input2 = input * input;
	float input3 = input * input * input;

	pNeuron->pDendrite_InputValueArray[0] = 1.0f;
	pNeuron->pDendrite_InputValueArray[1] = input;
	pNeuron->pDendrite_InputValueArray[2] = input2;
	pNeuron->pDendrite_InputValueArray[3] = input3;

	pNeuron->pDendrite_InputValueArray[4] = input;
	pNeuron->pDendrite_InputValueArray[5] = input2;
	pNeuron->pDendrite_InputValueArray[6] = input3;

	pNeuron->pDendrite_InputValueArray[7] = input;
	pNeuron->pDendrite_InputValueArray[8] = input2;
	pNeuron->pDendrite_InputValueArray[9] = input3;

	float output = pNeuron->pDendrite_FactorArray[0];
	output += input * pNeuron->pDendrite_FactorArray[1];
	output += input2 * pNeuron->pDendrite_FactorArray[2];
	output += input3 * pNeuron->pDendrite_FactorArray[3];

	output += input * pNeuron->pDendrite_FactorArray[4];
	output += input2 * pNeuron->pDendrite_FactorArray[5];
	output += input3 * pNeuron->pDendrite_FactorArray[6];
	
	output += input * pNeuron->pDendrite_FactorArray[7];
	output += input2 * pNeuron->pDendrite_FactorArray[8];
	output += input3 * pNeuron->pDendrite_FactorArray[9];

	pNeuron->NeuronOutput = output;
	pNeuron->NeuronInput = 0.0f;
}


inline void DendriteNeuronLearningFunction(CNeuronV2 *pNeuron, const CNeuronV2 *pBestNeuron, CRandomNumbersNN *pRandomNumbers, float learningRate, float learningRateVariance, float errorFactor1 = 1.0f, float errorFactor2 = 1.0f)
{
	pNeuron->Adjust_Dendrite_Factors(pBestNeuron, pRandomNumbers, learningRate, learningRateVariance, errorFactor1, errorFactor2);
}

/*
int main(void)
{
	static constexpr int32_t NumInputOutputValues = 11;

	float InputData[NumInputOutputValues];
	float DesiredOutputData[NumInputOutputValues];

	InputData[0] = 0.0f;
	InputData[1] = 1.0f;
	InputData[2] = 2.0f;
	InputData[3] = 3.0f;
	InputData[4] = 4.0f;
	InputData[5] = 5.0f;
	InputData[6] = 6.0f;
	InputData[7] = 7.0f;
	InputData[8] = 8.0f;
	InputData[9] = 9.0f;
	InputData[10] = 10.0f;


	
	float c = 6.0f;
	float f = 0.5f;
	float scale = 3.0f;
	

	float tempFloat;

	for (int32_t i = 0; i < NumInputOutputValues; i++)
	{
		tempFloat = InputData[i] - c;
		DesiredOutputData[i] = min(scale*exp(-f*tempFloat*tempFloat), 1.0f);
	}

	for (int32_t i = 0; i < NumInputOutputValues; i++)
	{
		cout << "input: " << InputData[i] << " => desired output: " << DesiredOutputData[i] << endl;
	}

	getchar();
	return 0;
}
*/

/*
int main(void)
{
	static constexpr int32_t NumInputOutputValues = 11;

	float InputData[NumInputOutputValues];
	float DesiredOutputData[NumInputOutputValues];

	InputData[0] = 0.0f;
	InputData[1] = 1.0f;
	InputData[2] = 2.0f;
	InputData[3] = 3.0f;
	InputData[4] = 4.0f;
	InputData[5] = 5.0f;
	InputData[6] = 6.0f;
	InputData[7] = 7.0f;
	InputData[8] = 8.0f;
	InputData[9] = 9.0f;
	InputData[10] = 10.0f;


	float c1 = 2.5f;
	float f1 = 1.5f;

	float c2 = 7.5f;
	float f2 = 1.5f;

	float tempFloat;

	for (int32_t i = 0; i < NumInputOutputValues; i++)
	{
		tempFloat = max(InputData[i], c1) - c1;
		DesiredOutputData[i] = exp(-f1*tempFloat*tempFloat);

		tempFloat = min(InputData[i], c2) - c2;
		DesiredOutputData[i] += exp(-f2*tempFloat*tempFloat);

		DesiredOutputData[i] = 1.0f - DesiredOutputData[i];
	}

	for (int32_t i = 0; i < NumInputOutputValues; i++)
	{
		cout << "input: " << InputData[i] << " => desired output: " << DesiredOutputData[i] << endl;
	}

	getchar();
	return 0;
}
*/

/*
int main(void)
{
	static constexpr int32_t NumInputOutputValues = 11;

	float InputData[NumInputOutputValues];
	float DesiredOutputData[NumInputOutputValues];

	InputData[0] = 0.0f;
	InputData[1] = 1.0f;
	InputData[2] = 2.0f;
	InputData[3] = 3.0f;
	InputData[4] = 4.0f;
	InputData[5] = 5.0f;
	InputData[6] = 6.0f;
	InputData[7] = 7.0f;
	InputData[8] = 8.0f;
	InputData[9] = 9.0f;
	InputData[10] = 10.0f;


	float c1 = 3.5f;
	float f1 = 1.5f;

	float c2 = 5.0f;
	float f2 = 0.5f;

	float c3 = 6.5f;
	float f3 = 1.5f;

	float tempFloat;

	for (int32_t i = 0; i < NumInputOutputValues; i++)
	{
		tempFloat = InputData[i] - c1;
		DesiredOutputData[i] = exp(-f1*tempFloat*tempFloat);

		tempFloat = InputData[i] - c2;
		DesiredOutputData[i] += exp(-f2*tempFloat*tempFloat);

		tempFloat = InputData[i] - c3;
		DesiredOutputData[i] += exp(-f3*tempFloat*tempFloat);

		DesiredOutputData[i] = min(DesiredOutputData[i], 1.0f);
	}

	for (int32_t i = 0; i < NumInputOutputValues; i++)
	{
		cout << "input: " << InputData[i] << " => desired output: " << DesiredOutputData[i] << endl;
	}

	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	static constexpr int32_t NumInputOutputValues = 9;

	float InputData[NumInputOutputValues];
	float DesiredOutputData[NumInputOutputValues];

	InputData[0] = -4.0f;
	InputData[1] = -3.0f;
	InputData[2] = -2.0f;
	InputData[3] = -1.0f;
	InputData[4] = 0.0f;
	InputData[5] = 1.0f;
	InputData[6] = 2.0f;
	InputData[7] = 3.0f;
	InputData[8] = 4.0f;


	// Output = (a * Input * Input * Input + b * Input * Input + c * Input + offset)

	float a = 0.5f;
	float b = 1.65f;
	float c = -0.85f;
	float offset = 1.0f;


	for (int32_t i = 0; i < NumInputOutputValues; i++)
	{
		DesiredOutputData[i] = offset;
		DesiredOutputData[i] += a * InputData[i] * InputData[i] * InputData[i];
		DesiredOutputData[i] += b * InputData[i] * InputData[i];
		DesiredOutputData[i] += c * InputData[i];
	}

	for (int32_t i = 0; i < NumInputOutputValues; i++)
	{
		cout << "input: " << InputData[i] << " => desired output: " << DesiredOutputData[i] << endl;
	}

	cout << endl;

	CNeuronV2 Neuron;

	//Neuron.Init_Dendrite_Arrays(4);
	//Neuron.Set_ActivationFunction(PolynomApproximationOutputFunction1);

	Neuron.Init_Dendrite_Arrays(7);
	Neuron.Set_ActivationFunction(PolynomApproximationOutputFunction2);

	//Neuron.Init_Dendrite_Arrays(10);
	//Neuron.Set_ActivationFunction(PolynomApproximationOutputFunction3);

	Neuron.Randomize_Dendrite_Factors(&RandomNumbers, -0.01f, 0.01f);
	

	int32_t maxCount = 10000;
	int32_t epoch = 0;
	float errorSum;

	for (int32_t i = 0; i < maxCount; i++)
	{
		epoch++;
		errorSum = 0.0f;

		for (int32_t k = 0; k < NumInputOutputValues; k++)
		{
			Neuron.Set_NeuronInput(InputData[k]);
			Neuron.Calculate_NeuronOutput();

			errorSum += Neuron.Calculate_Error(DesiredOutputData[k], 1.0f, 0.001f);
			Neuron.Adjust_Dendrite_Factor_AfterErrorCalculations(0, 0.01f);
			Neuron.Adjust_Dendrite_Factors_AfterErrorCalculations(0.0001f, 1, Neuron.Num_Of_Dendrite_Elements - 1);

			//errorSum += Neuron.Adjust_Dendrite_Factors(DesiredOutputData[k], 0.001f, 1.0f, 0.001f);

		}

		if (errorSum < 0.001f)
			break;
	}

	// training completed

	// training statistics:



	cout << "epoch: " << epoch << endl;
	cout << "error: " << errorSum << endl << endl;

	cout << endl;

	for (int32_t i = 0; i < NumInputOutputValues; i++)
	{
		Neuron.Set_NeuronInput(InputData[i]);
		Neuron.Calculate_NeuronOutput();

		cout << "input: " << InputData[i] << " => output: " << Neuron.Get_NeuronOutput() << endl;
	}

	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	static constexpr int32_t NumInputOutputValues = 9;

	float InputData[NumInputOutputValues];
	float DesiredOutputData[NumInputOutputValues];

	InputData[0] = -4.0f;
	InputData[1] = -3.0f;
	InputData[2] = -2.0f;
	InputData[3] = -1.0f;
	InputData[4] = 0.0f;
	InputData[5] = 1.0f;
	InputData[6] = 2.0f;
	InputData[7] = 3.0f;
	InputData[8] = 4.0f;


	// Output = (a * Input * Input * Input + b * Input * Input + c * Input + offset)

	float a = 0.5f;
	float b = 1.65f;
	float c = -0.85f;
	float offset = 1.0f;


	for (int32_t i = 0; i < NumInputOutputValues; i++)
	{
		DesiredOutputData[i] = offset;
		DesiredOutputData[i] += a * InputData[i] * InputData[i] * InputData[i];
		DesiredOutputData[i] += b * InputData[i] * InputData[i];
		DesiredOutputData[i] += c * InputData[i];
	}

	for (int32_t i = 0; i < NumInputOutputValues; i++)
	{
		cout << "input: " << InputData[i] << " => desired output: " << DesiredOutputData[i] << endl;
	}

	cout << endl;

	CNeuronV2 Neuron;

	
	Neuron.Init_Dendrite_Arrays(7);
	Neuron.Set_DendriticFunction(PolynomApproximationDendriticFunction_7Param);
	Neuron.Set_ActivationFunction(PolynomApproximationOutputFunction_7Param);

	
	Neuron.Randomize_Dendrite_Factors(&RandomNumbers, -0.01f, 0.01f);


	int32_t maxCount = 10000;
	int32_t epoch = 0;
	float errorSum;

	for (int32_t i = 0; i < maxCount; i++)
	{
		epoch++;
		errorSum = 0.0f;

		for (int32_t k = 0; k < NumInputOutputValues; k++)
		{
			Neuron.Set_NeuronInput(InputData[k]);
			Neuron.Calculate_NeuronOutput_Ext();

			errorSum += Neuron.Calculate_Error(DesiredOutputData[k], 1.0f, 0.001f);
			Neuron.Adjust_Dendrite_Factor_AfterErrorCalculations(0, 0.01f);
			Neuron.Adjust_Dendrite_Factors_AfterErrorCalculations(0.0001f, 1, Neuron.Num_Of_Dendrite_Elements - 1);

			//errorSum += Neuron.Adjust_Dendrite_Factors(DesiredOutputData[k], 0.001f, 1.0f, 0.001f);

		}

		if (errorSum < 0.001f)
			break;
	}

	// training completed

	// training statistics:



	cout << "epoch: " << epoch << endl;
	cout << "error: " << errorSum << endl << endl;

	cout << endl;

	for (int32_t i = 0; i < NumInputOutputValues; i++)
	{
		Neuron.Set_NeuronInput(InputData[i]);
		Neuron.Calculate_NeuronOutput_Ext();

		cout << "input: " << InputData[i] << " => output: " << Neuron.Get_NeuronOutput() << endl;
	}

	getchar();
	return 0;
}
*/


/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	static constexpr int32_t NumInputOutputValues = 9;

	float InputData[NumInputOutputValues];
	float DesiredOutputData[NumInputOutputValues];

	InputData[0] = -4.0f;
	InputData[1] = -3.0f;
	InputData[2] = -2.0f;
	InputData[3] = -1.0f;
	InputData[4] = 0.0f;
	InputData[5] = 1.0f;
	InputData[6] = 2.0f;
	InputData[7] = 3.0f;
	InputData[8] = 4.0f;


	// Output = (a * Input * Input * Input + b * Input * Input + c * Input + offset)

	float a = 0.5f;
	float b = 1.65f;
	float c = -0.85f;
	float offset = 1.0f;

	for (int32_t i = 0; i < NumInputOutputValues; i++)
	{
		DesiredOutputData[i] = offset;
		DesiredOutputData[i] += a * InputData[i] * InputData[i] * InputData[i];
		DesiredOutputData[i] += b * InputData[i] * InputData[i];
		DesiredOutputData[i] += c * InputData[i];
	}

	for (int32_t i = 0; i < NumInputOutputValues; i++)
	{
		cout << "input: " << InputData[i] << " => desired output: " << DesiredOutputData[i] << endl;
	}

	cout << endl;

	int32_t TrainingPopulationSize = 50;
	int32_t NumTrainingGenerationsMax = 200000;
	
	CNeuronV2 *pNeuronArray = new (std::nothrow) CNeuronV2[TrainingPopulationSize];
	float *pFitnessScoreArray = new (std::nothrow) float[TrainingPopulationSize];

	CDendriteNeuronPopulation NeuronPopulation;

	NeuronPopulation.Initialize(TrainingPopulationSize);

	for (int32_t i = 0; i < TrainingPopulationSize; i++)
	{
		NeuronPopulation.Set_Neuron(&pNeuronArray[i], i);
		pFitnessScoreArray[i] = 0.0f;
	}

	NeuronPopulation.Set_ActivationFunction(PolynomApproximationOutputFunction1);
	//NeuronPopulation.Set_ActivationFunction(PolynomApproximationOutputFunction2);
	//NeuronPopulation.Set_ActivationFunction(PolynomApproximationOutputFunction3);

	NeuronPopulation.Init_Or_Reinitialize_Dendrite_Arrays(4);
	//NeuronPopulation.Init_Or_Reinitialize_Dendrite_Arrays(7);
	//NeuronPopulation.Init_Or_Reinitialize_Dendrite_Arrays(10);
	//NeuronPopulation.Randomize_Dendrite_Values(0.0f, 0.0f, -2.0f, 2.0f);
	NeuronPopulation.Randomize_Dendrite_Factors(-2.0f, 2.0f);
	

	float output;
	float desiredOutput;
	float errorSum;

	for (int32_t j = 0; j < NumTrainingGenerationsMax; j++)
	{
		NeuronPopulation.Reset_MinErrorSum_ActualGeneration();

		for (int32_t i = 0; i < TrainingPopulationSize; i++)
		{
			pFitnessScoreArray[i] = 0.0f;
			errorSum = 0.0f;

			//NeuronPopulation.Learning(DendriteNeuronLearningFunction, i, 0.1f, 0.01f, 1.0f, 1.0f);
			
			for (int32_t k = 0; k < NumInputOutputValues; k++)
			{
				pNeuronArray[i].Set_NeuronInput(InputData[k]);
				pNeuronArray[i].Calculate_NeuronOutput();

				// Variante 1 - reine Neuroevolution:
				//errorSum += pNeuronArray[i].Calculate_VarianceSq(DesiredOutputData[k]);

				// Variante 2 - Neuroevolution + Backpropagation-Learning:
				errorSum += pNeuronArray[i].Calculate_Error(DesiredOutputData[k], 1.0f, 0.001f);
				pNeuronArray[i].Adjust_Dendrite_Factor_AfterErrorCalculations(0, 0.01f);
				pNeuronArray[i].Adjust_Dendrite_Factors_AfterErrorCalculations(0.0001f, 1, pNeuronArray[i].Num_Of_Dendrite_Elements - 1);
			}

			pFitnessScoreArray[i] = 1.0f / (errorSum + 0.01f);

			NeuronPopulation.Update_MinErrorSum_ActualGeneration(errorSum);
		}

		NeuronPopulation.Update_Population(pFitnessScoreArray);

		if (NeuronPopulation.MinErrorSum_ActualGeneration < 0.01f)
		{
			cout << "actual generation: " << j << endl;
			cout << "training completed" << endl << endl;
			break;
		}

		
		NeuronPopulation.Update_BaseEvolution_Dendrite_Factors(-0.1f, 0.1f, 0.75f);
		NeuronPopulation.Update_Evolution_BestBrainOnly_Dendrite_Factors(-0.1f, 0.1f, 0.75f);
		NeuronPopulation.Update_Evolution_SecondBestBrainOnly_Dendrite_Factors(-0.1f, 0.1f, 0.75f);
		NeuronPopulation.Update_Evolution_Combine_BestTwoBrains();
		NeuronPopulation.Update_Evolution_Combine_TwoBrains();

		//NeuronPopulation.Round_Dendrite_CentroidValues(0.001f);
	}

	CNeuronV2 BestNeuron;

	NeuronPopulation.Get_Best_Evolved_Neuron(&BestNeuron);

	cout << endl;

	for (int32_t i = 0; i < NumInputOutputValues; i++)
	{
		BestNeuron.Set_NeuronInput(InputData[i]);
		BestNeuron.Calculate_NeuronOutput();

		cout << "input: " << InputData[i] << " => output: " << BestNeuron.Get_NeuronOutput() << endl;
	}

	getchar();

	delete[] pFitnessScoreArray;
	pFitnessScoreArray = nullptr;

	delete[] pNeuronArray;
	pNeuronArray = nullptr;

	return 0;
}
*/


/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	static constexpr int32_t NumInputOutputValues = 9;

	float InputData[NumInputOutputValues];
	float DesiredOutputData[NumInputOutputValues];

	InputData[0] = -4.0f;
	InputData[1] = -3.0f;
	InputData[2] = -2.0f;
	InputData[3] = -1.0f;
	InputData[4] = 0.0f;
	InputData[5] = 1.0f;
	InputData[6] = 2.0f;
	InputData[7] = 3.0f;
	InputData[8] = 4.0f;


	// Output = (a * Input * Input * Input + b * Input * Input + c * Input + offset)

	float a = 0.5f;
	float b = 1.65f;
	float c = -0.85f;
	float offset = 1.0f;

	for (int32_t i = 0; i < NumInputOutputValues; i++)
	{
		DesiredOutputData[i] = offset;
		DesiredOutputData[i] += a * InputData[i] * InputData[i] * InputData[i];
		DesiredOutputData[i] += b * InputData[i] * InputData[i];
		DesiredOutputData[i] += c * InputData[i];
	}

	for (int32_t i = 0; i < NumInputOutputValues; i++)
	{
		cout << "input: " << InputData[i] << " => desired output: " << DesiredOutputData[i] << endl;
	}

	cout << endl;

	int32_t TrainingPopulationSize = 50;
	int32_t NumTrainingGenerationsMax = 200000;

	CNeuronV2 *pNeuronArray = new (std::nothrow) CNeuronV2[TrainingPopulationSize];
	float *pFitnessScoreArray = new (std::nothrow) float[TrainingPopulationSize];

	CDendriteNeuronPopulation NeuronPopulation;

	NeuronPopulation.Initialize(TrainingPopulationSize);

	for (int32_t i = 0; i < TrainingPopulationSize; i++)
	{
		NeuronPopulation.Set_Neuron(&pNeuronArray[i], i);
		pFitnessScoreArray[i] = 0.0f;
	}

	NeuronPopulation.Set_DendriticFunction(PolynomApproximationDendriticFunction_4Param);
	NeuronPopulation.Set_ActivationFunction(PolynomApproximationOutputFunction_4Param);
	

	NeuronPopulation.Init_Or_Reinitialize_Dendrite_Arrays(4);

	//NeuronPopulation.Randomize_Dendrite_Values(0.0f, 0.0f, -2.0f, 2.0f);
	NeuronPopulation.Randomize_Dendrite_Factors(-2.0f, 2.0f);


	float output;
	float desiredOutput;
	float errorSum;

	for (int32_t j = 0; j < NumTrainingGenerationsMax; j++)
	{
		NeuronPopulation.Reset_MinErrorSum_ActualGeneration();

		for (int32_t i = 0; i < TrainingPopulationSize; i++)
		{
			pFitnessScoreArray[i] = 0.0f;
			errorSum = 0.0f;

			//NeuronPopulation.Learning(DendriteNeuronLearningFunction, i, 0.1f, 0.01f, 1.0f, 1.0f);

			for (int32_t k = 0; k < NumInputOutputValues; k++)
			{
				pNeuronArray[i].Set_NeuronInput(InputData[k]);
				pNeuronArray[i].Calculate_NeuronOutput_Ext();

				// Variante 1 - reine Neuroevolution:
				//errorSum += pNeuronArray[i].Calculate_VarianceSq(DesiredOutputData[k]);

				// Variante 2 - Neuroevolution + Backpropagation-Learning:
				errorSum += pNeuronArray[i].Calculate_Error(DesiredOutputData[k], 1.0f, 0.001f);
				pNeuronArray[i].Adjust_Dendrite_Factor_AfterErrorCalculations(0, 0.01f);
				pNeuronArray[i].Adjust_Dendrite_Factors_AfterErrorCalculations(0.0001f, 1, pNeuronArray[i].Num_Of_Dendrite_Elements - 1);
			}

			pFitnessScoreArray[i] = 1.0f / (errorSum + 0.01f);

			NeuronPopulation.Update_MinErrorSum_ActualGeneration(errorSum);
		}

		NeuronPopulation.Update_Population(pFitnessScoreArray);

		if (NeuronPopulation.MinErrorSum_ActualGeneration < 0.01f)
		{
			cout << "actual generation: " << j << endl;
			cout << "training completed" << endl << endl;
			break;
		}


		NeuronPopulation.Update_BaseEvolution_Dendrite_Factors(-0.1f, 0.1f, 0.75f);
		NeuronPopulation.Update_Evolution_BestBrainOnly_Dendrite_Factors(-0.1f, 0.1f, 0.75f);
		NeuronPopulation.Update_Evolution_SecondBestBrainOnly_Dendrite_Factors(-0.1f, 0.1f, 0.75f);
		NeuronPopulation.Update_Evolution_Combine_BestTwoBrains();
		NeuronPopulation.Update_Evolution_Combine_TwoBrains();

		//NeuronPopulation.Round_Dendrite_CentroidValues(0.001f);
	}

	CNeuronV2 BestNeuron;

	NeuronPopulation.Get_Best_Evolved_Neuron(&BestNeuron);

	cout << endl;

	for (int32_t i = 0; i < NumInputOutputValues; i++)
	{
		BestNeuron.Set_NeuronInput(InputData[i]);
		BestNeuron.Calculate_NeuronOutput_Ext();

		cout << "input: " << InputData[i] << " => output: " << BestNeuron.Get_NeuronOutput() << endl;
	}

	getchar();

	delete[] pFitnessScoreArray;
	pFitnessScoreArray = nullptr;

	delete[] pNeuronArray;
	pNeuronArray = nullptr;

	return 0;
}
*/


/*int main(void)
{
	CCombinationPairs CombinationPairs;

	CombinationPairs.Set_NumOfElements(2);
	getchar();
	cout << endl;

	CombinationPairs.Set_NumOfElements(3);
	getchar();
	cout << endl;

	CombinationPairs.Set_NumOfElements(4);
	getchar();
	cout << endl;

	CombinationPairs.Set_NumOfElements(5);
	getchar();
	cout << endl;

	getchar();
	return 0;
}*/

/*
// kontinuierliches Lernen:
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	static constexpr int32_t NumInputOutputValues = 11;

	float InputData[NumInputOutputValues];
	float DesiredOutputData[NumInputOutputValues];

	InputData[0] = -5.0f;
	InputData[1] = -4.0f;
	InputData[2] = -3.0f;
	InputData[3] = -2.0f;
	InputData[4] = 1.0f;
	InputData[5] = 0.0f;
	InputData[6] = 1.0f;
	InputData[7] = 2.0f;
	InputData[8] = 3.0f;
	InputData[9] = 4.0f;
	InputData[10] = 5.0f;

	CCombinationPairs CombinationPairs;
	CombinationPairs.Set_NumOfElements(NumInputOutputValues);

	// Output = (a * Input * Input * Input * Input + b * Input * Input * Input + c * Input * Input + d * Input + offset)

	float a = -0.1f;
	float b = 0.5f;
	float c = 1.65f;
	float d = -0.85f;
	float offset = 1.0f;

	for (int32_t i = 0; i < NumInputOutputValues; i++)
	{
		DesiredOutputData[i] = offset;
		DesiredOutputData[i] += a * InputData[i] * InputData[i] * InputData[i] * InputData[i];
		DesiredOutputData[i] += b * InputData[i] * InputData[i] * InputData[i];
		DesiredOutputData[i] += c * InputData[i] * InputData[i];
		DesiredOutputData[i] += d * InputData[i];
	}

	for (int32_t i = 0; i < NumInputOutputValues; i++)
	{
		cout << "input: " << InputData[i] << " => desired output: " << DesiredOutputData[i] << endl;
	}

	cout << endl;

	//int32_t TrainingPopulationSize = 50;
	int32_t TrainingPopulationSize = 100;

	//int32_t NumTrainingGenerationsMax = 400000;
	//int32_t NumTrainingGenerationsMax = 20000;
	int32_t NumTrainingGenerationsMax = 200000;

	CNeuronV2 *pNeuronArray = new (std::nothrow) CNeuronV2[TrainingPopulationSize];
	float *pFitnessScoreArray = new (std::nothrow) float[TrainingPopulationSize];

	CDendriteNeuronPopulation NeuronPopulation;

	NeuronPopulation.Initialize(TrainingPopulationSize);

	for (int32_t i = 0; i < TrainingPopulationSize; i++)
	{
		NeuronPopulation.Set_Neuron(&pNeuronArray[i], i);
		pFitnessScoreArray[i] = 0.0f;
	}

	NeuronPopulation.Set_ActivationFunction(PolynomApproximationOutputFunction1_g4);


	NeuronPopulation.Init_Or_Reinitialize_Dendrite_Arrays(5);
	//NeuronPopulation.Randomize_Dendrite_Values(0.0f, 0.0f, -2.0f, 2.0f);
	NeuronPopulation.Randomize_Dendrite_Factors(-2.0f, 2.0f);


	float output;
	float desiredOutput;
	float errorSum;

	int32_t idOfCombination;
	int32_t dataElement1;
	int32_t dataElement2;

	for (int32_t j = 0; j < NumTrainingGenerationsMax; j++)
	{
		for (int32_t i = 0; i < TrainingPopulationSize; i++)
		{
			errorSum = 0.0f;

			idOfCombination = RandomNumbers.Get_IntegerNumber(0, CombinationPairs.NumOfCombinations);

			dataElement1 = CombinationPairs.pElement1_List[idOfCombination];
			dataElement2 = CombinationPairs.pElement2_List[idOfCombination];

			pNeuronArray[i].Set_NeuronInput(InputData[dataElement1]);
			pNeuronArray[i].Calculate_NeuronOutput();

			errorSum += pNeuronArray[i].Calculate_VarianceSq(DesiredOutputData[dataElement1]);

			pNeuronArray[i].Set_NeuronInput(InputData[dataElement2]);
			pNeuronArray[i].Calculate_NeuronOutput();

			errorSum += pNeuronArray[i].Calculate_VarianceSq(DesiredOutputData[dataElement2]);

			pFitnessScoreArray[i] = 1.0f / (errorSum + 0.01f);
		}

		NeuronPopulation.Update_Population_Ext(pFitnessScoreArray);

		NeuronPopulation.Update_BaseEvolution_Dendrite_Factors(-0.1f, 0.1f, 0.75f);
		NeuronPopulation.Update_Evolution_BestBrainOnly_Dendrite_Factors(-0.1f, 0.1f, 0.75f);
		NeuronPopulation.Update_Evolution_SecondBestBrainOnly_Dendrite_Factors(-0.1f, 0.1f, 0.75f);
		NeuronPopulation.Update_Evolution_Combine_BestTwoBrains();
		NeuronPopulation.Update_Evolution_Combine_TwoBrains();

		//NeuronPopulation.Round_Dendrite_Factors(0.001f);
	}

	CNeuronV2 BestNeuron;

	NeuronPopulation.Get_Best_Evolved_Neuron(&BestNeuron);

	cout << endl;

	for (int32_t i = 0; i < NumInputOutputValues; i++)
	{
		BestNeuron.Set_NeuronInput(InputData[i]);
		BestNeuron.Calculate_NeuronOutput();

		cout << "input: " << InputData[i] << " => output: " << BestNeuron.Get_NeuronOutput() << endl;
	}

	getchar();

	delete[] pFitnessScoreArray;
	pFitnessScoreArray = nullptr;

	delete[] pNeuronArray;
	pNeuronArray = nullptr;

	return 0;
}
*/

/*
// kontinuierliches Lernen:
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	static constexpr int32_t NumInputOutputValues = 9;

	float InputData[NumInputOutputValues];
	float DesiredOutputData[NumInputOutputValues];

	InputData[0] = -4.0f;
	InputData[1] = -3.0f;
	InputData[2] = -2.0f;
	InputData[3] = -1.0f;
	InputData[4] = 0.0f;
	InputData[5] = 1.0f;
	InputData[6] = 2.0f;
	InputData[7] = 3.0f;
	InputData[8] = 4.0f;


	// Output = (a * Input * Input * Input + b * Input * Input + c * Input + offset)

	float a = 0.5f;
	float b = 1.65f;
	float c = -0.85f;
	float offset = 1.0f;


	for (int32_t i = 0; i < NumInputOutputValues; i++)
	{
		DesiredOutputData[i] = offset;
		DesiredOutputData[i] += a * InputData[i] * InputData[i] * InputData[i];
		DesiredOutputData[i] += b * InputData[i] * InputData[i];
		DesiredOutputData[i] += c * InputData[i];
	}

	for (int32_t i = 0; i < NumInputOutputValues; i++)
	{
		cout << "input: " << InputData[i] << " => desired output: " << DesiredOutputData[i] << endl;
	}

	cout << endl;

	CNeuronV2 Neuron;

	//Neuron.Init_Dendrite_Arrays(4);
	//Neuron.Set_ActivationFunction(PolynomApproximationOutputFunction1);

	Neuron.Init_Dendrite_Arrays(7);
	Neuron.Set_ActivationFunction(PolynomApproximationOutputFunction2);

	//Neuron.Init_Dendrite_Arrays(10);
	//Neuron.Set_ActivationFunction(PolynomApproximationOutputFunction3);

	Neuron.Randomize_Dendrite_Factors(&RandomNumbers, -0.01f, 0.01f);


	int32_t maxCount = 10000;
	int32_t epoch = 0;
	float errorSum;
	float fcounter;

	for (int32_t i = 0; i < maxCount; i++)
	{
		epoch++;
		errorSum = 0.0f;

		fcounter = 0.0f;

		for (int32_t k = 0; k < NumInputOutputValues; k++)
		{
			if (fcounter >= 2.0f)
				break;
			if (RandomNumbers.Get_IntegerNumber2(1, 10) > 3)
				continue;

			fcounter += 1.0f;

			Neuron.Set_NeuronInput(InputData[k]);
			Neuron.Calculate_NeuronOutput();

			errorSum += Neuron.Calculate_Error(DesiredOutputData[k], 1.0f, 0.001f);
			Neuron.Adjust_Dendrite_Factor_AfterErrorCalculations(0, 0.01f);
			Neuron.Adjust_Dendrite_Factors_AfterErrorCalculations(0.0001f, 1, Neuron.Num_Of_Dendrite_Elements - 1);

			//errorSum += Neuron.Adjust_Dendrite_Factors(DesiredOutputData[k], 0.001f, 1.0f, 0.001f);

		}
	}

	// training completed

	// training statistics:



	cout << "epoch: " << epoch << endl;
	cout << "error: " << errorSum << endl << endl;

	cout << endl;

	for (int32_t i = 0; i < NumInputOutputValues; i++)
	{
		Neuron.Set_NeuronInput(InputData[i]);
		Neuron.Calculate_NeuronOutput();

		cout << "input: " << InputData[i] << " => output: " << Neuron.Get_NeuronOutput() << endl;
	}

	getchar();
	return 0;
}
*/



