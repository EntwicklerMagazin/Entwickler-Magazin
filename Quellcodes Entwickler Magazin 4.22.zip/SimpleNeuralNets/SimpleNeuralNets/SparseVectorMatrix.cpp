#include "SparseVectorMatrix.h"

using namespace std;

//-----------------------------------------------------------------------------
// CSparseVector
//-----------------------------------------------------------------------------

CSparseVector::CSparseVector()
{}

CSparseVector::~CSparseVector()
{
	delete[] pValueArray;
	pValueArray = nullptr;

	delete[] pNonZeroElementIndexArray;
	pNonZeroElementIndexArray = nullptr;
}

void CSparseVector::Initialize(int32_t size)
{
	delete[] pValueArray;
	pValueArray = nullptr;

	delete[] pNonZeroElementIndexArray;
	pNonZeroElementIndexArray = nullptr;

	Size = size;

	NumOfNonZeroElements = 0;

	pValueArray = new (std::nothrow) float[Size];
	pNonZeroElementIndexArray = new (std::nothrow) int32_t[Size];
}

void CSparseVector::Get_Vector(float *pOutVectorElementArray)
{
	for (int32_t i = 1; i < Size; i++)
	{
		pOutVectorElementArray[i] = pValueArray[i];
	}
}

void CSparseVector::Set_Vector(float *pInVectorElementArray)
{
	for (int32_t i = 0; i < Size; i++)
	{
		pValueArray[i] = pInVectorElementArray[i];
	}

	NumOfNonZeroElements = 0;

	for (int32_t i = 0; i < Size; i++)
	{
		if (pValueArray[i] != 0.0f)
		{
			pNonZeroElementIndexArray[NumOfNonZeroElements] = i;
			NumOfNonZeroElements++;
		}
	}
}

//-----------------------------------------------------------------------------
// CSparseVector2
//-----------------------------------------------------------------------------

CSparseVector2::CSparseVector2()
{}

CSparseVector2::~CSparseVector2()
{
	delete[] pValueArray;
	pValueArray = nullptr;
}

void CSparseVector2::Initialize(int32_t size)
{
	delete[] pValueArray;
	pValueArray = nullptr;

	Size = size;
	SizePlus1 = size + 1;
	SizePlus2 = size + 2;

	pValueArray = new (std::nothrow) float[SizePlus2];

	NonZeroElementList.Initialize(size);
}

void CSparseVector2::Set_Vector(float *pInVectorElementArray)
{
	NonZeroElementList.Deactivate_All_Elements();

	int32_t counter = 1;

	for (int32_t i = 0; i < Size; i++)
	{
		pValueArray[counter] = pInVectorElementArray[i];
		counter++;
	}

	for (int32_t i = 1; i < SizePlus1; i++)
	{
		if (pValueArray[i] != 0.0f)
		{
			NonZeroElementList.Reactivate_Element(i);
		}
	}
}

void CSparseVector2::Get_Vector(float *pOutVectorElementArray)
{
	int32_t counter = 1;

	for (int32_t i = 0; i < Size; i++)
	{
		pOutVectorElementArray[i] = pValueArray[counter];
		counter++;
	}
}

int32_t CSparseVector2::Get_IDs_Of_NonZero_Elements(int32_t *pOutElementIDArray)
{
	return NonZeroElementList.Get_CorrectedIDs_Of_Active_Elements(pOutElementIDArray);
}

//-----------------------------------------------------------------------------
// CSparseBinaryVector
//-----------------------------------------------------------------------------

CSparseBinaryVector::CSparseBinaryVector()
{}

CSparseBinaryVector::~CSparseBinaryVector()
{
	delete[] pNonZeroElementIndexArray;
	pNonZeroElementIndexArray = nullptr;
}

void CSparseBinaryVector::Initialize(int32_t size)
{
	delete[] pNonZeroElementIndexArray;
	pNonZeroElementIndexArray = nullptr;

	Size = size;
	
	NumOfNonZeroElements = 0;

	pNonZeroElementIndexArray = new (std::nothrow) int32_t[Size];
}


void CSparseBinaryVector::Get_Vector(bool *pOutVectorElementArray)
{
	for (int32_t i = 0; i < Size; i++)
	{
		pOutVectorElementArray[i] = false;
	}

	for (int32_t i = 0; i < NumOfNonZeroElements; i++)
	{
		pOutVectorElementArray[pNonZeroElementIndexArray[i]] = true;
	}
}



void CSparseBinaryVector::Set_Vector(bool *pInVectorElementArray)
{
	NumOfNonZeroElements = 0;

	for (int32_t i = 0; i < Size; i++)
	{
		if (pInVectorElementArray[i] == true)
		{
			pNonZeroElementIndexArray[NumOfNonZeroElements] = i;
			NumOfNonZeroElements++;
		}
	}
}

//-----------------------------------------------------------------------------
// CSparseBinaryVector2
//-----------------------------------------------------------------------------

CSparseBinaryVector2::CSparseBinaryVector2()
{}

CSparseBinaryVector2::~CSparseBinaryVector2()
{}

void CSparseBinaryVector2::Initialize(int32_t size)
{
	Size = size;
	SizePlus1 = size + 1;
	SizePlus2 = size + 2;

	NonZeroElementList.Initialize(size);
}

void CSparseBinaryVector2::Set_Vector(bool *pInVectorElementArray)
{
	NonZeroElementList.Deactivate_All_Elements();

	for (int32_t i = 0; i < Size; i++)
	{
		if (pInVectorElementArray[i] == true)
		{
			NonZeroElementList.Reactivate_Element(i + 1);
		}
	}
}

void CSparseBinaryVector2::Get_Vector(bool *pOutVectorElementArray)
{
	for (int32_t i = 0; i < Size; i++)
	{
		pOutVectorElementArray[i] = false;
	}

	int32_t numOfActiveElements = NonZeroElementList.NumOfActiveElements;

	if (numOfActiveElements == 0)
	{
		return;
	}

	int32_t id = NonZeroElementList.Get_First_Active_ElementID();
	pOutVectorElementArray[id - 1] = true;

	if (numOfActiveElements == 1)
	{
		return;
	}

	do
	{
		id = NonZeroElementList.Get_Next_Active_ElementID(id);

		if (id == 0)
		{
			break;
		}

		pOutVectorElementArray[id - 1] = true;

	} while (true);
}

int32_t CSparseBinaryVector2::Get_IDs_Of_NonZero_Elements(int32_t *pOutElementIDArray)
{
	return NonZeroElementList.Get_CorrectedIDs_Of_Active_Elements(pOutElementIDArray);
}

//-----------------------------------------------------------------------------
// 
//-----------------------------------------------------------------------------





bool Check_ForCompleteIncongruence(CSparseBinaryVector *pVector1, CSparseBinaryVector *pVector2)
{
	int32_t numOfNonZeroElements_V1 = pVector1->NumOfNonZeroElements;
	int32_t numOfNonZeroElements_V2 = pVector2->NumOfNonZeroElements;

	for (int32_t i_V1 = 0; i_V1 < numOfNonZeroElements_V1; i_V1++)
	{
		for (int32_t i_V2 = 0; i_V2 < numOfNonZeroElements_V2; i_V2++)
		{
			if (pVector1->pNonZeroElementIndexArray[i_V1] == pVector2->pNonZeroElementIndexArray[i_V2])
			{
				return false;
			}
		}
	}

	return true;
}

bool Combine_TwoVectors(CSparseBinaryVector *pOutVector, CSparseBinaryVector *pInVector1, CSparseBinaryVector *pInVector2, bool completeIncongruenceCheck)
{
	if (completeIncongruenceCheck == true)
	{
		if (Check_ForCompleteIncongruence(pInVector1, pInVector2) == false)
		{
			return false;
		}
	}

	int32_t numOfNonZeroElements_SumVector = pInVector1->NumOfNonZeroElements + pInVector2->NumOfNonZeroElements;

	pOutVector->NumOfNonZeroElements = numOfNonZeroElements_SumVector;
	

	int32_t numOfNonZeroElements_V1 = pInVector1->NumOfNonZeroElements;
	int32_t numOfNonZeroElements_V2 = pInVector2->NumOfNonZeroElements;

	int32_t counter = 0;

	for (int32_t i = 0; i < numOfNonZeroElements_V1; i++)
	{
		pOutVector->pNonZeroElementIndexArray[counter] = pInVector1->pNonZeroElementIndexArray[i];
		counter++;
	}

	for (int32_t i = 0; i < numOfNonZeroElements_V2; i++)
	{
		pOutVector->pNonZeroElementIndexArray[counter] = pInVector2->pNonZeroElementIndexArray[i];
		counter++;
	}

	return true;
}


CSparseMatrix::CSparseMatrix()
{

}

CSparseMatrix::~CSparseMatrix()
{
	delete[] pRowVectorArray; 
	pRowVectorArray = nullptr;
}

void CSparseMatrix::Initialize(int32_t numOfRows, int32_t numOfColumns)
{
	NumOfRows = numOfRows;
	NumOfColumns = numOfColumns;

	delete[] pRowVectorArray;
	pRowVectorArray = nullptr;

	pRowVectorArray = new (std::nothrow) CSparseVector[numOfRows];

	for (int32_t i = 0; i < numOfRows; i++)
	{
		pRowVectorArray[i].Initialize(numOfColumns);
	}
}

void CSparseMatrix::Set_RowVector(float *pInVectorElementArray, int32_t rowID)
{
	pRowVectorArray[rowID].Set_Vector(pInVectorElementArray);
}

void CSparseMatrix::Get_RowVector(float *pOutVectorElementArray, int32_t rowID)
{
	pRowVectorArray[rowID].Get_Vector(pOutVectorElementArray);
}




CSparseBinaryMatrix::CSparseBinaryMatrix()
{
	
}

CSparseBinaryMatrix::~CSparseBinaryMatrix()
{
	delete[] pRowVectorArray;
	pRowVectorArray = nullptr;
}

void CSparseBinaryMatrix::Initialize(int32_t numOfRows, int32_t numOfColumns)
{
	NumOfRows = numOfRows;
	NumOfColumns = numOfColumns;

	delete[] pRowVectorArray;
	pRowVectorArray = nullptr;

	pRowVectorArray = new (std::nothrow) CSparseBinaryVector[numOfRows];

	for (int32_t i = 0; i < numOfRows; i++)
	{
		pRowVectorArray[i].Initialize(numOfColumns);
	}
}


void CSparseBinaryMatrix::Set_RowVector(bool *pInVectorElementArray, int32_t rowID)
{
	pRowVectorArray[rowID].Set_Vector(pInVectorElementArray);
}

void CSparseBinaryMatrix::Get_RowVector(bool *pOutVectorElementArray, int32_t rowID)
{
	pRowVectorArray[rowID].Get_Vector(pOutVectorElementArray);
}






CPossibleExactCoverSolutionsPerConstraint::CPossibleExactCoverSolutionsPerConstraint()
{}

CPossibleExactCoverSolutionsPerConstraint::~CPossibleExactCoverSolutionsPerConstraint()
{
	delete[] pSolutionIDArray;
	pSolutionIDArray = nullptr;
}

void CPossibleExactCoverSolutionsPerConstraint::Clone(CPossibleExactCoverSolutionsPerConstraint *pOriginalObject)
{
	delete[] pSolutionIDArray;
	pSolutionIDArray = nullptr;

	NumOfSolutionsMax = pOriginalObject->NumOfSolutionsMax;
	NumOfSolutionsMinus1 = NumOfSolutionsMax - 1;
	ActualNumOfSolutions = pOriginalObject->ActualNumOfSolutions;

	pSolutionIDArray = new (std::nothrow) int32_t[NumOfSolutionsMax];

	for (int32_t i = 0; i < NumOfSolutionsMax; i++)
	{
		pSolutionIDArray[i] = pOriginalObject->pSolutionIDArray[i];
	}
}

void CPossibleExactCoverSolutionsPerConstraint::Initialize_SolutionIDArray(void)
{
	delete[] pSolutionIDArray;
	pSolutionIDArray = nullptr;

	pSolutionIDArray = new (std::nothrow) int32_t[NumOfSolutionsMax];

	NumOfSolutionsMinus1 = NumOfSolutionsMax - 1;

	ActualNumOfSolutions = 0;
}

void CPossibleExactCoverSolutionsPerConstraint::Initialize_SolutionIDArray(int32_t numOfSolutionsMax)
{
	delete[] pSolutionIDArray;
	pSolutionIDArray = nullptr;

	pSolutionIDArray = new (std::nothrow) int32_t[numOfSolutionsMax];

	NumOfSolutionsMax = numOfSolutionsMax;
	NumOfSolutionsMinus1 = numOfSolutionsMax - 1;
	ActualNumOfSolutions = 0;
}

void CPossibleExactCoverSolutionsPerConstraint::Add_SolutionID(int32_t id)
{
	pSolutionIDArray[ActualNumOfSolutions] = id;
	ActualNumOfSolutions++;
}

int32_t CPossibleExactCoverSolutionsPerConstraint::Get_Another_PossibleSolutionID(void)
{
	if (ActualNumOfSolutions == 0)
	{
		return -1;
	}

	ActualNumOfSolutions--;
	return pSolutionIDArray[ActualNumOfSolutions];
}

void CPossibleExactCoverSolutionsPerConstraint::Permute_SolutionIDs(CRandomNumbersNN *pRandomNumbers)
{
	if (NumOfSolutionsMax == 1)
	{
		return;
	}

	int32_t randomElement = pRandomNumbers->Get_IntegerNumber2(1, NumOfSolutionsMinus1);

	int32_t tempID = pSolutionIDArray[0];
	pSolutionIDArray[0] = pSolutionIDArray[randomElement];
	pSolutionIDArray[randomElement] = tempID;
}





void CPossibleExactCoverSolutionsPerConstraint::Delete_PreviousResults(void)
{
	ActualNumOfSolutions = NumOfSolutionsMax;
}







CIterativeExactCoverSolver::CIterativeExactCoverSolver()
{
}

CIterativeExactCoverSolver::~CIterativeExactCoverSolver()
{
	delete[] pConstraintAccessSequenceArray;
	pConstraintAccessSequenceArray = nullptr;

	delete[] pSolutionsPerConstraintArray;
	pSolutionsPerConstraintArray = nullptr;

	delete[] pIDListOfSolutionRowVectors;
	pIDListOfSolutionRowVectors = nullptr;

	delete[] pCoverVector;
	pCoverVector = nullptr;

	delete[] pSolutionIDUsageArray;
	pSolutionIDUsageArray = nullptr;
}

void CIterativeExactCoverSolver::Initialize(int32_t numOfRows_ProblemMatrix, int32_t numOfColumns_ProblemMatrix)
{
	delete[] pConstraintAccessSequenceArray;
	pConstraintAccessSequenceArray = nullptr;

	delete[] pSolutionsPerConstraintArray;
	pSolutionsPerConstraintArray = nullptr;

	delete[] pIDListOfSolutionRowVectors;
	pIDListOfSolutionRowVectors = nullptr;

	delete[] pCoverVector;
	pCoverVector = nullptr;

	delete[] pSolutionIDUsageArray;
	pSolutionIDUsageArray = nullptr;

	NumOfRows_ProblemMatrix = numOfRows_ProblemMatrix;
	NumOfColumns_ProblemMatrix = numOfColumns_ProblemMatrix;
	NumOfColumnsMinus1_ProblemMatrix = numOfColumns_ProblemMatrix - 1;
	
	pIDListOfSolutionRowVectors = new (std::nothrow) int32_t[numOfRows_ProblemMatrix];

	ActualNumberOfSolutionRowVectors = 0;

	pSolutionsPerConstraintArray = new (std::nothrow) CPossibleExactCoverSolutionsPerConstraint[NumOfColumns_ProblemMatrix];
	pConstraintAccessSequenceArray = new (std::nothrow) int32_t[NumOfColumns_ProblemMatrix];

	for (int32_t i = 0; i < NumOfColumns_ProblemMatrix; i++)
	{
		pConstraintAccessSequenceArray[i] = i;
	}

	ProblemMatrix.Initialize(numOfRows_ProblemMatrix, numOfColumns_ProblemMatrix);

	pCoverVector = new (std::nothrow) int32_t[NumOfColumns_ProblemMatrix];

	pSolutionIDUsageArray = new (std::nothrow) bool[NumOfRows_ProblemMatrix];

	for (int32_t i = 0; i < NumOfRows_ProblemMatrix; i++)
	{
		pSolutionIDUsageArray[i] = false;
	}
}

int32_t CIterativeExactCoverSolver::Add_SelectedRowVector_To_CoverVector_If_Possible(CSparseBinaryVector *pRowVector)
{
	int32_t numOfNonZeroElements = pRowVector->NumOfNonZeroElements;
	int32_t *pNonZeroElementIndexArray = pRowVector->pNonZeroElementIndexArray;
	
	int32_t success = 1;

	int32_t counter = 0;

	for (int32_t i = 0; i < numOfNonZeroElements; i++)
	{
		counter++;

		int32_t elementID = pNonZeroElementIndexArray[i];
		pCoverVector[elementID]++;
		CoverVector_SumOfColumnValues++;

		if (pCoverVector[elementID] > 1)
		{
			success = -1;
			break;
		}
	}

	// Addition r�ckg�ngig machen:
	if (success == -1)
	{
		for (int32_t i = 0; i < counter; i++)
		{
			int32_t elementID = pNonZeroElementIndexArray[i];
			pCoverVector[elementID]--;
			CoverVector_SumOfColumnValues--;
		}
	}

	return success;
}



int32_t CIterativeExactCoverSolver::Check_For_PossibleSolution(void)
{
	for (int32_t i = 0; i < NumOfColumns_ProblemMatrix; i++)
	{
		pCoverVector[i] = 0;
	}

	CSparseBinaryVector *pRowVectorArray = ProblemMatrix.pRowVectorArray;

	int32_t sumOfColumnValues = 0;

	for (int32_t i = 0; i < ActualNumberOfSolutionRowVectors; i++)
	{
		int32_t id = pIDListOfSolutionRowVectors[i];

		int32_t numOfNonZeroElements = pRowVectorArray[id].NumOfNonZeroElements;
		int32_t *pNonZeroElementIndexArray = pRowVectorArray[id].pNonZeroElementIndexArray;

		for (int32_t j = 0; j < numOfNonZeroElements; j++)
		{
			int32_t elementID = pNonZeroElementIndexArray[j];
			pCoverVector[elementID]++;

			if (pCoverVector[elementID] > 1)
			{
				return -1;
			}

			sumOfColumnValues++;
		}
	}

	if (sumOfColumnValues == NumOfColumns_ProblemMatrix)
	{
		return 1;
	}

	return 0;
}

int32_t CIterativeExactCoverSolver::Get_Solution_If_Possible(int32_t *pOutIDArrayOfSolutionRowVectors)
{
	if (SolutionFound == false)
	{
		return 0;
	}

	for (int32_t i = 0; i < ActualNumberOfSolutionRowVectors; i++)
	{
		int32_t id = pIDListOfSolutionRowVectors[i];
		pOutIDArrayOfSolutionRowVectors[i] = id;
	}

	return ActualNumberOfSolutionRowVectors;
}

int32_t CIterativeExactCoverSolver::Get_Solution(int32_t *pOutIDArrayOfSolutionRowVectors)
{
	for (int32_t i = 0; i < ActualNumberOfSolutionRowVectors; i++)
	{
		int32_t id = pIDListOfSolutionRowVectors[i];
		pOutIDArrayOfSolutionRowVectors[i] = id;
	}

	return ActualNumberOfSolutionRowVectors;
}

void CIterativeExactCoverSolver::Permute_SolutionIDs_For_ExactCoverSearchRestart(CRandomNumbersNN *pRandomNumbers)
{
	for (int32_t i = 0; i < NumOfColumns_ProblemMatrix; i++)
	{
		pSolutionsPerConstraintArray[i].Permute_SolutionIDs(pRandomNumbers);
	}
}

void CIterativeExactCoverSolver::Prepare_For_ExactCoverSearchRestart(void)
{
	for (int32_t i = 0; i < NumOfColumns_ProblemMatrix; i++)
	{
		pSolutionsPerConstraintArray[i].Delete_PreviousResults();
	}

	for (int32_t i = 0; i < NumOfRows_ProblemMatrix; i++)
	{
		pSolutionIDUsageArray[i] = false;
	}

	ActualNumberOfSolutionRowVectors = 0;

	for (int32_t i = 0; i < NumOfColumns_ProblemMatrix; i++)
	{
		pCoverVector[i] = 0;
	}

	CoverVector_SumOfColumnValues = 0;
}



bool CIterativeExactCoverSolver::Prepare_Calculations(void)
{
	SolutionFound = false;

	ActualNumberOfSolutionRowVectors = 0;

	for (int32_t i = 0; i < NumOfColumns_ProblemMatrix; i++)
	{
		pCoverVector[i] = 0;
	}

	CoverVector_SumOfColumnValues = 0;

	for (int32_t i = 0; i < NumOfColumns_ProblemMatrix; i++)
	{
		pSolutionsPerConstraintArray[i].NumOfSolutionsMax = 0;
	}

	for (int32_t i = 0; i < NumOfRows_ProblemMatrix; i++)
	{
		CSparseBinaryVector *pSelectedRowVector = &ProblemMatrix.pRowVectorArray[i];

		int32_t numOfNonZeroElements = pSelectedRowVector->NumOfNonZeroElements;

		for (int32_t j = 0; j < numOfNonZeroElements; j++)
		{
			pSolutionsPerConstraintArray[pSelectedRowVector->pNonZeroElementIndexArray[j]].NumOfSolutionsMax++;
		}
	}

	for (int32_t i = 0; i < NumOfColumns_ProblemMatrix; i++)
	{
		pSolutionsPerConstraintArray[i].Initialize_SolutionIDArray();
	}

	for (int32_t i = 0; i < NumOfRows_ProblemMatrix; i++)
	{
		CSparseBinaryVector *pSelectedRowVector = &ProblemMatrix.pRowVectorArray[i];

		int32_t numOfNonZeroElements = pSelectedRowVector->NumOfNonZeroElements;

		for (int32_t j = 0; j < numOfNonZeroElements; j++)
		{
			pSolutionsPerConstraintArray[pSelectedRowVector->pNonZeroElementIndexArray[j]].Add_SolutionID(i);
		}
	}

	for (int32_t i = 0; i < NumOfColumns_ProblemMatrix; i++)
	{
		if (pSolutionsPerConstraintArray[i].NumOfSolutionsMax == 0)
		{
			return false; // no exact cover possible!
		}
	}

	for (int32_t i = 0; i < NumOfRows_ProblemMatrix; i++)
	{
		pSolutionIDUsageArray[i] = false;
	}

	return true;
}

bool CIterativeExactCoverSolver::Prepare_Calculations2(void)
{
	SolutionFound = false;

	ActualNumberOfSolutionRowVectors = 0;

	for (int32_t i = 0; i < NumOfColumns_ProblemMatrix; i++)
	{
		pCoverVector[i] = 0;
	}

	CoverVector_SumOfColumnValues = 0;

	for (int32_t i = 0; i < NumOfColumns_ProblemMatrix; i++)
	{
		pSolutionsPerConstraintArray[i].NumOfSolutionsMax = 0;
	}

	for (int32_t i = 0; i < NumOfRows_ProblemMatrix; i++)
	{
		CSparseBinaryVector *pSelectedRowVector = &ProblemMatrix.pRowVectorArray[i];

		int32_t numOfNonZeroElements = pSelectedRowVector->NumOfNonZeroElements;

		for (int32_t j = 0; j < numOfNonZeroElements; j++)
		{
			pSolutionsPerConstraintArray[pSelectedRowVector->pNonZeroElementIndexArray[j]].NumOfSolutionsMax++;
		}
	}

	for (int32_t i = 0; i < NumOfColumns_ProblemMatrix; i++)
	{
		pSolutionsPerConstraintArray[i].Initialize_SolutionIDArray();
	}

	for (int32_t i = 0; i < NumOfRows_ProblemMatrix; i++)
	{
		CSparseBinaryVector *pSelectedRowVector = &ProblemMatrix.pRowVectorArray[i];

		int32_t numOfNonZeroElements = pSelectedRowVector->NumOfNonZeroElements;

		for (int32_t j = 0; j < numOfNonZeroElements; j++)
		{
			pSolutionsPerConstraintArray[pSelectedRowVector->pNonZeroElementIndexArray[j]].Add_SolutionID(i);
		}
	}

	COrderPreservingSingleLinkedList LinkedList;
	LinkedList.Initialize(NumOfColumns_ProblemMatrix);

	for (int32_t i = 0; i < NumOfColumns_ProblemMatrix; i++)
	{
		int32_t minNumOfSolutions = NumOfRows_ProblemMatrix;

		int32_t id = LinkedList.Get_First_Active_ElementID();

		if (id > 0)
		{
			int32_t minNumOfSolutions = NumOfRows_ProblemMatrix;
			int32_t belongingConstraintID = 0;

			do
			{
				int32_t numOfSolutions = pSolutionsPerConstraintArray[id - 1].NumOfSolutionsMax;

				if (numOfSolutions < minNumOfSolutions)
				{
					minNumOfSolutions = numOfSolutions;
					belongingConstraintID = id;
				}

				id = LinkedList.Get_Next_Active_ElementID(id);

				if (id == 0)
				{
					break;
				}

			} while (true);

			pConstraintAccessSequenceArray[i] = belongingConstraintID - 1;
			
			LinkedList.Deactivate_Element(belongingConstraintID);
		}
	} // end of for (int32_t i = 0; i < NumOfColumns_ProblemMatrix; i++)

	/*for (int32_t i = 0; i < NumOfColumns_ProblemMatrix; i++)
	{
		cout << pConstraintAccessSequenceArray[i] << " ";
	}

	cout << endl;*/
	
	for (int32_t i = 0; i < NumOfColumns_ProblemMatrix; i++)
	{
		if (pSolutionsPerConstraintArray[i].NumOfSolutionsMax == 0)
		{
			return false; // no exact cover possible!
		}
	}

	for (int32_t i = 0; i < NumOfRows_ProblemMatrix; i++)
	{
		pSolutionIDUsageArray[i] = false;
	}

	return true;
}



bool CIterativeExactCoverSolver::Search_Solution(int32_t numOfIterationStepsMax, int32_t *pOutNumOfNecessaryIterationSteps)
{
	ActualNumberOfSolutionRowVectors = 0;
	
	int32_t ActualVisitedConstraintID = 0;

	for (int32_t i = 0; i < numOfIterationStepsMax; i++)
	{
		int32_t idOfPossibleSolution = pSolutionsPerConstraintArray[ActualVisitedConstraintID].Get_Another_PossibleSolutionID();

		if (idOfPossibleSolution == -1)
		{
			if (ActualNumberOfSolutionRowVectors > 0)
			{
				ActualNumberOfSolutionRowVectors--;

				int32_t lastSolutionID = pIDListOfSolutionRowVectors[ActualNumberOfSolutionRowVectors];
				
				pSolutionIDUsageArray[lastSolutionID] = false;

				pIDListOfSolutionRowVectors[ActualNumberOfSolutionRowVectors] = 0;

				pSolutionsPerConstraintArray[ActualVisitedConstraintID].Delete_PreviousResults();

				if (ActualVisitedConstraintID > 0)
				{
					ActualVisitedConstraintID--;
				}

				continue;
			}

		} // end of if (idOfPossibleSolution == -1)
		else if (idOfPossibleSolution > -1)
		{
			if (pSolutionIDUsageArray[idOfPossibleSolution] == false)
			{
				int32_t result = 0;

				if (ActualNumberOfSolutionRowVectors < NumOfRows_ProblemMatrix)
				{
					pSolutionIDUsageArray[idOfPossibleSolution] = true;
					pIDListOfSolutionRowVectors[ActualNumberOfSolutionRowVectors] = idOfPossibleSolution;
					ActualNumberOfSolutionRowVectors++;

					result = Add_SelectedRowVector_To_CoverVector_If_Possible(&ProblemMatrix.pRowVectorArray[idOfPossibleSolution]);
				}
				
				if (result == 1)
				{
					if (CoverVector_SumOfColumnValues != NumOfColumns_ProblemMatrix)
					{
						result = 0;
					}
				}

				if (result == 1)
				{
					SolutionFound = true;

					if (pOutNumOfNecessaryIterationSteps != nullptr)
					{
						*pOutNumOfNecessaryIterationSteps = i + 1;
					}

					/*cout << "num iterations: " << i << endl;

					for (int32_t i = 0; i < ActualNumberOfSolutionRowVectors; i++)
					{
						cout << pIDListOfSolutionRowVectors[i] << " ";
					}

					cout << endl;
					getchar();*/
					return true;
				}

				if (result == -1)
				{
					if (ActualNumberOfSolutionRowVectors > 0)
					{
						ActualNumberOfSolutionRowVectors--;

						int32_t lastSolutionID = pIDListOfSolutionRowVectors[ActualNumberOfSolutionRowVectors];

						pSolutionIDUsageArray[lastSolutionID] = false;

						pIDListOfSolutionRowVectors[ActualNumberOfSolutionRowVectors] = 0;

						continue;
					}
				}
			} // end of if (pSolutionIDUsageArray[idOfPossibleSolution] == false)

			if (ActualVisitedConstraintID < NumOfColumnsMinus1_ProblemMatrix)
			{
				ActualVisitedConstraintID++;
			}

			continue;
		} // end of else if (idOfPossibleSolution > -1)
	} // end of for (int32_t i = 0; i < numOfCalculationStepsMax; i++)

	return false;
}

bool CIterativeExactCoverSolver::Search_Solution2(int32_t numOfIterationStepsMax, int32_t *pOutNumOfNecessaryIterationSteps)
{
	ActualNumberOfSolutionRowVectors = 0;

	int32_t ActualVisitedConstraintID = 0;

	for (int32_t i = 0; i < numOfIterationStepsMax; i++)
	{
		int32_t idOfPossibleSolution = pSolutionsPerConstraintArray[pConstraintAccessSequenceArray[ActualVisitedConstraintID]].Get_Another_PossibleSolutionID();

		if (idOfPossibleSolution == -1)
		{
			if (ActualNumberOfSolutionRowVectors > 0)
			{
				ActualNumberOfSolutionRowVectors--;

				int32_t lastSolutionID = pIDListOfSolutionRowVectors[ActualNumberOfSolutionRowVectors];

				pSolutionIDUsageArray[lastSolutionID] = false;
				
				pIDListOfSolutionRowVectors[ActualNumberOfSolutionRowVectors] = 0;

				pSolutionsPerConstraintArray[pConstraintAccessSequenceArray[ActualVisitedConstraintID]].Delete_PreviousResults();

				if (ActualVisitedConstraintID > 0)
				{
					ActualVisitedConstraintID--;
				}

				continue;
			}

		} // end of if (idOfPossibleSolution == -1)
		else if (idOfPossibleSolution > -1)
		{
			if (pSolutionIDUsageArray[idOfPossibleSolution] == false)
			{
				int32_t result = 0;

				if (ActualNumberOfSolutionRowVectors < NumOfRows_ProblemMatrix)
				{
					pSolutionIDUsageArray[idOfPossibleSolution] = true;
					pIDListOfSolutionRowVectors[ActualNumberOfSolutionRowVectors] = idOfPossibleSolution;
					ActualNumberOfSolutionRowVectors++;

					result = Add_SelectedRowVector_To_CoverVector_If_Possible(&ProblemMatrix.pRowVectorArray[idOfPossibleSolution]);
				}
				
				if (result == 1)
				{
					if (CoverVector_SumOfColumnValues != NumOfColumns_ProblemMatrix)
					{
						result = 0;
					}
				}

				if (result == 1)
				{
					SolutionFound = true;

					if (pOutNumOfNecessaryIterationSteps != nullptr)
					{
						*pOutNumOfNecessaryIterationSteps = i + 1;
					}

					/*cout << "num iterations: " << i << endl;

					for (int32_t i = 0; i < ActualNumberOfSolutionRowVectors; i++)
					{
					cout << pIDListOfSolutionRowVectors[i] << " ";
					}

					cout << endl;
					getchar();*/

					return true;
				}

				if (result == -1)
				{
					if (ActualNumberOfSolutionRowVectors > 0)
					{
						ActualNumberOfSolutionRowVectors--;

						int32_t lastSolutionID = pIDListOfSolutionRowVectors[ActualNumberOfSolutionRowVectors];

						pSolutionIDUsageArray[lastSolutionID] = false;

						pIDListOfSolutionRowVectors[ActualNumberOfSolutionRowVectors] = 0;

						continue;
					}
				}
			} // end of if (pSolutionIDUsageArray[idOfPossibleSolution] == false)

			if (ActualVisitedConstraintID < NumOfColumnsMinus1_ProblemMatrix)
			{
				ActualVisitedConstraintID++;
			}
			

			continue;
		} // end of else if (idOfPossibleSolution > -1)
	} // end of for (int32_t i = 0; i < numOfCalculationStepsMax; i++)

	return false;
}




	

	



