#include <iostream>
#include "BattleShip.h"
#include "LogFile.h"
#include "ConsoleHelperFunctions.h"

using namespace std;
using namespace HelperStuff;

#define KEYDOWN(vk_code) ((GetAsyncKeyState(vk_code) & 0x8000) ? 1 : 0)
#define KEYUP(vk_code)   ((GetAsyncKeyState(vk_code) & 0x8000) ? 0 : 1)


/*
used local receptive field
0 -1  0
1  0  1
0 -1  0
*/

// wenn DamagedElement-Tile, dann InputValue == 1, ansonsten InputValue == -100
void SimpleSearchAndDestroyRemainingShipElements(CNeuronV2 *pNeuron)
{
	float output1 = 0.0f;
	float output2 = 0.0f;

	int32_t numInputValues = pNeuron->Dendrite_InputCounter;
	//int32_t numInputValues = pNeuron->Num_Of_Dendrite_Elements;

	float factor;

	for (int32_t i = 0; i < numInputValues; i++)
	{
		factor = pNeuron->pDendrite_FactorArray[i];

		if (factor > 0.0f)
		{
			output1 += factor * pNeuron->pDendrite_InputValueArray[i];
		}
		else if (factor < 0.0f)
		{
			output2 -= factor * pNeuron->pDendrite_InputValueArray[i];
		}
	}

	// Treffer:
	if (output1 > 0.0f || output2 > 0.0f)
		pNeuron->NeuronOutput = 1.0f;
	// kein Treffer:
	else
		pNeuron->NeuronOutput = 0.0f;
}

/*
used local receptive field
0  0 -2  0  0
0  0 -1  0  0
9  7  0  1  2
0  0 -7  0  0
0  0 -9  0  0
*/

// wenn DamagedElement-Tile, dann InputValue == 1, ansonsten InputValue == 0
void SearchRemainingIntactShipElementsOld(CNeuronV2 *pNeuron)
{
	float output1 = 0.0f;
	float output2 = 0.0f;

	int32_t numInputValues = pNeuron->Dendrite_InputCounter;
	//int32_t numInputValues = pNeuron->Num_Of_Dendrite_Elements;

	float factor;

	for (int32_t i = 0; i < numInputValues; i++)
	{
		factor = pNeuron->pDendrite_FactorArray[i];

		if (factor > 0.0f)
		{
			output1 += factor * pNeuron->pDendrite_InputValueArray[i];
		}
		else if (factor < 0.0f)
		{
			output2 -= factor * pNeuron->pDendrite_InputValueArray[i];
		}
	}


	if (output1 == 3.0f || output1 == 16.0f || output1 == 8.0f || output1 == 19.0f)
	{
		pNeuron->NeuronOutput = 2.0f;
		return;
	}
	if (output2 == 3.0f || output2 == 16.0f || output2 == 8.0f || output2 == 19.0f)
	{
		pNeuron->NeuronOutput = 2.0f;
		return;
	}
	if (output1 == 1.0f || output1 == 7.0f || output2 == 1.0f || output2 == 7.0f)
	{
		pNeuron->NeuronOutput = 1.0f;
		return;
	}

	pNeuron->NeuronOutput = 0.0f;
}


/*
used local receptive field
0    0  -2  0  0
0    0  -1  0  0
29  17   0  1  2
0    0 -17  0  0
0    0 -29  0  0
*/

// wenn DamagedElement-Tile, dann InputValue == 1, ansonsten InputValue == 0
void SearchRemainingIntactShipElements(CNeuronV2 *pNeuron)
{
	float sum1 = 0.0f;
	float sum2 = 0.0f;

	int32_t numInputValues = pNeuron->Dendrite_InputCounter;
	//int32_t numInputValues = pNeuron->Num_Of_Dendrite_Elements;

	float factor;

	for (int32_t i = 0; i < numInputValues; i++)
	{
		factor = pNeuron->pDendrite_FactorArray[i];

		if (factor > 0.0f)
		{
			sum1 += factor * pNeuron->pDendrite_InputValueArray[i];
		}
		else if (factor < 0.0f)
		{
			sum2 -= factor * pNeuron->pDendrite_InputValueArray[i];
		}
	}

	if (sum1 == 49.0f || sum1 == 18.0f || sum1 == 46.0f || sum1 == 3.0f || sum1 == 48.0f || sum1 == 32.0f || sum1 == 20.0f || sum1 == 47.0f)
	{
		pNeuron->NeuronOutput = 2.0f;
		return;
	}
	if (sum2 == 49.0f || sum2 == 18.0f || sum2 == 46.0f || sum2 == 3.0f || sum2 == 48.0f || sum2 == 32.0f || sum2 == 20.0f || sum2 == 47.0f)
	{
		pNeuron->NeuronOutput = 2.0f;
		return;
	}

	if (sum1 == 1.0f || sum1 == 30.0f || sum1 == 17.0f || sum1 == 19.0f)
	{
		pNeuron->NeuronOutput = 1.0f;
		return;
	}
	if (sum2 == 1.0f || sum2 == 30.0f || sum2 == 17.0f || sum2 == 19.0f)
	{
		pNeuron->NeuronOutput = 1.0f;
		return;
	}

	


	/*if (sum1 == 49.0f) // H | H | A | H | H  
	{
		pNeuron->NeuronOutput = 2.0f;
		return;
	}
	if (sum1 == 18.0f) // W | H | A | H | W  
	{
		pNeuron->NeuronOutput = 2.0f;
		return;
	}
	if (sum1 == 46.0f) // H | H | A | W | W  
	{
		pNeuron->NeuronOutput = 2.0f;
		return;
	}
	if (sum1 == 3.0f) // W | W | A | H | H  
	{
		pNeuron->NeuronOutput = 2.0f;
		return;
	}
	if (sum1 == 48.0f) // H | H | A | W | H  
	{
		pNeuron->NeuronOutput = 2.0f;
		return;
	}
	if (sum1 == 32.0f) // H | W | A | H | H  
	{
		pNeuron->NeuronOutput = 2.0f;
		return;
	}

	if (sum1 == 20.0f) // W | H | A | H | H  
	{
		pNeuron->NeuronOutput = 2.0f;
		return;
	}

	if (sum1 == 47.0f) // H | H | A | H | W  
	{
		pNeuron->NeuronOutput = 2.0f;
		return;
	}*/

	/*if (sum1 == 1.0f) // W | W | A | H | W  
	{
		pNeuron->NeuronOutput = 1.0f;
		return;
	}

	if (sum1 == 30.0f) // H | W | A | H | W  
	{
		pNeuron->NeuronOutput = 1.0f;
		return;
	}


	if (sum1 == 17.0f) // W | H | A | W | W  
	{
		pNeuron->NeuronOutput = 1.0f;
		return;
	}
	if (output1 == 19.0f) // W | H | A | W | H  
	{
		pNeuron->NeuronOutput = 1.0f;
		return;
	}*/


	






	

	pNeuron->NeuronOutput = 0.0f;
}





/*
used local receptive field:
1 1 1
1 0 1
1 1 1
*/
// wenn DestroyedElement-Tile, dann InputValue == 1, ansonsten InputValue == 0
void DestroyedEntityNeighborhoodDetection(CNeuronV2 *pNeuron)
{
	float sum = 0.0f;

	int32_t numInputValues = pNeuron->Dendrite_InputCounter;
	//int32_t numInputValues = pNeuron->Num_Of_Dendrite_Elements;

	for (int32_t i = 0; i < numInputValues; i++)
	{
		sum += pNeuron->pDendrite_FactorArray[i] * pNeuron->pDendrite_InputValueArray[i];
	}

	if (sum > 0.0f)
		pNeuron->NeuronOutput = 1.0f;
	else
		pNeuron->NeuronOutput = 0.0f;
}

/*
used local receptive field:
0 1 0
1 0 1
0 1 0
*/
// Wenn Wasser-Treffer, dann InputValue == 1 wenn Wasser, dann InputValue == 0
void UnnecessaryShotDetection(CNeuronV2 *pNeuron)
{
	float sum = 0.0f;

	int32_t numInputValues = pNeuron->Dendrite_InputCounter;
	//int32_t numInputValues = pNeuron->Num_Of_Dendrite_Elements;

	for (int32_t i = 0; i < numInputValues; i++)
	{
		sum += pNeuron->pDendrite_FactorArray[i] * pNeuron->pDendrite_InputValueArray[i];
	}

	if (sum > 3.0f)
		pNeuron->NeuronOutput = 1.0f;
	else
		pNeuron->NeuronOutput = 0.0f;
}




void PlacementStrategyEvaluation(CNeuronV2 *pNeuron)
{
	float input, dendriticCentroidValue, dendriticFactor;
	float output = 0.0f;
	

	int32_t numInputValues = pNeuron->Num_Of_Dendrite_Elements;

	float maxCentroidValue = 0.000001f;

	for (int32_t i = 0; i < numInputValues; i++)
		maxCentroidValue = max(maxCentroidValue, pNeuron->pDendrite_CentroidValueArray[i]);

	float invMaxCentroidValue = 1.0f / maxCentroidValue;

	float maxHalfCentroidValue = 0.5f * maxCentroidValue;
	float �nvMaxHalfCentroidValue = 1.0f / maxHalfCentroidValue;

	float WaterShotCounter = 0.0f;

	for (int32_t i = 0; i < numInputValues; i++)
	{
		input = pNeuron->pDendrite_InputValueArray[i];
		dendriticCentroidValue = pNeuron->pDendrite_CentroidValueArray[i];
		dendriticFactor = pNeuron->pDendrite_FactorArray[i];

		if (input > 0.0f) // Treffer
		{
			/* Ein Treffer d�rfte im Rahmen der hier betrachteten Strategie eigentlich
			nicht m�glich sein: */
			if (dendriticCentroidValue == 0.0f)
			{
				pNeuron->NeuronOutput = -100000000.0f;
				//Add_To_Log(0, "dendriticCentroidValue == 0.0f");
				return;
			}
		
			/* Ein Treffer, der gem�� der hier betrachteten Strategie durchaus
			zu erwarten war, spricht f�r die tats�chliche Verwendung der
			besagten Strategie: */
			output += (1.0f - exp(-dendriticFactor * dendriticCentroidValue)) * invMaxCentroidValue * dendriticCentroidValue;
			//output += dendriticFactor * invMaxCentroidValue * dendriticCentroidValue;
			
		}
		else if (input < 0.0f) // kein Treffer
		{
			/* Ein Fehlschuss, der gem�� der hier betrachteten Strategie durchaus
			zu erwarten war, spricht f�r die tats�chliche Verwendung der
			besagten Strategie: */
			if (dendriticCentroidValue < maxHalfCentroidValue)
				output += (1.0f + WaterShotCounter) * exp(-dendriticFactor * dendriticCentroidValue) * �nvMaxHalfCentroidValue * (maxHalfCentroidValue - dendriticCentroidValue);
				//output += 0.1f*(1.0f + WaterShotCounter) * �nvMaxHalfCentroidValue * (maxHalfCentroidValue - dendriticCentroidValue);

			/* Ein Fehlschuss, der gem�� der hier betrachteten Strategie eher nicht zu
			erwarten war, spricht gegen die tats�chliche Verwendung der
			besagten Strategie: */
			else if (dendriticCentroidValue >= maxHalfCentroidValue)
				output -= (1.0f + WaterShotCounter) * exp(-dendriticFactor * dendriticCentroidValue) *�nvMaxHalfCentroidValue * (dendriticCentroidValue - maxHalfCentroidValue);
				//output -= 0.1f*(1.0f + WaterShotCounter) * �nvMaxHalfCentroidValue * (dendriticCentroidValue - maxHalfCentroidValue);

			/* Jeder Fehlschuss, der gem�� der hier betrachteten Strategie hundertprozentig
			zu erwarten war, spricht f�r die tats�chliche Verwendung der besagten
			Strategie: */
			if (dendriticCentroidValue == 0.0f)
				output += (2.0f + WaterShotCounter);
				
				

			WaterShotCounter += 0.1f;
		}
	}

	pNeuron->NeuronOutput = output;
}

void L2ShipPlacementEvaluation(CNeuronV2 *pNeuron)
{
	float output = 0.0f;
	float input;

	// local receptive field size: 3
	int32_t ixCenter = 1;
	int32_t iyCenter = 1;
	int32_t iiyCenter = iyCenter * 3;
	int32_t idCenter = ixCenter + iiyCenter;

	int32_t SumRight = 0;

	for(int32_t i = 1; i < 2; i++)
	{
		input = pNeuron->pDendrite_InputValueArray[ixCenter + i + iiyCenter];

		if (input == 0.0f)
			SumRight++;
		else
			break;
	}

	if (SumRight == 1)
	{
		output += 1.0f;
	}

	int32_t SumLeft = 0;

	for (int32_t i = 1; i < 2; i++)
	{
		input = pNeuron->pDendrite_InputValueArray[ixCenter - i + iiyCenter];

		if (input == 0.0f)
			SumLeft++;
		else
			break;
	}

	if (SumLeft == 1)
	{
		output += 1.0f;
	}

	int32_t SumDown = 0;

	for (int32_t i = 1; i < 2; i++)
	{
		input = pNeuron->pDendrite_InputValueArray[ixCenter + (iyCenter + i) * 3];

		if (input == 0.0f)
			SumDown++;
		else
			break;
	}

	if (SumDown == 1)
	{
		output += 1.0f;
	}


	int32_t SumUp = 0;

	for (int32_t i = 1; i < 2; i++)
	{
		input = pNeuron->pDendrite_InputValueArray[ixCenter + (iyCenter - i) * 3];

		if (input == 0.0f)
			SumUp++;
		else
			break;
	}

	if (SumUp == 1)
	{
		output += 1.0f;
	}

	pNeuron->NeuronOutput = output;
}

void L3ShipPlacementEvaluation(CNeuronV2 *pNeuron)
{
	float outputHorizontal = 0.0f;
	float outputVertical = 0.0f;
	float input;

	// local receptive field size: 5
	int32_t ixCenter = 2;
	int32_t iyCenter = 2;
	int32_t iiyCenter = iyCenter * 5;
	int32_t idCenter = ixCenter + iiyCenter;

	int32_t SumRight = 0;

	for (int32_t i = 1; i < 3; i++)
	{
		input = pNeuron->pDendrite_InputValueArray[ixCenter + i + iiyCenter];
		
		if (input == 0.0f)
			SumRight++;
		else
			break;
	}

	if (SumRight == 2)
	{
		outputHorizontal += 1.0f;
	}

	int32_t SumLeft = 0;

	for (int32_t i = 1; i < 3; i++)
	{
		input = pNeuron->pDendrite_InputValueArray[ixCenter - i + iiyCenter];
		
		if (input == 0.0f)
			SumLeft++;
		else
			break;
	}

	if (SumLeft == 2)
	{
		outputHorizontal += 1.0f;
	}

	if (SumRight + SumLeft > 1)
	{
		outputHorizontal += 1.0f;
	}

	int32_t SumDown = 0;

	for (int32_t i = 1; i < 3; i++)
	{
		input = pNeuron->pDendrite_InputValueArray[ixCenter + (iyCenter + i) * 5];
		
		if (input == 0.0f)
			SumDown++;
		else
			break;
	}

	if (SumDown == 2)
	{
		outputVertical += 1.0f;
	}

	int32_t SumUp = 0;

	for (int32_t i = 1; i < 3; i++)
	{
		input = pNeuron->pDendrite_InputValueArray[ixCenter + (iyCenter - i) * 5];
		
		if (input == 0.0f)
			SumUp++;
		else
			break;
	}

	if (SumUp == 2)
	{
		outputVertical += 1.0f;
	}

	if (SumDown + SumUp > 1)
	{
		outputVertical += 1.0f;
	}

	pNeuron->NeuronOutput = outputHorizontal + outputVertical;
}

void L4ShipPlacementEvaluation(CNeuronV2 *pNeuron)
{
	float outputHorizontal = 0.0f;
	float outputVertical = 0.0f;
	float input;

	// local receptive field size: 7
	int32_t ixCenter = 3;
	int32_t iyCenter = 3;
	int32_t iiyCenter = iyCenter * 7;
	int32_t idCenter = ixCenter + iiyCenter;

	int32_t SumRight = 0;

	for (int32_t i = 1; i < 4; i++)
	{
		input = pNeuron->pDendrite_InputValueArray[ixCenter + i + iiyCenter];

		if (input == 0.0f)
			SumRight++;
		else
			break;
	}

	if (SumRight == 3)
	{
		outputHorizontal += 1.0f;
	}

	int32_t SumLeft = 0;

	for (int32_t i = 1; i < 4; i++)
	{
		input = pNeuron->pDendrite_InputValueArray[ixCenter - i + iiyCenter];
		
		if (input == 0.0f)
			SumLeft++;
		else
			break;
	}

	if (SumLeft == 3)
	{
		outputHorizontal += 1.0f;
	}

	if (SumRight + SumLeft > 2)
	{
		outputHorizontal += 1.0f;
	}

	int32_t SumDown = 0;

	for (int32_t i = 1; i < 4; i++)
	{
		input = pNeuron->pDendrite_InputValueArray[ixCenter + (iyCenter + i) * 7];
		
		if (input == 0.0f)
			SumDown++;
		else
			break;
	}

	if (SumDown == 3)
	{
		outputVertical += 1.0f;
	}

	int32_t SumUp = 0;

	for (int32_t i = 1; i < 4; i++)
	{
		input = pNeuron->pDendrite_InputValueArray[ixCenter + (iyCenter - i) * 7];
		
		if (input == 0.0f)
			SumUp++;
		else
			break;
	}

	if (SumUp == 3)
	{
		outputVertical += 1.0f;
	}

	if (SumDown + SumUp > 2)
	{
		outputVertical += 1.0f;
	}

	pNeuron->NeuronOutput = outputHorizontal + outputVertical;
}

void L5ShipPlacementEvaluation(CNeuronV2 *pNeuron)
{
	float outputHorizontal = 0.0f;
	float outputVertical = 0.0f;
	float input;

	// local receptive field size: 9
	int32_t ixCenter = 4;
	int32_t iyCenter = 4;
	int32_t iiyCenter = iyCenter * 9;
	int32_t idCenter = ixCenter + iiyCenter;

	int32_t SumRight = 0;

	for (int32_t i = 1; i < 5; i++)
	{
		input = pNeuron->pDendrite_InputValueArray[ixCenter + i + iiyCenter];
		
		if (input == 0.0f)
			SumRight++;
		else
			break;
	}

	if (SumRight == 4)
	{
		outputHorizontal += 1.0f;
	}

	int32_t SumLeft = 0;

	for (int32_t i = 1; i < 5; i++)
	{
		input = pNeuron->pDendrite_InputValueArray[ixCenter - i + iiyCenter];
		
		if (input == 0.0f)
			SumLeft++;
		else
			break;
	}

	if (SumLeft == 4)
	{
		outputHorizontal += 1.0f;
	}

	if (SumRight + SumLeft > 3)
	{
		outputHorizontal += 1.0f;
	}


	int32_t SumDown = 0;

	for (int32_t i = 1; i < 5; i++)
	{
		input = pNeuron->pDendrite_InputValueArray[ixCenter + (iyCenter + i) * 9];
		
		if (input == 0.0f)
			SumDown++;
		else
			break;
	}

	if (SumDown == 4)
	{
		outputVertical += 1.0f;
	}

	int32_t SumUp = 0;

	for (int32_t i = 1; i < 5; i++)
	{
		input = pNeuron->pDendrite_InputValueArray[ixCenter + (iyCenter - i) * 9];
		
		if (input == 0.0f)
			SumUp++;
		else
			break;
	}

	if (SumUp == 4)
	{
		outputVertical += 1.0f;
	}

	if (SumDown + SumUp > 3)
	{
		outputVertical += 1.0f;
	}

	pNeuron->NeuronOutput = outputHorizontal + outputVertical;
}







void Init_GameBoard(int32_t *pData, int32_t gameBoardElement)
{
	int32_t id;

	for (int32_t iy = 0; iy < ConstGameBoardSizePerDir; iy++)
	{
		for (int32_t ix = 0; ix < ConstGameBoardSizePerDir; ix++)
		{
			id = ix + iy * ConstGameBoardSizePerDir;
			pData[id] = gameBoardElement;
		}
	}
}

void Init_PaddedGameBoard(int32_t *pData, int32_t gameBoardElement)
{
	int32_t id;

	for (int32_t iy = 0; iy < ConstGameBoardSizePerDirWithPadding; iy++)
	{
		for (int32_t ix = 0; ix < ConstGameBoardSizePerDirWithPadding; ix++)
		{
			id = ix + iy * ConstGameBoardSizePerDirWithPadding;
			pData[id] = gameBoardElement;
		}
	}
}


void Copy_GameBoard(int32_t *pOutData, int32_t *pInData)
{
	for (int32_t i = 0; i < ConstGameBoardSize; i++)
		pOutData[i] = pInData[i];
}

void Copy_WaterShotData(float *pOutData, int32_t *pInData, float watershotValue)
{
	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		pOutData[i] = 0.0f;

		if (pInData[i] == ConstGameBoard_WaterShot)
			pOutData[i] = watershotValue;
	}
}



void Copy_WaterShotAndHitData(float *pOutData, int32_t *pInData, float watershotValue, float hitValue)
{
	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		pOutData[i] = 0.0f;

		if (pInData[i] == ConstGameBoard_WaterShot)
			pOutData[i] = watershotValue;
		else if (pInData[i] == ConstGameBoard_DamagedElement || pInData[i] == ConstGameBoard_DestroyedElement)
			pOutData[i] = hitValue;
	}
}

void Copy_DamagedElementData(float *pOutData, int32_t *pInData, float damagedElementValue)
{
	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		pOutData[i] = 0.0f;

		if (pInData[i] == ConstGameBoard_DamagedElement)
			pOutData[i] = damagedElementValue;
	}
}

void Copy_WaterShotAndDestroyedElementData(float *pOutData, int32_t *pInData, float waterShotAndDestroyedElementValue)
{
	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		pOutData[i] = 0.0f;

		if (pInData[i] == ConstGameBoard_WaterShot || pInData[i] == ConstGameBoard_DestroyedElement)
			pOutData[i] = waterShotAndDestroyedElementValue;
	}
}

void Copy_DestroyedElementData(float *pOutData, int32_t *pInData, float destroyedElementValue)
{
	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		pOutData[i] = 0.0f;

		if (pInData[i] == ConstGameBoard_DestroyedElement)
			pOutData[i] = destroyedElementValue;
	}
}

void Init_Or_Reset_Memory(float *pData, float initialValue)
{
	for (int32_t i = 0; i < ConstGameBoardSize; i++)
		pData[i] = initialValue;
}






void Add_ForbiddenTileID(int32_t *pInOutForbiddenTileIDList, int32_t ix, int32_t iy, int32_t *pInOutNumOfForbiddenTiles)
{
	int32_t id = ix + iy * ConstGameBoardSizePerDir;
	pInOutForbiddenTileIDList[*pInOutNumOfForbiddenTiles] = id;
	(*pInOutNumOfForbiddenTiles)++;
}


void Init_GameBoard_And_Set_RandomEntityPositions(int32_t *pInOutGameBoardData, CNavalEntity *pNavalEntityArray, int32_t numNavalEntities, CRandomNumbersNN *pRandomNumbers, int32_t *pForbiddenTileIDList, int32_t numOfForbiddenTiles)
{
	bool success;

	int32_t counter = 0;

	do
	{
		Init_GameBoard(pInOutGameBoardData, ConstGameBoard_Water);

		// Block Tiles:
		for (int32_t i = 0; i < numOfForbiddenTiles; i++)
		{
			pInOutGameBoardData[pForbiddenTileIDList[i]] = ConstGameBoard_IntactElement;
		}


		success = true;

		for (int32_t i = 0; i < numNavalEntities; i++)
		{
			//Add_To_Log(0, "Length", pNavalEntityArray[i].Length);
			success = pNavalEntityArray[i].Set_RandomPos(pInOutGameBoardData, pRandomNumbers);

			if (success == false)
				break;
		}

		//Add_To_Log(0, "counter", counter);
		//counter++;

		//if (counter > 1000)
			//break;

		if (success == true)
			break;

	} while (true);

	// Deblock Tiles:
	for (int32_t i = 0; i < numOfForbiddenTiles; i++)
	{
		pInOutGameBoardData[pForbiddenTileIDList[i]] = ConstGameBoard_Water;
	}
}

void Init_GameBoard_And_Set_RandomEntityPositions_DynamicPlacement(int32_t *pInOutGameBoardData, CNavalEntity *pNavalEntityArray, int32_t numNavalEntities, CRandomNumbersNN *pRandomNumbers, int32_t *pForbiddenTileIDList, int32_t numOfForbiddenTiles)
{
	bool success;

	int32_t id;

	//int32_t counter = 0;

	do
	{
		Init_GameBoard(pInOutGameBoardData, ConstGameBoard_Water);

		// Block Tiles:
		for (int32_t i = 0; i < numOfForbiddenTiles; i++)
		{
			id = pForbiddenTileIDList[i];

			if (id >= 1)
			{
				pInOutGameBoardData[id - 1] = ConstGameBoard_ForbiddenTile;
			}
			else if (id <= -1)
			{
				pInOutGameBoardData[-id - 1] = ConstGameBoard_DestroyedElement;
			}
		}


		success = true;

		for (int32_t i = 0; i < numNavalEntities; i++)
		{
			//Add_To_Log(0, "Length", pNavalEntityArray[i].Length);
			success = pNavalEntityArray[i].Set_RandomPos_Simple(pInOutGameBoardData, pRandomNumbers);

			if (success == false)
				break;
		}

		//Add_To_Log(0, "counter", counter);
		//counter++;

		//if (counter > 1000)
		//break;

		if (success == true)
			break;

	} while (true);

	// Deblock Tiles:
	for (int32_t i = 0; i < numOfForbiddenTiles; i++)
	{
		id = pForbiddenTileIDList[i];

		if (id >= 1)
		{
			pInOutGameBoardData[id - 1] = ConstGameBoard_Water;
		}
	}
}

void Init_GameBoard_And_Set_RandomEntityPositions_Simple(int32_t *pInOutGameBoardData, CNavalEntity *pNavalEntityArray, int32_t numNavalEntities, CRandomNumbersNN *pRandomNumbers, int32_t *pForbiddenTileIDList, int32_t numOfForbiddenTiles)
{
	bool success;

	int32_t id;

	int32_t counter = 0;

	do
	{
		Init_GameBoard(pInOutGameBoardData, ConstGameBoard_Water);

		// Block Tiles:
		for (int32_t i = 0; i < numOfForbiddenTiles; i++)
		{
			pInOutGameBoardData[pForbiddenTileIDList[i]] = ConstGameBoard_ForbiddenTile;
		}

		


		success = true;

		for (int32_t i = 0; i < numNavalEntities; i++)
		{
			//Add_To_Log(0, "Length", pNavalEntityArray[i].Length);
			success = pNavalEntityArray[i].Set_RandomPos_Simple(pInOutGameBoardData, pRandomNumbers);

			if (success == false)
				break;
		}

		//Add_To_Log(0, "counter", counter);
		//counter++;

		//if (counter > 1000)
		//break;

		if (success == true)
			break;

	} while (true);

	// Deblock Tiles:
	for (int32_t i = 0; i < numOfForbiddenTiles; i++)
	{
		pInOutGameBoardData[pForbiddenTileIDList[i]] = ConstGameBoard_Water;
	}
}


void Init_GameBoard_And_Set_RandomEntityPositions(int32_t *pInOutGameBoardData, CNavalEntity *pNavalEntityArray, int32_t numNavalEntities, CRandomNumbersNN *pRandomNumbers)
{
	bool success;

	do
	{
		Init_GameBoard(pInOutGameBoardData, ConstGameBoard_Water);

		success = true;

		for (int32_t i = 0; i < numNavalEntities; i++)
		{
			success = pNavalEntityArray[i].Set_RandomPos(pInOutGameBoardData, pRandomNumbers);

			if (success == false)
				break;
		}

		if (success == true)
			break;

	} while (true);

}

void Init_GameBoard_And_Set_RandomEntityPositions_Simple(int32_t *pInOutGameBoardData, CNavalEntity *pNavalEntityArray, int32_t numNavalEntities, CRandomNumbersNN *pRandomNumbers)
{
	bool success;

	do
	{
		Init_GameBoard(pInOutGameBoardData, ConstGameBoard_Water);

		success = true;

		for (int32_t i = 0; i < numNavalEntities; i++)
		{
			success = pNavalEntityArray[i].Set_RandomPos_Simple(pInOutGameBoardData, pRandomNumbers);

			if (success == false)
				break;
		}

		if (success == true)
			break;

	} while (true);

}



CNavalEntity::CNavalEntity()
{}

CNavalEntity::~CNavalEntity()
{
	delete[] pPartPosArray;
	pPartPosArray = nullptr;
	delete[] pPartPosXArray;
	pPartPosXArray = nullptr;
	delete[] pPartPosYArray;
	pPartPosYArray = nullptr;
}

void CNavalEntity::Clone_Data(CNavalEntity *pOriginalNavalEntity)
{
	Destroyed = pOriginalNavalEntity->Destroyed;
	MaxHorizontalLeftPos = pOriginalNavalEntity->MaxHorizontalLeftPos;
	MaxVerticalUpperPos = pOriginalNavalEntity->MaxVerticalUpperPos;
	Length = pOriginalNavalEntity->Length;

	for (int32_t i = 0; i < Length; i++)
	{
		pPartPosArray[i] = pOriginalNavalEntity->pPartPosArray[i];
		pPartPosXArray[i] = pOriginalNavalEntity->pPartPosXArray[i];
		pPartPosYArray[i] = pOriginalNavalEntity->pPartPosYArray[i];
	}
}

void CNavalEntity::Clone(CNavalEntity *pOriginalNavalEntity)
{
	Destroyed = pOriginalNavalEntity->Destroyed;
	MaxHorizontalLeftPos = pOriginalNavalEntity->MaxHorizontalLeftPos;
	MaxVerticalUpperPos = pOriginalNavalEntity->MaxVerticalUpperPos;
	Length = pOriginalNavalEntity->Length;

	delete[] pPartPosArray;
	pPartPosArray = nullptr;
	delete[] pPartPosXArray;
	pPartPosXArray = nullptr;
	delete[] pPartPosYArray;
	pPartPosYArray = nullptr;

	pPartPosArray = new (std::nothrow) int32_t[Length];
	pPartPosXArray = new (std::nothrow) int32_t[Length];
	pPartPosYArray = new (std::nothrow) int32_t[Length];

	for (int32_t i = 0; i < Length; i++)
	{
		pPartPosArray[i] = pOriginalNavalEntity->pPartPosArray[i];
		pPartPosXArray[i] = pOriginalNavalEntity->pPartPosXArray[i];
		pPartPosYArray[i] = pOriginalNavalEntity->pPartPosYArray[i];
	}
}

void CNavalEntity::Set_HorizontalPlacementPosition(int32_t ixleft, int32_t iy)
{
	Destroyed = false;

	int32_t ix, id;

	int32_t iiy = iy * ConstGameBoardSizePerDir;

	int32_t counter = 0;

	for (int32_t i = 0; i < Length; i++)
	{
		ix = ixleft + i;
		id = ix + iiy;

		pPartPosArray[counter] = id;
		pPartPosXArray[counter] = ix;
		pPartPosYArray[counter] = iy;

		counter++;
	}
}

void CNavalEntity::Set_VerticalPlacementPosition(int32_t ix, int32_t iyTop)
{
	Destroyed = false;

	int32_t iy, id;

	int32_t counter = 0;

	for (int32_t i = 0; i < Length; i++)
	{
		iy = iyTop + i;
		id = ix + iy * ConstGameBoardSizePerDir;

		pPartPosArray[counter] = id;
		pPartPosXArray[counter] = ix;
		pPartPosYArray[counter] = iy;

		counter++;
	}

}

void CNavalEntity::Copy_Data(float *pInOutDataMap, float intactElementValue)
{
	for (int32_t i = 0; i < Length; i++)
	{
		pInOutDataMap[pPartPosArray[i]] = intactElementValue;
	}
}

void CNavalEntity::Copy_Data_If_Destroyed(float *pInOutDataMap, float destroyedElementValue)
{
	if (Destroyed == false)
		return;

	for (int32_t i = 0; i < Length; i++)
	{
		pInOutDataMap[pPartPosArray[i]] = destroyedElementValue;
	}
}

void CNavalEntity::Add_Data(float *pInOutDataMap, float intactElementValue)
{
	for (int32_t i = 0; i < Length; i++)
	{
		pInOutDataMap[pPartPosArray[i]] += intactElementValue;
	}
}

void CNavalEntity::Add_Data_If_Destroyed(float *pInOutDataMap, float destroyedElementValue)
{
	if (Destroyed == false)
		return;

	for (int32_t i = 0; i < Length; i++)
	{
		pInOutDataMap[pPartPosArray[i]] += destroyedElementValue;
	}
}

void CNavalEntity::Copy_Data(int32_t *pInOutDataMap, int32_t intactElementValue)
{
	for (int32_t i = 0; i < Length; i++)
	{
		pInOutDataMap[pPartPosArray[i]] = intactElementValue;
	}
}

void CNavalEntity::Copy_Data_If_Destroyed(int32_t *pInOutDataMap, int32_t destroyedElementValue)
{
	if (Destroyed == false)
		return;

	for (int32_t i = 0; i < Length; i++)
	{
		pInOutDataMap[pPartPosArray[i]] = destroyedElementValue;
	}
}


void CNavalEntity::Add_Data(int32_t *pInOutDataMap, int32_t intactElementValue)
{
	for (int32_t i = 0; i < Length; i++)
	{
		pInOutDataMap[pPartPosArray[i]] += intactElementValue;
	}
}

void CNavalEntity::Add_Data_If_Destroyed(int32_t *pInOutDataMap, int32_t destroyedElementValue)
{
	if (Destroyed == false)
		return;

	for (int32_t i = 0; i < Length; i++)
	{
		pInOutDataMap[pPartPosArray[i]] += destroyedElementValue;
	}
}

void CNavalEntity::Initialize_With_MaxLength(void)
{
	Destroyed = false;

	Length = MaxLength;

	MaxHorizontalLeftPos = ConstGameBoardSizePerDir - Length;
	MaxVerticalUpperPos = MaxHorizontalLeftPos;

	delete[] pPartPosArray;
	pPartPosArray = nullptr;
	delete[] pPartPosXArray;
	pPartPosXArray = nullptr;
	delete[] pPartPosYArray;
	pPartPosYArray = nullptr;

	pPartPosArray = new (std::nothrow) int32_t[MaxLength];
	pPartPosXArray = new (std::nothrow) int32_t[MaxLength];
	pPartPosYArray = new (std::nothrow) int32_t[MaxLength];
}

void CNavalEntity::Initialize(int32_t length)
{
	Destroyed = false;

	Length = length;

	MaxHorizontalLeftPos = ConstGameBoardSizePerDir - length;
	MaxVerticalUpperPos = MaxHorizontalLeftPos;

	delete[] pPartPosArray;
	pPartPosArray = nullptr;
	delete[] pPartPosXArray;
	pPartPosXArray = nullptr;
	delete[] pPartPosYArray;
	pPartPosYArray = nullptr;

	pPartPosArray = new (std::nothrow) int32_t[length];
	pPartPosXArray = new (std::nothrow) int32_t[length];
	pPartPosYArray = new (std::nothrow) int32_t[length];
}

void CNavalEntity::Copy_To_GameBoard(int32_t *pInOutGameBoardData)
{
	for (int32_t i = 0; i < Length; i++)
	{
		pInOutGameBoardData[pPartPosArray[i]] = ConstGameBoard_IntactElement;
	}
}

void CNavalEntity::Check_Destruction(int32_t *pInOutGameBoardData)
{
	if (Destroyed == true)
		return;

	bool allPartsdamaged = true;

	for (int32_t i = 0; i < Length; i++)
	{
		if (pInOutGameBoardData[pPartPosArray[i]] != ConstGameBoard_DamagedElement)
		{
			allPartsdamaged = false;
			break;
		}
	}

	if (allPartsdamaged == true)
	{
		for (int32_t i = 0; i < Length; i++)
			pInOutGameBoardData[pPartPosArray[i]] = ConstGameBoard_DestroyedElement;

		Destroyed = true;
	}

}

bool CNavalEntity::Set_RandomPos(int32_t *pInOutGameBoardData, CRandomNumbersNN *pRandomNumbers)
{
	int32_t maxAttempts = 10000;
	int32_t loopCounter = 0;

	Destroyed = false;

	/* Hinweis: Schiffe d�rfen sich nicht ber�hren!!*/

	// horizontal placement:
	if (pRandomNumbers->Get_IntegerNumber2(1, 2) == 1)
	{ 
		int32_t id;
		
		int32_t horizontalLeftPos = pRandomNumbers->Get_IntegerNumber2(0, MaxHorizontalLeftPos);
		int32_t horizontalRightPosPlus1 = horizontalLeftPos + Length;
		int32_t verticalPos = pRandomNumbers->Get_IntegerNumber2(0, ConstGameBoardSizePerDirMinus1);
		
		bool emptySpace = true;

		do
		{
			loopCounter++;

			if (loopCounter == maxAttempts)
				break;

			int32_t iyMinus1 = (verticalPos - 1) * ConstGameBoardSizePerDir;
			int32_t iy = verticalPos * ConstGameBoardSizePerDir;
			int32_t iyPlus1 = (verticalPos + 1) * ConstGameBoardSizePerDir;

			for (int32_t i = horizontalLeftPos - 1; i <= horizontalRightPosPlus1; i++)
			{
				if (i < 0)
					continue;
				if (i > ConstGameBoardSizePerDirMinus1)
					continue;
				
				if (verticalPos > 0)
				{
					id = i + iyMinus1;

					if (pInOutGameBoardData[id] != ConstGameBoard_Water)
					{
						emptySpace = false;
						break;
					}
				}

				id = i + iy;

				if (pInOutGameBoardData[id] != ConstGameBoard_Water)
				{
					emptySpace = false;
					break;
				}

				if (verticalPos < ConstGameBoardSizePerDirMinus1)
				{
					id = i + iyPlus1;

					if (pInOutGameBoardData[id] != ConstGameBoard_Water)
					{
						emptySpace = false;
						break;
					}
				}
			}

			if (emptySpace == true)
			{
				int32_t counter = 0;

				for (int32_t i = horizontalLeftPos; i < horizontalRightPosPlus1; i++)
				{
					id = i + iy;
					pInOutGameBoardData[id] = ConstGameBoard_IntactElement;

					pPartPosArray[counter] = id;
					pPartPosXArray[counter] = i;
					pPartPosYArray[counter] = verticalPos;
					counter++;
				}
			}
			else
			{
				emptySpace = true;
				horizontalLeftPos = pRandomNumbers->Get_IntegerNumber2(0, MaxHorizontalLeftPos);
				horizontalRightPosPlus1 = horizontalLeftPos + Length;
				verticalPos = pRandomNumbers->Get_IntegerNumber2(0, ConstGameBoardSizePerDirMinus1);
				
				continue;
			}

			if (emptySpace == true)
				break;

		} while (true);

		
	}
	// vertical placement:
	else
	{
		int32_t id;
		int32_t verticalUpperPos = pRandomNumbers->Get_IntegerNumber2(0, MaxVerticalUpperPos);
		int32_t verticalLowerPosPlus1 = verticalUpperPos + Length;
		int32_t horizontalPos = pRandomNumbers->Get_IntegerNumber2(0, ConstGameBoardSizePerDirMinus1);
		

		bool emptySpace = true;

		do
		{
			loopCounter++;

			if (loopCounter == maxAttempts)
				break;

			for (int32_t i = verticalUpperPos - 1; i <= verticalLowerPosPlus1; i++)
			{
				if (i < 0)
					continue;
				if (i > ConstGameBoardSizePerDirMinus1)
					continue;

				int32_t iy = i * ConstGameBoardSizePerDir;

				if (horizontalPos > 0)
				{
					id = horizontalPos - 1 + iy;

					if (pInOutGameBoardData[id] != ConstGameBoard_Water)
					{
						emptySpace = false;
						break;
					}
				}

				id = horizontalPos + iy;

				if (pInOutGameBoardData[id] != ConstGameBoard_Water)
				{
					emptySpace = false;
					break;
				}

				if (horizontalPos < ConstGameBoardSizePerDirMinus1)
				{
					id = horizontalPos + 1 + iy;

					if (pInOutGameBoardData[id] != ConstGameBoard_Water)
					{
						emptySpace = false;
						break;
					}
				}
			}

			if (emptySpace == true)
			{
				int32_t counter = 0;

				for (int32_t i = verticalUpperPos; i < verticalLowerPosPlus1; i++)
				{
					id = horizontalPos + i * ConstGameBoardSizePerDir;
					pInOutGameBoardData[id] = ConstGameBoard_IntactElement;
					
					pPartPosArray[counter] = id;
					pPartPosXArray[counter] = horizontalPos;
					pPartPosYArray[counter] = i;
					counter++;
				}

			}
			else
			{
				emptySpace = true;
				verticalUpperPos = pRandomNumbers->Get_IntegerNumber2(0, MaxVerticalUpperPos);
				verticalLowerPosPlus1 = verticalUpperPos + Length;
				horizontalPos = pRandomNumbers->Get_IntegerNumber2(0, ConstGameBoardSizePerDirMinus1);

				continue;
			}

			if (emptySpace == true)
				break;

		} while (true);
	}

	if (loopCounter == maxAttempts)
	{
		//Add_To_Log(0, "Set_RandomPos() - ship placement failed");
		return false;
	}
	else
		return true;
}



bool CNavalEntity::Set_RandomPos_Simple(int32_t *pInOutGameBoardData, CRandomNumbersNN *pRandomNumbers)
{
	int32_t maxAttempts = 10000;
	int32_t loopCounter = 0;

	Destroyed = false;

	// horizontal placement:
	if (pRandomNumbers->Get_IntegerNumber2(1, 2) == 1)
	{
		int32_t id;

		int32_t horizontalLeftPos = pRandomNumbers->Get_IntegerNumber2(0, MaxHorizontalLeftPos);
		int32_t horizontalRightPosPlus1 = horizontalLeftPos + Length;
		int32_t verticalPos = pRandomNumbers->Get_IntegerNumber2(0, ConstGameBoardSizePerDirMinus1);

		bool emptySpace = true;

		do
		{
			loopCounter++;

			if (loopCounter == maxAttempts)
				break;

			int32_t iy = verticalPos * ConstGameBoardSizePerDir;

			for (int32_t i = horizontalLeftPos; i < horizontalRightPosPlus1; i++)
			{
				id = i + iy;

				if (pInOutGameBoardData[id] != ConstGameBoard_Water)
				{
					emptySpace = false;
					break;
				}		
			}

			if (emptySpace == true)
			{
				int32_t counter = 0;

				for (int32_t i = horizontalLeftPos; i < horizontalRightPosPlus1; i++)
				{
					id = i + iy;
					pInOutGameBoardData[id] = ConstGameBoard_IntactElement;

					pPartPosArray[counter] = id;
					pPartPosXArray[counter] = i;
					pPartPosYArray[counter] = verticalPos;
					counter++;
				}
			}
			else
			{
				emptySpace = true;
				horizontalLeftPos = pRandomNumbers->Get_IntegerNumber2(0, MaxHorizontalLeftPos);
				horizontalRightPosPlus1 = horizontalLeftPos + Length;
				verticalPos = pRandomNumbers->Get_IntegerNumber2(0, ConstGameBoardSizePerDirMinus1);

				continue;
			}

			if (emptySpace == true)
				break;

		} while (true);


	}
	// vertical placement:
	else
	{
		int32_t id;
		int32_t verticalUpperPos = pRandomNumbers->Get_IntegerNumber2(0, MaxVerticalUpperPos);
		int32_t verticalLowerPosPlus1 = verticalUpperPos + Length;
		int32_t horizontalPos = pRandomNumbers->Get_IntegerNumber2(0, ConstGameBoardSizePerDirMinus1);


		bool emptySpace = true;

		do
		{
			loopCounter++;

			if (loopCounter == maxAttempts)
				break;

			for (int32_t i = verticalUpperPos; i < verticalLowerPosPlus1; i++)
			{
				

				int32_t iy = i * ConstGameBoardSizePerDir;

				

				id = horizontalPos + iy;

				if (pInOutGameBoardData[id] != ConstGameBoard_Water)
				{
					emptySpace = false;
					break;
				}

			}

			if (emptySpace == true)
			{
				int32_t counter = 0;

				for (int32_t i = verticalUpperPos; i < verticalLowerPosPlus1; i++)
				{
					id = horizontalPos + i * ConstGameBoardSizePerDir;
					pInOutGameBoardData[id] = ConstGameBoard_IntactElement;

					pPartPosArray[counter] = id;
					pPartPosXArray[counter] = horizontalPos;
					pPartPosYArray[counter] = i;
					counter++;
				}

			}
			else
			{
				emptySpace = true;
				verticalUpperPos = pRandomNumbers->Get_IntegerNumber2(0, MaxVerticalUpperPos);
				verticalLowerPosPlus1 = verticalUpperPos + Length;
				horizontalPos = pRandomNumbers->Get_IntegerNumber2(0, ConstGameBoardSizePerDirMinus1);

				continue;
			}

			if (emptySpace == true)
				break;

		} while (true);
	}

	if (loopCounter == maxAttempts)
	{
		//Add_To_Log(0, "Set_RandomPos_Simple2() - ship placement failed");
		return false;
	}
	else
		return true;
}


CDynamicForbiddenTileData::CDynamicForbiddenTileData()
{}

CDynamicForbiddenTileData::~CDynamicForbiddenTileData()
{
	delete[] pForbiddenTileIDList;
	pForbiddenTileIDList = nullptr;

	delete[] pIntactNavalEntityArray;
	pIntactNavalEntityArray = nullptr;

	delete[] pTempGameBoardData;
	pTempGameBoardData = nullptr;
}

void CDynamicForbiddenTileData::Initialize(int32_t gameBoardSize, int32_t numOfNavalEntities)
{
	delete[] pForbiddenTileIDList;
	pForbiddenTileIDList = nullptr;

	delete[] pIntactNavalEntityArray;
	pIntactNavalEntityArray = nullptr;

	delete[] pTempGameBoardData;
	pTempGameBoardData = nullptr;

	GameBoardSize = gameBoardSize;
	NumOfNavalEntities = numOfNavalEntities;

	pForbiddenTileIDList = new (std::nothrow) int32_t[gameBoardSize];
	pTempGameBoardData = new (std::nothrow) int32_t[gameBoardSize];

	for (int32_t i = 0; i < gameBoardSize; i++)
	{
		pForbiddenTileIDList[i] = 0;
	}

	pIntactNavalEntityArray = new (std::nothrow) CNavalEntity[numOfNavalEntities];

	for (int32_t i = 0; i < numOfNavalEntities; i++)
	{
		pIntactNavalEntityArray[i].Initialize_With_MaxLength();
	}
}

void CDynamicForbiddenTileData::Calculate_DynamicPlacementStrategy(CPlacementStrategies *pPlacementStrategies, int32_t numPlacementTests, CRandomNumbersNN *pRandomNumbers, bool additionalDendriteModifications)
{
	if (pPlacementStrategies->AdditionalDynamicStrategy == false)
		return;

	int32_t numNavalEntityElements = 0;

	for (int32_t i = 0; i < NumOfIntactNavalEntities; i++)
	{
		numNavalEntityElements += pIntactNavalEntityArray[i].Length;
	}

	pPlacementStrategies->pStrategyArray[pPlacementStrategies->NumPrecalculatedStrategies].Train_MemoryNeuron_DynamicPlacement(pTempGameBoardData, numPlacementTests, pForbiddenTileIDList, NumOfForbiddenTiles, pIntactNavalEntityArray, NumOfIntactNavalEntities, static_cast<float>(numNavalEntityElements), pRandomNumbers, additionalDendriteModifications);

	//pPlacementStrategies->pStrategyArray[pPlacementStrategies->NumStrategies - 1].Train_MemoryNeuron_DynamicPlacement(pTempGameBoardData, numPlacementTests, pForbiddenTileIDList, NumOfForbiddenTiles, pIntactNavalEntityArray, NumOfIntactNavalEntities, static_cast<float>(numNavalEntityElements), pRandomNumbers, additionalDendriteModifications);
}




void CDynamicForbiddenTileData::Update_ForbiddenTileData(CNavalEntity *pNavalEntityArray, int32_t *pGameBoardData)
{
	NumOfForbiddenTiles = 0;
	NumOfIntactNavalEntities = 0;

	for (int32_t i = 0; i < GameBoardSize; i++)
	{
		if (pGameBoardData[i] == ConstGameBoard_WaterShot)
		{
			pForbiddenTileIDList[NumOfForbiddenTiles++] = i + 1;
		}
		else if (pGameBoardData[i] == ConstGameBoard_DestroyedElement)
		{
			pForbiddenTileIDList[NumOfForbiddenTiles++] = -i - 1;
		}
	}

	
	for (int32_t i = 0; i < NumOfNavalEntities; i++)
	{
		if (pNavalEntityArray[i].Destroyed == false)
		{
			pIntactNavalEntityArray[NumOfIntactNavalEntities].Clone_Data(&pNavalEntityArray[i]);
			NumOfIntactNavalEntities++;
		}
	}
}



CPlacementStrategy::CPlacementStrategy()
{
	MemoryNeuron.Init_Dendrite_Arrays(ConstGameBoardSize);
	MemoryNeuron.Set_ActivationFunction(PlacementStrategyEvaluation);

	DynamicMemoryNeuron.Init_Dendrite_Arrays(ConstGameBoardSize);
	DynamicMemoryNeuron.Set_ActivationFunction(PlacementStrategyEvaluation);
}

CPlacementStrategy::~CPlacementStrategy()
{
}

void CPlacementStrategy::Prepare_New_PlacementStrategy(void)
{
	NumOfForbiddenTiles = 0;
}

void CPlacementStrategy::Set_ActivationFunction(pActivationFuncV2 pFunc)
{
	MemoryNeuron.Set_ActivationFunction(pFunc);
	DynamicMemoryNeuron.Set_ActivationFunction(pFunc);
}

void CPlacementStrategy::Train_MemoryNeuron(int32_t *pGameBoardData, CNavalEntity *pNavalEntityArray, int32_t numNavalEntities, float numNavalEntityElements, CRandomNumbersNN *pRandomNumbers)
{
	MemoryNeuron.Set_NumOfTrainingExamples(0);

	for (int32_t j = 0; j < NumPlacementTests; j++)
	{
		Init_GameBoard_And_Set_RandomEntityPositions(pGameBoardData, pNavalEntityArray, numNavalEntities, pRandomNumbers, ForbiddenTileIDList, NumOfForbiddenTiles);
		MemoryNeuron.SimpleAdd_Dendrite_CentroidValues(pGameBoardData, 0.5f);  // Hinweis  ConstGameBoard_IntactElement = 2;
		//MemoryNeuron.Add_SimpleDendrite_CentroidValues(pGameBoardData, 1.0f);
	}

	

	
	float sum = 0.000001f;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		sum += MemoryNeuron.pDendrite_CentroidValueArray[i];
	}

	float invSum = numNavalEntityElements / sum;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		MemoryNeuron.pDendrite_CentroidValueArray[i] *= invSum;
	}

	int32_t iiy, id;

	float fxxCorrected, fyyCorrected;

	if (CenterProbabilityDecrease == 0 && (CenterDistanceFactorX > 0.0f || CenterDistanceFactorY > 0.0f))
	{
		for (int32_t iy = 0; iy < ConstGameBoardSizePerDir; iy++)
		{
			iiy = iy * ConstGameBoardSizePerDir;

			fyyCorrected = static_cast<float>(iy) - 4.5f;
			fyyCorrected *= fyyCorrected;

			for (int32_t ix = 0; ix < ConstGameBoardSizePerDir; ix++)
			{
				id = ix + iiy;

				fxxCorrected = static_cast<float>(ix) - 4.5f;
				fxxCorrected *= fxxCorrected;

				MemoryNeuron.pDendrite_CentroidValueArray[id] *= exp(-CenterDistanceFactorX * fxxCorrected - CenterDistanceFactorY * fyyCorrected);
			}
		}

		float sum = 0.000001f;

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			sum += MemoryNeuron.pDendrite_CentroidValueArray[i];
		}

		float invSum = numNavalEntityElements / sum;

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			MemoryNeuron.pDendrite_CentroidValueArray[i] *= invSum;
		}
	}
	else if (CenterProbabilityDecrease == 1 && (CenterDistanceFactorX > 0.0f || CenterDistanceFactorY > 0.0f))
	{
		for (int32_t iy = 0; iy < ConstGameBoardSizePerDir; iy++)
		{
			iiy = iy * ConstGameBoardSizePerDir;

			fyyCorrected = 4.5f - abs(static_cast<float>(iy) - 4.5f);
			fyyCorrected *= fyyCorrected;

			for (int32_t ix = 0; ix < ConstGameBoardSizePerDir; ix++)
			{
				id = ix + iiy;

				fxxCorrected = 4.5f - abs(static_cast<float>(ix) - 4.5f);
				fxxCorrected *= fxxCorrected;

				MemoryNeuron.pDendrite_CentroidValueArray[id] *= exp(-CenterDistanceFactorX * fxxCorrected - CenterDistanceFactorY * fyyCorrected);
			}
		}

		float sum = 0.000001f;

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
			sum += MemoryNeuron.pDendrite_CentroidValueArray[i];


		float invSum = numNavalEntityElements / sum;

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			MemoryNeuron.pDendrite_CentroidValueArray[i] *= invSum;
		}
	}


	/*float maxValue = 0.000001f;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (MemoryNeuron.pDendrite_CentroidValueArray[i] > maxValue)
			maxValue = MemoryNeuron.pDendrite_CentroidValueArray[i];
	}

	float invMaxValue = 1.0f / maxValue;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
			MemoryNeuron.pDendrite_CentroidValueArray[i] *= invMaxValue;
	}*/

	MemoryNeuron.Calculate_Dendrite_Factors_From_CentroidValues(0.0f, 1000.0f, 4);
}

void CPlacementStrategy::Train_MemoryNeuron_Simple(int32_t *pGameBoardData, CNavalEntity *pNavalEntityArray, int32_t numNavalEntities, float numNavalEntityElements, CRandomNumbersNN *pRandomNumbers)
{
	MemoryNeuron.Set_NumOfTrainingExamples(0);

	for (int32_t j = 0; j < NumPlacementTests; j++)
	{
		Init_GameBoard_And_Set_RandomEntityPositions_Simple(pGameBoardData, pNavalEntityArray, numNavalEntities, pRandomNumbers, ForbiddenTileIDList, NumOfForbiddenTiles);
		MemoryNeuron.SimpleAdd_Dendrite_CentroidValues(pGameBoardData, 0.5f);  // Hinweis  ConstGameBoard_IntactElement = 2;
																			   //MemoryNeuron.Add_SimpleDendrite_CentroidValues(pGameBoardData, 1.0f);
	}




	float sum = 0.000001f;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		sum += MemoryNeuron.pDendrite_CentroidValueArray[i];
	}

	float invSum = numNavalEntityElements / sum;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		MemoryNeuron.pDendrite_CentroidValueArray[i] *= invSum;
	}

	int32_t iiy, id;

	float fxxCorrected, fyyCorrected;

	if (CenterProbabilityDecrease == 0 && (CenterDistanceFactorX > 0.0f || CenterDistanceFactorY > 0.0f))
	{
		for (int32_t iy = 0; iy < ConstGameBoardSizePerDir; iy++)
		{
			iiy = iy * ConstGameBoardSizePerDir;

			fyyCorrected = static_cast<float>(iy) - 4.5f;
			fyyCorrected *= fyyCorrected;

			for (int32_t ix = 0; ix < ConstGameBoardSizePerDir; ix++)
			{
				id = ix + iiy;

				fxxCorrected = static_cast<float>(ix) - 4.5f;
				fxxCorrected *= fxxCorrected;

				MemoryNeuron.pDendrite_CentroidValueArray[id] *= exp(-CenterDistanceFactorX * fxxCorrected - CenterDistanceFactorY * fyyCorrected);
			}
		}

		float sum = 0.000001f;

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			sum += MemoryNeuron.pDendrite_CentroidValueArray[i];
		}

		float invSum = numNavalEntityElements / sum;

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			MemoryNeuron.pDendrite_CentroidValueArray[i] *= invSum;
		}
	}
	else if (CenterProbabilityDecrease == 1 && (CenterDistanceFactorX > 0.0f || CenterDistanceFactorY > 0.0f))
	{
		for (int32_t iy = 0; iy < ConstGameBoardSizePerDir; iy++)
		{
			iiy = iy * ConstGameBoardSizePerDir;

			fyyCorrected = 4.5f - abs(static_cast<float>(iy) - 4.5f);
			fyyCorrected *= fyyCorrected;

			for (int32_t ix = 0; ix < ConstGameBoardSizePerDir; ix++)
			{
				id = ix + iiy;

				fxxCorrected = 4.5f - abs(static_cast<float>(ix) - 4.5f);
				fxxCorrected *= fxxCorrected;

				MemoryNeuron.pDendrite_CentroidValueArray[id] *= exp(-CenterDistanceFactorX * fxxCorrected - CenterDistanceFactorY * fyyCorrected);
			}
		}

		float sum = 0.000001f;

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
			sum += MemoryNeuron.pDendrite_CentroidValueArray[i];


		float invSum = numNavalEntityElements / sum;

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			MemoryNeuron.pDendrite_CentroidValueArray[i] *= invSum;
		}
	}


	/*float maxValue = 0.000001f;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
	if (MemoryNeuron.pDendrite_CentroidValueArray[i] > maxValue)
	maxValue = MemoryNeuron.pDendrite_CentroidValueArray[i];
	}

	float invMaxValue = 1.0f / maxValue;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
	MemoryNeuron.pDendrite_CentroidValueArray[i] *= invMaxValue;
	}*/

	MemoryNeuron.Calculate_Dendrite_Factors_From_CentroidValues(0.0f, 1000.0f, 4);
}

void CPlacementStrategy::Train_MemoryNeuron(int32_t *pGameBoardData, int32_t numPlacementTests, int32_t *pForbiddenTileIDList, int32_t numOfForbiddenTiles, CNavalEntity *pNavalEntityArray, int32_t numNavalEntities, float numNavalEntityElements, CRandomNumbersNN *pRandomNumbers)
{
	MemoryNeuron.Set_NumOfTrainingExamples(0);

	for (int32_t j = 0; j < numPlacementTests; j++)
	{
		Init_GameBoard_And_Set_RandomEntityPositions(pGameBoardData, pNavalEntityArray, numNavalEntities, pRandomNumbers, pForbiddenTileIDList, numOfForbiddenTiles);
		MemoryNeuron.SimpleAdd_Dendrite_CentroidValues(pGameBoardData, 0.5f);  // Hinweis  ConstGameBoard_IntactElement = 2;
																			   //MemoryNeuron.Add_SimpleDendrite_CentroidValues(pGameBoardData, 1.0f);
	}



	float sum = 0.000001f;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		sum += MemoryNeuron.pDendrite_CentroidValueArray[i];
	}

	float invSum = numNavalEntityElements / sum;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		MemoryNeuron.pDendrite_CentroidValueArray[i] *= invSum;
	}

	MemoryNeuron.Calculate_Dendrite_Factors_From_CentroidValues(0.0f, 1000.0f, 4);
}

void CPlacementStrategy::Train_MemoryNeuron_DynamicPlacement(int32_t *pGameBoardData, int32_t numPlacementTests, int32_t *pForbiddenTileIDList, int32_t numOfForbiddenTiles, CNavalEntity *pNavalEntityArray, int32_t numNavalEntities, float numNavalEntityElements, CRandomNumbersNN *pRandomNumbers, bool additionalDendriteModifications)
{
	MemoryNeuron.Set_NumOfTrainingExamples(0);

	for (int32_t j = 0; j < numPlacementTests; j++)
	{
		Init_GameBoard_And_Set_RandomEntityPositions_DynamicPlacement(pGameBoardData, pNavalEntityArray, numNavalEntities, pRandomNumbers, pForbiddenTileIDList, numOfForbiddenTiles);
		MemoryNeuron.SimpleAdd_Dendrite_CentroidValues(pGameBoardData, 0.5f);  
		/* Hinweise: ConstGameBoard_IntactElement = 2;
		centroidScale * ConstGameBoard_IntactElement = 1 */
																			   
	}

	float sum = 0.000001f;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		sum += MemoryNeuron.pDendrite_CentroidValueArray[i];
	}

	float invSum = numNavalEntityElements / sum;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		MemoryNeuron.pDendrite_CentroidValueArray[i] *= invSum;
	}

	

	MemoryNeuron.Calculate_Dendrite_Factors_From_CentroidValues(0.0f, 1000.0f, 4);

	if (additionalDendriteModifications == true)
	{
		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			MemoryNeuron.pDendrite_CentroidValueArray[i] = 1.0f - exp(-MemoryNeuron.pDendrite_FactorArray[i] * MemoryNeuron.pDendrite_CentroidValueArray[i] * MemoryNeuron.pDendrite_CentroidValueArray[i]);
		}
	}
	


	//////////////////////////////

	/*if (helperCounter % 5 == 0)
	{
		char strBuffer[100];

		std::ofstream WriteFile;

		sprintf(strBuffer, "BattleshipDynamicStrategies/%d.txt", helperCounter);

		// neue Datei erzeugen bzw. alte �berschreiben:
		WriteFile.open(strBuffer);


		int32_t counter = 0;

		for (int32_t iy = 0; iy < 10; iy++)
		{
			for (int32_t ix = 0; ix < 10; ix++)
			{
				WriteFile << MemoryNeuron.pDendrite_CentroidValueArray[counter] << "  ";
				counter++;
			}

			WriteFile << endl;
		}

		WriteFile.close();
	}

	helperCounter++;*/

	//////////////////////////////
}






CPlacementStrategies::CPlacementStrategies()
{
}

CPlacementStrategies::~CPlacementStrategies()
{
	//Add_To_Log(0, "~CPlacementStrategies() ...");

	delete[] pStrategyArray;
	pStrategyArray = nullptr;

	//Add_To_Log(0, "~CPlacementStrategies() ok");
}

void CPlacementStrategies::Set_ActivationFunction(pActivationFuncV2 pFunc)
{
	for (int32_t i = 0; i < NumStrategies; i++)
	{
		pStrategyArray[i].Set_ActivationFunction(pFunc);
	}
}



bool CPlacementStrategies::Init_New_Strategies(const char* pFilename, CRandomNumbersNN *pRandomNumbers, bool additionalDynamicStrategy)
{
	AdditionalDynamicStrategy = additionalDynamicStrategy;

	std::ifstream ReadFile;

	// eine existierende Datei zum Lesen �ffnen:
	ReadFile.open(pFilename);

	if (ReadFile.good() == false)
		return false;

	char strBuffer[200];
	int32_t numStrategies;
	int32_t numPlacementTestsMin, numPlacementTestsMax;
	int32_t numForbiddenTiles, ix, iy;
	
	ReadFile >> strBuffer;
	ReadFile >> NumBaseStrategies;
	ReadFile >> strBuffer;
	ReadFile >> NumAdditionalStrategies;
		
	numStrategies = NumBaseStrategies + NumAdditionalStrategies;

	NumPrecalculatedStrategies = numStrategies;

	NeuronEnsemble.Set_NumOfNeurons(NumPrecalculatedStrategies);
	DynamicNeuronEnsemble.Set_NumOfNeurons(NumPrecalculatedStrategies);

	if (additionalDynamicStrategy == true)
		numStrategies++;
	
	if (numStrategies > NumStrategies)
	{
		delete[] pStrategyArray;
		pStrategyArray = nullptr;

		pStrategyArray = new (std::nothrow) CPlacementStrategy[numStrategies];
	}

	NumStrategies = numStrategies;

	for (int32_t i = 0; i < NumBaseStrategies; i++)
	{
		NeuronEnsemble.Set_Neuron(&pStrategyArray[i].MemoryNeuron, i);
		DynamicNeuronEnsemble.Set_Neuron(&pStrategyArray[i].DynamicMemoryNeuron, i);

		pStrategyArray[i].Prepare_New_PlacementStrategy();

		ReadFile >> strBuffer;
		ReadFile >> numForbiddenTiles;
		ReadFile >> strBuffer;
		ReadFile >> pStrategyArray[i].CenterDistanceFactorX;
		ReadFile >> strBuffer;
		ReadFile >> pStrategyArray[i].CenterDistanceFactorY;
		ReadFile >> strBuffer;
		ReadFile >> pStrategyArray[i].CenterProbabilityDecrease;
		ReadFile >> strBuffer;
		ReadFile >> numPlacementTestsMin;
		ReadFile >> strBuffer;
		ReadFile >> numPlacementTestsMax;
		ReadFile >> strBuffer;

		if (numPlacementTestsMin == numPlacementTestsMax)
			pStrategyArray[i].NumPlacementTests = numPlacementTestsMin;
		else
			pStrategyArray[i].NumPlacementTests = pRandomNumbers->Get_IntegerNumber2(numPlacementTestsMin, numPlacementTestsMax);

		for (int32_t j = 0; j < numForbiddenTiles; j++)
		{
			ReadFile >> ix;
			ReadFile >> iy;

			Add_ForbiddenTileID(pStrategyArray[i].ForbiddenTileIDList, ix, iy, &pStrategyArray[i].NumOfForbiddenTiles);
		}
	}

	ReadFile.close();

	int32_t baseStrategiesMinus1 = NumBaseStrategies - 1;

	int32_t numPredefinedStrategys = numStrategies;

	if (additionalDynamicStrategy == true)
		numPredefinedStrategys--;

	for (int32_t i = NumBaseStrategies; i < numPredefinedStrategys; i++)
	{
		NeuronEnsemble.Set_Neuron(&pStrategyArray[i].MemoryNeuron, i);
		DynamicNeuronEnsemble.Set_Neuron(&pStrategyArray[i].DynamicMemoryNeuron, i);

		pStrategyArray[i].Prepare_New_PlacementStrategy();

		numForbiddenTiles = pStrategyArray[baseStrategiesMinus1].NumOfForbiddenTiles;
		pStrategyArray[i].NumOfForbiddenTiles = numForbiddenTiles;
		//pStrategyArray[i].NumTrainingGamesPerStrategy = pStrategyArray[baseStrategiesMinus1].NumTrainingGamesPerStrategy;

		if (numPlacementTestsMin == numPlacementTestsMax)
			pStrategyArray[i].NumPlacementTests = numPlacementTestsMin;
		else
			pStrategyArray[i].NumPlacementTests = pRandomNumbers->Get_IntegerNumber2(numPlacementTestsMin, numPlacementTestsMax);

		for (int32_t j = 0; j < numForbiddenTiles; j++)
		{
			pStrategyArray[i].ForbiddenTileIDList[j] = pStrategyArray[baseStrategiesMinus1].ForbiddenTileIDList[j];
		}
	}

	if (additionalDynamicStrategy == true)
	{
		int32_t id = numPredefinedStrategys;

		pStrategyArray[id].NumOfForbiddenTiles = 0;
		pStrategyArray[id].NumPlacementTests = 1000;
	}

	return true;
}

void CPlacementStrategies::Train_MemoryNeurons(int32_t *pGameBoardData, CNavalEntity *pNavalEntityArray, int32_t numNavalEntities, int32_t numNavalEntityElements, CRandomNumbersNN *pRandomNumbers)
{
	float fNumNavalEntityElements = static_cast<float>(numNavalEntityElements);

	int32_t numStrategies = NumStrategies;

	if (AdditionalDynamicStrategy == true)
		numStrategies--;

	for (int32_t i = 0; i < numStrategies; i++)
	{
		pStrategyArray[i].Train_MemoryNeuron(pGameBoardData, pNavalEntityArray, numNavalEntities, fNumNavalEntityElements, pRandomNumbers);
		//pStrategyArray[i].Train_MemoryNeuron_Simple(pGameBoardData, pNavalEntityArray, numNavalEntities, fNumNavalEntityElements, pRandomNumbers);
	}
}

void CPlacementStrategies::Get_StrongestActivatedMemoryNeuron(CNeuronV2 **ppOutMemoryNeuron, int32_t *pOutBelongingNeuronID, float *pGameBoardData_WaterShotsAndHits)
{
	if (KEYDOWN(VK_F2) == true)
	{
		for (int32_t i = 0; i < NumPrecalculatedStrategies; i++)
		{
			pStrategyArray[i].MemoryNeuron.Set_Dendrite_NeuronInput(pGameBoardData_WaterShotsAndHits, ConstGameBoardSize);
			pStrategyArray[i].MemoryNeuron.Calculate_NeuronOutput();
			Add_To_Log(0, "out", pStrategyArray[i].MemoryNeuron.NeuronOutput);
		}
	}
	else
	{
		for (int32_t i = 0; i < NumPrecalculatedStrategies; i++)
		{
			pStrategyArray[i].MemoryNeuron.Set_Dendrite_NeuronInput(pGameBoardData_WaterShotsAndHits, ConstGameBoardSize);
			pStrategyArray[i].MemoryNeuron.Calculate_NeuronOutput();
		}
	}

	int32_t id = NeuronEnsemble.Get_ID_Of_NeuronWithMaxOutput();
	*ppOutMemoryNeuron = &pStrategyArray[id].MemoryNeuron;
	*pOutBelongingNeuronID = id;
	
	IDofStrongestActivatedMemoryNeuron = id;
}

void CPlacementStrategies::Get_StrongestActivatedDynamicMemoryNeuron(CNeuronV2 **ppOutMemoryNeuron, int32_t *pOutBelongingNeuronID, float *pGameBoardData_WaterShotsAndHits)
{
	if (AdditionalDynamicStrategy == false)
		return;

	for (int32_t i = 0; i < NumPrecalculatedStrategies; i++)
	{
		for (int32_t j = 0; j < ConstGameBoardSize; j++)
		{
			pStrategyArray[i].DynamicMemoryNeuron.pDendrite_CentroidValueArray[j] = pStrategyArray[i].MemoryNeuron.pDendrite_CentroidValueArray[j] * pStrategyArray[NumPrecalculatedStrategies].MemoryNeuron.pDendrite_CentroidValueArray[j];

			pStrategyArray[i].DynamicMemoryNeuron.pDendrite_FactorArray[j] = pStrategyArray[i].MemoryNeuron.pDendrite_FactorArray[j] * pStrategyArray[NumPrecalculatedStrategies].MemoryNeuron.pDendrite_FactorArray[j];
		}
	}

	/*for (int32_t i = 0; i < NumPrecalculatedStrategies; i++)
	{
		for (int32_t j = 0; j < ConstGameBoardSize; j++)
		{
			pStrategyArray[i].DynamicMemoryNeuron.pDendrite_CentroidValueArray[j] = min(pStrategyArray[i].MemoryNeuron.pDendrite_CentroidValueArray[j], pStrategyArray[NumPrecalculatedStrategies].MemoryNeuron.pDendrite_CentroidValueArray[j]);

			pStrategyArray[i].DynamicMemoryNeuron.pDendrite_FactorArray[j] = min(pStrategyArray[i].MemoryNeuron.pDendrite_FactorArray[j], pStrategyArray[NumPrecalculatedStrategies].MemoryNeuron.pDendrite_FactorArray[j]);
		}
	}*/

	if (KEYDOWN(VK_F2) == true)
	{
		for (int32_t i = 0; i < NumPrecalculatedStrategies; i++)
		{
			pStrategyArray[i].DynamicMemoryNeuron.Set_Dendrite_NeuronInput(pGameBoardData_WaterShotsAndHits, ConstGameBoardSize);
			pStrategyArray[i].DynamicMemoryNeuron.Calculate_NeuronOutput();
			Add_To_Log(0, "out", pStrategyArray[i].DynamicMemoryNeuron.NeuronOutput);
		}
	}
	else
	{
		for (int32_t i = 0; i < NumPrecalculatedStrategies; i++)
		{
			pStrategyArray[i].DynamicMemoryNeuron.Set_Dendrite_NeuronInput(pGameBoardData_WaterShotsAndHits, ConstGameBoardSize);
			pStrategyArray[i].DynamicMemoryNeuron.Calculate_NeuronOutput();
		}
	}

	int32_t id = DynamicNeuronEnsemble.Get_ID_Of_NeuronWithMaxOutput();
	*ppOutMemoryNeuron = &pStrategyArray[id].DynamicMemoryNeuron;
	*pOutBelongingNeuronID = id;
	IDofStrongestActivatedMemoryNeuron = id;
}

bool CPlacementStrategies::Save_HitProbabilityValues(const char *pBaseFileName)
{
	char strBuffer[100];

	std::ofstream WriteFile;

	int32_t numStrategies = NumStrategies;

	if (AdditionalDynamicStrategy == true)
		numStrategies--;

	for (int32_t i = 0; i < numStrategies; i++)
	{
		sprintf(strBuffer, "%s%d.txt", pBaseFileName, i);

		// neue Datei erzeugen bzw. alte �berschreiben:
		WriteFile.open(strBuffer);

		if (WriteFile.good() == false)
			return false;

		int32_t counter = 0;

		for (int32_t iy = 0; iy < 10; iy++)
		{
			for (int32_t ix = 0; ix < 10; ix++)
			{
				WriteFile << pStrategyArray[i].MemoryNeuron.pDendrite_CentroidValueArray[counter] << "  ";
				counter++;
			}

			WriteFile << endl;
		}

		WriteFile.close();
	}

	/*for (int32_t i = 0; i < NumStrategies; i++)
	{
		sprintf(strBuffer, "%s%d__.txt", pBaseFileName, i);

		// neue Datei erzeugen bzw. alte �berschreiben:
		WriteFile.open(strBuffer);

		if (WriteFile.good() == false)
			return false;

		int32_t counter = 0;

		for (int32_t iy = 0; iy < 10; iy++)
		{
			for (int32_t ix = 0; ix < 10; ix++)
			{
				WriteFile << pStrategyArray[i].MemoryNeuron.pDendrite_FactorArray[counter] << "  ";
				counter++;
			}

			WriteFile << endl;
		}

		WriteFile.close();
	}*/

	return true;
}

bool CPlacementStrategies::Load_HitProbabilityValues(const char *pBaseFileName)
{
	char strBuffer[100];

	std::ifstream ReadFile;

	int32_t numStrategies = NumStrategies;

	if (AdditionalDynamicStrategy == true)
		numStrategies--;


	for (int32_t i = 0; i < numStrategies; i++)
	{
		sprintf(strBuffer, "%s%d.txt", pBaseFileName, i);

		// eine existierende Datei zum Lesen �ffnen:
		ReadFile.open(strBuffer);

		if (ReadFile.good() == false)
		{
			Add_To_Log(0, "cannot open file", strBuffer);
			return false;
		}

		int32_t counter = 0;

		for (int32_t iy = 0; iy < 10; iy++)
		{
			for (int32_t ix = 0; ix < 10; ix++)
			{
				ReadFile >> pStrategyArray[i].MemoryNeuron.pDendrite_CentroidValueArray[counter];
				counter++;
			}		
		}

		ReadFile.close();

		pStrategyArray[i].MemoryNeuron.Calculate_Dendrite_Factors_From_CentroidValues(0.0f, 1000.0f, 4);
	}

	return true;
}


void Compare_PlacementStrategyEnsembles(CNeuronV2 **ppOutStrongestActivatedMemoryNeuron, int32_t *pOutBelongingNeuronID, CPlacementStrategies *pEnsembleArray, int32_t numArrayElements)
{
	float maxOutput = -10000000.0f;
	float output;
	int32_t id;
	int32_t bestID = 0;
	CNeuronV2 *pBestNeuron = nullptr;

	for (int32_t i = 0; i < numArrayElements; i++)
	{
		id = pEnsembleArray[i].IDofStrongestActivatedMemoryNeuron;
		output = pEnsembleArray[i].pStrategyArray[id].MemoryNeuron.NeuronOutput;

		if (output > maxOutput)
		{
			maxOutput = output;
			bestID = id;
			pBestNeuron = &pEnsembleArray[i].pStrategyArray[id].MemoryNeuron;
		}
	}

	*ppOutStrongestActivatedMemoryNeuron = pBestNeuron;
	*pOutBelongingNeuronID = bestID;

}


void Copy_PaddedGameBoardData(int32_t *pOutUnpaddedGameBoard, int32_t *pInPaddedGameBoard)
{
	int32_t id_unpadded, id_padded;

	for (int32_t iy = 0; iy < ConstGameBoardSizePerDir; iy++)
	{
		for (int32_t ix = 0; ix < ConstGameBoardSizePerDir; ix++)
		{
			id_unpadded = ix + iy * ConstGameBoardSizePerDir;
			id_padded   = (ix + 1) + (iy + 1) * ConstGameBoardSizePerDirWithPadding;

			pOutUnpaddedGameBoard[id_unpadded] = pInPaddedGameBoard[id_padded];
		}
	}
}


bool Check_NavalEntityL2_HorizontalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding)
{
	// Array-Begrenzungen ber�cksichtigen:
	if (ixLeft < 0)
		return false;
	if (iyTop < 0)
		return false;
	if (ixLeft > ConstGameBoardSizePerDirWithPadding - 4)
		return false;
	if (iyTop > ConstGameBoardSizePerDirWithPadding - 3)
		return false;

	int32_t gameBoardID, iiy;

	for (int32_t iy = 0; iy < 3; iy++)
	{
		iiy = (iyTop + iy) * ConstGameBoardSizePerDirWithPadding;

		for (int32_t ix = 0; ix < 4; ix++)
		{
			gameBoardID = (ixLeft + ix) + iiy;

			if (pGameBoardwithPadding[gameBoardID] != 0)
				return false;
		}
	}

	return true;
}

void Delete_NavalEntityL2_HorizontalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding)
{
	// Array-Begrenzungen ber�cksichtigen:
	ixLeft = max(ixLeft, 0);
	ixLeft = min(ixLeft, ConstGameBoardSizePerDirWithPadding - 4);
	iyTop = max(iyTop, 0);
	iyTop = min(iyTop, ConstGameBoardSizePerDirWithPadding - 3);

	int32_t gameBoardID, iiy;

	for (int32_t iy = 0; iy < 3; iy++)
	{
		iiy = (iyTop + iy) * ConstGameBoardSizePerDirWithPadding;

		for (int32_t ix = 0; ix < 4; ix++)
		{
			gameBoardID = (ixLeft + ix) + iiy;

			pGameBoardwithPadding[gameBoardID] = 0;
		}
	}
}

bool Add_NavalEntityL2_HorizontalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding)
{
	if (Check_NavalEntityL2_HorizontalPlacement(ixLeft, iyTop, pGameBoardwithPadding) == false)
		return false;

	
	int32_t gameBoardID, iiy;

	for (int32_t iy = 0; iy < 3; iy++)
	{
		iiy = (iyTop + iy) * ConstGameBoardSizePerDirWithPadding;

		for (int32_t ix = 0; ix < 4; ix++)
		{
			gameBoardID = (ixLeft + ix) + iiy;

			pGameBoardwithPadding[gameBoardID] = g_NavalEntityL2_Horizontal[iy][ix];

		}
	}

	return true;
}


bool Check_NavalEntityL3_HorizontalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding)
{
	// Array-Begrenzungen ber�cksichtigen:
	if (ixLeft < 0)
		return false;
	if (iyTop < 0)
		return false;
	if (ixLeft > ConstGameBoardSizePerDirWithPadding - 5)
		return false;
	if (iyTop > ConstGameBoardSizePerDirWithPadding - 3)
		return false;


	int32_t gameBoardID, iiy;

	for (int32_t iy = 0; iy < 3; iy++)
	{
		iiy = (iyTop + iy) * ConstGameBoardSizePerDirWithPadding;

		for (int32_t ix = 0; ix < 5; ix++)
		{
			gameBoardID = (ixLeft + ix) + iiy;

			if (pGameBoardwithPadding[gameBoardID] != 0)
				return false;
		}
	}

	return true;
}

void Delete_NavalEntityL3_HorizontalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding)
{
	// Array-Begrenzungen ber�cksichtigen:
	ixLeft = max(ixLeft, 0);
	ixLeft = min(ixLeft, ConstGameBoardSizePerDirWithPadding - 5);
	iyTop = max(iyTop, 0);
	iyTop = min(iyTop, ConstGameBoardSizePerDirWithPadding - 3);

	int32_t gameBoardID, iiy;

	for (int32_t iy = 0; iy < 3; iy++)
	{
		iiy = (iyTop + iy) * ConstGameBoardSizePerDirWithPadding;

		for (int32_t ix = 0; ix < 5; ix++)
		{
			gameBoardID = (ixLeft + ix) + iiy;

			pGameBoardwithPadding[gameBoardID] = 0;
		}
	}
}

bool Add_NavalEntityL3_HorizontalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding)
{
	if (Check_NavalEntityL3_HorizontalPlacement(ixLeft, iyTop, pGameBoardwithPadding) == false)
		return false;

	
	int32_t gameBoardID, iiy;

	for (int32_t iy = 0; iy < 3; iy++)
	{
		iiy = (iyTop + iy) * ConstGameBoardSizePerDirWithPadding;

		for (int32_t ix = 0; ix < 5; ix++)
		{
			gameBoardID = (ixLeft + ix) + iiy;

			pGameBoardwithPadding[gameBoardID] = g_NavalEntityL3_Horizontal[iy][ix];
		}
	}

	return true;
}


bool Check_NavalEntityL4_HorizontalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding)
{
	// Array-Begrenzungen ber�cksichtigen:
	if (ixLeft < 0)
		return false;
	if (iyTop < 0)
		return false;
	if (ixLeft > ConstGameBoardSizePerDirWithPadding - 6)
		return false;
	if (iyTop > ConstGameBoardSizePerDirWithPadding - 3)
		return false;

	int32_t gameBoardID, iiy;

	for (int32_t iy = 0; iy < 3; iy++)
	{
		iiy = (iyTop + iy) * ConstGameBoardSizePerDirWithPadding;

		for (int32_t ix = 0; ix < 6; ix++)
		{
			gameBoardID = (ixLeft + ix) + iiy;

			if (pGameBoardwithPadding[gameBoardID] != 0)
				return false;
		}
	}

	return true;
}

void Delete_NavalEntityL4_HorizontalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding)
{
	// Array-Begrenzungen ber�cksichtigen:
	ixLeft = max(ixLeft, 0);
	ixLeft = min(ixLeft, ConstGameBoardSizePerDirWithPadding - 6);
	iyTop = max(iyTop, 0);
	iyTop = min(iyTop, ConstGameBoardSizePerDirWithPadding - 3);

	int32_t gameBoardID, iiy;

	for (int32_t iy = 0; iy < 3; iy++)
	{
		iiy = (iyTop + iy) * ConstGameBoardSizePerDirWithPadding;

		for (int32_t ix = 0; ix < 6; ix++)
		{
			gameBoardID = (ixLeft + ix) + iiy;

			pGameBoardwithPadding[gameBoardID] = 0;
		}
	}
}

bool Add_NavalEntityL4_HorizontalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding)
{
	if (Check_NavalEntityL4_HorizontalPlacement(ixLeft, iyTop, pGameBoardwithPadding) == false)
		return false;

	
	int32_t gameBoardID, iiy;

	for (int32_t iy = 0; iy < 3; iy++)
	{
		iiy = (iyTop + iy) * ConstGameBoardSizePerDirWithPadding;

		for (int32_t ix = 0; ix < 6; ix++)
		{
			gameBoardID = (ixLeft + ix) + iiy;

			pGameBoardwithPadding[gameBoardID] = g_NavalEntityL4_Horizontal[iy][ix];
		}
	}

	return true;
}


bool Check_NavalEntityL5_HorizontalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding)
{
	// Array-Begrenzungen ber�cksichtigen:
	if (ixLeft < 0)
		return false;
	if (iyTop < 0)
		return false;
	if (ixLeft > ConstGameBoardSizePerDirWithPadding - 7)
		return false;
	if (iyTop > ConstGameBoardSizePerDirWithPadding - 3)
		return false;

	int32_t gameBoardID, iiy;

	for (int32_t iy = 0; iy < 3; iy++)
	{
		iiy = (iyTop + iy) * ConstGameBoardSizePerDirWithPadding;

		for (int32_t ix = 0; ix < 7; ix++)
		{
			gameBoardID = (ixLeft + ix) + iiy;

			if (pGameBoardwithPadding[gameBoardID] != 0)
				return false;
		}
	}

	return true;
}

void Delete_NavalEntityL5_HorizontalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding)
{
	// Array-Begrenzungen ber�cksichtigen:
	ixLeft = max(ixLeft, 0);
	ixLeft = min(ixLeft, ConstGameBoardSizePerDirWithPadding - 7);
	iyTop = max(iyTop, 0);
	iyTop = min(iyTop, ConstGameBoardSizePerDirWithPadding - 3);

	int32_t gameBoardID, iiy;

	for (int32_t iy = 0; iy < 3; iy++)
	{
		iiy = (iyTop + iy) * ConstGameBoardSizePerDirWithPadding;

		for (int32_t ix = 0; ix < 7; ix++)
		{
			gameBoardID = (ixLeft + ix) + iiy;

			pGameBoardwithPadding[gameBoardID] = 0;
		}
	}
}

bool Add_NavalEntityL5_HorizontalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding)
{
	if (Check_NavalEntityL5_HorizontalPlacement(ixLeft, iyTop, pGameBoardwithPadding) == false)
		return false;

	
	int32_t gameBoardID, iiy;

	for (int32_t iy = 0; iy < 3; iy++)
	{
		iiy = (iyTop + iy) * ConstGameBoardSizePerDirWithPadding;

		for (int32_t ix = 0; ix < 7; ix++)
		{
			gameBoardID = (ixLeft + ix) + iiy;

			pGameBoardwithPadding[gameBoardID] = g_NavalEntityL5_Horizontal[iy][ix];
		}
	}

	return true;
}


bool Check_NavalEntityL2_VerticalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding)
{
	// Array-Begrenzungen ber�cksichtigen:
	if (ixLeft < 0)
		return false;
	if (iyTop < 0)
		return false;
	if (ixLeft > ConstGameBoardSizePerDirWithPadding - 3)
		return false;
	if (iyTop > ConstGameBoardSizePerDirWithPadding - 4)
		return false;

	int32_t gameBoardID, iiy;

	for (int32_t iy = 0; iy < 4; iy++)
	{
		iiy = (iyTop + iy) * ConstGameBoardSizePerDirWithPadding;

		for (int32_t ix = 0; ix < 3; ix++)
		{
			gameBoardID = (ixLeft + ix) + iiy;

			if (pGameBoardwithPadding[gameBoardID] != 0)
				return false;
		}
	}

	return true;
}

void Delete_NavalEntityL2_VerticalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding)
{
	// Array-Begrenzungen ber�cksichtigen:
	ixLeft = max(ixLeft, 0);
	ixLeft = min(ixLeft, ConstGameBoardSizePerDirWithPadding - 3);
	iyTop = max(iyTop, 0);
	iyTop = min(iyTop, ConstGameBoardSizePerDirWithPadding - 4);

	int32_t gameBoardID, iiy;

	for (int32_t iy = 0; iy < 4; iy++)
	{
		iiy = (iyTop + iy) * ConstGameBoardSizePerDirWithPadding;

		for (int32_t ix = 0; ix < 3; ix++)
		{
			gameBoardID = (ixLeft + ix) + iiy;

			pGameBoardwithPadding[gameBoardID] = 0;
		}
	}
}

bool Add_NavalEntityL2_VerticalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding)
{
	if (Check_NavalEntityL2_VerticalPlacement(ixLeft, iyTop, pGameBoardwithPadding) == false)
		return false;

	
	int32_t gameBoardID, iiy;

	for (int32_t iy = 0; iy < 4; iy++)
	{
		iiy = (iyTop + iy) * ConstGameBoardSizePerDirWithPadding;

		for (int32_t ix = 0; ix < 3; ix++)
		{
			gameBoardID = (ixLeft + ix) + iiy;

			pGameBoardwithPadding[gameBoardID] = g_NavalEntityL2_Vertical[iy][ix];
		}
	}

	return true;
}


bool Check_NavalEntityL3_VerticalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding)
{
	// Array-Begrenzungen ber�cksichtigen:
	if (ixLeft < 0)
		return false;
	if (iyTop < 0)
		return false;
	if (ixLeft > ConstGameBoardSizePerDirWithPadding - 3)
		return false;
	if (iyTop > ConstGameBoardSizePerDirWithPadding - 5)
		return false;

	int32_t gameBoardID, iiy;

	for (int32_t iy = 0; iy < 5; iy++)
	{
		iiy = (iyTop + iy) * ConstGameBoardSizePerDirWithPadding;

		for (int32_t ix = 0; ix < 3; ix++)
		{
			gameBoardID = (ixLeft + ix) + iiy;

			if (pGameBoardwithPadding[gameBoardID] != 0)
				return false;
		}
	}

	return true;
}

void Delete_NavalEntityL3_VerticalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding)
{
	// Array-Begrenzungen ber�cksichtigen:
	ixLeft = max(ixLeft, 0);
	ixLeft = min(ixLeft, ConstGameBoardSizePerDirWithPadding - 3);
	iyTop = max(iyTop, 0);
	iyTop = min(iyTop, ConstGameBoardSizePerDirWithPadding - 5);

	int32_t gameBoardID, iiy;

	for (int32_t iy = 0; iy < 5; iy++)
	{
		iiy = (iyTop + iy) * ConstGameBoardSizePerDirWithPadding;

		for (int32_t ix = 0; ix < 3; ix++)
		{
			gameBoardID = (ixLeft + ix) + iiy;

			pGameBoardwithPadding[gameBoardID] = 0;
		}
	}
}

bool Add_NavalEntityL3_VerticalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding)
{
	if (Check_NavalEntityL3_VerticalPlacement(ixLeft, iyTop, pGameBoardwithPadding) == false)
		return false;

	
	int32_t gameBoardID, iiy;

	for (int32_t iy = 0; iy < 5; iy++)
	{
		iiy = (iyTop + iy) * ConstGameBoardSizePerDirWithPadding;

		for (int32_t ix = 0; ix < 3; ix++)
		{
			gameBoardID = (ixLeft + ix) + iiy;

			pGameBoardwithPadding[gameBoardID] = g_NavalEntityL3_Vertical[iy][ix];
		}
	}

	return true;
}

bool Check_NavalEntityL4_VerticalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding)
{
	// Array-Begrenzungen ber�cksichtigen:
	if (ixLeft < 0)
		return false;
	if (iyTop < 0)
		return false;
	if (ixLeft > ConstGameBoardSizePerDirWithPadding - 3)
		return false;
	if (iyTop > ConstGameBoardSizePerDirWithPadding - 6)
		return false;

	int32_t gameBoardID, iiy;

	for (int32_t iy = 0; iy < 6; iy++)
	{
		iiy = (iyTop + iy) * ConstGameBoardSizePerDirWithPadding;

		for (int32_t ix = 0; ix < 3; ix++)
		{
			gameBoardID = (ixLeft + ix) + iiy;

			if (pGameBoardwithPadding[gameBoardID] != 0)
				return false;
		}
	}

	return true;
}

void Delete_NavalEntityL4_VerticalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding)
{
	// Array-Begrenzungen ber�cksichtigen:
	ixLeft = max(ixLeft, 0);
	ixLeft = min(ixLeft, ConstGameBoardSizePerDirWithPadding - 3);
	iyTop = max(iyTop, 0);
	iyTop = min(iyTop, ConstGameBoardSizePerDirWithPadding - 6);

	int32_t gameBoardID, iiy;

	for (int32_t iy = 0; iy < 6; iy++)
	{
		iiy = (iyTop + iy) * ConstGameBoardSizePerDirWithPadding;

		for (int32_t ix = 0; ix < 3; ix++)
		{
			gameBoardID = (ixLeft + ix) + iiy;

			pGameBoardwithPadding[gameBoardID] = 0;
		}
	}
}

bool Add_NavalEntityL4_VerticalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding)
{
	if (Check_NavalEntityL4_VerticalPlacement(ixLeft, iyTop, pGameBoardwithPadding) == false)
		return false;

	
	int32_t gameBoardID, iiy;

	for (int32_t iy = 0; iy < 6; iy++)
	{
		iiy = (iyTop + iy) * ConstGameBoardSizePerDirWithPadding;

		for (int32_t ix = 0; ix < 3; ix++)
		{
			gameBoardID = (ixLeft + ix) + iiy;

			pGameBoardwithPadding[gameBoardID] = g_NavalEntityL4_Vertical[iy][ix];
		}
	}

	return true;
}

bool Check_NavalEntityL5_VerticalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding)
{
	// Array-Begrenzungen ber�cksichtigen:
	if (ixLeft < 0)
		return false;
	if (iyTop < 0)
		return false;
	if (ixLeft > ConstGameBoardSizePerDirWithPadding - 3)
		return false;
	if (iyTop > ConstGameBoardSizePerDirWithPadding - 7)
		return false;

	
	int32_t gameBoardID, iiy;

	for (int32_t iy = 0; iy < 7; iy++)
	{
		iiy = (iyTop + iy) * ConstGameBoardSizePerDirWithPadding;

		for (int32_t ix = 0; ix < 3; ix++)
		{
			gameBoardID = (ixLeft + ix) + iiy;

			if (pGameBoardwithPadding[gameBoardID] != 0)
				return false;
		}
	}

	return true;
}

void Delete_NavalEntityL5_VerticalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding)
{
	// Array-Begrenzungen ber�cksichtigen:
	ixLeft = max(ixLeft, 0);
	ixLeft = min(ixLeft, ConstGameBoardSizePerDirWithPadding - 3);
	iyTop = max(iyTop, 0);
	iyTop = min(iyTop, ConstGameBoardSizePerDirWithPadding - 7);

	int32_t gameBoardID, iiy;

	for (int32_t iy = 0; iy < 7; iy++)
	{
		iiy = (iyTop + iy) * ConstGameBoardSizePerDirWithPadding;

		for (int32_t ix = 0; ix < 3; ix++)
		{
			gameBoardID = (ixLeft + ix) + iiy;

			pGameBoardwithPadding[gameBoardID] = 0;
		}
	}
}

bool Add_NavalEntityL5_VerticalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding)
{
	if (Check_NavalEntityL5_VerticalPlacement(ixLeft, iyTop, pGameBoardwithPadding) == false)
		return false;

	

	int32_t gameBoardID, iiy;

	for (int32_t iy = 0; iy < 7; iy++)
	{
		iiy = (iyTop + iy) * ConstGameBoardSizePerDirWithPadding;

		for (int32_t ix = 0; ix < 3; ix++)
		{
			gameBoardID = (ixLeft + ix) + iiy;

			pGameBoardwithPadding[gameBoardID] = g_NavalEntityL5_Vertical[iy][ix];
		}
	}

	return true;
}

