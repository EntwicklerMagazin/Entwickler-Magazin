#include <iostream>
#include "NeuralNet.h"

using namespace std;

inline float LinearOutput(float neuronInput)
{
	return neuronInput;
}

inline float QuadraticOutput(float neuronInput)
{
	return neuronInput * neuronInput;
}

inline float CubicOutput(float neuronInput)
{
	return neuronInput * neuronInput * neuronInput;
}


class C1DimPolynomialFunctionApproxBrain
{
public:

	uint32_t NumHiddenNeurons = 6;
	//uint32_t NumHiddenNeurons = 24;

	uint32_t NumBiasNeurons = 1;
	uint32_t NumOutputNeurons = 1;

	uint32_t NumNeurons = NumHiddenNeurons + NumBiasNeurons + NumOutputNeurons;

	
	uint32_t BiasNeuronID = NumHiddenNeurons;
	uint32_t OutputNeuronID = NumNeurons - 1;

	CNeuron *pNeuronArray = nullptr;

	CRandomNumbersNN RandomNumbers;

	C1DimPolynomialFunctionApproxBrain()
	{
		pNeuronArray = new (std::nothrow) CNeuron[NumNeurons];

		uint32_t i;

		for (i = 0; i < NumNeurons; i++)
			pNeuronArray[i].Connect_With_Brain(pNeuronArray);

		for (i = 0; i < NumHiddenNeurons; i++)
		{
			pNeuronArray[i].Use_As_HiddenNeuron();
			pNeuronArray[i].Init_OutputSynapses(NumOutputNeurons);
			pNeuronArray[i].Connect_With_ReceiverNeuron(OutputNeuronID, /*SynapseID:*/ 0);
			pNeuronArray[i].Randomize_OutputSynapsePlasticities(&RandomNumbers, -0.0001f, 0.0001f);
			pNeuronArray[i].Set_LearningRate(0.0001f);
			pNeuronArray[i].Randomize_OutputSynapsePlasticities(&RandomNumbers, -0.0001f, 0.0001f);
			pNeuronArray[i].Set_LearningRate(0.0001f);

			if (i % 3 == 0)
				pNeuronArray[i].Set_ActivationFunction(LinearOutput);
			else if (i % 3 == 1)
				pNeuronArray[i].Set_ActivationFunction(QuadraticOutput);
			else if (i % 3 == 2)
				pNeuronArray[i].Set_ActivationFunction(CubicOutput);

		}

		pNeuronArray[BiasNeuronID].Use_As_BiasNeuron();
		pNeuronArray[BiasNeuronID].Set_BiasNeuronOutput(1.0f);
		pNeuronArray[BiasNeuronID].Init_OutputSynapses(NumOutputNeurons);
		pNeuronArray[BiasNeuronID].Connect_With_ReceiverNeuron(OutputNeuronID, /*SynapseID:*/ 0);
		pNeuronArray[BiasNeuronID].Randomize_OutputSynapsePlasticities(&RandomNumbers, -0.0001f, 0.0001f);
		pNeuronArray[BiasNeuronID].Set_LearningRate(0.01f);
		

		pNeuronArray[OutputNeuronID].Use_As_OutputNeuron();
		pNeuronArray[OutputNeuronID].Set_ActivationFunction(LinearOutput);
		pNeuronArray[OutputNeuronID].Set_ErrorFactors(1.0f, 0.00025f);
	}

	~C1DimPolynomialFunctionApproxBrain()
	{
		delete[] pNeuronArray;
		pNeuronArray = nullptr;
	}

	// Kopierkonstruktor l�schen:
	C1DimPolynomialFunctionApproxBrain(const C1DimPolynomialFunctionApproxBrain &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	C1DimPolynomialFunctionApproxBrain& operator=(const C1DimPolynomialFunctionApproxBrain &originalObject) = delete;

	float Calculate_Output(float input)
	{
		for (uint32_t i = 0; i < NumHiddenNeurons; i++)
		{
			pNeuronArray[i].Set_NeuronInput(input);
			pNeuronArray[i].Calculate_NeuronOutput();
			pNeuronArray[i].Propagate_SynapticOutput();

		}
		

		pNeuronArray[BiasNeuronID].Propagate_SynapticOutput();

		pNeuronArray[OutputNeuronID].Calculate_NeuronOutput();
		return pNeuronArray[OutputNeuronID].Get_NeuronOutput();
	}

	float Learning(float desiredOutput)
	{
		float error = pNeuronArray[OutputNeuronID].Calculate_Error(desiredOutput);

		pNeuronArray[BiasNeuronID].Adjust_OutputSynapses_AfterErrorCalculations();

		for (uint32_t i = 0; i < NumHiddenNeurons; i++)
		{
			pNeuronArray[i].Adjust_OutputSynapses_AfterErrorCalculations();
		}
		
		return error;
	}

}; // end of class C1DimPolynomialFunctionApproxBrain

/*
int main(void)
{
	C1DimPolynomialFunctionApproxBrain Brain;

	static constexpr uint32_t NumInputValues = 9;

	float InputData[NumInputValues];

	InputData[0] = -4.0f;
	InputData[1] = -3.0f;
	InputData[2] = -2.0f;
	InputData[3] = -1.0f;
	InputData[4] = 0.0f;
	InputData[5] = 1.0f;
	InputData[6] = 2.0f;
	InputData[7] = 3.0f;
	InputData[8] = 4.0f;


	// Output = (a * Input * Input * Input + b * Input * Input + c * Input + offset)


	float a = 0.5f;
	float b = 0.65f;
	float c = 0.85f;
	float offset = 1.0f;

	//float a = 0.5f;
	//float b = 1.65f;
	//float c = -0.85f;
	//float offset = 1.0f;


	uint32_t maxCount = 200000;
	uint32_t epoch = 0;
	float error = 0.0f;

	// start training:

	for (uint32_t i = 0; i < maxCount; i++)
	{
		epoch++;
		error = 0.0f;

		for (uint32_t j = 0; j < NumInputValues; j++)
		{
			Brain.Calculate_Output(InputData[j]);
			float desiredOutput = a * InputData[j] * InputData[j] * InputData[j] + b * InputData[j] * InputData[j] + c * InputData[j] + offset;
			error += Brain.Learning(desiredOutput);
		}

		if (error < 0.001f)
			break;
	}

	// training completed

	// training statistics:

	cout << "epoch: " << epoch << endl;
	cout << "error: " << error << endl << endl;

	// neural network tests:

	for (uint32_t j = 0; j < NumInputValues; j++)
	{
		cout << "input : " << InputData[j] << endl;
		cout << "output: " << Brain.Calculate_Output(InputData[j]) << " --- desired output: " << a * InputData[j] * InputData[j] * InputData[j] + b * InputData[j] * InputData[j] + c * InputData[j] + offset << endl;
	}

	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CNeuralNet Brain;
	Brain.Init_NeuralNet(6);
	Brain.Init_Input_And_OutputNeurons(1, 0.01f, false, 1, LinearOutput, 1.0f, 0.00025f);
	Brain.Init_HiddenLayer1(3, true, true, nullptr, -0.0001f, 0.0001f, 1.0f, 1.0f, 0.0001f);

	Brain.Set_Activationfunction_HiddenLayer1Neuron(LinearOutput, 0);
	Brain.Set_Activationfunction_HiddenLayer1Neuron(QuadraticOutput, 1);
	Brain.Set_Activationfunction_HiddenLayer1Neuron(CubicOutput, 2);
	
	

	static constexpr uint32_t NumInputValues = 9;

	float InputData[NumInputValues];

	InputData[0] = -4.0f;
	InputData[1] = -3.0f;
	InputData[2] = -2.0f;
	InputData[3] = -1.0f;
	InputData[4] = 0.0f;
	InputData[5] = 1.0f;
	InputData[6] = 2.0f;
	InputData[7] = 3.0f;
	InputData[8] = 4.0f;


	// Output = (a * Input * Input * Input + b * Input * Input + c * Input + offset)


	float a = 0.5f;
	float b = 0.65f;
	float c = 0.85f;
	float offset = 1.0f;



	uint32_t maxCount = 200000;
	uint32_t epoch = 0;
	float error = 0.0f;

	// start training:

	uint64_t seed = 1;

	float outputValue;
	float desiredOutput;

	for (uint32_t i = 0; i < maxCount; i++)
	{
		epoch++;
		error = 0.0f;

		for (uint32_t j = 0; j < NumInputValues; j++)
		{
			//Brain.Set_InputValues_HiddenLayer1(InputData[j]);
			//Brain.Calculate_Output_IgnoreInputNeurons(&outputValue);

			Brain.Calculate_Output(&outputValue, &InputData[j]);

			desiredOutput = a * InputData[j] * InputData[j] * InputData[j] + b * InputData[j] * InputData[j] + c * InputData[j] + offset;
			error += Brain.ExtremeLearning(&desiredOutput);
		}

		
		if (error < 0.001f)
			break;

		// etwas Mutation (hilfreich, um einem eventuellen lokalen Fehlerminimum zu entkommen)
		// In unserem Fall wird der Lernvorgang sogar ein wenig beschleunigt!
		Brain.RandomChange_OutputSynapsePlasticities2_HiddenLayer1(seed++, -0.005f, 0.005f, 0.5f);
	}

	// training completed

	// training statistics:

	cout << "epoch: " << epoch << endl;
	cout << "error: " << error << endl << endl;

	// neural network tests:

	for (uint32_t j = 0; j < NumInputValues; j++)
	{
		cout << "input : " << InputData[j] << endl;
		//Brain.Set_InputValues_HiddenLayer1(InputData[j]);
		//Brain.Calculate_Output_IgnoreInputNeurons(&outputValue);

		Brain.Calculate_Output(&outputValue, &InputData[j]);

		cout << "output: " << outputValue << " --- desired output: " << a * InputData[j] * InputData[j] * InputData[j] + b * InputData[j] * InputData[j] + c * InputData[j] + offset << endl;
	}

	getchar();
	return 0;
}
*/