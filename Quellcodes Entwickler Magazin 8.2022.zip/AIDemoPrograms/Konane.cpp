#include "Konane.h"

using namespace std;
using namespace HelperStuff;

#ifndef max
#define max(a,b)    ( ((a) > (b)) ? (a) : (b) )
#endif

#ifndef min
#define min(a,b)    ( ((a) < (b)) ? (a) : (b) )
#endif

#define PRUNING





void Calculate_KonaneScore(int32_t* pOutPlayer1Score, int32_t* pOutPlayer2Score, int8_t* pInGameData)
{
	int32_t player1Score = 0;
	int32_t player2Score = 0;

	int8_t value;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		value = pInGameData[i];

		if (value == ConstGameBoard_Player1)
		{
			player1Score++;
		}
		else if (value == ConstGameBoard_Player2)
		{
			player2Score++;
		}
	}

	*pOutPlayer1Score = player1Score;
	*pOutPlayer2Score = player2Score;
}

void Calculate_CheckersKonaneScore(int32_t* pOutPlayer1Score, int32_t* pOutPlayer2Score, int8_t* pInGameData)
{
	int32_t player1Score = 0;
	int32_t player2Score = 0;

	int8_t value;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		value = pInGameData[i];

		if (value == ConstGameBoard_Player1_Man)
		{
			player1Score++;
			continue;
		}
		if (value == ConstGameBoard_Player1_King)
		{
			player1Score += 2;
			continue;
		}
		if (value == ConstGameBoard_Player2_Man)
		{
			player2Score++;
			continue;
		}
		if (value == ConstGameBoard_Player2_King)
		{
			player2Score += 2;
			continue;
		}
		
	}

	*pOutPlayer1Score = player1Score;
	*pOutPlayer2Score = player2Score;
}

void Calculate_KonanePlayer1Score(int32_t* pOutPlayer1Score, int8_t* pInGameData)
{
	int32_t player1Score = 0;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pInGameData[i] == ConstGameBoard_Player1)
		{
			player1Score++;
		}
	}

	*pOutPlayer1Score = player1Score;
}

void Calculate_CheckersKonanePlayer1Score(int32_t* pOutPlayer1Score, int8_t* pInGameData)
{
	int32_t player1Score = 0;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pInGameData[i] == ConstGameBoard_Player1_Man)
		{
			player1Score++;
			continue;
		}

		if (pInGameData[i] == ConstGameBoard_Player1_King)
		{
			player1Score += 2;
			continue;
		}
	}

	*pOutPlayer1Score = player1Score;
}

void Calculate_KonanePlayer2Score(int32_t* pOutPlayer2Score, int8_t* pInGameData)
{

	int32_t player2Score = 0;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pInGameData[i] == ConstGameBoard_Player2)
		{
			player2Score++;
		}
	}


	*pOutPlayer2Score = player2Score;
}

void Calculate_CheckersKonanePlayer2Score(int32_t* pOutPlayer2Score, int8_t* pInGameData)
{

	int32_t player2Score = 0;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pInGameData[i] == ConstGameBoard_Player2_Man)
		{
			player2Score++;
			continue;
		}

		if (pInGameData[i] == ConstGameBoard_Player2_King)
		{
			player2Score += 2;
			continue;
		}
	}


	*pOutPlayer2Score = player2Score;
}

bool Check_PossibleKonanePlayer1Moves(int8_t* pInGameData)
{
	//static int8_t GameData[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];

	int32_t player1Alive = false;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pInGameData[i] == ConstGameBoard_Player1)
		{
			player1Alive = true;
			break;
		}
	}

	if (player1Alive == false)
	{
		return false;
	}

	/*for (int32_t iy = 0; iy < ConstGameBoardSizePerDir; iy++)
	{
		int32_t iiy = iy * ConstGameBoardSizePerDir;

		for (int32_t ix = 0; ix < ConstGameBoardSizePerDir; ix++)
		{
			GameData[iy][ix] = pInGameData[ix + iiy];
		}
	}*/

	//bool moveFound = false;

	for (int32_t iy = 0; iy < ConstGameBoardSizePerDir; iy++)
	{
		int32_t iyy = iy * ConstGameBoardSizePerDir;

		for (int32_t ix = 0; ix < ConstGameBoardSizePerDir; ix++)
		{
			if (pInGameData[ix + iyy] == ConstGameBoard_Player1)
			//if (GameData[iy][ix] == ConstGameBoard_Player1)
			{
				if (ix > 1)
				{
					// jump left:
					if (pInGameData[ix - 1 + iyy] == ConstGameBoard_Player2)
					//if (GameData[iy][ix - 1] == ConstGameBoard_Player2)
					{
						if (pInGameData[ix - 2 + iyy] == ConstGameBoard_Empty)
						//if (GameData[iy][ix - 2] == ConstGameBoard_Empty)
						{
							//moveFound = true;
							return true;
						}
					}
				}

				// jump up:
				if (iy > 1)
				{
					if (pInGameData[ix + (iy - 1) * ConstGameBoardSizePerDir] == ConstGameBoard_Player2)
					//if (GameData[iy - 1][ix] == ConstGameBoard_Player2)
					{
						if (pInGameData[ix + (iy - 2) * ConstGameBoardSizePerDir] == ConstGameBoard_Empty)
						//if (GameData[iy - 2][ix] == ConstGameBoard_Empty)
						{
							//moveFound = true;
							return true;
						}
					}
				}

				// jump right:
				if (ix < ConstGameBoardSizePerDirMinus2)
				{
					if (pInGameData[ix + 1 + iyy] == ConstGameBoard_Player2)
					//if (GameData[iy][ix + 1] == ConstGameBoard_Player2)
					{
						if (pInGameData[ix + 2 + iyy] == ConstGameBoard_Empty)
						//if (GameData[iy][ix + 2] == ConstGameBoard_Empty)
						{
							//moveFound = true;
							return true;
						}
					}
				}

				// jump down:
				if (iy < ConstGameBoardSizePerDirMinus2)
				{
					if (pInGameData[ix + (iy + 1) * ConstGameBoardSizePerDir] == ConstGameBoard_Player2)
					//if (GameData[iy + 1][ix] == ConstGameBoard_Player2)
					{
						if (pInGameData[ix + (iy + 2) * ConstGameBoardSizePerDir] == ConstGameBoard_Empty)
						//if (GameData[iy + 2][ix] == ConstGameBoard_Empty)
						{
							//moveFound = true;
							return true;
						}
					}
				}
			} // end of if (pInGameData[ix + iyy] == ConstGameBoard_Player1)
		} // end of for (int32_t ix = 0; ix < ConstGameBoardSizePerDir; ix++)
	} // end of for (int32_t iy = 0; iy < ConstGameBoardSizePerDir; iy++)


	return false;
}

bool Check_PossibleCheckersKonanePlayer1Moves(int8_t* pInGameData, CMovePatternList* pMoveList)
{
	//static int8_t GameData[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];

	int32_t player1Alive = false;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pInGameData[i] == ConstGameBoard_Player1_Man)
		{
			player1Alive = true;
			break;
		}
		if (pInGameData[i] == ConstGameBoard_Player1_King)
		{
			player1Alive = true;
			break;
		}
	}

	if (player1Alive == false)
	{
		return false;
	}

	int32_t numOfPossibleMoves = pMoveList->NumOfMoves;

	for (int32_t iy = 0; iy < ConstGameBoardSizePerDir; iy++)
	{
		int32_t iyy = iy * ConstGameBoardSizePerDir;

		for (int32_t ix = 0; ix < ConstGameBoardSizePerDir; ix++)
		{
			int32_t posID = ix + iyy;

			for (int32_t moveCounter = 0; moveCounter < numOfPossibleMoves; moveCounter++)
			{
				if (pMoveList->pMoveArray[moveCounter].Validate_PossibleMove(ix, iy, posID, pInGameData) == true)
					return true;
			}
		}
	}

	/*for (int32_t iy = 0; iy < ConstGameBoardSizePerDir; iy++)
	{
		int32_t iiy = iy * ConstGameBoardSizePerDir;

		for (int32_t ix = 0; ix < ConstGameBoardSizePerDir; ix++)
		{
			GameData[iy][ix] = pInGameData[ix + iiy];
		}
	}*/

	//bool moveFound = false;
	/*
	for (int32_t iy = 0; iy < ConstGameBoardSizePerDir; iy++)
	{
		int32_t iyy = iy * ConstGameBoardSizePerDir;

		for (int32_t ix = 0; ix < ConstGameBoardSizePerDir; ix++)
		{
			if (pInGameData[ix + iyy] == ConstGameBoard_Player1)
				//if (GameData[iy][ix] == ConstGameBoard_Player1)
			{
				if (ix > 1)
				{
					// jump left:
					if (pInGameData[ix - 1 + iyy] == ConstGameBoard_Player2)
						//if (GameData[iy][ix - 1] == ConstGameBoard_Player2)
					{
						if (pInGameData[ix - 2 + iyy] == ConstGameBoard_Empty)
							//if (GameData[iy][ix - 2] == ConstGameBoard_Empty)
						{
							//moveFound = true;
							return true;
						}
					}
				}

				// jump up:
				if (iy > 1)
				{
					if (pInGameData[ix + (iy - 1) * ConstGameBoardSizePerDir] == ConstGameBoard_Player2)
						//if (GameData[iy - 1][ix] == ConstGameBoard_Player2)
					{
						if (pInGameData[ix + (iy - 2) * ConstGameBoardSizePerDir] == ConstGameBoard_Empty)
							//if (GameData[iy - 2][ix] == ConstGameBoard_Empty)
						{
							//moveFound = true;
							return true;
						}
					}
				}

				// jump right:
				if (ix < ConstGameBoardSizePerDirMinus2)
				{
					if (pInGameData[ix + 1 + iyy] == ConstGameBoard_Player2)
						//if (GameData[iy][ix + 1] == ConstGameBoard_Player2)
					{
						if (pInGameData[ix + 2 + iyy] == ConstGameBoard_Empty)
							//if (GameData[iy][ix + 2] == ConstGameBoard_Empty)
						{
							//moveFound = true;
							return true;
						}
					}
				}

				// jump down:
				if (iy < ConstGameBoardSizePerDirMinus2)
				{
					if (pInGameData[ix + (iy + 1) * ConstGameBoardSizePerDir] == ConstGameBoard_Player2)
						//if (GameData[iy + 1][ix] == ConstGameBoard_Player2)
					{
						if (pInGameData[ix + (iy + 2) * ConstGameBoardSizePerDir] == ConstGameBoard_Empty)
							//if (GameData[iy + 2][ix] == ConstGameBoard_Empty)
						{
							//moveFound = true;
							return true;
						}
					}
				}
			} // end of if (pInGameData[ix + iyy] == ConstGameBoard_Player1)
		} // end of for (int32_t ix = 0; ix < ConstGameBoardSizePerDir; ix++)
	} // end of for (int32_t iy = 0; iy < ConstGameBoardSizePerDir; iy++)
	*/

	return false;
}

bool Check_PossibleKonanePlayer2Moves(int8_t* pInGameData)
{
	//static int8_t GameData[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];

	int32_t player2Alive = false;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pInGameData[i] == ConstGameBoard_Player2)
		{
			player2Alive = true;
			break;
		}
	}

	if (player2Alive == false)
	{
		return false;
	}

	/*for (int32_t iy = 0; iy < ConstGameBoardSizePerDir; iy++)
	{
		int32_t iiy = iy * ConstGameBoardSizePerDir;

		for (int32_t ix = 0; ix < ConstGameBoardSizePerDir; ix++)
		{
			GameData[iy][ix] = pInGameData[ix + iiy];
		}
	}*/

	//bool moveFound = false;

	for (int32_t iy = 0; iy < ConstGameBoardSizePerDir; iy++)
	{
		int32_t iyy = iy * ConstGameBoardSizePerDir;

		for (int32_t ix = 0; ix < ConstGameBoardSizePerDir; ix++)
		{
			if (pInGameData[ix + iyy] == ConstGameBoard_Player2)
				//if (GameData[iy][ix] == ConstGameBoard_Player2)
			{
				if (ix > 1)
				{
					// jump left:
					if (pInGameData[ix - 1 + iyy] == ConstGameBoard_Player1)
						//if (GameData[iy][ix - 1] == ConstGameBoard_Player1)
					{
						if (pInGameData[ix - 2 + iyy] == ConstGameBoard_Empty)
							//if (GameData[iy][ix - 2] == ConstGameBoard_Empty)
						{
							//moveFound = true;
							return true;
						}
					}
				}

				// jump up:
				if (iy > 1)
				{
					if (pInGameData[ix + (iy - 1) * ConstGameBoardSizePerDir] == ConstGameBoard_Player1)
						//if (GameData[iy - 1][ix] == ConstGameBoard_Player1)
					{
						if (pInGameData[ix + (iy - 2) * ConstGameBoardSizePerDir] == ConstGameBoard_Empty)
							//if (GameData[iy - 2][ix] == ConstGameBoard_Empty)
						{
							//moveFound = true;
							return true;
						}
					}
				}

				// jump right:
				if (ix < ConstGameBoardSizePerDirMinus2)
				{
					if (pInGameData[ix + 1 + iyy] == ConstGameBoard_Player1)
						//if (GameData[iy][ix + 1] == ConstGameBoard_Player1)
					{
						if (pInGameData[ix + 2 + iyy] == ConstGameBoard_Empty)
							//if (GameData[iy][ix + 2] == ConstGameBoard_Empty)
						{
							//moveFound = true;
							return true;
						}
					}
				}

				// jump down:
				if (iy < ConstGameBoardSizePerDirMinus2)
				{
					if (pInGameData[ix + (iy + 1) * ConstGameBoardSizePerDir] == ConstGameBoard_Player1)
						//if (GameData[iy + 1][ix] == ConstGameBoard_Player1)
					{
						if (pInGameData[ix + (iy + 2) * ConstGameBoardSizePerDir] == ConstGameBoard_Empty)
							//if (GameData[iy + 2][ix] == ConstGameBoard_Empty)
						{
							//moveFound = true;
							return true;
						}
					}
				}
			} // end of if (pInGameData[ix + iyy] == ConstGameBoard_Player2)
		} // end of for (int32_t ix = 0; ix < ConstGameBoardSizePerDir; ix++)
	} // end of for (int32_t iy = 0; iy < ConstGameBoardSizePerDir; iy++)


	return false;
}

bool Check_PossibleCheckersKonanePlayer2Moves(int8_t* pInGameData, CMovePatternList* pMoveList)
{
	//static int8_t GameData[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];

	int32_t player2Alive = false;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pInGameData[i] == ConstGameBoard_Player2_Man)
		{
			player2Alive = true;
			break;
		}
		if (pInGameData[i] == ConstGameBoard_Player2_King)
		{
			player2Alive = true;
			break;
		}
	}

	if (player2Alive == false)
	{
		return false;
	}

	int32_t numOfPossibleMoves = pMoveList->NumOfMoves;

	for (int32_t iy = 0; iy < ConstGameBoardSizePerDir; iy++)
	{
		int32_t iyy = iy * ConstGameBoardSizePerDir;

		for (int32_t ix = 0; ix < ConstGameBoardSizePerDir; ix++)
		{
			int32_t posID = ix + iyy;

			for (int32_t moveCounter = 0; moveCounter < numOfPossibleMoves; moveCounter++)
			{
				if (pMoveList->pMoveArray[moveCounter].Validate_PossibleMove(ix, iy, posID, pInGameData) == true)
					return true;
			}
		}
	}

	/*for (int32_t iy = 0; iy < ConstGameBoardSizePerDir; iy++)
	{
		int32_t iiy = iy * ConstGameBoardSizePerDir;

		for (int32_t ix = 0; ix < ConstGameBoardSizePerDir; ix++)
		{
			GameData[iy][ix] = pInGameData[ix + iiy];
		}
	}*/

	//bool moveFound = false;

	/*for (int32_t iy = 0; iy < ConstGameBoardSizePerDir; iy++)
	{
		int32_t iyy = iy * ConstGameBoardSizePerDir;

		for (int32_t ix = 0; ix < ConstGameBoardSizePerDir; ix++)
		{
			if (pInGameData[ix + iyy] == ConstGameBoard_Player2)
				//if (GameData[iy][ix] == ConstGameBoard_Player2)
			{
				if (ix > 1)
				{
					// jump left:
					if (pInGameData[ix - 1 + iyy] == ConstGameBoard_Player1)
						//if (GameData[iy][ix - 1] == ConstGameBoard_Player1)
					{
						if (pInGameData[ix - 2 + iyy] == ConstGameBoard_Empty)
							//if (GameData[iy][ix - 2] == ConstGameBoard_Empty)
						{
							//moveFound = true;
							return true;
						}
					}
				}

				// jump up:
				if (iy > 1)
				{
					if (pInGameData[ix + (iy - 1) * ConstGameBoardSizePerDir] == ConstGameBoard_Player1)
						//if (GameData[iy - 1][ix] == ConstGameBoard_Player1)
					{
						if (pInGameData[ix + (iy - 2) * ConstGameBoardSizePerDir] == ConstGameBoard_Empty)
							//if (GameData[iy - 2][ix] == ConstGameBoard_Empty)
						{
							//moveFound = true;
							return true;
						}
					}
				}

				// jump right:
				if (ix < ConstGameBoardSizePerDirMinus2)
				{
					if (pInGameData[ix + 1 + iyy] == ConstGameBoard_Player1)
						//if (GameData[iy][ix + 1] == ConstGameBoard_Player1)
					{
						if (pInGameData[ix + 2 + iyy] == ConstGameBoard_Empty)
							//if (GameData[iy][ix + 2] == ConstGameBoard_Empty)
						{
							//moveFound = true;
							return true;
						}
					}
				}

				// jump down:
				if (iy < ConstGameBoardSizePerDirMinus2)
				{
					if (pInGameData[ix + (iy + 1) * ConstGameBoardSizePerDir] == ConstGameBoard_Player1)
						//if (GameData[iy + 1][ix] == ConstGameBoard_Player1)
					{
						if (pInGameData[ix + (iy + 2) * ConstGameBoardSizePerDir] == ConstGameBoard_Empty)
							//if (GameData[iy + 2][ix] == ConstGameBoard_Empty)
						{
							//moveFound = true;
							return true;
						}
					}
				}
			} // end of if (pInGameData[ix + iyy] == ConstGameBoard_Player2)
		} // end of for (int32_t ix = 0; ix < ConstGameBoardSizePerDir; ix++)
	} // end of for (int32_t iy = 0; iy < ConstGameBoardSizePerDir; iy++)
	*/

	return false;
}



void Evaluate_GameState_KonanePlayer1View(int32_t gameStateID, CExtendedGameStatePool* pGameStatePool)
{
	/*if (pGameStatePool->pGameStateArray[gameStateID].LeafNode == false)
	{
		return;
	}*/

	if (Check_PossibleKonanePlayer1Moves(&pGameStatePool->pGameStateArray[gameStateID].pValueArray[0]) == false)
	{
		pGameStatePool->pGameStateArray[gameStateID].iEvaluation = ConstMinEvaluationScore_Minimax;
		return;
	}
	if (Check_PossibleKonanePlayer2Moves(&pGameStatePool->pGameStateArray[gameStateID].pValueArray[0]) == false)
	{
		pGameStatePool->pGameStateArray[gameStateID].iEvaluation = ConstMaxEvaluationScore_Minimax;
		return;
	}

	int32_t Player1Score, Player2Score;

	Calculate_KonaneScore(&Player1Score, &Player2Score, &pGameStatePool->pGameStateArray[gameStateID].pValueArray[0]);

	if (Player1Score > 0 && Player2Score == 0)
	{
		pGameStatePool->pGameStateArray[gameStateID].iEvaluation = ConstMaxEvaluationScore_Minimax;
	}
	else if (Player1Score == 0 && Player2Score > 0)
	{
		pGameStatePool->pGameStateArray[gameStateID].iEvaluation = ConstMinEvaluationScore_Minimax;
	}
	else
	{
		pGameStatePool->pGameStateArray[gameStateID].iEvaluation = Player1Score - Player2Score;
	}
}

void Evaluate_GameState_CheckersKonanePlayer1View(int32_t gameStateID, CExtendedGameStatePool* pGameStatePool, CMovePatternList* pPlayer1MoveList, CMovePatternList* pPlayer2MoveList)
{
	/*if (pGameStatePool->pGameStateArray[gameStateID].LeafNode == false)
	{
		return;
	}*/

	if (Check_PossibleCheckersKonanePlayer1Moves(&pGameStatePool->pGameStateArray[gameStateID].pValueArray[0], pPlayer1MoveList) == false)
	{
		pGameStatePool->pGameStateArray[gameStateID].iEvaluation = ConstMinEvaluationScore_Minimax;
		return;
	}
	if (Check_PossibleCheckersKonanePlayer2Moves(&pGameStatePool->pGameStateArray[gameStateID].pValueArray[0], pPlayer2MoveList) == false)
	{
		pGameStatePool->pGameStateArray[gameStateID].iEvaluation = ConstMaxEvaluationScore_Minimax;
		return;
	}

	int32_t Player1Score, Player2Score;

	Calculate_CheckersKonaneScore(&Player1Score, &Player2Score, &pGameStatePool->pGameStateArray[gameStateID].pValueArray[0]);

	if (Player1Score > 0 && Player2Score == 0)
	{
		pGameStatePool->pGameStateArray[gameStateID].iEvaluation = ConstMaxEvaluationScore_Minimax;
	}
	else if (Player1Score == 0 && Player2Score > 0)
	{
		pGameStatePool->pGameStateArray[gameStateID].iEvaluation = ConstMinEvaluationScore_Minimax;
	}
	else
	{
		pGameStatePool->pGameStateArray[gameStateID].iEvaluation = Player1Score - Player2Score;
	}
}



void Check_KonaneLeafGameStates(CExtendedGameStatePool* pGameStatePool)
{
	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;

	for (int32_t i = numOfDepthLayersMax - 1; i > -1; i--)
	{
		CSimpleLinkedListManager* pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[i];
		int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
		int32_t id = 0;

		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);

			if (i == 2 && pGameStatePool->pGameStateArray[id].LeafNode == true)
				Add_To_Log(0, "LeafNode ok ", id);

			if (i == 2 && pGameStatePool->pGameStateArray[id].LeafNode == false)
				Add_To_Log(0, "must be LeafNode");
			if (i != 2 && pGameStatePool->pGameStateArray[id].LeafNode == true)
				Add_To_Log(0, "shound not be LeafNode", i);

			/*if (pGameStatePool->pGameStateArray[id].LeafNode == true)
			{
				if (pGameStatePool->pGameStateArray[id].iEvaluation == -2000000)
				{
					Add_To_Log(0, "Problem1 (1)", id);
					Add_To_Log(0, "Problem1 (2)", i);
				}
			}
			else
			{
				if (pGameStatePool->pGameStateArray[id].iEvaluation != -2000000)
				{
					Add_To_Log(0, "Problem2 (1)", id);
					Add_To_Log(0, "Problem2 (2)", i);
				}
			}*/
		}
	}
}

void Evaluate_LeafGameStates_KonanePlayer1View(CExtendedGameStatePool* pGameStatePool, int32_t depth)
{
	int32_t Player1Score, Player2Score;

	CSimpleLinkedListManager* pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[depth];
	int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	int32_t id = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);

		if (pGameStatePool->pGameStateArray[id].LeafNode == false)
		{
			continue;
		}

		if (Check_PossibleKonanePlayer1Moves(&pGameStatePool->pGameStateArray[id].pValueArray[0]) == false)
		{
			pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
			continue;
		}
		if (Check_PossibleKonanePlayer2Moves(&pGameStatePool->pGameStateArray[id].pValueArray[0]) == false)
		{
			pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
			continue;
		}

		Calculate_KonaneScore(&Player1Score, &Player2Score, &pGameStatePool->pGameStateArray[id].pValueArray[0]);

		if (Player1Score > 0 && Player2Score == 0)
		{
			pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
		}
		else if (Player1Score == 0 && Player2Score > 0)
		{
			pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
		}
		else
		{
			pGameStatePool->pGameStateArray[id].iEvaluation = Player1Score - Player2Score;
		}

	}
}

void Evaluate_LeafGameStates_CheckersKonanePlayer1View(CExtendedGameStatePool* pGameStatePool, int32_t depth, CMovePatternList* pPlayer1MoveList, CMovePatternList* pPlayer2MoveList)
{
	int32_t Player1Score, Player2Score;

	CSimpleLinkedListManager* pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[depth];
	int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	int32_t id = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);

		if (pGameStatePool->pGameStateArray[id].LeafNode == false)
		{
			continue;
		}

		if (Check_PossibleCheckersKonanePlayer1Moves(&pGameStatePool->pGameStateArray[id].pValueArray[0], pPlayer1MoveList) == false)
		{
			pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
			continue;
		}
		if (Check_PossibleCheckersKonanePlayer2Moves(&pGameStatePool->pGameStateArray[id].pValueArray[0], pPlayer2MoveList) == false)
		{
			pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
			continue;
		}

		Calculate_CheckersKonaneScore(&Player1Score, &Player2Score, &pGameStatePool->pGameStateArray[id].pValueArray[0]);

		if (Player1Score > 0 && Player2Score == 0)
		{
			pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
		}
		else if (Player1Score == 0 && Player2Score > 0)
		{
			pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
		}
		else
		{
			pGameStatePool->pGameStateArray[id].iEvaluation = Player1Score - Player2Score;
		}

	}
}

void Evaluate_LeafGameStates_KonanePlayer2View(CExtendedGameStatePool* pGameStatePool, int32_t depth)
{
	int32_t Player1Score, Player2Score;

	CSimpleLinkedListManager* pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[depth];
	int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	int32_t id = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);

		if (pGameStatePool->pGameStateArray[id].LeafNode == false)
		{
			continue;
		}

		if (Check_PossibleKonanePlayer2Moves(&pGameStatePool->pGameStateArray[id].pValueArray[0]) == false)
		{
			pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
			continue;
		}
		if (Check_PossibleKonanePlayer1Moves(&pGameStatePool->pGameStateArray[id].pValueArray[0]) == false)
		{
			pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
			continue;
		}

		Calculate_KonaneScore(&Player1Score, &Player2Score, &pGameStatePool->pGameStateArray[id].pValueArray[0]);

		if (Player1Score > 0 && Player2Score == 0)
		{
			pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
		}
		else if (Player1Score == 0 && Player2Score > 0)
		{
			pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
		}
		else
		{
			pGameStatePool->pGameStateArray[id].iEvaluation = Player2Score - Player1Score;
		}

	}
}

void Evaluate_LeafGameStates_CheckersKonanePlayer2View(CExtendedGameStatePool* pGameStatePool, int32_t depth, CMovePatternList* pPlayer1MoveList, CMovePatternList* pPlayer2MoveList)
{
	int32_t Player1Score, Player2Score;

	CSimpleLinkedListManager* pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[depth];
	int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	int32_t id = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);

		if (pGameStatePool->pGameStateArray[id].LeafNode == false)
		{
			continue;
		}

		if (Check_PossibleCheckersKonanePlayer2Moves(&pGameStatePool->pGameStateArray[id].pValueArray[0], pPlayer2MoveList) == false)
		{
			pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
			continue;
		}
		if (Check_PossibleCheckersKonanePlayer1Moves(&pGameStatePool->pGameStateArray[id].pValueArray[0], pPlayer1MoveList) == false)
		{
			pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
			continue;
		}

		Calculate_CheckersKonaneScore(&Player1Score, &Player2Score, &pGameStatePool->pGameStateArray[id].pValueArray[0]);

		if (Player1Score > 0 && Player2Score == 0)
		{
			pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
		}
		else if (Player1Score == 0 && Player2Score > 0)
		{
			pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
		}
		else
		{
			pGameStatePool->pGameStateArray[id].iEvaluation = Player2Score - Player1Score;
		}

	}
}

void Evaluate_LeafGameStates_KonanePlayer1View(CExtendedGameStatePool* pGameStatePool)
{
	int32_t Player1Score, Player2Score;

	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;

	for (int32_t i = numOfDepthLayersMax - 1; i > -1; i--)
	{
		CSimpleLinkedListManager* pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[i];
		int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
		int32_t id = 0;

		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);

			if (pGameStatePool->pGameStateArray[id].LeafNode == false)
			{
				continue;
			}

			if (Check_PossibleKonanePlayer1Moves(&pGameStatePool->pGameStateArray[id].pValueArray[0]) == false)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
				continue;
			}
			if (Check_PossibleKonanePlayer2Moves(&pGameStatePool->pGameStateArray[id].pValueArray[0]) == false)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
				continue;
			}
			
			Calculate_KonaneScore(&Player1Score, &Player2Score, &pGameStatePool->pGameStateArray[id].pValueArray[0]);

			if (Player1Score > 0 && Player2Score == 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
			}
			else if (Player1Score == 0 && Player2Score > 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
			}
			else
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = Player1Score - Player2Score;
			}

		} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)
	} // end of for (int32_t i = numOfDepthLayersMax - 1; i > -1; i--)
}

void Evaluate_LeafGameStates_CheckersKonanePlayer1View(CExtendedGameStatePool* pGameStatePool, CMovePatternList* pPlayer1MoveList, CMovePatternList* pPlayer2MoveList)
{
	int32_t Player1Score, Player2Score;

	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;

	for (int32_t i = numOfDepthLayersMax - 1; i > -1; i--)
	{
		CSimpleLinkedListManager* pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[i];
		int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
		int32_t id = 0;

		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);

			if (pGameStatePool->pGameStateArray[id].LeafNode == false)
			{
				continue;
			}

			if (Check_PossibleCheckersKonanePlayer1Moves(&pGameStatePool->pGameStateArray[id].pValueArray[0], pPlayer1MoveList) == false)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
				continue;
			}
			if (Check_PossibleCheckersKonanePlayer2Moves(&pGameStatePool->pGameStateArray[id].pValueArray[0], pPlayer2MoveList) == false)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
				continue;
			}

			Calculate_CheckersKonaneScore(&Player1Score, &Player2Score, &pGameStatePool->pGameStateArray[id].pValueArray[0]);

			if (Player1Score > 0 && Player2Score == 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
			}
			else if (Player1Score == 0 && Player2Score > 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
			}
			else
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = Player1Score - Player2Score;
			}

		} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)
	} // end of for (int32_t i = numOfDepthLayersMax - 1; i > -1; i--)
}

void Evaluate_GameStates_KonanePlayer1View(CExtendedGameStatePool* pGameStatePool)
{
	int32_t Player1Score, Player2Score;

	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;
	int32_t numOfDepthLayersMaxMinus1 = numOfDepthLayersMax - 1;

	for (int32_t i = 0; i < numOfDepthLayersMaxMinus1; i++)
	{
		CSimpleLinkedListManager* pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[i];
		int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
		int32_t id = 0;

		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);

			if (Check_PossibleKonanePlayer1Moves(&pGameStatePool->pGameStateArray[id].pValueArray[0]) == false)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
				continue;
			}
			if (Check_PossibleKonanePlayer2Moves(&pGameStatePool->pGameStateArray[id].pValueArray[0]) == false)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
				continue;
			}

			Calculate_KonaneScore(&Player1Score, &Player2Score, &pGameStatePool->pGameStateArray[id].pValueArray[0]);

			if (Player1Score > 0 && Player2Score == 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
			}
			else if (Player1Score == 0 && Player2Score > 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
			}
			else
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = Player1Score - Player2Score;
			}

		}
	}
}

void Evaluate_GameStates_CheckersKonanePlayer1View(CExtendedGameStatePool* pGameStatePool, CMovePatternList* pPlayer1MoveList, CMovePatternList* pPlayer2MoveList)
{
	int32_t Player1Score, Player2Score;

	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;
	int32_t numOfDepthLayersMaxMinus1 = numOfDepthLayersMax - 1;

	for (int32_t i = 0; i < numOfDepthLayersMaxMinus1; i++)
	{
		CSimpleLinkedListManager* pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[i];
		int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
		int32_t id = 0;

		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);

			if (Check_PossibleCheckersKonanePlayer1Moves(&pGameStatePool->pGameStateArray[id].pValueArray[0], pPlayer1MoveList) == false)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
				continue;
			}
			if (Check_PossibleCheckersKonanePlayer2Moves(&pGameStatePool->pGameStateArray[id].pValueArray[0], pPlayer2MoveList) == false)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
				continue;
			}

			Calculate_CheckersKonaneScore(&Player1Score, &Player2Score, &pGameStatePool->pGameStateArray[id].pValueArray[0]);

			if (Player1Score > 0 && Player2Score == 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
			}
			else if (Player1Score == 0 && Player2Score > 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
			}
			else
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = Player1Score - Player2Score;
			}

		}
	}
}

void Evaluate_GameState_KonanePlayer2View(int32_t gameStateID, CExtendedGameStatePool* pGameStatePool)
{
	/*if (pGameStatePool->pGameStateArray[gameStateID].LeafNode == false)
	{
		return;
	}*/

	if (Check_PossibleKonanePlayer2Moves(&pGameStatePool->pGameStateArray[gameStateID].pValueArray[0]) == false)
	{
		pGameStatePool->pGameStateArray[gameStateID].iEvaluation = ConstMinEvaluationScore_Minimax;
		return;
	}
	if (Check_PossibleKonanePlayer1Moves(&pGameStatePool->pGameStateArray[gameStateID].pValueArray[0]) == false)
	{
		pGameStatePool->pGameStateArray[gameStateID].iEvaluation = ConstMaxEvaluationScore_Minimax;
		return;
	}

	int32_t Player1Score, Player2Score;

	Calculate_KonaneScore(&Player1Score, &Player2Score, &pGameStatePool->pGameStateArray[gameStateID].pValueArray[0]);

	if (Player2Score > 0 && Player1Score == 0)
	{
		pGameStatePool->pGameStateArray[gameStateID].iEvaluation = ConstMaxEvaluationScore_Minimax;
	}
	else if (Player2Score == 0 && Player1Score > 0)
	{
		pGameStatePool->pGameStateArray[gameStateID].iEvaluation = ConstMinEvaluationScore_Minimax;
	}
	else
	{
		pGameStatePool->pGameStateArray[gameStateID].iEvaluation = Player2Score - Player1Score;
	}
}

void Evaluate_GameState_CheckersKonanePlayer2View(int32_t gameStateID, CExtendedGameStatePool* pGameStatePool, CMovePatternList* pPlayer1MoveList, CMovePatternList* pPlayer2MoveList)
{
	/*if (pGameStatePool->pGameStateArray[gameStateID].LeafNode == false)
	{
		return;
	}*/

	if (Check_PossibleCheckersKonanePlayer2Moves(&pGameStatePool->pGameStateArray[gameStateID].pValueArray[0], pPlayer2MoveList) == false)
	{
		pGameStatePool->pGameStateArray[gameStateID].iEvaluation = ConstMinEvaluationScore_Minimax;
		return;
	}
	if (Check_PossibleCheckersKonanePlayer1Moves(&pGameStatePool->pGameStateArray[gameStateID].pValueArray[0], pPlayer1MoveList) == false)
	{
		pGameStatePool->pGameStateArray[gameStateID].iEvaluation = ConstMaxEvaluationScore_Minimax;
		return;
	}

	int32_t Player1Score, Player2Score;

	Calculate_CheckersKonaneScore(&Player1Score, &Player2Score, &pGameStatePool->pGameStateArray[gameStateID].pValueArray[0]);

	if (Player2Score > 0 && Player1Score == 0)
	{
		pGameStatePool->pGameStateArray[gameStateID].iEvaluation = ConstMaxEvaluationScore_Minimax;
	}
	else if (Player2Score == 0 && Player1Score > 0)
	{
		pGameStatePool->pGameStateArray[gameStateID].iEvaluation = ConstMinEvaluationScore_Minimax;
	}
	else
	{
		pGameStatePool->pGameStateArray[gameStateID].iEvaluation = Player2Score - Player1Score;
	}
}

void Evaluate_LeafGameStates_KonanePlayer2View(CExtendedGameStatePool* pGameStatePool)
{
	int32_t Player1Score, Player2Score;

	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;

	for (int32_t i = numOfDepthLayersMax - 1; i > -1; i--)
	{
		CSimpleLinkedListManager* pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[i];
		int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
		int32_t id = 0;

		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);

			if (pGameStatePool->pGameStateArray[id].LeafNode == false)
			{
				continue;
			}

			if (Check_PossibleKonanePlayer2Moves(&pGameStatePool->pGameStateArray[id].pValueArray[0]) == false)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
				continue;
			}
			if (Check_PossibleKonanePlayer1Moves(&pGameStatePool->pGameStateArray[id].pValueArray[0]) == false)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
				continue;
			}

			Calculate_KonaneScore(&Player1Score, &Player2Score, &pGameStatePool->pGameStateArray[id].pValueArray[0]);

			if (Player2Score > 0 && Player1Score == 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
			}
			else if (Player2Score == 0 && Player1Score > 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
			}
			else
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = Player2Score - Player1Score;
			}

		}
	}
}

void Evaluate_LeafGameStates_CheckersKonanePlayer2View(CExtendedGameStatePool* pGameStatePool, CMovePatternList* pPlayer1MoveList, CMovePatternList* pPlayer2MoveList)
{
	int32_t Player1Score, Player2Score;

	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;

	for (int32_t i = numOfDepthLayersMax - 1; i > -1; i--)
	{
		CSimpleLinkedListManager* pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[i];
		int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
		int32_t id = 0;

		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);

			if (pGameStatePool->pGameStateArray[id].LeafNode == false)
			{
				continue;
			}

			if (Check_PossibleCheckersKonanePlayer2Moves(&pGameStatePool->pGameStateArray[id].pValueArray[0], pPlayer2MoveList) == false)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
				continue;
			}
			if (Check_PossibleCheckersKonanePlayer1Moves(&pGameStatePool->pGameStateArray[id].pValueArray[0], pPlayer1MoveList) == false)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
				continue;
			}

			Calculate_CheckersKonaneScore(&Player1Score, &Player2Score, &pGameStatePool->pGameStateArray[id].pValueArray[0]);

			if (Player2Score > 0 && Player1Score == 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
			}
			else if (Player2Score == 0 && Player1Score > 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
			}
			else
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = Player2Score - Player1Score;
			}

		}
	}
}

void Evaluate_GameStates_KonanePlayer2View(CExtendedGameStatePool* pGameStatePool)
{
	int32_t Player1Score, Player2Score;

	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;
	int32_t numOfDepthLayersMaxMinus1 = numOfDepthLayersMax - 1;

	for (int32_t i = 0; i < numOfDepthLayersMaxMinus1; i++)
	{
		CSimpleLinkedListManager* pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[i];
		int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
		int32_t id = 0;

		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);

			if (Check_PossibleKonanePlayer2Moves(&pGameStatePool->pGameStateArray[id].pValueArray[0]) == false)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
				continue;
			}
			if (Check_PossibleKonanePlayer1Moves(&pGameStatePool->pGameStateArray[id].pValueArray[0]) == false)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
				continue;
			}

			Calculate_KonaneScore(&Player1Score, &Player2Score, &pGameStatePool->pGameStateArray[id].pValueArray[0]);

			if (Player2Score > 0 && Player1Score == 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
			}
			else if (Player2Score == 0 && Player1Score > 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
			}
			else
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = Player2Score - Player1Score;
			}
		}
	}
}

void Evaluate_GameStates_CheckersKonanePlayer2View(CExtendedGameStatePool* pGameStatePool, CMovePatternList* pPlayer1MoveList, CMovePatternList* pPlayer2MoveList)
{
	int32_t Player1Score, Player2Score;

	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;
	int32_t numOfDepthLayersMaxMinus1 = numOfDepthLayersMax - 1;

	for (int32_t i = 0; i < numOfDepthLayersMaxMinus1; i++)
	{
		CSimpleLinkedListManager* pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[i];
		int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
		int32_t id = 0;

		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);

			if (Check_PossibleCheckersKonanePlayer2Moves(&pGameStatePool->pGameStateArray[id].pValueArray[0], pPlayer2MoveList) == false)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
				continue;
			}
			if (Check_PossibleCheckersKonanePlayer1Moves(&pGameStatePool->pGameStateArray[id].pValueArray[0], pPlayer1MoveList) == false)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
				continue;
			}

			Calculate_CheckersKonaneScore(&Player1Score, &Player2Score, &pGameStatePool->pGameStateArray[id].pValueArray[0]);

			if (Player2Score > 0 && Player1Score == 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
			}
			else if (Player2Score == 0 && Player1Score > 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
			}
			else
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = Player2Score - Player1Score;
			}
		}
	}
}

/*
CKonaneTestMove::CKonaneTestMove()
{
	for (int32_t i = 0; i < NumOfNonPlayerBoardValuesMax; i++)
	{
		NonPlayer1BoardValueArray[i] = 0;
		NonPlayer2BoardValueArray[i] = 0;
	}
}

CKonaneTestMove::~CKonaneTestMove()
{}

void CKonaneTestMove::Set_GameBoardSizeXDir(int32_t sizeX)
{
	GameBoardSizeXDir = sizeX;
}

void CKonaneTestMove::Set_GameBoardSizeXY(int32_t sizeXY)
{
	GameBoardSizeXY = sizeXY;
}

void CKonaneTestMove::Set_MovePatternLists(CMovePatternList* pPlayer1MoveList, CMovePatternList* pPlayer2MoveList)
{
	pUsedPlayer1MoveList = pPlayer1MoveList;
	pUsedPlayer2MoveList = pPlayer2MoveList;
}

void CKonaneTestMove::Prepare_Move(int32_t boardPosID, int32_t moveID)
{
	BoardPosID = boardPosID;
	MoveID = moveID;
}

int32_t CKonaneTestMove::Player1Move_If_Possible(CGameStateValues** ppOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool* pGameStatePool, int32_t depthLayer, bool resultingGameStateIsMaximizer)
{
	ResultingGameStateObjectID = -1;

	if (BoardPosID >= GameBoardSizeXY)
	{
		*ppOutNewGameState = nullptr;
		return 0;
	}

	int8_t gameStateValue = pInActualGameState->pValueArray[BoardPosID];

	for(int32_t i = 0; i < NumOfNonPlayer1BoardValues; i++)
	{
		if (gameStateValue == NonPlayer1BoardValueArray[i])
		{
			*ppOutNewGameState = nullptr;
			return 0;
		}
	}

	

	int32_t ix = BoardPosID % GameBoardSizeXDir;
	int32_t iy = BoardPosID / GameBoardSizeXDir;

	if (pUsedPlayer1MoveList->Validate_PossibleMove(MoveID, ix, iy, BoardPosID, pInActualGameState) == true)
	{
		CGameStateValues* pOutNewGameState = nullptr;

		if (pGameStatePool->Get_UnusedGameStateObject(depthLayer, &pOutNewGameState, &ResultingGameStateObjectID) == false)
		{
			*ppOutNewGameState = nullptr;
			return -1;
		}

		pOutNewGameState->Clone_GameStateValues(pInActualGameState);

		// test move:
		//pUsedPlayer1MoveList->Make_Move_If_Possible(MoveID, ix, iy, BoardPosID, pOutNewGameState);
		pUsedPlayer1MoveList->Make_Move(MoveID, ix, iy, BoardPosID, pOutNewGameState);
		pOutNewGameState->PlayerID = 0;
		pInActualGameState->LeafNode = false;
		pOutNewGameState->IDofPrevGameState = pInActualGameState->IDofGameState;

		if (resultingGameStateIsMaximizer == true)
		{
			pOutNewGameState->Use_As_Maximizer();
		}
		else
		{
			pOutNewGameState->Use_As_Minimizer();
		}

		*ppOutNewGameState = pOutNewGameState;
		return 1;
	}


	// no move from BoardPosID found:
	*ppOutNewGameState = nullptr;
	return 0;
}

int32_t CKonaneTestMove::Player2Move_If_Possible(CGameStateValues** ppOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool* pGameStatePool, int32_t depthLayer, bool resultingGameStateIsMaximizer)
{
	ResultingGameStateObjectID = -1;

	if (BoardPosID >= GameBoardSizeXY)
	{
		*ppOutNewGameState = nullptr;
		return 0;
	}


	int8_t gameStateValue = pInActualGameState->pValueArray[BoardPosID];

	for (int32_t i = 0; i < NumOfNonPlayer2BoardValues; i++)
	{
		if (gameStateValue == NonPlayer2BoardValueArray[i])
		{
			*ppOutNewGameState = nullptr;
			return 0;
		}
	}

	

	int32_t ix = BoardPosID % GameBoardSizeXDir;
	int32_t iy = BoardPosID / GameBoardSizeXDir;

	if (pUsedPlayer2MoveList->Validate_PossibleMove(MoveID, ix, iy, BoardPosID, pInActualGameState) == true)
	{
		CGameStateValues* pOutNewGameState = nullptr;

		if (pGameStatePool->Get_UnusedGameStateObject(depthLayer, &pOutNewGameState, &ResultingGameStateObjectID) == false)
		{
			*ppOutNewGameState = nullptr;
			return -1;
		}

		pOutNewGameState->Clone_GameStateValues(pInActualGameState);

		// test move:
		//pUsedPlayer2MoveList->Make_Move_If_Possible(MoveID, ix, iy, BoardPosID, pOutNewGameState);
		pUsedPlayer2MoveList->Make_Move(MoveID, ix, iy, BoardPosID, pOutNewGameState);
		pOutNewGameState->PlayerID = 1;
		pInActualGameState->LeafNode = false;
		pOutNewGameState->IDofPrevGameState = pInActualGameState->IDofGameState;

		if (resultingGameStateIsMaximizer == true)
		{
			pOutNewGameState->Use_As_Maximizer();
		}
		else
		{
			pOutNewGameState->Use_As_Minimizer();
		}

		*ppOutNewGameState = pOutNewGameState;
		return 1;
	}


	// no move from BoardPosID found:
	*ppOutNewGameState = nullptr;
	return 0;
}

int32_t CKonaneTestMove::Player1Move_If_Possible(CGameStateValues* pInActualGameState, CExtendedGameStatePool* pGameStatePool, int32_t depthLayer, bool resultingGameStateIsMaximizer)
{
	ResultingGameStateObjectID = -1;

	if (BoardPosID >= GameBoardSizeXY)
	{
		return 0;
	}

	int8_t gameStateValue = pInActualGameState->pValueArray[BoardPosID];

	for (int32_t i = 0; i < NumOfNonPlayer1BoardValues; i++)
	{
		if (gameStateValue == NonPlayer1BoardValueArray[i])
		{
			return 0;
		}
	}

	

	int32_t ix = BoardPosID % GameBoardSizeXDir;
	int32_t iy = BoardPosID / GameBoardSizeXDir;

	if (pUsedPlayer1MoveList->Validate_PossibleMove(MoveID, ix, iy, BoardPosID, pInActualGameState) == true)
	{
		CGameStateValues* pOutNewGameState = nullptr;

		if (pGameStatePool->Get_UnusedGameStateObject(depthLayer, &pOutNewGameState, &ResultingGameStateObjectID) == false)
		{
			return -1;
		}

		pOutNewGameState->Clone_GameStateValues(pInActualGameState);

		// test move:
		pUsedPlayer1MoveList->Make_Move(MoveID, ix, iy, BoardPosID, pOutNewGameState);
		//pUsedPlayer1MoveList->Make_Move_If_Possible(MoveID, ix, iy, BoardPosID, pOutNewGameState);
		pOutNewGameState->PlayerID = 0;
		pInActualGameState->LeafNode = false;
		pOutNewGameState->IDofPrevGameState = pInActualGameState->IDofGameState;

		if (resultingGameStateIsMaximizer == true)
		{
			pOutNewGameState->Use_As_Maximizer();
		}
		else
		{
			pOutNewGameState->Use_As_Minimizer();
		}

		
		return 1;
	}

	// no move from BoardPosID found:
	return 0;
}

int32_t CKonaneTestMove::Player2Move_If_Possible(CGameStateValues* pInActualGameState, CExtendedGameStatePool* pGameStatePool, int32_t depthLayer, bool resultingGameStateIsMaximizer)
{
	ResultingGameStateObjectID = -1;

	if (BoardPosID >= GameBoardSizeXY)
	{
		return 0;
	}

	int8_t gameStateValue = pInActualGameState->pValueArray[BoardPosID];

	

	for (int32_t i = 0; i < NumOfNonPlayer2BoardValues; i++)
	{
		if (gameStateValue == NonPlayer2BoardValueArray[i])
		{
			return 0;
		}
	}

	int32_t ix = BoardPosID % GameBoardSizeXDir;
	int32_t iy = BoardPosID / GameBoardSizeXDir;

	//Add_To_Log(0, "Player2Move_If_Possible ...");

	if (pUsedPlayer2MoveList->Validate_PossibleMove(MoveID, ix, iy, BoardPosID, pInActualGameState) == true)
	{
		CGameStateValues* pOutNewGameState = nullptr;

		if (pGameStatePool->Get_UnusedGameStateObject(depthLayer, &pOutNewGameState, &ResultingGameStateObjectID) == false)
		{
			return -1;
		}

		pOutNewGameState->Clone_GameStateValues(pInActualGameState);

		// test move:
		//pUsedPlayer2MoveList->Make_Move_If_Possible(MoveID, ix, iy, BoardPosID, pOutNewGameState);
		pUsedPlayer2MoveList->Make_Move(MoveID, ix, iy, BoardPosID, pOutNewGameState);
		pOutNewGameState->PlayerID = 0;
		pInActualGameState->LeafNode = false;
		pOutNewGameState->IDofPrevGameState = pInActualGameState->IDofGameState;

		if (resultingGameStateIsMaximizer == true)
		{
			pOutNewGameState->Use_As_Maximizer();
		}
		else
		{
			pOutNewGameState->Use_As_Minimizer();
		}

		return 1;
	}


	// no move from BoardPosID found:
	return 0;
}
*/

CKonaneBreadthFirstSearchAI::CKonaneBreadthFirstSearchAI()
{}

CKonaneBreadthFirstSearchAI::~CKonaneBreadthFirstSearchAI()
{}

void CKonaneBreadthFirstSearchAI::Change_Seed(uint64_t seed)
{
	RandomNumbers.Change_Seed(seed);
}


void CKonaneBreadthFirstSearchAI::Prepare_KonaneGame(void)
{
	KonaneTestMove.Set_GameBoardSizeXDir(8);
	KonaneTestMove.Set_GameBoardSizeXY(64);

	KonaneTestMove.NumOfPlayer1MoveExcludedBoardElements = 2;
	KonaneTestMove.Player1MoveExcludedBoardElementsArray[0] = ConstGameBoard_Empty;
	KonaneTestMove.Player1MoveExcludedBoardElementsArray[1] = ConstGameBoard_Player2;

	KonaneTestMove.NumOfPlayer2MoveExcludedBoardElements = 2;
	KonaneTestMove.Player2MoveExcludedBoardElementsArray[0] = ConstGameBoard_Empty;
	KonaneTestMove.Player2MoveExcludedBoardElementsArray[1] = ConstGameBoard_Player1;
}


void CKonaneBreadthFirstSearchAI::Prepare_CheckersKonaneGame(void)
{
	KonaneTestMove.Set_GameBoardSizeXDir(8);
	KonaneTestMove.Set_GameBoardSizeXY(64);

	KonaneTestMove.NumOfPlayer1MoveExcludedBoardElements = 3;
	KonaneTestMove.Player1MoveExcludedBoardElementsArray[0] = ConstGameBoard_Empty;
	KonaneTestMove.Player1MoveExcludedBoardElementsArray[1] = ConstGameBoard_Player2_Man;
	KonaneTestMove.Player1MoveExcludedBoardElementsArray[2] = ConstGameBoard_Player2_King;

	KonaneTestMove.NumOfPlayer2MoveExcludedBoardElements = 3;
	KonaneTestMove.Player2MoveExcludedBoardElementsArray[0] = ConstGameBoard_Empty;
	KonaneTestMove.Player2MoveExcludedBoardElementsArray[1] = ConstGameBoard_Player1_Man;
	KonaneTestMove.Player2MoveExcludedBoardElementsArray[2] = ConstGameBoard_Player1_King;
}

void CKonaneBreadthFirstSearchAI::Initialize(CMovePatternList* pPlayer1MoveList, CMovePatternList* pPlayer2MoveList, int32_t numTestGameStatesMax, int32_t numTestGameStatesMaxPerDepthLayer, int32_t maxSearchDepth)
{
	MaxSearchDepth = maxSearchDepth;
	NumTestGameStatesMax = numTestGameStatesMax;
	NumTestGameStatesMaxPerDepthLayer = numTestGameStatesMaxPerDepthLayer;

	pUsedPlayer1MoveList = pPlayer1MoveList;
	pUsedPlayer2MoveList = pPlayer2MoveList;

	KonaneTestMove.Set_MovePatternLists(pPlayer1MoveList, pPlayer2MoveList);

	GameStatePool.Initialize(MaxSearchDepth, NumTestGameStatesMax, ConstGameBoardSizePerDir, ConstGameBoardSizePerDir);
}

void CKonaneBreadthFirstSearchAI::Execute_Player1AI(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState)
{
	if (Check_PossibleKonanePlayer1Moves(pInActualGameState->pValueArray) == false)
	{
		pOutNewGameState->Clone_Data(pInActualGameState);
		return;
	}

	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		KonaneTestMove.BoardPosID = i;

		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			KonaneTestMove.MoveID = j;

			if (KonaneTestMove.Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, 0, false) == -1)
			{
				Add_To_Log(0, "game tree too large, searchDepth 1");
				goto GameTreeCreationFinished;
			}
		} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
	} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	for (int32_t searchDepth = 1; searchDepth < MaxSearchDepth; searchDepth++)
	{
		int32_t playerID = searchDepth % 2;

		int32_t movementCounter = 0;

		if (playerID == 0)
		{
			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			int32_t id = 0;
			int32_t movementCounter = 0;

			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

				for (int32_t i = 0; i < ConstGameBoardSize; i++)
				{
					KonaneTestMove.BoardPosID = i;

					for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
					{
						KonaneTestMove.MoveID = j;

						if (KonaneTestMove.Make_Player1Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, false) == -1)
						{
							Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
							goto GameTreeCreationFinished;
						}

						movementCounter++;

						if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
						{
							Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
							goto TooManyTestGameStates1;
							//break;
						}
					} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

			TooManyTestGameStates1:;

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)
		}
		else // if (playerID == 1)
		{
			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			int32_t id = 0;


			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

				for (int32_t i = 0; i < ConstGameBoardSize; i++)
				{
					KonaneTestMove.BoardPosID = i;

					for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
					{
						KonaneTestMove.MoveID = j;

						if (KonaneTestMove.Make_Player2Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, true) == -1)
						{
							Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
							goto GameTreeCreationFinished;
						}

						movementCounter++;

						if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
						{
							Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
							goto TooManyTestGameStates2;
							//break;
						}
					} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

			TooManyTestGameStates2:;

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)
		}

		if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
			break;

	} // end of for (int32_t searchDepth = 0; searchDepth < MaxSearchDepthPlus1; searchDepth++)

GameTreeCreationFinished:;

	Evaluate_LeafGameStates_KonanePlayer1View(&GameStatePool);
	Backpropagate_MinimaxIntegerEvaluationValues(&GameStatePool);

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID);
	pOutNewGameState->Clone_GameStateValues(pGameStateObject);
}

void CKonaneBreadthFirstSearchAI::Execute_Player1AI_CheckersKonane(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState)
{
	if (Check_PossibleCheckersKonanePlayer1Moves(pInActualGameState->pValueArray, pUsedPlayer1MoveList) == false)
	{
		pOutNewGameState->Clone_Data(pInActualGameState);
		return;
	}

	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		KonaneTestMove.BoardPosID = i;

		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			KonaneTestMove.MoveID = j;

			if (KonaneTestMove.Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, 0, false) == -1)
			{
				Add_To_Log(0, "game tree too large, searchDepth 1");
				goto GameTreeCreationFinished;
			}
		} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
	} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	for (int32_t searchDepth = 1; searchDepth < MaxSearchDepth; searchDepth++)
	{
		int32_t playerID = searchDepth % 2;

		int32_t movementCounter = 0;

		if (playerID == 0)
		{
			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			int32_t id = 0;
			int32_t movementCounter = 0;

			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

				for (int32_t i = 0; i < ConstGameBoardSize; i++)
				{
					KonaneTestMove.BoardPosID = i;

					for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
					{
						KonaneTestMove.MoveID = j;

						if (KonaneTestMove.Make_Player1Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, false) == -1)
						{
							Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
							goto GameTreeCreationFinished;
						}

						movementCounter++;

						if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
						{
							Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
							goto TooManyTestGameStates1;
							//break;
						}
					} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

			TooManyTestGameStates1:;

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)
		}
		else // if (playerID == 1)
		{
			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			int32_t id = 0;


			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

				for (int32_t i = 0; i < ConstGameBoardSize; i++)
				{
					KonaneTestMove.BoardPosID = i;

					for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
					{
						KonaneTestMove.MoveID = j;

						if (KonaneTestMove.Make_Player2Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, true) == -1)
						{
							Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
							goto GameTreeCreationFinished;
						}

						movementCounter++;

						if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
						{
							Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
							goto TooManyTestGameStates2;
							//break;
						}
					} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

			TooManyTestGameStates2:;

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)
		}

		if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
			break;

	} // end of for (int32_t searchDepth = 0; searchDepth < MaxSearchDepthPlus1; searchDepth++)

GameTreeCreationFinished:;

	Evaluate_LeafGameStates_CheckersKonanePlayer1View(&GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
	Backpropagate_MinimaxIntegerEvaluationValues(&GameStatePool);

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID);
	pOutNewGameState->Clone_GameStateValues(pGameStateObject);
}

void CKonaneBreadthFirstSearchAI::Execute_Player1AI(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, float* pSearchDepthMovementProbabilityArray)
{
	if (Check_PossibleKonanePlayer1Moves(pInActualGameState->pValueArray) == false)
	{
		pOutNewGameState->Clone_Data(pInActualGameState);
		return;
	}

	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		KonaneTestMove.BoardPosID = i;

		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			KonaneTestMove.MoveID = j;

			if (KonaneTestMove.Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, 0, false) == -1)
			{
				Add_To_Log(0, "game tree too large, searchDepth 1");
				goto GameTreeCreationFinished;
			}
		} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
	} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	for (int32_t searchDepth = 1; searchDepth < MaxSearchDepth; searchDepth++)
	{
		int32_t playerID = searchDepth % 2;

		int32_t movementCounter = 0;

		if (playerID == 0)
		{
			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			int32_t id = 0;
			int32_t movementCounter = 0;

			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				if (RandomNumbers.Get_FloatNumber_IncludingZero(0.0f, 1.0) > pSearchDepthMovementProbabilityArray[searchDepth])
				{
					continue;
				}

				int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

				for (int32_t i = 0; i < ConstGameBoardSize; i++)
				{
					KonaneTestMove.BoardPosID = i;

					for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
					{
						KonaneTestMove.MoveID = j;

						if (KonaneTestMove.Make_Player1Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, false) == -1)
						{
							Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
							goto GameTreeCreationFinished;
						}

						movementCounter++;

						if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
						{
							Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
							goto TooManyTestGameStates1;
							//break;
						}
					} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

			TooManyTestGameStates1:;

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)
		}
		else // if (playerID == 1)
		{
			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			int32_t id = 0;


			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				if (RandomNumbers.Get_FloatNumber_IncludingZero(0.0f, 1.0) > pSearchDepthMovementProbabilityArray[searchDepth])
				{
					continue;
				}

				int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

				for (int32_t i = 0; i < ConstGameBoardSize; i++)
				{
					KonaneTestMove.BoardPosID = i;

					for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
					{
						KonaneTestMove.MoveID = j;


						if (KonaneTestMove.Make_Player2Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, true) == -1)
						{
							Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
							goto GameTreeCreationFinished;
						}

						movementCounter++;

						if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
						{
							Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
							goto TooManyTestGameStates2;
							//break;
						}
					} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

			TooManyTestGameStates2:;

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)
		}

		if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
			break;

	} // end of for (int32_t searchDepth = 0; searchDepth < MaxSearchDepthPlus1; searchDepth++)

GameTreeCreationFinished:;

	Evaluate_LeafGameStates_KonanePlayer1View(&GameStatePool);
	Backpropagate_MinimaxIntegerEvaluationValues(&GameStatePool);

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID);
	pOutNewGameState->Clone_GameStateValues(pGameStateObject);
}

void CKonaneBreadthFirstSearchAI::Execute_Player1AI_CheckersKonane(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, float* pSearchDepthMovementProbabilityArray)
{
	if (Check_PossibleCheckersKonanePlayer1Moves(pInActualGameState->pValueArray, pUsedPlayer1MoveList) == false)
	{
		pOutNewGameState->Clone_Data(pInActualGameState);
		return;
	}

	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		KonaneTestMove.BoardPosID = i;

		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			KonaneTestMove.MoveID = j;

			if (KonaneTestMove.Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, 0, false) == -1)
			{
				Add_To_Log(0, "game tree too large, searchDepth 1");
				goto GameTreeCreationFinished;
			}
		} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
	} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	for (int32_t searchDepth = 1; searchDepth < MaxSearchDepth; searchDepth++)
	{
		int32_t playerID = searchDepth % 2;

		int32_t movementCounter = 0;

		if (playerID == 0)
		{
			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			int32_t id = 0;
			int32_t movementCounter = 0;

			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				if (RandomNumbers.Get_FloatNumber_IncludingZero(0.0f, 1.0) > pSearchDepthMovementProbabilityArray[searchDepth])
				{
					continue;
				}

				int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

				for (int32_t i = 0; i < ConstGameBoardSize; i++)
				{
					KonaneTestMove.BoardPosID = i;

					for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
					{
						KonaneTestMove.MoveID = j;

						if (KonaneTestMove.Make_Player1Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, false) == -1)
						{
							Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
							goto GameTreeCreationFinished;
						}

						movementCounter++;

						if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
						{
							Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
							goto TooManyTestGameStates1;
							//break;
						}
					} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

			TooManyTestGameStates1:;

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)
		}
		else // if (playerID == 1)
		{
			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			int32_t id = 0;


			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				if (RandomNumbers.Get_FloatNumber_IncludingZero(0.0f, 1.0) > pSearchDepthMovementProbabilityArray[searchDepth])
				{
					continue;
				}

				int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

				for (int32_t i = 0; i < ConstGameBoardSize; i++)
				{
					KonaneTestMove.BoardPosID = i;

					for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
					{
						KonaneTestMove.MoveID = j;


						if (KonaneTestMove.Make_Player2Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, true) == -1)
						{
							Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
							goto GameTreeCreationFinished;
						}

						movementCounter++;

						if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
						{
							Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
							goto TooManyTestGameStates2;
							//break;
						}
					} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

			TooManyTestGameStates2:;

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)
		}

		if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
			break;

	} // end of for (int32_t searchDepth = 0; searchDepth < MaxSearchDepthPlus1; searchDepth++)

GameTreeCreationFinished:;

	Evaluate_LeafGameStates_CheckersKonanePlayer1View(&GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
	Backpropagate_MinimaxIntegerEvaluationValues(&GameStatePool);

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID);
	pOutNewGameState->Clone_GameStateValues(pGameStateObject);
}

void CKonaneBreadthFirstSearchAI::Execute_Player2AI(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState)
{
	if (Check_PossibleKonanePlayer2Moves(pInActualGameState->pValueArray) == false)
	{
		pOutNewGameState->Clone_Data(pInActualGameState);
		return;
	}

	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		KonaneTestMove.BoardPosID = i;

		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			KonaneTestMove.MoveID = j;

			if (KonaneTestMove.Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, 0, false) == -1)
			{
				Add_To_Log(0, "game tree too large, searchDepth 1");
				goto GameTreeCreationFinished;
			}
		} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
	} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)


	for (int32_t searchDepth = 1; searchDepth < MaxSearchDepth; searchDepth++)
	{
		int32_t playerID = (1 + searchDepth) % 2;

		int32_t movementCounter = 0;

		if (playerID == 0)
		{
			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			//Add_To_Log(0, "NumUsedListElements", NumObjectsUsed);

			int32_t id = 0;


			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

				for (int32_t i = 0; i < ConstGameBoardSize; i++)
				{
					KonaneTestMove.BoardPosID = i;

					for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
					{
						KonaneTestMove.MoveID = j;

						if (KonaneTestMove.Make_Player1Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, true) == -1)
						{
							Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
							goto GameTreeCreationFinished;
						}

						if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
						{
							Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
							goto TooManyTestGameStates1;
							//break;
						}
					} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

			TooManyTestGameStates1:;

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)
		}
		else // if (playerID == 1)
		{
			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			//Add_To_Log(0, "NumUsedListElements", NumObjectsUsed);
			int32_t id = 0;
			int32_t movementCounter = 0;

			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

				for (int32_t i = 0; i < ConstGameBoardSize; i++)
				{
					KonaneTestMove.BoardPosID = i;

					for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
					{
						KonaneTestMove.MoveID = j;

						if (KonaneTestMove.Make_Player2Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, false) == -1)
						{
							Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
							goto GameTreeCreationFinished;
						}

						movementCounter++;

						if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
						{
							Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
							goto TooManyTestGameStates2;
							//break;
						}
					} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

			TooManyTestGameStates2:;

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)
		}

		if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
			break;

	} // end of for (int32_t searchDepth = 0; searchDepth < MaxSearchDepthPlus1; searchDepth++)

GameTreeCreationFinished:;

	Evaluate_LeafGameStates_KonanePlayer2View(&GameStatePool);
	//Add_To_Log(0, "Evaluate_LeafGameStates_Player2View() ok");

	Backpropagate_MinimaxIntegerEvaluationValues(&GameStatePool);
	//Add_To_Log(0, "Backpropagate_MinimaxIntegerEvaluationValues() ok");

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID);

	//if(pGameStateObject == nullptr)
		//Add_To_Log(0, "pGameStateObject == nullptr");

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);
}

void CKonaneBreadthFirstSearchAI::Execute_Player2AI_CheckersKonane(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState)
{
	if (Check_PossibleCheckersKonanePlayer2Moves(pInActualGameState->pValueArray, pUsedPlayer2MoveList) == false)
	{
		pOutNewGameState->Clone_Data(pInActualGameState);
		return;
	}

	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		KonaneTestMove.BoardPosID = i;

		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			KonaneTestMove.MoveID = j;

			if (KonaneTestMove.Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, 0, false) == -1)
			{
				Add_To_Log(0, "game tree too large, searchDepth 1");
				goto GameTreeCreationFinished;
			}
		} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
	} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)


	for (int32_t searchDepth = 1; searchDepth < MaxSearchDepth; searchDepth++)
	{
		int32_t playerID = (1 + searchDepth) % 2;

		int32_t movementCounter = 0;

		if (playerID == 0)
		{
			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			//Add_To_Log(0, "NumUsedListElements", NumObjectsUsed);

			int32_t id = 0;


			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

				for (int32_t i = 0; i < ConstGameBoardSize; i++)
				{
					KonaneTestMove.BoardPosID = i;

					for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
					{
						KonaneTestMove.MoveID = j;

						if (KonaneTestMove.Make_Player1Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, true) == -1)
						{
							Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
							goto GameTreeCreationFinished;
						}

						if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
						{
							Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
							goto TooManyTestGameStates1;
							//break;
						}
					} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

			TooManyTestGameStates1:;

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)
		}
		else // if (playerID == 1)
		{
			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			//Add_To_Log(0, "NumUsedListElements", NumObjectsUsed);
			int32_t id = 0;
			int32_t movementCounter = 0;

			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

				for (int32_t i = 0; i < ConstGameBoardSize; i++)
				{
					KonaneTestMove.BoardPosID = i;

					for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
					{
						KonaneTestMove.MoveID = j;

						if (KonaneTestMove.Make_Player2Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, false) == -1)
						{
							Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
							goto GameTreeCreationFinished;
						}

						movementCounter++;

						if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
						{
							Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
							goto TooManyTestGameStates2;
							//break;
						}
					} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

			TooManyTestGameStates2:;

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)
		}

		if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
			break;

	} // end of for (int32_t searchDepth = 0; searchDepth < MaxSearchDepthPlus1; searchDepth++)

GameTreeCreationFinished:;

	Evaluate_LeafGameStates_CheckersKonanePlayer2View(&GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
	//Add_To_Log(0, "Evaluate_LeafGameStates_Player2View() ok");

	Backpropagate_MinimaxIntegerEvaluationValues(&GameStatePool);
	//Add_To_Log(0, "Backpropagate_MinimaxIntegerEvaluationValues() ok");

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID);

	//if(pGameStateObject == nullptr)
		//Add_To_Log(0, "pGameStateObject == nullptr");

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);
}

void CKonaneBreadthFirstSearchAI::Execute_Player2AI(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, float* pSearchDepthMovementProbabilityArray)
{
	if (Check_PossibleKonanePlayer2Moves(pInActualGameState->pValueArray) == false)
	{
		pOutNewGameState->Clone_Data(pInActualGameState);
		return;
	}

	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		KonaneTestMove.BoardPosID = i;

		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			KonaneTestMove.MoveID = j;

			if (KonaneTestMove.Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, 0, false) == -1)
			{
				Add_To_Log(0, "game tree too large, searchDepth 1");
				goto GameTreeCreationFinished;
			}
		} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
	} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)


	for (int32_t searchDepth = 1; searchDepth < MaxSearchDepth; searchDepth++)
	{
		int32_t playerID = (1 + searchDepth) % 2;

		int32_t movementCounter = 0;

		if (playerID == 0)
		{
			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			//Add_To_Log(0, "NumUsedListElements", NumObjectsUsed);

			int32_t id = 0;


			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				if (RandomNumbers.Get_FloatNumber_IncludingZero(0.0f, 1.0) > pSearchDepthMovementProbabilityArray[searchDepth])
				{
					continue;
				}

				int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

				for (int32_t i = 0; i < ConstGameBoardSize; i++)
				{
					KonaneTestMove.BoardPosID = i;

					for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
					{
						KonaneTestMove.MoveID = j;

						if (KonaneTestMove.Make_Player1Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, true) == -1)
						{
							Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
							goto GameTreeCreationFinished;
						}

						if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
						{
							Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
							goto TooManyTestGameStates1;
							//break;
						}
					} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)

					/*if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					{
						//Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
						break;
					}*/
				} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

			TooManyTestGameStates1:;

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)
		}
		else // if (playerID == 1)
		{
			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			//Add_To_Log(0, "NumUsedListElements", NumObjectsUsed);
			int32_t id = 0;
			int32_t movementCounter = 0;

			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				if (RandomNumbers.Get_FloatNumber_IncludingZero(0.0f, 1.0) > pSearchDepthMovementProbabilityArray[searchDepth])
				{
					continue;
				}

				int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

				for (int32_t i = 0; i < ConstGameBoardSize; i++)
				{
					KonaneTestMove.BoardPosID = i;

					for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
					{
						KonaneTestMove.MoveID = j;

						if (KonaneTestMove.Make_Player2Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, false) == -1)
						{
							Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
							goto GameTreeCreationFinished;
						}

						movementCounter++;

						if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
						{
							Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
							goto TooManyTestGameStates2;
							//break;
						}
					} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)

					/*if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					{
						//Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
						break;
					}*/
				} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

			TooManyTestGameStates2:;

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)
		}

		if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
			break;

	} // end of for (int32_t searchDepth = 0; searchDepth < MaxSearchDepthPlus1; searchDepth++)

GameTreeCreationFinished:;

	Evaluate_LeafGameStates_KonanePlayer2View(&GameStatePool);
	//Add_To_Log(0, "Evaluate_LeafGameStates_Player2View() ok");

	Backpropagate_MinimaxIntegerEvaluationValues(&GameStatePool);
	//Add_To_Log(0, "Backpropagate_MinimaxIntegerEvaluationValues() ok");

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID);

	//if(pGameStateObject == nullptr)
		//Add_To_Log(0, "pGameStateObject == nullptr");

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);
}

void CKonaneBreadthFirstSearchAI::Execute_Player2AI_CheckersKonane(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, float* pSearchDepthMovementProbabilityArray)
{
	if (Check_PossibleCheckersKonanePlayer2Moves(pInActualGameState->pValueArray, pUsedPlayer2MoveList) == false)
	{
		pOutNewGameState->Clone_Data(pInActualGameState);
		return;
	}

	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		KonaneTestMove.BoardPosID = i;

		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			KonaneTestMove.MoveID = j;

			if (KonaneTestMove.Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, 0, false) == -1)
			{
				Add_To_Log(0, "game tree too large, searchDepth 1");
				goto GameTreeCreationFinished;
			}
		} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
	} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)


	for (int32_t searchDepth = 1; searchDepth < MaxSearchDepth; searchDepth++)
	{
		int32_t playerID = (1 + searchDepth) % 2;

		int32_t movementCounter = 0;

		if (playerID == 0)
		{
			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			//Add_To_Log(0, "NumUsedListElements", NumObjectsUsed);

			int32_t id = 0;


			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				if (RandomNumbers.Get_FloatNumber_IncludingZero(0.0f, 1.0) > pSearchDepthMovementProbabilityArray[searchDepth])
				{
					continue;
				}

				int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

				for (int32_t i = 0; i < ConstGameBoardSize; i++)
				{
					KonaneTestMove.BoardPosID = i;

					for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
					{
						KonaneTestMove.MoveID = j;

						if (KonaneTestMove.Make_Player1Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, true) == -1)
						{
							Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
							goto GameTreeCreationFinished;
						}

						if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
						{
							Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
							goto TooManyTestGameStates1;
							//break;
						}
					} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)

					/*if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					{
						//Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
						break;
					}*/
				} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

			TooManyTestGameStates1:;

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)
		}
		else // if (playerID == 1)
		{
			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			//Add_To_Log(0, "NumUsedListElements", NumObjectsUsed);
			int32_t id = 0;
			int32_t movementCounter = 0;

			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				if (RandomNumbers.Get_FloatNumber_IncludingZero(0.0f, 1.0) > pSearchDepthMovementProbabilityArray[searchDepth])
				{
					continue;
				}

				int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

				for (int32_t i = 0; i < ConstGameBoardSize; i++)
				{
					KonaneTestMove.BoardPosID = i;

					for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
					{
						KonaneTestMove.MoveID = j;

						if (KonaneTestMove.Make_Player2Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, false) == -1)
						{
							Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
							goto GameTreeCreationFinished;
						}

						movementCounter++;

						if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
						{
							Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
							goto TooManyTestGameStates2;
							//break;
						}
					} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)

					/*if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					{
						//Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
						break;
					}*/
				} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

			TooManyTestGameStates2:;

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)
		}

		if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
			break;

	} // end of for (int32_t searchDepth = 0; searchDepth < MaxSearchDepthPlus1; searchDepth++)

GameTreeCreationFinished:;

	Evaluate_LeafGameStates_CheckersKonanePlayer2View(&GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
	//Add_To_Log(0, "Evaluate_LeafGameStates_Player2View() ok");

	Backpropagate_MinimaxIntegerEvaluationValues(&GameStatePool);
	//Add_To_Log(0, "Backpropagate_MinimaxIntegerEvaluationValues() ok");

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID);

	//if(pGameStateObject == nullptr)
		//Add_To_Log(0, "pGameStateObject == nullptr");

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);
}







CKonaneDepthFirstSearchAI::CKonaneDepthFirstSearchAI()
{}

CKonaneDepthFirstSearchAI::~CKonaneDepthFirstSearchAI()
{
	delete[] pKonaneTestMoveArray;
	pKonaneTestMoveArray = nullptr;
}

void CKonaneDepthFirstSearchAI::Prepare_KonaneGame(void)
{
	int32_t maxSearchDepthPlus1 = MaxSearchDepth + 1;

	for (int32_t i = 0; i < maxSearchDepthPlus1; i++)
	{
		pKonaneTestMoveArray[i].Set_GameBoardSizeXDir(8);
		pKonaneTestMoveArray[i].Set_GameBoardSizeXY(64);

		pKonaneTestMoveArray[i].NumOfPlayer1MoveExcludedBoardElements = 2;
		pKonaneTestMoveArray[i].Player1MoveExcludedBoardElementsArray[0] = ConstGameBoard_Empty;
		pKonaneTestMoveArray[i].Player1MoveExcludedBoardElementsArray[1] = ConstGameBoard_Player2;
		
		pKonaneTestMoveArray[i].NumOfPlayer2MoveExcludedBoardElements = 2;
		pKonaneTestMoveArray[i].Player2MoveExcludedBoardElementsArray[0] = ConstGameBoard_Empty;
		pKonaneTestMoveArray[i].Player2MoveExcludedBoardElementsArray[1] = ConstGameBoard_Player1;
		
	}
}


void CKonaneDepthFirstSearchAI::Prepare_CheckersKonaneGame(void)
{
	int32_t maxSearchDepthPlus1 = MaxSearchDepth + 1;

	for (int32_t i = 0; i < maxSearchDepthPlus1; i++)
	{
		pKonaneTestMoveArray[i].Set_GameBoardSizeXDir(8);
		pKonaneTestMoveArray[i].Set_GameBoardSizeXY(64);

		pKonaneTestMoveArray[i].NumOfPlayer1MoveExcludedBoardElements = 3;
		pKonaneTestMoveArray[i].Player1MoveExcludedBoardElementsArray[0] = ConstGameBoard_Empty;
		pKonaneTestMoveArray[i].Player1MoveExcludedBoardElementsArray[1] = ConstGameBoard_Player2_Man;
		pKonaneTestMoveArray[i].Player1MoveExcludedBoardElementsArray[2] = ConstGameBoard_Player2_King;

		pKonaneTestMoveArray[i].NumOfPlayer2MoveExcludedBoardElements = 3;
		pKonaneTestMoveArray[i].Player2MoveExcludedBoardElementsArray[0] = ConstGameBoard_Empty;
		pKonaneTestMoveArray[i].Player2MoveExcludedBoardElementsArray[1] = ConstGameBoard_Player1_Man;
		pKonaneTestMoveArray[i].Player2MoveExcludedBoardElementsArray[2] = ConstGameBoard_Player1_King;
	}
}

void CKonaneDepthFirstSearchAI::Initialize(CMovePatternList* pPlayer1MoveList, CMovePatternList* pPlayer2MoveList, int32_t numTestGameStatesMax, int32_t maxSearchDepth)
{
	MaxSearchDepth = max(2, maxSearchDepth);
	MaxSearchDepthMinus1 = MaxSearchDepth - 1;
	NumTestGameStatesMax = numTestGameStatesMax;

	pUsedPlayer1MoveList = pPlayer1MoveList;
	pUsedPlayer2MoveList = pPlayer2MoveList;

	int32_t maxSearchDepthPlus1 = MaxSearchDepth + 1;

	GameStatePool.Initialize(maxSearchDepthPlus1, NumTestGameStatesMax, ConstGameBoardSizePerDir, ConstGameBoardSizePerDir);

	delete[] pKonaneTestMoveArray;
	pKonaneTestMoveArray = nullptr;

	pKonaneTestMoveArray = new (std::nothrow) CTestMove[maxSearchDepthPlus1];

	for (int32_t i = 0; i < maxSearchDepthPlus1; i++)
		pKonaneTestMoveArray[i].Set_MovePatternLists(pPlayer1MoveList, pPlayer2MoveList);
}

void CKonaneDepthFirstSearchAI::Execute_Player1AI(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState)
{
	if (Check_PossibleKonanePlayer1Moves(pInActualGameState->pValueArray) == false)
	{
		pOutNewGameState->Clone_Data(pInActualGameState);
		return;
	}

	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t RootGameStateID = -1;
	CGameStateValues* pRootGameStateObject = nullptr;

	GameStatePool.Get_UnusedGameStateObject(0, &pRootGameStateObject, &RootGameStateID);
	pRootGameStateObject->Clone_GameStateValues(pInActualGameState);
	pRootGameStateObject->Use_As_Maximizer();

	CTestMove* pKonaneTestMove = &pKonaneTestMoveArray[1];

	if (MaxSearchDepth == 2)
	{
		int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			pKonaneTestMove->BoardPosID = i;

			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				pKonaneTestMove->MoveID = j;

				if (pKonaneTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
				{
					CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pKonaneTestMove->ResultingGameStateObjectID];

					bool TestMoveDepth2Failed = Player1AI_InnerEvalulationLoop(pGameStateObjectDepth1, 1, 2);

					if (TestMoveDepth2Failed == true)
					{
						Evaluate_GameState_KonanePlayer1View(pGameStateObjectDepth1->IDofGameState, &GameStatePool);
					}

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);
				}
			} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	} // end of if (MaxSearchDepth == 2)
	else if (MaxSearchDepth > 2)
	{
		int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			pKonaneTestMove->BoardPosID = i;

			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				pKonaneTestMove->MoveID = j;

				if (pKonaneTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
				{
					CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pKonaneTestMove->ResultingGameStateObjectID];

					bool TestMoveDepth2Failed = Player1AI_OuterEvalulationLoop(pGameStateObjectDepth1, 1, 2);

					if (TestMoveDepth2Failed == true)
					{
						Evaluate_GameState_KonanePlayer1View(pGameStateObjectDepth1->IDofGameState, &GameStatePool);
					}

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);
				}
			} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	} // end of else if (MaxSearchDepth > 2)

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID, 1);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);
}

void CKonaneDepthFirstSearchAI::Execute_Player1AI_CheckersKonane(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState)
{
	if (Check_PossibleCheckersKonanePlayer1Moves(pInActualGameState->pValueArray, pUsedPlayer1MoveList) == false)
	{
		pOutNewGameState->Clone_Data(pInActualGameState);
		return;
	}

	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t RootGameStateID = -1;
	CGameStateValues* pRootGameStateObject = nullptr;

	GameStatePool.Get_UnusedGameStateObject(0, &pRootGameStateObject, &RootGameStateID);
	pRootGameStateObject->Clone_GameStateValues(pInActualGameState);
	pRootGameStateObject->Use_As_Maximizer();

	CTestMove* pKonaneTestMove = &pKonaneTestMoveArray[1];

	if (MaxSearchDepth == 2)
	{
		int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			pKonaneTestMove->BoardPosID = i;

			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				pKonaneTestMove->MoveID = j;

				if (pKonaneTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
				{
					CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pKonaneTestMove->ResultingGameStateObjectID];

					bool TestMoveDepth2Failed = Player1AI_InnerEvalulationLoop_CheckersKonane(pGameStateObjectDepth1, 1, 2);

					if (TestMoveDepth2Failed == true)
					{
						Evaluate_GameState_CheckersKonanePlayer1View(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
					}

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);
				}
			} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	} // end of if (MaxSearchDepth == 2)
	else if (MaxSearchDepth > 2)
	{
		int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			pKonaneTestMove->BoardPosID = i;

			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				pKonaneTestMove->MoveID = j;

				if (pKonaneTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
				{
					CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pKonaneTestMove->ResultingGameStateObjectID];

					bool TestMoveDepth2Failed = Player1AI_OuterEvalulationLoop_CheckersKonane(pGameStateObjectDepth1, 1, 2);

					if (TestMoveDepth2Failed == true)
					{
						Evaluate_GameState_CheckersKonanePlayer1View(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
					}

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);
				}
			} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	} // end of else if (MaxSearchDepth > 2)

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID, 1);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);
}

void CKonaneDepthFirstSearchAI::Execute_Player2AI(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState)
{
	if (Check_PossibleKonanePlayer2Moves(pInActualGameState->pValueArray) == false)
	{
		pOutNewGameState->Clone_Data(pInActualGameState);
		return;
	}

	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t RootGameStateID = -1;
	CGameStateValues* pRootGameStateObject = nullptr;

	GameStatePool.Get_UnusedGameStateObject(0, &pRootGameStateObject, &RootGameStateID);
	pRootGameStateObject->Clone_GameStateValues(pInActualGameState);
	pRootGameStateObject->Use_As_Maximizer();

	CTestMove* pKonaneTestMove = &pKonaneTestMoveArray[1];

	if (MaxSearchDepth == 2)
	{
		int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			pKonaneTestMove->BoardPosID = i;

			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				pKonaneTestMove->MoveID = j;

				if (pKonaneTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
				{
					CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pKonaneTestMove->ResultingGameStateObjectID];

					bool TestMoveDepth2Failed = Player2AI_InnerEvalulationLoop(pGameStateObjectDepth1, 0, 2);

					if (TestMoveDepth2Failed == true)
					{
						Evaluate_GameState_KonanePlayer2View(pGameStateObjectDepth1->IDofGameState, &GameStatePool);
					}

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);
				}
			} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	} // end of if (MaxSearchDepth == 2)
	else if (MaxSearchDepth > 2)
	{
		int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			pKonaneTestMove->BoardPosID = i;

			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				pKonaneTestMove->MoveID = j;

				if (pKonaneTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
				{
					CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pKonaneTestMove->ResultingGameStateObjectID];

					bool TestMoveDepth2Failed = Player2AI_OuterEvalulationLoop(pGameStateObjectDepth1, 0, 2);

					if (TestMoveDepth2Failed == true)
					{
						Evaluate_GameState_KonanePlayer2View(pGameStateObjectDepth1->IDofGameState, &GameStatePool);
					}

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);

				}
			} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	} // end of else if (MaxSearchDepth > 2)

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID, 1);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

}

void CKonaneDepthFirstSearchAI::Execute_Player2AI_CheckersKonane(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState)
{
	if (Check_PossibleCheckersKonanePlayer2Moves(pInActualGameState->pValueArray, pUsedPlayer2MoveList) == false)
	{
		pOutNewGameState->Clone_Data(pInActualGameState);
		return;
	}

	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t RootGameStateID = -1;
	CGameStateValues* pRootGameStateObject = nullptr;

	GameStatePool.Get_UnusedGameStateObject(0, &pRootGameStateObject, &RootGameStateID);
	pRootGameStateObject->Clone_GameStateValues(pInActualGameState);
	pRootGameStateObject->Use_As_Maximizer();

	CTestMove* pKonaneTestMove = &pKonaneTestMoveArray[1];

	if (MaxSearchDepth == 2)
	{
		int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			pKonaneTestMove->BoardPosID = i;

			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				pKonaneTestMove->MoveID = j;

				if (pKonaneTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
				{
					CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pKonaneTestMove->ResultingGameStateObjectID];

					bool TestMoveDepth2Failed = Player2AI_InnerEvalulationLoop_CheckersKonane(pGameStateObjectDepth1, 0, 2);

					if (TestMoveDepth2Failed == true)
					{
						Evaluate_GameState_CheckersKonanePlayer2View(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
					}

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);
				}
			} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	} // end of if (MaxSearchDepth == 2)
	else if (MaxSearchDepth > 2)
	{
		int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			pKonaneTestMove->BoardPosID = i;

			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				pKonaneTestMove->MoveID = j;

				if (pKonaneTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
				{
					CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pKonaneTestMove->ResultingGameStateObjectID];

					bool TestMoveDepth2Failed = Player2AI_OuterEvalulationLoop_CheckersKonane(pGameStateObjectDepth1, 0, 2);

					if (TestMoveDepth2Failed == true)
					{
						Evaluate_GameState_CheckersKonanePlayer2View(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
					}

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);

				}
			} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	} // end of else if (MaxSearchDepth > 2)

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID, 1);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

}

bool CKonaneDepthFirstSearchAI::Player1AI_OuterEvalulationLoop(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth)
{
	CTestMove* pKonaneTestMove = &pKonaneTestMoveArray[depth];
	
	int32_t depthPlus1 = depth + 1;


	if (depth == MaxSearchDepthMinus1)
	{
		if (playerID == 0)
		{
			int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

			for (int32_t i = 0; i < ConstGameBoardSize; i++)
			{
				pKonaneTestMove->BoardPosID = i;

				for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				{
					pKonaneTestMove->MoveID = j;

					if (pKonaneTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pKonaneTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player1AI_InnerEvalulationLoop(pResultingGameStateObject, 1, depthPlus1);

						if (TestMovesNextDepth == true)
						{
							Evaluate_GameState_KonanePlayer1View(resultingGameStateObjectID, &GameStatePool);
						}

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
						if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer1A;
						}
#endif
					}
				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer1A:;

			return TestMovesFailed;
		} // end of if (playerID == 0)
		else //if (playerID == 1)
		{
			int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

			for (int32_t i = 0; i < ConstGameBoardSize; i++)
			{
				pKonaneTestMove->BoardPosID = i;

				for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				{
					pKonaneTestMove->MoveID = j;

					if (pKonaneTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pKonaneTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player1AI_InnerEvalulationLoop(pResultingGameStateObject, 0, depthPlus1);

						if (TestMovesNextDepth == true)
						{
							Evaluate_GameState_KonanePlayer1View(resultingGameStateObjectID, &GameStatePool);
						}

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
						if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMaximizerEvalValue >= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer2A;
						}
#endif
					}
				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer2A:;

			return TestMovesFailed;
		} // end of else //if (playerID == 1)
	} // end of if (depth == MaxSearchDepthMinus1)
	else if (depth < MaxSearchDepthMinus1)
	{
		if (playerID == 0)
		{
			int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

			for (int32_t i = 0; i < ConstGameBoardSize; i++)
			{
				pKonaneTestMove->BoardPosID = i;

				for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				{
					pKonaneTestMove->MoveID = j;

					if (pKonaneTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pKonaneTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player1AI_OuterEvalulationLoop(pResultingGameStateObject, 1, depthPlus1);

						if (TestMovesNextDepth == true)
						{
							Evaluate_GameState_KonanePlayer1View(resultingGameStateObjectID, &GameStatePool);
						}

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
						if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer1B;
						}
#endif
					}
				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer1B:;

			return TestMovesFailed;
		} // end of if (playerID == 0)
		else //if (playerID == 1)
		{
			int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

			for (int32_t i = 0; i < ConstGameBoardSize; i++)
			{
				pKonaneTestMove->BoardPosID = i;

				for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				{
					pKonaneTestMove->MoveID = j;

					if (pKonaneTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pKonaneTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player1AI_OuterEvalulationLoop(pResultingGameStateObject, 0, depthPlus1);


						if (TestMovesNextDepth == true)
						{
							Evaluate_GameState_KonanePlayer1View(resultingGameStateObjectID, &GameStatePool);
						}

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
						if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMaximizerEvalValue >= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer2B;
						}
#endif
					}
				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer2B:;

			return TestMovesFailed;
		} // end of else //if (playerID == 1)
	} // end of else if (depth < MaxSearchDepthMinus1)

	return false;
}

bool CKonaneDepthFirstSearchAI::Player1AI_OuterEvalulationLoop_CheckersKonane(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth)
{
	CTestMove* pKonaneTestMove = &pKonaneTestMoveArray[depth];

	int32_t depthPlus1 = depth + 1;


	if (depth == MaxSearchDepthMinus1)
	{
		if (playerID == 0)
		{
			int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

			for (int32_t i = 0; i < ConstGameBoardSize; i++)
			{
				pKonaneTestMove->BoardPosID = i;

				for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				{
					pKonaneTestMove->MoveID = j;

					if (pKonaneTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pKonaneTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player1AI_InnerEvalulationLoop_CheckersKonane(pResultingGameStateObject, 1, depthPlus1);

						if (TestMovesNextDepth == true)
						{
							Evaluate_GameState_CheckersKonanePlayer1View(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
						}

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
						if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer1A;
						}
#endif
					}
				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer1A:;

			return TestMovesFailed;
		} // end of if (playerID == 0)
		else //if (playerID == 1)
		{
			int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

			for (int32_t i = 0; i < ConstGameBoardSize; i++)
			{
				pKonaneTestMove->BoardPosID = i;

				for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				{
					pKonaneTestMove->MoveID = j;

					if (pKonaneTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pKonaneTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player1AI_InnerEvalulationLoop_CheckersKonane(pResultingGameStateObject, 0, depthPlus1);

						if (TestMovesNextDepth == true)
						{
							Evaluate_GameState_CheckersKonanePlayer1View(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
						}

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
						if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMaximizerEvalValue >= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer2A;
						}
#endif
					}
				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer2A:;

			return TestMovesFailed;
		} // end of else //if (playerID == 1)
	} // end of if (depth == MaxSearchDepthMinus1)
	else if (depth < MaxSearchDepthMinus1)
	{
		if (playerID == 0)
		{
			int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

			for (int32_t i = 0; i < ConstGameBoardSize; i++)
			{
				pKonaneTestMove->BoardPosID = i;

				for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				{
					pKonaneTestMove->MoveID = j;

					if (pKonaneTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pKonaneTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player1AI_OuterEvalulationLoop_CheckersKonane(pResultingGameStateObject, 1, depthPlus1);

						if (TestMovesNextDepth == true)
						{
							Evaluate_GameState_CheckersKonanePlayer1View(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
						}

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
						if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer1B;
						}
#endif
					}
				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer1B:;

			return TestMovesFailed;
		} // end of if (playerID == 0)
		else //if (playerID == 1)
		{
			int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

			for (int32_t i = 0; i < ConstGameBoardSize; i++)
			{
				pKonaneTestMove->BoardPosID = i;

				for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				{
					pKonaneTestMove->MoveID = j;

					if (pKonaneTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pKonaneTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player1AI_OuterEvalulationLoop_CheckersKonane(pResultingGameStateObject, 0, depthPlus1);


						if (TestMovesNextDepth == true)
						{
							Evaluate_GameState_CheckersKonanePlayer1View(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
						}

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
						if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMaximizerEvalValue >= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer2B;
						}
#endif
					}
				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer2B:;

			return TestMovesFailed;
		} // end of else //if (playerID == 1)
	} // end of else if (depth < MaxSearchDepthMinus1)

	return false;
}


bool CKonaneDepthFirstSearchAI::Player2AI_OuterEvalulationLoop(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth)
{
	CTestMove* pKonaneTestMove = &pKonaneTestMoveArray[depth];

	int32_t depthPlus1 = depth + 1;


	if (depth == MaxSearchDepthMinus1)
	{
		if (playerID == 0)
		{
			int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

			for (int32_t i = 0; i < ConstGameBoardSize; i++)
			{
				pKonaneTestMove->BoardPosID = i;

				for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				{
					pKonaneTestMove->MoveID = j;

					if (pKonaneTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pKonaneTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player2AI_InnerEvalulationLoop(pResultingGameStateObject, 1, depthPlus1);

						if (TestMovesNextDepth == true)
						{
							Evaluate_GameState_KonanePlayer2View(resultingGameStateObjectID, &GameStatePool);
						}

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
						if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMaximizerEvalValue >= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer1A;
						}
#endif
					}
				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer1A:;

			return TestMovesFailed;
		} // end of if (playerID == 0)
		else //if (playerID == 1)
		{
			int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

			for (int32_t i = 0; i < ConstGameBoardSize; i++)
			{
				pKonaneTestMove->BoardPosID = i;

				for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				{
					pKonaneTestMove->MoveID = j;

					if (pKonaneTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pKonaneTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player2AI_InnerEvalulationLoop(pResultingGameStateObject, 0, depthPlus1);

						if (TestMovesNextDepth == true)
						{
							Evaluate_GameState_KonanePlayer2View(resultingGameStateObjectID, &GameStatePool);
						}

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
						if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer2A;
						}
#endif
					}
				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer2A:;

			return TestMovesFailed;
		} // end of else //if (playerID == 1)
	} // end of if (depth == MaxSearchDepthMinus1)
	else if (depth < MaxSearchDepthMinus1)
	{
		if (playerID == 0)
		{
			int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

			for (int32_t i = 0; i < ConstGameBoardSize; i++)
			{
				pKonaneTestMove->BoardPosID = i;

				for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				{
					pKonaneTestMove->MoveID = j;

					if (pKonaneTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pKonaneTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player2AI_OuterEvalulationLoop(pResultingGameStateObject, 1, depthPlus1);

						if (TestMovesNextDepth == true)
						{
							Evaluate_GameState_KonanePlayer2View(resultingGameStateObjectID, &GameStatePool);
						}

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
						if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMaximizerEvalValue >= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer1B;
						}
#endif
					}
				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer1B:;

			return TestMovesFailed;
		} // end of if (playerID == 0)
		else //if (playerID == 1)
		{
			int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

			for (int32_t i = 0; i < ConstGameBoardSize; i++)
			{
				pKonaneTestMove->BoardPosID = i;

				for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				{
					pKonaneTestMove->MoveID = j;

					if (pKonaneTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pKonaneTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player2AI_OuterEvalulationLoop(pResultingGameStateObject, 0, depthPlus1);

						if (TestMovesNextDepth == true)
						{
							Evaluate_GameState_KonanePlayer2View(resultingGameStateObjectID, &GameStatePool);
						}

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
						if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer2B;
						}
#endif
					}
				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer2B:;

			return TestMovesFailed;
		} // end of else //if (playerID == 1)
	} // end of else if (depth < MaxSearchDepthMinus1)

	return false;
}

bool CKonaneDepthFirstSearchAI::Player2AI_OuterEvalulationLoop_CheckersKonane(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth)
{
	CTestMove* pKonaneTestMove = &pKonaneTestMoveArray[depth];

	int32_t depthPlus1 = depth + 1;


	if (depth == MaxSearchDepthMinus1)
	{
		if (playerID == 0)
		{
			int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

			for (int32_t i = 0; i < ConstGameBoardSize; i++)
			{
				pKonaneTestMove->BoardPosID = i;

				for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				{
					pKonaneTestMove->MoveID = j;

					if (pKonaneTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pKonaneTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player2AI_InnerEvalulationLoop_CheckersKonane(pResultingGameStateObject, 1, depthPlus1);

						if (TestMovesNextDepth == true)
						{
							Evaluate_GameState_CheckersKonanePlayer2View(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
						}

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
						if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMaximizerEvalValue >= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer1A;
						}
#endif
					}
				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer1A:;

			return TestMovesFailed;
		} // end of if (playerID == 0)
		else //if (playerID == 1)
		{
			int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

			for (int32_t i = 0; i < ConstGameBoardSize; i++)
			{
				pKonaneTestMove->BoardPosID = i;

				for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				{
					pKonaneTestMove->MoveID = j;

					if (pKonaneTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pKonaneTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player2AI_InnerEvalulationLoop_CheckersKonane(pResultingGameStateObject, 0, depthPlus1);

						if (TestMovesNextDepth == true)
						{
							Evaluate_GameState_CheckersKonanePlayer2View(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
						}

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
						if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer2A;
						}
#endif
					}
				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer2A:;

			return TestMovesFailed;
		} // end of else //if (playerID == 1)
	} // end of if (depth == MaxSearchDepthMinus1)
	else if (depth < MaxSearchDepthMinus1)
	{
		if (playerID == 0)
		{
			int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

			for (int32_t i = 0; i < ConstGameBoardSize; i++)
			{
				pKonaneTestMove->BoardPosID = i;

				for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				{
					pKonaneTestMove->MoveID = j;

					if (pKonaneTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pKonaneTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player2AI_OuterEvalulationLoop_CheckersKonane(pResultingGameStateObject, 1, depthPlus1);

						if (TestMovesNextDepth == true)
						{
							Evaluate_GameState_CheckersKonanePlayer2View(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
						}

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
						if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMaximizerEvalValue >= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer1B;
						}
#endif
					}
				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer1B:;

			return TestMovesFailed;
		} // end of if (playerID == 0)
		else //if (playerID == 1)
		{
			int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

			for (int32_t i = 0; i < ConstGameBoardSize; i++)
			{
				pKonaneTestMove->BoardPosID = i;

				for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				{
					pKonaneTestMove->MoveID = j;

					if (pKonaneTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pKonaneTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player2AI_OuterEvalulationLoop_CheckersKonane(pResultingGameStateObject, 0, depthPlus1);

						if (TestMovesNextDepth == true)
						{
							Evaluate_GameState_CheckersKonanePlayer2View(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
						}

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
						if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer2B;
						}
#endif
					}
				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer2B:;

			return TestMovesFailed;
		} // end of else //if (playerID == 1)
	} // end of else if (depth < MaxSearchDepthMinus1)

	return false;
}

bool CKonaneDepthFirstSearchAI::Player1AI_InnerEvalulationLoop(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth)
{
	CTestMove* pKonaneTestMove = &pKonaneTestMoveArray[depth];

	if (playerID == 0)
	{
		int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

		bool TestMovesFailed = true;

		int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			pKonaneTestMove->BoardPosID = i;

			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				pKonaneTestMove->MoveID = j;

				if (pKonaneTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)
				{
					TestMovesFailed = false;

					int32_t resultingGameStateObjectID = pKonaneTestMove->ResultingGameStateObjectID;
					Evaluate_GameState_KonanePlayer1View(resultingGameStateObjectID, &GameStatePool);

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
					if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
					{
						//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
						goto StopEvaluationPlayer1;
					}
#endif
				}
			} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	StopEvaluationPlayer1:;

		return TestMovesFailed;

	} // end of if (playerID == 0)
	else //if (playerID == 1)
	{
		int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

		bool TestMovesFailed = true;

		int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			pKonaneTestMove->BoardPosID = i;

			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				pKonaneTestMove->MoveID = j;

				if (pKonaneTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)
				{
					TestMovesFailed = false;

					int32_t resultingGameStateObjectID = pKonaneTestMove->ResultingGameStateObjectID;
					Evaluate_GameState_KonanePlayer1View(resultingGameStateObjectID, &GameStatePool);

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
					if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
					{
						//Add_To_Log(0, "PrevMaximizerEvalValue >= pInActualGameState->iEvaluation");
						goto StopEvaluationPlayer2;
					}
#endif
				}
			} // for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	StopEvaluationPlayer2:;

		return TestMovesFailed;

	} // end of else //if (playerID == 1)

	return false;
}

bool CKonaneDepthFirstSearchAI::Player1AI_InnerEvalulationLoop_CheckersKonane(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth)
{
	CTestMove* pKonaneTestMove = &pKonaneTestMoveArray[depth];

	if (playerID == 0)
	{
		int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

		bool TestMovesFailed = true;

		int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			pKonaneTestMove->BoardPosID = i;

			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				pKonaneTestMove->MoveID = j;

				if (pKonaneTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)
				{
					TestMovesFailed = false;

					int32_t resultingGameStateObjectID = pKonaneTestMove->ResultingGameStateObjectID;
					Evaluate_GameState_CheckersKonanePlayer1View(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
					if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
					{
						//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
						goto StopEvaluationPlayer1;
					}
#endif
				}
			} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	StopEvaluationPlayer1:;

		return TestMovesFailed;

	} // end of if (playerID == 0)
	else //if (playerID == 1)
	{
		int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

		bool TestMovesFailed = true;

		int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			pKonaneTestMove->BoardPosID = i;

			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				pKonaneTestMove->MoveID = j;

				if (pKonaneTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)
				{
					TestMovesFailed = false;

					int32_t resultingGameStateObjectID = pKonaneTestMove->ResultingGameStateObjectID;
					Evaluate_GameState_CheckersKonanePlayer1View(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
					if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
					{
						//Add_To_Log(0, "PrevMaximizerEvalValue >= pInActualGameState->iEvaluation");
						goto StopEvaluationPlayer2;
					}
#endif
				}
			} // for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	StopEvaluationPlayer2:;

		return TestMovesFailed;

	} // end of else //if (playerID == 1)

	return false;
}

bool CKonaneDepthFirstSearchAI::Player2AI_InnerEvalulationLoop(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth)
{
	CTestMove* pKonaneTestMove = &pKonaneTestMoveArray[depth];

	if (playerID == 0)
	{
		int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

		bool TestMovesFailed = true;

		int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			pKonaneTestMove->BoardPosID = i;

			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				pKonaneTestMove->MoveID = j;

				if (pKonaneTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)
				{
					TestMovesFailed = false;

					int32_t resultingGameStateObjectID = pKonaneTestMove->ResultingGameStateObjectID;
					Evaluate_GameState_KonanePlayer2View(resultingGameStateObjectID, &GameStatePool);


					OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
					if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
					{
						//Add_To_Log(0, "PrevMaxEvalValue >= pInActualGameState->iEvaluation");
						goto StopEvaluationPlayer1;
					}
#endif
				}
			} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	StopEvaluationPlayer1:;

		return TestMovesFailed;

	} // end of if (playerID == 0)
	else //if (playerID == 1)
	{
		int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

		bool TestMovesFailed = true;

		int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			pKonaneTestMove->BoardPosID = i;

			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				pKonaneTestMove->MoveID = j;

				if (pKonaneTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)
				{
					TestMovesFailed = false;

					int32_t resultingGameStateObjectID = pKonaneTestMove->ResultingGameStateObjectID;
					Evaluate_GameState_KonanePlayer2View(resultingGameStateObjectID, &GameStatePool);

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
					if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
					{
						//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
						goto StopEvaluationPlayer2;
					}
#endif
				}
			} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	StopEvaluationPlayer2:;

		return TestMovesFailed;

	} // end of else //if (playerID == 1)

	return false;
}

bool CKonaneDepthFirstSearchAI::Player2AI_InnerEvalulationLoop_CheckersKonane(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth)
{
	CTestMove* pKonaneTestMove = &pKonaneTestMoveArray[depth];

	if (playerID == 0)
	{
		int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

		bool TestMovesFailed = true;

		int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			pKonaneTestMove->BoardPosID = i;

			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				pKonaneTestMove->MoveID = j;

				if (pKonaneTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)
				{
					TestMovesFailed = false;

					int32_t resultingGameStateObjectID = pKonaneTestMove->ResultingGameStateObjectID;
					Evaluate_GameState_CheckersKonanePlayer2View(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);


					OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
					if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
					{
						//Add_To_Log(0, "PrevMaxEvalValue >= pInActualGameState->iEvaluation");
						goto StopEvaluationPlayer1;
					}
#endif
				}
			} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	StopEvaluationPlayer1:;

		return TestMovesFailed;

	} // end of if (playerID == 0)
	else //if (playerID == 1)
	{
		int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

		bool TestMovesFailed = true;

		int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			pKonaneTestMove->BoardPosID = i;

			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				pKonaneTestMove->MoveID = j;

				if (pKonaneTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)
				{
					TestMovesFailed = false;

					int32_t resultingGameStateObjectID = pKonaneTestMove->ResultingGameStateObjectID;
					Evaluate_GameState_CheckersKonanePlayer2View(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
					if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
					{
						//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
						goto StopEvaluationPlayer2;
					}
#endif
				}
			} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	StopEvaluationPlayer2:;

		return TestMovesFailed;

	} // end of else //if (playerID == 1)

	return false;
}





