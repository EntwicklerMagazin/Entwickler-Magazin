// Schutz vor Mehrfachdeklarationen:

#ifndef _FuzzyLogic_H_
#define _FuzzyLogic_H_

#pragma warning( disable: 4996)

#include "MathInlineFunctions.h"

inline float Calculate_FuzzyNOT(float membershipValue)
{
	return 1.0f - membershipValue;
	//return 1.0f - min(1.0f, max(0.0f, membershipValue));
}

inline float Calculate_FuzzyOR(float membershipValue1, float membershipValue2)
{
	return max(membershipValue1, membershipValue2);
}

inline float CalculationStep_FuzzyOR(float furtherMembershipValue, float previousFuzzyORResult)
{
	return max(furtherMembershipValue, previousFuzzyORResult);
}

inline float Calculate_FuzzyAND(float membershipValue1, float membershipValue2)
{
	return min(membershipValue1, membershipValue2);
}

inline float CalculationStep_FuzzyAND(float furtherMembershipValue, float previousFuzzyANDResult)
{
	return min(furtherMembershipValue, previousFuzzyANDResult);
}


// Fuzzy Rule example:


// mathematical description of an element of a linguistic variable (e.g. elements of distance: close, medium, far)
class CGaussianFuzzyElement
{
public:

	int32_t NumOfCentroids = 0;
	float* pRBFFactorArray = nullptr;
	float* pFunctionParamArray = nullptr;
	float* pCentroidArray = nullptr;

	float ActualUsedMaxUpperMembershipValue = 1.0f;

	float ValueWithMaxMembership = 0.0f;

	CGaussianFuzzyElement();
	~CGaussianFuzzyElement();

	// Kopierkonstruktor l�schen:
	CGaussianFuzzyElement(const CGaussianFuzzyElement& originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CGaussianFuzzyElement& operator=(const CGaussianFuzzyElement& originalObject) = delete;

	void Set_ValueWithMaxMembership(float value);

	void Initialize(int32_t numOfCentroids);
	void Initialize(int32_t numOfCentroids, float* pRBFFactors, float* pFunctionParams, float* pCentroids);

	void Update_Data(float* pRBFFactors, float* pFunctionParams, float* pCentroids);


	float Calculate_Membership(float input);
	float Calculate_Membership(float input, float maxUpperMembershipValue);
	float Calculate_Membership_And_Consider_MaxUpperMembershipValue(float input);

	// necessary for fuzzy rule evaluation:
	void Set_MaxUpperMembershipValue(float value);
	// necessary for fuzzy rule evaluation:
	void AddTo_MaxUpperMembershipValue(float value);
	// necessary for fuzzy rule evaluation:
	void Reset_MaxUpperMembershipValue(void);
};

// mathematical description of an element of a linguistic variable (e.g. elements of distance: close, medium, far)
class CAsymmetricGaussianFuzzyElement
{
public:

	int32_t NumOfCentroids = 0;
	float* pRBFFactorArray_LeftHalf = nullptr;
	float* pRBFFactorArray_RightHalf = nullptr;
	float* pFunctionParamArray = nullptr;
	float* pCentroidArray = nullptr;

	float ActualUsedMaxUpperMembershipValue = 1.0f;

	float ValueWithMaxMembership = 0.0f;

	CAsymmetricGaussianFuzzyElement();
	~CAsymmetricGaussianFuzzyElement();

	// Kopierkonstruktor l�schen:
	CAsymmetricGaussianFuzzyElement(const CAsymmetricGaussianFuzzyElement& originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CAsymmetricGaussianFuzzyElement& operator=(const CAsymmetricGaussianFuzzyElement& originalObject) = delete;

	void Set_ValueWithMaxMembership(float value);
	void Initialize(int32_t numOfCentroids);
	void Initialize(int32_t numOfCentroids, float* pRBFFactors_LeftHalf, float* pRBFFactors_RightHalf, float* pFunctionParams, float* pCentroids);
	void Update_Data(float* pRBFFactors_LeftHalf, float* pRBFFactors_RightHalf, float* pFunctionParams, float* pCentroids);

	float Calculate_Membership(float input);
	float Calculate_Membership(float input, float maxUpperMembershipValue);
	float Calculate_Membership_And_Consider_MaxUpperMembershipValue(float input);

	// necessary for fuzzy rule evaluation:
	void Set_MaxUpperMembershipValue(float value);

	// necessary for fuzzy rule evaluation:
	void AddTo_MaxUpperMembershipValue(float value);

	// necessary for fuzzy rule evaluation:
	void Reset_MaxUpperMembershipValue(void);
};


// mathematical description of a linguistic variable (distance, velocity, height, temperature, etc.)
class CGaussianFuzzyRepresentation
{
public:

	int32_t NumOfElements = 0;
	CGaussianFuzzyElement* pElementArray = nullptr;

	float* pMembershipValueArray = nullptr;
	float* pNormalizedMembershipValueArray = nullptr;

	CGaussianFuzzyRepresentation();
	~CGaussianFuzzyRepresentation();

	// Kopierkonstruktor l�schen:
	CGaussianFuzzyRepresentation(const CGaussianFuzzyRepresentation& originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CGaussianFuzzyRepresentation& operator=(const CGaussianFuzzyRepresentation& originalObject) = delete;

	void Initialize(int32_t numOfElements);
	void Initialize_Element(int32_t elementID, int32_t numOfCentroids);
	void Initialize_Element(int32_t elementID, int32_t numOfCentroids, float* pRBFFactors, float* pFunctionParams, float* pCentroids);
	void Update_Element(int32_t elementID, float* pRBFFactors, float* pFunctionParams, float* pCentroids);

	// Call these methods for the antecedents-elements before evaluating the fuzzy rules:
	void Calculate_MembershipValues(float input);
	void Normalize_MembershipValues(void);

	// Call this method for the consequence-elements before evaluating the fuzzy rules:
	void Prepare_FuzzyRulesEvaluation(void);
	
	// Call this method for a consequence-element after evaluating a fuzzy rule:
	void Add_RuleEvaluationResult(int32_t elementID, float resultingMemberShip);

	
	// Defuzzification:
	// Call one of these  method for the consequence-elements after evaluating the fuzzy rules:
	float Calculate_CrispOutput_UseMaxMembershipValues(void);
	float Calculate_CrispOutput(float minInput, float maxInput, int32_t numOfcalculationSteps);
	float Calculate_CrispOutput(float minInput, float maxInput, CRandomNumbersNN* pRandomNumbers, int32_t numOfcalculationSteps);

	float Get_MaxMembership(void);
	void Get_MaxMembership(float* pOutValue, int32_t* pOutBelongingElementID);

	float Get_MaxNormalizedMembership(void);
	void Get_MaxNormalizedMembership(float* pOutValue, int32_t* pOutBelongingElementID);

	float Get_MinMembership(void);
	void Get_MinMembership(float* pOutValue, int32_t* pOutBelongingElementID);

	float Get_MinNormalizedMembership(void);
	void Get_MinNormalizedMembership(float* pOutValue, int32_t* pOutBelongingElementID);

	// This method is called by the  Calculate_CrispOutput()-methods responsible for defuzzification
	float Calculate_MaxMembership_And_Consider_MaxUpperMembershipValues(float input);
};



// mathematical description of a linguistic variable (distance, velocity, height, temperature, etc.)
class CAsymmetricGaussianFuzzyRepresentation
{
public:

	int32_t NumOfElements = 0;
	CAsymmetricGaussianFuzzyElement* pElementArray = nullptr;

	float* pMembershipValueArray = nullptr;
	float* pNormalizedMembershipValueArray = nullptr;

	CAsymmetricGaussianFuzzyRepresentation();
	~CAsymmetricGaussianFuzzyRepresentation();

	// Kopierkonstruktor l�schen:
	CAsymmetricGaussianFuzzyRepresentation(const CAsymmetricGaussianFuzzyRepresentation& originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CAsymmetricGaussianFuzzyRepresentation& operator=(const CAsymmetricGaussianFuzzyRepresentation& originalObject) = delete;

	void Initialize(int32_t numOfElements);
	void Initialize_Element(int32_t elementID, int32_t numOfCentroids);
	void Initialize_Element(int32_t elementID, int32_t numOfCentroids, float* pRBFFactors_LeftHalf, float* pRBFFactors_RightHalf, float* pFunctionParams, float* pCentroids);
	void Update_Element(int32_t elementID, float* pRBFFactors_LeftHalf, float* pRBFFactors_RightHalf, float* pFunctionParams, float* pCentroids);

	// Call these methods for the antecedents-elements before evaluating the fuzzy rules:
	void Calculate_MembershipValues(float input);
	void Normalize_MembershipValues(void);

	// Call this method for the consequence-elements before evaluating the fuzzy rules:
	void Prepare_FuzzyRulesEvaluation(void);
	
	// Call this method for a consequence-element after evaluating a fuzzy rule:
	void Add_RuleEvaluationResult(int32_t elementID, float resultingMemberShip);

	// Defuzzification:
	// Call one of these  method for the consequence-elements after evaluating the fuzzy rules:
	float Calculate_CrispOutput_UseMaxMembershipValues(void);
	float Calculate_CrispOutput(float minInput, float maxInput, int32_t numOfcalculationSteps);
	float Calculate_CrispOutput(float minInput, float maxInput, CRandomNumbersNN* pRandomNumbers, int32_t numOfcalculationSteps);

	
	float Get_MaxMembership(void);
	void Get_MaxMembership(float* pOutValue, int32_t* pOutBelongingElementID);

	float Get_MaxNormalizedMembership(void);
	void Get_MaxNormalizedMembership(float* pOutValue, int32_t* pOutBelongingElementID);

	float Get_MinMembership(void);
	void Get_MinMembership(float* pOutValue, int32_t* pOutBelongingElementID);

	float Get_MinNormalizedMembership(void);
	void Get_MinNormalizedMembership(float* pOutValue, int32_t* pOutBelongingElementID);

	
	// This method is called by the  Calculate_CrispOutput()-methods responsible for defuzzification
	float Calculate_MaxMembership_And_Consider_MaxUpperMembershipValues(float input);
};



class CFuzzyRule_GaussianElements
{
public:

	int32_t NumOfAntecedents = 0;
	CGaussianFuzzyElement** ppAntecedentElementArray = nullptr;

	CGaussianFuzzyElement* pConsequenceElement = nullptr;

	CFuzzyRule_GaussianElements();
	~CFuzzyRule_GaussianElements();

	// Kopierkonstruktor l�schen:
	CFuzzyRule_GaussianElements(const CFuzzyRule_GaussianElements& originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CFuzzyRule_GaussianElements& operator=(const CFuzzyRule_GaussianElements& originalObject) = delete;

	void Initialize(int32_t numOfAntecedents);
	void Set_ConsequenceElement(CGaussianFuzzyElement* pElement);
	void Set_AntecedentElement(int32_t elementID, CGaussianFuzzyElement* pElement);

	void Evaluate_FuzzyAND_Rule(void);
	void Evaluate_FuzzyOR_Rule(void);
};

class CFuzzyRule_AsymmetricGaussianElements
{
public:

	int32_t NumOfAntecedents = 0;
	CAsymmetricGaussianFuzzyElement** ppAntecedentElementArray = nullptr;

	CAsymmetricGaussianFuzzyElement* pConsequenceElement = nullptr;

	CFuzzyRule_AsymmetricGaussianElements();
	~CFuzzyRule_AsymmetricGaussianElements();

	// Kopierkonstruktor l�schen:
	CFuzzyRule_AsymmetricGaussianElements(const CFuzzyRule_AsymmetricGaussianElements& originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CFuzzyRule_AsymmetricGaussianElements& operator=(const CFuzzyRule_AsymmetricGaussianElements& originalObject) = delete;

	void Initialize(int32_t numOfAntecedents);
	void Set_ConsequenceElement(CAsymmetricGaussianFuzzyElement* pElement);
	void Set_AntecedentElement(int32_t elementID, CAsymmetricGaussianFuzzyElement* pElement);

	void Evaluate_FuzzyAND_Rule(void);
	void Evaluate_FuzzyOR_Rule(void);
};

#endif

