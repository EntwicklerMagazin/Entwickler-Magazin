// Schutz vor Mehrfachdeklarationen:

#ifndef _MemoryManagement_H_
#define _MemoryManagement_H_

#include <iostream>

class CSimpleMemoryManager
{
private:

	size_t *UnusedMemoryElementArray;

	/* Mit Hilfe der im UsageStatusArray gespeicherten Daten
	(true/false) l�sst sich sicherstellen, dass der Index
	eines freigegebenen Array-Elements nur ein einziges Mal
	im UnusedMemoryElementArray gespeichert werden kann: */
	bool *UsageStatusArray;

	size_t UnusedMemoryElementArrayID;

public:

	size_t NumMemoryElements;
	size_t NumMemoryElementsMinus1;

	CSimpleMemoryManager();
	~CSimpleMemoryManager();

	// Kopierkonstruktor l�schen:
	CSimpleMemoryManager(const CSimpleMemoryManager &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CSimpleMemoryManager& operator=(const CSimpleMemoryManager &originalObject) = delete;

	bool Initialize(size_t numMemoryElements);

	size_t Request_Unused_MemoryElementID(void);

	bool Free_Used_MemoryElement(size_t id);
};

struct CSimpleLinkedListElement
{
	bool Used;
	size_t PrevElementID;
	size_t NextElementID;

	CSimpleLinkedListElement() : Used(false), PrevElementID(0), NextElementID(0)
	{}

	~CSimpleLinkedListElement()
	{}
};

class CSimpleLinkedListManager
{
private:

	CSimpleLinkedListElement *LinkedListElementArray;

public:

	size_t NumUsedListElements;
	size_t NumListElements;
	size_t NumListElementsMinus1;

	CSimpleLinkedListManager();
	~CSimpleLinkedListManager();

	// Kopierkonstruktor l�schen:
	CSimpleLinkedListManager(const CSimpleLinkedListManager &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CSimpleLinkedListManager& operator=(const CSimpleLinkedListManager &originalObject) = delete;

	bool Initialize(size_t numListElements);

	bool Init_New_ListElement(size_t elementID);

	bool Free_Used_ListElement(size_t elementID);

	size_t Get_Next_Used_ListElement(
		size_t previousListElementID
	/*first ID-Value must be 0*/);
};



#endif