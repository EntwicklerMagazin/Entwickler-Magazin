// Schutz vor Mehrfachdeklarationen :

#ifndef _Ataxx_H_
#define _Ataxx_H_

#pragma warning( disable: 4996)

#include "NeuralCalculationNet.h"
#include "GameStateHandler.h"

static constexpr int32_t ConstGameBoardSizePerDir = 7;
static constexpr int32_t ConstGameBoardSizePerDirMinus1 = ConstGameBoardSizePerDir - 1;
//static constexpr int32_t ConstGameBoardSizePerDirMinus2 = ConstGameBoardSizePerDir - 2;

static constexpr int32_t ConstGameBoardSize = ConstGameBoardSizePerDir * ConstGameBoardSizePerDir;

static constexpr int8_t ConstGameBoard_Empty = 0;
static constexpr int8_t ConstGameBoard_Player1 = 1;
static constexpr int8_t ConstGameBoard_Player2 = 2;
static constexpr int8_t ConstGameBoard_Obstacle = 3;





bool AtaxxPlayer1CloneMoveValidationFunction(int32_t moveStartPosID, int32_t moveEndPosID, int8_t* pInOutGameStateValues);
bool AtaxxPlayer2CloneMoveValidationFunction(int32_t moveStartPosID, int32_t moveEndPosID, int8_t* pInOutGameStateValues);

bool AtaxxPlayer1FinishCloneMoveFunction(int32_t moveStartPosID, int32_t moveEndPosID, int8_t* pInOutGameStateValues);
bool AtaxxPlayer2FinishCloneMoveFunction(int32_t moveStartPosID, int32_t moveEndPosID, int8_t* pInOutGameStateValues);

bool AtaxxHumanPlayerJumpMoveValidationFunction(int32_t moveStartPosID, int32_t moveEndPosID, int8_t* pInOutGameStateValues);
bool AtaxxAIPlayer1JumpMoveValidationFunction(int32_t moveStartPosID, int32_t moveEndPosID, int8_t* pInOutGameStateValues);
bool AtaxxAIPlayer2JumpMoveValidationFunction(int32_t moveStartPosID, int32_t moveEndPosID, int8_t* pInOutGameStateValues);

bool AtaxxPlayer1FinishJumpMoveFunction(int32_t moveStartPosID, int32_t moveEndPosID, int8_t* pInOutGameStateValues);
bool AtaxxPlayer2FinishJumpMoveFunction(int32_t moveStartPosID, int32_t moveEndPosID, int8_t* pInOutGameStateValues);





//extern int32_t g_MaxSearchDepth;
//extern int32_t g_MaxSearchDepth_P1;
//extern int32_t g_MaxSearchDepth_P2;

//static constexpr int32_t ConstMaxEvaluationScore_Minimax = 2000000;
//static constexpr int32_t ConstMinEvaluationScore_Minimax = -2000000;


void Init_AtaxxGameBoard_WithoutObstacles(int8_t* pInOutGameData);

//void Init_AtaxxGameBoard(int8_t* pInOutGameData, CInitialAtaxxBoards* pInitialAtaxxBoards, int32_t boardID);
//void Clone_AtaxxGameBoard(int8_t* pOutGameData, int8_t* pInGameData);

void Calculate_AtaxxScore(int32_t* pOutPlayer1Score, int32_t* pOutPlayer2Score, int8_t* pInGameData);
void Calculate_AtaxxPlayer1Score(int32_t* pOutPlayer1Score, int8_t* pInGameData);
void Calculate_AtaxxPlayer2Score(int32_t* pOutPlayer2Score, int8_t* pInGameData);

bool Check_PossibleAtaxxPlayer1Move(int32_t oldX, int32_t oldY, int32_t newX, int32_t newY, int8_t* pInGameData);
bool Check_PossibleAtaxxPlayer2Move(int32_t oldX, int32_t oldY, int32_t newX, int32_t newY, int8_t* pInGameData);

bool Check_PossibleAtaxxPlayer1Moves(int8_t* pInGameData);
bool Check_PossibleAtaxxPlayer2Moves(int8_t* pInGameData);

bool Check_For_PossibleAtaxxMove(int8_t* pInGameData);

bool Check_PossibleAtaxxPlayer1CloneMove(int32_t newX, int32_t newY, int8_t* pInGameData);
bool Check_PossibleAtaxxPlayer2CloneMove(int32_t newX, int32_t newY, int8_t* pInGameData);

bool Check_PossibleAtaxxPlayer1CloneMove(int32_t newPosID, int8_t* pInGameData);
bool Check_PossibleAtaxxPlayer2CloneMove(int32_t newPosID, int8_t* pInGameData);

bool Get_PossibleAtaxxPlayer1CloneMoveStartPos(int32_t* pOutStartX, int32_t* pOutStartY, int32_t newX, int32_t newY, int8_t* pInGameData);
bool Get_PossibleAtaxxPlayer2CloneMoveStartPos(int32_t* pOutStartX, int32_t* pOutStartY, int32_t newX, int32_t newY, int8_t* pInGameData);

bool Get_PossibleAtaxxPlayer1CloneMoveStartPos(int32_t* pOutStartX, int32_t* pOutStartY, int32_t newPosID, int8_t* pInGameData);
bool Get_PossibleAtaxxPlayer2CloneMoveStartPos(int32_t* pOutStartX, int32_t* pOutStartY, int32_t newPosID, int8_t* pInGameData);

void Make_AtaxxPlayer1Move(int32_t oldX, int32_t oldY, int32_t newX, int32_t newY, int8_t* pInOutGameData);
void Make_AtaxxPlayer2Move(int32_t oldX, int32_t oldY, int32_t newX, int32_t newY, int8_t* pInOutGameData);

void Make_AtaxxPlayer1CloneMove(int32_t newX, int32_t newY, int8_t* pInOutGameData);
void Make_AtaxxPlayer2CloneMove(int32_t newX, int32_t newY, int8_t* pInOutGameData);


void Evaluate_LeafGameStates_AtaxxPlayer1View(CExtendedGameStatePool* pGameStatePool);
void Evaluate_LeafGameStates_AtaxxPlayer2View(CExtendedGameStatePool* pGameStatePool);

void Evaluate_LeafGameStates_AtaxxPlayer1View(CExtendedGameStatePool* pGameStatePool, CMovePatternList* pPlayer1MoveList, CMovePatternList* pPlayer2MoveList);
void Evaluate_LeafGameStates_AtaxxPlayer2View(CExtendedGameStatePool* pGameStatePool, CMovePatternList* pPlayer1MoveList, CMovePatternList* pPlayer2MoveList);

void Evaluate_LeafGameStates_AtaxxPlayer1View(CExtendedGameStatePool* pGameStatePool, int32_t depth);
void Evaluate_LeafGameStates_AtaxxPlayer2View(CExtendedGameStatePool* pGameStatePool, int32_t depth);


void Evaluate_GameStates_AtaxxPlayer1View(CExtendedGameStatePool* pGameStatePool);
void Evaluate_GameStates_AtaxxPlayer2View(CExtendedGameStatePool* pGameStatePool);

void Evaluate_LeafGameStates_AtaxxPlayer1View(CGameStatePool_SimpleGameTree* pGameStatePool);
void Evaluate_LeafGameStates_AtaxxPlayer2View(CGameStatePool_SimpleGameTree* pGameStatePool);

void Evaluate_GameStates_AtaxxPlayer1View(CGameStatePool_SimpleGameTree* pGameStatePool);
void Evaluate_GameStates_AtaxxPlayer2View(CGameStatePool_SimpleGameTree* pGameStatePool);

void Evaluate_GameState_AtaxxPlayer1View(int32_t gameStateID, CExtendedGameStatePool* pGameStatePool);
void Evaluate_GameState_AtaxxPlayer2View(int32_t gameStateID, CExtendedGameStatePool* pGameStatePool);

int32_t Evaluate_GameState_AtaxxPlayer1View(int8_t* pGameState);
int32_t Evaluate_GameState_AtaxxPlayer2View(int8_t* pGameState);


void Evaluate_GameState_AtaxxPlayer1View(int32_t gameStateID, CExtendedGameStatePool* pGameStatePool, CMovePatternList* pPlayer1MoveList, CMovePatternList* pPlayer2MoveList);
void Evaluate_GameState_AtaxxPlayer2View(int32_t gameStateID, CExtendedGameStatePool* pGameStatePool, CMovePatternList* pPlayer1MoveList, CMovePatternList* pPlayer2MoveList);


bool CheckGameStateEvaluation_AtaxxPlayer1View(CGameStateValues* pGameState, int32_t minTolerableEvalValue, CMovePatternList* pPlayer1MoveList, CMovePatternList* pPlayer2MoveList);
bool CheckGameStateEvaluation_AtaxxPlayer2View(CGameStateValues* pGameState, int32_t minTolerableEvalValue, CMovePatternList* pPlayer1MoveList, CMovePatternList* pPlayer2MoveList);

void Check_AtaxxLeafGameStates(CExtendedGameStatePool* pGameStatePool);




class CAtaxxTestMove
{
public:

	int32_t BoardPosID = 0;
	int32_t ResultingGameStateObjectID = -1;

	CAtaxxTestMove();
	~CAtaxxTestMove();

	void Prepare_Move(int32_t boardPosID);

	int32_t Player1Move_If_Possible(CGameStateValues** ppOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool* pGameStatePool, int32_t depthLayer, bool resultingGameStateIsMaximizer);
	int32_t Player2Move_If_Possible(CGameStateValues** ppOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool* pGameStatePool, int32_t depthLayer, bool resultingGameStateIsMaximizer);

	int32_t Player1Move_If_Possible(CGameStateValues* pInActualGameState, CExtendedGameStatePool* pGameStatePool, int32_t depthLayer, bool resultingGameStateIsMaximizer);
	int32_t Player2Move_If_Possible(CGameStateValues* pInActualGameState, CExtendedGameStatePool* pGameStatePool, int32_t depthLayer, bool resultingGameStateIsMaximizer);
};

class CAtaxxBreadthFirstSearchAI
{
public:

	int32_t MaxSearchDepth = 0;
	int32_t NumTestGameStatesMax = 0;
	int32_t NumTestGameStatesMaxPerDepthLayer = 0;

	CExtendedGameStatePool GameStatePool;

	CAtaxxTestMove AtaxxTestMove;

	CRandomNumbersNN RandomNumbers;

	CAtaxxBreadthFirstSearchAI();
	~CAtaxxBreadthFirstSearchAI();

	// Kopierkonstruktor l�schen:
	CAtaxxBreadthFirstSearchAI(const CAtaxxBreadthFirstSearchAI& originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CAtaxxBreadthFirstSearchAI& operator=(const CAtaxxBreadthFirstSearchAI& originalObject) = delete;

	void Initialize(int32_t numTestGameStatesMax, int32_t numTestGameStatesMaxPerDepthLayer, int32_t maxSearchDepth);

	void Change_Seed(uint64_t seed);

	void Execute_Player1AI(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState);
	void Execute_Player2AI(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState);

	void Execute_Player1AI(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, float *pSearchDepthMovementProbabilityArray);
	void Execute_Player2AI(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, float *pSearchDepthMovementProbabilityArray);
};

class CAtaxxDepthFirstSearchAI
{
public:

	int32_t MaxSearchDepth = 0;
	int32_t MaxSearchDepthMinus1 = 0;
	int32_t NumTestGameStatesMax = 0;

	CExtendedGameStatePool GameStatePool;

	CAtaxxTestMove* pAtaxxTestMoveArray = nullptr;

	int32_t DesiredEvaluationValue = 2;
	int32_t EarlyOutCounter = 0;

	CAtaxxDepthFirstSearchAI();
	~CAtaxxDepthFirstSearchAI();

	// Kopierkonstruktor l�schen:
	CAtaxxDepthFirstSearchAI(const CAtaxxDepthFirstSearchAI& originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CAtaxxDepthFirstSearchAI& operator=(const CAtaxxDepthFirstSearchAI& originalObject) = delete;

	void Initialize(int32_t numTestGameStatesMax, int32_t maxSearchDepth);

	void Execute_Player1AI_SearchDepth2(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState);
	void Execute_Player1AI_SearchDepth3(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState);
	void Execute_Player1AI_SearchDepth4(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState);
	void Execute_Player1AI_SearchDepth5(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState);
	void Execute_Player1AI_SearchDepth6(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState);

	void Execute_Player2AI_SearchDepth2(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState);
	void Execute_Player2AI_SearchDepth3(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState);
	void Execute_Player2AI_SearchDepth4(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState);
	void Execute_Player2AI_SearchDepth5(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState);
	void Execute_Player2AI_SearchDepth6(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState);


	void Execute_Player1AI(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState);
	void Execute_Player2AI(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState);

	bool Player1AI_InnerEvalulationLoop(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth);
	bool Player2AI_InnerEvalulationLoop(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth);

	bool Player1AI_OuterEvalulationLoop(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth);
	bool Player2AI_OuterEvalulationLoop(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth);

	void Execute_Player1AI_EarlyOut(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState);
	void Execute_Player2AI_EarlyOut(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState);

	bool Player1AI_InnerEvalulationLoop_EarlyOut(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth);
	bool Player2AI_InnerEvalulationLoop_EarlyOut(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth);

	bool Player1AI_OuterEvalulationLoop_EarlyOut(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth);
	bool Player2AI_OuterEvalulationLoop_EarlyOut(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth);

};


#endif