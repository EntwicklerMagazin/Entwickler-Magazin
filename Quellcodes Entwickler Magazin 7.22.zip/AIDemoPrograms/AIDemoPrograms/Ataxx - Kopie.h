// Schutz vor Mehrfachdeklarationen :

#ifndef _Ataxx_H_
#define _Ataxx_H_

#pragma warning( disable: 4996)

#include "NeuralCalculationNet.h"
#include "GameStateHandler.h"

static constexpr int32_t ConstGameBoardSizePerDir = 7;
static constexpr int32_t ConstGameBoardSizePerDirMinus1 = ConstGameBoardSizePerDir - 1;
//static constexpr int32_t ConstGameBoardSizePerDirMinus2 = ConstGameBoardSizePerDir - 2;

static constexpr int32_t ConstGameBoardSize = ConstGameBoardSizePerDir * ConstGameBoardSizePerDir;

static constexpr int8_t ConstGameBoard_Empty = 0;
static constexpr int8_t ConstGameBoard_Player1 = 1;
static constexpr int8_t ConstGameBoard_Player2 = 2;
static constexpr int8_t ConstGameBoard_Obstacle = 3;

class CInitialAtaxxBoards
{
public:

	int32_t NumOfInitialAtaxxBoards = 0;
	CGameStateValues* pInitialGameStateArray = nullptr;

	CInitialAtaxxBoards();
	~CInitialAtaxxBoards();

	// Kopierkonstruktor l�schen:
	CInitialAtaxxBoards(const CInitialAtaxxBoards& originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CInitialAtaxxBoards& operator=(const CInitialAtaxxBoards& originalObject) = delete;

	bool Initialize(const char* pFilename);
};

extern int32_t g_MaxSearchDepth;
extern int32_t g_MaxSearchDepth_P1;
extern int32_t g_MaxSearchDepth_P2;

static constexpr int32_t ConstMaxEvaluationScore_Minimax = 1000000;
static constexpr int32_t ConstMinEvaluationScore_Minimax = -1000000;

void Init_GameBoard_WithoutObstacles(int8_t* pInOutGameData);
void Init_GameBoard(int8_t* pInOutGameData, CInitialAtaxxBoards* pInitialAtaxxBoards, int32_t boardID);

void Clone_GameBoard(int8_t* pOutGameData, int8_t* pInGameData);

void Calculate_Score(int32_t* pOutPlayer1Score, int32_t* pOutPlayer2Score, int8_t* pInGameData);
void Calculate_Player1Score(int32_t* pOutPlayer1Score, int8_t* pInGameData);
void Calculate_Player2Score(int32_t* pOutPlayer2Score, int8_t* pInGameData);

bool Check_PossiblePlayer1Move(int32_t oldX, int32_t oldY, int32_t newX, int32_t newY, int8_t* pInGameData);
bool Check_PossiblePlayer2Move(int32_t oldX, int32_t oldY, int32_t newX, int32_t newY, int8_t* pInGameData);

bool Check_PossiblePlayer1Moves(int8_t* pInGameData);
bool Check_PossiblePlayer2Moves(int8_t* pInGameData);

bool Check_For_PossibleMove(int8_t* pInGameData);

bool Check_PossiblePlayer1CloneMove(int32_t newX, int32_t newY, int8_t* pInGameData);
bool Check_PossiblePlayer2CloneMove(int32_t newX, int32_t newY, int8_t* pInGameData);

bool Check_PossiblePlayer1CloneMove(int32_t newPosID, int8_t* pInGameData);
bool Check_PossiblePlayer2CloneMove(int32_t newPosID, int8_t* pInGameData);

bool Get_PossiblePlayer1CloneMoveStartPos(int32_t* pOutStartX, int32_t* pOutStartY, int32_t newX, int32_t newY, int8_t* pInGameData);
bool Get_PossiblePlayer2CloneMoveStartPos(int32_t* pOutStartX, int32_t* pOutStartY, int32_t newX, int32_t newY, int8_t* pInGameData);

bool Get_PossiblePlayer1CloneMoveStartPos(int32_t* pOutStartX, int32_t* pOutStartY, int32_t newPosID, int8_t* pInGameData);
bool Get_PossiblePlayer2CloneMoveStartPos(int32_t* pOutStartX, int32_t* pOutStartY, int32_t newPosID, int8_t* pInGameData);

void Make_Player1Move(int32_t oldX, int32_t oldY, int32_t newX, int32_t newY, int8_t* pInOutGameData);
void Make_Player2Move(int32_t oldX, int32_t oldY, int32_t newX, int32_t newY, int8_t* pInOutGameData);

void Make_Player1CloneMove(int32_t newX, int32_t newY, int8_t* pInOutGameData);
void Make_Player2CloneMove(int32_t newX, int32_t newY, int8_t* pInOutGameData);

int32_t Minimax_Player1MoveEvaluation(CGameStateValues* pInActualGameState, CSimpleGameStatePool* pGameStatePool, int32_t searchDepth, int32_t searchDepthMax, bool searchForMaximum, int32_t alpha, int32_t beta);
int32_t Minimax_Player2MoveEvaluation(CGameStateValues* pInActualGameState, CSimpleGameStatePool* pGameStatePool, int32_t searchDepth, int32_t searchDepthMax, bool searchForMaximum, int32_t alpha, int32_t beta);

void Minimax_Player1(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, CSimpleGameStatePool* pGameStatePool, int32_t maxSearchDepth);
void Minimax_Player2(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, CSimpleGameStatePool* pGameStatePool, int32_t maxSearchDepth);

void ExtMinimax_Player1(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, CSimpleGameStatePool* pGameStatePool, int32_t maxSearchDepth);
void ExtMinimax_Player2(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, CSimpleGameStatePool* pGameStatePool, int32_t maxSearchDepth);


void Evaluate_LeafGameStates_Player1View(CExtendedGameStatePool* pGameStatePool);
void Evaluate_LeafGameStates_Player2View(CExtendedGameStatePool* pGameStatePool);

void Evaluate_GameStates_Player1View(CExtendedGameStatePool* pGameStatePool);
void Evaluate_GameStates_Player2View(CExtendedGameStatePool* pGameStatePool);

void Evaluate_LeafGameStates_Player1View(CGameStatePool_SimpleGameTree* pGameStatePool);
void Evaluate_LeafGameStates_Player2View(CGameStatePool_SimpleGameTree* pGameStatePool);

void Evaluate_GameStates_Player1View(CGameStatePool_SimpleGameTree* pGameStatePool);
void Evaluate_GameStates_Player2View(CGameStatePool_SimpleGameTree* pGameStatePool);



void BreadthFirstSearch_Player1(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool* pGameStatePool, int32_t numTestGameStatesMaxPerDepthLayer, int32_t maxSearchDepth);
void BreadthFirstSearch_Player2(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool* pGameStatePool, int32_t numTestGameStatesMaxPerDepthLayer, int32_t maxSearchDepth);

void BreadthFirstSearch_Player1(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool* pGameStatePool, int32_t numTestGameStatesMaxPerDepthLayer, int32_t maxSearchDepth, CRandomNumbersNN* pRandomNumbers, float movementProbability_SearchDepth2, float movementProbability_SearchDepth3, float movementProbability_SearchDepth4);
void BreadthFirstSearch_Player2(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool* pGameStatePool, int32_t numTestGameStatesMaxPerDepthLayer, int32_t maxSearchDepth, CRandomNumbersNN* pRandomNumbers, float movementProbability_SearchDepth2, float movementProbability_SearchDepth3, float movementProbability_SearchDepth4);






#endif