// Schutz vor Mehrfachdeklarationen:
#ifndef _RandomNumbers_H_
#define _RandomNumbers_H_

#include <iostream>

static constexpr int32_t ConstNumOfPrimeNumbersUpTo1000 = 168;

static constexpr int32_t ConstPrimeNumberArray[ConstNumOfPrimeNumbersUpTo1000] = {
2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113, 127, 131,
137, 139, 149, 151, 157, 163, 167, 173, 179, 181, 191, 193, 197, 199, 211, 223, 227, 229, 233, 239, 241, 251, 257, 263, 269, 271,
277, 281, 283, 293, 307, 311, 313, 317, 331, 337, 347, 349, 353, 359, 367, 373, 379, 383, 389, 397, 401, 409, 419, 421, 431, 433, 439, 443,
449, 457, 461, 463, 467, 479, 487, 491, 499, 503, 509, 521, 523, 541, 547, 557, 563, 569, 571, 577, 587, 593, 599, 601, 607, 613, 617,
619, 631, 641, 643, 647, 653, 659, 661, 673, 677, 683, 691, 701, 709, 719, 727, 733, 739, 743, 751, 757, 761, 769, 773, 787, 797,
809, 811, 821, 823, 827, 829, 839, 853, 857, 859, 863, 877, 881, 883, 887, 907, 911, 919, 929, 937, 941, 947, 953, 967, 971, 977, 983, 991, 997 };

static constexpr float fConstPrimeNumberArray[ConstNumOfPrimeNumbersUpTo1000] = {
	2.0f, 3.0f, 5.0f, 7.0f, 11.0f, 13.0f, 17.0f, 19.0f, 23.0f, 29.0f, 31.0f, 37.0f, 41.0f, 43.0f, 47.0f, 53.0f, 59.0f, 61.0f, 67.0f, 71.0f, 73.0f, 79.0f, 83.0f, 89.0f, 97.0f, 101.0f, 103.0f, 107.0f, 109.0f, 113.0f, 127.0f, 131.0f,
	137.0f, 139.0f, 149.0f, 151.0f, 157.0f, 163.0f, 167.0f, 173.0f, 179.0f, 181.0f, 191.0f, 193.0f, 197.0f, 199.0f, 211.0f, 223.0f, 227.0f, 229.0f, 233.0f, 239.0f, 241.0f, 251.0f, 257.0f, 263.0f, 269.0f, 271.0f,
	277.0f, 281.0f, 283.0f, 293.0f, 307.0f, 311.0f, 313.0f, 317.0f, 331.0f, 337.0f, 347.0f, 349.0f, 353.0f, 359.0f, 367.0f, 373.0f, 379.0f, 383.0f, 389.0f, 397.0f, 401.0f, 409.0f, 419.0f, 421.0f, 431.0f, 433.0f, 439.0f, 443.0f,
	449.0f, 457.0f, 461.0f, 463.0f, 467.0f, 479.0f, 487.0f, 491.0f, 499.0f, 503.0f, 509.0f, 521.0f, 523.0f, 541.0f, 547.0f, 557.0f, 563.0f, 569.0f, 571.0f, 577.0f, 587.0f, 593.0f, 599.0f, 601.0f, 607.0f, 613.0f, 617.0f,
	619.0f, 631.0f, 641.0f, 643.0f, 647.0f, 653.0f, 659.0f, 661.0f, 673.0f, 677.0f, 683.0f, 691.0f, 701.0f, 709.0f, 719.0f, 727.0f, 733.0f, 739.0f, 743.0f, 751.0f, 757.0f, 761.0f, 769.0f, 773.0f, 787.0f, 797.0f,
	809.0f, 811.0f, 821.0f, 823.0f, 827.0f, 829.0f, 839.0f, 853.0f, 857.0f, 859.0f, 863.0f, 877.0f, 881.0f, 883.0f, 887.0f, 907.0f, 911.0f, 919.0f, 929.0f, 937.0f, 941.0f, 947.0f, 953.0f, 967.0f, 971.0f, 977.0f, 983.0f, 991.0f, 997.0f };

//namespace HelperStuff
//{

class CRandomNumbers_ParkMillerMLKG;
class CRandomNumbersNN;

static constexpr int32_t ConstRandomNumbersTableSize = 10000;
static constexpr int32_t ConstRandomNumbersTableSizeMinus1 = ConstRandomNumbersTableSize - 1;

extern int32_t g_iRandomNumbersTable[ConstRandomNumbersTableSize];
extern float g_fRandomNumbersTable[ConstRandomNumbersTableSize];

void Init_iRandomNumbersTable(CRandomNumbersNN *pRandomNumbers, int32_t minValue, int32_t maxValue);
void Init_iRandomNumbersTableExt(CRandomNumbersNN *pRandomNumbers, int32_t minValue, int32_t maxValue, int32_t minAbsValue);
void Init_iRandomNumbersTableExt2(CRandomNumbersNN *pRandomNumbers, int32_t minValue, int32_t maxValue, int32_t maxAbsValue);
void Init_iRandomNumbersTableExt3(CRandomNumbersNN *pRandomNumbers, int32_t minValue, int32_t maxValue, int32_t minAbsValue, int32_t maxAbsValue);

void Init_fRandomNumbersTable(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue);
void Init_fRandomNumbersTableExt(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float minAbsValue);
void Init_fRandomNumbersTableExt2(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float maxAbsValue);
void Init_fRandomNumbersTableExt3(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float minAbsValue, float maxAbsValue);


void Init_RandomNumbersTable(int32_t *pOutRandomNumbersArray, int32_t arraySize, CRandomNumbersNN *pRandomNumbers, int32_t minValue, int32_t maxValue);
void Init_RandomNumbersTableExt(int32_t *pOutRandomNumbersArray, int32_t arraySize, CRandomNumbersNN *pRandomNumbers, int32_t minValue, int32_t maxValue, int32_t minAbsValue);
void Init_RandomNumbersTableExt2(int32_t *pOutRandomNumbersArray, int32_t arraySize, CRandomNumbersNN *pRandomNumbers, int32_t minValue, int32_t maxValue, int32_t maxAbsValue);
void Init_RandomNumbersTableExt3(int32_t *pOutRandomNumbersArray, int32_t arraySize, CRandomNumbersNN *pRandomNumbers, int32_t minValue, int32_t maxValue, int32_t minAbsValue, int32_t maxAbsValue);

void Init_RandomNumbersTable(float *pOutRandomNumbersArray, int32_t arraySize, CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue);
void Init_RandomNumbersTableExt(float *pOutRandomNumbersArray, int32_t arraySize, CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float minAbsValue);
void Init_RandomNumbersTableExt2(float *pOutRandomNumbersArray, int32_t arraySize, CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float maxAbsValue);
void Init_RandomNumbersTableExt3(float *pOutRandomNumbersArray, int32_t arraySize, CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float minAbsValue, float maxAbsValue);


class CRandomNumbers_ParkMillerMLKG
{
private:

	/* Deklaration der ben�tigten Membervariablen und
	Konstanten. Ein �ffentlicher Zugriff ist im
	vorliegenden Fall nicht m�glich (weil nicht
	erforderlich): */

	uint64_t newValue;

	static constexpr uint64_t constParkMillerModulus =
		2147483647;
	static constexpr uint64_t constParkMillerMultiplier =
		48271;
	static constexpr double fconstParkMillerModulus =
		2147483647.0;

public:

	// Konstruktor (Deklaration):
	CRandomNumbers_ParkMillerMLKG();

	// Destruktor (Deklaration):
	~CRandomNumbers_ParkMillerMLKG();

	/* Deklaration der �ffentlich aufrufbaren
	Memberfunktionen (Klassenmethoden): */

	/* Neuen Startwert f�r die Berechnung der
	Zufallszahlen festlegen */
	void Change_Seed(uint64_t newSeed);

	/* Hinweis: Memberfunktionen lassen sich auch innerhalb
	einer Klassendeklarationen implementieren: */
	/*void Change_Seed( uint64_t newSeed)
	{
	newValue = newSeed;
	}*/

	/* Startwert f�r die Berechnung der Zufallszahlen
	auf 1 zur�cksetzen */
	void Reset_Seed(void);

	// zuf�llige 32-Bit-Flie�kommazahlen:
	float Get_FloatNumber(float low, float high);

	// zuf�llige 64-Bit-Flie�kommazahlen:
	double Get_DoubleNumber(double low, double high);

	// zuf�llige 32-Bit-Ganzzahlen:
	int32_t Get_IntegerNumber(int32_t low,
		int32_t high_excluded);

	// zuf�llige positive 32-Bit-Ganzzahlen:
	uint32_t Get_UnsignedIntegerNumber(uint32_t low,
		uint32_t high_excluded);

}; // end of class CRandomNumbers_ParkMillerMLKG

class CRandomNumbersNN
{
	/* Klassenelemente, die �ffentlich nicht
	einsehbar sind: */
private:

	/* Deklaration der ben�tigten Membervariablen und
	Konstanten. Ein �ffentlicher Zugriff ist im
	vorliegenden Fall nicht m�glich (weil nicht
	erforderlich): */

	uint64_t newValue = 1;

	static constexpr uint64_t constParkMillerModulus =
		2147483647;
	static constexpr uint64_t constParkMillerMultiplier =
		48271;
	static constexpr double fconstParkMillerModulus =
		2147483647.0;

	float precision = 0.001f;
	float invPrecision = 1000.0f;

	// �ffentlich einsehbare Klassenelemente:
public:

	// Konstruktor (Deklaration):
	CRandomNumbersNN();

	// Destruktor (Deklaration):
	~CRandomNumbersNN();

	/* Deklaration der �ffentlich aufrufbaren
	Memberfunktionen (Klassenmethoden): */

	/* Neuen Startwert f�r die Berechnung der
	Zufallszahlen festlegen: */
	void Change_Seed(uint64_t newSeed);

	/* Hinweis: Memberfunktionen lassen sich auch innerhalb
	einer Klassendeklarationen implementieren: */
	/*void Change_Seed( uint64_t newSeed)
	{
	newValue = newSeed;
	}*/

	uint64_t Get_Seed(void);

	/* Startwert f�r die Berechnung der Zufallszahlen
	auf 1 zur�cksetzen */
	void Reset_Seed(void);

	void Set_Precision(float value);

	// zuf�llige 32-Bit-Flie�kommazahlen:
	float Get_FloatNumber(float low, float high);
	float Get_FloatNumber(float low, float high, float zeroSubstitutionValue);
	float Get_RoundedFloatNumber(float low, float high);
	

	float Get_FloatNumber_IncludingZero(float low, float high);
	float Get_RoundedFloatNumber_IncludingZero(float low, float high);

	// zuf�llige 64-Bit-Flie�kommazahlen:
	double Get_DoubleNumber(double low, double high);
	double Get_DoubleNumber(double low, double high, double zeroSubstitutionValue);
	double Get_DoubleNumber_IncludingZero(double low, double high);

	// zuf�llige 32-Bit-Ganzzahlen:
	int32_t Get_IntegerNumber(int32_t low,
		int32_t high_excluded);

	int32_t Get_IntegerNumber2(int32_t low,
		int32_t high);

	// zuf�llige positive 32-Bit-Ganzzahlen:
	uint32_t Get_UnsignedIntegerNumber(uint32_t low,
		uint32_t high_excluded);

	uint32_t Get_UnsignedIntegerNumber2(uint32_t low,
		uint32_t high);

}; // end of class CRandomNumbersNN

//} /* end of namespace HelperStuff */

class CPermutation
{
public:

	CRandomNumbersNN RandomNumbers;

	CPermutation();
	~CPermutation();

	void Calculate_Permutation(int32_t *pInputOutputVector, int32_t minVectorElement, int32_t maxVectorElement, int32_t permutationSteps);
	void Calculate_Permutation(float *pInputOutputVector, int32_t minVectorElement, int32_t maxVectorElement, int32_t permutationSteps);

	// example: (0, a1, a2, a3, 0) + (0, b1, b2, b3, 0) => (0, b1, a2, a3, 0)
	void Combine_Vectors(int32_t *pOutputVector, int32_t *pInputVector1, int32_t *pInputVector2, int32_t numVectorElements, /*numVectorElements*2:*/ int32_t *pTempVector );
	void Combine_Vectors(float *pOutputVector, float *pInputVector1, float *pInputVector2, int32_t numVectorElements, /*numVectorElements*2:*/ float *pTempVector);
};

class CCombinationPairs
{
public:

	int32_t NumOfElements = 0;
	int32_t NumOfCombinations = 0;

	int32_t *pElement1_List = nullptr;
	int32_t *pElement2_List = nullptr;

	CCombinationPairs();
	~CCombinationPairs();

	// Kopierkonstruktor l�schen:
	CCombinationPairs(const CCombinationPairs  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CCombinationPairs & operator=(const CCombinationPairs  &originalObject) = delete;

	void Set_NumOfElements(int32_t number);
};



#endif