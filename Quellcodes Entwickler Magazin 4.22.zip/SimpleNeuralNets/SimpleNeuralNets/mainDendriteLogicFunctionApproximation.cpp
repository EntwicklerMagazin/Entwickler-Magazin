#include <iostream>
#include "NeuralNet_V2.h"

using namespace std;


// Dendnritische Funktionen:

inline void LogicFunctionApproximationDendriticFunction_2Inputs(CNeuronV2 *pNeuron)
{
	pNeuron->Dendrite_InputCounter = 0;

	float input1 = pNeuron->pDendrite_InputValueArray[0];
	float input2 = pNeuron->pDendrite_InputValueArray[1];

	//pNeuron->pDendrite_InputValueArray[2] = max(input1, input2);
	//pNeuron->pDendrite_InputValueArray[2] = min(input1, input2);
	pNeuron->pDendrite_InputValueArray[2] = input1 * input2;
	//pNeuron->pDendrite_InputValueArray[2] = (input1 + input2)*(input1 + input2);

	pNeuron->pDendrite_InputValueArray[3] = 1.0f;
}

inline void LogicFunctionApproximationDendriticFunction_3Inputs(CNeuronV2 *pNeuron)
{
	pNeuron->Dendrite_InputCounter = 0;

	float input1 = pNeuron->pDendrite_InputValueArray[0];
	float input2 = pNeuron->pDendrite_InputValueArray[1];
	float input3 = pNeuron->pDendrite_InputValueArray[2];

	
	pNeuron->pDendrite_InputValueArray[3] = input1 * input2;
	pNeuron->pDendrite_InputValueArray[4] = input1 * input3; 
	pNeuron->pDendrite_InputValueArray[5] = input2 * input3;

	pNeuron->pDendrite_InputValueArray[6] = input1 *input2 * input3;

	pNeuron->pDendrite_InputValueArray[7] = 1.0f;
}

inline void LogicFunctionApproximationDendriticFunction_4Inputs(CNeuronV2 *pNeuron)
{
	pNeuron->Dendrite_InputCounter = 0;

	float input1 = pNeuron->pDendrite_InputValueArray[0];
	float input2 = pNeuron->pDendrite_InputValueArray[1];
	float input3 = pNeuron->pDendrite_InputValueArray[2];
	float input4 = pNeuron->pDendrite_InputValueArray[3];


	pNeuron->pDendrite_InputValueArray[4] = input1 * input2;
	pNeuron->pDendrite_InputValueArray[5] = input1 * input3;
	pNeuron->pDendrite_InputValueArray[6] = input1 * input4;

	pNeuron->pDendrite_InputValueArray[7] = input2 * input3;
	pNeuron->pDendrite_InputValueArray[8] = input2 * input4;

	pNeuron->pDendrite_InputValueArray[9] = input3 * input4;

	pNeuron->pDendrite_InputValueArray[10] = input1 * input2 * input3;
	pNeuron->pDendrite_InputValueArray[11] = input1 * input2 * input4;
	pNeuron->pDendrite_InputValueArray[12] = input1 * input3 * input4;
	pNeuron->pDendrite_InputValueArray[13] = input2 * input3 * input4;

	pNeuron->pDendrite_InputValueArray[14] = 1.0f;
}

inline void LogicFunctionApproximationDendriticFunction_4Inputs_20(CNeuronV2 *pNeuron)
{
	pNeuron->Dendrite_InputCounter = 0;

	float inputArray[5];

	for(int32_t i = 0; i < 4; i++)
		inputArray[i] = pNeuron->pDendrite_InputValueArray[i];

	// Bias:
	inputArray[4] = 1.0f;
	
	int32_t counter = pNeuron->RandomSeedValue;
	float tempValue;

	for (int32_t i = 0; i < 20; i++)
	{
		tempValue = 0.0f;

		for (int32_t j = 0; j < 5; j++)
		{
			tempValue += g_fRandomNumbersTable[counter] * inputArray[j];
			counter++;
		}

		tempValue *= 6.0f;
		pNeuron->pDendrite_InputValueArray[i] = 0.5f + 0.5f*(tempValue / (1.0f + abs(tempValue)));
		//pNeuron->pDendrite_InputValueArray[i] = 1.0f / (1.0f + exp(-20.0f * tempValue));
	}
}


// 2 + 1 dim Input => 10 dim Input
inline void LogicFunctionApproximationDendriticFunction_2Inputs_To_10(CNeuronV2 *pNeuron)
{
	float *pInputArray = pNeuron->pDendrite_InputValueArray;

	// Bias:
	pInputArray[2] = 1.0f;

	int32_t counter = pNeuron->RandomSeedValue;
	float tempValue;

	for(int32_t i = 3; i < 13; i++)
	{
		tempValue = 0.0f;

		for (int32_t j = 0; j < 3; j++)
		{
			tempValue += g_fRandomNumbersTable[counter] * pInputArray[j];
			counter++;
		}

		tempValue *= 10.0f;
		pNeuron->pDendrite_InputValueArray[i] = tempValue / (1.0f + abs(tempValue));
	}
}

// 2 + 1 dim Input => 20 dim Input
inline void LogicFunctionApproximationDendriticFunction_2Inputs_To_20(CNeuronV2 *pNeuron)
{
	float *pInputArray = pNeuron->pDendrite_InputValueArray;

	// Bias:
	pInputArray[2] = 1.0f;

	int32_t counter = pNeuron->RandomSeedValue;
	float tempValue;

	for (int32_t i = 3; i < 23; i++)
	{
		tempValue = 0.0f;

		for (int32_t j = 0; j < 3; j++)
		{
			tempValue += g_fRandomNumbersTable[counter] * pInputArray[j];
			counter++;
		}


		tempValue *= 2.0f;
		pNeuron->pDendrite_InputValueArray[i] = tempValue / (1.0f + abs(tempValue));
	}
}



// Aktivierungsfunktionen:

inline void LogicFunctionApproximationOutputFunction1(CNeuronV2 *pNeuron)
{
	float output = 0.0f;

	int32_t numDendrites = pNeuron->Num_Of_Dendrite_Elements;

	for (int32_t i = 0; i < numDendrites; i++)
	{
		output += pNeuron->pDendrite_FactorArray[i] * pNeuron->pDendrite_InputValueArray[i];
	}
	
	pNeuron->NeuronOutput = min(1.0f, max(0.0f, output));
	pNeuron->NeuronInput = 0.0f;
}

inline void LogicFunctionApproximationOutputFunction2(CNeuronV2 *pNeuron)
{
	float output = 0.0f;

	int32_t numDendrites = pNeuron->Num_Of_Dendrite_Elements;

	for(int32_t i = 0; i < numDendrites; i++)
	{
		output += pNeuron->pDendrite_FactorArray[i] * pNeuron->pDendrite_InputValueArray[i];
	}

	
	pNeuron->NeuronOutput = output;

	pNeuron->NeuronInput = 0.0f;
}

inline void LogicFunctionApproximationOutputFunction3(CNeuronV2 *pNeuron)
{
	float output = 0.0f;

	int32_t numDendrites = pNeuron->Num_Of_Dendrite_Elements;

	for (int32_t i = 0; i < numDendrites; i++)
	{
		output += pNeuron->pDendrite_FactorArray[i] * pNeuron->pDendrite_InputValueArray_OtherNeuron[i];
	}


	pNeuron->NeuronOutput = output;

	pNeuron->NeuronInput = 0.0f;
}


/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	// XOR-Inputs:
	float InputArray1[2] = { 0.0f, 0.0f };
	float InputArray2[2] = { 1.0f, 0.0f };
	float InputArray3[2] = { 0.0f, 1.0f };
	float InputArray4[2] = { 1.0f, 1.0f };

	// zus�tzliche Inputs:
	float InputArray5[2] = { 0.5f, 1.0f };
	float InputArray6[2] = { 1.0f, 0.5f };

	// XOR-Outputs:
	float DesiredOutput1 = 0.0f;
	float DesiredOutput2 = 1.0f;
	float DesiredOutput3 = 1.0f;
	float DesiredOutput4 = 0.0f;

	// zus�tzliche Outputs:
	float DesiredOutput5 = 0.3f;
	float DesiredOutput6 = 0.6f;

	CNeuronV2 Neuron;

	Neuron.Init_Dendrite_Arrays(4);
	Neuron.Set_DendriticFunction(LogicFunctionApproximationDendriticFunction_2Inputs);
	Neuron.Set_ActivationFunction(LogicFunctionApproximationOutputFunction1);
	Neuron.Randomize_Dendrite_Factors(&RandomNumbers, -2.0f, 2.0f);

	int32_t maxCount = 200000;
	int32_t epoch = 0;
	float errorSum;

	for (int32_t i = 0; i < maxCount; i++)
	{
		epoch++;
		errorSum = 0.0f;

		Neuron.Set_Dendrite_NeuronInput(InputArray1, 2);
		//Neuron.Set_Dendrite_NeuronInput(InputArray1, 2, 0);
		Neuron.Calculate_NeuronOutput_Ext();

		errorSum += Neuron.Calculate_Error(DesiredOutput1, 1.0f, 0.01f);
		Neuron.Adjust_Dendrite_Factor_AfterErrorCalculations(0, 0.01f);
		Neuron.Adjust_Dendrite_Factors_AfterErrorCalculations(0.01f, 1, Neuron.Num_Of_Dendrite_Elements - 1);
		//errorSum += Neuron.Adjust_Dendrite_Factors(DesiredOutput1, 0.01f, 1.0f, 0.001f);

		Neuron.Set_Dendrite_NeuronInput(InputArray2, 2);
		//Neuron.Set_Dendrite_NeuronInput(InputArray2, 2, 0);
		Neuron.Calculate_NeuronOutput_Ext();

		errorSum += Neuron.Calculate_Error(DesiredOutput2, 1.0f, 0.01f);
		Neuron.Adjust_Dendrite_Factor_AfterErrorCalculations(0, 0.01f);
		Neuron.Adjust_Dendrite_Factors_AfterErrorCalculations(0.01f, 1, Neuron.Num_Of_Dendrite_Elements - 1);
		//errorSum += Neuron.Adjust_Dendrite_Factors(DesiredOutput1, 0.01f, 1.0f, 0.001f);

		Neuron.Set_Dendrite_NeuronInput(InputArray3, 2);
		//Neuron.Set_Dendrite_NeuronInput(InputArray3, 2, 0);
		Neuron.Calculate_NeuronOutput_Ext();

		errorSum += Neuron.Calculate_Error(DesiredOutput3, 1.0f, 0.01f);
		Neuron.Adjust_Dendrite_Factor_AfterErrorCalculations(0, 0.01f);
		Neuron.Adjust_Dendrite_Factors_AfterErrorCalculations(0.01f, 1, Neuron.Num_Of_Dendrite_Elements - 1);
		//errorSum += Neuron.Adjust_Dendrite_Factors(DesiredOutput1, 0.01f, 1.0f, 0.001f);

		Neuron.Set_Dendrite_NeuronInput(InputArray4, 2);
		//Neuron.Set_Dendrite_NeuronInput(InputArray4, 2, 0);
		Neuron.Calculate_NeuronOutput_Ext();

		errorSum += Neuron.Calculate_Error(DesiredOutput4, 1.0f, 0.01f);
		Neuron.Adjust_Dendrite_Factor_AfterErrorCalculations(0, 0.01f);
		Neuron.Adjust_Dendrite_Factors_AfterErrorCalculations(0.01f, 1, Neuron.Num_Of_Dendrite_Elements - 1);
		//errorSum += Neuron.Adjust_Dendrite_Factors(DesiredOutput1, 0.01f, 1.0f, 0.001f);

		////////////////

		Neuron.Set_Dendrite_NeuronInput(InputArray5, 2);
		//Neuron.Set_Dendrite_NeuronInput(InputArray5, 2, 0);
		Neuron.Calculate_NeuronOutput_Ext();

		errorSum += Neuron.Calculate_Error(DesiredOutput5, 1.0f, 0.01f);
		Neuron.Adjust_Dendrite_Factor_AfterErrorCalculations(0, 0.01f);
		Neuron.Adjust_Dendrite_Factors_AfterErrorCalculations(0.01f, 1, Neuron.Num_Of_Dendrite_Elements - 1);
		//errorSum += Neuron.Adjust_Dendrite_Factors(DesiredOutput1, 0.01f, 1.0f, 0.001f);

		Neuron.Set_Dendrite_NeuronInput(InputArray6, 2);
		//Neuron.Set_Dendrite_NeuronInput(InputArray6, 2, 0);
		Neuron.Calculate_NeuronOutput_Ext();

		errorSum += Neuron.Calculate_Error(DesiredOutput6, 1.0f, 0.01f);
		Neuron.Adjust_Dendrite_Factor_AfterErrorCalculations(0, 0.01f);
		Neuron.Adjust_Dendrite_Factors_AfterErrorCalculations(0.01f, 1, Neuron.Num_Of_Dendrite_Elements - 1);
		//errorSum += Neuron.Adjust_Dendrite_Factors(DesiredOutput1, 0.01f, 1.0f, 0.001f);


		if (errorSum < 0.0001f)
			break;
	}

	// training completed

	// training statistics:


	cout << "epoch: " << epoch << endl;
	cout << "error: " << errorSum << endl << endl;

	cout << endl;

	Neuron.Set_Dendrite_NeuronInput(InputArray1, 2);
	//Neuron.Set_Dendrite_NeuronInput(InputArray1, 2, 0);
	Neuron.Calculate_NeuronOutput_Ext();

	cout << "input values: " << InputArray1[0] << " " << InputArray1[1] << endl;
	cout << "activation value: " << Neuron.NeuronOutput << endl << endl;


	Neuron.Set_Dendrite_NeuronInput(InputArray2, 2);
	//Neuron.Set_Dendrite_NeuronInput(InputArray2, 2, 0);
	Neuron.Calculate_NeuronOutput_Ext();

	cout << "input values: " << InputArray2[0] << " " << InputArray2[1] << endl;
	cout << "activation value: " << Neuron.NeuronOutput << endl << endl;

	Neuron.Set_Dendrite_NeuronInput(InputArray3, 2);
	//Neuron.Set_Dendrite_NeuronInput(InputArray3, 2, 0);
	Neuron.Calculate_NeuronOutput_Ext();

	cout << "input values: " << InputArray3[0] << " " << InputArray3[1] << endl;
	cout << "activation value: " << Neuron.NeuronOutput << endl << endl;

	Neuron.Set_Dendrite_NeuronInput(InputArray4, 2);
	//Neuron.Set_Dendrite_NeuronInput(InputArray4, 2, 0);
	Neuron.Calculate_NeuronOutput_Ext();

	cout << "input values: " << InputArray4[0] << " " << InputArray4[1] << endl;
	cout << "activation value: " << Neuron.NeuronOutput << endl << endl;

	////

	Neuron.Set_Dendrite_NeuronInput(InputArray5, 2);
	//Neuron.Set_Dendrite_NeuronInput(InputArray5, 2, 0);
	Neuron.Calculate_NeuronOutput_Ext();

	cout << "input values: " << InputArray5[0] << " " << InputArray5[1] << endl;
	cout << "activation value: " << Neuron.NeuronOutput << endl << endl;

	Neuron.Set_Dendrite_NeuronInput(InputArray6, 2);
	//Neuron.Set_Dendrite_NeuronInput(InputArray6, 2, 0);
	Neuron.Calculate_NeuronOutput_Ext();

	cout << "input values: " << InputArray6[0] << " " << InputArray6[1] << endl;
	cout << "activation value: " << Neuron.NeuronOutput << endl << endl;

	getchar();
	return 0;
}
*/

/*
int main(void)
{
	static constexpr int32_t ConstNumOfInputArrays = 9;

	CRandomNumbersNN RandomNumbers;

	//Init_fRandomNumbersTable(&RandomNumbers, -1.0f, 1.0f);
	Init_fRandomNumbersTableExt2(&RandomNumbers, -1.0f, 1.0f, 0.5f);
	
	float InputArray1[2] = { 0.0f, 0.0f };
	float InputArray2[2] = { 1.0f, 0.0f };
	float InputArray3[2] = { 0.0f, 1.0f };
	float InputArray4[2] = { 1.0f, 1.0f };
	float InputArray5[2] = { 0.5f, 1.0f };
	float InputArray6[2] = { 1.0f, 0.5f };
	float InputArray7[2] = { 0.25f, 0.5f };
	float InputArray8[2] = { 0.5f, 0.25f };
	float InputArray9[2] = { 0.5f, 0.5f };

	
	float *pInputArrayPointer[ConstNumOfInputArrays];

	pInputArrayPointer[0] = InputArray1;
	pInputArrayPointer[1] = InputArray2;
	pInputArrayPointer[2] = InputArray3;
	pInputArrayPointer[3] = InputArray4;
	pInputArrayPointer[4] = InputArray5;
	pInputArrayPointer[5] = InputArray6;
	pInputArrayPointer[6] = InputArray7;
	pInputArrayPointer[7] = InputArray8;
	pInputArrayPointer[8] = InputArray9;

	float DesiredOutputArray[ConstNumOfInputArrays] =
	{ 0.005f, 0.105f, 0.205f, 0.305f, 0.405f, 0.505f, 0.605f, 0.705f, 0.805f };
	

	CNeuronV2 PrecedingNeuron;
	CNeuronV2 Neuron;
	
	PrecedingNeuron.Init_Dendrite_Arrays(13);
	PrecedingNeuron.Set_DendriticFunction(LogicFunctionApproximationDendriticFunction_2Inputs_To_10);
	Neuron.Init_Dendrite_Arrays(10);
	Neuron.Use_OtherNeuron_Dendrite_InputValueArray(PrecedingNeuron.pDendrite_InputValueArray, 3);

	//PrecedingNeuron.Init_Dendrite_Arrays(23);
	//PrecedingNeuron.Set_DendriticFunction(LogicFunctionApproximationDendriticFunction_2Inputs_To_20);
	//Neuron.Init_Dendrite_Arrays(20);
	//Neuron.Use_OtherNeuron_Dendrite_InputValueArray(PrecedingNeuron.pDendrite_InputValueArray, 3);

	
	Neuron.Set_ActivationFunction(LogicFunctionApproximationOutputFunction3);
	Neuron.Randomize_Dendrite_Factors(&RandomNumbers, -0.2f, 0.2f);

	
	int32_t maxCount = 400000;
	int32_t epoch = 0;
	float errorSum;

	for (int32_t j = 0; j < maxCount; j++)
	{
		epoch++;
		errorSum = 0.0f;

		for(int32_t i = 0; i <  ConstNumOfInputArrays; i++)
		{
			PrecedingNeuron.Set_Dendrite_NeuronInput(pInputArrayPointer[i], 2);
			PrecedingNeuron.Execute_DendriticCalculations();
			Neuron.Calculate_NeuronOutput();
			errorSum += Neuron.Adjust_Dendrite_Factors_ExternalInput(DesiredOutputArray[i], 0.2f, 1.0f, 0.005f);
		}

		if (errorSum < 0.0001f)
			break;
	}

	// training completed

	// training statistics:


	cout << "epoch: " << epoch << endl;
	cout << "error: " << errorSum << endl << endl;

	cout << endl;

	for (int32_t i = 0; i < ConstNumOfInputArrays; i++)
	{
		PrecedingNeuron.Set_Dendrite_NeuronInput(pInputArrayPointer[i], 2);
		PrecedingNeuron.Execute_DendriticCalculations();
		Neuron.Calculate_NeuronOutput();

		cout << "input values: " << pInputArrayPointer[i][0] << " " << pInputArrayPointer[i][1] << endl;
		cout << "activation value: " << 10.0f * Neuron.NeuronOutput << endl << endl;
	}

	float *pBestMatchedInputArray = nullptr;

	float TestInputArray1[2] = { 0.9f, 0.9f };

	Find_BestMatchedVectorFromList(&pBestMatchedInputArray, TestInputArray1, 2, pInputArrayPointer, ConstNumOfInputArrays);

	PrecedingNeuron.Set_Dendrite_NeuronInput(pBestMatchedInputArray, 2);
	PrecedingNeuron.Execute_DendriticCalculations();
	Neuron.Calculate_NeuronOutput();

	cout << "input values: " << TestInputArray1[0] << " " << TestInputArray1[1] << endl;
	cout << "activation value: " << 10.0f * Neuron.NeuronOutput << endl << endl;

	

	getchar();
	return 0;
}
*/



/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	float InputArray1[3] = { 0.0f, 0.0f, 0.0f };

	float InputArray2[3] = { 1.0f, 0.0f, 0.0f };
	float InputArray3[3] = { 0.0f, 1.0f, 0.0f };
	float InputArray4[3] = { 0.0f, 0.0f, 1.0f };

	float InputArray5[3] = { 1.0f, 1.0f, 0.0f };
	float InputArray6[3] = { 1.0f, 0.0f, 1.0f };
	float InputArray7[3] = { 0.0f, 1.0f, 1.0f };

	float InputArray8[3] = { 1.0f, 1.0f, 1.0f };

	float DesiredOutput1 = 0.0f;
	float DesiredOutput2 = 0.0f;
	float DesiredOutput3 = 0.0f;
	float DesiredOutput4 = 0.0f;
	float DesiredOutput5 = 1.0f;
	float DesiredOutput6 = 0.0f;
	float DesiredOutput7 = 1.0f;
	float DesiredOutput8 = 1.0f;

	CNeuronV2 Neuron;

	Neuron.Init_Dendrite_Arrays(8);
	Neuron.Set_DendriticFunction(LogicFunctionApproximationDendriticFunction_3Inputs);
	Neuron.Set_ActivationFunction(LogicFunctionApproximationOutputFunction1);
	Neuron.Randomize_Dendrite_Factors(&RandomNumbers, -4.0f, 4.0f);

	int32_t maxCount = 400000;
	int32_t epoch = 0;
	float errorSum;

	for (int32_t i = 0; i < maxCount; i++)
	{
		epoch++;
		errorSum = 0.0f;

		Neuron.Set_Dendrite_NeuronInput(InputArray1, 3);
		//Neuron.Set_Dendrite_NeuronInput(InputArray1, 3, 0);
		Neuron.Calculate_NeuronOutput_Ext();

		errorSum += Neuron.Calculate_Error(DesiredOutput1, 1.0f, 0.01f);
		Neuron.Adjust_Dendrite_Factor_AfterErrorCalculations(0, 0.01f);
		Neuron.Adjust_Dendrite_Factors_AfterErrorCalculations(0.01f, 1, Neuron.Num_Of_Dendrite_Elements - 1);
		//errorSum += Neuron.Adjust_Dendrite_Factors(DesiredOutput1, 0.01f, 1.0f, 0.001f);

		Neuron.Set_Dendrite_NeuronInput(InputArray2, 3);
		//Neuron.Set_Dendrite_NeuronInput(InputArray2, 3, 0);
		Neuron.Calculate_NeuronOutput_Ext();

		errorSum += Neuron.Calculate_Error(DesiredOutput2, 1.0f, 0.01f);
		Neuron.Adjust_Dendrite_Factor_AfterErrorCalculations(0, 0.01f);
		Neuron.Adjust_Dendrite_Factors_AfterErrorCalculations(0.01f, 1, Neuron.Num_Of_Dendrite_Elements - 1);
		//errorSum += Neuron.Adjust_Dendrite_Factors(DesiredOutput1, 0.01f, 1.0f, 0.001f);

		Neuron.Set_Dendrite_NeuronInput(InputArray3, 3);
		//Neuron.Set_Dendrite_NeuronInput(InputArray3, 3, 0);
		Neuron.Calculate_NeuronOutput_Ext();

		errorSum += Neuron.Calculate_Error(DesiredOutput3, 1.0f, 0.01f);
		Neuron.Adjust_Dendrite_Factor_AfterErrorCalculations(0, 0.01f);
		Neuron.Adjust_Dendrite_Factors_AfterErrorCalculations(0.01f, 1, Neuron.Num_Of_Dendrite_Elements - 1);
		//errorSum += Neuron.Adjust_Dendrite_Factors(DesiredOutput1, 0.01f, 1.0f, 0.001f);

		Neuron.Set_Dendrite_NeuronInput(InputArray4, 3);
		//Neuron.Set_Dendrite_NeuronInput(InputArray4, 3, 0);
		Neuron.Calculate_NeuronOutput_Ext();

		errorSum += Neuron.Calculate_Error(DesiredOutput4, 1.0f, 0.01f);
		Neuron.Adjust_Dendrite_Factor_AfterErrorCalculations(0, 0.01f);
		Neuron.Adjust_Dendrite_Factors_AfterErrorCalculations(0.01f, 1, Neuron.Num_Of_Dendrite_Elements - 1);
		//errorSum += Neuron.Adjust_Dendrite_Factors(DesiredOutput1, 0.01f, 1.0f, 0.001f);

		Neuron.Set_Dendrite_NeuronInput(InputArray5, 3);
		//Neuron.Set_Dendrite_NeuronInput(InputArray5, 3, 0);
		Neuron.Calculate_NeuronOutput_Ext();

		errorSum += Neuron.Calculate_Error(DesiredOutput5, 1.0f, 0.01f);
		Neuron.Adjust_Dendrite_Factor_AfterErrorCalculations(0, 0.01f);
		Neuron.Adjust_Dendrite_Factors_AfterErrorCalculations(0.01f, 1, Neuron.Num_Of_Dendrite_Elements - 1);
		//errorSum += Neuron.Adjust_Dendrite_Factors(DesiredOutput1, 0.01f, 1.0f, 0.001f);


		Neuron.Set_Dendrite_NeuronInput(InputArray6, 3);
		//Neuron.Set_Dendrite_NeuronInput(InputArray6, 3, 0);
		Neuron.Calculate_NeuronOutput_Ext();

		errorSum += Neuron.Calculate_Error(DesiredOutput6, 1.0f, 0.01f);
		Neuron.Adjust_Dendrite_Factor_AfterErrorCalculations(0, 0.01f);
		Neuron.Adjust_Dendrite_Factors_AfterErrorCalculations(0.01f, 1, Neuron.Num_Of_Dendrite_Elements - 1);
		//errorSum += Neuron.Adjust_Dendrite_Factors(DesiredOutput1, 0.01f, 1.0f, 0.001f);


		Neuron.Set_Dendrite_NeuronInput(InputArray7, 3);
		//Neuron.Set_Dendrite_NeuronInput(InputArray7, 3, 0);
		Neuron.Calculate_NeuronOutput_Ext();

		errorSum += Neuron.Calculate_Error(DesiredOutput7, 1.0f, 0.01f);
		Neuron.Adjust_Dendrite_Factor_AfterErrorCalculations(0, 0.01f);
		Neuron.Adjust_Dendrite_Factors_AfterErrorCalculations(0.01f, 1, Neuron.Num_Of_Dendrite_Elements - 1);
		//errorSum += Neuron.Adjust_Dendrite_Factors(DesiredOutput1, 0.01f, 1.0f, 0.001f);


		Neuron.Set_Dendrite_NeuronInput(InputArray8, 3);
		//Neuron.Set_Dendrite_NeuronInput(InputArray8, 3, 0);
		Neuron.Calculate_NeuronOutput_Ext();

		errorSum += Neuron.Calculate_Error(DesiredOutput8, 1.0f, 0.01f);
		Neuron.Adjust_Dendrite_Factor_AfterErrorCalculations(0, 0.01f);
		Neuron.Adjust_Dendrite_Factors_AfterErrorCalculations(0.01f, 1, Neuron.Num_Of_Dendrite_Elements - 1);
		//errorSum += Neuron.Adjust_Dendrite_Factors(DesiredOutput1, 0.01f, 1.0f, 0.001f);

		if (errorSum < 0.001f)
			break;
	}

	// training completed

	// training statistics:


	cout << "epoch: " << epoch << endl;
	cout << "error: " << errorSum << endl << endl;

	cout << endl;

	Neuron.Set_Dendrite_NeuronInput(InputArray1, 3);
	//Neuron.Set_Dendrite_NeuronInput(InputArray1, 3, 0);
	Neuron.Calculate_NeuronOutput_Ext();

	cout << "input values: " << InputArray1[0] << " " << InputArray1[1] << " " << InputArray1[2] << endl;
	cout << "activation value: " << Neuron.NeuronOutput << endl << endl;


	Neuron.Set_Dendrite_NeuronInput(InputArray2, 3);
	//Neuron.Set_Dendrite_NeuronInput(InputArray2, 3, 0);
	Neuron.Calculate_NeuronOutput_Ext();

	cout << "input values: " << InputArray2[0] << " " << InputArray2[1] << " " << InputArray2[2] << endl;
	cout << "activation value: " << Neuron.NeuronOutput << endl << endl;

	Neuron.Set_Dendrite_NeuronInput(InputArray3, 3);
	//Neuron.Set_Dendrite_NeuronInput(InputArray3, 3, 0);
	Neuron.Calculate_NeuronOutput_Ext();

	cout << "input values: " << InputArray3[0] << " " << InputArray3[1] << " " << InputArray3[2] << endl;
	cout << "activation value: " << Neuron.NeuronOutput << endl << endl;

	Neuron.Set_Dendrite_NeuronInput(InputArray4, 3);
	//Neuron.Set_Dendrite_NeuronInput(InputArray4, 3, 0);
	Neuron.Calculate_NeuronOutput_Ext();

	cout << "input values: " << InputArray4[0] << " " << InputArray4[1] << " " << InputArray4[2] << endl;
	cout << "activation value: " << Neuron.NeuronOutput << endl << endl;

	Neuron.Set_Dendrite_NeuronInput(InputArray5, 3);
	//Neuron.Set_Dendrite_NeuronInput(InputArray5, 3, 0);
	Neuron.Calculate_NeuronOutput_Ext();

	cout << "input values: " << InputArray5[0] << " " << InputArray5[1] << " " << InputArray5[2] << endl;
	cout << "activation value: " << Neuron.NeuronOutput << endl << endl;


	Neuron.Set_Dendrite_NeuronInput(InputArray6, 3);
	//Neuron.Set_Dendrite_NeuronInput(InputArray6, 3, 0);
	Neuron.Calculate_NeuronOutput_Ext();

	cout << "input values: " << InputArray6[0] << " " << InputArray6[1] << " " << InputArray6[2] << endl;
	cout << "activation value: " << Neuron.NeuronOutput << endl << endl;

	Neuron.Set_Dendrite_NeuronInput(InputArray7, 3);
	//Neuron.Set_Dendrite_NeuronInput(InputArray7, 3, 0);
	Neuron.Calculate_NeuronOutput_Ext();

	cout << "input values: " << InputArray7[0] << " " << InputArray7[1] << " " << InputArray7[2] << endl;
	cout << "activation value: " << Neuron.NeuronOutput << endl << endl;


	Neuron.Set_Dendrite_NeuronInput(InputArray8, 3);
	//Neuron.Set_Dendrite_NeuronInput(InputArray8, 3, 0);
	Neuron.Calculate_NeuronOutput_Ext();

	cout << "input values: " << InputArray8[0] << " " << InputArray8[1] << " " << InputArray8[2] << endl;
	cout << "activation value: " << Neuron.NeuronOutput << endl << endl;

	getchar();
	return 0;
}
*/

/*
int main(void)
{
	static constexpr int32_t ConstNumOfInputArrays = 16;

	CRandomNumbersNN RandomNumbers;

	float InputArray1[4] = { 0.0f, 0.0f, 0.0f, 0.0f };

	float InputArray2[4] = { 1.0f, 0.0f, 0.0f, 0.0f };
	float InputArray3[4] = { 0.0f, 1.0f, 0.0f, 0.0f };
	float InputArray4[4] = { 0.0f, 0.0f, 1.0f, 0.0f };
	float InputArray5[4] = { 0.0f, 0.0f, 0.0f, 1.0f };

	float InputArray6[4] = { 1.0f, 1.0f, 0.0f, 0.0f };
	float InputArray7[4] = { 1.0f, 0.0f, 1.0f, 0.0f };
	float InputArray8[4] = { 1.0f, 0.0f, 0.0f, 1.0f };
	float InputArray9[4] = { 0.0f, 1.0f, 1.0f, 0.0f };
	float InputArray10[4] = { 0.0f, 1.0f, 0.0f, 1.0f };
	float InputArray11[4] = { 0.0f, 0.0f, 1.0f, 1.0f };

	float InputArray12[4] = { 1.0f, 1.0f, 1.0f, 0.0f };
	float InputArray13[4] = { 1.0f, 1.0f, 0.0f, 1.0f };
	float InputArray14[4] = { 1.0f, 0.0f, 1.0f, 1.0f };
	float InputArray15[4] = { 0.0f, 1.0f, 1.0f, 1.0f };

	float InputArray16[4] = { 1.0f, 1.0f, 1.0f, 1.0f };

	float *pInputArrayPointer[ConstNumOfInputArrays];

	pInputArrayPointer[0] = InputArray1;
	pInputArrayPointer[1] = InputArray2;
	pInputArrayPointer[2] = InputArray3;
	pInputArrayPointer[3] = InputArray4;
	pInputArrayPointer[4] = InputArray5;
	pInputArrayPointer[5] = InputArray6;
	pInputArrayPointer[6] = InputArray7;
	pInputArrayPointer[7] = InputArray8;
	pInputArrayPointer[8] = InputArray9;
	pInputArrayPointer[9] = InputArray10;
	pInputArrayPointer[10] = InputArray11;
	pInputArrayPointer[11] = InputArray12;
	pInputArrayPointer[12] = InputArray13;
	pInputArrayPointer[13] = InputArray14;
	pInputArrayPointer[14] = InputArray15;
	pInputArrayPointer[15] = InputArray16;


	//float DesiredOutputArray[ConstNumOfInputArrays] =
	//{0.0f,
	//0.1f, 0.15f, 0.2f, 0.25f,
	//0.3f, 0.35f, 0.4f, 0.45f, 0.5f, 0.55f,
	//0.6f, 0.65f, 0.7f, 0.75f,
	//0.8f};

	float DesiredOutputArray[ConstNumOfInputArrays] =
	{ 1.0f,
		0.0f, 0.0f, 0.0f, 0.0f,
		0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
		0.0f, 0.0f, 0.0f, 0.0f,
		1.0f };

	
	CNeuronV2 Neuron;

	Neuron.Init_Dendrite_Arrays(15);
	Neuron.Set_DendriticFunction(LogicFunctionApproximationDendriticFunction_4Inputs);
	Neuron.Set_ActivationFunction(LogicFunctionApproximationOutputFunction1);
	Neuron.Randomize_Dendrite_Factors(&RandomNumbers, -1.0f, 1.0f);

	int32_t maxCount = 400000;
	int32_t epoch = 0;
	float errorSum;

	for (int32_t i = 0; i < maxCount; i++)
	{
		epoch++;
		errorSum = 0.0f;

		for (int32_t j = 0; j < ConstNumOfInputArrays; j++)
		{
			Neuron.Set_Dendrite_NeuronInput(pInputArrayPointer[j], 4);
			//Neuron.Set_Dendrite_NeuronInput(pInputArrayPointer[j], 4, 0);
			Neuron.Calculate_NeuronOutput_Ext();

			errorSum += Neuron.Calculate_Error(DesiredOutputArray[j], 1.0f, 0.01f);
			Neuron.Adjust_Dendrite_Factor_AfterErrorCalculations(0, 0.01f);
			Neuron.Adjust_Dendrite_Factors_AfterErrorCalculations(0.01f, 1, Neuron.Num_Of_Dendrite_Elements - 1);
			//errorSum += Neuron.Adjust_Dendrite_Factors(DesiredOutputArray[j], 0.01f, 1.0f, 0.01f);
		}
		
		if (errorSum < 0.0005f)
			break;
	}

	// training completed

	// training statistics:


	cout << "epoch: " << epoch << endl;
	cout << "error: " << errorSum << endl << endl;

	cout << endl;

	for (int32_t j = 0; j < ConstNumOfInputArrays; j++)
	{
		Neuron.Set_Dendrite_NeuronInput(pInputArrayPointer[j], 4);
		//Neuron.Set_Dendrite_NeuronInput(pInputArrayPointer[j], 4, 0);
		Neuron.Calculate_NeuronOutput_Ext();

		cout << "input values: " << *pInputArrayPointer[j] << " " << *(pInputArrayPointer[j] + 1) << " " << *(pInputArrayPointer[j] + 2) << " " << *(pInputArrayPointer[j] + 3) << " ";
		cout << "activation value: " << Neuron.NeuronOutput << endl;
	}

	getchar();
	return 0;
}
*/

/*
int main(void)
{
	static constexpr int32_t ConstNumOfInputArrays = 16;

	CRandomNumbersNN RandomNumbers;

	Init_fRandomNumbersTable(&RandomNumbers, -1.0f, 1.0f);

	float InputArray1[4] = { 0.0f, 0.0f, 0.0f, 0.0f };

	float InputArray2[4] = { 1.0f, 0.0f, 0.0f, 0.0f };
	float InputArray3[4] = { 0.0f, 1.0f, 0.0f, 0.0f };
	float InputArray4[4] = { 0.0f, 0.0f, 1.0f, 0.0f };
	float InputArray5[4] = { 0.0f, 0.0f, 0.0f, 1.0f };

	float InputArray6[4] = { 1.0f, 1.0f, 0.0f, 0.0f };
	float InputArray7[4] = { 1.0f, 0.0f, 1.0f, 0.0f };
	float InputArray8[4] = { 1.0f, 0.0f, 0.0f, 1.0f };
	float InputArray9[4] = { 0.0f, 1.0f, 1.0f, 0.0f };
	float InputArray10[4] = { 0.0f, 1.0f, 0.0f, 1.0f };
	float InputArray11[4] = { 0.0f, 0.0f, 1.0f, 1.0f };

	float InputArray12[4] = { 1.0f, 1.0f, 1.0f, 0.0f };
	float InputArray13[4] = { 1.0f, 1.0f, 0.0f, 1.0f };
	float InputArray14[4] = { 1.0f, 0.0f, 1.0f, 1.0f };
	float InputArray15[4] = { 0.0f, 1.0f, 1.0f, 1.0f };

	float InputArray16[4] = { 1.0f, 1.0f, 1.0f, 1.0f };

	float *pInputArrayPointer[ConstNumOfInputArrays];

	pInputArrayPointer[0] = InputArray1;
	pInputArrayPointer[1] = InputArray2;
	pInputArrayPointer[2] = InputArray3;
	pInputArrayPointer[3] = InputArray4;
	pInputArrayPointer[4] = InputArray5;
	pInputArrayPointer[5] = InputArray6;
	pInputArrayPointer[6] = InputArray7;
	pInputArrayPointer[7] = InputArray8;
	pInputArrayPointer[8] = InputArray9;
	pInputArrayPointer[9] = InputArray10;
	pInputArrayPointer[10] = InputArray11;
	pInputArrayPointer[11] = InputArray12;
	pInputArrayPointer[12] = InputArray13;
	pInputArrayPointer[13] = InputArray14;
	pInputArrayPointer[14] = InputArray15;
	pInputArrayPointer[15] = InputArray16;


	

	float DesiredOutputArray[ConstNumOfInputArrays] =
	{ 1.0f,
		0.0f, 0.0f, 0.0f, 0.0f,
		0.0f, 0.0f, 0.5f, 0.0f, 1.0f, 0.0f,
		0.0f, 0.0f, 0.0f, 0.0f,
		-1.0f };


	CNeuronV2 Neuron;

	Neuron.Init_Dendrite_Arrays(20);
	Neuron.Set_DendriticFunction(LogicFunctionApproximationDendriticFunction_4Inputs_20);
	Neuron.Set_ActivationFunction(LogicFunctionApproximationOutputFunction2);
	Neuron.Randomize_Dendrite_Factors(&RandomNumbers, -0.2f, 0.2f);

	int32_t maxCount = 20000;
	int32_t epoch = 0;
	float errorSum;

	for (int32_t i = 0; i < maxCount; i++)
	{
		epoch++;
		errorSum = 0.0f;

		for (int32_t j = 0; j < ConstNumOfInputArrays; j++)
		{
			//Neuron.Modify_Dendrite_Factors(&RandomNumbers, -0.0001f, 0.0001f, 0.75f);

			Neuron.Set_Dendrite_NeuronInput(pInputArrayPointer[j], 4);
			//Neuron.Set_Dendrite_NeuronInput(pInputArrayPointer[j], 4, 0);
			Neuron.Calculate_NeuronOutput_Ext();

			errorSum += Neuron.Adjust_Dendrite_Factors(DesiredOutputArray[j], 0.2f, 1.0f, 0.005f);
		}

		if (errorSum < 0.0005f)
			break;
	}

	// training completed

	// training statistics:


	cout << "epoch: " << epoch << endl;
	cout << "error: " << errorSum << endl << endl;

	cout << endl;

	for (int32_t j = 0; j < ConstNumOfInputArrays; j++)
	{
		Neuron.Set_Dendrite_NeuronInput(pInputArrayPointer[j], 4);
		//Neuron.Set_Dendrite_NeuronInput(pInputArrayPointer[j], 4, 0);
		Neuron.Calculate_NeuronOutput_Ext();

		cout << "input values: " << *pInputArrayPointer[j] << " " << *(pInputArrayPointer[j] + 1) << " " << *(pInputArrayPointer[j] + 2) << " " << *(pInputArrayPointer[j] + 3) << " ";
		cout << "activation value: " << Neuron.NeuronOutput << endl;
	}

	getchar();
	return 0;
}
*/

/*
int main(void)
{
	static constexpr int32_t ConstNumOfInputArrays = 16;

	CRandomNumbersNN RandomNumbers;

	Init_fRandomNumbersTable(&RandomNumbers, -1.0f, 1.0f);

	float InputArray1[4] = { 0.0f, 0.0f, 0.0f, 0.0f };

	float InputArray2[4] = { 1.0f, 0.0f, 0.0f, 0.0f };
	float InputArray3[4] = { 0.0f, 1.0f, 0.0f, 0.0f };
	float InputArray4[4] = { 0.0f, 0.0f, 1.0f, 0.0f };
	float InputArray5[4] = { 0.0f, 0.0f, 0.0f, 1.0f };

	float InputArray6[4] = { 1.0f, 1.0f, 0.0f, 0.0f };
	float InputArray7[4] = { 1.0f, 0.0f, 1.0f, 0.0f };
	float InputArray8[4] = { 1.0f, 0.0f, 0.0f, 1.0f };
	float InputArray9[4] = { 0.0f, 1.0f, 1.0f, 0.0f };
	float InputArray10[4] = { 0.0f, 1.0f, 0.0f, 1.0f };
	float InputArray11[4] = { 0.0f, 0.0f, 1.0f, 1.0f };

	float InputArray12[4] = { 1.0f, 1.0f, 1.0f, 0.0f };
	float InputArray13[4] = { 1.0f, 1.0f, 0.0f, 1.0f };
	float InputArray14[4] = { 1.0f, 0.0f, 1.0f, 1.0f };
	float InputArray15[4] = { 0.0f, 1.0f, 1.0f, 1.0f };

	float InputArray16[4] = { 1.0f, 1.0f, 1.0f, 1.0f };

	float *pInputArrayPointer[ConstNumOfInputArrays];

	pInputArrayPointer[0] = InputArray1;
	pInputArrayPointer[1] = InputArray2;
	pInputArrayPointer[2] = InputArray3;
	pInputArrayPointer[3] = InputArray4;
	pInputArrayPointer[4] = InputArray5;
	pInputArrayPointer[5] = InputArray6;
	pInputArrayPointer[6] = InputArray7;
	pInputArrayPointer[7] = InputArray8;
	pInputArrayPointer[8] = InputArray9;
	pInputArrayPointer[9] = InputArray10;
	pInputArrayPointer[10] = InputArray11;
	pInputArrayPointer[11] = InputArray12;
	pInputArrayPointer[12] = InputArray13;
	pInputArrayPointer[13] = InputArray14;
	pInputArrayPointer[14] = InputArray15;
	pInputArrayPointer[15] = InputArray16;




	float DesiredOutputArray1[ConstNumOfInputArrays] =
	{ 1.0f,
		0.0f, 0.0f, 0.0f, 0.0f,
		0.0f, 0.0f, 0.5f, 0.0f, 1.0f, 0.0f,
		0.0f, 0.0f, 0.0f, 0.0f,
		-1.0f };

	float DesiredOutputArray2[ConstNumOfInputArrays] =
	{ 0.0f,
		1.0f, 0.0f, 1.0f, 0.0f,
		0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,
		0.0f, 0.0f, 0.0f, 0.0f,
		0.0f };


	CNeuronV2 PrecedingNeuron;
	CNeuronV2 Neuron1;
	CNeuronV2 Neuron2;

	PrecedingNeuron.Init_Dendrite_Arrays(20);
	PrecedingNeuron.Set_DendriticFunction(LogicFunctionApproximationDendriticFunction_4Inputs_20);
	
	Neuron1.Init_Dendrite_Arrays(20);
	Neuron1.Use_OtherNeuron_Dendrite_InputValueArray(PrecedingNeuron.pDendrite_InputValueArray);
	Neuron1.Set_ActivationFunction(LogicFunctionApproximationOutputFunction3);
	Neuron1.Randomize_Dendrite_Factors(&RandomNumbers, -0.2f, 0.2f);

	Neuron2.Init_Dendrite_Arrays(20);
	Neuron2.Use_OtherNeuron_Dendrite_InputValueArray(PrecedingNeuron.pDendrite_InputValueArray);
	Neuron2.Set_ActivationFunction(LogicFunctionApproximationOutputFunction3);
	Neuron2.Randomize_Dendrite_Factors(&RandomNumbers, -0.2f, 0.2f);

	int32_t maxCount = 20000;
	int32_t epoch = 0;
	float errorSum1;
	float errorSum2;

	for (int32_t i = 0; i < maxCount; i++)
	{
		epoch++;
		errorSum1 = 0.0f;
		errorSum2 = 0.0f;

		for (int32_t j = 0; j < ConstNumOfInputArrays; j++)
		{
			//Neuron1.Modify_Dendrite_Factors(&RandomNumbers, -0.0001f, 0.0001f, 0.75f);
			//Neuron2.Modify_Dendrite_Factors(&RandomNumbers, -0.0001f, 0.0001f, 0.75f);

			PrecedingNeuron.Set_Dendrite_NeuronInput(pInputArrayPointer[j], 4);
			//PrecedingNeuron.Set_Dendrite_NeuronInput(pInputArrayPointer[j], 4, 0);
			PrecedingNeuron.Execute_DendriticCalculations();

			Neuron1.Calculate_NeuronOutput();
			errorSum1 += Neuron1.Adjust_Dendrite_Factors_ExternalInput(DesiredOutputArray1[j], 0.2f, 1.0f, 0.005f);

			Neuron2.Calculate_NeuronOutput();
			errorSum2 += Neuron2.Adjust_Dendrite_Factors_ExternalInput(DesiredOutputArray2[j], 0.2f, 1.0f, 0.005f);
		}

		if (errorSum1 < 0.0005f && errorSum2 < 0.0005f)
			break;
	}

	

	// training completed

	// training statistics:


	cout << "epoch: " << epoch << endl;
	cout << "error1: " << errorSum1 << " " << "error2: " << errorSum2 << endl << endl;

	cout << endl;

	for (int32_t j = 0; j < ConstNumOfInputArrays; j++)
	{
		PrecedingNeuron.Set_Dendrite_NeuronInput(pInputArrayPointer[j], 4);
		//PrecedingNeuron.Set_Dendrite_NeuronInput(pInputArrayPointer[j], 4, 0);
		PrecedingNeuron.Execute_DendriticCalculations();

		Neuron1.Calculate_NeuronOutput();
		Neuron2.Calculate_NeuronOutput();

		cout << "input values: " << *pInputArrayPointer[j] << " " << *(pInputArrayPointer[j] + 1) << " " << *(pInputArrayPointer[j] + 2) << " " << *(pInputArrayPointer[j] + 3) << " ";
		cout << "output1: " << Neuron1.NeuronOutput << " " << "output2: " << Neuron2.NeuronOutput << endl;
	}

	getchar();
	return 0;
}
*/

