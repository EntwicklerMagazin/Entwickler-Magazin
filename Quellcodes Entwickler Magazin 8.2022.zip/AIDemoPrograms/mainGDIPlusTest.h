#ifndef _mainGDIPlusTest_H_
#define _mainGDIPlusTest_H_  

#include "GDIPlusFramework/GDIPlusFramework.h"


class CApplicationMain
{
public:

	CGDIPlusWindow *pUsedGDIPlusWindow = nullptr;


	Gdiplus::LinearGradientBrush *pLinearGradientBrush = nullptr;


	CImageObject testImageObject;



	CTexturedObject testTexturedObject;

	CApplicationMain(CGDIPlusWindow *pGDIPlusWindow);
	~CApplicationMain();

	int main(void);
};

#endif