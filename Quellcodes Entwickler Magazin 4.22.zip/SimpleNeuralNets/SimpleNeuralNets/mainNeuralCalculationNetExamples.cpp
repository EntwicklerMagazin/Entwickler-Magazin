#include <iostream>
#include "NeuralCalculationNet.h"
#include "Graph.h"
#include "ConsoleHelperFunctions.h"
//#include "NeuralNetInlineFunctions.h"
#include "SparseVectorMatrix.h"
#include "Clustering.h"
#include "GeneticAlgorithms.h"

using namespace std;
using namespace HelperStuff;

#define KEYDOWN(vk_code) ((GetAsyncKeyState(vk_code) & 0x8000) ? 1 : 0)
#define KEYUP(vk_code)   ((GetAsyncKeyState(vk_code) & 0x8000) ? 0 : 1)


static void Identity(CNeuralCalculationUnit *pCalculationUnit)
{
	pCalculationUnit->OutputValue = pCalculationUnit->SumOfInputValues;
	pCalculationUnit->SumOfInputValues = 0.0f;
}

static void SumUp(CNeuralCalculationUnit *pCalculationUnit)
{
	pCalculationUnit->OutputValue += pCalculationUnit->SumOfInputValues;
	pCalculationUnit->SumOfInputValues = 0.0f;
}

static void SumUpExt(CNeuralCalculationUnit *pCalculationUnit)
{
	pCalculationUnit->OutputValue += pCalculationUnit->AdditionalCalcValueArray[0] * pCalculationUnit->SumOfInputValues;
	pCalculationUnit->SumOfInputValues = 0.0f;
}

static void Bias(CNeuralCalculationUnit *pCalculationUnit)
{
	pCalculationUnit->OutputValue = 1.0f;
	pCalculationUnit->SumOfInputValues = 0.0f;
}

static void NegBias(CNeuralCalculationUnit *pCalculationUnit)
{
	pCalculationUnit->OutputValue = -1.0f;
	pCalculationUnit->SumOfInputValues = 0.0f;
}

static void StdBinaryOutput(CNeuralCalculationUnit *pCalculationUnit)
{
	if (pCalculationUnit->SumOfInputValues > 0.999f)
	{
		pCalculationUnit->OutputValue = 1.0f;
		pCalculationUnit->SumOfInputValues = 0.0f;
		return;
	}

	pCalculationUnit->OutputValue = 0.0f;
	pCalculationUnit->SumOfInputValues = 0.0f;
}

static void Spiking(CNeuralCalculationUnit *pCalculationUnit)
{
	pCalculationUnit->OutputValue = 0.0f;

	if (pCalculationUnit->SumOfInputValues > 0.999f)
	{
		pCalculationUnit->OutputValue = 1.0f;
		pCalculationUnit->SumOfInputValues = 0.0f;
	}
	else
	{
		//pCalculationUnit->SumOfInputValues -= 0.1f;
		pCalculationUnit->SumOfInputValues -= pCalculationUnit->AdditionalCalcValueArray[0];
		pCalculationUnit->SumOfInputValues = max(pCalculationUnit->SumOfInputValues, 0.0f);
	}
}

static void LinearAccumulation(CNeuralCalculationUnit *pCalculationUnit)
{
	if (pCalculationUnit->SumOfInputValues > 0.999f)
	{
		pCalculationUnit->OutputValue = 1.0f;
		pCalculationUnit->SumOfInputValues = 0.0f;
		return;
	}

	pCalculationUnit->OutputValue = 0.0f;
}

static void OneTenthCounterStep(CNeuralCalculationUnit *pCalculationUnit)
{
	if (pCalculationUnit->SumOfInputValues > 0.999f)
	{
		pCalculationUnit->OutputValue = 1.0f;
		pCalculationUnit->SumOfInputValues = 0.0f;
		return;
	}

	pCalculationUnit->SumOfInputValues += 0.1f;
	pCalculationUnit->OutputValue = 0.0f;
}


static void ExpRBF(CNeuralCalculationUnit *pCalculationUnit)
{
	pCalculationUnit->OutputValue = exp(-pCalculationUnit->SumOfInputValues);
	pCalculationUnit->SumOfInputValues = 0.0f;
}


static void ReLU(CNeuralCalculationUnit *pCalculationUnit)
{
	pCalculationUnit->OutputValue = max(0.0f, pCalculationUnit->SumOfInputValues);
	pCalculationUnit->SumOfInputValues = 0.0f;
}
static void LeakyReLU(CNeuralCalculationUnit *pCalculationUnit)
{
	float sumOfInputValues = pCalculationUnit->SumOfInputValues;

	if (sumOfInputValues < 0.0f)
		pCalculationUnit->OutputValue = 0.01f * sumOfInputValues;
	else
		pCalculationUnit->OutputValue = sumOfInputValues;

	pCalculationUnit->SumOfInputValues = 0.0f;
}

static void Sigmoid(CNeuralCalculationUnit *pCalculationUnit)
{
	// von 0.0f bis 1.0f:
	pCalculationUnit->OutputValue =  1.0f / (1.0f + exp(-pCalculationUnit->SumOfInputValues));
	pCalculationUnit->SumOfInputValues = 0.0f;
}

static void ScaledSigmoid(CNeuralCalculationUnit *pCalculationUnit)
{
	// von 0.0f bis 1.0f:
	pCalculationUnit->OutputValue = 1.0f / (1.0f + exp(-10.0f * pCalculationUnit->SumOfInputValues));
	pCalculationUnit->SumOfInputValues = 0.0f;
}

static void TanH(CNeuralCalculationUnit *pCalculationUnit)
{
	// von -1.0f bis 1.0f:
	pCalculationUnit->OutputValue = tanh(pCalculationUnit->SumOfInputValues);
	pCalculationUnit->SumOfInputValues = 0.0f;
}

static void ScaledTanH(CNeuralCalculationUnit *pCalculationUnit)
{
	pCalculationUnit->OutputValue = tanh(0.1f * pCalculationUnit->SumOfInputValues);
	pCalculationUnit->SumOfInputValues = 0.0f;
}

static void FastTanHReplacement(CNeuralCalculationUnit *pCalculationUnit)
{
	// von -1.0f bis 1.0f:
	pCalculationUnit->OutputValue = pCalculationUnit->SumOfInputValues / (1.0f + abs(pCalculationUnit->SumOfInputValues));
	pCalculationUnit->SumOfInputValues = 0.0f;
}


static void MultiplyWith2(CNeuralCalculationUnit *pCalculationUnit)
{
	pCalculationUnit->OutputValue = 2.0f * pCalculationUnit->SumOfInputValues;
	pCalculationUnit->SumOfInputValues = 0.0f;
}



static void XORBrain_Reinitialization(CNeuralCalculationNetDesc *pInOutNetDesc, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	//CEvolutionParameter_NeuralCalculationNet *pParameter = static_cast<CEvolutionParameter_NeuralCalculationNet*>(pParam);

	float minRandomPlasticity = -2.0f;
	float maxRandomPlasticity = 2.0f;

	int32_t numOfNeuralConnections = pInOutNetDesc->NumOfNeuralConnections;

	for (int32_t i = 0; i < numOfNeuralConnections; i++)
	{
		if (pInOutNetDesc->pConnectionStatusArray[i] == 0.0f)
			continue;

		pInOutNetDesc->pPlasticityValueArray[i] = pRandomNumbers->Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
	}

}

static void XORBrainRBF_Reinitialization(CNeuralCalculationNetDesc *pInOutNetDesc, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	//CEvolutionParameter_NeuralCalculationNet *pParameter = static_cast<CEvolutionParameter_NeuralCalculationNet*>(pParam);

	float minRandomCentroidValue = -2.0f;
	float maxRandomCentroidValue = 2.0f;
	//float minRandomPlasticity = -2.0f;
	//float maxRandomPlasticity = 2.0f;

	int32_t numOfNeuralConnections = pInOutNetDesc->NumOfNeuralConnections;

	for (int32_t i = 0; i < numOfNeuralConnections; i++)
	{
		if (pInOutNetDesc->pConnectionStatusArray[i] == 0.0f)
			continue;

		if (pInOutNetDesc->pRBFConstantArray[i] == 0.0f)
		{
			//pInOutNetDesc->pPlasticityValueArray[i] = pRandomNumbers->Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
		}
		else
		{
			pInOutNetDesc->pCentroidValueArray[i] = pRandomNumbers->Get_FloatNumber(minRandomCentroidValue, maxRandomCentroidValue);
		}
	}

}

static void BrainRBF_Reinitialization(CNeuralCalculationNetDesc *pInOutNetDesc, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	//CEvolutionParameter_NeuralCalculationNet *pParameter = static_cast<CEvolutionParameter_NeuralCalculationNet*>(pParam);

	float minRandomCentroidValue = -2.0f;
	float maxRandomCentroidValue = 2.0f;
	float minRandomPlasticity = -1.0f;
	float maxRandomPlasticity = 1.0f;

	int32_t numOfNeuralConnections = pInOutNetDesc->NumOfNeuralConnections;

	for (int32_t i = 0; i < numOfNeuralConnections; i++)
	{
		if (pInOutNetDesc->pConnectionStatusArray[i] == 0.0f)
			continue;

		if (pInOutNetDesc->pRBFConstantArray[i] == 0.0f)
		{
			pInOutNetDesc->pPlasticityValueArray[i] = pRandomNumbers->Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
		}
		else
		{
			pInOutNetDesc->pCentroidValueArray[i] = pRandomNumbers->Get_FloatNumber(minRandomCentroidValue, maxRandomCentroidValue);
		}
	}

}


static void XORBrain_Mutation(CNeuralCalculationNetDesc *pInOutNetDesc, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	//CEvolutionParameter_NeuralCalculationNet *pParameter = static_cast<CEvolutionParameter_NeuralCalculationNet*>(pParam);

	float minDeltaPlasticity = -0.01f;
	float maxDeltaPlasticity = 0.01f;
	float mutationRate = 0.75f;

	int32_t numOfNeuralConnections = pInOutNetDesc->NumOfNeuralConnections;

	for (int32_t i = 0; i < numOfNeuralConnections; i++)
	{
		if (pInOutNetDesc->pConnectionStatusArray[i] == 0.0f)
			continue;

		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
			continue;

		pInOutNetDesc->pPlasticityValueArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minDeltaPlasticity, maxDeltaPlasticity);
	}

}

static void XORBrainRBF_Mutation(CNeuralCalculationNetDesc *pInOutNetDesc, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	//CEvolutionParameter_NeuralCalculationNet *pParameter = static_cast<CEvolutionParameter_NeuralCalculationNet*>(pParam);

	float minDeltaCentroidValue = -0.01f;
	float maxDeltaCentroidValue = 0.01f;
	//float minDeltaPlasticity = -0.01f;
	//float maxDeltaPlasticity = 0.01f;
	float mutationRate = 0.75f;

	int32_t numOfNeuralConnections = pInOutNetDesc->NumOfNeuralConnections;

	for (int32_t i = 0; i < numOfNeuralConnections; i++)
	{
		if (pInOutNetDesc->pConnectionStatusArray[i] == 0.0f)
			continue;

		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
			continue;
	
		if (pInOutNetDesc->pRBFConstantArray[i] == 0.0f)
		{
			//pInOutNetDesc->pPlasticityValueArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minDeltaPlasticity, maxDeltaPlasticity);
		}
		else
		{
			pInOutNetDesc->pCentroidValueArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minDeltaCentroidValue, maxDeltaCentroidValue);
		}
		
	}

}

static void BrainRBF_Mutation(CNeuralCalculationNetDesc *pInOutNetDesc, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	//CEvolutionParameter_NeuralCalculationNet *pParameter = static_cast<CEvolutionParameter_NeuralCalculationNet*>(pParam);

	float minDeltaCentroidValue = -0.01f;
	float maxDeltaCentroidValue = 0.01f;
	float minDeltaPlasticity = -0.01f;
	float maxDeltaPlasticity = 0.01f;
	float mutationRate = 0.75f;

	int32_t numOfNeuralConnections = pInOutNetDesc->NumOfNeuralConnections;

	for (int32_t i = 0; i < numOfNeuralConnections; i++)
	{
		if (pInOutNetDesc->pConnectionStatusArray[i] == 0.0f)
			continue;

		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
			continue;

		if (pInOutNetDesc->pRBFConstantArray[i] == 0.0f)
		{
			pInOutNetDesc->pPlasticityValueArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minDeltaPlasticity, maxDeltaPlasticity);
		}
		else
		{
			pInOutNetDesc->pCentroidValueArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minDeltaCentroidValue, maxDeltaCentroidValue);
		}
	}
}



static void XORBrain_Recombination(CNeuralCalculationNetDesc *pOffspring, const CNeuralCalculationNetDesc *pParent1, const CNeuralCalculationNetDesc *pParent2, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	//CEvolutionParameter_NeuralCalculationNet *pParameter = static_cast<CEvolutionParameter_NeuralCalculationNet*>(pParam);

	float crossoverRate = 0.75f;

	int32_t numOfNeuralConnections = pOffspring->NumOfNeuralConnections;

	if (pRandomNumbers->Get_IntegerNumber2(1, 2) == 1)
	{
		for (int32_t i = 0; i < numOfNeuralConnections; i++)
		{
			if (pOffspring->pConnectionStatusArray[i] == 0.0f)
				continue;

			pOffspring->pPlasticityValueArray[i] = pParent1->pPlasticityValueArray[i];
		}
	}
	else
	{
		for (int32_t i = 0; i < numOfNeuralConnections; i++)
		{
			if (pOffspring->pConnectionStatusArray[i] == 0.0f)
				continue;

			pOffspring->pPlasticityValueArray[i] = pParent2->pPlasticityValueArray[i];
		}
	}

	for (int32_t i = 0; i < numOfNeuralConnections; i++)
	{
		if (pOffspring->pConnectionStatusArray[i] == 0.0f)
			continue;

		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > crossoverRate)
			continue;

		float weight1 = pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f);
		float weight2 = 1.0f - weight1;

		pOffspring->pPlasticityValueArray[i] = weight1 * pParent1->pPlasticityValueArray[i] + weight2 * pParent2->pPlasticityValueArray[i];
	}
}

static void XORBrainRBF_Recombination(CNeuralCalculationNetDesc *pOffspring, const CNeuralCalculationNetDesc *pParent1, const CNeuralCalculationNetDesc *pParent2, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	//CEvolutionParameter_NeuralCalculationNet *pParameter = static_cast<CEvolutionParameter_NeuralCalculationNet*>(pParam);

	float crossoverRate = 0.75f;

	int32_t numOfNeuralConnections = pOffspring->NumOfNeuralConnections;

	if (pRandomNumbers->Get_IntegerNumber2(1, 2) == 1)
	{
		for (int32_t i = 0; i < numOfNeuralConnections; i++)
		{
			if (pOffspring->pConnectionStatusArray[i] == 0.0f)
				continue;

			pOffspring->pCentroidValueArray[i] = pParent1->pCentroidValueArray[i];
			//pOffspring->pPlasticityValueArray[i] = pParent1->pPlasticityValueArray[i];
		}
	}
	else
	{
		for (int32_t i = 0; i < numOfNeuralConnections; i++)
		{
			if (pOffspring->pConnectionStatusArray[i] == 0.0f)
				continue;

			pOffspring->pCentroidValueArray[i] = pParent2->pCentroidValueArray[i];
			//pOffspring->pPlasticityValueArray[i] = pParent2->pPlasticityValueArray[i];
		}
	}

	for (int32_t i = 0; i < numOfNeuralConnections; i++)
	{
		if (pOffspring->pConnectionStatusArray[i] == 0.0f)
			continue;

		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > crossoverRate)
			continue;

		float weight1 = pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f);
		float weight2 = 1.0f - weight1;

		pOffspring->pCentroidValueArray[i] = weight1 * pParent1->pCentroidValueArray[i] + weight2 * pParent2->pCentroidValueArray[i];
		//pOffspring->pPlasticityValueArray[i] = weight1 * pParent1->pPlasticityValueArray[i] + weight2 * pParent2->pPlasticityValueArray[i];
	}
}

static void BrainRBF_Recombination(CNeuralCalculationNetDesc *pOffspring, const CNeuralCalculationNetDesc *pParent1, const CNeuralCalculationNetDesc *pParent2, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	//CEvolutionParameter_NeuralCalculationNet *pParameter = static_cast<CEvolutionParameter_NeuralCalculationNet*>(pParam);

	float crossoverRate = 0.75f;

	int32_t numOfNeuralConnections = pOffspring->NumOfNeuralConnections;

	if (pRandomNumbers->Get_IntegerNumber2(1, 2) == 1)
	{
		for (int32_t i = 0; i < numOfNeuralConnections; i++)
		{
			if (pOffspring->pConnectionStatusArray[i] == 0.0f)
				continue;

			pOffspring->pCentroidValueArray[i] = pParent1->pCentroidValueArray[i];
			pOffspring->pPlasticityValueArray[i] = pParent1->pPlasticityValueArray[i];
		}
	}
	else
	{
		for (int32_t i = 0; i < numOfNeuralConnections; i++)
		{
			if (pOffspring->pConnectionStatusArray[i] == 0.0f)
				continue;

			pOffspring->pCentroidValueArray[i] = pParent2->pCentroidValueArray[i];
			pOffspring->pPlasticityValueArray[i] = pParent2->pPlasticityValueArray[i];
		}
	}

	for (int32_t i = 0; i < numOfNeuralConnections; i++)
	{
		if (pOffspring->pConnectionStatusArray[i] == 0.0f)
			continue;

		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > crossoverRate)
			continue;

		float weight1 = pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f);
		float weight2 = 1.0f - weight1;

		pOffspring->pCentroidValueArray[i] = weight1 * pParent1->pCentroidValueArray[i] + weight2 * pParent2->pCentroidValueArray[i];
		pOffspring->pPlasticityValueArray[i] = weight1 * pParent1->pPlasticityValueArray[i] + weight2 * pParent2->pPlasticityValueArray[i];
	}
}





/*
int main(void)
{
	CNeuralCalculationFunctions CalculationFunctions;
	CalculationFunctions.Initialize(3);
	CalculationFunctions.Set_Function(0, nullptr);
	CalculationFunctions.Set_Function(1, Identity);
	CalculationFunctions.Set_Function(2, MultiplyWith2);


	CNeuralCalculationNet CalculationNet;
	CalculationNet.Initialize(2, 1, 1);
	CalculationNet.Set_InputUnit(0, 0);
	CalculationNet.Set_OutputUnit(1, 0);

	//CalculationNet.Set_CalculationFunction(0, 1, Identity);
	//CalculationNet.Set_CalculationFunction(1, 2, MultiplyWith2);

	CalculationNet.Set_CalculationFunction(0, 1, &CalculationFunctions);
	CalculationNet.Set_CalculationFunction(1, 2, &CalculationFunctions);

	CalculationNet.Set_ConnectionValues(1, 0, 0.5f);
	CalculationNet.Activate_Connection(1, 0);

	CalculationNet.Set_ConnectionValues(0, 1, 0.5f);
	CalculationNet.Activate_Connection(0, 1);

	float inputValue;
	float outputValue;
	//float inputValueArray[1];
	//float outputValueArray[1];

	inputValue = 0.0f;
	CalculationNet.Set_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl;

	inputValue = 1.0f;
	CalculationNet.Add_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl;

	inputValue = 1.0f;
	CalculationNet.Add_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl;

	inputValue = 1.0f;
	CalculationNet.Add_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl << endl;

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/







/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	float InputArray1[2] = { 0.0f, 0.0f };
	float InputArray2[2] = { 1.0f, 0.0f };
	float InputArray3[2] = { 0.0f, 1.0f };
	float InputArray4[2] = { 1.0f, 1.0f };

	static constexpr int32_t ConstNumOfInputArrays = 4;

	float *pInputArrayPointer[ConstNumOfInputArrays];

	pInputArrayPointer[0] = InputArray1;
	pInputArrayPointer[1] = InputArray2;
	pInputArrayPointer[2] = InputArray3;
	pInputArrayPointer[3] = InputArray4;

	float DesiredXOROutputArray[ConstNumOfInputArrays] = { 0.0f, 1.0f, 1.0f, 0.0f };


	CNeuralCalculationFunctions CalculationFunctions;
	CalculationFunctions.Initialize(4);
	CalculationFunctions.Set_Function(0, nullptr);
	CalculationFunctions.Set_Function(1, Identity);
	CalculationFunctions.Set_Function(2, Bias);
	CalculationFunctions.Set_Function(3, TanH);

	static constexpr int32_t NumOfInputUnits = 2;
	static constexpr int32_t NumOfInputAndBiasUnits = NumOfInputUnits + 1;
	static constexpr int32_t NumOfHiddenUnits = 3;
	static constexpr int32_t NumOfOutputUnits = 1;
	static constexpr int32_t NumOfCalculationUnits = NumOfInputAndBiasUnits + NumOfHiddenUnits + NumOfOutputUnits;
	static constexpr int32_t NumOfInputAndBiasAndHiddenUnits = NumOfInputAndBiasUnits + NumOfHiddenUnits;

	int32_t idOfFirstInputUnit = 0;
	int32_t idOfBiasUnit = NumOfInputUnits;
	int32_t idOfFirstHiddenUnit = NumOfInputAndBiasUnits;
	int32_t idOfFirstOutputUnit = idOfFirstHiddenUnit + NumOfHiddenUnits;

	CNeuralCalculationNet CalculationNet;
	CalculationNet.Initialize(NumOfCalculationUnits, NumOfInputUnits, NumOfOutputUnits);

	for (int32_t i = 0; i < NumOfInputUnits; i++)
	{
		CalculationNet.Set_InputUnit(i, i);
		CalculationNet.Set_CalculationFunction(i, 1, &CalculationFunctions);
	}

	// Bias Unit:
	CalculationNet.Set_CalculationFunction(NumOfInputUnits, 2, &CalculationFunctions);

	for (int32_t i = 0; i < NumOfOutputUnits; i++)
	{
		int32_t unitID = i + idOfFirstOutputUnit;
		CalculationNet.Set_OutputUnit(unitID, i);
		CalculationNet.Set_CalculationFunction(unitID, 3, &CalculationFunctions);
	}

	for (int32_t i = 0; i < NumOfHiddenUnits; i++)
	{
		int32_t unitID = i + idOfFirstHiddenUnit;
		CalculationNet.Set_CalculationFunction(unitID, 3, &CalculationFunctions);
	}

	float minRandomPlasticity = -2.0f;
	float maxRandomPlasticity = 2.0f;

	// InputNeurons / BiasNeurons -> HiddenNeurons

	for (int32_t inputOrBiasUnitNumber = 0; inputOrBiasUnitNumber < NumOfInputAndBiasUnits; inputOrBiasUnitNumber++)
	{
		for (int32_t hiddenUnitNumber = 0; hiddenUnitNumber < NumOfHiddenUnits; hiddenUnitNumber++)
		{
			int32_t id;
			Get_ID_Of_1To2LayerConnection_3LayerFFNN(&id, inputOrBiasUnitNumber, hiddenUnitNumber, NumOfInputAndBiasUnits, NumOfCalculationUnits);

			CalculationNet.Set_ConnectionValues(id, RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity));
			CalculationNet.Activate_Connection(id);
		}
	}

	
	//for (int32_t iy = 0; iy < idOfFirstHiddenUnit; iy++)
	//{
	//for (int32_t ix = idOfFirstHiddenUnit; ix < idOfFirstOutputUnit; ix++)
	//{
	//CalculationNet.Set_ConnectionValues(ix, iy, RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity));
	//CalculationNet.Activate_Connection(ix, iy);
	//}
	//}
	

	// HiddenNeurons -> OutputNeurons

	for (int32_t hiddenUnitNumber = 0; hiddenUnitNumber < NumOfHiddenUnits; hiddenUnitNumber++)
	{
		for (int32_t outputUnitNumber = 0; outputUnitNumber < NumOfOutputUnits; outputUnitNumber++)
		{
			int32_t id;
			Get_ID_Of_2To3LayerConnection_3LayerFFNN(&id, hiddenUnitNumber, outputUnitNumber, NumOfInputAndBiasUnits, NumOfInputAndBiasAndHiddenUnits, NumOfCalculationUnits);

			CalculationNet.Set_ConnectionValues(id, RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity));
			CalculationNet.Activate_Connection(id);
		}
	}

	
	//for (int32_t iy = idOfFirstHiddenUnit; iy < idOfFirstOutputUnit; iy++)
	//{
	//for (int32_t ix = idOfFirstOutputUnit; ix < NumOfCalculationUnits; ix++)
	//{
	//CalculationNet.Set_ConnectionValues(ix, iy, RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity));
	//	CalculationNet.Activate_Connection(ix, iy);
	//}
	//}
	
	
	float outputValue;
	//float outputValueArray[1];

	float learningRate = 0.2f;
	float errorFactor1 = 1.0f;
	float errorFactor2 = 1.0f;

	int32_t maxCount = 10000;
	int32_t epoch = 0;
	float errorSum;

#define StandardBackpropagationTraining

	for (int32_t j = 0; j < maxCount; j++)
	{
		epoch++;
		errorSum = 0.0f;

		for (int32_t i = 0; i < ConstNumOfInputArrays; i++)
		{
			CalculationNet.Set_InputValues(pInputArrayPointer[i]);
			CalculationNet.Execute_Calculations();

#ifdef StandardBackpropagationTraining
			errorSum += CalculationNet.Calculate_OutputVarianceSum_And_OutputError(&DesiredXOROutputArray[i], errorFactor1, errorFactor2);	
			CalculationNet.Learning(learningRate, errorFactor1, errorFactor2);
#else
			float error = CalculationNet.Calculate_OutputVarianceSum_And_OutputError(&DesiredXOROutputArray[i], errorFactor1, errorFactor2);
	
			if (error > 0.0001f)
			{	
				errorSum += error;
				CalculationNet.Learning(learningRate, errorFactor1, errorFactor2);
			}
#endif	
		} // end of for (int32_t i = 0; i < ConstNumOfInputArrays; i++)

#ifdef StandardBackpropagationTraining
		if (j % 500 == 0)
#else
		if (j % 100 == 0)
#endif
		{
			cout << "error: " << errorSum << endl;
		}

		if (errorSum < 0.0005f)
			break;

	} // end of for (int32_t j = 0; j < maxCount; j++)

	// training completed

	// training statistics:


	cout << endl << "epoch: " << epoch << endl;
	cout << "error: " << errorSum << endl << endl;

	cout << endl;

	//getchar();

	for (int32_t i = 0; i < ConstNumOfInputArrays; i++)
	{
		CalculationNet.Set_InputValues(pInputArrayPointer[i]);
		CalculationNet.Execute_Calculations();
		CalculationNet.Get_OutputValues(&outputValue);
		
		cout << "input values: " << pInputArrayPointer[i][0] << " " << pInputArrayPointer[i][1] << endl;
		cout << "activation value: " << outputValue << endl << endl;
	}

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	float InputArray1[2] = { 0.0f, 0.0f };
	float InputArray2[2] = { 1.0f, 0.0f };
	float InputArray3[2] = { 0.0f, 1.0f };
	float InputArray4[2] = { 1.0f, 1.0f };

	static constexpr int32_t ConstNumOfInputArrays = 4;

	float *pInputArrayPointer[ConstNumOfInputArrays];

	pInputArrayPointer[0] = InputArray1;
	pInputArrayPointer[1] = InputArray2;
	pInputArrayPointer[2] = InputArray3;
	pInputArrayPointer[3] = InputArray4;

	float DesiredXOROutputArray[ConstNumOfInputArrays] = { 0.0f, 1.0f, 1.0f, 0.0f };


	CNeuralCalculationFunctions CalculationFunctions;
	CalculationFunctions.Initialize(4);
	CalculationFunctions.Set_Function(0, nullptr);
	CalculationFunctions.Set_Function(1, Identity);
	CalculationFunctions.Set_Function(2, Bias);
	CalculationFunctions.Set_Function(3, TanH);

	static constexpr int32_t NumOfInputUnits = 2;
	static constexpr int32_t NumOfInputAndBiasUnits = NumOfInputUnits + 1;
	static constexpr int32_t NumOfHiddenUnits = 5;
	static constexpr int32_t NumOfOutputUnits = 1;
	static constexpr int32_t NumOfCalculationUnits = NumOfInputAndBiasUnits + NumOfHiddenUnits + NumOfOutputUnits;

	int32_t idOfFirstInputUnit = 0;
	int32_t idOfBiasUnit = NumOfInputUnits;
	int32_t idOfFirstHiddenUnit = NumOfInputAndBiasUnits;
	int32_t idOfFirstOutputUnit = idOfFirstHiddenUnit + NumOfHiddenUnits;

	CNeuralCalculationNet CalculationNet;
	CalculationNet.Initialize(NumOfCalculationUnits, NumOfInputUnits, NumOfOutputUnits);

	for (int32_t i = 0; i < NumOfInputUnits; i++)
	{
		CalculationNet.Set_InputUnit(i, i);
		CalculationNet.Set_CalculationFunction(i, 1, &CalculationFunctions);
	}

	// Bias Unit:
	CalculationNet.Set_CalculationFunction(NumOfInputUnits, 2, &CalculationFunctions);

	for (int32_t i = 0; i < NumOfOutputUnits; i++)
	{
		int32_t unitID = i + idOfFirstOutputUnit;
		CalculationNet.Set_OutputUnit(unitID, i);
		CalculationNet.Set_CalculationFunction(unitID, 3, &CalculationFunctions);
	}

	for (int32_t i = 0; i < NumOfHiddenUnits; i++)
	{
		int32_t unitID = i + idOfFirstHiddenUnit;
		CalculationNet.Set_CalculationFunction(unitID, 3, &CalculationFunctions);
	}

	float minRandomPlasticity = -2.0f;
	float maxRandomPlasticity = 2.0f;

	for (int32_t iy = 0; iy < idOfFirstHiddenUnit; iy++)
	{
		for (int32_t ix = idOfFirstHiddenUnit; ix < idOfFirstOutputUnit; ix++)
		{
			CalculationNet.Set_ConnectionValues(ix, iy, RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity));
			CalculationNet.Activate_Connection(ix, iy);
		}
	}

	for (int32_t iy = idOfFirstHiddenUnit; iy < idOfFirstOutputUnit; iy++)
	{
		for (int32_t ix = idOfFirstOutputUnit; ix < NumOfCalculationUnits; ix++)
		{
			CalculationNet.Set_ConnectionValues(ix, iy, RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity));
			CalculationNet.Activate_Connection(ix, iy);
		}
	}




	float outputValue;
	//float outputValueArray[1];

	float learningRate = 0.1f;
	//float learningRate = 0.2f;
	float errorFactor1 = 1.0f;
	float errorFactor2 = 1.0f;

	int32_t maxCount = 4000;
	int32_t epoch = 0;
	float errorSum;

	for (int32_t j = 0; j < maxCount; j++)
	{
		epoch++;
		errorSum = 0.0f;

		for (int32_t i = 0; i < ConstNumOfInputArrays; i++)
		{
			CalculationNet.Set_InputValues(pInputArrayPointer[i]);
			CalculationNet.Execute_Calculations();

			errorSum += CalculationNet.Calculate_OutputVarianceSum_And_OutputError(&DesiredXOROutputArray[i], errorFactor1, errorFactor2);

			CalculationNet.Learning(learningRate, errorFactor1, errorFactor2);
			//CalculationNet.ExtremeLearning(learningRate);
		}

		if (j % 50 == 0)
		{
			cout << "error: " << errorSum << endl;
		}

		if (errorSum < 0.0005f)
			break;
	}

	// training completed

	// training statistics:


	cout << endl << "epoch: " << epoch << endl;
	cout << "error: " << errorSum << endl << endl;

	cout << endl;

	//getchar();

	for (int32_t i = 0; i < ConstNumOfInputArrays; i++)
	{
		CalculationNet.Set_InputValues(pInputArrayPointer[i]);
		CalculationNet.Execute_Calculations();
		CalculationNet.Get_OutputValues(&outputValue);

		cout << "input values: " << pInputArrayPointer[i][0] << " " << pInputArrayPointer[i][1] << endl;
		cout << "activation value: " << outputValue << endl << endl;
	}

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	float InputArray1[2] = { 0.0f, 0.0f };
	float InputArray2[2] = { 1.0f, 0.0f };
	float InputArray3[2] = { 0.0f, 1.0f };
	float InputArray4[2] = { 1.0f, 1.0f };

	static constexpr int32_t ConstNumOfInputArrays = 4;

	float *pInputArrayPointer[ConstNumOfInputArrays];

	pInputArrayPointer[0] = InputArray1;
	pInputArrayPointer[1] = InputArray2;
	pInputArrayPointer[2] = InputArray3;
	pInputArrayPointer[3] = InputArray4;

	float DesiredXOROutputArray[ConstNumOfInputArrays] = { 0.0f, 1.0f, 1.0f, 0.0f };


	CNeuralCalculationFunctions CalculationFunctions;
	CalculationFunctions.Initialize(4);
	CalculationFunctions.Set_Function(0, nullptr);
	CalculationFunctions.Set_Function(1, Identity);
	CalculationFunctions.Set_Function(2, Bias);
	CalculationFunctions.Set_Function(3, TanH);

	static constexpr int32_t NumOfInputUnits = 2;
	static constexpr int32_t NumOfInputAndBiasUnits = NumOfInputUnits + 1;
	static constexpr int32_t NumOfHiddenUnits = 3;
	static constexpr int32_t NumOfOutputUnits = 1;
	static constexpr int32_t NumOfCalculationUnits = NumOfInputAndBiasUnits + NumOfHiddenUnits + NumOfOutputUnits;

	int32_t idOfFirstInputUnit = 0;
	int32_t idOfBiasUnit = NumOfInputUnits;
	int32_t idOfFirstHiddenUnit = NumOfInputAndBiasUnits;
	int32_t idOfFirstOutputUnit = idOfFirstHiddenUnit + NumOfHiddenUnits;

	CNeuralCalculationNet CalculationNet;
	CalculationNet.Initialize(NumOfCalculationUnits, NumOfInputUnits, NumOfOutputUnits);

	for (int32_t i = 0; i < NumOfInputUnits; i++)
	{
		CalculationNet.Set_InputUnit(i, i);
		CalculationNet.Set_CalculationFunction(i, 1, &CalculationFunctions);
	}

	// Bias Unit:
	CalculationNet.Set_CalculationFunction(NumOfInputUnits, 2, &CalculationFunctions);

	for (int32_t i = 0; i < NumOfOutputUnits; i++)
	{
		int32_t unitID = i + idOfFirstOutputUnit;
		CalculationNet.Set_OutputUnit(unitID, i);
		CalculationNet.Set_CalculationFunction(unitID, 3, &CalculationFunctions);
	}

	for (int32_t i = 0; i < NumOfHiddenUnits; i++)
	{
		int32_t unitID = i + idOfFirstHiddenUnit;
		CalculationNet.Set_CalculationFunction(unitID, 3, &CalculationFunctions);
	}

	float minRandomPlasticity = -2.0f;
	float maxRandomPlasticity = 2.0f;

	for (int32_t iy = 0; iy < idOfFirstHiddenUnit; iy++)
	{
		for (int32_t ix = idOfFirstHiddenUnit; ix < idOfFirstOutputUnit; ix++)
		{
			CalculationNet.Set_ConnectionValues(ix, iy, RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity));
			CalculationNet.Activate_Connection(ix, iy);
		}
	}

	for (int32_t iy = idOfFirstHiddenUnit; iy < idOfFirstOutputUnit; iy++)
	{
		for (int32_t ix = idOfFirstOutputUnit; ix < NumOfCalculationUnits; ix++)
		{
			CalculationNet.Set_ConnectionValues(ix, iy, RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity));
			CalculationNet.Activate_Connection(ix, iy);
		}
	}

	

	CNeuralCalculationNetDesc CalculationNetDesc;

	CalculationNet.Readout_Data(&CalculationNetDesc, true);

	CNeuralCalculationNet CalculationNet2;

	CalculationNet2.Initialize(&CalculationNetDesc, &CalculationFunctions, 2, 1);

	

	float outputValue;
	//float outputValueArray[1];

	float learningRate = 0.2f;
	float errorFactor1 = 1.0f;
	float errorFactor2 = 1.0f;

	int32_t maxCount = 10000;
	int32_t epoch = 0;
	float errorSum;

	for (int32_t j = 0; j < maxCount; j++)
	{
		epoch++;
		errorSum = 0.0f;

		for (int32_t i = 0; i < ConstNumOfInputArrays; i++)
		{
			CalculationNet2.Set_InputValues(pInputArrayPointer[i]);
			CalculationNet2.Execute_Calculations();

			errorSum += CalculationNet2.Calculate_OutputVarianceSum_And_OutputError(&DesiredXOROutputArray[i], errorFactor1, errorFactor2);

			CalculationNet2.Learning(learningRate, errorFactor1, errorFactor2);

		}

		if (j % 500 == 0)
		{
			cout << "error: " << errorSum << endl;
		}

		if (errorSum < 0.0005f)
			break;
	}

	// training completed

	// training statistics:


	cout << endl << "epoch: " << epoch << endl;
	cout << "error: " << errorSum << endl << endl;

	cout << endl;

	//getchar();

	for (int32_t i = 0; i < ConstNumOfInputArrays; i++)
	{
		CalculationNet2.Set_InputValues(pInputArrayPointer[i]);
		CalculationNet2.Execute_Calculations();
		CalculationNet2.Get_OutputValues(&outputValue);

		cout << "input values: " << pInputArrayPointer[i][0] << " " << pInputArrayPointer[i][1] << endl;
		cout << "activation value: " << outputValue << endl << endl;
	}

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	float InputArray1[2] = { 0.0f, 0.0f };
	float InputArray2[2] = { 1.0f, 0.0f };
	float InputArray3[2] = { 0.0f, 1.0f };
	float InputArray4[2] = { 1.0f, 1.0f };

	static constexpr int32_t ConstNumOfInputArrays = 4;

	float *pInputArrayPointer[ConstNumOfInputArrays];

	pInputArrayPointer[0] = InputArray1;
	pInputArrayPointer[1] = InputArray2;
	pInputArrayPointer[2] = InputArray3;
	pInputArrayPointer[3] = InputArray4;

	float DesiredXOROutputArray[ConstNumOfInputArrays] = { 0.0f, 1.0f, 1.0f, 0.0f };


	CNeuralCalculationFunctions CalculationFunctions;
	CalculationFunctions.Initialize(4);
	CalculationFunctions.Set_Function(0, nullptr);
	CalculationFunctions.Set_Function(1, Identity);
	CalculationFunctions.Set_Function(2, Bias);
	CalculationFunctions.Set_Function(3, TanH);

	static constexpr int32_t NumOfInputUnits = 2;
	static constexpr int32_t NumOfInputAndBiasUnits = NumOfInputUnits + 1;
	static constexpr int32_t NumOfHiddenUnits = 3;
	static constexpr int32_t NumOfOutputUnits = 1;
	static constexpr int32_t NumOfCalculationUnits = NumOfInputAndBiasUnits + NumOfHiddenUnits + NumOfOutputUnits;

	int32_t idOfFirstInputUnit = 0;
	int32_t idOfBiasUnit = NumOfInputUnits;
	int32_t idOfFirstHiddenUnit = NumOfInputAndBiasUnits;
	int32_t idOfFirstOutputUnit = idOfFirstHiddenUnit + NumOfHiddenUnits;

	
	CNeuralCalculationNetDesc CalculationNetDesc;
	CalculationNetDesc.Initialize(NumOfCalculationUnits);

	
	for (int32_t i = 0; i < NumOfInputUnits; i++)
	{
		CalculationNetDesc.pCalculationFunctionIDArray[i] = 1;
		CalculationNetDesc.pCalculationUnitUsageStatusArray[i] = UsageStatus_CalculationInputUnit;
	}

	// Bias Unit:
	CalculationNetDesc.pCalculationFunctionIDArray[NumOfInputUnits] = 2;
	CalculationNetDesc.pCalculationUnitUsageStatusArray[NumOfInputUnits] = UsageStatus_CalculationUnit_Standard;
	

	for (int32_t i = 0; i < NumOfOutputUnits; i++)
	{
		int32_t unitID = i + idOfFirstOutputUnit;
		CalculationNetDesc.pCalculationFunctionIDArray[unitID] = 3;
		CalculationNetDesc.pCalculationUnitUsageStatusArray[unitID] = UsageStatus_CalculationOutputUnit;
	}

	for (int32_t i = 0; i < NumOfHiddenUnits; i++)
	{
		int32_t unitID = i + idOfFirstHiddenUnit;
		CalculationNetDesc.pCalculationFunctionIDArray[unitID] = 3;
		CalculationNetDesc.pCalculationUnitUsageStatusArray[unitID] = UsageStatus_CalculationUnit_Standard;
	}

	float minRandomPlasticity = -2.0f;
	float maxRandomPlasticity = 2.0f;

	for (int32_t iy = 0; iy < idOfFirstHiddenUnit; iy++)
	{
		for (int32_t ix = idOfFirstHiddenUnit; ix < idOfFirstOutputUnit; ix++)
		{
			int32_t id = ix + iy * NumOfCalculationUnits;
			CalculationNetDesc.pConnectionStatusArray[id] = 1;
			CalculationNetDesc.pPlasticityValueArray[id] = RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
		}
	}

	for (int32_t iy = idOfFirstHiddenUnit; iy < idOfFirstOutputUnit; iy++)
	{
		for (int32_t ix = idOfFirstOutputUnit; ix < NumOfCalculationUnits; ix++)
		{
			int32_t id = ix + iy * NumOfCalculationUnits;
			CalculationNetDesc.pConnectionStatusArray[id] = 1;
			CalculationNetDesc.pPlasticityValueArray[id] = RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
		}
	}


	
	CNeuralCalculationNet CalculationNet;

	//CalculationNet.Initialize(&CalculationNetDesc, &CalculationFunctions, NumOfInputUnits, NumOfOutputUnits);
	CalculationNet.Initialize(NumOfCalculationUnits, NumOfInputUnits, NumOfOutputUnits);
	CalculationNet.Modify(&CalculationNetDesc, &CalculationFunctions);
	
	
	float outputValue;
	//float outputValueArray[1];

	float learningRate = 0.2f;
	float errorFactor1 = 1.0f;
	float errorFactor2 = 1.0f;

	int32_t maxCount = 10000;
	int32_t epoch = 0;
	float errorSum;

	for (int32_t j = 0; j < maxCount; j++)
	{
		epoch++;
		errorSum = 0.0f;

		for (int32_t i = 0; i < ConstNumOfInputArrays; i++)
		{
			CalculationNet.Set_InputValues(pInputArrayPointer[i]);
			CalculationNet.Execute_Calculations();

			errorSum += CalculationNet.Calculate_OutputVarianceSum_And_OutputError(&DesiredXOROutputArray[i], errorFactor1, errorFactor2);

			CalculationNet.Learning(learningRate, errorFactor1, errorFactor2);

		}

		if (j % 500 == 0)
		{
			cout << "error: " << errorSum << endl;
		}

		if (errorSum < 0.0005f)
			break;
	}

	// training completed

	// training statistics:


	cout << endl << "epoch: " << epoch << endl;
	cout << "error: " << errorSum << endl << endl;

	cout << endl;

	//getchar();

	for (int32_t i = 0; i < ConstNumOfInputArrays; i++)
	{
		CalculationNet.Set_InputValues(pInputArrayPointer[i]);
		CalculationNet.Execute_Calculations();
		CalculationNet.Get_OutputValues(&outputValue);

		cout << "input values: " << pInputArrayPointer[i][0] << " " << pInputArrayPointer[i][1] << endl;
		cout << "activation value: " << outputValue << endl << endl;
	}

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	float InputArray1[2] = { 0.0f, 0.0f };
	float InputArray2[2] = { 1.0f, 0.0f };
	float InputArray3[2] = { 0.0f, 1.0f };
	float InputArray4[2] = { 1.0f, 1.0f };

	static constexpr int32_t ConstNumOfInputArrays = 4;

	float *pInputArrayPointer[ConstNumOfInputArrays];

	pInputArrayPointer[0] = InputArray1;
	pInputArrayPointer[1] = InputArray2;
	pInputArrayPointer[2] = InputArray3;
	pInputArrayPointer[3] = InputArray4;

	float DesiredXOROutputArray[ConstNumOfInputArrays] = { 0.0f, 1.0f, 1.0f, 0.0f };


	CNeuralCalculationFunctions CalculationFunctions;
	CalculationFunctions.Initialize(4);
	CalculationFunctions.Set_Function(0, nullptr);
	CalculationFunctions.Set_Function(1, Identity);
	CalculationFunctions.Set_Function(2, Bias);
	CalculationFunctions.Set_Function(3, TanH);

	static constexpr int32_t NumOfInputUnits = 2;
	static constexpr int32_t NumOfInputAndBiasUnits = NumOfInputUnits + 1;
	static constexpr int32_t NumOfHiddenUnits = 3;
	static constexpr int32_t NumOfOutputUnits = 1;
	static constexpr int32_t NumOfCalculationUnits = NumOfInputAndBiasUnits + NumOfHiddenUnits + NumOfOutputUnits;

	int32_t idOfFirstInputUnit = 0;
	int32_t idOfBiasUnit = NumOfInputUnits;
	int32_t idOfFirstHiddenUnit = NumOfInputAndBiasUnits;
	int32_t idOfFirstOutputUnit = idOfFirstHiddenUnit + NumOfHiddenUnits;


	CNeuralCalculationNetDesc CalculationNetDesc;
	CalculationNetDesc.Initialize(NumOfCalculationUnits);


	for (int32_t i = 0; i < NumOfInputUnits; i++)
	{
		CalculationNetDesc.pCalculationFunctionIDArray[i] = 1;
		CalculationNetDesc.pCalculationUnitUsageStatusArray[i] = UsageStatus_CalculationInputUnit;
	}

	// Bias Unit:
	CalculationNetDesc.pCalculationFunctionIDArray[NumOfInputUnits] = 2;
	CalculationNetDesc.pCalculationUnitUsageStatusArray[NumOfInputUnits] = UsageStatus_CalculationUnit_Standard;


	for (int32_t i = 0; i < NumOfOutputUnits; i++)
	{
		int32_t unitID = i + idOfFirstOutputUnit;
		CalculationNetDesc.pCalculationFunctionIDArray[unitID] = 3;
		CalculationNetDesc.pCalculationUnitUsageStatusArray[unitID] = UsageStatus_CalculationOutputUnit;
	}

	for (int32_t i = 0; i < NumOfHiddenUnits; i++)
	{
		int32_t unitID = i + idOfFirstHiddenUnit;
		CalculationNetDesc.pCalculationFunctionIDArray[unitID] = 3;
		CalculationNetDesc.pCalculationUnitUsageStatusArray[unitID] = UsageStatus_CalculationUnit_Standard;
	}

	float minRandomPlasticity = -2.0f;
	float maxRandomPlasticity = 2.0f;

	for (int32_t iy = 0; iy < idOfFirstHiddenUnit; iy++)
	{
		for (int32_t ix = idOfFirstHiddenUnit; ix < idOfFirstOutputUnit; ix++)
		{
			int32_t id = ix + iy * NumOfCalculationUnits;
			CalculationNetDesc.pConnectionStatusArray[id] = 1;
			CalculationNetDesc.pPlasticityValueArray[id] = RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
		}
	}

	for (int32_t iy = idOfFirstHiddenUnit; iy < idOfFirstOutputUnit; iy++)
	{
		for (int32_t ix = idOfFirstOutputUnit; ix < NumOfCalculationUnits; ix++)
		{
			int32_t id = ix + iy * NumOfCalculationUnits;
			CalculationNetDesc.pConnectionStatusArray[id] = 1;
			CalculationNetDesc.pPlasticityValueArray[id] = RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
		}
	}

	

	static constexpr int32_t TrainingPopulationSize = 50;
	static constexpr int32_t NumTrainingGenerationsMax = 1000;

	static CNeuralCalculationNetDesc CalculationNetDescArray[TrainingPopulationSize];

	CNeuralCalculationNetDescPopulation CalculationNetDescPopulation;
	CalculationNetDescPopulation.Initialize(TrainingPopulationSize);

	for (int32_t i = 0; i < TrainingPopulationSize; i++)
	{
		CalculationNetDescArray[i].Initialize(NumOfCalculationUnits);
		CalculationNetDescArray[i].Clone_Values(&CalculationNetDesc);

		XORBrain_Reinitialization(&CalculationNetDescArray[i], &RandomNumbers, nullptr);

		CalculationNetDescPopulation.Set_NeuralCalculationNetDesc(&CalculationNetDescArray[i], i);
	}


	CNeuralCalculationNet CalculationNet;

	//CalculationNet.Initialize(&CalculationNetDesc, &CalculationFunctions, 2, 1);
	CalculationNet.Initialize(NumOfCalculationUnits, 2, 1);
	CalculationNet.Modify(&CalculationNetDesc, &CalculationFunctions);


	float outputValue;
	//float outputValueArray[1];

	float errorSum;

	for (int32_t j = 0; j < NumTrainingGenerationsMax; j++)
	{
		CalculationNetDescPopulation.Reset_MinErrorSum_ActualGeneration();

		for (int32_t i = 0; i < TrainingPopulationSize; i++)
		{
			CalculationNet.Modify(&CalculationNetDescArray[i], &CalculationFunctions);

			errorSum = 0.0f;

			for (int32_t k = 0; k < ConstNumOfInputArrays; k++)
			{
				CalculationNet.Set_InputValues(pInputArrayPointer[k]);
				CalculationNet.Execute_Calculations();
				errorSum += CalculationNet.Calculate_OutputVarianceSum(&DesiredXOROutputArray[k]);
			}

			CalculationNetDescPopulation.Calculate_FitnessScore_FromError(i, errorSum);

			CalculationNetDescPopulation.Update_MinErrorSum_ActualGeneration(errorSum);

		} // end of for (int32_t i = 0; i < TrainingPopulationSize; i++)

		CalculationNetDescPopulation.Update_Population();

		if (j % 100 == 0)
		{
			cout << "minErrorSum: " << CalculationNetDescPopulation.MinErrorSum_ActualGeneration << endl;
		}

		if (CalculationNetDescPopulation.MinErrorSum_ActualGeneration < 0.01f)
		{
			cout << endl;
		    cout << "minErrorSum: " << CalculationNetDescPopulation.MinErrorSum_ActualGeneration << endl;
			cout << "actual generation: " << j << endl;
			cout << "training completed" << endl << endl;
			break;
		}

		CalculationNetDescPopulation.Update_BaseEvolution(XORBrain_Mutation, nullptr);
		CalculationNetDescPopulation.Update_Evolution_BestBrainOnly(XORBrain_Mutation, nullptr);
		CalculationNetDescPopulation.Update_Evolution_SecondBestBrainOnly(XORBrain_Mutation, nullptr);
		CalculationNetDescPopulation.Update_Evolution_Combine_BestTwoBrains(XORBrain_Recombination, nullptr);
		CalculationNetDescPopulation.Update_Evolution_Combine_TwoBrains(XORBrain_Recombination, nullptr);
		CalculationNetDescPopulation.Update_Evolution_Combine_TwoBrains(XORBrain_Recombination, nullptr);
		CalculationNetDescPopulation.Replace_WorstFitted_Brain(XORBrainRBF_Reinitialization, nullptr);
		CalculationNetDescPopulation.Replace_SecondWorstFitted_Brain(XORBrain_Reinitialization, nullptr);
		CalculationNetDescPopulation.Replace_ThirdWorstFitted_Brain(XORBrain_Reinitialization, nullptr);

	} // end of for (int32_t j = 0; j < NumTrainingGenerationsMax; j++)


	CalculationNetDescPopulation.Get_Best_Evolved_NeuralCalculationNetDesc(&CalculationNetDesc);

	
	CalculationNet.Modify(&CalculationNetDesc, &CalculationFunctions);

	
	cout << endl;

	//getchar();

	for (int32_t i = 0; i < ConstNumOfInputArrays; i++)
	{
		CalculationNet.Set_InputValues(pInputArrayPointer[i]);
		CalculationNet.Execute_Calculations();
		CalculationNet.Get_OutputValues(&outputValue);

		cout << "input values: " << pInputArrayPointer[i][0] << " " << pInputArrayPointer[i][1] << endl;
		cout << "activation value: " << outputValue << endl << endl;
	}

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	static constexpr int32_t ConstNumOfPoints = 4;
	static constexpr int32_t ConstNumOfClusters = 2;

	static C2DPoint_InsideCluster PointArray[ConstNumOfPoints];
	static C2DClusterCentroid CentroidArray[ConstNumOfClusters];

	PointArray[0].x = 0.0f;
	PointArray[0].y = 0.0f;

	PointArray[1].x = 1.0f;
	PointArray[1].y = 0.0f;

	PointArray[2].x = 0.0f;
	PointArray[2].y = 1.0f;

	PointArray[3].x = 1.0f;
	PointArray[3].y = 1.0f;

	for (int32_t i = 0; i < ConstNumOfClusters; i++)
	{
		CentroidArray[i].centroidID = i;
	}

	CentroidArray[0].centroidID = 0;
	CentroidArray[0].centerX = PointArray[2].x;
	CentroidArray[0].centerY = PointArray[2].y;

	CentroidArray[1].centroidID = 1;
	CentroidArray[1].centerX = PointArray[3].x;
	CentroidArray[1].centerY = PointArray[3].y;

	//CentroidArray[0].centroidID = 0;
	//CentroidArray[0].centerX = -0.5f;
	//CentroidArray[0].centerY = -0.2f;

	//CentroidArray[1].centroidID = 1;
	//CentroidArray[1].centerX = 1.5f;
	//CentroidArray[1].centerY = 0.9f;


	
	Calculate_Clusters(CentroidArray, ConstNumOfClusters, PointArray, ConstNumOfPoints, 100);

	cout << fixed;
	//cout << defaultfloat;
	cout.precision(2);

	for (int32_t i = 0; i < ConstNumOfClusters; i++)
	{
		cout << "centerX: " << CentroidArray[i].centerX << " centerY: " << CentroidArray[i].centerY << endl;
	}

	cout << endl;

	for (int32_t i = 0; i < ConstNumOfPoints; i++)
	{
		cout << PointArray[i].clusterID << " ";
	}

	cout << endl;

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/

/*
int main(void)
{
	static constexpr int32_t ImageSizeX = 32;
	static constexpr int32_t ImageSizeY = 32;
	static constexpr int32_t ImageSizeXY = ImageSizeX *  ImageSizeY;


	static float TestImage1[ImageSizeXY];

	uint8_t *pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("TestSample.bmp");

	Get_BinaryImageData_BlueChannel(TestImage1, pImageData, ImageSizeX, ImageSizeY);

	delete[] pImageData;
	pImageData = nullptr;

	int32_t NumOfNonZeroPixel = 0;

	for (int32_t i = 0; i < ImageSizeXY; i++)
	{
		if (TestImage1[i] > 0.0f)
		{
			NumOfNonZeroPixel++;
		}
	}

	static constexpr int32_t ConstNumOfClusters = 8;
	static C2DClusterCentroid CentroidArray[ConstNumOfClusters];
	static C2DClusterCentroid OptimizedCentroidArray[ConstNumOfClusters];

	C2DPoint_InsideCluster *pPixelArray = new (std::nothrow) C2DPoint_InsideCluster[NumOfNonZeroPixel];

	int32_t pixelCounter = 0;

	for (int32_t iy = 0; iy < ImageSizeY; iy++)
	{
		int32_t iiy = iy * ImageSizeX;

		for (int32_t ix = 0; ix < ImageSizeX; ix++)
		{
			int32_t id = ix + iiy;

			if (TestImage1[id] > 0.0f)
			{
				pPixelArray[pixelCounter].x = static_cast<float>(ix);
				pPixelArray[pixelCounter].y = static_cast<float>(iy);

				pixelCounter++;
			}
		}
	}

	CRandomNumbersNN RandomNumbers;
	
	for (int32_t i = 0; i < ConstNumOfClusters; i++)
	{
		OptimizedCentroidArray[i].centroidID = i;
		CentroidArray[i].centroidID = i;
	}

	float minVariance = 100000.0f;

	for (int32_t j = 0; j < 100; j++)
	{

		for (int32_t i = 0; i < ConstNumOfClusters; i++)
		{
			CentroidArray[i].centerX = RandomNumbers.Get_FloatNumber(5.0f, 26.0f);
			CentroidArray[i].centerY = RandomNumbers.Get_FloatNumber(5.0f, 26.0f);
		}

		Calculate_Clusters(CentroidArray, ConstNumOfClusters, pPixelArray, NumOfNonZeroPixel, 200);

		Calculate_ClusterRadiusSqs(CentroidArray, ConstNumOfClusters, pPixelArray, NumOfNonZeroPixel);

		float variance = Calculate_ClusterRadiusVariance(CentroidArray, ConstNumOfClusters);

		cout << "variance: " << variance << endl;
		
		if (variance < minVariance)
		{
			minVariance = variance;

			for (int32_t i = 0; i < ConstNumOfClusters; i++)
			{
				OptimizedCentroidArray[i].Set_Centroid(&CentroidArray[i]);
			}
		}
	} // end of for (int32_t j = 0; j < 30; j++)

	getchar();

	for (int32_t i = 0; i < ConstNumOfClusters; i++)
	{
		int32_t ix = static_cast<int32_t>(OptimizedCentroidArray[i].centerX);
		int32_t iy = static_cast<int32_t>(OptimizedCentroidArray[i].centerY);

		TestImage1[ix + iy * ImageSizeX] = 8;
	}

	
	for (int32_t iy = 0; iy < ImageSizeY; iy++)
	{
		int32_t iiy = iy * ImageSizeX;

		for (int32_t ix = 0; ix < ImageSizeX; ix++)
		{
			int32_t id = ix + iiy;

			cout << TestImage1[id];
		}

		cout << endl;
	}

	cout << endl;

	delete[] pPixelArray;
	pPixelArray = nullptr;

	cout << "bye bye (Press Return)" << endl;
	getchar();

	return 0;
}
*/

/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	float InputArray1[2] = { 0.0f, 0.0f };
	float InputArray2[2] = { 1.0f, 0.0f };
	float InputArray3[2] = { 0.0f, 1.0f };
	float InputArray4[2] = { 1.0f, 1.0f };

	static constexpr int32_t ConstNumOfInputArrays = 4;

	float *pInputArrayPointer[ConstNumOfInputArrays];

	pInputArrayPointer[0] = InputArray1;
	pInputArrayPointer[1] = InputArray2;
	pInputArrayPointer[2] = InputArray3;
	pInputArrayPointer[3] = InputArray4;

	float DesiredXOROutputArray[ConstNumOfInputArrays] = { 0.0f, 1.0f, 1.0f, 0.0f };


	CNeuralCalculationFunctions CalculationFunctions;
	CalculationFunctions.Initialize(4);
	CalculationFunctions.Set_Function(0, nullptr);
	CalculationFunctions.Set_Function(1, Identity);
	CalculationFunctions.Set_Function(2, ExpRBF);
	CalculationFunctions.Set_Function(3, SumUp);

	static constexpr int32_t NumOfInputUnits = 2;
	static constexpr int32_t NumOfHiddenUnits = 4;
	static constexpr int32_t NumOfOutputUnits = 1;
	static constexpr int32_t NumOfCalculationUnits = NumOfInputUnits + NumOfHiddenUnits + NumOfOutputUnits;

	int32_t idOfFirstInputUnit = 0;
	int32_t idOfFirstHiddenUnit = NumOfInputUnits;
	int32_t idOfFirstOutputUnit = idOfFirstHiddenUnit + NumOfHiddenUnits;


	CNeuralCalculationNetDesc CalculationNetDesc;
	CalculationNetDesc.Initialize(NumOfCalculationUnits);


	for (int32_t i = 0; i < NumOfInputUnits; i++)
	{
		CalculationNetDesc.pCalculationFunctionIDArray[i] = 1;
		CalculationNetDesc.pCalculationUnitUsageStatusArray[i] = UsageStatus_CalculationInputUnit;
	}

	
	for (int32_t i = 0; i < NumOfOutputUnits; i++)
	{
		int32_t unitID = i + idOfFirstOutputUnit;
		CalculationNetDesc.pCalculationFunctionIDArray[unitID] = 1;
		CalculationNetDesc.pCalculationUnitUsageStatusArray[unitID] = UsageStatus_CalculationOutputUnit;
	}

	for (int32_t i = 0; i < NumOfHiddenUnits; i++)
	{
		int32_t unitID = i + idOfFirstHiddenUnit;
		CalculationNetDesc.pCalculationFunctionIDArray[unitID] = 2;
		CalculationNetDesc.pCalculationUnitUsageStatusArray[unitID] = UsageStatus_CalculationUnit_Standard;
	}

	float minRandomCentroidValue = -2.0f;
	float maxRandomCentroidValue = 2.0f;

	for (int32_t iy = 0; iy < idOfFirstHiddenUnit; iy++)
	{
		for (int32_t ix = idOfFirstHiddenUnit; ix < idOfFirstOutputUnit; ix++)
		{
			int32_t id = ix + iy * NumOfCalculationUnits;
			CalculationNetDesc.pConnectionStatusArray[id] = 1;
			CalculationNetDesc.pPlasticityValueArray[id] = 1.0f;
			CalculationNetDesc.pRBFConstantArray[id] = 10.0f;
			CalculationNetDesc.pCentroidValueArray[id] = RandomNumbers.Get_FloatNumber(minRandomCentroidValue, maxRandomCentroidValue);
		}
	}

	for (int32_t iy = idOfFirstHiddenUnit; iy < idOfFirstOutputUnit; iy++)
	{
		for (int32_t ix = idOfFirstOutputUnit; ix < NumOfCalculationUnits; ix++)
		{
			int32_t id = ix + iy * NumOfCalculationUnits;
			CalculationNetDesc.pConnectionStatusArray[id] = 1;
			CalculationNetDesc.pPlasticityValueArray[id] = 1.0f;
		}
	}



	static constexpr int32_t TrainingPopulationSize = 50;
	static constexpr int32_t NumTrainingGenerationsMax = 10000;

	static CNeuralCalculationNetDesc CalculationNetDescArray[TrainingPopulationSize];

	CNeuralCalculationNetDescPopulation CalculationNetDescPopulation;
	CalculationNetDescPopulation.Initialize(TrainingPopulationSize);

	for (int32_t i = 0; i < TrainingPopulationSize; i++)
	{
		CalculationNetDescArray[i].Initialize(NumOfCalculationUnits);
		CalculationNetDescArray[i].Clone_Values(&CalculationNetDesc);

		XORBrainRBF_Reinitialization(&CalculationNetDescArray[i], &RandomNumbers, nullptr);

		CalculationNetDescPopulation.Set_NeuralCalculationNetDesc(&CalculationNetDescArray[i], i);
	}


	CNeuralCalculationNet CalculationNet;

	//CalculationNet.Initialize(&CalculationNetDesc, &CalculationFunctions, 2, 1);
	CalculationNet.Initialize(NumOfCalculationUnits, 2, 1);
	CalculationNet.Modify(&CalculationNetDesc, &CalculationFunctions);


	float outputValue;
	//float outputValueArray[1];

	float errorSum;

	for (int32_t j = 0; j < NumTrainingGenerationsMax; j++)
	{
		CalculationNetDescPopulation.Reset_MinErrorSum_ActualGeneration();

		for (int32_t i = 0; i < TrainingPopulationSize; i++)
		{
			CalculationNet.Modify(&CalculationNetDescArray[i], &CalculationFunctions);

			errorSum = 0.0f;

			for (int32_t k = 0; k < ConstNumOfInputArrays; k++)
			{
				CalculationNet.Set_InputValues(pInputArrayPointer[k]);
				CalculationNet.Execute_Calculations();
				errorSum += CalculationNet.Calculate_OutputVarianceSum(&DesiredXOROutputArray[k]);
			}

			CalculationNetDescPopulation.Calculate_FitnessScore_FromError(i, errorSum);

			CalculationNetDescPopulation.Update_MinErrorSum_ActualGeneration(errorSum);

		} // end of for (int32_t i = 0; i < TrainingPopulationSize; i++)

		CalculationNetDescPopulation.Update_Population();

		if (j % 1000 == 0)
		{
			cout << "minErrorSum: " << CalculationNetDescPopulation.MinErrorSum_ActualGeneration << endl;
		}

		if (CalculationNetDescPopulation.MinErrorSum_ActualGeneration < 0.0001f)
		{
		    cout << endl;
			cout << "minErrorSum: " << CalculationNetDescPopulation.MinErrorSum_ActualGeneration << endl;
			cout << "actual generation: " << j << endl;
			cout << "training completed" << endl << endl;
			break;
		}

		CalculationNetDescPopulation.Update_BaseEvolution(XORBrainRBF_Mutation, nullptr);
		CalculationNetDescPopulation.Update_Evolution_BestBrainOnly(XORBrainRBF_Mutation, nullptr);
		CalculationNetDescPopulation.Update_Evolution_SecondBestBrainOnly(XORBrainRBF_Mutation, nullptr);
		CalculationNetDescPopulation.Update_Evolution_Combine_BestTwoBrains(XORBrainRBF_Recombination, nullptr);
		CalculationNetDescPopulation.Update_Evolution_Combine_TwoBrains(XORBrainRBF_Recombination, nullptr);
		CalculationNetDescPopulation.Update_Evolution_Combine_TwoBrains(XORBrainRBF_Recombination, nullptr);
		CalculationNetDescPopulation.Replace_WorstFitted_Brain(XORBrainRBF_Reinitialization, nullptr);
		CalculationNetDescPopulation.Replace_SecondWorstFitted_Brain(XORBrainRBF_Reinitialization, nullptr);
		CalculationNetDescPopulation.Replace_ThirdWorstFitted_Brain(XORBrainRBF_Reinitialization, nullptr);

	} // end of for (int32_t j = 0; j < NumTrainingGenerationsMax; j++)


	CalculationNetDescPopulation.Get_Best_Evolved_NeuralCalculationNetDesc(&CalculationNetDesc);


	CalculationNet.Modify(&CalculationNetDesc, &CalculationFunctions);


	cout << endl;

	//getchar();

	for (int32_t i = 0; i < ConstNumOfInputArrays; i++)
	{
		CalculationNet.Set_InputValues(pInputArrayPointer[i]);
		CalculationNet.Execute_Calculations();
		CalculationNet.Get_OutputValues(&outputValue);

		cout << "input values: " << pInputArrayPointer[i][0] << " " << pInputArrayPointer[i][1] << endl;
		cout << "activation value: " << outputValue << endl << endl;
	}


	CNeuralCalculationNet CalculationNet2;
	CalculationNet2.Initialize(NumOfCalculationUnits, 2, 1);
	CalculationNet2.Modify(&CalculationNetDesc, &CalculationFunctions);

	// SumUp-Activation-Function:
	CalculationNet2.Set_CalculationFunction(CalculationNet2.pOutputUnitIDArray[0], 3, &CalculationFunctions);

	float PatternArray[8] = { 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f };

	CalculationNet2.Reset_OutputUnits_Input_And_OutputValue();

	CalculationNet2.Set_InputValues(PatternArray, 0);
	CalculationNet2.Execute_Calculations();
	CalculationNet2.Set_InputValues(PatternArray, 2);
	CalculationNet2.Execute_Calculations();
	CalculationNet2.Set_InputValues(PatternArray, 4);
	CalculationNet2.Execute_Calculations();
	CalculationNet2.Set_InputValues(PatternArray, 6);
	CalculationNet2.Execute_Calculations();

	CalculationNet2.Get_OutputValues(&outputValue);
	cout << "activation value: " << outputValue << endl << endl;


	cout << fixed;
	//cout << defaultfloat;
	cout.precision(2);

	int32_t couter = 0;

	for (int32_t iy = 0; iy < idOfFirstHiddenUnit; iy++)
	{
		if (iy == 0)
		{
			cout << "CentroidXValues: ";
		}
		else if (iy == 1)
		{
			cout << "CentroidYValues: ";
		}

		for (int32_t ix = idOfFirstHiddenUnit; ix < idOfFirstOutputUnit; ix++)
		{
			int32_t id = ix + iy * NumOfCalculationUnits;

			cout << CalculationNetDesc.pCentroidValueArray[id] << " ";

			couter++;

			if (couter == 4)
			{
				cout << endl;
			}
		}
	}

	cout << endl;
	cout << endl;

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/




/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	static float Image1[4] = { 0.0f, 0.0f , 0.0f , 0.0f };

	static float Image2[4] = { 1.0f, 0.0f , 0.0f , 0.0f };
	static float Image3[4] = { 0.0f, 1.0f , 0.0f , 0.0f };
	static float Image4[4] = { 0.0f, 0.0f , 1.0f , 0.0f };
	static float Image5[4] = { 0.0f, 0.0f , 0.0f , 1.0f };

	static float Image6[4] = { 1.0f, 1.0f , 0.0f , 0.0f };
	static float Image7[4] = { 1.0f, 0.0f , 1.0f , 0.0f };
	static float Image8[4] = { 1.0f, 0.0f , 0.0f , 1.0f };
	static float Image9[4] = { 0.0f, 1.0f , 1.0f , 0.0f };
	static float Image10[4] = { 0.0f, 1.0f , 0.0f , 1.0f };
	static float Image11[4] = { 0.0f, 0.0f , 1.0f , 1.0f };

	static float Image12[4] = { 1.0f, 1.0f , 1.0f , 0.0f };
	static float Image13[4] = { 1.0f, 1.0f , 0.0f , 1.0f };
	static float Image14[4] = { 1.0f, 0.0f , 1.0f , 1.0f };
	static float Image15[4] = { 0.0f, 1.0f , 1.0f , 1.0f };
	
	static float Image16[4] = { 1.0f, 1.0f , 1.0f , 1.0f };

	static constexpr int32_t ConstNumOfInputArrays = 16;

	float *pInputArrayPointer[ConstNumOfInputArrays];

	pInputArrayPointer[0] = Image1;
	pInputArrayPointer[1] = Image2;
	pInputArrayPointer[2] = Image3;
	pInputArrayPointer[3] = Image4;
	pInputArrayPointer[4] = Image5;
	pInputArrayPointer[5] = Image6;
	pInputArrayPointer[6] = Image7;
	pInputArrayPointer[7] = Image8;
	pInputArrayPointer[8] = Image9;
	pInputArrayPointer[9] = Image10;
	pInputArrayPointer[10] = Image11;
	pInputArrayPointer[11] = Image12;
	pInputArrayPointer[12] = Image13;
	pInputArrayPointer[13] = Image14;
	pInputArrayPointer[14] = Image15;
	pInputArrayPointer[15] = Image16;
	
	static float DesiredOutputArray[ConstNumOfInputArrays] = { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f };
	

	CNeuralCalculationFunctions CalculationFunctions;
	CalculationFunctions.Initialize(3);
	CalculationFunctions.Set_Function(0, nullptr);
	CalculationFunctions.Set_Function(1, Identity);
	CalculationFunctions.Set_Function(2, ExpRBF);
	

	static constexpr int32_t NumOfInputUnits = 4;
	static constexpr int32_t NumOfInputAndBiasUnits = 4;
	static constexpr int32_t NumOfOutputUnits = 1;
	static constexpr int32_t NumOfCalculationUnits = NumOfInputUnits + NumOfOutputUnits;

	int32_t idOfFirstInputUnit = 0;
	int32_t idOfFirstOutputUnit = NumOfInputUnits;


	CNeuralCalculationNetDesc CalculationNetDesc;
	CalculationNetDesc.Initialize(NumOfCalculationUnits);


	for (int32_t i = 0; i < NumOfInputUnits; i++)
	{
		CalculationNetDesc.pCalculationFunctionIDArray[i] = 1;
		CalculationNetDesc.pCalculationUnitUsageStatusArray[i] = UsageStatus_CalculationInputUnit;
	}


	for (int32_t i = 0; i < NumOfOutputUnits; i++)
	{
		int32_t unitID = i + idOfFirstOutputUnit;
		CalculationNetDesc.pCalculationFunctionIDArray[unitID] = 2;
		CalculationNetDesc.pCalculationUnitUsageStatusArray[unitID] = UsageStatus_CalculationOutputUnit;
	}

	
	float minRandomCentroidValue = -2.0f;
	float maxRandomCentroidValue = 2.0f;

	
	for (int32_t inputOrBiasUnitNumber = 0; inputOrBiasUnitNumber < NumOfInputAndBiasUnits; inputOrBiasUnitNumber++)
	{
		for (int32_t outputUnitNumber = 0; outputUnitNumber < NumOfOutputUnits; outputUnitNumber++)
		{
			int32_t id;
			Get_ConnectionID_2LayerFFNN(&id, inputOrBiasUnitNumber, outputUnitNumber, NumOfInputAndBiasUnits, NumOfCalculationUnits);

			CalculationNetDesc.pConnectionStatusArray[id] = 1;
			CalculationNetDesc.pPlasticityValueArray[id] = 1.0f;
			CalculationNetDesc.pRBFConstantArray[id] = 10.0f;
			CalculationNetDesc.pCentroidValueArray[id] = RandomNumbers.Get_FloatNumber(minRandomCentroidValue, maxRandomCentroidValue);
		}
	}

	


	//for (int32_t iy = 0; iy < idOfFirstOutputUnit; iy++)
	//{
	//int32_t ixMax = idOfFirstOutputUnit + NumOfOutputUnits;

	//for (int32_t ix = idOfFirstOutputUnit; ix < ixMax; ix++)
	//{
	//int32_t id = ix + iy * NumOfCalculationUnits;
	//CalculationNetDesc.pConnectionStatusArray[id] = 1;
	//CalculationNetDesc.pPlasticityValueArray[id] = 1.0f;
	//CalculationNetDesc.pRBFConstantArray[id] = 10.0f;
	//CalculationNetDesc.pCentroidValueArray[id] = RandomNumbers.Get_FloatNumber(minRandomCentroidValue, maxRandomCentroidValue);
	//}
	//}


	static constexpr int32_t TrainingPopulationSize = 50;
	static constexpr int32_t NumTrainingGenerationsMax = 10000;

	static CNeuralCalculationNetDesc CalculationNetDescArray[TrainingPopulationSize];

	CNeuralCalculationNetDescPopulation CalculationNetDescPopulation;
	CalculationNetDescPopulation.Initialize(TrainingPopulationSize);

	for (int32_t i = 0; i < TrainingPopulationSize; i++)
	{
		CalculationNetDescArray[i].Initialize(NumOfCalculationUnits);
		CalculationNetDescArray[i].Clone_Values(&CalculationNetDesc);

		BrainRBF_Reinitialization(&CalculationNetDescArray[i], &RandomNumbers, nullptr);

		CalculationNetDescPopulation.Set_NeuralCalculationNetDesc(&CalculationNetDescArray[i], i);
	}

	CNeuralCalculationNet CalculationNet;

	CalculationNet.Initialize(NumOfCalculationUnits, 4, 1);
	CalculationNet.Modify(&CalculationNetDesc, &CalculationFunctions);


	float outputValue;
	//float outputValueArray[1];

	float errorSum;

	float desiredOutput;

	for (int32_t j = 0; j < NumTrainingGenerationsMax; j++)
	{
		CalculationNetDescPopulation.Reset_MinErrorSum_ActualGeneration();

		for (int32_t i = 0; i < TrainingPopulationSize; i++)
		{
			CalculationNet.Modify(&CalculationNetDescArray[i], &CalculationFunctions);

			errorSum = 0.0f;

			for (int32_t k = 0; k < ConstNumOfInputArrays; k++)
			{
				CalculationNet.Set_InputValues(pInputArrayPointer[k]);
				CalculationNet.Execute_Calculations();
				errorSum += CalculationNet.Calculate_OutputVarianceSum(&DesiredOutputArray[k]);
			}

			CalculationNetDescPopulation.Calculate_FitnessScore_FromError(i, errorSum);

			CalculationNetDescPopulation.Update_MinErrorSum_ActualGeneration(errorSum);

		} // end of for (int32_t i = 0; i < TrainingPopulationSize; i++)

		CalculationNetDescPopulation.Update_Population();

		if (j % 1000 == 0)
		{
			cout << "minErrorSum: " << CalculationNetDescPopulation.MinErrorSum_ActualGeneration << endl;
		}

		if (CalculationNetDescPopulation.MinErrorSum_ActualGeneration < 0.0001f)
		{
			cout << endl;
			cout << "minErrorSum: " << CalculationNetDescPopulation.MinErrorSum_ActualGeneration << endl;
			cout << "actual generation: " << j << endl;
			cout << "training completed" << endl << endl;
			break;
		}

		CalculationNetDescPopulation.Update_BaseEvolution(BrainRBF_Mutation, nullptr);
		CalculationNetDescPopulation.Update_Evolution_BestBrainOnly(BrainRBF_Mutation, nullptr);
		CalculationNetDescPopulation.Update_Evolution_SecondBestBrainOnly(BrainRBF_Mutation, nullptr);
		CalculationNetDescPopulation.Update_Evolution_Combine_BestTwoBrains(BrainRBF_Recombination, nullptr);
		CalculationNetDescPopulation.Update_Evolution_Combine_TwoBrains(BrainRBF_Recombination, nullptr);
		CalculationNetDescPopulation.Update_Evolution_Combine_TwoBrains(BrainRBF_Recombination, nullptr);
		CalculationNetDescPopulation.Replace_WorstFitted_Brain(BrainRBF_Reinitialization, nullptr);
		CalculationNetDescPopulation.Replace_SecondWorstFitted_Brain(BrainRBF_Reinitialization, nullptr);
		CalculationNetDescPopulation.Replace_ThirdWorstFitted_Brain(BrainRBF_Reinitialization, nullptr);

	} // end of for (int32_t j = 0; j < NumTrainingGenerationsMax; j++)


	CalculationNetDescPopulation.Get_Best_Evolved_NeuralCalculationNetDesc(&CalculationNetDesc);


	CalculationNet.Modify(&CalculationNetDesc, &CalculationFunctions);


	cout << endl;

	cout << fixed;
	//cout << defaultfloat;
	cout.precision(2);

	int32_t counter = 0;
	cout << "activation values (desired):" << endl;

	for (int32_t i = 0; i < ConstNumOfInputArrays; i++)
	{
		cout << DesiredOutputArray[i] << " ";
		counter++;

		if (counter % 4 == 0)
		{
			cout << endl;
		}
	}


	counter = 0; 
	cout << endl << "activation values (learned):" << endl;

	for (int32_t i = 0; i < ConstNumOfInputArrays; i++)
	{
		CalculationNet.Set_InputValues(pInputArrayPointer[i]);
		CalculationNet.Execute_Calculations();
		CalculationNet.Get_OutputValues(&outputValue);

		cout << outputValue << " ";
		counter++;

		if (counter % 4 == 0)
		{
			cout << endl;
		}
	}

	cout << endl;

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CNeuralCalculationFunctions CalculationFunctions;
	CalculationFunctions.Initialize(4);
	CalculationFunctions.Set_Function(0, nullptr);
	CalculationFunctions.Set_Function(1, Identity);
	CalculationFunctions.Set_Function(2, ExpRBF);
	CalculationFunctions.Set_Function(3, SumUp);

	CNeuralCalculationNetDesc CalculationNetDesc;

	int32_t numOfCentroids = 3;
	float rbfConstant = 10.0f;
	int32_t inputUnitCalcFuncID = 1;
	int32_t hiddenUnitCalcFuncID = 2;
	int32_t outputUnitCalcFuncID = 3;
	bool initAdditionalCentroidOutputUnits = true;

	ConstructionFunction_2DCentroidNetDesc(&CalculationNetDesc, numOfCentroids, rbfConstant, inputUnitCalcFuncID, hiddenUnitCalcFuncID, outputUnitCalcFuncID, initAdditionalCentroidOutputUnits);

	CNeuralCalculationNet CalculationNet;

	CalculationNet.Initialize(&CalculationNetDesc, &CalculationFunctions, 2, numOfCentroids + 1);
	
	int32_t centroidIDX, centroidIDY;

	int32_t centroidNumber = 0;

	Get_2DimLayer2CentroidConnectionID(&centroidIDX, &centroidIDY, centroidNumber, CalculationNet.NumOfCalculationUnits);

	float centroid0_xValue = 2.0f;
	float centroid0_yValue = 1.0f;
	CalculationNet.Set_Connection_CentroidValue(centroidIDX, centroid0_xValue);
	CalculationNet.Set_Connection_CentroidValue(centroidIDY, centroid0_yValue);

	centroidNumber = 1;

	Get_2DimLayer2CentroidConnectionID(&centroidIDX, &centroidIDY, centroidNumber, CalculationNet.NumOfCalculationUnits);

	float centroid1_xValue = 1.0f;
	float centroid1_yValue = 2.0f;
	CalculationNet.Set_Connection_CentroidValue(centroidIDX, centroid1_xValue);
	CalculationNet.Set_Connection_CentroidValue(centroidIDY, centroid1_yValue);

	centroidNumber = 2;

	Get_2DimLayer2CentroidConnectionID(&centroidIDX, &centroidIDY, centroidNumber, CalculationNet.NumOfCalculationUnits);

	float centroid2_xValue = 3.0f;
	float centroid2_yValue = 2.0f;
	CalculationNet.Set_Connection_CentroidValue(centroidIDX, centroid2_xValue);
	CalculationNet.Set_Connection_CentroidValue(centroidIDY, centroid2_yValue);
	

	cout << fixed;
	//cout << defaultfloat;
	cout.precision(2);

	float outputValueArray[4];

	float InputValuePosArray[2];

	CalculationNet.Reset_OutputUnits_Input_And_OutputValue();

	InputValuePosArray[0] = centroid0_xValue;
	InputValuePosArray[1] = centroid0_yValue;

	CalculationNet.Set_InputValues(InputValuePosArray);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(outputValueArray);

	cout << outputValueArray[0] << " " << outputValueArray[1] << " " << outputValueArray[2] << " " << outputValueArray[3] << endl;

	InputValuePosArray[0] = centroid1_xValue;
	InputValuePosArray[1] = centroid1_yValue;

	CalculationNet.Set_InputValues(InputValuePosArray);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(outputValueArray);

	cout << outputValueArray[0] << " " << outputValueArray[1] << " " << outputValueArray[2] << " " << outputValueArray[3] << endl;

	InputValuePosArray[0] = centroid2_xValue;
	InputValuePosArray[1] = centroid2_yValue;

	CalculationNet.Set_InputValues(InputValuePosArray);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(outputValueArray);

	cout << outputValueArray[0] << " " << outputValueArray[1] << " " << outputValueArray[2] << " " << outputValueArray[3] << endl;

	InputValuePosArray[0] = 2.0f;
	InputValuePosArray[1] = 1.25f;

	CalculationNet.Set_InputValues(InputValuePosArray);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(outputValueArray);

	cout << outputValueArray[0] << " " << outputValueArray[1] << " " << outputValueArray[2] << " " << outputValueArray[3] << endl;


	cout << endl;

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/




/*
int main(void)
{
	CNeuralCalculationFunctions CalculationFunctions;
	CalculationFunctions.Initialize(4);
	CalculationFunctions.Set_Function(0, nullptr);
	CalculationFunctions.Set_Function(1, Identity);
	CalculationFunctions.Set_Function(2, ExpRBF);
	CalculationFunctions.Set_Function(3, SumUpExt);

	CNeuralCalculationNetDesc CalculationNetDesc;

	int32_t numOfCentroids = 3;
	float rbfConstant = 10.0f;
	int32_t inputUnitCalcFuncID = 1;
	int32_t hiddenUnitCalcFuncID = 2;
	int32_t outputUnitCalcFuncID = 3;
	bool initAdditionalCentroidOutputUnits = true;

	ConstructionFunction_2DCentroidNetDesc(&CalculationNetDesc, numOfCentroids, rbfConstant, inputUnitCalcFuncID, hiddenUnitCalcFuncID, outputUnitCalcFuncID, initAdditionalCentroidOutputUnits);

	

	int32_t centroidIDX, centroidIDY;

	int32_t centroidNumber = 0;

	Get_2DimLayer2CentroidConnectionID(&centroidIDX, &centroidIDY, centroidNumber, CalculationNetDesc.NumOfCalculationUnits);

	float centroid0_xValue = 2.0f;
	float centroid0_yValue = 1.0f;

	CalculationNetDesc.pRBFConstantArray[centroidIDX] = rbfConstant;
	CalculationNetDesc.pCentroidValueArray[centroidIDX] = centroid0_xValue;
	CalculationNetDesc.pRBFConstantArray[centroidIDY] = rbfConstant;
	CalculationNetDesc.pCentroidValueArray[centroidIDY] = centroid0_yValue;
	
	centroidNumber = 1;

	Get_2DimLayer2CentroidConnectionID(&centroidIDX, &centroidIDY, centroidNumber, CalculationNetDesc.NumOfCalculationUnits);

	float centroid1_xValue = 1.0f;
	float centroid1_yValue = 2.0f;

	CalculationNetDesc.pRBFConstantArray[centroidIDX] = rbfConstant;
	CalculationNetDesc.pCentroidValueArray[centroidIDX] = centroid1_xValue;
	CalculationNetDesc.pRBFConstantArray[centroidIDY] = rbfConstant;
	CalculationNetDesc.pCentroidValueArray[centroidIDY] = centroid1_yValue;

	centroidNumber = 2;

	Get_2DimLayer2CentroidConnectionID(&centroidIDX, &centroidIDY, centroidNumber, CalculationNetDesc.NumOfCalculationUnits);

	float centroid2_xValue = 3.0f;
	float centroid2_yValue = 2.0f;

	CalculationNetDesc.pRBFConstantArray[centroidIDX] = rbfConstant;
	CalculationNetDesc.pCentroidValueArray[centroidIDX] = centroid2_xValue;
	CalculationNetDesc.pRBFConstantArray[centroidIDY] = rbfConstant;
	CalculationNetDesc.pCentroidValueArray[centroidIDY] = centroid2_yValue;


	CNeuralCalculationNet CalculationNet;

	CalculationNet.Initialize(&CalculationNetDesc, &CalculationFunctions, 2, numOfCentroids + 1);

	cout << fixed;
	//cout << defaultfloat;
	cout.precision(2);

	float outputValueArray[4];
	float inputValue = 1.0f;

	CalculationNet.Reset_OutputUnits_Input_And_OutputValue();

	Set_Input_2DimCentroidNet(centroid0_xValue, centroid0_yValue, inputValue, &CalculationNet);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(outputValueArray);

	cout << outputValueArray[0] << " " << outputValueArray[1] << " " << outputValueArray[2] << " " << outputValueArray[3] << endl;

	Set_Input_2DimCentroidNet(centroid1_xValue, centroid1_yValue, inputValue, &CalculationNet);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(outputValueArray);

	cout << outputValueArray[0] << " " << outputValueArray[1] << " " << outputValueArray[2] << " " << outputValueArray[3] << endl;

	Set_Input_2DimCentroidNet(centroid2_xValue, centroid2_yValue, inputValue, &CalculationNet);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(outputValueArray);

	cout << outputValueArray[0] << " " << outputValueArray[1] << " " << outputValueArray[2] << " " << outputValueArray[3] << endl;

	Set_Input_2DimCentroidNet(2.0f, 1.25f, inputValue, &CalculationNet);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(outputValueArray);

	cout << outputValueArray[0] << " " << outputValueArray[1] << " " << outputValueArray[2] << " " << outputValueArray[3] << endl;

	float clusterMinMaxRelation;

	CentroidNet_Get_ClusterMinMaxRelation(&clusterMinMaxRelation, &CalculationNet);
	cout << "ClusterMinMaxRelation: "<< clusterMinMaxRelation << endl;


	cout << endl;

	



	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/




#include "Sudoku.h"


/*
int main(void)
{
    // sehr leichtes Sudoku:
	// Hinweis: 0: hier muss die korrekte Ziffer ermittelt werden!

	static int32_t SudokuPuzzle[SudokuSizeSq] = {
		0, 7, 8, 1, 0, 6, 0, 2, 0,
		2, 4, 0, 5, 3, 0, 0, 0, 6,
		6, 0, 0, 7, 0, 9, 8, 0, 0,
		8, 5, 3, 0, 0, 0, 9, 0, 2,
		0, 6, 0, 0, 0, 0, 0, 7, 0,
		1, 0, 7, 0, 0, 0, 4, 3, 5,
		0, 0, 6, 3, 0, 1, 0, 0, 4,
		7, 0, 0, 0, 9, 5, 0, 8, 1,
		0, 2, 0, 6, 0, 4, 3, 9, 0 };

	int32_t counter = 0;

	do
	{
		if (Add_Value_If_Possible(SudokuPuzzle) == true)
		{
			counter++;
		}
		else
		{
			break;
		}

	} while (true);

	cout << "numbers found: " << counter << endl << endl;


	Output_Sudoku(SudokuPuzzle);

	cout << "sudoku errors: " << Count_SudokuErrors(SudokuPuzzle) << endl;


	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/

/*
int main(void)
{
	// leichtes Sudoku:
	// Hinweis: 0: hier muss die korrekte Ziffer ermittelt werden!
	static int32_t SudokuPuzzle[SudokuSizeSq] = {
		0, 3, 9, 6, 0, 0, 2, 0, 0,
		4, 0, 8, 0, 0, 3, 0, 0, 9,
		1, 5, 0, 0, 0, 2, 0, 8, 4,
		0, 8, 0, 0, 0, 5, 0, 0, 3,
		2, 0, 0, 0, 0, 0, 0, 0, 8,
		3, 0, 0, 2, 0, 0, 0, 5, 0,
		8, 4, 0, 5, 0, 0, 0, 9, 1,
		9, 0, 0, 8, 0, 0, 5, 0, 2,
		0, 0, 3, 0, 0, 7, 8, 4, 0 };

	int32_t counter = 0;

	do
	{
		if (Add_Value_If_Possible(SudokuPuzzle) == true)
		{
			counter++;
		}
		else
		{
			break;
		}

	} while (true);

	cout << "numbers found: " << counter << endl << endl;


	Output_Sudoku(SudokuPuzzle);

	cout << "sudoku errors: " << Count_SudokuErrors(SudokuPuzzle) << endl;


	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/

/*
int main(void)
{
	// mittelschweres Sudoku:
	// Hinweis: 0: hier muss die korrekte Ziffer ermittelt werden!
	static int32_t SudokuPuzzle[SudokuSizeSq] = {
		0, 0, 0, 0, 0, 5, 0, 0, 0,
		8, 0, 0, 0, 0, 0, 2, 0, 6,
		2, 0, 0, 8, 7, 6, 0, 5, 0,
		0, 0, 4, 6, 0, 0, 0, 2, 5,
		0, 1, 0, 0, 0, 0, 0, 9, 0,
		9, 5, 0, 0, 0, 1, 3, 0, 0,
		0, 3, 0, 7, 2, 9, 0, 0, 1,
		4, 0, 6, 0, 0, 0, 0, 0, 9,
		0, 0, 0, 3, 0, 0, 0, 0, 0 };

	int32_t counter = 0;

	do
	{
		if (Add_Value_If_Possible_Ext(SudokuPuzzle) == true)
		{
			counter++;
		}
		else
		{
			break;
		}

	} while (true);

	cout << "numbers found: " << counter << endl << endl;

	Output_Sudoku(SudokuPuzzle);

	getchar();

	CSudokuUpdateNodeArray SudokuUpdateNodeArray;
	SudokuUpdateNodeArray.Initialize(SudokuPuzzle);

	for (int32_t i = 0; i < 10000; i++)
	{
		if (SudokuUpdateNodeArray.Update_Node(SudokuPuzzle) == 2)
		{
			cout << "num of attempts: " << i << endl;
			break;
		}
	}

	Output_Sudoku(SudokuPuzzle);

	cout << "sudoku errors: " << Count_SudokuErrors(SudokuPuzzle) << endl;


	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/


/*
int main(void)
{
	// Hinweis: 0: hier muss die korrekte Ziffer ermittelt werden!

	static int32_t SudokuPuzzle[SudokuSizeSq] = {
		3, 0, 6, 5, 0, 8, 4, 0, 0,
		5, 2, 0, 0, 0, 0, 0, 0, 0,
		0, 8, 7, 0, 0, 0, 0, 3, 1,
		0, 0, 3, 0, 1, 0, 0, 8, 0,
		9, 0, 0, 8, 6, 3, 0, 0, 5,
		0, 5, 0, 0, 9, 0, 6, 0, 0,
		1, 3, 0, 0, 0, 0, 2, 5, 0,
		0, 0, 0, 0, 0, 0, 0, 7, 4,
		0, 0, 5, 2, 0, 6, 3, 0, 0 };

	if (RecursiveSudokuSolver(SudokuPuzzle, 0, 0) == true)
	{
		Output_Sudoku(SudokuPuzzle);
	}
	else
	{
		cout << "no solution  exists " << endl;
	}

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/

/*
int main(void)
{
	// Hinweis: 0: hier muss die korrekte Ziffer ermittelt werden!

	static int32_t SudokuPuzzle[SudokuSizeSq] = {
		3, 0, 6, 5, 0, 8, 4, 0, 0,
		5, 2, 0, 0, 0, 0, 0, 0, 0,
		0, 8, 7, 0, 0, 0, 0, 3, 1,
		0, 0, 3, 0, 1, 0, 0, 8, 0,
		9, 0, 0, 8, 6, 3, 0, 0, 5,
		0, 5, 0, 0, 9, 0, 6, 0, 0,
		1, 3, 0, 0, 0, 0, 2, 5, 0,
		0, 0, 0, 0, 0, 0, 0, 7, 4,
		0, 0, 5, 2, 0, 6, 3, 0, 0 };

		
	int32_t counter = 0;

	do
	{
		if (Add_Value_If_Possible_Ext(SudokuPuzzle) == true)
		{
			counter++;
		}
		else
		{
			break;
		}

	} while (true);

	cout << "numbers found: " << counter << endl << endl;

	CSudokuUpdateNodeArray SudokuUpdateNodeArray;
	SudokuUpdateNodeArray.Initialize(SudokuPuzzle);

	
	for (int32_t i = 0; i < 10000; i++)
	{
		if(SudokuUpdateNodeArray.Update_Node(SudokuPuzzle) == 2)
		{
		    cout << "num of attempts: " << i << endl;
			break;
		}
	}

	Output_Sudoku(SudokuPuzzle);

	cout << "sudoku errors: " << Count_SudokuErrors(SudokuPuzzle) << endl;


	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/





/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	// Hinweis: 0: hier muss die korrekte Ziffer ermittelt werden!

	static int32_t SudokuPuzzle[SudokuSizeSq] = {
		3, 0, 6, 5, 0, 8, 4, 0, 0,
		5, 2, 0, 0, 0, 0, 0, 0, 0,
		0, 8, 7, 0, 0, 0, 0, 3, 1,
		0, 0, 3, 0, 1, 0, 0, 8, 0,
		9, 0, 0, 8, 6, 3, 0, 0, 5,
		0, 5, 0, 0, 9, 0, 6, 0, 0,
		1, 3, 0, 0, 0, 0, 2, 5, 0,
		0, 0, 0, 0, 0, 0, 0, 7, 4,
		0, 0, 5, 2, 0, 6, 3, 0, 0 };

	int32_t counter = 0;

	do
	{
		if (Add_Value_If_Possible(SudokuPuzzle) == true)
		{
			counter++;
		}
		else
		{
			break;
		}
		
	} while (true);

	cout << "numbers found: " << counter << endl << endl;


	CSudokuUpdateNodeArrayExt SudokuUpdateNodeArray;
	SudokuUpdateNodeArray.Initialize(SudokuPuzzle);

	
	for (int32_t i = 0; i < 10000; i++)
	{
		if (SudokuUpdateNodeArray.Update_Node(SudokuPuzzle, &RandomNumbers) == 2)
		{
			cout << "num of attempts: " << i << endl;
			break;
		}
	}

	Output_Sudoku(SudokuPuzzle);

	cout << "sudoku errors: " << Count_SudokuErrors(SudokuPuzzle) << endl;


	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/



/*
int main(void)
{
	// Hinweis: 0: hier muss die korrekte Ziffer ermittelt werden!

	static int32_t BaseSudokuPuzzle[SudokuSizeSq] = {
		1, 2, 3, 4, 5, 6, 7, 8, 9,
		4, 5, 6, 7, 8, 9, 1, 2, 3,
		7, 8, 9, 1, 2, 3, 4, 5, 6,
		2, 3, 4, 5, 6, 7, 8, 9, 1,
		5, 6, 7, 8, 9, 1, 2, 3, 4,
		8, 9, 1, 2, 3, 4, 5, 6, 7,
		3, 4, 5, 6, 7, 8, 9, 1, 2,
		6, 7, 8, 9, 1, 2, 3, 4, 5,
		9, 1, 2, 3, 4, 5, 6, 7, 8 };

	

	static int32_t SudokuPuzzle1[SudokuSizeSq];

	//SudokuPermutation(SudokuPuzzle1, BaseSudokuPuzzle, 2, 6);
	
	//Swap_TwoSudoku9x3Blocks(SudokuPuzzle1, BaseSudokuPuzzle, 1, 2);
	Swap_TwoSudoku3x9Blocks(SudokuPuzzle1, BaseSudokuPuzzle, 1, 2);

	Output_Sudoku(SudokuPuzzle1);
	
	cout << "sudoku errors: " << Count_SudokuErrors(SudokuPuzzle1) << endl;

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	int32_t NumOfRows_ProblemMatrix = 7;
	int32_t NumOfColumns_ProblemMatrix = 7;

	static int32_t IDArrayOfSolutionRowVectors[7];

	static bool RowVector1[7] = { true, false, false, true, false, false, true };
	static bool RowVector2[7] = { true, false, false, true, false, false, false };
	static bool RowVector3[7] = { false, false, false, true, true, false, true };
	static bool RowVector4[7] = { false, false, true, false, true, true, false };
	static bool RowVector5[7] = { false, true, true, false, false, true, true };
	static bool RowVector6[7] = { false, true, false, false, false, false, true };
	static bool RowVector7[7] = { true, false, false, true, false, false, false };

	CIterativeExactCoverSolver ExactCoverSolver;
	ExactCoverSolver.Initialize(NumOfRows_ProblemMatrix, NumOfColumns_ProblemMatrix);

	ExactCoverSolver.ProblemMatrix.Set_RowVector(RowVector1, 0);
	ExactCoverSolver.ProblemMatrix.Set_RowVector(RowVector2, 1);
	ExactCoverSolver.ProblemMatrix.Set_RowVector(RowVector3, 2);
	ExactCoverSolver.ProblemMatrix.Set_RowVector(RowVector4, 3);
	ExactCoverSolver.ProblemMatrix.Set_RowVector(RowVector5, 4);
	ExactCoverSolver.ProblemMatrix.Set_RowVector(RowVector6, 5);
	ExactCoverSolver.ProblemMatrix.Set_RowVector(RowVector7, 6);


	cout << endl;

	bool tempRowVector[7];

	for (int32_t i = 0; i < NumOfRows_ProblemMatrix; i++)
	{
		ExactCoverSolver.ProblemMatrix.Get_RowVector(tempRowVector, i);

		for (int32_t j = 0; j < NumOfColumns_ProblemMatrix; j++)
		{
			cout << static_cast<int32_t>(tempRowVector[j]) << " ";
		}

		cout << endl;
	}

	cout << endl;

	getchar();

	ExactCoverSolver.Prepare_Calculations2();
	//ExactCoverSolver.Prepare_Calculations();

	cout << endl;

	for (int32_t i = 0; i < NumOfRows_ProblemMatrix; i++)
	{
		int32_t numPosSolutionsPerConstraint = ExactCoverSolver.pSolutionsPerConstraintArray[i].NumOfSolutionsMax;

		cout << "num actual solutions per constraint: " << ExactCoverSolver.pSolutionsPerConstraintArray[i].ActualNumOfSolutions << endl;

		for (int32_t j = 0; j < numPosSolutionsPerConstraint; j++)
		{
			cout << ExactCoverSolver.pSolutionsPerConstraintArray[i].pSolutionIDArray[j] << " ";
		}

		cout << endl;
	}

	getchar();




	for (int32_t i = 0; i < 20; i++)
	{
		int32_t numOfNecessaryIterationSteps;

		if (ExactCoverSolver.Search_Solution2(100, &numOfNecessaryIterationSteps) == true)
		//if (ExactCoverSolver.Search_Solution(100, &numOfNecessaryIterationSteps) == true)
		{
			int32_t numberOfSolutionRowVectors = ExactCoverSolver.Get_Solution(IDArrayOfSolutionRowVectors);

			cout << "num iterations: " << numOfNecessaryIterationSteps << endl;

			for (int32_t i = 0; i < numberOfSolutionRowVectors; i++)
			{
				cout << IDArrayOfSolutionRowVectors[i] << " ";
			}

			cout << endl;
			getchar();
		}

		ExactCoverSolver.Prepare_For_ExactCoverSearchRestart();
		ExactCoverSolver.Permute_SolutionIDs_For_ExactCoverSearchRestart(&RandomNumbers);
	}

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	int32_t NumOfRows_ProblemMatrix = 5;
	int32_t NumOfColumns_ProblemMatrix = 5;

	static int32_t IDArrayOfSolutionRowVectors[5];

	static bool RowVector1[5] = { true, false, false, false, true };
	static bool RowVector2[5] = { false, true, false, true, false };
	static bool RowVector3[5] = { false, true, true, false, false };
	static bool RowVector4[5] = { false, false, true, false, false };
	static bool RowVector5[5] = { true, false, false, true, true };
	

	CIterativeExactCoverSolver ExactCoverSolver;
	ExactCoverSolver.Initialize(NumOfRows_ProblemMatrix, NumOfColumns_ProblemMatrix);

	ExactCoverSolver.ProblemMatrix.Set_RowVector(RowVector1, 0);
	ExactCoverSolver.ProblemMatrix.Set_RowVector(RowVector2, 1);
	ExactCoverSolver.ProblemMatrix.Set_RowVector(RowVector3, 2);
	ExactCoverSolver.ProblemMatrix.Set_RowVector(RowVector4, 3);
	ExactCoverSolver.ProblemMatrix.Set_RowVector(RowVector5, 4);
	


	cout << endl;

	bool tempRowVector[7];

	for (int32_t i = 0; i < NumOfRows_ProblemMatrix; i++)
	{
		ExactCoverSolver.ProblemMatrix.Get_RowVector(tempRowVector, i);

		for (int32_t j = 0; j < NumOfColumns_ProblemMatrix; j++)
		{
			cout << static_cast<int32_t>(tempRowVector[j]) << " ";
		}

		cout << endl;
	}

	cout << endl;

	getchar();

	//ExactCoverSolver.Prepare_Calculations2();
	ExactCoverSolver.Prepare_Calculations();

	cout << endl;

	for (int32_t i = 0; i < NumOfRows_ProblemMatrix; i++)
	{
		int32_t numPosSolutionsPerConstraint = ExactCoverSolver.pSolutionsPerConstraintArray[i].NumOfSolutionsMax;

		cout << "num actual solutions per constraint: " << ExactCoverSolver.pSolutionsPerConstraintArray[i].ActualNumOfSolutions << endl;

		for (int32_t j = 0; j < numPosSolutionsPerConstraint; j++)
		{
			cout << ExactCoverSolver.pSolutionsPerConstraintArray[i].pSolutionIDArray[j] << " ";
		}

		cout << endl;
	}

	getchar();




	for (int32_t i = 0; i < 20; i++)
	{
		int32_t numOfNecessaryIterationSteps;

		//if (ExactCoverSolver.Search_Solution2(100, &numOfNecessaryIterationSteps) == true)
			if (ExactCoverSolver.Search_Solution(100, &numOfNecessaryIterationSteps) == true)
		{
			int32_t numberOfSolutionRowVectors = ExactCoverSolver.Get_Solution(IDArrayOfSolutionRowVectors);

			cout << "num iterations: " << numOfNecessaryIterationSteps << endl;

			for (int32_t i = 0; i < numberOfSolutionRowVectors; i++)
			{
				cout << IDArrayOfSolutionRowVectors[i] << " ";
			}

			cout << endl;
			getchar();
		}

		ExactCoverSolver.Prepare_For_ExactCoverSearchRestart();
		ExactCoverSolver.Permute_SolutionIDs_For_ExactCoverSearchRestart(&RandomNumbers);
	}

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/


static constexpr int32_t NumSurfaceMapElementsPerDir = 7;
static constexpr int32_t NumSurfaceMapElements = 49;


static constexpr int32_t NumCities_TSP = 12;
static constexpr int32_t NumCities_TSP_Plus1 = NumCities_TSP + 1;


static constexpr int32_t NumWaypoints = 12;
static constexpr int32_t NumWaypointsMaxPerPath = 10;



static void Output_SurfaceMapData(char *pData)
{
	for (int32_t iy = 0; iy < NumSurfaceMapElementsPerDir; iy++)
	{
		int32_t iiy = iy * NumSurfaceMapElementsPerDir;

		for (int32_t ix = 0; ix < NumSurfaceMapElementsPerDir; ix++)
		{
			int32_t id = ix + iiy;
			cout << pData[id] << " ";
		}

		cout << endl;
	}

	cout << endl << endl;
}

static void Set_SurfaceMapData(char *pOutData, int32_t ix, int32_t iy, char sign)
{
	int32_t id = ix + iy * NumSurfaceMapElementsPerDir;
	pOutData[id] = sign;
}

static void Init_SurfaceMap(char *pOutData, char sign)
{
	uint32_t ix, iy, id;

	for (iy = 0; iy < NumSurfaceMapElementsPerDir; iy++)
	{
		for (ix = 0; ix < NumSurfaceMapElementsPerDir; ix++)
		{
			id = ix + iy * NumSurfaceMapElementsPerDir;
			pOutData[id] = sign;
		}
	}
}

static void Update_Fitnessvalues(CGraphNode *pGraphNodeArray, CGeneralPopulation *pPopulation)
{
	CSimpleIntegerValueGenome *pGenomeArray = static_cast<CSimpleIntegerValueGenome*>(pPopulation->ppGenomeArray[0]);

	int32_t populationSizePlusX = pPopulation->PopulationSizePlusX;
	int32_t numOfGenes = pGenomeArray[0].NumOfGenes;

	float distSq;

	for (int32_t i = 0; i < populationSizePlusX; i++)
	{
		distSq = pGraphNodeArray->Calculate_PathDistSq(pGenomeArray[i].pGeneArray, numOfGenes);
		pPopulation->Set_FitnessScore(i, 1.0f / distSq);
	}
}

static void Update_FitnessvaluesExt(CGraphNode *pGraphNodeArray, CWeightMatrix *pWeightMatrix, CGeneralPopulation *pPopulation)
{
	CSimpleIntegerValueGenome *pGenomeArray = static_cast<CSimpleIntegerValueGenome*>(pPopulation->ppGenomeArray[0]);

	int32_t populationSizePlusX = pPopulation->PopulationSizePlusX;
	int32_t numOfGenes = pGenomeArray[0].NumOfGenes;

	float distSq;

	for (int32_t i = 0; i < populationSizePlusX; i++)
	{
		distSq = pGraphNodeArray->Calculate_WeightedPathDistSq(pGenomeArray[i].pGeneArray, pWeightMatrix, numOfGenes);
		pPopulation->Set_FitnessScore(i, 1.0f / distSq);
	}
}

static void TSP_RecombinationFunction(void *pOffspring, void *pParent1, void *pParent2, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	CSimpleIntegerValueGenome *pOffspringGenome = static_cast<CSimpleIntegerValueGenome*>(pOffspring);
	CSimpleIntegerValueGenome *pParent1Genome = static_cast<CSimpleIntegerValueGenome*>(pParent1);
	CSimpleIntegerValueGenome *pParent2Genome = static_cast<CSimpleIntegerValueGenome*>(pParent2);

	static int32_t tempGeneArray[1000];

	int32_t numOfGenes = pOffspringGenome->NumOfGenes;
	int32_t numOfGenesMinus1 = numOfGenes - 1;

	int32_t *pInputGeneArray1 = pParent1Genome->pGeneArray;
	int32_t *pInputGeneArray2 = pParent2Genome->pGeneArray;
	int32_t *pOutputGeneArray = pOffspringGenome->pGeneArray;


	int32_t counter = 0;

	/* Route 1 von Individuum 1 mit Ausnahme des Zielpunkts zwischenspeichern: */
	for (int32_t i = 0; i < numOfGenesMinus1; i++)
	{
		tempGeneArray[counter] = pInputGeneArray1[i];
		counter++;
	}

	/* Route 2 von Individuum 2 mit Ausnahme des Startpunkts zwischenspeichern: */
	for (int32_t i = 1; i < numOfGenes; i++)
	{
		tempGeneArray[counter] = pInputGeneArray2[i];
		counter++;
	}


	counter--;

	for (int32_t i = 1; i < counter; i++)
	{
		/* entweder Wegpunkt von Route 1 deaktivieren (durch negatives Vorzeichen kennzeichnen): */
		if (pRandomNumbers->Get_IntegerNumber(1, 3) == 1)
		{
			for (int32_t j = 1; j < numOfGenesMinus1; j++)
			{
				if (tempGeneArray[j] == i)
				{
					tempGeneArray[j] = -i;
					break;
				}
			}
		}
		/* oder Wegpunkt von Route 2 deaktivieren (durch negatives Vorzeichen kennzeichnen): */
		else
		{
			for (int32_t j = numOfGenesMinus1; j < counter; j++)
			{
				if (tempGeneArray[j] == i)
				{
					tempGeneArray[j] = -i;
					break;
				}
			}
		}
	}

	/* Neue Route aus nicht deaktivierten Wegpunkten generieren: */

	pOutputGeneArray[0] = 0;
	pOutputGeneArray[numOfGenesMinus1] = 0;

	int32_t counter2 = 1;
	//counter--;
	for (int32_t i = 1; i < counter; i++)
	{
		/* pos. Vorzeichen => nicht deaktivierter Wegpunkt: */
		if (tempGeneArray[i] > 0)
		{
			pOutputGeneArray[counter2] = tempGeneArray[i];
			counter2++;
		}
	}
}


struct CPermutationInfo
{
	int32_t minGeneID;
	int32_t maxGeneID;
	int32_t permutationSteps;
};

static void TSP_PermutationFunction(void *pInOutGenome, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	CSimpleIntegerValueGenome *pGenome = static_cast<CSimpleIntegerValueGenome*>(pInOutGenome);
	CPermutationInfo *pPermutationInfo = static_cast<CPermutationInfo*>(pParam);

	int32_t minGeneID = pPermutationInfo->minGeneID;
	int32_t maxGeneID = pPermutationInfo->maxGeneID;
	int32_t permutationSteps = pPermutationInfo->permutationSteps;

	pGenome->Permute_GeneData(pRandomNumbers, minGeneID, maxGeneID, permutationSteps);
}



static void Pathfinding_MutationFunction(void *pInOutGenome, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	CSimpleIntegerValueGenome *pGenome = static_cast<CSimpleIntegerValueGenome*>(pInOutGenome);

	int32_t numOfGenes = pGenome->NumOfGenes;

	int32_t iDofMutatedPathElement = pRandomNumbers->Get_IntegerNumber(1, numOfGenes - 1);

	int32_t *pGeneArray = pGenome->pGeneArray;

	int32_t startID = pGeneArray[0];
	int32_t destinationID = pGeneArray[numOfGenes - 1];

	do
	{
		int32_t waypontID = pRandomNumbers->Get_IntegerNumber(0, numOfGenes);

		if (waypontID == startID)
			continue;
		if (waypontID == destinationID)
			continue;
		if (waypontID == pGeneArray[iDofMutatedPathElement])
			continue;

		pGeneArray[iDofMutatedPathElement] = waypontID;
		break;

	} while (true);
}

static void Pathfinding_RecombinationFunction(void *pOffspring, void *pParent1, void *pParent2, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	CSimpleIntegerValueGenome *pOffspringGenome = static_cast<CSimpleIntegerValueGenome*>(pOffspring);
	CSimpleIntegerValueGenome *pParent1Genome = static_cast<CSimpleIntegerValueGenome*>(pParent1);
	CSimpleIntegerValueGenome *pParent2Genome = static_cast<CSimpleIntegerValueGenome*>(pParent2);


	int32_t *pGeneArray_Parent1 = pParent1Genome->pGeneArray;
	int32_t *pGeneArray_Parent2 = pParent2Genome->pGeneArray;
	int32_t *pGeneArray_Offspring = pOffspringGenome->pGeneArray;

	int32_t numOfGenes = pOffspringGenome->NumOfGenes;
	int32_t numOfGenesMinus1 = numOfGenes - 1;

	for (int32_t i = 0; i < numOfGenes; i++)
		pGeneArray_Offspring[i] = pGeneArray_Parent1[i];

	for (int32_t i = 1; i < numOfGenesMinus1; i++)
	{
		if (pRandomNumbers->Get_IntegerNumber2(1, 2) == 2)
			pGeneArray_Offspring[i] = pGeneArray_Parent2[i];
	}
}

static void Get_Path(int32_t *pOutPath, int32_t *pOutNumWaypoints, CSimpleIntegerValueGenome *pGenome)
{
	int32_t counter = 0;

	int32_t *pGeneArray = pGenome->pGeneArray;

	int32_t numOfGenesMinus1 = pGenome->NumOfGenes - 1;

	int32_t id1, id2;

	for (int32_t i = 0; i < numOfGenesMinus1; i++)
	{
		id1 = pGeneArray[i];
		id2 = pGeneArray[i + 1];

		if (id1 != id2)
		{
			pOutPath[counter] = id1;
			counter++;
		}
	}

	pOutPath[counter] = pGeneArray[numOfGenesMinus1];
	counter++;

	*pOutNumWaypoints = counter;
}

static void Get_Best_Path(int32_t *pOutPath, int32_t *pOutNumWaypoints, CGeneralPopulation *pPopulation)
{
	CSimpleIntegerValueGenome *pBestGenome = static_cast<CSimpleIntegerValueGenome*>(pPopulation->ppGenomeArray[pPopulation->IDArrayOfBestFittedGenomes[0]]);
	int32_t numOfGenes = pBestGenome->NumOfGenes;
	int32_t numOfGenesMinus1 = numOfGenes - 1;

	int32_t counter = 0;

	int32_t *pGeneArray = pBestGenome->pGeneArray;

	int32_t id1, id2;

	for (int32_t i = 0; i < numOfGenesMinus1; i++)
	{
		id1 = pGeneArray[i];
		id2 = pGeneArray[i + 1];

		if (id1 != id2)
		{
			pOutPath[counter] = id1;
			counter++;
		}
	}

	pOutPath[counter] = pGeneArray[numOfGenesMinus1];
	counter++;

	*pOutNumWaypoints = counter;
}


static void Get_Path(int32_t *pOutPath, CSimpleIntegerValueGenome *pGenome)
{
	int32_t numOfGenes = pGenome->NumOfGenes;

	for (int32_t i = 0; i < numOfGenes; i++)
		pOutPath[i] = pGenome->pGeneArray[i];
}

static void Get_Shortest_TSP_Path(int32_t *pOutPath, CGeneralPopulation *pPopulation)
{
	CSimpleIntegerValueGenome *pBestGenome = static_cast<CSimpleIntegerValueGenome*>(pPopulation->ppGenomeArray[pPopulation->IDArrayOfBestFittedGenomes[0]]);
	int32_t numOfGenes = pBestGenome->NumOfGenes;

	for (int32_t i = 0; i < numOfGenes; i++)
		pOutPath[i] = pBestGenome->pGeneArray[i];
}




/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	int32_t TrainingPopulationSize = 100;
	int32_t NumTrainingGenerationsMax = 20000;

	// Visualisierung der einzelnen St�dte:

	static char SurfaceMap[NumSurfaceMapElements];

	Init_SurfaceMap(SurfaceMap, '*');

	Set_SurfaceMapData(SurfaceMap, 2, 0, '0');
	Set_SurfaceMapData(SurfaceMap, 4, 0, '1');
	Set_SurfaceMapData(SurfaceMap, 0, 1, '2');
	Set_SurfaceMapData(SurfaceMap, 4, 2, '3');
	Set_SurfaceMapData(SurfaceMap, 0, 4, '4');
	Set_SurfaceMapData(SurfaceMap, 2, 3, '5');
	Set_SurfaceMapData(SurfaceMap, 3, 4, '6');
	Set_SurfaceMapData(SurfaceMap, 5, 5, '7');
	Set_SurfaceMapData(SurfaceMap, 6, 3, '8');
	Set_SurfaceMapData(SurfaceMap, 1, 6, '9');
	Set_SurfaceMapData(SurfaceMap, 6, 1, 'A');
	Set_SurfaceMapData(SurfaceMap, 3, 6, 'B');


	Output_SurfaceMapData(SurfaceMap);

	// Visualisierung der einzelnen St�dte abgeschlossen

	static CGraphNode GraphNodeArray[NumCities_TSP_Plus1];

	GraphNodeArray[0].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[0].Set_Position(2.0f, 0.0f, 0.0f);
	GraphNodeArray[1].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[1].Set_Position(4.0f, 0.0f, 0.0f);
	GraphNodeArray[2].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[2].Set_Position(0.0f, 1.0f, 0.0f);
	GraphNodeArray[3].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[3].Set_Position(4.0f, 2.0f, 0.0f);
	GraphNodeArray[4].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[4].Set_Position(0.0f, 4.0f, 0.0f);
	GraphNodeArray[5].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[5].Set_Position(2.0f, 3.0f, 0.0f);
	GraphNodeArray[6].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[6].Set_Position(3.0f, 4.0f, 0.0f);
	GraphNodeArray[7].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[7].Set_Position(5.0f, 5.0f, 0.0f);
	GraphNodeArray[8].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[8].Set_Position(6.0f, 3.0f, 0.0f);
	GraphNodeArray[9].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[9].Set_Position(1.0f, 6.0f, 0.0f);
	GraphNodeArray[10].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[10].Set_Position(6.0f, 1.0f, 0.0f);
	GraphNodeArray[11].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[11].Set_Position(3.0f, 6.0f, 0.0f);
	GraphNodeArray[12].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[12].Set_Position(2.0f, 0.0f, 0.0f);

	CSimpleIntegerValueGenome *pGenomeArray = new (std::nothrow) CSimpleIntegerValueGenome[TrainingPopulationSize];

	CGeneralPopulation Population;
	Population.Set_GenomeValueCloningFunction(CSimpleIntegerValueGenome_CloningFunction);

	

	Population.Initialize(TrainingPopulationSize);

	for (int32_t i = 0; i < TrainingPopulationSize; i++)
	{
		pGenomeArray[i].Initialize(NumCities_TSP_Plus1);
		Population.Set_Genome(&pGenomeArray[i], i);
	}

	Population.Reset_Population();

	static int32_t InitialPath[NumCities_TSP_Plus1];

	for (int32_t i = 0; i < NumCities_TSP; i++)
		InitialPath[i] = i;

	// Ziel der Rundreise:
	InitialPath[NumCities_TSP] = 0;

	for (int32_t i = 0; i < NumCities_TSP_Plus1; i++)
	{
		cout << InitialPath[i] << " ";
	}

	cout << endl;

	for (int32_t i = 0; i < TrainingPopulationSize; i++)
	{
		pGenomeArray[i].Set_GeneData(InitialPath);
		pGenomeArray[i].Permute_GeneData(&RandomNumbers, 1, NumCities_TSP_Plus1 - 2, 3);
	}

	CPermutationInfo PermutationInfo;
	PermutationInfo.minGeneID = 1;
	PermutationInfo.maxGeneID = NumCities_TSP_Plus1 - 2;
	PermutationInfo.permutationSteps = 1;

	for (int32_t i = 0; i < NumTrainingGenerationsMax; i++)
	{
		Update_Fitnessvalues(GraphNodeArray, &Population);

		Population.Update_Population();

		Population.Update_BaseEvolution2(TSP_PermutationFunction, &PermutationInfo);
		Population.Update_Evolution_BestGenomeOnly2(TSP_PermutationFunction, &PermutationInfo);
		Population.Update_Evolution_SecondBestGenomeOnly2(TSP_PermutationFunction, &PermutationInfo);
		Population.Update_Evolution_Combine_BestTwoGenomes(TSP_RecombinationFunction, nullptr);
		Population.Update_Evolution_Combine_TwoGenomes(TSP_RecombinationFunction, nullptr);
		Population.Update_Evolution_Combine_TwoGenomes(TSP_RecombinationFunction, nullptr);
	}

	static int32_t ShortestPath[NumCities_TSP_Plus1];

	Get_Shortest_TSP_Path(ShortestPath, &Population);

	float minPathDistSq = GraphNodeArray[0].Calculate_PathDistSq(ShortestPath, NumCities_TSP_Plus1);

	cout << endl << "minPathDistSq: " << minPathDistSq << endl;

	static int32_t RearrangedPath[NumCities_TSP_Plus1];

	Rearrange_TSP_Path(RearrangedPath, ShortestPath, NumCities_TSP_Plus1, 3);

	for (int32_t i = 0; i < NumCities_TSP_Plus1; i++)
	{
		cout << ShortestPath[i] << " ";
	}

	cout << endl;

	for (int32_t i = 0; i < NumCities_TSP_Plus1; i++)
	{
		cout << RearrangedPath[i] << " ";
	}

	cout << endl;


	delete[] pGenomeArray;
	pGenomeArray = nullptr;

	cout << "bye bye (Press Return)" << endl;
	getchar();
	

	return 0;
}
*/

/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	int32_t TrainingPopulationSize = 100;
	int32_t NumTrainingGenerationsMax = 5000;

	// Visualisierung der einzelnen St�dte:

	static char SurfaceMap[NumSurfaceMapElements];

	Init_SurfaceMap(SurfaceMap, '*');

	Set_SurfaceMapData(SurfaceMap, 2, 0, '0');
	Set_SurfaceMapData(SurfaceMap, 4, 0, '1');
	Set_SurfaceMapData(SurfaceMap, 0, 1, '2');
	Set_SurfaceMapData(SurfaceMap, 4, 2, '3');
	Set_SurfaceMapData(SurfaceMap, 0, 4, '4');
	Set_SurfaceMapData(SurfaceMap, 2, 3, '5');
	Set_SurfaceMapData(SurfaceMap, 3, 4, '6');
	Set_SurfaceMapData(SurfaceMap, 5, 5, '7');
	Set_SurfaceMapData(SurfaceMap, 6, 3, '8');
	Set_SurfaceMapData(SurfaceMap, 1, 6, '9');
	Set_SurfaceMapData(SurfaceMap, 6, 1, 'A');
	Set_SurfaceMapData(SurfaceMap, 3, 6, 'B');


	Output_SurfaceMapData(SurfaceMap);

	// Visualisierung der einzelnen St�dte abgeschlossen

	static CGraphNode GraphNodeArray[NumWaypoints];

	GraphNodeArray[0].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[0].Set_Position(2.0f, 0.0f, 0.0f);
	GraphNodeArray[1].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[1].Set_Position(4.0f, 0.0f, 0.0f);
	GraphNodeArray[2].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[2].Set_Position(0.0f, 1.0f, 0.0f);
	GraphNodeArray[3].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[3].Set_Position(4.0f, 2.0f, 0.0f);
	GraphNodeArray[4].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[4].Set_Position(0.0f, 4.0f, 0.0f);
	GraphNodeArray[5].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[5].Set_Position(2.0f, 3.0f, 0.0f);
	GraphNodeArray[6].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[6].Set_Position(3.0f, 4.0f, 0.0f);
	GraphNodeArray[7].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[7].Set_Position(5.0f, 5.0f, 0.0f);
	GraphNodeArray[8].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[8].Set_Position(6.0f, 3.0f, 0.0f);
	GraphNodeArray[9].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[9].Set_Position(1.0f, 6.0f, 0.0f);
	GraphNodeArray[10].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[10].Set_Position(6.0f, 1.0f, 0.0f);
	GraphNodeArray[11].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[11].Set_Position(3.0f, 6.0f, 0.0f);

	int32_t StartID = 1;
	int32_t DestinationID = 11;



	CWeightMatrix WeightMatrix;
	WeightMatrix.Init_Matrix(NumWaypoints, NumWaypoints, 1.0f);

	WeightMatrix.Set_Weight(StartID, DestinationID, 1000.0f);
	WeightMatrix.Set_Weight(DestinationID, StartID, 1000.0f);

	WeightMatrix.Set_Weight(0, 5, 1000.0f);
	WeightMatrix.Set_Weight(5, 0, 1000.0f);

	WeightMatrix.Set_Weight(0, 1, 1000.0f);
	WeightMatrix.Set_Weight(1, 0, 1000.0f);


	CSimpleIntegerValueGenome *pGenomeArray = new (std::nothrow) CSimpleIntegerValueGenome[TrainingPopulationSize];

	CGeneralPopulation Population;
	Population.Set_GenomeValueCloningFunction(CSimpleIntegerValueGenome_CloningFunction);

	Population.Initialize(TrainingPopulationSize);

	for (int32_t i = 0; i < TrainingPopulationSize; i++)
	{
		pGenomeArray[i].Initialize(NumWaypointsMaxPerPath);
		Population.Set_Genome(&pGenomeArray[i], i);
	}

	Population.Reset_Population();

	static int32_t InitialPath[NumWaypointsMaxPerPath];

	for (int32_t i = 0; i < NumWaypointsMaxPerPath; i++)
	{
		InitialPath[i] = StartID;
	}

	InitialPath[NumWaypointsMaxPerPath - 1] = DestinationID;


	for (int32_t i = 0; i < NumWaypointsMaxPerPath; i++)
	{
		cout << InitialPath[i] << " ";
	}

	cout << endl;

	for (int32_t i = 0; i < TrainingPopulationSize; i++)
	{
		pGenomeArray[i].Set_GeneData(InitialPath);
		Pathfinding_MutationFunction(&pGenomeArray[i], &RandomNumbers, nullptr);
	}

	for (int32_t i = 0; i < NumTrainingGenerationsMax; i++)
	{
		Update_FitnessvaluesExt(GraphNodeArray, &WeightMatrix, &Population);

		Population.Update_Population();

		Population.Update_BaseEvolution(Pathfinding_MutationFunction, nullptr);
		Population.Update_Evolution_BestGenomeOnly(Pathfinding_MutationFunction, nullptr);
		Population.Update_Evolution_SecondBestGenomeOnly(Pathfinding_MutationFunction, nullptr);
		Population.Update_Evolution_Combine_BestTwoGenomes(Pathfinding_RecombinationFunction, nullptr);
		Population.Update_Evolution_Combine_TwoGenomes(Pathfinding_RecombinationFunction, nullptr);
	}

	static int32_t BestPath[NumWaypointsMaxPerPath];
	int32_t NumWaypoints;

	Get_Best_Path(BestPath, &NumWaypoints, &Population);

	float minPathDistSq = GraphNodeArray[0].Calculate_PathDistSq(BestPath, NumWaypoints);

	cout << endl << "minPathDistSq: " << minPathDistSq << endl;

	for (int32_t i = 0; i < NumWaypoints; i++)
	{
		cout << BestPath[i] << " ";
	}

	cout << endl;

	

	delete[] pGenomeArray;
	pGenomeArray = nullptr;

	cout << "bye bye (Press Return)" << endl;
	getchar();
	
	return 0;
}
*/


/*
int main(void)
{
	static constexpr int32_t ImageSizeX = 32;
	static constexpr int32_t ImageSizeY = 32;
	static constexpr int32_t ImageSizeXY = ImageSizeX *  ImageSizeY;

	static constexpr int32_t ReducedImageSizeX = 16;
	static constexpr int32_t ReducedImageSizeY = 16;
	static constexpr int32_t ReducedImageSizeXY = ReducedImageSizeX *  ReducedImageSizeY;

	static float ReducedImage[ReducedImageSizeXY];
	static float ReducedImage_Inverted[ReducedImageSizeXY];

	for (int32_t i = 0; i < ReducedImageSizeXY; i++)
	{
		ReducedImage[i] = 0.0f;
		ReducedImage_Inverted[i] = 0.0f;
	}

	static float TestImage1[ImageSizeXY];

	uint8_t *pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("TestSample.bmp");

	Get_BinaryImageData_BlueChannel(TestImage1, pImageData, ImageSizeX, ImageSizeY);

	delete[] pImageData;
	pImageData = nullptr;

	//Generate_LowResImageCopy(ReducedImage, ReducedImageSizeX, ReducedImageSizeY, TestImage1, ImageSizeX, ImageSizeY, 1.0f);
	Generate_LowResImageCopy(ReducedImage, ReducedImageSizeX, ReducedImageSizeY, TestImage1, ImageSizeX, ImageSizeY, 3.0f);
	Generate_InvertedLowResImageCopy(ReducedImage_Inverted, ReducedImageSizeX, ReducedImageSizeY, TestImage1, ImageSizeX, ImageSizeY, 3.0f);

	//Generate_LowResImageCopy(ReducedImage, ReducedImageSizeX, ReducedImageSizeY, TestImage1, ImageSizeX, ImageSizeY);
	//Generate_InvertedLowResImageCopy(ReducedImage_Inverted, ReducedImageSizeX, ReducedImageSizeY, TestImage1, ImageSizeX, ImageSizeY);
	

	


	for (int32_t iy = 0; iy < ReducedImageSizeY; iy++)
	{
		int32_t iiy = iy * ReducedImageSizeX;

		for (int32_t ix = 0; ix < ReducedImageSizeX; ix++)
		{
			int32_t id = ix + iiy;

			cout << ReducedImage[id];
		}

		cout << endl;
	}

	cout << endl;

	

	for (int32_t iy = 0; iy < ReducedImageSizeY; iy++)
	{
		int32_t iiy = iy * ReducedImageSizeX;

		for (int32_t ix = 0; ix < ReducedImageSizeX; ix++)
		{
			int32_t id = ix + iiy;

			cout << ReducedImage_Inverted[id];
		}

		cout << endl;
	}

	cout << endl;

	
	cout << "bye bye (Press Return)" << endl;
	getchar();

	return 0;
}
*/






