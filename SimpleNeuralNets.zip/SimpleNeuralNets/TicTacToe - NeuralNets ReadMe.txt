Zwei Ansätze:

1) Neuronales Netz, das selbstständig spielt.
Bei einem unzulässigen Zug wird ein alternativer Zufallszug generiert.

2) Neuronales Netz, das alle möglichen Züge begutachtet (evaluiert),
damit sich die KI für den besten Zug entscheiden kann.




