#include "NeuralCalculationNet.h"

using namespace std;
using namespace HelperStuff;


CNeuralCalculationFunctions::CNeuralCalculationFunctions()
{}

CNeuralCalculationFunctions::~CNeuralCalculationFunctions()
{
	delete[] pFunctionArray;
	pFunctionArray = nullptr;
}

void CNeuralCalculationFunctions::Initialize(int32_t numOfFunctions)
{
	delete[] pFunctionArray;
	pFunctionArray = nullptr;

	NumOfFunctions = numOfFunctions;

	pFunctionArray = new (std::nothrow) pNeuralCalculationFunction[NumOfFunctions];

	for (int32_t i = 0; i < NumOfFunctions; i++)
	{
		pFunctionArray[i] = nullptr;
	}
}

void CNeuralCalculationFunctions::Set_Function(int32_t id, pNeuralCalculationFunction pFunc)
{
	pFunctionArray[id] = pFunc;
}

CNeuralCalculationUnit::CNeuralCalculationUnit()
{
	for (int32_t i = 0; i < NumOfAdditionalCalcValues; i++)
	{
		AdditionalCalcValueArray[i] = 0.25f;
	}
}

CNeuralCalculationUnit::~CNeuralCalculationUnit()
{}

void CNeuralCalculationUnit::Calculate_OutputValue(void)
{
	pCalculationFunction(this);
}

void CNeuralCalculationUnit::Reset_CalculationValues(void)
{
	SumOfInputValues = 0.0f;
	OutputValue = 0.0f;
}

void CNeuralCalculationUnit::Set_ErrorFactors(float errorFactor1, float errorFactor2)
{
	ErrorFactor1 = errorFactor1;
	ErrorFactor2 = errorFactor2;
}

void CNeuralCalculationUnit::Set_LearningRate(float learningRate)
{
	LearningRate = learningRate;
}

void CNeuralCalculationUnit::Set_AdditionalCalculationValue(float value, int32_t valueID)
{
	AdditionalCalcValueArray[valueID] = value;
}

void CNeuralCalculationUnit::Set_CalculationFunction(int32_t functionID, pNeuralCalculationFunction pFunc)
{
	FunctionID = functionID;
	pCalculationFunction = pFunc;
}

void CNeuralCalculationUnit::Set_CalculationFunction(int32_t functionID, CNeuralCalculationFunctions *pFunctions)
{
	FunctionID = functionID;
	pCalculationFunction = pFunctions->pFunctionArray[functionID];
}

void CNeuralCalculationUnit::Clone_Data(CNeuralCalculationUnit *pOriginalObject)
{
	UsageStatus = pOriginalObject->UsageStatus;
	FunctionID = pOriginalObject->FunctionID;
	SumOfInputValues = pOriginalObject->SumOfInputValues;
	OutputValue = pOriginalObject->OutputValue;
	ErrorValue = pOriginalObject->ErrorValue;
	ErrorSumOfSubsequentUnits = pOriginalObject->ErrorSumOfSubsequentUnits;
	pCalculationFunction = pOriginalObject->pCalculationFunction;
	ErrorFactor1 = pOriginalObject->ErrorFactor1;
	ErrorFactor2 = pOriginalObject->ErrorFactor2;
	LearningRate = pOriginalObject->LearningRate;
}

float CNeuralCalculationUnit::Calculate_Variance(float desiredOutput)
{
	// Abweichung:
	float variance = desiredOutput - OutputValue;
	return variance * variance;
}



float CNeuralCalculationUnit::Calculate_Variance_And_Error(float desiredOutput, float errorFactor1, float errorFactor2)
{
	// Abweichung:
	float variance = desiredOutput - OutputValue;
	ErrorValue = variance * errorFactor1 * exp(-(errorFactor2 * OutputValue * OutputValue));

	/* Hinweis: Wenn bereits eine geringe Neuronenaktivit�t (OutputValue)
	zu einer gro�en Abweichung f�hrt, ist auch der Fehler gro�. Abweichungen
	bei einer starken Neuronenaktivit�t f�hren hingegen zu einem kleineren
	Fehler. */

	return variance * variance;
}

float CNeuralCalculationUnit::Calculate_Variance_And_Error(float desiredOutput)
{
	// Abweichung:
	float variance = desiredOutput - OutputValue;
	ErrorValue = variance * ErrorFactor1 * exp(-(ErrorFactor2 * OutputValue * OutputValue));

	/* Hinweis: Wenn bereits eine geringe Neuronenaktivit�t (OutputValue)
	zu einer gro�en Abweichung f�hrt, ist auch der Fehler gro�. Abweichungen
	bei einer starken Neuronenaktivit�t f�hren hingegen zu einem kleineren
	Fehler. */

	return variance*variance;
}

void CNeuralCalculationUnit::Calculate_Error(void)
{
	ErrorValue = ErrorSumOfSubsequentUnits * ErrorFactor1 * exp(-(ErrorFactor2 * OutputValue * OutputValue));

	/* Hinweis: Wenn bereits eine geringe Neuronenaktivit�t (OutputValue)
	zu einer gro�en Abweichung f�hrt, ist auch der Fehler gro�. Abweichungen
	bei einer starken Neuronenaktivit�t f�hren hingegen zu einem kleineren
	Fehler. */
}
void CNeuralCalculationUnit::Calculate_Error(float errorFactor1, float errorFactor2)
{
	ErrorValue = ErrorSumOfSubsequentUnits * errorFactor1 * exp(-(errorFactor2 * OutputValue * OutputValue));

	/* Hinweis: Wenn bereits eine geringe Neuronenaktivit�t (OutputValue)
	zu einer gro�en Abweichung f�hrt, ist auch der Fehler gro�. Abweichungen
	bei einer starken Neuronenaktivit�t f�hren hingegen zu einem kleineren
	Fehler. */
}


CNeuralConnection::CNeuralConnection()
{}

CNeuralConnection::~CNeuralConnection()
{}

void CNeuralConnection::Transform_TransmissionValue(void)
{
	if (RBFConstant == 0.0f)
	{
		TransmissionValue *= PlasticityValue;
		return;
	}

	float tempFloat = PlasticityValue * TransmissionValue - CentroidValue;
	tempFloat *= tempFloat;

	TransmissionValue = RBFConstant * tempFloat;
}

void CNeuralConnection::Clone_Data(CNeuralConnection *pOriginalObject)
{
	PlasticityValue = pOriginalObject->PlasticityValue;
	CentroidValue = pOriginalObject->CentroidValue;
	RBFConstant = pOriginalObject->RBFConstant;

	TransmissionValue = pOriginalObject->TransmissionValue;
}


CNeuralCalculationNetDesc::CNeuralCalculationNetDesc()
{}

CNeuralCalculationNetDesc::~CNeuralCalculationNetDesc()
{
	delete[] pCalculationFunctionIDArray;
	pCalculationFunctionIDArray = nullptr;

	delete[] pCalculationUnitUsageStatusArray;
	pCalculationUnitUsageStatusArray = nullptr;

	delete[] pConnectionStatusArray;
	pConnectionStatusArray = nullptr;

	delete[] pPlasticityValueArray;
	pPlasticityValueArray = nullptr;

	delete[] pCentroidValueArray;
	pCentroidValueArray = nullptr;

	delete[] pRBFConstantArray;
	pRBFConstantArray = nullptr;
}

void CNeuralCalculationNetDesc::Clone(CNeuralCalculationNetDesc *pOriginalObject)
{
	delete[] pCalculationFunctionIDArray;
	pCalculationFunctionIDArray = nullptr;

	delete[] pCalculationUnitUsageStatusArray;
	pCalculationUnitUsageStatusArray = nullptr;

	delete[] pConnectionStatusArray;
	pConnectionStatusArray = nullptr;

	delete[] pPlasticityValueArray;
	pPlasticityValueArray = nullptr;

	delete[] pCentroidValueArray;
	pCentroidValueArray = nullptr;

	delete[] pRBFConstantArray;
	pRBFConstantArray = nullptr;

	FitnessScore = pOriginalObject->FitnessScore;

	NumOfCalculationUnits = pOriginalObject->NumOfCalculationUnits;
	NumOfNeuralConnections = pOriginalObject->NumOfNeuralConnections;

	pCalculationFunctionIDArray = new (std::nothrow) int32_t[NumOfCalculationUnits];
	pCalculationUnitUsageStatusArray = new (std::nothrow) int32_t[NumOfCalculationUnits];

	for (int32_t i = 0; i < NumOfCalculationUnits; i++)
	{
		pCalculationFunctionIDArray[i] = pOriginalObject->pCalculationFunctionIDArray[i];
		pCalculationUnitUsageStatusArray[i] = pOriginalObject->pCalculationUnitUsageStatusArray[i];
	}

	pConnectionStatusArray = new (std::nothrow) int32_t[NumOfNeuralConnections];
	pPlasticityValueArray = new (std::nothrow) float[NumOfNeuralConnections];
	pCentroidValueArray = new (std::nothrow) float[NumOfNeuralConnections];
	pRBFConstantArray = new (std::nothrow) float[NumOfNeuralConnections];

	for (int32_t i = 0; i < NumOfNeuralConnections; i++)
	{
		pConnectionStatusArray[i] = pOriginalObject->pConnectionStatusArray[i];
		pPlasticityValueArray[i] = pOriginalObject->pPlasticityValueArray[i];
		pCentroidValueArray[i] = pOriginalObject->pCentroidValueArray[i];
		pRBFConstantArray[i] = pOriginalObject->pRBFConstantArray[i];
	}
}

void CNeuralCalculationNetDesc::Clone_Values(CNeuralCalculationNetDesc *pOriginalObject)
{
	//NumOfCalculationUnits = pOriginalObject->NumOfCalculationUnits;
	//NumOfNeuralConnections = pOriginalObject->NumOfNeuralConnections;

	FitnessScore = pOriginalObject->FitnessScore;

	for (int32_t i = 0; i < NumOfCalculationUnits; i++)
	{
		pCalculationFunctionIDArray[i] = pOriginalObject->pCalculationFunctionIDArray[i];
		pCalculationUnitUsageStatusArray[i] = pOriginalObject->pCalculationUnitUsageStatusArray[i];
	}

	for (int32_t i = 0; i < NumOfNeuralConnections; i++)
	{
		pConnectionStatusArray[i] = pOriginalObject->pConnectionStatusArray[i];
		pPlasticityValueArray[i] = pOriginalObject->pPlasticityValueArray[i];
		pCentroidValueArray[i] = pOriginalObject->pCentroidValueArray[i];
		pRBFConstantArray[i] = pOriginalObject->pRBFConstantArray[i];
	}
}

void CNeuralCalculationNetDesc::Initialize(int32_t numOfCalculationUnits)
{
	NumOfCalculationUnits = numOfCalculationUnits;
	NumOfNeuralConnections = numOfCalculationUnits * numOfCalculationUnits;

	delete[] pCalculationFunctionIDArray;
	pCalculationFunctionIDArray = nullptr;

	delete[] pCalculationUnitUsageStatusArray;
	pCalculationUnitUsageStatusArray = nullptr;

	delete[] pConnectionStatusArray;
	pConnectionStatusArray = nullptr;

	delete[] pPlasticityValueArray;
	pPlasticityValueArray = nullptr;

	delete[] pCentroidValueArray;
	pCentroidValueArray = nullptr;

	delete[] pRBFConstantArray;
	pRBFConstantArray = nullptr;

	pCalculationFunctionIDArray = new (std::nothrow) int32_t[NumOfCalculationUnits];
	pCalculationUnitUsageStatusArray = new (std::nothrow) int32_t[NumOfCalculationUnits];

	for (int32_t i = 0; i < NumOfCalculationUnits; i++)
	{
		pCalculationFunctionIDArray[i] = 0;
		pCalculationUnitUsageStatusArray[i] = UsageStatus_CalculationUnit_Standard;
	}

	pConnectionStatusArray = new (std::nothrow) int32_t[NumOfNeuralConnections];
	pPlasticityValueArray = new (std::nothrow) float[NumOfNeuralConnections];
	pCentroidValueArray = new (std::nothrow) float[NumOfNeuralConnections];
	pRBFConstantArray = new (std::nothrow) float[NumOfNeuralConnections];

	for (int32_t i = 0; i < NumOfNeuralConnections; i++)
	{
		pConnectionStatusArray[i] = 0;
		pPlasticityValueArray[i] = 0.0f;
		pCentroidValueArray[i] = 0.0f;
		pRBFConstantArray[i] = 0.0f;
	}
}



bool CNeuralCalculationNetDesc::Load_Data(const char* pFilename, bool memoryAllocation)
{
	std::ifstream ReadFile;

	// eine existierende Datei zum Lesen �ffnen:
	ReadFile.open(pFilename);

	if (ReadFile.good() == false)
		return false;

	ReadFile >> NumOfCalculationUnits;

	NumOfNeuralConnections = NumOfCalculationUnits * NumOfCalculationUnits;

	if (memoryAllocation == true)
	{
		delete[] pCalculationFunctionIDArray;
		pCalculationFunctionIDArray = nullptr;

		delete[] pCalculationUnitUsageStatusArray;
		pCalculationUnitUsageStatusArray = nullptr;

		delete[] pConnectionStatusArray;
		pConnectionStatusArray = nullptr;

		delete[] pPlasticityValueArray;
		pPlasticityValueArray = nullptr;

		delete[] pCentroidValueArray;
		pCentroidValueArray = nullptr;

		delete[] pRBFConstantArray;
		pRBFConstantArray = nullptr;

		pCalculationFunctionIDArray = new (std::nothrow) int32_t[NumOfCalculationUnits];
		pCalculationUnitUsageStatusArray = new (std::nothrow) int32_t[NumOfCalculationUnits];

		pConnectionStatusArray = new (std::nothrow) int32_t[NumOfNeuralConnections];
		pPlasticityValueArray = new (std::nothrow) float[NumOfNeuralConnections];
		pCentroidValueArray = new (std::nothrow) float[NumOfNeuralConnections];
		pRBFConstantArray = new (std::nothrow) float[NumOfNeuralConnections];
	}

	for (int32_t i = 0; i < NumOfCalculationUnits; i++)
	{
		ReadFile >> pCalculationFunctionIDArray[i];
		ReadFile >> pCalculationUnitUsageStatusArray[i];
	}

	for (int32_t i = 0; i < NumOfNeuralConnections; i++)
	{
		ReadFile >> pConnectionStatusArray[i];
		ReadFile >> pPlasticityValueArray[i];
		ReadFile >> pCentroidValueArray[i];
		ReadFile >> pRBFConstantArray[i];
	}

	ReadFile.close();

	return true;
}

bool CNeuralCalculationNetDesc::Save_Data(const char* pFilename)
{
	std::ofstream WriteFile;

	// neue Datei erzeugen bzw. alte �berschreiben:
	WriteFile.open(pFilename);

	// neue Datei erzeugen bzw. Inhalt ans Ende einer bestehenden Datei schreiben: 
	//WriteFile.open(pFilename, ios::app);

	if (WriteFile.good() == false)
		return false;

	WriteFile << NumOfCalculationUnits << "  ";

	for (int32_t i = 0; i < NumOfCalculationUnits; i++)
	{
		WriteFile << pCalculationFunctionIDArray[i] << "  ";
		WriteFile << pCalculationUnitUsageStatusArray[i] << "  ";
	}

	for (int32_t i = 0; i < NumOfNeuralConnections; i++)
	{
		WriteFile << pConnectionStatusArray[i] << "  ";
		WriteFile << pPlasticityValueArray[i] << "  ";
		WriteFile << pCentroidValueArray[i] << "  ";
		WriteFile << pRBFConstantArray[i] << "  ";
	}


	WriteFile.close();

	return true;
}


CNeuralCalculationNet::CNeuralCalculationNet()
{}

CNeuralCalculationNet::~CNeuralCalculationNet()
{
	delete[] pCalculationUnitArray;
	pCalculationUnitArray = nullptr;

	delete[] pConnectionArray;
	pConnectionArray = nullptr;

	delete[] ppConnectionNet;
	ppConnectionNet = nullptr;

	delete[] pInputUnitIDArray;
	pInputUnitIDArray = nullptr;

	delete[] pOutputUnitIDArray;
	pOutputUnitIDArray = nullptr;
}

void CNeuralCalculationNet::Activate_Connection(int32_t connectionID)
{
	ppConnectionNet[connectionID] = &pConnectionArray[connectionID];
}

void CNeuralCalculationNet::Activate_Connection(int32_t ix, int32_t iy)
{
	int32_t id = ix + iy * NumOfCalculationUnits;
	ppConnectionNet[id] = &pConnectionArray[id];
}

void CNeuralCalculationNet::Deactivate_Connection(int32_t connectionID)
{
	ppConnectionNet[connectionID] = nullptr;
}

void CNeuralCalculationNet::Deactivate_Connection(int32_t ix, int32_t iy)
{
	ppConnectionNet[ix + iy * NumOfCalculationUnits] = nullptr;
}


void CNeuralCalculationNet::Set_CalculationFunction(int32_t unitID, int32_t functionID, pNeuralCalculationFunction pFunc)
{
	pCalculationUnitArray[unitID].pCalculationFunction = pFunc;
	pCalculationUnitArray[unitID].FunctionID = functionID;
}

void CNeuralCalculationNet::Set_CalculationFunction(int32_t unitID, int32_t functionID, CNeuralCalculationFunctions *pFunctions)
{
	pCalculationUnitArray[unitID].pCalculationFunction = pFunctions->pFunctionArray[functionID];
	pCalculationUnitArray[unitID].FunctionID = functionID;
}


void CNeuralCalculationNet::Set_ConnectionValues(int32_t connectionID, float plasticityValue, float centroidValue, float rBFConstant)
{
	CNeuralConnection *pConnection = &pConnectionArray[connectionID];
	pConnection->PlasticityValue = plasticityValue;
	pConnection->CentroidValue = centroidValue;
	pConnection->RBFConstant = rBFConstant;
}
void CNeuralCalculationNet::Set_Connection_RBFConstant(int32_t connectionID, float rBFConstant)
{
	CNeuralConnection *pConnection = &pConnectionArray[connectionID];
	pConnection->RBFConstant = rBFConstant;
}


void CNeuralCalculationNet::Set_Connection_CentroidValue(int32_t connectionID, float centroidValue)
{
	CNeuralConnection *pConnection = &pConnectionArray[connectionID];
	pConnection->CentroidValue = centroidValue;
}

void CNeuralCalculationNet::Set_Connection_PlasticityValue(int32_t connectionID, float plasticityValue)
{
	CNeuralConnection *pConnection = &pConnectionArray[connectionID];
	pConnection->PlasticityValue = plasticityValue;
}

void CNeuralCalculationNet::Set_ConnectionValues(int32_t ix, int32_t iy, float plasticityValue, float centroidValue, float rBFConstant)
{
	CNeuralConnection *pConnection = &pConnectionArray[ix + iy * NumOfCalculationUnits];
	pConnection->PlasticityValue = plasticityValue;
	pConnection->CentroidValue = centroidValue;
	pConnection->RBFConstant = rBFConstant;
}

void CNeuralCalculationNet::Set_Connection_RBFConstant(int32_t ix, int32_t iy, float rBFConstant)
{
	CNeuralConnection *pConnection = &pConnectionArray[ix + iy * NumOfCalculationUnits];
	pConnection->RBFConstant = rBFConstant;
}

void CNeuralCalculationNet::Set_Connection_PlasticityValue(int32_t ix, int32_t iy, float plasticityValue)
{
	CNeuralConnection *pConnection = &pConnectionArray[ix + iy * NumOfCalculationUnits];
	pConnection->PlasticityValue = plasticityValue;
}

void CNeuralCalculationNet::Set_Connection_CentroidValue(int32_t ix, int32_t iy, float centroidValue)
{
	CNeuralConnection *pConnection = &pConnectionArray[ix + iy * NumOfCalculationUnits];
	pConnection->CentroidValue = centroidValue;
}

void CNeuralCalculationNet::Initialize(int32_t numOfCalculationUnits, int32_t numOfInputUnits, int32_t numOfOutputUnits)
{
	delete[] pCalculationUnitArray;
	pCalculationUnitArray = nullptr;

	delete[] pConnectionArray;
	pConnectionArray = nullptr;

	delete[] ppConnectionNet;
	ppConnectionNet = nullptr;

	delete[] pInputUnitIDArray;
	pInputUnitIDArray = nullptr;

	delete[] pOutputUnitIDArray;
	pOutputUnitIDArray = nullptr;

	NumOfInputUnits = numOfInputUnits;
	NumOfOutputUnits = numOfOutputUnits;

	pInputUnitIDArray = new (std::nothrow) int32_t[NumOfInputUnits];
	pOutputUnitIDArray = new (std::nothrow) int32_t[NumOfOutputUnits];

	for (int32_t i = 0; i < NumOfInputUnits; i++)
	{
		pInputUnitIDArray[i] = 0;
	}

	for (int32_t i = 0; i < NumOfOutputUnits; i++)
	{
		pOutputUnitIDArray[i] = 0;
	}

	NumOfCalculationUnits = numOfCalculationUnits;
	NumOfNeuralConnections = numOfCalculationUnits * numOfCalculationUnits;

	pCalculationUnitArray = new (std::nothrow) CNeuralCalculationUnit[NumOfCalculationUnits];
	pConnectionArray = new (std::nothrow) CNeuralConnection[NumOfNeuralConnections];

	ppConnectionNet = new (std::nothrow) CNeuralConnection*[NumOfNeuralConnections];

	for (int32_t i = 0; i < NumOfNeuralConnections; i++)
	{
		ppConnectionNet[i] = nullptr;
	}
}

void CNeuralCalculationNet::Initialize(CNeuralCalculationNetDesc *pInDesc, CNeuralCalculationFunctions *pFunctions, int32_t numOfInputUnits, int32_t numOfOutputUnits)
{
	delete[] pCalculationUnitArray;
	pCalculationUnitArray = nullptr;

	delete[] pConnectionArray;
	pConnectionArray = nullptr;

	delete[] ppConnectionNet;
	ppConnectionNet = nullptr;

	delete[] pInputUnitIDArray;
	pInputUnitIDArray = nullptr;

	delete[] pOutputUnitIDArray;
	pOutputUnitIDArray = nullptr;

	NumOfInputUnits = numOfInputUnits;
	NumOfOutputUnits = numOfOutputUnits;

	pInputUnitIDArray = new (std::nothrow) int32_t[NumOfInputUnits];
	pOutputUnitIDArray = new (std::nothrow) int32_t[NumOfOutputUnits];

	for (int32_t i = 0; i < NumOfInputUnits; i++)
	{
		pInputUnitIDArray[i] = 0;
	}

	for (int32_t i = 0; i < NumOfOutputUnits; i++)
	{
		pOutputUnitIDArray[i] = 0;
	}

	NumOfCalculationUnits = pInDesc->NumOfCalculationUnits;
	NumOfNeuralConnections = pInDesc->NumOfNeuralConnections;

	pCalculationUnitArray = new (std::nothrow) CNeuralCalculationUnit[NumOfCalculationUnits];

	int32_t inputUnitCounter = 0;
	int32_t outputUnitCounter = 0;

	for (int32_t i = 0; i < NumOfCalculationUnits; i++)
	{
		pCalculationUnitArray[i].FunctionID = pInDesc->pCalculationFunctionIDArray[i];
		pCalculationUnitArray[i].pCalculationFunction = pFunctions->pFunctionArray[pCalculationUnitArray[i].FunctionID];
		pCalculationUnitArray[i].UsageStatus = pInDesc->pCalculationUnitUsageStatusArray[i];
		pCalculationUnitArray[i].SumOfInputValues = 0.0f;
		pCalculationUnitArray[i].OutputValue = 0.0f;

		if(pCalculationUnitArray[i].UsageStatus == UsageStatus_CalculationInputUnit)
		{
			pInputUnitIDArray[inputUnitCounter] = i;
			inputUnitCounter++;
		}
		else if (pCalculationUnitArray[i].UsageStatus == UsageStatus_CalculationOutputUnit)
		{
			pOutputUnitIDArray[outputUnitCounter] = i;
			outputUnitCounter++;
		}
	}

	pConnectionArray = new (std::nothrow) CNeuralConnection[NumOfNeuralConnections];

	for (int32_t i = 0; i < NumOfNeuralConnections; i++)
	{
		pConnectionArray[i].TransmissionValue = 0.0f;
		pConnectionArray[i].PlasticityValue = pInDesc->pPlasticityValueArray[i];
		pConnectionArray[i].CentroidValue = pInDesc->pCentroidValueArray[i];
		pConnectionArray[i].RBFConstant = pInDesc->pRBFConstantArray[i];
	}

	ppConnectionNet = new (std::nothrow) CNeuralConnection*[NumOfNeuralConnections];

	for (int32_t i = 0; i < NumOfNeuralConnections; i++)
	{
		ppConnectionNet[i] = nullptr;

		if (pInDesc->pConnectionStatusArray[i] != 0)
		{
			ppConnectionNet[i] = &pConnectionArray[i];
		}
	}
}

void CNeuralCalculationNet::Readout_Data(CNeuralCalculationNetDesc *pOutDesc, bool memoryAllocation)
{
	if (memoryAllocation == true)
	{
		pOutDesc->Initialize(NumOfCalculationUnits);
	}

	pOutDesc->NumOfCalculationUnits = NumOfCalculationUnits;
	pOutDesc->NumOfNeuralConnections = NumOfNeuralConnections;

	for (int32_t i = 0; i < NumOfCalculationUnits; i++)
	{
		pOutDesc->pCalculationFunctionIDArray[i] = pCalculationUnitArray[i].FunctionID;
		pOutDesc->pCalculationUnitUsageStatusArray[i] = pCalculationUnitArray[i].UsageStatus;
	}

	for (int32_t i = 0; i < NumOfNeuralConnections; i++)
	{
		if (ppConnectionNet[i] == nullptr)
		{
			pOutDesc->pConnectionStatusArray[i] = 0;
		}
		else
		{
			pOutDesc->pConnectionStatusArray[i] = 1;
		}

		pOutDesc->pPlasticityValueArray[i] = pConnectionArray[i].PlasticityValue;
		pOutDesc->pCentroidValueArray[i] = pConnectionArray[i].CentroidValue;
		pOutDesc->pRBFConstantArray[i] = pConnectionArray[i].RBFConstant;
	}
}

void CNeuralCalculationNet::Modify(CNeuralCalculationNetDesc *pInDesc, CNeuralCalculationFunctions *pFunctions)
{
	int32_t inputUnitCounter = 0;
	int32_t outputUnitCounter = 0;

	for (int32_t i = 0; i < NumOfCalculationUnits; i++)
	{
		pCalculationUnitArray[i].FunctionID = pInDesc->pCalculationFunctionIDArray[i];
		pCalculationUnitArray[i].pCalculationFunction = pFunctions->pFunctionArray[pCalculationUnitArray[i].FunctionID];
		pCalculationUnitArray[i].UsageStatus = pInDesc->pCalculationUnitUsageStatusArray[i];
		pCalculationUnitArray[i].SumOfInputValues = 0.0f;
		pCalculationUnitArray[i].OutputValue = 0.0f;

		if (pCalculationUnitArray[i].UsageStatus == UsageStatus_CalculationInputUnit)
		{
			pInputUnitIDArray[inputUnitCounter] = i;
			inputUnitCounter++;
		}
		else if (pCalculationUnitArray[i].UsageStatus == UsageStatus_CalculationOutputUnit)
		{
			pOutputUnitIDArray[outputUnitCounter] = i;
			outputUnitCounter++;
		}
	}

	for (int32_t i = 0; i < NumOfNeuralConnections; i++)
	{
		pConnectionArray[i].TransmissionValue = 0.0f;
		pConnectionArray[i].PlasticityValue = pInDesc->pPlasticityValueArray[i];
		pConnectionArray[i].CentroidValue = pInDesc->pCentroidValueArray[i];
		pConnectionArray[i].RBFConstant = pInDesc->pRBFConstantArray[i];
	}

	for (int32_t i = 0; i < NumOfNeuralConnections; i++)
	{
		ppConnectionNet[i] = nullptr;

		if (pInDesc->pConnectionStatusArray[i] != 0)
		{
			ppConnectionNet[i] = &pConnectionArray[i];
		}
	}
}

void CNeuralCalculationNet::Clone_NeuralCalculationUnitValues(CNeuralCalculationNet *pOriginalObject)
{
	for (int32_t i = 0; i < NumOfCalculationUnits; i++)
	{
		pCalculationUnitArray[i].Clone_Data(&pOriginalObject->pCalculationUnitArray[i]);
	}
}

void CNeuralCalculationNet::Clone_NeuralConnectionValues(CNeuralCalculationNet *pOriginalObject)
{
	for (int32_t i = 0; i < NumOfNeuralConnections; i++)
	{
		pConnectionArray[i].Clone_Data(&pOriginalObject->pConnectionArray[i]);
	}
}

void CNeuralCalculationNet::Clone_ConnectionNet(CNeuralCalculationNet *pOriginalObject)
{
	for (int32_t i = 0; i < NumOfCalculationUnits; i++)
	{
		int32_t ii = i * NumOfCalculationUnits;

		for (int32_t j = 0; j < NumOfCalculationUnits; j++)
		{
			int32_t id = j + ii;

			if (pOriginalObject->ppConnectionNet[id] == nullptr)
			{
				ppConnectionNet[id] = nullptr;
			}
			else
			{
				ppConnectionNet[id] = &pConnectionArray[id];
			}
		}
	}
}

void CNeuralCalculationNet::Set_CalculationUnit_AdditionalCalculationValue(int32_t unitID, float value, int32_t valueID)
{
	pCalculationUnitArray[unitID].AdditionalCalcValueArray[valueID] = value;
}

void CNeuralCalculationNet::Set_InputUnit_AdditionalCalculationValue(int32_t unitID, float value, int32_t valueID)
{
	int32_t id = pInputUnitIDArray[unitID];
	pCalculationUnitArray[id].AdditionalCalcValueArray[valueID] = value;
}

void CNeuralCalculationNet::Set_InputUnits_AdditionalCalculationValue(float value, int32_t valueID)
{
	for (int32_t i = 0; i < NumOfInputUnits; i++)
	{
		int32_t id = pInputUnitIDArray[i];
		pCalculationUnitArray[id].AdditionalCalcValueArray[valueID] = value;
	}
}

void CNeuralCalculationNet::Set_OutputUnit_AdditionalCalculationValue(int32_t unitID, float value, int32_t valueID)
{
	int32_t id = pOutputUnitIDArray[unitID];
	pCalculationUnitArray[id].AdditionalCalcValueArray[valueID] = value;
}

void CNeuralCalculationNet::Set_OutputUnits_AdditionalCalculationValue(float value, int32_t valueID)
{
	for (int32_t i = 0; i < NumOfOutputUnits; i++)
	{
		int32_t id = pOutputUnitIDArray[i];
		pCalculationUnitArray[id].AdditionalCalcValueArray[valueID] = value;
	}
}

void CNeuralCalculationNet::Reset_InputUnits_Input_And_OutputValue(void)
{
	for (int32_t i = 0; i < NumOfInputUnits; i++)
	{
		int32_t id = pInputUnitIDArray[i];
		pCalculationUnitArray[id].SumOfInputValues = 0.0f;
		pCalculationUnitArray[id].OutputValue = 0.0f;
	}
}

void CNeuralCalculationNet::Reset_OutputUnits_Input_And_OutputValue(void)
{
	for (int32_t i = 0; i < NumOfOutputUnits; i++)
	{
		int32_t id = pOutputUnitIDArray[i];
		pCalculationUnitArray[id].SumOfInputValues = 0.0f;
		pCalculationUnitArray[id].OutputValue = 0.0f;
	}
}

void CNeuralCalculationNet::Reset_CalculationUnits_Input_And_OutputValue(void)
{
	for (int32_t i = 0; i < NumOfCalculationUnits; i++)
	{
		pCalculationUnitArray[i].SumOfInputValues = 0.0f;
		pCalculationUnitArray[i].OutputValue = 0.0f;
	}
}

void CNeuralCalculationNet::Reset_CalculationUnit_Input_And_OutputValue(int32_t unitID)
{
	pCalculationUnitArray[unitID].SumOfInputValues = 0.0f;
	pCalculationUnitArray[unitID].OutputValue = 0.0f;
}

void CNeuralCalculationNet::Reset_UsageStatus_Of_CalculationUnits(void)
{
	for (int32_t i = 0; i < NumOfCalculationUnits; i++)
	{
		pCalculationUnitArray[i].UsageStatus = UsageStatus_CalculationUnit_Standard;
	}
}

void CNeuralCalculationNet::Set_InputUnits(int32_t *pUnitIDArray)
{
	for (int32_t i = 0; i < NumOfInputUnits; i++)
	{
		pInputUnitIDArray[i] = pUnitIDArray[i];
		pCalculationUnitArray[pInputUnitIDArray[i]].UsageStatus = UsageStatus_CalculationInputUnit;
	}
}

void CNeuralCalculationNet::Set_OutputUnits(int32_t *pUnitIDArray)
{
	for (int32_t i = 0; i < NumOfOutputUnits; i++)
	{
		pOutputUnitIDArray[i] = pUnitIDArray[i];
		pCalculationUnitArray[pOutputUnitIDArray[i]].UsageStatus = UsageStatus_CalculationOutputUnit;
	}
}

void CNeuralCalculationNet::Set_InputUnit(int32_t unitID, int32_t unitIDArrayIndex)
{
	pInputUnitIDArray[unitIDArrayIndex] = unitID;
	pCalculationUnitArray[unitID].UsageStatus = UsageStatus_CalculationInputUnit;
}

void CNeuralCalculationNet::Set_OutputUnit(int32_t unitID, int32_t unitIDArrayIndex)
{
	pOutputUnitIDArray[unitIDArrayIndex] = unitID;
	pCalculationUnitArray[unitID].UsageStatus = UsageStatus_CalculationOutputUnit;
}

void CNeuralCalculationNet::Set_InputValues(float *pInputValueArray, int32_t firstArrayElementID)
{
	for (int32_t i = 0; i < NumOfInputUnits; i++)
	{
		pCalculationUnitArray[pInputUnitIDArray[i]].SumOfInputValues = pInputValueArray[firstArrayElementID];
		firstArrayElementID++;
	}
}

void CNeuralCalculationNet::Set_InputValue(float value)
{
	pCalculationUnitArray[pInputUnitIDArray[0]].SumOfInputValues = value;
}

void CNeuralCalculationNet::Set_InputValues(float *pInputValueArray)
{
	for (int32_t i = 0; i < NumOfInputUnits; i++)
	{
		pCalculationUnitArray[pInputUnitIDArray[i]].SumOfInputValues = pInputValueArray[i];
	}
}

void CNeuralCalculationNet::Add_InputValues(float *pInputValueArray, int32_t firstArrayElementID)
{
	for (int32_t i = 0; i < NumOfInputUnits; i++)
	{
		pCalculationUnitArray[pInputUnitIDArray[i]].SumOfInputValues += pInputValueArray[firstArrayElementID];
		firstArrayElementID++;
	}
}

void CNeuralCalculationNet::Add_InputValue(float value)
{
	pCalculationUnitArray[pInputUnitIDArray[0]].SumOfInputValues += value;
}

void CNeuralCalculationNet::Add_InputValues(float *pInputValueArray)
{
	for (int32_t i = 0; i < NumOfInputUnits; i++)
	{
		pCalculationUnitArray[pInputUnitIDArray[i]].SumOfInputValues += pInputValueArray[i];
	}
}

bool CNeuralCalculationNet::Set_InputValues_UseLRFCenterPos(int32_t posX_center, int32_t posY_center, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY)
{
	if (inputMapSizeX == localReceptiveFieldSizeX && inputMapSizeY == localReceptiveFieldSizeY)
	{
		int32_t inputValueCounter = localReceptiveFieldSizeX * localReceptiveFieldSizeY;

		for (int32_t i = 0; i < inputValueCounter; i++)
		{
			pCalculationUnitArray[pInputUnitIDArray[i]].SumOfInputValues = pInputMap[i];
		}

		return true;
	}

	int32_t posX_left = posX_center - localReceptiveFieldSizeX / 2;
	int32_t posY_top = posY_center - localReceptiveFieldSizeY / 2;

	if (posX_left < 0)
		return false;
	if (posY_top < 0)
		return false;
	if (posX_left > inputMapSizeX - localReceptiveFieldSizeX)
		return false;
	if (posY_top > inputMapSizeY - localReceptiveFieldSizeY)
		return false;

	int32_t ixStart = posX_left;
	int32_t ixStop = ixStart + localReceptiveFieldSizeX;

	int32_t iyStart = posY_top;
	int32_t iyStop = iyStart + localReceptiveFieldSizeY;

	int32_t iiy;
	int32_t counter = 0;

	for (int32_t iy = iyStart; iy < iyStop; iy++)
	{
		iiy = iy * inputMapSizeX;

		for (int32_t ix = ixStart; ix < ixStop; ix++)
		{
			pCalculationUnitArray[pInputUnitIDArray[counter++]].SumOfInputValues = pInputMap[ix + iiy];
		}
	}

	return true;
}

bool CNeuralCalculationNet::Add_InputValues_UseLRFCenterPos(int32_t posX_center, int32_t posY_center, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY)
{
	if (inputMapSizeX == localReceptiveFieldSizeX && inputMapSizeY == localReceptiveFieldSizeY)
	{
		int32_t inputValueCounter = localReceptiveFieldSizeX * localReceptiveFieldSizeY;

		for (int32_t i = 0; i < inputValueCounter; i++)
		{
			pCalculationUnitArray[pInputUnitIDArray[i]].SumOfInputValues += pInputMap[i];
		}

		return true;
	}

	int32_t posX_left = posX_center - localReceptiveFieldSizeX / 2;
	int32_t posY_top = posY_center - localReceptiveFieldSizeY / 2;

	if (posX_left < 0)
		return false;
	if (posY_top < 0)
		return false;
	if (posX_left > inputMapSizeX - localReceptiveFieldSizeX)
		return false;
	if (posY_top > inputMapSizeY - localReceptiveFieldSizeY)
		return false;

	int32_t ixStart = posX_left;
	int32_t ixStop = ixStart + localReceptiveFieldSizeX;

	int32_t iyStart = posY_top;
	int32_t iyStop = iyStart + localReceptiveFieldSizeY;

	int32_t iiy;
	int32_t counter = 0;

	for (int32_t iy = iyStart; iy < iyStop; iy++)
	{
		iiy = iy * inputMapSizeX;

		for (int32_t ix = ixStart; ix < ixStop; ix++)
		{
			pCalculationUnitArray[pInputUnitIDArray[counter++]].SumOfInputValues += pInputMap[ix + iiy];
		}
	}

	return true;
}

bool CNeuralCalculationNet::Set_InputValues_UseLRFTopLeftPos(int32_t posX_left, int32_t posY_top, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY)
{
	if (inputMapSizeX == localReceptiveFieldSizeX && inputMapSizeY == localReceptiveFieldSizeY)
	{
		int32_t inputValueCounter = localReceptiveFieldSizeX * localReceptiveFieldSizeY;

		for (int32_t i = 0; i < inputValueCounter; i++)
		{
			pCalculationUnitArray[pInputUnitIDArray[i]].SumOfInputValues = pInputMap[i];
		}

		return true;
	}

	if (posX_left < 0)
		return false;
	if (posY_top < 0)
		return false;
	if (posX_left > inputMapSizeX - localReceptiveFieldSizeX)
		return false;
	if (posY_top > inputMapSizeY - localReceptiveFieldSizeY)
		return false;

	int32_t ixStart = posX_left;
	int32_t ixStop = ixStart + localReceptiveFieldSizeX;

	int32_t iyStart = posY_top;
	int32_t iyStop = iyStart + localReceptiveFieldSizeY;

	int32_t iiy;
	int32_t counter = 0;

	for (int32_t iy = iyStart; iy < iyStop; iy++)
	{
		iiy = iy * inputMapSizeX;

		for (int32_t ix = ixStart; ix < ixStop; ix++)
		{
			pCalculationUnitArray[pInputUnitIDArray[counter++]].SumOfInputValues = pInputMap[ix + iiy];
		}
	}


	return true;
}

bool CNeuralCalculationNet::Add_InputValues_UseLRFTopLeftPos(int32_t posX_left, int32_t posY_top, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY)
{
	if (inputMapSizeX == localReceptiveFieldSizeX && inputMapSizeY == localReceptiveFieldSizeY)
	{
		int32_t inputValueCounter = localReceptiveFieldSizeX * localReceptiveFieldSizeY;

		for (int32_t i = 0; i < inputValueCounter; i++)
		{
			pCalculationUnitArray[pInputUnitIDArray[i]].SumOfInputValues += pInputMap[i];
		}

		return true;
	}

	if (posX_left < 0)
		return false;
	if (posY_top < 0)
		return false;
	if (posX_left > inputMapSizeX - localReceptiveFieldSizeX)
		return false;
	if (posY_top > inputMapSizeY - localReceptiveFieldSizeY)
		return false;

	int32_t ixStart = posX_left;
	int32_t ixStop = ixStart + localReceptiveFieldSizeX;

	int32_t iyStart = posY_top;
	int32_t iyStop = iyStart + localReceptiveFieldSizeY;

	int32_t iiy;
	int32_t counter = 0;

	for (int32_t iy = iyStart; iy < iyStop; iy++)
	{
		iiy = iy * inputMapSizeX;

		for (int32_t ix = ixStart; ix < ixStop; ix++)
		{
			pCalculationUnitArray[pInputUnitIDArray[counter++]].SumOfInputValues += pInputMap[ix + iiy];
		}
	}


	return true;
}

float CNeuralCalculationNet::Get_OutputValue(int32_t id)
{
	return pCalculationUnitArray[pOutputUnitIDArray[id]].OutputValue;
}


void CNeuralCalculationNet::Get_SoftmaxOutputValues(float *pOutputValueArray)
{
	for (int32_t i = 0; i < NumOfOutputUnits; i++)
	{
		pOutputValueArray[i] = pCalculationUnitArray[pOutputUnitIDArray[i]].OutputValue;
	}

	SoftMax(pOutputValueArray, NumOfOutputUnits);
}

void CNeuralCalculationNet::Get_OutputValues(float *pOutputValueArray)
{
	for (int32_t i = 0; i < NumOfOutputUnits; i++)
	{
		pOutputValueArray[i] = pCalculationUnitArray[pOutputUnitIDArray[i]].OutputValue;
	}
}

float CNeuralCalculationNet::Calculate_OutputVarianceSum_And_OutputError(float *pDesiredOutputValueArray, float errorFactor1, float errorFactor2)
{
	float varianceSq = 0.0f;

	for (int32_t i = 0; i < NumOfOutputUnits; i++)
	{
		varianceSq += pCalculationUnitArray[pOutputUnitIDArray[i]].Calculate_Variance_And_Error(pDesiredOutputValueArray[i], errorFactor1, errorFactor2);
	}

	return varianceSq;
}

float CNeuralCalculationNet::Calculate_OutputVarianceSum_And_OutputError(float *pDesiredOutputValueArray)
{
	float varianceSq = 0.0f;

	for (int32_t i = 0; i < NumOfOutputUnits; i++)
	{
		varianceSq += pCalculationUnitArray[pOutputUnitIDArray[i]].Calculate_Variance_And_Error(pDesiredOutputValueArray[i]);
	}

	return varianceSq;
}

float CNeuralCalculationNet::Calculate_OutputVarianceSum(float *pDesiredOutputValueArray)
{
	float varianceSq = 0.0f;

	for (int32_t i = 0; i < NumOfOutputUnits; i++)
	{
		varianceSq += pCalculationUnitArray[pOutputUnitIDArray[i]].Calculate_Variance(pDesiredOutputValueArray[i]);
	}

	return varianceSq;
}

float CNeuralCalculationNet::Calculate_OutputVarianceSum(float *pDesiredOutputValueArray, int32_t firstOutputUnitID, int32_t numOfOutputUnits)
{
	float varianceSq = 0.0f;

	int32_t maxOutputUnitIDPlus1 = firstOutputUnitID + numOfOutputUnits;

	int32_t counter = 0;

	for (int32_t i = firstOutputUnitID; i < maxOutputUnitIDPlus1; i++)
	{
		varianceSq += pCalculationUnitArray[pOutputUnitIDArray[i]].Calculate_Variance(pDesiredOutputValueArray[counter]);
		counter++;
	}

	return varianceSq;
}


void CNeuralCalculationNet::Learning(float learningRate, float errorFactor1, float errorFactor2)
{
	// error calculations:

	for (int32_t i = 0; i < NumOfCalculationUnits; i++)
	{
		pCalculationUnitArray[i].ErrorSumOfSubsequentUnits = 0.0f;
	}

	CNeuralCalculationUnit *pSourceCalculationUnit = nullptr;
	CNeuralConnection *pConnection = nullptr;

	int32_t numOfCalculationUnitsMinus1 = NumOfCalculationUnits - 1;

	for (int32_t column = numOfCalculationUnitsMinus1; column > -1; column--)
	{
		pSourceCalculationUnit = &pCalculationUnitArray[column];

		if (pSourceCalculationUnit->pCalculationFunction == nullptr)
		{
			continue;
		}

		if (pSourceCalculationUnit->UsageStatus != UsageStatus_CalculationOutputUnit)
		{
			pSourceCalculationUnit->Calculate_Error(errorFactor1, errorFactor2);
		}

		// Fehlerwerte zur�ckpropagieren:

		for (int32_t row = 0; row < NumOfCalculationUnits; row++)
		{
			int32_t id = column + row * NumOfCalculationUnits;

			pConnection = ppConnectionNet[id];

			if (pConnection == nullptr)
			{
				continue;
			}

			pCalculationUnitArray[row].ErrorSumOfSubsequentUnits += pSourceCalculationUnit->ErrorValue * pConnection->PlasticityValue;
		}
	}

	// learning:

	CNeuralCalculationUnit *pSubsequentCalculationUnit = nullptr;

	for (int32_t row = 0; row < NumOfCalculationUnits; row++)
	{
		pSourceCalculationUnit = &pCalculationUnitArray[row];

		if (pSourceCalculationUnit->pCalculationFunction == nullptr)
		{
			continue;
		}

		int32_t _row = row * NumOfCalculationUnits;

		for (int32_t column = 0; column < NumOfCalculationUnits; column++)
		{
			int32_t id = column + _row;

			pConnection = ppConnectionNet[id];

			if (pConnection == nullptr)
			{
				continue;
			}

			pSubsequentCalculationUnit = &pCalculationUnitArray[column];

			if (pSubsequentCalculationUnit->pCalculationFunction == nullptr)
			{
				continue;
			}

			pConnection->PlasticityValue += learningRate * pSubsequentCalculationUnit->ErrorValue * pSourceCalculationUnit->OutputValue;
		}
	}
}

void CNeuralCalculationNet::ExtremeLearning(float learningRate)
{
	CNeuralCalculationUnit *pSourceCalculationUnit = nullptr;
	CNeuralConnection *pConnection = nullptr;
	CNeuralCalculationUnit *pSubsequentCalculationUnit = nullptr;

	for (int32_t row = 0; row < NumOfCalculationUnits; row++)
	{
		pSourceCalculationUnit = &pCalculationUnitArray[row];

		if (pSourceCalculationUnit->pCalculationFunction == nullptr)
		{
			continue;
		}

		int32_t _row = row * NumOfCalculationUnits;

		for (int32_t column = 0; column < NumOfCalculationUnits; column++)
		{
			int32_t id = column + _row;

			pConnection = ppConnectionNet[id];

			if (pConnection == nullptr)
			{
				continue;
			}

			pSubsequentCalculationUnit = &pCalculationUnitArray[column];

			if (pSubsequentCalculationUnit->pCalculationFunction == nullptr)
			{
				continue;
			}

			if (pSubsequentCalculationUnit->UsageStatus != UsageStatus_CalculationOutputUnit)
			{
				continue;
			}

			pConnection->PlasticityValue += learningRate * pSubsequentCalculationUnit->ErrorValue * pSourceCalculationUnit->OutputValue;
		}
	}
}

void CNeuralCalculationNet::Learning(void)
{
	// error calculations:

	for (int32_t i = 0; i < NumOfCalculationUnits; i++)
	{
		pCalculationUnitArray[i].ErrorSumOfSubsequentUnits = 0.0f;
	}

	CNeuralCalculationUnit *pSourceCalculationUnit = nullptr;
	CNeuralConnection *pConnection = nullptr;

	int32_t numOfCalculationUnitsMinus1 = NumOfCalculationUnits - 1;

	for (int32_t column = numOfCalculationUnitsMinus1; column > -1; column--)
	{
		pSourceCalculationUnit = &pCalculationUnitArray[column];

		if (pSourceCalculationUnit->pCalculationFunction == nullptr)
		{
			continue;
		}

		if (pSourceCalculationUnit->UsageStatus != UsageStatus_CalculationOutputUnit)
		{
			pSourceCalculationUnit->Calculate_Error();
		}

		// Fehlerwerte zur�ckpropagieren:

		for (int32_t row = 0; row < NumOfCalculationUnits; row++)
		{
			int32_t id = column + row * NumOfCalculationUnits;

			pConnection = ppConnectionNet[id];

			if (pConnection == nullptr)
			{
				continue;
			}

			pCalculationUnitArray[row].ErrorSumOfSubsequentUnits += pSourceCalculationUnit->ErrorValue * pConnection->PlasticityValue;
		}
	}

	// learning:

	CNeuralCalculationUnit *pSubsequentCalculationUnit = nullptr;

	for (int32_t row = 0; row < NumOfCalculationUnits; row++)
	{
		pSourceCalculationUnit = &pCalculationUnitArray[row];

		if (pSourceCalculationUnit->pCalculationFunction == nullptr)
		{
			continue;
		}

		int32_t _row = row * NumOfCalculationUnits;

		for (int32_t column = 0; column < NumOfCalculationUnits; column++)
		{
			int32_t id = column + _row;

			pConnection = ppConnectionNet[id];

			if (pConnection == nullptr)
			{
				continue;
			}

			pSubsequentCalculationUnit = &pCalculationUnitArray[column];

			if (pSubsequentCalculationUnit->pCalculationFunction == nullptr)
			{
				continue;
			}

			pConnection->PlasticityValue += pSubsequentCalculationUnit->LearningRate * pSubsequentCalculationUnit->ErrorValue * pSubsequentCalculationUnit->OutputValue;
		}
	}
}

void CNeuralCalculationNet::ExtremeLearning(void)
{
	CNeuralCalculationUnit *pSourceCalculationUnit = nullptr;
	CNeuralConnection *pConnection = nullptr;
	CNeuralCalculationUnit *pSubsequentCalculationUnit = nullptr;

	for (int32_t row = 0; row < NumOfCalculationUnits; row++)
	{
		pSourceCalculationUnit = &pCalculationUnitArray[row];

		if (pSourceCalculationUnit->pCalculationFunction == nullptr)
		{
			continue;
		}

		int32_t _row = row * NumOfCalculationUnits;

		for (int32_t column = 0; column < NumOfCalculationUnits; column++)
		{
			int32_t id = column + _row;

			pConnection = ppConnectionNet[id];

			if (pConnection == nullptr)
			{
				continue;
			}

			pSubsequentCalculationUnit = &pCalculationUnitArray[column];

			if (pSubsequentCalculationUnit->pCalculationFunction == nullptr)
			{
				continue;
			}

			if (pSubsequentCalculationUnit->UsageStatus != UsageStatus_CalculationOutputUnit)
			{
				continue;
			}

			pConnection->PlasticityValue += pSubsequentCalculationUnit->LearningRate * pSubsequentCalculationUnit->ErrorValue * pSubsequentCalculationUnit->OutputValue;
		}
	}
}



void CNeuralCalculationNet::Execute_Calculations(void)
{
	CNeuralCalculationUnit *pSourceCalculationUnit = nullptr;
	CNeuralConnection *pConnection = nullptr;

	for (int32_t row = 0; row < NumOfCalculationUnits; row++)
	{
		pSourceCalculationUnit = &pCalculationUnitArray[row];

		if (pSourceCalculationUnit->pCalculationFunction == nullptr)
		{
			continue;
		}

		pSourceCalculationUnit->Calculate_OutputValue();

		int32_t _row = row * NumOfCalculationUnits;

		for (int32_t column = 0; column < NumOfCalculationUnits; column++)
		{
			int32_t id = column + _row;

			pConnection = ppConnectionNet[id];

			if (pConnection == nullptr)
			{
				continue;
			}

			pConnection->TransmissionValue = pSourceCalculationUnit->OutputValue;
			pConnection->Transform_TransmissionValue();

			pCalculationUnitArray[column].SumOfInputValues += pConnection->TransmissionValue;
					
		}
	}
}


void CNeuralCalculationNetDescPopulation::Modify_All_Brains(pCalculationNetDesc_Mutation pFunc, void *pParam)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFunc(ppDescArray[i], &RandomNumbers, pParam);
	}
}



void CNeuralCalculationNetDescPopulation::Modify_All_Brains2(pCalculationNetDesc_Permutation pFunc, void *pParam)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFunc(ppDescArray[i], &RandomNumbers, pParam);
	}
}



void CNeuralCalculationNetDescPopulation::Replace_WorstFitted_Brain(pCalculationNetDesc_Reinitialization pFunc, void *pParam)
{
	pFunc(ppDescArray[IDArrayOfWorstFittedBrains[0]], &RandomNumbers, pParam);
}

void CNeuralCalculationNetDescPopulation::Replace_WorstFitted_Brain(uint64_t seed, pCalculationNetDesc_Reinitialization pFunc, void *pParam)
{
	RandomNumbers.Change_Seed(seed);
	pFunc(ppDescArray[IDArrayOfWorstFittedBrains[0]], &RandomNumbers, pParam);
}





void CNeuralCalculationNetDescPopulation::Replace_SecondWorstFitted_Brain(pCalculationNetDesc_Reinitialization pFunc, void *pParam)
{
	pFunc(ppDescArray[IDArrayOfWorstFittedBrains[1]], &RandomNumbers, pParam);
}

void CNeuralCalculationNetDescPopulation::Replace_SecondWorstFitted_Brain(uint64_t seed, pCalculationNetDesc_Reinitialization pFunc, void *pParam)
{
	RandomNumbers.Change_Seed(seed);
	pFunc(ppDescArray[IDArrayOfWorstFittedBrains[1]], &RandomNumbers, pParam);
}





void CNeuralCalculationNetDescPopulation::Replace_ThirdWorstFitted_Brain(pCalculationNetDesc_Reinitialization pFunc, void *pParam)
{
	pFunc(ppDescArray[IDArrayOfWorstFittedBrains[2]], &RandomNumbers, pParam);
}

void CNeuralCalculationNetDescPopulation::Replace_ThirdWorstFitted_Brain(uint64_t seed, pCalculationNetDesc_Reinitialization pFunc, void *pParam)
{
	RandomNumbers.Change_Seed(seed);
	pFunc(ppDescArray[IDArrayOfWorstFittedBrains[2]], &RandomNumbers, pParam);
}





void CNeuralCalculationNetDescPopulation::Update_Evolution_SecondBestBrainOnly2(pCalculationNetDesc_Permutation pFunc, void *pParam)
{
	if (UseAdditionalMutatedSecondBestBrain == true)
		return;

	ppDescArray[PopulationSize + 1]->Clone_Values(ppDescArray[IDArrayOfBestFittedBrains[1]]);


	pFunc(ppDescArray[PopulationSize + 1], &RandomNumbers, pParam);

	UseAdditionalMutatedSecondBestBrain = true;
}



void CNeuralCalculationNetDescPopulation::Update_Evolution_SecondBestBrainOnly(pCalculationNetDesc_Mutation pFunc, void *pParam)
{
	if (UseAdditionalMutatedSecondBestBrain == true)
		return;

	ppDescArray[PopulationSize + 1]->Clone_Values(ppDescArray[IDArrayOfBestFittedBrains[1]]);

	pFunc(ppDescArray[PopulationSize + 1], &RandomNumbers, pParam);

	UseAdditionalMutatedSecondBestBrain = true;
}



void CNeuralCalculationNetDescPopulation::Update_Evolution_BestBrainOnly2(pCalculationNetDesc_Permutation pFunc, void *pParam)
{
	if (UseAdditionalMutatedBestBrain == true)
		return;

	ppDescArray[PopulationSize]->Clone_Values(ppDescArray[IDArrayOfBestFittedBrains[0]]);


	pFunc(ppDescArray[PopulationSize], &RandomNumbers, pParam);

	UseAdditionalMutatedBestBrain = true;
}



void CNeuralCalculationNetDescPopulation::Update_Evolution_BestBrainOnly(pCalculationNetDesc_Mutation pFunc, void *pParam)
{
	if (UseAdditionalMutatedBestBrain == true)
		return;

	ppDescArray[PopulationSize]->Clone_Values(ppDescArray[IDArrayOfBestFittedBrains[0]]);

	pFunc(ppDescArray[PopulationSize], &RandomNumbers, pParam);

	UseAdditionalMutatedBestBrain = true;
}



void CNeuralCalculationNetDescPopulation::Update_BaseEvolution2(pCalculationNetDesc_Permutation pFunc, void *pParam)
{
	bool bestFittedBrains;

	for (int32_t i = 0; i < PopulationSize; i++)
	{
		bestFittedBrains = false;

		for (int32_t j = 0; j < constNumOfBestFittedBrains; j++)
		{
			if (i == IDArrayOfBestFittedBrains[j])
			{
				bestFittedBrains = true;
				break;
			}
		}

		if (bestFittedBrains == false)
		{
			pFunc(ppDescArray[i], &RandomNumbers, pParam);
		}
	}
}



void CNeuralCalculationNetDescPopulation::Update_BaseEvolution(pCalculationNetDesc_Mutation pFunc, void *pParam)
{
	bool bestFittedBrains;

	for (int32_t i = 0; i < PopulationSize; i++)
	{
		bestFittedBrains = false;

		for (int32_t j = 0; j < constNumOfBestFittedBrains; j++)
		{
			if (i == IDArrayOfBestFittedBrains[j])
			{
				bestFittedBrains = true;
				break;
			}
		}

		if (bestFittedBrains == false)
		{
			pFunc(ppDescArray[i], &RandomNumbers, pParam);
		}
	}
}



void CNeuralCalculationNetDescPopulation::Update_Evolution_Combine_TwoBrains(pCalculationNetDesc_Recombination pFunc, void *pParam)
{
	if (UseAdditionalRandomBrainsChild[RandomBrainsChildCounter] == true)
		return;

	int32_t id1, id2;

	for (int32_t i = 0; i < constNumPopulationSearchStepsMax; i++)
	{
		id1 = RandomNumbers.Get_IntegerNumber(0, PopulationSize);

		// die am schlechtesten angepassten Individuen d�rfen sich nicht vermehren:
		if (pFitnessScoreArray[id1] <= FitnessArrayOfWorstFittedBrains[constNumOfWorstFittedBrains - 1])
			continue;

		id2 = RandomNumbers.Get_IntegerNumber(0, PopulationSize);

		// die am schlechtesten angepassten Individuen d�rfen sich nicht vermehren:
		if (pFitnessScoreArray[id2] <= FitnessArrayOfWorstFittedBrains[constNumOfWorstFittedBrains - 1])
			continue;

		if (id1 == id2)
			continue;

		pFunc(ppDescArray[PopulationSize + 3 + RandomBrainsChildCounter], ppDescArray[id1], ppDescArray[id2], &RandomNumbers, pParam);


		UseAdditionalRandomBrainsChild[RandomBrainsChildCounter] = true;

		if (RandomBrainsChildCounter < constNumOfRandomBrainsChildren - 1)
			RandomBrainsChildCounter++;

		break;
	}
}



void CNeuralCalculationNetDescPopulation::Update_Evolution_Combine_BestTwoBrains(pCalculationNetDesc_Recombination pFunc, void *pParam)
{
	if (UseAdditionalBestBrainsChild == true)
		return;

	pFunc(ppDescArray[PopulationSize + 2], ppDescArray[IDArrayOfBestFittedBrains[0]], ppDescArray[IDArrayOfBestFittedBrains[1]], &RandomNumbers, pParam);

	UseAdditionalBestBrainsChild = true;
}





CNeuralCalculationNetDescPopulation::CNeuralCalculationNetDescPopulation()
{
	for (int32_t i = 0; i < constNumOfBestFittedBrains; i++)
	{
		IDArrayOfBestFittedBrains[i] = 0;
		FitnessArrayOfBestFittedBrains[i] = 0.0f;
	}

	for (int32_t i = 0; i < constNumOfWorstFittedBrains; i++)
	{
		IDArrayOfWorstFittedBrains[i] = 0;
		FitnessArrayOfWorstFittedBrains[i] = 0.0f;
	}
}





CNeuralCalculationNetDescPopulation::~CNeuralCalculationNetDescPopulation()
{
	delete[] pFitnessScoreArray;
	pFitnessScoreArray = nullptr;

	delete[] ppDescArray;
	ppDescArray = nullptr;
}




void CNeuralCalculationNetDescPopulation::Change_Seed(uint64_t seed)
{
	Seed = seed;
}






void CNeuralCalculationNetDescPopulation::Get_Best_Evolved_NeuralCalculationNetDesc(CNeuralCalculationNetDesc *pOutDesc)
{
	pOutDesc->Clone_Values(ppDescArray[IDArrayOfBestFittedBrains[0]]);
}





CNeuralCalculationNetDesc* CNeuralCalculationNetDescPopulation::Get_Best_Evolved_NeuralCalculationNetDesc(void)
{
	return ppDescArray[IDArrayOfBestFittedBrains[0]];
}



void CNeuralCalculationNetDescPopulation::Reset_MinErrorSum_ActualGeneration(float value)
{
	MinErrorSum_ActualGeneration = value;
}



void CNeuralCalculationNetDescPopulation::Reset_Population(void)
{
	for (int32_t i = 0; i < constNumOfBestFittedBrains; i++)
	{
		IDArrayOfBestFittedBrains[i] = 0;
		FitnessArrayOfBestFittedBrains[i] = 0.0f;
	}

	for (int32_t i = 0; i < constNumOfWorstFittedBrains; i++)
	{
		IDArrayOfWorstFittedBrains[i] = 0;
		FitnessArrayOfWorstFittedBrains[i] = 0.0f;
	}

	UseAdditionalMutatedBestBrain = false;
	UseAdditionalMutatedSecondBestBrain = false;
	UseAdditionalBestBrainsChild = false;

	RandomBrainsChildCounter = 0;

	for (int32_t i = 0; i < constNumOfRandomBrainsChildren; i++)
		UseAdditionalRandomBrainsChild[i] = false;


	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFitnessScoreArray[i] = 0.0f;
	}
}



void CNeuralCalculationNetDescPopulation::Update_MinErrorSum_ActualGeneration(float value)
{
	if (value < MinErrorSum_ActualGeneration)
		MinErrorSum_ActualGeneration = value;
}



void CNeuralCalculationNetDescPopulation::Calculate_FitnessScore_FromError(int32_t descID, float error)
{
	ppDescArray[descID]->FitnessScore = 1.0f / (error + 0.01f);
}






bool CNeuralCalculationNetDescPopulation::Initialize(int32_t populationSize)
{
	int32_t minPopulationSize = constNumOfBestFittedBrains + constNumOfWorstFittedBrains + constNumOfAdditionalBrains + 10;

	//if (populationSize < minPopulationSize)
	//populationSize = minPopulationSize;

	for (int32_t i = 0; i < constNumOfBestFittedBrains; i++)
	{
		IDArrayOfBestFittedBrains[i] = 0;
		FitnessArrayOfBestFittedBrains[i] = 0.0f;
	}

	for (int32_t i = 0; i < constNumOfWorstFittedBrains; i++)
	{
		IDArrayOfWorstFittedBrains[i] = 0;
		FitnessArrayOfWorstFittedBrains[i] = 0.0f;
	}

	UseAdditionalMutatedBestBrain = false;
	UseAdditionalMutatedSecondBestBrain = false;
	UseAdditionalBestBrainsChild = false;

	RandomBrainsChildCounter = 0;

	for (int32_t i = 0; i < constNumOfRandomBrainsChildren; i++)
		UseAdditionalRandomBrainsChild[i] = false;

	delete[] pFitnessScoreArray;
	pFitnessScoreArray = nullptr;

	delete[] ppDescArray;
	ppDescArray = nullptr;

	PopulationSizePlusX = populationSize;
	PopulationSize = PopulationSizePlusX - constNumOfAdditionalBrains;

	//PopulationSize = populationSize;
	//PopulationSizePlusX = populationSize + constNumOfAdditionalBrains;

	pFitnessScoreArray = new (std::nothrow) float[PopulationSizePlusX];
	ppDescArray = new (std::nothrow) CNeuralCalculationNetDesc*[PopulationSizePlusX];

	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFitnessScoreArray[i] = 0.0f;
		ppDescArray[i] = nullptr;
	}

	if (populationSize < minPopulationSize)
		return false;

	return true;
}



void CNeuralCalculationNetDescPopulation::Set_NeuralCalculationNetDesc(CNeuralCalculationNetDesc *pInDesc, int32_t id)
{
	ppDescArray[id] = pInDesc;
}



void CNeuralCalculationNetDescPopulation::Update_Population(void)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFitnessScoreArray[i] = ppDescArray[i]->FitnessScore;
	}

	for (int32_t i = 0; i < constNumOfBestFittedBrains; i++)
	{
		IDArrayOfBestFittedBrains[i] = 0;
		FitnessArrayOfBestFittedBrains[i] = -100000000.0f;
	}

	for (int32_t i = 0; i < constNumOfWorstFittedBrains; i++)
	{
		IDArrayOfWorstFittedBrains[i] = 0;
		FitnessArrayOfWorstFittedBrains[i] = 100000000.0f;
	}

	for (int32_t i = 0; i < PopulationSize; i++)
	{
		for (int32_t j = 0; j < constNumOfBestFittedBrains; j++)
		{
			if (pFitnessScoreArray[i] > FitnessArrayOfBestFittedBrains[j])
			{
				for (uint32_t k = constNumOfBestFittedBrains - 1; k > j; k--)
				{
					IDArrayOfBestFittedBrains[k] = IDArrayOfBestFittedBrains[k - 1];
					FitnessArrayOfBestFittedBrains[k] = FitnessArrayOfBestFittedBrains[k - 1];
				}

				FitnessArrayOfBestFittedBrains[j] = pFitnessScoreArray[i];
				IDArrayOfBestFittedBrains[j] = i;

				break;
			}
		}

		for (int32_t j = 0; j < constNumOfWorstFittedBrains; j++)
		{
			if (pFitnessScoreArray[i] < FitnessArrayOfWorstFittedBrains[j])
			{
				for (int32_t k = constNumOfWorstFittedBrains - 1; k > j; k--)
				{
					IDArrayOfWorstFittedBrains[k] = IDArrayOfWorstFittedBrains[k - 1];
					FitnessArrayOfWorstFittedBrains[k] = FitnessArrayOfWorstFittedBrains[k - 1];
				}

				FitnessArrayOfWorstFittedBrains[j] = pFitnessScoreArray[i];
				IDArrayOfWorstFittedBrains[j] = i;

				break;
			}
		}

	} // end of for (int32_t i = 0; i < PopulationSize; i++)


	  //HelperStuff::Add_To_Log(0, "best fitness", pFitnessScoreArray[IDArrayOfBestFittedBrains[0]]);

	float fitnessScoreOfBestFittedAdditionalBrain = -1000000.0f;
	int32_t idOfBestFittedAdditionalBrain = 0;

	for (int32_t i = 0; i < constNumOfAdditionalBrains; i++)
	{
		if (pFitnessScoreArray[PopulationSize + i] > fitnessScoreOfBestFittedAdditionalBrain)
		{
			fitnessScoreOfBestFittedAdditionalBrain = pFitnessScoreArray[PopulationSize + i];
			idOfBestFittedAdditionalBrain = PopulationSize + i;
		}
	}

	if (pFitnessScoreArray[idOfBestFittedAdditionalBrain] > pFitnessScoreArray[IDArrayOfBestFittedBrains[0]])
	{
		ppDescArray[IDArrayOfBestFittedBrains[0]]->Clone_Values(ppDescArray[idOfBestFittedAdditionalBrain]);
	}
	else if (pFitnessScoreArray[idOfBestFittedAdditionalBrain] > pFitnessScoreArray[IDArrayOfBestFittedBrains[1]])
	{
		ppDescArray[IDArrayOfBestFittedBrains[1]]->Clone_Values(ppDescArray[idOfBestFittedAdditionalBrain]);
	}
	else if (pFitnessScoreArray[idOfBestFittedAdditionalBrain] > pFitnessScoreArray[IDArrayOfBestFittedBrains[2]])
	{
		ppDescArray[IDArrayOfBestFittedBrains[2]]->Clone_Values(ppDescArray[idOfBestFittedAdditionalBrain]);
	}

	UseAdditionalMutatedBestBrain = false;
	UseAdditionalMutatedSecondBestBrain = false;
	UseAdditionalBestBrainsChild = false;

	RandomBrainsChildCounter = 0;

	for (int32_t i = 0; i < constNumOfRandomBrainsChildren; i++)
		UseAdditionalRandomBrainsChild[i] = false;
}



void CNeuralCalculationNetDescPopulation::Update_Population_Ext(void)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFitnessScoreArray[i] = ppDescArray[i]->FitnessScore;
	}

	for (int32_t i = 0; i < constNumOfBestFittedBrains; i++)
	{
		IDArrayOfBestFittedBrains[i] = 0;
		FitnessArrayOfBestFittedBrains[i] = -100000000.0f;
	}

	for (int32_t i = 0; i < constNumOfWorstFittedBrains; i++)
	{
		IDArrayOfWorstFittedBrains[i] = 0;
		FitnessArrayOfWorstFittedBrains[i] = 100000000.0f;
	}

	for (int32_t i = 0; i < PopulationSize; i++)
	{
		for (int32_t j = 0; j < constNumOfBestFittedBrains; j++)
		{
			if (pFitnessScoreArray[i] > FitnessArrayOfBestFittedBrains[j])
			{
				for (uint32_t k = constNumOfBestFittedBrains - 1; k > j; k--)
				{
					IDArrayOfBestFittedBrains[k] = IDArrayOfBestFittedBrains[k - 1];
					FitnessArrayOfBestFittedBrains[k] = FitnessArrayOfBestFittedBrains[k - 1];
				}

				FitnessArrayOfBestFittedBrains[j] = pFitnessScoreArray[i];
				IDArrayOfBestFittedBrains[j] = i;

				break;
			}
		}

		for (int32_t j = 0; j < constNumOfWorstFittedBrains; j++)
		{
			if (pFitnessScoreArray[i] < FitnessArrayOfWorstFittedBrains[j])
			{
				for (int32_t k = constNumOfWorstFittedBrains - 1; k > j; k--)
				{
					IDArrayOfWorstFittedBrains[k] = IDArrayOfWorstFittedBrains[k - 1];
					FitnessArrayOfWorstFittedBrains[k] = FitnessArrayOfWorstFittedBrains[k - 1];
				}

				FitnessArrayOfWorstFittedBrains[j] = pFitnessScoreArray[i];
				IDArrayOfWorstFittedBrains[j] = i;

				break;
			}
		}

	} // end of for (int32_t i = 0; i < PopulationSize; i++)


	  //HelperStuff::Add_To_Log(0, "best fitness", pFitnessScoreArray[IDArrayOfBestFittedBrains[0]]);

	float fitnessScoreOfBestFittedAdditionalBrain = -1000000.0f;
	int32_t idOfBestFittedAdditionalBrain = 0;

	for (int32_t i = 0; i < constNumOfAdditionalBrains; i++)
	{
		if (pFitnessScoreArray[PopulationSize + i] > fitnessScoreOfBestFittedAdditionalBrain)
		{
			fitnessScoreOfBestFittedAdditionalBrain = pFitnessScoreArray[PopulationSize + i];
			idOfBestFittedAdditionalBrain = PopulationSize + i;
		}
	}

	for (int32_t i = constNumOfBestFittedBrains - 1; i > -1; i--)
	{
		if (pFitnessScoreArray[idOfBestFittedAdditionalBrain] > pFitnessScoreArray[IDArrayOfBestFittedBrains[i]])
		{
			ppDescArray[IDArrayOfBestFittedBrains[i]]->Clone_Values(ppDescArray[idOfBestFittedAdditionalBrain]);
			break;
		}
	}



	UseAdditionalMutatedBestBrain = false;
	UseAdditionalMutatedSecondBestBrain = false;
	UseAdditionalBestBrainsChild = false;

	RandomBrainsChildCounter = 0;

	for (int32_t i = 0; i < constNumOfRandomBrainsChildren; i++)
		UseAdditionalRandomBrainsChild[i] = false;
}



void CNeuralCalculationNetDescPopulation::Update_PopulationKnowledge(void)
{
	CNeuralCalculationNetDesc *pBestDesc = ppDescArray[IDArrayOfBestFittedBrains[0]];

	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppDescArray[i]->Clone_Values(pBestDesc);
	}
}





void Search_Pattern(int32_t *pOutPatternCount, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CNeuralCalculationNet *pDetectionBrain, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float minActivationValue)
{

	int32_t patternCounter = 0;

	//int32_t numOfDetectionTests = 0;

	for (int32_t iy = minPosY; iy < maxPosYPlus1; iy += strideY)
	{
		for (int32_t ix = minPosX; ix < maxPosXPlus1; ix += strideX)
		{
			//numOfDetectionTests++;

			if (pDetectionBrain->Set_InputValues_UseLRFCenterPos(ix, iy, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY) == true)
			{
				pDetectionBrain->Execute_Calculations();

				//float outputValue;
				//pDetectionBrain->Get_OutputValues(&outputValue);

				float outputValue = pDetectionBrain->Get_OutputValue(0);

				if (outputValue > minActivationValue)
				{
					patternCounter++;
				}
			}
		}
	}

	*pOutPatternCount = patternCounter;
}

void Search_Pattern(int32_t *pOutPatternCount, CSimpleFeatureMap *pInSectorMap, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CNeuralCalculationNet *pDetectionBrain, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float minActivationValue)
{
	int32_t numOfSectorsXDir = pInSectorMap->SizeX;
	int32_t numOfSectorsYDir = pInSectorMap->SizeY;

	int32_t valuesPerSectorXDir = inputMapSizeX / numOfSectorsXDir;
	int32_t valuesPerSectorYDir = inputMapSizeY / numOfSectorsYDir;

	float *pSectorDataArray = pInSectorMap->pDataArray;

	int32_t ixSector, iySector, iiySector;

	int32_t patternCounter = 0;

	//int32_t numOfDetectionTests = 0;

	for (int32_t iy = minPosY; iy < maxPosYPlus1; iy += strideY)
	{
		iySector = iy / valuesPerSectorYDir;
		iiySector = iySector * numOfSectorsXDir;
		
		for (int32_t ix = minPosX; ix < maxPosXPlus1; ix += strideX)
		{
			ixSector = ix / valuesPerSectorXDir;

			if (pSectorDataArray[ixSector + iiySector] < 1.0f)
			{
				continue;
			}

			//numOfDetectionTests++;

			if (pDetectionBrain->Set_InputValues_UseLRFCenterPos(ix, iy, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY) == true)
			{
				pDetectionBrain->Execute_Calculations();

				//float outputValue;
				//pDetectionBrain->Get_OutputValues(&outputValue);

				float outputValue = pDetectionBrain->Get_OutputValue(0);

				if (outputValue > minActivationValue)
				{
					patternCounter++;
				}
			}
		}
	}

	*pOutPatternCount = patternCounter;
}

void Search_Pattern(int32_t *pOutPatternCount, int32_t *pOutPatternPosXArray, int32_t *pOutPatternPosYArray, int32_t numPatternPositionsMax, CSimpleFeatureMap *pInSectorMap, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CNeuralCalculationNet *pDetectionBrain, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float minActivationValue)
{
	int32_t numPatternPositionsMaxMinus1 = numPatternPositionsMax - 1;

	int32_t numOfSectorsXDir = pInSectorMap->SizeX;
	int32_t numOfSectorsYDir = pInSectorMap->SizeY;

	int32_t valuesPerSectorXDir = inputMapSizeX / numOfSectorsXDir;
	int32_t valuesPerSectorYDir = inputMapSizeY / numOfSectorsYDir;

	float *pSectorDataArray = pInSectorMap->pDataArray;

	int32_t ixSector, iySector, iiySector;

	int32_t patternCounter = 0;

	//int32_t numOfDetectionTests = 0;

	for (int32_t iy = minPosY; iy < maxPosYPlus1; iy += strideY)
	{
		iySector = iy / valuesPerSectorYDir;
		iiySector = iySector * numOfSectorsXDir;

		for (int32_t ix = minPosX; ix < maxPosXPlus1; ix += strideX)
		{
			ixSector = ix / valuesPerSectorXDir;

			if (pSectorDataArray[ixSector + iiySector] < 1.0f)
			{
				continue;
			}

			//numOfDetectionTests++;

			if (pDetectionBrain->Set_InputValues_UseLRFCenterPos(ix, iy, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY) == true)
			{
				pDetectionBrain->Execute_Calculations();

				//float outputValue;
				//pDetectionBrain->Get_OutputValues(&outputValue);

				float outputValue = pDetectionBrain->Get_OutputValue(0);

				if (outputValue > minActivationValue)
				{
					pOutPatternPosXArray[patternCounter] = ix;
					pOutPatternPosYArray[patternCounter] = iy;

					patternCounter++;
					patternCounter = min(patternCounter, numPatternPositionsMaxMinus1);
				}
			}
		}
	}

	*pOutPatternCount = patternCounter;
}

void Search_Pattern(float *pOutPatternCount, float *pOutPatternPosXArray, float *pOutPatternPosYArray, int32_t numPatternPositionsMax, CSimpleFeatureMap *pInSectorMap, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CNeuralCalculationNet *pDetectionBrain, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float minActivationValue)
{
	int32_t numPatternPositionsMaxMinus1 = numPatternPositionsMax - 1;

	int32_t numOfSectorsXDir = pInSectorMap->SizeX;
	int32_t numOfSectorsYDir = pInSectorMap->SizeY;

	int32_t valuesPerSectorXDir = inputMapSizeX / numOfSectorsXDir;
	int32_t valuesPerSectorYDir = inputMapSizeY / numOfSectorsYDir;

	float *pSectorDataArray = pInSectorMap->pDataArray;

	int32_t ixSector, iySector, iiySector;

	int32_t patternCounter = 0;

	//int32_t numOfDetectionTests = 0;

	for (int32_t iy = minPosY; iy < maxPosYPlus1; iy += strideY)
	{
		iySector = iy / valuesPerSectorYDir;
		iiySector = iySector * numOfSectorsXDir;

		for (int32_t ix = minPosX; ix < maxPosXPlus1; ix += strideX)
		{
			ixSector = ix / valuesPerSectorXDir;

			if (pSectorDataArray[ixSector + iiySector] < 1.0f)
			{
				continue;
			}

			//numOfDetectionTests++;

			if (pDetectionBrain->Set_InputValues_UseLRFCenterPos(ix, iy, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY) == true)
			{
				pDetectionBrain->Execute_Calculations();

				//float outputValue;
				//pDetectionBrain->Get_OutputValues(&outputValue);

				float outputValue = pDetectionBrain->Get_OutputValue(0);

				if (outputValue > minActivationValue)
				{
					pOutPatternPosXArray[patternCounter] = static_cast<float>(ix);
					pOutPatternPosYArray[patternCounter] = static_cast<float>(iy);

					patternCounter++;
					patternCounter = min(patternCounter, numPatternPositionsMaxMinus1);
				}
			}
		}
	}

	*pOutPatternCount = static_cast<float>(patternCounter);
}

void Search_Pattern(float *pOutPatternCount, CSimpleFeatureMap *pInSectorMap, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CNeuralCalculationNet *pDetectionBrain, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float minActivationValue)
{
	int32_t numOfSectorsXDir = pInSectorMap->SizeX;
	int32_t numOfSectorsYDir = pInSectorMap->SizeY;

	int32_t valuesPerSectorXDir = inputMapSizeX / numOfSectorsXDir;
	int32_t valuesPerSectorYDir = inputMapSizeY / numOfSectorsYDir;

	float *pSectorDataArray = pInSectorMap->pDataArray;

	int32_t ixSector, iySector, iiySector;

	int32_t patternCounter = 0;

	//int32_t numOfDetectionTests = 0;

	for (int32_t iy = minPosY; iy < maxPosYPlus1; iy += strideY)
	{
		iySector = iy / valuesPerSectorYDir;
		iiySector = iySector * numOfSectorsXDir;

		for (int32_t ix = minPosX; ix < maxPosXPlus1; ix += strideX)
		{
			ixSector = ix / valuesPerSectorXDir;

			if (pSectorDataArray[ixSector + iiySector] < 1.0f)
			{
				continue;
			}

			//numOfDetectionTests++;

			if (pDetectionBrain->Set_InputValues_UseLRFCenterPos(ix, iy, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY) == true)
			{
				pDetectionBrain->Execute_Calculations();

				//float outputValue;
				//pDetectionBrain->Get_OutputValues(&outputValue);

				float outputValue = pDetectionBrain->Get_OutputValue(0);

				if (outputValue > minActivationValue)
				{
					patternCounter++;
				}
			}
		}
	}

	*pOutPatternCount = static_cast<float>(patternCounter);
}



void Search_Pattern(CSimpleFeatureMap *pOutFeatureMap, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CNeuralCalculationNet *pDetectionBrain, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float minActivationValue)
{
	int32_t featureMapSizeX = pOutFeatureMap->SizeX;
	int32_t featureMapSizeY = pOutFeatureMap->SizeY;

	int32_t invScaleX = inputMapSizeX / featureMapSizeX;
	int32_t invScaleY = inputMapSizeX / featureMapSizeY;

	int32_t patternCounter = 0;

	//int32_t numOfDetectionTests = 0;

	for (int32_t iy = minPosY; iy < maxPosYPlus1; iy += strideY)
	{
		int32_t iiy_FeatureMap = featureMapSizeX * iy / invScaleY;

		for (int32_t ix = minPosX; ix < maxPosXPlus1; ix += strideX)
		{
			//numOfDetectionTests++;

			if (pDetectionBrain->Set_InputValues_UseLRFCenterPos(ix, iy, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY) == true)
			{
				pDetectionBrain->Execute_Calculations();

				//float outputValue;
				//pDetectionBrain->Get_OutputValues(&outputValue);

				float outputValue = pDetectionBrain->Get_OutputValue(0);

				if (outputValue > minActivationValue)
				{
					pOutFeatureMap->pDataArray[ix / invScaleX + iiy_FeatureMap] = outputValue;
					patternCounter++;
				}
			}
		}
	}
}

void Search_Patterns(CSimpleFeatureMap *pOutFeatureMapArray, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CNeuralCalculationNet *pDetectionBrain, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float minActivationValue)
{
	int32_t numOfOutputValues = pDetectionBrain->NumOfOutputUnits;

	int32_t featureMapSizeX = pOutFeatureMapArray[0].SizeX;
	int32_t featureMapSizeY = pOutFeatureMapArray[0].SizeY;

	int32_t invScaleX = inputMapSizeX / featureMapSizeX;
	int32_t invScaleY = inputMapSizeX / featureMapSizeY;

	int32_t patternCounter = 0;

	//int32_t numOfDetectionTests = 0;

	for (int32_t iy = minPosY; iy < maxPosYPlus1; iy += strideY)
	{
		int32_t iiy_FeatureMap = featureMapSizeX * iy / invScaleY;

		for (int32_t ix = minPosX; ix < maxPosXPlus1; ix += strideX)
		{
			//numOfDetectionTests++;

			if (pDetectionBrain->Set_InputValues_UseLRFCenterPos(ix, iy, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY) == true)
			{
				pDetectionBrain->Execute_Calculations();

				int32_t id_FeatureMap = ix / invScaleX + iiy_FeatureMap;

				for (int32_t i = 0; i < numOfOutputValues; i++)
				{	
					float outputValue = pDetectionBrain->Get_OutputValue(i);

					if (outputValue > minActivationValue)
					{
						pOutFeatureMapArray[i].pDataArray[id_FeatureMap] = outputValue;
						patternCounter++;
					}
				}
			}
		}
	}
}

void Search_Patterns(CInt32OutputVector *pOutVectorArray, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CNeuralCalculationNet *pDetectionBrain, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float minActivationValue)
{
	int32_t numOfOutputValues = pDetectionBrain->NumOfOutputUnits;

	

	int32_t patternCounter = 0;

	//int32_t numOfDetectionTests = 0;

	for (int32_t iy = minPosY; iy < maxPosYPlus1; iy += strideY)
	{
		for (int32_t ix = minPosX; ix < maxPosXPlus1; ix += strideX)
		{
			//numOfDetectionTests++;

			if (pDetectionBrain->Set_InputValues_UseLRFCenterPos(ix, iy, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY) == true)
			{
				pDetectionBrain->Execute_Calculations();

				
				for (int32_t i = 0; i < numOfOutputValues; i++)
				{
					float outputValue = pDetectionBrain->Get_OutputValue(i);

					if (outputValue > minActivationValue)
					{
						int32_t vectorCounter = pOutVectorArray[i].PatternCounter;
						pOutVectorArray[i].pExternalPatternPosXArray[vectorCounter] = ix;
						pOutVectorArray[i].pExternalPatternPosYArray[vectorCounter] = iy;
						pOutVectorArray[i].PatternCounter++;
						patternCounter++;
					}
				}
			}
		}
	}
}

void Search_Patterns(CInt32OutputVector *pOutVectorArray, CSimpleFeatureMap *pInSectorMap, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CNeuralCalculationNet *pDetectionBrain, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float minActivationValue)
{
	int32_t numOfSectorsXDir = pInSectorMap->SizeX;
	int32_t numOfSectorsYDir = pInSectorMap->SizeY;

	int32_t valuesPerSectorXDir = inputMapSizeX / numOfSectorsXDir;
	int32_t valuesPerSectorYDir = inputMapSizeY / numOfSectorsYDir;

	float *pSectorDataArray = pInSectorMap->pDataArray;

	int32_t ixSector, iySector, iiySector;


	int32_t numOfOutputValues = pDetectionBrain->NumOfOutputUnits;

	int32_t patternCounter = 0;

	//int32_t numOfDetectionTests = 0;

	for (int32_t iy = minPosY; iy < maxPosYPlus1; iy += strideY)
	{
		iySector = iy / valuesPerSectorYDir;
		iiySector = iySector * numOfSectorsXDir;

		for (int32_t ix = minPosX; ix < maxPosXPlus1; ix += strideX)
		{
			ixSector = ix / valuesPerSectorXDir;

			if (pSectorDataArray[ixSector + iiySector] < 1.0f)
			{
				continue;
			}

			//numOfDetectionTests++;

			if (pDetectionBrain->Set_InputValues_UseLRFCenterPos(ix, iy, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY) == true)
			{
				pDetectionBrain->Execute_Calculations();


				for (int32_t i = 0; i < numOfOutputValues; i++)
				{
					float outputValue = pDetectionBrain->Get_OutputValue(i);

					if (outputValue > minActivationValue)
					{
						int32_t vectorCounter = pOutVectorArray[i].PatternCounter;
						pOutVectorArray[i].pExternalPatternPosXArray[vectorCounter] = ix;
						pOutVectorArray[i].pExternalPatternPosYArray[vectorCounter] = iy;
						pOutVectorArray[i].PatternCounter++;
						patternCounter++;
					}
				}
			}
		}
	}
}

void Search_Patterns(CFloatOutputVector *pOutVectorArray, CSimpleFeatureMap *pInSectorMap, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CNeuralCalculationNet *pDetectionBrain, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float minActivationValue)
{
	int32_t numOfSectorsXDir = pInSectorMap->SizeX;
	int32_t numOfSectorsYDir = pInSectorMap->SizeY;

	int32_t valuesPerSectorXDir = inputMapSizeX / numOfSectorsXDir;
	int32_t valuesPerSectorYDir = inputMapSizeY / numOfSectorsYDir;

	float *pSectorDataArray = pInSectorMap->pDataArray;

	int32_t ixSector, iySector, iiySector;


	int32_t numOfOutputValues = pDetectionBrain->NumOfOutputUnits;

	int32_t patternCounter = 0;

	//int32_t numOfDetectionTests = 0;

	for (int32_t iy = minPosY; iy < maxPosYPlus1; iy += strideY)
	{
		iySector = iy / valuesPerSectorYDir;
		iiySector = iySector * numOfSectorsXDir;

		for (int32_t ix = minPosX; ix < maxPosXPlus1; ix += strideX)
		{
			ixSector = ix / valuesPerSectorXDir;

			if (pSectorDataArray[ixSector + iiySector] < 1.0f)
			{
				continue;
			}

			//numOfDetectionTests++;

			if (pDetectionBrain->Set_InputValues_UseLRFCenterPos(ix, iy, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY) == true)
			{
				pDetectionBrain->Execute_Calculations();


				for (int32_t i = 0; i < numOfOutputValues; i++)
				{
					float outputValue = pDetectionBrain->Get_OutputValue(i);

					if (outputValue > minActivationValue)
					{
						int32_t vectorCounter = pOutVectorArray[i].PatternCounter;
						pOutVectorArray[i].pExternalPatternPosXArray[vectorCounter] = static_cast<float>(ix);
						pOutVectorArray[i].pExternalPatternPosYArray[vectorCounter] = static_cast<float>(iy);
						pOutVectorArray[i].PatternCounter++;
						patternCounter++;
					}
				}
			}
		}
	}
}

void Search_Patterns(CFloatOutputVector *pOutVectorArray, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CNeuralCalculationNet *pDetectionBrain, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float minActivationValue)
{
	int32_t numOfOutputValues = pDetectionBrain->NumOfOutputUnits;



	int32_t patternCounter = 0;

	//int32_t numOfDetectionTests = 0;

	for (int32_t iy = minPosY; iy < maxPosYPlus1; iy += strideY)
	{
		for (int32_t ix = minPosX; ix < maxPosXPlus1; ix += strideX)
		{
			//numOfDetectionTests++;

			if (pDetectionBrain->Set_InputValues_UseLRFCenterPos(ix, iy, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY) == true)
			{
				pDetectionBrain->Execute_Calculations();


				for (int32_t i = 0; i < numOfOutputValues; i++)
				{
					float outputValue = pDetectionBrain->Get_OutputValue(i);

					if (outputValue > minActivationValue)
					{
						int32_t vectorCounter = pOutVectorArray[i].PatternCounter;
						pOutVectorArray[i].pExternalPatternPosXArray[vectorCounter] = static_cast<float>(ix);
						pOutVectorArray[i].pExternalPatternPosYArray[vectorCounter] = static_cast<float>(iy);
						pOutVectorArray[i].PatternCounter++;
						patternCounter++;
					}
				}
			}
		}
	}
}


void Add_Patterns(CSimpleFeatureMap *pOutFeatureMapArray, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CNeuralCalculationNet *pDetectionBrain, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float minActivationValue)
{
	int32_t numOfOutputValues = pDetectionBrain->NumOfOutputUnits;

	int32_t featureMapSizeX = pOutFeatureMapArray[0].SizeX;
	int32_t featureMapSizeY = pOutFeatureMapArray[0].SizeY;

	int32_t invScaleX = inputMapSizeX / featureMapSizeX;
	int32_t invScaleY = inputMapSizeX / featureMapSizeY;

	int32_t patternCounter = 0;

	//int32_t numOfDetectionTests = 0;

	for (int32_t iy = minPosY; iy < maxPosYPlus1; iy += strideY)
	{
		int32_t iiy_FeatureMap = featureMapSizeX * iy / invScaleY;

		for (int32_t ix = minPosX; ix < maxPosXPlus1; ix += strideX)
		{
			//numOfDetectionTests++;

			if (pDetectionBrain->Set_InputValues_UseLRFCenterPos(ix, iy, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY) == true)
			{
				pDetectionBrain->Execute_Calculations();

				int32_t id_FeatureMap = ix / invScaleX + iiy_FeatureMap;

				for (int32_t i = 0; i < numOfOutputValues; i++)
				{
					float outputValue = pDetectionBrain->Get_OutputValue(i);

					if (outputValue > minActivationValue)
					{
						pOutFeatureMapArray[i].pDataArray[id_FeatureMap] += outputValue;
						patternCounter++;
					}
				}
			}
		}
	}
}

void Search_Pattern(CSimpleFeatureMap *pOutFeatureMap, CSimpleFeatureMap *pInSectorMap, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CNeuralCalculationNet *pDetectionBrain, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float minActivationValue)
{
	int32_t numOfSectorsXDir = pInSectorMap->SizeX;
	int32_t numOfSectorsYDir = pInSectorMap->SizeY;

	int32_t valuesPerSectorXDir = inputMapSizeX / numOfSectorsXDir;
	int32_t valuesPerSectorYDir = inputMapSizeY / numOfSectorsYDir;

	float *pSectorDataArray = pInSectorMap->pDataArray;

	int32_t ixSector, iySector, iiySector;


	int32_t featureMapSizeX = pOutFeatureMap->SizeX;
	int32_t featureMapSizeY = pOutFeatureMap->SizeY;

	int32_t invScaleX = inputMapSizeX / featureMapSizeX;
	int32_t invScaleY = inputMapSizeX / featureMapSizeY;

	int32_t patternCounter = 0;

	//int32_t numOfDetectionTests = 0;

	for (int32_t iy = minPosY; iy < maxPosYPlus1; iy += strideY)
	{
		iySector = iy / valuesPerSectorYDir;
		iiySector = iySector * numOfSectorsXDir;

		int32_t iiy_FeatureMap = featureMapSizeX * iy / invScaleY;

		for (int32_t ix = minPosX; ix < maxPosXPlus1; ix += strideX)
		{
			ixSector = ix / valuesPerSectorXDir;

			if (pSectorDataArray[ixSector + iiySector] < 1.0f)
			{
				continue;
			}

			//numOfDetectionTests++;

			if (pDetectionBrain->Set_InputValues_UseLRFCenterPos(ix, iy, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY) == true)
			{
				pDetectionBrain->Execute_Calculations();

				//float outputValue;
				//pDetectionBrain->Get_OutputValues(&outputValue);

				float outputValue = pDetectionBrain->Get_OutputValue(0);

				if (outputValue > minActivationValue)
				{
					pOutFeatureMap->pDataArray[ix / invScaleX + iiy_FeatureMap] = outputValue;
					patternCounter++;
				}
			}
		}
	}
}

void Search_Patterns(CSimpleFeatureMap *pOutFeatureMapArray, CSimpleFeatureMap *pInSectorMap, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CNeuralCalculationNet *pDetectionBrain, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float minActivationValue)
{
	int32_t numOfSectorsXDir = pInSectorMap->SizeX;
	int32_t numOfSectorsYDir = pInSectorMap->SizeY;

	int32_t valuesPerSectorXDir = inputMapSizeX / numOfSectorsXDir;
	int32_t valuesPerSectorYDir = inputMapSizeY / numOfSectorsYDir;

	float *pSectorDataArray = pInSectorMap->pDataArray;

	int32_t ixSector, iySector, iiySector;


	int32_t numOfOutputValues = pDetectionBrain->NumOfOutputUnits;

	int32_t featureMapSizeX = pOutFeatureMapArray[0].SizeX;
	int32_t featureMapSizeY = pOutFeatureMapArray[0].SizeY;

	int32_t invScaleX = inputMapSizeX / featureMapSizeX;
	int32_t invScaleY = inputMapSizeX / featureMapSizeY;

	int32_t patternCounter = 0;

	//int32_t numOfDetectionTests = 0;

	for (int32_t iy = minPosY; iy < maxPosYPlus1; iy += strideY)
	{
		iySector = iy / valuesPerSectorYDir;
		iiySector = iySector * numOfSectorsXDir;

		int32_t iiy_FeatureMap = featureMapSizeX * iy / invScaleY;

		for (int32_t ix = minPosX; ix < maxPosXPlus1; ix += strideX)
		{
			ixSector = ix / valuesPerSectorXDir;

			if (pSectorDataArray[ixSector + iiySector] < 1.0f)
			{
				continue;
			}

			//numOfDetectionTests++;

			if (pDetectionBrain->Set_InputValues_UseLRFCenterPos(ix, iy, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY) == true)
			{
				pDetectionBrain->Execute_Calculations();

				int32_t id_FeatureMap = ix / invScaleX + iiy_FeatureMap;

				for (int32_t i = 0; i < numOfOutputValues; i++)
				{
					float outputValue = pDetectionBrain->Get_OutputValue(i);

					if (outputValue > minActivationValue)
					{
						pOutFeatureMapArray[i].pDataArray[id_FeatureMap] = outputValue;
						patternCounter++;
					}
				}
			}
		}
	}
}

void Add_Patterns(CSimpleFeatureMap *pOutFeatureMapArray, CSimpleFeatureMap *pInSectorMap, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CNeuralCalculationNet *pDetectionBrain, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float minActivationValue)
{
	int32_t numOfSectorsXDir = pInSectorMap->SizeX;
	int32_t numOfSectorsYDir = pInSectorMap->SizeY;

	int32_t valuesPerSectorXDir = inputMapSizeX / numOfSectorsXDir;
	int32_t valuesPerSectorYDir = inputMapSizeY / numOfSectorsYDir;

	float *pSectorDataArray = pInSectorMap->pDataArray;

	int32_t ixSector, iySector, iiySector;


	int32_t numOfOutputValues = pDetectionBrain->NumOfOutputUnits;

	int32_t featureMapSizeX = pOutFeatureMapArray[0].SizeX;
	int32_t featureMapSizeY = pOutFeatureMapArray[0].SizeY;

	int32_t invScaleX = inputMapSizeX / featureMapSizeX;
	int32_t invScaleY = inputMapSizeX / featureMapSizeY;

	int32_t patternCounter = 0;

	//int32_t numOfDetectionTests = 0;

	for (int32_t iy = minPosY; iy < maxPosYPlus1; iy += strideY)
	{
		iySector = iy / valuesPerSectorYDir;
		iiySector = iySector * numOfSectorsXDir;

		int32_t iiy_FeatureMap = featureMapSizeX * iy / invScaleY;

		for (int32_t ix = minPosX; ix < maxPosXPlus1; ix += strideX)
		{
			ixSector = ix / valuesPerSectorXDir;

			if (pSectorDataArray[ixSector + iiySector] < 1.0f)
			{
				continue;
			}

			//numOfDetectionTests++;

			if (pDetectionBrain->Set_InputValues_UseLRFCenterPos(ix, iy, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY) == true)
			{
				pDetectionBrain->Execute_Calculations();

				int32_t id_FeatureMap = ix / invScaleX + iiy_FeatureMap;

				for (int32_t i = 0; i < numOfOutputValues; i++)
				{
					float outputValue = pDetectionBrain->Get_OutputValue(i);

					if (outputValue > minActivationValue)
					{
						pOutFeatureMapArray[i].pDataArray[id_FeatureMap] += outputValue;
						patternCounter++;
					}
				}
			}
		}
	}
}

void Add_Pattern(CSimpleFeatureMap *pOutFeatureMap, CSimpleFeatureMap *pInSectorMap, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CNeuralCalculationNet *pDetectionBrain, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float minActivationValue)
{
	int32_t numOfSectorsXDir = pInSectorMap->SizeX;
	int32_t numOfSectorsYDir = pInSectorMap->SizeY;

	int32_t valuesPerSectorXDir = inputMapSizeX / numOfSectorsXDir;
	int32_t valuesPerSectorYDir = inputMapSizeY / numOfSectorsYDir;

	float *pSectorDataArray = pInSectorMap->pDataArray;

	int32_t ixSector, iySector, iiySector;


	int32_t featureMapSizeX = pOutFeatureMap->SizeX;
	int32_t featureMapSizeY = pOutFeatureMap->SizeY;

	int32_t invScaleX = inputMapSizeX / featureMapSizeX;
	int32_t invScaleY = inputMapSizeX / featureMapSizeY;

	int32_t patternCounter = 0;

	//int32_t numOfDetectionTests = 0;

	for (int32_t iy = minPosY; iy < maxPosYPlus1; iy += strideY)
	{
		iySector = iy / valuesPerSectorYDir;
		iiySector = iySector * numOfSectorsXDir;

		int32_t iiy_FeatureMap = featureMapSizeX * iy / invScaleY;

		for (int32_t ix = minPosX; ix < maxPosXPlus1; ix += strideX)
		{
			ixSector = ix / valuesPerSectorXDir;

			if (pSectorDataArray[ixSector + iiySector] < 1.0f)
			{
				continue;
			}

			//numOfDetectionTests++;

			if (pDetectionBrain->Set_InputValues_UseLRFCenterPos(ix, iy, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY) == true)
			{
				pDetectionBrain->Execute_Calculations();

				//float outputValue;
				//pDetectionBrain->Get_OutputValues(&outputValue);

				float outputValue = pDetectionBrain->Get_OutputValue(0);

				if (outputValue > minActivationValue)
				{
					pOutFeatureMap->pDataArray[ix / invScaleX + iiy_FeatureMap] += outputValue;
					patternCounter++;
				}
			}
		}
	}
}

void Add_Pattern(CSimpleFeatureMap *pOutFeatureMap, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CNeuralCalculationNet *pDetectionBrain, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float minActivationValue)
{
	int32_t featureMapSizeX = pOutFeatureMap->SizeX;
	int32_t featureMapSizeY = pOutFeatureMap->SizeY;

	int32_t invScaleX = inputMapSizeX / featureMapSizeX;
	int32_t invScaleY = inputMapSizeX / featureMapSizeY;

	int32_t patternCounter = 0;

	//int32_t numOfDetectionTests = 0;

	for (int32_t iy = minPosY; iy < maxPosYPlus1; iy += strideY)
	{
		int32_t iiy_FeatureMap = featureMapSizeX * iy / invScaleY;

		for (int32_t ix = minPosX; ix < maxPosXPlus1; ix += strideX)
		{
			//numOfDetectionTests++;

			if (pDetectionBrain->Set_InputValues_UseLRFCenterPos(ix, iy, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY) == true)
			{
				pDetectionBrain->Execute_Calculations();

				//float outputValue;
				//pDetectionBrain->Get_OutputValues(&outputValue);

				float outputValue = pDetectionBrain->Get_OutputValue(0);

				if (outputValue > minActivationValue)
				{
					pOutFeatureMap->pDataArray[ix / invScaleX + iiy_FeatureMap] = outputValue;
					patternCounter++;
				}
			}
		}
	}
}

void Search_Pattern(float *pOutPatternCount, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CNeuralCalculationNet *pDetectionBrain, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float minActivationValue)
{

	int32_t patternCounter = 0;

	//int32_t numOfDetectionTests = 0;

	for (int32_t iy = minPosY; iy < maxPosYPlus1; iy += strideY)
	{
		for (int32_t ix = minPosX; ix < maxPosXPlus1; ix += strideX)
		{
			//numOfDetectionTests++;

			if (pDetectionBrain->Set_InputValues_UseLRFCenterPos(ix, iy, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY) == true)
			{
				pDetectionBrain->Execute_Calculations();

				//float outputValue;
				//pDetectionBrain->Get_OutputValues(&outputValue);

				float outputValue = pDetectionBrain->Get_OutputValue(0);

				if (outputValue > minActivationValue)
				{
					patternCounter++;
				}
			}
		}
	}

	*pOutPatternCount = static_cast<float>(patternCounter);
}

void Search_Pattern(int32_t *pOutPatternCount, int32_t *pOutPatternPosXArray, int32_t *pOutPatternPosYArray, int32_t numPatternPositionsMax, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CNeuralCalculationNet *pDetectionBrain, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float minActivationValue)
{
	int32_t numPatternPositionsMaxMinus1 = numPatternPositionsMax - 1;

	int32_t patternCounter = 0;

	//int32_t numOfDetectionTests = 0;

	for (int32_t iy = minPosY; iy < maxPosYPlus1; iy += strideY)
	{
		for (int32_t ix = minPosX; ix < maxPosXPlus1; ix += strideX)
		{
			//numOfDetectionTests++;

			if (pDetectionBrain->Set_InputValues_UseLRFCenterPos(ix, iy, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY) == true)
			{
				pDetectionBrain->Execute_Calculations();

				//float outputValue;
				//pDetectionBrain->Get_OutputValues(&outputValue);

				float outputValue = pDetectionBrain->Get_OutputValue(0);

				if (outputValue > minActivationValue)
				{
					pOutPatternPosXArray[patternCounter] = ix;
					pOutPatternPosYArray[patternCounter] = iy;

					patternCounter++;
					patternCounter = min(patternCounter, numPatternPositionsMaxMinus1);
				}
			}
		}
	}

	*pOutPatternCount = patternCounter;
}

void Search_Pattern(float *pOutPatternCount, float *pOutPatternPosXArray, float *pOutPatternPosYArray, int32_t numPatternPositionsMax, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CNeuralCalculationNet *pDetectionBrain, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float minActivationValue)
{
	int32_t numPatternPositionsMaxMinus1 = numPatternPositionsMax - 1;

	int32_t patternCounter = 0;

	//int32_t numOfDetectionTests = 0;

	for (int32_t iy = minPosY; iy < maxPosYPlus1; iy += strideY)
	{
		for (int32_t ix = minPosX; ix < maxPosXPlus1; ix += strideX)
		{
			//numOfDetectionTests++;

			if (pDetectionBrain->Set_InputValues_UseLRFCenterPos(ix, iy, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY) == true)
			{
				pDetectionBrain->Execute_Calculations();

				//float outputValue;
				//pDetectionBrain->Get_OutputValues(&outputValue);

				float outputValue = pDetectionBrain->Get_OutputValue(0);

				if (outputValue > minActivationValue)
				{
					pOutPatternPosXArray[patternCounter] = static_cast<float>(ix);
					pOutPatternPosYArray[patternCounter] = static_cast<float>(iy);

					patternCounter++;
					patternCounter = min(patternCounter, numPatternPositionsMaxMinus1);
				}
			}
		}
	}

	*pOutPatternCount = static_cast<float>(patternCounter);
}

