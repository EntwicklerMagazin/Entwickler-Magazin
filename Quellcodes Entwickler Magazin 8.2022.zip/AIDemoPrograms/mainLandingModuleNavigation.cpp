#pragma warning( disable: 4996)

#include <iostream>
//#include <chrono>
#include <omp.h>
#include <thread>
#include "ConsoleHelperFunctions.h"
#include "LogFile.h"
#include "NeuralCalculationNet.h"
#include "Physics.h"

using namespace std;
using namespace chrono;
using namespace HelperStuff;

#ifndef max
#define max(a,b)    ( ((a) > (b)) ? (a) : (b) )
#endif

#ifndef min
#define min(a,b)    ( ((a) < (b)) ? (a) : (b) )
#endif

#define KEYDOWN(vk_code) ((GetAsyncKeyState(vk_code) & 0x8000) ? 1 : 0)
#define KEYUP(vk_code)   ((GetAsyncKeyState(vk_code) & 0x8000) ? 0 : 1)

extern float g_AirFrictionConstant;

static constexpr int32_t ConstGameBoardSizeX = 140;
static constexpr int32_t ConstGameBoardSizeY = 100;

static constexpr float fConstGameBoardSizeX = 140.0f;
static constexpr float fConstGameBoardSizeY = 100.0f;

static constexpr int32_t ConstGameBoardSizeXMinus1 = 139;
static constexpr int32_t ConstGameBoardSizeYMinus1 = 99;

static constexpr float fConstGameBoardSizeXMinus1 = 139.0f;
static constexpr float fConstGameBoardSizeYMinus1 = 99.0f;

static constexpr float fConstGameBoardSizeXMinus2 = 138.0f;
static constexpr float fConstGameBoardSizeYMinus2 = 98.0f;


static void Reinitialization(CNeuralCalculationNetDesc* pInOutNetDesc, CRandomNumbersNN* pRandomNumbers, void* pParam)
{
	CEvolutionParameter_NeuralCalculationNet *pParameter = static_cast<CEvolutionParameter_NeuralCalculationNet*>(pParam);

	float minRandomPlasticity = pParameter->value1;
	float maxRandomPlasticity = pParameter->value2;

	int32_t numOfNeuralConnections = pInOutNetDesc->NumOfNeuralConnections;

	for (int32_t i = 0; i < numOfNeuralConnections; i++)
	{
		if (pInOutNetDesc->pConnectionStatusArray[i] == 0.0f)
			continue;

		pInOutNetDesc->pPlasticityValueArray[i] = pRandomNumbers->Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
	}

}

static void Mutation(CNeuralCalculationNetDesc* pInOutNetDesc, CRandomNumbersNN* pRandomNumbers, void* pParam)
{
	CEvolutionParameter_NeuralCalculationNet *pParameter = static_cast<CEvolutionParameter_NeuralCalculationNet*>(pParam);

	float minDeltaPlasticity = pParameter->value3;
	float maxDeltaPlasticity = pParameter->value4;
	float mutationRate = pParameter->value5;


	int32_t numOfNeuralConnections = pInOutNetDesc->NumOfNeuralConnections;

	for (int32_t i = 0; i < numOfNeuralConnections; i++)
	{
		if (pInOutNetDesc->pConnectionStatusArray[i] == 0.0f)
			continue;

		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
			continue;

		pInOutNetDesc->pPlasticityValueArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minDeltaPlasticity, maxDeltaPlasticity);
	}

}

static void Recombination(CNeuralCalculationNetDesc* pOffspring, const CNeuralCalculationNetDesc* pParent1, const CNeuralCalculationNetDesc* pParent2, CRandomNumbersNN* pRandomNumbers, void* pParam)
{
	CEvolutionParameter_NeuralCalculationNet *pParameter = static_cast<CEvolutionParameter_NeuralCalculationNet*>(pParam);

	float crossoverRate = pParameter->value6;

	int32_t numOfNeuralConnections = pOffspring->NumOfNeuralConnections;

	if (pRandomNumbers->Get_IntegerNumber2(1, 2) == 1)
	{
		for (int32_t i = 0; i < numOfNeuralConnections; i++)
		{
			if (pOffspring->pConnectionStatusArray[i] == 0.0f)
				continue;

			pOffspring->pPlasticityValueArray[i] = pParent1->pPlasticityValueArray[i];
		}
	}
	else
	{
		for (int32_t i = 0; i < numOfNeuralConnections; i++)
		{
			if (pOffspring->pConnectionStatusArray[i] == 0.0f)
				continue;

			pOffspring->pPlasticityValueArray[i] = pParent2->pPlasticityValueArray[i];
		}
	}

	for (int32_t i = 0; i < numOfNeuralConnections; i++)
	{
		if (pOffspring->pConnectionStatusArray[i] == 0.0f)
			continue;

		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > crossoverRate)
			continue;

		float weight1 = pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f);
		float weight2 = 1.0f - weight1;

		pOffspring->pPlasticityValueArray[i] = weight1 * pParent1->pPlasticityValueArray[i] + weight2 * pParent2->pPlasticityValueArray[i];
	}
}



/*
int main(void)
{
	Begin_Log(0, "Begin Log", "LogFile.txt");

	int32_t numCpuCores = omp_get_num_procs();
	int32_t maxThreads = omp_get_max_threads();

	Add_To_Log(0, "numCpuCores", numCpuCores);
	Add_To_Log(0, "maxThreads", maxThreads);

	CRandomNumbersNN RandomNumbers;

	CWindowsConsoleScreenBuffer WinConsole;
	WinConsole.Initialize(ConstGameBoardSizeX, ConstGameBoardSizeY, false, BackgroundColor);

	Set_Title("Landing Module Navigation (neuro-evolution running ... )");
	Set_ConsolePos(10, 10);

	WinConsole.Set_CursorVisibilityAndSize(FALSE);
	//WinConsole.Set_Font(L"Consolas", 15, 15);
	WinConsole.Set_Font(L"Consolas", 4, 4);
	//WinConsole.Set_Font(L"Consolas", 8, 8);
	//WinConsole.Set_Font_Ext(L"Consolas", 90, 10, 10);


	//WinConsole.Set_BackgroundColor(RGB(100, 50, 25));
	WinConsole.Set_BackgroundColor(BackgroundColor);

	Set_CursorVisibilityAndSize(false);

	CWindowsConsole2DObject LandingPlatform;
	LandingPlatform.Initialize(7, 7);

	LandingPlatform.Set_Pixel(1, 0, lightred);
	LandingPlatform.Set_Pixel(5, 0, lightred);
	LandingPlatform.Set_Pixel(2, 1, lightred);
	LandingPlatform.Set_Pixel(4, 1, lightred);
	LandingPlatform.Set_Pixel(3, 2, lightred);
	LandingPlatform.Set_Pixel(2, 3, lightred);
	LandingPlatform.Set_Pixel(4, 3, lightred);
	LandingPlatform.Set_Pixel(1, 4, lightred);
	LandingPlatform.Set_Pixel(5, 4, lightred);
	LandingPlatform.Set_Pixel(0, 6, graywhite);
	LandingPlatform.Set_Pixel(1, 6, graywhite);
	LandingPlatform.Set_Pixel(2, 6, graywhite);
	LandingPlatform.Set_Pixel(3, 6, graywhite);
	LandingPlatform.Set_Pixel(4, 6, graywhite);
	LandingPlatform.Set_Pixel(5, 6, graywhite);
	LandingPlatform.Set_Pixel(6, 6, graywhite);

	CWindowsConsole2DObject LaunchingPlatform;
	LaunchingPlatform.Initialize(7, 7);

	LaunchingPlatform.Set_Pixel(3, 0, lightaqua);
	LaunchingPlatform.Set_Pixel(2, 1, lightaqua);
	LaunchingPlatform.Set_Pixel(4, 1, lightaqua);
	LaunchingPlatform.Set_Pixel(1, 2, lightaqua);
	LaunchingPlatform.Set_Pixel(5, 2, lightaqua);
	LaunchingPlatform.Set_Pixel(3, 3, lightaqua);
	LaunchingPlatform.Set_Pixel(3, 4, lightaqua);
	LaunchingPlatform.Set_Pixel(3, 5, lightaqua);
	LaunchingPlatform.Set_Pixel(0, 6, graywhite);
	LaunchingPlatform.Set_Pixel(1, 6, graywhite);
	LaunchingPlatform.Set_Pixel(2, 6, graywhite);
	LaunchingPlatform.Set_Pixel(3, 6, graywhite);
	LaunchingPlatform.Set_Pixel(4, 6, graywhite);
	LaunchingPlatform.Set_Pixel(5, 6, graywhite);
	LaunchingPlatform.Set_Pixel(6, 6, graywhite);

	CWindowsConsole2DObject LandingModule;
	LandingModule.Initialize(5, 5);

	LandingModule.Set_Pixel(2, 0, lightgreen);
	LandingModule.Set_Pixel(1, 1, lightgreen);
	LandingModule.Set_Pixel(2, 1, lightgreen);
	LandingModule.Set_Pixel(3, 1, lightgreen);

	LandingModule.Set_Pixel(0, 2, lightgreen);
	LandingModule.Set_Pixel(1, 2, lightgreen);
	LandingModule.Set_Pixel(2, 2, lightgreen);
	LandingModule.Set_Pixel(3, 2, lightgreen);
	LandingModule.Set_Pixel(4, 2, lightgreen);

	LandingModule.Set_Pixel(0, 3, lightgreen);
	LandingModule.Set_Pixel(1, 3, graywhite);
	LandingModule.Set_Pixel(2, 3, lightred);
	LandingModule.Set_Pixel(3, 3, graywhite);
	LandingModule.Set_Pixel(4, 3, lightgreen);

	LandingModule.Set_Pixel(1, 4, graywhite);
	LandingModule.Set_Pixel(3, 4, graywhite);

	
	float MaxToleratedLandingVelocityAmountSq = 0.5f;
	float MaxToleratedTargetDistanceSq = 0.5f;

	float FuelCapacityMax = 100.0f;
	float ActualFuelCapacity;

	// fuel consumption per flight maneuver
	float FuelConsumptionX = 0.001f;
	float FuelConsumptionY = 0.001f;

	// maneuver-accelerationY must be greater than gravitation-accelerationY!!
	//float ManeuverAccelerationX = 100.0f;
	//float ManeuverAccelerationY = 100.0f;

	float ManeuverAccelerationX = 50.0f;
	float ManeuverAccelerationY = 50.0f;

	float GravitationAccelerationX = 0.0f;
	float GravitationAccelerationY = 20.0f;

	int32_t iStartPosXMin = 10;
	int32_t iStartPosXMax = 120;

	int32_t iStartPosYMin = 10;
	int32_t iStartPosYMax = 30;

	int32_t iTargetPosXMin = 10;
	int32_t iTargetPosXMax = 130;

	int32_t iTargetPosYMin = 70;
	int32_t iTargetPosYMax = 90;

	float InitalVelocityXMin = -20.0f;
	float InitalVelocityXMax = 20.0f;

	float InitalVelocityYMin = -5.0f;
	float InitalVelocityYMax = 5.0f;

	int32_t iStartPosX, iStartPosY;
	int32_t iTargetPosX, iTargetPosY;

	float StartPosX, StartPosY;
	float TargetPosX, TargetPosY;
	float InitalVelocityX, InitalVelocityY;

	
	

	CSimplePhysicsObject LandingModulePhysicsObject;

	
	float minRandomPlasticity = -2.0f;
	float maxRandomPlasticity = 2.0f;

	float minDeltaPlasticity = -0.0001f;
	float maxDeltaPlasticity = 0.0001f;

	float mutationRate = 0.25f;
	float crossoverRate = 0.5f;

	
	int32_t NumOfHiddenUnitsL1 = 10;
	int32_t NumOfHiddenUnitsL2 = 0;
	
	//int32_t NumOfHiddenUnitsL1 = 10;
	//int32_t NumOfHiddenUnitsL2 = 10;

	CEvolutionParameter_NeuralCalculationNet EvolutionParameter;
	EvolutionParameter.value1 = minRandomPlasticity;
	EvolutionParameter.value2 = maxRandomPlasticity;
	EvolutionParameter.value3 = minDeltaPlasticity;
	EvolutionParameter.value4 = maxDeltaPlasticity;
	EvolutionParameter.value5 = mutationRate;
	EvolutionParameter.value6 = crossoverRate;

	CLandingModuleNavigationAI LandingModuleNavigationAI;
	
	if(NumOfHiddenUnitsL2 == 0)
		LandingModuleNavigationAI.Initialize(NumOfHiddenUnitsL1, minRandomPlasticity, maxRandomPlasticity);
	else
		LandingModuleNavigationAI.Initialize(NumOfHiddenUnitsL1, NumOfHiddenUnitsL2, minRandomPlasticity, maxRandomPlasticity);
	
	// Maneuver: nothing / up / down / right / left
	static constexpr int32_t NumOfOutputUnits = LandingModuleNavigationAI.NumOfOutputUnits;

	// neuro-evolution running

	float simulationTimeStep = 0.015f;
	

	CNeuralCalculationNetDesc BestEvolvedCalculationNetDesc;
	LandingModuleNavigationAI.Readout_CalculationNetData(&BestEvolvedCalculationNetDesc);

	static constexpr int32_t TrainingPopulationSize = 200;
	static constexpr int32_t NumTrainingGenerationsMax = 400;
	//static constexpr int32_t NumTrainingGenerationsMax = 100;

	static constexpr int32_t NumTrainingGamesPerGeneration = 20;
	static constexpr int32_t NumSimpleMutationGenerations = 20;

	static CNeuralCalculationNetDesc CalculationNetDescArray[TrainingPopulationSize];

	CNeuralCalculationNetDescPopulation CalculationNetDescPopulation;
	CalculationNetDescPopulation.Initialize(TrainingPopulationSize);

	for (int32_t i = 0; i < TrainingPopulationSize; i++)
	{
		LandingModuleNavigationAI.Readout_CalculationNetData(&CalculationNetDescArray[i]);
		Reinitialization(&CalculationNetDescArray[i], &RandomNumbers, &EvolutionParameter);

		CalculationNetDescPopulation.Set_NeuralCalculationNetDesc(&CalculationNetDescArray[i], i);
	}

	static CSimplePhysicsObject TrainingLandingModulePhysicsObject[4];
	static CLandingModuleNavigationAI TrainingLandingModuleNavigationAIArray[4];

	for (int32_t i = 0; i < 4; i++)
	{
		if (NumOfHiddenUnitsL2 == 0)
			TrainingLandingModuleNavigationAIArray[i].Initialize(NumOfHiddenUnitsL1, minRandomPlasticity, maxRandomPlasticity);
		else
			TrainingLandingModuleNavigationAIArray[i].Initialize(NumOfHiddenUnitsL1, NumOfHiddenUnitsL2, minRandomPlasticity, maxRandomPlasticity);
	}

	
	RandomNumbers.Change_Seed(10);

	
	for (int32_t j = 0; j < NumTrainingGenerationsMax; j++)
	{
		CalculationNetDescPopulation.Reset_MinErrorSum_ActualGeneration();

		for (int32_t i = 0; i < TrainingPopulationSize; i++)
		{
			CalculationNetDescPopulation.Set_FitnessScore(i, 0.0f);
		}

		//RandomNumbers.Change_Seed(10);

		for (int32_t k = 0; k < NumTrainingGamesPerGeneration; k++)
		{
			// start training game:

			int32_t iStartPosX = RandomNumbers.Get_IntegerNumber2(iStartPosXMin, iStartPosXMax);
			int32_t iStartPosY = RandomNumbers.Get_IntegerNumber2(iStartPosYMin, iStartPosYMax);

			int32_t iTargetPosX = RandomNumbers.Get_IntegerNumber2(iTargetPosXMin, iTargetPosXMax);
			int32_t iTargetPosY = RandomNumbers.Get_IntegerNumber2(iTargetPosYMin, iTargetPosYMax);

			float startPosX = static_cast<float>(iStartPosX);
			float startPosY = static_cast<float>(iStartPosY);
			float targetPosX = static_cast<float>(iTargetPosX);
			float targetPosY = static_cast<float>(iTargetPosY);

			float initalVelocityX = RandomNumbers.Get_FloatNumber_IncludingZero(InitalVelocityXMin, InitalVelocityXMax);
			float initalVelocityY = RandomNumbers.Get_FloatNumber_IncludingZero(InitalVelocityYMin, InitalVelocityYMax);

			
#pragma omp parallel for num_threads(4)
			for (int32_t i = 0; i < TrainingPopulationSize; i++)
			{
				int32_t threadID = omp_get_thread_num();

				CSimplePhysicsObject* pLandingModulePhysicsObject = &TrainingLandingModulePhysicsObject[threadID];
				CLandingModuleNavigationAI* pLandingModuleNavigationAI = &TrainingLandingModuleNavigationAIArray[threadID];

				pLandingModuleNavigationAI->Modify_CalculationNet(&CalculationNetDescArray[i]);

				float actualFuelCapacity = FuelCapacityMax;

				pLandingModulePhysicsObject->Reset_Values();

				pLandingModulePhysicsObject->VelX_LastFrame = initalVelocityX;
				pLandingModulePhysicsObject->VelY_LastFrame = initalVelocityY;
				pLandingModulePhysicsObject->VelX = initalVelocityX;
				pLandingModulePhysicsObject->VelY = initalVelocityY;

				pLandingModulePhysicsObject->PosX = startPosX;
				pLandingModulePhysicsObject->PosY = startPosY;


			

				float outputData[NumOfOutputUnits];

				uint32_t counter = 0;

				int32_t TrainingGameLength = 400;

				bool LandingFailure = false;

				do
				{

					pLandingModuleNavigationAI->Calculate_PossibleCourseCorrection(outputData, pLandingModulePhysicsObject, targetPosX, targetPosY);

					float maxOutputValue = -100000.0f;
					int32_t belongingArrayID = 0;

					for (int32_t ii = 0; ii < NumOfOutputUnits; ii++)
					{
						if (outputData[ii] > maxOutputValue)
						{
							maxOutputValue = outputData[ii];
							belongingArrayID = ii;
						}
					}

					pLandingModulePhysicsObject->AccelX = GravitationAccelerationX;
					pLandingModulePhysicsObject->AccelY = GravitationAccelerationY;

					if (belongingArrayID != 0)
					{
						if (outputData[1] > outputData[2] && outputData[1] > 0.0f)
						{
							pLandingModulePhysicsObject->AccelY += outputData[1] * ManeuverAccelerationY;
							actualFuelCapacity -= outputData[1] * FuelConsumptionY;
						}
						else if (outputData[2] > outputData[1] && outputData[2] > 0.0f)
						{
							pLandingModulePhysicsObject->AccelY -= outputData[2] * ManeuverAccelerationY;
							actualFuelCapacity -= outputData[2] * FuelConsumptionY;
						}

						if (outputData[3] > outputData[4] && outputData[3] > 0.0f)
						{
							pLandingModulePhysicsObject->AccelX += outputData[3] * ManeuverAccelerationX;
							actualFuelCapacity -= outputData[3] * FuelConsumptionX;
						}
						else if (outputData[4] > outputData[3] && outputData[4] > 0.0f)
						{
							pLandingModulePhysicsObject->AccelX -= outputData[4] * ManeuverAccelerationX;
							actualFuelCapacity -= outputData[4] * FuelConsumptionX;
						}
					}

					
					pLandingModulePhysicsObject->Update(simulationTimeStep);

					

					// Wenn sich das Raumfahrzeug unterhalb der Landeplattform befindet, gilt der Landevorgang als gescheitert: 
					if (pLandingModulePhysicsObject->PosY > targetPosY)
					{
						LandingFailure = true;
						break;
					}

					float distXSq = pLandingModulePhysicsObject->PosX - targetPosX;
					distXSq *= distXSq;

					float distYSq = pLandingModulePhysicsObject->PosY - targetPosY;
					distYSq *= distYSq;

					float distSq = distXSq + distYSq;

					if (distSq < MaxToleratedTargetDistanceSq && (pLandingModulePhysicsObject->VelX * pLandingModulePhysicsObject->VelX + pLandingModulePhysicsObject->VelY * pLandingModulePhysicsObject->VelY) < MaxToleratedLandingVelocityAmountSq)
						break;

					
					if (actualFuelCapacity < 2.0f * max(FuelConsumptionX, FuelConsumptionY))
					{
						LandingFailure = true;
						break;
					}

					counter++;

					if (counter > TrainingGameLength)
					{
						//LandingFailure = true;
						break;
					}

				} while (true);

				float fitnessScore = 0.0f;

				if (LandingFailure == false)
				{
					float distXSq = pLandingModulePhysicsObject->PosX - targetPosX;
					distXSq *= distXSq;

					float distYSq = pLandingModulePhysicsObject->PosY - targetPosY;
					distYSq *= distYSq;

					float restFuelCapacitySq = FuelCapacityMax - actualFuelCapacity;
					restFuelCapacitySq *= restFuelCapacitySq;

					fitnessScore += exp(-0.1f * (distXSq + distYSq));
					fitnessScore += (1.0f - exp(-0.01f * restFuelCapacitySq));
				}

				CalculationNetDescPopulation.Add_FitnessScore(i, fitnessScore);

			} // end of for (int32_t i = 0; i < TrainingPopulationSize; i++)
		} // end of for (int32_t k = 0; k < NumTrainingGamesPerGeneration; k++)

		for (int32_t i = 0; i < TrainingPopulationSize; i++)
		{
			CalculationNetDescPopulation.Update_MinErrorSum_ActualGeneration(CalculationNetDescPopulation.Calculate_Error_From_FitnessScore(i));
		}

		CalculationNetDescPopulation.Update_Population();


		//if (CalculationNetDescPopulation.MinErrorSum_ActualGeneration < 0.0001f)
			//break;


		CalculationNetDescPopulation.Update_BaseEvolution(Mutation, &EvolutionParameter);
		CalculationNetDescPopulation.Update_Evolution_BestBrainOnly(Mutation, &EvolutionParameter);
		CalculationNetDescPopulation.Update_Evolution_SecondBestBrainOnly(Mutation, &EvolutionParameter);

		if (j < NumSimpleMutationGenerations)
			continue;

		CalculationNetDescPopulation.Update_Evolution_Combine_BestTwoBrains(Recombination, &EvolutionParameter);
		CalculationNetDescPopulation.Update_Evolution_Combine_TwoBrains(Recombination, &EvolutionParameter);
		CalculationNetDescPopulation.Update_Evolution_Combine_TwoBrains(Recombination, &EvolutionParameter);
		CalculationNetDescPopulation.Replace_WorstFitted_Brain(Reinitialization, &EvolutionParameter);
		CalculationNetDescPopulation.Replace_SecondWorstFitted_Brain(Reinitialization, &EvolutionParameter);
		CalculationNetDescPopulation.Replace_ThirdWorstFitted_Brain(Reinitialization, &EvolutionParameter);	

	} // end of for (int32_t j = 0; j < NumTrainingGenerationsMax; j++)


	CalculationNetDescPopulation.Get_Best_Evolved_NeuralCalculationNetDesc(&BestEvolvedCalculationNetDesc);


	LandingModuleNavigationAI.Modify_CalculationNet(&BestEvolvedCalculationNetDesc);

	RandomNumbers.Change_Seed(10);

	//neuro-evolution completed

	Set_Title("LandingModuleNavigation (SPACE: Fire, ESC: Exit)");

	//char strBuffer[100];

	float FrameTime = 1.0f;
	float FrameRate = 1.0f;

	RandomNumbers.Change_Seed(10);


	iStartPosX = RandomNumbers.Get_IntegerNumber2(iStartPosXMin, iStartPosXMax);
	iStartPosY = RandomNumbers.Get_IntegerNumber2(iStartPosYMin, iStartPosYMax);

	iTargetPosX = RandomNumbers.Get_IntegerNumber2(iTargetPosXMin, iTargetPosXMax);
	iTargetPosY = RandomNumbers.Get_IntegerNumber2(iTargetPosYMin, iTargetPosYMax);

	StartPosX = static_cast<float>(iStartPosX);
	StartPosY = static_cast<float>(iStartPosY);
	TargetPosX = static_cast<float>(iTargetPosX);
	TargetPosY = static_cast<float>(iTargetPosY);

	InitalVelocityX = RandomNumbers.Get_FloatNumber_IncludingZero(InitalVelocityXMin, InitalVelocityXMax);
	InitalVelocityY = RandomNumbers.Get_FloatNumber_IncludingZero(InitalVelocityYMin, InitalVelocityYMax);

	LandingModulePhysicsObject.Reset_Values();

	LandingModulePhysicsObject.VelX_LastFrame = InitalVelocityX;
	LandingModulePhysicsObject.VelY_LastFrame = InitalVelocityY;
	LandingModulePhysicsObject.VelX = InitalVelocityX;
	LandingModulePhysicsObject.VelY = InitalVelocityY;

	LandingModulePhysicsObject.PosX = StartPosX;
	LandingModulePhysicsObject.PosY = StartPosY;

	ActualFuelCapacity = FuelCapacityMax;
	

	float outputData[NumOfOutputUnits];

	int32_t counter = 0;

	do
	{
		if (KEYDOWN(VK_ESCAPE) == true)
			break;

		//auto last_timepoint = std::chrono::steady_clock::now();
		auto last_timepoint = steady_clock::now();

		LandingModuleNavigationAI.Calculate_PossibleCourseCorrection(outputData, &LandingModulePhysicsObject, TargetPosX, TargetPosY);

		float maxOutputValue = -100000.0f;
		int32_t belongingArrayID = 0;

		for (int32_t i = 0; i < LandingModuleNavigationAI.NumOfOutputUnits; i++)
		{
			if (outputData[i] > maxOutputValue)
			{
				maxOutputValue = outputData[i];
				belongingArrayID = i;
			}
		}

		LandingModulePhysicsObject.AccelX = GravitationAccelerationX;
		LandingModulePhysicsObject.AccelY = GravitationAccelerationY;

		if (belongingArrayID != 0)
		{
			if (outputData[1] > outputData[2] && outputData[1] > 0.0f)
			{
				LandingModulePhysicsObject.AccelY += outputData[1] * ManeuverAccelerationY;
				ActualFuelCapacity -= outputData[1] * FuelConsumptionY;
			}
			else if (outputData[2] > outputData[1] && outputData[2] > 0.0f)
			{
				LandingModulePhysicsObject.AccelY -= outputData[2] * ManeuverAccelerationY;
				ActualFuelCapacity -= outputData[2] * FuelConsumptionY;
			}

			if (outputData[3] > outputData[4] && outputData[3] > 0.0f)
			{
				LandingModulePhysicsObject.AccelX += outputData[3] * ManeuverAccelerationX;
				ActualFuelCapacity -= outputData[3] * FuelConsumptionX;
			}
			else if (outputData[4] > outputData[3] && outputData[4] > 0.0f)
			{
				LandingModulePhysicsObject.AccelX -= outputData[4] * ManeuverAccelerationX;
				ActualFuelCapacity -= outputData[4] * FuelConsumptionX;
			}
		}

		LandingModulePhysicsObject.Update(simulationTimeStep);

		WinConsole.Clear_BackBuffer();

		int32_t posX_Left = iTargetPosX - LandingPlatform.NumCharactersPerRow / 2;
		int32_t posY_Top = iTargetPosY - LandingPlatform.NumCharactersPerColumn / 2;

		WinConsole.Draw_2DObject_Into_BackBuffer(posX_Left, posY_Top, LandingPlatform.pDataArray, LandingPlatform.NumCharactersPerRow, LandingPlatform.NumCharactersPerColumn);


		posX_Left = LandingModulePhysicsObject.PosX - LandingModule.NumCharactersPerRow / 2;
		posY_Top = LandingModulePhysicsObject.PosY - LandingModule.NumCharactersPerColumn / 2;

		WinConsole.Draw_2DObject_Into_BackBuffer(posX_Left, posY_Top, LandingModule.pDataArray, LandingModule.NumCharactersPerRow, LandingModule.NumCharactersPerColumn);

		WinConsole.Present_BackBuffer();

		counter++;

		if (GetAsyncKeyState(VK_SPACE) || GetAsyncKeyState(VK_RETURN) || counter > 400)
		{
			counter = 0;

			iStartPosX = RandomNumbers.Get_IntegerNumber2(iStartPosXMin, iStartPosXMax);
			iStartPosY = RandomNumbers.Get_IntegerNumber2(iStartPosYMin, iStartPosYMax);

			iTargetPosX = RandomNumbers.Get_IntegerNumber2(iTargetPosXMin, iTargetPosXMax);
			iTargetPosY = RandomNumbers.Get_IntegerNumber2(iTargetPosYMin, iTargetPosYMax);

			StartPosX = static_cast<float>(iStartPosX);
			StartPosY = static_cast<float>(iStartPosY);
			TargetPosX = static_cast<float>(iTargetPosX);
			TargetPosY = static_cast<float>(iTargetPosY);

			InitalVelocityX = RandomNumbers.Get_FloatNumber_IncludingZero(InitalVelocityXMin, InitalVelocityXMax);
			InitalVelocityY = RandomNumbers.Get_FloatNumber_IncludingZero(InitalVelocityYMin, InitalVelocityYMax);

			LandingModulePhysicsObject.Reset_Values();

			LandingModulePhysicsObject.VelX_LastFrame = InitalVelocityX;
			LandingModulePhysicsObject.VelY_LastFrame = InitalVelocityY;
			LandingModulePhysicsObject.VelX = InitalVelocityX;
			LandingModulePhysicsObject.VelY = InitalVelocityY;

			LandingModulePhysicsObject.PosX = StartPosX;
			LandingModulePhysicsObject.PosY = StartPosY;

			ActualFuelCapacity = FuelCapacityMax;
		}

		//Frame-Bremse:

		auto current_timepoint = steady_clock::now();

		//while (current_timepoint - last_timepoint < 250ms)
		//while (current_timepoint - last_timepoint < 50ms)
		while (current_timepoint - last_timepoint < 16ms)
			//while (current_timepoint - last_timepoint < 16666us) // 16.7 Millisekunden (ms)  bzw. 16666 Mikrosekunden (us): maximal 60 Frames pro Sekunde					
		{
			current_timepoint = steady_clock::now();
		}

		FrameTime = 0.000000001f * (current_timepoint - last_timepoint).count();
		FrameRate = 1.0f / FrameTime;

	} while (true);

	WinConsole.Clear_BackBuffer();
	WinConsole.Present_BackBuffer();
	WinConsole.CleanUp();

	Set_CursorVisibilityAndSize(true);
	Reset_CursorPos();
	Set_CursorPos(0, 0);

	cout << "bye bye (Press Return)" << endl;
	getchar();
	Add_To_Log(0, "bye bye");
	return 0;
}
*/




