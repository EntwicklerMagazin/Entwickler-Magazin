// Schutz vor Mehrfachdeklarationen:
#ifndef _GravitationSamples_H_
#define _GravitationSamples_H_

#include <iostream>
#include "ConsoleHelperFunctions.h"
#include "RandomNumbers.h"
#include "NeuralNet.h"
#include "LogFile.h"




#ifndef max
#define max(a,b)    ( ((a) > (b)) ? (a) : (b) )
#endif

#ifndef min
#define min(a,b)    ( ((a) < (b)) ? (a) : (b) )
#endif

extern float g_AirFrictionConstant;


static constexpr int32_t ConstGameBoardSizeX = 140;
static constexpr int32_t ConstGameBoardSizeY = 100;


static constexpr float fConstGameBoardSizeX = 140.0f;
static constexpr float fConstGameBoardSizeY = 100.0f;

static constexpr int32_t ConstGameBoardSizeXMinus1 = 139;
static constexpr int32_t ConstGameBoardSizeYMinus1 = 99;

static constexpr float fConstGameBoardSizeXMinus1 = 139.0f;
static constexpr float fConstGameBoardSizeYMinus1 = 99.0f;

static constexpr float fConstGameBoardSizeXMinus2 = 138.0f;
static constexpr float fConstGameBoardSizeYMinus2 = 98.0f;

inline float SigmoidOutput(float neuronInput)
{
	// von 0.0f bis 1.0f:
	return 1.0f / (1.0f + exp(-neuronInput));
}

inline float TanHOutput(float neuronInput)
{
	// von -1.0f bis 1.0f:
	//return tanh(neuronInput);
	return tanh(0.5f*neuronInput);
}

inline float FastTanHReplacementOutput(float neuronInput)
{
	// von -1.0f bis 1.0f:
	return neuronInput / (1.0f + abs(neuronInput));
}


inline float LinearOutput(float neuronInput)
{
	return neuronInput;
}

inline float NegLinearOutput(float neuronInput)
{
	return -neuronInput;
}

/*
inline float QuadraticOutput(float neuronInput)
{
	return neuronInput * neuronInput;
}


inline float CubicOutput(float neuronInput)
{
	return neuronInput * neuronInput * neuronInput;
}

inline float QuarticOutput(float neuronInput)
{
	return neuronInput * neuronInput * neuronInput * neuronInput;
}

inline float QuinticOutput(float neuronInput)
{
	return neuronInput * neuronInput * neuronInput * neuronInput * neuronInput;
}
*/

inline float SqrtOutput(float neuronInput)
{
	if (neuronInput < 0.0f)
		return 0.0f;

	return sqrt(neuronInput);
}



inline float InvLinearOutput(float neuronInput)
{
	if (neuronInput == 0.0f)
		neuronInput = 0.00001f;

	return 1.0f / neuronInput;
}

inline float ReLUOutput(float neuronInput)
{
	// von 0.0f bis unendlich:
	return max(0.0f, neuronInput);
}


inline float BinaryOutput(float neuronInput)
{
	//if (neuronInput > 0.9999f)
	//return 1.0f;

	// less accuracy
	if (neuronInput > 0.9f)
		return 1.0f;

	return 0.0f;
}

inline float DampenedLinearOutput(float neuronInput)
{
	return 0.5f*neuronInput;
}




class CSimplePhysicsObject
{
public:

	float mass;

	// Position:
	float posX, posY, posZ;
	float dposX, dposY, dposZ;

	// Geschwindigkeit (Velocity):
	float velX, velY, velZ;
	float velX_LastFrame, velY_LastFrame, velZ_LastFrame;
	float velX_LastFrame2, velY_LastFrame2, velZ_LastFrame2;
	float dvelX, dvelY, dvelZ;

	// Beschleunigung (Acceleration):
	float accelX, accelY, accelZ;

	CSimplePhysicsObject();
	~CSimplePhysicsObject();

	// Kopierkonstruktor l�schen: 
	CSimplePhysicsObject(const CSimplePhysicsObject &originalObject) = delete;

	// �berladenen Zuweisungsoperator l�schen: 
	CSimplePhysicsObject operator=(const CSimplePhysicsObject &originalObject) = delete;

	void Reset_Values(void);
	void Update(float timeStep);
};

class CArtilleryAI
{
public:

	CNeuralNet Brain;

	static constexpr uint32_t NumOfInputNeurons = 4;
	static constexpr uint32_t NumOfOutputNeurons = 2;

	CArtilleryAI();
	~CArtilleryAI();

	// Kopierkonstruktor l�schen: 
	CArtilleryAI(const CArtilleryAI &originalObject) = delete;

	// �berladenen Zuweisungsoperator l�schen: 
	CArtilleryAI operator=(const CArtilleryAI &originalObject) = delete;

	void Initialize(uint32_t numOfHiddenNeuronsL1, uint32_t numOfHiddenNeuronsL2);

	void Calculate_FiringSolution(float *pOutVelocityX, float *pOutVelocityY, float startPosX, float startPosY, float targetPosX, float targetPosY, float gravitationAccelerationX, float gravitationAccelerationY, float velocityScaleX = 100.0f, float velocityScaleY = 100.0f);
};

class CArtilleryAIPopulation
{
public:

	uint64_t Seed = 1;
	CRandomNumbersNN RandomNumbers;

	uint32_t PopulationSize;
	uint32_t PopulationSizePlus4;

	CArtilleryAI *pArtilleryAIArray = nullptr;
	float *pFitnessScoreArray = nullptr;

	static constexpr uint32_t NumOfInputNeurons = 4;
	static constexpr uint32_t NumOfOutputNeurons = 2;

	int32_t iFirePosXMin = 3;
	int32_t iFirePosXMax = 6;

	int32_t iFirePosYMin = 30;
	int32_t iFirePosYMax = 50;

	int32_t iTargetPosXMin = 80;
	int32_t iTargetPosXMax = 130;

	int32_t iTargetPosYMin = 20;
	int32_t iTargetPosYMax = 70;

	CArtilleryAIPopulation();
	~CArtilleryAIPopulation();

	// Kopierkonstruktor l�schen: 
	CArtilleryAIPopulation(const CArtilleryAIPopulation &originalObject) = delete;

	// �berladenen Zuweisungsoperator l�schen: 
	CArtilleryAIPopulation operator=(const CArtilleryAIPopulation &originalObject) = delete;

	void Initialize(uint32_t populationSize, uint32_t numOfHiddenNeuronsL1, uint32_t numOfHiddenNeuronsL2);

	void Change_Seed(uint64_t seed);

	void RandomChange_OutputSynapsePlasticities(uint64_t seed, float minSynapticPlasticity, float maxSynapticPlasticity);
	void RandomChange_OutputSynapsePlasticities(uint64_t seed, float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRate);

	void RandomChange_OutputSynapsePlasticities(float minSynapticPlasticity, float maxSynapticPlasticity);
	void RandomChange_OutputSynapsePlasticities(float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRate);

	void RandomReduce_BrainConnections(uint64_t seed, float mutationRateL1, float mutationRateL2, float mutationRateL3);
	void RandomReduce_BrainConnections(float mutationRateL1, float mutationRateL2, float mutationRateL3);

	
	void Init_Play_and_Evaluate_NewTrainingSequence(uint32_t trainingGameLength, uint32_t numTrainingGames, float gravitationAccelerationX, float gravitationAccelerationY, float timeStep, float velocityScaleX = 100.0f, float velocityScaleY = 100.0f);
};

void Init_NeuralNetPopulation(CNeuralNetPopulation *pNeuralNetPopulation, CArtilleryAIPopulation *pArtilleryAIPopulation);

class CSimpleArtilleryAI
{
public:

	CNeuralNet Brain;

	static constexpr uint32_t NumOfInputNeurons = 4;
	static constexpr uint32_t NumOfOutputNeurons = 2;

	CSimpleArtilleryAI();
	~CSimpleArtilleryAI();

	// Kopierkonstruktor l�schen: 
	CSimpleArtilleryAI(const CSimpleArtilleryAI &originalObject) = delete;

	// �berladenen Zuweisungsoperator l�schen: 
	CSimpleArtilleryAI operator=(const CSimpleArtilleryAI &originalObject) = delete;

	void Initialize(uint32_t numOfHiddenNeuronsL1, uint32_t numOfHiddenNeuronsL2);

	void Calculate_FiringSolution(float *pOutVelocityX, float *pOutVelocityY, float startPosX, float startPosY, float targetPosX, float targetPosY, float targetVelX, float targetVelY, float accelX, float accelY, float velocityScaleX = 100.0f, float velocityScaleY = 100.0f);
};

class CSimpleArtilleryAIPopulation
{
public:

	uint64_t Seed = 1;
	CRandomNumbersNN RandomNumbers;

	uint32_t PopulationSize;
	uint32_t PopulationSizePlus4;

	CSimpleArtilleryAI *pArtilleryAIArray = nullptr;
	float *pFitnessScoreArray = nullptr;

	static constexpr uint32_t NumOfInputNeurons = 4;
	static constexpr uint32_t NumOfOutputNeurons = 2;

	int32_t iFirePosXMin = 3;
	int32_t iFirePosXMax = 6;

	int32_t iFirePosYMin = 30;
	int32_t iFirePosYMax = 50;

	int32_t iTargetPosXMin = 80;
	int32_t iTargetPosXMax = 130;

	int32_t iTargetPosYMin = 20;
	int32_t iTargetPosYMax = 70;

	int32_t iTargetVelXMin = -6;
	int32_t iTargetVelXMax = 6;

	int32_t iTargetVelYMin = -6;
	int32_t iTargetVelYMax = 6;

	CSimpleArtilleryAIPopulation();
	~CSimpleArtilleryAIPopulation();

	// Kopierkonstruktor l�schen: 
	CSimpleArtilleryAIPopulation(const CSimpleArtilleryAIPopulation &originalObject) = delete;

	// �berladenen Zuweisungsoperator l�schen: 
	CSimpleArtilleryAIPopulation operator=(const CSimpleArtilleryAIPopulation &originalObject) = delete;

	void Initialize(uint32_t populationSize, uint32_t numOfHiddenNeuronsL1, uint32_t numOfHiddenNeuronsL2);

	void Change_Seed(uint64_t seed);

	void RandomChange_OutputSynapsePlasticities(uint64_t seed, float minSynapticPlasticity, float maxSynapticPlasticity);
	void RandomChange_OutputSynapsePlasticities(uint64_t seed, float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRate);

	void RandomChange_OutputSynapsePlasticities(float minSynapticPlasticity, float maxSynapticPlasticity);
	void RandomChange_OutputSynapsePlasticities(float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRate);

	void RandomReduce_BrainConnections(uint64_t seed, float mutationRateL1, float mutationRateL2, float mutationRateL3);
	void RandomReduce_BrainConnections(float mutationRateL1, float mutationRateL2, float mutationRateL3);

	
	void Init_Play_and_Evaluate_NewTrainingSequence(uint32_t trainingGameLength, uint32_t numTrainingGames, float gravitationAccelerationX, float gravitationAccelerationY, float timeStep, float velocityScaleX = 100.0f, float velocityScaleY = 100.0f);
};

void Init_NeuralNetPopulation(CNeuralNetPopulation *pNeuralNetPopulation, CSimpleArtilleryAIPopulation *pArtilleryAIPopulation);


class COrbitalNavigationAI
{
public:

	CNeuralNet Brain;

	static constexpr uint32_t NumOfInputNeurons = 2;
	static constexpr uint32_t NumOfOutputNeurons = 1;
	
	COrbitalNavigationAI();
	~COrbitalNavigationAI();

	// Kopierkonstruktor l�schen: 
	COrbitalNavigationAI(const COrbitalNavigationAI &originalObject) = delete;

	// �berladenen Zuweisungsoperator l�schen: 
	COrbitalNavigationAI operator=(const COrbitalNavigationAI &originalObject) = delete;

	void Initialize(uint32_t numOfHiddenNeuronsL1, uint32_t numOfHiddenNeuronsL2);
	
	void Calculate_InitialOrbitalVelocity(float *pOutVelocityX, float *pOutVelocityY, float startPosX, float startPosY, float targetPosX, float targetPosY, float gravitySourcePosX, float gravitySourcePosY, float gravitySourceMass);
};

class COrbitalNavigationAIPopulation
{
public:

	uint64_t Seed = 1;
	CRandomNumbersNN RandomNumbers;

	uint32_t PopulationSize;
	uint32_t PopulationSizePlus4;

	COrbitalNavigationAI *pOrbitalNavigationAIArray = nullptr;
	float *pFitnessScoreArray = nullptr;

	static constexpr uint32_t NumOfInputNeurons = 2;
	static constexpr uint32_t NumOfOutputNeurons = 1;

	COrbitalNavigationAIPopulation();
	~COrbitalNavigationAIPopulation();

	// Kopierkonstruktor l�schen: 
	COrbitalNavigationAIPopulation(const COrbitalNavigationAIPopulation &originalObject) = delete;

	// �berladenen Zuweisungsoperator l�schen: 
	COrbitalNavigationAIPopulation operator=(const COrbitalNavigationAIPopulation &originalObject) = delete;

	void Initialize(uint32_t populationSize, uint32_t numOfHiddenNeuronsL1, uint32_t numOfHiddenNeuronsL2);

	void Change_Seed(uint64_t seed);

	void RandomChange_OutputSynapsePlasticities(uint64_t seed, float minSynapticPlasticity, float maxSynapticPlasticity);
	void RandomChange_OutputSynapsePlasticities(uint64_t seed, float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRate);

	void RandomChange_OutputSynapsePlasticities(float minSynapticPlasticity, float maxSynapticPlasticity);
	void RandomChange_OutputSynapsePlasticities(float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRate);

	void RandomReduce_BrainConnections(uint64_t seed, float mutationRateL1, float mutationRateL2, float mutationRateL3);
	void RandomReduce_BrainConnections(float mutationRateL1, float mutationRateL2, float mutationRateL3);

	
	void Init_Play_and_Evaluate_NewTrainingSequence(uint32_t trainingGameLength, uint32_t numTrainingGames, CSimplePhysicsObject* pGravitySource, float timeStep);
};

void Init_NeuralNetPopulation(CNeuralNetPopulation *pNeuralNetPopulation, COrbitalNavigationAIPopulation *pOrbitalNavigationAIPopulation);


class CLandingModuleNavigationAI
{
public:

	CNeuralNet Brain;

	static constexpr uint32_t NumOfInputNeurons = 8; 

	// Maneuver: nothing / up / down / right / left
	static constexpr uint32_t NumOfOutputNeurons = 5; 

	CLandingModuleNavigationAI();
	~CLandingModuleNavigationAI();

	// Kopierkonstruktor l�schen: 
	CLandingModuleNavigationAI(const CLandingModuleNavigationAI &originalObject) = delete;

	// �berladenen Zuweisungsoperator l�schen: 
	CLandingModuleNavigationAI operator=(const CLandingModuleNavigationAI &originalObject) = delete;

	void Initialize(uint32_t numOfHiddenNeuronsL1, uint32_t numOfHiddenNeuronsL2);

	void Calculate_PossibleCourseCorrection(float *pOutputData, CSimplePhysicsObject * pLandingModule, float targetPosX, float targetPosY);
};

class CLandingModuleNavigationAIPopulation
{
public:

	uint64_t Seed = 1;
	CRandomNumbersNN RandomNumbers;

	uint32_t PopulationSize;
	uint32_t PopulationSizePlus4;

	CLandingModuleNavigationAI *pLandingModuleNavigationAIArray = nullptr;
	float *pFitnessScoreArray = nullptr;

	static constexpr uint32_t NumOfInputNeurons = 8; 
	
	// Maneuver: nothing / up / down / right / left
	static constexpr uint32_t NumOfOutputNeurons = 5;

	float MaxToleratedLandingVelocityAmountSq = 0.5f;
	float MaxToleratedTargetDistanceSq = 0.5f;

	float FuelCapacityMax = 100.0f;
	

	// fuel consumption per flight maneuver
	float FuelConsumptionX = 0.001f;
	float FuelConsumptionY = 0.001f;
	

	// maneuver-accelerationY must be greater than gravitation-accelerationY!!
	float ManeuverAccelerationX = 100.0f;
	float ManeuverAccelerationY = 100.0f; 
	
	
	int32_t iStartPosXMin = 10;
	int32_t iStartPosXMax = 120;

	int32_t iStartPosYMin = 10;
	int32_t iStartPosYMax = 30;

	int32_t iTargetPosXMin = 10;
	int32_t iTargetPosXMax = 130;

	int32_t iTargetPosYMin = 70;
	int32_t iTargetPosYMax = 90;

	float InitalVelocityXMin = -20.0f;
	float InitalVelocityXMax = 20.0f;

	float InitalVelocityYMin = -20.0f;
	float InitalVelocityYMax = 20.0f;

	
	CLandingModuleNavigationAIPopulation();
	~CLandingModuleNavigationAIPopulation();

	// Kopierkonstruktor l�schen: 
	CLandingModuleNavigationAIPopulation(const CLandingModuleNavigationAIPopulation &originalObject) = delete;

	// �berladenen Zuweisungsoperator l�schen: 
	CLandingModuleNavigationAIPopulation operator=(const CLandingModuleNavigationAIPopulation &originalObject) = delete;

	void Initialize(uint32_t populationSize, uint32_t numOfHiddenNeuronsL1, uint32_t numOfHiddenNeuronsL2);

	void Change_Seed(uint64_t seed);

	void RandomChange_OutputSynapsePlasticities(uint64_t seed, float minSynapticPlasticity, float maxSynapticPlasticity);
	void RandomChange_OutputSynapsePlasticities(uint64_t seed, float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRate);

	void RandomChange_OutputSynapsePlasticities(float minSynapticPlasticity, float maxSynapticPlasticity);
	void RandomChange_OutputSynapsePlasticities(float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRate);

	void RandomReduce_BrainConnections(uint64_t seed, float mutationRateL1, float mutationRateL2, float mutationRateL3);
	void RandomReduce_BrainConnections(float mutationRateL1, float mutationRateL2, float mutationRateL3);

	
	void Init_Play_and_Evaluate_NewTrainingSequence(uint32_t trainingGameLength, uint32_t numTrainingGames, float gravitationAccelerationX, float gravitationAccelerationY, float timeStep, float targetDistanceInvReward1, float targetDistanceReward2, float fuelConsumptionInvReward1, float fuelConsumptionReward2, float horizontalVelocityInvPenalty, float verticalVelocityInvPenalty, float velocityPenalty, float flightDurationInvPenalty1, float flightDurationPenalty2);
};

void Init_NeuralNetPopulation(CNeuralNetPopulation *pNeuralNetPopulation, CLandingModuleNavigationAIPopulation *pLandingModuleNavigationAIPopulation);


#endif