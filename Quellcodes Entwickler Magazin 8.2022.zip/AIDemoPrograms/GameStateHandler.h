// Schutz vor Mehrfachdeklarationen:
#ifndef _GameStateHandler_H_
#define _GameStateHandler_H_

#pragma warning( disable: 4996)

#include <iostream>
#include <fstream>
#include "LogFile.h"
#include "RandomNumbers.h"
#include "MemoryManagement.h"

#ifndef max
#define max(a,b)    ( ((a) > (b)) ? (a) : (b) )
#endif

#ifndef min
#define min(a,b)    ( ((a) < (b)) ? (a) : (b) )
#endif

static constexpr int32_t ConstMaxEvaluationScore_Minimax = 2000000;
static constexpr int32_t ConstMinEvaluationScore_Minimax = -2000000;

static constexpr float fConstMaxEvaluationScore_Minimax = 2000000.0f;
static constexpr float fConstMinEvaluationScore_Minimax = -2000000.0f;



class CGameStateValues;
class CExtendedGameStatePool;
class CMovePattern;
class CMovePatternList;

typedef void(*pGameStateEvalFunc)(int32_t gameStateID, CExtendedGameStatePool* pGameStatePool, CMovePatternList* pPlayer1MoveList, CMovePatternList* pPlayer2MoveList);
typedef void(*pLeafGameStatesEvalFunc)(CExtendedGameStatePool* pGameStatePool, CMovePatternList* pPlayer1MoveList, CMovePatternList* pPlayer2MoveList);
typedef bool(*pCheckGameStateEvalFunc)(CGameStateValues* pGameState, int32_t minTolerableEvalValue, CMovePatternList* pPlayer1MoveList, CMovePatternList* pPlayer2MoveList);
typedef bool(*pAdditionalMoveOrValidationFunc)(int32_t moveStartPosID, int32_t moveEndPosID, int8_t* pInOutGameStateValues);

class CInitialGameBoards
{
public:

	int32_t NumOfInitialBoards = 0;
	CGameStateValues* pInitialGameStateArray = nullptr;

	CInitialGameBoards();
	~CInitialGameBoards();

	// Kopierkonstruktor l�schen:
	CInitialGameBoards(const CInitialGameBoards& originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CInitialGameBoards& operator=(const CInitialGameBoards& originalObject) = delete;

	bool Initialize(const char* pFilename, int32_t gameBoardSizeXDir, int32_t gameBoardSizeYDir);
};

void Init_GameBoard(int8_t* pInOutGameData, CInitialGameBoards* pInitialGameBoards, int32_t boardID, int32_t gameBoardSizeXY);
void Clone_GameBoard(int8_t* pOutGameData, int8_t* pInGameData, int32_t gameBoardSizeXY);




class CMovePattern
{
public:

	int32_t NumOfMoveElements = 0;

	int32_t ixStartMin = 0;
	int32_t ixStartMax = 0;
	int32_t iyStartMin = 0;
	int32_t iyStartMax = 0;

	int32_t GameBoardSizeXYMinus1 = 63;

	int8_t* pBoardValueArray = nullptr;
	int32_t* pRelBoardPosIDArray = nullptr;

	int8_t* pBoardValueArray_Outcome = nullptr;
	int32_t* pRelBoardPosIDArray_Outcome = nullptr;

	bool MoveCurrentlyPermitted = true;

	pAdditionalMoveOrValidationFunc AdditionalMoveFunc = nullptr;
	pAdditionalMoveOrValidationFunc AdditionalValidationFunc = nullptr;
	
	CMovePattern();
	~CMovePattern();

	// Kopierkonstruktor l�schen:
	CMovePattern(const CMovePattern& originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CMovePattern& operator=(const CMovePattern& originalObject) = delete;

	void Initialize(int32_t numOfMoveElements);

	void Set_AdditionalMoveFunction(pAdditionalMoveOrValidationFunc pFunc);
	void Set_AdditionalValidationFunction(pAdditionalMoveOrValidationFunc pFunc);

	void Set_MoveStatus(bool moveCurrentlyPermitted);

	bool Validate_PossibleMove(int32_t ixStart, int32_t iyStart, int32_t startPosID, CGameStateValues* pInGameStateValues);
	bool Validate_PossibleMove(int32_t ixStart, int32_t iyStart, int32_t startPosID, int32_t endPosID, CGameStateValues* pInGameStateValues);
	bool Make_Move_If_Possible(int32_t ixStart, int32_t iyStart, int32_t startPosID, CGameStateValues* pInOutGameStateValues);
	bool Make_Move_If_Possible(int32_t ixStart, int32_t iyStart, int32_t startPosID, int32_t endPosID, CGameStateValues* pInOutGameStateValues);
	void Make_Move(int32_t ixStart, int32_t iyStart, int32_t startPosID, CGameStateValues* pInOutGameStateValues);
	
	
	bool Validate_PossibleMove(int32_t ixStart, int32_t iyStart, int32_t startPosID, int8_t* pInGameStateValues);
	bool Validate_PossibleMove(int32_t ixStart, int32_t iyStart, int32_t startPosID, int32_t endPosID, int8_t* pInGameStateValues);
	bool Make_Move_If_Possible(int32_t ixStart, int32_t iyStart, int32_t startPosID, int8_t* pInOutGameStateValues);
	bool Make_Move_If_Possible(int32_t ixStart, int32_t iyStart, int32_t startPosID, int32_t endPosID, int8_t* pInOutGameStateValues);
	void Make_Move(int32_t ixStart, int32_t iyStart, int32_t startPosID, int8_t* pInOutGameStateValues);
};

class CMovePatternList
{
public:

	int32_t NumOfMoves = 0;

	CMovePattern* pMoveArray = nullptr;

	CMovePatternList();
	~CMovePatternList();

	// Kopierkonstruktor l�schen:
	CMovePatternList(const CMovePatternList& originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CMovePatternList& operator=(const CMovePatternList& originalObject) = delete;

	bool Initialize(const char* pFilename);
	bool Initialize_UseMoveEndPositionsforValidation(const char* pFilename);

	void Set_AdditionalMoveFunction(pAdditionalMoveOrValidationFunc pFunc);
	void Set_AdditionalMoveFunction(int32_t moveID, pAdditionalMoveOrValidationFunc pFunc);
	void Set_AdditionalMoveFunction(int32_t minMoveID, int32_t maxMoveIDPlus1, pAdditionalMoveOrValidationFunc pFunc);

	void Set_AdditionalValidationFunction(pAdditionalMoveOrValidationFunc pFunc);
	void Set_AdditionalValidationFunction(int32_t moveID, pAdditionalMoveOrValidationFunc pFunc);
	void Set_AdditionalValidationFunction(int32_t minMoveID, int32_t maxMoveIDPlus1, pAdditionalMoveOrValidationFunc pFunc);
	
	void Set_MoveStatus(int32_t moveID, bool moveCurrentlyPermitted);

	bool Validate_PossibleMove(int32_t moveID, int32_t ixStart, int32_t iyStart, int32_t startPosID, CGameStateValues* pInGameStateValues);
	bool Validate_PossibleMove(int32_t moveID, int32_t ixStart, int32_t iyStart, int32_t startPosID, int32_t endPosID, CGameStateValues* pInGameStateValues);
	bool Make_Move_If_Possible(int32_t moveID, int32_t ixStart, int32_t iyStart, int32_t startPosID, CGameStateValues* pInOutGameStateValues);
	bool Make_Move_If_Possible(int32_t moveID, int32_t ixStart, int32_t iyStart, int32_t startPosID, int32_t endPosID, CGameStateValues* pInOutGameStateValues);
	void Make_Move(int32_t moveID, int32_t ixStart, int32_t iyStart, int32_t startPosID, CGameStateValues* pInOutGameStateValues);
	
	bool Validate_PossibleMove(int32_t moveID, int32_t ixStart, int32_t iyStart, int32_t startPosID, int8_t* pInGameStateValues);
	bool Validate_PossibleMove(int32_t moveID, int32_t ixStart, int32_t iyStart, int32_t startPosID, int32_t endPosID, int8_t* pInGameStateValues);
	bool Make_Move_If_Possible(int32_t moveID, int32_t ixStart, int32_t iyStart, int32_t startPosID, int8_t* pInOutGameStateValues);
	bool Make_Move_If_Possible(int32_t moveID, int32_t ixStart, int32_t iyStart, int32_t startPosID, int32_t endPosID, int8_t* pInOutGameStateValues);
	void Make_Move(int32_t moveID, int32_t ixStart, int32_t iyStart, int32_t startPosID, int8_t* pInOutGameStateValues);
};



class CTestMove
{
public:

	int32_t GameBoardSizeXDir = 8;
	int32_t GameBoardSizeXY = 64;

	
	int32_t BoardPosID = 0;
	int32_t MoveID = 0;
	int32_t ResultingGameStateObjectID = -1;

	CMovePatternList* pUsedPlayer1MoveList = nullptr;
	CMovePatternList* pUsedPlayer2MoveList = nullptr;

	
	static constexpr int32_t NumOfMoveExcludedBoardElementsMax = 10;

	int32_t NumOfPlayer1MoveExcludedBoardElements = 0;
	int8_t Player1MoveExcludedBoardElementsArray[NumOfMoveExcludedBoardElementsMax];

	int32_t NumOfPlayer2MoveExcludedBoardElements = 0;
	int8_t Player2MoveExcludedBoardElementsArray[NumOfMoveExcludedBoardElementsMax];

	pCheckGameStateEvalFunc Player1ViewCheckGameStateEvalFunc = nullptr;
	pCheckGameStateEvalFunc Player2ViewCheckGameStateEvalFunc = nullptr;

	int32_t MinTolerableEvaluationValue_Player1 = 0;
	int32_t MinTolerableEvaluationValue_Player2 = 0;

	CTestMove();
	~CTestMove();

	void Set_EvaluationFunctions(pCheckGameStateEvalFunc Player1ViewFunc, pCheckGameStateEvalFunc Player2ViewFunc);

	void Set_GameBoardSizeXDir(int32_t sizeX);
	void Set_GameBoardSizeXY(int32_t sizeXY);

	void Set_MovePatternLists(CMovePatternList* pPlayer1MoveList, CMovePatternList* pPlayer2MoveList);

	void Prepare_Move(int32_t boardPosID, int32_t moveID);

	int32_t Make_Player1Move_If_Possible(CGameStateValues** ppOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool* pGameStatePool, int32_t depthLayer, bool resultingGameStateIsMaximizer);
	int32_t Make_Player2Move_If_Possible(CGameStateValues** ppOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool* pGameStatePool, int32_t depthLayer, bool resultingGameStateIsMaximizer);

	int32_t Make_Player1Move_If_Possible(CGameStateValues* pInActualGameState, CExtendedGameStatePool* pGameStatePool, int32_t depthLayer, bool resultingGameStateIsMaximizer);
	int32_t Make_Player2Move_If_Possible(CGameStateValues* pInActualGameState, CExtendedGameStatePool* pGameStatePool, int32_t depthLayer, bool resultingGameStateIsMaximizer);

	//////////////////////////////////

	int32_t Make_Player1Move_If_Possible_AvoidRepetitiveStates(CGameStateValues** ppOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool* pGameStatePool, int32_t depthLayer, bool resultingGameStateIsMaximizer);
	int32_t Make_Player2Move_If_Possible_AvoidRepetitiveStates(CGameStateValues** ppOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool* pGameStatePool, int32_t depthLayer, bool resultingGameStateIsMaximizer);

	int32_t Make_Player1Move_If_Possible_AvoidRepetitiveStates(CGameStateValues* pInActualGameState, CExtendedGameStatePool* pGameStatePool, int32_t depthLayer, bool resultingGameStateIsMaximizer);
	int32_t Make_Player2Move_If_Possible_AvoidRepetitiveStates(CGameStateValues* pInActualGameState, CExtendedGameStatePool* pGameStatePool, int32_t depthLayer, bool resultingGameStateIsMaximizer);

	int32_t Make_Player1Move_If_Possible_DiscardInsufficientStates(CGameStateValues** ppOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool* pGameStatePool, int32_t depthLayer, bool resultingGameStateIsMaximizer);
	int32_t Make_Player2Move_If_Possible_DiscardInsufficientStates(CGameStateValues** ppOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool* pGameStatePool, int32_t depthLayer, bool resultingGameStateIsMaximizer);

	int32_t Make_Player1Move_If_Possible_DiscardInsufficientStates(CGameStateValues* pInActualGameState, CExtendedGameStatePool* pGameStatePool, int32_t depthLayer, bool resultingGameStateIsMaximizer);
	int32_t Make_Player2Move_If_Possible_DiscardInsufficientStates(CGameStateValues* pInActualGameState, CExtendedGameStatePool* pGameStatePool, int32_t depthLayer, bool resultingGameStateIsMaximizer);

};



class C1DimMoveDesc
{
public:

	int32_t id_Old = -1;
	int32_t id_New = -1;
	                       
	int32_t iEvaluation = -2000000;
	float fEvaluation = -2000000.0f;

	C1DimMoveDesc();
	~C1DimMoveDesc();

	void Clone_Data(C1DimMoveDesc *pOriginalObject);

	void Reset(void);
};

class C2DimMoveDesc
{
public:

	int32_t ix_Old = -1;
	int32_t iy_Old = -1;

	int32_t ix_New = -1;
	int32_t iy_New = -1;

	int32_t iEvaluation = -2000000;
	float fEvaluation = -2000000.0f;

	C2DimMoveDesc();
	~C2DimMoveDesc();

	void Clone_Data(C2DimMoveDesc *pOriginalObject);

	void Reset(void);
};

class C3DimMoveDesc
{
public:

	int32_t ix_Old = -1;
	int32_t iy_Old = -1;
	int32_t iz_Old = -1;

	int32_t ix_New = -1;
	int32_t iy_New = -1;
	int32_t iz_New = -1;

	int32_t iEvaluation = -2000000;
	float fEvaluation = -2000000.0f;

	C3DimMoveDesc();
	~C3DimMoveDesc();

	void Clone_Data(C3DimMoveDesc *pOriginalObject);

	void Reset(void);
};

void Update_ListOfBestMoves_IntegerEvaluation(C1DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C1DimMoveDesc* pInMoveDesc);
void Update_ListOfBestMoves_FloatEvaluation(C1DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C1DimMoveDesc* pInMoveDesc);

void Update_ListOfBestMoves_IntegerEvaluation(C2DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C2DimMoveDesc* pInMoveDesc);
void Update_ListOfBestMoves_FloatEvaluation(C2DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C2DimMoveDesc* pInMoveDesc);

void Update_ListOfBestMoves_IntegerEvaluation(C3DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C3DimMoveDesc* pInMoveDesc);
void Update_ListOfBestMoves_FloatEvaluation(C3DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C3DimMoveDesc* pInMoveDesc);


void Generate_ListOfBestMoves_IntegerEvaluation(C1DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C1DimMoveDesc* pInMoveDescArray, int32_t numOfMoves);
void Generate_ListOfBestMoves_FloatEvaluation(C1DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C1DimMoveDesc* pInMoveDescArray, int32_t numOfMoves);

void Generate_ListOfBestMoves_IntegerEvaluation(C2DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C2DimMoveDesc* pInMoveDescArray, int32_t numOfMoves);
void Generate_ListOfBestMoves_FloatEvaluation(C2DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C2DimMoveDesc* pInMoveDescArray, int32_t numOfMoves);

void Generate_ListOfBestMoves_IntegerEvaluation(C3DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C3DimMoveDesc* pInMoveDescArray, int32_t numOfMoves);
void Generate_ListOfBestMoves_FloatEvaluation(C3DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C3DimMoveDesc* pInMoveDescArray, int32_t numOfMoves);


class CGameStateValues
{
public:

	CGameStateValues *pUsedGameStateArray = nullptr;

	bool LeafNode = false;
	int32_t PlayerID = -1;
	int32_t IDofGameState = -1;
	int32_t IDofPrevGameState = -1;
	// Ebene innerhalb eines Game-Trees:
	int32_t DepthValue = 0;

	// take minimum Evaluation value:
	bool Minimizer = false;
	int32_t iEvaluation = ConstMinEvaluationScore_Minimax;
	int32_t iEvaluationChange = 0;
	float fEvaluation = fConstMinEvaluationScore_Minimax;
	float fEvaluationChange = 0.0f;
	bool FurtherExploration = true;

	int32_t LastMove_BoardPosID = 0;
	int32_t LastMove_MoveID = 0;
	
	int32_t SizeX = 0;
	int32_t SizeY = 0;
	int32_t SizeZ = 0;
	int32_t SizeXY = 0;
	int32_t Size = 0;
	int8_t *pValueArray = nullptr;

	uint32_t SimpleHashValue = 0;

	CGameStateValues();
	CGameStateValues(int32_t size);
	CGameStateValues(int32_t sizeX, int32_t sizeY);
	CGameStateValues(int32_t sizeX, int32_t sizeY, int32_t sizeZ);

	~CGameStateValues();

	// Kopierkonstruktor l�schen:
	CGameStateValues(const CGameStateValues  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CGameStateValues & operator=(const CGameStateValues  &originalObject) = delete;

	void Initialize(int32_t size);
	void Initialize(int32_t sizeX, int32_t sizeY);
	void Initialize(int32_t sizeX, int32_t sizeY, int32_t sizeZ);

	void Connect_With_GameStateArray(CGameStateValues *pGameStateArray);

	void Calculate_SimpleHashValue(void);
	bool Check_Identity(CGameStateValues *pOtherObject);

	// take minimum Evaluation value:
	void Use_As_Minimizer(void);

	// take maximum Evaluation value:
	void Use_As_Maximizer(void);
	void Reset_MinimaxEvaluation(void);
	
	bool Check_Usage(void);

	void Reset_Evaluation(void);

	void Reset(void);

	void Clone_Data(CGameStateValues *pOriginalObject);

	void Clone_GameStateValues(CGameStateValues *pOriginalObject);
	void Clone_GameStateValues(int8_t *pOriginalValueArray);

	int32_t Get_ID_From_CartesianCoord(int32_t ix, int32_t iy);
	int32_t Get_ID_From_CartesianCoord(int32_t ix, int32_t iy, int32_t iz);

	void Get_ID_From_CartesianCoord(int32_t *pOutID, int32_t ix, int32_t iy);
	void Get_ID_From_CartesianCoord(int32_t *pOutID, int32_t ix, int32_t iy, int32_t iz);

	void Get_CartesianCoord_From_ID(int32_t *pOut_ix, int32_t *pOut_iy, int32_t id);
	void Get_CartesianCoord_From_ID(int32_t *pOut_ix, int32_t *pOut_iy, int32_t *pOut_iz, int32_t id);

	void Set_Value(int8_t value, int32_t id);
	void Set_Value(int8_t value, int32_t ix, int32_t iy);
	void Set_Value(int8_t value, int32_t ix, int32_t iy, int32_t iz);

	int8_t Get_Value(int32_t id);
	int8_t Get_Value(int32_t ix, int32_t iy);
	int8_t Get_Value(int32_t ix, int32_t iy, int32_t iz);

	void Use_As_Root_GameState(bool leafNodeToo);

	void Set_TreeInfo_If_Desired(int32_t depth, int32_t IDPrevGameState, bool leafNode);

	void Backpropagate_MinimaxIntegerEvaluation(void);
	void Backpropagate_MinimaxFloatEvaluation(void);

	void Backpropagate_MinimaxIntegerEvaluation(int32_t intendedDepth);
	void Backpropagate_MinimaxFloatEvaluation(int32_t intendedDepth);

	void Backpropagate_IntegerEvaluationChange(void);
	void Backpropagate_FloatEvaluationChange(void);

	void Backpropagate_IntegerEvaluationChange(int32_t intendedDepth);
	void Backpropagate_FloatEvaluationChange(int32_t intendedDepth);

	void Set_EvaluationValue(float value);
	void Set_EvaluationValue(int32_t value);

	void Update_Evaluation(float valueOfChange);
	void Update_Evaluation(int32_t valueOfChange);
	
	
	// true if this game state is a successor of *pPrevGameState:
	bool Check_If_Possible_Successor(CGameStateValues *pPrevGameState);

	int32_t Get_PrevGameState(CGameStateValues **ppOutPrevGameState);
	int32_t Get_PrevGameStateID(void);

	int32_t Get_RootID(void);
	int32_t Get_Root_And_RootID(CGameStateValues **ppOutPrevGameState);
};






class CGameStateRingBuffer
{
public:

	int32_t Size = 0;
	CGameStateValues *pGameStateArray = nullptr;

	int32_t PreviousBufferElement = 0;
	int32_t ActualBufferElement = 0;

	CGameStateRingBuffer();
	~CGameStateRingBuffer();

	// Kopierkonstruktor l�schen:
	CGameStateRingBuffer(const CGameStateRingBuffer  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CGameStateRingBuffer & operator=(const CGameStateRingBuffer  &originalObject) = delete;

	void Initialize(int32_t bufferSize, int32_t gameStateSize);
	void Initialize(int32_t bufferSize, int32_t gameStateSizeX, int32_t gameStateSizeY);
	void Initialize(int32_t bufferSize, int32_t gameStateSizeX, int32_t gameStateSizeY, int32_t gameStateSizeZ);

	void Reset_ActualBufferElement(void);
	void Set_ActualBufferElement(int32_t value);

	void Increase_ActualBufferElement(void);
	void Decrease_ActualBufferElement(void);
	
	int32_t Get_ActualBufferElementID(void);
	int32_t Get_PreviousBufferElementID(void);

	int32_t Get_ActualBufferElement(CGameStateValues **ppOutGameStateObject);
	int32_t Get_PreviousBufferElement(CGameStateValues **ppOutGameStateObject);

	int32_t Get_ActualBufferElement(int8_t **ppOutGameState);
	int32_t Get_PreviousBufferElement(int8_t **ppOutGameState);

	void Set_ActualBufferElementData(CGameStateValues *pGameStateObject);
	void Set_PreviousBufferElementData(CGameStateValues *pGameStateObject);

	void Set_ActualBufferElementData(int8_t *pGameState);
	void Set_PreviousBufferElementData(int8_t *pGameState);
	
	
};

class CSimpleGameStatePool
{
public:

	int32_t Size = 0;
	CGameStateValues *pGameStateArray = nullptr;

	int32_t NumGameStateObjectsUsed = 0;

	CSimpleMemoryManager SimpleMemoryManager;
	
	CSimpleGameStatePool();
	~CSimpleGameStatePool();

	// Kopierkonstruktor l�schen:
	CSimpleGameStatePool(const CSimpleGameStatePool  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CSimpleGameStatePool & operator=(const CSimpleGameStatePool  &originalObject) = delete;

	void Initialize(int32_t poolSize, int32_t gameStateSize);
	void Initialize(int32_t poolSize, int32_t gameStateSizeX, int32_t gameStateSizeY);
	void Initialize(int32_t poolSize, int32_t gameStateSizeX, int32_t gameStateSizeY, int32_t gameStateSizeZ);

	bool Get_UnusedGameStateObject(int32_t* pOutBelongingID);
	bool Get_UnusedGameStateObject(CGameStateValues** ppOutGameStateObject, int32_t* pOutBelongingID);

	bool Stop_Using_GameStateObject(int32_t id);
	bool Stop_Using_GameStateObject(CGameStateValues** ppGameStateObject);

	void Stop_Using_AllGameStateObjects(void);
};

class CGameStatePool
{
public:

	int32_t Size = 0;
	CGameStateValues *pGameStateArray = nullptr;

	int32_t NumGameStateObjectsUsed = 0;

	CSimpleMemoryManager SimpleMemoryManager;
	CSimpleLinkedListManager SimpleLinkedListManager;

	CGameStatePool();
	~CGameStatePool();

	// Kopierkonstruktor l�schen:
	CGameStatePool(const CGameStatePool  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CGameStatePool & operator=(const CGameStatePool  &originalObject) = delete;

	void Initialize(int32_t poolSize, int32_t gameStateSize);
	void Initialize(int32_t poolSize, int32_t gameStateSizeX, int32_t gameStateSizeY);
	void Initialize(int32_t poolSize, int32_t gameStateSizeX, int32_t gameStateSizeY, int32_t gameStateSizeZ);

	bool Get_UnusedGameStateObject(int32_t* pBelongingID);
	bool Get_UnusedGameStateObject(CGameStateValues** ppOutGameStateObject, int32_t* pOutBelongingID);
	
	bool Stop_Using_GameStateObject(int32_t id);
	bool Stop_Using_GameStateObject(CGameStateValues** ppGameStateObject);
	
	void Stop_Using_AllGameStateObjects(void);
};

// Gamestate-Pool with Game-Tree-Handling
class CExtendedGameStatePool
{
public:

	int32_t Size = 0;
	CGameStateValues *pGameStateArray = nullptr;

	int32_t NumGameStateObjectsUsed = 0;

	CSimpleMemoryManager SimpleMemoryManager;

	int32_t NumOfDepthLayersMax = 0;
	CSimpleLinkedListManager *pSimpleLinkedListManagerArray = nullptr;

	CGameStateValues TempGameState;

	int32_t NextBestMove_BoardID = 0;
	int32_t NextBestMove_MoveID = 0;
	int32_t NextBestMove_iEvaluation = ConstMinEvaluationScore_Minimax;
	float NextBestMove_fEvaluation = fConstMinEvaluationScore_Minimax;

	int32_t IDofLastReturnedGameStateObject = 0;

	CExtendedGameStatePool();
	~CExtendedGameStatePool();

	// Kopierkonstruktor l�schen:
	CExtendedGameStatePool(const CExtendedGameStatePool  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CExtendedGameStatePool & operator=(const CExtendedGameStatePool  &originalObject) = delete;

	void Initialize(int32_t numOfDepthLayersMax, int32_t poolSize, int32_t gameStateSize);
	void Initialize(int32_t numOfDepthLayersMax, int32_t poolSize, int32_t gameStateSizeX, int32_t gameStateSizeY);
	void Initialize(int32_t numOfDepthLayersMax, int32_t poolSize, int32_t gameStateSizeX, int32_t gameStateSizeY, int32_t gameStateSizeZ);

	void Reset_NextBestMoveData(void);

	bool Check_If_TempGameState_Already_Exists(int32_t depth);

	bool Get_UnusedGameStateObject(int32_t depth, int32_t* pOutBelongingID);
	bool Get_UnusedGameStateObject(int32_t depth, CGameStateValues** ppOutGameStateObject, int32_t* pOutBelongingID);

	
	void Get_Best_GameState_IntegerEvaluation(CGameStateValues** ppOutGameStateObject, int32_t* pOutBelongingID, int32_t deepthLayer = 0);
	void Get_Best_GameState_FloatEvaluation(CGameStateValues** ppOutGameStateObject, int32_t* pOutBelongingID, int32_t deepthLayer = 0);

	void Get_Worst_GameState_IntegerEvaluation(CGameStateValues** ppOutGameStateObject, int32_t* pOutBelongingID, int32_t deepthLayer = 0);
	void Get_Worst_GameState_FloatEvaluation(CGameStateValues** ppOutGameStateObject, int32_t* pOutBelongingID, int32_t deepthLayer = 0);

	bool Stop_Using_GameStateObject(int32_t id);
	bool Stop_Using_GameStateObject(CGameStateValues** ppGameStateObject);

	void Stop_Using_AllGameStateObjects(void);

	void Reset_EvaluationValues(void);

	int32_t Get_Random_GameStateID_LastDepthLayerExcluded(int32_t minDepth, int32_t maxDepth, int32_t numAttemptsMax, CRandomNumbersNN *pRandomNumbers);
	int32_t Get_Random_GameStateID(int32_t minDepth, int32_t maxDepth, int32_t numAttemptsMax, CRandomNumbersNN *pRandomNumbers);

	int32_t Get_RootID(CGameStateValues* pGameStateObject);
	int32_t Get_Root_And_RootID(CGameStateValues** ppOutGameStateObject, CGameStateValues* pInGameStateObject);
};

void Backpropagate_MinimaxIntegerEvaluationValues(CExtendedGameStatePool *pGameStatePool);
void Backpropagate_IntegerEvaluationChanges(CExtendedGameStatePool *pGameStatePool);

void Backpropagate_MinimaxFloatEvaluationValues(CExtendedGameStatePool *pGameStatePool);
void Backpropagate_FloatEvaluationChanges(CExtendedGameStatePool *pGameStatePool);

void OneStepBackpropagate_MinimaxIntegerEvaluationValues(int32_t IDofSourceGameState, CExtendedGameStatePool* pGameStatePool);
void OneStepBackpropagate_MinimaxFloatEvaluationValues(int32_t IDofSourceGameState, CExtendedGameStatePool* pGameStatePool);
void OneStepBackpropagate_IntegerEvaluationChanges(int32_t IDofSourceGameState, CExtendedGameStatePool* pGameStatePool);
void OneStepBackpropagate_FloatEvaluationChanges(int32_t IDofSourceGameState, CExtendedGameStatePool* pGameStatePool);


class CSimpleGameTree_DepthLayerInfo
{
public:

	int32_t NumGameStatesMax = 0;
	int32_t NumGameStatesUsed = 0;

	int32_t *pGameStateIDArray = nullptr;

	CSimpleGameTree_DepthLayerInfo();
	~CSimpleGameTree_DepthLayerInfo();

	// Kopierkonstruktor l�schen:
	CSimpleGameTree_DepthLayerInfo(const CSimpleGameTree_DepthLayerInfo  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CSimpleGameTree_DepthLayerInfo & operator=(const CSimpleGameTree_DepthLayerInfo  &originalObject) = delete;

	void Initialize(int32_t numGameStatesMax);
	bool Add_GameState(int32_t gameStateID);
	bool Remove_GameState(int32_t gameStateID);
	void Reset(void);
};




class CGameStatePool_SimpleGameTree
{
public:

	int32_t Size = 0;
	CGameStateValues *pGameStateArray = nullptr;

	int32_t NumGameStateObjectsUsed = 0;

	CSimpleMemoryManager SimpleMemoryManager;
	CSimpleLinkedListManager SimpleLinkedListManager;

	int32_t NumOfDepthLayersMax = 0;
	CSimpleGameTree_DepthLayerInfo *pDepthLayerInfoArray = nullptr;

	CGameStatePool_SimpleGameTree();
	~CGameStatePool_SimpleGameTree();

	// Kopierkonstruktor l�schen:
	CGameStatePool_SimpleGameTree(const CGameStatePool_SimpleGameTree  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CGameStatePool_SimpleGameTree & operator=(const CGameStatePool_SimpleGameTree  &originalObject) = delete;

	void Initialize(int32_t poolSize, int32_t gameStateSize);
	void Initialize(int32_t poolSize, int32_t gameStateSizeX, int32_t gameStateSizeY);
	void Initialize(int32_t poolSize, int32_t gameStateSizeX, int32_t gameStateSizeY, int32_t gameStateSizeZ);

	void Initialize_DepthLayers(int32_t numOfDepthLayersMax, int32_t numOfGameStatesMaxPerLayer);
	void Initialize_DepthLayers(int32_t numOfDepthLayersMax, int32_t *pNumOfGameStatesMaxPerLayerArray);

	bool Get_UnusedGameStateObject(int32_t depth, int32_t* pBelongingID);
	bool Get_UnusedGameStateObject(int32_t depth, CGameStateValues** ppOutGameStateObject, int32_t* pOutBelongingID);

	void Stop_Using_AllGameStateObjects(void);
};

void Backpropagate_MinimaxIntegerEvaluationValues(CGameStatePool_SimpleGameTree *pGameStatePool);
void Backpropagate_IntegerEvaluationChanges(CGameStatePool_SimpleGameTree *pGameStatePool);


void Backpropagate_MinimaxFloatEvaluationValues(CGameStatePool_SimpleGameTree *pGameStatePool);
void Backpropagate_FloatEvaluationChanges(CGameStatePool_SimpleGameTree *pGameStatePool);



struct CMoveDescValues
{
	int32_t MoveID = 0;
	int32_t BoardPosID = 0;
	int32_t EstimatedEvaluation = ConstMinEvaluationScore_Minimax;

	int32_t IDofResultingGameState = 0;
};


class CBreadthFirstSearchAI
{
public:

	int32_t MaxSearchDepth = 0;
	int32_t MaxSearchDepthOriginal = 0;
	int32_t NumTestGameStatesMax = 0;
	int32_t NumTestGameStatesMaxPerDepthLayer = 0;

	CExtendedGameStatePool GameStatePool;

	CTestMove TestMove;

	CRandomNumbersNN RandomNumbers;

	CMovePatternList* pUsedPlayer1MoveList = nullptr;
	CMovePatternList* pUsedPlayer2MoveList = nullptr;

	pLeafGameStatesEvalFunc Player1ViewLeafGameStatesEvalFunc = nullptr;
	pLeafGameStatesEvalFunc Player2ViewLeafGameStatesEvalFunc = nullptr;

	int32_t GameBoardSizeXY = 0;

	CMoveDescValues* pMoveDescValuesArray = nullptr;

	int32_t NumOfDifferentMoveTypes = 0;
	int32_t NumOfMoveDescriptions = 0;

	CBreadthFirstSearchAI();
	~CBreadthFirstSearchAI();

	// Kopierkonstruktor l�schen:
	CBreadthFirstSearchAI(const CBreadthFirstSearchAI& originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CBreadthFirstSearchAI& operator=(const CBreadthFirstSearchAI& originalObject) = delete;

	void Initialize(CMovePatternList* pPlayer1MoveList, CMovePatternList* pPlayer2MoveList, int32_t numTestGameStatesMax, int32_t numTestGameStatesMaxPerDepthLayer, int32_t maxSearchDepth, int32_t gameBoardSizeXDir, int32_t gameBoardSizeYDir);
	
	// necessary for discarding insufficient game states:
	void Initialize(CMovePatternList* pPlayer1MoveList, CMovePatternList* pPlayer2MoveList, int32_t numTestGameStatesMax, int32_t numTestGameStatesMaxPerDepthLayer, int32_t maxSearchDepth, int32_t gameBoardSizeXDir, int32_t gameBoardSizeYDir, pCheckGameStateEvalFunc Player1ViewFunc, pCheckGameStateEvalFunc Player2ViewFunc);
	

	void Set_Player1MoveExcludedBoardElements(int32_t numOfValues, int8_t *pValueArray);
	void Set_Player2MoveExcludedBoardElements(int32_t numOfValues, int8_t *pValueArray);

	void Set_LeafGameStatesEvaluationFunctions(pLeafGameStatesEvalFunc Player1ViewFunc, pLeafGameStatesEvalFunc Player2ViewFunc);

	void Change_Seed(uint64_t seed);

	void Use_MaxSearchDepth(void);
	void Set_SearchDepth(int32_t depth);

	void Improve_MoveOrder(int32_t numOfSortingStepsMax);

	void Execute_Player1AI(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState);
	void Execute_Player2AI(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState);

	void Execute_Player1AI(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, float* pSearchDepthMovementProbabilityArray);
	void Execute_Player2AI(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, float* pSearchDepthMovementProbabilityArray);


	void Execute_Player1AI_AvoidRepetitiveStates(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState);
	void Execute_Player2AI_AvoidRepetitiveStates(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState);

	void Execute_Player1AI_AvoidRepetitiveStates(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, float* pSearchDepthMovementProbabilityArray);
	void Execute_Player2AI_AvoidRepetitiveStates(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, float* pSearchDepthMovementProbabilityArray);


	void Execute_Player1AI_DiscardInsufficientStates(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, int32_t minTolerableEvalValuePlayer1, int32_t minTolerableEvalValuePlayer2);
	void Execute_Player2AI_DiscardInsufficientStates(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, int32_t minTolerableEvalValuePlayer1, int32_t minTolerableEvalValuePlayer2);

	void Execute_Player1AI_DiscardInsufficientStates(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, float* pSearchDepthMovementProbabilityArray, int32_t minTolerableEvalValuePlayer1, int32_t minTolerableEvalValuePlayer2);
	void Execute_Player2AI_DiscardInsufficientStates(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, float* pSearchDepthMovementProbabilityArray, int32_t minTolerableEvalValuePlayer1, int32_t minTolerableEvalValuePlayer2);
};





class CDepthFirstSearchAI
{
public:

	int32_t MaxSearchDepth = 0;
	int32_t MaxSearchDepthMinus1 = 0;
	int32_t NumTestGameStatesMax = 0;

	CExtendedGameStatePool GameStatePool;

	CTestMove* pTestMoveArray = nullptr;

	CMovePatternList* pUsedPlayer1MoveList = nullptr;
	CMovePatternList* pUsedPlayer2MoveList = nullptr;

	pGameStateEvalFunc Player1ViewGameStateEvalFunc = nullptr;
	pGameStateEvalFunc Player2ViewGameStateEvalFunc = nullptr;

	int32_t GameBoardSizeXY = 0;

	int32_t EarlyOutCounter = 0;
	int32_t MinAcceptableEvalValueEarlyOut = 0;

	bool StopFurtherExploration = false;

	CMoveDescValues* pMoveDescValuesArray = nullptr;

	CRandomNumbersNN RandomNumbers;

	int32_t NumOfDifferentMoveTypes = 0;
	int32_t NumOfMoveDescriptions = 0;
	
	CDepthFirstSearchAI();
	~CDepthFirstSearchAI();

	// Kopierkonstruktor l�schen:
	CDepthFirstSearchAI(const CDepthFirstSearchAI& originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CDepthFirstSearchAI& operator=(const CDepthFirstSearchAI& originalObject) = delete;

	void Initialize(CMovePatternList* pPlayer1MoveList, CMovePatternList* pPlayer2MoveList, int32_t numTestGameStatesMax, int32_t maxSearchDepth, int32_t gameBoardSizeXDir, int32_t gameBoardSizeYDir);
	
	// necessary for discarding insufficient game states:
	void Initialize(CMovePatternList* pPlayer1MoveList, CMovePatternList* pPlayer2MoveList, int32_t numTestGameStatesMax, int32_t maxSearchDepth, int32_t gameBoardSizeXDir, int32_t gameBoardSizeYDir, pCheckGameStateEvalFunc Player1ViewFunc, pCheckGameStateEvalFunc Player2ViewFunc);

	// must be called after Initialize():
	void Set_Player1MoveExcludedBoardElements(int32_t numOfValues, int8_t *pValueArray);
	// must be called after Initialize():
	void Set_Player2MoveExcludedBoardElements(int32_t numOfValues, int8_t *pValueArray);

	// must be called after Initialize():
	void Set_MinTolerableEvaluationValues(int32_t player1Value, int32_t player2Value);

	

	void Reset_MoveDescValuesArray(void);
	void Randomize_MoveDescValuesArray(int32_t numOfPermutationSteps);
	void Randomize_MoveDescValuesArray_OnlyBoardPosIDs(int32_t numOfPermutationSteps);
	void Randomize_MoveDescValuesArray_OnlyMoveIDs(int32_t numOfPermutationSteps);

	void Improve_MoveOrder(int32_t numOfSortingStepsMax);

	void Change_Seed(uint64_t seed);

	void Stop_FurtherExploration_From_Separate_Thread(void);

	void Set_GameStateEvaluationFunctions(pGameStateEvalFunc Player1ViewFunc, pGameStateEvalFunc Player2ViewFunc);

	//////////////////////////

	void Find_PromisingMoves_Player1View(CGameStateValues* pInActualGameState, int32_t moveOrder_NumOfSortingStepsMax, int32_t searchDepth = 1);
	void Find_PromisingMoves_Player2View(CGameStateValues* pInActualGameState, int32_t moveOrder_NumOfSortingStepsMax, int32_t searchDepth = 1);

	//////////////////////////

	int32_t IterativeDeepeningStep_Player1View(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, int32_t moveOrder_NumOfSortingStepsMax, int32_t searchDepth);
	int32_t IterativeDeepeningStep_Player2View(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, int32_t moveOrder_NumOfSortingStepsMax, int32_t searchDepth);

	int32_t IterativeDeepeningStep_Player1View_DiscardInsufficientStates(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, int32_t minTolerableEvalValuePlayer1, int32_t minTolerableEvalValuePlayer2, int32_t moveOrder_NumOfSortingStepsMax, int32_t searchDepth);
	int32_t IterativeDeepeningStep_Player2View_DiscardInsufficientStates(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, int32_t minTolerableEvalValuePlayer1, int32_t minTolerableEvalValuePlayer2, int32_t moveOrder_NumOfSortingStepsMax, int32_t searchDepth);

	int32_t IterativeDeepeningStep_Player1View_EarlyOut(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, int32_t minAcceptableEvalValuePlayer1, int32_t moveOrder_NumOfSortingStepsMax, int32_t searchDepth);
	int32_t IterativeDeepeningStep_Player2View_EarlyOut(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, int32_t minAcceptableEvalValuePlayer2, int32_t moveOrder_NumOfSortingStepsMax, int32_t searchDepth);

	int32_t IterativeDeepeningStep_Player1View_EarlyOut_DiscardInsufficientStates(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, int32_t minAcceptableEvalValuePlayer1, int32_t minTolerableEvalValuePlayer1, float minTolerableEvalValuePlayer2, int32_t moveOrder_NumOfSortingStepsMax, int32_t searchDepth);
	int32_t IterativeDeepeningStep_Player2View_EarlyOut_DiscardInsufficientStates(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, int32_t minAcceptableEvalValuePlayer2, int32_t minTolerableEvalValuePlayer1, float minTolerableEvalValuePlayer2, int32_t moveOrder_NumOfSortingStepsMax, int32_t searchDepth);


	//////////////////////////


	void Execute_Player1AI(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState);
	void Execute_Player2AI(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState);

	bool Player1AI_InnerEvalulationLoop(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth);
	bool Player2AI_InnerEvalulationLoop(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth);

	bool Player1AI_OuterEvalulationLoop(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth);
	bool Player2AI_OuterEvalulationLoop(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth);

	//////////////////////////

	void Execute_Player1AI_DiscardInsufficientStates(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, int32_t minTolerableEvalValuePlayer1, int32_t minTolerableEvalValuePlayer2);
	void Execute_Player2AI_DiscardInsufficientStates(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, int32_t minTolerableEvalValuePlayer1, int32_t minTolerableEvalValuePlayer2);

	bool Player1AI_InnerEvalulationLoop_DiscardInsufficientStates(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth);
	bool Player2AI_InnerEvalulationLoop_DiscardInsufficientStates(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth);

	bool Player1AI_OuterEvalulationLoop_DiscardInsufficientStates(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth);
	bool Player2AI_OuterEvalulationLoop_DiscardInsufficientStates(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth);

	//////////////////////////

	void Execute_Player1AI_EarlyOut(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, int32_t minAcceptableEvalValuePlayer1);
	void Execute_Player2AI_EarlyOut(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, int32_t minAcceptableEvalValuePlayer2);

	bool Player1AI_InnerEvalulationLoop_EarlyOut(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth);
	bool Player2AI_InnerEvalulationLoop_EarlyOut(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth);

	bool Player1AI_OuterEvalulationLoop_EarlyOut(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth);
	bool Player2AI_OuterEvalulationLoop_EarlyOut(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth);

	//////////////////////////

	void Execute_Player1AI_EarlyOut_DiscardInsufficientStates(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, int32_t minAcceptableEvalValuePlayer1, int32_t minTolerableEvalValuePlayer1, int32_t minTolerableEvalValuePlayer2);
	void Execute_Player2AI_EarlyOut_DiscardInsufficientStates(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, int32_t minAcceptableEvalValuePlayer2, int32_t minTolerableEvalValuePlayer1, int32_t minTolerableEvalValuePlayer2);

	bool Player1AI_InnerEvalulationLoop_EarlyOut_DiscardInsufficientStates(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth);
	bool Player2AI_InnerEvalulationLoop_EarlyOut_DiscardInsufficientStates(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth);

	bool Player1AI_OuterEvalulationLoop_EarlyOut_DiscardInsufficientStates(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth);
	bool Player2AI_OuterEvalulationLoop_EarlyOut_DiscardInsufficientStates(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth);

	//////////////////////////
	
};




#endif


