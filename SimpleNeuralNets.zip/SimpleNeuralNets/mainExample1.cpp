#include <iostream>
#include "NeuralNet.h"

using namespace std;


inline float LinearOutput(float neuronInput)
{
	return neuronInput;
}

class CSimpleMultiplierBrain
{
public:

	uint32_t NumInputNeurons = 1;
	uint32_t NumOutputNeurons = 1;

	uint32_t NumNeurons = NumInputNeurons + NumOutputNeurons;

	uint32_t InputNeuronID = 0;
	uint32_t OutputNeuronID = 1;

	CNeuron *pNeuronArray = nullptr;


	CSimpleMultiplierBrain()
	{
		pNeuronArray = new (std::nothrow) CNeuron[NumNeurons];

		uint32_t i;

		for (i = 0; i < NumNeurons; i++)
			pNeuronArray[i].Connect_With_Brain(pNeuronArray);

		float plasticity = 1.0f;

		pNeuronArray[InputNeuronID].Use_As_InputNeuron();
		pNeuronArray[InputNeuronID].Init_OutputSynapses(NumOutputNeurons);
		pNeuronArray[InputNeuronID].Connect_With_ReceiverNeuron(OutputNeuronID, /*SynapseID:*/ 0);
		pNeuronArray[InputNeuronID].Set_OutputSynapsePlasticity(plasticity, /*SynapseID:*/ 0);

		pNeuronArray[OutputNeuronID].Use_As_OutputNeuron();
		pNeuronArray[OutputNeuronID].Set_ActivationFunction(LinearOutput);
	}

	~CSimpleMultiplierBrain()
	{
		delete[] pNeuronArray;
		pNeuronArray = nullptr;
	}

	// Kopierkonstruktor l�schen:
	CSimpleMultiplierBrain(const CSimpleMultiplierBrain &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CSimpleMultiplierBrain& operator=(const CSimpleMultiplierBrain &originalObject) = delete;

	void Set_Plasticity(float plasticity)
	{
		pNeuronArray[InputNeuronID].Set_OutputSynapsePlasticity(plasticity, /*SynapseID:*/ 0);
	}

	float Calculate_Output(float input)
	{
		pNeuronArray[InputNeuronID].Set_Input(input);
		pNeuronArray[InputNeuronID].Propagate_SynapticOutput();

		pNeuronArray[OutputNeuronID].Calculate_NeuronOutput();
		return pNeuronArray[OutputNeuronID].Get_NeuronOutput();
	}
}; // end of class CSimpleMultiplierBrain

/*
int main(void)
{
	CSimpleMultiplierBrain Brain;

	float InputData[4];

	InputData[0] = 0.0f;
	InputData[1] = 1.0f;
	InputData[2] = 2.0f;
	InputData[3] = 3.0f;

	// Steigung (slope) =>  Output = slope * Input 
	float slope = 2.0f;
	Brain.Set_Plasticity(slope);
	
	// neural network tests:

	for (uint32_t i = 0; i < 4; i++)
	{
		cout << "input : " << InputData[i] << endl;
		cout << "output: " << Brain.Calculate_Output(InputData[i]) << " --- desired output: " << slope * InputData[i] << endl;
	}
	
	cout << "test input: " << 10.0f << endl;
	cout << "output: " << Brain.Calculate_Output(10.0f) << " --- desired output: " << slope * 10.0f << endl;
	

	getchar();
	return 0;
}
*/


