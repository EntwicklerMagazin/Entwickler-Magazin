// Schutz vor Mehrfachdeklarationen :

#ifndef _Sudoku_H_
#define _Sudoku_H_

#include <iostream>
#include "RandomNumbers.h"

static constexpr int32_t SudokuSizePerDir = 9;
static constexpr int32_t SudokuSizePerDirMinus1 = SudokuSizePerDir - 1;
static constexpr int32_t SudokuSizePerDirPlus1 = SudokuSizePerDir + 1;
static constexpr int32_t SudokuSizeSq = SudokuSizePerDir *  SudokuSizePerDir;

void Output_Sudoku(int32_t *pInData);

int32_t Count_EmptySudokuCells(int32_t *pInData);

bool Check_If_SudokuNumber_Could_Be_Correct(int32_t *pInOutData, int32_t row, int32_t column, int32_t number);

bool RecursiveSudokuSolver(int32_t *pInOutData, int32_t row, int32_t column);

bool Complete_SudokuRows_If_Possible(int32_t *pInOutData);
bool Complete_SudokuColumns_If_Possible(int32_t *pInOutData);
bool Complete_Sudoku3x3Blocks_If_Possible(int32_t *pInOutData);

bool Add_SudokuNumber_If_Possible(int32_t *pInOutData);
bool Add_SudokuNumber_If_Possible_Ext(int32_t *pInOutData);

int32_t Count_SudokuErrors(int32_t *pInData);

void SudokuTransposition(int32_t *pOutData, int32_t *pInData);
void SudokuPermutation(int32_t *pOutData, int32_t *pInData, int32_t number1, int32_t number2);
void HorizontalSudokuReflection(int32_t *pOutData, int32_t *pInData);
void VerticalSudokuReflection(int32_t *pOutData, int32_t *pInData);

void Swap_TwoSudokuRows(int32_t *pOutData, int32_t *pInData, int32_t blockRow1, int32_t blockRow2, int32_t _9x3BlockID);
void Swap_TwoSudokuColumns(int32_t *pOutData, int32_t *pInData, int32_t blockColumn1, int32_t blockColumn2, int32_t _3x9BlockID);

void Swap_TwoSudoku9x3Blocks(int32_t *pOutData, int32_t *pInData, int32_t block1ID, int32_t block2ID);
void Swap_TwoSudoku3x9Blocks(int32_t *pOutData, int32_t *pInData, int32_t block1ID, int32_t block2ID);



class CSudokuNode
{
public:

	int32_t GridID = 0;
	int32_t SmallestCheckedNumber = 0;

	void Reset(void);
	void Reset_GridID(void);
	void Reset_SmallestCheckedNumber(void);

	int32_t Try_To_Find_Correct_Number(int32_t *pInData);
};

class CIterativeSudokuSolver
{
public:

	int32_t NumOfNodes = 0;
	CSudokuNode *pNodeArray = nullptr;

	int32_t ActualSearchDepth = 0;

	CIterativeSudokuSolver();
	~CIterativeSudokuSolver();

	// Kopierkonstruktor l�schen:
	CIterativeSudokuSolver(const CIterativeSudokuSolver&originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CIterativeSudokuSolver& operator=(const CIterativeSudokuSolver&originalObject) = delete;

	void Initialize(int32_t *pInData);

	void Reset_NodeData(void);
	void Reset_NodeData_GridID_Only(void);
	void Reset_NodeData_SmallestCheckedNumber_Only(void);

	// returns 2 if the puzzle is finally solved:
	int32_t Try_To_Solve_Puzzle(int32_t *pInOutData);
};

class CSudokuNodeExt
{
public:

	int32_t GridID = 0;
	
	CRandomNumbersWithoutRepetition RandomNumbers;

	void Reset(void);
	void Reset_GridID(void);
	void Reset_RandomNumberSelection(void);

	int32_t Try_To_Find_Correct_Number(int32_t *pInData);
};

class CIterativeSudokuSolverExt
{
public:

	int32_t NumOfNodes = 0;
	CSudokuNodeExt *pNodeArray = nullptr;

	int32_t ActualSearchDepth = 0;

	CIterativeSudokuSolverExt();
	~CIterativeSudokuSolverExt();

	// Kopierkonstruktor l�schen:
	CIterativeSudokuSolverExt(const CIterativeSudokuSolverExt&originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CIterativeSudokuSolverExt& operator=(const CIterativeSudokuSolverExt&originalObject) = delete;

	void Initialize(int32_t *pInData, uint64_t additionalSeedValue = 0);

	void Reset_NodeData(void);
	void Reset_NodeData_GridID_Only(void);
	void Reset_NodeData_RandomNumberSelection_Only(void);

	// returns 2 if the puzzle is finally solved:
	int32_t Try_To_Solve_Puzzle(int32_t *pInOutData);
};



#endif