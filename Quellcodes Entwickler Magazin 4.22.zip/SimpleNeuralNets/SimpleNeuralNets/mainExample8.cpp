#include <iostream>
#include "NeuralNet.h"

using namespace std;

//#define NegValues

inline float ScaledSigmoidOutput(float neuronInput)
{
	// von 0.0f bis 1.0f:
	return 1.0f / (1.0f + exp(-20.0f * neuronInput));
}

inline float TanHOutput(float neuronInput)
{
	// von -1.0f bis 1.0f:
	return tanh(neuronInput);
	//return neuronInput / (1.0f + abs(neuronInput)); // alternative

	//int32_t iValue = static_cast<int32_t>(1000.0f*tanh(neuronInput));
	//float fValue = static_cast<float>(iValue);
	//return 0.001f*fValue;
}


inline float LinearOutput(float neuronInput)
{
	return neuronInput;
}

class CDecisionBrain1
{
public:

	uint32_t NumInputNeurons = 4;
	uint32_t NumBiasNeurons = 1;
	uint32_t NumHiddenNeurons = 20; 
	//uint32_t NumHiddenNeurons = 120; // faster learning
	uint32_t NumOutputNeurons = 1;

	uint32_t NumNeurons = NumInputNeurons + NumHiddenNeurons + NumOutputNeurons + NumBiasNeurons;

	uint32_t BiasNeuronID = NumInputNeurons;
	uint32_t FirstHiddenNeuronID = NumInputNeurons + NumBiasNeurons;
	uint32_t OutputNeuronID = NumInputNeurons + NumHiddenNeurons + NumBiasNeurons;

	CNeuron *pNeuronArray = nullptr;

	CRandomNumbersNN RandomNumbers;

	CDecisionBrain1()
	{
		pNeuronArray = new (std::nothrow) CNeuron[NumNeurons];

		uint32_t i, j, id;

		for (i = 0; i < NumNeurons; i++)
			pNeuronArray[i].Connect_With_Brain(pNeuronArray);

		for (i = 0; i < NumInputNeurons; i++)
		{
			pNeuronArray[i].Use_As_InputNeuron();
			pNeuronArray[i].Init_OutputSynapses(NumHiddenNeurons);
			pNeuronArray[i].Randomize_OutputSynapsePlasticities(&RandomNumbers, -0.2f, 0.2f);
			pNeuronArray[i].Set_LearningRate(0.2f);

			for (j = 0; j < NumHiddenNeurons; j++)
			{
				id = FirstHiddenNeuronID + j;

				pNeuronArray[i].Connect_With_ReceiverNeuron(id, /*SynapseID:*/ j);
			}
		}

		pNeuronArray[BiasNeuronID].Use_As_BiasNeuron();
		pNeuronArray[BiasNeuronID].Set_BiasNeuronOutput(-1.0f);
		pNeuronArray[BiasNeuronID].Init_OutputSynapses(NumHiddenNeurons);
		pNeuronArray[BiasNeuronID].Randomize_OutputSynapsePlasticities(&RandomNumbers, -0.2f, 0.2f);
		pNeuronArray[BiasNeuronID].Set_LearningRate(0.2f);

		for (j = 0; j < NumHiddenNeurons; j++)
		{
			id = FirstHiddenNeuronID + j;

			pNeuronArray[BiasNeuronID].Connect_With_ReceiverNeuron(id, /*SynapseID:*/ j);
		}


		for (i = 0; i < NumHiddenNeurons; i++)
		{
			id = FirstHiddenNeuronID + i;
			pNeuronArray[id].Use_As_HiddenNeuron();
			pNeuronArray[id].Init_OutputSynapses(NumOutputNeurons);
			pNeuronArray[id].Randomize_OutputSynapsePlasticities(&RandomNumbers, -0.2f, 0.2f);
			pNeuronArray[id].Set_ActivationFunction(ScaledSigmoidOutput);
			pNeuronArray[id].Set_LearningRate(0.2f);
			pNeuronArray[id].Set_ErrorFactors(1.0f, 1.0f);

			pNeuronArray[id].Connect_With_ReceiverNeuron(OutputNeuronID, /*SynapseID:*/ 0);
		}

		pNeuronArray[OutputNeuronID].Use_As_OutputNeuron();
		pNeuronArray[OutputNeuronID].Set_ActivationFunction(LinearOutput);
		pNeuronArray[OutputNeuronID].Set_ErrorFactors(1.0f, 0.005f);	
	}

	~CDecisionBrain1()
	{
		delete[] pNeuronArray;
		pNeuronArray = nullptr;
	}

	// Kopierkonstruktor l�schen:
	CDecisionBrain1(const CDecisionBrain1 &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CDecisionBrain1& operator=(const CDecisionBrain1 &originalObject) = delete;

	float Calculate_Output(const float *pInputPattern)
	{
		uint32_t i;

		for (i = 0; i < NumInputNeurons; i++)
		{
			pNeuronArray[i].Set_Input(pInputPattern[i]);
			pNeuronArray[i].Propagate_SynapticOutput();
		}

		pNeuronArray[BiasNeuronID].Propagate_SynapticOutput();

		uint32_t id;

		for (i = 0; i < NumHiddenNeurons; i++)
		{
			id = FirstHiddenNeuronID + i;

			pNeuronArray[id].Calculate_NeuronOutput();
			pNeuronArray[id].Propagate_SynapticOutput();
		}

		pNeuronArray[OutputNeuronID].Calculate_NeuronOutput();

		return pNeuronArray[OutputNeuronID].NeuronOutput;
	}

	float Learning(float desiredOutput)
	{
		float error = pNeuronArray[OutputNeuronID].Calculate_Error(desiredOutput);
		
		uint32_t i;
		uint32_t id;

		for (i = 0; i < NumHiddenNeurons; i++)
		{
			id = FirstHiddenNeuronID + i;
			pNeuronArray[id].Calculate_Error();
		}

		for (i = 0; i < NumHiddenNeurons; i++)
		{
			id = FirstHiddenNeuronID + i;
			pNeuronArray[id].Adjust_OutputSynapses_AfterErrorCalculations();
		}

		for (uint32_t i = 0; i < NumInputNeurons; i++)
			pNeuronArray[i].Adjust_OutputSynapses_AfterErrorCalculations();

		pNeuronArray[BiasNeuronID].Adjust_OutputSynapses_AfterErrorCalculations();

		return error;
	}

	// Nur die Plastizit�tswerte der mit dem Output-Neuron verbundenen Synapsen werden modifiziert:
	float ExtremeLearning(float desiredOutput)
	{
		float error = pNeuronArray[OutputNeuronID].Calculate_Error(desiredOutput);

		uint32_t i;
		uint32_t id;

		for (i = 0; i < NumHiddenNeurons; i++)
		{
			id = FirstHiddenNeuronID + i;
			pNeuronArray[id].Adjust_OutputSynapses_AfterErrorCalculations();
		}

		return error;
	}

}; // end of class CDecisionBrain1





/*
Mit Hilfe der vom neuronalen Netz ausgegebenen Werte k�nnte man beispielsweise auf die in einem
Array gespeicherten Funktionszeiger zugreifen. 
Hinweis: Die Funktionen, auf welche die besagten Zeiger verweisen, k�nnten dann die vom
neuronalen Netz vorgeschlagenen Aktionen ausf�hren!
*/

/*
int main(void)
{
	CDecisionBrain1 Brain;

	// values unequal to -1.0f, 0.0f or 1.0f can also be used!

#ifdef NegValues

	float DecisionPattern1[4] = { -1.0f, -1.0f, -1.0f, -1.0f };
	float DecisionPattern2[4] = { 1.0f, -1.0f, -1.0f, -1.0f };
	float DecisionPattern3[4] = { -1.0f, 1.0f, -1.0f, -1.0f };
	float DecisionPattern4[4] = { -1.0f, -1.0f, 1.0f, -1.0f };
	float DecisionPattern5[4] = { -1.0f, -1.0f, -1.0f, 1.0f };
	float DecisionPattern6[4] = { 1.0f, 1.0f, -1.0f, -1.0f };
	float DecisionPattern7[4] = { 1.0f, -1.0f, 1.0f, -1.0f };
	float DecisionPattern8[4] = { 1.0f, -1.0f, -1.0f, 1.0f };
	float DecisionPattern9[4] = { -1.0f, 1.0f, 1.0f, -1.0f };
	float DecisionPattern10[4] = { -1.0f, 1.0f, -1.0f, 1.0f };
	float DecisionPattern11[4] = { -1.0f, -1.0f, 1.0f, 1.0f };
	float DecisionPattern12[4] = { -1.0f, 1.0f, 1.0f, 1.0f };
	float DecisionPattern13[4] = { 1.0f, -1.0f, 1.0f, 1.0f };
	float DecisionPattern14[4] = { 1.0f, 1.0f, -1.0f, 1.0f };
	float DecisionPattern15[4] = { 1.0f, 1.0f, 1.0f, -1.0f };
	float DecisionPattern16[4] = { 1.0f, 1.0f, 1.0f, 1.0f };

#else

	float DecisionPattern1[4] = { 0.0f, 0.0f, 0.0f, 0.0f };
	float DecisionPattern2[4] = { 1.0f, 0.0f, 0.0f, 0.0f };
	float DecisionPattern3[4] = { 0.0f, 1.0f, 0.0f, 0.0f };
	float DecisionPattern4[4] = { 0.0f, 0.0f, 1.0f, 0.0f };
	float DecisionPattern5[4] = { 0.0f, 0.0f, 0.0f, 1.0f };
	float DecisionPattern6[4] = { 1.0f, 1.0f, 0.0f, 0.0f };
	float DecisionPattern7[4] = { 1.0f, 0.0f, 1.0f, 0.0f };
	float DecisionPattern8[4] = { 1.0f, 0.0f, 0.0f, 1.0f };
	float DecisionPattern9[4] = { 0.0f, 1.0f, 1.0f, 0.0f };
	float DecisionPattern10[4] = { 0.0f, 1.0f, 0.0f, 1.0f };
	float DecisionPattern11[4] = { 0.0f, 0.0f, 1.0f, 1.0f };
	float DecisionPattern12[4] = { 0.0f, 1.0f, 1.0f, 1.0f };
	float DecisionPattern13[4] = { 1.0f, 0.0f, 1.0f, 1.0f };
	float DecisionPattern14[4] = { 1.0f, 1.0f, 0.0f, 1.0f };
	float DecisionPattern15[4] = { 1.0f, 1.0f, 1.0f, 0.0f };
	float DecisionPattern16[4] = { 1.0f, 1.0f, 1.0f, 1.0f };

#endif	


	uint32_t maxCount = 100000;
	uint32_t epoch = 0;
	float error;

	// start training:

	for (uint32_t i = 0; i < maxCount; i++)
	{
		epoch++;
		error = 0.0f;

		Brain.Calculate_Output(DecisionPattern1);
		error += Brain.Learning(0.001f);

		Brain.Calculate_Output(DecisionPattern2);
		error += Brain.Learning(0.11f);

		Brain.Calculate_Output(DecisionPattern3);
		error += Brain.Learning(0.21f);

		Brain.Calculate_Output(DecisionPattern4);
		error += Brain.Learning(0.31f);

		Brain.Calculate_Output(DecisionPattern5);
		error += Brain.Learning(0.41f);

		Brain.Calculate_Output(DecisionPattern6);
		error += Brain.Learning(0.51f);

		Brain.Calculate_Output(DecisionPattern7);
		error += Brain.Learning(0.61f);

		Brain.Calculate_Output(DecisionPattern8);
		error += Brain.Learning(0.71f);

		Brain.Calculate_Output(DecisionPattern9);
		error += Brain.Learning(0.81f);

		Brain.Calculate_Output(DecisionPattern10);
		error += Brain.Learning(0.91f);

		Brain.Calculate_Output(DecisionPattern11);
		error += Brain.Learning(1.01f);

		Brain.Calculate_Output(DecisionPattern12);
		error += Brain.Learning(1.11f);

		Brain.Calculate_Output(DecisionPattern13);
		error += Brain.Learning(1.21f);

		Brain.Calculate_Output(DecisionPattern14);
		error += Brain.Learning(1.31f);

		Brain.Calculate_Output(DecisionPattern15);
		error += Brain.Learning(1.41f);

		Brain.Calculate_Output(DecisionPattern16);
		error += Brain.Learning(1.51f);

		if (error < 0.000001f)
			break;
	}


	// training completed

	// training statistics:

	cout << "epoch: " << epoch << endl;
	cout << "error: " << error << endl << endl;

	// neural network tests:

	cout << "Decision Pattern 01: " << 10.0f*Brain.Calculate_Output(DecisionPattern1) << " --- desired output: " << 0.1f << endl;
	cout << "Decision Pattern 02: " << 10.0f*Brain.Calculate_Output(DecisionPattern2) << " --- desired output: " << 1.1f << endl;
	cout << "Decision Pattern 03: " << 10.0f*Brain.Calculate_Output(DecisionPattern3) << " --- desired output: " << 2.1f << endl;
	cout << "Decision Pattern 04: " << 10.0f*Brain.Calculate_Output(DecisionPattern4) << " --- desired output: " << 3.1f << endl;
	cout << "Decision Pattern 05: " << 10.0f*Brain.Calculate_Output(DecisionPattern5) << " --- desired output: " << 4.1f << endl;
	cout << "Decision Pattern 06: " << 10.0f*Brain.Calculate_Output(DecisionPattern6) << " --- desired output: " << 5.1f << endl;
	cout << "Decision Pattern 07: " << 10.0f*Brain.Calculate_Output(DecisionPattern7) << " --- desired output: " << 6.1f << endl;
	cout << "Decision Pattern 08: " << 10.0f*Brain.Calculate_Output(DecisionPattern8) << " --- desired output: " << 7.1f << endl;
	cout << "Decision Pattern 09: " << 10.0f*Brain.Calculate_Output(DecisionPattern9) << " --- desired output: " << 8.1f << endl;
	cout << "Decision Pattern 10: " << 10.0f*Brain.Calculate_Output(DecisionPattern10) << " --- desired output: " << 9.1f << endl;
	cout << "Decision Pattern 11: " << 10.0f*Brain.Calculate_Output(DecisionPattern11) << " --- desired output: " << 10.1f << endl;
	cout << "Decision Pattern 12: " << 10.0f*Brain.Calculate_Output(DecisionPattern12) << " --- desired output: " << 11.1f << endl;
	cout << "Decision Pattern 13: " << 10.0f*Brain.Calculate_Output(DecisionPattern13) << " --- desired output: " << 12.1f << endl;
	cout << "Decision Pattern 14: " << 10.0f*Brain.Calculate_Output(DecisionPattern14) << " --- desired output: " << 13.1f << endl;
	cout << "Decision Pattern 15: " << 10.0f*Brain.Calculate_Output(DecisionPattern15) << " --- desired output: " << 14.1f << endl;
	cout << "Decision Pattern 16: " << 10.0f*Brain.Calculate_Output(DecisionPattern16) << " --- desired output: " << 15.1f << endl;

	getchar();
	return 0;
}
*/


/*
int main(void)
{
	CDecisionBrain1 Brain;

	// values unequal to -1.0f, 0.0f or 1.0f can also be used!

#ifdef NegValues

	float DecisionPattern1[4] = { -1.0f, -1.0f, -1.0f, -1.0f };
	float DecisionPattern2[4] = { 1.0f, -1.0f, -1.0f, -1.0f };
	float DecisionPattern3[4] = { -1.0f, 1.0f, -1.0f, -1.0f };
	float DecisionPattern4[4] = { -1.0f, -1.0f, 1.0f, -1.0f };
	float DecisionPattern5[4] = { -1.0f, -1.0f, -1.0f, 1.0f };
	float DecisionPattern6[4] = { 1.0f, 1.0f, -1.0f, -1.0f };
	float DecisionPattern7[4] = { 1.0f, -1.0f, 1.0f, -1.0f };
	float DecisionPattern8[4] = { 1.0f, -1.0f, -1.0f, 1.0f };
	float DecisionPattern9[4] = { -1.0f, 1.0f, 1.0f, -1.0f };
	float DecisionPattern10[4] = { -1.0f, 1.0f, -1.0f, 1.0f };
	float DecisionPattern11[4] = { -1.0f, -1.0f, 1.0f, 1.0f };
	float DecisionPattern12[4] = { -1.0f, 1.0f, 1.0f, 1.0f };
	float DecisionPattern13[4] = { 1.0f, -1.0f, 1.0f, 1.0f };
	float DecisionPattern14[4] = { 1.0f, 1.0f, -1.0f, 1.0f };
	float DecisionPattern15[4] = { 1.0f, 1.0f, 1.0f, -1.0f };
	float DecisionPattern16[4] = { 1.0f, 1.0f, 1.0f, 1.0f };

#else

	float DecisionPattern1[4] = { 0.0f, 0.0f, 0.0f, 0.0f };
	float DecisionPattern2[4] = { 1.0f, 0.0f, 0.0f, 0.0f };
	float DecisionPattern3[4] = { 0.0f, 1.0f, 0.0f, 0.0f };
	float DecisionPattern4[4] = { 0.0f, 0.0f, 1.0f, 0.0f };
	float DecisionPattern5[4] = { 0.0f, 0.0f, 0.0f, 1.0f };
	float DecisionPattern6[4] = { 1.0f, 1.0f, 0.0f, 0.0f };
	float DecisionPattern7[4] = { 1.0f, 0.0f, 1.0f, 0.0f };
	float DecisionPattern8[4] = { 1.0f, 0.0f, 0.0f, 1.0f };
	float DecisionPattern9[4] = { 0.0f, 1.0f, 1.0f, 0.0f };
	float DecisionPattern10[4] = { 0.0f, 1.0f, 0.0f, 1.0f };
	float DecisionPattern11[4] = { 0.0f, 0.0f, 1.0f, 1.0f };
	float DecisionPattern12[4] = { 0.0f, 1.0f, 1.0f, 1.0f };
	float DecisionPattern13[4] = { 1.0f, 0.0f, 1.0f, 1.0f };
	float DecisionPattern14[4] = { 1.0f, 1.0f, 0.0f, 1.0f };
	float DecisionPattern15[4] = { 1.0f, 1.0f, 1.0f, 0.0f };
	float DecisionPattern16[4] = { 1.0f, 1.0f, 1.0f, 1.0f };

#endif	


	uint32_t maxCount = 100000;
	uint32_t epoch = 0;
	float error;


	// start training:



	for (uint32_t i = 0; i < maxCount; i++)
	{
		epoch++;
		error = 0.0f;

		Brain.Calculate_Output(DecisionPattern1);
		error += Brain.ExtremeLearning(0.001f);

		Brain.Calculate_Output(DecisionPattern2);
		error += Brain.ExtremeLearning(0.11f);

		Brain.Calculate_Output(DecisionPattern3);
		error += Brain.ExtremeLearning(0.21f);

		Brain.Calculate_Output(DecisionPattern4);
		error += Brain.ExtremeLearning(0.31f);

		Brain.Calculate_Output(DecisionPattern5);
		error += Brain.ExtremeLearning(0.41f);

		Brain.Calculate_Output(DecisionPattern6);
		error += Brain.ExtremeLearning(0.51f);

		Brain.Calculate_Output(DecisionPattern7);
		error += Brain.ExtremeLearning(0.61f);

		Brain.Calculate_Output(DecisionPattern8);
		error += Brain.ExtremeLearning(0.71f);

		Brain.Calculate_Output(DecisionPattern9);
		error += Brain.ExtremeLearning(0.81f);

		Brain.Calculate_Output(DecisionPattern10);
		Brain.ExtremeLearning(0.91f);

		Brain.Calculate_Output(DecisionPattern11);
		error += Brain.ExtremeLearning(1.01f);

		Brain.Calculate_Output(DecisionPattern12);
		error += Brain.ExtremeLearning(1.11f);

		Brain.Calculate_Output(DecisionPattern13);
		Brain.ExtremeLearning(1.21f);

		Brain.Calculate_Output(DecisionPattern14);
		error += Brain.ExtremeLearning(1.31f);

		Brain.Calculate_Output(DecisionPattern15);
		error += Brain.ExtremeLearning(1.41f);

		Brain.Calculate_Output(DecisionPattern16);
		error += Brain.ExtremeLearning(1.51f);

		if (error < 0.000001f)
			break;
	}

	// training completed

	// training statistics:

	cout << "epoch: " << epoch << endl;
	cout << "error: " << error << endl << endl;

	// neural network tests:

	cout << "Decision Pattern 01: " << 10.0f*Brain.Calculate_Output(DecisionPattern1) << " --- desired output: " << 0.1f << endl;
	cout << "Decision Pattern 02: " << 10.0f*Brain.Calculate_Output(DecisionPattern2) << " --- desired output: " << 1.1f << endl;
	cout << "Decision Pattern 03: " << 10.0f*Brain.Calculate_Output(DecisionPattern3) << " --- desired output: " << 2.1f << endl;
	cout << "Decision Pattern 04: " << 10.0f*Brain.Calculate_Output(DecisionPattern4) << " --- desired output: " << 3.1f << endl;
	cout << "Decision Pattern 05: " << 10.0f*Brain.Calculate_Output(DecisionPattern5) << " --- desired output: " << 4.1f << endl;
	cout << "Decision Pattern 06: " << 10.0f*Brain.Calculate_Output(DecisionPattern6) << " --- desired output: " << 5.1f << endl;
	cout << "Decision Pattern 07: " << 10.0f*Brain.Calculate_Output(DecisionPattern7) << " --- desired output: " << 6.1f << endl;
	cout << "Decision Pattern 08: " << 10.0f*Brain.Calculate_Output(DecisionPattern8) << " --- desired output: " << 7.1f << endl;
	cout << "Decision Pattern 09: " << 10.0f*Brain.Calculate_Output(DecisionPattern9) << " --- desired output: " << 8.1f << endl;
	cout << "Decision Pattern 10: " << 10.0f*Brain.Calculate_Output(DecisionPattern10) << " --- desired output: " << 9.1f << endl;
	cout << "Decision Pattern 11: " << 10.0f*Brain.Calculate_Output(DecisionPattern11) << " --- desired output: " << 10.1f << endl;
	cout << "Decision Pattern 12: " << 10.0f*Brain.Calculate_Output(DecisionPattern12) << " --- desired output: " << 11.1f << endl;
	cout << "Decision Pattern 13: " << 10.0f*Brain.Calculate_Output(DecisionPattern13) << " --- desired output: " << 12.1f << endl;
	cout << "Decision Pattern 14: " << 10.0f*Brain.Calculate_Output(DecisionPattern14) << " --- desired output: " << 13.1f << endl;
	cout << "Decision Pattern 15: " << 10.0f*Brain.Calculate_Output(DecisionPattern15) << " --- desired output: " << 14.1f << endl;
	cout << "Decision Pattern 16: " << 10.0f*Brain.Calculate_Output(DecisionPattern16) << " --- desired output: " << 15.1f << endl;

	getchar();
	return 0;
}
*/




/*
int main(void)
{
	CNeuralNet Brain;

	Brain.Init_NeuralNet(16);
	Brain.Init_Input_And_OutputNeurons(4, 0.1f, true, 1, LinearOutput, 1.0f, 0.001f);
	Brain.Init_HiddenLayer1(10, false, true, ScaledSigmoidOutput, -0.2f, 0.2f, -0.2f, 0.2f, 0.1f);
	


	// values unequal to -1.0f, 0.0f or 1.0f can also be used!

#ifdef NegValues

	float DecisionPattern1[4] = { -1.0f, -1.0f, -1.0f, -1.0f };
	float DecisionPattern2[4] = { 1.0f, -1.0f, -1.0f, -1.0f };
	float DecisionPattern3[4] = { -1.0f, 1.0f, -1.0f, -1.0f };
	float DecisionPattern4[4] = { -1.0f, -1.0f, 1.0f, -1.0f };
	float DecisionPattern5[4] = { -1.0f, -1.0f, -1.0f, 1.0f };
	float DecisionPattern6[4] = { 1.0f, 1.0f, -1.0f, -1.0f };
	float DecisionPattern7[4] = { 1.0f, -1.0f, 1.0f, -1.0f };
	float DecisionPattern8[4] = { 1.0f, -1.0f, -1.0f, 1.0f };
	float DecisionPattern9[4] = { -1.0f, 1.0f, 1.0f, -1.0f };
	float DecisionPattern10[4] = { -1.0f, 1.0f, -1.0f, 1.0f };
	float DecisionPattern11[4] = { -1.0f, -1.0f, 1.0f, 1.0f };
	float DecisionPattern12[4] = { -1.0f, 1.0f, 1.0f, 1.0f };
	float DecisionPattern13[4] = { 1.0f, -1.0f, 1.0f, 1.0f };
	float DecisionPattern14[4] = { 1.0f, 1.0f, -1.0f, 1.0f };
	float DecisionPattern15[4] = { 1.0f, 1.0f, 1.0f, -1.0f };
	float DecisionPattern16[4] = { 1.0f, 1.0f, 1.0f, 1.0f };

#else

	float DecisionPattern1[4] = { 0.0f, 0.0f, 0.0f, 0.0f };
	float DecisionPattern2[4] = { 1.0f, 0.0f, 0.0f, 0.0f };
	float DecisionPattern3[4] = { 0.0f, 1.0f, 0.0f, 0.0f };
	float DecisionPattern4[4] = { 0.0f, 0.0f, 1.0f, 0.0f };
	float DecisionPattern5[4] = { 0.0f, 0.0f, 0.0f, 1.0f };
	float DecisionPattern6[4] = { 1.0f, 1.0f, 0.0f, 0.0f };
	float DecisionPattern7[4] = { 1.0f, 0.0f, 1.0f, 0.0f };
	float DecisionPattern8[4] = { 1.0f, 0.0f, 0.0f, 1.0f };
	float DecisionPattern9[4] = { 0.0f, 1.0f, 1.0f, 0.0f };
	float DecisionPattern10[4] = { 0.0f, 1.0f, 0.0f, 1.0f };
	float DecisionPattern11[4] = { 0.0f, 0.0f, 1.0f, 1.0f };
	float DecisionPattern12[4] = { 0.0f, 1.0f, 1.0f, 1.0f };
	float DecisionPattern13[4] = { 1.0f, 0.0f, 1.0f, 1.0f };
	float DecisionPattern14[4] = { 1.0f, 1.0f, 0.0f, 1.0f };
	float DecisionPattern15[4] = { 1.0f, 1.0f, 1.0f, 0.0f };
	float DecisionPattern16[4] = { 1.0f, 1.0f, 1.0f, 1.0f };

#endif	

	uint32_t maxCount = 100000;
	uint32_t epoch = 0;
	float error;

	float outputValueArray[1];
	float desiredOutputValueArray[1];

	uint64_t seed = 1;

	// start training:

	for (uint32_t i = 0; i < maxCount; i++)
	{
		epoch++;
		error = 0.0f;

		Brain.Calculate_Output(outputValueArray, DecisionPattern1);
		desiredOutputValueArray[0] = 0.001f;
		error += Brain.Learning(desiredOutputValueArray);

		Brain.Calculate_Output(outputValueArray, DecisionPattern2);
		desiredOutputValueArray[0] = 0.11f;
		error += Brain.Learning(desiredOutputValueArray);

		Brain.Calculate_Output(outputValueArray, DecisionPattern3);
		desiredOutputValueArray[0] = 0.21f;
		error += Brain.Learning(desiredOutputValueArray);

		Brain.Calculate_Output(outputValueArray, DecisionPattern4);
		desiredOutputValueArray[0] = 0.31f;
		error += Brain.Learning(desiredOutputValueArray);

		Brain.Calculate_Output(outputValueArray, DecisionPattern5);
		desiredOutputValueArray[0] = 0.41f;
		error += Brain.Learning(desiredOutputValueArray);

		Brain.Calculate_Output(outputValueArray, DecisionPattern6);
		desiredOutputValueArray[0] = 0.51f;
		error += Brain.Learning(desiredOutputValueArray);

		Brain.Calculate_Output(outputValueArray, DecisionPattern7);
		desiredOutputValueArray[0] = 0.61f;
		error += Brain.Learning(desiredOutputValueArray);

		Brain.Calculate_Output(outputValueArray, DecisionPattern8);
		desiredOutputValueArray[0] = 0.71f;
		error += Brain.Learning(desiredOutputValueArray);

		Brain.Calculate_Output(outputValueArray, DecisionPattern9);
		desiredOutputValueArray[0] = 0.81f;
		error += Brain.Learning(desiredOutputValueArray);

		Brain.Calculate_Output(outputValueArray, DecisionPattern10);
		desiredOutputValueArray[0] = 0.91f;
		error += Brain.Learning(desiredOutputValueArray);

		Brain.Calculate_Output(outputValueArray, DecisionPattern11);
		desiredOutputValueArray[0] = 1.01f;
		error += Brain.Learning(desiredOutputValueArray);

		Brain.Calculate_Output(outputValueArray, DecisionPattern12);
		desiredOutputValueArray[0] = 1.11f;
		error += Brain.Learning(desiredOutputValueArray);

		Brain.Calculate_Output(outputValueArray, DecisionPattern13);
		desiredOutputValueArray[0] = 1.21f;
		error += Brain.Learning(desiredOutputValueArray);

		Brain.Calculate_Output(outputValueArray, DecisionPattern14);
		desiredOutputValueArray[0] = 1.31f;
		error += Brain.Learning(desiredOutputValueArray);

		Brain.Calculate_Output(outputValueArray, DecisionPattern15);
		desiredOutputValueArray[0] = 1.41f;
		error += Brain.Learning(desiredOutputValueArray);

		Brain.Calculate_Output(outputValueArray, DecisionPattern16);
		desiredOutputValueArray[0] = 1.51f;
		error += Brain.Learning(desiredOutputValueArray);

		if (error < 0.000001f)
			break;

		// etwas Mutation (hilfreich, um einem eventuellen lokalen Fehlerminimum zu entkommen)
		// In unserem Fall wird der Lernvorgang sogar ein wenig beschleunigt!
		Brain.RandomChange_OutputSynapsePlasticities2(seed++, -0.00001f, 0.00001f, 1.0f);
	}

	

	// training completed

	// training statistics:

	cout << "epoch: " << epoch << endl;
	cout << "error: " << error << endl << endl;


	// neural network tests:

	Brain.Calculate_Output(outputValueArray, DecisionPattern1);
	cout << "Decision Pattern 01: " << 10.0f*outputValueArray[0] << " --- desired output: " << 0.1f << endl;

	Brain.Calculate_Output(outputValueArray, DecisionPattern2);
	cout << "Decision Pattern 02: " << 10.0f*outputValueArray[0] << " --- desired output: " << 1.1f << endl;

	Brain.Calculate_Output(outputValueArray, DecisionPattern3);
	cout << "Decision Pattern 03: " << 10.0f*outputValueArray[0] << " --- desired output: " << 2.1f << endl;

	Brain.Calculate_Output(outputValueArray, DecisionPattern4);
	cout << "Decision Pattern 04: " << 10.0f*outputValueArray[0] << " --- desired output: " << 3.1f << endl;

	Brain.Calculate_Output(outputValueArray, DecisionPattern5);
	cout << "Decision Pattern 05: " << 10.0f*outputValueArray[0] << " --- desired output: " << 4.1f << endl;

	Brain.Calculate_Output(outputValueArray, DecisionPattern6);
	cout << "Decision Pattern 06: " << 10.0f*outputValueArray[0] << " --- desired output: " << 5.1f << endl;

	Brain.Calculate_Output(outputValueArray, DecisionPattern7);
	cout << "Decision Pattern 07: " << 10.0f*outputValueArray[0] << " --- desired output: " << 6.1f << endl;

	Brain.Calculate_Output(outputValueArray, DecisionPattern8);
	cout << "Decision Pattern 08: " << 10.0f*outputValueArray[0] << " --- desired output: " << 7.1f << endl;

	Brain.Calculate_Output(outputValueArray, DecisionPattern9);
	cout << "Decision Pattern 09: " << 10.0f*outputValueArray[0] << " --- desired output: " << 8.1f << endl;

	Brain.Calculate_Output(outputValueArray, DecisionPattern10);
	cout << "Decision Pattern 10: " << 10.0f*outputValueArray[0] << " --- desired output: " << 9.1f << endl;

	Brain.Calculate_Output(outputValueArray, DecisionPattern11);
	cout << "Decision Pattern 11: " << 10.0f*outputValueArray[0] << " --- desired output: " << 10.1f << endl;

	Brain.Calculate_Output(outputValueArray, DecisionPattern12);
	cout << "Decision Pattern 12: " << 10.0f*outputValueArray[0] << " --- desired output: " << 11.1f << endl;

	Brain.Calculate_Output(outputValueArray, DecisionPattern13);
	cout << "Decision Pattern 13: " << 10.0f*outputValueArray[0] << " --- desired output: " << 12.1f << endl;

	Brain.Calculate_Output(outputValueArray, DecisionPattern14);
	cout << "Decision Pattern 14: " << 10.0f*outputValueArray[0] << " --- desired output: " << 13.1f << endl;

	Brain.Calculate_Output(outputValueArray, DecisionPattern15);
	cout << "Decision Pattern 15: " << 10.0f*outputValueArray[0] << " --- desired output: " << 14.1f << endl;

	Brain.Calculate_Output(outputValueArray, DecisionPattern16);
	cout << "Decision Pattern 16: " << 10.0f*outputValueArray[0] << " --- desired output: " << 15.1f << endl;

	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CNeuralNet Brain;

	Brain.Init_NeuralNet(26);
	Brain.Init_Input_And_OutputNeurons(4, 0.1f, true, 1, LinearOutput, 1.0f, 0.001f);
	Brain.Init_HiddenLayer1(20, false, true, ScaledSigmoidOutput, -0.2f, 0.2f, -0.2f, 0.2f, 0.1f);



	// values unequal to -1.0f, 0.0f or 1.0f can also be used!

#ifdef NegValues

	float DecisionPattern1[4] = { -1.0f, -1.0f, -1.0f, -1.0f };
	float DecisionPattern2[4] = { 1.0f, -1.0f, -1.0f, -1.0f };
	float DecisionPattern3[4] = { -1.0f, 1.0f, -1.0f, -1.0f };
	float DecisionPattern4[4] = { -1.0f, -1.0f, 1.0f, -1.0f };
	float DecisionPattern5[4] = { -1.0f, -1.0f, -1.0f, 1.0f };
	float DecisionPattern6[4] = { 1.0f, 1.0f, -1.0f, -1.0f };
	float DecisionPattern7[4] = { 1.0f, -1.0f, 1.0f, -1.0f };
	float DecisionPattern8[4] = { 1.0f, -1.0f, -1.0f, 1.0f };
	float DecisionPattern9[4] = { -1.0f, 1.0f, 1.0f, -1.0f };
	float DecisionPattern10[4] = { -1.0f, 1.0f, -1.0f, 1.0f };
	float DecisionPattern11[4] = { -1.0f, -1.0f, 1.0f, 1.0f };
	float DecisionPattern12[4] = { -1.0f, 1.0f, 1.0f, 1.0f };
	float DecisionPattern13[4] = { 1.0f, -1.0f, 1.0f, 1.0f };
	float DecisionPattern14[4] = { 1.0f, 1.0f, -1.0f, 1.0f };
	float DecisionPattern15[4] = { 1.0f, 1.0f, 1.0f, -1.0f };
	float DecisionPattern16[4] = { 1.0f, 1.0f, 1.0f, 1.0f };

#else

	float DecisionPattern1[4] = { 0.0f, 0.0f, 0.0f, 0.0f };
	float DecisionPattern2[4] = { 1.0f, 0.0f, 0.0f, 0.0f };
	float DecisionPattern3[4] = { 0.0f, 1.0f, 0.0f, 0.0f };
	float DecisionPattern4[4] = { 0.0f, 0.0f, 1.0f, 0.0f };
	float DecisionPattern5[4] = { 0.0f, 0.0f, 0.0f, 1.0f };
	float DecisionPattern6[4] = { 1.0f, 1.0f, 0.0f, 0.0f };
	float DecisionPattern7[4] = { 1.0f, 0.0f, 1.0f, 0.0f };
	float DecisionPattern8[4] = { 1.0f, 0.0f, 0.0f, 1.0f };
	float DecisionPattern9[4] = { 0.0f, 1.0f, 1.0f, 0.0f };
	float DecisionPattern10[4] = { 0.0f, 1.0f, 0.0f, 1.0f };
	float DecisionPattern11[4] = { 0.0f, 0.0f, 1.0f, 1.0f };
	float DecisionPattern12[4] = { 0.0f, 1.0f, 1.0f, 1.0f };
	float DecisionPattern13[4] = { 1.0f, 0.0f, 1.0f, 1.0f };
	float DecisionPattern14[4] = { 1.0f, 1.0f, 0.0f, 1.0f };
	float DecisionPattern15[4] = { 1.0f, 1.0f, 1.0f, 0.0f };
	float DecisionPattern16[4] = { 1.0f, 1.0f, 1.0f, 1.0f };

#endif	

	uint32_t maxCount = 100000;
	uint32_t epoch = 0;
	float error;

	float outputValueArray[1];
	float desiredOutputValueArray[1];

	uint64_t seed = 1;

	// start training:

	for (uint32_t i = 0; i < maxCount; i++)
	{
		epoch++;
		error = 0.0f;

		Brain.Calculate_Output(outputValueArray, DecisionPattern1);
		desiredOutputValueArray[0] = 0.001f;
		error += Brain.ExtremeLearning(desiredOutputValueArray);

		Brain.Calculate_Output(outputValueArray, DecisionPattern2);
		desiredOutputValueArray[0] = 0.11f;
		error += Brain.ExtremeLearning(desiredOutputValueArray);

		Brain.Calculate_Output(outputValueArray, DecisionPattern3);
		desiredOutputValueArray[0] = 0.21f;
		error += Brain.ExtremeLearning(desiredOutputValueArray);

		Brain.Calculate_Output(outputValueArray, DecisionPattern4);
		desiredOutputValueArray[0] = 0.31f;
		error += Brain.ExtremeLearning(desiredOutputValueArray);

		Brain.Calculate_Output(outputValueArray, DecisionPattern5);
		desiredOutputValueArray[0] = 0.41f;
		error += Brain.ExtremeLearning(desiredOutputValueArray);

		Brain.Calculate_Output(outputValueArray, DecisionPattern6);
		desiredOutputValueArray[0] = 0.51f;
		error += Brain.ExtremeLearning(desiredOutputValueArray);

		Brain.Calculate_Output(outputValueArray, DecisionPattern7);
		desiredOutputValueArray[0] = 0.61f;
		error += Brain.ExtremeLearning(desiredOutputValueArray);

		Brain.Calculate_Output(outputValueArray, DecisionPattern8);
		desiredOutputValueArray[0] = 0.71f;
		error += Brain.ExtremeLearning(desiredOutputValueArray);

		Brain.Calculate_Output(outputValueArray, DecisionPattern9);
		desiredOutputValueArray[0] = 0.81f;
		error += Brain.ExtremeLearning(desiredOutputValueArray);

		Brain.Calculate_Output(outputValueArray, DecisionPattern10);
		desiredOutputValueArray[0] = 0.91f;
		error += Brain.ExtremeLearning(desiredOutputValueArray);

		Brain.Calculate_Output(outputValueArray, DecisionPattern11);
		desiredOutputValueArray[0] = 1.01f;
		error += Brain.ExtremeLearning(desiredOutputValueArray);

		Brain.Calculate_Output(outputValueArray, DecisionPattern12);
		desiredOutputValueArray[0] = 1.11f;
		error += Brain.ExtremeLearning(desiredOutputValueArray);

		Brain.Calculate_Output(outputValueArray, DecisionPattern13);
		desiredOutputValueArray[0] = 1.21f;
		error += Brain.ExtremeLearning(desiredOutputValueArray);

		Brain.Calculate_Output(outputValueArray, DecisionPattern14);
		desiredOutputValueArray[0] = 1.31f;
		error += Brain.ExtremeLearning(desiredOutputValueArray);

		Brain.Calculate_Output(outputValueArray, DecisionPattern15);
		desiredOutputValueArray[0] = 1.41f;
		error += Brain.ExtremeLearning(desiredOutputValueArray);

		Brain.Calculate_Output(outputValueArray, DecisionPattern16);
		desiredOutputValueArray[0] = 1.51f;
		error += Brain.ExtremeLearning(desiredOutputValueArray);

		if (error < 0.000001f)
			break;

		// etwas Mutation (hilfreich, um einem eventuellen lokalen Fehlerminimum zu entkommen)
		// In unserem Fall wird der Lernvorgang sogar ein wenig beschleunigt!
		//Brain.RandomChange_OutputSynapsePlasticities2(seed++, -0.00001f, 0.00001f, 1.0f);
		Brain.RandomChange_OutputSynapsePlasticities2_HiddenLayer1(seed++, -0.00001f, 0.00001f, 1.0f);
	}



	// training completed

	// training statistics:

	cout << "epoch: " << epoch << endl;
	cout << "error: " << error << endl << endl;


	// neural network tests:

	Brain.Calculate_Output(outputValueArray, DecisionPattern1);
	cout << "Decision Pattern 01: " << 10.0f*outputValueArray[0] << " --- desired output: " << 0.1f << endl;

	Brain.Calculate_Output(outputValueArray, DecisionPattern2);
	cout << "Decision Pattern 02: " << 10.0f*outputValueArray[0] << " --- desired output: " << 1.1f << endl;

	Brain.Calculate_Output(outputValueArray, DecisionPattern3);
	cout << "Decision Pattern 03: " << 10.0f*outputValueArray[0] << " --- desired output: " << 2.1f << endl;

	Brain.Calculate_Output(outputValueArray, DecisionPattern4);
	cout << "Decision Pattern 04: " << 10.0f*outputValueArray[0] << " --- desired output: " << 3.1f << endl;

	Brain.Calculate_Output(outputValueArray, DecisionPattern5);
	cout << "Decision Pattern 05: " << 10.0f*outputValueArray[0] << " --- desired output: " << 4.1f << endl;

	Brain.Calculate_Output(outputValueArray, DecisionPattern6);
	cout << "Decision Pattern 06: " << 10.0f*outputValueArray[0] << " --- desired output: " << 5.1f << endl;

	Brain.Calculate_Output(outputValueArray, DecisionPattern7);
	cout << "Decision Pattern 07: " << 10.0f*outputValueArray[0] << " --- desired output: " << 6.1f << endl;

	Brain.Calculate_Output(outputValueArray, DecisionPattern8);
	cout << "Decision Pattern 08: " << 10.0f*outputValueArray[0] << " --- desired output: " << 7.1f << endl;

	Brain.Calculate_Output(outputValueArray, DecisionPattern9);
	cout << "Decision Pattern 09: " << 10.0f*outputValueArray[0] << " --- desired output: " << 8.1f << endl;

	Brain.Calculate_Output(outputValueArray, DecisionPattern10);
	cout << "Decision Pattern 10: " << 10.0f*outputValueArray[0] << " --- desired output: " << 9.1f << endl;

	Brain.Calculate_Output(outputValueArray, DecisionPattern11);
	cout << "Decision Pattern 11: " << 10.0f*outputValueArray[0] << " --- desired output: " << 10.1f << endl;

	Brain.Calculate_Output(outputValueArray, DecisionPattern12);
	cout << "Decision Pattern 12: " << 10.0f*outputValueArray[0] << " --- desired output: " << 11.1f << endl;

	Brain.Calculate_Output(outputValueArray, DecisionPattern13);
	cout << "Decision Pattern 13: " << 10.0f*outputValueArray[0] << " --- desired output: " << 12.1f << endl;

	Brain.Calculate_Output(outputValueArray, DecisionPattern14);
	cout << "Decision Pattern 14: " << 10.0f*outputValueArray[0] << " --- desired output: " << 13.1f << endl;

	Brain.Calculate_Output(outputValueArray, DecisionPattern15);
	cout << "Decision Pattern 15: " << 10.0f*outputValueArray[0] << " --- desired output: " << 14.1f << endl;

	Brain.Calculate_Output(outputValueArray, DecisionPattern16);
	cout << "Decision Pattern 16: " << 10.0f*outputValueArray[0] << " --- desired output: " << 15.1f << endl;

	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CNeuralNet Brain;

	Brain.Init_NeuralNet(37);
	Brain.Init_Input_And_OutputNeurons(4, 0.1f, true, 2, LinearOutput, 1.0f, 0.001f);
	Brain.Init_HiddenLayer1(30, false, true, ScaledSigmoidOutput, -0.2f, 0.2f, -0.2f, 0.2f, 0.1f);


	// values unequal to -1.0f, 0.0f or 1.0f can also be used!

#ifdef NegValues

	float DecisionPattern1[4] = { -1.0f, -1.0f, -1.0f, -1.0f };
	float DecisionPattern2[4] = { 1.0f, -1.0f, -1.0f, -1.0f };
	float DecisionPattern3[4] = { -1.0f, 1.0f, -1.0f, -1.0f };
	float DecisionPattern4[4] = { -1.0f, -1.0f, 1.0f, -1.0f };
	float DecisionPattern5[4] = { -1.0f, -1.0f, -1.0f, 1.0f };
	float DecisionPattern6[4] = { 1.0f, 1.0f, -1.0f, -1.0f };
	float DecisionPattern7[4] = { 1.0f, -1.0f, 1.0f, -1.0f };
	float DecisionPattern8[4] = { 1.0f, -1.0f, -1.0f, 1.0f };
	float DecisionPattern9[4] = { -1.0f, 1.0f, 1.0f, -1.0f };
	float DecisionPattern10[4] = { -1.0f, 1.0f, -1.0f, 1.0f };
	float DecisionPattern11[4] = { -1.0f, -1.0f, 1.0f, 1.0f };
	float DecisionPattern12[4] = { -1.0f, 1.0f, 1.0f, 1.0f };
	float DecisionPattern13[4] = { 1.0f, -1.0f, 1.0f, 1.0f };
	float DecisionPattern14[4] = { 1.0f, 1.0f, -1.0f, 1.0f };
	float DecisionPattern15[4] = { 1.0f, 1.0f, 1.0f, -1.0f };
	float DecisionPattern16[4] = { 1.0f, 1.0f, 1.0f, 1.0f };

#else

	float DecisionPattern1[4] = { 0.0f, 0.0f, 0.0f, 0.0f };
	float DecisionPattern2[4] = { 1.0f, 0.0f, 0.0f, 0.0f };
	float DecisionPattern3[4] = { 0.0f, 1.0f, 0.0f, 0.0f };
	float DecisionPattern4[4] = { 0.0f, 0.0f, 1.0f, 0.0f };
	float DecisionPattern5[4] = { 0.0f, 0.0f, 0.0f, 1.0f };
	float DecisionPattern6[4] = { 1.0f, 1.0f, 0.0f, 0.0f };
	float DecisionPattern7[4] = { 1.0f, 0.0f, 1.0f, 0.0f };
	float DecisionPattern8[4] = { 1.0f, 0.0f, 0.0f, 1.0f };
	float DecisionPattern9[4] = { 0.0f, 1.0f, 1.0f, 0.0f };
	float DecisionPattern10[4] = { 0.0f, 1.0f, 0.0f, 1.0f };
	float DecisionPattern11[4] = { 0.0f, 0.0f, 1.0f, 1.0f };
	float DecisionPattern12[4] = { 0.0f, 1.0f, 1.0f, 1.0f };
	float DecisionPattern13[4] = { 1.0f, 0.0f, 1.0f, 1.0f };
	float DecisionPattern14[4] = { 1.0f, 1.0f, 0.0f, 1.0f };
	float DecisionPattern15[4] = { 1.0f, 1.0f, 1.0f, 0.0f };
	float DecisionPattern16[4] = { 1.0f, 1.0f, 1.0f, 1.0f };

#endif	

	uint32_t maxCount = 100000;
	uint32_t epoch = 0;
	float error;

	float desiredOutputValue;

	uint64_t seed = 1;

	// start training:

	for (uint32_t i = 0; i < maxCount; i++)
	{
		epoch++;
		error = 0.0f;

		Brain.Calculate_Output2(DecisionPattern1, 0);
		desiredOutputValue = 0.001f;
		error += Brain.ExtremeLearning(desiredOutputValue, 0);

		Brain.Calculate_Output2(DecisionPattern2, 0);
		desiredOutputValue = 0.11f;
		error += Brain.ExtremeLearning(desiredOutputValue, 0);

		Brain.Calculate_Output2(DecisionPattern3, 0);
		desiredOutputValue = 0.21f;
		error += Brain.ExtremeLearning(desiredOutputValue, 0);

		Brain.Calculate_Output2(DecisionPattern4, 0);
		desiredOutputValue = 0.31f;
		error += Brain.ExtremeLearning(desiredOutputValue, 0);

		Brain.Calculate_Output2(DecisionPattern5, 0);
		desiredOutputValue = 0.41f;
		error += Brain.ExtremeLearning(desiredOutputValue, 0);

		Brain.Calculate_Output2(DecisionPattern6, 0);
		desiredOutputValue = 0.51f;
		error += Brain.ExtremeLearning(desiredOutputValue, 0);

		Brain.Calculate_Output2(DecisionPattern7, 0);
		desiredOutputValue = 0.61f;
		error += Brain.ExtremeLearning(desiredOutputValue, 0);

		Brain.Calculate_Output2(DecisionPattern8, 0);
		desiredOutputValue = 0.71f;
		error += Brain.ExtremeLearning(desiredOutputValue, 0);

		Brain.Calculate_Output2(DecisionPattern8, 0);
		desiredOutputValue = 0.71f;
		error += Brain.ExtremeLearning(desiredOutputValue, 0);

		
		if (error < 0.000001f)
			break;
	}

	// training statistics:

	cout << "epoch: " << epoch << endl;
	cout << "error: " << error << endl << endl;

	epoch = 0;

	for (uint32_t i = 0; i < maxCount; i++)
	{
		epoch++;
		error = 0.0f;

		Brain.Calculate_Output2(DecisionPattern9, 1);
		desiredOutputValue = 0.81f;
		error += Brain.ExtremeLearning(desiredOutputValue, 1);

		Brain.Calculate_Output2(DecisionPattern10, 1);
		desiredOutputValue = 0.91f;
		error += Brain.ExtremeLearning(desiredOutputValue, 1);

		Brain.Calculate_Output2(DecisionPattern11, 1);
		desiredOutputValue = 1.01f;
		error += Brain.ExtremeLearning(desiredOutputValue, 1);

		Brain.Calculate_Output2(DecisionPattern12, 1);
		desiredOutputValue = 1.11f;
		error += Brain.ExtremeLearning(desiredOutputValue, 1);

		Brain.Calculate_Output2(DecisionPattern13, 1);
		desiredOutputValue = 1.21f;
		error += Brain.ExtremeLearning(desiredOutputValue, 1);

		Brain.Calculate_Output2(DecisionPattern14, 1);
		desiredOutputValue = 1.31f;
		error += Brain.ExtremeLearning(desiredOutputValue, 1);

		Brain.Calculate_Output2(DecisionPattern15, 1);
		desiredOutputValue = 1.41f;
		error += Brain.ExtremeLearning(desiredOutputValue, 1);

		Brain.Calculate_Output2(DecisionPattern16, 1);
		desiredOutputValue = 1.51f;
		error += Brain.ExtremeLearning(desiredOutputValue, 1);

		
		if (error < 0.000001f)
			break;
	}


	// training statistics:

	cout << "epoch: " << epoch << endl;
	cout << "error: " << error << endl << endl;


	// training completed

	


	// neural network tests:

	float outputValue;

	outputValue = Brain.Calculate_Output2(DecisionPattern1, 0);
	cout << "Decision Pattern 01: " << 10.0f*outputValue << " --- desired output: " << 0.1f << endl;

	outputValue = Brain.Calculate_Output2(DecisionPattern2, 0);
	cout << "Decision Pattern 02: " << 10.0f*outputValue << " --- desired output: " << 1.1f << endl;

	outputValue = Brain.Calculate_Output2(DecisionPattern3, 0);
	cout << "Decision Pattern 03: " << 10.0f*outputValue << " --- desired output: " << 2.1f << endl;

	outputValue = Brain.Calculate_Output2(DecisionPattern4, 0);
	cout << "Decision Pattern 04: " << 10.0f*outputValue << " --- desired output: " << 3.1f << endl;

	outputValue = Brain.Calculate_Output2(DecisionPattern5, 0);
	cout << "Decision Pattern 05: " << 10.0f*outputValue << " --- desired output: " << 4.1f << endl;

	outputValue = Brain.Calculate_Output2(DecisionPattern6, 0);
	cout << "Decision Pattern 06: " << 10.0f*outputValue << " --- desired output: " << 5.1f << endl;

	outputValue = Brain.Calculate_Output2(DecisionPattern7, 0);
	cout << "Decision Pattern 07: " << 10.0f*outputValue << " --- desired output: " << 6.1f << endl;

	outputValue = Brain.Calculate_Output2(DecisionPattern8, 0);
	cout << "Decision Pattern 08: " << 10.0f*outputValue << " --- desired output: " << 7.1f << endl;

	outputValue = Brain.Calculate_Output2(DecisionPattern9, 1);
	cout << "Decision Pattern 09: " << 10.0f*outputValue << " --- desired output: " << 8.1f << endl;

	outputValue = Brain.Calculate_Output2(DecisionPattern10, 1);
	cout << "Decision Pattern 10: " << 10.0f*outputValue << " --- desired output: " << 9.1f << endl;

	outputValue = Brain.Calculate_Output2(DecisionPattern11, 1);
	cout << "Decision Pattern 11: " << 10.0f*outputValue << " --- desired output: " << 10.1f << endl;

	outputValue = Brain.Calculate_Output2(DecisionPattern12, 1);
	cout << "Decision Pattern 12: " << 10.0f*outputValue << " --- desired output: " << 11.1f << endl;

	outputValue = Brain.Calculate_Output2(DecisionPattern13, 1);
	cout << "Decision Pattern 13: " << 10.0f*outputValue << " --- desired output: " << 12.1f << endl;

	outputValue = Brain.Calculate_Output2(DecisionPattern14, 1);
	cout << "Decision Pattern 14: " << 10.0f*outputValue << " --- desired output: " << 13.1f << endl;

	outputValue = Brain.Calculate_Output2(DecisionPattern15, 1);
	cout << "Decision Pattern 15: " << 10.0f*outputValue << " --- desired output: " << 14.1f << endl;

	outputValue = Brain.Calculate_Output2(DecisionPattern16, 1);
	cout << "Decision Pattern 16: " << 10.0f*outputValue << " --- desired output: " << 15.1f << endl;

	getchar();
	return 0;
}
*/





