#include "GameStateHandler.h"


using namespace std;
using namespace HelperStuff;

C1DimMoveDesc::C1DimMoveDesc()
{}

C1DimMoveDesc::~C1DimMoveDesc()
{}

void C1DimMoveDesc::Reset(void)
{
	id_Old = -1;
	id_New = -1;

	iEvaluation = -2000000;
	fEvaluation = -2000000.0f;
}

void C1DimMoveDesc::Clone_Data(C1DimMoveDesc *pOriginalObject)
{
	id_Old = pOriginalObject->id_Old;
	id_New = pOriginalObject->id_New;

	iEvaluation = pOriginalObject->iEvaluation;
	fEvaluation = pOriginalObject->fEvaluation;
}

C2DimMoveDesc::C2DimMoveDesc()
{}

C2DimMoveDesc::~C2DimMoveDesc()
{}

void C2DimMoveDesc::Reset(void)
{
	ix_Old = -1;
	iy_Old = -1;

	ix_New = -1;
	iy_New = -1;

	iEvaluation = -2000000;
	fEvaluation = -2000000.0f;
}

void C2DimMoveDesc::Clone_Data(C2DimMoveDesc *pOriginalObject)
{
	ix_Old = pOriginalObject->ix_Old;
	iy_Old = pOriginalObject->iy_Old;

	ix_New = pOriginalObject->ix_New;
	iy_New = pOriginalObject->iy_New;

	iEvaluation = pOriginalObject->iEvaluation;
	fEvaluation = pOriginalObject->fEvaluation;
}


C3DimMoveDesc::C3DimMoveDesc()
{}

C3DimMoveDesc::~C3DimMoveDesc()
{}

void C3DimMoveDesc::Reset(void)
{
	ix_Old = -1;
	iy_Old = -1;
	iz_Old = -1;

	ix_New = -1;
	iy_New = -1;
	iz_New = -1;

	iEvaluation = -2000000;
	fEvaluation = -2000000.0f;
}

void C3DimMoveDesc::Clone_Data(C3DimMoveDesc *pOriginalObject)
{
	ix_Old = pOriginalObject->ix_Old;
	iy_Old = pOriginalObject->iy_Old;
	iz_Old = pOriginalObject->iz_Old;

	ix_New = pOriginalObject->ix_New;
	iy_New = pOriginalObject->iy_New;
	iz_New = pOriginalObject->iz_New;

	iEvaluation = pOriginalObject->iEvaluation;
	fEvaluation = pOriginalObject->fEvaluation;
}

void Update_ListOfBestMoves_IntegerEvaluation(C1DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C1DimMoveDesc* pInMoveDesc)
{
	int32_t iEvaluation = pInMoveDesc->iEvaluation;

	for (int32_t j = 0; j < numOfBestMoves; j++)
	{
		if (iEvaluation > pOutBestMoveDescArray[j].iEvaluation)
		{
			for (uint32_t k = numOfBestMoves - 1; k > j; k--)
			{
				pOutBestMoveDescArray[k].Clone_Data(&pOutBestMoveDescArray[k - 1]);
			}

			pOutBestMoveDescArray[j].Clone_Data(pInMoveDesc);

			break;
		}
	}	
}

void Update_ListOfBestMoves_IntegerEvaluation(C2DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C2DimMoveDesc* pInMoveDesc)
{
	int32_t iEvaluation = pInMoveDesc->iEvaluation;

	for (int32_t j = 0; j < numOfBestMoves; j++)
	{
		if (iEvaluation >= pOutBestMoveDescArray[j].iEvaluation)
		{
			for (uint32_t k = numOfBestMoves - 1; k > j; k--)
			{
				pOutBestMoveDescArray[k].Clone_Data(&pOutBestMoveDescArray[k - 1]);
			}

			pOutBestMoveDescArray[j].Clone_Data(pInMoveDesc);

			break;
		}
	}
}

void Update_ListOfBestMoves_IntegerEvaluation(C3DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C3DimMoveDesc* pInMoveDesc)
{
	int32_t iEvaluation = pInMoveDesc->iEvaluation;

	for (int32_t j = 0; j < numOfBestMoves; j++)
	{
		if (iEvaluation >= pOutBestMoveDescArray[j].iEvaluation)
		{
			for (uint32_t k = numOfBestMoves - 1; k > j; k--)
			{
				pOutBestMoveDescArray[k].Clone_Data(&pOutBestMoveDescArray[k - 1]);
			}

			pOutBestMoveDescArray[j].Clone_Data(pInMoveDesc);

			break;
		}
	}
}

void Update_ListOfBestMoves_FloatEvaluation(C1DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C1DimMoveDesc* pInMoveDesc)
{
	float fEvaluation = pInMoveDesc->fEvaluation;

	for (int32_t j = 0; j < numOfBestMoves; j++)
	{
		if (fEvaluation >= pOutBestMoveDescArray[j].fEvaluation)
		{
			for (uint32_t k = numOfBestMoves - 1; k > j; k--)
			{
				pOutBestMoveDescArray[k].Clone_Data(&pOutBestMoveDescArray[k - 1]);
			}

			pOutBestMoveDescArray[j].Clone_Data(pInMoveDesc);

			break;
		}
	}
}

void Update_ListOfBestMoves_FloatEvaluation(C2DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C2DimMoveDesc* pInMoveDesc)
{
	float fEvaluation = pInMoveDesc->fEvaluation;

	for (int32_t j = 0; j < numOfBestMoves; j++)
	{
		if (fEvaluation >= pOutBestMoveDescArray[j].fEvaluation)
		{
			for (uint32_t k = numOfBestMoves - 1; k > j; k--)
			{
				pOutBestMoveDescArray[k].Clone_Data(&pOutBestMoveDescArray[k - 1]);
			}

			pOutBestMoveDescArray[j].Clone_Data(pInMoveDesc);

			break;
		}
	}
}

void Update_ListOfBestMoves_FloatEvaluation(C3DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C3DimMoveDesc* pInMoveDesc)
{
	float fEvaluation = pInMoveDesc->fEvaluation;

	for (int32_t j = 0; j < numOfBestMoves; j++)
	{
		if (fEvaluation >= pOutBestMoveDescArray[j].fEvaluation)
		{
			for (uint32_t k = numOfBestMoves - 1; k > j; k--)
			{
				pOutBestMoveDescArray[k].Clone_Data(&pOutBestMoveDescArray[k - 1]);
			}

			pOutBestMoveDescArray[j].Clone_Data(pInMoveDesc);

			break;
		}
	}
}

void Generate_ListOfBestMoves_IntegerEvaluation(C1DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C1DimMoveDesc* pInMoveDescArray, int32_t numOfMoves)
{
	numOfMoves = min(numOfMoves, numOfBestMoves);

	for (int32_t i = 0; i < numOfBestMoves; i++)
	{
		pOutBestMoveDescArray[i].Reset();
	}

	for (int32_t i = 0; i < numOfMoves; i++)
	{
		int32_t iEvaluation = pInMoveDescArray[i].iEvaluation;

		for (int32_t j = 0; j < numOfBestMoves; j++)
		{
			if (iEvaluation >= pOutBestMoveDescArray[j].iEvaluation)
			{
				for (uint32_t k = numOfBestMoves - 1; k > j; k--)
				{
					pOutBestMoveDescArray[k].Clone_Data(&pOutBestMoveDescArray[k - 1]);
				}

				pOutBestMoveDescArray[j].Clone_Data(&pInMoveDescArray[i]);

				break;
			}
		}
	}
}

void Generate_ListOfBestMoves_IntegerEvaluation(C2DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C2DimMoveDesc* pInMoveDescArray, int32_t numOfMoves)
{
	numOfMoves = min(numOfMoves, numOfBestMoves);

	for (int32_t i = 0; i < numOfBestMoves; i++)
	{
		pOutBestMoveDescArray[i].Reset();
	}

	for (int32_t i = 0; i < numOfMoves; i++)
	{
		int32_t iEvaluation = pInMoveDescArray[i].iEvaluation;

		for (int32_t j = 0; j < numOfBestMoves; j++)
		{
			if (iEvaluation >= pOutBestMoveDescArray[j].iEvaluation)
			{
				for (uint32_t k = numOfBestMoves - 1; k > j; k--)
				{
					pOutBestMoveDescArray[k].Clone_Data(&pOutBestMoveDescArray[k - 1]);
				}

				pOutBestMoveDescArray[j].Clone_Data(&pInMoveDescArray[i]);

				break;
			}
		}
	}
}

void Generate_ListOfBestMoves_IntegerEvaluation(C3DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C3DimMoveDesc* pInMoveDescArray, int32_t numOfMoves)
{
	numOfMoves = min(numOfMoves, numOfBestMoves);

	for (int32_t i = 0; i < numOfBestMoves; i++)
	{
		pOutBestMoveDescArray[i].Reset();
	}

	for (int32_t i = 0; i < numOfMoves; i++)
	{
		int32_t iEvaluation = pInMoveDescArray[i].iEvaluation;

		for (int32_t j = 0; j < numOfBestMoves; j++)
		{
			if (iEvaluation >= pOutBestMoveDescArray[j].iEvaluation)
			{
				for (uint32_t k = numOfBestMoves - 1; k > j; k--)
				{
					pOutBestMoveDescArray[k].Clone_Data(&pOutBestMoveDescArray[k - 1]);
				}

				pOutBestMoveDescArray[j].Clone_Data(&pInMoveDescArray[i]);

				break;
			}
		}
	}
}

void Generate_ListOfBestMoves_FloatEvaluation(C1DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C1DimMoveDesc* pInMoveDescArray, int32_t numOfMoves)
{
	numOfMoves = min(numOfMoves, numOfBestMoves);

	for (int32_t i = 0; i < numOfBestMoves; i++)
	{
		pOutBestMoveDescArray[i].Reset();
	}

	for (int32_t i = 0; i < numOfMoves; i++)
	{
		float fEvaluation = pInMoveDescArray[i].fEvaluation;

		for (int32_t j = 0; j < numOfBestMoves; j++)
		{
			if (fEvaluation >= pOutBestMoveDescArray[j].fEvaluation)
			{
				for (uint32_t k = numOfBestMoves - 1; k > j; k--)
				{
					pOutBestMoveDescArray[k] = pOutBestMoveDescArray[k - 1];
					//pOutBestMoveDescArray[k].Clone_Data(&pOutBestMoveDescArray[k - 1]);
				}

				pOutBestMoveDescArray[j] = pInMoveDescArray[i];
				//pOutBestMoveDescArray[j].Clone_Data(&pInMoveDescArray[i]);

				break;
			}
		}
	}
}

void Generate_ListOfBestMoves_FloatEvaluation(C2DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C2DimMoveDesc* pInMoveDescArray, int32_t numOfMoves)
{
	numOfMoves = min(numOfMoves, numOfBestMoves);

	for (int32_t i = 0; i < numOfBestMoves; i++)
	{
		pOutBestMoveDescArray[i].Reset();
	}

	for (int32_t i = 0; i < numOfMoves; i++)
	{
		float fEvaluation = pInMoveDescArray[i].fEvaluation;

		for (int32_t j = 0; j < numOfBestMoves; j++)
		{
			if (fEvaluation >= pOutBestMoveDescArray[j].fEvaluation)
			{
				for (uint32_t k = numOfBestMoves - 1; k > j; k--)
				{
					pOutBestMoveDescArray[k].Clone_Data(&pOutBestMoveDescArray[k - 1]);
				}

				pOutBestMoveDescArray[j].Clone_Data(&pInMoveDescArray[i]);

				break;
			}
		}
	}
}

void Generate_ListOfBestMoves_FloatEvaluation(C3DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C3DimMoveDesc* pInMoveDescArray, int32_t numOfMoves)
{
	numOfMoves = min(numOfMoves, numOfBestMoves);

	for (int32_t i = 0; i < numOfBestMoves; i++)
	{
		pOutBestMoveDescArray[i].Reset();
	}

	for (int32_t i = 0; i < numOfMoves; i++)
	{
		float fEvaluation = pInMoveDescArray[i].fEvaluation;

		for (int32_t j = 0; j < numOfBestMoves; j++)
		{
			if (fEvaluation >= pOutBestMoveDescArray[j].fEvaluation)
			{
				for (uint32_t k = numOfBestMoves - 1; k > j; k--)
				{
					pOutBestMoveDescArray[k].Clone_Data(&pOutBestMoveDescArray[k - 1]);
				}

				pOutBestMoveDescArray[j].Clone_Data(&pInMoveDescArray[i]);

				break;
			}
		}
	}
}


CGameStateValues::CGameStateValues()
{

}

CGameStateValues::~CGameStateValues()
{
	delete[] pValueArray;
	pValueArray = nullptr;
}

void CGameStateValues::Set_EvaluationValue(float value)
{
	fEvaluation = value;
}

void CGameStateValues::Set_EvaluationValue(int32_t value)
{
	iEvaluation = value;
}

void CGameStateValues::Update_Evaluation(int32_t valueOfChange)
{
	iEvaluationChange = valueOfChange;
	iEvaluation += valueOfChange;
}

void CGameStateValues::Update_Evaluation(float valueOfChange)
{
	fEvaluationChange = valueOfChange;
	fEvaluation += valueOfChange;
}


void CGameStateValues::Backpropagate_IntegerEvaluationChange(void)
{
	if (DepthValue < 1)
	{
		return;
	}

	pUsedGameStateArray[IDofPrevGameState].iEvaluationChange = iEvaluationChange;
	pUsedGameStateArray[IDofPrevGameState].iEvaluation += iEvaluationChange;
}

void CGameStateValues::Backpropagate_MinimaxIntegerEvaluation(void)
{
	if (DepthValue < 1)
	{
		return;
	}

	if (pUsedGameStateArray[IDofPrevGameState].Minimizer == true)
	{
		if (pUsedGameStateArray[IDofPrevGameState].iEvaluation > iEvaluation)
		{
			pUsedGameStateArray[IDofPrevGameState].iEvaluation = iEvaluation;
		}
	}
	else
	{
		if (pUsedGameStateArray[IDofPrevGameState].iEvaluation < iEvaluation)
		{
			pUsedGameStateArray[IDofPrevGameState].iEvaluation = iEvaluation;
		}
	}
}

void CGameStateValues::Backpropagate_IntegerEvaluationChange(int32_t intendedDepth)
{
	if (DepthValue != intendedDepth)
	{
		return;
	}

	pUsedGameStateArray[IDofPrevGameState].iEvaluationChange = iEvaluationChange;
	pUsedGameStateArray[IDofPrevGameState].iEvaluation += iEvaluationChange;
}

void CGameStateValues::Backpropagate_MinimaxIntegerEvaluation(int32_t intendedDepth)
{
	if (DepthValue != intendedDepth)
	{
		return;
	}

	if (pUsedGameStateArray[IDofPrevGameState].Minimizer == true)
	{
		if (pUsedGameStateArray[IDofPrevGameState].iEvaluation > iEvaluation)
		{
			pUsedGameStateArray[IDofPrevGameState].iEvaluation = iEvaluation;
		}
	}
	else
	{
		if (pUsedGameStateArray[IDofPrevGameState].iEvaluation < iEvaluation)
		{
			pUsedGameStateArray[IDofPrevGameState].iEvaluation = iEvaluation;
		}
	}
}

void CGameStateValues::Backpropagate_FloatEvaluationChange(void)
{
	if (DepthValue < 1)
	{
		return;
	}

	pUsedGameStateArray[IDofPrevGameState].fEvaluationChange = fEvaluationChange;
	pUsedGameStateArray[IDofPrevGameState].fEvaluation += fEvaluationChange;
}

void CGameStateValues::Backpropagate_MinimaxFloatEvaluation(void)
{
	if (DepthValue < 1)
	{
		return;
	}

	if (pUsedGameStateArray[IDofPrevGameState].Minimizer == true)
	{
		if (pUsedGameStateArray[IDofPrevGameState].fEvaluation > fEvaluation)
		{
			pUsedGameStateArray[IDofPrevGameState].fEvaluation = fEvaluation;
		}
	}
	else
	{
		if (pUsedGameStateArray[IDofPrevGameState].fEvaluation < fEvaluation)
		{
			pUsedGameStateArray[IDofPrevGameState].fEvaluation = fEvaluation;
		}
	}
}

void CGameStateValues::Backpropagate_FloatEvaluationChange(int32_t intendedDepth)
{
	if (DepthValue != intendedDepth)
	{
		return;
	}

	pUsedGameStateArray[IDofPrevGameState].fEvaluationChange = fEvaluationChange;
	pUsedGameStateArray[IDofPrevGameState].fEvaluation += fEvaluationChange;
}

void CGameStateValues::Backpropagate_MinimaxFloatEvaluation(int32_t intendedDepth)
{
	if (DepthValue != intendedDepth)
	{
		return;
	}

	if (pUsedGameStateArray[IDofPrevGameState].Minimizer == true)
	{
		if (pUsedGameStateArray[IDofPrevGameState].fEvaluation > fEvaluation)
		{
			pUsedGameStateArray[IDofPrevGameState].fEvaluation = fEvaluation;
		}
	}
	else
	{
		if (pUsedGameStateArray[IDofPrevGameState].fEvaluation < fEvaluation)
		{
			pUsedGameStateArray[IDofPrevGameState].fEvaluation = fEvaluation;
		}
	}
}




void CGameStateValues::Reset_Evaluation(void)
{
	iEvaluation = -2000000;
	fEvaluation = -2000000.0f;
	FurtherExploration = true;
}

void CGameStateValues::Connect_With_GameStateArray(CGameStateValues *pGameStateArray)
{
	pUsedGameStateArray = pGameStateArray;
}

void CGameStateValues::Set_Value(int8_t value, int32_t id)
{
	pValueArray[id] = value;
}

int8_t CGameStateValues::Get_Value(int32_t id)
{
	return pValueArray[id];
}

void CGameStateValues::Set_Value(int8_t value, int32_t ix, int32_t iy)
{
	pValueArray[ix + SizeX * iy] = value;
}

int8_t CGameStateValues::Get_Value(int32_t ix, int32_t iy)
{
	return pValueArray[ix + SizeX * iy];
}

void CGameStateValues::Set_Value(int8_t value, int32_t ix, int32_t iy, int32_t iz)
{
	pValueArray[ix + SizeX * iy + SizeXY * iz] = value;
}

int8_t CGameStateValues::Get_Value(int32_t ix, int32_t iy, int32_t iz)
{
	return pValueArray[ix + SizeX * iy + SizeXY * iz];
}


int32_t CGameStateValues::Get_ID_From_CartesianCoord(int32_t ix, int32_t iy)
{
	return ix + SizeX * iy;
}

int32_t CGameStateValues::Get_ID_From_CartesianCoord(int32_t ix, int32_t iy, int32_t iz)
{
	return ix + SizeX * iy + SizeXY * iz;
}

void CGameStateValues::Get_ID_From_CartesianCoord(int32_t *pOutID, int32_t ix, int32_t iy)
{
	*pOutID = ix + SizeX * iy;
}



void CGameStateValues::Get_ID_From_CartesianCoord(int32_t *pOutID, int32_t ix, int32_t iy, int32_t iz)
{
	*pOutID = ix + SizeX * iy + SizeXY * iz;
}

void CGameStateValues::Get_CartesianCoord_From_ID(int32_t *pOut_ix, int32_t *pOut_iy, int32_t id)
{
	*pOut_ix = id % SizeX;
	*pOut_iy = id / SizeX;
}

void CGameStateValues::Get_CartesianCoord_From_ID(int32_t *pOut_ix, int32_t *pOut_iy, int32_t *pOut_iz, int32_t id)
{
	int32_t iz = id / SizeXY;
	id -= iz * SizeXY;

	*pOut_ix = id % SizeX;
	*pOut_iy = id / SizeX;
	*pOut_iz = iz;
}

bool CGameStateValues::Check_If_Possible_Successor(CGameStateValues *pPrevGameState)
{
	if (IDofPrevGameState == pPrevGameState->IDofGameState)
	{
		return true;
	}

	return false;
}


int32_t CGameStateValues::Get_RootID(void)
{
	if (IDofPrevGameState < 0)
	{
		return IDofGameState;
	}

	int32_t id = IDofPrevGameState;

	CGameStateValues* pTempGameStateObject = nullptr;

	do
	{
		pTempGameStateObject = &pUsedGameStateArray[id];

		id = pTempGameStateObject->IDofPrevGameState;

		if (id < 0)
		{
			return pTempGameStateObject->IDofGameState;
		}

	} while (true);

	return -1;
}

int32_t CGameStateValues::Get_Root_And_RootID(CGameStateValues **ppOutPrevGameState)
{
	*ppOutPrevGameState = &pUsedGameStateArray[IDofGameState];

	if (IDofPrevGameState < 0)
	{
		return IDofGameState;
	}

	int32_t id = IDofPrevGameState;

	CGameStateValues* pTempGameStateObject = nullptr;

	do
	{
		pTempGameStateObject = &pUsedGameStateArray[id];

		id = pTempGameStateObject->IDofPrevGameState;

		if (id < 0)
		{
			*ppOutPrevGameState = pTempGameStateObject;
			return pTempGameStateObject->IDofGameState;
		}

	} while (true);

	return -1;
}

int32_t CGameStateValues::Get_PrevGameState(CGameStateValues **ppOutPrevGameState)
{
	if (IDofPrevGameState < 0)
	{
		*ppOutPrevGameState = nullptr;
		return -1;
	}

	*ppOutPrevGameState = &pUsedGameStateArray[IDofPrevGameState];
	return IDofPrevGameState;
}

int32_t CGameStateValues::Get_PrevGameStateID(void)
{
	return IDofPrevGameState;
}



void CGameStateValues::Use_As_Root_GameState(bool leafNodeToo)
{
	LeafNode = leafNodeToo;
	IDofPrevGameState = -1;
	DepthValue = 0;
}

void CGameStateValues::Reset(void)
{
	PlayerID = -1;
	LeafNode = false;
	IDofGameState = -1;
	IDofPrevGameState = -1;
	DepthValue = 0;
	iEvaluation = -2000000;
	fEvaluation = -2000000.0f;
	FurtherExploration = true;
}

void CGameStateValues::Set_TreeInfo_If_Desired(int32_t depth, int32_t IDPrevGameState, bool leafNode)
{
	LeafNode = leafNode;
	DepthValue = depth;
	IDofPrevGameState = IDPrevGameState;
}

void CGameStateValues::Clone_GameStateValues(int8_t *pOriginalValueArray)
{
	for (int32_t i = 0; i < Size; i++)
	{
		pValueArray[i] = pOriginalValueArray[i];
	}
}

void CGameStateValues::Clone_GameStateValues(CGameStateValues *pOriginalObject)
{
	//PlayerID = pOriginalObject->PlayerID;
	//IDofPrevGameState = pOriginalObject->IDofPrevGameState;
	//DepthValue = pOriginalObject->DepthValue;
	//LeafNode = pOriginalObject->LeafNode;

	int8_t *pOriginalValue = &pOriginalObject->pValueArray[0];

	for (int32_t i = 0; i < Size; i++)
	{
		pValueArray[i] = pOriginalValue[i];
	}
}



bool CGameStateValues::Check_Identity(CGameStateValues *pOtherObject)
{
	int8_t *pOtherValue = &pOtherObject->pValueArray[0];

	for (int32_t i = 0; i < Size; i++)
	{
		if (pValueArray[i] != pOtherValue[i])
		{
			return false;
		}
	}

	return true;
}

void CGameStateValues::Clone_Data(CGameStateValues *pOriginalObject)
{
	SizeX = pOriginalObject->SizeX;
	SizeY = pOriginalObject->SizeY;
	SizeZ = pOriginalObject->SizeZ;
	Size = pOriginalObject->Size;
	SizeXY = pOriginalObject->SizeXY;
	IDofPrevGameState = pOriginalObject->IDofPrevGameState;
	DepthValue = pOriginalObject->DepthValue;
	LeafNode = pOriginalObject->LeafNode;
	PlayerID = pOriginalObject->PlayerID;
	iEvaluation = pOriginalObject->iEvaluation;
	fEvaluation = pOriginalObject->fEvaluation;

	int8_t *pOriginalValue = &pOriginalObject->pValueArray[0];

	for (int32_t i = 0; i < Size; i++)
	{
		pValueArray[i] = pOriginalValue[i];
	}
}

void CGameStateValues::Reset_MinimaxEvaluation(void)
{
	if (Minimizer == true)
	{
		iEvaluation = 2000000;
		fEvaluation = 2000000.0f;
	}
	else
	{
		iEvaluation = -2000000;
		fEvaluation = -2000000.0f;
	}
}

void CGameStateValues::Use_As_Minimizer(void)
{
	Minimizer = true;
	iEvaluation = 2000000;
	fEvaluation = 2000000.0f;
}

void CGameStateValues::Use_As_Maximizer(void)
{
	Minimizer = false;
	iEvaluation = -2000000;
	fEvaluation = -2000000.0f;
}

bool CGameStateValues::Check_Usage(void)
{
	if (IDofGameState < 1)
	{
		return false;
	}

	return true;
}

void CGameStateValues::Initialize(int32_t size)
{
	LeafNode = false;
	IDofGameState = -1;
	IDofPrevGameState = -1;
	DepthValue = 0;
	iEvaluation = -2000000;
	fEvaluation = -2000000.0f;

	SizeX = size;
	SizeY = 0;
	SizeZ = 0;
	SizeXY = 0;

	if (size <= Size)
	{
		Size = size;

		for (int32_t i = 0; i < Size; i++)
		{
			pValueArray[i] = 0;
		}
		
		return;
	}

	delete[] pValueArray;
	pValueArray = nullptr;

	Size = size;

	pValueArray = new (std::nothrow) int8_t[Size];

	for (int32_t i = 0; i < Size; i++)
	{
		pValueArray[i] = 0;
	}
}

CGameStateValues::CGameStateValues(int32_t size)
{
	LeafNode = false;
	IDofGameState = -1;
	IDofPrevGameState = -1;
	DepthValue = 0;
	iEvaluation = -2000000;
	fEvaluation = -2000000.0f;

	SizeX = size;
	SizeY = 0;
	SizeZ = 0;
	SizeXY = 0;

	Size = size;

	pValueArray = new (std::nothrow) int8_t[Size];

	for (int32_t i = 0; i < Size; i++)
	{
		pValueArray[i] = 0;
	}
}

void CGameStateValues::Initialize(int32_t sizeX, int32_t sizeY)
{
	IDofGameState = -1;
	IDofPrevGameState = -1;
	DepthValue = 0;

	SizeX = sizeX;
	SizeY = sizeY;
	SizeZ = 0;

	int32_t size = sizeX * sizeY;
	SizeXY = size;

	if (size <= Size)
	{
		Size = size;

		for (int32_t i = 0; i < Size; i++)
		{
			pValueArray[i] = 0;
		}

		return;
	}

	delete[] pValueArray;
	pValueArray = nullptr;

	Size = size;

	pValueArray = new (std::nothrow) int8_t[Size];

	for (int32_t i = 0; i < Size; i++)
	{
		pValueArray[i] = 0;
	}
}

CGameStateValues::CGameStateValues(int32_t sizeX, int32_t sizeY)
{
	IDofGameState = -1;
	IDofPrevGameState = -1;
	DepthValue = 0;

	SizeX = sizeX;
	SizeY = sizeY;
	SizeZ = 0;

	int32_t size = sizeX * sizeY;
	SizeXY = size;

	Size = size;

	pValueArray = new (std::nothrow) int8_t[Size];

	for (int32_t i = 0; i < Size; i++)
	{
		pValueArray[i] = 0;
	}
}

void CGameStateValues::Initialize(int32_t sizeX, int32_t sizeY, int32_t sizeZ)
{
	IDofGameState = -1;
	IDofPrevGameState = -1;
	DepthValue = 0;

	SizeX = sizeX;
	SizeY = sizeY;
	SizeZ = sizeZ;

	SizeXY = sizeX * sizeY;

	int32_t size = sizeX * sizeY  * sizeZ;

	if (size <= Size)
	{
		Size = size;

		for (int32_t i = 0; i < Size; i++)
		{
			pValueArray[i] = 0;
		}

		return;
	}

	delete[] pValueArray;
	pValueArray = nullptr;

	Size = size;

	pValueArray = new (std::nothrow) int8_t[Size];

	for (int32_t i = 0; i < Size; i++)
	{
		pValueArray[i] = 0;
	}
}

CGameStateValues::CGameStateValues(int32_t sizeX, int32_t sizeY, int32_t sizeZ)
{
	IDofGameState = -1;
	IDofPrevGameState = -1;
	DepthValue = 0;

	SizeX = sizeX;
	SizeY = sizeY;
	SizeZ = sizeZ;

	SizeXY = sizeX * sizeY;

	int32_t size = sizeX * sizeY  * sizeZ;

	Size = size;

	pValueArray = new (std::nothrow) int8_t[Size];

	for (int32_t i = 0; i < Size; i++)
	{
		pValueArray[i] = 0;
	}
}





CGameStateRingBuffer::CGameStateRingBuffer()
{

}

CGameStateRingBuffer::~CGameStateRingBuffer()
{
	delete[] pGameStateArray;
	pGameStateArray = nullptr;
}


int32_t CGameStateRingBuffer::Get_PreviousBufferElementID(void)
{
	return PreviousBufferElement;
}


int32_t CGameStateRingBuffer::Get_PreviousBufferElement(int8_t **ppGameState)
{
	*ppGameState = &(pGameStateArray[PreviousBufferElement].pValueArray[0]);
	return PreviousBufferElement;
}

void CGameStateRingBuffer::Set_PreviousBufferElementData(int8_t *pGameState)
{
	pGameStateArray[PreviousBufferElement].Clone_GameStateValues(pGameState);
}

void CGameStateRingBuffer::Set_PreviousBufferElementData(CGameStateValues *pGameStateObject)
{
	pGameStateArray[PreviousBufferElement].Clone_GameStateValues(pGameStateObject);
}

int32_t CGameStateRingBuffer::Get_PreviousBufferElement(CGameStateValues **ppGameStateObject)
{
	*ppGameStateObject = &pGameStateArray[PreviousBufferElement];

	return PreviousBufferElement;
}




int32_t CGameStateRingBuffer::Get_ActualBufferElementID(void)
{
	return ActualBufferElement;
}


int32_t CGameStateRingBuffer::Get_ActualBufferElement(int8_t **ppGameState)
{
	*ppGameState = &(pGameStateArray[ActualBufferElement].pValueArray[0]);
	return ActualBufferElement;
}

void CGameStateRingBuffer::Set_ActualBufferElementData(CGameStateValues *pGameStateObject)
{
	pGameStateArray[ActualBufferElement].Clone_GameStateValues(pGameStateObject);
}

void CGameStateRingBuffer::Set_ActualBufferElementData(int8_t *pGameState)
{
	pGameStateArray[ActualBufferElement].Clone_GameStateValues(pGameState);
}

int32_t CGameStateRingBuffer::Get_ActualBufferElement(CGameStateValues **ppGameStateObject)
{
	*ppGameStateObject = &pGameStateArray[ActualBufferElement];

	return ActualBufferElement;
}



void CGameStateRingBuffer::Reset_ActualBufferElement(void)
{
	PreviousBufferElement = Size - 1;
	ActualBufferElement = 0;
}

void CGameStateRingBuffer::Set_ActualBufferElement(int32_t value)
{
	ActualBufferElement = value % Size;

	if (ActualBufferElement > 0)
	{
		PreviousBufferElement = ActualBufferElement - 1;
	}
	else
	{
		PreviousBufferElement = Size - 1;
	}
}

void CGameStateRingBuffer::Decrease_ActualBufferElement(void)
{
	if (ActualBufferElement > 0)
	{
		ActualBufferElement--;
	}
	else
	{
		ActualBufferElement = Size - 1;
	}

	if (PreviousBufferElement > 0)
	{
		PreviousBufferElement--;
	}
	else
	{
		PreviousBufferElement = Size - 1;
	}
}

void CGameStateRingBuffer::Increase_ActualBufferElement(void)
{
	PreviousBufferElement = ActualBufferElement;

	ActualBufferElement++;
	ActualBufferElement = ActualBufferElement % Size;

	pGameStateArray[ActualBufferElement].Clone_GameStateValues(&pGameStateArray[PreviousBufferElement]);
}

void CGameStateRingBuffer::Initialize(int32_t bufferSize, int32_t gameStateSize)
{
	PreviousBufferElement = bufferSize - 1;
	ActualBufferElement = 0;

	if (bufferSize <= Size)
	{
		Size = bufferSize;

		for (int32_t i = 0; i < Size; i++)
		{
			pGameStateArray[i].Initialize(gameStateSize);
			pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
		}

		return;
	}

	delete[] pGameStateArray;
	pGameStateArray = nullptr;

	Size = bufferSize;

	pGameStateArray = new (std::nothrow) CGameStateValues[Size];

	for (int32_t i = 0; i < Size; i++)
	{		
		pGameStateArray[i].Initialize(gameStateSize);	
		pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
	}
}

void CGameStateRingBuffer::Initialize(int32_t bufferSize, int32_t gameStateSizeX, int32_t gameStateSizeY)
{
	PreviousBufferElement = bufferSize - 1;
	ActualBufferElement = 0;

	if (bufferSize <= Size)
	{
		Size = bufferSize;

		for (int32_t i = 0; i < Size; i++)
		{
			pGameStateArray[i].Initialize(gameStateSizeX, gameStateSizeY);
			pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
		}

		return;
	}

	delete[] pGameStateArray;
	pGameStateArray = nullptr;

	Size = bufferSize;

	pGameStateArray = new (std::nothrow) CGameStateValues[Size];

	for (int32_t i = 0; i < Size; i++)
	{
		pGameStateArray[i].Initialize(gameStateSizeX, gameStateSizeY);
		pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
	}
}

void CGameStateRingBuffer::Initialize(int32_t bufferSize, int32_t gameStateSizeX, int32_t gameStateSizeY, int32_t gameStateSizeZ)
{
	PreviousBufferElement = bufferSize - 1;
	ActualBufferElement = 0;

	if (bufferSize <= Size)
	{
		Size = bufferSize;

		for (int32_t i = 0; i < Size; i++)
		{
			pGameStateArray[i].Initialize(gameStateSizeX, gameStateSizeY, gameStateSizeZ);
			pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
		}

		return;
	}

	delete[] pGameStateArray;
	pGameStateArray = nullptr;

	Size = bufferSize;

	pGameStateArray = new (std::nothrow) CGameStateValues[Size];

	for (int32_t i = 0; i < Size; i++)
	{
		pGameStateArray[i].Initialize(gameStateSizeX, gameStateSizeY, gameStateSizeZ);
		pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
	}
}

CSimpleGameTree_DepthLayerInfo::CSimpleGameTree_DepthLayerInfo()
{}

CSimpleGameTree_DepthLayerInfo::~CSimpleGameTree_DepthLayerInfo()
{
	delete[] pGameStateIDArray;
	pGameStateIDArray = nullptr;
}

void CSimpleGameTree_DepthLayerInfo::Initialize(int32_t numGameStatesMax)
{
	NumGameStatesMax = numGameStatesMax;
	NumGameStatesUsed = 0;

	delete[] pGameStateIDArray;
	pGameStateIDArray = nullptr;

	pGameStateIDArray = new (std::nothrow) int32_t[numGameStatesMax];
}

void CSimpleGameTree_DepthLayerInfo::Add_GameState(int32_t gameStateID)
{
	if (NumGameStatesUsed >= NumGameStatesMax)
	{
		return;
	}

	pGameStateIDArray[NumGameStatesUsed] = gameStateID;
	NumGameStatesUsed++;
}

void CSimpleGameTree_DepthLayerInfo::Reset(void)
{
	NumGameStatesUsed = 0;
}


CGameStatePool::CGameStatePool()
{

}

CGameStatePool_SimpleGameTree::CGameStatePool_SimpleGameTree()
{

}

void CGameStatePool_SimpleGameTree::Initialize_DepthLayers(int32_t numOfDepthLayersMax, int32_t numOfGameStatesMaxPerLayer)
{
	delete[] pDepthLayerInfoArray;
	pDepthLayerInfoArray = nullptr;

	NumOfDepthLayersMax = numOfDepthLayersMax;

	pDepthLayerInfoArray = new (std::nothrow) CSimpleGameTree_DepthLayerInfo[numOfDepthLayersMax];

	for (int32_t i = 0; i < numOfDepthLayersMax; i++)
	{
		pDepthLayerInfoArray[i].Initialize(numOfGameStatesMaxPerLayer);
	}
}

void CGameStatePool_SimpleGameTree::Initialize_DepthLayers(int32_t numOfDepthLayersMax, int32_t *pNumOfGameStatesMaxPerLayerArray)
{
	delete[] pDepthLayerInfoArray;
	pDepthLayerInfoArray = nullptr;

	NumOfDepthLayersMax = numOfDepthLayersMax;

	pDepthLayerInfoArray = new (std::nothrow) CSimpleGameTree_DepthLayerInfo[numOfDepthLayersMax];

	for (int32_t i = 0; i < numOfDepthLayersMax; i++)
	{
		pDepthLayerInfoArray[i].Initialize(pNumOfGameStatesMaxPerLayerArray[i % numOfDepthLayersMax]);
	}
}


CExtendedGameStatePool::CExtendedGameStatePool()
{

}

CSimpleGameStatePool::CSimpleGameStatePool()
{

}

CGameStatePool::~CGameStatePool()
{
	delete[] pGameStateArray;
	pGameStateArray = nullptr;
}

CGameStatePool_SimpleGameTree::~CGameStatePool_SimpleGameTree()
{
	delete[] pGameStateArray;
	pGameStateArray = nullptr;

	delete[] pDepthLayerInfoArray;
	pDepthLayerInfoArray = nullptr;
}

CExtendedGameStatePool::~CExtendedGameStatePool()
{
	delete[] pGameStateArray;
	pGameStateArray = nullptr;

	delete[] pSimpleLinkedListManagerArray;
	pSimpleLinkedListManagerArray = nullptr;
}



int32_t CExtendedGameStatePool::Get_Random_GameStateID_LastDepthLayerExcluded(int32_t minDepth, int32_t maxDepth, int32_t numAttemptsMax, CRandomNumbersNN *pRandomNumbers)
{
	// ein Game-State auf der untersten Ebene stellt bereits den Endpunkt eines m�glichen testspiels dar:
	maxDepth = min(maxDepth, NumOfDepthLayersMax - 2);

	int32_t id;

	for (int32_t i = 0; i < numAttemptsMax; i++)
	{
		id = pRandomNumbers->Get_IntegerNumber(0, Size);

		if (pGameStateArray[id].IDofGameState < 1)
		{
			continue;
		}

		if (pGameStateArray[id].DepthValue < minDepth)
		{
			continue;
		}

		if (pGameStateArray[id].DepthValue > maxDepth)
		{
			continue;
		}

		return id;

	}

	return -1;
}

int32_t CExtendedGameStatePool::Get_Random_GameStateID(int32_t minDepth, int32_t maxDepth, int32_t numAttemptsMax, CRandomNumbersNN *pRandomNumbers)
{
	maxDepth = min(maxDepth, NumOfDepthLayersMax - 1);

	int32_t id;

	for (int32_t i = 0; i < numAttemptsMax; i++)
	{
		id = pRandomNumbers->Get_IntegerNumber(0, Size);

		if (pGameStateArray[id].IDofGameState < 1)
		{
			continue;
		}

		if (pGameStateArray[id].DepthValue < minDepth)
		{
			continue;
		}

		if (pGameStateArray[id].DepthValue > maxDepth)
		{
			continue;
		}

		return id;

	}

	return -1;
}


CSimpleGameStatePool::~CSimpleGameStatePool()
{
	delete[] pGameStateArray;
	pGameStateArray = nullptr;
}

void CGameStatePool::Initialize(int32_t poolSize, int32_t gameStateSize)
{
	NumGameStateObjectsUsed = 0;

	if (poolSize <= Size)
	{
		Size = poolSize;

		for (int32_t i = 0; i < Size; i++)
		{
			pGameStateArray[i].Initialize(gameStateSize);
			pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
		}

		SimpleMemoryManager.Initialize(Size);
		SimpleLinkedListManager.Initialize(Size);

		return;
	}

	delete[] pGameStateArray;
	pGameStateArray = nullptr;

	Size = poolSize;

	pGameStateArray = new (std::nothrow) CGameStateValues[Size];

	for (int32_t i = 0; i < Size; i++)
	{
		pGameStateArray[i].Initialize(gameStateSize);
		pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
	}

	SimpleMemoryManager.Initialize(Size);
	SimpleLinkedListManager.Initialize(Size);
}

void CGameStatePool_SimpleGameTree::Initialize(int32_t poolSize, int32_t gameStateSize)
{
	NumGameStateObjectsUsed = 0;

	if (poolSize <= Size)
	{
		Size = poolSize;

		for (int32_t i = 0; i < Size; i++)
		{
			pGameStateArray[i].Initialize(gameStateSize);
			pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
		}

		SimpleMemoryManager.Initialize(Size);
		SimpleLinkedListManager.Initialize(Size);

		return;
	}

	delete[] pGameStateArray;
	pGameStateArray = nullptr;

	Size = poolSize;

	pGameStateArray = new (std::nothrow) CGameStateValues[Size];

	for (int32_t i = 0; i < Size; i++)
	{
		pGameStateArray[i].Initialize(gameStateSize);
		pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
	}

	SimpleMemoryManager.Initialize(Size);
	SimpleLinkedListManager.Initialize(Size);
}

void CExtendedGameStatePool::Initialize(int32_t numOfDepthLayersMax, int32_t poolSize, int32_t gameStateSize)
{
	NumGameStateObjectsUsed = 0;

	if (poolSize <= Size)
	{
		Size = poolSize;

		for (int32_t i = 0; i < Size; i++)
		{
			pGameStateArray[i].Initialize(gameStateSize);
			pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
		}

		SimpleMemoryManager.Initialize(Size);

		if (numOfDepthLayersMax <= NumOfDepthLayersMax)
		{
			NumOfDepthLayersMax = numOfDepthLayersMax;
			

			for (int32_t i = 0; i < NumOfDepthLayersMax; i++)
			{
				pSimpleLinkedListManagerArray[i].Initialize(Size);
			}
		}
		else
		{
			delete[] pSimpleLinkedListManagerArray;
			pSimpleLinkedListManagerArray = nullptr;

			NumOfDepthLayersMax = numOfDepthLayersMax;
			

			pSimpleLinkedListManagerArray = new (std::nothrow) CSimpleLinkedListManager[NumOfDepthLayersMax];

			for (int32_t i = 0; i < NumOfDepthLayersMax; i++)
			{
				pSimpleLinkedListManagerArray[i].Initialize(Size);
			}
		}

		return;
	}

	

	delete[] pGameStateArray;
	pGameStateArray = nullptr;

	delete[] pSimpleLinkedListManagerArray;
	pSimpleLinkedListManagerArray = nullptr;

	NumOfDepthLayersMax = numOfDepthLayersMax;
	

	pSimpleLinkedListManagerArray = new (std::nothrow) CSimpleLinkedListManager[NumOfDepthLayersMax];

	Size = poolSize;

	pGameStateArray = new (std::nothrow) CGameStateValues[Size];

	for (int32_t i = 0; i < Size; i++)
	{
		pGameStateArray[i].Initialize(gameStateSize);
		pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
	}

	SimpleMemoryManager.Initialize(Size);

	for (int32_t i = 0; i < NumOfDepthLayersMax; i++)
	{
		pSimpleLinkedListManagerArray[i].Initialize(Size);
	}
}

void CExtendedGameStatePool::Initialize(int32_t numOfDepthLayersMax, int32_t poolSize, int32_t gameStateSizeX, int32_t gameStateSizeY)
{
	NumGameStateObjectsUsed = 0;

	if (poolSize <= Size)
	{
		Size = poolSize;

		for (int32_t i = 0; i < Size; i++)
		{
			pGameStateArray[i].Initialize(gameStateSizeX, gameStateSizeY);
			pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
		}

		SimpleMemoryManager.Initialize(Size);

		if (numOfDepthLayersMax <= NumOfDepthLayersMax)
		{
			NumOfDepthLayersMax = numOfDepthLayersMax;
			

			for (int32_t i = 0; i < NumOfDepthLayersMax; i++)
			{
				pSimpleLinkedListManagerArray[i].Initialize(Size);
			}
		}
		else
		{
			delete[] pSimpleLinkedListManagerArray;
			pSimpleLinkedListManagerArray = nullptr;

			NumOfDepthLayersMax = numOfDepthLayersMax;
			

			pSimpleLinkedListManagerArray = new (std::nothrow) CSimpleLinkedListManager[NumOfDepthLayersMax];

			for (int32_t i = 0; i < NumOfDepthLayersMax; i++)
			{
				pSimpleLinkedListManagerArray[i].Initialize(Size);
			}
		}

		return;
	}



	delete[] pGameStateArray;
	pGameStateArray = nullptr;

	delete[] pSimpleLinkedListManagerArray;
	pSimpleLinkedListManagerArray = nullptr;

	NumOfDepthLayersMax = numOfDepthLayersMax;
	

	pSimpleLinkedListManagerArray = new (std::nothrow) CSimpleLinkedListManager[NumOfDepthLayersMax];

	Size = poolSize;

	pGameStateArray = new (std::nothrow) CGameStateValues[Size];

	for (int32_t i = 0; i < Size; i++)
	{
		pGameStateArray[i].Initialize(gameStateSizeX, gameStateSizeY);
		pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
	}

	SimpleMemoryManager.Initialize(Size);

	for (int32_t i = 0; i < NumOfDepthLayersMax; i++)
	{
		pSimpleLinkedListManagerArray[i].Initialize(Size);
	}
}

void CExtendedGameStatePool::Initialize(int32_t numOfDepthLayersMax, int32_t poolSize, int32_t gameStateSizeX, int32_t gameStateSizeY, int32_t gameStateSizeZ)
{
	NumGameStateObjectsUsed = 0;

	if (poolSize <= Size)
	{
		Size = poolSize;

		for (int32_t i = 0; i < Size; i++)
		{
			pGameStateArray[i].Initialize(gameStateSizeX, gameStateSizeY, gameStateSizeZ);
			pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
		}

		SimpleMemoryManager.Initialize(Size);

		if (numOfDepthLayersMax <= NumOfDepthLayersMax)
		{
			NumOfDepthLayersMax = numOfDepthLayersMax;
			

			for (int32_t i = 0; i < NumOfDepthLayersMax; i++)
			{
				pSimpleLinkedListManagerArray[i].Initialize(Size);
			}
		}
		else
		{
			delete[] pSimpleLinkedListManagerArray;
			pSimpleLinkedListManagerArray = nullptr;

			NumOfDepthLayersMax = numOfDepthLayersMax;
			

			pSimpleLinkedListManagerArray = new (std::nothrow) CSimpleLinkedListManager[NumOfDepthLayersMax];

			for (int32_t i = 0; i < NumOfDepthLayersMax; i++)
			{
				pSimpleLinkedListManagerArray[i].Initialize(Size);
			}
		}

		return;
	}



	delete[] pGameStateArray;
	pGameStateArray = nullptr;

	delete[] pSimpleLinkedListManagerArray;
	pSimpleLinkedListManagerArray = nullptr;

	NumOfDepthLayersMax = numOfDepthLayersMax;
	

	pSimpleLinkedListManagerArray = new (std::nothrow) CSimpleLinkedListManager[NumOfDepthLayersMax];

	Size = poolSize;

	pGameStateArray = new (std::nothrow) CGameStateValues[Size];

	for (int32_t i = 0; i < Size; i++)
	{
		pGameStateArray[i].Initialize(gameStateSizeX, gameStateSizeY, gameStateSizeZ);
		pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
	}

	SimpleMemoryManager.Initialize(Size);

	for (int32_t i = 0; i < NumOfDepthLayersMax; i++)
	{
		pSimpleLinkedListManagerArray[i].Initialize(Size);
	}
}

void CSimpleGameStatePool::Initialize(int32_t poolSize, int32_t gameStateSize)
{
	NumGameStateObjectsUsed = 0;

	if (poolSize <= Size)
	{
		Size = poolSize;

		for (int32_t i = 0; i < Size; i++)
		{
			pGameStateArray[i].Initialize(gameStateSize);
			pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
		}

		SimpleMemoryManager.Initialize(Size);
		

		return;
	}

	delete[] pGameStateArray;
	pGameStateArray = nullptr;

	Size = poolSize;

	pGameStateArray = new (std::nothrow) CGameStateValues[Size];

	for (int32_t i = 0; i < Size; i++)
	{
		pGameStateArray[i].Initialize(gameStateSize);
		pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
	}

	SimpleMemoryManager.Initialize(Size);
	
}

void CGameStatePool::Initialize(int32_t poolSize, int32_t gameStateSizeX, int32_t gameStateSizeY)
{
	NumGameStateObjectsUsed = 0;

	if (poolSize < Size)
	{
		Size = poolSize;

		for (int32_t i = 0; i < Size; i++)
		{
			pGameStateArray[i].Initialize(gameStateSizeX, gameStateSizeY);
			pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
		}

		SimpleMemoryManager.Initialize(Size);
		SimpleLinkedListManager.Initialize(Size);

		return;
	}

	delete[] pGameStateArray;
	pGameStateArray = nullptr;

	Size = poolSize;

	pGameStateArray = new (std::nothrow) CGameStateValues[Size];

	for (int32_t i = 0; i < Size; i++)
	{
		pGameStateArray[i].Initialize(gameStateSizeX, gameStateSizeY);
		pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
	}

	SimpleMemoryManager.Initialize(Size);
	SimpleLinkedListManager.Initialize(Size);
}



void CGameStatePool_SimpleGameTree::Initialize(int32_t poolSize, int32_t gameStateSizeX, int32_t gameStateSizeY)
{
	NumGameStateObjectsUsed = 0;

	if (poolSize < Size)
	{
		Size = poolSize;

		for (int32_t i = 0; i < Size; i++)
		{
			pGameStateArray[i].Initialize(gameStateSizeX, gameStateSizeY);
			pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
		}

		SimpleMemoryManager.Initialize(Size);
		SimpleLinkedListManager.Initialize(Size);

		return;
	}

	delete[] pGameStateArray;
	pGameStateArray = nullptr;

	Size = poolSize;

	pGameStateArray = new (std::nothrow) CGameStateValues[Size];

	for (int32_t i = 0; i < Size; i++)
	{
		pGameStateArray[i].Initialize(gameStateSizeX, gameStateSizeY);
		pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
	}

	SimpleMemoryManager.Initialize(Size);
	SimpleLinkedListManager.Initialize(Size);
}


void CSimpleGameStatePool::Initialize(int32_t poolSize, int32_t gameStateSizeX, int32_t gameStateSizeY)
{
	NumGameStateObjectsUsed = 0;

	if (poolSize <= Size)
	{
		Size = poolSize;

		for (int32_t i = 0; i < Size; i++)
		{
			pGameStateArray[i].Initialize(gameStateSizeX, gameStateSizeY);
			pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
		}

		SimpleMemoryManager.Initialize(Size);
		

		return;
	}

	delete[] pGameStateArray;
	pGameStateArray = nullptr;

	Size = poolSize;

	pGameStateArray = new (std::nothrow) CGameStateValues[Size];

	for (int32_t i = 0; i < Size; i++)
	{
		pGameStateArray[i].Initialize(gameStateSizeX, gameStateSizeY);
		pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
	}

	SimpleMemoryManager.Initialize(Size);
	
}

void CGameStatePool::Initialize(int32_t poolSize, int32_t gameStateSizeX, int32_t gameStateSizeY, int32_t gameStateSizeZ)
{
	NumGameStateObjectsUsed = 0;

	if (poolSize <= Size)
	{
		Size = poolSize;

		for (int32_t i = 0; i < Size; i++)
		{
			pGameStateArray[i].Initialize(gameStateSizeX, gameStateSizeY, gameStateSizeZ);
			pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
		}

		SimpleMemoryManager.Initialize(Size);
		SimpleLinkedListManager.Initialize(Size);

		return;
	}

	delete[] pGameStateArray;
	pGameStateArray = nullptr;

	Size = poolSize;

	pGameStateArray = new (std::nothrow) CGameStateValues[Size];

	for (int32_t i = 0; i < Size; i++)
	{
		pGameStateArray[i].Initialize(gameStateSizeX, gameStateSizeY, gameStateSizeZ);
		pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
	}

	SimpleMemoryManager.Initialize(Size);
	SimpleLinkedListManager.Initialize(Size);
}



void CGameStatePool_SimpleGameTree::Initialize(int32_t poolSize, int32_t gameStateSizeX, int32_t gameStateSizeY, int32_t gameStateSizeZ)
{
	NumGameStateObjectsUsed = 0;

	if (poolSize <= Size)
	{
		Size = poolSize;

		for (int32_t i = 0; i < Size; i++)
		{
			pGameStateArray[i].Initialize(gameStateSizeX, gameStateSizeY, gameStateSizeZ);
			pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
		}

		SimpleMemoryManager.Initialize(Size);
		SimpleLinkedListManager.Initialize(Size);

		return;
	}

	delete[] pGameStateArray;
	pGameStateArray = nullptr;

	Size = poolSize;

	pGameStateArray = new (std::nothrow) CGameStateValues[Size];

	for (int32_t i = 0; i < Size; i++)
	{
		pGameStateArray[i].Initialize(gameStateSizeX, gameStateSizeY, gameStateSizeZ);
		pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
	}

	SimpleMemoryManager.Initialize(Size);
	SimpleLinkedListManager.Initialize(Size);
}


void CSimpleGameStatePool::Initialize(int32_t poolSize, int32_t gameStateSizeX, int32_t gameStateSizeY, int32_t gameStateSizeZ)
{
	NumGameStateObjectsUsed = 0;

	if (poolSize <= Size)
	{
		Size = poolSize;

		for (int32_t i = 0; i < Size; i++)
		{
			pGameStateArray[i].Initialize(gameStateSizeX, gameStateSizeY, gameStateSizeZ);
			pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
		}

		SimpleMemoryManager.Initialize(Size);
	

		return;
	}

	delete[] pGameStateArray;
	pGameStateArray = nullptr;

	Size = poolSize;

	pGameStateArray = new (std::nothrow) CGameStateValues[Size];

	for (int32_t i = 0; i < Size; i++)
	{
		pGameStateArray[i].Initialize(gameStateSizeX, gameStateSizeY, gameStateSizeZ);
		pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
	}

	SimpleMemoryManager.Initialize(Size);
	
}

bool CGameStatePool::Get_UnusedGameStateObject(int32_t* pBelongingID)
{
	int32_t id = SimpleMemoryManager.Request_Unused_MemoryElementID();

	if (id == 0) // no unused object found
	{
		*pBelongingID = 0;
		return false;
	}
	else // unused object found
	{
		SimpleLinkedListManager.Init_New_ListElement(id);

		*pBelongingID = id;
		pGameStateArray[id].IDofGameState = id;
		

		NumGameStateObjectsUsed++;
		return true;
	}
}



bool CGameStatePool_SimpleGameTree::Get_UnusedGameStateObject(int32_t depth, int32_t* pBelongingID)
{
	int32_t id = SimpleMemoryManager.Request_Unused_MemoryElementID();

	if (id == 0) // no unused object found
	{
		*pBelongingID = 0;
		return false;
	}
	else // unused object found
	{
		SimpleLinkedListManager.Init_New_ListElement(id);

		*pBelongingID = id;
		pGameStateArray[id].IDofGameState = id;
		pGameStateArray[id].IDofPrevGameState = -1;
		pGameStateArray[id].DepthValue = depth;
		pGameStateArray[id].LeafNode = true;


		NumGameStateObjectsUsed++;
		return true;
	}
}



bool CExtendedGameStatePool::Get_UnusedGameStateObject(int32_t depth, int32_t* pBelongingID)
{
	if (depth < 0)
	{
		return false;
	}
	if (depth >= NumOfDepthLayersMax)
	{
		return false;
	}

	int32_t id = SimpleMemoryManager.Request_Unused_MemoryElementID();

	if (id == 0) // no unused object found
	{
		*pBelongingID = 0;
		return false;
	}
	else // unused object found
	{
		pSimpleLinkedListManagerArray[depth].Init_New_ListElement(id);

		*pBelongingID = id;
		pGameStateArray[id].IDofPrevGameState = -1;
		pGameStateArray[id].IDofGameState = id;
		pGameStateArray[id].DepthValue = depth;
		pGameStateArray[id].LeafNode = true;
		NumGameStateObjectsUsed++;
		return true;
	}
}

bool CSimpleGameStatePool::Get_UnusedGameStateObject(int32_t* pBelongingID)
{
	int32_t id = SimpleMemoryManager.Request_Unused_MemoryElementID();

	if (id == 0) // no unused object found
	{
		*pBelongingID = 0;
		return false;
	}
	else // unused object found
	{
		*pBelongingID = id;
		pGameStateArray[id].IDofGameState = id;

		NumGameStateObjectsUsed++;
		return true;
	}
}


bool CGameStatePool::Get_UnusedGameStateObject(CGameStateValues** ppGameStateObject, int32_t* pBelongingID)
{
	int32_t id = SimpleMemoryManager.Request_Unused_MemoryElementID();

	//_Add_To_Log("id", &id);

	if (id == 0) // no unused object found
	{
		*pBelongingID = 0;
		*ppGameStateObject = nullptr;
		return false;
	}
	else // unused object found
	{
		SimpleLinkedListManager.Init_New_ListElement(id);

		//if(SimpleLinkedListManager.Init_New_ListElement(id) == true)
		//Add_To_Log("Init_New_ListElement");

		*pBelongingID = id;
		pGameStateArray[id].IDofGameState = id;
		*ppGameStateObject = &pGameStateArray[id];

		NumGameStateObjectsUsed++;

		return true;
	}
}



bool CGameStatePool_SimpleGameTree::Get_UnusedGameStateObject(int32_t depth, CGameStateValues** ppGameStateObject, int32_t* pBelongingID)
{
	int32_t id = SimpleMemoryManager.Request_Unused_MemoryElementID();

	//_Add_To_Log("id", &id);

	if (id == 0) // no unused object found
	{
		*pBelongingID = 0;
		*ppGameStateObject = nullptr;
		return false;
	}
	else // unused object found
	{
		SimpleLinkedListManager.Init_New_ListElement(id);

		//if(SimpleLinkedListManager.Init_New_ListElement(id) == true)
		//Add_To_Log("Init_New_ListElement");

		*pBelongingID = id;
		
		pGameStateArray[id].IDofGameState = id;
		pGameStateArray[id].IDofPrevGameState = -1;
		pGameStateArray[id].DepthValue = depth;
		pGameStateArray[id].LeafNode = true;

		*ppGameStateObject = &pGameStateArray[id];

		NumGameStateObjectsUsed++;

		return true;
	}
}


bool CExtendedGameStatePool::Get_UnusedGameStateObject(int32_t depth, CGameStateValues** ppGameStateObject, int32_t* pBelongingID)
{
	if (depth < 0)
	{
		return false;
	}
	if (depth >= NumOfDepthLayersMax)
	{
		return false;
	}

	int32_t id = SimpleMemoryManager.Request_Unused_MemoryElementID();

	//_Add_To_Log("id", &id);

	if (id == 0) // no unused object found
	{
		*pBelongingID = 0;
		*ppGameStateObject = nullptr;
		return false;
	}
	else // unused object found
	{
		pSimpleLinkedListManagerArray[depth].Init_New_ListElement(id);

		//if(SimpleLinkedListManager.Init_New_ListElement(id) == true)
		//Add_To_Log("Init_New_ListElement");

		*pBelongingID = id;
		pGameStateArray[id].IDofPrevGameState = -1;
		pGameStateArray[id].IDofGameState = id;
		pGameStateArray[id].DepthValue = depth;
		pGameStateArray[id].LeafNode = true;
		*ppGameStateObject = &pGameStateArray[id];

		NumGameStateObjectsUsed++;

		return true;
	}
}

bool CSimpleGameStatePool::Get_UnusedGameStateObject(CGameStateValues** ppGameStateObject, int32_t* pBelongingID)
{
	int32_t id = SimpleMemoryManager.Request_Unused_MemoryElementID();

	//_Add_To_Log("id", &id);

	if (id == 0) // no unused object found
	{
		*pBelongingID = 0;
		*ppGameStateObject = nullptr;
		return false;
	}
	else // unused object found
	{
		*pBelongingID = id;
		pGameStateArray[id].IDofGameState = id;
		*ppGameStateObject = &pGameStateArray[id];

		NumGameStateObjectsUsed++;

		return true;
	}
}


bool CGameStatePool::Stop_Using_GameStateObject(CGameStateValues** ppGameStateObject)
{
	if (*ppGameStateObject == nullptr)
	{
		return false;
	}

	int32_t id = (*ppGameStateObject)->IDofGameState;

	if (id < 0)
	{
		return false;
	}

	if (SimpleMemoryManager.Free_Used_MemoryElement(id) == true)
	{
		pGameStateArray[id].Reset();
		*ppGameStateObject = nullptr;

		NumGameStateObjectsUsed--;

		return SimpleLinkedListManager.Free_Used_ListElement(id);
	}

	return false;
}

bool CGameStatePool::Stop_Using_GameStateObject(int32_t id)
{
	if (SimpleMemoryManager.Free_Used_MemoryElement(id) == true)
	{
		pGameStateArray[id].Reset();

		NumGameStateObjectsUsed--;

		return SimpleLinkedListManager.Free_Used_ListElement(id);
	}

	return false;
}

bool CExtendedGameStatePool::Stop_Using_GameStateObject(int32_t id)
{
	if (SimpleMemoryManager.Free_Used_MemoryElement(id) == true)
	{
		int32_t depth = pGameStateArray[id].DepthValue;
		pGameStateArray[id].Reset();

		NumGameStateObjectsUsed--;

		return pSimpleLinkedListManagerArray[depth].Free_Used_ListElement(id);
	}

	return false;
}

bool CExtendedGameStatePool::Stop_Using_GameStateObject(CGameStateValues** ppGameStateObject)
{
	if (*ppGameStateObject == nullptr)
	{
		return false;
	}

	int32_t id = (*ppGameStateObject)->IDofGameState;

	if (id < 0)
	{
		return false;
	}

	if (SimpleMemoryManager.Free_Used_MemoryElement(id) == true)
	{
		int32_t depth = pGameStateArray[id].DepthValue;
		pGameStateArray[id].Reset();
		*ppGameStateObject = nullptr;

		NumGameStateObjectsUsed--;

		return pSimpleLinkedListManagerArray[depth].Free_Used_ListElement(id);
	}

	return false;
}


bool CSimpleGameStatePool::Stop_Using_GameStateObject(int32_t id)
{
	if (SimpleMemoryManager.Free_Used_MemoryElement(id) == true)
	{
		pGameStateArray[id].Reset();

		NumGameStateObjectsUsed--;

		return true;
	}

	return false;
}

bool CSimpleGameStatePool::Stop_Using_GameStateObject(CGameStateValues** ppGameStateObject)
{
	if (*ppGameStateObject == nullptr)
	{
		return false;
	}

	int32_t id = (*ppGameStateObject)->IDofGameState;

	if (id < 0)
	{
		return false;
	}

	if (SimpleMemoryManager.Free_Used_MemoryElement(id) == true)
	{
		pGameStateArray[id].Reset();
		*ppGameStateObject = nullptr;

		NumGameStateObjectsUsed--;

		return true;
	}

	return false;
}


void CGameStatePool::Stop_Using_AllGameStateObjects(void)
{
	int32_t NumObjectsUsed = SimpleLinkedListManager.NumUsedListElements;
	int32_t id = 0;

	for (int32_t i = 0; i < NumObjectsUsed; i++)
	{
		id = SimpleLinkedListManager.Get_Next_Used_ListElement(id);

		pGameStateArray[id].Reset();

		NumGameStateObjectsUsed--;

		SimpleMemoryManager.Free_Used_MemoryElement(id);
		SimpleLinkedListManager.Free_Used_ListElement(id);
	}
}



void CGameStatePool_SimpleGameTree::Stop_Using_AllGameStateObjects(void)
{
	int32_t NumObjectsUsed = SimpleLinkedListManager.NumUsedListElements;
	int32_t id = 0;

	for (int32_t i = 0; i < NumObjectsUsed; i++)
	{
		id = SimpleLinkedListManager.Get_Next_Used_ListElement(id);

		pGameStateArray[id].Reset();

		NumGameStateObjectsUsed--;

		SimpleMemoryManager.Free_Used_MemoryElement(id);
		SimpleLinkedListManager.Free_Used_ListElement(id);
	}
}


int32_t CExtendedGameStatePool::Get_Root_And_RootID(CGameStateValues** ppOutGameStateObject, CGameStateValues* pInGameStateObject)
{
	*ppOutGameStateObject = pInGameStateObject;

	int32_t id = pInGameStateObject->IDofPrevGameState;

	if (id < 0)
	{
		return pInGameStateObject->IDofGameState;
	}

	CGameStateValues* pTempGameStateObject = nullptr;

	do
	{
		pTempGameStateObject = &pGameStateArray[id];

		id = pTempGameStateObject->IDofPrevGameState;

		if (id < 0)
		{
			*ppOutGameStateObject = pTempGameStateObject;
			return pTempGameStateObject->IDofGameState;
		}

	} while (true);

	return -1;
}

int32_t CExtendedGameStatePool::Get_RootID(CGameStateValues* pGameStateObject)
{
	int32_t id = pGameStateObject->IDofPrevGameState;

	if (id < 0)
	{
		return pGameStateObject->IDofGameState;
	}

	CGameStateValues* pTempGameStateObject = nullptr;

	do
	{
		pTempGameStateObject = &pGameStateArray[id];

		id = pTempGameStateObject->IDofPrevGameState;

		if (id < 0)
		{
			return pTempGameStateObject->IDofGameState;
		}

	} while (true);

	return -1;
}

void CExtendedGameStatePool::Reset_EvaluationValues(void)
{
	for (int32_t j = 0; j < NumOfDepthLayersMax; j++)
	{
		int32_t NumObjectsUsed = pSimpleLinkedListManagerArray[j].NumUsedListElements;
		int32_t id = 0;

		for (int32_t i = 0; i < NumObjectsUsed; i++)
		{
			id = pSimpleLinkedListManagerArray[j].Get_Next_Used_ListElement(id);

			pGameStateArray[id].Reset_Evaluation();
		}
	}
}

void CExtendedGameStatePool::Stop_Using_AllGameStateObjects(void)
{
	for (int32_t j = 0; j < NumOfDepthLayersMax; j++)
	{
		int32_t NumObjectsUsed = pSimpleLinkedListManagerArray[j].NumUsedListElements;
		int32_t id = 0;

		for (int32_t i = 0; i < NumObjectsUsed; i++)
		{
			id = pSimpleLinkedListManagerArray[j].Get_Next_Used_ListElement(id);

			pGameStateArray[id].Reset();

			NumGameStateObjectsUsed--;

			SimpleMemoryManager.Free_Used_MemoryElement(id);
			pSimpleLinkedListManagerArray[j].Free_Used_ListElement(id);
		}
	}
}

void CExtendedGameStatePool::Get_Best_GameState_IntegerEvaluation(CGameStateValues** ppOutGameStateObject, int32_t* pOutBelongingID)
{
	int32_t NumObjectsUsed = pSimpleLinkedListManagerArray[0].NumUsedListElements;

	if (NumObjectsUsed < 1)
	{
		*ppOutGameStateObject = nullptr;
		*pOutBelongingID = -1;
		return;
	}

	int32_t bestEvaluation = -2000000;
	int32_t belongingID = -1;

	
	int32_t id = 0;

	for (int32_t i = 0; i < NumObjectsUsed; i++)
	{
		id = pSimpleLinkedListManagerArray[0].Get_Next_Used_ListElement(id);

		if (pGameStateArray[id].iEvaluation >= bestEvaluation)
		{
			bestEvaluation = pGameStateArray[id].iEvaluation;
			belongingID = id;
		}
	}

	*ppOutGameStateObject = &pGameStateArray[belongingID];
	*pOutBelongingID = belongingID;
}

void CExtendedGameStatePool::Get_Best_GameState_FloatEvaluation(CGameStateValues** ppOutGameStateObject, int32_t* pOutBelongingID)
{
	int32_t NumObjectsUsed = pSimpleLinkedListManagerArray[0].NumUsedListElements;

	if (NumObjectsUsed < 1)
	{
		*ppOutGameStateObject = nullptr;
		*pOutBelongingID = -1;
		return;
	}

	float bestEvaluation = -2000000.0f;
	int32_t belongingID = -1;

	
	int32_t id = 0;

	for (uint32_t i = 0; i < NumObjectsUsed; i++)
	{
		id = pSimpleLinkedListManagerArray[0].Get_Next_Used_ListElement(id);

		if (pGameStateArray[id].fEvaluation >= bestEvaluation)
		{
			bestEvaluation = pGameStateArray[id].fEvaluation;
			belongingID = id;
		}
	}

	*ppOutGameStateObject = &pGameStateArray[belongingID];
	*pOutBelongingID = belongingID;
}


void CSimpleGameStatePool::Stop_Using_AllGameStateObjects(void)
{
	SimpleMemoryManager.Reset_Arrays();

	for (int32_t i = 0; i < Size; i++)
	{
		pGameStateArray[i].Reset();
	}
}

void Backpropagate_IntegerEvaluationValues_Player1(CExtendedGameStatePool *pGameStatePool)
{
	CGameStateValues *pGameState = nullptr;
	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;

	for (int32_t i = numOfDepthLayersMax - 1; i > 0; i--)
	{
		CSimpleLinkedListManager *pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[i];
		int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
		int32_t id = 0;


		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);

			pGameState = &pGameStatePool->pGameStateArray[id];

			pGameState->Backpropagate_MinimaxIntegerEvaluation();
		}
	}
}



void Backpropagate_MinimaxIntegerEvaluationValues(CExtendedGameStatePool *pGameStatePool)
{
	CGameStateValues *pGameState = nullptr;
	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;

	for (int32_t i = numOfDepthLayersMax - 1; i > 0; i--)
	{
		CSimpleLinkedListManager *pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[i];
		int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
		int32_t id = 0;


		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);

			pGameState = &pGameStatePool->pGameStateArray[id];

			pGameState->Backpropagate_MinimaxIntegerEvaluation();
		}
	}
}

void Backpropagate_MinimaxIntegerEvaluationValues(CGameStatePool_SimpleGameTree *pGameStatePool)
{
	CGameStateValues *pGameState = nullptr;
	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;

	for (int32_t i = numOfDepthLayersMax - 1; i > 0; i--)
	{
		CSimpleGameTree_DepthLayerInfo *pDepthLayerInfo = &pGameStatePool->pDepthLayerInfoArray[i];

		int32_t NumObjectsUsed = pDepthLayerInfo->NumGameStatesUsed;

		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			pGameState = &pGameStatePool->pGameStateArray[pDepthLayerInfo->pGameStateIDArray[j]];

			pGameState->Backpropagate_MinimaxIntegerEvaluation();
		}
	}
}


void Backpropagate_IntegerEvaluationChanges(CExtendedGameStatePool *pGameStatePool)
{
	CGameStateValues *pGameState = nullptr;
	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;

	for (int32_t i = numOfDepthLayersMax - 1; i > 0; i--)
	{
		CSimpleLinkedListManager *pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[i];
		int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
		int32_t id = 0;


		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);

			pGameState = &pGameStatePool->pGameStateArray[id];

			pGameState->Backpropagate_IntegerEvaluationChange();
		}
	}
}

void Backpropagate_IntegerEvaluationChanges(CGameStatePool_SimpleGameTree *pGameStatePool)
{
	CGameStateValues *pGameState = nullptr;
	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;

	for (int32_t i = numOfDepthLayersMax - 1; i > 0; i--)
	{
		CSimpleGameTree_DepthLayerInfo *pDepthLayerInfo = &pGameStatePool->pDepthLayerInfoArray[i];

		int32_t NumObjectsUsed = pDepthLayerInfo->NumGameStatesUsed;

		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			pGameState = &pGameStatePool->pGameStateArray[pDepthLayerInfo->pGameStateIDArray[j]];

			pGameState->Backpropagate_IntegerEvaluationChange();
		}
	}
}


void Backpropagate_MinimaxFloatEvaluationValues(CExtendedGameStatePool *pGameStatePool)
{
	CGameStateValues *pGameState = nullptr;
	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;

	for (int32_t i = numOfDepthLayersMax - 1; i > 0; i--)
	{
		CSimpleLinkedListManager *pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[i];
		int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
		int32_t id = 0;


		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);

			pGameState = &pGameStatePool->pGameStateArray[id];

			pGameState->Backpropagate_MinimaxFloatEvaluation();
		}
	}
}

void Backpropagate_MinimaxFloatEvaluationValues(CGameStatePool_SimpleGameTree *pGameStatePool)
{
	CGameStateValues *pGameState = nullptr;
	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;

	for (int32_t i = numOfDepthLayersMax - 1; i > 0; i--)
	{
		CSimpleGameTree_DepthLayerInfo *pDepthLayerInfo = &pGameStatePool->pDepthLayerInfoArray[i];

		int32_t NumObjectsUsed = pDepthLayerInfo->NumGameStatesUsed;

		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			pGameState = &pGameStatePool->pGameStateArray[pDepthLayerInfo->pGameStateIDArray[j]];

			pGameState->Backpropagate_MinimaxFloatEvaluation();
		}
	}
}

void Backpropagate_FloatEvaluationChanges(CExtendedGameStatePool *pGameStatePool)
{
	CGameStateValues *pGameState = nullptr;
	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;

	for (int32_t i = numOfDepthLayersMax - 1; i > 0; i--)
	{
		CSimpleLinkedListManager *pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[i];
		int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
		int32_t id = 0;


		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);

			pGameState = &pGameStatePool->pGameStateArray[id];

			pGameState->Backpropagate_FloatEvaluationChange();
		}
	}
}

void Backpropagate_FloatEvaluationChanges(CGameStatePool_SimpleGameTree *pGameStatePool)
{
	CGameStateValues *pGameState = nullptr;
	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;

	for (int32_t i = numOfDepthLayersMax - 1; i > 0; i--)
	{
		CSimpleGameTree_DepthLayerInfo *pDepthLayerInfo = &pGameStatePool->pDepthLayerInfoArray[i];

		int32_t NumObjectsUsed = pDepthLayerInfo->NumGameStatesUsed;

		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			pGameState = &pGameStatePool->pGameStateArray[pDepthLayerInfo->pGameStateIDArray[j]];

			pGameState->Backpropagate_FloatEvaluationChange();
		}
	}
}
