#include <iostream>
//#include <chrono>
#include <omp.h>
#include <thread>
#include "BattleShip.h"
#include "ConsoleHelperFunctions.h"
#include "NeuralNet_V2.h"
#include "LogFile.h"

using namespace std;
using namespace chrono;
using namespace HelperStuff;

#define KEYDOWN(vk_code) ((GetAsyncKeyState(vk_code) & 0x8000) ? 1 : 0)
#define KEYUP(vk_code)   ((GetAsyncKeyState(vk_code) & 0x8000) ? 0 : 1)







static COLOR_PALETTE g_GameBoardColorArray[5] = { lightblue, gray, lightgreen, lightyello, lightred};

static void Update_GameBoardGraphics(CWindowsConsole2DObject *pGameBoard, int32_t *pData)
{
	int32_t id;

	for (int32_t iy = 0; iy < ConstGameBoardSizePerDir; iy++)
	{
		for (int32_t ix = 0; ix < ConstGameBoardSizePerDir; ix++)
		{
			id = ix + iy * ConstGameBoardSizePerDir;

			pGameBoard->Set_Pixel(ix, iy, g_GameBoardColorArray[pData[id]]);
		}
	}
}

static void Update_GameBoardGraphics2(CWindowsConsole2DObject *pGameBoard, int32_t *pPaddedData)
{
	int32_t id, idWithPadding;

	for (int32_t iy = 0; iy < ConstGameBoardSizePerDir; iy++)
	{
		for (int32_t ix = 0; ix < ConstGameBoardSizePerDir; ix++)
		{
			id = ix + iy * ConstGameBoardSizePerDir;
			idWithPadding = (ix + 1) + (iy + 1) * ConstGameBoardSizePerDirWithPadding;

			pGameBoard->Set_Pixel(ix, iy, g_GameBoardColorArray[pPaddedData[idWithPadding]]);
		}
	}
}


static void Update_GameBoardGraphics_DontShow_IntactParts(CWindowsConsole2DObject *pGameBoard, int32_t *pData)
{
	int32_t id;
	int32_t data;

	for (int32_t iy = 0; iy < ConstGameBoardSizePerDir; iy++)
	{
		for (int32_t ix = 0; ix < ConstGameBoardSizePerDir; ix++)
		{
			id = ix + iy * ConstGameBoardSizePerDir;

			data = pData[id];

			if(data == ConstGameBoard_WaterShot)
				pGameBoard->Set_Pixel(ix, iy, g_GameBoardColorArray[data]);
			else if (data == ConstGameBoard_DamagedElement)
				pGameBoard->Set_Pixel(ix, iy, g_GameBoardColorArray[data]);
			else if (data == ConstGameBoard_DestroyedElement)
				pGameBoard->Set_Pixel(ix, iy, g_GameBoardColorArray[data]);
			else
				pGameBoard->Set_Pixel(ix, iy, g_GameBoardColorArray[0]);
		}
	}
}

static void Update_GameBoardGraphics_DontShow_IntactParts2(CWindowsConsole2DObject *pGameBoard, int32_t *pPaddedData)
{
	int32_t id, idWithPadding;
	int32_t data;

	for (int32_t iy = 0; iy < ConstGameBoardSizePerDir; iy++)
	{
		for (int32_t ix = 0; ix < ConstGameBoardSizePerDir; ix++)
		{
			id = ix + iy * ConstGameBoardSizePerDir;
			idWithPadding = (ix + 1) + (iy + 1) * ConstGameBoardSizePerDirWithPadding;

			data = pPaddedData[idWithPadding];

			if (data == ConstGameBoard_WaterShot)
				pGameBoard->Set_Pixel(ix, iy, g_GameBoardColorArray[data]);
			else if (data == ConstGameBoard_DamagedElement)
				pGameBoard->Set_Pixel(ix, iy, g_GameBoardColorArray[data]);
			else if (data == ConstGameBoard_DestroyedElement)
				pGameBoard->Set_Pixel(ix, iy, g_GameBoardColorArray[data]);
			else
				pGameBoard->Set_Pixel(ix, iy, g_GameBoardColorArray[0]);
		}
	}
}



static void Set_ProcessPriority(unsigned long priority)
{
	HANDLE ProcessHandle = GetCurrentProcess();

	if (priority == 0)
		SetPriorityClass(ProcessHandle, NORMAL_PRIORITY_CLASS);
	else if (priority == 1)
		SetPriorityClass(ProcessHandle, ABOVE_NORMAL_PRIORITY_CLASS);
	else if (priority == 2)
		SetPriorityClass(ProcessHandle, HIGH_PRIORITY_CLASS);
	else
		SetPriorityClass(ProcessHandle, REALTIME_PRIORITY_CLASS);
}

static int32_t AI_Controlled_Random_Shot(int32_t *pInOutGameBoardData, int32_t *pInOutNumOfShots,
	CNeuronV2 *pDestroyedEntityNeighborhoodDetectionNeuron, float *pGameBoardData_DestroyedElements,
	CNeuronV2 *pPlacementEvaluationNeuron, int32_t placementEvaluationHalfLRFSizePerDirMinus1, float *pGameBoardData_WaterShotsAndDestroyedElements, CNeuronV2 *pUnnecessaryShotDetectionNeuron, float *pGameBoardData_WaterShots, int32_t lengthOfBiggestUndestroyedEntity,
	float *pPositionProbabilityMemory, CRandomNumbersNN *pRandomNumbers)
{
	if (*pInOutNumOfShots == ConstGameBoardSize)
		return 0;


	/* Den ersten Schuss platzieren wir im Spielfeldzentrum, da hier die statistische Trefferwahrscheinlichkeit
	   am gr��ten ist (sofern keine spezielle Platzierungsstrategie verwendet wurde): */
	if (*pInOutNumOfShots == 0)
	{
		int32_t ix, iy;

		if (pRandomNumbers->Get_IntegerNumber2(1, 2) == 1)
		{
			ix = 4;
			iy = 5;
		}
		else
		{
			ix = 5;
			iy = 4;
		}

		int32_t id = ix + ConstGameBoardSizePerDir * iy;

		if (pInOutGameBoardData[id] == ConstGameBoard_Water)
		{
			pInOutGameBoardData[id] = ConstGameBoard_WaterShot;

			*pInOutNumOfShots += 1;
			return 1;
		}
		else if (pInOutGameBoardData[id] == ConstGameBoard_IntactElement)
		{
			pInOutGameBoardData[id] = ConstGameBoard_DamagedElement;

			*pInOutNumOfShots += 1;
			return 2;
		}
	} 
	/* end of if (*pInOutNumOfShots == 0)*/

	
	static constexpr int32_t ConstNumTestPositionsMax = 20;

	
	int32_t idArray[ConstNumTestPositionsMax];
	float placementEvaluationValueArray[ConstNumTestPositionsMax];

	int32_t ix, iy, id, loopCounter, loopCounter2, tempInt;

	//int32_t SelectionCounter = 0;

	for (int32_t i = 0; i < ConstNumTestPositionsMax; i++)
	{
		placementEvaluationValueArray[i] = 0.0f;

		loopCounter = 0;
		
		/* Ermittlung eines weiteren m�glichst guten Angriffsziels:*/
		do
		{
			id = pRandomNumbers->Get_IntegerNumber(0, ConstGameBoardSize);

			//id = SelectionCounter % ConstGameBoardSize;
			//SelectionCounter++;

			if (pInOutGameBoardData[id] == ConstGameBoard_WaterShot) // wenn sich die Schiffsplatzierung im Spielverlauf �ndern k�nnte, w�rde diese Kriterium wegfallen
				continue;
			if (pInOutGameBoardData[id] == ConstGameBoard_DamagedElement)
				continue;
			if (pInOutGameBoardData[id] == ConstGameBoard_DestroyedElement)
				continue;
			if (pPositionProbabilityMemory[id] == 0.0f && pRandomNumbers->Get_IntegerNumber2(0, 1000) < 2)
				continue;

			ix = id % ConstGameBoardSizePerDir;
			iy = id / ConstGameBoardSizePerDir;

			//  nicht auf horizontal/vertikal benachbarte Tiles schie�en:
			if ((ix + iy) % 2 == 0)
				continue;
			

			

			pUnnecessaryShotDetectionNeuron->Set_Dendrite_NeuronInput(ix, iy, pGameBoardData_WaterShots, ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 1, 1, 1, 1, 1.0f);
			pUnnecessaryShotDetectionNeuron->Calculate_NeuronOutput();

			if (pUnnecessaryShotDetectionNeuron->NeuronOutput > 0.0f)
				continue;

			pDestroyedEntityNeighborhoodDetectionNeuron->Set_Dendrite_NeuronInput(ix, iy, pGameBoardData_DestroyedElements, ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 1, 1, 1, 1);
			pDestroyedEntityNeighborhoodDetectionNeuron->Calculate_NeuronOutput();

			if (pDestroyedEntityNeighborhoodDetectionNeuron->NeuronOutput > 0.0f)
				continue;

			pPlacementEvaluationNeuron->Set_Dendrite_NeuronInput(ix, iy, pGameBoardData_WaterShotsAndDestroyedElements, ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, placementEvaluationHalfLRFSizePerDirMinus1, placementEvaluationHalfLRFSizePerDirMinus1, placementEvaluationHalfLRFSizePerDirMinus1, placementEvaluationHalfLRFSizePerDirMinus1, 1.0f);
			pPlacementEvaluationNeuron->Calculate_NeuronOutput();

			if (pPlacementEvaluationNeuron->NeuronOutput == 0.0f)
				continue;

			loopCounter++;

			// Suche nach einem L3/L4/L5-Schiff:
			if (placementEvaluationHalfLRFSizePerDirMinus1 > 1) 
			{
				if (loopCounter < 2000)
				{
					if (pPlacementEvaluationNeuron->NeuronOutput < 6.0f)
						continue;
				}
				else if (loopCounter < 3000)
				{
					if (pPlacementEvaluationNeuron->NeuronOutput < 5.0f)
						continue;
				}
				else if (loopCounter < 4000)
				{
					if (pPlacementEvaluationNeuron->NeuronOutput < 4.0f)
						continue;
				}
				else if (loopCounter < 5000)
				{
					if (pPlacementEvaluationNeuron->NeuronOutput < 3.0f)
						continue;
				}
				else if (loopCounter < 6000)
				{
					if (pPlacementEvaluationNeuron->NeuronOutput < 2.0f)
						continue;
				}
			} // end of if (placementEvaluationHalfLRFSizePerDirMinus1 > 1)
			
			// Suche nach einem L2-Schiff:
			else 
			{
				if (loopCounter < 2000)
				{
					if (pPlacementEvaluationNeuron->NeuronOutput < 4.0f)
						continue;
				}
				else if (loopCounter < 3000)
				{
					if (pPlacementEvaluationNeuron->NeuronOutput < 3.0f)
						continue;
				}
				else if (loopCounter < 4000)
				{
					if (pPlacementEvaluationNeuron->NeuronOutput < 2.0f)
						continue;
				}
			} // end of else 

			 /* Wenn m�glich kein Spielfeld beschie�en, an dem sich gem�� der
			 mutma�lichen Patzierungsstrategie gar kein Schiff befinden kann: */
			if (pPositionProbabilityMemory[id] == 0.0f && loopCounter < 7000)
				continue;

			idArray[i] = id;
			/*placementEvaluationValueArray[i] = pPositionProbabilityMemory[id] * pPlacementEvaluationNeuron->NeuronOutput;*/
			placementEvaluationValueArray[i] = pPositionProbabilityMemory[id] * sqrt(pPlacementEvaluationNeuron->NeuronOutput);
			break;

		} while (true);
	} // end of for(int32_t i = 0; i < ConstNumTestPositionsMax; i++)

	/* Auswahl des bestm�glichen Angriffsziels aus den zuvor ermittelten Zielen: */
	int32_t id_Best = idArray[0];
	float placementEvaluationValue_Best = placementEvaluationValueArray[0];

	for (int32_t i = 1; i < ConstNumTestPositionsMax; i++)
	{
		if (placementEvaluationValueArray[i] > placementEvaluationValue_Best)
		{
			id_Best = idArray[i];
			placementEvaluationValue_Best = placementEvaluationValueArray[i];
		}
	}

	// Beschuss des bestm�glichen Angriffsziels:
	if (pInOutGameBoardData[id_Best] == ConstGameBoard_Water)
	{
		pInOutGameBoardData[id_Best] = ConstGameBoard_WaterShot;

		*pInOutNumOfShots += 1;
		return 1;
	}
	else if (pInOutGameBoardData[id_Best] == ConstGameBoard_IntactElement)
	{
		pInOutGameBoardData[id_Best] = ConstGameBoard_DamagedElement;

		*pInOutNumOfShots += 1;
		return 2;
	}
}





static int32_t AI_Controlled_Random_Shot(int32_t *pInOutGameBoardData, int32_t *pInOutNumOfShots,
	CNeuronV2 *pDestroyedEntityNeighborhoodDetectionNeuron, float *pGameBoardData_DestroyedElements,
	CNeuronV2 *pPlacementEvaluationNeuron, int32_t placementEvaluationHalfLRFSizePerDirMinus1, float *pGameBoardData_WaterShotsAndDestroyedElements, CNeuronV2 *pUnnecessaryShotDetectionNeuron, float *pGameBoardData_WaterShots, int32_t lengthOfBiggestUndestroyedEntity,
	float *pPositionProbabilityMemory, float *pDynamicPositionProbabilityMemory, CRandomNumbersNN *pRandomNumbers)
{
	static int32_t ix_last = 0;
	static int32_t iy_last = 0;

	if (*pInOutNumOfShots == ConstGameBoardSize)
		return 0;

	/* Den ersten Schuss platzieren wir im Spielfeldzentrum, da hier die statistische Trefferwahrscheinlichkeit
	am gr��ten ist (sofern keine spezielle Platzierungsstrategie verwendet wurde): */
	if (*pInOutNumOfShots == 0)
	{
		int32_t ix, iy;

		if (pRandomNumbers->Get_IntegerNumber2(1, 2) == 1)
		{
			ix = 4;
			iy = 5;

			ix_last = ix;
			iy_last = iy;
		}
		else
		{
			ix = 5;
			iy = 4;

			ix_last = ix;
			iy_last = iy;
		}


		int32_t id = ix + ConstGameBoardSizePerDir * iy;

		if (pInOutGameBoardData[id] == ConstGameBoard_Water)
		{
			pInOutGameBoardData[id] = ConstGameBoard_WaterShot;

			*pInOutNumOfShots += 1;
			return 1;
		}
		else if (pInOutGameBoardData[id] == ConstGameBoard_IntactElement)
		{
			pInOutGameBoardData[id] = ConstGameBoard_DamagedElement;

			*pInOutNumOfShots += 1;
			return 2;
		}
	}
	/* end of if (*pInOutNumOfShots == 0)*/

	static constexpr int32_t ConstNumTestPositionsMax = 20;


	int32_t id_Array[ConstNumTestPositionsMax];
	float placementEvaluationValue[ConstNumTestPositionsMax];

	int32_t ix, iy, id, loopCounter, loopCounter2, tempInt;

	for (int32_t i = 0; i < ConstNumTestPositionsMax; i++)
	{
		placementEvaluationValue[i] = 0.0f;

		loopCounter = 0;
		//loopCounter2 = 0;

		/* Ermittlung eines weiteren m�glichst guten Angriffsziels:*/
		do
		{
			id = pRandomNumbers->Get_IntegerNumber(0, ConstGameBoardSize);

			if (pInOutGameBoardData[id] == ConstGameBoard_WaterShot)
				continue;
			if (pInOutGameBoardData[id] == ConstGameBoard_DamagedElement)
				continue;
			if (pInOutGameBoardData[id] == ConstGameBoard_DestroyedElement)
				continue;
			if ((pPositionProbabilityMemory[id] * pDynamicPositionProbabilityMemory[id]) == 0.0f && pRandomNumbers->Get_IntegerNumber2(0, 1000) < 2)
			//if (min(pPositionProbabilityMemory[id], pDynamicPositionProbabilityMemory[id]) == 0.0f && pRandomNumbers->Get_IntegerNumber2(0, 1000) < 2)
				continue;

			ix = id % ConstGameBoardSizePerDir;
			iy = id / ConstGameBoardSizePerDir;

			

			//  nicht auf horizontal/vertikal benachbarte Tiles schie�en:
			if ((ix + iy) % 2 == 0)
			{
				continue;
			}

			//loopCounter2++;

			/* Wenn m�glich kein Spielfeld beschie�en, an dem sich gem�� der
			mutma�lichen Patzierungsstrategie gar kein Schiff befinden kann: */
			//if (pPositionProbabilityMemory[id] == 0.0f && loopCounter2 < 20000)
			//continue;

			pUnnecessaryShotDetectionNeuron->Set_Dendrite_NeuronInput(ix, iy, pGameBoardData_WaterShots, ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 1, 1, 1, 1, 1.0f);
			pUnnecessaryShotDetectionNeuron->Calculate_NeuronOutput();

			if (pUnnecessaryShotDetectionNeuron->NeuronOutput > 0.0f)
				continue;

			pDestroyedEntityNeighborhoodDetectionNeuron->Set_Dendrite_NeuronInput(ix, iy, pGameBoardData_DestroyedElements, ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 1, 1, 1, 1);
			pDestroyedEntityNeighborhoodDetectionNeuron->Calculate_NeuronOutput();

			if (pDestroyedEntityNeighborhoodDetectionNeuron->NeuronOutput > 0.0f)
				continue;

			pPlacementEvaluationNeuron->Set_Dendrite_NeuronInput(ix, iy, pGameBoardData_WaterShotsAndDestroyedElements, ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, placementEvaluationHalfLRFSizePerDirMinus1, placementEvaluationHalfLRFSizePerDirMinus1, placementEvaluationHalfLRFSizePerDirMinus1, placementEvaluationHalfLRFSizePerDirMinus1, 1.0f);
			pPlacementEvaluationNeuron->Calculate_NeuronOutput();

			if (pPlacementEvaluationNeuron->NeuronOutput == 0.0f)
				continue;

			loopCounter++;

			/*if (loopCounter < 1000)
			{
				int32_t dx = ix - ix_last;
				int32_t dy = iy - iy_last;

				int32_t dxdx = dx * dx;
				int32_t dydy = dy * dy;

				if (dxdx < 16 && dydy < 16)
					continue;
			}*/

			// Suche nach einem L3/L4/L5-Schiff:
			if (placementEvaluationHalfLRFSizePerDirMinus1 > 1)
			{
				if (loopCounter < 2000)
				{
					if (pPlacementEvaluationNeuron->NeuronOutput < 6.0f)
						continue;
				}
				else if (loopCounter < 3000)
				{
					if (pPlacementEvaluationNeuron->NeuronOutput < 5.0f)
						continue;
				}
				else if (loopCounter < 4000)
				{
					if (pPlacementEvaluationNeuron->NeuronOutput < 4.0f)
						continue;
				}
				else if (loopCounter < 5000)
				{
					if (pPlacementEvaluationNeuron->NeuronOutput < 3.0f)
						continue;
				}
				else if (loopCounter < 6000)
				{
					if (pPlacementEvaluationNeuron->NeuronOutput < 2.0f)
						continue;
				}
			} // end of if (placementEvaluationHalfLRFSizePerDirMinus1 > 1)

			  // Suche nach einem L2-Schiff:
			else
			{
				if (loopCounter < 2000)
				{
					if (pPlacementEvaluationNeuron->NeuronOutput < 4.0f)
						continue;
				}
				else if (loopCounter < 3000)
				{
					if (pPlacementEvaluationNeuron->NeuronOutput < 3.0f)
						continue;
				}
				else if (loopCounter < 4000)
				{
					if (pPlacementEvaluationNeuron->NeuronOutput < 2.0f)
						continue;
				}
			} // end of else 

			  /* Wenn m�glich kein Spielfeld beschie�en, an dem sich gem�� der
			  mutma�lichen Patzierungsstrategie gar kein Schiff befinden kann: */
			//if (min(pPositionProbabilityMemory[id], pDynamicPositionProbabilityMemory[id]) == 0.0f && loopCounter < 7000)
			if ((pPositionProbabilityMemory[id] * pDynamicPositionProbabilityMemory[id]) == 0.0f && loopCounter < 7000)
				continue;

			id_Array[i] = id;
			////placementEvaluationValue[i] = (pPositionProbabilityMemory[id] + pDynamicPositionProbabilityMemory[id]) * pPlacementEvaluationNeuron->NeuronOutput;
			//placementEvaluationValue[i] = (pPositionProbabilityMemory[id] + pDynamicPositionProbabilityMemory[id]) * sqrt(pPlacementEvaluationNeuron->NeuronOutput);
			placementEvaluationValue[i] = (pPositionProbabilityMemory[id] * pDynamicPositionProbabilityMemory[id]) * sqrt(pPlacementEvaluationNeuron->NeuronOutput);
			break;

		} while (true);
	} // end of for(int32_t i = 0; i < ConstNumTestPositionsMax; i++)

	  /* Auswahl des bestm�glichen Angriffsziels aus den zuvor ermittelten Zielen: */
	int32_t id_Best = id_Array[0];
	float placementEvaluationValue_Best = placementEvaluationValue[0];

	for (int32_t i = 1; i < ConstNumTestPositionsMax; i++)
	{
		if (placementEvaluationValue[i] > placementEvaluationValue_Best)
		{
			id_Best = id_Array[i];
			placementEvaluationValue_Best = placementEvaluationValue[i];
		}
	}

	ix_last = id_Best % ConstGameBoardSizePerDir;
	iy_last = id_Best / ConstGameBoardSizePerDir;

	// Beschuss des bestm�glichen Angriffsziels:
	if (pInOutGameBoardData[id_Best] == ConstGameBoard_Water)
	{
		pInOutGameBoardData[id_Best] = ConstGameBoard_WaterShot;

		*pInOutNumOfShots += 1;
		return 1;
	}
	else if (pInOutGameBoardData[id_Best] == ConstGameBoard_IntactElement)
	{
		pInOutGameBoardData[id_Best] = ConstGameBoard_DamagedElement;

		*pInOutNumOfShots += 1;
		return 2;
	}
}


static int32_t AI_Controlled_Random_ShotOld(int32_t *pInOutGameBoardData, int32_t *pInOutNumOfShots,
	CNeuronV2 *pDestroyedEntityNeighborhoodDetectionNeuron, float *pGameBoardData_DestroyedElements,
	CNeuronV2 *pPlacementEvaluationNeuron, int32_t placementEvaluationHalfLRFSizePerDirMinus1, float *pGameBoardData_WaterShotsAndDestroyedElements, CNeuronV2 *pUnnecessaryShotDetectionNeuron, float *pGameBoardData_WaterShots, int32_t lengthOfBiggestUndestroyedEntity,
	float *pPositionProbabilityMemory, CRandomNumbersNN *pRandomNumbers, int32_t numAdditionalTestsMax = 100000)
{
	if (*pInOutNumOfShots == ConstGameBoardSize)
		return 0;

	if(*pInOutNumOfShots == 0)
	{ 
		int32_t ix, iy;

		if (pRandomNumbers->Get_IntegerNumber2(1, 2) == 1)
		{
			ix = 4;
			iy = 5;
		}
		else
		{
			ix = 5;
			iy = 4;
		}
		
		
		int32_t id = ix + ConstGameBoardSizePerDir * iy;

		if (pInOutGameBoardData[id] == ConstGameBoard_Water)
		{
			pInOutGameBoardData[id] = ConstGameBoard_WaterShot;

			*pInOutNumOfShots += 1;
			return 1;
		}
		else if (pInOutGameBoardData[id] == ConstGameBoard_IntactElement)
		{
			pInOutGameBoardData[id] = ConstGameBoard_DamagedElement;

			*pInOutNumOfShots += 1;
			return 2;
		}
	}


	int32_t numAdditionalTestsMaxHalf = numAdditionalTestsMax / 2;

	int32_t id, ix, iy, iyy;

	static constexpr int32_t ConstNumTestPositionsMax = 500;

	//int32_t id_Array[ConstNumTestPositionsMax];
	//float placementEvaluationValue[ConstNumTestPositionsMax];

	static int32_t id_Array[ConstNumTestPositionsMax];
	static float placementEvaluationValue[ConstNumTestPositionsMax];

	int32_t numTestPositions = 0;

	for (int32_t i = 0; i < numAdditionalTestsMax; i++)
	{
		placementEvaluationValue[i] = 0.0f;

		id = pRandomNumbers->Get_IntegerNumber(0, ConstGameBoardSize);

		if (pInOutGameBoardData[id] == ConstGameBoard_WaterShot)
			continue;
		if (pInOutGameBoardData[id] == ConstGameBoard_DamagedElement)
			continue;
		if (pInOutGameBoardData[id] == ConstGameBoard_DestroyedElement)
			continue;
		if (pPositionProbabilityMemory[id] == 0.0f)
			continue;

		ix = id % ConstGameBoardSizePerDir;
		iy = id / ConstGameBoardSizePerDir;

		
		pUnnecessaryShotDetectionNeuron->Set_Dendrite_NeuronInput(ix, iy, pGameBoardData_WaterShots, ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 1, 1, 1, 1, 1.0f);
		pUnnecessaryShotDetectionNeuron->Calculate_NeuronOutput();

		if (pUnnecessaryShotDetectionNeuron->NeuronOutput > 0.0f)
		{
			i--;
			continue;
		}

		//if (pPlacementEvaluationNeuron == nullptr)
		{
			//  nicht auf horizontal/vertikal benachbarte Tiles schie�en:
			if ((ix + iy) % 2 == 0)
			{
				i--;
				continue;
			}
		}

		pDestroyedEntityNeighborhoodDetectionNeuron->Set_Dendrite_NeuronInput(ix, iy, pGameBoardData_DestroyedElements, ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 1, 1, 1, 1);
		pDestroyedEntityNeighborhoodDetectionNeuron->Calculate_NeuronOutput();

		if (pDestroyedEntityNeighborhoodDetectionNeuron->NeuronOutput > 0.0f)
		{
			i--;
			continue;
		}

		if (pPlacementEvaluationNeuron != nullptr)
		{
			pPlacementEvaluationNeuron->Set_Dendrite_NeuronInput(ix, iy, pGameBoardData_WaterShotsAndDestroyedElements, ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, placementEvaluationHalfLRFSizePerDirMinus1, placementEvaluationHalfLRFSizePerDirMinus1, placementEvaluationHalfLRFSizePerDirMinus1, placementEvaluationHalfLRFSizePerDirMinus1, 1.0f);
			pPlacementEvaluationNeuron->Calculate_NeuronOutput();

			if (i < numAdditionalTestsMaxHalf)
			{
				if (pPlacementEvaluationNeuron->NeuronOutput <= 1.0f)
				{
					continue;
				}
			}
			
			if (pPlacementEvaluationNeuron->NeuronOutput == 0.0f)
			{
				i--;
				continue;
			}
		}

		//if (id < 0 || id > 99)
			//Add_To_Log(0, "illegal shot3");

		id_Array[numTestPositions] = id;

		

		placementEvaluationValue[numTestPositions] = pPositionProbabilityMemory[id];

		if (pPlacementEvaluationNeuron != nullptr && i < numAdditionalTestsMaxHalf)
			placementEvaluationValue[numTestPositions] *= pPlacementEvaluationNeuron->NeuronOutput;

		numTestPositions++;

		if (numTestPositions >= ConstNumTestPositionsMax)
			break;
	}
	// end of for(int32_t i = 0; i < numAdditionalTestsMax; i++)

	if (numTestPositions == 0)
	{
		int32_t loopCounter = 0;

		do
		{	
			id = pRandomNumbers->Get_IntegerNumber(0, ConstGameBoardSize);

			if (pInOutGameBoardData[id] == ConstGameBoard_WaterShot)
				continue;
			if (pInOutGameBoardData[id] == ConstGameBoard_DamagedElement)
				continue;
			if (pInOutGameBoardData[id] == ConstGameBoard_DestroyedElement)
				continue;

			/*
			////////// test
			if (pInOutGameBoardData[id] == ConstGameBoard_Water)
			{
				pInOutGameBoardData[id] = ConstGameBoard_WaterShot;

				*pInOutNumOfShots += 1;
				return 1;
			}
			else if (pInOutGameBoardData[id] == ConstGameBoard_IntactElement)
			{
				pInOutGameBoardData[id] = ConstGameBoard_DamagedElement;

				*pInOutNumOfShots += 1;
				return 2;
			}
			//////////
			*/

			ix = id % ConstGameBoardSizePerDir;
			iy = id / ConstGameBoardSizePerDir;

			pUnnecessaryShotDetectionNeuron->Set_Dendrite_NeuronInput(ix, iy, pGameBoardData_WaterShots, ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 1, 1, 1, 1, 1.0f);
			pUnnecessaryShotDetectionNeuron->Calculate_NeuronOutput();

			if (pUnnecessaryShotDetectionNeuron->NeuronOutput > 0.0f)
				continue;

			pDestroyedEntityNeighborhoodDetectionNeuron->Set_Dendrite_NeuronInput(ix, iy, pGameBoardData_DestroyedElements, ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 1, 1, 1, 1);
			pDestroyedEntityNeighborhoodDetectionNeuron->Calculate_NeuronOutput();

			if (pDestroyedEntityNeighborhoodDetectionNeuron->NeuronOutput > 0.0f)
				continue;

			loopCounter++;

			if (loopCounter < numAdditionalTestsMax)
			{
				if (pPositionProbabilityMemory[id] == 0.0f)
					continue;

				//  nicht auf horizontal/vertikal benachbarte Tiles schie�en:
				if ((ix + iy) % 2 == 0)
					continue;
			}

			/*if (pPositionMemory[id] == 0.0f)
			{
				Add_To_Log(0, "problematic shot 1", id);
			}*/

			//if (id < 0 || id > 99)
				//Add_To_Log(0, "illegal shot4");

			if (pInOutGameBoardData[id] == ConstGameBoard_Water)
			{
				pInOutGameBoardData[id] = ConstGameBoard_WaterShot;

				*pInOutNumOfShots += 1;
				return 1;
			}
			else if (pInOutGameBoardData[id] == ConstGameBoard_IntactElement)
			{
				pInOutGameBoardData[id] = ConstGameBoard_DamagedElement;

				*pInOutNumOfShots += 1;
				return 2;
			}
		} while (true);
	} // end of if (numTestPositions == 0)
	else if (numTestPositions > 0)
	{
		int32_t id_Best = id_Array[0];
		float evaluationValueBest = placementEvaluationValue[id_Best];
		float evaluationValue;

		for (int32_t i = 1; i < numTestPositions; i++)
		{
			evaluationValue = placementEvaluationValue[i];

			if (evaluationValue > evaluationValueBest)
			{
				evaluationValueBest = evaluationValue;
				id_Best = id_Array[i];
			}
		}

		/*if (pPositionMemory[id_Best] == 0.0f)
		{
			Add_To_Log(0, "problematic shot 2", id_Best);
		}*/

		if (pInOutGameBoardData[id_Best] == ConstGameBoard_Water)
		{
			pInOutGameBoardData[id_Best] = ConstGameBoard_WaterShot;

			*pInOutNumOfShots += 1;
			return 1;
		}
		else if (pInOutGameBoardData[id_Best] == ConstGameBoard_IntactElement)
		{
			pInOutGameBoardData[id_Best] = ConstGameBoard_DamagedElement;

			*pInOutNumOfShots += 1;
			return 2;
		}
	} // end of else if (numTestPositions > 0)

	return 0;
}



static int32_t AI_Shot(int32_t *pInOutGameBoardData, int32_t *pInOutNumOfShots, 
	CNeuronV2 *pSearchRemainingIntactShipElementsNeuron, float *pGameBoardData_DamagedElements,
	CNeuronV2 *pDestroyedEntityNeighborhoodDetectionNeuron, float *pGameBoardData_DestroyedElements,
	CNeuronV2 *pPlacementEvaluationNeuron, int32_t placementEvaluationHalfLRFSizePerDirMinus1, float *pGameBoardData_WaterShotsAndDestroyedElements, CNeuronV2 *pUnnecessaryShotDetectionNeuron, float *pGameBoardData_WaterShots, int32_t lengthOfBiggestUndestroyedEntity,
	float *pPositionProbabilityMemory, CRandomNumbersNN *pRandomNumbers)
{
	if (*pInOutNumOfShots == ConstGameBoardSize)
		return 0;

	int32_t savedID = -1;
	float neuronOutput;
	int32_t ix, iy;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pInOutGameBoardData[i] == ConstGameBoard_WaterShot)
			continue;
		else if (pInOutGameBoardData[i] == ConstGameBoard_DamagedElement)
			continue;
		else if (pInOutGameBoardData[i] == ConstGameBoard_DestroyedElement)
			continue;
		

		ix = i % ConstGameBoardSizePerDir;
		iy = i / ConstGameBoardSizePerDir;

		pDestroyedEntityNeighborhoodDetectionNeuron->Set_Dendrite_NeuronInput(ix, iy, pGameBoardData_DestroyedElements, ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 1, 1, 1, 1);
		pDestroyedEntityNeighborhoodDetectionNeuron->Calculate_NeuronOutput();

		if (pDestroyedEntityNeighborhoodDetectionNeuron->NeuronOutput > 0.0f)
			continue;

		pSearchRemainingIntactShipElementsNeuron->Set_Dendrite_NeuronInput(ix, iy, pGameBoardData_DamagedElements, ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 2, 2, 2, 2);

		pSearchRemainingIntactShipElementsNeuron->Calculate_NeuronOutput();
		neuronOutput = pSearchRemainingIntactShipElementsNeuron->NeuronOutput;

		/*
		Hinweise:
		akzeptables Angriffsziel: neuronOutput == 1
		optimales Angriffsziel: neuronOutput == 2
		*/

		// Beschuss eines optimalen Angriffsziels:
		if(neuronOutput == 2.0f)
		{
			if (pInOutGameBoardData[i] == ConstGameBoard_Water)
			{
				pInOutGameBoardData[i] = ConstGameBoard_WaterShot;

				*pInOutNumOfShots += 1;
				return 1;
			}
			else if (pInOutGameBoardData[i] == ConstGameBoard_IntactElement)
			{
				pInOutGameBoardData[i] = ConstGameBoard_DamagedElement;

				*pInOutNumOfShots += 1;
				return 2;
			}
		}
		// akzeptables Angriffsziel f�r eine m�gliche sp�tere Verwendung zwischenspeichern:
		else if (neuronOutput == 1.0f)
			savedID = i;

	} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	// Beschuss des zuletzt gespeicherten akzeptablen Angriffsziels:
	if (savedID > -1)
	{
		if (pInOutGameBoardData[savedID] == ConstGameBoard_Water)
		{
			pInOutGameBoardData[savedID] = ConstGameBoard_WaterShot;

			*pInOutNumOfShots += 1;
			return 1;
		}
		else if (pInOutGameBoardData[savedID] == ConstGameBoard_IntactElement)
		{
			pInOutGameBoardData[savedID] = ConstGameBoard_DamagedElement;

			*pInOutNumOfShots += 1;
			return 2;
		}
	} // end of if (savedID > -1)

	// Nach einem anderen Angriffsziel suchen, falls zuvor kein geeignetes Ziel gefunden wurde:

	
	return AI_Controlled_Random_Shot(pInOutGameBoardData, pInOutNumOfShots,
		pDestroyedEntityNeighborhoodDetectionNeuron, pGameBoardData_DestroyedElements,
		pPlacementEvaluationNeuron, placementEvaluationHalfLRFSizePerDirMinus1, pGameBoardData_WaterShotsAndDestroyedElements, pUnnecessaryShotDetectionNeuron, pGameBoardData_WaterShots, lengthOfBiggestUndestroyedEntity,
		pPositionProbabilityMemory, pRandomNumbers);
}

static int32_t AI_Shot(int32_t *pInOutGameBoardData, int32_t *pInOutNumOfShots,
	CNeuronV2 *pSearchRemainingIntactShipElementsNeuron, float *pGameBoardData_DamagedElements,
	CNeuronV2 *pDestroyedEntityNeighborhoodDetectionNeuron, float *pGameBoardData_DestroyedElements,
	CNeuronV2 *pPlacementEvaluationNeuron, int32_t placementEvaluationHalfLRFSizePerDirMinus1, float *pGameBoardData_WaterShotsAndDestroyedElements, CNeuronV2 *pUnnecessaryShotDetectionNeuron, float *pGameBoardData_WaterShots, int32_t lengthOfBiggestUndestroyedEntity,
	float *pPositionProbabilityMemory, float *pDynamicPositionProbabilityMemory, CRandomNumbersNN *pRandomNumbers)
{
	if (*pInOutNumOfShots == ConstGameBoardSize)
		return 0;

	int32_t savedID = -1;
	float neuronOutput;
	int32_t ix, iy;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pInOutGameBoardData[i] == ConstGameBoard_WaterShot)
			continue;
		else if (pInOutGameBoardData[i] == ConstGameBoard_DamagedElement)
			continue;
		else if (pInOutGameBoardData[i] == ConstGameBoard_DestroyedElement)
			continue;


		ix = i % ConstGameBoardSizePerDir;
		iy = i / ConstGameBoardSizePerDir;

		pDestroyedEntityNeighborhoodDetectionNeuron->Set_Dendrite_NeuronInput(ix, iy, pGameBoardData_DestroyedElements, ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 1, 1, 1, 1);
		pDestroyedEntityNeighborhoodDetectionNeuron->Calculate_NeuronOutput();

		if (pDestroyedEntityNeighborhoodDetectionNeuron->NeuronOutput > 0.0f)
			continue;

		pSearchRemainingIntactShipElementsNeuron->Set_Dendrite_NeuronInput(ix, iy, pGameBoardData_DamagedElements, ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 2, 2, 2, 2);

		pSearchRemainingIntactShipElementsNeuron->Calculate_NeuronOutput();
		neuronOutput = pSearchRemainingIntactShipElementsNeuron->NeuronOutput;

		/*
		Hinweise:
		akzeptables Angriffsziel: neuronOutput == 1
		optimales Angriffsziel: neuronOutput == 2
		*/

		// Beschuss eines optimalen Angriffsziels:
		if (neuronOutput == 2.0f)
		{
			if (pInOutGameBoardData[i] == ConstGameBoard_Water)
			{
				pInOutGameBoardData[i] = ConstGameBoard_WaterShot;

				*pInOutNumOfShots += 1;
				return 1;
			}
			else if (pInOutGameBoardData[i] == ConstGameBoard_IntactElement)
			{
				pInOutGameBoardData[i] = ConstGameBoard_DamagedElement;

				*pInOutNumOfShots += 1;
				return 2;
			}
		}
		// akzeptables Angriffsziel f�r eine m�gliche sp�tere Verwendung zwischenspeichern:
		else if (neuronOutput == 1.0f)
			savedID = i;

	} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	  // Beschuss des zuletzt gespeicherten akzeptablen Angriffsziels:
	if (savedID > -1)
	{
		if (pInOutGameBoardData[savedID] == ConstGameBoard_Water)
		{
			pInOutGameBoardData[savedID] = ConstGameBoard_WaterShot;

			*pInOutNumOfShots += 1;
			return 1;
		}
		else if (pInOutGameBoardData[savedID] == ConstGameBoard_IntactElement)
		{
			pInOutGameBoardData[savedID] = ConstGameBoard_DamagedElement;

			*pInOutNumOfShots += 1;
			return 2;
		}
	} // end of if (savedID > -1)

	  // Nach einem anderen Angriffsziel suchen, falls zuvor kein geeignetes Ziel gefunden wurde:

	return AI_Controlled_Random_Shot(pInOutGameBoardData, pInOutNumOfShots,
		pDestroyedEntityNeighborhoodDetectionNeuron, pGameBoardData_DestroyedElements,
		pPlacementEvaluationNeuron, placementEvaluationHalfLRFSizePerDirMinus1, pGameBoardData_WaterShotsAndDestroyedElements, pUnnecessaryShotDetectionNeuron, pGameBoardData_WaterShots, lengthOfBiggestUndestroyedEntity,
		pPositionProbabilityMemory, pDynamicPositionProbabilityMemory, pRandomNumbers);
}


/*
// UI Test + Human Player Placement Test
int main(void)
{
	//Set_ProcessPriority(2);

	CInputHandling InputHandling;
	InputHandling.Initialize();

	Begin_Log(0, "start AI_Log",
		"AI_Log.txt");

	Clear_Terminal_And_Reset_CursorPos();

	CWindowsConsoleScreenBuffer WinConsole;
	WinConsole.Initialize(40, 30, false, BackgroundColor);

	Set_Title("Battleship");
	Set_ConsolePos(10, 10);

	WinConsole.Set_CursorVisibilityAndSize(FALSE);
	//WinConsole.Set_Font(L"Consolas", 15, 15);
	//WinConsole.Set_Font(L"Consolas", 4, 4);
	//WinConsole.Set_Font(L"Consolas", 8, 8);
	WinConsole.Set_Font_Ext(L"Consolas", 90, 15, 15);


	//WinConsole.Set_BackgroundColor(RGB(100, 50, 25));
	WinConsole.Set_BackgroundColor(BackgroundColor);

	Set_CursorVisibilityAndSize(false);

	CRandomNumbersNN RandomNumbers;
	RandomNumbers.Change_Seed(20);

	char strBuffer[100];

	bool leftMouseButtonClick = false;
	bool middleMouseButtonClick = false;
	bool rightMouseButtonClick = false;

	float FrameTime = 1.0f;
	float FrameRate = 1.0f;

	int32_t GameBoardPosX_Left = 2;
	int32_t GameBoardPosY_Top = 5;

	CWindowsConsole2DObject GameBoard;
	GameBoard.Initialize(ConstGameBoardSizePerDir, ConstGameBoardSizePerDir);

	static int32_t InitialPaddedGameBoardData[ConstGameBoardSizePerDirWithPadding][ConstGameBoardSizePerDirWithPadding];
	static int32_t InitialGameBoardData[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];

	Init_PaddedGameBoard(InitialPaddedGameBoardData[0], 0);
	Init_GameBoard(InitialGameBoardData[0], 0);

	static constexpr int32_t ConstNumNavalEntities = 5;

	static CNavalEntity NavalEntityArray[ConstNumNavalEntities];

	NavalEntityArray[0].Initialize(5);
	NavalEntityArray[1].Initialize(4);
	NavalEntityArray[2].Initialize(3);
	NavalEntityArray[3].Initialize(3);
	NavalEntityArray[4].Initialize(2);

	

	int32_t navalEntityID = 0;

#pragma omp parallel num_threads(2)
	{
		do
		{
			if (KEYDOWN(VK_ESCAPE) == true)
				break;

			int32_t threadID = omp_get_thread_num();

			if (threadID == 1)
			{
				InputHandling.Check_For_Input();
			}
			else if (threadID == 0) // master thread
			{
				//auto last_timepoint = std::chrono::steady_clock::now();
				auto last_timepoint = steady_clock::now();

				
				

				if (InputHandling.LeftMouseButtonPressed == true)
				{
					if (leftMouseButtonClick == false)
						leftMouseButtonClick = true;
					else
						leftMouseButtonClick = false;
				}

				if (InputHandling.MiddleMouseButtonPressed == true)
				{
					if (middleMouseButtonClick == false)
						middleMouseButtonClick = true;
					else
						middleMouseButtonClick = false;
				}

				if (InputHandling.RightMouseButtonPressed == true)
				{
					if (rightMouseButtonClick == false)
						rightMouseButtonClick = true;
					else
						rightMouseButtonClick = false;
				}

				InputHandling.Reset_MouseButtons();

				int32_t mousePosX = InputHandling.MousePosX;
				int32_t mousePosY = InputHandling.MousePosY;

				int32_t relativeMousePosX = mousePosX - GameBoardPosX_Left;
				int32_t relativeMousePosY = mousePosY - GameBoardPosY_Top;

				int32_t paddedRelativeMousePosX = mousePosX - GameBoardPosX_Left + 1;
				int32_t paddedRelativeMousePosY = mousePosY - GameBoardPosY_Top + 1;

				Update_GameBoardGraphics2(&GameBoard, InitialPaddedGameBoardData[0]);

				if (relativeMousePosX > -1 && relativeMousePosX < ConstGameBoardSizePerDir)
				{
					if (relativeMousePosY > -1 && relativeMousePosY < ConstGameBoardSizePerDir)
					{
						GameBoard.Set_Pixel(relativeMousePosX, relativeMousePosY, lightaqua);

						if (middleMouseButtonClick == true)
						{
							Init_PaddedGameBoard(InitialPaddedGameBoardData[0], 0);
							Init_GameBoard(InitialGameBoardData[0], 0);
							navalEntityID = 0;
							goto EndOfPlacement;
						}

						if (navalEntityID < 5)
						{
							bool placementSuccess = false;

							if (navalEntityID == 0)
							{
								if (leftMouseButtonClick == true)
								{
									placementSuccess = Add_NavalEntityL5_HorizontalPlacement(paddedRelativeMousePosX - 1, paddedRelativeMousePosY - 1, InitialPaddedGameBoardData[0]);

									if (placementSuccess == true)
									{
										NavalEntityArray[navalEntityID].Set_HorizontalPlacementPosition(relativeMousePosX, relativeMousePosY);							
									}
								}
								else if (rightMouseButtonClick == true)
								{
									placementSuccess = Add_NavalEntityL5_VerticalPlacement(paddedRelativeMousePosX - 1, paddedRelativeMousePosY - 1, InitialPaddedGameBoardData[0]);

									if (placementSuccess == true)
									{
										NavalEntityArray[navalEntityID].Set_VerticalPlacementPosition(relativeMousePosX, relativeMousePosY);	
									}
								}
							}
							else if (navalEntityID == 1)
							{
								if (leftMouseButtonClick == true)
								{
									placementSuccess = Add_NavalEntityL4_HorizontalPlacement(paddedRelativeMousePosX - 1, paddedRelativeMousePosY - 1, InitialPaddedGameBoardData[0]);

									if (placementSuccess == true)
									{
										NavalEntityArray[navalEntityID].Set_HorizontalPlacementPosition(relativeMousePosX, relativeMousePosY);								
									}
								}
								else if (rightMouseButtonClick == true)
								{
									placementSuccess = Add_NavalEntityL4_VerticalPlacement(paddedRelativeMousePosX - 1, paddedRelativeMousePosY - 1, InitialPaddedGameBoardData[0]);

									if (placementSuccess == true)
									{
										NavalEntityArray[navalEntityID].Set_VerticalPlacementPosition(relativeMousePosX, relativeMousePosY);
									}
								}
							}
							else if (navalEntityID == 2 || navalEntityID == 3)
							{
								if (leftMouseButtonClick == true)
								{
									placementSuccess = Add_NavalEntityL3_HorizontalPlacement(paddedRelativeMousePosX - 1, paddedRelativeMousePosY - 1, InitialPaddedGameBoardData[0]);

									if (placementSuccess == true)
									{
										NavalEntityArray[navalEntityID].Set_HorizontalPlacementPosition(relativeMousePosX, relativeMousePosY);								
									}
								}
								else if (rightMouseButtonClick == true)
								{
									placementSuccess = Add_NavalEntityL3_VerticalPlacement(paddedRelativeMousePosX - 1, paddedRelativeMousePosY - 1, InitialPaddedGameBoardData[0]);

									if (placementSuccess == true)
									{
										NavalEntityArray[navalEntityID].Set_VerticalPlacementPosition(relativeMousePosX, relativeMousePosY);					
									}
								}
							}
							else if (navalEntityID == 4)
							{
								if (leftMouseButtonClick == true)
								{
									placementSuccess = Add_NavalEntityL2_HorizontalPlacement(paddedRelativeMousePosX - 1, paddedRelativeMousePosY - 1, InitialPaddedGameBoardData[0]);

									if (placementSuccess == true)
									{
										NavalEntityArray[navalEntityID].Set_HorizontalPlacementPosition(relativeMousePosX, relativeMousePosY);								
									}
								}
								else if (rightMouseButtonClick == true)
								{
									placementSuccess = Add_NavalEntityL2_VerticalPlacement(paddedRelativeMousePosX - 1, paddedRelativeMousePosY - 1, InitialPaddedGameBoardData[0]);

									if (placementSuccess == true)
									{
										NavalEntityArray[navalEntityID].Set_VerticalPlacementPosition(relativeMousePosX, relativeMousePosY);								
									}
								}
							}

							if (placementSuccess == true)
							{
								Copy_PaddedGameBoardData(InitialGameBoardData[0], InitialPaddedGameBoardData[0]);
								navalEntityID++;
							}
						} // end of if (navalEntityID < 4)

					EndOfPlacement:;


					} // end of if (relativeMousePosY > -1 && relativeMousePosY < ConstGameBoardSizePerDir)
				} // end of if (relativeMousePosX > -1 && relativeMousePosX < ConstGameBoardSizePerDir)

				
				
				leftMouseButtonClick = false;
				rightMouseButtonClick = false;
				middleMouseButtonClick = false;

				WinConsole.Clear_BackBuffer();

				WinConsole.Draw_2DObject_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top, GameBoard.pDataArray, GameBoard.NumCharactersPerRow, GameBoard.NumCharactersPerColumn);

				sprintf(strBuffer, "Ship Placement Test (Human Player)");
				WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, 1, strBuffer, lightaqua, black);

				sprintf(strBuffer, "left mButton: hor. ship");
				WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 13, strBuffer, lightaqua, black);
				sprintf(strBuffer, "right mButton: vert. ship");
				WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 15, strBuffer, lightaqua, black);
				sprintf(strBuffer, "middle mButton: clear");
				WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 17, strBuffer, lightaqua, black);

				WinConsole.Present_BackBuffer();

				//Frame-Bremse:

				auto current_timepoint = steady_clock::now();

				//while (current_timepoint - last_timepoint < 250ms)
				//while (current_timepoint - last_timepoint < 50ms)
				while (current_timepoint - last_timepoint < 16ms)
					//while (current_timepoint - last_timepoint < 16666us) // 16.7 Millisekunden (ms)  bzw. 16666 Mikrosekunden (us): maximal 60 Frames pro Sekunde					
				{
					current_timepoint = steady_clock::now();
				}

				FrameTime = 0.000000001f * (current_timepoint - last_timepoint).count();
				FrameRate = 1.0f / FrameTime;
			} // end of else if (threadID == 0) // master thread

		} while (true);
	} // end of #pragma omp parallel num_threads(2)

	InputHandling.CleanUp();
	WinConsole.Clear_BackBuffer();
	WinConsole.Present_BackBuffer();
	WinConsole.CleanUp();

	Set_CursorVisibilityAndSize(true);
	Reset_CursorPos();
	Set_CursorPos(0, 0);

	cout << "bye bye (Press Return)" << endl;

	//getchar();

	return 0;
}
*/


/*
// AI Test
int main(void)
{
	//Set_ProcessPriority(2);

	Begin_Log(0, "start AI_Log",
		"AI_Log.txt");

	Set_Title("Battleship");
	Set_ConsolePos(10, 10);

	char inputBuffer[100];
	int32_t RecalculatePlacementStrategies = 0;

	cout << "Recalculate Placement Strategies (0/1): ";

	cin.getline(inputBuffer, 100);
	RecalculatePlacementStrategies = atoi(inputBuffer);

	Clear_Terminal_And_Reset_CursorPos();

	CWindowsConsoleScreenBuffer WinConsole;
	WinConsole.Initialize(40, 30, false, BackgroundColor);

	Set_Title("Battleship");
	Set_ConsolePos(10, 10);

	WinConsole.Set_CursorVisibilityAndSize(FALSE);
	//WinConsole.Set_Font(L"Consolas", 15, 15);
	//WinConsole.Set_Font(L"Consolas", 4, 4);
	//WinConsole.Set_Font(L"Consolas", 8, 8);
	WinConsole.Set_Font_Ext(L"Consolas", 90, 15, 15);


	//WinConsole.Set_BackgroundColor(RGB(100, 50, 25));
	WinConsole.Set_BackgroundColor(BackgroundColor);

	Set_CursorVisibilityAndSize(false);


	

	CRandomNumbersNN RandomNumbers;
	RandomNumbers.Change_Seed(20);
	
	

	static constexpr int32_t ConstNumNavalEntities = 5;
	static constexpr int32_t ConstNumNavalEntityElements = 17;


	static int32_t GameBoardData[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];
	static int32_t InitialGameBoardData[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];

	static float GameBoardData_DestroyedElements[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];
	Init_2DimArray(GameBoardData_DestroyedElements[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);

	static float GameBoardData_WaterShots[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];
	Init_2DimArray(GameBoardData_WaterShots[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);

	static float GameBoardData_WaterShotsAndHits[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];
	Init_2DimArray(GameBoardData_WaterShotsAndHits[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);

	static float GameBoardData_WaterShotsAndDestroyedElements[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];
	Init_2DimArray(GameBoardData_WaterShotsAndDestroyedElements[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);
	
	static float GameBoardData_DamagedElements[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];
	Init_2DimArray(GameBoardData_DamagedElements[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);

	CNeuronV2 DestroyedEntityNeighborhoodDetectionNeuron;
	DestroyedEntityNeighborhoodDetectionNeuron.Init_Dendrite_Arrays(9);
	DestroyedEntityNeighborhoodDetectionNeuron.Set_ActivationFunction(DestroyedEntityNeighborhoodDetection);

	// local receptive field:
	float DestroyedEntityNeighborhoodDetectionLRF[9] = { 1.0f, 1.0f, 1.0f,  1.0f, 0.0f, 1.0f,  1.0f, 1.0f, 1.0f };
	DestroyedEntityNeighborhoodDetectionNeuron.Set_Dendrite_Factors(DestroyedEntityNeighborhoodDetectionLRF);

	CNeuronV2 UnnecessaryShotDetectionNeuron;
	UnnecessaryShotDetectionNeuron.Init_Dendrite_Arrays(9);
	UnnecessaryShotDetectionNeuron.Set_ActivationFunction(UnnecessaryShotDetection);

	// local receptive field:
	float UnnecessaryShotDetectionLRF[9] = { 0.0f, 1.0f, 0.0f,  1.0f, 0.0f, 1.0f,  0.0f, 1.0f, 0.0f };
	UnnecessaryShotDetectionNeuron.Set_Dendrite_Factors(UnnecessaryShotDetectionLRF);

	CNeuronV2 L2ShipPlacementEvaluationNeuron;
	L2ShipPlacementEvaluationNeuron.Init_Dendrite_Arrays(9);
	L2ShipPlacementEvaluationNeuron.Set_ActivationFunction(L2ShipPlacementEvaluation);
	int32_t L2PlacementEvaluationHalfLRFSizePerDirMinus1 = 1;

	CNeuronV2 L3ShipPlacementEvaluationNeuron;
	L3ShipPlacementEvaluationNeuron.Init_Dendrite_Arrays(25);
	L3ShipPlacementEvaluationNeuron.Set_ActivationFunction(L3ShipPlacementEvaluation);
	int32_t L3PlacementEvaluationHalfLRFSizePerDirMinus1 = 2;

	CNeuronV2 L4ShipPlacementEvaluationNeuron;	
	L4ShipPlacementEvaluationNeuron.Init_Dendrite_Arrays(49);
	L4ShipPlacementEvaluationNeuron.Set_ActivationFunction(L4ShipPlacementEvaluation);
	int32_t L4PlacementEvaluationHalfLRFSizePerDirMinus1 = 3;

	CNeuronV2 L5ShipPlacementEvaluationNeuron;
	L5ShipPlacementEvaluationNeuron.Init_Dendrite_Arrays(81);
	L5ShipPlacementEvaluationNeuron.Set_ActivationFunction(L5ShipPlacementEvaluation);
	int32_t L5PlacementEvaluationHalfLRFSizePerDirMinus1 = 4;
	


	CNeuronV2 SearchRemainingIntactShipElementsNeuron;
	SearchRemainingIntactShipElementsNeuron.Init_Dendrite_Arrays(25);
	SearchRemainingIntactShipElementsNeuron.Set_ActivationFunction(SearchRemainingIntactShipElements);

	// local receptive field:
	//float SearchRemainingIntactShipElementsLRF[25] = { 0.0f, 0.0f, -2.0f, 0.0f, 0.0f,
	//0.0f, 0.0f, -1.0f, 0.0f, 0.0f,
	//9.0f, 7.0f,  0.0f, 1.0f, 2.0f,
	//0.0f, 0.0f, -7.0f, 0.0f, 0.0f,
	//0.0f, 0.0f, -9.0f, 0.0f, 0.0f };

	float SearchRemainingIntactShipElementsLRF[25] = { 
		0.0f, 0.0f, -2.0f, 0.0f, 0.0f,
		0.0f, 0.0f, -1.0f, 0.0f, 0.0f,
		29.0f, 17.0f,  0.0f, 1.0f, 2.0f,
		0.0f, 0.0f, -17.0f, 0.0f, 0.0f,
		0.0f, 0.0f, -29.0f, 0.0f, 0.0f };


	SearchRemainingIntactShipElementsNeuron.Set_Dendrite_Factors(SearchRemainingIntactShipElementsLRF);
	
	

	

	static CNavalEntity NavalEntityArray[ConstNumNavalEntities];

	NavalEntityArray[0].Initialize(5);
	NavalEntityArray[1].Initialize(4);
	NavalEntityArray[2].Initialize(3);
	NavalEntityArray[3].Initialize(3);
	NavalEntityArray[4].Initialize(2);

	CPlacementStrategies PlacementStrategies;
	
	PlacementStrategies.Init_New_Strategies("BattleShipPlacementStrategiesSimple.txt", &RandomNumbers);
	

	if (RecalculatePlacementStrategies != 0)
	{
		PlacementStrategies.Train_MemoryNeurons(GameBoardData[0], NavalEntityArray, ConstNumNavalEntities, ConstNumNavalEntityElements, &RandomNumbers);
		PlacementStrategies.Save_HitProbabilityValues("SimpleBattleshipStrategies/Strategy");
	}
	else
	{
		PlacementStrategies.Load_HitProbabilityValues("SimpleBattleshipStrategies/Strategy");
	}
	
	
	RandomNumbers.Change_Seed(20);

	//Init_GameBoard_And_Set_RandomEntityPositions(InitialGameBoardData[0], NavalEntityArray, ConstNumNavalEntities, &RandomNumbers);
	
	int32_t StrategyID = RandomNumbers.Get_IntegerNumber(0, PlacementStrategies.NumStrategies);
	Init_GameBoard_And_Set_RandomEntityPositions(InitialGameBoardData[0], NavalEntityArray, ConstNumNavalEntities, &RandomNumbers, PlacementStrategies.pStrategyArray[StrategyID].ForbiddenTileIDList, PlacementStrategies.pStrategyArray[StrategyID].NumOfForbiddenTiles);
	Copy_GameBoard(GameBoardData[0], InitialGameBoardData[0]);

	//Add_To_Log(0, "new game");
	//Add_To_Log(0, "correct strategyID", StrategyID);

	float FrameTime = 1.0f;
	float FrameRate = 1.0f;

	int32_t GameBoardPosX_Left = 2;
	int32_t GameBoardPosY_Top = 5;

	
	CWindowsConsole2DObject GameBoard;
	GameBoard.Initialize(ConstGameBoardSizePerDir, ConstGameBoardSizePerDir);

	

	char strBuffer[100];

	

	int32_t NumOfShots = 0;
	int32_t MeanScore = 0;
	int32_t SumOfScore = 0;
	int32_t GameCounter = 0;
	int32_t LastScore = 0;
	int32_t Score = 0;

	int32_t PlacementStrategyNeuronID;
	
	int32_t loopcounter = 0;

	do
	{
		if (KEYDOWN(VK_ESCAPE) == true)
			break;

		//auto last_timepoint = std::chrono::steady_clock::now();
		auto last_timepoint = steady_clock::now();

			
		bool startNewGame = true;

		for (int32_t i = 0; i < ConstNumNavalEntities; i++)
		{
			if (NavalEntityArray[i].Destroyed == false)
			{
				startNewGame = false;
				break;
			}
		}

		if (startNewGame == true|| KEYDOWN(VK_F1) == true)
		{
			Init_2DimArray(GameBoardData_WaterShots[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);
			Init_2DimArray(GameBoardData_WaterShotsAndHits[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);
			Init_2DimArray(GameBoardData_DestroyedElements[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);
			Init_2DimArray(GameBoardData_DamagedElements[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);

		

			LastScore = ConstGameBoardSize - NumOfShots;
			SumOfScore += LastScore;
			GameCounter++;
			MeanScore = SumOfScore / GameCounter;
			NumOfShots = 0;
				
			//Init_GameBoard_And_Set_RandomEntityPositions(InitialGameBoardData[0], NavalEntityArray, ConstNumNavalEntities, &RandomNumbers);
			
			StrategyID = RandomNumbers.Get_IntegerNumber(0, PlacementStrategies.NumStrategies);
			Init_GameBoard_And_Set_RandomEntityPositions(InitialGameBoardData[0], NavalEntityArray, ConstNumNavalEntities, &RandomNumbers, PlacementStrategies.pStrategyArray[StrategyID].ForbiddenTileIDList, PlacementStrategies.pStrategyArray[StrategyID].NumOfForbiddenTiles);
			Copy_GameBoard(GameBoardData[0], InitialGameBoardData[0]);

			

			//Add_To_Log(0, "new game");
			//Add_To_Log(0, "correct strategyID", StrategyID);
		}

		if (loopcounter == 0)//RandomNumbers.Get_IntegerNumber(0, 10) == 1)
		{
			
			//for (int32_t i = 0; i < ConstNumNavalEntities; i++)
			//{
				//NavalEntityArray[i].Copy_Data_If_Destroyed(GameBoardData_DestroyedElements[0], 1.0f);					
			//}

			Copy_DestroyedElementData(GameBoardData_DestroyedElements[0], GameBoardData[0], 1.0f);
			Copy_WaterShotData(GameBoardData_WaterShots[0], GameBoardData[0], 1.0f);
			Copy_WaterShotAndHitData(GameBoardData_WaterShotsAndHits[0], GameBoardData[0], -1.0f, 1.0f);
			Copy_WaterShotAndDestroyedElementData(GameBoardData_WaterShotsAndDestroyedElements[0], GameBoardData[0], 1.0f);
			Copy_DamagedElementData(GameBoardData_DamagedElements[0], GameBoardData[0], 1.0f);


			CNeuronV2 *pPlacementStrategyNeuron = nullptr;
			PlacementStrategyNeuronID = -1;


			PlacementStrategies.Get_StrongestActivatedMemoryNeuron(&pPlacementStrategyNeuron, &PlacementStrategyNeuronID, GameBoardData_WaterShotsAndHits[0]);
			//Add_To_Log(0, "strategyID", PlacementStrategyNeuronID);


			// kleinstm�gliche NavalEntity-L�nge: 2
			CNeuronV2 *pPlacementEvaluationNeuron = &L2ShipPlacementEvaluationNeuron;				
			int32_t lengthOfBiggestUndestroyedEntity = 2;
			int32_t placementEvaluationHalfLRFSizePerDirMinus1 = 1;

			if (NavalEntityArray[0].Destroyed == false)
			{
				pPlacementEvaluationNeuron = &L5ShipPlacementEvaluationNeuron;
				lengthOfBiggestUndestroyedEntity = 5;
				placementEvaluationHalfLRFSizePerDirMinus1 = L5PlacementEvaluationHalfLRFSizePerDirMinus1;
			}
			else if (NavalEntityArray[1].Destroyed == false)
			{
				pPlacementEvaluationNeuron = &L4ShipPlacementEvaluationNeuron;
				lengthOfBiggestUndestroyedEntity = 4;
				placementEvaluationHalfLRFSizePerDirMinus1 = L4PlacementEvaluationHalfLRFSizePerDirMinus1;
			}
			else if (NavalEntityArray[2].Destroyed == false || NavalEntityArray[3].Destroyed == false)
			{
				pPlacementEvaluationNeuron = &L3ShipPlacementEvaluationNeuron;
				lengthOfBiggestUndestroyedEntity = 3;
				placementEvaluationHalfLRFSizePerDirMinus1 = L3PlacementEvaluationHalfLRFSizePerDirMinus1;
			}
				

				
			int32_t out = AI_Shot(GameBoardData[0], &NumOfShots,
					&SearchRemainingIntactShipElementsNeuron, GameBoardData_DamagedElements[0],
					&DestroyedEntityNeighborhoodDetectionNeuron, GameBoardData_DestroyedElements[0],
					pPlacementEvaluationNeuron, placementEvaluationHalfLRFSizePerDirMinus1, GameBoardData_WaterShotsAndDestroyedElements[0], &UnnecessaryShotDetectionNeuron, GameBoardData_WaterShots[0], lengthOfBiggestUndestroyedEntity, pPlacementStrategyNeuron->pDendrite_CentroidValueArray,
					&RandomNumbers);

			//if (out == 0)
				//Add_To_Log(0, "no shot");

			for (int32_t i = 0; i < ConstNumNavalEntities; i++)
			{
				NavalEntityArray[i].Check_Destruction(GameBoardData[0]);
			}

				
		} // end of if (loopcounter == 0)

		loopcounter++;

		if(loopcounter > 10)
			loopcounter = 0;

		Update_GameBoardGraphics(&GameBoard, GameBoardData[0]);
				
			
		WinConsole.Clear_BackBuffer();

		WinConsole.Draw_2DObject_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top, GameBoard.pDataArray, GameBoard.NumCharactersPerRow, GameBoard.NumCharactersPerColumn);

			
		

		Score = ConstGameBoardSize - NumOfShots;
		sprintf(strBuffer, "score: %03d", Score);
		WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 13, strBuffer, lightaqua, black);

		sprintf(strBuffer, "last: %03d", LastScore);
		WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 15, strBuffer, lightaqua, black);

		sprintf(strBuffer, "mean: %03d", MeanScore);
		WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 17, strBuffer, lightaqua, black);
			
		sprintf(strBuffer, "placement strategy: %03d", PlacementStrategyNeuronID);
		WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 19, strBuffer, lightaqua, black);

		sprintf(strBuffer, "correct placement strategy: %03d", StrategyID);
		WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 21, strBuffer, lightaqua, black);
		
		

		WinConsole.Present_BackBuffer();

		//Frame-Bremse:

		auto current_timepoint = steady_clock::now();

		//while (current_timepoint - last_timepoint < 250ms)
		//while (current_timepoint - last_timepoint < 50ms)
		while (current_timepoint - last_timepoint < 16ms)
		//while (current_timepoint - last_timepoint < 16666us) // 16.7 Millisekunden (ms)  bzw. 16666 Mikrosekunden (us): maximal 60 Frames pro Sekunde					
		{
			current_timepoint = steady_clock::now();
		}


		FrameTime = 0.000000001f * (current_timepoint - last_timepoint).count();
		FrameRate = 1.0f / FrameTime;
				
	} while (true);

    
	
	WinConsole.Clear_BackBuffer();
	WinConsole.Present_BackBuffer();
	WinConsole.CleanUp();

	Set_CursorVisibilityAndSize(true);
	Reset_CursorPos();
	Set_CursorPos(0, 0);

	cout << "bye bye (Press Return)" << endl;

	//getchar();
	
	return 0;
}
*/

/*
// AI Test (with dynamic placement strategies)
int main(void)
{
	//Set_ProcessPriority(2);

	Begin_Log(0, "start AI_Log",
		"AI_Log.txt");

	Set_Title("Battleship");
	Set_ConsolePos(10, 10);

	char inputBuffer[100];
	int32_t RecalculatePlacementStrategies = 0;

	cout << "Recalculate Placement Strategies (0/1): ";

	cin.getline(inputBuffer, 100);
	RecalculatePlacementStrategies = atoi(inputBuffer);

	Clear_Terminal_And_Reset_CursorPos();

	CWindowsConsoleScreenBuffer WinConsole;
	WinConsole.Initialize(40, 30, false, BackgroundColor);

	Set_Title("Battleship");
	Set_ConsolePos(10, 10);

	WinConsole.Set_CursorVisibilityAndSize(FALSE);
	//WinConsole.Set_Font(L"Consolas", 15, 15);
	//WinConsole.Set_Font(L"Consolas", 4, 4);
	//WinConsole.Set_Font(L"Consolas", 8, 8);
	WinConsole.Set_Font_Ext(L"Consolas", 90, 15, 15);


	//WinConsole.Set_BackgroundColor(RGB(100, 50, 25));
	WinConsole.Set_BackgroundColor(BackgroundColor);

	Set_CursorVisibilityAndSize(false);




	CRandomNumbersNN RandomNumbers;
	RandomNumbers.Change_Seed(20);

	CRandomNumbersNN RandomNumbers2;


	static constexpr int32_t ConstNumNavalEntities = 5;
	static constexpr int32_t ConstNumNavalEntityElements = 17;

	CDynamicForbiddenTileData DynamicForbiddenTileData;
	DynamicForbiddenTileData.Initialize(ConstGameBoardSize, ConstNumNavalEntities);

	


	static int32_t GameBoardData[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];
	static int32_t InitialGameBoardData[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];

	static float GameBoardData_DestroyedElements[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];
	Init_2DimArray(GameBoardData_DestroyedElements[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);

	static float GameBoardData_WaterShots[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];
	Init_2DimArray(GameBoardData_WaterShots[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);

	static float GameBoardData_WaterShotsAndHits[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];
	Init_2DimArray(GameBoardData_WaterShotsAndHits[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);

	static float GameBoardData_WaterShotsAndDestroyedElements[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];
	Init_2DimArray(GameBoardData_WaterShotsAndDestroyedElements[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);

	static float GameBoardData_DamagedElements[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];
	Init_2DimArray(GameBoardData_DamagedElements[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);

	CNeuronV2 DestroyedEntityNeighborhoodDetectionNeuron;
	DestroyedEntityNeighborhoodDetectionNeuron.Init_Dendrite_Arrays(9);
	DestroyedEntityNeighborhoodDetectionNeuron.Set_ActivationFunction(DestroyedEntityNeighborhoodDetection);

	// local receptive field:
	float DestroyedEntityNeighborhoodDetectionLRF[9] = { 1.0f, 1.0f, 1.0f,  1.0f, 0.0f, 1.0f,  1.0f, 1.0f, 1.0f };
	DestroyedEntityNeighborhoodDetectionNeuron.Set_Dendrite_Factors(DestroyedEntityNeighborhoodDetectionLRF);

	CNeuronV2 UnnecessaryShotDetectionNeuron;
	UnnecessaryShotDetectionNeuron.Init_Dendrite_Arrays(9);
	UnnecessaryShotDetectionNeuron.Set_ActivationFunction(UnnecessaryShotDetection);

	// local receptive field:
	float UnnecessaryShotDetectionLRF[9] = { 0.0f, 1.0f, 0.0f,  1.0f, 0.0f, 1.0f,  0.0f, 1.0f, 0.0f };
	UnnecessaryShotDetectionNeuron.Set_Dendrite_Factors(UnnecessaryShotDetectionLRF);

	CNeuronV2 L2ShipPlacementEvaluationNeuron;
	L2ShipPlacementEvaluationNeuron.Init_Dendrite_Arrays(9);
	L2ShipPlacementEvaluationNeuron.Set_ActivationFunction(L2ShipPlacementEvaluation);
	int32_t L2PlacementEvaluationHalfLRFSizePerDirMinus1 = 1;

	CNeuronV2 L3ShipPlacementEvaluationNeuron;
	L3ShipPlacementEvaluationNeuron.Init_Dendrite_Arrays(25);
	L3ShipPlacementEvaluationNeuron.Set_ActivationFunction(L3ShipPlacementEvaluation);
	int32_t L3PlacementEvaluationHalfLRFSizePerDirMinus1 = 2;

	CNeuronV2 L4ShipPlacementEvaluationNeuron;
	L4ShipPlacementEvaluationNeuron.Init_Dendrite_Arrays(49);
	L4ShipPlacementEvaluationNeuron.Set_ActivationFunction(L4ShipPlacementEvaluation);
	int32_t L4PlacementEvaluationHalfLRFSizePerDirMinus1 = 3;

	CNeuronV2 L5ShipPlacementEvaluationNeuron;
	L5ShipPlacementEvaluationNeuron.Init_Dendrite_Arrays(81);
	L5ShipPlacementEvaluationNeuron.Set_ActivationFunction(L5ShipPlacementEvaluation);
	int32_t L5PlacementEvaluationHalfLRFSizePerDirMinus1 = 4;



	CNeuronV2 SearchRemainingIntactShipElementsNeuron;
	SearchRemainingIntactShipElementsNeuron.Init_Dendrite_Arrays(25);
	SearchRemainingIntactShipElementsNeuron.Set_ActivationFunction(SearchRemainingIntactShipElements);

	// local receptive field:
	//float SearchRemainingIntactShipElementsLRF[25] = { 0.0f, 0.0f, -2.0f, 0.0f, 0.0f,
	//0.0f, 0.0f, -1.0f, 0.0f, 0.0f,
	//9.0f, 7.0f,  0.0f, 1.0f, 2.0f,
	//0.0f, 0.0f, -7.0f, 0.0f, 0.0f,
	//0.0f, 0.0f, -9.0f, 0.0f, 0.0f };

	float SearchRemainingIntactShipElementsLRF[25] = {
		0.0f, 0.0f, -2.0f, 0.0f, 0.0f,
		0.0f, 0.0f, -1.0f, 0.0f, 0.0f,
		29.0f, 17.0f,  0.0f, 1.0f, 2.0f,
		0.0f, 0.0f, -17.0f, 0.0f, 0.0f,
		0.0f, 0.0f, -29.0f, 0.0f, 0.0f };


	SearchRemainingIntactShipElementsNeuron.Set_Dendrite_Factors(SearchRemainingIntactShipElementsLRF);





	static CNavalEntity NavalEntityArray[ConstNumNavalEntities];

	NavalEntityArray[0].Initialize(5);
	NavalEntityArray[1].Initialize(4);
	NavalEntityArray[2].Initialize(3);
	NavalEntityArray[3].Initialize(3);
	NavalEntityArray[4].Initialize(2);

	CPlacementStrategies PlacementStrategies;

	PlacementStrategies.Init_New_Strategies("BattleShipPlacementStrategiesSimple.txt", &RandomNumbers, true);

	


	if (RecalculatePlacementStrategies != 0)
	{
		PlacementStrategies.Train_MemoryNeurons(GameBoardData[0], NavalEntityArray, ConstNumNavalEntities, ConstNumNavalEntityElements, &RandomNumbers);
		PlacementStrategies.Save_HitProbabilityValues("SimpleBattleshipStrategies/Strategy");
	}
	else
	{
		PlacementStrategies.Load_HitProbabilityValues("SimpleBattleshipStrategies/Strategy");
	}


	RandomNumbers.Change_Seed(20);

	//Init_GameBoard_And_Set_RandomEntityPositions(InitialGameBoardData[0], NavalEntityArray, ConstNumNavalEntities, &RandomNumbers);

	int32_t StrategyID = 8;
	//int32_t StrategyID = RandomNumbers.Get_IntegerNumber(0, PlacementStrategies.NumPrecalculatedStrategies);
	Init_GameBoard_And_Set_RandomEntityPositions(InitialGameBoardData[0], NavalEntityArray, ConstNumNavalEntities, &RandomNumbers, PlacementStrategies.pStrategyArray[StrategyID].ForbiddenTileIDList, PlacementStrategies.pStrategyArray[StrategyID].NumOfForbiddenTiles);
	Copy_GameBoard(GameBoardData[0], InitialGameBoardData[0]);

	//Add_To_Log(0, "new game");
	//Add_To_Log(0, "correct strategyID", StrategyID);

	float FrameTime = 1.0f;
	float FrameRate = 1.0f;

	int32_t GameBoardPosX_Left = 2;
	int32_t GameBoardPosY_Top = 5;


	CWindowsConsole2DObject GameBoard;
	GameBoard.Initialize(ConstGameBoardSizePerDir, ConstGameBoardSizePerDir);



	char strBuffer[100];



	int32_t NumOfShots = 0;
	int32_t MeanScore = 0;
	int32_t SumOfScore = 0;
	int32_t GameCounter = 0;
	int32_t LastScore = 0;
	int32_t Score = 0;

	int32_t PlacementStrategyNeuronID;

	int32_t loopcounter = 0;

	do
	{
		if (KEYDOWN(VK_ESCAPE) == true)
			break;

		//auto last_timepoint = std::chrono::steady_clock::now();
		auto last_timepoint = steady_clock::now();


		bool startNewGame = true;

		for (int32_t i = 0; i < ConstNumNavalEntities; i++)
		{
			if (NavalEntityArray[i].Destroyed == false)
			{
				startNewGame = false;
				break;
			}
		}

		if (startNewGame == true || KEYDOWN(VK_F1) == true)
		{
			Init_2DimArray(GameBoardData_WaterShots[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);
			Init_2DimArray(GameBoardData_WaterShotsAndHits[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);
			Init_2DimArray(GameBoardData_DestroyedElements[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);
			Init_2DimArray(GameBoardData_DamagedElements[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);



			LastScore = ConstGameBoardSize - NumOfShots;
			SumOfScore += LastScore;
			GameCounter++;
			MeanScore = SumOfScore / GameCounter;
			NumOfShots = 0;

			//Init_GameBoard_And_Set_RandomEntityPositions(InitialGameBoardData[0], NavalEntityArray, ConstNumNavalEntities, &RandomNumbers);

			StrategyID = 8;
			//StrategyID = RandomNumbers.Get_IntegerNumber(0, PlacementStrategies.NumPrecalculatedStrategies);
			Init_GameBoard_And_Set_RandomEntityPositions(InitialGameBoardData[0], NavalEntityArray, ConstNumNavalEntities, &RandomNumbers, PlacementStrategies.pStrategyArray[StrategyID].ForbiddenTileIDList, PlacementStrategies.pStrategyArray[StrategyID].NumOfForbiddenTiles);
			Copy_GameBoard(GameBoardData[0], InitialGameBoardData[0]);



			//Add_To_Log(0, "new game");
			//Add_To_Log(0, "correct strategyID", StrategyID);
		}

		if (loopcounter == 0)//RandomNumbers.Get_IntegerNumber(0, 10) == 1)
		{

			//for (int32_t i = 0; i < ConstNumNavalEntities; i++)
			//{
			//NavalEntityArray[i].Copy_Data_If_Destroyed(GameBoardData_DestroyedElements[0], 1.0f);					
			//}

			Copy_DestroyedElementData(GameBoardData_DestroyedElements[0], GameBoardData[0], 1.0f);
			Copy_WaterShotData(GameBoardData_WaterShots[0], GameBoardData[0], 1.0f);
			Copy_WaterShotAndHitData(GameBoardData_WaterShotsAndHits[0], GameBoardData[0], -1.0f, 1.0f);
			Copy_WaterShotAndDestroyedElementData(GameBoardData_WaterShotsAndDestroyedElements[0], GameBoardData[0], 1.0f);
			Copy_DamagedElementData(GameBoardData_DamagedElements[0], GameBoardData[0], 1.0f);


			DynamicForbiddenTileData.Update_ForbiddenTileData(NavalEntityArray, GameBoardData[0]);
			//DynamicForbiddenTileData.Calculate_DynamicPlacementStrategy(&PlacementStrategies, 1000, &RandomNumbers2);
			DynamicForbiddenTileData.Calculate_DynamicPlacementStrategy(&PlacementStrategies, 10, &RandomNumbers2);

			CNeuronV2 *pPlacementStrategyNeuron = nullptr;
			PlacementStrategyNeuronID = -1;

			//PlacementStrategies.Get_StrongestActivatedMemoryNeuron(&pPlacementStrategyNeuron, &PlacementStrategyNeuronID, GameBoardData_WaterShotsAndHits[0]);
			PlacementStrategies.Get_StrongestActivatedDynamicMemoryNeuron(&pPlacementStrategyNeuron, &PlacementStrategyNeuronID, GameBoardData_WaterShotsAndHits[0]);
			//Add_To_Log(0, "strategyID", PlacementStrategyNeuronID);


			// kleinstm�gliche NavalEntity-L�nge: 2
			CNeuronV2 *pPlacementEvaluationNeuron = &L2ShipPlacementEvaluationNeuron;
			int32_t lengthOfBiggestUndestroyedEntity = 2;
			int32_t placementEvaluationHalfLRFSizePerDirMinus1 = 1;

			if (NavalEntityArray[0].Destroyed == false)
			{
				pPlacementEvaluationNeuron = &L5ShipPlacementEvaluationNeuron;
				lengthOfBiggestUndestroyedEntity = 5;
				placementEvaluationHalfLRFSizePerDirMinus1 = L5PlacementEvaluationHalfLRFSizePerDirMinus1;
			}
			else if (NavalEntityArray[1].Destroyed == false)
			{
				pPlacementEvaluationNeuron = &L4ShipPlacementEvaluationNeuron;
				lengthOfBiggestUndestroyedEntity = 4;
				placementEvaluationHalfLRFSizePerDirMinus1 = L4PlacementEvaluationHalfLRFSizePerDirMinus1;
			}
			else if (NavalEntityArray[2].Destroyed == false || NavalEntityArray[3].Destroyed == false)
			{
				pPlacementEvaluationNeuron = &L3ShipPlacementEvaluationNeuron;
				lengthOfBiggestUndestroyedEntity = 3;
				placementEvaluationHalfLRFSizePerDirMinus1 = L3PlacementEvaluationHalfLRFSizePerDirMinus1;
			}

			

			


			int32_t out = AI_Shot(GameBoardData[0], &NumOfShots,
			&SearchRemainingIntactShipElementsNeuron, GameBoardData_DamagedElements[0],
			&DestroyedEntityNeighborhoodDetectionNeuron, GameBoardData_DestroyedElements[0],
			pPlacementEvaluationNeuron, placementEvaluationHalfLRFSizePerDirMinus1, GameBoardData_WaterShotsAndDestroyedElements[0], &UnnecessaryShotDetectionNeuron, GameBoardData_WaterShots[0], lengthOfBiggestUndestroyedEntity, pPlacementStrategyNeuron->pDendrite_CentroidValueArray,
				&RandomNumbers);

			//CNeuronV2 *pDynamicPlacementStrategyNeuron = &PlacementStrategies.pStrategyArray[PlacementStrategies.NumPrecalculatedStrategies].MemoryNeuron;
						
			//int32_t out = AI_Shot(GameBoardData[0], &NumOfShots,
			//&SearchRemainingIntactShipElementsNeuron, GameBoardData_DamagedElements[0],
			//&DestroyedEntityNeighborhoodDetectionNeuron, GameBoardData_DestroyedElements[0],
			//	pPlacementEvaluationNeuron, placementEvaluationHalfLRFSizePerDirMinus1, GameBoardData_WaterShotsAndDestroyedElements[0], &UnnecessaryShotDetectionNeuron, GameBoardData_WaterShots[0], lengthOfBiggestUndestroyedEntity, pPlacementStrategyNeuron->pDendrite_CentroidValueArray, pDynamicPlacementStrategyNeuron->pDendrite_CentroidValueArray,
			//&RandomNumbers);

			

			//if (out == 0)
			//Add_To_Log(0, "no shot");

			for (int32_t i = 0; i < ConstNumNavalEntities; i++)
			{
				NavalEntityArray[i].Check_Destruction(GameBoardData[0]);
			}


		} // end of if (loopcounter == 0)

		loopcounter++;

		if (loopcounter > 10)
			loopcounter = 0;

		Update_GameBoardGraphics(&GameBoard, GameBoardData[0]);


		WinConsole.Clear_BackBuffer();

		WinConsole.Draw_2DObject_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top, GameBoard.pDataArray, GameBoard.NumCharactersPerRow, GameBoard.NumCharactersPerColumn);




		Score = ConstGameBoardSize - NumOfShots;
		sprintf(strBuffer, "score: %03d", Score);
		WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 13, strBuffer, lightaqua, black);

		sprintf(strBuffer, "last: %03d", LastScore);
		WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 15, strBuffer, lightaqua, black);

		sprintf(strBuffer, "mean: %03d", MeanScore);
		WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 17, strBuffer, lightaqua, black);

		sprintf(strBuffer, "placement strategy: %03d", PlacementStrategyNeuronID);
		WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 19, strBuffer, lightaqua, black);

		sprintf(strBuffer, "correct placement strategy: %03d", StrategyID);
		WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 21, strBuffer, lightaqua, black);



		WinConsole.Present_BackBuffer();

		//Frame-Bremse:

		auto current_timepoint = steady_clock::now();

		//while (current_timepoint - last_timepoint < 250ms)
		//while (current_timepoint - last_timepoint < 50ms)
		while (current_timepoint - last_timepoint < 16ms)
			//while (current_timepoint - last_timepoint < 16666us) // 16.7 Millisekunden (ms)  bzw. 16666 Mikrosekunden (us): maximal 60 Frames pro Sekunde					
		{
			current_timepoint = steady_clock::now();
		}


		FrameTime = 0.000000001f * (current_timepoint - last_timepoint).count();
		FrameRate = 1.0f / FrameTime;

	} while (true);



	WinConsole.Clear_BackBuffer();
	WinConsole.Present_BackBuffer();
	WinConsole.CleanUp();

	Set_CursorVisibilityAndSize(true);
	Reset_CursorPos();
	Set_CursorPos(0, 0);

	cout << "bye bye (Press Return)" << endl;

	//getchar();

	return 0;
}
*/


/*
// AI Placememt + Human Player Search
int main(void)
{
	//Set_ProcessPriority(2);

	Begin_Log(0, "start AI_Log",
		"AI_Log.txt");

	Set_Title("Battleship");
	Set_ConsolePos(10, 10);

	char inputBuffer[100];
	int32_t RecalculatePlacementStrategies = 0;

	cout << "Recalculate Placement Strategies (0/1): ";

	cin.getline(inputBuffer, 100);
	RecalculatePlacementStrategies = atoi(inputBuffer);

	CInputHandling InputHandling;
	InputHandling.Initialize();

	Clear_Terminal_And_Reset_CursorPos();

	CWindowsConsoleScreenBuffer WinConsole;
	WinConsole.Initialize(40, 30, false, BackgroundColor);

	Set_Title("Battleship");
	Set_ConsolePos(10, 10);

	WinConsole.Set_CursorVisibilityAndSize(FALSE);
	//WinConsole.Set_Font(L"Consolas", 15, 15);
	//WinConsole.Set_Font(L"Consolas", 4, 4);
	//WinConsole.Set_Font(L"Consolas", 8, 8);
	WinConsole.Set_Font_Ext(L"Consolas", 90, 15, 15);


	//WinConsole.Set_BackgroundColor(RGB(100, 50, 25));
	WinConsole.Set_BackgroundColor(BackgroundColor);

	Set_CursorVisibilityAndSize(false);




	CRandomNumbersNN RandomNumbers;
	RandomNumbers.Change_Seed(20);



	static constexpr int32_t ConstNumNavalEntities = 5;
	static constexpr int32_t ConstNumNavalEntityElements = 17;


	static int32_t GameBoardData[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];
	static int32_t InitialGameBoardData[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];

	

	static CNavalEntity NavalEntityArray[ConstNumNavalEntities];

	NavalEntityArray[0].Initialize(5);
	NavalEntityArray[1].Initialize(4);
	NavalEntityArray[2].Initialize(3);
	NavalEntityArray[3].Initialize(3);
	NavalEntityArray[4].Initialize(2);

	CPlacementStrategies PlacementStrategies;

	PlacementStrategies.Init_New_Strategies("BattleShipPlacementStrategies.txt", &RandomNumbers);


	if (RecalculatePlacementStrategies != 0)
	{
		PlacementStrategies.Train_MemoryNeurons(GameBoardData[0], NavalEntityArray, ConstNumNavalEntities, ConstNumNavalEntityElements, &RandomNumbers);
		PlacementStrategies.Save_HitProbabilityValues("BattleshipStrategies/Strategy");
	}
	else
	{
		PlacementStrategies.Load_HitProbabilityValues("BattleshipStrategies/Strategy");
	}


	RandomNumbers.Change_Seed(20);

	//Init_GameBoard_And_Set_RandomEntityPositions(InitialGameBoardData[0], NavalEntityArray, ConstNumNavalEntities, &RandomNumbers);

	int32_t StrategyID = RandomNumbers.Get_IntegerNumber(0, PlacementStrategies.NumStrategies);
	Init_GameBoard_And_Set_RandomEntityPositions(InitialGameBoardData[0], NavalEntityArray, ConstNumNavalEntities, &RandomNumbers, PlacementStrategies.pStrategyArray[StrategyID].ForbiddenTileIDList, PlacementStrategies.pStrategyArray[StrategyID].NumOfForbiddenTiles);
	Copy_GameBoard(GameBoardData[0], InitialGameBoardData[0]);

	//Add_To_Log(0, "new game");
	//Add_To_Log(0, "correct strategyID", StrategyID);

	float FrameTime = 1.0f;
	float FrameRate = 1.0f;

	bool leftMouseButtonClick = false;
	bool middleMouseButtonClick = false;
	bool rightMouseButtonClick = false;

	int32_t GameBoardPosX_Left = 2;
	int32_t GameBoardPosY_Top = 5;


	CWindowsConsole2DObject GameBoard;
	GameBoard.Initialize(ConstGameBoardSizePerDir, ConstGameBoardSizePerDir);



	char strBuffer[100];



	int32_t NumOfShots = 0;
	int32_t MeanScore = 0;
	int32_t SumOfScore = 0;
	int32_t GameCounter = 0;
	int32_t LastScore = 0;
	int32_t Score = 0;

	int32_t PlacementStrategyNeuronID;

#pragma omp parallel num_threads(2)
	{
		do
		{
			if (KEYDOWN(VK_ESCAPE) == true)
				break;

			int32_t threadID = omp_get_thread_num();

			if (threadID == 1)
			{
				InputHandling.Check_For_Input();
			}
			else if (threadID == 0) // master thread
			{
				//auto last_timepoint = std::chrono::steady_clock::now();
				auto last_timepoint = steady_clock::now();

				if (InputHandling.LeftMouseButtonPressed == true)
				{
					if (leftMouseButtonClick == false)
						leftMouseButtonClick = true;
					else
						leftMouseButtonClick = false;
				}

				if (InputHandling.MiddleMouseButtonPressed == true)
				{
					if (middleMouseButtonClick == false)
						middleMouseButtonClick = true;
					else
						middleMouseButtonClick = false;
				}

				if (InputHandling.RightMouseButtonPressed == true)
				{
					if (rightMouseButtonClick == false)
						rightMouseButtonClick = true;
					else
						rightMouseButtonClick = false;
				}

				InputHandling.Reset_MouseButtons();

				int32_t mousePosX = InputHandling.MousePosX;
				int32_t mousePosY = InputHandling.MousePosY;

				int32_t relativeMousePosX = mousePosX - GameBoardPosX_Left;
				int32_t relativeMousePosY = mousePosY - GameBoardPosY_Top;

				bool startNewGame = true;

				for (int32_t i = 0; i < ConstNumNavalEntities; i++)
				{
					if (NavalEntityArray[i].Destroyed == false)
					{
						startNewGame = false;
						break;
					}
				}

				if (startNewGame == true || KEYDOWN(VK_F1) == true)
				{
					LastScore = ConstGameBoardSize - NumOfShots;
					SumOfScore += LastScore;
					GameCounter++;
					MeanScore = SumOfScore / GameCounter;
					NumOfShots = 0;

					//Init_GameBoard_And_Set_RandomEntityPositions(InitialGameBoardData[0], NavalEntityArray, ConstNumNavalEntities, &RandomNumbers);

					StrategyID = RandomNumbers.Get_IntegerNumber(0, PlacementStrategies.NumStrategies);
					Init_GameBoard_And_Set_RandomEntityPositions(InitialGameBoardData[0], NavalEntityArray, ConstNumNavalEntities, &RandomNumbers, PlacementStrategies.pStrategyArray[StrategyID].ForbiddenTileIDList, PlacementStrategies.pStrategyArray[StrategyID].NumOfForbiddenTiles);
					
					Copy_GameBoard(GameBoardData[0], InitialGameBoardData[0]);



					//Add_To_Log(0, "new game");
					//Add_To_Log(0, "correct strategyID", StrategyID);
				}

				
				// player shot:
				if (relativeMousePosX > -1 && relativeMousePosX < ConstGameBoardSizePerDir)
				{
					if (relativeMousePosY > -1 && relativeMousePosY < ConstGameBoardSizePerDir)
					{
						if(leftMouseButtonClick == true)
						{
							int32_t tileData = GameBoardData[relativeMousePosY][relativeMousePosX];

							if (tileData == ConstGameBoard_Water)
							{
								NumOfShots++;
								GameBoardData[relativeMousePosY][relativeMousePosX] = ConstGameBoard_WaterShot;
							}
							else if (tileData == ConstGameBoard_IntactElement)
							{
								NumOfShots++;
								GameBoardData[relativeMousePosY][relativeMousePosX] = ConstGameBoard_DamagedElement;
							}
						}
					}
				} // end of if (relativeMousePosX > -1 && relativeMousePosX < ConstGameBoardSizePerDir)
						
						

				for (int32_t i = 0; i < ConstNumNavalEntities; i++)
				{
					NavalEntityArray[i].Check_Destruction(GameBoardData[0]);
				}

					
				//Update_GameBoardGraphics(&GameBoard, GameBoardData[0]);
				Update_GameBoardGraphics_DontShow_IntactParts(&GameBoard, GameBoardData[0]);

				if (relativeMousePosX > -1 && relativeMousePosX < ConstGameBoardSizePerDir)
				{
					if (relativeMousePosY > -1 && relativeMousePosY < ConstGameBoardSizePerDir)
					{
						GameBoard.Set_Pixel(relativeMousePosX, relativeMousePosY, lightaqua);
					}
				}

				leftMouseButtonClick = false;
				rightMouseButtonClick = false;
				middleMouseButtonClick = false;

				WinConsole.Clear_BackBuffer();

				WinConsole.Draw_2DObject_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top, GameBoard.pDataArray, GameBoard.NumCharactersPerRow, GameBoard.NumCharactersPerColumn);

				
				sprintf(strBuffer, "Human Player Ship Search");
				WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, 1, strBuffer, lightaqua, black);


				Score = ConstGameBoardSize - NumOfShots;
				sprintf(strBuffer, "score: %03d", Score);
				WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 13, strBuffer, lightaqua, black);

				sprintf(strBuffer, "last: %03d", LastScore);
				WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 15, strBuffer, lightaqua, black);

				sprintf(strBuffer, "mean: %03d", MeanScore);
				WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 17, strBuffer, lightaqua, black);

				WinConsole.Present_BackBuffer();

				//Frame-Bremse:

				auto current_timepoint = steady_clock::now();

				//while (current_timepoint - last_timepoint < 250ms)
				//while (current_timepoint - last_timepoint < 50ms)
				while (current_timepoint - last_timepoint < 16ms)
					//while (current_timepoint - last_timepoint < 16666us) // 16.7 Millisekunden (ms)  bzw. 16666 Mikrosekunden (us): maximal 60 Frames pro Sekunde					
				{
					current_timepoint = steady_clock::now();
				}


				FrameTime = 0.000000001f * (current_timepoint - last_timepoint).count();
				FrameRate = 1.0f / FrameTime;
			} // end of else if (threadID == 0) // master thread

		} while (true);
	} // end of #pragma omp parallel num_threads(2)


	WinConsole.Clear_BackBuffer();
	WinConsole.Present_BackBuffer();
	WinConsole.CleanUp();

	Set_CursorVisibilityAndSize(true);
	Reset_CursorPos();
	Set_CursorPos(0, 0);

	cout << "bye bye (Press Return)" << endl;

	//getchar();

	return 0;
}
*/

/*
// AI Placememt + Human Player Search  vs. AI Search
int main(void)
{
	//Set_ProcessPriority(2);

	Begin_Log(0, "start AI_Log",
		"AI_Log.txt");

	Set_Title("Battleship");
	Set_ConsolePos(10, 10);

	char inputBuffer[100];
	int32_t RecalculatePlacementStrategies = 0;

	cout << "Recalculate Placement Strategies (0/1): ";

	cin.getline(inputBuffer, 100);
	RecalculatePlacementStrategies = atoi(inputBuffer);

	int32_t RandomSeed = 1;

	cout << "RandomSeed (> 0): ";

	cin.getline(inputBuffer, 100);
	RandomSeed = atoi(inputBuffer);
	RandomSeed = max(1, RandomSeed);

	CInputHandling InputHandling;
	InputHandling.Initialize();

	Clear_Terminal_And_Reset_CursorPos();

	CWindowsConsoleScreenBuffer WinConsole;
	WinConsole.Initialize(40, 30, false, BackgroundColor);

	Set_Title("Battleship");
	Set_ConsolePos(10, 10);

	WinConsole.Set_CursorVisibilityAndSize(FALSE);
	//WinConsole.Set_Font(L"Consolas", 15, 15);
	//WinConsole.Set_Font(L"Consolas", 4, 4);
	//WinConsole.Set_Font(L"Consolas", 8, 8);
	WinConsole.Set_Font_Ext(L"Consolas", 90, 15, 15);


	//WinConsole.Set_BackgroundColor(RGB(100, 50, 25));
	WinConsole.Set_BackgroundColor(BackgroundColor);

	Set_CursorVisibilityAndSize(false);




	CRandomNumbersNN RandomNumbers;
	RandomNumbers.Change_Seed(RandomSeed);

	

	static constexpr int32_t ConstNumNavalEntities = 5;
	static constexpr int32_t ConstNumNavalEntityElements = 17;


	static int32_t GameBoardData[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];
	static int32_t InitialGameBoardData[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];

	static float GameBoardData_DestroyedElements[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];
	Init_2DimArray(GameBoardData_DestroyedElements[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);

	static float GameBoardData_WaterShots[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];
	Init_2DimArray(GameBoardData_WaterShots[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);

	static float GameBoardData_WaterShotsAndHits[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];
	Init_2DimArray(GameBoardData_WaterShotsAndHits[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);

	static float GameBoardData_WaterShotsAndDestroyedElements[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];
	Init_2DimArray(GameBoardData_WaterShotsAndDestroyedElements[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);

	static float GameBoardData_DamagedElements[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];
	Init_2DimArray(GameBoardData_DamagedElements[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);

	CNeuronV2 DestroyedEntityNeighborhoodDetectionNeuron;
	DestroyedEntityNeighborhoodDetectionNeuron.NeuronID = 10;
	DestroyedEntityNeighborhoodDetectionNeuron.Init_Dendrite_Arrays(9);
	DestroyedEntityNeighborhoodDetectionNeuron.Set_ActivationFunction(DestroyedEntityNeighborhoodDetection);

	// local receptive field:
	float DestroyedEntityNeighborhoodDetectionLRF[9] = { 1.0f, 1.0f, 1.0f,  1.0f, 0.0f, 1.0f,  1.0f, 1.0f, 1.0f };
	DestroyedEntityNeighborhoodDetectionNeuron.Set_Dendrite_Factors(DestroyedEntityNeighborhoodDetectionLRF);

	CNeuronV2 UnnecessaryShotDetectionNeuron;
	UnnecessaryShotDetectionNeuron.NeuronID = 20;
	UnnecessaryShotDetectionNeuron.Init_Dendrite_Arrays(9);
	UnnecessaryShotDetectionNeuron.Set_ActivationFunction(UnnecessaryShotDetection);

	// local receptive field:
	float UnnecessaryShotDetectionLRF[9] = { 0.0f, 1.0f, 0.0f,  1.0f, 0.0f, 1.0f,  0.0f, 1.0f, 0.0f };
	UnnecessaryShotDetectionNeuron.Set_Dendrite_Factors(UnnecessaryShotDetectionLRF);

	CNeuronV2 L2ShipPlacementEvaluationNeuron;
	L2ShipPlacementEvaluationNeuron.Init_Dendrite_Arrays(9);
	L2ShipPlacementEvaluationNeuron.Set_ActivationFunction(L2ShipPlacementEvaluation);
	int32_t L2PlacementEvaluationHalfLRFSizePerDirMinus1 = 1;

	CNeuronV2 L3ShipPlacementEvaluationNeuron;
	L3ShipPlacementEvaluationNeuron.Init_Dendrite_Arrays(25);
	L3ShipPlacementEvaluationNeuron.Set_ActivationFunction(L3ShipPlacementEvaluation);
	int32_t L3PlacementEvaluationHalfLRFSizePerDirMinus1 = 2;

	CNeuronV2 L4ShipPlacementEvaluationNeuron;
	L4ShipPlacementEvaluationNeuron.Init_Dendrite_Arrays(49);
	L4ShipPlacementEvaluationNeuron.Set_ActivationFunction(L4ShipPlacementEvaluation);
	int32_t L4PlacementEvaluationHalfLRFSizePerDirMinus1 = 3;

	CNeuronV2 L5ShipPlacementEvaluationNeuron;
	L5ShipPlacementEvaluationNeuron.Init_Dendrite_Arrays(81);
	L5ShipPlacementEvaluationNeuron.Set_ActivationFunction(L5ShipPlacementEvaluation);
	int32_t L5PlacementEvaluationHalfLRFSizePerDirMinus1 = 4;


	CNeuronV2 SearchRemainingIntactShipElementsNeuron;
	SearchRemainingIntactShipElementsNeuron.NeuronID = 60;
	SearchRemainingIntactShipElementsNeuron.Init_Dendrite_Arrays(25);
	SearchRemainingIntactShipElementsNeuron.Set_ActivationFunction(SearchRemainingIntactShipElements);

	// local receptive field:
	float SearchRemainingIntactShipElementsLRF[25] = {
	0.0f, 0.0f, -2.0f, 0.0f, 0.0f,
	0.0f, 0.0f, -1.0f, 0.0f, 0.0f,
	29.0f, 17.0f,  0.0f, 1.0f, 2.0f,
	0.0f, 0.0f, -17.0f, 0.0f, 0.0f,
	0.0f, 0.0f, -29.0f, 0.0f, 0.0f };

	

	SearchRemainingIntactShipElementsNeuron.Set_Dendrite_Factors(SearchRemainingIntactShipElementsLRF);



	static CNavalEntity NavalEntityArray[ConstNumNavalEntities];

	NavalEntityArray[0].Initialize(5);
	NavalEntityArray[1].Initialize(4);
	NavalEntityArray[2].Initialize(3);
	NavalEntityArray[3].Initialize(3);
	NavalEntityArray[4].Initialize(2);

	CPlacementStrategies PlacementStrategies;

	PlacementStrategies.Init_New_Strategies("BattleShipPlacementStrategies.txt", &RandomNumbers);


	if (RecalculatePlacementStrategies != 0)
	{
		PlacementStrategies.Train_MemoryNeurons(GameBoardData[0], NavalEntityArray, ConstNumNavalEntities, ConstNumNavalEntityElements, &RandomNumbers);
		PlacementStrategies.Save_HitProbabilityValues("BattleshipStrategies/Strategy");
	}
	else
	{
		PlacementStrategies.Load_HitProbabilityValues("BattleshipStrategies/Strategy");
	}


	RandomNumbers.Change_Seed(RandomSeed);

	Init_GameBoard_And_Set_RandomEntityPositions(InitialGameBoardData[0], NavalEntityArray, ConstNumNavalEntities, &RandomNumbers);

	//int32_t StrategyID = RandomNumbers.Get_IntegerNumber(0, PlacementStrategies.NumStrategies);
	//Init_GameBoard_And_Set_RandomEntityPositions(InitialGameBoardData[0], NavalEntityArray, ConstNumNavalEntities, &RandomNumbers, PlacementStrategies.pStrategyArray[StrategyID].ForbiddenTileIDList, PlacementStrategies.pStrategyArray[StrategyID].NumOfForbiddenTiles);
	Copy_GameBoard(GameBoardData[0], InitialGameBoardData[0]);

	//Add_To_Log(0, "new game");
	//Add_To_Log(0, "correct strategyID", StrategyID);

	float FrameTime = 1.0f;
	float FrameRate = 1.0f;

	bool leftMouseButtonClick = false;
	bool middleMouseButtonClick = false;
	bool rightMouseButtonClick = false;

	int32_t GameBoardPosX_Left = 2;
	int32_t GameBoardPosY_Top = 5;


	CWindowsConsole2DObject GameBoard;
	GameBoard.Initialize(ConstGameBoardSizePerDir, ConstGameBoardSizePerDir);



	char strBuffer[100];



	int32_t NumOfShots_Player = 0;
	int32_t MeanScore_Player = 0;
	int32_t SumOfScore_Player = 0;
	int32_t LastScore_Player = 0;
	int32_t Score_Player = 0;

	int32_t NumOfShots_AI = 0;
	int32_t MeanScore_AI = 0;
	int32_t SumOfScore_AI = 0;
	int32_t LastScore_AI = 0;
	int32_t Score_AI = 0;

	int32_t GameCounter = 0;

	int32_t PlacementStrategyNeuronID = 0;

	int32_t loopcounter = 0;

	bool PlayerGameCompleted = false;
	bool AIGameCompleted = false;

#pragma omp parallel num_threads(2)
	{
		do
		{
			if (KEYDOWN(VK_ESCAPE) == true)
				break;

			int32_t threadID = omp_get_thread_num();

			if (threadID == 1)
			{
				InputHandling.Check_For_Input();
			}
			else if (threadID == 0) // master thread
			{
				//auto last_timepoint = std::chrono::steady_clock::now();
				auto last_timepoint = steady_clock::now();

				if (InputHandling.LeftMouseButtonPressed == true)
				{
					if (leftMouseButtonClick == false)
						leftMouseButtonClick = true;
					else
						leftMouseButtonClick = false;
				}

				if (InputHandling.MiddleMouseButtonPressed == true)
				{
					if (middleMouseButtonClick == false)
						middleMouseButtonClick = true;
					else
						middleMouseButtonClick = false;
				}

				if (InputHandling.RightMouseButtonPressed == true)
				{
					if (rightMouseButtonClick == false)
						rightMouseButtonClick = true;
					else
						rightMouseButtonClick = false;
				}

				InputHandling.Reset_MouseButtons();

				int32_t mousePosX = InputHandling.MousePosX;
				int32_t mousePosY = InputHandling.MousePosY;

				int32_t relativeMousePosX = mousePosX - GameBoardPosX_Left;
				int32_t relativeMousePosY = mousePosY - GameBoardPosY_Top;

				if (PlayerGameCompleted == false && AIGameCompleted == false)
				{
					bool startNewGame = true;

					for (int32_t i = 0; i < ConstNumNavalEntities; i++)
					{
						if (NavalEntityArray[i].Destroyed == false)
						{
							startNewGame = false;
							break;
						}
					}

					if (startNewGame == true)
					{
						PlayerGameCompleted = true;
						Copy_GameBoard(GameBoardData[0], InitialGameBoardData[0]);

						Init_2DimArray(GameBoardData_WaterShots[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);
						Init_2DimArray(GameBoardData_WaterShotsAndHits[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);
						Init_2DimArray(GameBoardData_DestroyedElements[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);
						Init_2DimArray(GameBoardData_DamagedElements[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);

						for (int32_t i = 0; i < ConstNumNavalEntities; i++)
							NavalEntityArray[i].Destroyed = false;

					}
				} // end of if (PlayerGameCompleted == false && AIGameCompleted == false)
				else if (PlayerGameCompleted == true && AIGameCompleted == false)
				{
					bool startNewGame = true;

					for (int32_t i = 0; i < ConstNumNavalEntities; i++)
					{
						if (NavalEntityArray[i].Destroyed == false)
						{
							startNewGame = false;
							break;
						}
					}

					if (startNewGame == true)
					{
						AIGameCompleted = true;
					}
				} // end of else if (PlayerGameCompleted == true && AIGameCompleted == false)

				if (PlayerGameCompleted == true && AIGameCompleted == true)
				{
					PlayerGameCompleted = false;
					AIGameCompleted = false;

					GameCounter++;

					LastScore_Player = ConstGameBoardSize - NumOfShots_Player;
					SumOfScore_Player += LastScore_Player;
					MeanScore_Player = SumOfScore_Player / GameCounter;
					NumOfShots_Player = 0;

					LastScore_AI = ConstGameBoardSize - NumOfShots_AI;
					SumOfScore_AI += LastScore_AI;	
					MeanScore_AI = SumOfScore_AI / GameCounter;
					NumOfShots_AI = 0;

					
					Init_GameBoard_And_Set_RandomEntityPositions(InitialGameBoardData[0], NavalEntityArray, ConstNumNavalEntities, &RandomNumbers);

					//StrategyID = RandomNumbers.Get_IntegerNumber(0, PlacementStrategies.NumStrategies);
					//Init_GameBoard_And_Set_RandomEntityPositions(InitialGameBoardData[0], NavalEntityArray, ConstNumNavalEntities, &RandomNumbers, PlacementStrategies.pStrategyArray[StrategyID].ForbiddenTileIDList, PlacementStrategies.pStrategyArray[StrategyID].NumOfForbiddenTiles);

					Copy_GameBoard(GameBoardData[0], InitialGameBoardData[0]);



					//Add_To_Log(0, "new game");
					//Add_To_Log(0, "correct strategyID", StrategyID);
				}

				// Spieler ist am Spielen:
				if (PlayerGameCompleted == false && AIGameCompleted == false)
				{
					// player shot:
					if (relativeMousePosX > -1 && relativeMousePosX < ConstGameBoardSizePerDir)
					{
						if (relativeMousePosY > -1 && relativeMousePosY < ConstGameBoardSizePerDir)
						{
							if (leftMouseButtonClick == true)
							{
								int32_t tileData = GameBoardData[relativeMousePosY][relativeMousePosX];

								if (tileData == ConstGameBoard_Water)
								{
									NumOfShots_Player++;
									GameBoardData[relativeMousePosY][relativeMousePosX] = ConstGameBoard_WaterShot;
								}
								else if (tileData == ConstGameBoard_IntactElement)
								{
									NumOfShots_Player++;
									GameBoardData[relativeMousePosY][relativeMousePosX] = ConstGameBoard_DamagedElement;
								}
							}
						}
					} // end of if (relativeMousePosX > -1 && relativeMousePosX < ConstGameBoardSizePerDir)

					for (int32_t i = 0; i < ConstNumNavalEntities; i++)
					{
						NavalEntityArray[i].Check_Destruction(GameBoardData[0]);
					}

					Update_GameBoardGraphics_DontShow_IntactParts(&GameBoard, GameBoardData[0]);

				} // end of if (PlayerGameCompleted == false && AIGameCompleted == false)

				// AI ist am Spielen:
				if (PlayerGameCompleted == true && AIGameCompleted == false)
				{
					if (loopcounter == 0)
					{
						
						//for (int32_t i = 0; i < ConstNumNavalEntities; i++)
						//{
						//	NavalEntityArray[i].Copy_Data_If_Destroyed(GameBoardData_DestroyedElements[0], 1.0f);
						//}

						Copy_DestroyedElementData(GameBoardData_DestroyedElements[0], GameBoardData[0], 1.0f);
						Copy_WaterShotData(GameBoardData_WaterShots[0], GameBoardData[0], 1.0f);
						Copy_WaterShotAndHitData(GameBoardData_WaterShotsAndHits[0], GameBoardData[0], -1.0f, 1.0f);
						Copy_WaterShotAndDestroyedElementData(GameBoardData_WaterShotsAndDestroyedElements[0], GameBoardData[0], 1.0f);
						Copy_DamagedElementData(GameBoardData_DamagedElements[0], GameBoardData[0], 1.0f);


						CNeuronV2 *pPlacementStrategyNeuron = nullptr;
						PlacementStrategyNeuronID = -1;


						PlacementStrategies.Get_StrongestActivatedMemoryNeuron(&pPlacementStrategyNeuron, &PlacementStrategyNeuronID, GameBoardData_WaterShotsAndHits[0]);
						//Add_To_Log(0, "strategyID", PlacementStrategyNeuronID);

						// kleinstm�gliche NavalEntity-L�nge: 2
						CNeuronV2 *pPlacementEvaluationNeuron = &L2ShipPlacementEvaluationNeuron;
						int32_t lengthOfBiggestUndestroyedEntity = 2;
						int32_t placementEvaluationHalfLRFSizePerDirMinus1 = 1;

						if (NavalEntityArray[0].Destroyed == false)
						{
							pPlacementEvaluationNeuron = &L5ShipPlacementEvaluationNeuron;
							lengthOfBiggestUndestroyedEntity = 5;
							placementEvaluationHalfLRFSizePerDirMinus1 = L5PlacementEvaluationHalfLRFSizePerDirMinus1;
						}
						else if (NavalEntityArray[1].Destroyed == false)
						{
							pPlacementEvaluationNeuron = &L4ShipPlacementEvaluationNeuron;
							lengthOfBiggestUndestroyedEntity = 4;
							placementEvaluationHalfLRFSizePerDirMinus1 = L4PlacementEvaluationHalfLRFSizePerDirMinus1;
						}
						else if (NavalEntityArray[2].Destroyed == false || NavalEntityArray[3].Destroyed == false)
						{
							pPlacementEvaluationNeuron = &L3ShipPlacementEvaluationNeuron;
							lengthOfBiggestUndestroyedEntity = 3;
							placementEvaluationHalfLRFSizePerDirMinus1 = L3PlacementEvaluationHalfLRFSizePerDirMinus1;
						}
							

						int32_t out = AI_Shot(GameBoardData[0], &NumOfShots_AI,
							&SearchRemainingIntactShipElementsNeuron, GameBoardData_DamagedElements[0],
							&DestroyedEntityNeighborhoodDetectionNeuron, GameBoardData_DestroyedElements[0],
							pPlacementEvaluationNeuron, placementEvaluationHalfLRFSizePerDirMinus1, GameBoardData_WaterShotsAndDestroyedElements[0], &UnnecessaryShotDetectionNeuron, GameBoardData_WaterShots[0], lengthOfBiggestUndestroyedEntity, pPlacementStrategyNeuron->pDendrite_CentroidValueArray,
							&RandomNumbers);

						if (out == 0)
							Add_To_Log(0, "no shot");

						for (int32_t i = 0; i < ConstNumNavalEntities; i++)
						{
							NavalEntityArray[i].Check_Destruction(GameBoardData[0]);
						}
							
					} // end of if (loopcounter == 0)

					loopcounter++;

					if (loopcounter > 10)
						loopcounter = 0;
					

					Update_GameBoardGraphics(&GameBoard, GameBoardData[0]);

				} // end of if (PlayerGameCompleted == true && AIGameCompleted == false)

				
				
				if (relativeMousePosX > -1 && relativeMousePosX < ConstGameBoardSizePerDir)
				{
					if (relativeMousePosY > -1 && relativeMousePosY < ConstGameBoardSizePerDir)
					{
						GameBoard.Set_Pixel(relativeMousePosX, relativeMousePosY, lightaqua);
					}
				}

				leftMouseButtonClick = false;
				rightMouseButtonClick = false;
				middleMouseButtonClick = false;

				WinConsole.Clear_BackBuffer();

				WinConsole.Draw_2DObject_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top, GameBoard.pDataArray, GameBoard.NumCharactersPerRow, GameBoard.NumCharactersPerColumn);

				if (PlayerGameCompleted == false)
				{
					sprintf(strBuffer, "Human Player Ship Search");
					WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, 1, strBuffer, lightaqua, black);
				}
				else
				{
					sprintf(strBuffer, "AI Player Ship Search");
					WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, 1, strBuffer, lightaqua, black);
				}

				Score_Player = ConstGameBoardSize - NumOfShots_Player;
				Score_AI = ConstGameBoardSize - NumOfShots_AI;
				sprintf(strBuffer, "score player/AI: %03d/%03d", Score_Player, Score_AI);
				WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 13, strBuffer, lightaqua, black);

				sprintf(strBuffer, "last player/AI: %03d/%03d", LastScore_Player, LastScore_AI);
				WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 15, strBuffer, lightaqua, black);

				sprintf(strBuffer, "mean player/AI: %03d/%03d", MeanScore_Player, MeanScore_AI);
				WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 17, strBuffer, lightaqua, black);

				//sprintf(strBuffer, "placement strategy: %03d", PlacementStrategyNeuronID);
				//WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 19, strBuffer, lightaqua, black);

				//sprintf(strBuffer, "correct placement strategy: %03d", StrategyID);
				//WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 21, strBuffer, lightaqua, black);

				WinConsole.Present_BackBuffer();

				//Frame-Bremse:

				auto current_timepoint = steady_clock::now();

				//while (current_timepoint - last_timepoint < 250ms)
				//while (current_timepoint - last_timepoint < 50ms)
				while (current_timepoint - last_timepoint < 16ms)
				//while (current_timepoint - last_timepoint < 16666us) // 16.7 Millisekunden (ms)  bzw. 16666 Mikrosekunden (us): maximal 60 Frames pro Sekunde				
				{
					current_timepoint = steady_clock::now();
				}


				FrameTime = 0.000000001f * (current_timepoint - last_timepoint).count();
				FrameRate = 1.0f / FrameTime;
			} // end of else if (threadID == 0) // master thread

		} while (true);
	} // end of #pragma omp parallel num_threads(2)


	WinConsole.Clear_BackBuffer();
	WinConsole.Present_BackBuffer();
	WinConsole.CleanUp();

	Set_CursorVisibilityAndSize(true);
	Reset_CursorPos();
	Set_CursorPos(0, 0);

	cout << "bye bye (Press Return)" << endl;

	//getchar();

	return 0;
}
*/

/*
// Human Player Placememt + AI Search
int main(void)
{
	//Set_ProcessPriority(2);

	//Set_ProcessPriority(2);

	Begin_Log(0, "start AI_Log",
		"AI_Log.txt");

	Set_Title("Battleship");
	Set_ConsolePos(10, 10);

	char inputBuffer[100];
	int32_t RecalculatePlacementStrategies = 0;

	cout << "Recalculate Placement Strategies (0/1): ";

	cin.getline(inputBuffer, 100);
	RecalculatePlacementStrategies = atoi(inputBuffer);

	CInputHandling InputHandling;
	InputHandling.Initialize();

	Clear_Terminal_And_Reset_CursorPos();

	CWindowsConsoleScreenBuffer WinConsole;
	WinConsole.Initialize(40, 30, false, BackgroundColor);

	Set_Title("Battleship");
	Set_ConsolePos(10, 10);

	WinConsole.Set_CursorVisibilityAndSize(FALSE);
	//WinConsole.Set_Font(L"Consolas", 15, 15);
	//WinConsole.Set_Font(L"Consolas", 4, 4);
	//WinConsole.Set_Font(L"Consolas", 8, 8);
	WinConsole.Set_Font_Ext(L"Consolas", 90, 15, 15);


	//WinConsole.Set_BackgroundColor(RGB(100, 50, 25));
	WinConsole.Set_BackgroundColor(BackgroundColor);

	Set_CursorVisibilityAndSize(false);

	CRandomNumbersNN RandomNumbers;
	RandomNumbers.Change_Seed(20);

	static constexpr int32_t ConstNumNavalEntities = 5;
	static constexpr int32_t ConstNumNavalEntityElements = 17;


	static int32_t GameBoardData[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];
	static int32_t InitialGameBoardData[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];

	static float GameBoardData_DestroyedElements[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];
	Init_2DimArray(GameBoardData_DestroyedElements[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);

	static float GameBoardData_WaterShots[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];
	Init_2DimArray(GameBoardData_WaterShots[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);

	static float GameBoardData_WaterShotsAndHits[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];
	Init_2DimArray(GameBoardData_WaterShotsAndHits[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);

	static float GameBoardData_WaterShotsAndDestroyedElements[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];
	Init_2DimArray(GameBoardData_WaterShotsAndDestroyedElements[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);

	static float GameBoardData_DamagedElements[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];
	Init_2DimArray(GameBoardData_DamagedElements[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);

	CNeuronV2 DestroyedEntityNeighborhoodDetectionNeuron;
	DestroyedEntityNeighborhoodDetectionNeuron.NeuronID = 10;
	DestroyedEntityNeighborhoodDetectionNeuron.Init_Dendrite_Arrays(9);
	DestroyedEntityNeighborhoodDetectionNeuron.Set_ActivationFunction(DestroyedEntityNeighborhoodDetection);

	// local receptive field:
	float DestroyedEntityNeighborhoodDetectionLRF[9] = { 1.0f, 1.0f, 1.0f,  1.0f, 0.0f, 1.0f,  1.0f, 1.0f, 1.0f };
	DestroyedEntityNeighborhoodDetectionNeuron.Set_Dendrite_Factors(DestroyedEntityNeighborhoodDetectionLRF);

	CNeuronV2 UnnecessaryShotDetectionNeuron;
	UnnecessaryShotDetectionNeuron.NeuronID = 20;
	UnnecessaryShotDetectionNeuron.Init_Dendrite_Arrays(9);
	UnnecessaryShotDetectionNeuron.Set_ActivationFunction(UnnecessaryShotDetection);

	// local receptive field:
	float UnnecessaryShotDetectionLRF[9] = { 0.0f, 1.0f, 0.0f,  1.0f, 0.0f, 1.0f,  0.0f, 1.0f, 0.0f };
	UnnecessaryShotDetectionNeuron.Set_Dendrite_Factors(UnnecessaryShotDetectionLRF);

	CNeuronV2 L2ShipPlacementEvaluationNeuron;
	L2ShipPlacementEvaluationNeuron.Init_Dendrite_Arrays(9);
	L2ShipPlacementEvaluationNeuron.Set_ActivationFunction(L2ShipPlacementEvaluation);
	int32_t L2PlacementEvaluationHalfLRFSizePerDirMinus1 = 1;

	CNeuronV2 L3ShipPlacementEvaluationNeuron;
	L3ShipPlacementEvaluationNeuron.Init_Dendrite_Arrays(25);
	L3ShipPlacementEvaluationNeuron.Set_ActivationFunction(L3ShipPlacementEvaluation);
	int32_t L3PlacementEvaluationHalfLRFSizePerDirMinus1 = 2;

	CNeuronV2 L4ShipPlacementEvaluationNeuron;	
	L4ShipPlacementEvaluationNeuron.Init_Dendrite_Arrays(49);
	L4ShipPlacementEvaluationNeuron.Set_ActivationFunction(L4ShipPlacementEvaluation);
	int32_t L4PlacementEvaluationHalfLRFSizePerDirMinus1 = 3;

	CNeuronV2 L5ShipPlacementEvaluationNeuron;
	L5ShipPlacementEvaluationNeuron.Init_Dendrite_Arrays(81);
	L5ShipPlacementEvaluationNeuron.Set_ActivationFunction(L5ShipPlacementEvaluation);
	int32_t L5PlacementEvaluationHalfLRFSizePerDirMinus1 = 4;


	CNeuronV2 SearchRemainingIntactShipElementsNeuron;
	SearchRemainingIntactShipElementsNeuron.NeuronID = 60;
	SearchRemainingIntactShipElementsNeuron.Init_Dendrite_Arrays(25);
	SearchRemainingIntactShipElementsNeuron.Set_ActivationFunction(SearchRemainingIntactShipElements);

	// local receptive field:
	float SearchRemainingIntactShipElementsLRF[25] = {
	0.0f, 0.0f, -2.0f, 0.0f, 0.0f,
	0.0f, 0.0f, -1.0f, 0.0f, 0.0f,
	29.0f, 17.0f,  0.0f, 1.0f, 2.0f,
	0.0f, 0.0f, -17.0f, 0.0f, 0.0f,
	0.0f, 0.0f, -29.0f, 0.0f, 0.0f };

	
	SearchRemainingIntactShipElementsNeuron.Set_Dendrite_Factors(SearchRemainingIntactShipElementsLRF);


	static CNavalEntity NavalEntityArray[ConstNumNavalEntities];

	NavalEntityArray[0].Initialize(5);
	NavalEntityArray[1].Initialize(4);
	NavalEntityArray[2].Initialize(3);
	NavalEntityArray[3].Initialize(3);
	NavalEntityArray[4].Initialize(2);

	CPlacementStrategies PlacementStrategies;

	PlacementStrategies.Init_New_Strategies("BattleShipPlacementStrategies.txt", &RandomNumbers);


	if (RecalculatePlacementStrategies != 0)
	{
		PlacementStrategies.Train_MemoryNeurons(GameBoardData[0], NavalEntityArray, ConstNumNavalEntities, ConstNumNavalEntityElements, &RandomNumbers);
		PlacementStrategies.Save_HitProbabilityValues("BattleshipStrategies/Strategy");
	}
	else
	{
		PlacementStrategies.Load_HitProbabilityValues("BattleshipStrategies/Strategy");
	}

	char strBuffer[100];

	bool leftMouseButtonClick = false;
	bool middleMouseButtonClick = false;
	bool rightMouseButtonClick = false;

	float FrameTime = 1.0f;
	float FrameRate = 1.0f;

	int32_t GameBoardPosX_Left = 2;
	int32_t GameBoardPosY_Top = 5;

	CWindowsConsole2DObject GameBoard;
	GameBoard.Initialize(ConstGameBoardSizePerDir, ConstGameBoardSizePerDir);

	static int32_t InitialPaddedGameBoardData[ConstGameBoardSizePerDirWithPadding][ConstGameBoardSizePerDirWithPadding];
	

	Init_PaddedGameBoard(InitialPaddedGameBoardData[0], 0);
	Init_GameBoard(InitialGameBoardData[0], 0);

	int32_t NumOfShots = 0;
	int32_t MeanScore = 0;
	int32_t SumOfScore = 0;
	int32_t GameCounter = 0;
	int32_t LastScore = 0;
	int32_t Score = 0;

	int32_t PlacementStrategyNeuronID;

	int32_t loopcounter = 0;

	int32_t navalEntityID = 0;

	bool shipPlacementRunning = true;
	bool prepareNewGame = true;

#pragma omp parallel num_threads(2)
	{
		do
		{
			if (KEYDOWN(VK_ESCAPE) == true)
				break;

			if (KEYDOWN(VK_F1) == true && prepareNewGame == false)
			{
				prepareNewGame = true;
			}

			int32_t threadID = omp_get_thread_num();

			if (threadID == 1)
			{
				InputHandling.Check_For_Input();
			}
			else if (threadID == 0) // master thread
			{
				if (prepareNewGame == true)
				{
					prepareNewGame = false;
					shipPlacementRunning = true;
					Init_PaddedGameBoard(InitialPaddedGameBoardData[0], 0);
					Init_GameBoard(InitialGameBoardData[0], 0);
					navalEntityID = 0;
					loopcounter = 0;

					if (NumOfShots > 0)
					{
						LastScore = ConstGameBoardSize - NumOfShots;
						SumOfScore += LastScore;
						GameCounter++;
						MeanScore = SumOfScore / GameCounter;
						NumOfShots = 0;
					}
				}

				//auto last_timepoint = std::chrono::steady_clock::now();
				auto last_timepoint = steady_clock::now();
				
				if (InputHandling.LeftMouseButtonPressed == true)
				{
					if (leftMouseButtonClick == false)
						leftMouseButtonClick = true;
					else
						leftMouseButtonClick = false;
				}

				if (InputHandling.MiddleMouseButtonPressed == true)
				{
					if (middleMouseButtonClick == false)
						middleMouseButtonClick = true;
					else
						middleMouseButtonClick = false;
				}

				if (InputHandling.RightMouseButtonPressed == true)
				{
					if (rightMouseButtonClick == false)
						rightMouseButtonClick = true;
					else
						rightMouseButtonClick = false;
				}

				InputHandling.Reset_MouseButtons();

				int32_t mousePosX = InputHandling.MousePosX;
				int32_t mousePosY = InputHandling.MousePosY;

				int32_t relativeMousePosX = mousePosX - GameBoardPosX_Left;
				int32_t relativeMousePosY = mousePosY - GameBoardPosY_Top;

				int32_t paddedRelativeMousePosX = mousePosX - GameBoardPosX_Left + 1;
				int32_t paddedRelativeMousePosY = mousePosY - GameBoardPosY_Top + 1;

				if (shipPlacementRunning == true)
				{	
					Init_2DimArray(GameBoardData_WaterShots[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);
					Init_2DimArray(GameBoardData_WaterShotsAndHits[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);
					Init_2DimArray(GameBoardData_DestroyedElements[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);
					Init_2DimArray(GameBoardData_DamagedElements[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);

					

					Update_GameBoardGraphics2(&GameBoard, InitialPaddedGameBoardData[0]);

					if (relativeMousePosX > -1 && relativeMousePosX < ConstGameBoardSizePerDir)
					{
						if (relativeMousePosY > -1 && relativeMousePosY < ConstGameBoardSizePerDir)
						{
							GameBoard.Set_Pixel(relativeMousePosX, relativeMousePosY, lightaqua);

							if (middleMouseButtonClick == true)
							{
								Init_PaddedGameBoard(InitialPaddedGameBoardData[0], 0);
								Init_GameBoard(InitialGameBoardData[0], 0);
								navalEntityID = 0;
								goto EndOfPlacement;
							}

							if (navalEntityID < 5)
							{
								bool placementSuccess = false;

								if (navalEntityID == 0)
								{
									if (leftMouseButtonClick == true)
									{
										placementSuccess = Add_NavalEntityL5_HorizontalPlacement(paddedRelativeMousePosX - 1, paddedRelativeMousePosY - 1, InitialPaddedGameBoardData[0]);

										if (placementSuccess == true)
										{
											NavalEntityArray[navalEntityID].Set_HorizontalPlacementPosition(relativeMousePosX, relativeMousePosY);
											//NavalEntityArray[navalEntityID].Copy_To_GameBoard(InitialGameBoardData[0]);		
										}
									}
									else if (rightMouseButtonClick == true)
									{
										placementSuccess = Add_NavalEntityL5_VerticalPlacement(paddedRelativeMousePosX - 1, paddedRelativeMousePosY - 1, InitialPaddedGameBoardData[0]);

										if (placementSuccess == true)
										{
											NavalEntityArray[navalEntityID].Set_VerticalPlacementPosition(relativeMousePosX, relativeMousePosY);
											//NavalEntityArray[navalEntityID].Copy_To_GameBoard(InitialGameBoardData[0]);
										}
									}
								}
								else if (navalEntityID == 1)
								{
									if (leftMouseButtonClick == true)
									{
										placementSuccess = Add_NavalEntityL4_HorizontalPlacement(paddedRelativeMousePosX - 1, paddedRelativeMousePosY - 1, InitialPaddedGameBoardData[0]);

										if (placementSuccess == true)
										{
											NavalEntityArray[navalEntityID].Set_HorizontalPlacementPosition(relativeMousePosX, relativeMousePosY);
											//NavalEntityArray[navalEntityID].Copy_To_GameBoard(InitialGameBoardData[0]);
										}
									}
									else if (rightMouseButtonClick == true)
									{
										placementSuccess = Add_NavalEntityL4_VerticalPlacement(paddedRelativeMousePosX - 1, paddedRelativeMousePosY - 1, InitialPaddedGameBoardData[0]);

										if (placementSuccess == true)
										{
											NavalEntityArray[navalEntityID].Set_VerticalPlacementPosition(relativeMousePosX, relativeMousePosY);
											//NavalEntityArray[navalEntityID].Copy_To_GameBoard(InitialGameBoardData[0]);
										}
									}
								}
								else if (navalEntityID == 2 || navalEntityID == 3)
								{
									if (leftMouseButtonClick == true)
									{
										placementSuccess = Add_NavalEntityL3_HorizontalPlacement(paddedRelativeMousePosX - 1, paddedRelativeMousePosY - 1, InitialPaddedGameBoardData[0]);

										if (placementSuccess == true)
										{
											NavalEntityArray[navalEntityID].Set_HorizontalPlacementPosition(relativeMousePosX, relativeMousePosY);
											//NavalEntityArray[navalEntityID].Copy_To_GameBoard(InitialGameBoardData[0]);
										}
									}
									else if (rightMouseButtonClick == true)
									{
										placementSuccess = Add_NavalEntityL3_VerticalPlacement(paddedRelativeMousePosX - 1, paddedRelativeMousePosY - 1, InitialPaddedGameBoardData[0]);

										if (placementSuccess == true)
										{
											NavalEntityArray[navalEntityID].Set_VerticalPlacementPosition(relativeMousePosX, relativeMousePosY);
											//NavalEntityArray[navalEntityID].Copy_To_GameBoard(InitialGameBoardData[0]);
										}
									}
								}
								else if (navalEntityID == 4)
								{
									if (leftMouseButtonClick == true)
									{
										placementSuccess = Add_NavalEntityL2_HorizontalPlacement(paddedRelativeMousePosX - 1, paddedRelativeMousePosY - 1, InitialPaddedGameBoardData[0]);

										if (placementSuccess == true)
										{
											NavalEntityArray[navalEntityID].Set_HorizontalPlacementPosition(relativeMousePosX, relativeMousePosY);
											//NavalEntityArray[navalEntityID].Copy_To_GameBoard(InitialGameBoardData[0]);
										}
									}
									else if (rightMouseButtonClick == true)
									{
										placementSuccess = Add_NavalEntityL2_VerticalPlacement(paddedRelativeMousePosX - 1, paddedRelativeMousePosY - 1, InitialPaddedGameBoardData[0]);

										if (placementSuccess == true)
										{
											NavalEntityArray[navalEntityID].Set_VerticalPlacementPosition(relativeMousePosX, relativeMousePosY);
											//NavalEntityArray[navalEntityID].Copy_To_GameBoard(InitialGameBoardData[0]);
										}
									}
								}

								if (placementSuccess == true)
								{
									Copy_PaddedGameBoardData(InitialGameBoardData[0], InitialPaddedGameBoardData[0]);
									navalEntityID++;
								}
							} // end of if (navalEntityID < 4)

						EndOfPlacement:;


						} // end of if (relativeMousePosY > -1 && relativeMousePosY < ConstGameBoardSizePerDir)
					} // end of if (relativeMousePosX > -1 && relativeMousePosX < ConstGameBoardSizePerDir)

					if (navalEntityID == 5) // alle Schiffe plaziert
					{
						shipPlacementRunning = false;
						Copy_GameBoard(GameBoardData[0], InitialGameBoardData[0]);
					}
				} // end of if(startNewGame == true)


				leftMouseButtonClick = false;
				rightMouseButtonClick = false;
				middleMouseButtonClick = false;

				WinConsole.Clear_BackBuffer();

				if (shipPlacementRunning == true)
				{
					WinConsole.Draw_2DObject_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top, GameBoard.pDataArray, GameBoard.NumCharactersPerRow, GameBoard.NumCharactersPerColumn);

					sprintf(strBuffer, "Ship Placement (Human Player)");
					WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, 1, strBuffer, lightaqua, black);

					sprintf(strBuffer, "left mButton: hor. ship");
					WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 13, strBuffer, lightaqua, black);
					sprintf(strBuffer, "right mButton: vert. ship");
					WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 15, strBuffer, lightaqua, black);
					sprintf(strBuffer, "middle mButton: clear");
					WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 17, strBuffer, lightaqua, black);
				}
				else if (shipPlacementRunning == false)
				{
					//sprintf(strBuffer, "game running");
					//WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 13, strBuffer, lightaqua, black);

					prepareNewGame = true;

					for (int32_t i = 0; i < ConstNumNavalEntities; i++)
					{
						if (NavalEntityArray[i].Destroyed == false)
						{
							prepareNewGame = false;
							break;
						}
					}

					if (loopcounter == 0)
					{
						
						//for (int32_t i = 0; i < ConstNumNavalEntities; i++)
						//{
						//	NavalEntityArray[i].Copy_Data_If_Destroyed(GameBoardData_DestroyedElements[0], 1.0f);
						//}

						Copy_DestroyedElementData(GameBoardData_DestroyedElements[0], GameBoardData[0], 1.0f);
						Copy_WaterShotData(GameBoardData_WaterShots[0], GameBoardData[0], 1.0f);
						Copy_WaterShotAndHitData(GameBoardData_WaterShotsAndHits[0], GameBoardData[0], -1.0f, 1.0f);
						Copy_WaterShotAndDestroyedElementData(GameBoardData_WaterShotsAndDestroyedElements[0], GameBoardData[0], 1.0f);
						Copy_DamagedElementData(GameBoardData_DamagedElements[0], GameBoardData[0], 1.0f);

						CNeuronV2 *pPlacementStrategyNeuron = nullptr;
						PlacementStrategyNeuronID = -1;

						PlacementStrategies.Get_StrongestActivatedMemoryNeuron(&pPlacementStrategyNeuron, &PlacementStrategyNeuronID, GameBoardData_WaterShotsAndHits[0]);
						//Add_To_Log(0, "strategyID", PlacementStrategyNeuronID);


						// kleinstm�gliche NavalEntity-L�nge: 2
						CNeuronV2 *pPlacementEvaluationNeuron = &L2ShipPlacementEvaluationNeuron;				
						int32_t lengthOfBiggestUndestroyedEntity = 2;
						int32_t placementEvaluationHalfLRFSizePerDirMinus1 = 1;

						if (NavalEntityArray[0].Destroyed == false)
						{
							pPlacementEvaluationNeuron = &L5ShipPlacementEvaluationNeuron;
							lengthOfBiggestUndestroyedEntity = 5;
							placementEvaluationHalfLRFSizePerDirMinus1 = L5PlacementEvaluationHalfLRFSizePerDirMinus1;
						}
						else if (NavalEntityArray[1].Destroyed == false)
						{
							pPlacementEvaluationNeuron = &L4ShipPlacementEvaluationNeuron;
							lengthOfBiggestUndestroyedEntity = 4;
							placementEvaluationHalfLRFSizePerDirMinus1 = L4PlacementEvaluationHalfLRFSizePerDirMinus1;
						}
						else if (NavalEntityArray[2].Destroyed == false || NavalEntityArray[3].Destroyed == false)
						{
							pPlacementEvaluationNeuron = &L3ShipPlacementEvaluationNeuron;
							lengthOfBiggestUndestroyedEntity = 3;
							placementEvaluationHalfLRFSizePerDirMinus1 = L3PlacementEvaluationHalfLRFSizePerDirMinus1;
						}

							
						int32_t out = AI_Shot(GameBoardData[0], &NumOfShots,
								&SearchRemainingIntactShipElementsNeuron, GameBoardData_DamagedElements[0],
								&DestroyedEntityNeighborhoodDetectionNeuron, GameBoardData_DestroyedElements[0],
								pPlacementEvaluationNeuron, placementEvaluationHalfLRFSizePerDirMinus1, GameBoardData_WaterShotsAndDestroyedElements[0], &UnnecessaryShotDetectionNeuron, GameBoardData_WaterShots[0], lengthOfBiggestUndestroyedEntity, pPlacementStrategyNeuron->pDendrite_CentroidValueArray,
								&RandomNumbers);

						if (out == 0)
							Add_To_Log(0, "no shot");

						for (int32_t i = 0; i < ConstNumNavalEntities; i++)
						{
							NavalEntityArray[i].Check_Destruction(GameBoardData[0]);
						}

					} // end of if (loopcounter == 0)

					loopcounter++;

					if (loopcounter > 20)
						loopcounter = 0;

					Update_GameBoardGraphics(&GameBoard, GameBoardData[0]);


					WinConsole.Clear_BackBuffer();

					WinConsole.Draw_2DObject_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top, GameBoard.pDataArray, GameBoard.NumCharactersPerRow, GameBoard.NumCharactersPerColumn);


					sprintf(strBuffer, "AI Player Ship Search");
					WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, 1, strBuffer, lightaqua, black);

					Score = ConstGameBoardSize - NumOfShots;
					sprintf(strBuffer, "score: %03d", Score);
					WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 13, strBuffer, lightaqua, black);

					sprintf(strBuffer, "last: %03d", LastScore);
					WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 15, strBuffer, lightaqua, black);

					sprintf(strBuffer, "mean: %03d", MeanScore);
					WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 17, strBuffer, lightaqua, black);

					sprintf(strBuffer, "placement strategy: %03d", PlacementStrategyNeuronID);
					WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 19, strBuffer, lightaqua, black);

				} // end of else if (startNewGame == false)

				WinConsole.Present_BackBuffer();

				//Frame-Bremse:

				auto current_timepoint = steady_clock::now();

				//while (current_timepoint - last_timepoint < 250ms)
				//while (current_timepoint - last_timepoint < 50ms)
				while (current_timepoint - last_timepoint < 16ms)
					//while (current_timepoint - last_timepoint < 16666us) // 16.7 Millisekunden (ms)  bzw. 16666 Mikrosekunden (us): maximal 60 Frames pro Sekunde					
				{
					current_timepoint = steady_clock::now();
				}

				FrameTime = 0.000000001f * (current_timepoint - last_timepoint).count();
				FrameRate = 1.0f / FrameTime;
			} // end of else if (threadID == 0) // master thread

		} while (true);
	} // end of #pragma omp parallel num_threads(2)

	InputHandling.CleanUp();
	WinConsole.Clear_BackBuffer();
	WinConsole.Present_BackBuffer();
	WinConsole.CleanUp();

	Set_CursorVisibilityAndSize(true);
	Reset_CursorPos();
	Set_CursorPos(0, 0);

	cout << "bye bye (Press Return)" << endl;

	//getchar();

	return 0;
}
*/

/*
// AI Player vs. Human Player
int main(void)
{
	//Set_ProcessPriority(2);

	//Set_ProcessPriority(2);

	Begin_Log(0, "start AI_Log",
		"AI_Log.txt");

	Set_Title("Battleship");
	Set_ConsolePos(10, 10);

	char inputBuffer[100];
	int32_t RecalculatePlacementStrategies = 0;

	cout << "Recalculate Placement Strategies (0/1): ";

	cin.getline(inputBuffer, 100);
	RecalculatePlacementStrategies = atoi(inputBuffer);

	int32_t RandomSeed = 1;

	cout << "RandomSeed (> 0): ";

	cin.getline(inputBuffer, 100);
	RandomSeed = atoi(inputBuffer);
	RandomSeed = max(1, RandomSeed);

	CInputHandling InputHandling;
	InputHandling.Initialize();

	Clear_Terminal_And_Reset_CursorPos();

	CWindowsConsoleScreenBuffer WinConsole;
	WinConsole.Initialize(40, 30, false, BackgroundColor);

	Set_Title("Battleship");
	Set_ConsolePos(10, 10);

	WinConsole.Set_CursorVisibilityAndSize(FALSE);
	//WinConsole.Set_Font(L"Consolas", 15, 15);
	//WinConsole.Set_Font(L"Consolas", 4, 4);
	//WinConsole.Set_Font(L"Consolas", 8, 8);
	WinConsole.Set_Font_Ext(L"Consolas", 90, 15, 15);


	//WinConsole.Set_BackgroundColor(RGB(100, 50, 25));
	WinConsole.Set_BackgroundColor(BackgroundColor);

	Set_CursorVisibilityAndSize(false);

	CRandomNumbersNN RandomNumbers;
	RandomNumbers.Change_Seed(RandomSeed);

	static constexpr int32_t ConstNumNavalEntities = 5;
	static constexpr int32_t ConstNumNavalEntityElements = 17;


	static int32_t GameBoardData[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];
	static int32_t InitialGameBoardData[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];

	static float GameBoardData_DestroyedElements[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];
	Init_2DimArray(GameBoardData_DestroyedElements[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);

	static float GameBoardData_WaterShots[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];
	Init_2DimArray(GameBoardData_WaterShots[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);

	static float GameBoardData_WaterShotsAndHits[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];
	Init_2DimArray(GameBoardData_WaterShotsAndHits[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);

	static float GameBoardData_WaterShotsAndDestroyedElements[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];
	Init_2DimArray(GameBoardData_WaterShotsAndDestroyedElements[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);

	static float GameBoardData_DamagedElements[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];
	Init_2DimArray(GameBoardData_DamagedElements[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);

	CNeuronV2 DestroyedEntityNeighborhoodDetectionNeuron;
	DestroyedEntityNeighborhoodDetectionNeuron.NeuronID = 10;
	DestroyedEntityNeighborhoodDetectionNeuron.Init_Dendrite_Arrays(9);
	DestroyedEntityNeighborhoodDetectionNeuron.Set_ActivationFunction(DestroyedEntityNeighborhoodDetection);

	// local receptive field:
	float DestroyedEntityNeighborhoodDetectionLRF[9] = { 1.0f, 1.0f, 1.0f,  1.0f, 0.0f, 1.0f,  1.0f, 1.0f, 1.0f };
	DestroyedEntityNeighborhoodDetectionNeuron.Set_Dendrite_Factors(DestroyedEntityNeighborhoodDetectionLRF);

	CNeuronV2 UnnecessaryShotDetectionNeuron;
	UnnecessaryShotDetectionNeuron.NeuronID = 20;
	UnnecessaryShotDetectionNeuron.Init_Dendrite_Arrays(9);
	UnnecessaryShotDetectionNeuron.Set_ActivationFunction(UnnecessaryShotDetection);

	// local receptive field:
	float UnnecessaryShotDetectionLRF[9] = { 0.0f, 1.0f, 0.0f,  1.0f, 0.0f, 1.0f,  0.0f, 1.0f, 0.0f };
	UnnecessaryShotDetectionNeuron.Set_Dendrite_Factors(UnnecessaryShotDetectionLRF);

	CNeuronV2 L2ShipPlacementEvaluationNeuron;
	L2ShipPlacementEvaluationNeuron.Init_Dendrite_Arrays(9);
	L2ShipPlacementEvaluationNeuron.Set_ActivationFunction(L2ShipPlacementEvaluation);
	int32_t L2PlacementEvaluationHalfLRFSizePerDirMinus1 = 1;

	CNeuronV2 L3ShipPlacementEvaluationNeuron;
	L3ShipPlacementEvaluationNeuron.Init_Dendrite_Arrays(25);
	L3ShipPlacementEvaluationNeuron.Set_ActivationFunction(L3ShipPlacementEvaluation);
	int32_t L3PlacementEvaluationHalfLRFSizePerDirMinus1 = 2;

	CNeuronV2 L4ShipPlacementEvaluationNeuron;
	L4ShipPlacementEvaluationNeuron.Init_Dendrite_Arrays(49);
	L4ShipPlacementEvaluationNeuron.Set_ActivationFunction(L4ShipPlacementEvaluation);
	int32_t L4PlacementEvaluationHalfLRFSizePerDirMinus1 = 3;

	CNeuronV2 L5ShipPlacementEvaluationNeuron;
	L5ShipPlacementEvaluationNeuron.Init_Dendrite_Arrays(81);
	L5ShipPlacementEvaluationNeuron.Set_ActivationFunction(L5ShipPlacementEvaluation);
	int32_t L5PlacementEvaluationHalfLRFSizePerDirMinus1 = 4;


	CNeuronV2 SearchRemainingIntactShipElementsNeuron;
	SearchRemainingIntactShipElementsNeuron.NeuronID = 60;
	SearchRemainingIntactShipElementsNeuron.Init_Dendrite_Arrays(25);
	SearchRemainingIntactShipElementsNeuron.Set_ActivationFunction(SearchRemainingIntactShipElements);

	// local receptive field:
	float SearchRemainingIntactShipElementsLRF[25] = {
	0.0f, 0.0f, -2.0f, 0.0f, 0.0f,
	0.0f, 0.0f, -1.0f, 0.0f, 0.0f,
	29.0f, 17.0f,  0.0f, 1.0f, 2.0f,
	0.0f, 0.0f, -17.0f, 0.0f, 0.0f,
	0.0f, 0.0f, -29.0f, 0.0f, 0.0f };

	SearchRemainingIntactShipElementsNeuron.Set_Dendrite_Factors(SearchRemainingIntactShipElementsLRF);


	static CNavalEntity NavalEntityArray[ConstNumNavalEntities];

	NavalEntityArray[0].Initialize(5);
	NavalEntityArray[1].Initialize(4);
	NavalEntityArray[2].Initialize(3);
	NavalEntityArray[3].Initialize(3);
	NavalEntityArray[4].Initialize(2);

	CPlacementStrategies PlacementStrategies;

	PlacementStrategies.Init_New_Strategies("BattleShipPlacementStrategies.txt", &RandomNumbers);


	if (RecalculatePlacementStrategies != 0)
	{
		PlacementStrategies.Train_MemoryNeurons(GameBoardData[0], NavalEntityArray, ConstNumNavalEntities, ConstNumNavalEntityElements, &RandomNumbers);
		PlacementStrategies.Save_HitProbabilityValues("BattleshipStrategies/Strategy");
	}
	else
	{
		PlacementStrategies.Load_HitProbabilityValues("BattleshipStrategies/Strategy");
	}

	char strBuffer[100];

	bool leftMouseButtonClick = false;
	bool middleMouseButtonClick = false;
	bool rightMouseButtonClick = false;

	float FrameTime = 1.0f;
	float FrameRate = 1.0f;

	int32_t GameBoardPosX_Left = 2;
	int32_t GameBoardPosY_Top = 5;

	CWindowsConsole2DObject GameBoard;
	GameBoard.Initialize(ConstGameBoardSizePerDir, ConstGameBoardSizePerDir);

	static int32_t InitialPaddedGameBoardData[ConstGameBoardSizePerDirWithPadding][ConstGameBoardSizePerDirWithPadding];


	Init_PaddedGameBoard(InitialPaddedGameBoardData[0], 0);
	Init_GameBoard(InitialGameBoardData[0], 0);

	
	int32_t MeanScore_Human = 0;
	int32_t SumOfScore_Human = 0;
	int32_t GameCounter_Human = 0;
	int32_t LastScore_Human = 0;
	int32_t Score_Human = 0;
	int32_t NumOfShots_Human = 0;

	int32_t MeanScore_AI = 0;
	int32_t SumOfScore_AI = 0;
	int32_t GameCounter_AI = 0;
	int32_t LastScore_AI = 0;
	int32_t Score_AI = 0;
	int32_t NumOfShots_AI = 0;

	
	int32_t PlacementStrategyNeuronID;

	int32_t loopcounter = 0;

	int32_t navalEntityID = 0;

	
	bool shipPlacementRunning = true;
	bool prepareNewGame = true;

	// Human Player Placememt + AI Search
	int32_t PlayerID = 0; 

#pragma omp parallel num_threads(2)
	{
		do
		{
			if (KEYDOWN(VK_ESCAPE) == true)
				break;

			

			int32_t threadID = omp_get_thread_num();

			if (threadID == 1)
			{
				InputHandling.Check_For_Input();
			}
			// AI Placememt + Human Player Search
			else if (threadID == 0 && PlayerID == 1) // master thread
			{
				//auto last_timepoint = std::chrono::steady_clock::now();
				auto last_timepoint = steady_clock::now();

				if (InputHandling.LeftMouseButtonPressed == true)
				{
					if (leftMouseButtonClick == false)
						leftMouseButtonClick = true;
					else
						leftMouseButtonClick = false;
				}

				if (InputHandling.MiddleMouseButtonPressed == true)
				{
					if (middleMouseButtonClick == false)
						middleMouseButtonClick = true;
					else
						middleMouseButtonClick = false;
				}

				if (InputHandling.RightMouseButtonPressed == true)
				{
					if (rightMouseButtonClick == false)
						rightMouseButtonClick = true;
					else
						rightMouseButtonClick = false;
				}

				InputHandling.Reset_MouseButtons();

				int32_t mousePosX = InputHandling.MousePosX;
				int32_t mousePosY = InputHandling.MousePosY;

				int32_t relativeMousePosX = mousePosX - GameBoardPosX_Left;
				int32_t relativeMousePosY = mousePosY - GameBoardPosY_Top;

				

				if (prepareNewGame == true)
				{
					prepareNewGame = false;

					Init_GameBoard_And_Set_RandomEntityPositions(InitialGameBoardData[0], NavalEntityArray, ConstNumNavalEntities, &RandomNumbers);

					//int32_t StrategyID = RandomNumbers.Get_IntegerNumber(0, PlacementStrategies.NumStrategies);
					//Init_GameBoard_And_Set_RandomEntityPositions(InitialGameBoardData[0], NavalEntityArray, ConstNumNavalEntities, &RandomNumbers, PlacementStrategies.pStrategyArray[StrategyID].ForbiddenTileIDList, PlacementStrategies.pStrategyArray[StrategyID].NumOfForbiddenTiles);

					Copy_GameBoard(GameBoardData[0], InitialGameBoardData[0]);
				}

				if (prepareNewGame == false)
				{
					bool startNewGame = true;

					for (int32_t i = 0; i < ConstNumNavalEntities; i++)
					{
						if (NavalEntityArray[i].Destroyed == false)
						{
							startNewGame = false;
							break;
						}
					}

					if (startNewGame == true)
					{
						PlayerID = 0; // nun ist der andere Spieler an der Reihe

						if (NumOfShots_Human > 0)
						{
							LastScore_Human = ConstGameBoardSize - NumOfShots_Human;
							SumOfScore_Human += LastScore_Human;
							GameCounter_Human++;
							MeanScore_Human = SumOfScore_Human / GameCounter_Human;
							NumOfShots_Human = 0;
						}

						prepareNewGame = true;
						continue;
					}
				}


				// player shot:
				if (relativeMousePosX > -1 && relativeMousePosX < ConstGameBoardSizePerDir)
				{
					if (relativeMousePosY > -1 && relativeMousePosY < ConstGameBoardSizePerDir)
					{
						if (leftMouseButtonClick == true)
						{
							int32_t tileData = GameBoardData[relativeMousePosY][relativeMousePosX];

							if (tileData == ConstGameBoard_Water)
							{
								NumOfShots_Human++;
								GameBoardData[relativeMousePosY][relativeMousePosX] = ConstGameBoard_WaterShot;
							}
							else if (tileData == ConstGameBoard_IntactElement)
							{
								NumOfShots_Human++;
								GameBoardData[relativeMousePosY][relativeMousePosX] = ConstGameBoard_DamagedElement;
							}
						}
					}
				} // end of if (relativeMousePosX > -1 && relativeMousePosX < ConstGameBoardSizePerDir)



				for (int32_t i = 0; i < ConstNumNavalEntities; i++)
				{
					NavalEntityArray[i].Check_Destruction(GameBoardData[0]);
				}


				//Update_GameBoardGraphics(&GameBoard, GameBoardData[0]);
				Update_GameBoardGraphics_DontShow_IntactParts(&GameBoard, GameBoardData[0]);

				if (relativeMousePosX > -1 && relativeMousePosX < ConstGameBoardSizePerDir)
				{
					if (relativeMousePosY > -1 && relativeMousePosY < ConstGameBoardSizePerDir)
					{
						GameBoard.Set_Pixel(relativeMousePosX, relativeMousePosY, lightaqua);
					}
				}

				leftMouseButtonClick = false;
				rightMouseButtonClick = false;
				middleMouseButtonClick = false;

				WinConsole.Clear_BackBuffer();

				WinConsole.Draw_2DObject_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top, GameBoard.pDataArray, GameBoard.NumCharactersPerRow, GameBoard.NumCharactersPerColumn);

				sprintf(strBuffer, "Human Player Ship Search");
				WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, 1, strBuffer, lightaqua, black);

				Score_Human = ConstGameBoardSize - NumOfShots_Human;
				sprintf(strBuffer, "score: %03d", Score_Human);
				WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 13, strBuffer, lightaqua, black);

				sprintf(strBuffer, "last (Human / AI): %03d / %03d", LastScore_Human, LastScore_AI);
				WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 15, strBuffer, lightaqua, black);

				sprintf(strBuffer, "mean (Human / AI): %03d / %03d", MeanScore_Human, MeanScore_AI);
				WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 17, strBuffer, lightaqua, black);

				WinConsole.Present_BackBuffer();

				//Frame-Bremse:

				auto current_timepoint = steady_clock::now();

				//while (current_timepoint - last_timepoint < 250ms)
				//while (current_timepoint - last_timepoint < 50ms)
				while (current_timepoint - last_timepoint < 16ms)
				//while (current_timepoint - last_timepoint < 16666us) // 16.7 Millisekunden (ms)  bzw. 16666 Mikrosekunden (us): maximal 60 Frames pro Sekunde					
				{
					current_timepoint = steady_clock::now();
				}


				FrameTime = 0.000000001f * (current_timepoint - last_timepoint).count();
				FrameRate = 1.0f / FrameTime;
			} // end of else if (threadID == 0 && PlayerID == 1) // master thread
			// Human Player Placememt + AI Search
			else if (threadID == 0 && PlayerID == 0) // master thread
			{
				if (prepareNewGame == true)
				{
					prepareNewGame = false;
					shipPlacementRunning = true;
					Init_PaddedGameBoard(InitialPaddedGameBoardData[0], 0);
					Init_GameBoard(InitialGameBoardData[0], 0);
					navalEntityID = 0;
					loopcounter = 0;

					Init_2DimArray(GameBoardData_WaterShots[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);
					Init_2DimArray(GameBoardData_WaterShotsAndHits[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);
					Init_2DimArray(GameBoardData_DestroyedElements[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);
					Init_2DimArray(GameBoardData_DamagedElements[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);				
				}

				//auto last_timepoint = std::chrono::steady_clock::now();
				auto last_timepoint = steady_clock::now();

				if (InputHandling.LeftMouseButtonPressed == true)
				{
					if (leftMouseButtonClick == false)
						leftMouseButtonClick = true;
					else
						leftMouseButtonClick = false;
				}

				if (InputHandling.MiddleMouseButtonPressed == true)
				{
					if (middleMouseButtonClick == false)
						middleMouseButtonClick = true;
					else
						middleMouseButtonClick = false;
				}

				if (InputHandling.RightMouseButtonPressed == true)
				{
					if (rightMouseButtonClick == false)
						rightMouseButtonClick = true;
					else
						rightMouseButtonClick = false;
				}

				InputHandling.Reset_MouseButtons();

				int32_t mousePosX = InputHandling.MousePosX;
				int32_t mousePosY = InputHandling.MousePosY;

				int32_t relativeMousePosX = mousePosX - GameBoardPosX_Left;
				int32_t relativeMousePosY = mousePosY - GameBoardPosY_Top;

				int32_t paddedRelativeMousePosX = mousePosX - GameBoardPosX_Left + 1;
				int32_t paddedRelativeMousePosY = mousePosY - GameBoardPosY_Top + 1;

				if (shipPlacementRunning == true)
				{
					Update_GameBoardGraphics2(&GameBoard, InitialPaddedGameBoardData[0]);

					if (relativeMousePosX > -1 && relativeMousePosX < ConstGameBoardSizePerDir)
					{
						if (relativeMousePosY > -1 && relativeMousePosY < ConstGameBoardSizePerDir)
						{
							GameBoard.Set_Pixel(relativeMousePosX, relativeMousePosY, lightaqua);

							if (middleMouseButtonClick == true)
							{
								Init_PaddedGameBoard(InitialPaddedGameBoardData[0], 0);
								Init_GameBoard(InitialGameBoardData[0], 0);
								navalEntityID = 0;
								goto EndOfPlacement;
							}

							if (navalEntityID < 5)
							{
								bool placementSuccess = false;

								if (navalEntityID == 0)
								{
									if (leftMouseButtonClick == true)
									{
										placementSuccess = Add_NavalEntityL5_HorizontalPlacement(paddedRelativeMousePosX - 1, paddedRelativeMousePosY - 1, InitialPaddedGameBoardData[0]);

										if (placementSuccess == true)
										{
											NavalEntityArray[navalEntityID].Set_HorizontalPlacementPosition(relativeMousePosX, relativeMousePosY);
											//NavalEntityArray[navalEntityID].Copy_To_GameBoard(InitialGameBoardData[0]);		
										}
									}
									else if (rightMouseButtonClick == true)
									{
										placementSuccess = Add_NavalEntityL5_VerticalPlacement(paddedRelativeMousePosX - 1, paddedRelativeMousePosY - 1, InitialPaddedGameBoardData[0]);

										if (placementSuccess == true)
										{
											NavalEntityArray[navalEntityID].Set_VerticalPlacementPosition(relativeMousePosX, relativeMousePosY);
											//NavalEntityArray[navalEntityID].Copy_To_GameBoard(InitialGameBoardData[0]);
										}
									}
								}
								else if (navalEntityID == 1)
								{
									if (leftMouseButtonClick == true)
									{
										placementSuccess = Add_NavalEntityL4_HorizontalPlacement(paddedRelativeMousePosX - 1, paddedRelativeMousePosY - 1, InitialPaddedGameBoardData[0]);

										if (placementSuccess == true)
										{
											NavalEntityArray[navalEntityID].Set_HorizontalPlacementPosition(relativeMousePosX, relativeMousePosY);
											//NavalEntityArray[navalEntityID].Copy_To_GameBoard(InitialGameBoardData[0]);
										}
									}
									else if (rightMouseButtonClick == true)
									{
										placementSuccess = Add_NavalEntityL4_VerticalPlacement(paddedRelativeMousePosX - 1, paddedRelativeMousePosY - 1, InitialPaddedGameBoardData[0]);

										if (placementSuccess == true)
										{
											NavalEntityArray[navalEntityID].Set_VerticalPlacementPosition(relativeMousePosX, relativeMousePosY);
											//NavalEntityArray[navalEntityID].Copy_To_GameBoard(InitialGameBoardData[0]);
										}
									}
								}
								else if (navalEntityID == 2 || navalEntityID == 3)
								{
									if (leftMouseButtonClick == true)
									{
										placementSuccess = Add_NavalEntityL3_HorizontalPlacement(paddedRelativeMousePosX - 1, paddedRelativeMousePosY - 1, InitialPaddedGameBoardData[0]);

										if (placementSuccess == true)
										{
											NavalEntityArray[navalEntityID].Set_HorizontalPlacementPosition(relativeMousePosX, relativeMousePosY);
											//NavalEntityArray[navalEntityID].Copy_To_GameBoard(InitialGameBoardData[0]);
										}
									}
									else if (rightMouseButtonClick == true)
									{
										placementSuccess = Add_NavalEntityL3_VerticalPlacement(paddedRelativeMousePosX - 1, paddedRelativeMousePosY - 1, InitialPaddedGameBoardData[0]);

										if (placementSuccess == true)
										{
											NavalEntityArray[navalEntityID].Set_VerticalPlacementPosition(relativeMousePosX, relativeMousePosY);
											//NavalEntityArray[navalEntityID].Copy_To_GameBoard(InitialGameBoardData[0]);
										}
									}
								}
								else if (navalEntityID == 4)
								{
									if (leftMouseButtonClick == true)
									{
										placementSuccess = Add_NavalEntityL2_HorizontalPlacement(paddedRelativeMousePosX - 1, paddedRelativeMousePosY - 1, InitialPaddedGameBoardData[0]);

										if (placementSuccess == true)
										{
											NavalEntityArray[navalEntityID].Set_HorizontalPlacementPosition(relativeMousePosX, relativeMousePosY);
											//NavalEntityArray[navalEntityID].Copy_To_GameBoard(InitialGameBoardData[0]);
										}
									}
									else if (rightMouseButtonClick == true)
									{
										placementSuccess = Add_NavalEntityL2_VerticalPlacement(paddedRelativeMousePosX - 1, paddedRelativeMousePosY - 1, InitialPaddedGameBoardData[0]);

										if (placementSuccess == true)
										{
											NavalEntityArray[navalEntityID].Set_VerticalPlacementPosition(relativeMousePosX, relativeMousePosY);
											//NavalEntityArray[navalEntityID].Copy_To_GameBoard(InitialGameBoardData[0]);
										}
									}
								}

								if (placementSuccess == true)
								{
									Copy_PaddedGameBoardData(InitialGameBoardData[0], InitialPaddedGameBoardData[0]);
									navalEntityID++;
								}
							} // end of if (navalEntityID < 4)

						EndOfPlacement:;


						} // end of if (relativeMousePosY > -1 && relativeMousePosY < ConstGameBoardSizePerDir)
					} // end of if (relativeMousePosX > -1 && relativeMousePosX < ConstGameBoardSizePerDir)

					if (navalEntityID == 5) // alle Schiffe plaziert
					{
						shipPlacementRunning = false;
						Copy_GameBoard(GameBoardData[0], InitialGameBoardData[0]);
					}
				} // end of if(startNewGame == true)


				leftMouseButtonClick = false;
				rightMouseButtonClick = false;
				middleMouseButtonClick = false;

				WinConsole.Clear_BackBuffer();

				if (shipPlacementRunning == true)
				{
					WinConsole.Draw_2DObject_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top, GameBoard.pDataArray, GameBoard.NumCharactersPerRow, GameBoard.NumCharactersPerColumn);

					sprintf(strBuffer, "Ship Placement (Human Player)");
					WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, 1, strBuffer, lightaqua, black);

					sprintf(strBuffer, "left mButton: hor. ship");
					WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 13, strBuffer, lightaqua, black);
					sprintf(strBuffer, "right mButton: vert. ship");
					WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 15, strBuffer, lightaqua, black);
					sprintf(strBuffer, "middle mButton: clear");
					WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 17, strBuffer, lightaqua, black);
				}
				else if (shipPlacementRunning == false)
				{
					//sprintf(strBuffer, "game running");
					//WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 13, strBuffer, lightaqua, black);

					prepareNewGame = true;

					for (int32_t i = 0; i < ConstNumNavalEntities; i++)
					{
						if (NavalEntityArray[i].Destroyed == false)
						{
							prepareNewGame = false;
							break;
						}
					}

					if (prepareNewGame == true)
					{
						PlayerID = 1; // nun ist der andere Spieler an der Reihe

						if (NumOfShots_AI > 0)
						{
							LastScore_AI = ConstGameBoardSize - NumOfShots_AI;
							SumOfScore_AI += LastScore_AI;
							GameCounter_AI++;
							MeanScore_AI = SumOfScore_AI / GameCounter_AI;
							NumOfShots_AI = 0;
						}

						prepareNewGame = true;
						continue;
					}

					if (loopcounter == 0)
					{
						//for (int32_t i = 0; i < ConstNumNavalEntities; i++)
						//{
						//	NavalEntityArray[i].Copy_Data_If_Destroyed(GameBoardData_DestroyedElements[0], 1.0f);
						//}

						Copy_DestroyedElementData(GameBoardData_DestroyedElements[0], GameBoardData[0], 1.0f);
						Copy_WaterShotData(GameBoardData_WaterShots[0], GameBoardData[0], 1.0f);
						Copy_WaterShotAndHitData(GameBoardData_WaterShotsAndHits[0], GameBoardData[0], -1.0f, 1.0f);
						Copy_WaterShotAndDestroyedElementData(GameBoardData_WaterShotsAndDestroyedElements[0], GameBoardData[0], 1.0f);
						Copy_DamagedElementData(GameBoardData_DamagedElements[0], GameBoardData[0], 1.0f);

						CNeuronV2 *pPlacementStrategyNeuron = nullptr;
						PlacementStrategyNeuronID = -1;

						PlacementStrategies.Get_StrongestActivatedMemoryNeuron(&pPlacementStrategyNeuron, &PlacementStrategyNeuronID, GameBoardData_WaterShotsAndHits[0]);
						//Add_To_Log(0, "strategyID", PlacementStrategyNeuronID);


						// kleinstm�gliche NavalEntity-L�nge: 2
						CNeuronV2 *pPlacementEvaluationNeuron = &L2ShipPlacementEvaluationNeuron;
						int32_t lengthOfBiggestUndestroyedEntity = 2;
						int32_t placementEvaluationHalfLRFSizePerDirMinus1 = 1;

						if (NavalEntityArray[0].Destroyed == false)
						{
							pPlacementEvaluationNeuron = &L5ShipPlacementEvaluationNeuron;
							lengthOfBiggestUndestroyedEntity = 5;
							placementEvaluationHalfLRFSizePerDirMinus1 = L5PlacementEvaluationHalfLRFSizePerDirMinus1;
						}
						else if (NavalEntityArray[1].Destroyed == false)
						{
							pPlacementEvaluationNeuron = &L4ShipPlacementEvaluationNeuron;
							lengthOfBiggestUndestroyedEntity = 4;
							placementEvaluationHalfLRFSizePerDirMinus1 = L4PlacementEvaluationHalfLRFSizePerDirMinus1;
						}
						else if (NavalEntityArray[2].Destroyed == false || NavalEntityArray[3].Destroyed == false)
						{
							pPlacementEvaluationNeuron = &L3ShipPlacementEvaluationNeuron;
							lengthOfBiggestUndestroyedEntity = 3;
							placementEvaluationHalfLRFSizePerDirMinus1 = L3PlacementEvaluationHalfLRFSizePerDirMinus1;
						}

						int32_t out = AI_Shot(GameBoardData[0], &NumOfShots_AI,
								&SearchRemainingIntactShipElementsNeuron, GameBoardData_DamagedElements[0],
								&DestroyedEntityNeighborhoodDetectionNeuron, GameBoardData_DestroyedElements[0],
								pPlacementEvaluationNeuron, placementEvaluationHalfLRFSizePerDirMinus1, GameBoardData_WaterShotsAndDestroyedElements[0], &UnnecessaryShotDetectionNeuron, GameBoardData_WaterShots[0], lengthOfBiggestUndestroyedEntity, pPlacementStrategyNeuron->pDendrite_CentroidValueArray,
								&RandomNumbers);

						if (out == 0)
							Add_To_Log(0, "no shot");

						for (int32_t i = 0; i < ConstNumNavalEntities; i++)
						{
							NavalEntityArray[i].Check_Destruction(GameBoardData[0]);
						}	
					} // end of if (loopcounter == 0)

					loopcounter++;

					if (loopcounter > 20)
						loopcounter = 0;

					Update_GameBoardGraphics(&GameBoard, GameBoardData[0]);


					WinConsole.Clear_BackBuffer();

					WinConsole.Draw_2DObject_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top, GameBoard.pDataArray, GameBoard.NumCharactersPerRow, GameBoard.NumCharactersPerColumn);


					sprintf(strBuffer, "AI Player Ship Search");
					WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, 1, strBuffer, lightaqua, black);

					Score_AI = ConstGameBoardSize - NumOfShots_AI;
					sprintf(strBuffer, "score: %03d", Score_AI);
					WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 13, strBuffer, lightaqua, black);

					sprintf(strBuffer, "last (Human / AI): %03d / %03d", LastScore_Human, LastScore_AI);
					WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 15, strBuffer, lightaqua, black);

					sprintf(strBuffer, "mean (Human / AI): %03d / %03d", MeanScore_Human, MeanScore_AI);
					WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 17, strBuffer, lightaqua, black);

					sprintf(strBuffer, "placement strategy: %03d", PlacementStrategyNeuronID);
					WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 19, strBuffer, lightaqua, black);

				} // end of else if (startNewGame == false)

				WinConsole.Present_BackBuffer();

				//Frame-Bremse:

				auto current_timepoint = steady_clock::now();

				//while (current_timepoint - last_timepoint < 250ms)
				//while (current_timepoint - last_timepoint < 50ms)
				while (current_timepoint - last_timepoint < 16ms)
					//while (current_timepoint - last_timepoint < 16666us) // 16.7 Millisekunden (ms)  bzw. 16666 Mikrosekunden (us): maximal 60 Frames pro Sekunde					
				{
					current_timepoint = steady_clock::now();
				}

				FrameTime = 0.000000001f * (current_timepoint - last_timepoint).count();
				FrameRate = 1.0f / FrameTime;
			} // end of else if (threadID == 0 && PlayerID == 0) // master thread

		} while (true);
	} // end of #pragma omp parallel num_threads(2)

	InputHandling.CleanUp();
	WinConsole.Clear_BackBuffer();
	WinConsole.Present_BackBuffer();
	WinConsole.CleanUp();

	Set_CursorVisibilityAndSize(true);
	Reset_CursorPos();
	Set_CursorPos(0, 0);

	cout << "bye bye (Press Return)" << endl;

	//getchar();

	return 0;
}
*/




/*
// classic game
int main(void)
{
	//Set_ProcessPriority(2);

	Begin_Log(0, "start AI_Log",
		"AI_Log.txt");

	Set_Title("Battleship");
	Set_ConsolePos(10, 10);

	char inputBuffer[100];
	int32_t RecalculatePlacementStrategies = 0;

	cout << "Recalculate Placement Strategies (0/1): ";

	cin.getline(inputBuffer, 100);
	RecalculatePlacementStrategies = atoi(inputBuffer);

	int32_t RandomSeed = 1;

	cout << "RandomSeed (> 0): ";

	cin.getline(inputBuffer, 100);
	RandomSeed = atoi(inputBuffer);
	RandomSeed = max(1, RandomSeed);

	int32_t MultipleShots = 0;

	cout << "Multiple Shots (0/1): ";

	cin.getline(inputBuffer, 100);
	MultipleShots = atoi(inputBuffer);

	CInputHandling InputHandling;
	InputHandling.Initialize();

	Clear_Terminal_And_Reset_CursorPos();

	CWindowsConsoleScreenBuffer WinConsole;
	WinConsole.Initialize(40, 30, false, BackgroundColor);

	Set_Title("Battleship");
	Set_ConsolePos(10, 10);

	WinConsole.Set_CursorVisibilityAndSize(FALSE);
	//WinConsole.Set_Font(L"Consolas", 15, 15);
	//WinConsole.Set_Font(L"Consolas", 4, 4);
	//WinConsole.Set_Font(L"Consolas", 8, 8);
	WinConsole.Set_Font_Ext(L"Consolas", 90, 15, 15);


	//WinConsole.Set_BackgroundColor(RGB(100, 50, 25));
	WinConsole.Set_BackgroundColor(BackgroundColor);

	Set_CursorVisibilityAndSize(false);

	CRandomNumbersNN RandomNumbers;
	RandomNumbers.Change_Seed(RandomSeed);

	static constexpr int32_t ConstNumNavalEntities = 5;
	static constexpr int32_t ConstNumNavalEntityElements = 17;


	static int32_t AIPlayerGameBoardData[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];
	static int32_t InitialAIPlayerGameBoardData[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];

	static int32_t HumanPlayerGameBoardData[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];
	static int32_t InitialHumanPlayerGameBoardData[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];

	static float GameBoardData_DestroyedElements[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];
	Init_2DimArray(GameBoardData_DestroyedElements[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);

	static float GameBoardData_WaterShots[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];
	Init_2DimArray(GameBoardData_WaterShots[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);

	static float GameBoardData_WaterShotsAndHits[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];
	Init_2DimArray(GameBoardData_WaterShotsAndHits[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);

	static float GameBoardData_WaterShotsAndDestroyedElements[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];
	Init_2DimArray(GameBoardData_WaterShotsAndDestroyedElements[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);

	static float GameBoardData_DamagedElements[ConstGameBoardSizePerDir][ConstGameBoardSizePerDir];
	Init_2DimArray(GameBoardData_DamagedElements[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);

	CNeuronV2 DestroyedEntityNeighborhoodDetectionNeuron;
	DestroyedEntityNeighborhoodDetectionNeuron.NeuronID = 10;
	DestroyedEntityNeighborhoodDetectionNeuron.Init_Dendrite_Arrays(9);
	DestroyedEntityNeighborhoodDetectionNeuron.Set_ActivationFunction(DestroyedEntityNeighborhoodDetection);

	// local receptive field:
	float DestroyedEntityNeighborhoodDetectionLRF[9] = { 1.0f, 1.0f, 1.0f,  1.0f, 0.0f, 1.0f,  1.0f, 1.0f, 1.0f };
	DestroyedEntityNeighborhoodDetectionNeuron.Set_Dendrite_Factors(DestroyedEntityNeighborhoodDetectionLRF);

	CNeuronV2 UnnecessaryShotDetectionNeuron;
	UnnecessaryShotDetectionNeuron.NeuronID = 20;
	UnnecessaryShotDetectionNeuron.Init_Dendrite_Arrays(9);
	UnnecessaryShotDetectionNeuron.Set_ActivationFunction(UnnecessaryShotDetection);

	// local receptive field:
	float UnnecessaryShotDetectionLRF[9] = { 0.0f, 1.0f, 0.0f,  1.0f, 0.0f, 1.0f,  0.0f, 1.0f, 0.0f };
	UnnecessaryShotDetectionNeuron.Set_Dendrite_Factors(UnnecessaryShotDetectionLRF);

	CNeuronV2 L2ShipPlacementEvaluationNeuron;
	L2ShipPlacementEvaluationNeuron.Init_Dendrite_Arrays(9);
	L2ShipPlacementEvaluationNeuron.Set_ActivationFunction(L2ShipPlacementEvaluation);
	int32_t L2PlacementEvaluationHalfLRFSizePerDirMinus1 = 1;

	CNeuronV2 L3ShipPlacementEvaluationNeuron;
	L3ShipPlacementEvaluationNeuron.Init_Dendrite_Arrays(25);
	L3ShipPlacementEvaluationNeuron.Set_ActivationFunction(L3ShipPlacementEvaluation);
	int32_t L3PlacementEvaluationHalfLRFSizePerDirMinus1 = 2;

	CNeuronV2 L4ShipPlacementEvaluationNeuron;
	L4ShipPlacementEvaluationNeuron.Init_Dendrite_Arrays(49);
	L4ShipPlacementEvaluationNeuron.Set_ActivationFunction(L4ShipPlacementEvaluation);
	int32_t L4PlacementEvaluationHalfLRFSizePerDirMinus1 = 3;

	CNeuronV2 L5ShipPlacementEvaluationNeuron;
	L5ShipPlacementEvaluationNeuron.Init_Dendrite_Arrays(81);
	L5ShipPlacementEvaluationNeuron.Set_ActivationFunction(L5ShipPlacementEvaluation);
	int32_t L5PlacementEvaluationHalfLRFSizePerDirMinus1 = 4;


	CNeuronV2 SearchRemainingIntactShipElementsNeuron;
	SearchRemainingIntactShipElementsNeuron.NeuronID = 60;
	SearchRemainingIntactShipElementsNeuron.Init_Dendrite_Arrays(25);
	SearchRemainingIntactShipElementsNeuron.Set_ActivationFunction(SearchRemainingIntactShipElements);

	// local receptive field:
	float SearchRemainingIntactShipElementsLRF[25] = {
	0.0f, 0.0f, -2.0f, 0.0f, 0.0f,
	0.0f, 0.0f, -1.0f, 0.0f, 0.0f,
	29.0f, 17.0f,  0.0f, 1.0f, 2.0f,
	0.0f, 0.0f, -17.0f, 0.0f, 0.0f,
	0.0f, 0.0f, -29.0f, 0.0f, 0.0f };

	SearchRemainingIntactShipElementsNeuron.Set_Dendrite_Factors(SearchRemainingIntactShipElementsLRF);


	static CNavalEntity AIPlayerHostileNavalEntityArray[ConstNumNavalEntities];

	AIPlayerHostileNavalEntityArray[0].Initialize(5);
	AIPlayerHostileNavalEntityArray[1].Initialize(4);
	AIPlayerHostileNavalEntityArray[2].Initialize(3);
	AIPlayerHostileNavalEntityArray[3].Initialize(3);
	AIPlayerHostileNavalEntityArray[4].Initialize(2);

	static CNavalEntity HumanPlayerHostileNavalEntityArray[ConstNumNavalEntities];

	HumanPlayerHostileNavalEntityArray[0].Initialize(5);
	HumanPlayerHostileNavalEntityArray[1].Initialize(4);
	HumanPlayerHostileNavalEntityArray[2].Initialize(3);
	HumanPlayerHostileNavalEntityArray[3].Initialize(3);
	HumanPlayerHostileNavalEntityArray[4].Initialize(2);

	CPlacementStrategies PlacementStrategies;

	PlacementStrategies.Init_New_Strategies("BattleShipPlacementStrategies.txt", &RandomNumbers);


	if (RecalculatePlacementStrategies != 0)
	{
		PlacementStrategies.Train_MemoryNeurons(AIPlayerGameBoardData[0], AIPlayerHostileNavalEntityArray, ConstNumNavalEntities, ConstNumNavalEntityElements, &RandomNumbers);
		PlacementStrategies.Save_HitProbabilityValues("BattleshipStrategies/Strategy");
	}
	else
	{
		PlacementStrategies.Load_HitProbabilityValues("BattleshipStrategies/Strategy");
	}

	char strBuffer[100];

	bool leftMouseButtonClick = false;
	bool middleMouseButtonClick = false;
	bool rightMouseButtonClick = false;

	float FrameTime = 1.0f;
	float FrameRate = 1.0f;

	int32_t AIPlayerGameBoardPosX_Left = 2;
	int32_t AIPlayerGameBoardPosY_Top = 5;

	int32_t HumanPlayerGameBoardPosX_Left = 2 + 10 + 2;
	int32_t HumanPlayerGameBoardPosY_Top = 5;

	CWindowsConsole2DObject AIPlayerGameBoard;
	AIPlayerGameBoard.Initialize(ConstGameBoardSizePerDir, ConstGameBoardSizePerDir);

	CWindowsConsole2DObject HumanPlayerGameBoard;
	HumanPlayerGameBoard.Initialize(ConstGameBoardSizePerDir, ConstGameBoardSizePerDir);

	static int32_t InitialPaddedGameBoardData[ConstGameBoardSizePerDirWithPadding][ConstGameBoardSizePerDirWithPadding];


	Init_PaddedGameBoard(InitialPaddedGameBoardData[0], 0);
	Init_GameBoard(InitialAIPlayerGameBoardData[0], 0);
	Init_GameBoard(InitialHumanPlayerGameBoardData[0], 0);


	
	int32_t NumOfShots_Human = 0;
	int32_t NumOfShots_AI = 0;
	int32_t NumOfHumanPlayerWins = 0;
	int32_t NumOfAIPlayerWins = 0;

	int32_t PlacementStrategyNeuronID;

	

	int32_t navalEntityID = 0;

	bool NewGamePrepared = false;
	bool ShipPlacementRunning = true;
	bool AIShipPlacementCompleted = false;
	bool PlayerShipPlacementCompleted = false;
	bool prepareNewGame = true;

	bool PlayerShotCompleted = false;

	// Human Player Placememt + AI Search
	int32_t PlayerID = 0;

#pragma omp parallel num_threads(2)
	{
		do
		{
			if (KEYDOWN(VK_ESCAPE) == true)
				break;



			int32_t threadID = omp_get_thread_num();

			if (threadID == 1)
			{
				InputHandling.Check_For_Input();
			}
			else if (threadID == 0) // master thread
			{
				//auto last_timepoint = std::chrono::steady_clock::now();
				auto last_timepoint = steady_clock::now();

				if (InputHandling.LeftMouseButtonPressed == true)
				{
					if (leftMouseButtonClick == false)
						leftMouseButtonClick = true;
					else
						leftMouseButtonClick = false;
				}

				if (InputHandling.MiddleMouseButtonPressed == true)
				{
					if (middleMouseButtonClick == false)
						middleMouseButtonClick = true;
					else
						middleMouseButtonClick = false;
				}

				if (InputHandling.RightMouseButtonPressed == true)
				{
					if (rightMouseButtonClick == false)
						rightMouseButtonClick = true;
					else
						rightMouseButtonClick = false;
				}

				InputHandling.Reset_MouseButtons();
				

				
				if (ShipPlacementRunning == true)
				{
					if (NewGamePrepared == false)
					{
						Init_2DimArray(GameBoardData_WaterShots[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);
						Init_2DimArray(GameBoardData_WaterShotsAndHits[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);
						Init_2DimArray(GameBoardData_DestroyedElements[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);
						Init_2DimArray(GameBoardData_DamagedElements[0], ConstGameBoardSizePerDir, ConstGameBoardSizePerDir, 0.0f);

						Init_PaddedGameBoard(InitialPaddedGameBoardData[0], 0);
						Init_GameBoard(InitialAIPlayerGameBoardData[0], 0);
						navalEntityID = 0;

						NewGamePrepared = true;
						PlayerShotCompleted = false;
					}

					if (PlayerShipPlacementCompleted == false)
					{
						int32_t mousePosX = InputHandling.MousePosX;
						int32_t mousePosY = InputHandling.MousePosY;

						int32_t relativeMousePosX = mousePosX - AIPlayerGameBoardPosX_Left;
						int32_t relativeMousePosY = mousePosY - AIPlayerGameBoardPosY_Top;

						int32_t paddedRelativeMousePosX = mousePosX - AIPlayerGameBoardPosX_Left + 1;
						int32_t paddedRelativeMousePosY = mousePosY - AIPlayerGameBoardPosY_Top + 1;

						
						Update_GameBoardGraphics2(&AIPlayerGameBoard, InitialPaddedGameBoardData[0]);

						if (relativeMousePosX > -1 && relativeMousePosX < ConstGameBoardSizePerDir)
						{
							if (relativeMousePosY > -1 && relativeMousePosY < ConstGameBoardSizePerDir)
							{
								AIPlayerGameBoard.Set_Pixel(relativeMousePosX, relativeMousePosY, lightaqua);

								if (middleMouseButtonClick == true)
								{
									Init_PaddedGameBoard(InitialPaddedGameBoardData[0], 0);
									Init_GameBoard(InitialAIPlayerGameBoardData[0], 0);
									navalEntityID = 0;
									goto EndOfPlacement;
								}

								if (navalEntityID < 5)
								{
									bool placementSuccess = false;

									if (navalEntityID == 0)
									{
										if (leftMouseButtonClick == true)
										{
											placementSuccess = Add_NavalEntityL5_HorizontalPlacement(paddedRelativeMousePosX - 1, paddedRelativeMousePosY - 1, InitialPaddedGameBoardData[0]);

											if (placementSuccess == true)
											{
												AIPlayerHostileNavalEntityArray[navalEntityID].Set_HorizontalPlacementPosition(relativeMousePosX, relativeMousePosY);
												//AIPlayerHostileNavalEntityArray[navalEntityID].Copy_To_GameBoard(InitialGameBoardData[0]);		
											}
										}
										else if (rightMouseButtonClick == true)
										{
											placementSuccess = Add_NavalEntityL5_VerticalPlacement(paddedRelativeMousePosX - 1, paddedRelativeMousePosY - 1, InitialPaddedGameBoardData[0]);

											if (placementSuccess == true)
											{
												AIPlayerHostileNavalEntityArray[navalEntityID].Set_VerticalPlacementPosition(relativeMousePosX, relativeMousePosY);
												//AIPlayerHostileNavalEntityArray[navalEntityID].Copy_To_GameBoard(InitialGameBoardData[0]);
											}
										}
									}
									else if (navalEntityID == 1)
									{
										if (leftMouseButtonClick == true)
										{
											placementSuccess = Add_NavalEntityL4_HorizontalPlacement(paddedRelativeMousePosX - 1, paddedRelativeMousePosY - 1, InitialPaddedGameBoardData[0]);

											if (placementSuccess == true)
											{
												AIPlayerHostileNavalEntityArray[navalEntityID].Set_HorizontalPlacementPosition(relativeMousePosX, relativeMousePosY);
												//AIPlayerHostileNavalEntityArray[navalEntityID].Copy_To_GameBoard(InitialGameBoardData[0]);
											}
										}
										else if (rightMouseButtonClick == true)
										{
											placementSuccess = Add_NavalEntityL4_VerticalPlacement(paddedRelativeMousePosX - 1, paddedRelativeMousePosY - 1, InitialPaddedGameBoardData[0]);

											if (placementSuccess == true)
											{
												AIPlayerHostileNavalEntityArray[navalEntityID].Set_VerticalPlacementPosition(relativeMousePosX, relativeMousePosY);
												//AIPlayerHostileNavalEntityArray[navalEntityID].Copy_To_GameBoard(InitialGameBoardData[0]);
											}
										}
									}
									else if (navalEntityID == 2 || navalEntityID == 3)
									{
										if (leftMouseButtonClick == true)
										{
											placementSuccess = Add_NavalEntityL3_HorizontalPlacement(paddedRelativeMousePosX - 1, paddedRelativeMousePosY - 1, InitialPaddedGameBoardData[0]);

											if (placementSuccess == true)
											{
												AIPlayerHostileNavalEntityArray[navalEntityID].Set_HorizontalPlacementPosition(relativeMousePosX, relativeMousePosY);
												//AIPlayerHostileNavalEntityArray[navalEntityID].Copy_To_GameBoard(InitialGameBoardData[0]);
											}
										}
										else if (rightMouseButtonClick == true)
										{
											placementSuccess = Add_NavalEntityL3_VerticalPlacement(paddedRelativeMousePosX - 1, paddedRelativeMousePosY - 1, InitialPaddedGameBoardData[0]);

											if (placementSuccess == true)
											{
												AIPlayerHostileNavalEntityArray[navalEntityID].Set_VerticalPlacementPosition(relativeMousePosX, relativeMousePosY);
												//AIPlayerHostileNavalEntityArray[navalEntityID].Copy_To_GameBoard(InitialGameBoardData[0]);
											}
										}
									}
									else if (navalEntityID == 4)
									{
										if (leftMouseButtonClick == true)
										{
											placementSuccess = Add_NavalEntityL2_HorizontalPlacement(paddedRelativeMousePosX - 1, paddedRelativeMousePosY - 1, InitialPaddedGameBoardData[0]);

											if (placementSuccess == true)
											{
												AIPlayerHostileNavalEntityArray[navalEntityID].Set_HorizontalPlacementPosition(relativeMousePosX, relativeMousePosY);
												//AIPlayerHostileNavalEntityArray[navalEntityID].Copy_To_GameBoard(InitialGameBoardData[0]);
											}
										}
										else if (rightMouseButtonClick == true)
										{
											placementSuccess = Add_NavalEntityL2_VerticalPlacement(paddedRelativeMousePosX - 1, paddedRelativeMousePosY - 1, InitialPaddedGameBoardData[0]);

											if (placementSuccess == true)
											{
												AIPlayerHostileNavalEntityArray[navalEntityID].Set_VerticalPlacementPosition(relativeMousePosX, relativeMousePosY);
												//AIPlayerHostileNavalEntityArray[navalEntityID].Copy_To_GameBoard(InitialGameBoardData[0]);
											}
										}
									}

									if (placementSuccess == true)
									{
										Copy_PaddedGameBoardData(InitialAIPlayerGameBoardData[0], InitialPaddedGameBoardData[0]);
										navalEntityID++;
									}
								} // end of if (navalEntityID < 4)

							EndOfPlacement:;

							} // end of if (relativeMousePosY > -1 && relativeMousePosY < ConstGameBoardSizePerDir)
						} // end of if (relativeMousePosX > -1 && relativeMousePosX < ConstGameBoardSizePerDir)

						
					} // end of if (PlayerShipPlacementCompleted == false)

					leftMouseButtonClick = false;
					rightMouseButtonClick = false;
					middleMouseButtonClick = false;
					
					if (AIShipPlacementCompleted == false)
					{
						Init_GameBoard_And_Set_RandomEntityPositions(InitialHumanPlayerGameBoardData[0], HumanPlayerHostileNavalEntityArray, ConstNumNavalEntities, &RandomNumbers);

						//int32_t StrategyID = RandomNumbers.Get_IntegerNumber(0, PlacementStrategies.NumStrategies);
						//Init_GameBoard_And_Set_RandomEntityPositions(InitialHumanPlayerGameBoardData[0], HumanPlayerHostileNavalEntityArray, ConstNumNavalEntities, &RandomNumbers, PlacementStrategies.pStrategyArray[StrategyID].ForbiddenTileIDList, PlacementStrategies.pStrategyArray[StrategyID].NumOfForbiddenTiles);

						Copy_GameBoard(HumanPlayerGameBoardData[0], InitialHumanPlayerGameBoardData[0]);

						AIShipPlacementCompleted = true;
					} // end of if (AIShipPlacementCompleted == false)

					
					Update_GameBoardGraphics(&AIPlayerGameBoard, InitialAIPlayerGameBoardData[0]);

					WinConsole.Clear_BackBuffer();

					WinConsole.Draw_2DObject_Into_BackBuffer(AIPlayerGameBoardPosX_Left, AIPlayerGameBoardPosY_Top, AIPlayerGameBoard.pDataArray, AIPlayerGameBoard.NumCharactersPerRow, AIPlayerGameBoard.NumCharactersPerColumn);

					sprintf(strBuffer, "Ship Placement");
					WinConsole.Write_String_Into_BackBuffer(AIPlayerGameBoardPosX_Left, 1, strBuffer, lightaqua, black);

					sprintf(strBuffer, "left mButton: hor. ship");
					WinConsole.Write_String_Into_BackBuffer(AIPlayerGameBoardPosX_Left, AIPlayerGameBoardPosY_Top + 13, strBuffer, lightaqua, black);
					sprintf(strBuffer, "right mButton: vert. ship");
					WinConsole.Write_String_Into_BackBuffer(AIPlayerGameBoardPosX_Left, AIPlayerGameBoardPosY_Top + 15, strBuffer, lightaqua, black);
					sprintf(strBuffer, "middle mButton: clear");
					WinConsole.Write_String_Into_BackBuffer(AIPlayerGameBoardPosX_Left, AIPlayerGameBoardPosY_Top + 17, strBuffer, lightaqua, black);

					WinConsole.Present_BackBuffer();

					if (navalEntityID == 5 && AIShipPlacementCompleted == true) // alle Schiffe plaziert
					{
						PlayerShipPlacementCompleted == true;
						ShipPlacementRunning = false;
						Copy_GameBoard(AIPlayerGameBoardData[0], InitialAIPlayerGameBoardData[0]);
					}

				} // end of if (ShipPlacementRunning == true)
				else //if (ShipPlacementRunning == false)
				{
					int32_t mousePosX = InputHandling.MousePosX;
					int32_t mousePosY = InputHandling.MousePosY;

					int32_t relativeMousePosX = mousePosX - HumanPlayerGameBoardPosX_Left;
					int32_t relativeMousePosY = mousePosY - HumanPlayerGameBoardPosY_Top;

					if (PlayerShotCompleted == false)
					{
						// player shot:
						if (relativeMousePosX > -1 && relativeMousePosX < ConstGameBoardSizePerDir)
						{
							if (relativeMousePosY > -1 && relativeMousePosY < ConstGameBoardSizePerDir)
							{
								if (leftMouseButtonClick == true)
								{
									int32_t tileData = HumanPlayerGameBoardData[relativeMousePosY][relativeMousePosX];

									if (tileData == ConstGameBoard_Water)
									{
										NumOfShots_Human++;
										HumanPlayerGameBoardData[relativeMousePosY][relativeMousePosX] = ConstGameBoard_WaterShot;
										PlayerShotCompleted = true;
									}
									else if (tileData == ConstGameBoard_IntactElement)
									{
										NumOfShots_Human++;
										HumanPlayerGameBoardData[relativeMousePosY][relativeMousePosX] = ConstGameBoard_DamagedElement;

										if (MultipleShots == 0)
										{
											PlayerShotCompleted = true;
										}
										else
										{
											PlayerShotCompleted = false;
										}
									}
								}
							}
						} // end of if (relativeMousePosX > -1 && relativeMousePosX < ConstGameBoardSizePerDir)



						for (int32_t i = 0; i < ConstNumNavalEntities; i++)
						{
							HumanPlayerHostileNavalEntityArray[i].Check_Destruction(HumanPlayerGameBoardData[0]);
						}

						Update_GameBoardGraphics_DontShow_IntactParts(&HumanPlayerGameBoard, HumanPlayerGameBoardData[0]);

						if (relativeMousePosX > -1 && relativeMousePosX < ConstGameBoardSizePerDir)
						{
							if (relativeMousePosY > -1 && relativeMousePosY < ConstGameBoardSizePerDir)
							{
								HumanPlayerGameBoard.Set_Pixel(relativeMousePosX, relativeMousePosY, lightaqua);
							}
						}
					} // end of if (PlayerShotCompleted == false)

					// Ai Shot:
					else if (PlayerShotCompleted == true)
					{
						do
						{
							Copy_DestroyedElementData(GameBoardData_DestroyedElements[0], AIPlayerGameBoardData[0], 1.0f);
							Copy_WaterShotData(GameBoardData_WaterShots[0], AIPlayerGameBoardData[0], 1.0f);
							Copy_WaterShotAndHitData(GameBoardData_WaterShotsAndHits[0], AIPlayerGameBoardData[0], -1.0f, 1.0f);
							Copy_WaterShotAndDestroyedElementData(GameBoardData_WaterShotsAndDestroyedElements[0], AIPlayerGameBoardData[0], 1.0f);
							Copy_DamagedElementData(GameBoardData_DamagedElements[0], AIPlayerGameBoardData[0], 1.0f);

							CNeuronV2 *pPlacementStrategyNeuron = nullptr;
							PlacementStrategyNeuronID = -1;

							PlacementStrategies.Get_StrongestActivatedMemoryNeuron(&pPlacementStrategyNeuron, &PlacementStrategyNeuronID, GameBoardData_WaterShotsAndHits[0]);
							//Add_To_Log(0, "strategyID", PlacementStrategyNeuronID);


							// kleinstm�gliche NavalEntity-L�nge: 2
							CNeuronV2 *pPlacementEvaluationNeuron = &L2ShipPlacementEvaluationNeuron;
							int32_t lengthOfBiggestUndestroyedEntity = 2;
							int32_t placementEvaluationHalfLRFSizePerDirMinus1 = 1;

							if (AIPlayerHostileNavalEntityArray[0].Destroyed == false)
							{
								pPlacementEvaluationNeuron = &L5ShipPlacementEvaluationNeuron;
								lengthOfBiggestUndestroyedEntity = 5;
								placementEvaluationHalfLRFSizePerDirMinus1 = L5PlacementEvaluationHalfLRFSizePerDirMinus1;
							}
							else if (AIPlayerHostileNavalEntityArray[1].Destroyed == false)
							{
								pPlacementEvaluationNeuron = &L4ShipPlacementEvaluationNeuron;
								lengthOfBiggestUndestroyedEntity = 4;
								placementEvaluationHalfLRFSizePerDirMinus1 = L4PlacementEvaluationHalfLRFSizePerDirMinus1;
							}
							else if (AIPlayerHostileNavalEntityArray[2].Destroyed == false || AIPlayerHostileNavalEntityArray[3].Destroyed == false)
							{
								pPlacementEvaluationNeuron = &L3ShipPlacementEvaluationNeuron;
								lengthOfBiggestUndestroyedEntity = 3;
								placementEvaluationHalfLRFSizePerDirMinus1 = L3PlacementEvaluationHalfLRFSizePerDirMinus1;
							}





							int32_t out = AI_Shot(AIPlayerGameBoardData[0], &NumOfShots_AI,
								&SearchRemainingIntactShipElementsNeuron, GameBoardData_DamagedElements[0],
								&DestroyedEntityNeighborhoodDetectionNeuron, GameBoardData_DestroyedElements[0],
								pPlacementEvaluationNeuron, placementEvaluationHalfLRFSizePerDirMinus1, GameBoardData_WaterShotsAndDestroyedElements[0], &UnnecessaryShotDetectionNeuron, GameBoardData_WaterShots[0], lengthOfBiggestUndestroyedEntity, pPlacementStrategyNeuron->pDendrite_CentroidValueArray,
								&RandomNumbers);

							if (out == 0)
								Add_To_Log(0, "no shot");

							for (int32_t i = 0; i < ConstNumNavalEntities; i++)
							{
								AIPlayerHostileNavalEntityArray[i].Check_Destruction(AIPlayerGameBoardData[0]);
							}

							if (MultipleShots == 0)
							{
								PlayerShotCompleted = false;
								break;
							}
							else
							{
								if (out != 2)
								{
									PlayerShotCompleted = false;
									break;
								}
							}

						} while (true);

						Update_GameBoardGraphics(&AIPlayerGameBoard, AIPlayerGameBoardData[0]);

					} // end of else if (PlayerShotCompleted == true)


					WinConsole.Clear_BackBuffer();

					WinConsole.Draw_2DObject_Into_BackBuffer(AIPlayerGameBoardPosX_Left, AIPlayerGameBoardPosY_Top, AIPlayerGameBoard.pDataArray, AIPlayerGameBoard.NumCharactersPerRow, AIPlayerGameBoard.NumCharactersPerColumn);

					WinConsole.Draw_2DObject_Into_BackBuffer(HumanPlayerGameBoardPosX_Left, HumanPlayerGameBoardPosY_Top, HumanPlayerGameBoard.pDataArray, HumanPlayerGameBoard.NumCharactersPerRow, HumanPlayerGameBoard.NumCharactersPerColumn);

					sprintf(strBuffer, "Search And Destruction");
					WinConsole.Write_String_Into_BackBuffer(AIPlayerGameBoardPosX_Left, 1, strBuffer, lightaqua, black);
				
					sprintf(strBuffer, "shots (Human / AI): %03d / %03d", NumOfShots_Human, NumOfShots_AI);
					WinConsole.Write_String_Into_BackBuffer(AIPlayerGameBoardPosX_Left, AIPlayerGameBoardPosY_Top + 13, strBuffer, lightaqua, black);
					
					sprintf(strBuffer, "wins (Human / AI): %03d / %03d", NumOfHumanPlayerWins, NumOfAIPlayerWins);
					WinConsole.Write_String_Into_BackBuffer(AIPlayerGameBoardPosX_Left, AIPlayerGameBoardPosY_Top + 15, strBuffer, lightaqua, black);
					
					WinConsole.Present_BackBuffer();


					leftMouseButtonClick = false;
					rightMouseButtonClick = false;
					middleMouseButtonClick = false;

					//Frame-Bremse:

					auto current_timepoint = steady_clock::now();

					//while (current_timepoint - last_timepoint < 250ms)
					//while (current_timepoint - last_timepoint < 50ms)
					while (current_timepoint - last_timepoint < 16ms)
						//while (current_timepoint - last_timepoint < 16666us) // 16.7 Millisekunden (ms)  bzw. 16666 Mikrosekunden (us): maximal 60 Frames pro Sekunde					
					{
						current_timepoint = steady_clock::now();
					}

					FrameTime = 0.000000001f * (current_timepoint - last_timepoint).count();
					FrameRate = 1.0f / FrameTime;

					bool shipPlacementRunning = true;

					for (int32_t i = 0; i < ConstNumNavalEntities; i++)
					{
						if (AIPlayerHostileNavalEntityArray[i].Destroyed == false)
						{
							shipPlacementRunning = false;
							break;
						}
					}

					if (shipPlacementRunning == true)
					{
						NumOfAIPlayerWins++;

						NumOfShots_Human = 0;
						NumOfShots_AI = 0;

						AIShipPlacementCompleted = false;
						PlayerShipPlacementCompleted = false;
						NewGamePrepared = false;

						ShipPlacementRunning = true;
					}
					else if (shipPlacementRunning == false)
					{
						shipPlacementRunning = true;

						for (int32_t i = 0; i < ConstNumNavalEntities; i++)
						{
							if (HumanPlayerHostileNavalEntityArray[i].Destroyed == false)
							{
								shipPlacementRunning = false;
								break;
							}
						}

						if (shipPlacementRunning == true)
						{
							NumOfHumanPlayerWins++;

							NumOfShots_Human = 0;
							NumOfShots_AI = 0;

							AIShipPlacementCompleted = false;
							PlayerShipPlacementCompleted = false;
							NewGamePrepared = false;

							ShipPlacementRunning = true;
						}
					} // end of else if (ShipPlacementRunning == false)					

				} // end of else if (ShipPlacementRunning == false)

				

				

			} // end of else if (threadID == 0) // master thread

			

		} while (true);
	} // end of #pragma omp parallel num_threads(2)

	InputHandling.CleanUp();
	WinConsole.Clear_BackBuffer();
	WinConsole.Present_BackBuffer();
	WinConsole.CleanUp();

	Set_CursorVisibilityAndSize(true);
	Reset_CursorPos();
	Set_CursorPos(0, 0);

	cout << "bye bye (Press Return)" << endl;

	//getchar();

	return 0;
}
*/









































