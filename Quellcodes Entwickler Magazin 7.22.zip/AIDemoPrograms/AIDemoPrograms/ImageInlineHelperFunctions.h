// Schutz vor Mehrfachdeklarationen:

#ifndef _ImageInlineHelperFunctions_H_
#define _ImageInlineHelperFunctions_H_

#pragma warning( disable: 4996)

#include <iostream>
#include <fstream>
#include "NeuralNetInlineFunctions.h"

#ifndef max
#define max(a,b)    ( ((a) > (b)) ? (a) : (b) )
#endif

#ifndef min
#define min(a,b)    ( ((a) < (b)) ? (a) : (b) )
#endif





#endif