// Schutz vor Mehrfachdeklarationen:
#ifndef _SokobanClone_H_
#define _SokobanClone_H_

#include <iostream>
#include "NeuralNet_V2.h"
#include "SimpleNeuron.h"
#include "GameStateHandler.h"

/*
Funktionsweise der KI orientiert sich an der Vorgehensweise eines menschlichen Spielers:
Memorierung der Spielstellungen, von denen aus es kein Weiterkommen meht gibt (Deadlocks, Sackgassen).
*/


static constexpr int8_t ConstGameBoard_Empty = 0;
static constexpr int8_t ConstGameBoard_Wall = 1;
static constexpr int8_t ConstGameBoard_Box = 2;
static constexpr int8_t ConstGameBoard_Destination = 3;
static constexpr int8_t ConstGameBoard_DestinationWithBox = 4;
static constexpr int8_t ConstGameBoard_Player = 5;
static constexpr int8_t ConstGameBoard_DestinationWithPlayer = 6;


/*
Nach dem Laden z�hlen: SumOfBoxes = Number ConstGameBoard_Box + Number ConstGameBoard_DestinationWithBox
wenn SumOfBoxes == Number ConstGameBoard_DestinationWithBox => spiel gewonnen
*/

// LRF: lokales rezeptives Feld

// Ermitteln, ob eine Box nicht mehr bewegt werden kann (pNeuron->ActivationValue > 0.0f => Deadlock) (LRF-Gr��e: 3x3):
inline void SokobanDeadlockRecognitionFunction(CSimpleNeuron *pNeuron)
{
	static int32_t IndexArray[4]{ 1, 3, 5, 7 };

	for (int32_t i = 0; i < 4; i++)
	{
		/* Zielfelder, auf denen keine Kiste steht (0.01f), sind frei
		   begehbar und stellen demzufolge kein Hindernis dar: */
		if (pNeuron->pDendrite_DataArray[IndexArray[i]] == 0.01f)
			pNeuron->pDendrite_DataArray[IndexArray[i]] = 0.0f;
	}

	pNeuron->ActivationValue = 0.0f;

	// Befindet sich im LRF-Zentrum keine Box, liegt auch kein Deadlock vor:
	if (pNeuron->pDendrite_DataArray[4] != 0.5f)
		return;

	pNeuron->ActivationValue = min(pNeuron->pDendrite_DataArray[3] + pNeuron->pDendrite_DataArray[5],
		pNeuron->pDendrite_DataArray[1] + pNeuron->pDendrite_DataArray[7]);

	/*
	// Sofern sich im LRF-Zentrum eine Kiste befindet und der
	// horizontalActivationValue gleich null ist, l�sst sich die
	// besagte Kiste in horizontaler Richtung verschieben: 
	float horizontalActivationValue = pNeuron->pDendrite_DataArray[3] +
		pNeuron->pDendrite_DataArray[5];

	// Sofern sich im LRF-Zentrum eine Kiste befindet und der
	// verticalActivationValue gleich null ist, l�sst sich die
	// besagte Kiste in horizontaler Richtung verschieben: 
	float verticalActivationValue = pNeuron->pDendrite_DataArray[1] +
		pNeuron->pDendrite_DataArray[7];

	// Ein Deadlock liegt vor, wenn sowohl der horizontalActivationValue
	// wie auch der verticalActivationValue gr��er als null sind:
	pNeuron->ActivationValue = min(horizontalActivationValue,
		verticalActivationValue);
	*/
}

/* Ermitteln, welche der Tiles zumindest momentan blockiert sind (�ber eine m�gliche permanente 
   Blockierung kann an dieser Stelle noch keine Aussage getroffen werden!): */
inline void SokobanCurrentlyBlockedTileRecognitionFunction(CSimpleNeuron *pNeuron)
{
	static int32_t IndexArray[4]{ 1, 3, 5, 7 };

	for (int32_t i = 0; i < 4; i++)
	{
		/* Zielfelder, auf denen keine Kiste steht (0.01f), sind frei
		   begehbar und stellen demzufolge kein Hindernis dar: */
		if (pNeuron->pDendrite_DataArray[IndexArray[i]] == 0.01f)
			pNeuron->pDendrite_DataArray[IndexArray[i]] = 0.0f;
	}

	float centerValue = pNeuron->pDendrite_DataArray[4];
	pNeuron->ActivationValue = centerValue;
	int32_t sum = 0;

	// begehbare Spielfeldkachel:
	if (centerValue == 0.0f)
	{
		for (int32_t i = 0; i < 4; i++)
		{
			if (pNeuron->pDendrite_DataArray[IndexArray[i]] > 0.0f)
				sum++;
		}

		/* Eine Spielfeldkachel gilt als blockiert, wenn sie sowohl in
		   horizontaler als auch in vertikaler Richtung von insgesamt vier
		   nicht begehbaren Tiles (Kisten bzw. Wandelementen) umgeben ist: */

		if(sum == 4)
			pNeuron->ActivationValue = 100.0f; 
	}
}

// Da eine bewegbare Box keine permanete Blockade darstellt, k�nnen wir eine solche aus der Feature-Map entfernen:
inline void SokobanRemoveMovableBoxFromFeatureMapFunction(CSimpleNeuron *pNeuron)
{
	float centerValue = pNeuron->pDendrite_DataArray[4];

	pNeuron->ActivationValue = centerValue;

	// Spielfeldkachel, auf der eine Kiste steht:
	if (centerValue == 0.5f)
	{
		float tempValue = min(pNeuron->pDendrite_DataArray[3] + pNeuron->pDendrite_DataArray[5],
			pNeuron->pDendrite_DataArray[1] + pNeuron->pDendrite_DataArray[7]);

		/* Kann die Kiste weggeschoben werden, stellt sie nur eine tempor�re
		Blockade dar und kann aus der Feature-Map entfernt werden: */
		if (tempValue <= 0.0f)
			pNeuron->ActivationValue = 0.0f;
	}
}

// Ermitteln, welche der momentan blockierten Tiles tats�chlich dauerhaft blockiert sind:
inline void SokobanPermanentlyBlockedTileRecognitionFunction(CSimpleNeuron *pNeuron)
{
	static int32_t IndexArray[4]{ 1, 3, 5, 7 };

	for (int32_t i = 0; i < 4; i++)
	{
		/* Zielfelder, auf denen keine Kiste steht (0.01f), sind frei
		   begehbar und stellen demzufolge kein Hindernis dar: */
		if (pNeuron->pDendrite_DataArray[IndexArray[i]] == 0.01f)
			pNeuron->pDendrite_DataArray[IndexArray[i]] = 0.0f;
	}

	float centerValue = pNeuron->pDendrite_DataArray[4];
	pNeuron->ActivationValue = centerValue;
	int32_t sum = 0;

	// blockierte Spielfeldkachel:
	if (centerValue == 100.0f)
	{
		for (int32_t i = 0; i < 4; i++)
		{
			if (pNeuron->pDendrite_DataArray[IndexArray[i]] > 0.0f)
				sum++;
		}

		/* Die Blockade des Zugangs zu einer Spielfeldkachel ist von
		   tempor�rer Natur, sofern die Blockade zumindest auf einer der
		   Seiten lediglich durch eine verschiebbare Kiste erfolgt: */
		if (sum < 4) 
			pNeuron->ActivationValue = 0.0f;
	}
}


inline void SokobanDeadEndRecognitionFunction(CSimpleNeuron *pNeuron)
{
	static int32_t IndexArray[4]{ 1, 3, 5, 7 };

	// Bestimmung des Spielfeldkacheltyps im LRF-Zentrum:
	float centerValue = pNeuron->pDendrite_DataArray[4];

	pNeuron->ActivationValue = centerValue;

	int32_t sum = 0;

	// leere Spielfeldkachel im LRF-Zentrum:
	if (centerValue == 0.0f)
	{
		for (int32_t i = 0; i < 4; i++)
		{
			// weiteres Wandelement gefunden:
			if (pNeuron->pDendrite_DataArray[IndexArray[i]] == 10.0f)
				sum++;
		}

		/* Sofern eine leere Spielfeldkachel von drei oder mehr Wandelelementen
		umgeben ist, stellt die besagte Kachel eine Sackgasse f�r den Spieler
		dar und wird �hnlich wie ein Wandelement als nicht begehbar
		klassifiziert:*/


		if (sum > 2) 
			pNeuron->ActivationValue = 10.0f;
	}
}


class CSokobanGameStateCharacteristics
{
public:

	int32_t PlayerPosID = -1;

	int32_t NumOfBoxes = 0;
	int32_t *pBoxPosIDArray = nullptr;

	float fStatusValue = 0.0f;

	CSokobanGameStateCharacteristics();
	~CSokobanGameStateCharacteristics();

	// Kopierkonstruktor l�schen:
	CSokobanGameStateCharacteristics(const CSokobanGameStateCharacteristics  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CSokobanGameStateCharacteristics & operator=(const CSokobanGameStateCharacteristics  &originalObject) = delete;

	void Initialize(int32_t numOfBoxes);
	void Clone_Values(CSokobanGameStateCharacteristics *pOriginalObject);
	void Reset(void);
	void Set_Values(CGameStateValues *pGameState);
	bool Check_Identity(CSokobanGameStateCharacteristics *pOtherObject);
	bool Check_Identity_IgnorePlayer(CSokobanGameStateCharacteristics *pOtherObject);
	bool Check_Identity(CGameStateValues *pOtherObject);
	bool Check_Identity_IgnorePlayer(CGameStateValues *pOtherObject);
	void Reconstruct_GameState(CGameStateValues *pInOutReconstructedGameState);
};

class CSokobanBoxCharacteristics
{
public:

	int32_t PosID = 0;
	int32_t PosX = 0;
	int32_t PosY = 0;

	bool LeftPushPossible = false;
	bool RightPushPossible = false;
	bool UpwardPushPossible = false;
	bool DownwardPushPossible = false;

	bool LeftPullPossible = false;
	bool RightPullPossible = false;
	bool UpwardPullPossible = false;
	bool DownwardPullPossible = false;

	bool LeftSideBlockedForPlayer = false;
	bool RightSideBlockedForPlayer = false;
	bool UpperSideBlockedForPlayer = false;
	bool LowerSideBlockedForPlayer = false;

	int32_t MinDistanceToInitialPos = 1000000;

	CSokobanBoxCharacteristics();
	~CSokobanBoxCharacteristics();

	// Kopierkonstruktor l�schen:
	CSokobanBoxCharacteristics(const CSokobanBoxCharacteristics  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CSokobanBoxCharacteristics & operator=(const CSokobanBoxCharacteristics  &originalObject) = delete;

	void Clone_Values(CSokobanBoxCharacteristics *pOriginalObject);

	void Reset(void);
};

class CSokobanPuzzle
{
public:

	int32_t SizeX = 0;
	int32_t SizeY = 0;
	int32_t SizeXY = 0;

	int32_t NumOfBoxesInsideGamesWorld = 0;

	int32_t *pInitialBoxPosIDArray = nullptr;
	int32_t *pInitialBoxPosXArray = nullptr;
	int32_t *pInitialBoxPosYArray = nullptr;

	CGameStateValues GameState;

	static constexpr int32_t constNumOfFeatureMaps = 4;
	static constexpr int32_t constNumOfFeatureMapsMinus1 = constNumOfFeatureMaps - 1;
	CSimpleFeatureMap FeatureMapArray[constNumOfFeatureMaps];
	
	char* pFileName = nullptr;
	
	CSokobanPuzzle();
	~CSokobanPuzzle();

	// Kopierkonstruktor l�schen:
	CSokobanPuzzle(const CSokobanPuzzle  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CSokobanPuzzle & operator=(const CSokobanPuzzle  &originalObject) = delete;

	void Set_Filename(const char* pFilename);

	bool Load_Puzzle(const char* pFilename);
	bool Save_Puzzle(const char* pFilename);

	bool Load_Puzzle(void);
	bool Save_Puzzle(void);

	void Clone_Puzzle(CSokobanPuzzle *pOriginalObject);
	
	void Calculate_NeuralNetValueArray_MovementSpace(int8_t *pActualGameStateData, int32_t featureMapID);
	void Calculate_NeuralNetValueArray_MovementSpace(int32_t featureMapID_Destination, int32_t featureMapID_Source);
	// Manhatten-Distanzwerte auf 0 zur�cksetzen:
	void Reset_NeuralNetValueArray_MovementSpace(int32_t featureMapID);
	void Reset_NeuralNetValueArray_MovementSpace_OMP(int32_t featureMapID);

	void Update_NeuralNetValueArray(int8_t *pActualGameStateData, int32_t featureMapID);

	void Substitute_Update_NeuralNetArrayValue(float newValue, float oldValue, int32_t featureMapID);

	void Clone_FeatureMapValues(int32_t featureMapID_Destination, int32_t featureMapID_Source);
	void Clone_FeatureMapValues_OMP(int32_t featureMapID_Destination, int32_t featureMapID_Source);

	// return false: Start- und Zielposition befinden sich nicht in direkter Nachbarschaft 
	bool Check_For_ShortestPaths(int32_t *pOutPathTileIDArray, int32_t *pOutNumOfPathSteps, int32_t startPosX, int32_t startPosY, int32_t destinationPosX, int32_t destinationPosY);
	bool Check_For_ShortestPaths(int32_t startPosX, int32_t startPosY, int32_t destinationPosX, int32_t destinationPosY);

	// return false: Start- und Zielposition befinden sich nicht in direkter Nachbarschaft 
	bool Check_For_ShortestPaths_IncludingDiagonalMovement(int32_t *pOutPathTileIDArray, int32_t *pOutNumOfPathSteps, int32_t startPosX, int32_t startPosY, int32_t destinationPosX, int32_t destinationPosY);
	bool Check_For_ShortestPaths_IncludingDiagonalMovement(int32_t startPosX, int32_t startPosY, int32_t destinationPosX, int32_t destinationPosY);

	// return false: Wegfindung nicht m�glich, da Ziel-Tile nicht begehbar ist
	bool Start_Pathfinding(int32_t destinationPosX, int32_t destinationPosY, int32_t featureMapID);
	
	// return true: Pfad ermittelt, searchSteps: 1, 2, usw.
	bool Update_Pathfinding(int32_t searchStep, int32_t startPosX, int32_t startPosY, int32_t featureMapID);
	bool Update_Pathfinding_OMP(int32_t searchStep, int32_t startPosX, int32_t startPosY, int32_t featureMapID);

	void Get_Path(int32_t *pOutPathTileIDArray, int32_t *pOutNumOfPathSteps, int32_t startPosX, int32_t startPosY, int32_t destinationPosX, int32_t destinationPosY, int32_t featureMapID);

	void Get_Path_IncludingDiagonalMovement(int32_t *pOutPathTileIDArray, int32_t *pOutNumOfPathSteps, int32_t startPosX, int32_t startPosY, int32_t destinationPosX, int32_t destinationPosY, int32_t featureMapID);
};



class CSokobanPuzzles
{
public:

	int32_t NumOfPuzzles = 0;
	CSokobanPuzzle *pPuzzleArray = nullptr;
	CSokobanPuzzle *pSolvedPuzzleArray = nullptr;

	int32_t IDofActualPlayedPuzzle = 0;

	CSokobanPuzzles();
	~CSokobanPuzzles();

	// Kopierkonstruktor l�schen:
	CSokobanPuzzles(const CSokobanPuzzles  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CSokobanPuzzles & operator=(const CSokobanPuzzles  &originalObject) = delete;

	// Wenn ein Puzzle gel�st ist, kommt das n�chste an die Reihe:
	bool Load_PlayerProgressInfo(const char* pFilename);
	bool Save_PlayerProgressInfo(const char* pFilename);
	void Update_PlayerProgressInfo(void);

	bool Initialize_Puzzles(const char* pFilename);

	bool Load_PuzzleInfos(const char* pFilename);

	bool Initialize_Puzzle(int32_t puzzleID);
	bool Initialize_SolvedPuzzle(int32_t puzzleID);

	bool Initialize_Puzzle(CSokobanPuzzle **ppOutSokobanPuzzle, int32_t puzzleID);
	bool Initialize_SolvedPuzzle(CSokobanPuzzle **ppOutSokobanPuzzle, int32_t puzzleID);
};


void Get_PlayerPos(int32_t *pOutPosX, int32_t *pOutPosY, int8_t *pGamesWorldData, int32_t gamesWorldSizeX, int32_t gamesWorldSizeY);

int8_t Get_TileType_Of_GamesWorldPos(int32_t posX, int32_t posY, int8_t *pGamesWorldData, int32_t gamesWorldSizeX);

bool Update_GamesWorld_AfterPlayerMovement(int32_t newPlayerPosX, int32_t newPlayerPosY, int32_t oldPlayerPosX, int32_t oldPlayerPosY, int8_t *pGamesWorldData, int32_t gamesWorldSizeX);

bool Check_PossibleBoxLeftPushMove(int32_t boxPosX, int32_t boxPosY, int8_t *pGamesWorldData, int32_t gamesWorldSizeX);
bool Check_PossibleBoxRightPushMove(int32_t boxPosX, int32_t boxPosY, int8_t *pGamesWorldData, int32_t gamesWorldSizeX);
bool Check_PossibleBoxUpwardPushMove(int32_t boxPosX, int32_t boxPosY, int8_t *pGamesWorldData, int32_t gamesWorldSizeX);
bool Check_PossibleBoxDownwardPushMove(int32_t boxPosX, int32_t boxPosY, int8_t *pGamesWorldData, int32_t gamesWorldSizeX);

bool Set_BoxPos_If_Possible(int32_t boxPosX, int32_t boxPosY, int8_t *pGamesWorldData, int32_t gamesWorldSizeX);

bool Check_PossibleWin(int32_t numOfBoxesInsideGamesWorld, int8_t *pGamesWorldData, int32_t gamesWorldSizeX, int32_t gamesWorldSizeY);

bool Pull_Box(int32_t oldPossibleBoxPosX, int32_t oldPossibleBoxPosY, int32_t oldPlayerPosX, int32_t oldPlayerPosY, int8_t tileTypePlayerPos, int8_t *pGamesWorldData, int32_t gamesWorldSizeX);


void Calculate_Path(int32_t *pOutPathTileIDArray, int32_t *pOutNumOfPathSteps, int32_t startPosX, int32_t startPosY, int32_t destinationPosX, int32_t destinationPosY, CSokobanPuzzle *pPuzzle, int32_t featureMapID, int32_t numOfSearchStepsMax);

bool Verify_Path(int32_t startPosX, int32_t startPosY, int32_t destinationPosX, int32_t destinationPosY, CSokobanPuzzle *pPuzzle, int32_t featureMapID, int32_t numOfSearchStepsMax);

void Calculate_Path_IncludingDiagonalMovement(int32_t *pOutPathTileIDArray, int32_t *pOutNumOfPathSteps, int32_t startPosX, int32_t startPosY, int32_t destinationPosX, int32_t destinationPosY, CSokobanPuzzle *pPuzzle, int32_t featureMapID, int32_t numOfSearchStepsMax);

bool Verify_Path_IncludingDiagonalMovement(int32_t startPosX, int32_t startPosY, int32_t destinationPosX, int32_t destinationPosY, CSokobanPuzzle *pPuzzle, int32_t featureMapID, int32_t numOfSearchStepsMax);


class CSimpleSokobanSolver
{
public:

	CSokobanPuzzle *pInitialPuzzle = nullptr;
	CSokobanPuzzle *pSolvedPuzzle = nullptr;
	
	int32_t NumOfBoxes = 0;
	CSokobanBoxCharacteristics *pBoxCharacteristicsArray = nullptr;
	CSokobanBoxCharacteristics *pTempBoxCharacteristicsArray = nullptr;

	int32_t PlayerPosX = 0;
	int32_t PlayerPosY = 0;
	int32_t PlayerPosID = 0;

	int32_t PuzzleSizeX = 0;
	int32_t PuzzleSize2X = 0;
	int32_t PuzzleSizeY = 0;
	int32_t PuzzleSizeXY = 0;

	int32_t NumOfDiscardedGameStatesMax = 1000;
	int32_t NumOfDiscardedGameStatesMaxMinus1 = NumOfDiscardedGameStatesMax - 1;
	int32_t NumOfDiscardedGameStatesInUse = 0;
	                                
	CSokobanGameStateCharacteristics *pDiscardedGameStateCharacteristicsArray = nullptr;
	CSokobanGameStateCharacteristics DiscardedGameStateCharacteristics;

	int32_t NumOfVisitedGameStatesMax = 10000;
	int32_t NumOfVisitedGameStatesMaxMinus1 = NumOfVisitedGameStatesMax - 1;
	int32_t NumOfVisitedGameStatesInUse = 0;

	CSokobanGameStateCharacteristics *pVisitedGameStateCharacteristicsArray = nullptr;
	CSokobanGameStateCharacteristics TestVisitedGameStateCharacteristics;
	
	// Maximale Anzahl von Pull-Z�gen, die im Rahmen der L�sungsfindung ausgef�hrt werden k�nnen:
	int32_t NumOfSavedGameStatesMax = 200;	
	int32_t ActualSearchDepth = 0;

	CGameStateValues *pSavedGameStateArray = nullptr;
	//int32_t *pSavedGameStateNumOfPossibleSubsequentMoves = nullptr;
	int32_t *pNumOfPossibleSubsequentMovesArray = nullptr;

	int32_t MaxDistBasedEvaluationValue = -1000000;
	int32_t LowestDistBasedEvaluationValue = -1000000;
	int32_t LastEvaluationValue = -1000000;
	
	CGameStateValues ActualGameState;
	CGameStateValues TestVisitedGameState;

	CRandomNumbersNN RandomNumbers_Movement;
	//CRandomNumbersNN RandomNumbers_Evaluation;

	CSokobanPuzzle Puzzle;
	int32_t NumOfPathFindingSearchStepsMax = 100;

	// Definition eines Methodenzeiger-Typs:
	typedef bool(CSimpleSokobanSolver::*pPullMoveFunc)(int8_t *pActualGameStateData, int32_t boxID);

	pPullMoveFunc PullMoveFunctionArray[4];
	
	int32_t InitialPlayerPosX = 0;
	int32_t InitialPlayerPosY = 0;

	bool PuzzleSolved = false;

	
	
	CSimpleSokobanSolver();
	~CSimpleSokobanSolver();

	// Kopierkonstruktor l�schen:
	CSimpleSokobanSolver(const CSimpleSokobanSolver  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CSimpleSokobanSolver & operator=(const CSimpleSokobanSolver  &originalObject) = delete;

	void Set_Puzzles(CSokobanPuzzle *pInitial_Puzzle, CSokobanPuzzle *pPuzzle_Solved);

	bool Make_PullMove(int32_t searchDepthMax, float distEvaluationBasedWeightingFactor, float visitedGameStateStatusValueIncrease, float visitedGameStateStatusValueDecrease);

private:

	void Increase_StatusValue_Of_Visited_GameState(CGameStateValues *pActualVisitedGameState, float value);
	void Decrease_StatusValues_Of_Visited_GameStates(float value);

	float Evaluate_TestGameState(float distEvaluationBasedWeightingFactor);

	void Update_ActualGameState(void);

	void Restart_with_Solved_Puzzle(void);

	bool Check_If_ActualGameState_Is_Discarded(void);
	void Discard_ActualGameState(void);
	
	bool Check_If_GameState_Is_Discarded(CGameStateValues *pGameState);
	void Discard_GameState(CGameStateValues *pGameState);

	bool Make_TestPullMove_If_Possible(int32_t testMoveNumber, int32_t selectedBoxID);


	bool Check_If_BoxIsPermanentlyBlockedForPullMove(int32_t boxPosID, int8_t *pActualGameStateData);
	int32_t Calc_DistanceBasedEvaluationValue(void);
	
	//void Determine_NextTestMove(int32_t *pOutIDofMovingBox, int32_t *pOutMovementDir);

	void Update_BoxCharacteristics(int8_t *pActualGameStateData);
	void Update_PosBasedBoxCharacteristicsOnly(int8_t *pActualGameStateData);

	void Get_PlayerPosition(int8_t *pActualGameStateData);

	bool Check_PossibleBoxPlacementIdentity(CGameStateValues *pGameState1, CGameStateValues *pGameState2);

	bool Check_If_Puzzle_Is_Solved(CGameStateValues *pGameState);

	// achtung: hier werden nur unmittelbare deadlocks gefunden!!!!
	bool Check_PlayerDeadLock(int8_t *pActualGameStateData);

	bool Make_LeftPullMove(int8_t *pInOutActualGameStateData, int32_t boxID);
	bool Make_RightPullMove(int8_t *pInOutActualGameStateData, int32_t boxID);
	bool Make_UpwardPullMove(int8_t *pInOutActualGameStateData, int32_t boxID);
	bool Make_DownwardPullMove(int8_t *pInOutActualGameStateData, int32_t boxID);
};



#endif