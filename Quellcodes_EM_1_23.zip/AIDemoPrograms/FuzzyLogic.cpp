#include "FuzzyLogic.h"

using namespace std;

CGaussianFuzzyElement::CGaussianFuzzyElement()
{}

CGaussianFuzzyElement::~CGaussianFuzzyElement()
{
	delete[] pRBFFactorArray;
	pRBFFactorArray = nullptr;
	delete[] pFunctionParamArray;
	pFunctionParamArray = nullptr;
	delete[] pCentroidArray;
	pCentroidArray = nullptr;
}

void CGaussianFuzzyElement::Set_ValueWithMaxMembership(float value)
{
	ValueWithMaxMembership = value;
}

void CGaussianFuzzyElement::Initialize(int32_t numOfCentroids)
{
	delete[] pRBFFactorArray;
	pRBFFactorArray = nullptr;
	delete[] pFunctionParamArray;
	pFunctionParamArray = nullptr;
	delete[] pCentroidArray;
	pCentroidArray = nullptr;

	NumOfCentroids = numOfCentroids;

	pRBFFactorArray = new (std::nothrow) float[NumOfCentroids];
	pFunctionParamArray = new (std::nothrow) float[NumOfCentroids];
	pCentroidArray = new (std::nothrow) float[NumOfCentroids];
}

void CGaussianFuzzyElement::Initialize(int32_t numOfCentroids, float* pRBFFactors, float* pFunctionParams, float* pCentroids)
{
	delete[] pRBFFactorArray;
	pRBFFactorArray = nullptr;
	delete[] pFunctionParamArray;
	pFunctionParamArray = nullptr;
	delete[] pCentroidArray;
	pCentroidArray = nullptr;

	NumOfCentroids = numOfCentroids;

	pRBFFactorArray = new (std::nothrow) float[NumOfCentroids];
	pFunctionParamArray = new (std::nothrow) float[NumOfCentroids];
	pCentroidArray = new (std::nothrow) float[NumOfCentroids];

	for (int32_t i = 0; i < NumOfCentroids; i++)
	{
		pRBFFactorArray[i] = pRBFFactors[i];
		pFunctionParamArray[i] = pFunctionParams[i];
		pCentroidArray[i] = pCentroids[i];
	}
}

void CGaussianFuzzyElement::Update_Data(float* pRBFFactors, float* pFunctionParams, float* pCentroids)
{
	for (int32_t i = 0; i < NumOfCentroids; i++)
	{
		pRBFFactorArray[i] = pRBFFactors[i];
		pFunctionParamArray[i] = pFunctionParams[i];
		pCentroidArray[i] = pCentroids[i];
	}
}

float CGaussianFuzzyElement::Calculate_Membership(float input)
{
	return GaussianRBF_1D(input, pRBFFactorArray, pCentroidArray, pFunctionParamArray, NumOfCentroids);
}

float CGaussianFuzzyElement::Calculate_Membership(float input, float maxUpperMembershipValue)
{
	return min(maxUpperMembershipValue, GaussianRBF_1D(input, pRBFFactorArray, pCentroidArray, pFunctionParamArray, NumOfCentroids));
}

float CGaussianFuzzyElement::Calculate_Membership_And_Consider_MaxUpperMembershipValue(float input)
{
	return min(ActualUsedMaxUpperMembershipValue, GaussianRBF_1D(input, pRBFFactorArray, pCentroidArray, pFunctionParamArray, NumOfCentroids));
}

// necessary for fuzzy rule evaluation:
void CGaussianFuzzyElement::Set_MaxUpperMembershipValue(float value)
{
	ActualUsedMaxUpperMembershipValue = value;
}

// necessary for fuzzy rule evaluation:
void CGaussianFuzzyElement::AddTo_MaxUpperMembershipValue(float value)
{
	ActualUsedMaxUpperMembershipValue += value;
	ActualUsedMaxUpperMembershipValue = min(1.0f, ActualUsedMaxUpperMembershipValue);
}

// necessary for fuzzy rule evaluation:
void CGaussianFuzzyElement::Reset_MaxUpperMembershipValue(void)
{
	ActualUsedMaxUpperMembershipValue = 1;
}


CAsymmetricGaussianFuzzyElement::CAsymmetricGaussianFuzzyElement()
{}

CAsymmetricGaussianFuzzyElement::~CAsymmetricGaussianFuzzyElement()
{
	delete[] pRBFFactorArray_LeftHalf;
	pRBFFactorArray_LeftHalf = nullptr;
	delete[] pRBFFactorArray_RightHalf;
	pRBFFactorArray_RightHalf = nullptr;
	delete[] pFunctionParamArray;
	pFunctionParamArray = nullptr;
	delete[] pCentroidArray;
	pCentroidArray = nullptr;
}

void CAsymmetricGaussianFuzzyElement::Set_ValueWithMaxMembership(float value)
{
	ValueWithMaxMembership = value;
}

void CAsymmetricGaussianFuzzyElement::Initialize(int32_t numOfCentroids)
{
	delete[] pRBFFactorArray_LeftHalf;
	pRBFFactorArray_LeftHalf = nullptr;
	delete[] pRBFFactorArray_RightHalf;
	pRBFFactorArray_RightHalf = nullptr;
	delete[] pFunctionParamArray;
	pFunctionParamArray = nullptr;
	delete[] pCentroidArray;
	pCentroidArray = nullptr;

	NumOfCentroids = numOfCentroids;

	pRBFFactorArray_LeftHalf = new (std::nothrow) float[NumOfCentroids];
	pRBFFactorArray_RightHalf = new (std::nothrow) float[NumOfCentroids];
	pFunctionParamArray = new (std::nothrow) float[NumOfCentroids];
	pCentroidArray = new (std::nothrow) float[NumOfCentroids];
}

void CAsymmetricGaussianFuzzyElement::Initialize(int32_t numOfCentroids, float* pRBFFactors_LeftHalf, float* pRBFFactors_RightHalf, float* pFunctionParams, float* pCentroids)
{
	delete[] pRBFFactorArray_LeftHalf;
	pRBFFactorArray_LeftHalf = nullptr;
	delete[] pRBFFactorArray_RightHalf;
	pRBFFactorArray_RightHalf = nullptr;
	delete[] pFunctionParamArray;
	pFunctionParamArray = nullptr;
	delete[] pCentroidArray;
	pCentroidArray = nullptr;

	NumOfCentroids = numOfCentroids;

	pRBFFactorArray_LeftHalf = new (std::nothrow) float[NumOfCentroids];
	pRBFFactorArray_RightHalf = new (std::nothrow) float[NumOfCentroids];
	pFunctionParamArray = new (std::nothrow) float[NumOfCentroids];
	pCentroidArray = new (std::nothrow) float[NumOfCentroids];

	for (int32_t i = 0; i < NumOfCentroids; i++)
	{
		pRBFFactorArray_LeftHalf[i] = pRBFFactors_LeftHalf[i];
		pRBFFactorArray_RightHalf[i] = pRBFFactors_RightHalf[i];
		pFunctionParamArray[i] = pFunctionParams[i];
		pCentroidArray[i] = pCentroids[i];
	}
}

void CAsymmetricGaussianFuzzyElement::Update_Data(float* pRBFFactors_LeftHalf, float* pRBFFactors_RightHalf, float* pFunctionParams, float* pCentroids)
{
	for (int32_t i = 0; i < NumOfCentroids; i++)
	{
		pRBFFactorArray_LeftHalf[i] = pRBFFactors_LeftHalf[i];
		pRBFFactorArray_RightHalf[i] = pRBFFactors_RightHalf[i];
		pFunctionParamArray[i] = pFunctionParams[i];
		pCentroidArray[i] = pCentroids[i];
	}
}

float CAsymmetricGaussianFuzzyElement::Calculate_Membership(float input)
{
	return AsymmetricGaussianRBF_1D(input, pRBFFactorArray_LeftHalf, pRBFFactorArray_RightHalf, pCentroidArray, pFunctionParamArray, NumOfCentroids);
}

float CAsymmetricGaussianFuzzyElement::Calculate_Membership(float input, float maxUpperMembershipValue)
{
	return min(maxUpperMembershipValue, AsymmetricGaussianRBF_1D(input, pRBFFactorArray_LeftHalf, pRBFFactorArray_RightHalf, pCentroidArray, pFunctionParamArray, NumOfCentroids));
}

float CAsymmetricGaussianFuzzyElement::Calculate_Membership_And_Consider_MaxUpperMembershipValue(float input)
{
	return min(ActualUsedMaxUpperMembershipValue, AsymmetricGaussianRBF_1D(input, pRBFFactorArray_LeftHalf, pRBFFactorArray_RightHalf, pCentroidArray, pFunctionParamArray, NumOfCentroids));
}

// necessary for fuzzy rule evaluation:
void CAsymmetricGaussianFuzzyElement::Set_MaxUpperMembershipValue(float value)
{
	ActualUsedMaxUpperMembershipValue = value;
}

// necessary for fuzzy rule evaluation:
void CAsymmetricGaussianFuzzyElement::AddTo_MaxUpperMembershipValue(float value)
{
	ActualUsedMaxUpperMembershipValue += value;
	ActualUsedMaxUpperMembershipValue = min(1.0f, ActualUsedMaxUpperMembershipValue);
}

// necessary for fuzzy rule evaluation:
void CAsymmetricGaussianFuzzyElement::Reset_MaxUpperMembershipValue(void)
{
	ActualUsedMaxUpperMembershipValue = 1;
}


CGaussianFuzzyRepresentation::CGaussianFuzzyRepresentation()
{}

CGaussianFuzzyRepresentation::~CGaussianFuzzyRepresentation()
{
	delete[] pElementArray;
	pElementArray = nullptr;

	delete[] pMembershipValueArray;
	pMembershipValueArray = nullptr;

	delete[] pNormalizedMembershipValueArray;
	pNormalizedMembershipValueArray = nullptr;
}

void CGaussianFuzzyRepresentation::Initialize(int32_t numOfElements)
{
	delete[] pElementArray;
	pElementArray = nullptr;

	delete[] pMembershipValueArray;
	pMembershipValueArray = nullptr;

	delete[] pNormalizedMembershipValueArray;
	pNormalizedMembershipValueArray = nullptr;

	NumOfElements = numOfElements;

	pElementArray = new (std::nothrow) CGaussianFuzzyElement[NumOfElements];
	pMembershipValueArray = new (std::nothrow) float[NumOfElements];
	pNormalizedMembershipValueArray = new (std::nothrow) float[NumOfElements];
}

void CGaussianFuzzyRepresentation::Initialize_Element(int32_t elementID, int32_t numOfCentroids)
{
	pElementArray[elementID].Initialize(numOfCentroids);
}

void CGaussianFuzzyRepresentation::Initialize_Element(int32_t elementID, int32_t numOfCentroids, float* pRBFFactors, float* pFunctionParams, float* pCentroids)
{
	pElementArray[elementID].Initialize(numOfCentroids, pRBFFactors, pFunctionParams, pCentroids);
}

void CGaussianFuzzyRepresentation::Update_Element(int32_t elementID, float* pRBFFactors, float* pFunctionParams, float* pCentroids)
{
	pElementArray[elementID].Update_Data(pRBFFactors, pFunctionParams, pCentroids);
}

void CGaussianFuzzyRepresentation::Calculate_MembershipValues(float input)
{
	for (int32_t i = 0; i < NumOfElements; i++)
	{
		pMembershipValueArray[i] = pElementArray[i].Calculate_Membership(input);
		pElementArray[i].Set_MaxUpperMembershipValue(pMembershipValueArray[i]);
	}
}

void CGaussianFuzzyRepresentation::Normalize_MembershipValues(void)
{
	float length = 0.0001f;

	for (int32_t i = 0; i < NumOfElements; i++)
	{
		length += pMembershipValueArray[i];
	}

	float InvLength = 1.0f / length;

	for (int32_t i = 0; i < NumOfElements; i++)
	{
		pNormalizedMembershipValueArray[i] = InvLength * pMembershipValueArray[i];
		pElementArray[i].Set_MaxUpperMembershipValue(pNormalizedMembershipValueArray[i]);
	}
}

float CGaussianFuzzyRepresentation::Calculate_MaxMembership_And_Consider_MaxUpperMembershipValues(float input)
{
	float maxMembership = 0.0f;

	for (int32_t i = 0; i < NumOfElements; i++)
	{
		float membership = pElementArray[i].Calculate_Membership_And_Consider_MaxUpperMembershipValue(input);
		maxMembership = max(maxMembership, membership);
	}

	return maxMembership;
}

void CGaussianFuzzyRepresentation::Prepare_FuzzyRulesEvaluation(void)
{
	for (int32_t i = 0; i < NumOfElements; i++)
	{
		pElementArray[i].Reset_MaxUpperMembershipValue();
	}
}

void CGaussianFuzzyRepresentation::Add_RuleEvaluationResult(int32_t elementID, float resultingMemberShip)
{
	pElementArray[elementID].AddTo_MaxUpperMembershipValue(resultingMemberShip);
}

float CGaussianFuzzyRepresentation::Calculate_CrispOutput_UseMaxMembershipValues(void)
{
	float membershipSum = 0.000001f;
	float nonNormalizedCrispOutput = 0.0f;

	for (int32_t i = 0; i < NumOfElements; i++)
	{
		float maxUpperMembershipValue = pElementArray[i].ActualUsedMaxUpperMembershipValue;
		membershipSum += maxUpperMembershipValue;
		nonNormalizedCrispOutput += maxUpperMembershipValue * pElementArray[i].ValueWithMaxMembership;
	}

	return nonNormalizedCrispOutput / membershipSum;
}


float CGaussianFuzzyRepresentation::Calculate_CrispOutput(float minInput, float maxInput, int32_t numOfcalculationSteps)
{
	float deltaInput = (maxInput - minInput) / static_cast<float>(numOfcalculationSteps);
	numOfcalculationSteps++;

	float membershipSum = 0.000001f;
	float nonNormalizedCrispOutput = 0.0f;
	float input = minInput;

	for (int32_t i = 0; i < numOfcalculationSteps; i++)
	{
		float membership = Calculate_MaxMembership_And_Consider_MaxUpperMembershipValues(input);
		membershipSum += membership;
		nonNormalizedCrispOutput += input * membership;
		input += deltaInput;
	}

	return nonNormalizedCrispOutput / membershipSum;
}


float CGaussianFuzzyRepresentation::Calculate_CrispOutput(float minInput, float maxInput, CRandomNumbersNN* pRandomNumbers, int32_t numOfcalculationSteps)
{
	float membershipSum = 0.000001f;
	float nonNormalizedCrispOutput = 0.0f;

	for (int32_t i = 0; i < numOfcalculationSteps; i++)
	{
		float input = pRandomNumbers->Get_FloatNumber_IncludingZero(minInput, maxInput);

		float membership = Calculate_MaxMembership_And_Consider_MaxUpperMembershipValues(input);
		membershipSum += membership;
		nonNormalizedCrispOutput += input * membership;
	}

	return nonNormalizedCrispOutput / membershipSum;
}

float CGaussianFuzzyRepresentation::Get_MaxMembership(void)
{
	float maxMembership = 0.0f;

	for (int32_t i = 0; i < NumOfElements; i++)
	{
		maxMembership = max(maxMembership, pMembershipValueArray[i]);
	}

	return maxMembership;
}

void CGaussianFuzzyRepresentation::Get_MaxMembership(float* pOutValue, int32_t* pOutBelongingElementID)
{
	float maxMembership = 0.0f;
	int32_t belongingElementID = -1;

	for (int32_t i = 0; i < NumOfElements; i++)
	{
		float membership = pMembershipValueArray[i];

		if (membership >= maxMembership)
		{
			maxMembership = membership;
			belongingElementID = i;
		}
	}

	*pOutValue = maxMembership;
	*pOutBelongingElementID = belongingElementID;
}

float CGaussianFuzzyRepresentation::Get_MaxNormalizedMembership(void)
{
	float maxMembership = 0.0f;

	for (int32_t i = 0; i < NumOfElements; i++)
	{
		maxMembership = max(maxMembership, pNormalizedMembershipValueArray[i]);
	}

	return maxMembership;
}

void CGaussianFuzzyRepresentation::Get_MaxNormalizedMembership(float* pOutValue, int32_t* pOutBelongingElementID)
{
	float maxMembership = 0.0f;
	int32_t belongingElementID = -1;

	for (int32_t i = 0; i < NumOfElements; i++)
	{
		float membership = pNormalizedMembershipValueArray[i];

		if (membership >= maxMembership)
		{
			maxMembership = membership;
			belongingElementID = i;
		}
	}

	*pOutValue = maxMembership;
	*pOutBelongingElementID = belongingElementID;
}

float CGaussianFuzzyRepresentation::Get_MinMembership(void)
{
	float minMembership = 1.0f;

	for (int32_t i = 0; i < NumOfElements; i++)
	{
		minMembership = min(minMembership, pMembershipValueArray[i]);
	}

	return minMembership;
}

void CGaussianFuzzyRepresentation::Get_MinMembership(float* pOutValue, int32_t* pOutBelongingElementID)
{
	float minMembership = 1.0f;
	int32_t belongingElementID = -1;

	for (int32_t i = 0; i < NumOfElements; i++)
	{
		float membership = pMembershipValueArray[i];

		if (membership <= minMembership)
		{
			minMembership = membership;
			belongingElementID = i;
		}
	}

	*pOutValue = minMembership;
	*pOutBelongingElementID = belongingElementID;
}

float CGaussianFuzzyRepresentation::Get_MinNormalizedMembership(void)
{
	float minMembership = 1.0f;

	for (int32_t i = 0; i < NumOfElements; i++)
	{
		minMembership = min(minMembership, pNormalizedMembershipValueArray[i]);
	}

	return minMembership;
}


void CGaussianFuzzyRepresentation::Get_MinNormalizedMembership(float* pOutValue, int32_t* pOutBelongingElementID)
{
	float minMembership = 1.0f;
	int32_t belongingElementID = -1;

	for (int32_t i = 0; i < NumOfElements; i++)
	{
		float membership = pNormalizedMembershipValueArray[i];

		if (membership <= minMembership)
		{
			minMembership = membership;
			belongingElementID = i;
		}
	}

	*pOutValue = minMembership;
	*pOutBelongingElementID = belongingElementID;
}





CAsymmetricGaussianFuzzyRepresentation::CAsymmetricGaussianFuzzyRepresentation()
{}

CAsymmetricGaussianFuzzyRepresentation::~CAsymmetricGaussianFuzzyRepresentation()
{
	delete[] pElementArray;
	pElementArray = nullptr;

	delete[] pMembershipValueArray;
	pMembershipValueArray = nullptr;

	delete[] pNormalizedMembershipValueArray;
	pNormalizedMembershipValueArray = nullptr;
}

void CAsymmetricGaussianFuzzyRepresentation::Initialize(int32_t numOfElements)
{
	delete[] pElementArray;
	pElementArray = nullptr;

	delete[] pMembershipValueArray;
	pMembershipValueArray = nullptr;

	delete[] pNormalizedMembershipValueArray;
	pNormalizedMembershipValueArray = nullptr;

	NumOfElements = numOfElements;

	pElementArray = new (std::nothrow) CAsymmetricGaussianFuzzyElement[NumOfElements];
	pMembershipValueArray = new (std::nothrow) float[NumOfElements];
	pNormalizedMembershipValueArray = new (std::nothrow) float[NumOfElements];
}

void CAsymmetricGaussianFuzzyRepresentation::Initialize_Element(int32_t elementID, int32_t numOfCentroids)
{
	pElementArray[elementID].Initialize(numOfCentroids);
}

void CAsymmetricGaussianFuzzyRepresentation::Initialize_Element(int32_t elementID, int32_t numOfCentroids, float* pRBFFactors_LeftHalf, float* pRBFFactors_RightHalf, float* pFunctionParams, float* pCentroids)
{
	pElementArray[elementID].Initialize(numOfCentroids, pRBFFactors_LeftHalf, pRBFFactors_RightHalf, pFunctionParams, pCentroids);
}

void CAsymmetricGaussianFuzzyRepresentation::Update_Element(int32_t elementID, float* pRBFFactors_LeftHalf, float* pRBFFactors_RightHalf, float* pFunctionParams, float* pCentroids)
{
	pElementArray[elementID].Update_Data(pRBFFactors_LeftHalf, pRBFFactors_RightHalf, pFunctionParams, pCentroids);
}

void CAsymmetricGaussianFuzzyRepresentation::Calculate_MembershipValues(float input)
{
	for (int32_t i = 0; i < NumOfElements; i++)
	{
		pMembershipValueArray[i] = pElementArray[i].Calculate_Membership(input);
		pElementArray[i].Set_MaxUpperMembershipValue(pMembershipValueArray[i]);
	}
}

void CAsymmetricGaussianFuzzyRepresentation::Normalize_MembershipValues(void)
{
	float length = 0.0001f;

	for (int32_t i = 0; i < NumOfElements; i++)
	{
		length += pMembershipValueArray[i];
	}

	float InvLength = 1.0f / length;

	for (int32_t i = 0; i < NumOfElements; i++)
	{
		pNormalizedMembershipValueArray[i] = InvLength * pMembershipValueArray[i];
		pElementArray[i].Set_MaxUpperMembershipValue(pNormalizedMembershipValueArray[i]);
	}
}

float CAsymmetricGaussianFuzzyRepresentation::Calculate_MaxMembership_And_Consider_MaxUpperMembershipValues(float input)
{
	float maxMembership = 0.0f;

	for (int32_t i = 0; i < NumOfElements; i++)
	{
		float membership = pElementArray[i].Calculate_Membership_And_Consider_MaxUpperMembershipValue(input);
		maxMembership = max(maxMembership, membership);
	}

	return maxMembership;
}

void CAsymmetricGaussianFuzzyRepresentation::Prepare_FuzzyRulesEvaluation(void)
{
	for (int32_t i = 0; i < NumOfElements; i++)
	{
		pElementArray[i].Reset_MaxUpperMembershipValue();
	}
}

void CAsymmetricGaussianFuzzyRepresentation::Add_RuleEvaluationResult(int32_t elementID, float resultingMemberShip)
{
	pElementArray[elementID].AddTo_MaxUpperMembershipValue(resultingMemberShip);
}

float CAsymmetricGaussianFuzzyRepresentation::Calculate_CrispOutput_UseMaxMembershipValues(void)
{
	float membershipSum = 0.000001f;
	float nonNormalizedCrispOutput = 0.0f;

	for (int32_t i = 0; i < NumOfElements; i++)
	{
		float maxUpperMembershipValue = pElementArray[i].ActualUsedMaxUpperMembershipValue;
		membershipSum += maxUpperMembershipValue;
		nonNormalizedCrispOutput += maxUpperMembershipValue * pElementArray[i].ValueWithMaxMembership;
	}

	return nonNormalizedCrispOutput / membershipSum;
}


float CAsymmetricGaussianFuzzyRepresentation::Calculate_CrispOutput(float minInput, float maxInput, int32_t numOfcalculationSteps)
{
	float deltaInput = (maxInput - minInput) / static_cast<float>(numOfcalculationSteps);
	numOfcalculationSteps++;

	float membershipSum = 0.000001f;
	float nonNormalizedCrispOutput = 0.0f;
	float input = minInput;

	for (int32_t i = 0; i < numOfcalculationSteps; i++)
	{
		float membership = Calculate_MaxMembership_And_Consider_MaxUpperMembershipValues(input);
		membershipSum += membership;
		nonNormalizedCrispOutput += input * membership;
		input += deltaInput;
	}

	return nonNormalizedCrispOutput / membershipSum;
}


float CAsymmetricGaussianFuzzyRepresentation::Calculate_CrispOutput(float minInput, float maxInput, CRandomNumbersNN* pRandomNumbers, int32_t numOfcalculationSteps)
{
	float membershipSum = 0.000001f;
	float nonNormalizedCrispOutput = 0.0f;

	for (int32_t i = 0; i < numOfcalculationSteps; i++)
	{
		float input = pRandomNumbers->Get_FloatNumber_IncludingZero(minInput, maxInput);

		float membership = Calculate_MaxMembership_And_Consider_MaxUpperMembershipValues(input);
		membershipSum += membership;
		nonNormalizedCrispOutput += input * membership;
	}

	return nonNormalizedCrispOutput / membershipSum;
}

float CAsymmetricGaussianFuzzyRepresentation::Get_MaxMembership(void)
{
	float maxMembership = 0.0f;

	for (int32_t i = 0; i < NumOfElements; i++)
	{
		maxMembership = max(maxMembership, pMembershipValueArray[i]);
	}

	return maxMembership;
}

void CAsymmetricGaussianFuzzyRepresentation::Get_MaxMembership(float* pOutValue, int32_t* pOutBelongingElementID)
{
	float maxMembership = 0.0f;
	int32_t belongingElementID = -1;

	for (int32_t i = 0; i < NumOfElements; i++)
	{
		float membership = pMembershipValueArray[i];

		if (membership >= maxMembership)
		{
			maxMembership = membership;
			belongingElementID = i;
		}
	}

	*pOutValue = maxMembership;
	*pOutBelongingElementID = belongingElementID;
}

float CAsymmetricGaussianFuzzyRepresentation::Get_MaxNormalizedMembership(void)
{
	float maxMembership = 0.0f;

	for (int32_t i = 0; i < NumOfElements; i++)
	{
		maxMembership = max(maxMembership, pNormalizedMembershipValueArray[i]);
	}

	return maxMembership;
}

void CAsymmetricGaussianFuzzyRepresentation::Get_MaxNormalizedMembership(float* pOutValue, int32_t* pOutBelongingElementID)
{
	float maxMembership = 0.0f;
	int32_t belongingElementID = -1;

	for (int32_t i = 0; i < NumOfElements; i++)
	{
		float membership = pNormalizedMembershipValueArray[i];

		if (membership >= maxMembership)
		{
			maxMembership = membership;
			belongingElementID = i;
		}
	}

	*pOutValue = maxMembership;
	*pOutBelongingElementID = belongingElementID;
}

float CAsymmetricGaussianFuzzyRepresentation::Get_MinMembership(void)
{
	float minMembership = 1.0f;

	for (int32_t i = 0; i < NumOfElements; i++)
	{
		minMembership = min(minMembership, pMembershipValueArray[i]);
	}

	return minMembership;
}

void CAsymmetricGaussianFuzzyRepresentation::Get_MinMembership(float* pOutValue, int32_t* pOutBelongingElementID)
{
	float minMembership = 1.0f;
	int32_t belongingElementID = -1;

	for (int32_t i = 0; i < NumOfElements; i++)
	{
		float membership = pMembershipValueArray[i];

		if (membership <= minMembership)
		{
			minMembership = membership;
			belongingElementID = i;
		}
	}

	*pOutValue = minMembership;
	*pOutBelongingElementID = belongingElementID;
}

float CAsymmetricGaussianFuzzyRepresentation::Get_MinNormalizedMembership(void)
{
	float minMembership = 1.0f;

	for (int32_t i = 0; i < NumOfElements; i++)
	{
		minMembership = min(minMembership, pNormalizedMembershipValueArray[i]);
	}

	return minMembership;
}


void CAsymmetricGaussianFuzzyRepresentation::Get_MinNormalizedMembership(float* pOutValue, int32_t* pOutBelongingElementID)
{
	float minMembership = 1.0f;
	int32_t belongingElementID = -1;

	for (int32_t i = 0; i < NumOfElements; i++)
	{
		float membership = pNormalizedMembershipValueArray[i];

		if (membership <= minMembership)
		{
			minMembership = membership;
			belongingElementID = i;
		}
	}

	*pOutValue = minMembership;
	*pOutBelongingElementID = belongingElementID;
}




CFuzzyRule_GaussianElements::CFuzzyRule_GaussianElements()
{}

CFuzzyRule_GaussianElements::~CFuzzyRule_GaussianElements()
{
	delete[] ppAntecedentElementArray;
	ppAntecedentElementArray = nullptr;
}

void CFuzzyRule_GaussianElements::Initialize(int32_t numOfAntecedents)
{
	delete[] ppAntecedentElementArray;
	ppAntecedentElementArray = nullptr;

	NumOfAntecedents = numOfAntecedents;

	ppAntecedentElementArray = new (std::nothrow) CGaussianFuzzyElement * [NumOfAntecedents];

	for (int32_t i = 0; i < NumOfAntecedents; i++)
	{
		ppAntecedentElementArray[i] = nullptr;
	}

	pConsequenceElement = nullptr;
}

void CFuzzyRule_GaussianElements::Set_ConsequenceElement(CGaussianFuzzyElement* pElement)
{
	pConsequenceElement = pElement;
}

void CFuzzyRule_GaussianElements::Set_AntecedentElement(int32_t elementID, CGaussianFuzzyElement* pElement)
{
	ppAntecedentElementArray[elementID] = pElement;
}

void CFuzzyRule_GaussianElements::Evaluate_FuzzyAND_Rule(void)
{
	float resultingMembershipValue = ppAntecedentElementArray[0]->ActualUsedMaxUpperMembershipValue;

	for (int32_t i = 1; i < NumOfAntecedents; i++)
	{
		resultingMembershipValue = min(resultingMembershipValue, ppAntecedentElementArray[i]->ActualUsedMaxUpperMembershipValue);
	}

	pConsequenceElement->AddTo_MaxUpperMembershipValue(resultingMembershipValue);
}

void CFuzzyRule_GaussianElements::Evaluate_FuzzyOR_Rule(void)
{
	float resultingMembershipValue = ppAntecedentElementArray[0]->ActualUsedMaxUpperMembershipValue;

	for (int32_t i = 1; i < NumOfAntecedents; i++)
	{
		resultingMembershipValue = max(resultingMembershipValue, ppAntecedentElementArray[i]->ActualUsedMaxUpperMembershipValue);
	}

	pConsequenceElement->AddTo_MaxUpperMembershipValue(resultingMembershipValue);
}


CFuzzyRule_AsymmetricGaussianElements::CFuzzyRule_AsymmetricGaussianElements()
{}

CFuzzyRule_AsymmetricGaussianElements::~CFuzzyRule_AsymmetricGaussianElements()
{
	delete[] ppAntecedentElementArray;
	ppAntecedentElementArray = nullptr;
}

void CFuzzyRule_AsymmetricGaussianElements::Initialize(int32_t numOfAntecedents)
{
	delete[] ppAntecedentElementArray;
	ppAntecedentElementArray = nullptr;

	NumOfAntecedents = numOfAntecedents;

	ppAntecedentElementArray = new (std::nothrow) CAsymmetricGaussianFuzzyElement * [NumOfAntecedents];

	for (int32_t i = 0; i < NumOfAntecedents; i++)
	{
		ppAntecedentElementArray[i] = nullptr;
	}

	pConsequenceElement = nullptr;
}

void CFuzzyRule_AsymmetricGaussianElements::Set_ConsequenceElement(CAsymmetricGaussianFuzzyElement* pElement)
{
	pConsequenceElement = pElement;
}

void CFuzzyRule_AsymmetricGaussianElements::Set_AntecedentElement(int32_t elementID, CAsymmetricGaussianFuzzyElement* pElement)
{
	ppAntecedentElementArray[elementID] = pElement;
}

void CFuzzyRule_AsymmetricGaussianElements::Evaluate_FuzzyAND_Rule(void)
{
	float resultingMembershipValue = ppAntecedentElementArray[0]->ActualUsedMaxUpperMembershipValue;

	for (int32_t i = 1; i < NumOfAntecedents; i++)
	{
		resultingMembershipValue = min(resultingMembershipValue, ppAntecedentElementArray[i]->ActualUsedMaxUpperMembershipValue);
	}

	pConsequenceElement->AddTo_MaxUpperMembershipValue(resultingMembershipValue);
}

void CFuzzyRule_AsymmetricGaussianElements::Evaluate_FuzzyOR_Rule(void)
{
	float resultingMembershipValue = ppAntecedentElementArray[0]->ActualUsedMaxUpperMembershipValue;

	for (int32_t i = 1; i < NumOfAntecedents; i++)
	{
		resultingMembershipValue = max(resultingMembershipValue, ppAntecedentElementArray[i]->ActualUsedMaxUpperMembershipValue);
	}

	pConsequenceElement->AddTo_MaxUpperMembershipValue(resultingMembershipValue);
}
