// Schutz vor Mehrfachdeklarationen:

#ifndef _NeuralNet_H_
#define _NeuralNet_H_

#include <iostream>
#include <fstream>
#include "LogFile.h"

#ifndef max
#define max(a,b)    ( ((a) > (b)) ? (a) : (b) )
#endif

#ifndef min
#define min(a,b)    ( ((a) < (b)) ? (a) : (b) )
#endif

#define UseNoImagePooling      0
#define UseImageMaxPooling2x2  1
#define UseImageL2Pooling2x2   2


//sigmoid(x) = 0.5f + 0.25f*x - 1.0f/48.0f*x*x*x + 1.0f/480.0f*x*x*x*x*x
// tanh(x) = x - 1.0f/3.0f*x*x*x+2.0f/15.0f**x*x*x*x*x


inline float SigmoidActivationFunc(float neuronInput)
{
	// von 0.0f bis 1.0f:
	return 1.0f / (1.0f + exp(-neuronInput));
}

inline float ScaledSigmoidActivationFunc(float neuronInput)
{
	// von 0.0f bis 1.0f:
	return 1.0f / (1.0f + exp(-10.0f * neuronInput));
}

inline float SineActivationFunc(float neuronInput)
{
	// von -1.0f bis 1.0f:
	return sin(neuronInput);
}

inline float CosineActivationFunc(float neuronInput)
{
	// von -1.0f bis 1.0f:
	return cos(neuronInput);
}


inline float TanHActivationFunc(float neuronInput)
{
	// von -1.0f bis 1.0f:
	return tanh(neuronInput);
}

inline float ScaledTanHActivationFunc(float neuronInput)
{
	return tanh(0.1f * neuronInput);
}

inline float FastTanHReplacementActivationFunc(float neuronInput)
{
	// von -1.0f bis 1.0f:
	return neuronInput / (1.0f + abs(neuronInput));
}

inline float ReLUActivationFunc(float neuronInput)
{
	// von 0.0f bis unendlich:
	return max(0.0f, neuronInput);

	/*if (neuronInput < 0.0f)
	return 0.01f * neuronInput;
	else
	return neuronInput;*/
}

inline float ClippedReLUActivationFunc(float neuronInput)
{
	if (neuronInput < 0.0f)
		return 0.0f;
	else
	{
		return min(1.0f, neuronInput);
	}
}

inline float LeakyReLUActivationFunc(float neuronInput)
{
	if (neuronInput < 0.0f)
		return 0.01f * neuronInput;
	else
		return neuronInput;
}

inline float ClippedLeakyReLUActivationFunc(float neuronInput)
{
	if (neuronInput < 0.0f)
		return max(-1.0f, 0.01f * neuronInput);
	else
	{
		return min(1.0f, neuronInput);
	}
}



inline float BinaryOutputActivationFunc1(float neuronInput)
{
	//if (neuronInput > 0.9999f)
	//return 1.0f;

	// less accuracy
	if (neuronInput > 0.9f)
		return 1.0f;

	return 0.0f;
}

inline float BinaryOutputActivationFunc2(float neuronInput)
{
	if (neuronInput > 0.4999f)
		return 1.0f;

	return 0.0f;
}


inline float ClippedLinearActivationFunc(float neuronInput)
{
	if (neuronInput > 1.0f)
		neuronInput = 1.0f;
	else if (neuronInput < -1.0f)
		neuronInput = -1.0f;

	return neuronInput;
}

inline float LinearActivationFunc(float neuronInput)
{
	return neuronInput;
}

inline float NegLinearActivationFunc(float neuronInput)
{
	return -neuronInput;
}


inline float RBFActivationFunc(/*scaledRBFCentroidDistanceSqSum*/ float neuronInput)
{
	return exp(-neuronInput);
}

static float g_StepwiseNeuronOutputArray[100];

inline float StepwiseOutput(float neuronInput)
{
	float offset = 1.0f;

	int32_t id = 10.0f*(neuronInput + offset);

	id = max(id, 0);
	id = min(id, 99);

	return g_StepwiseNeuronOutputArray[id];
}


inline float ConstantError(float neuronOutput)
{
	return 1.0f;
}

inline float LinearError(float neuronOutput)
{
	return neuronOutput;
}

inline float GaussianError(float neuronOutput)
{
	return exp(-(neuronOutput*neuronOutput));
}

inline float DerivedSigmoidError(float neuronOutput)
{
	return neuronOutput * (1.0f - neuronOutput);
}


// Definition eines Funktionszeiger-Typs:
typedef float(*pActivationFunc)(float inputActivity);

// Definition eines Funktionszeiger-Typs:
typedef float(*pErrorFunc)(float neuronOutput);


/*inline uint8_t* Read_Bitmap_BGR(const char* pFilename)
{
	FILE* pFile = fopen(pFilename, "rb");
	uint8_t info[54];
	fread(info, sizeof(uint8_t), 54, pFile); // read bitmap header

											   // extract image height and width from header
	int32_t width = *(int32_t*)&info[18];
	int32_t height = *(int32_t*)&info[22];

	int32_t size = 3 * width * height; //  3 color channels
	uint8_t* pData = new (std::nothrow) uint8_t[size];
	fread(pData, sizeof(uint8_t), size, pFile);
	fclose(pFile);

	return pData;
}*/

inline uint8_t* Read_Bitmap_BGR(const char* pFilename)
{
	FILE* pFile = fopen(pFilename, "rb");

	int32_t width, height, padding, bitcount, size;
	uint8_t info[54] = { 0 };

	fread(info, 1, 54, pFile);
	width = *(int32_t*)(info + 18);
	height = *(int32_t*)(info + 22);
	bitcount = *(int32_t*)(info + 28);
	size = ((width * bitcount + 31) / 32) * 4 * height;
	padding = width % 4;

	uint8_t* pTempData = new (std::nothrow) uint8_t[size];

	fread(pTempData, 1, size, pFile);

	uint8_t* pData = new (std::nothrow) uint8_t[3 * width * height];

	int32_t id;
	int32_t counter = 0;

	for (int32_t row = 0; row < height; row++)
	{
		for (int32_t col = 0; col < width; col++)
		{
			id = (row * width + col) * 3 + row * padding;

			pData[counter++] = pTempData[id + 0];
			pData[counter++] = pTempData[id + 1];
			pData[counter++] = pTempData[id + 2];

		}
	}

	delete[] pTempData;
	pTempData = nullptr;

	fclose(pFile);

	return pData;
}

inline void Get_ImageData_RedChannel(float *pOutputArray, const uint8_t *pImageData, int32_t sizeX, int32_t sizeY, float dataBiasValue = 0.0f)
{
	int32_t ix, iy, iy2, id;

	int32_t counter = 2;

	for (iy = sizeY - 1; iy > -1; iy--)
	{
		iy2 = iy * sizeX;

		for (ix = 0; ix < sizeX; ix++)
		{
			id = ix + iy2;

			pOutputArray[id] = static_cast<float>(pImageData[counter]);
			pOutputArray[id] += dataBiasValue;

			counter += 3;
		}
	}
}

inline void Get_BinaryImageData_RedChannel(float *pOutputArray, const uint8_t *pImageData, int32_t sizeX, int32_t sizeY, bool use_0_And_1_Values = true)
{
	int32_t ix, iy, iy2, id;

	int32_t counter = 2;

	for (iy = sizeY - 1; iy > -1; iy--)
	{
		iy2 = iy * sizeX;

		for (ix = 0; ix < sizeX; ix++)
		{
			id = ix + iy2;

			pOutputArray[id] = static_cast<float>(pImageData[counter]);

			pOutputArray[id] = min(1.0f, pOutputArray[id]);

			counter += 3;
		}
	}

	if (use_0_And_1_Values == false)
	{
		int32_t size = sizeX * sizeY;

		for (int32_t i = 0; i < size; i++)
		{
			if (pOutputArray[i] == 0.0f)
				pOutputArray[i] = -1.0f;
		}
	}
}

inline void Get_ImageData_GreenChannel(float *pOutputArray, const uint8_t *pImageData, int32_t sizeX, int32_t sizeY, float dataBiasValue = 0.0f)
{
	int32_t ix, iy, iy2, id;

	int32_t counter = 1;

	for (iy = sizeY - 1; iy > -1; iy--)
	{
		iy2 = iy * sizeX;

		for (ix = 0; ix < sizeX; ix++)
		{
			id = ix + iy2;

			pOutputArray[id] = static_cast<float>(pImageData[counter]);
			pOutputArray[id] += dataBiasValue;

			counter += 3;
		}
	}
}

inline void Get_BinaryImageData_GreenChannel(float *pOutputArray, const uint8_t *pImageData, int32_t sizeX, int32_t sizeY, bool use_0_And_1_Values = true)
{
	int32_t ix, iy, iy2, id;

	int32_t counter = 1;

	for (iy = sizeY - 1; iy > -1; iy--)
	{
		iy2 = iy * sizeX;

		for (ix = 0; ix < sizeX; ix++)
		{
			id = ix + iy2;

			pOutputArray[id] = static_cast<float>(pImageData[counter]);

			pOutputArray[id] = min(1.0f, pOutputArray[id]);

			counter += 3;
		}
	}

	if (use_0_And_1_Values == false)
	{
		int32_t size = sizeX * sizeY;

		for (int32_t i = 0; i < size; i++)
		{
			if (pOutputArray[i] == 0.0f)
				pOutputArray[i] = -1.0f;
		}
	}
}

inline void Get_ImageData_BlueChannel(float *pOutputArray, const uint8_t *pImageData, int32_t sizeX, int32_t sizeY, float dataBiasValue = 0.0f)
{
	int32_t ix, iy, iy2, id;

	int32_t counter = 0;

	for (iy = sizeY - 1; iy > -1; iy--)
	{
		iy2 = iy * sizeX;

		for (ix = 0; ix < sizeX; ix++)
		{
			id = ix + iy2;

			pOutputArray[id] = static_cast<float>(pImageData[counter]);
			pOutputArray[id] += dataBiasValue;

			counter += 3;
		}
	}
}

inline void Get_BinaryImageData_BlueChannel(float *pOutputArray, const uint8_t *pImageData, int32_t sizeX, int32_t sizeY, bool use_0_And_1_Values = true)
{
	int32_t ix, iy, iy2, id;

	int32_t counter = 0;

	for (iy = sizeY - 1; iy > -1; iy--)
	{
		iy2 = iy * sizeX;

		for (ix = 0; ix < sizeX; ix++)
		{
			id = ix + iy2;

			pOutputArray[id] = static_cast<float>(pImageData[counter]);

			pOutputArray[id] = min(1.0f, pOutputArray[id]);

			counter += 3;
		}
	}

	if (use_0_And_1_Values == false)
	{
		int32_t size = sizeX * sizeY;

		for (int32_t i = 0; i < size; i++)
		{
			if (pOutputArray[i] == 0.0f)
				pOutputArray[i] = -1.0f;
		}
	}
}



inline void Output_RawImageData(float *pImage, uint32_t sizeX, uint32_t sizeY)
{
	uint32_t iy, ix, id, iy2;

	for (iy = 0; iy < sizeY; iy++)
	{
		iy2 = iy * sizeX;

		for (ix = 0; ix < sizeX; ix++)
		{
			id = ix + iy2;

			std::cout << pImage[id] << " ";
		}

		std::cout << std::endl;
	}
}

inline void Output_PosImageData(float *pImage, uint32_t sizeX, uint32_t sizeY)
{
	uint32_t iy, ix, id, iy2;

	for (iy = 0; iy < sizeY; iy++)
	{
		iy2 = iy * sizeX;

		for (ix = 0; ix < sizeX; ix++)
		{
			id = ix + iy2;

			std::cout << max(0.0f, pImage[id]) << " ";
		}

		std::cout << std::endl;
	}
}

inline void Output_BinaryImageData(float *pImage, uint32_t sizeX, uint32_t sizeY)
{
	uint32_t iy, ix, id, iy2;

	for (iy = 0; iy < sizeY; iy++)
	{
		iy2 = iy * sizeX;

		for (ix = 0; ix < sizeX; ix++)
		{
			id = ix + iy2;

			if (pImage[id] > 0.0f)
				std::cout << 1 << " ";
			else
				std::cout << 0 << " ";
		}

		std::cout << std::endl;
	}
}

inline void Output_BinaryImageData2(float *pImage, uint32_t sizeX, uint32_t sizeY)
{
	uint32_t iy, ix, id, iy2;

	for (iy = 0; iy < sizeY; iy++)
	{
		iy2 = iy * sizeX;

		for (ix = 0; ix < sizeX; ix++)
		{
			id = ix + iy2;

			if (pImage[id] > 0.0f)
				std::cout << 1 << " ";
			else
				std::cout << "  ";
		}

		std::cout << std::endl;
	}
}

inline void NearestPointImageScaling(float* pOutputImage, int32_t outputSizeX, int32_t outputSizeY, const float *pInputImage, int32_t inputSizeX, int32_t inputSizeY)
{
	int32_t iiy_OutputImage;
	int32_t iiy_InputImage;

	for (int32_t iy = 0; iy < outputSizeY; iy++)
	{
		iiy_OutputImage = iy * outputSizeX;
		iiy_InputImage = inputSizeY * iy / outputSizeY * inputSizeX;

		for (int32_t ix = 0; ix < outputSizeX; ix++)
			pOutputImage[ix + iiy_OutputImage] = pInputImage[inputSizeX * ix / outputSizeX + iiy_InputImage];
	}
}




inline void Scale_Data(float *pInputOutputArray, /*numArrayElements:*/ uint32_t arraySize, float scaleFactor)
{
	for (uint32_t i = 0; i < arraySize; i++)
		pInputOutputArray[i] *= scaleFactor;
}

inline void Scale_Data(float *pOutputArray, const float *pInputArray, /*numArrayElements:*/ uint32_t arraySize, float scaleFactor)
{
	for (uint32_t i = 0; i < arraySize; i++)
		pOutputArray[i] = scaleFactor * pInputArray[i];
}


inline void Init_1DimArray(float *pInputOutputArray, /*numArrayElements:*/ uint32_t arraySize, float value)
{
	for (uint32_t i = 0; i < arraySize; i++)
		pInputOutputArray[i] = value;
}

inline void Copy_1DimArray(float *pOutputArray, const float *pInputArray, /*numArrayElements:*/ uint32_t arraySize)
{
	for (uint32_t i = 0; i < arraySize; i++)
		pOutputArray[i] = pInputArray[i];
}

inline void Init_2DimArray(float *pInputOutputArray, uint32_t arraySizeX, uint32_t arraySizeY, float value)
{
	uint32_t numArrayElements = arraySizeX * arraySizeY;

	for (uint32_t i = 0; i < numArrayElements; i++)
		pInputOutputArray[i] = value;
}

inline void Copy_2DimArray(float *pOutputArray, const float *pInputArray, uint32_t arraySizeX, uint32_t arraySizeY)
{
	uint32_t numArrayElements = arraySizeX * arraySizeY;

	for (uint32_t i = 0; i < numArrayElements; i++)
		pOutputArray[i] = pInputArray[i];
}


inline void Copy_FromInputToOutputArray(float *pOutputArray, uint32_t outputArraySizeX, const float *pInputArray, uint32_t inputArraySizeX, uint32_t inputArraySizeY, uint32_t copySizeX, uint32_t copySizeY, uint32_t inputArrayOffsetX, uint32_t inputArrayOffsetY)
{
	uint32_t ixInputMin = inputArrayOffsetX;
	uint32_t ixInputMax = min(inputArraySizeX,  ixInputMin + copySizeX);

	uint32_t iyInputMin = inputArrayOffsetY;
	uint32_t iyInputMax = min(inputArraySizeY, iyInputMin + copySizeY);

	uint32_t ixInput, iyInput, iiy_input, iiy_output;
	

	uint32_t counterX = 0;
	uint32_t counterY = 0;
	

	for (iyInput = iyInputMin; iyInput < iyInputMax; iyInput++)
	{
		iiy_output = outputArraySizeX * counterY;
		iiy_input = inputArraySizeX * iyInput;

		counterX = 0;

		for (ixInput = ixInputMin; ixInput < ixInputMax; ixInput++)
		{
			pOutputArray[counterX + iiy_output] = pInputArray[ixInput + iiy_input];
			counterX++;
		}

		counterY++;
	}
}

inline void Copy_FromInputToOutputArray(float *pOutputArray, uint32_t outputArraySizeX, uint32_t outputArrayOffsetX, uint32_t outputArrayOffsetY, const float *pInputArray, uint32_t inputArraySizeX, uint32_t inputArraySizeY, uint32_t copySizeX, uint32_t copySizeY, uint32_t inputArrayOffsetX, uint32_t inputArrayOffsetY)
{
	uint32_t ixInputMin = inputArrayOffsetX;
	uint32_t ixInputMax = min(inputArraySizeX, ixInputMin + copySizeX);

	uint32_t iyInputMin = inputArrayOffsetY;
	uint32_t iyInputMax = min(inputArraySizeY, iyInputMin + copySizeY);

	uint32_t ixInput, iyInput, iiy_input, iiy_output;


	uint32_t counterX = outputArrayOffsetX;
	uint32_t counterY = outputArrayOffsetY;


	for (iyInput = iyInputMin; iyInput < iyInputMax; iyInput++)
	{
		iiy_output = outputArraySizeX * counterY;
		iiy_input = inputArraySizeX * iyInput;

		counterX = outputArrayOffsetX;

		for (ixInput = ixInputMin; ixInput < ixInputMax; ixInput++)
		{
			pOutputArray[counterX + iiy_output] = pInputArray[ixInput + iiy_input];
			counterX++;
		}

		counterY++;
	}
}


inline void Copy_FromInputToOutputArray(float *pOutputArray, const float *pInputArray, uint32_t inputArraySize, uint32_t copySize, uint32_t inputArrayOffset)
{
	uint32_t inputMin = inputArrayOffset;
	uint32_t inputMax = min(inputArraySize, inputMin + copySize);

	uint32_t counter = 0;

	for (uint32_t i = inputMin; i < inputMax; i++)
	{
		pOutputArray[counter] = pInputArray[i];
		counter++;
	}
}

inline void Copy_FromInputToOutputArray(float *pOutputArray, uint32_t outputArrayOffset, const float *pInputArray, uint32_t inputArraySize, uint32_t copySize, uint32_t inputArrayOffset)
{
	uint32_t inputMin = inputArrayOffset;
	uint32_t inputMax = min(inputArraySize, inputMin + copySize);

	uint32_t counter = outputArrayOffset;

	for (uint32_t i = inputMin; i < inputMax; i++)
	{
		pOutputArray[counter] = pInputArray[i];
		counter++;
	}
}


// old resolution => new resolution
// 32x32 => 16x16
// 30x30 => 15x15
// 15x15 => 8x8

inline void Bisect_Resolution(float *pOutputArray, const float *pInputArray, uint32_t inputArraySizeX, uint32_t inputArraySizeY)
{
	uint32_t inputArraySizeXMinus1 = inputArraySizeX - 1;
	uint32_t inputArraySizeYMinus1 = inputArraySizeY - 1;

	uint32_t ixInput, iyInput, tempIy1, tempIy2, idInput;
	uint32_t ixInputPlus1, iyInputPlus1;
	uint32_t counter = 0;

	float tempValue;

	for (iyInput = 0; iyInput < inputArraySizeY; iyInput += 2)
	{
		tempIy1 = inputArraySizeX*iyInput;
		iyInputPlus1 = min(inputArraySizeYMinus1, (iyInput + 1));
		tempIy2 = inputArraySizeX*iyInputPlus1;

		for (ixInput = 0; ixInput < inputArraySizeX; ixInput += 2)
		{
			ixInputPlus1 = min(inputArraySizeXMinus1, (ixInput + 1));

			idInput = ixInput + tempIy1;
			tempValue = pInputArray[idInput];

			idInput = ixInputPlus1 + tempIy1;
			tempValue += pInputArray[idInput];

			idInput = ixInput + tempIy2;
			tempValue += pInputArray[idInput];

			idInput = ixInputPlus1 + tempIy2;
			tempValue += pInputArray[idInput];

			tempValue *= 0.25f;

			pOutputArray[counter] = tempValue;
			counter++;
		}
	}
}

inline void Bisect_Resolution(float *pOutputArray, const float *pInputArray, uint32_t inputArraySize)
{
	uint32_t inputArraySizeMinus1 = inputArraySize - 1;
	
	uint32_t inputPlus1;

	uint32_t counter = 0;

	float tempValue;

	for (uint32_t i = 0; i < inputArraySize; i += 2)
	{
		inputPlus1 = min(inputArraySizeMinus1, (i + 1));

		tempValue = pInputArray[i];
		tempValue += pInputArray[inputPlus1];

		tempValue *= 0.5f;

		pOutputArray[counter] = tempValue;
		counter++;
	}
}


inline void MaxPooling2x2(float *pOutputArray, const float *pInputArray, uint32_t inputArraySizeX, uint32_t inputArraySizeY)
{
	uint32_t inputArraySizeXMinus1 = inputArraySizeX - 1;
	uint32_t inputArraySizeYMinus1 = inputArraySizeY - 1;

	
	uint32_t ixInput, iyInput, tempIy1, tempIy2, idInput;
	uint32_t ixInputPlus1, iyInputPlus1;
	uint32_t counter = 0;

	float maxValue;

	for (iyInput = 0; iyInput < inputArraySizeY; iyInput += 2)
	{
		tempIy1 = inputArraySizeX*iyInput;
		iyInputPlus1 = min(inputArraySizeYMinus1, (iyInput + 1));
		tempIy2 = inputArraySizeX*iyInputPlus1;

		for (ixInput = 0; ixInput < inputArraySizeX; ixInput += 2)
		{
			ixInputPlus1 = min(inputArraySizeXMinus1, (ixInput + 1));

			idInput = ixInput + tempIy1;
			maxValue = pInputArray[idInput];

			idInput = ixInputPlus1 + tempIy1;
			maxValue = max(maxValue, pInputArray[idInput]);

			idInput = ixInput + tempIy2;
			maxValue = max(maxValue, pInputArray[idInput]);

			idInput = ixInputPlus1 + tempIy2;
			maxValue = max(maxValue, pInputArray[idInput]);

			pOutputArray[counter] = maxValue;
			counter++;
		}
	}
}

inline void MaxPooling2x1(float *pOutputArray, const float *pInputArray, uint32_t inputArraySize)
{
	uint32_t inputArraySizeMinus1 = inputArraySize - 1;

	uint32_t inputPlus1;

	uint32_t counter = 0;

	float maxValue;

	for (uint32_t i = 0; i < inputArraySize; i += 2)
	{
		inputPlus1 = min(inputArraySizeMinus1, (i + 1));

		maxValue = pInputArray[i];
		maxValue = max(maxValue, pInputArray[inputPlus1]);
		
		pOutputArray[counter] = maxValue;
		counter++;
	}
}


inline void L2Pooling2x2(float *pOutputArray, const float *pInputArray, uint32_t inputArraySizeX, uint32_t inputArraySizeY)
{
	uint32_t inputArraySizeXMinus1 = inputArraySizeX - 1;
	uint32_t inputArraySizeYMinus1 = inputArraySizeY - 1;

	uint32_t ixInput, iyInput, tempIy1, tempIy2, idInput;
	uint32_t ixInputPlus1, iyInputPlus1;
	uint32_t counter = 0;

	float tempValue, tempValue2;

	for (iyInput = 0; iyInput < inputArraySizeY; iyInput += 2)
	{
		tempIy1 = inputArraySizeX*iyInput;
		iyInputPlus1 = min(inputArraySizeYMinus1, (iyInput + 1));
		tempIy2 = inputArraySizeX*iyInputPlus1;

		for (ixInput = 0; ixInput < inputArraySizeX; ixInput += 2)
		{
			ixInputPlus1 = min(inputArraySizeXMinus1, (ixInput + 1));

			idInput = ixInput + tempIy1;
			tempValue2 = pInputArray[idInput];
			tempValue = tempValue2 * tempValue2;

			idInput = ixInputPlus1 + tempIy1;
			tempValue2 = pInputArray[idInput];
			tempValue += tempValue2 * tempValue2;

			idInput = ixInput + tempIy2;
			tempValue2 = pInputArray[idInput];
			tempValue += tempValue2 * tempValue2;

			idInput = ixInputPlus1 + tempIy2;
			tempValue2 = pInputArray[idInput];
			tempValue += tempValue2 * tempValue2;

			pOutputArray[counter] = sqrt(tempValue);
			counter++;
		}
	}
}

inline void L2Pooling2x1(float *pOutputArray, const float *pInputArray, uint32_t inputArraySize)
{
	uint32_t inputArraySizeMinus1 = inputArraySize - 1;

	uint32_t inputPlus1;

	uint32_t counter = 0;

	float tempValue, tempValue2;

	for (uint32_t i = 0; i < inputArraySize; i += 2)
	{
		inputPlus1 = min(inputArraySizeMinus1, (i + 1));

		tempValue2 = pInputArray[i];
		tempValue = tempValue2 * tempValue2;

		tempValue2 = pInputArray[inputPlus1];
		tempValue += tempValue2 * tempValue2;

		pOutputArray[counter] = sqrt(tempValue);
		counter++;
	}
}




inline void Calculate_FeatureMap(float *pFeatureMap, const float *pInputArray, int32_t inputArraySizeX, int32_t inputArraySizeY,
	const float *pKernelValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY)
{
	if (kernelSizeX == inputArraySizeX && kernelSizeY == inputArraySizeY)
	{
		int32_t Size = kernelSizeX * kernelSizeY;

		float inputValue, kernelValue, productValue;

		float sumOfProductValues = 0.0f;

		for (uint32_t i = 0; i < Size; i++)
		{
			inputValue = pInputArray[i];
			kernelValue = pKernelValueArray[i];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[0] = sumOfProductValues;

		return;
	}


	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput,iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;
	
	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = 0.0f;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] = sumOfProductValues;
			counter++;
	
		}
	}
}

inline void Calculate_FeatureMap(float *pFeatureMap, const float *pInputArray, int32_t inputArraySizeX, int32_t inputArraySizeY,
	const float *pKernelValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY, pActivationFunc pFunc)
{
	if (kernelSizeX == inputArraySizeX && kernelSizeY == inputArraySizeY)
	{
		int32_t Size = kernelSizeX * kernelSizeY;

		float inputValue, kernelValue, productValue, outputValue;

		float sumOfProductValues = 0.0f;

		for (uint32_t i = 0; i < Size; i++)
		{
			inputValue = pInputArray[i];
			kernelValue = pKernelValueArray[i];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		outputValue = pFunc(sumOfProductValues);

		pFeatureMap[0] = outputValue;

		return;
	}

	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = 0.0f;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] = pFunc(sumOfProductValues);
			counter++;

		}
	}
}


inline void Calculate_FeatureMap(float *pFeatureMap, const float *pInputArray, int32_t inputArraySize, 
	const float *pKernelValueArray, int32_t kernelSize, int32_t stride)
{
	if (kernelSize == inputArraySize)
	{
		float inputValue, kernelValue, productValue;

		float sumOfProductValues = 0.0f;

		for (uint32_t i = 0; i < kernelSize; i++)
		{
			inputValue = pInputArray[i];
			kernelValue = pKernelValueArray[i];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[0] = sumOfProductValues;

		return;
	}

	int32_t halfKernelSize = kernelSize / 2;
	
	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = 0.0f;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] = sumOfProductValues;
		counter++;
	}
}

inline void Calculate_FeatureMap(float *pFeatureMap, const float *pInputArray, int32_t inputArraySize,
	const float *pKernelValueArray, int32_t kernelSize, int32_t stride, pActivationFunc pFunc)
{
	if (kernelSize == inputArraySize)
	{
		float inputValue, kernelValue, productValue, outputValue;

		float sumOfProductValues = 0.0f;

		for (uint32_t i = 0; i < kernelSize; i++)
		{
			inputValue = pInputArray[i];
			kernelValue = pKernelValueArray[i];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		outputValue = pFunc(sumOfProductValues);

		pFeatureMap[0] = outputValue;

		return;
	}

	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = 0.0f;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] = pFunc(sumOfProductValues);
		counter++;
	}
}



inline void Calculate_FeatureMap2(float *pFeatureMap, const float *pInputArray, int32_t inputArraySizeX, int32_t inputArraySizeY,
	const float *pKernelBiasValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY)
{
	if (kernelSizeX == inputArraySizeX && kernelSizeY == inputArraySizeY)
	{
		int32_t Size = kernelSizeX * kernelSizeY;

		float bias = pKernelBiasValueArray[Size];

		float inputValue, kernelValue, productValue;

		float sumOfProductValues = bias;
		//float sumOfProductValues = 0.0f;

		for (uint32_t i = 0; i < Size; i++)
		{
			inputValue = pInputArray[i];
			kernelValue = pKernelBiasValueArray[i];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[0] = sumOfProductValues;

		return;
	}

	int32_t kernelBiasEntryID = kernelSizeX * kernelSizeY;

	float bias = pKernelBiasValueArray[kernelBiasEntryID];

	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = bias;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelBiasValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] = sumOfProductValues;
			counter++;

		}
	}
}

inline void Calculate_FeatureMap2(float *pFeatureMap, const float *pInputArray, int32_t inputArraySizeX, int32_t inputArraySizeY,
	const float *pKernelBiasValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY, pActivationFunc pFunc)
{
	if (kernelSizeX == inputArraySizeX && kernelSizeY == inputArraySizeY)
	{
		int32_t Size = kernelSizeX * kernelSizeY;

		float inputValue, kernelValue, productValue, outputValue;

		float sumOfProductValues = pKernelBiasValueArray[Size];
		
		for (uint32_t i = 0; i < Size; i++)
		{
			inputValue = pInputArray[i];
			kernelValue = pKernelBiasValueArray[i];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		outputValue = pFunc(sumOfProductValues);

		pFeatureMap[0] = outputValue;

		return;
	}

	int32_t kernelBiasEntryID = kernelSizeX * kernelSizeY;

	float bias = pKernelBiasValueArray[kernelBiasEntryID];

	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = bias;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelBiasValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] = pFunc(sumOfProductValues);
			counter++;

		}
	}
}


inline void Calculate_FeatureMap2(float *pFeatureMap, const float *pInputArray, int32_t inputArraySize,
	const float *pKernelBiasValueArray, int32_t kernelSize, int32_t stride)
{
	if (kernelSize == inputArraySize)
	{
		float inputValue, kernelValue, productValue;

		float sumOfProductValues = pKernelBiasValueArray[kernelSize];

		for (uint32_t i = 0; i < kernelSize; i++)
		{
			inputValue = pInputArray[i];
			kernelValue = pKernelBiasValueArray[i];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[0] = sumOfProductValues;

		return;
	}

	int32_t kernelBiasEntryID = kernelSize;

	float bias = pKernelBiasValueArray[kernelBiasEntryID];

	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = bias;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelBiasValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] = sumOfProductValues;
		counter++;
	}
}

inline void Calculate_FeatureMap2(float *pFeatureMap, const float *pInputArray, int32_t inputArraySize,
	const float *pKernelBiasValueArray, int32_t kernelSize, int32_t stride, pActivationFunc pFunc)
{
	if (kernelSize == inputArraySize)
	{
		float inputValue, kernelValue, productValue, outputValue;

		float sumOfProductValues = pKernelBiasValueArray[kernelSize];

		for (uint32_t i = 0; i < kernelSize; i++)
		{
			inputValue = pInputArray[i];
			kernelValue = pKernelBiasValueArray[i];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		outputValue = pFunc(sumOfProductValues);

		pFeatureMap[0] = outputValue;

		return;
	}

	int32_t kernelBiasEntryID = kernelSize;

	float bias = pKernelBiasValueArray[kernelBiasEntryID];

	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = bias;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelBiasValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] = pFunc(sumOfProductValues);
		counter++;
	}
}


inline void Calculate_FeatureMap(float *pFeatureMap, const float *pInputArray, int32_t inputArraySizeX, int32_t inputArraySizeY,
	const float *pKernelValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY, float bias)
{
	if (kernelSizeX == inputArraySizeX && kernelSizeY == inputArraySizeY)
	{
		int32_t Size = kernelSizeX * kernelSizeY;

		float inputValue, kernelValue, productValue;

		float sumOfProductValues = bias;
		

		for (uint32_t i = 0; i < Size; i++)
		{
			inputValue = pInputArray[i];
			kernelValue = pKernelValueArray[i];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[0] = sumOfProductValues;

		return;
	}

	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = bias;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] = sumOfProductValues;
			counter++;

		}
	}
}

inline void Calculate_FeatureMap(float *pFeatureMap, const float *pInputArray, int32_t inputArraySizeX, int32_t inputArraySizeY,
	const float *pKernelValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY, float bias, pActivationFunc pFunc)
{
	if (kernelSizeX == inputArraySizeX && kernelSizeY == inputArraySizeY)
	{
		int32_t Size = kernelSizeX * kernelSizeY;

		float inputValue, kernelValue, productValue, outputValue;

		float sumOfProductValues = bias;
		

		for (uint32_t i = 0; i < Size; i++)
		{
			inputValue = pInputArray[i];
			kernelValue = pKernelValueArray[i];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		outputValue = pFunc(sumOfProductValues);

		pFeatureMap[0] = outputValue;

		return;
	}

	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = bias;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] = pFunc(sumOfProductValues);
			counter++;

		}
	}
}


inline void Calculate_FeatureMap(float *pFeatureMap, const float *pInputArray, int32_t inputArraySize, 
	const float *pKernelValueArray, int32_t kernelSize, int32_t stride, float bias)
{
	if (kernelSize == inputArraySize)
	{
		float inputValue, kernelValue, productValue;

		float sumOfProductValues = bias;

		for (uint32_t i = 0; i < kernelSize; i++)
		{
			inputValue = pInputArray[i];
			kernelValue = pKernelValueArray[i];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[0] = sumOfProductValues;

		return;
	}

	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = bias;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] = sumOfProductValues;
		counter++;
	}
}

inline void Calculate_FeatureMap(float *pFeatureMap, const float *pInputArray, int32_t inputArraySize,
	const float *pKernelValueArray, int32_t kernelSize, int32_t stride, float bias, pActivationFunc pFunc)
{
	if (kernelSize == inputArraySize)
	{
		float inputValue, kernelValue, productValue, outputValue;

		float sumOfProductValues = bias;

		for (uint32_t i = 0; i < kernelSize; i++)
		{
			inputValue = pInputArray[i];
			kernelValue = pKernelValueArray[i];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		outputValue = pFunc(sumOfProductValues);

		pFeatureMap[0] = outputValue;

		return;
	}

	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = bias;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] = pFunc(sumOfProductValues);
		counter++;
	}
}



inline void Add_Feature_To_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputArraySizeX, int32_t inputArraySizeY,
	const float *pKernelValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY)
{
	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = 0.0f;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] += sumOfProductValues;
			counter++;
		}
	}
}

inline void Add_Feature_To_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputArraySizeX, int32_t inputArraySizeY,
	const float *pKernelValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY, pActivationFunc pFunc)
{
	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = 0.0f;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] += pFunc(sumOfProductValues);
			counter++;
		}
	}
}


inline void Add_Feature_To_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputArraySize,
	const float *pKernelValueArray, int32_t kernelSize, int32_t stride)
{
	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = 0.0f;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] += sumOfProductValues;
		counter++;
	}
}

inline void Add_Feature_To_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputArraySize,
	const float *pKernelValueArray, int32_t kernelSize, int32_t stride, pActivationFunc pFunc)
{
	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = 0.0f;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] += pFunc(sumOfProductValues);
		counter++;
	}
}

inline void Add_Feature_To_FeatureMap2(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputArraySizeX, int32_t inputArraySizeY,
	const float *pKernelBiasValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY)
{
	int32_t kernelBiasEntryID = kernelSizeX * kernelSizeY;

	float bias = pKernelBiasValueArray[kernelBiasEntryID];

	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = bias;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelBiasValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] += sumOfProductValues;
			counter++;
		}
	}
}

inline void Add_Feature_To_FeatureMap2(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputArraySizeX, int32_t inputArraySizeY,
	const float *pKernelBiasValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY, pActivationFunc pFunc)
{
	int32_t kernelBiasEntryID = kernelSizeX * kernelSizeY;

	float bias = pKernelBiasValueArray[kernelBiasEntryID];

	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = bias;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelBiasValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] += pFunc(sumOfProductValues);
			counter++;
		}
	}
}


inline void Add_Feature_To_FeatureMap2(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputArraySize, 
	const float *pKernelBiasValueArray, int32_t kernelSize,  int32_t stride)
{
	int32_t kernelBiasEntryID = kernelSize;

	float bias = pKernelBiasValueArray[kernelBiasEntryID];

	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = bias;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelBiasValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] += sumOfProductValues;
		counter++;
	}
}


inline void Add_Feature_To_FeatureMap2(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputArraySize,
	const float *pKernelBiasValueArray, int32_t kernelSize, int32_t stride, pActivationFunc pFunc)
{
	int32_t kernelBiasEntryID = kernelSize;

	float bias = pKernelBiasValueArray[kernelBiasEntryID];

	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = bias;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelBiasValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] += pFunc(sumOfProductValues);
		counter++;
	}
}


inline void Add_Feature_To_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputArraySizeX, int32_t inputArraySizeY,
	const float *pKernelValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY, float bias)
{
	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = bias;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] += sumOfProductValues;
			counter++;
		}
	}
}

inline void Add_Feature_To_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputArraySizeX, int32_t inputArraySizeY,
	const float *pKernelValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY, float bias, pActivationFunc pFunc)
{
	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = bias;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] += pFunc(sumOfProductValues);
			counter++;
		}
	}
}


inline void Add_Feature_To_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputArraySize,
	const float *pKernelValueArray, int32_t kernelSize, int32_t stride, float bias)
{
	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = bias;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] += sumOfProductValues;
		counter++;
	}
}

inline void Add_Feature_To_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputArraySize,
	const float *pKernelValueArray, int32_t kernelSize, int32_t stride, float bias, pActivationFunc pFunc)
{
	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = bias;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] += pFunc(sumOfProductValues);
		counter++;
	}
}


inline void Calculate_FeatureMap(float *pFeatureMap, const float *pInputArray, int32_t inputSizeX, int32_t inputSizeY,
	int32_t paddingSizeX, int32_t paddingSizeY, const float *pKernelValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY)
{
	int32_t inputArraySizeX = inputSizeX + 2 * paddingSizeX;
	int32_t inputArraySizeY = inputSizeY + 2 * paddingSizeY;

	int32_t featureSizeX = (inputArraySizeX - kernelSizeX) / strideX;
	featureSizeX++;

	int32_t featureSizeY = (inputArraySizeY - kernelSizeY) / strideY;
	featureSizeY++;

	
	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = 0.0f;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelValueArray[ixKernel + halfKernelSizeX + iiyKernel];
					
					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] = sumOfProductValues;
			counter++;
		}
	}
}

inline void Calculate_FeatureMap(float *pFeatureMap, const float *pInputArray, int32_t inputSizeX, int32_t inputSizeY,
	int32_t paddingSizeX, int32_t paddingSizeY, const float *pKernelValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY, pActivationFunc pFunc)
{
	int32_t inputArraySizeX = inputSizeX + 2 * paddingSizeX;
	int32_t inputArraySizeY = inputSizeY + 2 * paddingSizeY;

	int32_t featureSizeX = (inputArraySizeX - kernelSizeX) / strideX;
	featureSizeX++;

	int32_t featureSizeY = (inputArraySizeY - kernelSizeY) / strideY;
	featureSizeY++;


	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = 0.0f;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] = pFunc(sumOfProductValues);
			counter++;
		}
	}
}

inline void Calculate_FeatureMap(float *pFeatureMap, const float *pInputArray, int32_t inputSize,
	int32_t paddingSize, const float *pKernelValueArray, int32_t kernelSize,  int32_t stride)
{
	int32_t inputArraySize = inputSize + 2 * paddingSize;
	
	int32_t featureSize = (inputArraySize - kernelSize) / stride;
	featureSize++;

	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = 0.0f;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] = sumOfProductValues;
		counter++;
	}
}

inline void Calculate_FeatureMap(float *pFeatureMap, const float *pInputArray, int32_t inputSize,
	int32_t paddingSize, const float *pKernelValueArray, int32_t kernelSize, int32_t stride, pActivationFunc pFunc)
{
	int32_t inputArraySize = inputSize + 2 * paddingSize;

	int32_t featureSize = (inputArraySize - kernelSize) / stride;
	featureSize++;

	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = 0.0f;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] = pFunc(sumOfProductValues);
		counter++;
	}
}


inline void Calculate_FeatureMap2(float *pFeatureMap, const float *pInputArray, int32_t inputSizeX, int32_t inputSizeY,
	int32_t paddingSizeX, int32_t paddingSizeY, const float *pKernelBiasValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY)
{
	int32_t kernelBiasEntryID = kernelSizeX * kernelSizeY;

	float bias = pKernelBiasValueArray[kernelBiasEntryID];

	int32_t inputArraySizeX = inputSizeX + 2 * paddingSizeX;
	int32_t inputArraySizeY = inputSizeY + 2 * paddingSizeY;

	int32_t featureSizeX = (inputArraySizeX - kernelSizeX) / strideX;
	featureSizeX++;

	int32_t featureSizeY = (inputArraySizeY - kernelSizeY) / strideY;
	featureSizeY++;


	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = bias;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelBiasValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] = sumOfProductValues;
			counter++;
		}
	}
}

inline void Calculate_FeatureMap2(float *pFeatureMap, const float *pInputArray, int32_t inputSizeX, int32_t inputSizeY,
	int32_t paddingSizeX, int32_t paddingSizeY, const float *pKernelBiasValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY, pActivationFunc pFunc)
{
	int32_t kernelBiasEntryID = kernelSizeX * kernelSizeY;

	float bias = pKernelBiasValueArray[kernelBiasEntryID];

	int32_t inputArraySizeX = inputSizeX + 2 * paddingSizeX;
	int32_t inputArraySizeY = inputSizeY + 2 * paddingSizeY;

	int32_t featureSizeX = (inputArraySizeX - kernelSizeX) / strideX;
	featureSizeX++;

	int32_t featureSizeY = (inputArraySizeY - kernelSizeY) / strideY;
	featureSizeY++;


	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = bias;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelBiasValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] = pFunc(sumOfProductValues);
			counter++;
		}
	}
}

inline void Calculate_FeatureMap2(float *pFeatureMap, const float *pInputArray, int32_t inputSize, 
	int32_t paddingSize,  const float *pKernelBiasValueArray, int32_t kernelSize,  int32_t stride)
{
	int32_t kernelBiasEntryID = kernelSize;

	float bias = pKernelBiasValueArray[kernelBiasEntryID];

	int32_t inputArraySize = inputSize + 2 * paddingSize;

	int32_t featureSize = (inputArraySize - kernelSize) / stride;
	featureSize++;

	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = bias;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelBiasValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] = sumOfProductValues;
		counter++;
	}
}

inline void Calculate_FeatureMap2(float *pFeatureMap, const float *pInputArray, int32_t inputSize,
	int32_t paddingSize, const float *pKernelBiasValueArray, int32_t kernelSize, int32_t stride, pActivationFunc pFunc)
{
	int32_t kernelBiasEntryID = kernelSize;

	float bias = pKernelBiasValueArray[kernelBiasEntryID];

	int32_t inputArraySize = inputSize + 2 * paddingSize;

	int32_t featureSize = (inputArraySize - kernelSize) / stride;
	featureSize++;

	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = bias;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelBiasValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] = pFunc(sumOfProductValues);
		counter++;
	}
}

inline void Calculate_FeatureMap(float *pFeatureMap, const float *pInputArray, int32_t inputSizeX, int32_t inputSizeY,
	int32_t paddingSizeX, int32_t paddingSizeY, const float *pKernelValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY, float bias)
{
	int32_t inputArraySizeX = inputSizeX + 2 * paddingSizeX;
	int32_t inputArraySizeY = inputSizeY + 2 * paddingSizeY;

	int32_t featureSizeX = (inputArraySizeX - kernelSizeX) / strideX;
	featureSizeX++;

	int32_t featureSizeY = (inputArraySizeY - kernelSizeY) / strideY;
	featureSizeY++;


	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = bias;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] = sumOfProductValues;
			counter++;
		}
	}
}

inline void Calculate_FeatureMap(float *pFeatureMap, const float *pInputArray, int32_t inputSizeX, int32_t inputSizeY,
	int32_t paddingSizeX, int32_t paddingSizeY, const float *pKernelValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY, float bias, pActivationFunc pFunc)
{
	int32_t inputArraySizeX = inputSizeX + 2 * paddingSizeX;
	int32_t inputArraySizeY = inputSizeY + 2 * paddingSizeY;

	int32_t featureSizeX = (inputArraySizeX - kernelSizeX) / strideX;
	featureSizeX++;

	int32_t featureSizeY = (inputArraySizeY - kernelSizeY) / strideY;
	featureSizeY++;


	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = bias;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] = pFunc(sumOfProductValues);
			counter++;
		}
	}
}


inline void Calculate_FeatureMap(float *pFeatureMap, const float *pInputArray, int32_t inputSize,
	int32_t paddingSize, const float *pKernelValueArray, int32_t kernelSize, int32_t stride, float bias)
{
	int32_t inputArraySize = inputSize + 2 * paddingSize;

	int32_t featureSize = (inputArraySize - kernelSize) / stride;
	featureSize++;

	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = bias;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] = sumOfProductValues;
		counter++;
	}
}

inline void Calculate_FeatureMap(float *pFeatureMap, const float *pInputArray, int32_t inputSize,
	int32_t paddingSize, const float *pKernelValueArray, int32_t kernelSize, int32_t stride, float bias, pActivationFunc pFunc)
{
	int32_t inputArraySize = inputSize + 2 * paddingSize;

	int32_t featureSize = (inputArraySize - kernelSize) / stride;
	featureSize++;

	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = bias;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] = pFunc(sumOfProductValues);
		counter++;
	}
}


inline void Add_Feature_To_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputSizeX, int32_t inputSizeY,
	int32_t paddingSizeX, int32_t paddingSizeY, const float *pKernelValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY)
{
	int32_t inputArraySizeX = inputSizeX + 2 * paddingSizeX;
	int32_t inputArraySizeY = inputSizeY + 2 * paddingSizeY;

	int32_t featureSizeX = (inputArraySizeX - kernelSizeX) / strideX;
	featureSizeX++;

	int32_t featureSizeY = (inputArraySizeY - kernelSizeY) / strideY;
	featureSizeY++;


	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = 0.0f;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] += sumOfProductValues;
			counter++;
		}
	}
}

inline void Add_Feature_To_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputSizeX, int32_t inputSizeY,
	int32_t paddingSizeX, int32_t paddingSizeY, const float *pKernelValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY, pActivationFunc pFunc)
{
	int32_t inputArraySizeX = inputSizeX + 2 * paddingSizeX;
	int32_t inputArraySizeY = inputSizeY + 2 * paddingSizeY;

	int32_t featureSizeX = (inputArraySizeX - kernelSizeX) / strideX;
	featureSizeX++;

	int32_t featureSizeY = (inputArraySizeY - kernelSizeY) / strideY;
	featureSizeY++;


	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = 0.0f;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] += pFunc(sumOfProductValues);
			counter++;
		}
	}
}


inline void Add_Feature_To_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputSize,
	int32_t paddingSize, const float *pKernelValueArray, int32_t kernelSize, int32_t stride)
{
	int32_t inputArraySize = inputSize + 2 * paddingSize;

	int32_t featureSize = (inputArraySize - kernelSize) / stride;
	featureSize++;

	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = 0.0f;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] += sumOfProductValues;
		counter++;
	}

}

inline void Add_Feature_To_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputSize,
	int32_t paddingSize, const float *pKernelValueArray, int32_t kernelSize, int32_t stride, pActivationFunc pFunc)
{
	int32_t inputArraySize = inputSize + 2 * paddingSize;

	int32_t featureSize = (inputArraySize - kernelSize) / stride;
	featureSize++;

	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = 0.0f;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] += pFunc(sumOfProductValues);
		counter++;
	}

}


inline void Add_Feature_To_FeatureMap2(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputSizeX, int32_t inputSizeY,
	int32_t paddingSizeX, int32_t paddingSizeY, const float *pKernelBiasValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY)
{
	int32_t kernelBiasEntryID = kernelSizeX * kernelSizeY;

	float bias = pKernelBiasValueArray[kernelBiasEntryID];

	int32_t inputArraySizeX = inputSizeX + 2 * paddingSizeX;
	int32_t inputArraySizeY = inputSizeY + 2 * paddingSizeY;

	int32_t featureSizeX = (inputArraySizeX - kernelSizeX) / strideX;
	featureSizeX++;

	int32_t featureSizeY = (inputArraySizeY - kernelSizeY) / strideY;
	featureSizeY++;


	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = bias;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelBiasValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] += sumOfProductValues;
			counter++;
		}
	}
}

inline void Add_Feature_To_FeatureMap2(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputSizeX, int32_t inputSizeY,
	int32_t paddingSizeX, int32_t paddingSizeY, const float *pKernelBiasValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY, pActivationFunc pFunc)
{
	int32_t kernelBiasEntryID = kernelSizeX * kernelSizeY;

	float bias = pKernelBiasValueArray[kernelBiasEntryID];

	int32_t inputArraySizeX = inputSizeX + 2 * paddingSizeX;
	int32_t inputArraySizeY = inputSizeY + 2 * paddingSizeY;

	int32_t featureSizeX = (inputArraySizeX - kernelSizeX) / strideX;
	featureSizeX++;

	int32_t featureSizeY = (inputArraySizeY - kernelSizeY) / strideY;
	featureSizeY++;


	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = bias;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelBiasValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] += pFunc(sumOfProductValues);
			counter++;
		}
	}
}


inline void Add_Feature_To_FeatureMap2(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputSize,
	int32_t paddingSize, const float *pKernelBiasValueArray, int32_t kernelSize, int32_t stride)
{
	int32_t kernelBiasEntryID = kernelSize;

	float bias = pKernelBiasValueArray[kernelBiasEntryID];

	int32_t inputArraySize = inputSize + 2 * paddingSize;

	int32_t featureSize = (inputArraySize - kernelSize) / stride;
	featureSize++;

	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = bias;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelBiasValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] += sumOfProductValues;
		counter++;
	}
}

inline void Add_Feature_To_FeatureMap2(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputSize,
	int32_t paddingSize, const float *pKernelBiasValueArray, int32_t kernelSize, int32_t stride, pActivationFunc pFunc)
{
	int32_t kernelBiasEntryID = kernelSize;

	float bias = pKernelBiasValueArray[kernelBiasEntryID];

	int32_t inputArraySize = inputSize + 2 * paddingSize;

	int32_t featureSize = (inputArraySize - kernelSize) / stride;
	featureSize++;

	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = bias;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelBiasValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] += pFunc(sumOfProductValues);
		counter++;
	}
}


inline void Add_Feature_To_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputSizeX, int32_t inputSizeY,
	int32_t paddingSizeX, int32_t paddingSizeY, const float *pKernelValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY, float bias)
{
	int32_t inputArraySizeX = inputSizeX + 2 * paddingSizeX;
	int32_t inputArraySizeY = inputSizeY + 2 * paddingSizeY;

	int32_t featureSizeX = (inputArraySizeX - kernelSizeX) / strideX;
	featureSizeX++;

	int32_t featureSizeY = (inputArraySizeY - kernelSizeY) / strideY;
	featureSizeY++;


	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = bias;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] += sumOfProductValues;
			counter++;
		}
	}
}

inline void Add_Feature_To_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputSizeX, int32_t inputSizeY,
	int32_t paddingSizeX, int32_t paddingSizeY, const float *pKernelValueArray, int32_t kernelSizeX, int32_t kernelSizeY, int32_t strideX, int32_t strideY, float bias, pActivationFunc pFunc)
{
	int32_t inputArraySizeX = inputSizeX + 2 * paddingSizeX;
	int32_t inputArraySizeY = inputSizeY + 2 * paddingSizeY;

	int32_t featureSizeX = (inputArraySizeX - kernelSizeX) / strideX;
	featureSizeX++;

	int32_t featureSizeY = (inputArraySizeY - kernelSizeY) / strideY;
	featureSizeY++;


	int32_t halfKernelSizeX = kernelSizeX / 2;
	int32_t halfKernelSizeY = kernelSizeY / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t ixInputMax = inputArraySizeX - halfKernelSizeX;
	int32_t iyInputMax = inputArraySizeY - halfKernelSizeY;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = bias;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputArraySizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * kernelSizeX;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputArray[ixInput + ixKernel + iiyInput];
					kernelValue = pKernelValueArray[ixKernel + halfKernelSizeX + iiyKernel];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			pFeatureMap[counter] += pFunc(sumOfProductValues);
			counter++;
		}
	}
}




inline void Add_Feature_To_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputSize, 
	int32_t paddingSize, const float *pKernelValueArray, int32_t kernelSize, int32_t stride, float bias)
{
	int32_t inputArraySize = inputSize + 2 * paddingSize;

	int32_t featureSize = (inputArraySize - kernelSize) / stride;
	featureSize++;

	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = bias;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] += sumOfProductValues;
		counter++;
	}
}

inline void Add_Feature_To_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputSize,
	int32_t paddingSize, const float *pKernelValueArray, int32_t kernelSize, int32_t stride, float bias, pActivationFunc pFunc)
{
	int32_t inputArraySize = inputSize + 2 * paddingSize;

	int32_t featureSize = (inputArraySize - kernelSize) / stride;
	featureSize++;

	int32_t halfKernelSize = kernelSize / 2;

	int32_t iKernelMin = -halfKernelSize;
	int32_t iKernelMax = halfKernelSize + 1;

	int32_t inputMax = inputArraySize - halfKernelSize;

	int32_t iKernel;

	float inputValue, kernelValue, productValue, sumOfProductValues;

	uint32_t counter = 0;

	for (int32_t iInput = halfKernelSize; iInput < inputMax; iInput += stride)
	{
		sumOfProductValues = bias;

		for (iKernel = iKernelMin; iKernel < iKernelMax; iKernel++)
		{
			inputValue = pInputArray[iInput + iKernel];
			kernelValue = pKernelValueArray[iKernel + halfKernelSize];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		pFeatureMap[counter] += pFunc(sumOfProductValues);
		counter++;
	}
}

////////////////////////////////


inline void Add_Bias(float* pOutputData, const float* pInputData, /*numArrayElements:*/ uint32_t arraySize, float bias)
{
	for (uint32_t i = 0; i < arraySize; i++)
		pOutputData[i] = pInputData[i] + bias;
}

inline void Add_Bias(float* pInputOutputData, /*numArrayElements:*/ uint32_t arraySize, float bias)
{
	for (uint32_t i = 0; i < arraySize; i++)
		pInputOutputData[i] = pInputOutputData[i] + bias;
}

inline void Add_Bias(float* pOutputData, const float* pInputData, uint32_t arraySizeX, uint32_t arraySizeY, float bias)
{
	uint32_t numArrayElements = arraySizeX * arraySizeY;

	for (uint32_t i = 0; i < numArrayElements; i++)
		pOutputData[i] = pInputData[i] + bias;
}

inline void Add_Bias(float* pInputOutputData, uint32_t arraySizeX, uint32_t arraySizeY, float bias)
{
	uint32_t numArrayElements = arraySizeX * arraySizeY;

	for (uint32_t i = 0; i < numArrayElements; i++)
		pInputOutputData[i] = pInputOutputData[i] + bias;
}



inline void Modify_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, /*numArrayElements:*/ uint32_t arraySize, pActivationFunc pFunc)
{
	for (uint32_t i = 0; i < arraySize; i++)
		pFeatureMap[i] = pFunc(pFeatureMap[i]);
}

inline void Modify_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, /*numArrayElements:*/ uint32_t arraySize, pActivationFunc pFunc, float bias)
{
	for (uint32_t i = 0; i < arraySize; i++)
		pFeatureMap[i] = pFunc(pFeatureMap[i] + bias);
}

inline void Modify_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, uint32_t arraySizeX, uint32_t arraySizeY, pActivationFunc pFunc)
{
	uint32_t numArrayElements = arraySizeX * arraySizeY;

	for (uint32_t i = 0; i < numArrayElements; i++)
		pFeatureMap[i] = pFunc(pFeatureMap[i]);
}

inline void Modify_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, uint32_t arraySizeX, uint32_t arraySizeY, pActivationFunc pFunc, float bias)
{
	uint32_t numArrayElements = arraySizeX * arraySizeY;

	for (uint32_t i = 0; i < numArrayElements; i++)
		pFeatureMap[i] = pFunc(pFeatureMap[i] + bias);
}

inline void Modify_FeatureMap(float *pOutputFeatureMap, const float *pInputFeatureMap, /*numArrayElements:*/ uint32_t arraySize, pActivationFunc pFunc)
{
	for (uint32_t i = 0; i < arraySize; i++)
		pOutputFeatureMap[i] = pFunc(pInputFeatureMap[i]);
}

inline void Modify_FeatureMap(float *pOutputFeatureMap, const float *pInputFeatureMap, /*numArrayElements:*/ uint32_t arraySize, pActivationFunc pFunc, float bias)
{
	for (uint32_t i = 0; i < arraySize; i++)
		pOutputFeatureMap[i] = pFunc(pInputFeatureMap[i] + bias);
}

inline void Modify_FeatureMap(float *pOutputFeatureMap, const float *pInputFeatureMap, uint32_t arraySizeX, uint32_t arraySizeY, pActivationFunc pFunc)
{
	uint32_t numArrayElements = arraySizeX * arraySizeY;

	for (uint32_t i = 0; i < numArrayElements; i++)
		pOutputFeatureMap[i] = pFunc(pInputFeatureMap[i]);
}

inline void Modify_FeatureMap(float *pOutputFeatureMap, const float *pInputFeatureMap, uint32_t arraySizeX, uint32_t arraySizeY, pActivationFunc pFunc, float bias)
{
	uint32_t numArrayElements = arraySizeX * arraySizeY;

	for (uint32_t i = 0; i < numArrayElements; i++)
		pOutputFeatureMap[i] = pFunc(pInputFeatureMap[i] + bias);
}





inline void SoftMax(float* pOutputData, const float* pInputData, uint32_t numElements)
{
	float maxValue = pInputData[0];

	for (uint32_t i = 1; i < numElements; i++)
	{
		if (pInputData[i] > maxValue)
			maxValue = pInputData[i];
	}

	float tempfloat = 0.00000001f;

	for (uint32_t i = 0; i < numElements; i++)
		tempfloat += exp(pInputData[i] - maxValue);

	/*tempfloat = 1.0f / tempfloat;

	for (uint32_t i = 0; i < numElements; i++)
		pOutputData[i] = exp(pInputData[i] - maxValue)*tempfloat;*/

	float offset = maxValue + log(tempfloat);

	for (uint32_t i = 0; i < numElements; i++)
		pOutputData[i] = exp(pInputData[i] - offset);
}

inline void SoftMax(float* pInputOutputData, uint32_t numElements)
{
	float maxValue = pInputOutputData[0];

	for (uint32_t i = 1; i < numElements; i++)
	{
		if (pInputOutputData[i] > maxValue)
			maxValue = pInputOutputData[i];
	}

	float tempfloat = 0.00000001f;

	for (uint32_t i = 0; i < numElements; i++)
		tempfloat += exp(pInputOutputData[i] - maxValue);

	/*tempfloat = 1.0f / tempfloat;

	for (uint32_t i = 0; i < numElements; i++)
		pInputOutputData[i] = exp(pInputOutputData[i] - maxValue)*tempfloat;*/

	float offset = maxValue + log(tempfloat);

	for (uint32_t i = 0; i < numElements; i++)
		pInputOutputData[i] = exp(pInputOutputData[i] - offset);
}

inline void Normalize(float* pOutputData, const float* pInputData, uint32_t numElements)
{
	float tempfloat = 0.0f;

	for (uint32_t i = 0; i < numElements; i++)
		tempfloat += pInputData[i] * pInputData[i];

	if (tempfloat == 0.0f)
		return;

	tempfloat = sqrtf(tempfloat);
	tempfloat = 1.0f / tempfloat;

	for (uint32_t i = 0; i < numElements; i++)
		pOutputData[i] = tempfloat * pInputData[i];
}

inline void Normalize(float* pInputOutputData, uint32_t numElements)
{
	float tempfloat = 0.0f;

	for (uint32_t i = 0; i < numElements; i++)
		tempfloat += pInputOutputData[i] * pInputOutputData[i];

	if (tempfloat == 0.0f)
		return;

	tempfloat = sqrtf(tempfloat);
	tempfloat = 1.0f / tempfloat;

	for (uint32_t i = 0; i < numElements; i++)
		pInputOutputData[i] = tempfloat * pInputOutputData[i];
}

inline float DotProduct(const float *pVector1, const float *pVector2, uint32_t numVectorElements)
{
	float dot = 0.0f;

	for (uint32_t i = 0; i < numVectorElements; i++)
		dot += pVector1[i] * pVector2[i];

	return dot;
}

inline float VectorLengthSq(const float *pVector, uint32_t numVectorElements)
{
	float lengthSq = 0.0f;

	for (uint32_t i = 0; i < numVectorElements; i++)
		lengthSq += pVector[i] * pVector[i];

	return lengthSq;
}

inline void MatrixMultiplication(float *pOutMat, const float *pInMat1, uint32_t numColumnsMat1, uint32_t numRowsMat1, const float *pInMat2, int32_t numColumnsMat2, uint32_t numRowsMat2)
{
	if (numColumnsMat1 != numRowsMat2)
		return;

	uint32_t i, j, k, ii1, iiProduct, idProduct;

	for(i = 0; i < numRowsMat1; i++)
	{
		ii1 = i * numColumnsMat1;
		iiProduct = i*numColumnsMat2;

		for (j = 0; j < numColumnsMat2; j++)
		{
			idProduct = j + iiProduct;

			pOutMat[idProduct] = 0.0f;

			for (k = 0; k < numRowsMat2; k++)
				pOutMat[idProduct] += pInMat1[k + ii1] * pInMat2[j + k * numColumnsMat2];
		}
	}	
}

inline void TransposeMatrix(float *pOutMat, const float *pInMat, uint32_t numColumnsMat, uint32_t numRowsMat)
{
	uint32_t i, j, ii;

	for (i = 0; i < numRowsMat; i++)
	{
		ii = i *  numColumnsMat;

		for (j = 0; j < numColumnsMat; j++)
		{ 
			pOutMat[i + j * numRowsMat] = pInMat[j + ii];
		}
	}
}

inline void Set_MatrixRowVector(float *pInOutMat, uint32_t numColumns, const float *pInVector, uint32_t rowID)
{
	uint32_t ii = rowID * numColumns;

	for (uint32_t i = 0; i < numColumns; i++)
		pInOutMat[ii + i] = pInVector[i];
}

inline void Get_MatrixRowVector(float *pInMat, uint32_t numColumns, float *pOutVector, uint32_t rowID)
{
	uint32_t ii = rowID * numColumns;

	for (uint32_t i = 0; i < numColumns; i++)
		pOutVector[i] = pInMat[ii + i];
}

inline void Set_MatrixColumnVector(float *pInOutMat, uint32_t numColumns, uint32_t numRows, const float *pInVector, uint32_t columnID)
{
	for (uint32_t i = 0; i < numRows; i++)
		pInOutMat[columnID + i * numColumns] = pInVector[i];
}

inline void Get_MatrixColumnVector(float *pInMat, uint32_t numColumns, uint32_t numRows, float *pOutVector, uint32_t columnID)
{
	for (uint32_t i = 0; i < numRows; i++)
		pOutVector[i] = pInMat[columnID + i * numColumns];
}

inline void Normalize_MatrixRowVectors(float *pInOutMat, uint32_t numColumns, uint32_t numRows)
{
	uint32_t i, j, ii, id;

	float lengthSq, invLength;

	for (i = 0; i < numRows; i++)
	{
		ii = i * numColumns;

		lengthSq = 0.0001f;

		for (j = 0; j < numColumns; j++)
		{
			id = j + ii;

			lengthSq += pInOutMat[id] * pInOutMat[id];
		}

		invLength = 1.0f / sqrt(lengthSq);

		for (j = 0; j < numColumns; j++)
		{
			pInOutMat[j + ii] *= invLength;
		}
	}
}

inline void Normalize_MatrixRowVectors(float *pOutMat, const float *pInMat, uint32_t numColumns, uint32_t numRows)
{
	uint32_t i, j, ii, id;

	float lengthSq, invLength;

	for (i = 0; i < numRows; i++)
	{
		ii = i * numColumns;

		lengthSq = 0.0001f;

		for (j = 0; j < numColumns; j++)
		{
			id = j + ii;

			lengthSq += pInMat[id] * pInMat[id];
		}

		invLength = 1.0f / sqrt(lengthSq);

		for (j = 0; j < numColumns; j++)
		{
			id = j + ii;
			pOutMat[id] = pInMat[id] * invLength;
		}
	}
}

inline void Normalize_MatrixColumnVectors(float *pInOutMat, uint32_t numColumns, uint32_t numRows)
{
	uint32_t i, j, id;

	float lengthSq, invLength;

	for (j = 0; j < numColumns; j++)
	{
		lengthSq = 0.0001f;

		for (i = 0; i < numRows; i++)
		{
			id = j + i * numColumns;

			lengthSq += pInOutMat[id] * pInOutMat[id];
		}

		invLength = 1.0f / sqrt(lengthSq);

		for (i = 0; i < numRows; i++)
		{
			pInOutMat[j + i * numColumns] *= invLength;
		}
	}
}

inline void Normalize_MatrixColumnVectors(float *pOutMat, const float *pInMat, uint32_t numColumns, uint32_t numRows)
{
	uint32_t i, j, id;

	float lengthSq, invLength;

	for (j = 0; j < numColumns; j++)
	{
		lengthSq = 0.0001f;

		for (i = 0; i < numRows; i++)
		{
			id = j + i * numColumns;

			lengthSq += pInMat[id] * pInMat[id];
		}

		invLength = 1.0f / sqrt(lengthSq);

		for (i = 0; i < numRows; i++)
		{
			id = j + i * numColumns;
			pOutMat[id] = pInMat[id] * invLength;
		}
	}
}

inline bool Check_MatrixOrthogonality(float *pOutTransposeMat, const float *pInMat, uint32_t numColumns, uint32_t numRows, float *pTempMat)
{
	TransposeMatrix(pOutTransposeMat, pInMat, numColumns, numRows);

	MatrixMultiplication(pTempMat, pInMat, numColumns, numRows, pOutTransposeMat, numRows, numColumns);

	uint32_t i, j, ii, id;

	for (i = 0; i < numRows; i++)
	{
		ii = i * numColumns;

		for (j = 0; j < numColumns; j++)
		{
			id = j + ii;

			if(i == j)
			{
				if (pTempMat[id] < 0.99f || pTempMat[id] > 1.01f)
					return false;
			}
			else
			{
				if (pTempMat[id] < -0.01f || pTempMat[id] > 0.01f)
					return false;
			}
		}
	}

	return true;
}

inline bool Check_MatrixDiagonality(float *pOutTransposeMat, const float *pInMat, uint32_t numColumns, uint32_t numRows, float *pTempMat)
{
	TransposeMatrix(pOutTransposeMat, pInMat, numColumns, numRows);

	MatrixMultiplication(pTempMat, pInMat, numColumns, numRows, pOutTransposeMat, numRows, numColumns);

	uint32_t i, j, ii, id;

	for (i = 0; i < numRows; i++)
	{
		ii = i * numColumns;

		for (j = 0; j < numColumns; j++)
		{
			id = j + ii;

			if (i != j)
			{
				if (pTempMat[id] < -0.01f || pTempMat[id] > 0.01f)
					return false;
			}
		}
	}

	return true;
}

inline float Check_MatrixOrthogonality2(float *pOutTransposeMat, const float *pInMat, uint32_t numColumns, uint32_t numRows, float *pTempMat)
{
	TransposeMatrix(pOutTransposeMat, pInMat, numColumns, numRows);

	MatrixMultiplication(pTempMat, pInMat, numColumns, numRows, pOutTransposeMat, numRows, numColumns);


	uint32_t i, j, ii, id;

	float error = 0.0f;

	for (i = 0; i < numRows; i++)
	{
		ii = i * numColumns;

		for (j = 0; j < numColumns; j++)
		{
			id = j + ii;

			if (i == j)
				error += abs(pTempMat[id] - 1.0f);
			else
				error += abs(pTempMat[id]);
		}
	}

	return error;
}

inline float Check_MatrixDiagonality2(float *pOutTransposeMat, const float *pInMat, uint32_t numColumns, uint32_t numRows, float *pTempMat)
{
	TransposeMatrix(pOutTransposeMat, pInMat, numColumns, numRows);

	MatrixMultiplication(pTempMat, pInMat, numColumns, numRows, pOutTransposeMat, numRows, numColumns);


	Output_RawImageData(pTempMat, numColumns, numRows);
	getchar();

	uint32_t i, j, ii, id;

	float error = 0.0f;

	for (i = 0; i < numRows; i++)
	{
		ii = i * numColumns;

		for (j = 0; j < numColumns; j++)
		{
			id = j + ii;

			if (i != j)
				error += abs(pTempMat[id]);
		}
	}

	return error;
}

class CRandomNumbersNN
{
	/* Klassenelemente, die �ffentlich nicht
	einsehbar sind: */
private:

	/* Deklaration der ben�tigten Membervariablen und
	Konstanten. Ein �ffentlicher Zugriff ist im
	vorliegenden Fall nicht m�glich (weil nicht
	erforderlich): */

	uint64_t newValue = 1;

	static constexpr uint64_t constParkMillerModulus =
		2147483647;
	static constexpr uint64_t constParkMillerMultiplier =
		48271;
	static constexpr double fconstParkMillerModulus =
		2147483647.0;

	// �ffentlich einsehbare Klassenelemente:
public:

	// Konstruktor (Deklaration):
	CRandomNumbersNN();

	// Destruktor (Deklaration):
	~CRandomNumbersNN();

	/* Deklaration der �ffentlich aufrufbaren
	Memberfunktionen (Klassenmethoden): */

	/* Neuen Startwert f�r die Berechnung der
	Zufallszahlen festlegen: */
	void Change_Seed(uint64_t newSeed);

	/* Hinweis: Memberfunktionen lassen sich auch innerhalb
	einer Klassendeklarationen implementieren: */
	/*void Change_Seed( uint64_t newSeed)
	{
	newValue = newSeed;
	}*/

	/* Startwert f�r die Berechnung der Zufallszahlen
	auf 1 zur�cksetzen */
	void Reset_Seed(void);

	// zuf�llige 32-Bit-Flie�kommazahlen:
	float Get_FloatNumber(float low, float high);
	float Get_FloatNumber_IncludingZero(float low, float high);

	// zuf�llige 64-Bit-Flie�kommazahlen:
	double Get_DoubleNumber(double low, double high);
	double Get_DoubleNumber_IncludingZero(double low, double high);

	// zuf�llige 32-Bit-Ganzzahlen:
	int32_t Get_IntegerNumber(int32_t low,
		int32_t high_excluded);

	int32_t Get_IntegerNumber2(int32_t low,
		int32_t high);

	// zuf�llige positive 32-Bit-Ganzzahlen:
	uint32_t Get_UnsignedIntegerNumber(uint32_t low,
		uint32_t high_excluded);

	uint32_t Get_UnsignedIntegerNumber2(uint32_t low,
		uint32_t high);

}; // end of class CRandomNumbersNN


inline void Init_RandomNormalVector(float *pOutVec, CRandomNumbersNN *pRandomNumbers, uint32_t numVectorElements)
{
	for (uint32_t i = 0; i < numVectorElements; i++)
		pOutVec[i] = pRandomNumbers->Get_FloatNumber(-1.0f, 1.0f);

	Normalize(pOutVec, numVectorElements);
}

inline void Init_RandomVector(float *pOutVec, CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, uint32_t numVectorElements)
{
	for (uint32_t i = 0; i < numVectorElements; i++)
		pOutVec[i] = pRandomNumbers->Get_FloatNumber(minValue, maxValue);
}

inline void Init_RandomVector(float *pOutVec, CRandomNumbersNN *pRandomNumbers, int32_t minValue, int32_t maxValue, uint32_t numVectorElements)
{
	for (uint32_t i = 0; i < numVectorElements; i++)
	{
		pOutVec[i] = pRandomNumbers->Get_IntegerNumber2(minValue, maxValue);
		
		if (pOutVec[i] == 0.0f)
		{
			pOutVec[i] = 1.0f;

			if (pRandomNumbers->Get_IntegerNumber2(1, 2) == 1)
				pOutVec[i] = -1.0f;
		}
	}
}

inline void Find_RandomOrthogonalVector(float *pOutVec, float *pInVec, CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, uint32_t numVectorElements)
{
	for (uint32_t i = 1; i < numVectorElements; i++)
		pOutVec[i] = pRandomNumbers->Get_FloatNumber(minValue, maxValue);

	
	pOutVec[0] = 0.0f;

	for (uint32_t i = 1; i < numVectorElements; i++)
		pOutVec[0] -= pOutVec[i] * pInVec[i];

	float tempfloat = pInVec[0];

	if (tempfloat == 0.0f)
		tempfloat = 0.0001f;

	pOutVec[0] *= 1.0f / tempfloat;
}



inline void Find_RandomOrthonormalVector(float *pOutVec, float *pInVec, CRandomNumbersNN *pRandomNumbers, uint32_t numVectorElements)
{
	for (uint32_t i = 1; i < numVectorElements; i++)
		pOutVec[i] = pRandomNumbers->Get_FloatNumber(-1.0f, 1.0f);


	pOutVec[0] = 0.0f;

	for (uint32_t i = 1; i < numVectorElements; i++)
		pOutVec[0] -= pOutVec[i] * pInVec[i];

	float tempfloat = pInVec[0];

	if (tempfloat == 0.0f)
		tempfloat = 0.0001f;

	pOutVec[0] *= 1.0f / tempfloat;

	Normalize(pOutVec, numVectorElements);
}

inline void Find_RandomOrthonormalVector(float *pOutVec, float *pInVec1, float *pInVec2, float *pInTempVec, CRandomNumbersNN *pRandomNumbers, uint32_t numVectorElements, uint32_t numIterations)
{
	Find_RandomOrthonormalVector(pOutVec, pInVec2, pRandomNumbers, numVectorElements);

	float dotProductMin = abs(DotProduct(pOutVec, pInVec1, numVectorElements));
	float dotProduct;

	for (uint32_t i = 0; i < numIterations; i++)
	{
		Find_RandomOrthonormalVector(pInTempVec, pInVec2, pRandomNumbers, numVectorElements);

		dotProduct = abs(DotProduct(pInTempVec, pInVec1, numVectorElements));
		
		if (dotProduct < dotProductMin)
		{
			dotProductMin = dotProduct;

			Copy_1DimArray(pOutVec, pInTempVec, numVectorElements);

			if (dotProductMin < 0.01f)
				return;
		}
	}
}



inline void Find_RandomOrthonormalVector(float *pOutVec, float *pInVec1, float *pInVec2, float *pInVec3, float *pInTempVec, CRandomNumbersNN *pRandomNumbers, uint32_t numVectorElements, uint32_t numIterations)
{
	Find_RandomOrthonormalVector(pOutVec, pInVec3, pRandomNumbers, numVectorElements);

	float sumOfDotProductsMin = abs(DotProduct(pOutVec, pInVec1, numVectorElements)) + abs(DotProduct(pOutVec, pInVec2, numVectorElements));

	float sumOfDotProducts;

	for (uint32_t i = 0; i < numIterations; i++)
	{
		Find_RandomOrthonormalVector(pInTempVec, pInVec3, pRandomNumbers, numVectorElements);

		sumOfDotProducts = abs(DotProduct(pInTempVec, pInVec1, numVectorElements)) + abs(DotProduct(pInTempVec, pInVec2, numVectorElements));
		

		if (sumOfDotProducts < sumOfDotProductsMin)
		{
			sumOfDotProductsMin = sumOfDotProducts;

			Copy_1DimArray(pOutVec, pInTempVec, numVectorElements);

			if (sumOfDotProductsMin < 0.01f)
				return;
		}
	}
}





inline void Approximate_OrthonormalMatrix(float *pInOutMat, uint32_t numColumns, uint32_t numRows, CRandomNumbersNN *pRandomNumbers, uint32_t *pNumIterationsArray, float *pTempVec1, float *pTempVec2, float *pTempVec3)
{
	Init_RandomNormalVector(pTempVec1, pRandomNumbers, numColumns);

	Set_MatrixRowVector(pInOutMat, numColumns, pTempVec1, 0);

	Find_RandomOrthonormalVector(pTempVec2, pTempVec1, pRandomNumbers, numColumns);

	Set_MatrixRowVector(pInOutMat, numColumns, pTempVec2, 1);

	float sumOfDotProductsMin, sumOfDotProducts;

	
	for (uint32_t i = 2; i < numRows; i++)
	{
		Get_MatrixRowVector(pInOutMat, numColumns, pTempVec1, i - 1);
		Find_RandomOrthonormalVector(pTempVec3, pTempVec1, pRandomNumbers,  numColumns);

		sumOfDotProductsMin = 0.0f;

		for (uint32_t j = 0; j < i; j++)
		{
			Get_MatrixRowVector(pInOutMat, numColumns, pTempVec1, j);
			sumOfDotProductsMin += abs(DotProduct(pTempVec3, pTempVec1, numColumns));
		}
		
		
		
		for (uint32_t ii = 0; ii < pNumIterationsArray[i]; ii++)
		{
			Find_RandomOrthonormalVector(pTempVec2, pTempVec1, pRandomNumbers,  numColumns);

			sumOfDotProducts = 0.0f;

			for (uint32_t j = 0; j < i; j++)
			{
				Get_MatrixRowVector(pInOutMat, numColumns, pTempVec1, j);

				sumOfDotProducts += abs(DotProduct(pTempVec2, pTempVec1, numColumns));
			}

			if (sumOfDotProducts < sumOfDotProductsMin)
			{
				Copy_1DimArray(pTempVec3, pTempVec2, numColumns);

				sumOfDotProductsMin = sumOfDotProducts;

				if (sumOfDotProductsMin < 0.01f)
					break;
			}
		}

		Set_MatrixRowVector(pInOutMat, numColumns, pTempVec3, i);

	}
}





inline void Init_RandomFilter(float *pOutputKernel, /*numArrayElements:*/ uint32_t kernelSize, CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue)
{
	for (uint32_t i = 0; i < kernelSize; i++)
		pOutputKernel[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minValue, maxValue);
}

inline void Init_RandomFilter(float *pOutputKernel, /*numArrayElements:*/ uint32_t kernelSize, CRandomNumbersNN *pRandomNumbers, int32_t minValue, int32_t maxValue)
{
	for (uint32_t i = 0; i < kernelSize; i++)
	{
		pOutputKernel[i] = pRandomNumbers->Get_IntegerNumber2(minValue, maxValue);

		if (pOutputKernel[i] == 0.0f)
		{
			pOutputKernel[i] = 1.0f;

			if (pRandomNumbers->Get_IntegerNumber2(1, 2) == 1)
				pOutputKernel[i] = -1.0f;
		}
	}
}

inline void Init_RandomFilter(float *pOutputKernel, float *pReceptiveFieldDensityValues, /*numArrayElements:*/ uint32_t kernelSize, CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue)
{
	for (uint32_t i = 0; i < kernelSize; i++)
		pOutputKernel[i] = pReceptiveFieldDensityValues[i] * pRandomNumbers->Get_FloatNumber_IncludingZero(minValue, maxValue);
}


inline void Init_RandomFilter(float *pOutputKernel, uint32_t kernelSizeX, uint32_t kernelSizeY, CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue)
{
	uint32_t numArrayElements = kernelSizeX * kernelSizeY;

	for (uint32_t i = 0; i < numArrayElements; i++)
		pOutputKernel[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minValue, maxValue);
}

inline void Init_RandomFilter(float *pOutputKernel, uint32_t kernelSizeX, uint32_t kernelSizeY, CRandomNumbersNN *pRandomNumbers, int32_t minValue, int32_t maxValue)
{
	uint32_t numArrayElements = kernelSizeX * kernelSizeY;

	for (uint32_t i = 0; i < numArrayElements; i++)
	{
		pOutputKernel[i] = pRandomNumbers->Get_IntegerNumber2(minValue, maxValue);

		if (pOutputKernel[i] == 0.0f)
		{
			pOutputKernel[i] = 1.0f;

			if (pRandomNumbers->Get_IntegerNumber2(1, 2) == 1)
				pOutputKernel[i] = -1.0f;
		}
	}
}

inline void Init_RandomFilter(float *pOutputKernel, float *pReceptiveFieldDensityValues, uint32_t kernelSizeX, uint32_t kernelSizeY, CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue)
{
	uint32_t numArrayElements = kernelSizeX * kernelSizeY;

	for (uint32_t i = 0; i < numArrayElements; i++)
		pOutputKernel[i] = pReceptiveFieldDensityValues[i] * pRandomNumbers->Get_FloatNumber_IncludingZero(minValue, maxValue);
}

inline void Init_RandomFilter2(float *pOutputKernelWithBias, /*numArrayElements:*/ uint32_t kernelSizeWithoutBias, CRandomNumbersNN *pRandomNumbers, float minFilterValue, float maxFilterValue, float minBiasValue, float maxBiasValue)
{
	for (uint32_t i = 0; i < kernelSizeWithoutBias; i++)
		pOutputKernelWithBias[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minFilterValue, maxFilterValue);

	pOutputKernelWithBias[kernelSizeWithoutBias] = pRandomNumbers->Get_FloatNumber_IncludingZero(minBiasValue, maxBiasValue);
}

inline void Init_RandomFilter2(float *pOutputKernelWithBias, /*numArrayElements:*/ uint32_t kernelSizeWithoutBias, CRandomNumbersNN *pRandomNumbers, int32_t minFilterValue, int32_t maxFilterValue, float minBiasValue, float maxBiasValue)
{
	for (uint32_t i = 0; i < kernelSizeWithoutBias; i++)
	{
		pOutputKernelWithBias[i] = pRandomNumbers->Get_IntegerNumber2(minFilterValue, maxFilterValue);

		if (pOutputKernelWithBias[i] == 0.0f)
		{
			pOutputKernelWithBias[i] = 1.0f;

			if (pRandomNumbers->Get_IntegerNumber2(1, 2) == 1)
				pOutputKernelWithBias[i] = -1.0f;
		}
	}

	pOutputKernelWithBias[kernelSizeWithoutBias] = pRandomNumbers->Get_FloatNumber_IncludingZero(minBiasValue, maxBiasValue);
}

inline void Init_RandomFilter2(float *pOutputKernelWithBias, float *pReceptiveFieldDensityValues, /*numArrayElements:*/ uint32_t kernelSizeWithoutBias, CRandomNumbersNN *pRandomNumbers, float minFilterValue, float maxFilterValue, float minBiasValue, float maxBiasValue)
{
	for (uint32_t i = 0; i < kernelSizeWithoutBias; i++)
		pOutputKernelWithBias[i] = pReceptiveFieldDensityValues[i] * pRandomNumbers->Get_FloatNumber_IncludingZero(minFilterValue, maxFilterValue);

	pOutputKernelWithBias[kernelSizeWithoutBias] = pReceptiveFieldDensityValues[kernelSizeWithoutBias] * pRandomNumbers->Get_FloatNumber_IncludingZero(minBiasValue, maxBiasValue);
}

inline void Init_RandomFilter2(float *pOutputKernelWithBias, uint32_t kernelSizeWithoutBiasX, uint32_t kernelSizeWithoutBiasY, CRandomNumbersNN *pRandomNumbers, float minFilterValue, float maxFilterValue, float minBiasValue, float maxBiasValue)
{
	uint32_t numArrayElements = kernelSizeWithoutBiasX * kernelSizeWithoutBiasY;

	for (uint32_t i = 0; i < numArrayElements; i++)
		pOutputKernelWithBias[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minFilterValue, maxFilterValue);

	pOutputKernelWithBias[numArrayElements] = pRandomNumbers->Get_FloatNumber_IncludingZero(minBiasValue, maxBiasValue);
}

inline void Init_RandomFilter2(float *pOutputKernelWithBias, uint32_t kernelSizeWithoutBiasX, uint32_t kernelSizeWithoutBiasY, CRandomNumbersNN *pRandomNumbers, int32_t minFilterValue, int32_t maxFilterValue, float minBiasValue, float maxBiasValue)
{
	uint32_t numArrayElements = kernelSizeWithoutBiasX * kernelSizeWithoutBiasY;

	for (uint32_t i = 0; i < numArrayElements; i++)
	{
		pOutputKernelWithBias[i] = pRandomNumbers->Get_IntegerNumber2(minFilterValue, maxFilterValue);

		if (pOutputKernelWithBias[i] == 0.0f)
		{
			pOutputKernelWithBias[i] = 1.0f;

			if (pRandomNumbers->Get_IntegerNumber2(1, 2) == 1)
				pOutputKernelWithBias[i] = -1.0f;
		}
	}

	pOutputKernelWithBias[numArrayElements] = pRandomNumbers->Get_FloatNumber_IncludingZero(minBiasValue, maxBiasValue);
}

inline void Init_RandomFilter2(float *pOutputKernelWithBias, float *pReceptiveFieldDensityValues, uint32_t kernelSizeWithoutBiasX, uint32_t kernelSizeWithoutBiasY, CRandomNumbersNN *pRandomNumbers, float minFilterValue, float maxFilterValue, float minBiasValue, float maxBiasValue)
{
	uint32_t numArrayElements = kernelSizeWithoutBiasX * kernelSizeWithoutBiasY;

	for (uint32_t i = 0; i < numArrayElements; i++)
		pOutputKernelWithBias[i] = pReceptiveFieldDensityValues[i] * pRandomNumbers->Get_FloatNumber_IncludingZero(minFilterValue, maxFilterValue);

	pOutputKernelWithBias[numArrayElements] = pReceptiveFieldDensityValues[numArrayElements] * pRandomNumbers->Get_FloatNumber_IncludingZero(minBiasValue, maxBiasValue);
}



class CImageDataF
{
public:

	uint32_t SizeXDir;
	uint32_t SizeYDir;
	uint32_t Size;  // SizeXDir * SizeYDir

	float *pValueArray = nullptr;

	CImageDataF();
	~CImageDataF();

	// Kopierkonstruktor l�schen:
	CImageDataF(const CImageDataF &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CImageDataF& operator=(const CImageDataF &originalObject) = delete;

	void Initialize(uint32_t sizeXDir, uint32_t sizeYDir);
	void Clear(float value = 0.0f);

	// old resolution => new resolution
	// 32x32 => 16x16
	// 30x30 => 15x15
	// 15x15 => 8x8
	void Bisect_Resolution(float *pOutputArray);

	void MaxPoolingPooling2x2(float *pOutputArray);
	void L2Pooling2x2(float *pOutputArray);
};

class C1DimDataF
{
public:

	uint32_t Size; 

	float *pValueArray = nullptr;

	C1DimDataF();
	~C1DimDataF();

	// Kopierkonstruktor l�schen:
	C1DimDataF(const C1DimDataF &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	C1DimDataF& operator=(const C1DimDataF &originalObject) = delete;

	void Initialize(uint32_t size);
	void Clear(float value = 0.0f);
	void Bisect_Resolution(float *pOutputArray);
	void MaxPoolingPooling2x1(float *pOutputArray);
	void L2Pooling2x1(float *pOutputArray);
};





class CGeometricNeuron
{
public:

	int32_t NeuronID = -1;

	CGeometricNeuron *pUsedNeuronArray = nullptr;
	
	float Activity = 0.0f;
	float PosX = 0.0f;
	float PosY = 0.0f;
	float PosZ = 0.0f;

	int32_t NumConnections = 0;

	float *pSynapsePlasticityArray = nullptr;

	// Hinweis: pConnectionWeightArray[i] == 0.0f => related path is impassable
	float *pConnectionWeightArray = nullptr; 

	float *pDistanceArray = nullptr;
	int32_t *pReceiverNeuronIDArray = nullptr;

	int32_t ReceiverSynapseID = -1;
	int32_t ReceiverNeuronID = -1;

	CGeometricNeuron();
	~CGeometricNeuron();

	// Kopierkonstruktor l�schen: 
	CGeometricNeuron(const CGeometricNeuron &originalObject) = delete;

	// �berladenen Zuweisungsoperator l�schen: 
	CGeometricNeuron operator=(const CGeometricNeuron &originalObject) = delete;

	void Init_FullyConnectedNeuron(int32_t neuronID, int32_t numNeurons);
	void Init_Neuron(int32_t neuronID, int32_t numConnections);

	void Connect_With_ReceiverNeuron(int32_t neuronID, int32_t synapseID);
	void Connect_With_ReceiverNeurons(int32_t *pNeuronIDArray);

	void Set_ConnectionWeight(float weight, int32_t synapseID);

	void Connect_With_Brain(CGeometricNeuron* pNeuronArray);

	void Set_Position(float x, float y, float z);

	void Calculate_ConnectionDistances(void);
	void Calculate_ConnectionSquareDistances(void);

	void Reset_Activity(void);
	void Set_Activity(float value);

	void Propagate_Signal(int32_t receiverNeuronID);
	int32_t Propagate_Signal_To_NonActivatedNeuron(CRandomNumbersNN *pRandomNumbers);
	int32_t Propagate_Signal(CRandomNumbersNN *pRandomNumbers);
	int32_t Propagate_Signal_Randomly(CRandomNumbersNN *pRandomNumbers);
	int32_t Select_Connected_Neuron_Randomly(CRandomNumbersNN *pRandomNumbers);

	void Reset_PlasticityValues(void);
	void Update_PlasticityValues(float finalActivity, float learningRate);
	void Reduce_PlasticityValues(float decreaseValue, float minPlasticityValue = 0.0f);

	int32_t Get_ID_Of_Strongest_ConnectedNeuron(void);
};



class CGeometricNeuralNet
{
public:

	int32_t NumNeurons = 0;

	CGeometricNeuron *pNeuronArray = nullptr;

	CRandomNumbersNN RandomNumbers;

	float MinNonZeroPlasticityValue = 0.0f;
	float MaxPlasticityValue = 0.0f;

	CGeometricNeuralNet();
	~CGeometricNeuralNet();

	// Kopierkonstruktor l�schen: 
	CGeometricNeuralNet(const CGeometricNeuralNet &originalObject) = delete;

	// �berladenen Zuweisungsoperator l�schen: 
	CGeometricNeuralNet operator=(const CGeometricNeuralNet &originalObject) = delete;

	void Initialize_FullyConnected_NeuralNet(int32_t numNeurons);

	// Es werden noch keine neuronalen Verbindungen gekn�pft:
	void Initialize_NeuralNet(int32_t numNeurons);
	void Init_Neuron(int32_t neuronID, int32_t numConnections);

	void Connect_With_ReceiverNeuron(int32_t neuronID, int32_t receiverNeuronID, int32_t synapseID);

	// Hinweis: ConnectionWeight == 0.0f => related path is impassable
	void Set_ConnectionWeight(int32_t neuronID, float weight, int32_t synapseID);

	// Hinweis: ConnectionWeight == 0.0f => related path is impassable
	void Set_ConnectionWeight(int32_t neuronID, int32_t receiverNeuronID, float weight);

	float Find_MinNonZeroPlasticityValue(void);
	float Find_MaxPlasticityValue(void);

	void Set_Position(int32_t neuronID, float x, float y, float z);

	void Start_Training(void);

	// TSP: Travelling Salesman Problem
	void Train_NeuralNet_TSP(int32_t IDofFirstAndLastNeuron, float initialActivity, float learningRate);
	
	void Train_NeuralNet_PathFinding(int32_t IDofFirstNeuron, int32_t IDofLastNeuron, float initialActivity, float learningRate);

	void Random_PathFinding(int32_t IDofFirstNeuron, int32_t IDofLastNeuron, float initialActivity, float learningRate);
	
	void Reduce_PlasticityValues(float decreaseValue, float minPlasticityValue = 0.0f);

	// Ausgabe des neuronalen Pfades mit den st�rksten synaptischen Plastizit�ten (step by step):
	int32_t Get_ID_Of_Strongest_ConnectedNeuron(int32_t lastNeuronID);

	void Calculate_ConnectionDistances(void);
	void Calculate_ConnectionSquareDistances(void);
};





class CNeuron
{
public:

	CNeuron *pUsedNeuronArray = nullptr;

	bool UsedAsInputNeuron = true;
	bool UsedAsHiddenNeuron = false;
	bool UsedAsOutputNeuron = false;
	bool UsedAsBiasNeuron = false;
	bool UsedAsMemoryNeuron = false;
	bool UsedAsRBFNeuron = false;

	float NeuronInput = 0.0f;
	float NeuronOutput = 0.0f;
	float NeuronOutput_LastCalculationStep = 0.0f;

	float ErrorValue = 0.0f;
	float ErrorFactor1 = 1.0f;
	float ErrorFactor2 = 1.0f;
	// Hinweis: Bei linearen Aktivierungsfunktionen sollte ErrorFactor2 kleiner als 1.0f sein (z. B. 0.5f oder 0.25f) 

	float LearningRate = 0.2f;

	pActivationFunc pActivationFunction = nullptr;
	pErrorFunc pUserDefErrorFunction = nullptr;

	uint32_t NumOfOutputSynapsesMax = 0;
	uint32_t NumOfOutputSynapses = 0;

	uint32_t *pReceiverNeuronIDArray = nullptr;

	bool *pOutputSynapseActivityStatusArray = nullptr;

	// auch bekannt als OutputWeightArray: 
	float *pOutputSynapsePlasticityArray = nullptr;

	// f�r bin�ren Output:
	float *pOutputSynapseMinBlockingValueArray = nullptr;
	float *pOutputSynapseMaxBlockingValueArray = nullptr;
	
	bool Dropout = false;

	uint32_t NumOfRBFCentroidValues = 0;
	float *pRBFCentroidValueArray = nullptr;
	float RBFCentroidDistanceSqSum = 0.0f;
	float RBF_Factor = 1.0f;

	uint32_t RBFInputCounter = 0;

	CNeuron();
	~CNeuron();

	// Kopierkonstruktor l�schen: 
	CNeuron(const CNeuron &originalObject) = delete;

	// �berladenen Zuweisungsoperator l�schen: 
	CNeuron operator=(const CNeuron &originalObject) = delete;

	void Init_RBFCentroid(uint32_t numOfRBFCentroidValues);
	void Set_RBFCentroidValues(float rBF_Factor, float *pValueArray);

	void Set_DropoutState(bool state);

	void Round_OutputWeights(float precision, float invPrecision);
	void Remove_Unused_Connections(void);

	void Clone(const CNeuron &originalObject);
	void Clone_Data(const CNeuron &originalObject);

	void Init_OutputSynapses(uint32_t numOfOutputSynapses);

	void Disable_Random_OutputSynapses(CRandomNumbersNN *pRandomNumbers, float probabilityValue);
	void Enable_Disabled_OutputSynapses(CRandomNumbersNN *pRandomNumbers, float minPlasticityValue, float maxPlasticityValue);
	void Enable_Disabled_OutputSynapses(CRandomNumbersNN *pRandomNumbers, float minPlasticityValue, float maxPlasticityValue, float probabilityValue);

	void Randomize_OutputSynapsePlasticities(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue);
	void Randomize_OutputSynapsePlasticities(CRandomNumbersNN *pRandomNumbers, float *pRandomValueArray, uint32_t numArrayElements);

	void Add_Randomized_OutputSynapsePlasticities(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float weight1, float weight2);
	void Add_Randomized_OutputSynapsePlasticities(CRandomNumbersNN *pRandomNumbers, float *pRandomValueArray, uint32_t numArrayElements, float weight1, float weight2);
	
	void Clone_OutputSynapsePlasticities(const CNeuron &originalObject);
	void Clone_OutputSynapsePlasticities(const CNeuron &originalObject, CRandomNumbersNN *pRandomNumbers, float variance);
	void Clone_OutputSynapsePlasticities(const CNeuron &originalObject, CRandomNumbersNN *pRandomNumbers, float minVariance, float maxVariance);
	void Combine_OutputSynapsePlasticities(CNeuron *pParentNeuron1, CNeuron *pParentNeuron2, CRandomNumbersNN *pRandomNumbers, float minWeight1);
	void Combine_OutputSynapsePlasticities(CNeuron *pParentNeuron1, CNeuron *pParentNeuron2, CRandomNumbersNN *pRandomNumbers);

	void Modify_OutputSynapsePlasticities(float multiplier);

	void Connect_With_Brain(CNeuron *pNeuronArray);
	void Connect_With_ReceiverNeuron(uint32_t neuronID, uint32_t synapseID);
	void Connect_With_ReceiverNeurons(uint32_t *pNeuronIDArray);

	void Use_As_InputNeuron(void);
	void Use_As_HiddenNeuron(void);
	void Use_As_OutputNeuron(void);
	void Use_As_BiasNeuron(void);
	void Use_As_MemoryNeuron(void);
	void Use_As_RBFNeuron(void);

	void Set_OutputSynapsePlasticity(float value, uint32_t synapseID);
	void Set_OutputSynapseBlockingValue(float minValue, float maxValue, uint32_t synapseID);
	void Set_LearningRate(float learningRate);
	void Set_ActivationFunction(pActivationFunc pFunc);
	void Set_UserDefErrorFunction(pErrorFunc pFunc);

	// Hinweis: Bei linearen Aktivierungsfunktionen sollte ErrorFactor2 kleiner als 1.0f sein (z. B. 0.5f, 0.25f, 0.01f) 
	void Set_ErrorFactors(float factor1, float factor2);
	
	// Funktioniert nur bei Input-Neuronen (Inputwert wird in der Variable NeuronOutput gespeichert): 
	void Set_Input(float value);
	void Add_Input(float value);

	void Reset_NeuronInput(void);
	float Get_NeuronInput(void);
	void Set_NeuronInput(float value);

	void Calculate_NeuronOutput(void);
	void Calculate_NeuronOutput_And_Retain_Input(void);
	void Calculate_NeuronOutput(float inputDecrease, float minInputValue);

	/* if (NeuronOutput < minOutputValue) => NeuronInput wird nicht ge�ndert */
	void Accumulate_NeuronInput_And_Calculate_NeuronOutput(float minOutputValue);

	/* if (NeuronOutput < minOutputValue) oder if (NeuronOutput > maxOutputValue) => NeuronInput wird nicht ge�ndert */
	void Accumulate_NeuronInput_And_Calculate_NeuronOutput(float minOutputValue, float maxOutputValue);

	/* if (NeuronOutput < minOutputValue) => NeuronInput wird nicht ge�ndert */
	void Accumulate_NeuronInput_And_Calculate_NeuronOutput(float minOutputValue, float inputDecrease, float minInputValue);

	/* if (NeuronOutput < minOutputValue) oder if (NeuronOutput > maxOutputValue) => NeuronInput wird nicht ge�ndert */
	void Accumulate_NeuronInput_And_Calculate_NeuronOutput(float minOutputValue, float maxOutputValue, float inputDecrease, float minInputValue);

	void Reset_NeuronOutput(void);

	// Weiterleitung des Signals an s�mtliche Receiver-Neuronen (nachgeschaltete Neuronen):
	void Propagate_SynapticOutput(void);
	void Propagate_MaximumSynapticOutput(void);
	void Propagate_MinimumSynapticOutput(void);
	void Propagate_MaximumAbsolutSynapticOutput(void);
	void Propagate_BinaryValue(void);

	void Propagate_SynapticOutput(uint32_t synapseID);
	void Propagate_MaximumSynapticOutput(uint32_t synapseID);
	void Propagate_MinimumSynapticOutput(uint32_t synapseID);
	void Propagate_MaximumAbsolutSynapticOutput(uint32_t synapseID);
	void Propagate_BinaryValue(uint32_t synapseID);

	void Update_NeuronInput(float value);

	float Get_NeuronOutput(void);
	void Set_NeuronOutput(float value);
	void Set_BiasNeuronOutput(float value);

	void Set_Error(float value);
	float Calculate_Error(float desiredNeuronOutput);
	float Calculate_Error_WithUserDefFunction(float desiredNeuronOutput);

	/* Fehlerberechnung (Input-Neuronen sind ausgenommen) unter Ber�cksichtigung der bereits berechneten Fehler von
	s�mtlichen Receiver-Neuronen (nachgeschalteten Neuronen): */
	void Calculate_Error(void);
	void Calculate_Error_WithUserDefFunction(void);

	void Calculate_InputNeuronError(void);
	void Calculate_InputNeuronError_WithUserDefFunction(void);

	// Anpassung der Synapsen-Pastizit�t unter Ber�cksichtigung der zuvor berechneten Fehlerwerte:
	void Adjust_OutputSynapses_AfterErrorCalculations(void);
	void Adjust_OutputSynapses_AfterErrorCalculationsExt(void);

	void Adjust_OutputSynapse_AfterErrorCalculations(uint32_t synapseID);
	void Adjust_OutputSynapse_AfterErrorCalculationsExt(uint32_t synapseID);

	void Adjust_OutputSynapse_AfterErrorCalculations2(uint32_t receiverNeuronID);
	void Adjust_OutputSynapse_AfterErrorCalculationsExt2(uint32_t synapseID);

	bool Save_OutputSynapsePlasticities(const char* pFilename);
	bool Load_OutputSynapsePlasticities(const char* pFilename);

	bool Save_ReceiverNeuronIDs_And_OutputSynapsePlasticities(const char* pFilename);
	bool Load_ReceiverNeuronIDs_And_OutputSynapsePlasticities(const char* pFilename);

	bool Save_ReceiverNeuronIDs_And_OutputSynapsePlasticities_Ext(const char* pFilename);
	bool Load_ReceiverNeuronIDs_And_OutputSynapsePlasticities_Ext(const char* pFilename);

	bool Save_RBFCentroidValues(const char* pFilename);
	bool Load_RBFCentroidValues(const char* pFilename);
};

class CLongTermMemoryNeuron
{
public:

	CNeuron *pUsedNeuronArray = nullptr;

	uint32_t NumOfMemorySynapses = 0;
	uint32_t NumOfMemorySynapsesPlus1 = 0;

	float *pSynapsePlasticityArray = nullptr;
	

	float Activity = 0.0f;

	float Counter = 0.0f;
	float InvCounter = 1.0f;

	CLongTermMemoryNeuron();
	~CLongTermMemoryNeuron();
	
	// Kopierkonstruktor l�schen: 
	CLongTermMemoryNeuron(const CLongTermMemoryNeuron &originalObject) = delete;

	// �berladenen Zuweisungsoperator l�schen: 
	CLongTermMemoryNeuron operator=(const CLongTermMemoryNeuron &originalObject) = delete;

	void Init_Neuron(uint32_t numOfMemorySynapses);

	void Connect_With_Brain(CNeuron* pNeuronArray);

	void Reset_Memory(void);

	void Add_MemoryValue(int32_t synapseID, float value);
	void Set_MemoryValue(int32_t synapseID, float value);
	float Get_MemoryValue(int32_t synapseID);

	void Update_Memory(int32_t synapseID, int32_t inputNeuronID, float learningRate = 1.0f);

	void Propagate_Memory(int32_t synapseID, int32_t receiverNeuronID);
	                                   
	void Transfer_Plasticity_To_DestinationNeuron(int32_t synapseID, int32_t destinationNeuronID, int32_t destinationNeuronSynapseID, float plasticityMultiplier);
	void Transfer_Plasticity_To_DestinationNeuron(int32_t synapseID, int32_t destinationNeuronID, int32_t destinationNeuronSynapseID);


	void Reset_Activity(void);
	void Set_Activity(float value);

	void Reduce_PlasticityValues(float decreaseValue, float minPlasticityValue);

};





class C2State2DCellularAutomatonRules
{
public:

	int32_t NumBirthRules = 0;
	int32_t BirthRuleArray[8];

	int32_t NumSurvivingRules = 0;
	int32_t SurvivingRuleArray[8];

	C2State2DCellularAutomatonRules();
	void Reset(void);
};


class C2DCellularAutomata
{
public:

	int32_t NumCellsXDir;
	int32_t NumCellsYDir;

	int32_t NumCellsXDirMinus1;
	int32_t NumCellsYDirMinus1;

	int32_t NumCells;

	int32_t *pCellMap1 = nullptr;
	int32_t *pCellMap2 = nullptr;

	int32_t *PtrToLastUpdatedCellMap = nullptr;

	static constexpr int32_t Value_BlockingCell = -1;
	static constexpr int32_t Value_DeadCell = 0;
	static constexpr int32_t Value_LivingCell = 1;

	C2DCellularAutomata();
	~C2DCellularAutomata();

	
	// Kopierkonstruktor l�schen:
	C2DCellularAutomata(const C2DCellularAutomata &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	C2DCellularAutomata& operator=(const C2DCellularAutomata &originalObject) = delete;

	void Set_CellValue(int32_t cellIID, int32_t value);
	void Set_CellValue(int32_t cellPosX, int32_t cellPosY, int32_t value);

	int32_t Get_CellValue(int32_t cellIID);
	int32_t Get_CellValue(int32_t cellPosX, int32_t cellPosY);

	int32_t Get_PrevCellValue(int32_t cellIID);
	int32_t Get_PrevCellValue(int32_t cellPosX, int32_t cellPosY);

	void Get_PtrToLastUpdatedCellMap(int32_t **ppOut);

	void Init_CellularAutomata(int32_t numCellsXDir, int32_t numCellsYDir);

	void Reset_CellMap(int32_t cellValue);
	void Kill_All_Cells(void);

	void Init_CellMap(CRandomNumbersNN *pRandomNumbers, int32_t densityValue, int32_t invDensity);
	void Init_CellMap(CRandomNumbersNN *pRandomNumbers, int32_t minXPos, int32_t maxXPos, int32_t minYPos, int32_t maxYPos, int32_t densityValue, int32_t invDensity);


	void Output_CellMap(void);

	bool Save_CellMap(const char* pFilename);
	bool Save_CellMap(const char* pFilename, int32_t valueLivingCell, int32_t valueDeadCell);
	bool Save_CellMapPattern(const char* pFilename, int32_t value);

	void Smooth_CellMap(int32_t smoothingValue);
	void Smooth_BorderlessCellMap(int32_t smoothingValue);

	void Detect_Edges(int32_t valueEdgeCell);
	void Detect_Edges2(int32_t valueNonEdgeCell);

	void Update_CellMap(C2State2DCellularAutomatonRules *pRules);
	void Update_BorderlessCellMap(C2State2DCellularAutomatonRules *pRules);

	void Set_CellMapBoarderValue(int32_t value);

	void Exchange_LivingAndDeadCells(void);
	void Exchange_CellsValue(int32_t oldValue, int32_t newValue);
};


class C2DCellularAutomataF
{
public:

	int32_t NumCellsXDir;
	int32_t NumCellsYDir;

	int32_t NumCellsXDirMinus1;
	int32_t NumCellsYDirMinus1;

	int32_t NumCells;

	float *pCellMap1 = nullptr;
	float *pCellMap2 = nullptr;

	float *PtrToLastUpdatedCellMap = nullptr;

	static constexpr float Value_BlockingCell = -1.0f;
	static constexpr float Value_DeadCell = 0.0f;
	static constexpr float Value_LivingCell = 1.0f;

	C2DCellularAutomataF();
	~C2DCellularAutomataF();


	// Kopierkonstruktor l�schen:
	C2DCellularAutomataF(const C2DCellularAutomataF &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	C2DCellularAutomataF& operator=(const C2DCellularAutomataF &originalObject) = delete;

	void Set_CellValue(int32_t cellIID, float value);
	void Set_CellValue(int32_t cellPosX, int32_t cellPosY, float value);

	float Get_CellValue(int32_t cellIID);
	float Get_CellValue(int32_t cellPosX, int32_t cellPosY);

	float Get_PrevCellValue(int32_t cellIID);
	float Get_PrevCellValue(int32_t cellPosX, int32_t cellPosY);

	void Get_PtrToLastUpdatedCellMap(float **ppOut);

	void Init_CellularAutomata(int32_t numCellsXDir, int32_t numCellsYDir);

	void Reset_CellMap(float cellValue);
	void Kill_All_Cells(void);

	void Init_CellMap(CRandomNumbersNN *pRandomNumbers, int32_t densityValue, int32_t invDensity);
	void Init_CellMap(CRandomNumbersNN *pRandomNumbers, int32_t minXPos, int32_t maxXPos, int32_t minYPos, int32_t maxYPos, int32_t densityValue, int32_t invDensity);

	void Output_CellMap(void);

	bool Save_CellMap(const char* pFilename);
	bool Save_CellMap(const char* pFilename, float valueLivingCell, float valueDeadCell);
	bool Save_CellMapPattern(const char* pFilename, float value);

	void Smooth_CellMap(int32_t smoothingValue);
	void Smooth_BorderlessCellMap(int32_t smoothingValue);

	void Detect_Edges(float valueEdgeCell);
	void Detect_Edges2(float valueNonEdgeCell);

	void Update_CellMap(C2State2DCellularAutomatonRules *pRules);
	void Update_BorderlessCellMap(C2State2DCellularAutomatonRules *pRules);

	void Set_CellMapBoarderValue(float value);

	void Exchange_LivingAndDeadCells(void);
	void Exchange_CellsValue(float oldValue, float newValue);
};



class CNeuralNetHiddenLayer
{
public:

	uint32_t NumOfNeurons = 0;
	uint32_t *pNeuronIDArray = nullptr;

	bool AdditionalBiasNeuron = false;
	uint32_t BiasNeuronID = 0;

	CNeuralNetHiddenLayer();
	~CNeuralNetHiddenLayer();

	// Kopierkonstruktor l�schen:
	CNeuralNetHiddenLayer(const CNeuralNetHiddenLayer &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CNeuralNetHiddenLayer& operator=(const CNeuralNetHiddenLayer &originalObject) = delete;

	void Init_Layer(uint32_t idOfFirstNeuron, uint32_t numOfNeurons, bool additionalBiasNeuron);
	void Reset(void);
};


class CNeuralNet
{
public:

	uint32_t NumOfNeurons = 0;
	uint32_t NumOfUsedNeurons = 0;

	bool HiddenLayer1Used = false;
	bool HiddenLayer2Used = false;
	bool HiddenLayer3Used = false;
	bool ReservorComputing = false;

	CNeuralNetHiddenLayer HiddenLayer1;
	CNeuralNetHiddenLayer HiddenLayer2;
	CNeuralNetHiddenLayer HiddenLayer3;
	

	uint32_t NumInputNeurons = 0;
	uint32_t NumOutputNeurons = 0;
	uint32_t FirstOutputNeuronID = 0;

	uint32_t NumReservoirNeurons = 0;
	uint32_t FirstReservoirNeuronID = 0;
	uint32_t NumReservoirConnectionsPerInputNeuron = 0;
	uint32_t NumReservoirConnectionsPerOutputNeuron = 0;
	uint32_t *pNumInternalReservoirConnectionsArray = nullptr;

	bool AdditionalInputBiasNeuron = false;
	uint32_t InputBiasNeuronID = 0;

	CNeuron *pNeuronArray = nullptr;

	uint32_t NumOfActivationSequenceArrayEntries = 0;
	uint32_t *pActivationSequenceArray = nullptr;

	CRandomNumbersNN RandomNumbers;

	CNeuralNet();
	~CNeuralNet();

	// Kopierkonstruktor l�schen:
	CNeuralNet(const CNeuralNet &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CNeuralNet& operator=(const CNeuralNet &originalObject) = delete;

	void Init_ActivationSequenceArray(uint32_t numOfActivationSequenceArrayEntries);
	void Init_ActivationSequenceArray(uint32_t numOfActivationSequenceArrayEntries, uint32_t *pSequenceArray);	
	void Update_ActivationSequenceArray(uint32_t neuronID, uint32_t entryID);
	
	void Disable_Random_InputNeuron_OutputSynapses(uint64_t newSeed, float mutationRate);
	void Disable_Random_HiddenLayer1Neuron_OutputSynapses(uint64_t newSeed, float mutationRate);
	void Disable_Random_HiddenLayer2Neuron_OutputSynapses(uint64_t newSeed, float mutationRate);
	void Disable_Random_HiddenLayer3Neuron_OutputSynapses(uint64_t newSeed, float mutationRate);

	void Enable_Disabled_InputNeuron_OutputSynapses(uint64_t newSeed, float minPlasticityValue, float maxPlasticityValue);
	void Enable_Disabled_HiddenLayer1Neuron_OutputSynapses(uint64_t newSeed, float minPlasticityValue, float maxPlasticityValue);
	void Enable_Disabled_HiddenLayer2Neuron_OutputSynapses(uint64_t newSeed, float minPlasticityValue, float maxPlasticityValue);
	void Enable_Disabled_HiddenLayer3Neuron_OutputSynapses(uint64_t newSeed, float minPlasticityValue, float maxPlasticityValue);

	void Enable_Disabled_InputNeuron_OutputSynapses(uint64_t newSeed, float minPlasticityValue, float maxPlasticityValue, float mutationRate);
	void Enable_Disabled_HiddenLayer1Neuron_OutputSynapses(uint64_t newSeed, float minPlasticityValue, float maxPlasticityValue, float mutationRate);
	void Enable_Disabled_HiddenLayer2Neuron_OutputSynapses(uint64_t newSeed, float minPlasticityValue, float maxPlasticityValue, float mutationRate);
	void Enable_Disabled_HiddenLayer3Neuron_OutputSynapses(uint64_t newSeed, float minPlasticityValue, float maxPlasticityValue, float mutationRate);
	
	void Init_NeuralNet(uint32_t numOfNeurons);
	
	void Round_OutputWeights(float precision);
	void Remove_Unused_Connections(void);

	void Deactivate_Unused_Neurons(void);

	
	void Set_Activationfunction_OutputLayerNeuron(pActivationFunc pFunc, uint32_t id_InsideLayer);
	void Set_Activationfunction_HiddenLayer1Neuron(pActivationFunc pFunc, uint32_t id_InsideLayer);
	void Set_Activationfunction_HiddenLayer2Neuron(pActivationFunc pFunc, uint32_t id_InsideLayer);
	void Set_Activationfunction_HiddenLayer3Neuron(pActivationFunc pFunc, uint32_t id_InsideLayer);
	void Set_Activationfunction_ReservorNeuron(pActivationFunc pFunc, uint32_t id_InsideReservoir);

	
	void Set_DropoutState_HiddenLayer1Neuron(bool state, uint32_t id_InsideLayer);
	void Set_DropoutState_HiddenLayer2Neuron(bool state, uint32_t id_InsideLayer);
	void Set_DropoutState_HiddenLayer3Neuron(bool state, uint32_t id_InsideLayer);
	void Set_DropoutState_ReservorNeuron(bool state, uint32_t id_InsideReservoir);

	void Init_TwoLayerNetwork(uint32_t numInputNeurons, float minPlasticityValue_InputLayer, float maxPlasticityValue_InputLayer, float inputNeuronLearningRate, bool additionalInputBiasNeuron, uint32_t numOutputNeurons, pActivationFunc pOutputNeuronActivationFunc, float outputNeuronErrorFactor1 = 1.0f, float outputNeuronErrorFactor2 = 1.0f);
	
	void Calculate_Output_TwoLayerNetwork(float *pOutputValueArray, const float *pInputValueArray);
	void Calculate_Output_TwoLayerNetwork(float *pOutputValue, const float *pInputValueArray, uint32_t idOfOutputNeuron);
	void Calculate_Output_TwoLayerNetwork(float *pOutputValueArray);

	float Learning_TwoLayerNetwork(const float *pDesiredOutputValueArray);

	float Learning_TwoLayerNetwork(float desiredOutputValue, uint32_t idOfOutputNeuron);

	void Init_Input_And_OutputNeurons(uint32_t numInputNeurons, float inputNeuronLearningRate, bool additionalInputBiasNeuron, uint32_t numOutputNeurons, pActivationFunc pOutputNeuronActivationFunc, float outputNeuronErrorFactor1 = 1.0f, float outputNeuronErrorFactor2 = 1.0f);

	
	void Init_ReservoirComputing_FullyConnectedReservoir(uint32_t numInputNeurons, uint32_t numReservoirConnectionsPerInputNeuron, uint32_t *pReservoirNeuronsWithInputConnection_IDArray, float inputNeuronLearningRate, bool additionalInputBiasNeuron, uint32_t numReservoirNeurons, pActivationFunc pReservoirNeuronActivationFunc, float reservoirNeuronLearningRate, float minPlasticityValue_ReservoirNeurons, float maxPlasticityValue_ReservoirNeurons, uint32_t numOutputNeurons, uint32_t numReservoirConnectionsPerOutputNeuron, uint32_t *pReservoirNeuronsWithOutputConnection_IDArray, pActivationFunc pOutputNeuronActivationFunc, float outputNeuronErrorFactor1 = 1.0f, float outputNeuronErrorFactor2 = 1.0f);

	void Init_ReservoirComputing(uint32_t numInputNeurons, uint32_t numReservoirConnectionsPerInputNeuron, uint32_t *pReservoirNeuronsWithInputConnection_IDArray, float inputNeuronLearningRate, bool additionalInputBiasNeuron, uint32_t numReservoirNeurons, uint32_t minNumOfReservoirConnections, uint32_t maxNumOfReservoirConnections, pActivationFunc pReservoirNeuronActivationFunc, float reservoirNeuronLearningRate, float minPlasticityValue_ReservoirNeurons, float maxPlasticityValue_ReservoirNeurons, uint32_t numOutputNeurons, uint32_t numReservoirConnectionsPerOutputNeuron, uint32_t *pReservoirNeuronsWithOutputConnection_IDArray, pActivationFunc pOutputNeuronActivationFunc, float outputNeuronErrorFactor1 = 1.0f, float outputNeuronErrorFactor2 = 1.0f);

	void Init_HiddenLayer1(uint32_t numOfNeurons, bool additionalBiasNeuron, bool connectWithOutputLayer, pActivationFunc pFunc, float minPlasticityValue_HiddenLayer1, float maxPlasticityValue_HiddenLayer1, float minPlasticityValue_InputLayer, float maxPlasticityValue_InputLayer, float learningRate, float errorFactor1 = 1.0f, float errorFactor2 = 1.0f);

	void Init_HiddenLayer2(uint32_t numOfNeurons, bool additionalBiasNeuron, bool connectWithOutputLayer, pActivationFunc pFunc, float minPlasticityValue_HiddenLayer2, float maxPlasticityValue_HiddenLayer2, float minPlasticityValue_HiddenLayer1, float maxPlasticityValue_HiddenLayer1, float learningRate, float errorFactor1 = 1.0f, float errorFactor2 = 1.0f);
	
	void Init_HiddenLayer3(uint32_t numOfNeurons, bool additionalBiasNeuron, pActivationFunc pFunc, float minPlasticityValue_HiddenLayer3, float maxPlasticityValue_HiddenLayer3, float minPlasticityValue_HiddenLayer2, float maxPlasticityValue_HiddenLayer2, float learningRate, float errorFactor1 = 1.0f, float errorFactor2 = 1.0f);

	void RandomChange_OutputSynapsePlasticities(uint64_t newSeed, float minPlasticity, float maxPlasticity);
	void RandomChange_OutputSynapsePlasticities(uint64_t newSeed, float minPlasticity, float maxPlasticity, float mutationRate);
	void RandomChange_OutputSynapsePlasticities2(uint64_t newSeed, float minPlasticityVariance, float maxPlasticityVariance);
	void RandomChange_OutputSynapsePlasticities2(uint64_t newSeed, float minPlasticityVariance, float maxPlasticityVariance, float mutationRate);

	void RandomChange_OutputSynapsePlasticities_InputLayer(uint64_t newSeed, float minPlasticity, float maxPlasticity);
	void RandomChange_OutputSynapsePlasticities_InputLayer(uint64_t newSeed, float minPlasticity, float maxPlasticity, float mutationRate);
	void RandomChange_OutputSynapsePlasticities2_InputLayer(uint64_t newSeed, float minPlasticityVariance, float maxPlasticityVariance);
	void RandomChange_OutputSynapsePlasticities2_InputLayer(uint64_t newSeed, float minPlasticityVariance, float maxPlasticityVariance, float mutationRate);

	void RandomChange_OutputSynapsePlasticities_HiddenLayer1(uint64_t newSeed, float minPlasticity, float maxPlasticity);
	void RandomChange_OutputSynapsePlasticities_HiddenLayer1(uint64_t newSeed, float minPlasticity, float maxPlasticity, float mutationRate);
	void RandomChange_OutputSynapsePlasticities2_HiddenLayer1(uint64_t newSeed, float minPlasticityVariance, float maxPlasticityVariance);
	void RandomChange_OutputSynapsePlasticities2_HiddenLayer1(uint64_t newSeed, float minPlasticityVariance, float maxPlasticityVariance, float mutationRate);
	
	void RandomChange_OutputSynapsePlasticities_HiddenLayer2(uint64_t newSeed, float minPlasticity, float maxPlasticity);
	void RandomChange_OutputSynapsePlasticities_HiddenLayer2(uint64_t newSeed, float minPlasticity, float maxPlasticity, float mutationRate);
	void RandomChange_OutputSynapsePlasticities2_HiddenLayer2(uint64_t newSeed, float minPlasticityVariance, float maxPlasticityVariance);
	void RandomChange_OutputSynapsePlasticities2_HiddenLayer2(uint64_t newSeed, float minPlasticityVariance, float maxPlasticityVariance, float mutationRate);
	
	void RandomChange_OutputSynapsePlasticities_HiddenLayer3(uint64_t newSeed, float minPlasticity, float maxPlasticity);
	void RandomChange_OutputSynapsePlasticities_HiddenLayer3(uint64_t newSeed, float minPlasticity, float maxPlasticity, float mutationRate);
	void RandomChange_OutputSynapsePlasticities2_HiddenLayer3(uint64_t newSeed, float minPlasticityVariance, float maxPlasticityVariance);
	void RandomChange_OutputSynapsePlasticities2_HiddenLayer3(uint64_t newSeed, float minPlasticityVariance, float maxPlasticityVariance, float mutationRate);
	
	void RandomChange_OutputSynapsePlasticities_ReservoirNeurons(uint64_t newSeed, float minPlasticity, float maxPlasticity);
	void RandomChange_OutputSynapsePlasticities_ReservoirNeurons(uint64_t newSeed, float minPlasticity, float maxPlasticity, float mutationRate);
	void RandomChange_OutputSynapsePlasticities2_ReservoirNeurons(uint64_t newSeed, float minPlasticityVariance, float maxPlasticityVariance);
	void RandomChange_OutputSynapsePlasticities2_ReservoirNeurons(uint64_t newSeed, float minPlasticityVariance, float maxPlasticityVariance, float mutationRate);

	
	void Clone_OutputSynapsePlasticities(CNeuralNet *pOriginalBrain);
	void Clone_OutputSynapsePlasticities(CNeuralNet *pOriginalBrain, float variance, uint64_t newSeed);
	void Clone_OutputSynapsePlasticities(CNeuralNet *pOriginalBrain, float variance, float mutationRate, uint64_t newSeed);
	void Clone_OutputSynapsePlasticities(CNeuralNet *pOriginalBrain, float minVariance, float maxVariance, float mutationRate, uint64_t newSeed);

	void Clone_OutputSynapsePlasticities2(CNeuralNet *pOriginalBrain, float varianceMemoryNeurons, uint64_t newSeed);
	void Clone_OutputSynapsePlasticities2(CNeuralNet *pOriginalBrain, float varianceMemoryNeurons, float mutationRate, uint64_t newSeed);
	
	void Clone_OutputSynapsePlasticities3(CNeuralNet *pOriginalBrain, float varianceNonMemoryNeurons, uint64_t newSeed);
	void Clone_OutputSynapsePlasticities3(CNeuralNet *pOriginalBrain, float varianceNonMemoryNeurons, float mutationRate, uint64_t newSeed);

	void Clone_OutputSynapsePlasticities_InputLayer(CNeuralNet *pOriginalBrain, float variance, uint64_t newSeed);
	void Clone_OutputSynapsePlasticities_InputLayer(CNeuralNet *pOriginalBrain, float variance, float mutationRate, uint64_t newSeed);
	void Clone_OutputSynapsePlasticities_InputLayer(CNeuralNet *pOriginalBrain, float minVariance, float maxVariance, float mutationRate, uint64_t newSeed);
	
	void Clone_OutputSynapsePlasticities_HiddenLayer1(CNeuralNet *pOriginalBrain, float variance, uint64_t newSeed);
	void Clone_OutputSynapsePlasticities_HiddenLayer1(CNeuralNet *pOriginalBrain, float variance, float mutationRate, uint64_t newSeed);
	void Clone_OutputSynapsePlasticities_HiddenLayer1(CNeuralNet *pOriginalBrain, float minVariance, float maxVariance, float mutationRate, uint64_t newSeed);

	void Clone_OutputSynapsePlasticities_HiddenLayer2(CNeuralNet *pOriginalBrain, float variance, uint64_t newSeed);
	void Clone_OutputSynapsePlasticities_HiddenLayer2(CNeuralNet *pOriginalBrain, float variance, float mutationRate, uint64_t newSeed);
	void Clone_OutputSynapsePlasticities_HiddenLayer2(CNeuralNet *pOriginalBrain, float minVariance, float maxVariance, float mutationRate, uint64_t newSeed);
	
	void Clone_OutputSynapsePlasticities_HiddenLayer3(CNeuralNet *pOriginalBrain, float variance, uint64_t newSeed);
	void Clone_OutputSynapsePlasticities_HiddenLayer3(CNeuralNet *pOriginalBrain, float variance, float mutationRate, uint64_t newSeed);
	void Clone_OutputSynapsePlasticities_HiddenLayer3(CNeuralNet *pOriginalBrain, float minVariance, float maxVariance, float mutationRate, uint64_t newSeed);

	void Combine_OutputSynapsePlasticities_InputLayer(CNeuralNet *pParentBrain1, CNeuralNet *pParentBrain2, float minWeight1, uint64_t newSeed);
	void Combine_OutputSynapsePlasticities_HiddenLayer1(CNeuralNet *pParentBrain1, CNeuralNet *pParentBrain2, float minWeight1, uint64_t newSeed);
	void Combine_OutputSynapsePlasticities_HiddenLayer2(CNeuralNet *pParentBrain1, CNeuralNet *pParentBrain2, float minWeight1, uint64_t newSeed);
	void Combine_OutputSynapsePlasticities_HiddenLayer3(CNeuralNet *pParentBrain1, CNeuralNet *pParentBrain2, float minWeight1, uint64_t newSeed);
	void Combine_OutputSynapsePlasticities_ReservoirNeurons(CNeuralNet *pParentBrain1, CNeuralNet *pParentBrain2, float minWeight1, uint64_t newSeed);

	void Combine_OutputSynapsePlasticities(CNeuralNet *pParentBrain1, CNeuralNet *pParentBrain2, float minWeight1, uint64_t newSeed);

	
	void Calculate_Output_UseActivationSequence(float *pOutputValueArray, const float *pInputValueArray);
	float Calculate_Output_With_Error_UseActivationSequence(float *pOutputValueArray, const float *pInputValueArray);
	
	void Set_InputNeuronValues_And_Propagate_Them(const float *pInputValueArray);
	void Set_InputNeuronValues_And_Propagate_Them(const float *pInputValueArray, uint32_t offset, uint32_t numValues);
	

	void Set_InputValues_HiddenLayer1(const float *pInputValueArray);
	void Set_InputValues_HiddenLayer1(float value);
	void Set_InputValues_HiddenLayer1(float value, uint32_t id_InsideLayer);
	
	void Get_Output(float *pOutputValueArray);

	void Calculate_Output(float *pOutputValueArray, const float *pInputValueArray);	
	float Calculate_Output2(const float *pInputValueArray, uint32_t idOfOutputNeuron);
	void Calculate_Output_IgnoreInputNeurons(float *pOutputValueArray);
	float Calculate_Output_With_Error(float *pOutputValueArray, const float *pInputValueArray);
	
	void Calculate_Error(float *pErrorValueArray, const float *pDesiredOutputValueArray);
	float Calculate_Error(const float *pDesiredOutputValueArray);

	float Learning_UseActivationSequence(const float *pDesiredOutputValueArray);

	float Backpropagate_Error_UseActivationSequence(const float *pDesiredOutputValueArray);
	void Adjust_Weights_After_Backpropagation_UseActivationSequence(void);

	float Learning(const float *pDesiredOutputValueArray);

	float Backpropagate_Error(const float *pDesiredOutputValueArray);
	void Adjust_Weights_After_Backpropagation(void);
	
	float Learning(float desiredOutputValue, uint32_t idOfOutputNeuron);
	
	float Backpropagate_Error(float desiredOutputValue, uint32_t idOfOutputNeuron);

	

	// Nur die Plastizit�tswerte der mit den Output-Neuronen verbundenen Synapsen werden modifiziert:
	float ExtremeLearning(const float *pDesiredOutputValueArray);

	// Nur die Plastizit�tswerte der mit den Output-Neuronen verbundenen Synapsen werden modifiziert:
	float ExtremeLearning(float desiredOutputValue, uint32_t idOfOutputNeuron);

	
	void Reset_Memory_Of_ReservoirNeurons(void);
	

	void Calculate_Output_ReservoirComputing(float *pOutputValueArray, const float *pInputValueArray, uint32_t numAdditionalRecurrentCycles = 0);

	
	void Update_InputNeurons_Prior_ReservorUpdate(const float *pInputValueArray);
	void Update_ReservoirNeurons(void);
	void Update_OutputNeurons_After_ReservorUpdate(float *pOutputValueArray);

	float Learning_ReservoirComputing(const float *pDesiredOutputValueArray);

}; // end of class CNeuralNet


class C2DPatternDetector
{
public:

	uint32_t SizeXDir;
	uint32_t SizeYDir;
	uint32_t Size;  // SizeXDir * SizeYDir

	float *pValueArray = nullptr;

	C2DPatternDetector();
	~C2DPatternDetector();

	// Kopierkonstruktor l�schen:
	C2DPatternDetector(const C2DPatternDetector &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	C2DPatternDetector& operator=(const C2DPatternDetector &originalObject) = delete;

	void Initialize(uint32_t sizeXDir, uint32_t sizeYDir);

	bool Load_Data(const char* pFilename);
	bool Save_Data(const char* pFilename);
	
	bool Load_Binary_Data_From_Bitmap(const char* pDescFilename /*not the bitmap*/, bool binaryImageData, bool use_0_And_1_Values = true);
	bool Load_Data_From_Bitmap(const char* pDescFilename /*not the bitmap*/, float dataBiasValue = 0.0f);

	bool Search_Pattern(int32_t *pOutPatternCount, int32_t *pOutPatternPosXArray, int32_t *pOutPatternPosYArray, int32_t maxPosArrayElements, const float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, float minActivationValue);

	bool Search_Pattern(int32_t *pOutPatternCount, int32_t *pOutPatternPosXArray, int32_t *pOutPatternPosYArray, int32_t maxPosArrayElements, const float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, float activationValue, float minTolerance, float maxTolerance);
};


// lokales rezeptives Feld als neuronales Netz:
// mehrere Input-Neuronen, die mit einem Output-Neuron verkn�pft sind

class C2DLocalReceptiveField // LocalReceptiveField: LRF
{
public:

	uint32_t SizeXDir;
	uint32_t SizeYDir;
	uint32_t Size;  // SizeXDir * SizeYDir

	float *pValueArray = nullptr;
	float *pInputErrorValueArray = nullptr;
	float *pSumOfInputValuesArray = nullptr;

	float SumOfOutputValues;
	float OutputErrorValue;
	float Bias;
	

	float SumOfActivationValues;
	float MaxActivationValue;
	float MinActivationValue;

	float FittingValue;

	C2DLocalReceptiveField();
	~C2DLocalReceptiveField();

	// Kopierkonstruktor l�schen:
	C2DLocalReceptiveField(const C2DLocalReceptiveField &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	C2DLocalReceptiveField& operator=(const C2DLocalReceptiveField &originalObject) = delete;

	void Initialize(uint32_t sizeXDir, uint32_t sizeYDir);

	bool Load_Data(const char* pFilename);
	
	bool Load_Binary_Data_From_Bitmap(const char* pDescFilename /*not the bitmap*/, bool binaryImageData, bool use_0_And_1_Values = true);
	bool Load_Data_From_Bitmap(const char* pDescFilename /*not the bitmap*/, float dataBiasValue = 0.0f);
	
	bool Save_Data(const char* pFilename);
	
	void Reset_ErrorValues(void);
	void Reset_SumOfOutputAndInputValues(void);
	void Set_Value(float value, uint32_t index);
	void Clear_Values(float value = 0.0f);
	void Set_Bias(float value);

	// Achtung: Werte von 0 lassen sich mittels Backpropagation-Training nicht ver�ndern! 
	void Generate_RandomValues(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float minBiasValue, float maxBiasValue, bool includingZeroValues = false);

	// Achtung: Werte von 0 lassen sich mittels Backpropagation-Training nicht ver�ndern! 
	void Generate_RandomValues(CRandomNumbersNN *pRandomNumbers, int32_t minValue, int32_t maxValue, float minBiasValue, float maxBiasValue, bool includingZeroValues = false);

	void Mutate_Values1(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float mutationRate);
	void Mutate_Values2(CRandomNumbersNN *pRandomNumbers, float minVariance, float maxVariance, float mutationRate);

	void Clone_Values(C2DLocalReceptiveField *pOriginalLRF);
	void Clone_Values(C2DLocalReceptiveField *pOriginalLRF, CRandomNumbersNN *pRandomNumbers, float filterVariance, float biasVariance, float mutationRate);

	void Combine_Values(C2DLocalReceptiveField *pParentLRF1, C2DLocalReceptiveField *pParentLRF2, CRandomNumbersNN *pRandomNumbers, float minWeight1);
	
	void Reset_ActivationData(void);
	void Update_ActivationData(float value);
	
	void Calculate_FittingValue(float fittingParam1, float fittingParam2);
	
	void Calculate_FeatureMap(float *pFeatureMap, const float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, pActivationFunc pFunc);
	
	void Add_Feature_To_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, const float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY,
		int32_t strideX, int32_t strideY, pActivationFunc pFunc);
	
	// Bei der Fehlerberecnung werden die Fehler der direkt nachgeschalteten C2DLocalReceptiveField-Instanzen ber�cksichtigt:
	void Begin_ErrorCalculation(C2DLocalReceptiveField *pPostLocalReceptiveField);
	void Continue_ErrorCalculation(C2DLocalReceptiveField *pPostLocalReceptiveField);
	void Finish_ErrorCalculation(float inputErrorFactor1, float inputErrorFactor2, float outputErrorFactor1, float outputErrorFactor2);
	
	// Train:

	void Adjust_LocalReceptiveField_AfterErrorCalculations(float learningRate);
	
	void Train_Final_LocalReceptiveField(CNeuralNet *pBrain, uint32_t firstReceiverNeuronID, uint32_t lastReceiverNeuronID, float learningRate, float receiverNeuronErrorFactor1, float receiverNeuronErrorFactor2, float inputErrorFactor1, float inputErrorFactor2, float outputErrorFactor1, float outputErrorFactor2);
};


// lokales rezeptives Feld als neuronales Netz:
// mehrere Input-Neuronen, die mit einem Output-Neuron verkn�ft sind

class C1DLocalReceptiveField // LocalReceptiveField: LRF
{
public:

	uint32_t Size;

	float *pValueArray = nullptr;
	float *pInputErrorValueArray = nullptr;
	float *pSumOfInputValuesArray = nullptr;

	float SumOfOutputValues;

	float OutputErrorValue;

	float Bias;
	

	float SumOfActivationValues;
	float MaxActivationValue;
	float MinActivationValue;

	float FittingValue;

	C1DLocalReceptiveField();
	~C1DLocalReceptiveField();

	// Kopierkonstruktor l�schen:
	C1DLocalReceptiveField(const C1DLocalReceptiveField &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	C1DLocalReceptiveField& operator=(const C1DLocalReceptiveField &originalObject) = delete;

	void Initialize(uint32_t size);

	bool Load_Data(const char* pFilename);

	bool Save_Data(const char* pFilename);

	void Reset_ErrorValues(void);

	void Reset_SumOfOutputAndInputValues(void);

	void Set_Value(float value, uint32_t index);
	void Clear_Values(float value = 0.0f);
	void Set_Bias(float value);

	// Achtung: Werte von 0 lassen sich mittels Backpropagation-Training nicht ver�ndern! 
	void Generate_RandomValues(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float minBiasValue, float maxBiasValue, bool includingZeroValues = false);

	// Achtung: Werte von 0 lassen sich mittels Backpropagation-Training nicht ver�ndern! 
	void Generate_RandomValues(CRandomNumbersNN *pRandomNumbers, int32_t minValue, int32_t maxValue, float minBiasValue, float maxBiasValue, bool includingZeroValues = false);

	void Mutate_Values1(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float mutationRate);
	void Mutate_Values2(CRandomNumbersNN *pRandomNumbers, float minVariance, float maxVariance, float mutationRate);

	void Clone_Values(C1DLocalReceptiveField *pOriginalLRF);
	void Clone_Values(C1DLocalReceptiveField *pOriginalLRF, CRandomNumbersNN *pRandomNumbers, float filterVariance, float biasVariance, float mutationRate);

	void Combine_Values(C1DLocalReceptiveField *pParentLRF1, C1DLocalReceptiveField *pParentLRF2, CRandomNumbersNN *pRandomNumbers, float minWeight1);

	void Reset_ActivationData(void);
	void Update_ActivationData(float value);

	void Calculate_FittingValue(float fittingParam1, float fittingParam2);
	void Calculate_FeatureMap(float *pFeatureMap, const float *pInputArray, int32_t inputArraySize, int32_t stride, pActivationFunc pFunc);

	void Add_Feature_To_FeatureMap(/*old/new feature map:*/ float *pFeatureMap, const float *pInputArray, int32_t inputArraySize, int32_t stride, pActivationFunc pFunc);

	// Bei der Fehlerberecnung werden die Fehler der direkt nachgeschalteten C1DLocalReceptiveField-Instanzen ber�cksichtigt:

	void Begin_ErrorCalculation(C1DLocalReceptiveField *pPostLocalReceptiveField);
	void Continue_ErrorCalculation(C1DLocalReceptiveField *pPostLocalReceptiveField);
	void Finish_ErrorCalculation(float inputErrorFactor1, float inputErrorFactor2, float outputErrorFactor1, float outputErrorFactor2);
	
	// Train:

	void Adjust_LocalReceptiveField_AfterErrorCalculations(float learningRate);
	
	void Train_Final_LocalReceptiveField(CNeuralNet *pBrain, uint32_t firstReceiverNeuronID, uint32_t lastReceiverNeuronID, float learningRate, float receiverNeuronErrorFactor1, float receiverNeuronErrorFactor2, float inputErrorFactor1, float inputErrorFactor2, float outputErrorFactor1, float outputErrorFactor2);
};



#define NormalizeImageData


class CImageDataPreprocessing
{
public:

	CRandomNumbersNN RandomNumbers;

	uint32_t Stride;
	uint32_t LRFSizeX; // LRF: Local Receptive Field
	uint32_t LRFSizeY;
	uint32_t LRFSize;

	uint32_t UnpooledFeatureMapSizeX;
	uint32_t UnpooledFeatureMapSizeY;
	uint32_t UnpooledFeatureMapSize;

	uint32_t FeatureMapSizeX;
	uint32_t FeatureMapSizeY;
	uint32_t FeatureMapSize;

	// Anzahl der lokalen rezeptiven Felder bzw. Feature-Maps:
	uint32_t NumFeatureMaps; 

	CImageDataF *pUnpooledFeatureMapArray = nullptr;
	CImageDataF *pFeatureMapArray = nullptr;
	C2DLocalReceptiveField *pLRFArray = nullptr;

	C2DLocalReceptiveField TempLRF;

	uint32_t ImageSizeX;
	uint32_t ImageSizeY;
	uint32_t ImageSize;

	uint32_t IdOfWorstFittedLRF = 0;
	uint32_t IdOfBestFittedLRF = 0;

	CImageDataPreprocessing(uint32_t imageSizeX, uint32_t imageSizeY, uint32_t numFeatureMaps, uint32_t lRFSizeX, uint32_t lRFSizeY, uint32_t stride, float minBiasValue, float maxBiasValue);

	// Achtung: LRF-Werte von 0 lassen sich mittels Backpropagation-Training nicht ver�ndern! 
	CImageDataPreprocessing(uint32_t imageSizeX, uint32_t imageSizeY, uint32_t numFeatureMaps, uint32_t lRFSizeX, uint32_t lRFSizeY, uint32_t stride, int32_t minLRFValue, int32_t maxLRFValue, float minBiasValue, float maxBiasValue, bool includingZeroValues = false);

	// Achtung: LRF-Werte von 0 lassen sich mittels Backpropagation-Training nicht ver�ndern! 
	CImageDataPreprocessing(uint32_t imageSizeX, uint32_t imageSizeY, uint32_t numFeatureMaps, uint32_t lRFSizeX, uint32_t lRFSizeY, uint32_t stride, float minLRFValue, float maxLRFValue, float minBiasValue, float maxBiasValue, bool includingZeroValues = false);

	
	~CImageDataPreprocessing();

	
	// Kopierkonstruktor l�schen:
	CImageDataPreprocessing(const CImageDataPreprocessing &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CImageDataPreprocessing& operator=(const CImageDataPreprocessing &originalObject) = delete;

	void Init_Standard_LocalReceptiveFields(float minBiasValue, float maxBiasValue);

	void Init_LocalReceptiveField(float *pValueArray, uint32_t id);

	void Single_LocalReceptiveField_Evolution(float *pImageData, uint32_t idOfLRF, float minFilterValue, float maxFilterValue, float minBiasValue, float maxBiasValue, pActivationFunc pFunc, bool includingZeroValues = true);

	void Single_LocalReceptiveField_Evolution(CImageDataF *pImageArray, uint32_t numImages, uint32_t idOfLRF, float minFilterValue, float maxFilterValue, float minBiasValue, float maxBiasValue, pActivationFunc pFunc, bool includingZeroValues = false);
	
	void Single_LocalReceptiveField_Evolution(float *pImageData, uint32_t idOfLRF, int32_t minFilterValue, int32_t maxFilterValue, float minBiasValue, float maxBiasValue, pActivationFunc pFunc, bool includingZeroValues = false);
	
	void Single_LocalReceptiveField_Evolution(CImageDataF *pImageArray, uint32_t numImages, uint32_t idOfLRF, int32_t minFilterValue, int32_t maxFilterValue, float minBiasValue, float maxBiasValue, pActivationFunc pFunc, bool includingZeroValues = false);

	void Prepare_LocalReceptiveField_Analysis(void);
	void Display_LocalReceptiveField_Analysis(void);
	
	void Analyze_LocalReceptiveFields(float *pImageData, pActivationFunc pFunc);
	void Analyze_LocalReceptiveFields(CImageDataF *pImageArray, uint32_t numImages, pActivationFunc pFunc);

	void Update_Evolution(float minValue, float maxValue, float minBiasValue, float maxBiasValue, float fittingParam1 = 0.1f, float fittingParam2 = 0.5f, bool includingZeroValues = false);
	
	void Update_Evolution(int32_t minValue, int32_t maxValue, float minBiasValue, float maxBiasValue, float fittingParam1 = 0.1f, float fittingParam2 = 0.5f, bool includingZeroValues = false);
	
	void Preprocess_Data(float *pImageData, pActivationFunc pFunc, uint32_t poolingType);
	
	void Preprocess_Data(CImageDataF *pImageArray, uint32_t numImages, pActivationFunc pFunc, uint32_t poolingType);

	// pImageIDArray erm�glicht die Auswahl einzelner Images aus dem pImageArray:
	void Preprocess_Data(CImageDataF *pImageArray, uint32_t *pImageIDArray, uint32_t numImages, pActivationFunc pFunc, uint32_t poolingType);

	void Preprocess_Data(CNeuralNet *pBrain, float *pImageData, pActivationFunc pFunc, uint32_t poolingType);

	// pInOutNeuronIDOffset:
	// Verweist beim Methodenaufruf auf die ID des ersten Neurons, an welches die Berechnungsergebnisse weitergeleitet werden sollen.
	// Verweist nach dem Methodenaufruf auf die Nachfolge-ID des letzten Neurons, an welches die Berechnungsergebnisse weitergeleitet wurden. 
	void Preprocess_Data(CNeuralNet *pBrain, float *pImageData, uint32_t *pInOutNeuronIDOffset, pActivationFunc pFunc, uint32_t poolingType);

	void Preprocess_Data(CNeuralNet *pBrain, CImageDataF *pImageArray, uint32_t numImages, pActivationFunc pFunc, uint32_t poolingType);

	void Preprocess_Data(CNeuralNet *pBrain, CImageDataF *pImageArray, uint32_t numImages, uint32_t *pInOutNeuronIDOffset, pActivationFunc pFunc, uint32_t poolingType);

	// pImageIDArray erm�glicht die Auswahl einzelner Images aus dem pImageArray:
	void Preprocess_Data(CNeuralNet *pBrain, CImageDataF *pImageArray, uint32_t *pImageIDArray, uint32_t numImages, pActivationFunc pFunc, uint32_t poolingType);

	// pImageIDArray erm�glicht die Auswahl einzelner Images aus dem pImageArray:
	void Preprocess_Data(CNeuralNet *pBrain, CImageDataF *pImageArray, uint32_t *pImageIDArray, uint32_t numImages, uint32_t *pInOutNeuronIDOffset, pActivationFunc pFunc, uint32_t poolingType);

	void Train_Final_LocalReceptiveFields(CNeuralNet *pBrain, float learningRate, float receiverNeuronErrorFactor1, float receiverNeuronErrorFactor2, float inputErrorFactor1, float inputErrorFactor2, float outputErrorFactor1, float outputErrorFactor2);

	void Train_Final_LocalReceptiveFields(CNeuralNet *pBrain, uint32_t *pInOutNeuronIDOffset, float learningRate, float receiverNeuronErrorFactor1, float receiverNeuronErrorFactor2, float inputErrorFactor1, float inputErrorFactor2, float outputErrorFactor1, float outputErrorFactor2);

	void Train_LocalReceptiveFields(CImageDataPreprocessing* pPostDataPreprocessingStep, float learningRate, float inputErrorFactor1, float inputErrorFactor2, float outputErrorFactor1, float outputErrorFactor2);

	void Train_LocalReceptiveFields(CImageDataPreprocessing* pPostDataPreprocessingStep, uint32_t *pLRF_IDArray, uint32_t numOfPostConnectedLRFs, float learningRate, float inputErrorFactor1, float inputErrorFactor2, float outputErrorFactor1, float outputErrorFactor2);
};

class CShortTermMemoryElement
{
public:

	uint32_t NumOfNeurons = 0;
	uint32_t NumOfMemoryNeurons = 0;
	uint32_t NumOfOutputNeurons = 0;

	CNeuron *pNeuronArray = nullptr;

	uint32_t FirstOutputNeuronID = 0;
	uint32_t FirstMemoryNeuronID = 0;
	
	CShortTermMemoryElement();
	~CShortTermMemoryElement();

	// Kopierkonstruktor l�schen:
	CShortTermMemoryElement(const CShortTermMemoryElement &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CShortTermMemoryElement& operator=(const CShortTermMemoryElement &originalObject) = delete;

	void Set_MemoryNeuronActivationFunction(pActivationFunc pFunc, uint32_t idOfMemeoryNeuron);
	void Set_OutputNeuronActivationFunction(pActivationFunc pFunc, uint32_t idOfOutputNeuron);

	void Reset_Memory(void);
	float Get_Actual_Output(void);
	void Get_Actual_Output(float *pOutputValueArray);
	float Get_MemoryNeuronOutput(uint32_t idOfMemeoryNeuron);

	
	void Initialize_SingleInput_SingleOutput(uint32_t numOfMemoryNeurons, pActivationFunc pFunc, float memoryDrecreaseFactor = 1.0f);
	void Initialize_SingleInput_SingleOutput(uint32_t numOfMemoryNeurons, pActivationFunc pFunc1, pActivationFunc pFunc_LastMemoryNeuron, float memoryDrecreaseFactor = 1.0f);
	void Initialize_SingleInput_OutputArray(uint32_t numOfOutputNeurons, pActivationFunc pFunc, float memoryDrecreaseFactor = 1.0f);
	
	float Calculate_Output(float inputValue);
	void Calculate_Output(float *pOutputValueArray, float inputValue);
};









class CNeuralNetPopulation
{
public:

	uint64_t Seed = 1;
	CRandomNumbersNN RandomNumbers;

	uint32_t PopulationSize;
	uint32_t PopulationSizePlus4;

	CNeuralNet **ppUsedNeuralNetArray = nullptr;

	float *pFitnessScoreArray = nullptr;

	static constexpr uint32_t constNumOfBestFittedBrains = 10;
	uint32_t IDArrayOfBestFittedBrains[constNumOfBestFittedBrains];
	float FitnessArrayOfBestFittedBrains[constNumOfBestFittedBrains];

	static constexpr uint32_t constNumOfWorstFittedBrains = 10;
	uint32_t IDArrayOfWorstFittedBrains[constNumOfWorstFittedBrains];
	float FitnessArrayOfWorstFittedBrains[constNumOfWorstFittedBrains];

	bool UseAdditionalMutatedBestBrain = false;
	bool UseAdditionalMutatedSecondBestBrain = false;
	bool UseAdditionalBestBrainsChild = false;

	static constexpr uint32_t constNumOfRandomBrainsChilds = 1;
	bool UseAdditionalRandomBrainsChild[constNumOfRandomBrainsChilds];

	static constexpr uint32_t constNumPopulationSearchStepsMax = 3;

	uint32_t NumOfInputNeurons = 0;
	uint32_t NumOfOutputNeurons = 0;

	uint32_t MinNumOfHiddenNeuronsL1 = 0;
	uint32_t MaxNumOfHiddenNeuronsL1 = 0;
	uint32_t MinNumOfHiddenNeuronsL2 = 0;
	uint32_t MaxNumOfHiddenNeuronsL2 = 0;

	pActivationFunc pOutputNeuronActivationFunc = nullptr;
	pActivationFunc pHiddenLayer1NeuronActivationFunc = nullptr;
	pActivationFunc pHiddenLayer2NeuronActivationFunc = nullptr;

	CNeuralNetPopulation();
	~CNeuralNetPopulation();

	// Kopierkonstruktor l�schen:
	CNeuralNetPopulation(const CNeuralNetPopulation  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CNeuralNetPopulation & operator=(const CNeuralNetPopulation  &originalObject) = delete;

	void Initialize(uint32_t populationSize, uint32_t numOfInputNeurons, uint32_t numOfOutputNeurons, uint32_t minNumOfHiddenNeuronsL1, uint32_t maxNumOfHiddenNeuronsL1, uint32_t minNumOfHiddenNeuronsL2, uint32_t maxNumOfHiddenNeuronsL2, pActivationFunc pOutputNeuronFunc, pActivationFunc pHiddenLayer1NeuronFunc, pActivationFunc pHiddenLayer2NeuronFunc);

	void Set_Activationfunction_OutputLayerNeuron(pActivationFunc pFunc);
	void Set_Activationfunction_HiddenLayer1Neuron(pActivationFunc pFunc);
	void Set_Activationfunction_HiddenLayer2Neuron(pActivationFunc pFunc);

	void Change_Seed(uint64_t seed);

	CNeuralNet* Get_Best_Evolved_NeuralNet(void);
	void Get_Best_Evolved_NeuralNet_Ext(CNeuralNet* pOutNeuralNet);
	void Get_HiddenNeuronNumbers_Of_Best_Evolved_NeuralNet(uint32_t *pNumOfHiddenNeuronsL1, uint32_t *pNumOfHiddenNeuronsL2);

	void Round_OutputWeights(float precision);

	void Replace_WorstFitted_Brain(float probabilityValue);
	void Replace_SecondWorstFitted_Brain(float probabilityValue);
	void Replace_ThirdWorstFitted_Brain(float probabilityValue);

	void Restore_ConnectionTopology_WorstFitted_Brain(float minSynapticPlasticity, float maxSynapticPlasticity);
	void Restore_ConnectionTopology_SecondWorstFitted_Brain(float minSynapticPlasticity, float maxSynapticPlasticity);
	void Restore_ConnectionTopology_ThirdWorstFitted_Brain(float minSynapticPlasticity, float maxSynapticPlasticity);

	void RandomChange_OutputSynapsePlasticities(uint64_t seed, float minSynapticPlasticity, float maxSynapticPlasticity);
	void RandomChange_OutputSynapsePlasticities(uint64_t seed, float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRate);

	void RandomChange_OutputSynapsePlasticities(float minSynapticPlasticity, float maxSynapticPlasticity);
	void RandomChange_OutputSynapsePlasticities(float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRate);

	void RandomChange_ConnectionTopologies(uint64_t seed, float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRateL1, float mutationRateL2, float mutationRateL3, bool reduceNeuralConnections);
	void RandomChange_ConnectionTopologies(float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRateL1, float mutationRateL2, float mutationRateL3, bool reduceNeuralConnections);


	void Update_Population(float *pFitnessValueArray);
	void Update_Population_Ext(float *pFitnessValueArray);

	void Update_Evolution_Combine_BestTwoBrains(void);
	void Update_Evolution_Combine_BestTwoBrains_Ext(void);

	void Update_Evolution_Combine_TwoBrains(void);
	void Update_Evolution_Combine_TwoBrains_Ext(void);

	void Update_Evolution_ConnectionTopologyMutationsOnly(float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRateL1, float mutationRateL2, float mutationRateL3, bool reduceNeuralConnections);

	void Update_Evolution_SynapticPlasticityMutationsOnly(float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRate, bool extremeLearning);

	void Update_Evolution_SynapticPlasticityMutationsOnly(float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRateL1, float mutationRateL2, float mutationRateL3, bool extremeLearning);

	void Update_Evolution_BestBrainOnly(float minSynapticPlasticityVariance, float maxSynapticPlasticityVariance, float mutationRate);

	void Update_Evolution_BestBrainOnly(float minSynapticPlasticityVariance, float maxSynapticPlasticityVariance, float mutationRateL1, float mutationRateL2, float mutationRateL3);

	void Update_Evolution_BestBrainOnly_Ext(float minSynapticPlasticityVariance, float maxSynapticPlasticityVariance, float mutationRate);

	void Update_Evolution_BestBrainOnly_Ext(float minSynapticPlasticityVariance, float maxSynapticPlasticityVariance, float mutationRateL1, float mutationRateL2, float mutationRateL3);

	void Update_Evolution_SecondBestBrainOnly(float minSynapticPlasticityVariance, float maxSynapticPlasticityVariance, float mutationRate);

	void Update_Evolution_SecondBestBrainOnly(float minSynapticPlasticityVariance, float maxSynapticPlasticityVariance, float mutationRateL1, float mutationRateL2, float mutationRateL3);

	void Update_Evolution_SecondBestBrainOnly_Ext(float minSynapticPlasticityVariance, float maxSynapticPlasticityVariance, float mutationRate);

	void Update_Evolution_SecondBestBrainOnly_Ext(float minSynapticPlasticityVariance, float maxSynapticPlasticityVariance, float mutationRateL1, float mutationRateL2, float mutationRateL3);

private:

	void Reinitialize_NeuralNet(uint32_t brainID, uint32_t numOfHiddenNeuronsL1, uint32_t numOfHiddenNeuronsL2);
	
};



#endif