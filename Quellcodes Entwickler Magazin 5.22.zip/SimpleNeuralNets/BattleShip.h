// Schutz vor Mehrfachdeklarationen:
#ifndef _BattleShip_H_
#define _BattleShip_H_

#include <iostream>
#include "NeuralNet_V2.h"


static constexpr int32_t ConstGameBoardSizePerDir = 10;
static constexpr int32_t ConstGameBoardSizePerDirWithPadding = ConstGameBoardSizePerDir + 2;
static constexpr int32_t ConstGameBoardSizePerDirWithPaddingMinus1 = ConstGameBoardSizePerDirWithPadding - 1;
static constexpr float ConstInvGameBoardSizePerDir = 0.1f;
static constexpr int32_t ConstGameBoardHalfSizePerDir = 5;
static constexpr int32_t ConstGameBoardHalfSizePerDirMinus1 = 4;
static constexpr int32_t ConstGameBoardSizePerDirMinus1 = 9;
static constexpr int32_t ConstGameBoardSizePerDirMinus2 = 8;
static constexpr int32_t ConstGameBoardSizePerDirMinus3 = 7;
static constexpr int32_t ConstGameBoardSize = 100;
static constexpr int32_t ConstGameBoardSizeMinus1 = 99;

static constexpr int32_t ConstGameBoard_Water = 0;
static constexpr int32_t ConstGameBoard_WaterShot = 1;
static constexpr int32_t ConstGameBoard_IntactElement = 2;
static constexpr int32_t ConstGameBoard_DamagedElement = 3;
static constexpr int32_t ConstGameBoard_DestroyedElement = 4;
static constexpr int32_t ConstGameBoard_ForbiddenTile = 2;


static int32_t g_NavalEntityL2_Horizontal[3][4] = { { 0, 0, 0, 0},
                                                    { 0, 2, 2, 0},
                                                    { 0, 0, 0, 0} };

static int32_t g_NavalEntityL2_Vertical[4][3] = { { 0, 0, 0 },
                                                  { 0, 2, 0 },
                                                  { 0, 2, 0 },
                                                  { 0, 0, 0 } };

static int32_t g_NavalEntityL3_Horizontal[3][5] = { { 0, 0, 0, 0, 0 },
                                                    { 0, 2, 2, 2, 0 },
									                { 0, 0, 0, 0, 0 } };

static int32_t g_NavalEntityL3_Vertical[5][3] = { { 0, 0, 0 },
                                                  { 0, 2, 0 },
                                                  { 0, 2, 0 },
                                                  { 0, 2, 0 },
                                                  { 0, 0, 0 } };

static int32_t g_NavalEntityL4_Horizontal[3][6] = { { 0, 0, 0, 0, 0, 0 },
                                                    { 0, 2, 2, 2, 2, 0 },
                                                    { 0, 0, 0, 0, 0, 0 } };

static int32_t g_NavalEntityL4_Vertical[6][3] = { { 0, 0, 0 },
                                                  { 0, 2, 0 },
                                                  { 0, 2, 0 },
                                                  { 0, 2, 0 },
                                                  { 0, 2, 0 },
                                                  { 0, 0, 0 } };

static int32_t g_NavalEntityL5_Horizontal[3][7] = { { 0, 0, 0, 0, 0, 0, 0 },
                                                    { 0, 2, 2, 2, 2, 2, 0 },
									                { 0, 0, 0, 0, 0, 0, 0 } };

static int32_t g_NavalEntityL5_Vertical[7][3] = { { 0, 0, 0 },
                                                  { 0, 2, 0 },
                                                  { 0, 2, 0 },
                                                  { 0, 2, 0 },
                                                  { 0, 2, 0 },
                                                  { 0, 2, 0 },
                                                  { 0, 0, 0 } };


void Copy_PaddedGameBoardData(int32_t *pOutUnpaddedGameBoard, int32_t *pInPaddedGameBoard);



bool Check_NavalEntityL2_HorizontalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding);
bool Check_NavalEntityL3_HorizontalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding);
bool Check_NavalEntityL4_HorizontalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding);
bool Check_NavalEntityL5_HorizontalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding);

bool Check_NavalEntityL2_VerticalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding);
bool Check_NavalEntityL3_VerticalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding);
bool Check_NavalEntityL4_VerticalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding);
bool Check_NavalEntityL5_VerticalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding);

bool Add_NavalEntityL2_HorizontalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding);
bool Add_NavalEntityL3_HorizontalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding);
bool Add_NavalEntityL4_HorizontalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding);
bool Add_NavalEntityL5_HorizontalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding);

bool Add_NavalEntityL2_VerticalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding);
bool Add_NavalEntityL3_VerticalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding);
bool Add_NavalEntityL4_VerticalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding);
bool Add_NavalEntityL5_VerticalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding);

void Delete_NavalEntityL2_HorizontalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding);
void Delete_NavalEntityL3_HorizontalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding);
void Delete_NavalEntityL4_HorizontalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding);
void Delete_NavalEntityL5_HorizontalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding);

void Delete_NavalEntityL2_VerticalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding);
void Delete_NavalEntityL3_VerticalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding);
void Delete_NavalEntityL4_VerticalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding);
void Delete_NavalEntityL5_VerticalPlacement(int32_t ixLeft, int32_t iyTop, int32_t *pGameBoardwithPadding);


/*
used local receptive field
0 -1  0
1  0  1
0 -1  0
*/

// wenn DamagedElement-Tile, dann InputValue == 1, ansonsten InputValue == -100
void SimpleSearchAndDestroyRemainingShipElements(CNeuronV2 *pNeuron);


/*
used local receptive field
0  0 -2  0  0
0  0 -1  0  0
9  7  0  1  2
0  0 -7  0  0
0  0 -9  0  0
*/

// wenn DamagedElement-Tile, dann InputValue == 1, ansonsten InputValue == 0
void SearchRemainingIntactShipElements(CNeuronV2 *pNeuron);


/*
used local receptive field:
1 1 1
1 0 1
1 1 1
*/
// wenn DestroyedElement-Tile, dann InputValue == 1, ansonsten InputValue == 0
void DestroyedEntityNeighborhoodDetection(CNeuronV2 *pNeuron);


/*
used local receptive field:
0 1 0
1 0 1
0 1 0
*/
// Wenn Wasser-Treffer, dann InputValue == 1 wenn Wasser, dann InputValue == 0
void UnnecessaryShotDetection(CNeuronV2 *pNeuron);

void PlacementStrategyEvaluation(CNeuronV2 *pNeuron);

void L2ShipPlacementEvaluation(CNeuronV2 *pNeuron);
void L3ShipPlacementEvaluation(CNeuronV2 *pNeuron);
void L4ShipPlacementEvaluation(CNeuronV2 *pNeuron);
void L5ShipPlacementEvaluation(CNeuronV2 *pNeuron);


class CNavalEntity
{
public:

	// Zusatzinformation f�r eine m�gliche horizontale Platzierung:
	int32_t MaxHorizontalLeftPos = 0;

	// Zusatzinformation f�r eine m�gliche verticale Platzierung:
	int32_t MaxVerticalUpperPos = 0;

	int32_t Length = 1;
	int32_t MaxLength = 5;

	bool Destroyed = false;

	int32_t *pPartPosArray = nullptr;
	int32_t *pPartPosXArray = nullptr;
	int32_t *pPartPosYArray = nullptr;

	CNavalEntity();
	~CNavalEntity();
	
	// Kopierkonstruktor l�schen:
	CNavalEntity(const CNavalEntity  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CNavalEntity & operator=(const CNavalEntity  &originalObject) = delete;

	void Clone_Data(CNavalEntity *pOriginalNavalEntity);
	void Clone(CNavalEntity *pOriginalNavalEntity);

	void Initialize(int32_t length);
	void Initialize_With_MaxLength(void);

	bool Set_RandomPos(int32_t *pInOutGameBoardData, CRandomNumbersNN *pRandomNumbers);
	bool Set_RandomPos_Simple(int32_t *pInOutGameBoardData, CRandomNumbersNN *pRandomNumbers);
	
	void Check_Destruction(int32_t *pInOutGameBoardData);

	// f�r Testzwecke:
	void Copy_To_GameBoard(int32_t *pInOutGameBoardData);

	void Set_HorizontalPlacementPosition(int32_t ixleft, int32_t iy);
	void Set_VerticalPlacementPosition(int32_t ix, int32_t iyTop);

	void Copy_Data(float *pInOutDataMap, float intactElementValue = 1.0f);
	void Copy_Data(int32_t *pInOutDataMap, int32_t intactElementValue = 1);

	void Copy_Data_If_Destroyed(float *pInOutDataMap, float destroyedElementValue = 1.0f);
	void Copy_Data_If_Destroyed(int32_t *pInOutDataMap, int32_t destroyedElementValue = 1);

	void Add_Data(float *pInOutDataMap, float intactElementValue = 1.0f);
	void Add_Data(int32_t *pInOutDataMap, int32_t posValue = 1);

	void Add_Data_If_Destroyed(float *pInOutDataMap, float destroyedElementValue = 1.0f);
	void Add_Data_If_Destroyed(int32_t *pInOutDataMap, int32_t destroyedElementValue = 1);

};






class CPlacementStrategy
{
public:

	int32_t ForbiddenTileIDList[ConstGameBoardSize];
	int32_t NumOfForbiddenTiles = 0;
		
	CNeuronV2 MemoryNeuron;
	CNeuronV2 DynamicMemoryNeuron;
	
	int32_t NumPlacementTests = 0;

	float CenterDistanceFactorX = 1.0f;
	float CenterDistanceFactorY = 1.0f;
	int32_t CenterProbabilityDecrease = 0;

	int32_t helperCounter = 0;

	CPlacementStrategy();
	~CPlacementStrategy();

	// Kopierkonstruktor l�schen:
	CPlacementStrategy(const CPlacementStrategy  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CPlacementStrategy & operator=(const CPlacementStrategy  &originalObject) = delete;

	void Set_ActivationFunction(pActivationFuncV2 pFunc);

	void Prepare_New_PlacementStrategy(void);

	void Train_MemoryNeuron(int32_t *pGameBoardData, CNavalEntity *pNavalEntityArray, int32_t numNavalEntities, float numNavalEntityElements, CRandomNumbersNN *pRandomNumbers);

	void Train_MemoryNeuron_Simple(int32_t *pGameBoardData, CNavalEntity *pNavalEntityArray, int32_t numNavalEntities, float numNavalEntityElements, CRandomNumbersNN *pRandomNumbers);

	void Train_MemoryNeuron(int32_t *pGameBoardData, int32_t numPlacementTests, int32_t *pForbiddenTileIDList, int32_t numOfForbiddenTiles, CNavalEntity *pNavalEntityArray, int32_t numNavalEntities, float numNavalEntityElements, CRandomNumbersNN *pRandomNumbers);

	void Train_MemoryNeuron_DynamicPlacement(int32_t *pGameBoardData, int32_t numPlacementTests, int32_t *pForbiddenTileIDList, int32_t numOfForbiddenTiles, CNavalEntity *pNavalEntityArray, int32_t numNavalEntities, float numNavalEntityElements, CRandomNumbersNN *pRandomNumbers, bool additionalDendriteModifications = false);
};
class CPlacementStrategies
{
public:

	int32_t NumStrategies = 0;
	int32_t NumBaseStrategies = 0;
	int32_t NumAdditionalStrategies = 0;

	int32_t NumPrecalculatedStrategies = 0;

	bool AdditionalDynamicStrategy = false;
	
	CPlacementStrategy* pStrategyArray = nullptr;

	CNeuronEnsembleV2 NeuronEnsemble;
	CNeuronEnsembleV2 DynamicNeuronEnsemble;

	int32_t IDofStrongestActivatedMemoryNeuron = 0;

	CPlacementStrategies();
	~CPlacementStrategies();

	// Kopierkonstruktor l�schen:
	CPlacementStrategies(const CPlacementStrategies  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CPlacementStrategies & operator=(const CPlacementStrategies  &originalObject) = delete;

	void Set_ActivationFunction(pActivationFuncV2 pFunc);

	bool Init_New_Strategies(const char* pFilename, CRandomNumbersNN *pRandomNumbers, bool additionalDynamicStrategy = false);

	void Train_MemoryNeurons(int32_t *pGameBoardData, CNavalEntity *pNavalEntityArray, int32_t numNavalEntities, int32_t numNavalEntityElements, CRandomNumbersNN *pRandomNumbers);

	void Get_StrongestActivatedMemoryNeuron(CNeuronV2 **ppOutMemoryNeuron, int32_t *pOutBelongingNeuronID, float *pGameBoardData_WaterShotsAndHits);
	void Get_StrongestActivatedDynamicMemoryNeuron(CNeuronV2 **ppOutMemoryNeuron, int32_t *pOutBelongingNeuronID, float *pGameBoardData_WaterShotsAndHits);

	bool Save_HitProbabilityValues(const char *pBaseFileName);
	bool Load_HitProbabilityValues(const char *pBaseFileName);
};

void Compare_PlacementStrategyEnsembles(CNeuronV2 **ppOutStrongestActivatedMemoryNeuron, int32_t *pOutBelongingNeuronID, CPlacementStrategies *pEnsembleArray, int32_t numArrayElements);



void Init_GameBoard(int32_t *pData, int32_t gameBoardElement);
void Init_PaddedGameBoard(int32_t *pData, int32_t gameBoardElement);

void Copy_GameBoard(int32_t *pOutData, int32_t *pInData);

void Copy_WaterShotData(float *pOutData, int32_t *pInData, float watershotValue);



void Copy_WaterShotAndHitData(float *pOutData, int32_t *pInData, float watershotValue, float hitValue);

void Copy_DamagedElementData(float *pOutData, int32_t *pInData, float damagedElementValue);

void Copy_WaterShotAndDestroyedElementData(float *pOutData, int32_t *pInData, float waterShotAndDestroyedElementValue);

void Copy_DestroyedElementData(float *pOutData, int32_t *pInData, float destroyedElementValue);

void Init_Or_Reset_Memory(float *pData, float initialValue = 0.0f);

void Add_ForbiddenTileID(int32_t *pInOutForbiddenTileIDList, int32_t ix, int32_t iy, int32_t *pInOutNumOfForbiddenTiles);


// lediglich die ForbiddenTiles bleiben bei der Platzierung unber�cksichtigt 
void Init_GameBoard_And_Set_RandomEntityPositions_DynamicPlacement(int32_t *pInOutGameBoardData, CNavalEntity *pNavalEntityArray, int32_t numNavalEntities, CRandomNumbersNN *pRandomNumbers, int32_t *pForbiddenTileIDList, int32_t numOfForbiddenTiles);

void Init_GameBoard_And_Set_RandomEntityPositions_Simple(int32_t *pInOutGameBoardData, CNavalEntity *pNavalEntityArray, int32_t numNavalEntities, CRandomNumbersNN *pRandomNumbers, int32_t *pForbiddenTileIDList, int32_t numOfForbiddenTiles);

// die ForbiddenTiles sowie die sie umbegenen Tiles bleiben bei der Platzierung unber�cksichtigt; 
void Init_GameBoard_And_Set_RandomEntityPositions(int32_t *pInOutGameBoardData, CNavalEntity *pNavalEntityArray, int32_t numNavalEntities, CRandomNumbersNN *pRandomNumbers, int32_t *pForbiddenTileIDList, int32_t numOfForbiddenTiles);

void Init_GameBoard_And_Set_RandomEntityPositions(int32_t *pInOutGameBoardData, CNavalEntity *pNavalEntityArray, int32_t numNavalEntities, CRandomNumbersNN *pRandomNumbers);

void Init_GameBoard_And_Set_RandomEntityPositions_Simple(int32_t *pInOutGameBoardData, CNavalEntity *pNavalEntityArray, int32_t numNavalEntities, CRandomNumbersNN *pRandomNumbers);


class CDynamicForbiddenTileData
{
public:

	int32_t GameBoardSize = 0;
	int32_t NumOfForbiddenTiles = 0;
	int32_t *pForbiddenTileIDList = nullptr;

	int32_t NumOfNavalEntities = 0;
	int32_t NumOfIntactNavalEntities = 0;
	CNavalEntity *pIntactNavalEntityArray = nullptr;

	int32_t *pTempGameBoardData = nullptr;

	CDynamicForbiddenTileData();
	~CDynamicForbiddenTileData();

	// Kopierkonstruktor l�schen:
	CDynamicForbiddenTileData(const CDynamicForbiddenTileData  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CDynamicForbiddenTileData & operator=(const CDynamicForbiddenTileData  &originalObject) = delete;

	void Initialize(int32_t gameBoardSize, int32_t numOfNavalEntities);

	void Update_ForbiddenTileData(CNavalEntity *pNavalEntityArray, int32_t *pGameBoardData);

	void Calculate_DynamicPlacementStrategy(CPlacementStrategies *pPlacementStrategies, int32_t numPlacementTests, CRandomNumbersNN *pRandomNumbers, bool additionalDendriteModifications = false);
};


#endif