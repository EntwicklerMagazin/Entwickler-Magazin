// Schutz vor Mehrfachdeklarationen :

#ifndef _Physics_H_
#define _Physics_H_

#pragma warning( disable: 4996)

#include "NeuralCalculationNet.h"


class CSimplePhysicsObject
{
public:

	float Mass = 0.0f;

	// Position:
	float PosX = 0.0f;
	float PosY = 0.0f;
	float PosZ = 0.0f;

	float DeltaPosX = 0.0f;
	float DeltaPosY = 0.0f;
	float DeltaPosZ = 0.0f;

	// Geschwindigkeit (Velocity):
	float VelX = 0.0f;
	float VelY = 0.0f;
	float VelZ = 0.0f;
	float VelX_LastFrame = 0.0f;
	float VelY_LastFrame = 0.0f;
	float VelZ_LastFrame = 0.0f;
	float VelX_LastFrame2 = 0.0f;
	float VelY_LastFrame2 = 0.0f;
	float VelZ_LastFrame2 = 0.0f;

	float DeltaVelX = 0.0f;
	float DeltaVelY = 0.0f;
	float DeltaVelZ = 0.0f;

	// Beschleunigung (Acceleration):
	float AccelX = 0.0f;
	float AccelY = 0.0f;
	float AccelZ = 0.0f;

	CSimplePhysicsObject();
	~CSimplePhysicsObject();

	void Reset_Values(void);
	void Update(float timeStep);
};

class CSimpleArtilleryAI
{
public:

	CNeuralCalculationNet CalculationNet;

	CNeuralCalculationFunctions CalculationFunctions;

	static constexpr int32_t NumOfInputUnits = 4;
	static constexpr int32_t NumOfOutputUnits = 2;

	CSimpleArtilleryAI();
	~CSimpleArtilleryAI();

	// Kopierkonstruktor l�schen: 
	CSimpleArtilleryAI(const CSimpleArtilleryAI& originalObject) = delete;

	// �berladenen Zuweisungsoperator l�schen: 
	CSimpleArtilleryAI operator=(const CSimpleArtilleryAI& originalObject) = delete;

	void Initialize(int32_t numOfHiddenUnitsL1, int32_t numOfHiddenUnitsL2, float minRandomPlasticity, float maxRandomPlasticity,uint64_t seed = 1);
	void Initialize(int32_t numOfHiddenUnitsL1, float minRandomPlasticity, float maxRandomPlasticity, uint64_t seed = 1);

	void Modify_CalculationNet(CNeuralCalculationNetDesc* pInCalculationNetDesc);
	void Readout_CalculationNetData(CNeuralCalculationNetDesc* pOutCalculationNetDesc, bool memoryAllocation = true);

	void Calculate_FiringSolution(float* pOutVelocityX, float* pOutVelocityY, float startPosX, float startPosY, float targetPosX, float targetPosY, float accelerationX, float accelerationY, float velocityScaleX = 100.0f, float velocityScaleY = 100.0f);
};



class COrbitalNavigationAI
{
public:

	CNeuralCalculationNet CalculationNet;

	CNeuralCalculationFunctions CalculationFunctions;

	static constexpr int32_t NumOfInputUnits = 2;
	static constexpr int32_t NumOfOutputUnits = 1;

	COrbitalNavigationAI();
	~COrbitalNavigationAI();

	// Kopierkonstruktor l�schen: 
	COrbitalNavigationAI(const COrbitalNavigationAI& originalObject) = delete;

	// �berladenen Zuweisungsoperator l�schen: 
	COrbitalNavigationAI operator=(const COrbitalNavigationAI& originalObject) = delete;

	void Initialize(int32_t numOfHiddenUnitsL1, float minRandomPlasticity, float maxRandomPlasticity, uint64_t seed = 1);

	void Modify_CalculationNet(CNeuralCalculationNetDesc* pInCalculationNetDesc);
	void Readout_CalculationNetData(CNeuralCalculationNetDesc* pOutCalculationNetDesc, bool memoryAllocation = true);

	void Calculate_InitialOrbitalVelocity(float* pOutVelocityX, float* pOutVelocityY, float startPosX, float startPosY, float targetPosX, float targetPosY, float gravitySourcePosX, float gravitySourcePosY, float gravitySourceMass);
};

class CLandingModuleNavigationAI
{
public:

	CNeuralCalculationNet CalculationNet;

	CNeuralCalculationFunctions CalculationFunctions;

	static constexpr int32_t NumOfInputUnits = 8;

	// Maneuver: nothing / up / down / right / left
	static constexpr int32_t NumOfOutputUnits = 5;

	CLandingModuleNavigationAI();
	~CLandingModuleNavigationAI();

	// Kopierkonstruktor l�schen: 
	CLandingModuleNavigationAI(const CLandingModuleNavigationAI& originalObject) = delete;

	// �berladenen Zuweisungsoperator l�schen: 
	CLandingModuleNavigationAI operator=(const CLandingModuleNavigationAI& originalObject) = delete;

	void Initialize(int32_t numOfHiddenUnitsL1, int32_t numOfHiddenUnitsL2, float minRandomPlasticity, float maxRandomPlasticity, uint64_t seed = 1);
	void Initialize(int32_t numOfHiddenUnitsL1, float minRandomPlasticity, float maxRandomPlasticity, uint64_t seed = 1);

	void Modify_CalculationNet(CNeuralCalculationNetDesc* pInCalculationNetDesc);
	void Readout_CalculationNetData(CNeuralCalculationNetDesc* pOutCalculationNetDesc, bool memoryAllocation = true);

	void Calculate_PossibleCourseCorrection(float* pOutputData, CSimplePhysicsObject* pLandingModule, float targetPosX, float targetPosY);
};

#endif