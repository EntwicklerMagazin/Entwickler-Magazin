#include <iostream>
//#include <chrono>
#include <thread>
#include "ConsoleHelperFunctions.h"
#include "RandomNumbers.h"
#include "NeuralNet.h"
#include "GravitationSamples.h"


using namespace std;
using namespace chrono;



#define KEYDOWN(vk_code) ((GetAsyncKeyState(vk_code) & 0x8000) ? 1 : 0)
#define KEYUP(vk_code)   ((GetAsyncKeyState(vk_code) & 0x8000) ? 0 : 1)



static char g_InputBuffer[100];


static void Set_ProcessPriority(unsigned long priority)
{
	HANDLE ProcessHandle = GetCurrentProcess();

	if (priority == 0)
		SetPriorityClass(ProcessHandle, NORMAL_PRIORITY_CLASS);
	else if (priority == 1)
		SetPriorityClass(ProcessHandle, ABOVE_NORMAL_PRIORITY_CLASS);
	else if (priority == 2)
		SetPriorityClass(ProcessHandle, HIGH_PRIORITY_CLASS);
	else
		SetPriorityClass(ProcessHandle, REALTIME_PRIORITY_CLASS);
}


/*
int main(void)
{
	//Set_ProcessPriority(2);

	HelperStuff::Begin_Log(0, "Begin_Log", "Logfile.txt");

	CRandomNumbersNN RandomNumbers;

	CWindowsConsoleScreenBuffer WinConsole;
	WinConsole.Initialize(ConstGameBoardSizeX, ConstGameBoardSizeY, false, BackgroundColor);

	
	Set_Title("NeuralNetGravitationSample3 (neuro-evolution running ... )");
	Set_ConsolePos(10, 10);

	WinConsole.Set_CursorVisibilityAndSize(FALSE);
	//WinConsole.Set_Font(L"Consolas", 15, 15);
	WinConsole.Set_Font(L"Consolas", 4, 4);
	//WinConsole.Set_Font(L"Consolas", 8, 8);
	//WinConsole.Set_Font_Ext(L"Consolas", 90, 10, 10);
	

	//WinConsole.Set_BackgroundColor(RGB(100, 50, 25));
	WinConsole.Set_BackgroundColor(BackgroundColor);

	Set_CursorVisibilityAndSize(false);

	
	float FrameTime = 0.0f;

	CWindowsConsole2DObject Target;
	Target.Initialize(5, 5);

	Target.Set_Pixel(0, 0, lightred);
	Target.Set_Pixel(4, 0, lightred);
	Target.Set_Pixel(1, 1, lightred);
	Target.Set_Pixel(3, 1, lightred);
	Target.Set_Pixel(2, 2, lightred);
	Target.Set_Pixel(1, 3, lightred);
	Target.Set_Pixel(3, 3, lightred);
	Target.Set_Pixel(0, 4, lightred);
	Target.Set_Pixel(4, 4, lightred);

	CWindowsConsole2DObject Ball;
	Ball.Initialize(5, 5);

	Ball.Set_Pixel(0, 0, black);
	Ball.Set_Pixel(1, 0, lightgreen);
	Ball.Set_Pixel(2, 0, lightgreen);
	Ball.Set_Pixel(3, 0, lightgreen);
	Ball.Set_Pixel(4, 0, black);

	Ball.Set_Pixel(0, 1, lightgreen);
	Ball.Set_Pixel(1, 1, lightgreen);
	Ball.Set_Pixel(2, 1, lightgreen);
	Ball.Set_Pixel(3, 1, lightgreen);
	Ball.Set_Pixel(4, 1, lightgreen);

	Ball.Set_Pixel(0, 2, lightgreen);
	Ball.Set_Pixel(1, 2, lightgreen);
	Ball.Set_Pixel(2, 2, lightgreen);
	Ball.Set_Pixel(3, 2, lightgreen);
	Ball.Set_Pixel(4, 2, lightgreen);

	Ball.Set_Pixel(0, 3, lightgreen);
	Ball.Set_Pixel(1, 3, lightgreen);
	Ball.Set_Pixel(2, 3, lightgreen);
	Ball.Set_Pixel(3, 3, lightgreen);
	Ball.Set_Pixel(4, 3, lightgreen);

	Ball.Set_Pixel(0, 4, black);
	Ball.Set_Pixel(1, 4, lightgreen);
	Ball.Set_Pixel(2, 4, lightgreen);
	Ball.Set_Pixel(3, 4, lightgreen);
	Ball.Set_Pixel(4, 4, black);

	CWindowsConsole2DObject GravitySourceObject;
	GravitySourceObject.Initialize(7, 7);

	GravitySourceObject.Set_Pixel(0, 0, black);
	GravitySourceObject.Set_Pixel(1, 0, gray);
	GravitySourceObject.Set_Pixel(2, 0, gray);
	GravitySourceObject.Set_Pixel(3, 0, gray);
	GravitySourceObject.Set_Pixel(4, 0, gray);
	GravitySourceObject.Set_Pixel(5, 0, gray);
	GravitySourceObject.Set_Pixel(6, 0, black);
	
	GravitySourceObject.Set_Pixel(0, 1, gray);
	GravitySourceObject.Set_Pixel(1, 1, gray);
	GravitySourceObject.Set_Pixel(2, 1, gray);
	GravitySourceObject.Set_Pixel(3, 1, gray);
	GravitySourceObject.Set_Pixel(4, 1, gray);
	GravitySourceObject.Set_Pixel(5, 1, gray);
	GravitySourceObject.Set_Pixel(6, 1, gray);

	GravitySourceObject.Set_Pixel(0, 2, gray);
	GravitySourceObject.Set_Pixel(1, 2, gray);
	GravitySourceObject.Set_Pixel(2, 2, gray);
	GravitySourceObject.Set_Pixel(3, 2, gray);
	GravitySourceObject.Set_Pixel(4, 2, gray);
	GravitySourceObject.Set_Pixel(5, 2, gray);
	GravitySourceObject.Set_Pixel(6, 2, gray);

	GravitySourceObject.Set_Pixel(0, 3, gray);
	GravitySourceObject.Set_Pixel(1, 3, gray);
	GravitySourceObject.Set_Pixel(2, 3, gray);
	GravitySourceObject.Set_Pixel(3, 3, gray);
	GravitySourceObject.Set_Pixel(4, 3, gray);
	GravitySourceObject.Set_Pixel(5, 3, gray);
	GravitySourceObject.Set_Pixel(6, 3, gray);

	GravitySourceObject.Set_Pixel(0, 4, gray);
	GravitySourceObject.Set_Pixel(1, 4, gray);
	GravitySourceObject.Set_Pixel(2, 4, gray);
	GravitySourceObject.Set_Pixel(3, 4, gray);
	GravitySourceObject.Set_Pixel(4, 4, gray);
	GravitySourceObject.Set_Pixel(5, 4, gray);
	GravitySourceObject.Set_Pixel(6, 4, gray);

	GravitySourceObject.Set_Pixel(0, 5, gray);
	GravitySourceObject.Set_Pixel(1, 5, gray);
	GravitySourceObject.Set_Pixel(2, 5, gray);
	GravitySourceObject.Set_Pixel(3, 5, gray);
	GravitySourceObject.Set_Pixel(4, 5, gray);
	GravitySourceObject.Set_Pixel(5, 5, gray);
	GravitySourceObject.Set_Pixel(6, 5, gray);
	
	GravitySourceObject.Set_Pixel(0, 6, black);
	GravitySourceObject.Set_Pixel(1, 6, gray);
	GravitySourceObject.Set_Pixel(2, 6, gray);
	GravitySourceObject.Set_Pixel(3, 6, gray);
	GravitySourceObject.Set_Pixel(4, 6, gray);
	GravitySourceObject.Set_Pixel(5, 6, gray);
	GravitySourceObject.Set_Pixel(6, 6, black);


	int32_t iGravitySourcePosX = 70;
	int32_t iGravitySourcePosY = 50;
	//int32_t iGravitySourcePosY = 40;
	//int32_t iGravitySourcePosY = 60;

	CSimplePhysicsObject GravitySource;
	GravitySource.posX = static_cast<float>(iGravitySourcePosX);
	GravitySource.posY = static_cast<float>(iGravitySourcePosY);
	GravitySource.mass = 150000.0f;
	
	
	COrbitalNavigationAIPopulation OrbitalNavigationAIPopulation;
	
	

	
	int32_t NumSimpleMutationGenerations = 100;
	int32_t NumTrainingGamesPerEpoch = 40;

	int32_t TrainingPopulationSize = 200;
	
	int32_t NumTrainingGenerationsMax = 400;
	int32_t NumOfHiddenNeuronsL1 = 2;
	int32_t NumOfHiddenNeuronsL2 = 0;
	bool ExtremeLearning = false;
	float MinSynapticPlasticity = -3.0f;
	float MaxSynapticPlasticity = 3.0f;
	


	float MinSynapticPlasticityVariance = -0.0001f;
	float MaxSynapticPlasticityVariance = 0.0001f;

	

	float PlasticityMutationRate = 0.1f;

	float PlasticityMutationRateL1 = 0.0f;
	float PlasticityMutationRateL2 = 0.0f;
	float PlasticityMutationRateL3 = 0.0f;
	

	float TopologyMutationRateL1 = 0.0f;
	float TopologyMutationRateL2 = 0.0f;
	float TopologyMutationRateL3 = 0.0f;
	
	
	float AccelerationX;
	float AccelerationY;


	OrbitalNavigationAIPopulation.Initialize(TrainingPopulationSize, NumOfHiddenNeuronsL1, NumOfHiddenNeuronsL2);

	OrbitalNavigationAIPopulation.RandomChange_OutputSynapsePlasticities(MinSynapticPlasticity, MaxSynapticPlasticity);

	if (TopologyMutationRateL1 != 0.0f || TopologyMutationRateL2 != 0.0f || TopologyMutationRateL3 != 0.0f)
	{
		OrbitalNavigationAIPopulation.RandomReduce_BrainConnections(TopologyMutationRateL1, TopologyMutationRateL2, TopologyMutationRateL3);
	}



	CNeuralNetPopulation NeuralNetPopulation;

	NeuralNetPopulation.Initialize(OrbitalNavigationAIPopulation.PopulationSize, OrbitalNavigationAIPopulation.NumOfInputNeurons, OrbitalNavigationAIPopulation.NumOfOutputNeurons, NumOfHiddenNeuronsL1, NumOfHiddenNeuronsL1, NumOfHiddenNeuronsL2, NumOfHiddenNeuronsL2, SqrtOutput, LinearOutput, LinearOutput);

	Init_NeuralNetPopulation(&NeuralNetPopulation, &OrbitalNavigationAIPopulation);

	

	for (int32_t i = 0; i < NumSimpleMutationGenerations; i++)
	{
		OrbitalNavigationAIPopulation.Init_Play_and_Evaluate_NewTrainingSequence(300, NumTrainingGamesPerEpoch, &GravitySource, 0.0075f);
		//OrbitalNavigationAIPopulation.Init_Play_and_Evaluate_NewTrainingSequence(600, NumTrainingGamesPerEpoch, &GravitySource, 0.0125f);

		NeuralNetPopulation.Update_Population(OrbitalNavigationAIPopulation.pFitnessScoreArray);


		if (PlasticityMutationRate != 0.0f)
		{
			NeuralNetPopulation.Update_Evolution_SynapticPlasticityMutationsOnly(MinSynapticPlasticity, MaxSynapticPlasticity, PlasticityMutationRate, ExtremeLearning);
		}
		else if (PlasticityMutationRate == 0.0f)
		{
			NeuralNetPopulation.Update_Evolution_SynapticPlasticityMutationsOnly(MinSynapticPlasticity, MaxSynapticPlasticity, PlasticityMutationRateL1, PlasticityMutationRateL2, PlasticityMutationRateL3, ExtremeLearning);
		}

		if (TopologyMutationRateL1 != 0.0f || TopologyMutationRateL2 != 0.0f || TopologyMutationRateL3 != 0.0f)
		{
			NeuralNetPopulation.Update_Evolution_ConnectionTopologyMutationsOnly(MinSynapticPlasticity, MaxSynapticPlasticity, TopologyMutationRateL1, TopologyMutationRateL2, TopologyMutationRateL3, true);
		}

		if (PlasticityMutationRate != 0.0f)
		{
			NeuralNetPopulation.Update_Evolution_BestBrainOnly(MinSynapticPlasticityVariance, MaxSynapticPlasticityVariance, PlasticityMutationRate);
			NeuralNetPopulation.Update_Evolution_SecondBestBrainOnly(MinSynapticPlasticityVariance, MaxSynapticPlasticityVariance, PlasticityMutationRate);
		}
		else if (PlasticityMutationRate == 0.0f)
		{
			NeuralNetPopulation.Update_Evolution_BestBrainOnly(MinSynapticPlasticityVariance, MaxSynapticPlasticityVariance, PlasticityMutationRateL1, PlasticityMutationRateL2, PlasticityMutationRateL3);
			NeuralNetPopulation.Update_Evolution_SecondBestBrainOnly(MinSynapticPlasticityVariance, MaxSynapticPlasticityVariance, PlasticityMutationRateL1, PlasticityMutationRateL2, PlasticityMutationRateL3);
		}

		if (TopologyMutationRateL1 != 0.0f || TopologyMutationRateL2 != 0.0f || TopologyMutationRateL3 != 0.0f)
		{
			NeuralNetPopulation.Restore_ConnectionTopology_WorstFitted_Brain(MinSynapticPlasticity, MaxSynapticPlasticity);
			NeuralNetPopulation.Restore_ConnectionTopology_SecondWorstFitted_Brain(MinSynapticPlasticity, MaxSynapticPlasticity);
			NeuralNetPopulation.Restore_ConnectionTopology_ThirdWorstFitted_Brain(MinSynapticPlasticity, MaxSynapticPlasticity);
		}
	}

	for (int32_t i = NumSimpleMutationGenerations; i < NumTrainingGenerationsMax; i++)
	{
		OrbitalNavigationAIPopulation.Init_Play_and_Evaluate_NewTrainingSequence(300, NumTrainingGamesPerEpoch, &GravitySource, 0.0075f);
		//OrbitalNavigationAIPopulation.Init_Play_and_Evaluate_NewTrainingSequence(600, NumTrainingGamesPerEpoch, &GravitySource, 0.0125f);

		NeuralNetPopulation.Update_Population(OrbitalNavigationAIPopulation.pFitnessScoreArray);

		if (PlasticityMutationRate != 0.0f)
		{
			NeuralNetPopulation.Update_Evolution_SynapticPlasticityMutationsOnly(MinSynapticPlasticity, MaxSynapticPlasticity, PlasticityMutationRate, ExtremeLearning);
		}
		else if (PlasticityMutationRate == 0.0f)
		{
			NeuralNetPopulation.Update_Evolution_SynapticPlasticityMutationsOnly(MinSynapticPlasticity, MaxSynapticPlasticity, PlasticityMutationRateL1, PlasticityMutationRateL2, PlasticityMutationRateL3, ExtremeLearning);
		}



		if (TopologyMutationRateL1 != 0.0f || TopologyMutationRateL2 != 0.0f || TopologyMutationRateL3 != 0.0f)
		{
			NeuralNetPopulation.Update_Evolution_ConnectionTopologyMutationsOnly(MinSynapticPlasticity, MaxSynapticPlasticity, TopologyMutationRateL1, TopologyMutationRateL2, TopologyMutationRateL3, true);
		}

		if (PlasticityMutationRate != 0.0f)
		{
			NeuralNetPopulation.Update_Evolution_BestBrainOnly(MinSynapticPlasticityVariance, MaxSynapticPlasticityVariance, PlasticityMutationRate);
			NeuralNetPopulation.Update_Evolution_SecondBestBrainOnly(MinSynapticPlasticityVariance, MaxSynapticPlasticityVariance, PlasticityMutationRate);
		}
		else if (PlasticityMutationRate == 0.0f)
		{
			NeuralNetPopulation.Update_Evolution_BestBrainOnly(MinSynapticPlasticityVariance, MaxSynapticPlasticityVariance, PlasticityMutationRateL1, PlasticityMutationRateL2, PlasticityMutationRateL3);
			NeuralNetPopulation.Update_Evolution_SecondBestBrainOnly(MinSynapticPlasticityVariance, MaxSynapticPlasticityVariance, PlasticityMutationRateL1, PlasticityMutationRateL2, PlasticityMutationRateL3);
		}


		NeuralNetPopulation.Update_Evolution_Combine_BestTwoBrains();
		NeuralNetPopulation.Update_Evolution_Combine_TwoBrains();

		if (TopologyMutationRateL1 != 0.0f || TopologyMutationRateL2 != 0.0f || TopologyMutationRateL3 != 0.0f)
		{
			NeuralNetPopulation.Restore_ConnectionTopology_WorstFitted_Brain(MinSynapticPlasticity, MaxSynapticPlasticity);
			NeuralNetPopulation.Restore_ConnectionTopology_SecondWorstFitted_Brain(MinSynapticPlasticity, MaxSynapticPlasticity);
			NeuralNetPopulation.Restore_ConnectionTopology_ThirdWorstFitted_Brain(MinSynapticPlasticity, MaxSynapticPlasticity);
		}

		//NeuralNetPopulation.Round_OutputWeights(0.00001f);
	}

	Set_Title("NeuralNetGravitationSample3 (SPACE: Fire)");

	COrbitalNavigationAI OrbitalNavigationAI;
	OrbitalNavigationAI.Initialize(NumOfHiddenNeuronsL1, NumOfHiddenNeuronsL2);
	OrbitalNavigationAI.Brain.Clone_OutputSynapsePlasticities(NeuralNetPopulation.Get_Best_Evolved_NeuralNet());
	//NeuralNetPopulation.Get_Best_Evolved_NeuralNet_Ext(&OrbitalNavigationAI.Brain);

	RandomNumbers.Change_Seed(150);

	

	CSimplePhysicsObject SimplePhysicsObject;

	float dirX = -1.0f;
	float dirY = 0.0f;


	float distSq = dirX * dirX + dirY *  dirY + 0.00001f;
	float invLength = 1.0f / sqrt(distSq);

	dirX *= invLength;
	dirY *= invLength;

	float radius = RandomNumbers.Get_FloatNumber(20.0f, 30.0f);

	float  StartPosX = dirX *  radius + GravitySource.posX;
	float  StartPosY = dirY *  radius + GravitySource.posY;

	int32_t iStartPosX = static_cast<int32_t>(StartPosX);
	int32_t iStartPosY = static_cast<int32_t>(StartPosY);

	//dirX = 1.0f;
	//dirY = 0.0f;

	//distSq = dirX * dirX + dirY *  dirY + 0.00001f;
	//invLength = 1.0f / sqrt(distSq);

	//dirX *= invLength;
	//dirY *= invLength;

	//radius = RandomNumbers.Get_FloatNumber(10.0f, 40.0f);

	//float  TargetPosX = dirX *  radius + GravitySource.posX;
	//float  TargetPosY = dirY *  radius + GravitySource.posY;

	dirX = RandomNumbers.Get_FloatNumber(0.1f, 1.0f);
	dirY = RandomNumbers.Get_FloatNumber(-1.0f, -0.1f);

	float scale = RandomNumbers.Get_FloatNumber(10.0f, 40.0f);

	float  TargetPosX = dirX *  scale + GravitySource.posX;
	float  TargetPosY = dirY *  scale + GravitySource.posY;

	int32_t iTargetPosX = static_cast<int32_t>(TargetPosX);
	int32_t iTargetPosY = static_cast<int32_t>(TargetPosY);

	SimplePhysicsObject.posX = StartPosX;
	SimplePhysicsObject.posY = StartPosY;


	OrbitalNavigationAI.Calculate_InitialOrbitalVelocity(&SimplePhysicsObject.velX, &SimplePhysicsObject.velY, SimplePhysicsObject.posX, SimplePhysicsObject.posY, TargetPosX, TargetPosY, GravitySource.posX, GravitySource.posY, GravitySource.mass);

	int32_t counter = 0;

	do
	{
		//auto last_timepoint = std::chrono::steady_clock::now();
		auto last_timepoint = steady_clock::now();
		
		if (KEYDOWN(VK_ESCAPE) == true)
			break;

		float distX = GravitySource.posX - SimplePhysicsObject.posX;
		float distY = GravitySource.posY - SimplePhysicsObject.posY;

		float distSq = distX * distX + distY * distY;
		float invDist = 1.0f / sqrt(distSq + 0.00001f);

		float dirX = invDist * distX;
		float dirY = invDist * distY;

		float acceleration = GravitySource.mass / distSq;

		SimplePhysicsObject.accelX = dirX * acceleration;
		SimplePhysicsObject.accelY = dirY * acceleration;

		SimplePhysicsObject.Update(FrameTime);

		
		WinConsole.Clear_BackBuffer();

		
		int32_t posX_Left = iGravitySourcePosX - GravitySourceObject.NumCharactersPerRow / 2;
		int32_t posY_Top = iGravitySourcePosY - GravitySourceObject.NumCharactersPerColumn / 2;

		WinConsole.Draw_2DObject_Into_BackBuffer(posX_Left, posY_Top, GravitySourceObject.pDataArray, GravitySourceObject.NumCharactersPerRow, GravitySourceObject.NumCharactersPerColumn);

		posX_Left = SimplePhysicsObject.posX - Ball.NumCharactersPerRow / 2;
		posY_Top = SimplePhysicsObject.posY - Ball.NumCharactersPerColumn / 2;

		WinConsole.Draw_2DObject_Into_BackBuffer(posX_Left, posY_Top, Ball.pDataArray, Ball.NumCharactersPerRow, Ball.NumCharactersPerColumn);
	
		posX_Left = iTargetPosX - Target.NumCharactersPerRow / 2;
		posY_Top = iTargetPosY - Target.NumCharactersPerColumn / 2;

		WinConsole.Draw_2DObject_Into_BackBuffer(posX_Left, posY_Top, Target.pDataArray, Target.NumCharactersPerRow, Target.NumCharactersPerColumn);
		//WinConsole.Write_Pixel_Into_BackBuffer(iTargetPosX, iTargetPosY, lightred);

		WinConsole.Present_BackBuffer();

		counter++;

		if (GetAsyncKeyState(VK_SPACE) || GetAsyncKeyState(VK_RETURN) || counter > 300)
		{
			counter = 0;

			SimplePhysicsObject.Reset_Values();

			float dirX = -1.0f;
			float dirY = 0.0f;
			
			float distSq = dirX * dirX + dirY *  dirY + 0.00001f;
			float invLength = 1.0f / sqrt(distSq);

			dirX *= invLength;
			dirY *= invLength;

			float radius = RandomNumbers.Get_FloatNumber(20.0f, 30.0f);

			StartPosX = dirX *  radius + GravitySource.posX;
			StartPosY = dirY *  radius + GravitySource.posY;

			iStartPosX = static_cast<int32_t>(StartPosX);
			iStartPosY = static_cast<int32_t>(StartPosY);

			
			//dirX = 1.0f;
			//dirY = 0.0f;

			//distSq = dirX * dirX + dirY *  dirY + 0.00001f;
			//invLength = 1.0f / sqrt(distSq);

			//dirX *= invLength;
			//dirY *= invLength;
		
			//radius = RandomNumbers.Get_FloatNumber(10.0f, 40.0f);

			//TargetPosX = dirX *  radius + GravitySource.posX;
			//TargetPosY = dirY *  radius + GravitySource.posY;

			dirX = RandomNumbers.Get_FloatNumber(0.1f, 1.0f);
			dirY = RandomNumbers.Get_FloatNumber(-1.0f, -0.1f);

			float scale = RandomNumbers.Get_FloatNumber(10.0f, 40.0f);

			float  TargetPosX = dirX *  scale + GravitySource.posX;
			float  TargetPosY = dirY *  scale + GravitySource.posY;

			iTargetPosX = static_cast<int32_t>(TargetPosX);
			iTargetPosY = static_cast<int32_t>(TargetPosY);

			SimplePhysicsObject.posX = StartPosX;
			SimplePhysicsObject.posY = StartPosY;

			OrbitalNavigationAI.Calculate_InitialOrbitalVelocity(&SimplePhysicsObject.velX, &SimplePhysicsObject.velY, SimplePhysicsObject.posX, SimplePhysicsObject.posY, TargetPosX, TargetPosY, GravitySource.posX, GravitySource.posY, GravitySource.mass);

		}

		//Frame-Bremse:

		auto current_timepoint = steady_clock::now();
		

		//while (current_timepoint - last_timepoint < 50ms)
		//while (current_timepoint - last_timepoint < 16ms)
		while (current_timepoint - last_timepoint < 16666us) // 16.7 Millisekunden (ms)  bzw. 16666 Mikrosekunden (us): maximal 60 Frames pro Sekunde					
		{
			current_timepoint = steady_clock::now();
			
		}


		FrameTime = 0.000000001f * (current_timepoint - last_timepoint).count();
		//HelperStuff::Add_To_Log(0, "dt (s)", FrameTime);

		//FrameTime = 0.0125f;
		//FrameTime = 0.0075f;

	} while (true);

	WinConsole.Clear_BackBuffer();
	WinConsole.Present_BackBuffer();
	WinConsole.CleanUp();


	Set_CursorVisibilityAndSize(true);
	Reset_CursorPos();
	//Set_CursorPos(0, 0);

	cout << "bye bye (Press Return)" << endl;


	getchar();
	return 0;

}
*/



