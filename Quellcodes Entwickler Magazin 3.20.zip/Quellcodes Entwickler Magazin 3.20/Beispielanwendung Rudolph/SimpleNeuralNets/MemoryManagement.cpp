#include "MemoryManagement.h"

using namespace std;

// Konstruktor:
CSimpleMemoryManager::CSimpleMemoryManager() : UnusedMemoryElementArray(nullptr), UsageStatusArray(nullptr), UnusedMemoryElementArrayID(0), NumMemoryElements(0), NumMemoryElementsMinus1(0)
{}

// Destruktor:
CSimpleMemoryManager::~CSimpleMemoryManager()
{
	delete[] UnusedMemoryElementArray;
	UnusedMemoryElementArray = nullptr;

	delete[] UsageStatusArray;
	UsageStatusArray = nullptr;
}

bool CSimpleMemoryManager::
Initialize(size_t numMemoryElements)
{
	delete[] UnusedMemoryElementArray;
	UnusedMemoryElementArray = nullptr;

	delete[] UsageStatusArray;
	UsageStatusArray = nullptr;

	NumMemoryElements = numMemoryElements;
	NumMemoryElementsMinus1 = numMemoryElements - 1;
	UnusedMemoryElementArrayID = 1;

	
	UnusedMemoryElementArray =
		new size_t[NumMemoryElements];

	if (UnusedMemoryElementArray == nullptr)
		return false;

	
	UsageStatusArray = new bool[NumMemoryElements];

	if (UsageStatusArray == nullptr)
		return false;


	for (size_t i = 0; i < NumMemoryElements; i++)
	{
		UnusedMemoryElementArray[i] = i;
		UsageStatusArray[i] = false;
	}

	return true;
}

size_t CSimpleMemoryManager::
Request_Unused_MemoryElementID(void)
{
	if (UnusedMemoryElementArrayID == NumMemoryElementsMinus1)
		return 0;

	size_t id = UnusedMemoryElementArray[
		UnusedMemoryElementArrayID];

	UsageStatusArray[id] = true;

	UnusedMemoryElementArrayID++;
	return id;
}

bool CSimpleMemoryManager::
Free_Used_MemoryElement(size_t id)
{
	if (id < 1)
		return false;

	if (id >= NumMemoryElementsMinus1)
		return false;

	if (UsageStatusArray[id] == false)
		return false;

	//if (UnusedMemoryElementArrayID == 1)
		//return false;

	UsageStatusArray[id] = false;

	UnusedMemoryElementArrayID--;
	UnusedMemoryElementArray[UnusedMemoryElementArrayID] = id;

	return true;
}

// Konstruktor:
CSimpleLinkedListManager::CSimpleLinkedListManager() : LinkedListElementArray(nullptr), NumUsedListElements(0), NumListElements(0), NumListElementsMinus1(0)
{}

// Destruktor:
CSimpleLinkedListManager::~CSimpleLinkedListManager()
{
	delete[] LinkedListElementArray;
	LinkedListElementArray = nullptr;
}

bool CSimpleLinkedListManager::
Initialize(size_t numListElements)
{
	delete[] LinkedListElementArray;
	LinkedListElementArray = nullptr;

	NumUsedListElements = 0;
	NumListElements = numListElements;
	NumListElementsMinus1 = numListElements - 1;

	/* Verzicht auf eine m�gliche Fehlerbehandlung
	(Ausnahme-Behandlung) bei der Speicheranforderung: */
	LinkedListElementArray =
		new CSimpleLinkedListElement[NumListElements];

	if (LinkedListElementArray == nullptr)
		return false;

	/* Erstes Element mit dem letzten
	Element verbinden: */
	LinkedListElementArray[0].NextElementID =
		NumListElementsMinus1;
	/* Letztes Element mit dem ersten
	Element verbinden: */
	LinkedListElementArray[NumListElementsMinus1].
		PrevElementID = 0;

	return true;
}

bool CSimpleLinkedListManager::
Init_New_ListElement(size_t elementID)
{
	// Element wird bereits verwendet:
	if (LinkedListElementArray[elementID].Used == true)
		return false;

	/* Erstes (id==0) und letztes (id==NumListElementsMinus1)
	Element dienen lediglich zur Listenverwaltung: */
	if (elementID < 1)
		return false;

	if (elementID >= NumListElementsMinus1)
		return false;

	LinkedListElementArray[elementID].Used = true;

	// Neues Element am Anfang der Liste einf�gen:

	/* ID des bisherigen ersten Elements
	zwischenspeichern: */
	size_t OldFirstElementID = LinkedListElementArray[0].
		NextElementID;

	// neues Element hinter dem Kopfknoten einf�gen:
	LinkedListElementArray[0].NextElementID = elementID;

	/* vormals erstes Element mit dem neuen ersten
	Element verkn�pfen: */
	LinkedListElementArray[OldFirstElementID].PrevElementID =
		elementID;

	/* neues erstes Element mit dem vormals ersten
	Element verkn�pfen: */
	LinkedListElementArray[elementID].NextElementID =
		OldFirstElementID;

	/* neues erstes Element mit dem Kopfknoten
	verkn�pfen: */
	LinkedListElementArray[elementID].PrevElementID = 0;


	NumUsedListElements++;

	return true;
}


bool CSimpleLinkedListManager::
Free_Used_ListElement(size_t elementID)
{
	/* Erstes (id==0) und letztes (id==NumListElementsMinus1)
	Element dienen lediglich zur Listenverwaltung: */
	if (elementID < 1)
		return false;

	if (elementID >= NumListElementsMinus1)
		return false;

	// Element wird bereits nicht mehr verwendet:
	if (LinkedListElementArray[elementID].Used == false)
		return false;

	LinkedListElementArray[elementID].Used = false;

	size_t NextElementID = LinkedListElementArray[
		elementID].NextElementID;

	size_t PrevElementID = LinkedListElementArray[
		elementID].PrevElementID;

	// �berbr�ckung des zu entfernenden Elements:

	LinkedListElementArray[PrevElementID].
		NextElementID = NextElementID;

	LinkedListElementArray[NextElementID].
		PrevElementID = PrevElementID;

	NumUsedListElements--;

	return true;
}

size_t CSimpleLinkedListManager::
Get_Next_Used_ListElement(
	size_t previousListElementID
/*first ID-Value must be 0*/)
{
	/* Falls m�glich das erste verwendete
	Element zur�ckgeben: */
	if (previousListElementID == 0)
	{
		if (NumUsedListElements == 0)
			return 0;
		else
			return LinkedListElementArray[0].NextElementID;
	}
	/* Falls m�glich ein weiteres verwendetes
	Element zur�ckgeben: */
	else
	{
		size_t tempID =
			LinkedListElementArray[previousListElementID].
			NextElementID;

		/* Kein Element gefunden (das letzte Element ist
		nur f�r Verwaltungsaufgaben vorgesehen): */
		if (tempID >= NumListElementsMinus1)
			return 0;
		else
			return tempID;
	}
}

