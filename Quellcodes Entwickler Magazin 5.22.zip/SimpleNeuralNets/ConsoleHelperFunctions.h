#include <windows.h>

// Schutz vor Mehrfachdeklarationen:
#ifndef _ConsoleHelperFunctions_H_
#define _ConsoleHelperFunctions_H_






//namespace HelperStuff
//{


#define KEYDOWN(vk_code) ((GetAsyncKeyState(vk_code) & 0x8000) ? 1 : 0)
#define KEYUP(vk_code)   ((GetAsyncKeyState(vk_code) & 0x8000) ? 0 : 1)


//enum SpecialASCIICharacters : char
enum SpecialASCIICharacters
{
	VerticalDoubleArrow = 18,
	HorizontalDoubleArrow = 29,

	ArrowUp = 24,
	ArrowDown = 25,
	ArrowRight = 26,
	ArrowLeft = 27,

	DiagonalCross = 158,

	Copyright = 184,

	LowDensityQuad = 176,
	MedDensityQuad = 177,
	HighDensityQuad = 178,
	FullQuad = 219,

	DoubleSmaller = 174,
	DoubleGreater = 175,

	LowerLeftDoubleCorner = 200,
	UpperLeftDoubleCorner = 201,
	UpperRightDoubleCorner = 187,
	LowerRightDoubleCorner = 188,

	LowerLeftCorner = 192,
	UpperLeftCorner = 218,
	UpperRightCorner = 191,
	LowerRightCorner = 217,

	DoubleLineCross = 206,
	LineCross = 197,

	VerticalDoubleLine = 186,
	HorizontalDoubleLine = 205,

	VerticalLine = 179,
	HorizontalLine = 196,

	RightT = 180,
	LeftT = 195,
	LowerT = 193,
	UpperT = 194,

	RightDoubleT = 185,
	LeftDoubleT = 204,
	LowerDoubleT = 202,
	UpperDoubleT = 203,

	TriangleRight = 16,
	TriangleLeft = 17,


	TriangleUp = 30,
	TriangleDown = 31,

	PlusMinus = 241,
	CenterDot = 250,

	DiagonalLine_TopRight = 47,
	DiagonalLine_TopLeft = 92

};

enum COLOR_PALETTE
{
	black,
	blue,
	green,
	aqua,
	red,
	purple,
	yello,
	graywhite,
	gray,
	lightblue,
	lightgreen,
	lightaqua,
	lightred,
	lightpurple,
	lightyello,
	white
};

#define BackgroundColor black

inline void Set_FontSize(int16_t sizeX = 10, int16_t sizeY = 20)
{
#ifdef _WIN32
	HANDLE outputHandle = GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_FONT_INFOEX consoleCurrentFontEx;
	consoleCurrentFontEx.cbSize = sizeof(CONSOLE_FONT_INFOEX);
	GetCurrentConsoleFontEx(outputHandle, 0, &consoleCurrentFontEx);
	consoleCurrentFontEx.dwFontSize.X = sizeX;
	consoleCurrentFontEx.dwFontSize.Y = sizeY;
	SetCurrentConsoleFontEx(outputHandle, 0, &consoleCurrentFontEx);
#endif
}

inline void Set_Font(const wchar_t* pFontName, int16_t sizeX = 10, int16_t sizeY = 20)
{
#ifdef _WIN32
	HANDLE outputHandle = GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_FONT_INFOEX consoleCurrentFontEx;
	consoleCurrentFontEx.cbSize = sizeof(CONSOLE_FONT_INFOEX);
	GetCurrentConsoleFontEx(outputHandle, 0, &consoleCurrentFontEx);
	consoleCurrentFontEx.dwFontSize.X = sizeX;
	consoleCurrentFontEx.dwFontSize.Y = sizeY;
	consoleCurrentFontEx.FontFamily = FF_DONTCARE;
	consoleCurrentFontEx.FontWeight = FW_NORMAL;
	wsprintf(consoleCurrentFontEx.FaceName, pFontName);
	SetCurrentConsoleFontEx(outputHandle, 0, &consoleCurrentFontEx);
#endif
}

inline void Set_BoldFont(const wchar_t* pFontName, int16_t sizeX = 10, int16_t sizeY = 20)
{
#ifdef _WIN32
	HANDLE outputHandle = GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_FONT_INFOEX consoleCurrentFontEx;
	consoleCurrentFontEx.cbSize = sizeof(CONSOLE_FONT_INFOEX);
	GetCurrentConsoleFontEx(outputHandle, 0, &consoleCurrentFontEx);
	consoleCurrentFontEx.dwFontSize.X = sizeX;
	consoleCurrentFontEx.dwFontSize.Y = sizeY;
	consoleCurrentFontEx.FontFamily = FF_DONTCARE;
	consoleCurrentFontEx.FontWeight = FW_HEAVY;
	wsprintf(consoleCurrentFontEx.FaceName, pFontName);
	SetCurrentConsoleFontEx(outputHandle, 0, &consoleCurrentFontEx);
#endif
}

inline void Use_NormalFont(void)
{
#ifdef _WIN32
	HANDLE outputHandle = GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_FONT_INFOEX consoleCurrentFontEx;
	consoleCurrentFontEx.cbSize = sizeof(CONSOLE_FONT_INFOEX);
	GetCurrentConsoleFontEx(outputHandle, 0, &consoleCurrentFontEx);
	consoleCurrentFontEx.FontWeight = FW_NORMAL;
	SetCurrentConsoleFontEx(outputHandle, 0, &consoleCurrentFontEx);
#endif
}

inline void Use_BoldFont(void)
{
#ifdef _WIN32
	HANDLE outputHandle = GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_FONT_INFOEX consoleCurrentFontEx;
	consoleCurrentFontEx.cbSize = sizeof(CONSOLE_FONT_INFOEX);
	GetCurrentConsoleFontEx(outputHandle, 0, &consoleCurrentFontEx);
	consoleCurrentFontEx.FontWeight = FW_HEAVY;
	SetCurrentConsoleFontEx(outputHandle, 0, &consoleCurrentFontEx);
#endif
}

inline void Set_CursorVisibilityAndSize(int32_t visible, DWORD size = 1)
{
#ifdef _WIN32
	CONSOLE_CURSOR_INFO info;
	info.bVisible = visible;
	info.dwSize = size;
	SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &info);
#endif
}

inline void Set_Title(const char* pTitle)
{
#ifdef _WIN32
	SetConsoleTitleA(pTitle);
#endif
}

inline void Set_ConsolePos(int32_t leftPos, int32_t upperPos)
{
#ifdef _WIN32
		
	//HWND handle = GetConsoleWindow();
	//SetWindowPos(GetConsoleWindow(), NULL, leftPos, upperPos, 0, 0, SWP_NOZORDER | SWP_NOSIZE);
	SetWindowPos(GetConsoleWindow(), NULL, leftPos, upperPos, 0, 0, TRUE);

#endif
}




inline void Set_TextColor(uint8_t foregroundColorValue, uint8_t backgroundColorValue)
{
#ifdef _WIN32
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), (backgroundColorValue << 4) + foregroundColorValue);
#endif
}

inline void Set_TextColor(uint16_t colorValue)
{
#ifdef _WIN32
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), colorValue);
#endif
}


inline void Set_CursorPos(int16_t x, int16_t y)
{
#ifdef _WIN32
	COORD pos = { x, y };
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), pos);
#else
	printf("\033[%d;%dH", y, x);
	fflush(stdout);
#endif
}

inline void Reset_CursorPos(void)
{
#ifdef _WIN32
	COORD pos = { 0, 0 };
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), pos);
#else
	printf("\033[0;0H");
	fflush(stdout);
#endif
}

inline void Clear_Terminal_And_Reset_CursorPos(void)
{
#ifdef _WIN32
	HANDLE outputHandle = GetStdHandle(STD_OUTPUT_HANDLE);

	CONSOLE_SCREEN_BUFFER_INFO screenBufferInfo;
	
	GetConsoleScreenBufferInfo(outputHandle, &screenBufferInfo);
	DWORD screenBufferSize = screenBufferInfo.dwSize.X *screenBufferInfo.dwSize.Y;

	DWORD numberOfWrittenChars;
	COORD pos = { 0, 0 };

	FillConsoleOutputCharacter(outputHandle, (TCHAR) ' ', screenBufferSize, pos, &numberOfWrittenChars);
	FillConsoleOutputAttribute(outputHandle, screenBufferInfo.wAttributes, screenBufferSize, pos, &numberOfWrittenChars);
	SetConsoleCursorPosition(outputHandle, pos);
#else
	printf("\033[2J");
	printf("\033[0;0H");
	fflush(stdout);
#endif
}


inline void Set_BackgroundColor(COLORREF color)
{
#ifdef _WIN32
	HANDLE outputHandle = GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_SCREEN_BUFFER_INFOEX sbInfoEx;
	sbInfoEx.cbSize = sizeof(CONSOLE_SCREEN_BUFFER_INFOEX);

	GetConsoleScreenBufferInfoEx(outputHandle, &sbInfoEx);

	sbInfoEx.ColorTable[0] = color;
	SetConsoleScreenBufferInfoEx(outputHandle, &sbInfoEx);
#endif
}

inline void Set_WindowSizeAndBackgroundColor(int16_t numCharactersPerRow, int16_t numCharactersPerColumn, bool scrollbar, COLORREF color)
{
#ifdef _WIN32
	
	COORD coord;
	coord.X = numCharactersPerRow;
	coord.Y = numCharactersPerColumn;

	SMALL_RECT rect;
	rect.Top = 0;
	rect.Left = 0;

	if (scrollbar == false)
	{
		rect.Bottom = numCharactersPerColumn;
		rect.Right = numCharactersPerRow;
	}
	else
	{
		rect.Bottom = numCharactersPerColumn - 1;
		rect.Right = numCharactersPerRow - 1;
	}

	HANDLE outputHandle = GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_SCREEN_BUFFER_INFOEX sbInfoEx;
	sbInfoEx.cbSize = sizeof(CONSOLE_SCREEN_BUFFER_INFOEX);


	GetConsoleScreenBufferInfoEx(outputHandle, &sbInfoEx);

	sbInfoEx.ColorTable[0] = color;
	sbInfoEx.dwSize = coord;
	sbInfoEx.srWindow = rect;
	SetConsoleScreenBufferInfoEx(outputHandle, &sbInfoEx);
#endif
}


class CInputHandling
{
public:

	HANDLE InputHandle = nullptr;

	DWORD OldInputMode;


	bool LeftMouseButtonPressed = false;
	bool MiddleMouseButtonPressed = false;
	bool RightMouseButtonPressed = false;

	int16_t MousePosX;
	int16_t MousePosY;

	CInputHandling()
	{}
	~CInputHandling()
	{}

	// Kopierkonstruktor l�schen:
	CInputHandling(const CInputHandling &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CInputHandling& operator=(const CInputHandling &originalObject) = delete;

	void Initialize(void)
	{
		InputHandle = GetStdHandle(STD_INPUT_HANDLE);

		GetConsoleMode(InputHandle, &OldInputMode);

		//DWORD dwMode = ENABLE_WINDOW_INPUT | ENABLE_MOUSE_INPUT;
		DWORD dwMode = ENABLE_MOUSE_INPUT;
		SetConsoleMode(InputHandle, dwMode);
	}

	void CleanUp(void)
	{
		SetConsoleMode(InputHandle, OldInputMode);
		//CloseHandle(InputHandle);
	}

	void Reset_MouseButtons(void)
	{
		LeftMouseButtonPressed = false;
		MiddleMouseButtonPressed = false;
		RightMouseButtonPressed = false;
	}

	bool Check_For_Input()
	{
		INPUT_RECORD InputRecord;
		DWORD InputRecordInfo;

		bool InputDetected = false;
		
		ReadConsoleInput(InputHandle, &InputRecord, 1, &InputRecordInfo);
		
		if (InputRecord.EventType == MOUSE_EVENT)
		{
			MousePosX = InputRecord.Event.MouseEvent.dwMousePosition.X;
			MousePosY = InputRecord.Event.MouseEvent.dwMousePosition.Y;

			if (InputRecord.Event.MouseEvent.dwButtonState == FROM_LEFT_1ST_BUTTON_PRESSED)
			{
				LeftMouseButtonPressed = true;

			}

			if (InputRecord.Event.MouseEvent.dwButtonState == FROM_LEFT_2ND_BUTTON_PRESSED)
			{
				MiddleMouseButtonPressed = true;
			}

			if (InputRecord.Event.MouseEvent.dwButtonState == RIGHTMOST_BUTTON_PRESSED)
			{
				RightMouseButtonPressed = true;
			}

			InputDetected = true;
		}

		return InputDetected;
	}

};


class CWindowsTimer
{
public:

	int64_t ActualCount_WithPerformanceCounter;
	int64_t Frequency_WithPerformanceCounter;
	int64_t StartCount_WithPerformanceCounter;

	CWindowsTimer()
	{
		QueryPerformanceFrequency((LARGE_INTEGER*)&Frequency_WithPerformanceCounter);
	}
	~CWindowsTimer()
	{}

	// Kopierkonstruktor l�schen:
	CWindowsTimer(const CWindowsTimer &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CWindowsTimer& operator=(const CWindowsTimer &originalObject) = delete;

	void Start_TimeMeasurement(void)
	{
		QueryPerformanceCounter((LARGE_INTEGER*)&StartCount_WithPerformanceCounter);
	}

	void Stop_TimeMeasurement(double* pElapsedTime)
	{
		QueryPerformanceCounter((LARGE_INTEGER*)&ActualCount_WithPerformanceCounter);

		*pElapsedTime = ((double)(ActualCount_WithPerformanceCounter - StartCount_WithPerformanceCounter) / (double)Frequency_WithPerformanceCounter);
	}

	void Stop_TimeMeasurement(double* pElapsedTime, double minFrameTime)
	{
		double elapsedTime;

		QueryPerformanceCounter((LARGE_INTEGER*)&ActualCount_WithPerformanceCounter);

		elapsedTime = ((double)(ActualCount_WithPerformanceCounter - StartCount_WithPerformanceCounter) / (double)Frequency_WithPerformanceCounter);

		while (elapsedTime < minFrameTime)
		{
			QueryPerformanceCounter((LARGE_INTEGER*)&ActualCount_WithPerformanceCounter);

			elapsedTime = ((double)(ActualCount_WithPerformanceCounter - StartCount_WithPerformanceCounter) / (double)Frequency_WithPerformanceCounter);
		}

		*pElapsedTime = elapsedTime;
	}
};

class CConsoleCollisionQuad
{
public:

	int16_t XMin = 0;
	int16_t XMax = 0;
	int16_t YMin = 0;
	int16_t YMax = 0;

	void Set_Position(int16_t xMin, int16_t xMax, int16_t yMin, int16_t yMax)
	{
		XMin = xMin;
		XMax = xMax;
		YMin = yMin;
		YMax = yMax;
	}

	void Set_Position(int16_t x, int16_t y)
	{
		XMin = x;
		XMax = x;
		YMin = y;
		YMax = y;
	}

	bool Check_Selection(int16_t mouseX, int16_t mouseY)
	{
		if (mouseX < XMin)
			return false;

		if (mouseX > XMax)
			return false;

		if (mouseY < YMin)
			return false;

		if (mouseY > YMax)
			return false;

		return true;
	}

	bool Check_Hit(int16_t possibleHitX, int16_t possibleHitY)
	{
		if (possibleHitX < XMin)
			return false;

		if (possibleHitX > XMax)
			return false;

		if (possibleHitY < YMin)
			return false;

		if (possibleHitY > YMax)
			return false;

		return true;
	}

	bool Check_Collision(CConsoleCollisionQuad *pOtherObject)
	{
		if (XMax < pOtherObject->XMin)
			return false;

		if (XMin > pOtherObject->XMax)
			return false;

		if (YMax < pOtherObject->YMin)
			return false;

		if (YMin > pOtherObject->YMax)
			return false;

		return true;
	}
};

class CWindowsConsoleScreenBuffer
{
public:

	HANDLE OutputHandle = nullptr;

	HANDLE ActualUsedOutputHandle;

	HANDLE OutputHandleA, OutputHandleB;

	int16_t NumCharactersPerRow;
	int16_t NumCharactersPerColumn;
	int16_t NumCharactersPerRowMinus1;
	int16_t NumCharactersPerColumnMinus1;
	int16_t NumCharacters;

	SMALL_RECT WindowSize;

	CHAR_INFO* pBackBuffer = nullptr;
	CHAR_INFO* pEmptyBuffer = nullptr;

	uint64_t FrameCounter = 0;

	bool Scrollbar = true;

	CWindowsConsoleScreenBuffer()
	{}
	~CWindowsConsoleScreenBuffer()
	{}

	// Kopierkonstruktor l�schen:
	CWindowsConsoleScreenBuffer(const CWindowsConsoleScreenBuffer &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CWindowsConsoleScreenBuffer& operator=(const CWindowsConsoleScreenBuffer &originalObject) = delete;

	void Set_Title(const char* pTitle)
	{
		SetConsoleTitleA(pTitle);
	}

	void Initialize(int16_t numCharactersPerRow, int16_t numCharactersPerColumn, bool scrollbar, COLORREF backgroundColor)
	{
		Scrollbar = scrollbar;

		FrameCounter = 0;

		OutputHandle = GetStdHandle(STD_OUTPUT_HANDLE);

		ActualUsedOutputHandle = OutputHandle;

		NumCharactersPerRow = numCharactersPerRow;
		NumCharactersPerColumn = numCharactersPerColumn;

		COORD coord;
		coord.X = NumCharactersPerRow;
		coord.Y = NumCharactersPerColumn;

		SMALL_RECT rect;
		rect.Top = 0;
		rect.Left = 0;

		if (scrollbar == false)
		{
			rect.Bottom = NumCharactersPerColumn;
			rect.Right = NumCharactersPerRow;
		}
		else
		{
			NumCharactersPerColumn--;
			NumCharactersPerRow--;
			rect.Bottom = NumCharactersPerColumn;
			rect.Right = NumCharactersPerRow;
		}

		NumCharactersPerRowMinus1 = NumCharactersPerRow - 1;
		NumCharactersPerColumnMinus1 = NumCharactersPerColumn - 1;

		CONSOLE_SCREEN_BUFFER_INFOEX screenBufferInfoEx;
		screenBufferInfoEx.cbSize = sizeof(CONSOLE_SCREEN_BUFFER_INFOEX);

		GetConsoleScreenBufferInfoEx(OutputHandle, &screenBufferInfoEx);

		screenBufferInfoEx.ColorTable[0] = backgroundColor;
		screenBufferInfoEx.dwSize = coord;
		screenBufferInfoEx.srWindow = rect;
		SetConsoleScreenBufferInfoEx(OutputHandle, &screenBufferInfoEx);

		NumCharacters = NumCharactersPerColumn*NumCharactersPerRow;

		pBackBuffer = new CHAR_INFO[NumCharacters];
		pEmptyBuffer = new CHAR_INFO[NumCharacters];

		for (uint32_t i = 0; i < NumCharacters; i++)
		{
			pBackBuffer[i].Char.AsciiChar = ' ';
			pBackBuffer[i].Attributes = 0;

			pEmptyBuffer[i].Char.AsciiChar = ' ';
			pEmptyBuffer[i].Attributes = 0;
		}


		OutputHandleA = CreateConsoleScreenBuffer(GENERIC_WRITE, 0, NULL, CONSOLE_TEXTMODE_BUFFER, NULL);
		OutputHandleB = CreateConsoleScreenBuffer(GENERIC_WRITE, 0, NULL, CONSOLE_TEXTMODE_BUFFER, NULL);

		CONSOLE_FONT_INFOEX consoleCurrentFontEx;
		consoleCurrentFontEx.cbSize = sizeof(CONSOLE_FONT_INFOEX);
		GetCurrentConsoleFontEx(OutputHandle, 0, &consoleCurrentFontEx);

		SetCurrentConsoleFontEx(OutputHandleA, FALSE, &consoleCurrentFontEx);
		SetConsoleScreenBufferSize(OutputHandleA, screenBufferInfoEx.dwSize);
		SetConsoleWindowInfo(OutputHandleA, TRUE, &screenBufferInfoEx.srWindow);

		SetCurrentConsoleFontEx(OutputHandleB, FALSE, &consoleCurrentFontEx);
		SetConsoleScreenBufferSize(OutputHandleB, screenBufferInfoEx.dwSize);
		SetConsoleWindowInfo(OutputHandleB, TRUE, &screenBufferInfoEx.srWindow);

	}

	

	void CleanUp(void)
	{
		NumCharactersPerRow = 30;
		NumCharactersPerColumn = 10;

		COORD coord;
		coord.X = NumCharactersPerRow;
		coord.Y = NumCharactersPerColumn;

		SMALL_RECT rect;
		rect.Top = 0;
		rect.Left = 0;

		
		NumCharactersPerColumn--;
		NumCharactersPerRow--;
		rect.Bottom = NumCharactersPerColumn;
		rect.Right = NumCharactersPerRow;

		CONSOLE_SCREEN_BUFFER_INFOEX screenBufferInfoEx;
		screenBufferInfoEx.cbSize = sizeof(CONSOLE_SCREEN_BUFFER_INFOEX);

		GetConsoleScreenBufferInfoEx(OutputHandle, &screenBufferInfoEx);

		screenBufferInfoEx.ColorTable[0] = RGB(0, 0, 0);
		screenBufferInfoEx.dwSize = coord;
		screenBufferInfoEx.srWindow = rect;
		SetConsoleScreenBufferInfoEx(OutputHandle, &screenBufferInfoEx);

		Set_Font(L"Consolas", 10, 20);

		Set_TextColor(graywhite, black);

		Set_CursorVisibilityAndSize(TRUE);

		ActualUsedOutputHandle = OutputHandle;
		SetConsoleActiveScreenBuffer(ActualUsedOutputHandle);

		Clear_BackBuffer();
		Present_BackBuffer();

		delete[] pBackBuffer;
		pBackBuffer = nullptr;

		delete[] pEmptyBuffer;
		pEmptyBuffer = nullptr;

		Set_CursorPos(0, 0);

		CloseHandle(OutputHandleA);
		CloseHandle(OutputHandleB);

		// w�rde dazu f�hren, dass sich nichts mehr in der Konsole ausgeben l�sst:
		//CloseHandle(OutputHandle);

	}

	void Set_TextColor(uint8_t foregroundColorValue, uint8_t backgroundColorValue)
	{
		SetConsoleTextAttribute(OutputHandle, (backgroundColorValue << 4) + foregroundColorValue);
		SetConsoleTextAttribute(OutputHandleA, (backgroundColorValue << 4) + foregroundColorValue);
		SetConsoleTextAttribute(OutputHandleB, (backgroundColorValue << 4) + foregroundColorValue);
	}

	void Set_CursorVisibilityAndSize(int32_t visible, DWORD size = 1)
	{
		CONSOLE_CURSOR_INFO info;
		info.bVisible = visible;
		info.dwSize = size;
		SetConsoleCursorInfo(OutputHandle, &info);
		SetConsoleCursorInfo(OutputHandleA, &info);
		SetConsoleCursorInfo(OutputHandleB, &info);
	}

	void Set_Font(const wchar_t* pFontName, int16_t sizeX = 10, int16_t sizeY = 20)
	{
		CONSOLE_FONT_INFOEX consoleCurrentFontEx;
		consoleCurrentFontEx.cbSize = sizeof(CONSOLE_FONT_INFOEX);
		GetCurrentConsoleFontEx(OutputHandle, 0, &consoleCurrentFontEx);
		consoleCurrentFontEx.dwFontSize.X = sizeX;
		consoleCurrentFontEx.dwFontSize.Y = sizeY;
		consoleCurrentFontEx.FontFamily = FF_DONTCARE;
		consoleCurrentFontEx.FontWeight = FW_NORMAL;
		wsprintf(consoleCurrentFontEx.FaceName, pFontName);
		SetCurrentConsoleFontEx(OutputHandle, 0, &consoleCurrentFontEx);
		SetCurrentConsoleFontEx(OutputHandleA, 0, &consoleCurrentFontEx);
		SetCurrentConsoleFontEx(OutputHandleB, 0, &consoleCurrentFontEx);
	}

	void Set_Font_Ext(const wchar_t* pFontName, uint32_t fontWeight, int16_t sizeX = 10, int16_t sizeY = 20)
	{
		CONSOLE_FONT_INFOEX consoleCurrentFontEx;
		consoleCurrentFontEx.cbSize = sizeof(CONSOLE_FONT_INFOEX);
		GetCurrentConsoleFontEx(OutputHandle, 0, &consoleCurrentFontEx);
		consoleCurrentFontEx.dwFontSize.X = sizeX;
		consoleCurrentFontEx.dwFontSize.Y = sizeY;
		consoleCurrentFontEx.FontFamily = FF_DONTCARE;
		consoleCurrentFontEx.FontWeight = 100 * fontWeight;
		wsprintf(consoleCurrentFontEx.FaceName, pFontName);
		SetCurrentConsoleFontEx(OutputHandle, 0, &consoleCurrentFontEx);
		SetCurrentConsoleFontEx(OutputHandleA, 0, &consoleCurrentFontEx);
		SetCurrentConsoleFontEx(OutputHandleB, 0, &consoleCurrentFontEx);
	}

	void Use_NormalFont(void)
	{
		CONSOLE_FONT_INFOEX consoleCurrentFontEx;
		consoleCurrentFontEx.cbSize = sizeof(CONSOLE_FONT_INFOEX);
		GetCurrentConsoleFontEx(OutputHandle, 0, &consoleCurrentFontEx);
		consoleCurrentFontEx.FontWeight = FW_NORMAL;
		SetCurrentConsoleFontEx(OutputHandle, 0, &consoleCurrentFontEx);
		SetCurrentConsoleFontEx(OutputHandleA, 0, &consoleCurrentFontEx);
		SetCurrentConsoleFontEx(OutputHandleB, 0, &consoleCurrentFontEx);
	}

	void Use_BoldFont(void)
	{
		CONSOLE_FONT_INFOEX consoleCurrentFontEx;
		consoleCurrentFontEx.cbSize = sizeof(CONSOLE_FONT_INFOEX);
		GetCurrentConsoleFontEx(OutputHandle, 0, &consoleCurrentFontEx);
		consoleCurrentFontEx.FontWeight = FW_HEAVY;
		SetCurrentConsoleFontEx(OutputHandle, 0, &consoleCurrentFontEx);
		SetCurrentConsoleFontEx(OutputHandleA, 0, &consoleCurrentFontEx);
		SetCurrentConsoleFontEx(OutputHandleB, 0, &consoleCurrentFontEx);
	}

	void Clear_BackBuffer(void)
	{
		memcpy(pBackBuffer, pEmptyBuffer, NumCharacters * sizeof(CHAR_INFO));
	}

	void Present_BackBuffer(void)
	{
		COORD CharBufSize = { NumCharactersPerRow, NumCharactersPerColumn };
		COORD CharacterPos = { 0, 0 };

		int16_t baseX = 0;
		int16_t baseY = 0;

		SMALL_RECT WriteArea = { baseX, baseY, baseX + NumCharactersPerRow, baseY + NumCharactersPerColumn };

		WriteConsoleOutputA(OutputHandle, pBackBuffer, CharBufSize, CharacterPos, &WriteArea);
	}

	void Update_DoubleBuffering(void)
	{
		if (FrameCounter % 2 == 0)
			ActualUsedOutputHandle = OutputHandleA;
		else
			ActualUsedOutputHandle = OutputHandleB;
	}

	void Present_BackBuffer_UseDoubleBuffering(void)
	{
		COORD CharBufSize = { NumCharactersPerRow, NumCharactersPerColumn };
		COORD CharacterPos = { 0, 0 };

		int16_t baseX = 0;
		int16_t baseY = 0;

		SMALL_RECT WriteArea = { baseX, baseY, baseX + NumCharactersPerRow, baseY + NumCharactersPerColumn };


		WriteConsoleOutputA(ActualUsedOutputHandle, pBackBuffer, CharBufSize, CharacterPos, &WriteArea);
		SetConsoleActiveScreenBuffer(ActualUsedOutputHandle);
		FrameCounter++;

	}

	void Set_BackgroundColor(COLORREF color)
	{
		CONSOLE_SCREEN_BUFFER_INFOEX sbInfoEx;
		sbInfoEx.cbSize = sizeof(CONSOLE_SCREEN_BUFFER_INFOEX);

		COORD coord;
		coord.X = NumCharactersPerRow;
		coord.Y = NumCharactersPerColumn;

		SMALL_RECT Rect;
		Rect.Top = 0;
		Rect.Left = 0;

		if (Scrollbar == false)
		{
			Rect.Bottom = NumCharactersPerColumn;
			Rect.Right = NumCharactersPerRow;
		}
		else
		{
			Rect.Bottom = NumCharactersPerColumn - 1;
			Rect.Right = NumCharactersPerRow - 1;
		}

		GetConsoleScreenBufferInfoEx(OutputHandle, &sbInfoEx);

		sbInfoEx.ColorTable[0] = color;
		sbInfoEx.dwSize = coord;
		sbInfoEx.srWindow = Rect;
		SetConsoleScreenBufferInfoEx(OutputHandle, &sbInfoEx);
	}

	void Set_BackgroundColor_UseDoubleBuffering(COLORREF color)
	{
		CONSOLE_SCREEN_BUFFER_INFOEX sbInfoEx;
		sbInfoEx.cbSize = sizeof(CONSOLE_SCREEN_BUFFER_INFOEX);

		COORD coord;
		coord.X = NumCharactersPerRow;
		coord.Y = NumCharactersPerColumn;

		SMALL_RECT Rect;
		Rect.Top = 0;
		Rect.Left = 0;

		if (Scrollbar == false)
		{
			Rect.Bottom = NumCharactersPerColumn;
			Rect.Right = NumCharactersPerRow;
		}
		else
		{
			Rect.Bottom = NumCharactersPerColumn - 1;
			Rect.Right = NumCharactersPerRow - 1;
		}

		GetConsoleScreenBufferInfoEx(OutputHandle, &sbInfoEx);

		sbInfoEx.ColorTable[0] = color;
		sbInfoEx.dwSize = coord;
		sbInfoEx.srWindow = Rect;
		//SetConsoleScreenBufferInfoEx(ActualUsedScreenBuffer, &sbInfoEx);

		SetConsoleScreenBufferInfoEx(OutputHandleA, &sbInfoEx);
		SetConsoleScreenBufferInfoEx(OutputHandleB, &sbInfoEx);
	}


	void Write_Pixel_Into_BackBuffer(uint32_t posX, uint32_t posY, COLOR_PALETTE colorValue)
	{
		uint32_t pos = posX + NumCharactersPerRow*posY;

		pBackBuffer[pos].Char.AsciiChar = ' ';
		//pBackBuffer[pos].Attributes = 16 * colorValue;
		pBackBuffer[pos].Attributes = colorValue << 4;
	}

	void Write_Pixel_Into_BackBuffer(uint32_t posX, uint32_t posY, uint32_t colorValue)
	{
		uint32_t pos = posX + NumCharactersPerRow*posY;

		pBackBuffer[pos].Char.AsciiChar = ' ';
		//pBackBuffer[pos].Attributes = 16 * colorValue;
		pBackBuffer[pos].Attributes = colorValue << 4;
	}

	void Write_Character_Into_BackBuffer(uint32_t posX, uint32_t posY, char c, uint32_t foregroundColorValue, uint32_t backgroundColorValue)
	{
		uint32_t pos = posX + NumCharactersPerRow*posY;

		pBackBuffer[pos].Char.AsciiChar = c;
		//pBackBuffer[pos].Attributes = foregroundColorValue + 16 * backgroundColorValue;
		pBackBuffer[pos].Attributes = (backgroundColorValue << 4) + foregroundColorValue;
	}

	void Write_Character_Into_BackBuffer(uint32_t posX, uint32_t posY, char c, COLOR_PALETTE foregroundColorValue, COLOR_PALETTE backgroundColorValue)
	{
		uint32_t pos = posX + NumCharactersPerRow*posY;

		pBackBuffer[pos].Char.AsciiChar = c;
		//pBackBuffer[pos].Attributes = foregroundColorValue + 16 * backgroundColorValue;
		pBackBuffer[pos].Attributes = (backgroundColorValue << 4) + foregroundColorValue;
	}

	void Write_String_Into_BackBuffer(uint32_t posX, uint32_t posY, char* pString, COLOR_PALETTE textColorValue, COLOR_PALETTE backgroundColorValue)
	{
		uint32_t pos = posX + NumCharactersPerRow*posY;

		uint32_t length = strlen(pString);

		uint32_t posMax = pos + length;

		if (posMax > NumCharacters)
			return;

		//WORD Attributes = textColorValue + 16 * backgroundColorValue;
		WORD Attributes = backgroundColorValue << 4;
		Attributes += textColorValue;

		for (uint32_t i = pos, j = 0; i < posMax; i++, j++)
		{
			pBackBuffer[i].Char.AsciiChar = pString[j];
			//pBackBuffer[i].Attributes = textColorValue + 16 * backgroundColorValue;
			pBackBuffer[i].Attributes = Attributes;
		}
	}

	void Write_String_Into_BackBuffer(uint32_t posX, uint32_t posY, char* pString, uint32_t numCharacters, COLOR_PALETTE textColorValue, COLOR_PALETTE backgroundColorValue)
	{
		uint32_t pos = posX + NumCharactersPerRow*posY;

		uint32_t posMax = pos + numCharacters;

		if (posMax > NumCharacters)
			return;

		//WORD Attributes = textColorValue + 16 * backgroundColorValue;
		WORD Attributes = backgroundColorValue << 4;
		Attributes += textColorValue;

		for (uint32_t i = pos, j = 0; i < posMax; i++, j++)
		{
			pBackBuffer[i].Char.AsciiChar = pString[j];
			//pBackBuffer[i].Attributes = textColorValue + 16 * backgroundColorValue;
			pBackBuffer[i].Attributes = Attributes;
		}
	}

	void Write_String_Into_BackBuffer(uint32_t posX, uint32_t posY, char* pString, uint32_t numCharacters, uint32_t textColorValue, uint32_t backgroundColorValue)
	{
		uint32_t pos = posX + NumCharactersPerRow*posY;

		uint32_t posMax = pos + numCharacters;

		if (posMax > NumCharacters)
			return;

		//WORD Attributes = textColorValue + 16 * backgroundColorValue;
		WORD Attributes = backgroundColorValue << 4;
		Attributes += textColorValue;

		for (uint32_t i = pos, j = 0; i < posMax; i++, j++)
		{
			pBackBuffer[i].Char.AsciiChar = pString[j];
			//pBackBuffer[i].Attributes = textColorValue + 16 * backgroundColorValue;
			pBackBuffer[i].Attributes = Attributes;
		}
	}

	void Write_String_Into_BackBuffer(uint32_t posX, uint32_t posY, char* pString, uint32_t textColorValue, uint32_t backgroundColorValue)
	{
		uint32_t pos = posX + NumCharactersPerRow*posY;

		uint32_t length = strlen(pString);

		uint32_t posMax = pos + length;

		if (posMax > NumCharacters)
			return;

		//WORD Attributes = textColorValue + 16 * backgroundColorValue;
		WORD Attributes = backgroundColorValue << 4;
		Attributes += textColorValue;

		for (uint32_t i = pos, j = 0; i < posMax; i++, j++)
		{
			pBackBuffer[i].Char.AsciiChar = pString[j];
			//pBackBuffer[i].Attributes = textColorValue + 16 * backgroundColorValue;
			pBackBuffer[i].Attributes = Attributes;
		}
	}

	void Draw_HorizontalLine_Into_BackBuffer(uint32_t posX_Left, uint32_t posY, uint32_t length, COLOR_PALETTE colorValue)
	{
		uint32_t pos = posX_Left + NumCharactersPerRow*posY;

		//WORD Attributes = 16 * colorValue;
		WORD Attributes = colorValue << 4;

		for (uint32_t i = 0; i < length; i++)
		{
			pBackBuffer[pos].Char.AsciiChar = ' ';
			//pBackBuffer[pos].Attributes = 16 * colorValue;
			pBackBuffer[pos].Attributes = Attributes;
			pos++;
		}

	}

	void Draw_HorizontalLine_Into_BackBuffer(uint32_t posX_Left, uint32_t posY, uint32_t length, char c, COLOR_PALETTE foregroundColorValue, COLOR_PALETTE backgroundColorValue)
	{
		uint32_t pos = posX_Left + NumCharactersPerRow*posY;

		//WORD Attributes = foregroundColorValue + 16 * backgroundColorValue;
		WORD Attributes = backgroundColorValue << 4;
		Attributes += foregroundColorValue;

		for (uint32_t i = 0; i < length; i++)
		{
			pBackBuffer[pos].Char.AsciiChar = c;
			pBackBuffer[pos].Attributes = Attributes;
			pos++;
		}
	}

	void Draw_HorizontalLine_Into_BackBuffer(uint32_t posX_Left, uint32_t posY, uint32_t length, uint32_t colorValue)
	{
		uint32_t pos = posX_Left + NumCharactersPerRow*posY;

		//WORD Attributes = 16 * colorValue;
		WORD Attributes = colorValue << 4;

		for (uint32_t i = 0; i < length; i++)
		{
			pBackBuffer[pos].Char.AsciiChar = ' ';
			pBackBuffer[pos].Attributes = Attributes;
			pos++;
		}

	}

	void Draw_HorizontalLine_Into_BackBuffer(uint32_t posX_Left, uint32_t posY, uint32_t length, char c, uint32_t foregroundColorValue, uint32_t backgroundColorValue)
	{
		uint32_t pos = posX_Left + NumCharactersPerRow*posY;

		//WORD Attributes = foregroundColorValue + 16 * backgroundColorValue;
		WORD Attributes = backgroundColorValue << 4;
		Attributes += foregroundColorValue;

		for (uint32_t i = 0; i < length; i++)
		{
			pBackBuffer[pos].Char.AsciiChar = c;
			pBackBuffer[pos].Attributes = Attributes;
			pos++;
		}
	}
	
	void Draw_VerticalLine_Into_BackBuffer(uint32_t posX, uint32_t posY_Top, uint32_t length, COLOR_PALETTE colorValue)
	{
		uint32_t pos = posX + NumCharactersPerRow*posY_Top;

		//WORD Attributes = 16 * colorValue;
		WORD Attributes = colorValue << 4;

		for (uint32_t i = 0; i < length; i++)
		{
			pBackBuffer[pos].Char.AsciiChar = ' ';
			//pBackBuffer[pos].Attributes = 16 * colorValue;
			pBackBuffer[pos].Attributes = Attributes;
			pos += NumCharactersPerRow;
		}
	}

	void Draw_VerticalLine_Into_BackBuffer(uint32_t posX, uint32_t posY_Top, uint32_t length, uint32_t colorValue)
	{
		uint32_t pos = posX + NumCharactersPerRow*posY_Top;

		//WORD Attributes = 16 * colorValue;
		WORD Attributes = colorValue << 4;

		for (uint32_t i = 0; i < length; i++)
		{
			pBackBuffer[pos].Char.AsciiChar = ' ';
			//pBackBuffer[pos].Attributes = 16 * colorValue;
			pBackBuffer[pos].Attributes = Attributes;
			pos += NumCharactersPerRow;
		}
	}

	void Draw_VerticalLine_Into_BackBuffer(uint32_t posX, uint32_t posY_Top, uint32_t length, char c, COLOR_PALETTE foregroundColorValue, COLOR_PALETTE backgroundColorValue)
	{
		uint32_t pos = posX + NumCharactersPerRow*posY_Top;

		//WORD Attributes = foregroundColorValue + 16 * backgroundColorValue;
		WORD Attributes = backgroundColorValue << 4;
		Attributes += foregroundColorValue;

		for (uint32_t i = 0; i < length; i++)
		{
			pBackBuffer[pos].Char.AsciiChar = c;
			pBackBuffer[pos].Attributes = Attributes;
			pos += NumCharactersPerRow;
		}
	}

	void Draw_VerticalLine_Into_BackBuffer(uint32_t posX, uint32_t posY_Top, uint32_t length, char c, uint32_t foregroundColorValue, uint32_t backgroundColorValue)
	{
		uint32_t pos = posX + NumCharactersPerRow*posY_Top;

		//WORD Attributes = foregroundColorValue + 16 * backgroundColorValue;
		WORD Attributes = backgroundColorValue << 4;
		Attributes += foregroundColorValue;

		for (uint32_t i = 0; i < length; i++)
		{
			pBackBuffer[pos].Char.AsciiChar = c;
			pBackBuffer[pos].Attributes = Attributes;
			pos += NumCharactersPerRow;
		}
	}


	void Draw_DiagonalLine1_Into_BackBuffer(uint32_t posX_Left, uint32_t posY_Top, uint32_t length, COLOR_PALETTE colorValue)
	{
		uint32_t pos = posX_Left + NumCharactersPerRow*posY_Top;

		uint32_t deltaPos = NumCharactersPerRow + 1;

		//WORD Attributes = 16 * colorValue;
		WORD Attributes = colorValue << 4;

		for (uint32_t i = 0; i < length; i++)
		{
			pBackBuffer[pos].Char.AsciiChar = ' ';
			pBackBuffer[pos].Attributes = Attributes;
			pos += deltaPos;
		}
	}
	
	void Draw_DiagonalLine1_Into_BackBuffer(uint32_t posX_Left, uint32_t posY_Top, uint32_t length, char c, COLOR_PALETTE foregroundColorValue, COLOR_PALETTE backgroundColorValue)
	{
		uint32_t pos = posX_Left + NumCharactersPerRow*posY_Top;

		uint32_t deltaPos = NumCharactersPerRow + 1;

		//WORD Attributes = foregroundColorValue + 16 * backgroundColorValue;
		WORD Attributes = backgroundColorValue << 4;
		Attributes += foregroundColorValue;

		for (uint32_t i = 0; i < length; i++)
		{
			pBackBuffer[pos].Char.AsciiChar = c;
			pBackBuffer[pos].Attributes = Attributes;
			pos += deltaPos;
		}
	}
	
	void Draw_DiagonalLine1_Into_BackBuffer(uint32_t posX_Left, uint32_t posY_Top, uint32_t length, uint32_t colorValue)
	{
		uint32_t pos = posX_Left + NumCharactersPerRow*posY_Top;

		uint32_t deltaPos = NumCharactersPerRow + 1;

		//WORD Attributes = 16 * colorValue;
		WORD Attributes = colorValue << 4;

		for (uint32_t i = 0; i < length; i++)
		{
			pBackBuffer[pos].Char.AsciiChar = ' ';
			pBackBuffer[pos].Attributes = Attributes;
			pos += deltaPos;
		}
	}

	void Draw_DiagonalLine1_Into_BackBuffer(uint32_t posX_Left, uint32_t posY_Top, uint32_t length, char c, uint32_t foregroundColorValue, uint32_t  backgroundColorValue)
	{
		uint32_t pos = posX_Left + NumCharactersPerRow*posY_Top;

		uint32_t deltaPos = NumCharactersPerRow + 1;

		//WORD Attributes = foregroundColorValue + 16 * backgroundColorValue;
		WORD Attributes = backgroundColorValue << 4;
		Attributes += foregroundColorValue;

		for (uint32_t i = 0; i < length; i++)
		{
			pBackBuffer[pos].Char.AsciiChar = c;
			pBackBuffer[pos].Attributes = Attributes;
			pos += deltaPos;
		}
	}

	void Draw_DiagonalLine2_Into_BackBuffer(uint32_t posX_Right, uint32_t posY_Top, uint32_t length, COLOR_PALETTE colorValue)
	{
		uint32_t pos = posX_Right + NumCharactersPerRow*posY_Top;

		uint32_t deltaPos = NumCharactersPerRow - 1;

		//WORD Attributes = 16 * colorValue;
		WORD Attributes = colorValue << 4;

		for (uint32_t i = 0; i < length; i++)
		{
			pBackBuffer[pos].Char.AsciiChar = ' ';
			pBackBuffer[pos].Attributes = Attributes;
			pos += deltaPos;
		}
	}

	void Draw_DiagonalLine2_Into_BackBuffer(uint32_t posX_Right, uint32_t posY_Top, uint32_t length, char c, COLOR_PALETTE foregroundColorValue, COLOR_PALETTE backgroundColorValue)
	{
		uint32_t pos = posX_Right + NumCharactersPerRow*posY_Top;

		uint32_t deltaPos = NumCharactersPerRow - 1;

		//WORD Attributes = foregroundColorValue + 16 * backgroundColorValue;
		WORD Attributes = backgroundColorValue << 4;
		Attributes += foregroundColorValue;

		for (uint32_t i = 0; i < length; i++)
		{
			pBackBuffer[pos].Char.AsciiChar = c;
			pBackBuffer[pos].Attributes = Attributes;
			pos += deltaPos;
		}
	}

	void Draw_DiagonalLine2_Into_BackBuffer(uint32_t posX_Right, uint32_t posY_Top, uint32_t length, uint32_t colorValue)
	{
		uint32_t pos = posX_Right + NumCharactersPerRow*posY_Top;

		uint32_t deltaPos = NumCharactersPerRow - 1;

		//WORD Attributes = 16 * colorValue;
		WORD Attributes = colorValue << 4;

		for (uint32_t i = 0; i < length; i++)
		{
			pBackBuffer[pos].Char.AsciiChar = ' ';
			pBackBuffer[pos].Attributes = Attributes;
			pos += deltaPos;
		}
	}

	void Draw_DiagonalLine2_Into_BackBuffer(uint32_t posX_Right, uint32_t posY_Top, uint32_t length, char c, uint32_t foregroundColorValue, uint32_t backgroundColorValue)
	{
		uint32_t pos = posX_Right + NumCharactersPerRow*posY_Top;

		uint32_t deltaPos = NumCharactersPerRow - 1;

		//WORD Attributes = foregroundColorValue + 16 * backgroundColorValue;
		WORD Attributes = backgroundColorValue << 4;
		Attributes += foregroundColorValue;

		for (uint32_t i = 0; i < length; i++)
		{
			pBackBuffer[pos].Char.AsciiChar = c;
			pBackBuffer[pos].Attributes = Attributes;
			pos += deltaPos;
		}
	}

	void Draw_Line_Into_BackBuffer(uint32_t xStart, uint32_t yStart, uint32_t xEnd, uint32_t yEnd, COLOR_PALETTE colorValue)
	{
		uint32_t pos;

		int32_t deltaX = labs(xEnd - xStart);
		int32_t deltaY = labs(yEnd - yStart);
		int32_t deltaMin;
		int32_t numpixels; // deltaMax
		int32_t err;
		int32_t x = xStart;
		int32_t y = yStart;
		int32_t xChange_DiagonalStep;
		int32_t xChange_ParallelStep;
		int32_t yChange_DiagonalStep;
		int32_t yChange_ParallelStep;


		//WORD Attributes = 16 * colorValue;
		WORD Attributes = colorValue << 4;


		if (xEnd >= xStart)
		{
			xChange_DiagonalStep = 1;
			xChange_ParallelStep = 1;
		}
		else
		{
			xChange_DiagonalStep = -1;
			xChange_ParallelStep = -1;
		}

		if (yEnd >= yStart)
		{
			yChange_DiagonalStep = 1;
			yChange_ParallelStep = 1;
		}
		else
		{
			yChange_DiagonalStep = -1;
			yChange_ParallelStep = -1;
		}

		if (deltaX >= deltaY)
		{
			xChange_DiagonalStep = 0;
			yChange_ParallelStep = 0;
			err = deltaX / 2;
			deltaMin = deltaY;
			numpixels = deltaX;
		}
		else //if (deltaX < deltaY)
		{
			xChange_ParallelStep = 0;
			yChange_DiagonalStep = 0;
			err = deltaY / 2;
			deltaMin = deltaX;
			numpixels = deltaY;
		}

		for (uint32_t i = 0; i <= numpixels; i++)
		{
			pos = x + NumCharactersPerRow*y;
			pBackBuffer[pos].Char.AsciiChar = ' ';
			pBackBuffer[pos].Attributes = Attributes;

			err += deltaMin;

			if (err >= numpixels)
			{
				err -= numpixels;
				x += xChange_DiagonalStep;
				y += yChange_DiagonalStep;
			}
			x += xChange_ParallelStep;
			y += yChange_ParallelStep;
		}
	}
	
	void Draw_Line_Into_BackBuffer(uint32_t xStart, uint32_t yStart, uint32_t xEnd, uint32_t yEnd, char c, COLOR_PALETTE foregroundColorValue, COLOR_PALETTE backgroundColorValue)
	{
		uint32_t pos;

		int32_t deltaX = labs(xEnd - xStart);
		int32_t deltaY = labs(yEnd - yStart);
		int32_t deltaMin;
		int32_t numpixels; // deltaMax
		int32_t err;
		int32_t x = xStart;
		int32_t y = yStart;
		int32_t xChange_DiagonalStep;
		int32_t xChange_ParallelStep;
		int32_t yChange_DiagonalStep;
		int32_t yChange_ParallelStep;

		//WORD Attributes = foregroundColorValue + 16 * backgroundColorValue;
		WORD Attributes = backgroundColorValue << 4;
		Attributes += foregroundColorValue;


		if (xEnd >= xStart)
		{
			xChange_DiagonalStep = 1;
			xChange_ParallelStep = 1;
		}
		else
		{
			xChange_DiagonalStep = -1;
			xChange_ParallelStep = -1;
		}

		if (yEnd >= yStart)
		{
			yChange_DiagonalStep = 1;
			yChange_ParallelStep = 1;
		}
		else
		{
			yChange_DiagonalStep = -1;
			yChange_ParallelStep = -1;
		}

		if (deltaX >= deltaY)
		{
			xChange_DiagonalStep = 0;
			yChange_ParallelStep = 0;
			err = deltaX / 2;
			deltaMin = deltaY;
			numpixels = deltaX;
		}
		else //if (deltaX < deltaY)
		{
			xChange_ParallelStep = 0;
			yChange_DiagonalStep = 0;
			err = deltaY / 2;
			deltaMin = deltaX;
			numpixels = deltaY;
		}

		for (uint32_t i = 0; i <= numpixels; i++)
		{
			pos = x + NumCharactersPerRow*y;
			pBackBuffer[pos].Char.AsciiChar = c;
			pBackBuffer[pos].Attributes = Attributes;

			err += deltaMin;

			if (err >= numpixels)
			{
				err -= numpixels;
				x += xChange_DiagonalStep;
				y += yChange_DiagonalStep;
			}
			x += xChange_ParallelStep;
			y += yChange_ParallelStep;
		}
	}

	void Draw_Line_Into_BackBuffer(uint32_t xStart, uint32_t yStart, uint32_t xEnd, uint32_t yEnd, uint32_t colorValue)
	{
		uint32_t pos;

		int32_t deltaX = labs(xEnd - xStart);
		int32_t deltaY = labs(yEnd - yStart);
		int32_t deltaMin;
		int32_t numpixels; // deltaMax
		int32_t err;
		int32_t x = xStart;
		int32_t y = yStart;
		int32_t xChange_DiagonalStep;
		int32_t xChange_ParallelStep;
		int32_t yChange_DiagonalStep;
		int32_t yChange_ParallelStep;


		//WORD Attributes = 16 * colorValue;
		WORD Attributes = colorValue << 4;


		if (xEnd >= xStart)
		{
			xChange_DiagonalStep = 1;
			xChange_ParallelStep = 1;
		}
		else
		{
			xChange_DiagonalStep = -1;
			xChange_ParallelStep = -1;
		}

		if (yEnd >= yStart)
		{
			yChange_DiagonalStep = 1;
			yChange_ParallelStep = 1;
		}
		else
		{
			yChange_DiagonalStep = -1;
			yChange_ParallelStep = -1;
		}

		if (deltaX >= deltaY)
		{
			xChange_DiagonalStep = 0;
			yChange_ParallelStep = 0;
			err = deltaX / 2;
			deltaMin = deltaY;
			numpixels = deltaX;
		}
		else //if (deltaX < deltaY)
		{
			xChange_ParallelStep = 0;
			yChange_DiagonalStep = 0;
			err = deltaY / 2;
			deltaMin = deltaX;
			numpixels = deltaY;
		}

		for (uint32_t i = 0; i <= numpixels; i++)
		{
			pos = x + NumCharactersPerRow*y;
			pBackBuffer[pos].Char.AsciiChar = ' ';
			pBackBuffer[pos].Attributes = Attributes;

			err += deltaMin;

			if (err >= numpixels)
			{
				err -= numpixels;
				x += xChange_DiagonalStep;
				y += yChange_DiagonalStep;
			}
			x += xChange_ParallelStep;
			y += yChange_ParallelStep;
		}
	}

	void Draw_Line_Into_BackBuffer(uint32_t xStart, uint32_t yStart, uint32_t xEnd, uint32_t yEnd, char c, uint32_t foregroundColorValue, uint32_t backgroundColorValue)
	{
		uint32_t pos;

		int32_t deltaX = labs(xEnd - xStart);
		int32_t deltaY = labs(yEnd - yStart);
		int32_t deltaMin;
		int32_t numpixels; // deltaMax
		int32_t err;
		int32_t x = xStart;
		int32_t y = yStart;
		int32_t xChange_DiagonalStep;
		int32_t xChange_ParallelStep;
		int32_t yChange_DiagonalStep;
		int32_t yChange_ParallelStep;

		//WORD Attributes = foregroundColorValue + 16 * backgroundColorValue;
		WORD Attributes = backgroundColorValue << 4;
		Attributes += foregroundColorValue;


		if (xEnd >= xStart)
		{
			xChange_DiagonalStep = 1;
			xChange_ParallelStep = 1;
		}
		else
		{
			xChange_DiagonalStep = -1;
			xChange_ParallelStep = -1;
		}

		if (yEnd >= yStart)
		{
			yChange_DiagonalStep = 1;
			yChange_ParallelStep = 1;
		}
		else
		{
			yChange_DiagonalStep = -1;
			yChange_ParallelStep = -1;
		}

		if (deltaX >= deltaY)
		{
			xChange_DiagonalStep = 0;
			yChange_ParallelStep = 0;
			err = deltaX / 2;
			deltaMin = deltaY;
			numpixels = deltaX;
		}
		else //if (deltaX < deltaY)
		{
			xChange_ParallelStep = 0;
			yChange_DiagonalStep = 0;
			err = deltaY / 2;
			deltaMin = deltaX;
			numpixels = deltaY;
		}

		for (uint32_t i = 0; i <= numpixels; i++)
		{
			pos = x + NumCharactersPerRow*y;
			pBackBuffer[pos].Char.AsciiChar = c;
			pBackBuffer[pos].Attributes = Attributes;

			err += deltaMin;

			if (err >= numpixels)
			{
				err -= numpixels;
				x += xChange_DiagonalStep;
				y += yChange_DiagonalStep;
			}
			x += xChange_ParallelStep;
			y += yChange_ParallelStep;
		}
	}

	void Draw_2DObject_Into_BackBuffer(int32_t posX_Left, int32_t posY_Top, CHAR_INFO* pObject, int32_t numCharactersXDir, int32_t numCharactersYDir)
	{
		if (posX_Left > NumCharactersPerRowMinus1)
			return;
		if (posY_Top > NumCharactersPerColumnMinus1)
			return;

		int32_t xMax = posX_Left + numCharactersXDir;

		if (xMax <= 0)
			return;

		int32_t yMax = posY_Top + numCharactersYDir;

		if (yMax <= 0)
			return;



		if (posX_Left > -1 && posY_Top > -1 && xMax < NumCharactersPerRow && yMax < NumCharactersPerColumn)
		{
			int32_t y, x;

			int32_t pos, posY;
			int32_t posLocal, posYLocal;

			for (y = 0; y < numCharactersYDir; y++)
			{
				posY = posY_Top + y;

				posY *= NumCharactersPerRow;

				posYLocal = y * numCharactersXDir;

				for (x = 0; x < numCharactersXDir; x++)
				{
					posLocal = x + posYLocal;

					if (pObject[posLocal].Attributes < 1)
						continue;

					pos = posX_Left + x + posY;

					pBackBuffer[pos].Char.AsciiChar = pObject[posLocal].Char.AsciiChar;
					pBackBuffer[pos].Attributes = pObject[posLocal].Attributes;
				}
			}

		} // end if (posX_Left > -1 && posY_Top > -1 && xMax < NumCharactersPerRow && yMax < NumCharactersPerColumn)
		else
		{
			int32_t y, x;

			int32_t pos, posX, posY;
			int32_t posLocal, posYLocal;

			for (y = 0; y < numCharactersYDir; y++)
			{
				posY = posY_Top + y;

				if (posY < 0)
					continue;

				if (posY > NumCharactersPerColumnMinus1)
					break;

				posY *= NumCharactersPerRow;

				posYLocal = y * numCharactersXDir;

				for (x = 0; x < numCharactersXDir; x++)
				{
					posLocal = x + posYLocal;

					if (pObject[posLocal].Attributes < 1)
						continue;

					posX = posX_Left + x;

					if (posX < 0)
						continue;

					if (posX > NumCharactersPerRowMinus1)
						break;

					pos = posX + posY;

					pBackBuffer[pos].Char.AsciiChar = pObject[posLocal].Char.AsciiChar;
					pBackBuffer[pos].Attributes = pObject[posLocal].Attributes;
				}
			}

		}





	}

	void Draw_2DObject_Into_BackBuffer(int32_t posX_Left, int32_t posY_Top, int32_t offsetX, int32_t offsetY, int32_t numVisibleCharactersXDir, int32_t numVisibleCharactersYDir, CHAR_INFO* pObject, int32_t numCharactersXDir, int32_t numCharactersYDir)
	{
		offsetX = max(offsetX, 0);
		offsetY = max(offsetY, 0);

		int32_t posXLeft = posX_Left + offsetX;
		int32_t posYTop = posY_Top + offsetY;

		if (posXLeft > NumCharactersPerRowMinus1)
			return;
		if (posYTop > NumCharactersPerColumnMinus1)
			return;

		numVisibleCharactersXDir += offsetX;
		numVisibleCharactersXDir = min(numVisibleCharactersXDir, numCharactersXDir);

		numVisibleCharactersYDir += offsetY;
		numVisibleCharactersYDir = min(numVisibleCharactersYDir, numCharactersYDir);

		int32_t xMax = posX_Left + numVisibleCharactersXDir;

		if (xMax <= 0)
			return;

		int32_t yMax = posY_Top + numVisibleCharactersYDir;

		if (yMax <= 0)
			return;


		//Add_To_Log(0, "xMax", &xMax);


		if (posXLeft > -1 && posYTop > -1 && xMax < NumCharactersPerRow && yMax < NumCharactersPerColumn)
		{
			int32_t y, x;

			int32_t pos, posY;
			int32_t posLocal, posYLocal;

			for (y = offsetY; y < numVisibleCharactersYDir; y++)
			{
				posY = posY_Top + y;

				posY *= NumCharactersPerRow;

				posYLocal = y * numCharactersXDir;

				for (x = offsetX; x < numVisibleCharactersXDir; x++)
				{
					posLocal = x + posYLocal;

					if (pObject[posLocal].Attributes < 1)
						continue;

					pos = posX_Left + x + posY;

					pBackBuffer[pos].Char.AsciiChar = pObject[posLocal].Char.AsciiChar;
					pBackBuffer[pos].Attributes = pObject[posLocal].Attributes;
				}
			}

		} // end if (posXLeft > -1 && posYTop > -1 && xMax < NumCharactersPerRow && yMax < NumCharactersPerColumn)
		else
		{
			int32_t y, x;

			int32_t pos, posX, posY;
			int32_t posLocal, posYLocal;

			for (y = offsetY; y < numVisibleCharactersYDir; y++)
			{
				posY = posY_Top + y;

				if (posY < 0)
					continue;

				if (posY > NumCharactersPerColumnMinus1)
					break;

				posY *= NumCharactersPerRow;

				posYLocal = y * numCharactersXDir;

				for (x = offsetX; x < numVisibleCharactersXDir; x++)
				{
					posLocal = x + posYLocal;

					if (pObject[posLocal].Attributes < 1)
						continue;

					posX = posX_Left + x;

					if (posX < 0)
						continue;

					if (posX > NumCharactersPerRowMinus1)
						break;

					pos = posX + posY;

					pBackBuffer[pos].Char.AsciiChar = pObject[posLocal].Char.AsciiChar;
					pBackBuffer[pos].Attributes = pObject[posLocal].Attributes;
				}
			}
		}
	}

};


class CWindowsConsole2DObject
{
public:

	int32_t NumCharactersPerRow = 0;
	int32_t NumCharactersPerColumn = 0;
	int32_t NumCharacters = 0;

	CHAR_INFO *pDataArray = nullptr;

	CWindowsConsole2DObject()
	{}
	~CWindowsConsole2DObject()
	{
		delete[] pDataArray;
		pDataArray = nullptr;
	}

	// Kopierkonstruktor l�schen:
	CWindowsConsole2DObject(const CWindowsConsole2DObject &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CWindowsConsole2DObject& operator=(const CWindowsConsole2DObject &originalObject) = delete;

	void RotateDeg(float angle, CHAR_INFO *pOriginalDataArray)
	{
		if(angle == 0.0f)
		{
			for (int32_t i = 0; i < NumCharacters; i++)
			{
				pDataArray[i].Char.AsciiChar = pOriginalDataArray[i].Char.AsciiChar;
				pDataArray[i].Attributes = pOriginalDataArray[i].Attributes;
			}

			return;
		}

		if (angle == -90.0f)
			angle = 270.0f;
		else if (angle == -180.0f)
			angle = 180.0f;


		float angleRad = -angle * 3.14159265359f / 180.0f;

		for (int32_t i = 0; i < NumCharacters; i++)
		{
			pDataArray[i].Char.AsciiChar = ' ';
			pDataArray[i].Attributes = 0;
		}

		int32_t ix, iy;

		float xOriginal, yOriginal;
		int32_t ixRotated, iyRotated;


		int32_t icenterX = NumCharactersPerRow / 2;
		int32_t icenterY = NumCharactersPerColumn / 2;

		float centerX = (float)icenterX;
		float centerY = (float)icenterY;


		float deltaX, deltaY;
		int32_t iDeltaYsinAngle;
		int32_t iDeltaYcosAngle;

		int32_t NumCharactersPerRowMinus1 = NumCharactersPerRow - 1;
		int32_t NumCharactersPerColumnMinus1 = NumCharactersPerColumn - 1;


		int32_t idRotated;
		int32_t id = 0;

		if (angle == abs(90.0f) || angle == abs(180.0f) || angle == abs(270.0f))
		{
			float cosAngle = cos(angleRad);
			float sinAngle = sin(angleRad);

			for (iy = 0; iy < NumCharactersPerColumn; iy++)
			{
				yOriginal = (float)iy;
				deltaY = yOriginal - centerY;

				iDeltaYsinAngle = (int32_t)(deltaY * sinAngle);
				iDeltaYcosAngle = (int32_t)(deltaY * cosAngle);

				for (ix = 0; ix < NumCharactersPerRow; ix++)
				{
					xOriginal = (float)ix;
					deltaX = xOriginal - centerX;

					ixRotated = (int32_t)(deltaX * cosAngle) - iDeltaYsinAngle + icenterX;
					iyRotated = (int32_t)(deltaX * sinAngle) + iDeltaYcosAngle + icenterY;

					ixRotated = max(0, ixRotated);
					ixRotated = min(ixRotated, NumCharactersPerRowMinus1);

					iyRotated = max(0, iyRotated);
					iyRotated = min(iyRotated, NumCharactersPerColumnMinus1);

					//id = ix + iy * NumCharactersPerRow;
					idRotated = ixRotated + iyRotated * NumCharactersPerRow;

					pDataArray[id].Char.AsciiChar = pOriginalDataArray[idRotated].Char.AsciiChar;
					pDataArray[id].Attributes = pOriginalDataArray[idRotated].Attributes;
					id++;
				}
			}
		}
		else
		{
			float cosAngle = sqrt(2.0f)*cos(angleRad);
			float sinAngle = sqrt(2.0f)*sin(angleRad);

			for (iy = 0; iy < NumCharactersPerColumn; iy++)
			{
				deltaY = (float)iy - centerY;

				for (ix = 0; ix < NumCharactersPerRow; ix++)
				{
					deltaX = (float)ix - centerX;
					ixRotated = (int32_t)(deltaX  * cosAngle - deltaY  * sinAngle);
					iyRotated = (int32_t)(deltaX  * sinAngle + deltaY  * cosAngle);
					ixRotated = ixRotated + centerX;
					iyRotated = iyRotated + centerY;

					ixRotated = max(0, ixRotated);
					ixRotated = min(ixRotated, NumCharactersPerRowMinus1);

					iyRotated = max(0, iyRotated);
					iyRotated = min(iyRotated, NumCharactersPerColumnMinus1);

					idRotated = ixRotated + iyRotated * NumCharactersPerRow;

					pDataArray[id].Char.AsciiChar = pOriginalDataArray[idRotated].Char.AsciiChar;
					pDataArray[id].Attributes = pOriginalDataArray[idRotated].Attributes;
					id++;
				}
			}
		}


		

		
		

		

		

		

		
	
		
	}

	

	void Initialize(int16_t numCharactersPerRow, int16_t numCharactersPerColumn)
	{
		delete[] pDataArray;
		pDataArray = nullptr;

		NumCharactersPerRow = numCharactersPerRow;
		NumCharactersPerColumn = numCharactersPerColumn;

		NumCharacters = NumCharactersPerRow * NumCharactersPerColumn;

		pDataArray = new CHAR_INFO[NumCharacters];

		for (uint32_t i = 0; i < NumCharacters; i++)
		{
			pDataArray[i].Char.AsciiChar = ' ';
			pDataArray[i].Attributes = 0;
		}
	}

	void Initialize(int16_t numCharactersPerRow, int16_t numCharactersPerColumn, COLOR_PALETTE backgroundColorValue)
	{
		delete[] pDataArray;
		pDataArray = nullptr;

		NumCharactersPerRow = numCharactersPerRow;
		NumCharactersPerColumn = numCharactersPerColumn;

		NumCharacters = NumCharactersPerRow * NumCharactersPerColumn;

		pDataArray = new CHAR_INFO[NumCharacters];

		WORD colorValue = backgroundColorValue << 4;

		for (uint32_t i = 0; i < NumCharacters; i++)
		{
			pDataArray[i].Char.AsciiChar = ' ';
			pDataArray[i].Attributes = colorValue;
		}
	}

	void Set_Character(uint32_t posX, uint32_t posY, char c, COLOR_PALETTE foregroundColorValue, COLOR_PALETTE backgroundColorValue)
	{
		uint32_t pos = posX + NumCharactersPerRow*posY;

		pDataArray[pos].Char.AsciiChar = c;
		//pDataArray[pos].Attributes = foregroundColorValue + 16 * backgroundColorValue;
		pDataArray[pos].Attributes = (backgroundColorValue << 4) + foregroundColorValue;
	}
	void Set_Pixel(uint32_t posX, uint32_t posY, COLOR_PALETTE colorValue)
	{
		uint32_t pos = posX + NumCharactersPerRow*posY;

		pDataArray[pos].Char.AsciiChar = ' ';
		//pDataArray[pos].Attributes = 16 * colorValue;
		pDataArray[pos].Attributes = colorValue << 4;
	}

	void Set_Pixel(uint32_t pos, COLOR_PALETTE colorValue)
	{
		pDataArray[pos].Char.AsciiChar = ' ';
		//pDataArray[pos].Attributes = 16 * colorValue;
		pDataArray[pos].Attributes = colorValue << 4;
	}

	void Modify(int32_t posX_Left, int32_t posY_Top, CWindowsConsole2DObject *pOtherObject)
	{
		uint32_t otherObjectNumCharactersPerColumn = pOtherObject->NumCharactersPerColumn;
		uint32_t otherObjectNumCharactersPerRow = pOtherObject->NumCharactersPerRow;

		uint32_t pos, localPos, ix, iy;

		for (iy = 0; iy < otherObjectNumCharactersPerColumn; iy++)
		{
			for (ix = 0; ix < otherObjectNumCharactersPerRow; ix++)
			{
				localPos = ix + iy*otherObjectNumCharactersPerRow;

				pos = posX_Left + ix + (posY_Top + iy)*NumCharactersPerRow;

				pDataArray[pos].Char.AsciiChar = pOtherObject->pDataArray[localPos].Char.AsciiChar;
				pDataArray[pos].Attributes = pOtherObject->pDataArray[localPos].Attributes;
			}
		}
	}

	void Init_SmallGrid(uint32_t numGridElementsXDir, uint32_t numGridElementsYDir, COLOR_PALETTE foregroundColorValue, COLOR_PALETTE backgroundColorValue)
	{
		uint32_t NumGridElementsXDir = numGridElementsXDir;
		uint32_t NumGridElementsYDir = numGridElementsYDir;

		uint32_t NumGridElementsXDirMinus1 = numGridElementsXDir - 1;
		uint32_t NumGridElementsYDirMinus1 = numGridElementsYDir - 1;

		uint32_t NumCharactersXDir = numGridElementsXDir * 2 + 1;
		uint32_t NumCharactersYDir = numGridElementsYDir * 2 + 1;

		Initialize(numGridElementsXDir * 2 + 1, numGridElementsYDir * 2 + 1, backgroundColorValue);

		uint32_t NumCharactersXDirMinus1 = NumCharactersXDir - 1;
		uint32_t NumCharactersYDirMinus1 = NumCharactersYDir - 1;

		uint32_t x, y;

		for (y = 0; y < NumCharactersYDir; y++)
		{
			if (y % 2 == 0)
			{
				Set_Character(0, y, LeftT, foregroundColorValue, backgroundColorValue);
				Set_Character(NumCharactersXDirMinus1, y, RightT, foregroundColorValue, backgroundColorValue);
			}
			else
			{
				Set_Character(0, y, VerticalLine, foregroundColorValue, backgroundColorValue);
				Set_Character(NumCharactersXDirMinus1, y, VerticalLine, foregroundColorValue, backgroundColorValue);
			}
		}

		for (y = 0; y < NumCharactersYDir; y++)
		{
			for (x = 0; x < NumCharactersXDir; x++)
			{
				if (y == 0)
				{
					if (x % 2 == 0)
						Set_Character(x, y, UpperT, foregroundColorValue, backgroundColorValue);
					else
						Set_Character(x, y, HorizontalLine, foregroundColorValue, backgroundColorValue);
				}
				else if (y == NumCharactersYDirMinus1)
				{
					if (x % 2 == 0)
						Set_Character(x, y, LowerT, foregroundColorValue, backgroundColorValue);
					else
						Set_Character(x, y, HorizontalLine, foregroundColorValue, backgroundColorValue);
				}
				else
				{
					if (x > 0 && x < NumCharactersXDirMinus1)
					{
						if (x % 2 == 0)
						{
							if (y % 2 == 0)
								Set_Character(x, y, LineCross, foregroundColorValue, backgroundColorValue);
							else if (y % 2 == 1)
								Set_Character(x, y, VerticalLine, foregroundColorValue, backgroundColorValue);
						}
						else
						{
							if (y % 2 == 0)
								Set_Character(x, y, HorizontalLine, foregroundColorValue, backgroundColorValue);
						}
					}
				}
			}
		}

		Set_Character(0, 0, UpperLeftCorner, foregroundColorValue, backgroundColorValue);
		Set_Character(NumCharactersXDir - 1, 0, UpperRightCorner, foregroundColorValue, backgroundColorValue);

		Set_Character(0, NumCharactersYDir - 1, LowerLeftCorner, foregroundColorValue, backgroundColorValue);
		Set_Character(NumCharactersXDir - 1, NumCharactersYDir - 1, LowerRightCorner, foregroundColorValue, backgroundColorValue);
	}

	void Init_MediumGrid(uint32_t numGridElementsXDir, uint32_t numGridElementsYDir, COLOR_PALETTE foregroundColorValue, COLOR_PALETTE backgroundColorValue)
	{
		uint32_t NumGridElementsXDir = numGridElementsXDir;
		uint32_t NumGridElementsYDir = numGridElementsYDir;

		uint32_t NumGridElementsXDirMinus1 = numGridElementsXDir - 1;
		uint32_t NumGridElementsYDirMinus1 = numGridElementsYDir - 1;

		uint32_t NumCharactersXDir = numGridElementsXDir * 3 + 1;
		uint32_t NumCharactersYDir = numGridElementsYDir * 3 + 1;

		Initialize(numGridElementsXDir * 3 + 1, numGridElementsYDir * 3 + 1, backgroundColorValue);

		uint32_t NumCharactersXDirMinus1 = NumCharactersXDir - 1;
		uint32_t NumCharactersYDirMinus1 = NumCharactersYDir - 1;

		uint32_t x, y;

		for (y = 0; y < NumCharactersYDir; y++)
		{
			if (y % 3 == 0)
			{
				Set_Character(0, y, LeftT, foregroundColorValue, backgroundColorValue);
				Set_Character(NumCharactersXDirMinus1, y, RightT, foregroundColorValue, backgroundColorValue);
			}
			else
			{
				Set_Character(0, y, VerticalLine, foregroundColorValue, backgroundColorValue);
				Set_Character(NumCharactersXDirMinus1, y, VerticalLine, foregroundColorValue, backgroundColorValue);
			}
		}

		for (y = 0; y < NumCharactersYDir; y++)
		{
			for (x = 0; x < NumCharactersXDir; x++)
			{
				if (y == 0)
				{
					if (x % 3 == 0)
						Set_Character(x, y, UpperT, foregroundColorValue, backgroundColorValue);
					else
						Set_Character(x, y, HorizontalLine, foregroundColorValue, backgroundColorValue);
				}
				else if (y == NumCharactersYDirMinus1)
				{
					if (x % 3 == 0)
						Set_Character(x, y, LowerT, foregroundColorValue, backgroundColorValue);
					else
						Set_Character(x, y, HorizontalLine, foregroundColorValue, backgroundColorValue);
				}
				else
				{
					if (x > 0 && x < NumCharactersXDirMinus1)
					{
						if (x % 3 == 0)
						{
							if (y % 3 == 0)
								Set_Character(x, y, LineCross, foregroundColorValue, backgroundColorValue);
							else if (y % 3 == 1 || y % 3 == 2)
								Set_Character(x, y, VerticalLine, foregroundColorValue, backgroundColorValue);
						}
						else
						{
							if (y % 3 == 0)
								Set_Character(x, y, HorizontalLine, foregroundColorValue, backgroundColorValue);
						}
					}
				}
			}
		}

		Set_Character(0, 0, UpperLeftCorner, foregroundColorValue, backgroundColorValue);
		Set_Character(NumCharactersXDir - 1, 0, UpperRightCorner, foregroundColorValue, backgroundColorValue);

		Set_Character(0, NumCharactersYDir - 1, LowerLeftCorner, foregroundColorValue, backgroundColorValue);
		Set_Character(NumCharactersXDir - 1, NumCharactersYDir - 1, LowerRightCorner, foregroundColorValue, backgroundColorValue);
	}

	void Init_LargeGrid(uint32_t numGridElementsXDir, uint32_t numGridElementsYDir, COLOR_PALETTE foregroundColorValue, COLOR_PALETTE backgroundColorValue)
	{
		uint32_t NumGridElementsXDir = numGridElementsXDir;
		uint32_t NumGridElementsYDir = numGridElementsYDir;

		uint32_t NumGridElementsXDirMinus1 = numGridElementsXDir - 1;
		uint32_t NumGridElementsYDirMinus1 = numGridElementsYDir - 1;

		uint32_t NumCharactersXDir = numGridElementsXDir * 4 + 1;
		uint32_t NumCharactersYDir = numGridElementsYDir * 4 + 1;

		Initialize(numGridElementsXDir * 4 + 1, numGridElementsYDir * 4 + 1, backgroundColorValue);

		uint32_t NumCharactersXDirMinus1 = NumCharactersXDir - 1;
		uint32_t NumCharactersYDirMinus1 = NumCharactersYDir - 1;

		uint32_t x, y;

		for (y = 0; y < NumCharactersYDir; y++)
		{
			if (y % 4 == 0)
			{
				Set_Character(0, y, LeftT, foregroundColorValue, backgroundColorValue);
				Set_Character(NumCharactersXDirMinus1, y, RightT, foregroundColorValue, backgroundColorValue);
			}
			else
			{
				Set_Character(0, y, VerticalLine, foregroundColorValue, backgroundColorValue);
				Set_Character(NumCharactersXDirMinus1, y, VerticalLine, foregroundColorValue, backgroundColorValue);
			}
		}

		for (y = 0; y < NumCharactersYDir; y++)
		{
			for (x = 0; x < NumCharactersXDir; x++)
			{
				if (y == 0)
				{
					if (x % 4 == 0)
						Set_Character(x, y, UpperT, foregroundColorValue, backgroundColorValue);
					else
						Set_Character(x, y, HorizontalLine, foregroundColorValue, backgroundColorValue);
				}
				else if (y == NumCharactersYDirMinus1)
				{
					if (x % 4 == 0)
						Set_Character(x, y, LowerT, foregroundColorValue, backgroundColorValue);
					else
						Set_Character(x, y, HorizontalLine, foregroundColorValue, backgroundColorValue);
				}
				else
				{
					if (x > 0 && x < NumCharactersXDirMinus1)
					{
						if (x % 4 == 0)
						{
							if (y % 4 == 0)
								Set_Character(x, y, LineCross, foregroundColorValue, backgroundColorValue);
							else if (y % 4 == 1 || y % 4 == 2 || y % 4 == 3)
								Set_Character(x, y, VerticalLine, foregroundColorValue, backgroundColorValue);
						}
						else
						{
							if (y % 4 == 0)
								Set_Character(x, y, HorizontalLine, foregroundColorValue, backgroundColorValue);
						}
					}
				}
			}
		}

		Set_Character(0, 0, UpperLeftCorner, foregroundColorValue, backgroundColorValue);
		Set_Character(NumCharactersXDir - 1, 0, UpperRightCorner, foregroundColorValue, backgroundColorValue);

		Set_Character(0, NumCharactersYDir - 1, LowerLeftCorner, foregroundColorValue, backgroundColorValue);
		Set_Character(NumCharactersXDir - 1, NumCharactersYDir - 1, LowerRightCorner, foregroundColorValue, backgroundColorValue);
	}
};

//} /* end of namespace HelperStuff */




#endif