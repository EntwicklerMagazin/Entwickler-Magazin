#include <iostream>
#include "NeuralNet.h"

using namespace std;

//#define BisectResolution
#define MaxPoolResolution


inline float SigmoidOutput(float neuronInput)
{
	// von 0.0f bis 1.0f:
	return 1.0f / (1.0f + exp(-neuronInput));
}

inline float TanHOutput(float neuronInput)
{
	// von -1.0f bis 1.0f:
	return tanh(neuronInput);
}


inline float LinearOutput(float neuronInput)
{
	return neuronInput;
}

inline float ReLUOutput(float neuronInput)
{
	// von 0.0f bis unendlich:
	return max(0.0f, neuronInput);
}

inline float BinaryOutput(float neuronInput)
{
	//if (neuronInput > 0.9999f)
	//return 1.0f;

	// less accuracy
	if (neuronInput > 0.99f)
		return 1.0f;

	return 0.0f;
}

/*
int main(void)
{
	static float Image_5_1[32 * 32];
	static float Image_5_2[32 * 32];

	static float Image_S_1[32 * 32];
	static float Image_S_2[32 * 32];

	static float Image_6_1[32 * 32];
	static float Image_6_2[32 * 32];

	static float Image_G_1[32 * 32];
	static float Image_G_2[32 * 32];

	static float Image_8_1[32 * 32];
	static float Image_8_2[32 * 32];

	static float Image_B_1[32 * 32];
	static float Image_B_2[32 * 32];

	// test image(s):

	static float Image_5_3[32 * 32];
	static float Image_S_3[32 * 32];
	static float Image_6_3[32 * 32];
	static float Image_G_3[32 * 32];
	static float Image_8_3[32 * 32];
	static float Image_B_3[32 * 32];



	uint8_t *pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_5_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_5_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;


	pImageData = Read_Bitmap_BGR("Sample_S_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_S_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_S_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;


	pImageData = Read_Bitmap_BGR("Sample_6_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_6_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_6_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_G_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_G_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;


	pImageData = Read_Bitmap_BGR("Sample_B_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;


	// test image(s):

	pImageData = Read_Bitmap_BGR("Sample_5_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_5_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_S_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_6_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_G_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;


	CNeuralNet Brain;
	Brain.Init_NeuralNet(32 * 32 + 1 + 6);
	Brain.Init_TwoLayerNetwork(32 * 32, -0.2f, 0.2f, 0.2f, true, 6, SigmoidOutput);
	
	uint32_t maxCount = 2000;
	uint32_t epoch = 0;
	float error;

	uint32_t i;

	float OutputPattern[6];

	float DesiredOutputPattern1[6] = { 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f };
	float DesiredOutputPattern2[6] = { 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f };
	float DesiredOutputPattern3[6] = { 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f };
	float DesiredOutputPattern4[6] = { 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f };
	float DesiredOutputPattern5[6] = { 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f };
	float DesiredOutputPattern6[6] = { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f };


	// start training:


	uint64_t seed = 1;

	for (i = 0; i < maxCount; i++)
	{
		epoch++;
		error = 0.0f;

		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_5_1);
		error += Brain.Learning_TwoLayerNetwork(DesiredOutputPattern1);

		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_5_2);
		error += Brain.Learning_TwoLayerNetwork(DesiredOutputPattern1);

		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_S_1);
		error += Brain.Learning_TwoLayerNetwork(DesiredOutputPattern2);

		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_S_2);
		error += Brain.Learning_TwoLayerNetwork(DesiredOutputPattern2);

		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_6_1);
		error += Brain.Learning_TwoLayerNetwork(DesiredOutputPattern3);

		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_6_2);
		error += Brain.Learning_TwoLayerNetwork(DesiredOutputPattern3);

		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_G_1);
		error += Brain.Learning_TwoLayerNetwork(DesiredOutputPattern4);

		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_G_2);
		error += Brain.Learning_TwoLayerNetwork(DesiredOutputPattern4);

		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_8_1);
		error += Brain.Learning_TwoLayerNetwork(DesiredOutputPattern5);

		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_8_2);
		error += Brain.Learning_TwoLayerNetwork(DesiredOutputPattern5);

		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_B_1);
		error += Brain.Learning_TwoLayerNetwork(DesiredOutputPattern6);

		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_B_2);
		error += Brain.Learning_TwoLayerNetwork(DesiredOutputPattern6);

		if (error < 0.0001f)
			break;

		Brain.RandomChange_OutputSynapsePlasticities2(seed++, -0.005f, 0.005f, 0.5f);
	}

	// training completed

	// training statistics:

	cout << "epoch: " << epoch << endl;
	cout << "error: " << error << endl << endl;



	cout << fixed;
	cout.precision(2);


	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_5_1);

	cout << "5 (1)" << " " << "desired output: 1 0 0 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_5_2);

	cout << "5 (2)" << " " << "desired output: 1 0 0 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;


	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_S_1);

	cout << "S (1)" << " " << "desired output: 0 1 0 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_S_2);

	cout << "S (2)" << " " << "desired output: 0 1 0 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_6_1);

	cout << "6 (1)" << " " << "desired output: 0 0 1 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_6_2);

	cout << "6 (2)" << " " << "desired output: 0 0 1 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_G_1);

	cout << "G (1)" << " " << "desired output: 0 0 0 1 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_G_2);

	cout << "G (2)" << " " << "desired output: 0 0 0 1 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_8_1);

	cout << "8 (1)" << " " << "desired output: 0 0 0 0 1 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_8_2);

	cout << "8 (2)" << " " << "desired output: 0 0 0 0 1 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_B_1);

	cout << "B (1)" << " " << "desired output: 0 0 0 0 0 1" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_B_2);

	cout << "B (2)" << " " << "desired output: 0 0 0 0 0 1" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	// test image(s):

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_5_3);

	//Normalize(OutputPattern, 6);

	cout << "unknown 5" << " " << "desired output: 1 0 0 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_S_3);

	//Normalize(OutputPattern, 6);

	cout << "unknown S" << " " << "desired output: 0 1 0 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_6_3);

	//Normalize(OutputPattern, 6);

	cout << "unknown 6" << " " << "desired output: 0 0 1 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_G_3);

	//Normalize(OutputPattern, 6);

	cout << "unknown G" << " " << "desired output: 0 0 0 1 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_8_3);

	//Normalize(OutputPattern, 6);

	cout << "unknown 8" << " " << "desired output: 0 0 0 0 1 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_B_3);

	//Normalize(OutputPattern, 6);

	cout << "unknown B" << " " << "desired output: 0 0 0 0 0 1" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;



	getchar();
	return 0;
}
*/



/*
int main(void)
{
	static float Image_5_1[16 * 16];
	static float Image_5_2[16 * 16];

	static float Image_S_1[16 * 16];
	static float Image_S_2[16 * 16];

	static float Image_6_1[16 * 16];
	static float Image_6_2[16 * 16];

	static float Image_G_1[16 * 16];
	static float Image_G_2[16 * 16];

	static float Image_8_1[16 * 16];
	static float Image_8_2[16 * 16];

	static float Image_B_1[16 * 16];
	static float Image_B_2[16 * 16];


	static float Image_5_1_L[32 * 32];
	static float Image_5_2_L[32 * 32];

	static float Image_S_1_L[32 * 32];
	static float Image_S_2_L[32 * 32];

	static float Image_6_1_L[32 * 32];
	static float Image_6_2_L[32 * 32];

	static float Image_G_1_L[32 * 32];
	static float Image_G_2_L[32 * 32];

	static float Image_8_1_L[32 * 32];
	static float Image_8_2_L[32 * 32];

	static float Image_B_1_L[32 * 32];
	static float Image_B_2_L[32 * 32];

	// test image(s):

	static float Image_5_3[16 * 16];
	static float Image_S_3[16 * 16];
	static float Image_6_3[16 * 16];
	static float Image_G_3[16 * 16];
	static float Image_8_3[16 * 16];
	static float Image_B_3[16 * 16];

	static float Image_5_3_L[32 * 32];
	static float Image_S_3_L[32 * 32];
	static float Image_6_3_L[32 * 32];
	static float Image_G_3_L[32 * 32];
	static float Image_8_3_L[32 * 32];
	static float Image_B_3_L[32 * 32];



	uint8_t *pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_5_1_L, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_5_2_L, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;


	pImageData = Read_Bitmap_BGR("Sample_S_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_S_1_L, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_S_2_L, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;


	pImageData = Read_Bitmap_BGR("Sample_6_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_6_1_L, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_6_2_L, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_G_1_L, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_G_2_L, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_1_L, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_2_L, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;


	pImageData = Read_Bitmap_BGR("Sample_B_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_1_L, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_2_L, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;


	// test image(s):

	pImageData = Read_Bitmap_BGR("Sample_5_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_5_3_L, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_S_3_L, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_6_3_L, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_G_3_L, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_3_L, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_3_L, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;


#ifdef BisectResolution

	Bisect_Resolution(Image_5_1, Image_5_1_L, 32, 32);
	Bisect_Resolution(Image_5_2, Image_5_2_L, 32, 32);
	Bisect_Resolution(Image_5_3, Image_5_3_L, 32, 32);

	Bisect_Resolution(Image_S_1, Image_S_1_L, 32, 32);
	Bisect_Resolution(Image_S_2, Image_S_2_L, 32, 32);
	Bisect_Resolution(Image_S_3, Image_S_3_L, 32, 32);

	Bisect_Resolution(Image_6_1, Image_6_1_L, 32, 32);
	Bisect_Resolution(Image_6_2, Image_6_2_L, 32, 32);
	Bisect_Resolution(Image_6_3, Image_6_3_L, 32, 32);

	Bisect_Resolution(Image_G_1, Image_G_1_L, 32, 32);
	Bisect_Resolution(Image_G_2, Image_G_2_L, 32, 32);
	Bisect_Resolution(Image_G_3, Image_G_3_L, 32, 32);

	Bisect_Resolution(Image_8_1, Image_8_1_L, 32, 32);
	Bisect_Resolution(Image_8_2, Image_8_2_L, 32, 32);
	Bisect_Resolution(Image_8_3, Image_8_3_L, 32, 32);

	Bisect_Resolution(Image_B_1, Image_B_1_L, 32, 32);
	Bisect_Resolution(Image_B_2, Image_B_2_L, 32, 32);
	Bisect_Resolution(Image_B_3, Image_B_3_L, 32, 32);

#endif

#ifdef MaxPoolResolution

	MaxPooling2x2(Image_5_1, Image_5_1_L, 32, 32);
	MaxPooling2x2(Image_5_2, Image_5_2_L, 32, 32);
	MaxPooling2x2(Image_5_3, Image_5_3_L, 32, 32);

	MaxPooling2x2(Image_S_1, Image_S_1_L, 32, 32);
	MaxPooling2x2(Image_S_2, Image_S_2_L, 32, 32);
	MaxPooling2x2(Image_S_3, Image_S_3_L, 32, 32);

	MaxPooling2x2(Image_6_1, Image_6_1_L, 32, 32);
	MaxPooling2x2(Image_6_2, Image_6_2_L, 32, 32);
	MaxPooling2x2(Image_6_3, Image_6_3_L, 32, 32);

	MaxPooling2x2(Image_G_1, Image_G_1_L, 32, 32);
	MaxPooling2x2(Image_G_2, Image_G_2_L, 32, 32);
	MaxPooling2x2(Image_G_3, Image_G_3_L, 32, 32);

	MaxPooling2x2(Image_8_1, Image_8_1_L, 32, 32);
	MaxPooling2x2(Image_8_2, Image_8_2_L, 32, 32);
	MaxPooling2x2(Image_8_3, Image_8_3_L, 32, 32);

	MaxPooling2x2(Image_B_1, Image_B_1_L, 32, 32);
	MaxPooling2x2(Image_B_2, Image_B_2_L, 32, 32);
	MaxPooling2x2(Image_B_3, Image_B_3_L, 32, 32);

#endif

	CNeuralNet Brain;
	Brain.Init_NeuralNet(16 * 16 + 1 + 6);
	Brain.Init_TwoLayerNetwork(16 * 16, -0.2f, 0.2f, 0.2f, true, 6, SigmoidOutput);



	uint32_t maxCount = 2000;
	uint32_t epoch = 0;
	float error;

	uint32_t i;

	float OutputPattern[6];

	float DesiredOutputPattern1[6] = { 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f };
	float DesiredOutputPattern2[6] = { 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f };
	float DesiredOutputPattern3[6] = { 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f };
	float DesiredOutputPattern4[6] = { 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f };
	float DesiredOutputPattern5[6] = { 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f };
	float DesiredOutputPattern6[6] = { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f };


	// start training:


	uint64_t seed = 1;

	for (i = 0; i < maxCount; i++)
	{
		epoch++;
		error = 0.0f;

		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_5_1);
		error += Brain.Learning_TwoLayerNetwork(DesiredOutputPattern1);

		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_5_2);
		error += Brain.Learning_TwoLayerNetwork(DesiredOutputPattern1);

		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_S_1);
		error += Brain.Learning_TwoLayerNetwork(DesiredOutputPattern2);

		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_S_2);
		error += Brain.Learning_TwoLayerNetwork(DesiredOutputPattern2);

		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_6_1);
		error += Brain.Learning_TwoLayerNetwork(DesiredOutputPattern3);

		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_6_2);
		error += Brain.Learning_TwoLayerNetwork(DesiredOutputPattern3);

		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_G_1);
		error += Brain.Learning_TwoLayerNetwork(DesiredOutputPattern4);

		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_G_2);
		error += Brain.Learning_TwoLayerNetwork(DesiredOutputPattern4);

		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_8_1);
		error += Brain.Learning_TwoLayerNetwork(DesiredOutputPattern5);

		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_8_2);
		error += Brain.Learning_TwoLayerNetwork(DesiredOutputPattern5);

		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_B_1);
		error += Brain.Learning_TwoLayerNetwork(DesiredOutputPattern6);

		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_B_2);
		error += Brain.Learning_TwoLayerNetwork(DesiredOutputPattern6);

		if (error < 0.0001f)
			break;

		Brain.RandomChange_OutputSynapsePlasticities2(seed++, -0.005f, 0.005f, 0.5f);
	}

	// training completed

	// training statistics:

	cout << "epoch: " << epoch << endl;
	cout << "error: " << error << endl << endl;



	cout << fixed;
	cout.precision(2);


	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_5_1);

	cout << "5 (1)" << " " << "desired output: 1 0 0 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_5_2);

	cout << "5 (2)" << " " << "desired output: 1 0 0 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;


	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_S_1);

	cout << "S (1)" << " " << "desired output: 0 1 0 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_S_2);

	cout << "S (2)" << " " << "desired output: 0 1 0 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_6_1);

	cout << "6 (1)" << " " << "desired output: 0 0 1 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_6_2);

	cout << "6 (2)" << " " << "desired output: 0 0 1 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_G_1);

	cout << "G (1)" << " " << "desired output: 0 0 0 1 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_G_2);

	cout << "G (2)" << " " << "desired output: 0 0 0 1 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_8_1);

	cout << "8 (1)" << " " << "desired output: 0 0 0 0 1 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_8_2);

	cout << "8 (2)" << " " << "desired output: 0 0 0 0 1 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_B_1);

	cout << "B (1)" << " " << "desired output: 0 0 0 0 0 1" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_B_2);

	cout << "B (2)" << " " << "desired output: 0 0 0 0 0 1" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	// test image(s):

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_5_3);

	//Normalize(OutputPattern, 6);

	cout << "unknown 5" << " " << "desired output: 1 0 0 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_S_3);

	//Normalize(OutputPattern, 6);

	cout << "unknown S" << " " << "desired output: 0 1 0 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_6_3);

	//Normalize(OutputPattern, 6);

	cout << "unknown 6" << " " << "desired output: 0 0 1 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_G_3);

	//Normalize(OutputPattern, 6);

	cout << "unknown G" << " " << "desired output: 0 0 0 1 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_8_3);

	//Normalize(OutputPattern, 6);

	cout << "unknown 8" << " " << "desired output: 0 0 0 0 1 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_B_3);

	//Normalize(OutputPattern, 6);

	cout << "unknown B" << " " << "desired output: 0 0 0 0 0 1" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;



	getchar();
	return 0;
}
*/


/*
int main(void)
{
	static float Image_5_1[8 * 8];
	static float Image_5_2[8 * 8];

	static float Image_S_1[8 * 8];
	static float Image_S_2[8 * 8];

	static float Image_6_1[8 * 8];
	static float Image_6_2[8 * 8];

	static float Image_G_1[8 * 8];
	static float Image_G_2[8 * 8];

	static float Image_8_1[8 * 8];
	static float Image_8_2[8 * 8];

	static float Image_B_1[8 * 8];
	static float Image_B_2[8 * 8];


	static float Image_5_1_L[32 * 32];
	static float Image_5_2_L[32 * 32];

	static float Image_S_1_L[32 * 32];
	static float Image_S_2_L[32 * 32];

	static float Image_6_1_L[32 * 32];
	static float Image_6_2_L[32 * 32];

	static float Image_G_1_L[32 * 32];
	static float Image_G_2_L[32 * 32];

	static float Image_8_1_L[32 * 32];
	static float Image_8_2_L[32 * 32];

	static float Image_B_1_L[32 * 32];
	static float Image_B_2_L[32 * 32];

	// test image(s):

	static float Image_5_3[8 * 8];
	static float Image_S_3[8 * 8];
	static float Image_6_3[8 * 8];
	static float Image_G_3[8 * 8];
	static float Image_8_3[8 * 8];
	static float Image_B_3[8 * 8];

	static float Image_5_3_L[32 * 32];
	static float Image_S_3_L[32 * 32];
	static float Image_6_3_L[32 * 32];
	static float Image_G_3_L[32 * 32];
	static float Image_8_3_L[32 * 32];
	static float Image_B_3_L[32 * 32];



	uint8_t *pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_5_1_L, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_5_2_L, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;


	pImageData = Read_Bitmap_BGR("Sample_S_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_S_1_L, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_S_2_L, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;


	pImageData = Read_Bitmap_BGR("Sample_6_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_6_1_L, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_6_2_L, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_G_1_L, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_G_2_L, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_1_L, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_2_L, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;


	pImageData = Read_Bitmap_BGR("Sample_B_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_1_L, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_2_L, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;


	// test image(s):

	pImageData = Read_Bitmap_BGR("Sample_5_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_5_3_L, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_S_3_L, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_6_3_L, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_G_3_L, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_3_L, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_3_L, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;


	static float tempImage[16 * 16];

#ifdef BisectResolution

	Bisect_Resolution(tempImage, Image_5_1_L, 32, 32);
	Bisect_Resolution(Image_5_1, tempImage, 16, 16);

	Bisect_Resolution(tempImage, Image_5_2_L, 32, 32);
	Bisect_Resolution(Image_5_2, tempImage, 16, 16);

	Bisect_Resolution(tempImage, Image_5_3_L, 32, 32);
	Bisect_Resolution(Image_5_3, tempImage, 16, 16);


	Bisect_Resolution(tempImage, Image_S_1_L, 32, 32);
	Bisect_Resolution(Image_S_1, tempImage, 16, 16);

	Bisect_Resolution(tempImage, Image_S_2_L, 32, 32);
	Bisect_Resolution(Image_S_2, tempImage, 16, 16);

	Bisect_Resolution(tempImage, Image_S_3_L, 32, 32);
	Bisect_Resolution(Image_S_3, tempImage, 16, 16);


	Bisect_Resolution(tempImage, Image_6_1_L, 32, 32);
	Bisect_Resolution(Image_6_1, tempImage, 16, 16);

	Bisect_Resolution(tempImage, Image_6_2_L, 32, 32);
	Bisect_Resolution(Image_6_2, tempImage, 16, 16);

	Bisect_Resolution(tempImage, Image_6_2_L, 32, 32);
	Bisect_Resolution(Image_6_2, tempImage, 16, 16);


	Bisect_Resolution(tempImage, Image_G_1_L, 32, 32);
	Bisect_Resolution(Image_G_1, tempImage, 16, 16);

	Bisect_Resolution(tempImage, Image_G_2_L, 32, 32);
	Bisect_Resolution(Image_G_2, tempImage, 16, 16);

	Bisect_Resolution(tempImage, Image_G_3_L, 32, 32);
	Bisect_Resolution(Image_G_3, tempImage, 16, 16);


	Bisect_Resolution(tempImage, Image_8_1_L, 32, 32);
	Bisect_Resolution(Image_8_1, tempImage, 16, 16);

	Bisect_Resolution(tempImage, Image_8_2_L, 32, 32);
	Bisect_Resolution(Image_8_2, tempImage, 16, 16);

	Bisect_Resolution(tempImage, Image_8_3_L, 32, 32);
	Bisect_Resolution(Image_8_3, tempImage, 16, 16);


	Bisect_Resolution(tempImage, Image_B_1_L, 32, 32);
	Bisect_Resolution(Image_B_1, tempImage, 16, 16);

	Bisect_Resolution(tempImage, Image_B_2_L, 32, 32);
	Bisect_Resolution(Image_B_2, tempImage, 16, 16);

	Bisect_Resolution(tempImage, Image_B_3_L, 32, 32);
	Bisect_Resolution(Image_B_3, tempImage, 16, 16);

#endif

#ifdef MaxPoolResolution

	MaxPooling2x2(tempImage, Image_5_1_L, 32, 32);
	MaxPooling2x2(Image_5_1, tempImage, 16, 16);

	MaxPooling2x2(tempImage, Image_5_2_L, 32, 32);
	MaxPooling2x2(Image_5_2, tempImage, 16, 16);

	MaxPooling2x2(tempImage, Image_5_3_L, 32, 32);
	MaxPooling2x2(Image_5_3, tempImage, 16, 16);


	MaxPooling2x2(tempImage, Image_S_1_L, 32, 32);
	MaxPooling2x2(Image_S_1, tempImage, 16, 16);

	MaxPooling2x2(tempImage, Image_S_2_L, 32, 32);
	MaxPooling2x2(Image_S_2, tempImage, 16, 16);

	MaxPooling2x2(tempImage, Image_S_3_L, 32, 32);
	MaxPooling2x2(Image_S_3, tempImage, 16, 16);


	MaxPooling2x2(tempImage, Image_6_1_L, 32, 32);
	MaxPooling2x2(Image_6_1, tempImage, 16, 16);

	MaxPooling2x2(tempImage, Image_6_2_L, 32, 32);
	MaxPooling2x2(Image_6_2, tempImage, 16, 16);

	MaxPooling2x2(tempImage, Image_6_2_L, 32, 32);
	MaxPooling2x2(Image_6_2, tempImage, 16, 16);


	MaxPooling2x2(tempImage, Image_G_1_L, 32, 32);
	MaxPooling2x2(Image_G_1, tempImage, 16, 16);

	MaxPooling2x2(tempImage, Image_G_2_L, 32, 32);
	MaxPooling2x2(Image_G_2, tempImage, 16, 16);

	MaxPooling2x2(tempImage, Image_G_3_L, 32, 32);
	MaxPooling2x2(Image_G_3, tempImage, 16, 16);


	MaxPooling2x2(tempImage, Image_8_1_L, 32, 32);
	MaxPooling2x2(Image_8_1, tempImage, 16, 16);

	MaxPooling2x2(tempImage, Image_8_2_L, 32, 32);
	MaxPooling2x2(Image_8_2, tempImage, 16, 16);

	MaxPooling2x2(tempImage, Image_8_3_L, 32, 32);
	MaxPooling2x2(Image_8_3, tempImage, 16, 16);


	MaxPooling2x2(tempImage, Image_B_1_L, 32, 32);
	MaxPooling2x2(Image_B_1, tempImage, 16, 16);

	MaxPooling2x2(tempImage, Image_B_2_L, 32, 32);
	MaxPooling2x2(Image_B_2, tempImage, 16, 16);

	MaxPooling2x2(tempImage, Image_B_3_L, 32, 32);
	MaxPooling2x2(Image_B_3, tempImage, 16, 16);

#endif

	CNeuralNet Brain;
	Brain.Init_NeuralNet(8 * 8 + 1 + 6);
	Brain.Init_TwoLayerNetwork(8 * 8, -0.2f, 0.2f, 0.2f, true, 6, SigmoidOutput);



	uint32_t maxCount = 4000;
	uint32_t epoch = 0;
	float error;

	uint32_t i;

	float OutputPattern[6];

	float DesiredOutputPattern1[6] = { 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f };
	float DesiredOutputPattern2[6] = { 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f };
	float DesiredOutputPattern3[6] = { 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f };
	float DesiredOutputPattern4[6] = { 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f };
	float DesiredOutputPattern5[6] = { 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f };
	float DesiredOutputPattern6[6] = { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f };


	// start training:


	uint64_t seed = 1;

	for (i = 0; i < maxCount; i++)
	{
		epoch++;
		error = 0.0f;

		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_5_1);
		error += Brain.Learning_TwoLayerNetwork(DesiredOutputPattern1);

		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_5_2);
		error += Brain.Learning_TwoLayerNetwork(DesiredOutputPattern1);

		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_S_1);
		error += Brain.Learning_TwoLayerNetwork(DesiredOutputPattern2);

		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_S_2);
		error += Brain.Learning_TwoLayerNetwork(DesiredOutputPattern2);

		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_6_1);
		error += Brain.Learning_TwoLayerNetwork(DesiredOutputPattern3);

		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_6_2);
		error += Brain.Learning_TwoLayerNetwork(DesiredOutputPattern3);

		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_G_1);
		error += Brain.Learning_TwoLayerNetwork(DesiredOutputPattern4);

		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_G_2);
		error += Brain.Learning_TwoLayerNetwork(DesiredOutputPattern4);

		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_8_1);
		error += Brain.Learning_TwoLayerNetwork(DesiredOutputPattern5);

		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_8_2);
		error += Brain.Learning_TwoLayerNetwork(DesiredOutputPattern5);

		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_B_1);
		error += Brain.Learning_TwoLayerNetwork(DesiredOutputPattern6);

		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_B_2);
		error += Brain.Learning_TwoLayerNetwork(DesiredOutputPattern6);

		if (error < 0.0001f)
			break;

		//Brain.RandomChange_OutputSynapsePlasticities2(seed++, -0.005f, 0.005f, 0.5f);
	}

	// training completed

	// training statistics:

	cout << "epoch: " << epoch << endl;
	cout << "error: " << error << endl << endl;



	cout << fixed;
	cout.precision(2);


	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_5_1);

	cout << "5 (1)" << " " << "desired output: 1 0 0 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_5_2);

	cout << "5 (2)" << " " << "desired output: 1 0 0 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;


	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_S_1);

	cout << "S (1)" << " " << "desired output: 0 1 0 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_S_2);

	cout << "S (2)" << " " << "desired output: 0 1 0 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_6_1);

	cout << "6 (1)" << " " << "desired output: 0 0 1 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_6_2);

	cout << "6 (2)" << " " << "desired output: 0 0 1 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_G_1);

	cout << "G (1)" << " " << "desired output: 0 0 0 1 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_G_2);

	cout << "G (2)" << " " << "desired output: 0 0 0 1 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_8_1);

	cout << "8 (1)" << " " << "desired output: 0 0 0 0 1 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_8_2);

	cout << "8 (2)" << " " << "desired output: 0 0 0 0 1 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_B_1);

	cout << "B (1)" << " " << "desired output: 0 0 0 0 0 1" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_B_2);

	cout << "B (2)" << " " << "desired output: 0 0 0 0 0 1" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	// test image(s):

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_5_3);

	//Normalize(OutputPattern, 6);

	cout << "unknown 5" << " " << "desired output: 1 0 0 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_S_3);

	//Normalize(OutputPattern, 6);

	cout << "unknown S" << " " << "desired output: 0 1 0 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_6_3);

	//Normalize(OutputPattern, 6);

	cout << "unknown 6" << " " << "desired output: 0 0 1 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_G_3);

	//Normalize(OutputPattern, 6);

	cout << "unknown G" << " " << "desired output: 0 0 0 1 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_8_3);

	//Normalize(OutputPattern, 6);

	cout << "unknown 8" << " " << "desired output: 0 0 0 0 1 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern, Image_B_3);

	//Normalize(OutputPattern, 6);

	cout << "unknown B" << " " << "desired output: 0 0 0 0 0 1" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;



	getchar();
	return 0;
}
*/






