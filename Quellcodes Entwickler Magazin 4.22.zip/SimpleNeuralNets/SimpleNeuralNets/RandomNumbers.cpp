#include "RandomNumbers.h"

//namespace HelperStuff
//{

//static constexpr int32_t ConstRandomNumbersTableSize = 10000;

int32_t g_iRandomNumbersTable[ConstRandomNumbersTableSize];
float g_fRandomNumbersTable[ConstRandomNumbersTableSize];

void Init_iRandomNumbersTable(CRandomNumbersNN *pRandomNumbers, int32_t minValue, int32_t maxValue)
{
	for (int32_t i = 0; i < ConstRandomNumbersTableSize; i++)
		g_iRandomNumbersTable[i] = pRandomNumbers->Get_IntegerNumber2(minValue, maxValue);
}

void Init_RandomNumbersTable(int32_t *pOutRandomNumbersArray, int32_t arraySize, CRandomNumbersNN *pRandomNumbers, int32_t minValue, int32_t maxValue)
{
	for (int32_t i = 0; i < arraySize; i++)
		pOutRandomNumbersArray[i] = pRandomNumbers->Get_IntegerNumber2(minValue, maxValue);
}

void Init_iRandomNumbersTableExt(CRandomNumbersNN *pRandomNumbers, int32_t minValue, int32_t maxValue, int32_t minAbsValue)
{
	int32_t tempInt;
	int32_t tempIntAbs;

	for (int32_t i = 0; i < ConstRandomNumbersTableSize; i++)
	{
		do
		{
			tempInt = pRandomNumbers->Get_IntegerNumber2(minValue, maxValue);
			tempIntAbs = abs(tempInt);
		} while (tempIntAbs < minAbsValue);


		g_iRandomNumbersTable[i] = tempInt;
	}
}

void Init_RandomNumbersTableExt(int32_t *pOutRandomNumbersArray, int32_t arraySize, CRandomNumbersNN *pRandomNumbers, int32_t minValue, int32_t maxValue, int32_t minAbsValue)
{
	int32_t tempInt;
	int32_t tempIntAbs;

	for (int32_t i = 0; i < arraySize; i++)
	{
		do
		{
			tempInt = pRandomNumbers->Get_IntegerNumber2(minValue, maxValue);
			tempIntAbs = abs(tempInt);
		} while (tempIntAbs < minAbsValue);


		pOutRandomNumbersArray[i] = tempInt;
	}
}

void Init_iRandomNumbersTableExt2(CRandomNumbersNN *pRandomNumbers, int32_t minValue, int32_t maxValue, int32_t maxAbsValue)
{
	int32_t tempInt;
	int32_t tempIntAbs;

	for (int32_t i = 0; i < ConstRandomNumbersTableSize; i++)
	{
		do
		{
			tempInt = pRandomNumbers->Get_IntegerNumber2(minValue, maxValue);
			tempIntAbs = abs(tempInt);
		} while (tempIntAbs > maxAbsValue);


		g_iRandomNumbersTable[i] = tempInt;
	}
}

void Init_RandomNumbersTableExt2(int32_t *pOutRandomNumbersArray, int32_t arraySize, CRandomNumbersNN *pRandomNumbers, int32_t minValue, int32_t maxValue, int32_t maxAbsValue)
{
	int32_t tempInt;
	int32_t tempIntAbs;

	for (int32_t i = 0; i < arraySize; i++)
	{
		do
		{
			tempInt = pRandomNumbers->Get_IntegerNumber2(minValue, maxValue);
			tempIntAbs = abs(tempInt);
		} while (tempIntAbs > maxAbsValue);


		pOutRandomNumbersArray[i] = tempInt;
	}
}

void Init_iRandomNumbersTableExt3(CRandomNumbersNN *pRandomNumbers, int32_t minValue, int32_t maxValue, int32_t minAbsValue, int32_t maxAbsValue)
{
	int32_t tempInt;
	int32_t tempIntAbs;

	for (int32_t i = 0; i < ConstRandomNumbersTableSize; i++)
	{
		do
		{
			tempInt = pRandomNumbers->Get_IntegerNumber2(minValue, maxValue);
			tempIntAbs = abs(tempInt);
		} while (tempIntAbs > maxAbsValue || tempIntAbs < minAbsValue);


		g_iRandomNumbersTable[i] = tempInt;
	}
}

void Init_RandomNumbersTableExt3(int32_t *pOutRandomNumbersArray, int32_t arraySize, CRandomNumbersNN *pRandomNumbers, int32_t minValue, int32_t maxValue, int32_t minAbsValue, int32_t maxAbsValue)
{
	int32_t tempInt;
	int32_t tempIntAbs;

	for (int32_t i = 0; i < arraySize; i++)
	{
		do
		{
			tempInt = pRandomNumbers->Get_IntegerNumber2(minValue, maxValue);
			tempIntAbs = abs(tempInt);
		} while (tempIntAbs > maxAbsValue || tempIntAbs < minAbsValue);


		pOutRandomNumbersArray[i] = tempInt;
	}
}

void Init_fRandomNumbersTable(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue)
{
	for (int32_t i = 0; i < ConstRandomNumbersTableSize; i++)
		g_fRandomNumbersTable[i] = pRandomNumbers->Get_FloatNumber(minValue, maxValue);
}

void Init_RandomNumbersTable(float *pOutRandomNumbersArray, int32_t arraySize, CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue)
{
	for (int32_t i = 0; i < arraySize; i++)
		pOutRandomNumbersArray[i] = pRandomNumbers->Get_FloatNumber(minValue, maxValue);
}

void Init_fRandomNumbersTableExt(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float minAbsValue)
{
	float tempFloat;
	float tempFloatAbs;

	for (int32_t i = 0; i < ConstRandomNumbersTableSize; i++)
	{
		do
		{
			tempFloat = pRandomNumbers->Get_FloatNumber(minValue, maxValue);
			tempFloatAbs = abs(tempFloat);
		} while (tempFloatAbs < minAbsValue);
		

		g_fRandomNumbersTable[i] = tempFloat;
	}
}

void Init_RandomNumbersTableExt(float *pOutRandomNumbersArray, int32_t arraySize, CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float minAbsValue)
{
	float tempFloat;
	float tempFloatAbs;

	for (int32_t i = 0; i < arraySize; i++)
	{
		do
		{
			tempFloat = pRandomNumbers->Get_FloatNumber(minValue, maxValue);
			tempFloatAbs = abs(tempFloat);
		} while (tempFloatAbs < minAbsValue);


		pOutRandomNumbersArray[i] = tempFloat;
	}
}

void Init_fRandomNumbersTableExt2(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float maxAbsValue)
{
	float tempFloat;
	float tempFloatAbs;

	for (int32_t i = 0; i < ConstRandomNumbersTableSize; i++)
	{
		do
		{
			tempFloat = pRandomNumbers->Get_FloatNumber(minValue, maxValue);
			tempFloatAbs = abs(tempFloat);
		} while (tempFloatAbs > maxAbsValue);


		g_fRandomNumbersTable[i] = tempFloat;
	}
}

void Init_RandomNumbersTableExt2(float *pOutRandomNumbersArray, int32_t arraySize, CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float maxAbsValue)
{
	float tempFloat;
	float tempFloatAbs;

	for (int32_t i = 0; i < arraySize; i++)
	{
		do
		{
			tempFloat = pRandomNumbers->Get_FloatNumber(minValue, maxValue);
			tempFloatAbs = abs(tempFloat);
		} while (tempFloatAbs > maxAbsValue);


		pOutRandomNumbersArray[i] = tempFloat;
	}
}

void Init_fRandomNumbersTableExt3(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float minAbsValue, float maxAbsValue)
{
	float tempFloat;
	float tempFloatAbs;

	for (int32_t i = 0; i < ConstRandomNumbersTableSize; i++)
	{
		do
		{
			tempFloat = pRandomNumbers->Get_FloatNumber(minValue, maxValue);
			tempFloatAbs = abs(tempFloat);
		} while (tempFloatAbs > maxAbsValue || tempFloatAbs < minAbsValue);


		g_fRandomNumbersTable[i] = tempFloat;
	}
}

void Init_RandomNumbersTableExt3(float *pOutRandomNumbersArray, int32_t arraySize, CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float minAbsValue, float maxAbsValue)
{
	float tempFloat;
	float tempFloatAbs;

	for (int32_t i = 0; i < arraySize; i++)
	{
		do
		{
			tempFloat = pRandomNumbers->Get_FloatNumber(minValue, maxValue);
			tempFloatAbs = abs(tempFloat);
		} while (tempFloatAbs > maxAbsValue || tempFloatAbs < minAbsValue);


		pOutRandomNumbersArray[i] = tempFloat;
	}
}

// Konstruktor:
CRandomNumbers_ParkMillerMLKG::
CRandomNumbers_ParkMillerMLKG() : newValue(1)
{}

// Destruktor:
CRandomNumbers_ParkMillerMLKG::
~CRandomNumbers_ParkMillerMLKG()
{}

/* Neuen Startwert f�r die Berechnung der
Zufallszahlen festlegen */
void CRandomNumbers_ParkMillerMLKG::Change_Seed(
	uint64_t newSeed)
{
	newValue = newSeed;
}

/* Startwert f�r die Berechnung der Zufallszahlen
auf 1 zur�cksetzen */
void CRandomNumbers_ParkMillerMLKG::Reset_Seed(void)
{
	newValue = 1;
}

// zuf�llige 32-Bit-Flie�kommazahlen:
float CRandomNumbers_ParkMillerMLKG::
Get_FloatNumber(float low, float high)
{
	newValue = (newValue*constParkMillerMultiplier) %
		constParkMillerModulus;

	return low + (high - low)*
		((double)newValue / fconstParkMillerModulus);
}

// zuf�llige 64-Bit-Flie�kommazahlen:
double CRandomNumbers_ParkMillerMLKG::
Get_DoubleNumber(double low, double high)
{
	newValue = (newValue*constParkMillerMultiplier) %
		constParkMillerModulus;

	return low + (high - low)*
		((double)newValue / fconstParkMillerModulus);
}

// zuf�llige 32-Bit-Ganzzahlen:
int32_t CRandomNumbers_ParkMillerMLKG::
Get_IntegerNumber(int32_t low,
	int32_t high_excluded)
{
	newValue = (newValue*constParkMillerMultiplier) %
		constParkMillerModulus;

	int32_t tempVal = low + (high_excluded - low)*
		((double)newValue / fconstParkMillerModulus);

	if (tempVal < high_excluded)
		return tempVal;
	else
		return low;
}

// zuf�llige positive 32-Bit-Ganzzahlen:
uint32_t CRandomNumbers_ParkMillerMLKG::
Get_UnsignedIntegerNumber(uint32_t low,
	uint32_t high_excluded)
{
	newValue = (newValue*constParkMillerMultiplier) %
		constParkMillerModulus;

	uint32_t tempVal = low + (high_excluded - low)*
		((double)newValue / fconstParkMillerModulus);

	if (tempVal < high_excluded)
		return tempVal;
	else
		return low;
}

// Konstruktor:
CRandomNumbersNN::
CRandomNumbersNN() : newValue(1)
{}

// Destruktor:
CRandomNumbersNN::
~CRandomNumbersNN()
{}

/* Neuen Startwert f�r die Berechnung der
Zufallszahlen festlegen */
void CRandomNumbersNN::Change_Seed(
	uint64_t newSeed)
{
	newValue = newSeed;
}

uint64_t CRandomNumbersNN::Get_Seed(void)
{
	return newValue;
}

/* Startwert f�r die Berechnung der Zufallszahlen
auf 1 zur�cksetzen */
void CRandomNumbersNN::Reset_Seed(void)
{
	newValue = 1;
}

void CRandomNumbersNN::Set_Precision(float value)
{
	precision = value;
	invPrecision = 1.0f / precision;
}

// zuf�llige 32-Bit-Flie�kommazahlen:
float CRandomNumbersNN::
Get_FloatNumber(float low, float high)
{
	newValue = (newValue*constParkMillerMultiplier) %
		constParkMillerModulus;

	float value = low + (high - low)*
		((double)newValue / fconstParkMillerModulus);

	if (value == 0.0f)
		value = 0.0001f;

	return value;
}

float CRandomNumbersNN::Get_FloatNumber(float low, float high, float zeroSubstitutionValue)
{
	newValue = (newValue*constParkMillerMultiplier) %
		constParkMillerModulus;

	float value = low + (high - low)*
		((double)newValue / fconstParkMillerModulus);

	if (value == 0.0f)
		value = zeroSubstitutionValue;

	return value;
}

float CRandomNumbersNN::
Get_RoundedFloatNumber(float low, float high)
{


	newValue = (newValue*constParkMillerMultiplier) %
		constParkMillerModulus;

	float value = low + (high - low)*
		((double)newValue / fconstParkMillerModulus);

	if (value == 0.0f)
		value = 0.0001f;

	int32_t iValue = static_cast<int32_t>(invPrecision * value);
	value = static_cast<float>(iValue);
	value *= precision;

	return value;
}


float CRandomNumbersNN::
Get_FloatNumber_IncludingZero(float low, float high)
{


	newValue = (newValue*constParkMillerMultiplier) %
		constParkMillerModulus;

	float value = low + (high - low)*
		((double)newValue / fconstParkMillerModulus);

	return value;
}

float CRandomNumbersNN::Get_RoundedFloatNumber_IncludingZero(float low, float high)
{
	newValue = (newValue*constParkMillerMultiplier) %
		constParkMillerModulus;

	float value = low + (high - low)*
		((double)newValue / fconstParkMillerModulus);

	int32_t iValue = static_cast<int32_t>(invPrecision * value);
	value = static_cast<float>(iValue);
	value *= precision;

	return value;
}




// zuf�llige 64-Bit-Flie�kommazahlen:
double CRandomNumbersNN::
Get_DoubleNumber(double low, double high)
{
	newValue = (newValue*constParkMillerMultiplier) %
		constParkMillerModulus;

	double value = low + (high - low)*
		((double)newValue / fconstParkMillerModulus);

	if (value == 0.0)
		value = 0.0001;

	return value;
}

double CRandomNumbersNN::Get_DoubleNumber(double low, double high, double zeroSubstitutionValue)
{
	newValue = (newValue*constParkMillerMultiplier) %
		constParkMillerModulus;

	double value = low + (high - low)*
		((double)newValue / fconstParkMillerModulus);

	if (value == 0.0)
		value = zeroSubstitutionValue;

	return value;
}

// zuf�llige 64-Bit-Flie�kommazahlen:
double CRandomNumbersNN::
Get_DoubleNumber_IncludingZero(double low, double high)
{


	newValue = (newValue*constParkMillerMultiplier) %
		constParkMillerModulus;

	double value = low + (high - low)*
		((double)newValue / fconstParkMillerModulus);

	return value;
}

// zuf�llige 32-Bit-Ganzzahlen:
int32_t CRandomNumbersNN::
Get_IntegerNumber(int32_t low,
	int32_t high_excluded)
{
	newValue = (newValue*constParkMillerMultiplier) %
		constParkMillerModulus;

	int32_t tempVal = low + (high_excluded - low)*
		((double)newValue / fconstParkMillerModulus);

	if (tempVal < high_excluded)
		return tempVal;
	else
		return low;
}

int32_t CRandomNumbersNN::Get_IntegerNumber2(int32_t low, int32_t high)
{
	if (high > 0)
		high++;

	if (low < 0)
		low--;

	newValue = (newValue*constParkMillerMultiplier) %
		constParkMillerModulus;

	int32_t tempVal = low + (high - low)*
		((double)newValue / fconstParkMillerModulus);

	return tempVal;
}

// zuf�llige positive 32-Bit-Ganzzahlen:
uint32_t CRandomNumbersNN::
Get_UnsignedIntegerNumber(uint32_t low,
	uint32_t high_excluded)
{
	newValue = (newValue*constParkMillerMultiplier) %
		constParkMillerModulus;

	uint32_t tempVal = low + (high_excluded - low)*
		((double)newValue / fconstParkMillerModulus);

	if (tempVal < high_excluded)
		return tempVal;
	else
		return low;
}

uint32_t CRandomNumbersNN::
Get_UnsignedIntegerNumber2(uint32_t low,
	uint32_t high)
{
	high++;

	newValue = (newValue*constParkMillerMultiplier) %
		constParkMillerModulus;

	uint32_t tempVal = low + (high - low)*
		((double)newValue / fconstParkMillerModulus);

	return tempVal;
}

//} /* end of namespace HelperStuff */


CPermutation::CPermutation()
{}

CPermutation::~CPermutation()
{}

void CPermutation::Calculate_Permutation(int32_t *pInputOutputVector, int32_t minVectorElement, int32_t maxVectorElement, int32_t permutationSteps)
{
	for (int32_t i = 0; i < permutationSteps; i++)
	{
		int32_t id1 = RandomNumbers.Get_IntegerNumber2(minVectorElement, maxVectorElement);
		int32_t id2 = RandomNumbers.Get_IntegerNumber2(minVectorElement, maxVectorElement);

		int32_t tempValue = pInputOutputVector[id1];
		pInputOutputVector[id1] = pInputOutputVector[id2];
		pInputOutputVector[id2] = tempValue;
	}
}

void CPermutation::Calculate_Permutation(float *pInputOutputVector, int32_t minVectorElement, int32_t maxVectorElement, int32_t permutationSteps)
{
	for (int32_t i = 0; i < permutationSteps; i++)
	{
		int32_t id1 = RandomNumbers.Get_IntegerNumber2(minVectorElement, maxVectorElement);
		int32_t id2 = RandomNumbers.Get_IntegerNumber2(minVectorElement, maxVectorElement);

		float tempValue = pInputOutputVector[id1];
		pInputOutputVector[id1] = pInputOutputVector[id2];
		pInputOutputVector[id2] = tempValue;
	}
}

void CPermutation::Combine_Vectors(float *pOutputVector, float *pInputVector1, float *pInputVector2, int32_t numVectorElements, /*numVectorElements*2:*/ float *pTempVector)
{
	int32_t numVectorElementsMinus1 = numVectorElements - 1;

	int32_t counter = 0;

	for (int32_t i = 0; i < numVectorElementsMinus1; i++)
	{
		pTempVector[counter] = pInputVector1[i];
		counter++;
	}

	for (int32_t i = 1; i < numVectorElements; i++)
	{
		pTempVector[counter] = pInputVector2[i];
		counter++;
	}


	counter--;

	for (int32_t i = 1; i < counter; i++)
	{
		if (RandomNumbers.Get_IntegerNumber(1, 3) == 1)
		{
			for (int32_t j = 1; j < numVectorElementsMinus1; j++)
			{
				if (pTempVector[j] == static_cast<float>(i))
				{
					pTempVector[j] = static_cast<float>(-i);
					break;
				}
			}
		}
		else
		{
			for (int32_t j = numVectorElementsMinus1; j <= counter; j++)
			{
				if (pTempVector[j] == static_cast<float>(i))
				{
					pTempVector[j] = static_cast<float>(-i);
					break;
				}
			}
		}
	}

	pOutputVector[0] = 0.0f;
	pOutputVector[numVectorElementsMinus1] = 0.0f;
	int32_t counter2 = 1;

	for (int32_t i = 1; i < counter; i++)
	{
		if (pTempVector[i] > 0.0f)
		{
			pOutputVector[counter2] = pTempVector[i];
			counter2++;
		}
	}
}

void CPermutation::Combine_Vectors(int32_t *pOutputVector, int32_t *pInputVector1, int32_t *pInputVector2, int32_t numVectorElements, /*numVectorElements*2:*/ int32_t *pTempVector)
{
	int32_t numVectorElementsMinus1 = numVectorElements - 1;

	int32_t counter = 0;

	for (int32_t i = 0; i < numVectorElementsMinus1; i++)
	{
		pTempVector[counter] = pInputVector1[i];
		counter++;
	}

	for (int32_t i = 1; i < numVectorElements; i++)
	{
		pTempVector[counter] = pInputVector2[i];
		counter++;
	}

	
	counter--;

	for (int32_t i = 1; i < counter; i++)
	{
		if (RandomNumbers.Get_IntegerNumber(1, 3) == 1)
		{
			for (int32_t j = 1; j < numVectorElementsMinus1; j++)
			{
				if (pTempVector[j] == i)
				{
					pTempVector[j] = -i;
					break;
				}
			}
		}
		else
		{
			for (int32_t j = numVectorElementsMinus1; j <= counter; j++)
			{
				if (pTempVector[j] == i)
				{
					pTempVector[j] = -i;
					break;
				}
			}
		}
	}

	pOutputVector[0] = 0;
	pOutputVector[numVectorElementsMinus1] = 0;
	int32_t counter2 = 1;

	for (int32_t i = 1; i < counter; i++)
	{
		if (pTempVector[i] > 0)
		{
			pOutputVector[counter2] = pTempVector[i];
			counter2++;
		}
	}
}

CCombinationPairs::CCombinationPairs()
{}

CCombinationPairs::~CCombinationPairs()
{
	delete[] pElement1_List;
	pElement1_List = nullptr;

	delete[] pElement2_List;
	pElement2_List = nullptr;
}

void CCombinationPairs::Set_NumOfElements(int32_t number)
{
	if (number < 2)
		number = 2;

	NumOfElements = number;
	NumOfCombinations = number * (number - 1) / 2;

	delete[] pElement1_List;
	pElement1_List = nullptr;

	delete[] pElement2_List;
	pElement2_List = nullptr;

	pElement1_List = new (std::nothrow) int32_t[NumOfCombinations];
	pElement2_List = new (std::nothrow) int32_t[NumOfCombinations];

	int32_t NumOfElementsMinus1 = NumOfElements - 1;

	int32_t counter = 0;

	for (int32_t i = 0; i < NumOfElementsMinus1; i++)
	{
		for (int32_t j = i + 1; j < NumOfElements; j++)
		{
			pElement1_List[counter] = i;
			pElement2_List[counter] = j;

			counter++;
		}
	}

	/*counter = 0;

	for (int32_t i = 0; i < NumOfCombinations; i++)
	{
		std::cout << pElement1_List[i] << " " << pElement2_List[i] << " | ";
		counter++;

		if (counter == 4)
		{
			std::cout << std::endl;
			counter = 0;
		}
	}*/
}