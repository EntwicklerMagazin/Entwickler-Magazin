#include "SimpleNeuron.h"


using namespace HelperStuff;


inline void ConvolutionalKernel(CSimpleNeuron *pNeuron)
{
	int32_t localReceptiveFieldSize = pNeuron->LocalReceptiveFieldSizeX * pNeuron->LocalReceptiveFieldSizeY;

	float output = 0.0f;

	for (int32_t i = 0; i < localReceptiveFieldSize; i++)
	{
		output += pNeuron->pDendrite_FactorArray[i] * pNeuron->pDendrite_DataArray[i];
	}

	// Bias:
	output += pNeuron->pDendrite_FactorArray[localReceptiveFieldSize];

	pNeuron->ActivationValue = output;
}

inline void ProcessingNeuralNet_DendriticFunction(CSimpleNeuron *pNeuron)
{
	float *pInputArray = pNeuron->pDendrite_DataArray;

	float *pPlasticityArray = pNeuron->pAdditionalMemoryValueArray;
	int32_t numOfAdditionalConnections = pNeuron->NumOfAdditionalMemoryValues;


	int32_t numOfOutputSynapses = pNeuron->NumOfOutputDendrites;
	int32_t numOfInputValues = pNeuron->NumOfInputDendrites;

	float *pOutputArray = &pNeuron->pDendrite_DataArray[pNeuron->FirstOutputDendriteID];

	// Bias:
	pInputArray[numOfInputValues - 1] = 1.0f;

	int32_t counter = pNeuron->RandomSeedValue;

	for (int32_t i = 0; i < numOfOutputSynapses; i++)
	{
		pOutputArray[i] = 0.0f;
	}

	for (int32_t j = 0; j < numOfInputValues; j++)
	{
		float inputValue = pInputArray[j];

		for (int32_t i = 0; i < numOfOutputSynapses; i++)
		{
			pOutputArray[i] += pPlasticityArray[counter] * inputValue;
			//Add_To_Log(0, "counter", counter);

			counter++;
			counter = counter % numOfAdditionalConnections;
		}
	}

	float tempValue;

	for (int32_t i = 0; i < numOfOutputSynapses; i++)
	{
		tempValue = pOutputArray[i];
		pOutputArray[i] = tempValue / (1.0f + abs(tempValue));
	}
}

inline void ProcessingNeuralNet_ActivationFunction(CSimpleNeuron *pNeuron)
{
	float output = 0.0f;

	int32_t numDendrites = pNeuron->NumOfDendriteElements;

	for (int32_t i = 0; i < numDendrites; i++)
	{
		output += pNeuron->pDendrite_FactorArray[i] * pNeuron->pDendrite_DataArray_OtherNeuron[i];
	}

	pNeuron->ActivationValue = output;
	//pNeuron->ActivationValue = output / (1.0f + abs(output));
}





void PrecedingNeuronLearning(CSimpleNeuron *pPrecedingNeuron, CSimpleNeuron *pSubsequentNeuron, float learningRate, float errorFactor1, float errorFactor2)
{
	int32_t numOfOutputDendrites = pPrecedingNeuron->NumOfOutputDendrites;
	int32_t numOfInputValues = pPrecedingNeuron->NumOfInputDendrites;

	float *pInputArray = &pPrecedingNeuron->pDendrite_DataArray[0];
	//float *pOutputArray = &pPrecedingNeuron->pDendrite_DataArray[numOfInputValues];
	float *pOutputArray = &pPrecedingNeuron->pDendrite_DataArray[pPrecedingNeuron->FirstOutputDendriteID];

	float *pPlasticityArray = pPrecedingNeuron->pAdditionalMemoryValueArray;
	int32_t numOfAdditionalConnections = pPrecedingNeuron->NumOfAdditionalMemoryValues;

	float *pOutputDendritesErrorValueArray = &pPrecedingNeuron->pDendrite_ErrorValueArray[pPrecedingNeuron->FirstOutputDendriteID];

	for (int32_t i = 0; i < numOfOutputDendrites; i++)
	{
		pOutputDendritesErrorValueArray[i] = pSubsequentNeuron->ErrorValue * pSubsequentNeuron->pDendrite_FactorArray[i] *
			errorFactor1 * exp(-(errorFactor2 * pOutputArray[i] * pOutputArray[i]));
	}

	int32_t counter = pPrecedingNeuron->RandomSeedValue;

	for (int32_t j = 0; j < numOfInputValues; j++)
	{
		for (int32_t i = 0; i < numOfOutputDendrites; i++)
		{
			pPlasticityArray[counter] += learningRate * pOutputDendritesErrorValueArray[i] * pInputArray[j];
			//Add_To_Log(0, "counter", counter);
			counter++;
			counter = counter % numOfAdditionalConnections;
		}
	}
}

void PrecedingNeuronErrorCalculations(CSimpleNeuron *pPrecedingNeuron, CSimpleNeuron *pSubsequentNeuron, float errorFactor1, float errorFactor2)
{
	int32_t numOfOutputDendrites = pPrecedingNeuron->NumOfOutputDendrites;
	int32_t numOfInputValues = pPrecedingNeuron->NumOfInputDendrites;

	float *pInputArray = &pPrecedingNeuron->pDendrite_DataArray[0];
	//float *pOutputArray = &pPrecedingNeuron->pDendrite_DataArray[numOfInputValues];
	float *pOutputArray = &pPrecedingNeuron->pDendrite_DataArray[pPrecedingNeuron->FirstOutputDendriteID];

	//float *pPlasticityArray = pPrecedingNeuron->pAdditionalMemoryValueArray;
	//int32_t numOfAdditionalConnections = pPrecedingNeuron->NumOfAdditionalMemoryValues;

	float *pOutputDendritesErrorValueArray = &pPrecedingNeuron->pDendrite_ErrorValueArray[pPrecedingNeuron->FirstOutputDendriteID];

	for (int32_t i = 0; i < numOfOutputDendrites; i++)
	{
		pOutputDendritesErrorValueArray[i] = pSubsequentNeuron->ErrorValue * pSubsequentNeuron->pDendrite_FactorArray[i] *
			errorFactor1 * exp(-(errorFactor2 * pOutputArray[i] * pOutputArray[i]));
	}
}

void Calculate_InputDendritesErrorValues(CSimpleNeuron *pNeuron, float errorFactor1, float errorFactor2)
{
	float *pInputArray = pNeuron->pDendrite_DataArray;

	float *pPlasticityArray = pNeuron->pAdditionalMemoryValueArray;
	int32_t numOfAdditionalConnections = pNeuron->NumOfAdditionalMemoryValues;


	int32_t numOfOutputSynapses = pNeuron->NumOfOutputDendrites;
	int32_t numOfInputValues = pNeuron->NumOfInputDendrites;

	//float *pInputDendrite_ErrorValueArray = &pNeuron->pDendrite_ErrorValueArray[0];
	float *pInputDendrite_ErrorValueArray = pNeuron->pDendrite_ErrorValueArray;
	float *pOutputDendrite_ErrorValueArray = &pNeuron->pDendrite_ErrorValueArray[pNeuron->FirstOutputDendriteID];

	
	int32_t counter = pNeuron->RandomSeedValue;

	for (int32_t j = 0; j < numOfInputValues; j++)
	{
		float errorSum = 0.0f;

		for (int32_t i = 0; i < numOfOutputSynapses; i++)
		{
			errorSum += pOutputDendrite_ErrorValueArray[i] * pPlasticityArray[counter];
		
			//Add_To_Log(0, "counter", counter);

			counter++;
			counter = counter % numOfAdditionalConnections;
		}

		float inputValue = pInputArray[j];
		pInputDendrite_ErrorValueArray[j] = errorSum * errorFactor1 * exp(-(errorFactor2 * inputValue * inputValue));
	}
}





void PrecedingNeuronLearning(CSimpleNeuron *pPrecedingNeuron, CSimpleNeuron *pSubsequentNeuronArray, int32_t numOfSubsequentNeurons, float learningRate, float errorFactor1, float errorFactor2)
{
	int32_t numOfOutputDendrites = pPrecedingNeuron->NumOfOutputDendrites;
	int32_t numOfInputValues = pPrecedingNeuron->NumOfInputDendrites;

	//float *pInputArray = &pPrecedingNeuron->pDendrite_DataArray[0];
	float *pInputArray = pPrecedingNeuron->pDendrite_DataArray;

	//float *pOutputArray = &pPrecedingNeuron->pDendrite_DataArray[numOfInputValues];
	float *pOutputArray = &pPrecedingNeuron->pDendrite_DataArray[pPrecedingNeuron->FirstOutputDendriteID];

	float *pPlasticityArray = pPrecedingNeuron->pAdditionalMemoryValueArray;
	int32_t numOfAdditionalConnections = pPrecedingNeuron->NumOfAdditionalMemoryValues;

	float *pOutputDendritesErrorValueArray = &pPrecedingNeuron->pDendrite_ErrorValueArray[pPrecedingNeuron->FirstOutputDendriteID];

	for (int32_t i = 0; i < numOfOutputDendrites; i++)
	{
		float errorSum = 0.0f;

		for (int32_t j = 0; j < numOfSubsequentNeurons; j++)
		{
			errorSum += pSubsequentNeuronArray[j].ErrorValue *
				pSubsequentNeuronArray[j].pDendrite_FactorArray[i];
		}

		pOutputDendritesErrorValueArray[i] = errorSum * errorFactor1 * exp(-(errorFactor2 * pOutputArray[i] * pOutputArray[i]));
	}

	int32_t counter = pPrecedingNeuron->RandomSeedValue;

	for (int32_t j = 0; j < numOfInputValues; j++)
	{
		for (int32_t i = 0; i < numOfOutputDendrites; i++)
		{
			pPlasticityArray[counter] += learningRate * pOutputDendritesErrorValueArray[i] * pInputArray[j];
			counter++;
			counter = counter % numOfAdditionalConnections;
		}
	}
}

void PrecedingNeuronLearning(CSimpleNeuron *pPrecedingNeuron, float learningRate)
{
	int32_t numOfOutputDendrites = pPrecedingNeuron->NumOfOutputDendrites;
	int32_t numOfInputValues = pPrecedingNeuron->NumOfInputDendrites;

	//float *pInputArray = &pPrecedingNeuron->pDendrite_DataArray[0];
	float *pInputArray = pPrecedingNeuron->pDendrite_DataArray;

	float *pPlasticityArray = pPrecedingNeuron->pAdditionalMemoryValueArray;
	int32_t numOfAdditionalConnections = pPrecedingNeuron->NumOfAdditionalMemoryValues;

	float *pOutputDendritesErrorValueArray = &pPrecedingNeuron->pDendrite_ErrorValueArray[pPrecedingNeuron->FirstOutputDendriteID];

	int32_t counter = pPrecedingNeuron->RandomSeedValue;

	for (int32_t j = 0; j < numOfInputValues; j++)
	{
		for (int32_t i = 0; i < numOfOutputDendrites; i++)
		{
			pPlasticityArray[counter] += learningRate * pOutputDendritesErrorValueArray[i] * pInputArray[j];
			counter++;
			counter = counter % numOfAdditionalConnections;
		}
	}
}

void PrecedingNeuronErrorCalculations(CSimpleNeuron *pPrecedingNeuron, CSimpleNeuron *pSubsequentNeuronArray, int32_t numOfSubsequentNeurons, float errorFactor1, float errorFactor2)
{
	int32_t numOfOutputDendrites = pPrecedingNeuron->NumOfOutputDendrites;
	int32_t numOfInputValues = pPrecedingNeuron->NumOfInputDendrites;

	float *pInputArray = &pPrecedingNeuron->pDendrite_DataArray[0];
	//float *pOutputArray = &pPrecedingNeuron->pDendrite_DataArray[numOfInputValues];
	float *pOutputArray = &pPrecedingNeuron->pDendrite_DataArray[pPrecedingNeuron->FirstOutputDendriteID];

	//float *pPlasticityArray = pPrecedingNeuron->pAdditionalMemoryValueArray;
	//int32_t numOfAdditionalConnections = pPrecedingNeuron->NumOfAdditionalMemoryValues;

	float *pOutputDendritesErrorValueArray = &pPrecedingNeuron->pDendrite_ErrorValueArray[pPrecedingNeuron->FirstOutputDendriteID];

	for (int32_t i = 0; i < numOfOutputDendrites; i++)
	{
		float errorSum = 0.0f;

		for (int32_t j = 0; j < numOfSubsequentNeurons; j++)
		{
			errorSum += pSubsequentNeuronArray[j].ErrorValue *
				pSubsequentNeuronArray[j].pDendrite_FactorArray[i];
		}

		pOutputDendritesErrorValueArray[i] = errorSum * errorFactor1 * exp(-(errorFactor2 * pOutputArray[i] * pOutputArray[i]));
	}

	
}

CSimpleNeuron::CSimpleNeuron()
{
	for (int32_t i = 0; i < ConstNumOfPrecedingSimpleNeuronsMax; i++)
	{
		pPrecedingNeuronArray[i] = nullptr;
		pDendrite_DataArray_OtherNeurons[i] = nullptr;
		pDendrite_CentroidValueArray_OtherNeurons[i] = nullptr;
		pDendrite_FactorArray_OtherNeurons[i] = nullptr;
	}
}

CSimpleNeuron::~CSimpleNeuron()
{
	delete[] pAdditionalMemoryValueArray;
	pAdditionalMemoryValueArray = nullptr;

	delete[] pDendrite_DataArray;
	pDendrite_DataArray = nullptr;

	delete[] pDendrite_CentroidValueArray;
	pDendrite_CentroidValueArray = nullptr;

	delete[] pDendrite_FactorArray;
	pDendrite_FactorArray = nullptr;

	delete[] pDendrite_ErrorValueArray;
	pDendrite_ErrorValueArray = nullptr;

	delete[] pReceiverNeuronIDArray;
	pReceiverNeuronIDArray = nullptr;

	delete[] pOutputSynapsePlasticityArray;
	pOutputSynapsePlasticityArray = nullptr;
}

void CSimpleNeuron::Init_OutputSynapses(int32_t numOfOutputSynapses)
{
	if (numOfOutputSynapses > NumOfOutputSynapses)
	{
		delete[] pReceiverNeuronIDArray;
		pReceiverNeuronIDArray = nullptr;

		delete[] pOutputSynapsePlasticityArray;
		pOutputSynapsePlasticityArray = nullptr;

		pReceiverNeuronIDArray = new (std::nothrow) int32_t[numOfOutputSynapses];
		pOutputSynapsePlasticityArray = new (std::nothrow) float[numOfOutputSynapses];
	}

	NumOfOutputSynapses = numOfOutputSynapses;

	for (int32_t i = 0; i < numOfOutputSynapses; i++)
	{
		pReceiverNeuronIDArray[i] = 0;
		pOutputSynapsePlasticityArray[i] = 1.0f;
	}
}

void CSimpleNeuron::Init_OutputSynapses(int32_t numOfOutputSynapses, int32_t *pInReceiverNeuronIDArray, float *pInSynapsePlasticityArray)
{
	if (numOfOutputSynapses > NumOfOutputSynapses)
	{
		delete[] pReceiverNeuronIDArray;
		pReceiverNeuronIDArray = nullptr;

		delete[] pOutputSynapsePlasticityArray;
		pOutputSynapsePlasticityArray = nullptr;

		pReceiverNeuronIDArray = new (std::nothrow) int32_t[numOfOutputSynapses];
		pOutputSynapsePlasticityArray = new (std::nothrow) float[numOfOutputSynapses];
	}

	NumOfOutputSynapses = numOfOutputSynapses;

	for (int32_t i = 0; i < numOfOutputSynapses; i++)
	{
		pReceiverNeuronIDArray[i] = pInReceiverNeuronIDArray[i];
		pOutputSynapsePlasticityArray[i] = pInSynapsePlasticityArray[i];
	}
}



void CSimpleNeuron::Use_OtherNeuron_Dendrite_DataArray(float *pArray)
{
	pDendrite_DataArray_OtherNeuron = pArray;
}

void CSimpleNeuron::Use_OtherNeuron_Dendrite_DataArray(int32_t connectionID, float *pArray)
{
	pDendrite_DataArray_OtherNeurons[connectionID] = pArray;
}

void CSimpleNeuron::Use_OtherNeuron_Dendrite_DataArray(float *pArray, int32_t idFirstSourceDendrite)
{
	pDendrite_DataArray_OtherNeuron = &pArray[idFirstSourceDendrite];
}

void CSimpleNeuron::Use_OtherNeuron_Dendrite_DataArray(int32_t connectionID, float *pArray, int32_t idFirstSourceDendrite)
{
	pDendrite_DataArray_OtherNeurons[connectionID] = &pArray[idFirstSourceDendrite];
}



void CSimpleNeuron::Use_OtherNeuron_Dendrite_CentroidValueArray(float *pArray)
{
	pDendrite_CentroidValueArray_OtherNeuron = pArray;
}

void CSimpleNeuron::Use_OtherNeuron_Dendrite_CentroidValueArray(int32_t connectionID, float *pArray)
{
	pDendrite_CentroidValueArray_OtherNeurons[connectionID] = pArray;
}

void CSimpleNeuron::Use_OtherNeuron_Dendrite_CentroidValueArray(float *pArray, int32_t idFirstSourceDendrite)
{
	pDendrite_CentroidValueArray_OtherNeuron = &(pArray[idFirstSourceDendrite]);
}

void CSimpleNeuron::Use_OtherNeuron_Dendrite_CentroidValueArray(int32_t connectionID, float *pArray, int32_t idFirstSourceDendrite)
{
	pDendrite_CentroidValueArray_OtherNeurons[connectionID] = &(pArray[idFirstSourceDendrite]);
}


void CSimpleNeuron::Use_OtherNeuron_Dendrite_FactorArray(float *pArray)
{
	pDendrite_FactorArray_OtherNeuron = pArray;
}

void CSimpleNeuron::Use_OtherNeuron_Dendrite_FactorArray(int32_t connectionID, float *pArray)
{
	pDendrite_FactorArray_OtherNeurons[connectionID] = pArray;
}

void CSimpleNeuron::Use_OtherNeuron_Dendrite_FactorArray(float *pArray, int32_t idFirstSourceDendrite)
{
	pDendrite_FactorArray_OtherNeuron = &(pArray[idFirstSourceDendrite]);
}

void CSimpleNeuron::Use_OtherNeuron_Dendrite_FactorArray(int32_t connectionID, float *pArray, int32_t idFirstSourceDendrite)
{
	pDendrite_FactorArray_OtherNeurons[connectionID] = &(pArray[idFirstSourceDendrite]);
}





void CSimpleNeuron::Set_ActivationFunction(pActivationFunction pFunc)
{
	pActivationFunc = pFunc;
}

void CSimpleNeuron::Set_DendriticFunction(pDendriticFunction pFunc)
{
	pDendriticFunc = pFunc;
}

void CSimpleNeuron::Mutate(pMutationFunction pFunc, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	pFunc(this, pRandomNumbers, pParam);
}

void CSimpleNeuron::Reinitialize(pReinitializationFunction pFunc, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	pFunc(this, pRandomNumbers, pParam);
}

void CSimpleNeuron::Permute(pPermutationFunction pFunc, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	pFunc(this, pRandomNumbers, pParam);
}

void CSimpleNeuron::Recombination(pRecombinationFunction pFunc, CSimpleNeuron *pParent1, CSimpleNeuron *pParent2, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	pFunc(this, pParent1, pParent2, pRandomNumbers, pParam);
}


void CSimpleNeuron::Clone_Values(CSimpleNeuron *pOriginalObject)
{
	ErrorFactor1 = pOriginalObject->ErrorFactor1;
	ErrorFactor2 = pOriginalObject->ErrorFactor2;
	LearningRate = pOriginalObject->LearningRate;
	NumOfDendriteElements = pOriginalObject->NumOfDendriteElements;
	MaxDendriteID = pOriginalObject->MaxDendriteID;
	NumOfTrainingExamples = pOriginalObject->NumOfTrainingExamples;
	pActivationFunc = pOriginalObject->pActivationFunc;
	pDendriticFunc = pOriginalObject->pDendriticFunc;
	RandomSeedValue = pOriginalObject->RandomSeedValue;

	LocalReceptiveFieldSizeX = pOriginalObject->LocalReceptiveFieldSizeX;
	LocalReceptiveFieldSizeY = pOriginalObject->LocalReceptiveFieldSizeY;

	FirstInputDendriteID = pOriginalObject->FirstInputDendriteID;
	NumOfInputDendrites = pOriginalObject->NumOfInputDendrites;
	NumOfInputDendritesXDir = pOriginalObject->NumOfInputDendritesXDir;
	NumOfInputDendritesYDir = pOriginalObject->NumOfInputDendritesYDir;

	FirstOutputDendriteID = pOriginalObject->FirstOutputDendriteID;
	NumOfOutputDendrites = pOriginalObject->NumOfOutputDendrites;
	NumOfOutputDendritesXDir = pOriginalObject->NumOfOutputDendritesXDir;
	NumOfOutputDendritesYDir = pOriginalObject->NumOfOutputDendritesYDir;

	UsedDendritesMinID = pOriginalObject->UsedDendritesMinID;
	UsedDendritesMaxIDPlus1 = pOriginalObject->UsedDendritesMaxIDPlus1;

	NumOfAdditionalMemoryValues = pOriginalObject->NumOfAdditionalMemoryValues;

	NumOfOutputSynapses == pOriginalObject->NumOfOutputSynapses;

	for (int32_t i = 0; i < NumOfAdditionalMemoryValues; i++)
	{
		pAdditionalMemoryValueArray[i] = pOriginalObject->pAdditionalMemoryValueArray[i];
	}
	
	
	for (int32_t i = 0; i < NumOfDendriteElements; i++)
	{
		pDendrite_CentroidValueArray[i] = pOriginalObject->pDendrite_CentroidValueArray[i];
		pDendrite_FactorArray[i] = pOriginalObject->pDendrite_FactorArray[i];
		pDendrite_ErrorValueArray[i] = pOriginalObject->pDendrite_ErrorValueArray[i];
	}	

	for (int32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		pReceiverNeuronIDArray[i] = pOriginalObject->pReceiverNeuronIDArray[i];
		pOutputSynapsePlasticityArray[i] = pOriginalObject->pOutputSynapsePlasticityArray[i];
	}	
}

void CSimpleNeuron::Reset_NumOfUsedPrecedingNeurons(void)
{
	NumOfUsedPrecedingNeurons = 0;
}

void CSimpleNeuron::Add_PrecedingNeuron(CSimpleNeuron *pNeuron)
{
	if (NumOfUsedPrecedingNeurons >= ConstNumOfPrecedingSimpleNeuronsMax)
	{
		return;
	}

	pPrecedingNeuronArray[NumOfUsedPrecedingNeurons] = pNeuron;
	NumOfUsedPrecedingNeurons++;
}

void CSimpleNeuron::Use_PrecedingNeuronActivationValues_As_InputValues(void)
{
	Dendrite_InputCounter = NumOfUsedPrecedingNeurons;
	UsedDendritesMinID = 0;
	UsedDendritesMaxIDPlus1 = UsedDendritesMinID + NumOfUsedPrecedingNeurons;

	for (int32_t i = 0; i < NumOfUsedPrecedingNeurons; i++)
	{
		pDendrite_DataArray[i] = pPrecedingNeuronArray[i]->ActivationValue;
	}
}


void CSimpleNeuron::Set_NeuronID(int32_t id)
{
	NeuronID = id;
}

void CSimpleNeuron::Set_InputDendriteInfo(int32_t firstInputDendriteID, int32_t numOfInputDendrites)
{
	FirstInputDendriteID = firstInputDendriteID;
	NumOfInputDendrites = numOfInputDendrites;
}

void CSimpleNeuron::Set_InputDendriteInfo(int32_t firstInputDendriteID, int32_t numOfInputDendritesXDir, int32_t numOfInputDendritesYDir)
{
	FirstInputDendriteID = firstInputDendriteID;
	NumOfInputDendritesXDir = numOfInputDendritesXDir;
	NumOfInputDendritesYDir = numOfInputDendritesYDir;
	NumOfInputDendrites = numOfInputDendritesXDir * numOfInputDendritesYDir;
}

void CSimpleNeuron::Set_OutputDendriteInfo(int32_t firstOutputDendriteID, int32_t numOfOutputDendrites)
{
	FirstOutputDendriteID = firstOutputDendriteID;
	NumOfOutputDendrites = numOfOutputDendrites;
}

void CSimpleNeuron::Set_OutputDendriteInfo(int32_t firstOutputDendriteID, int32_t numOfOutputDendritesXDir, int32_t numOfOutputDendritesYDir)
{
	FirstOutputDendriteID = firstOutputDendriteID;
	NumOfOutputDendritesXDir = numOfOutputDendritesXDir;
	NumOfOutputDendritesYDir = numOfOutputDendritesYDir;
	NumOfOutputDendrites = numOfOutputDendritesXDir * numOfOutputDendritesYDir;
}

void CSimpleNeuron::Set_LocalReceptiveFieldSizeInfo(int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY)
{
	LocalReceptiveFieldSizeX = localReceptiveFieldSizeX;
	LocalReceptiveFieldSizeY = localReceptiveFieldSizeY;
}

void CSimpleNeuron::Connect_With_Brain(CSimpleNeuron *pNeuronArray)
{
	pUsedNeuronArray = pNeuronArray;
}

bool CSimpleNeuron::Compare_DataWithMemory(float *pDataArray)
{
	/*if (pAdditionalMemoryValueArray == nullptr)
	{
		return false;
	}*/

	for (int32_t i = 0; i < NumOfAdditionalMemoryValues; i++)
	{
		if (pAdditionalMemoryValueArray[i] != pDataArray[i])
		{
			return false;
		}
	}

	return true;
}

void CSimpleNeuron::Set_AdditionalMemoryValues(float *pMemoryValueArray)
{
	/*if (pAdditionalMemoryValueArray == nullptr)
	{
		return;
	}*/

	for (int32_t i = 0; i < NumOfAdditionalMemoryValues; i++)
	{
		pAdditionalMemoryValueArray[i] = pMemoryValueArray[i];
	}
}
void CSimpleNeuron::Init_AdditionalMemoryValues(int32_t numOfAdditionalMemoryValues)
{
	if (numOfAdditionalMemoryValues > NumOfAdditionalMemoryValues)
	{
		delete[] pAdditionalMemoryValueArray;
		pAdditionalMemoryValueArray = nullptr;

		pAdditionalMemoryValueArray = new (std::nothrow) float[numOfAdditionalMemoryValues];
	}

	NumOfAdditionalMemoryValues = numOfAdditionalMemoryValues;

	for (int32_t i = 0; i < numOfAdditionalMemoryValues; i++)
	{
		pAdditionalMemoryValueArray[i] = -1000000000.0f;
	}
}

void CSimpleNeuron::Init_AdditionalMemoryValues(float *pMemoryValueArray, int32_t numOfAdditionalMemoryValues)
{
	if (numOfAdditionalMemoryValues > NumOfAdditionalMemoryValues)
	{
		delete[] pAdditionalMemoryValueArray;
		pAdditionalMemoryValueArray = nullptr;

		pAdditionalMemoryValueArray = new (std::nothrow) float[numOfAdditionalMemoryValues];
	}

	if (pMemoryValueArray != nullptr)
	{
		for (int32_t i = 0; i < numOfAdditionalMemoryValues; i++)
		{
			pAdditionalMemoryValueArray[i] = pMemoryValueArray[i];
		}
	}
	else
	{
		for (int32_t i = 0; i < numOfAdditionalMemoryValues; i++)
		{
			pAdditionalMemoryValueArray[i] = -1000000000.0f;
		}
	}

	NumOfAdditionalMemoryValues = numOfAdditionalMemoryValues;
}

void CSimpleNeuron::Clone(CSimpleNeuron *pOriginalObject)
{
	ErrorFactor1 = pOriginalObject->ErrorFactor1;
	ErrorFactor2 = pOriginalObject->ErrorFactor2;
	LearningRate = pOriginalObject->LearningRate;
	NumOfDendriteElements = pOriginalObject->NumOfDendriteElements;
	MaxDendriteID = pOriginalObject->MaxDendriteID;
	NumOfTrainingExamples = pOriginalObject->NumOfTrainingExamples;
	pActivationFunc = pOriginalObject->pActivationFunc;
	pDendriticFunc = pOriginalObject->pDendriticFunc;
	RandomSeedValue = pOriginalObject->RandomSeedValue;

	LocalReceptiveFieldSizeX = pOriginalObject->LocalReceptiveFieldSizeX;
	LocalReceptiveFieldSizeY = pOriginalObject->LocalReceptiveFieldSizeY;

	FirstInputDendriteID = pOriginalObject->FirstInputDendriteID;
	NumOfInputDendrites = pOriginalObject->NumOfInputDendrites;
	NumOfInputDendritesXDir = pOriginalObject->NumOfInputDendritesXDir;
	NumOfInputDendritesYDir = pOriginalObject->NumOfInputDendritesYDir;

	FirstOutputDendriteID = pOriginalObject->FirstOutputDendriteID;
	NumOfOutputDendrites = pOriginalObject->NumOfOutputDendrites;
	NumOfOutputDendritesXDir = pOriginalObject->NumOfOutputDendritesXDir;
	NumOfOutputDendritesYDir = pOriginalObject->NumOfOutputDendritesYDir;

	UsedDendritesMinID = pOriginalObject->UsedDendritesMinID;
	UsedDendritesMaxIDPlus1 = pOriginalObject->UsedDendritesMaxIDPlus1;

	NumOfAdditionalMemoryValues = pOriginalObject->NumOfAdditionalMemoryValues;

	NumOfOutputSynapses = pOriginalObject->NumOfOutputSynapses;

	if (pOriginalObject->NumOfAdditionalMemoryValues > 0)
	{
		delete[] pAdditionalMemoryValueArray;
		pAdditionalMemoryValueArray = nullptr;

		pAdditionalMemoryValueArray = new (std::nothrow) float[NumOfAdditionalMemoryValues];

		for (int32_t i = 0; i < NumOfAdditionalMemoryValues; i++)
		{
			pAdditionalMemoryValueArray[i] = pOriginalObject->pAdditionalMemoryValueArray[i];
		}
	}

	if (pOriginalObject->NumOfDendriteElements > 0)
	{
		delete[] pDendrite_DataArray;
		pDendrite_DataArray = nullptr;

		delete[] pDendrite_CentroidValueArray;
		pDendrite_CentroidValueArray = nullptr;

		delete[] pDendrite_FactorArray;
		pDendrite_FactorArray = nullptr;

		delete[] pDendrite_ErrorValueArray;
		pDendrite_ErrorValueArray = nullptr;

		pDendrite_DataArray = new (std::nothrow) float[NumOfDendriteElements];
		pDendrite_CentroidValueArray = new (std::nothrow) float[NumOfDendriteElements];
		pDendrite_FactorArray = new (std::nothrow) float[NumOfDendriteElements];
		pDendrite_ErrorValueArray = new (std::nothrow) float[NumOfDendriteElements];

		for (int32_t i = 0; i < NumOfDendriteElements; i++)
		{
			pDendrite_CentroidValueArray[i] = pOriginalObject->pDendrite_CentroidValueArray[i];
			pDendrite_FactorArray[i] = pOriginalObject->pDendrite_FactorArray[i];
			pDendrite_ErrorValueArray[i] = pOriginalObject->pDendrite_ErrorValueArray[i];
		}
	}

	if (pOriginalObject->NumOfOutputSynapses > 0)
	{
		delete[] pReceiverNeuronIDArray;
		pReceiverNeuronIDArray = nullptr;

		delete[] pOutputSynapsePlasticityArray;
		pOutputSynapsePlasticityArray = nullptr;

		pReceiverNeuronIDArray = new (std::nothrow) int32_t[NumOfOutputSynapses];
		pOutputSynapsePlasticityArray = new (std::nothrow) float[NumOfOutputSynapses];

		for (int32_t i = 0; i < NumOfOutputSynapses; i++)
		{
			pReceiverNeuronIDArray[i] = pOriginalObject->pReceiverNeuronIDArray[i];
			pOutputSynapsePlasticityArray[i] = pOriginalObject->pOutputSynapsePlasticityArray[i];
		}
	}
}

void CSimpleNeuron::Set_Dendrite_Data(float *pCentroidValueArray, float *pFactorArray)
{
	for (int32_t i = 0; i < NumOfDendriteElements; i++)
	{
		pDendrite_CentroidValueArray[i] = pCentroidValueArray[i];
		pDendrite_FactorArray[i] = pFactorArray[i];
	}
}

void CSimpleNeuron::Set_Dendrite_CentroidValues(float *pCentroidValueArray)
{
	for (int32_t i = 0; i < NumOfDendriteElements; i++)
	{
		pDendrite_CentroidValueArray[i] = pCentroidValueArray[i];
	}
}

void CSimpleNeuron::Set_Dendrite_Factors(float *pFactorArray)
{
	for (int32_t i = 0; i < NumOfDendriteElements; i++)
	{
		pDendrite_FactorArray[i] = pFactorArray[i];
	}
}

void CSimpleNeuron::Init_Dendrite_Arrays(int32_t numOfDendriteElements)
{
	if (NumOfDendriteElements < numOfDendriteElements)
	{
		delete[] pDendrite_DataArray;
		pDendrite_DataArray = nullptr;

		delete[] pDendrite_CentroidValueArray;
		pDendrite_CentroidValueArray = nullptr;

		delete[] pDendrite_FactorArray;
		pDendrite_FactorArray = nullptr;

		delete[] pDendrite_ErrorValueArray;
		pDendrite_ErrorValueArray = nullptr;

		pDendrite_DataArray = new (std::nothrow) float[numOfDendriteElements];
		pDendrite_CentroidValueArray = new (std::nothrow) float[numOfDendriteElements];
		pDendrite_FactorArray = new (std::nothrow) float[numOfDendriteElements];
		pDendrite_ErrorValueArray = new (std::nothrow) float[numOfDendriteElements];
	}

	NumOfDendriteElements = numOfDendriteElements;

	for (int32_t i = 0; i < numOfDendriteElements; i++)
	{
		pDendrite_DataArray[i] = 0.0f;
		pDendrite_CentroidValueArray[i] = 0.0f;
		pDendrite_FactorArray[i] = 1.0f;
		pDendrite_ErrorValueArray[i] = 0;
	}

	MaxDendriteID = NumOfDendriteElements - 1;
}


bool CSimpleNeuron::Load_OutputSynapsesData(const char* pFilename, bool memoryAllocation)
{
	std::ifstream ReadFile;

	// eine existierende Datei zum Lesen �ffnen:
	ReadFile.open(pFilename);

	if (ReadFile.good() == false)
		return false;

	int32_t numOfOutputSynapses;

	ReadFile >> numOfOutputSynapses;

	if (memoryAllocation == true)
	{
		if (numOfOutputSynapses > NumOfOutputSynapses)
		{
			delete[] pReceiverNeuronIDArray;
			pReceiverNeuronIDArray = nullptr;

			delete[] pOutputSynapsePlasticityArray;
			pOutputSynapsePlasticityArray = nullptr;

			pReceiverNeuronIDArray = new (std::nothrow) int32_t[numOfOutputSynapses];
			pOutputSynapsePlasticityArray = new (std::nothrow) float[numOfOutputSynapses];
		}
	}

	NumOfOutputSynapses = numOfOutputSynapses;

	for (int32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		ReadFile >> pReceiverNeuronIDArray[i];
		ReadFile >> pOutputSynapsePlasticityArray[i];
	}

	ReadFile.close();

	return true;
}

bool CSimpleNeuron::Load_Dendrite_Values(const char* pFilename, bool memoryAllocation)
{
	std::ifstream ReadFile;

	// eine existierende Datei zum Lesen �ffnen:
	ReadFile.open(pFilename);

	if (ReadFile.good() == false)
		return false;


	ReadFile >> RandomSeedValue;
	ReadFile >> NumOfTrainingExamples;
	
	int32_t numOfDendriteElements;

	ReadFile >> numOfDendriteElements;

	if (memoryAllocation == true)
	{
		if (numOfDendriteElements > NumOfDendriteElements)
		{
			delete[] pDendrite_DataArray;
			pDendrite_DataArray = nullptr;

			delete[] pDendrite_CentroidValueArray;
			pDendrite_CentroidValueArray = nullptr;

			delete[] pDendrite_FactorArray;
			pDendrite_FactorArray = nullptr;

			delete[] pDendrite_ErrorValueArray;
			pDendrite_ErrorValueArray = nullptr;

			pDendrite_DataArray = new (std::nothrow) float[numOfDendriteElements];
			pDendrite_CentroidValueArray = new (std::nothrow) float[numOfDendriteElements];
			pDendrite_FactorArray = new (std::nothrow) float[numOfDendriteElements];
			pDendrite_ErrorValueArray = new (std::nothrow) float[numOfDendriteElements];
		}
	}

	NumOfDendriteElements = numOfDendriteElements;

	for (int32_t i = 0; i < NumOfDendriteElements; i++)
	{
		ReadFile >> pDendrite_FactorArray[i];
		ReadFile >> pDendrite_CentroidValueArray[i];
	}

	ReadFile.close();

	return true;
}

bool CSimpleNeuron::Load_Dendrite_Centroids(const char* pFilename, bool memoryAllocation)
{
	std::ifstream ReadFile;

	// eine existierende Datei zum Lesen �ffnen:
	ReadFile.open(pFilename);

	if (ReadFile.good() == false)
		return false;

	ReadFile >> RandomSeedValue;

	int32_t numOfDendriteElements;

	ReadFile >> numOfDendriteElements;

	if (memoryAllocation == true)
	{
		if (numOfDendriteElements > NumOfDendriteElements)
		{
			delete[] pDendrite_DataArray;
			pDendrite_DataArray = nullptr;

			delete[] pDendrite_CentroidValueArray;
			pDendrite_CentroidValueArray = nullptr;

			delete[] pDendrite_FactorArray;
			pDendrite_FactorArray = nullptr;

			delete[] pDendrite_ErrorValueArray;
			pDendrite_ErrorValueArray = nullptr;

			pDendrite_DataArray = new (std::nothrow) float[numOfDendriteElements];
			pDendrite_CentroidValueArray = new (std::nothrow) float[numOfDendriteElements];
			pDendrite_FactorArray = new (std::nothrow) float[numOfDendriteElements];
			pDendrite_ErrorValueArray = new (std::nothrow) float[numOfDendriteElements];
		}
	}

	NumOfDendriteElements = numOfDendriteElements;

	for (int32_t i = 0; i < NumOfDendriteElements; i++)
	{
		//ReadFile >> pDendrite_FactorArray[i];
		ReadFile >> pDendrite_CentroidValueArray[i];
	}

	ReadFile.close();

	return true;
}

bool CSimpleNeuron::Load_Dendrite_Factors(const char* pFilename, bool memoryAllocation)
{
	std::ifstream ReadFile;

	// eine existierende Datei zum Lesen �ffnen:
	ReadFile.open(pFilename);

	if (ReadFile.good() == false)
		return false;

	ReadFile >> RandomSeedValue;

	int32_t numOfDendriteElements;

	ReadFile >> numOfDendriteElements;

	if (memoryAllocation == true)
	{
		if (numOfDendriteElements > NumOfDendriteElements)
		{
			delete[] pDendrite_DataArray;
			pDendrite_DataArray = nullptr;

			delete[] pDendrite_CentroidValueArray;
			pDendrite_CentroidValueArray = nullptr;

			delete[] pDendrite_FactorArray;
			pDendrite_FactorArray = nullptr;

			delete[] pDendrite_ErrorValueArray;
			pDendrite_ErrorValueArray = nullptr;

			pDendrite_DataArray = new (std::nothrow) float[numOfDendriteElements];
			pDendrite_CentroidValueArray = new (std::nothrow) float[numOfDendriteElements];
			pDendrite_FactorArray = new (std::nothrow) float[numOfDendriteElements];
			pDendrite_ErrorValueArray = new (std::nothrow) float[numOfDendriteElements];
		}
	}

	NumOfDendriteElements = numOfDendriteElements;

	for (int32_t i = 0; i < NumOfDendriteElements; i++)
	{
		ReadFile >> pDendrite_FactorArray[i];
		//ReadFile >> pDendrite_CentroidValueArray[i];
	}

	ReadFile.close();

	return true;
}

bool CSimpleNeuron::Load_AdditionalMemoryValues(const char* pFilename, bool memoryAllocation)
{
	std::ifstream ReadFile;

	// eine existierende Datei zum Lesen �ffnen:
	ReadFile.open(pFilename);

	if (ReadFile.good() == false)
		return false;

	int32_t numOfAdditionalMemoryValues;

	ReadFile >> numOfAdditionalMemoryValues;

	if (memoryAllocation == true)
	{
		if (numOfAdditionalMemoryValues > NumOfAdditionalMemoryValues)
		{
			delete[] pAdditionalMemoryValueArray;
			pAdditionalMemoryValueArray = nullptr;

			pAdditionalMemoryValueArray = new (std::nothrow) float[numOfAdditionalMemoryValues];
		}
	}

	NumOfAdditionalMemoryValues = numOfAdditionalMemoryValues;

	for (int32_t i = 0; i < NumOfAdditionalMemoryValues; i++)
	{
		ReadFile >> pAdditionalMemoryValueArray[i];
	}

	ReadFile.close();

	return true;
}

bool CSimpleNeuron::Save_OutputSynapsesData(const char* pFilename)
{
	std::ofstream WriteFile;

	// neue Datei erzeugen bzw. alte �berschreiben:
	WriteFile.open(pFilename);

	// neue Datei erzeugen bzw. Inhalt ans Ende einer bestehenden Datei schreiben: 
	//WriteFile.open(pFilename, ios::app);

	if (WriteFile.good() == false)
		return false;

	WriteFile << NumOfOutputSynapses << "  ";

	for (int32_t i = 0; i <  NumOfOutputSynapses; i++)
	{
		WriteFile << pReceiverNeuronIDArray[i] << "  ";
		WriteFile << pOutputSynapsePlasticityArray[i] << "  ";
	}

	WriteFile.close();

	return true;
}

bool CSimpleNeuron::Save_Dendrite_Values(const char* pFilename)
{
	std::ofstream WriteFile;

	// neue Datei erzeugen bzw. alte �berschreiben:
	WriteFile.open(pFilename);

	// neue Datei erzeugen bzw. Inhalt ans Ende einer bestehenden Datei schreiben: 
	//WriteFile.open(pFilename, ios::app);

	if (WriteFile.good() == false)
		return false;

	WriteFile << RandomSeedValue << "  ";
	WriteFile << NumOfTrainingExamples << "  ";
	WriteFile << NumOfDendriteElements << "  ";

	for (int32_t i = 0; i < NumOfDendriteElements; i++)
	{
		WriteFile << pDendrite_FactorArray[i] << "  ";
		WriteFile << pDendrite_CentroidValueArray[i] << "  ";
	}

	WriteFile.close();

	return true;
}

bool CSimpleNeuron::Save_Dendrite_Centroids(const char* pFilename)
{
	std::ofstream WriteFile;

	// neue Datei erzeugen bzw. alte �berschreiben:
	WriteFile.open(pFilename);

	// neue Datei erzeugen bzw. Inhalt ans Ende einer bestehenden Datei schreiben: 
	//WriteFile.open(pFilename, ios::app);

	if (WriteFile.good() == false)
		return false;

	WriteFile << RandomSeedValue << "  ";
	WriteFile << NumOfDendriteElements << "  ";

	for (int32_t i = 0; i < NumOfDendriteElements; i++)
	{
		//WriteFile << pDendrite_FactorArray[i] << "  ";
		WriteFile << pDendrite_CentroidValueArray[i] << "  ";
	}

	WriteFile.close();

	return true;
}

bool CSimpleNeuron::Save_Dendrite_Factors(const char* pFilename)
{
	std::ofstream WriteFile;

	// neue Datei erzeugen bzw. alte �berschreiben:
	WriteFile.open(pFilename);

	// neue Datei erzeugen bzw. Inhalt ans Ende einer bestehenden Datei schreiben: 
	//WriteFile.open(pFilename, ios::app);

	if (WriteFile.good() == false)
		return false;

	WriteFile << RandomSeedValue << "  ";
	WriteFile << NumOfDendriteElements << "  ";

	for (int32_t i = 0; i < NumOfDendriteElements; i++)
	{
		WriteFile << pDendrite_FactorArray[i] << "  ";
		//WriteFile << pDendrite_CentroidValueArray[i] << "  ";
	}

	WriteFile.close();

	return true;
}

bool CSimpleNeuron::Save_AdditionalMemoryValues(const char* pFilename)
{
	std::ofstream WriteFile;

	// neue Datei erzeugen bzw. alte �berschreiben:
	WriteFile.open(pFilename);

	// neue Datei erzeugen bzw. Inhalt ans Ende einer bestehenden Datei schreiben: 
	//WriteFile.open(pFilename, ios::app);

	if (WriteFile.good() == false)
		return false;

	WriteFile << NumOfAdditionalMemoryValues << "  ";

	for (int32_t i = 0; i < NumOfAdditionalMemoryValues; i++)
	{
		WriteFile << pAdditionalMemoryValueArray[i] << "  ";
	}

	WriteFile.close();

	return true;
}

void CSimpleNeuron::Reset_NumOfTrainingExamples(void)
{
	NumOfTrainingExamples = 0;


	for (int32_t i = 0; i < NumOfDendriteElements; i++)
	{
		pDendrite_CentroidValueArray[i] = 0.0f;
		pDendrite_FactorArray[i] = 1.0f;
	}

}

void CSimpleNeuron::Randomize_Dendrite_CentroidValues(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue)
{
	for (int32_t i = 0; i < NumOfDendriteElements; i++)
	{
		pDendrite_CentroidValueArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minValue, maxValue);
	}
}

void CSimpleNeuron::Randomize_Dendrite_CentroidValues(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float mutationRate)
{
	for (int32_t i = 0; i < NumOfDendriteElements; i++)
	{
		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
			continue;

		pDendrite_CentroidValueArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minValue, maxValue);
	}
}

void CSimpleNeuron::Randomize_Dendrite_CentroidValues(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, int32_t minDendriteID, int32_t maxDendriteID)
{
	maxDendriteID++;

	for (int32_t i = minDendriteID; i < maxDendriteID; i++)
	{
		pDendrite_CentroidValueArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minValue, maxValue);
	}
}

void CSimpleNeuron::Randomize_Dendrite_CentroidValues(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float mutationRate, int32_t minDendriteID, int32_t maxDendriteID)
{
	maxDendriteID++;

	for (int32_t i = minDendriteID; i < maxDendriteID; i++)
	{
		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
			continue;

		pDendrite_CentroidValueArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minValue, maxValue);
	}
}

void CSimpleNeuron::Modify_Dendrite_CentroidValues(CRandomNumbersNN *pRandomNumbers, float minVariance, float maxVariance)
{
	for (int32_t i = 0; i < NumOfDendriteElements; i++)
	{
		pDendrite_CentroidValueArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minVariance, maxVariance);
	}
}

void CSimpleNeuron::Modify_Dendrite_CentroidValues(CRandomNumbersNN *pRandomNumbers, float minVariance, float maxVariance, float mutationRate)
{
	for (int32_t i = 0; i < NumOfDendriteElements; i++)
	{
		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
			continue;

		pDendrite_CentroidValueArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minVariance, maxVariance);
	}
}

void CSimpleNeuron::Modify_Dendrite_CentroidValues(CRandomNumbersNN *pRandomNumbers, float minVariance, float maxVariance, int32_t minDendriteID, int32_t maxDendriteID)
{
	maxDendriteID++;

	for (int32_t i = minDendriteID; i < maxDendriteID; i++)
	{
		pDendrite_CentroidValueArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minVariance, maxVariance);
	}
}

void CSimpleNeuron::Modify_Dendrite_CentroidValues(CRandomNumbersNN *pRandomNumbers, float minVariance, float maxVariance, float mutationRate, int32_t minDendriteID, int32_t maxDendriteID)
{
	maxDendriteID++;

	for (int32_t i = minDendriteID; i < maxDendriteID; i++)
	{
		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
			continue;

		pDendrite_CentroidValueArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minVariance, maxVariance);
	}
}

void CSimpleNeuron::Randomize_AdditionalMemoryValues(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue)
{
	for (int32_t i = 0; i < NumOfAdditionalMemoryValues; i++)
	{
		pAdditionalMemoryValueArray[i] = pRandomNumbers->Get_FloatNumber(minValue, maxValue);
	}
}

void CSimpleNeuron::Randomize_AdditionalMemoryValues(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, int32_t minValueID, int32_t maxValueID)
{
	maxValueID++;

	for (int32_t i = minValueID; i < maxValueID; i++)
	{
		pAdditionalMemoryValueArray[i] = pRandomNumbers->Get_FloatNumber(minValue, maxValue);
	}
}


void CSimpleNeuron::Randomize_Dendrite_Factors(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue)
{
	for (int32_t i = 0; i < NumOfDendriteElements; i++)
	{
		pDendrite_FactorArray[i] = pRandomNumbers->Get_FloatNumber(minValue, maxValue);
	}
}

void CSimpleNeuron::Randomize_AdditionalMemoryValues(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float mutationRate)
{
	for (int32_t i = 0; i < NumOfAdditionalMemoryValues; i++)
	{
		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
			continue;

		pAdditionalMemoryValueArray[i] = pRandomNumbers->Get_FloatNumber(minValue, maxValue);
	}
}

void CSimpleNeuron::Randomize_AdditionalMemoryValues(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float mutationRate, int32_t minValueID, int32_t maxValueID)
{
	maxValueID++;

	for (int32_t i = minValueID; i < maxValueID; i++)
	{
		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
			continue;

		pAdditionalMemoryValueArray[i] = pRandomNumbers->Get_FloatNumber(minValue, maxValue);
	}
}

void CSimpleNeuron::Randomize_Dendrite_Factors(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float mutationRate)
{
	for (int32_t i = 0; i < NumOfDendriteElements; i++)
	{
		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
			continue;

		pDendrite_FactorArray[i] = pRandomNumbers->Get_FloatNumber(minValue, maxValue);
	}
}

void CSimpleNeuron::Randomize_Dendrite_Factors(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, int32_t minDendriteID, int32_t maxDendriteID)
{
	maxDendriteID++;

	for (int32_t i = minDendriteID; i < maxDendriteID; i++)
	{
		pDendrite_FactorArray[i] = pRandomNumbers->Get_FloatNumber(minValue, maxValue);
	}
}

void CSimpleNeuron::Randomize_Dendrite_Factors(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float mutationRate, int32_t minDendriteID, int32_t maxDendriteID)
{
	maxDendriteID++;

	for (int32_t i = minDendriteID; i < maxDendriteID; i++)
	{
		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
			continue;

		pDendrite_FactorArray[i] = pRandomNumbers->Get_FloatNumber(minValue, maxValue);
	}
}

void CSimpleNeuron::Modify_AdditionalMemoryValues(CRandomNumbersNN *pRandomNumbers, float minVariance, float maxVariance)
{
	for (int32_t i = 0; i < NumOfAdditionalMemoryValues; i++)
	{
		pAdditionalMemoryValueArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minVariance, maxVariance);

		if (pAdditionalMemoryValueArray[i] == 0.0f)
		{
			pAdditionalMemoryValueArray[i] = 0.0001f;
		}
	}
}

void CSimpleNeuron::Modify_AdditionalMemoryValues(CRandomNumbersNN *pRandomNumbers, float minVariance, float maxVariance, int32_t minValueID, int32_t maxValueID)
{
	maxValueID++;

	for (int32_t i = minValueID; i < maxValueID; i++)
	{
		pAdditionalMemoryValueArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minVariance, maxVariance);

		if (pAdditionalMemoryValueArray[i] == 0.0f)
		{
			pAdditionalMemoryValueArray[i] = 0.0001f;
		}
	}
}

void CSimpleNeuron::Modify_Dendrite_Factors(CRandomNumbersNN *pRandomNumbers, float minVariance, float maxVariance)
{
	for (int32_t i = 0; i < NumOfDendriteElements; i++)
	{
		pDendrite_FactorArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minVariance, maxVariance);

		if (pDendrite_FactorArray[i] == 0.0f)
		{
			pDendrite_FactorArray[i] = 0.0001f;
		}
	}
}

void CSimpleNeuron::Modify_AdditionalMemoryValues(CRandomNumbersNN *pRandomNumbers, float minVariance, float maxVariance, float mutationRate)
{
	for (int32_t i = 0; i < NumOfAdditionalMemoryValues; i++)
	{
		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
			continue;

		pAdditionalMemoryValueArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minVariance, maxVariance);

		if (pAdditionalMemoryValueArray[i] == 0.0f)
		{
			pAdditionalMemoryValueArray[i] = 0.0001f;
		}
	}
}

void CSimpleNeuron::Modify_AdditionalMemoryValues(CRandomNumbersNN *pRandomNumbers, float minVariance, float maxVariance, float mutationRate, int32_t minValueID, int32_t maxValueID)
{
	maxValueID++;

	for (int32_t i = minValueID; i < maxValueID; i++)
	{
		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
			continue;

		pAdditionalMemoryValueArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minVariance, maxVariance);

		if (pAdditionalMemoryValueArray[i] == 0.0f)
		{
			pAdditionalMemoryValueArray[i] = 0.0001f;
		}
	}
}

void CSimpleNeuron::Modify_Dendrite_Factors(CRandomNumbersNN *pRandomNumbers, float minVariance, float maxVariance, float mutationRate)
{
	for (int32_t i = 0; i < NumOfDendriteElements; i++)
	{
		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
			continue;

		pDendrite_FactorArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minVariance, maxVariance);
		
		if (pDendrite_FactorArray[i] == 0.0f)
		{
			pDendrite_FactorArray[i] = 0.0001f;
		}
	}
}

void CSimpleNeuron::Modify_Dendrite_Factors(CRandomNumbersNN *pRandomNumbers, float minVariance, float maxVariance, int32_t minDendriteID, int32_t maxDendriteID)
{
	maxDendriteID++;

	for (int32_t i = minDendriteID; i < maxDendriteID; i++)
	{
		pDendrite_FactorArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minVariance, maxVariance);

		if (pDendrite_FactorArray[i] == 0.0f)
		{
			pDendrite_FactorArray[i] = 0.0001f;
		}
	}
}

void CSimpleNeuron::Modify_Dendrite_Factors(CRandomNumbersNN *pRandomNumbers, float minVariance, float maxVariance, float mutationRate, int32_t minDendriteID, int32_t maxDendriteID)
{
	maxDendriteID++;

	for (int32_t i = minDendriteID; i < maxDendriteID; i++)
	{
		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
			continue;

		pDendrite_FactorArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minVariance, maxVariance);

		if (pDendrite_FactorArray[i] == 0.0f)
		{
			pDendrite_FactorArray[i] = 0.0001f;
		}
	}
}

void CSimpleNeuron::Permute_Dendrite_Values(CRandomNumbersNN *pRandomNumbers, int32_t minVectorElement, int32_t maxVectorElement, int32_t permutationSteps)
{
	for (int32_t i = 0; i < permutationSteps; i++)
	{
		int32_t id1 = pRandomNumbers->Get_IntegerNumber2(minVectorElement, maxVectorElement);
		int32_t id2 = pRandomNumbers->Get_IntegerNumber2(minVectorElement, maxVectorElement);

		float tempValue1 = pDendrite_CentroidValueArray[id1];
		float tempValue2 = pDendrite_FactorArray[id1];

		pDendrite_CentroidValueArray[id1] = pDendrite_CentroidValueArray[id2];
		pDendrite_FactorArray[id1] = pDendrite_FactorArray[id2];

		pDendrite_CentroidValueArray[id2] = tempValue1;
		pDendrite_FactorArray[id2] = tempValue2;
	}
}

void CSimpleNeuron::Permute_Dendrite_Values(CRandomNumbersNN *pRandomNumbers, int32_t permutationSteps)
{
	for (int32_t i = 0; i < permutationSteps; i++)
	{
		int32_t id1 = pRandomNumbers->Get_IntegerNumber(0, NumOfDendriteElements);
		int32_t id2 = pRandomNumbers->Get_IntegerNumber(0, NumOfDendriteElements);

		float tempValue1 = pDendrite_CentroidValueArray[id1];
		float tempValue2 = pDendrite_FactorArray[id1];

		pDendrite_CentroidValueArray[id1] = pDendrite_CentroidValueArray[id2];
		pDendrite_FactorArray[id1] = pDendrite_FactorArray[id2];

		pDendrite_CentroidValueArray[id2] = tempValue1;
		pDendrite_FactorArray[id2] = tempValue2;
	}
}

void CSimpleNeuron::Permute_Dendrite_CentroidValues(CRandomNumbersNN *pRandomNumbers, int32_t minVectorElement, int32_t maxVectorElement, int32_t permutationSteps)
{
	for (int32_t i = 0; i < permutationSteps; i++)
	{
		int32_t id1 = pRandomNumbers->Get_IntegerNumber2(minVectorElement, maxVectorElement);
		int32_t id2 = pRandomNumbers->Get_IntegerNumber2(minVectorElement, maxVectorElement);

		float tempValue = pDendrite_CentroidValueArray[id1];

		pDendrite_CentroidValueArray[id1] = pDendrite_CentroidValueArray[id2];

		pDendrite_CentroidValueArray[id2] = tempValue;
	}
}

void CSimpleNeuron::Permute_Dendrite_CentroidValues(CRandomNumbersNN *pRandomNumbers, int32_t permutationSteps)
{
	for (int32_t i = 0; i < permutationSteps; i++)
	{
		int32_t id1 = pRandomNumbers->Get_IntegerNumber(0, NumOfDendriteElements);
		int32_t id2 = pRandomNumbers->Get_IntegerNumber(0, NumOfDendriteElements);

		float tempValue = pDendrite_CentroidValueArray[id1];

		pDendrite_CentroidValueArray[id1] = pDendrite_CentroidValueArray[id2];

		pDendrite_CentroidValueArray[id2] = tempValue;
	}
}

void CSimpleNeuron::Permute_Dendrite_Factors(CRandomNumbersNN *pRandomNumbers, int32_t minVectorElement, int32_t maxVectorElement, int32_t permutationSteps)
{
	for (int32_t i = 0; i < permutationSteps; i++)
	{
		int32_t id1 = pRandomNumbers->Get_IntegerNumber2(minVectorElement, maxVectorElement);
		int32_t id2 = pRandomNumbers->Get_IntegerNumber2(minVectorElement, maxVectorElement);

		float tempValue = pDendrite_FactorArray[id1];

		pDendrite_FactorArray[id1] = pDendrite_FactorArray[id2];

		pDendrite_FactorArray[id2] = tempValue;
	}
}

void CSimpleNeuron::Permute_AdditionalMemoryValues(CRandomNumbersNN *pRandomNumbers, int32_t permutationSteps)
{
	for (int32_t i = 0; i < permutationSteps; i++)
	{
		int32_t id1 = pRandomNumbers->Get_IntegerNumber(0, NumOfAdditionalMemoryValues);
		int32_t id2 = pRandomNumbers->Get_IntegerNumber(0, NumOfAdditionalMemoryValues);

		float tempValue = pAdditionalMemoryValueArray[id1];

		pAdditionalMemoryValueArray[id1] = pAdditionalMemoryValueArray[id2];

		pAdditionalMemoryValueArray[id2] = tempValue;
	}
}

void CSimpleNeuron::Permute_AdditionalMemoryValues(CRandomNumbersNN *pRandomNumbers, int32_t minValueID, int32_t maxValueID, int32_t permutationSteps)
{
	for (int32_t i = 0; i < permutationSteps; i++)
	{
		int32_t id1 = pRandomNumbers->Get_IntegerNumber2(minValueID, maxValueID);
		int32_t id2 = pRandomNumbers->Get_IntegerNumber2(minValueID, maxValueID);

		float tempValue = pAdditionalMemoryValueArray[id1];

		pAdditionalMemoryValueArray[id1] = pAdditionalMemoryValueArray[id2];

		pAdditionalMemoryValueArray[id2] = tempValue;
	}
}

void CSimpleNeuron::Permute_Dendrite_Factors(CRandomNumbersNN *pRandomNumbers, int32_t permutationSteps)
{
	for (int32_t i = 0; i < permutationSteps; i++)
	{
		int32_t id1 = pRandomNumbers->Get_IntegerNumber(0, NumOfDendriteElements);
		int32_t id2 = pRandomNumbers->Get_IntegerNumber(0, NumOfDendriteElements);

		float tempValue = pDendrite_FactorArray[id1];

		pDendrite_FactorArray[id1] = pDendrite_FactorArray[id2];

		pDendrite_FactorArray[id2] = tempValue;
	}
}





void CSimpleNeuron::Reset_NumOfTrainingExamples(int32_t minDendriteID, int32_t maxDendriteID)
{
	maxDendriteID++;

	NumOfTrainingExamples = 0;


	for (int32_t i = minDendriteID; i < maxDendriteID; i++)
	{
		pDendrite_CentroidValueArray[i] = 0.0f;
		pDendrite_FactorArray[i] = 1.0f;
	}

}

void CSimpleNeuron::Round_Dendrite_Factors(float precision)
{
	float invPrecision = 1.0f / precision;

	float fValue;
	int32_t iValue;

	for (int32_t i = 0; i < NumOfDendriteElements; i++)
	{
		iValue = static_cast<int32_t>(invPrecision * pDendrite_FactorArray[i]);
		fValue = static_cast<float>(iValue);
		fValue *= precision;

		pDendrite_FactorArray[i] = fValue;
	}
}

void CSimpleNeuron::Round_Dendrite_Factors(float precision, int32_t minDendriteID, int32_t maxDendriteID)
{
	maxDendriteID++;

	float invPrecision = 1.0f / precision;

	float fValue;
	int32_t iValue;

	for (int32_t i = minDendriteID; i < maxDendriteID; i++)
	{
		iValue = static_cast<int32_t>(invPrecision * pDendrite_FactorArray[i]);
		fValue = static_cast<float>(iValue);
		fValue *= precision;

		pDendrite_FactorArray[i] = fValue;
	}
}

void CSimpleNeuron::Round_AdditionalMemoryValues(float precision, int32_t minValueID, int32_t maxValueID)
{
	maxValueID++;

	float invPrecision = 1.0f / precision;

	float fValue;
	int32_t iValue;

	for (int32_t i = minValueID; i < maxValueID; i++)
	{
		iValue = static_cast<int32_t>(invPrecision * pAdditionalMemoryValueArray[i]);
		fValue = static_cast<float>(iValue);
		fValue *= precision;

		pAdditionalMemoryValueArray[i] = fValue;
	}
}

void CSimpleNeuron::Round_AdditionalMemoryValues(float precision)
{
	float invPrecision = 1.0f / precision;

	float fValue;
	int32_t iValue;

	for (int32_t i = 0; i < NumOfAdditionalMemoryValues; i++)
	{
		iValue = static_cast<int32_t>(invPrecision * pAdditionalMemoryValueArray[i]);
		fValue = static_cast<float>(iValue);
		fValue *= precision;

		pAdditionalMemoryValueArray[i] = fValue;
	}
}

void CSimpleNeuron::Round_Dendrite_CentroidValues(float precision)
{
	float invPrecision = 1.0f / precision;

	float fValue;
	int32_t iValue;

	for (int32_t i = 0; i < NumOfDendriteElements; i++)
	{
		iValue = static_cast<int32_t>(invPrecision * pDendrite_CentroidValueArray[i]);
		fValue = static_cast<float>(iValue);
		fValue *= precision;

		pDendrite_CentroidValueArray[i] = fValue;
	}
}

void CSimpleNeuron::Round_Dendrite_CentroidValues(float precision, int32_t minDendriteID, int32_t maxDendriteID)
{
	maxDendriteID++;

	float invPrecision = 1.0f / precision;

	float fValue;
	int32_t iValue;

	for (int32_t i = minDendriteID; i < maxDendriteID; i++)
	{
		iValue = static_cast<int32_t>(invPrecision * pDendrite_CentroidValueArray[i]);
		fValue = static_cast<float>(iValue);
		fValue *= precision;

		pDendrite_CentroidValueArray[i] = fValue;
	}
}

void CSimpleNeuron::Add_TrainingExample(float *pCentroidValueArray)
{
	float weight1 = 1.0f / (static_cast<float>(NumOfTrainingExamples) + 1.0f);
	float weight2 = 1.0f - weight1;

	for (int32_t i = 0; i < NumOfDendriteElements; i++)
	{
		pDendrite_CentroidValueArray[i] = weight1 * pCentroidValueArray[i] + weight2 * pDendrite_CentroidValueArray[i];
	}

	NumOfTrainingExamples++;
}

void CSimpleNeuron::Add_TrainingExample(float *pCentroidValueArray, int32_t minDendriteID, int32_t maxDendriteID)
{
	maxDendriteID++;

	float weight1 = 1.0f / (static_cast<float>(NumOfTrainingExamples) + 1.0f);
	float weight2 = 1.0f - weight1;

	int32_t counter = 0;
	for (int32_t i = minDendriteID; i < maxDendriteID; i++)
	{
		pDendrite_CentroidValueArray[i] = weight1 * pCentroidValueArray[counter++] + weight2 * pDendrite_CentroidValueArray[i];
	}

	NumOfTrainingExamples++;
}

void CSimpleNeuron::Calculate_Dendrite_Factors_From_CentroidValues(int32_t minDendriteID, int32_t maxDendriteID, float fallback_RBF_Factor, float centroidWeightFactor, int32_t centroidExponent)
{
	maxDendriteID++;

	for (int32_t i = minDendriteID; i < maxDendriteID; i++)
	{
		pDendrite_FactorArray[i] = pDendrite_CentroidValueArray[i];
	}

	for (int32_t j = 1; j < centroidExponent; j++)
	{
		for (int32_t i = minDendriteID; i < maxDendriteID; i++)
		{
			pDendrite_FactorArray[i] *= pDendrite_CentroidValueArray[i];
		}
	}

	for (int32_t i = minDendriteID; i < maxDendriteID; i++)
	{
		pDendrite_FactorArray[i] *= centroidWeightFactor;
	}

	for (int32_t i = minDendriteID; i < maxDendriteID; i++)
	{
		if (pDendrite_CentroidValueArray[i] == 0.0f)
			pDendrite_FactorArray[i] = fallback_RBF_Factor;
	}
}

void CSimpleNeuron::Calculate_Dendrite_Factors_From_CentroidValues(float fallback_RBF_Factor, float centroidWeightFactor, int32_t centroidExponent)
{
	for (int32_t i = 0; i < NumOfDendriteElements; i++)
	{
		pDendrite_FactorArray[i] = pDendrite_CentroidValueArray[i];
	}

	for (int32_t j = 1; j < centroidExponent; j++)
	{
		for (int32_t i = 0; i < NumOfDendriteElements; i++)
		{
			pDendrite_FactorArray[i] *= pDendrite_CentroidValueArray[i];
		}
	}

	for (int32_t i = 0; i < NumOfDendriteElements; i++)
	{
		pDendrite_FactorArray[i] *= centroidWeightFactor;
	}

	for (int32_t i = 0; i < NumOfDendriteElements; i++)
	{
		if (pDendrite_CentroidValueArray[i] == 0.0f)
			pDendrite_FactorArray[i] = fallback_RBF_Factor;
	}
}

void CSimpleNeuron::Set_Dendrite_Factor(float factor, float regardedCentroidValue)
{
	for (int32_t i = 0; i < NumOfDendriteElements; i++)
	{
		if (pDendrite_CentroidValueArray[i] == regardedCentroidValue)
			pDendrite_FactorArray[i] = factor;
	}
}

void CSimpleNeuron::Set_Dendrite_Factor(float factor, float lowerCentroidValueThreshold, float upperCentroidValueThreshold)
{
	for (int32_t i = 0; i < NumOfDendriteElements; i++)
	{
		if (pDendrite_CentroidValueArray[i] <= upperCentroidValueThreshold && pDendrite_CentroidValueArray[i] >= lowerCentroidValueThreshold)
			pDendrite_FactorArray[i] = factor;
	}
}

void CSimpleNeuron::Set_Dendrite_Factor(float factor, float regardedCentroidValue, int32_t minDendriteID, int32_t maxDendriteID)
{
	maxDendriteID++;

	for (int32_t i = minDendriteID; i < maxDendriteID; i++)
	{
		if (pDendrite_CentroidValueArray[i] == regardedCentroidValue)
			pDendrite_FactorArray[i] = factor;
	}
}

void CSimpleNeuron::Set_Dendrite_Factor(float factor, float lowerCentroidValueThreshold, float upperCentroidValueThreshold, int32_t minDendriteID, int32_t maxDendriteID)
{
	maxDendriteID++;

	for (int32_t i = minDendriteID; i < maxDendriteID; i++)
	{
		if (pDendrite_CentroidValueArray[i] <= upperCentroidValueThreshold && pDendrite_CentroidValueArray[i] >= lowerCentroidValueThreshold)
			pDendrite_FactorArray[i] = factor;
	}
}

void CSimpleNeuron::Set_CentroidValue(float centroidValue, float lowerCentroidValueThreshold, float upperCentroidValueThreshold)
{
	for (int32_t i = 0; i < NumOfDendriteElements; i++)
	{
		if (pDendrite_CentroidValueArray[i] <= upperCentroidValueThreshold && pDendrite_CentroidValueArray[i] >= lowerCentroidValueThreshold)
			pDendrite_CentroidValueArray[i] = 0.0f;
	}
}

void CSimpleNeuron::Set_CentroidValue(float centroidValue, float lowerCentroidValueThreshold, float upperCentroidValueThreshold, int32_t minDendriteID, int32_t maxDendriteID)
{
	maxDendriteID++;

	for (int32_t i = minDendriteID; i < maxDendriteID; i++)
	{
		if (pDendrite_CentroidValueArray[i] <= upperCentroidValueThreshold && pDendrite_CentroidValueArray[i] >= lowerCentroidValueThreshold)
			pDendrite_CentroidValueArray[i] = 0.0f;
	}
}


void CSimpleNeuron::Set_AdditionalInputValue(float value)
{
	AdditionalInputValue = value;
}

void CSimpleNeuron::Set_RandomSeedValue(int32_t newSeed)
{
	RandomSeedValue = max(0, newSeed);
	RandomSeedValue = min(RandomSeedValue, ConstRandomNumbersTableSize - 1000);
}

void CSimpleNeuron::Set_ErrorFactors(float factor1, float factor2)
{
	ErrorFactor1 = factor1;
	ErrorFactor2 = factor2;
}

void CSimpleNeuron::Set_LearningRate(float learningRate)
{
	LearningRate = learningRate;
}

void CSimpleNeuron::Get_Dendrite_NeuronOutput(float *pOutputValueArray)
{
	int32_t LastOutputDendriteIDPlus1 = FirstOutputDendriteID + NumOfOutputDendrites;

	int32_t counter = 0;

	for (int32_t i = FirstOutputDendriteID; i < LastOutputDendriteIDPlus1; i++)
	{
		pOutputValueArray[counter] = pDendrite_DataArray[i];
		counter++;
	}
}

void CSimpleNeuron::Set_Dendrite_NeuronInput(float *pInputValueArray)
{
	Dendrite_InputCounter = NumOfDendriteElements;
	UsedDendritesMinID = 0;
	UsedDendritesMaxIDPlus1 = NumOfDendriteElements;

	for (int32_t i = 0; i < NumOfDendriteElements; i++)
	{
		pDendrite_DataArray[i] = pInputValueArray[i];
	}
}

void CSimpleNeuron::Set_Dendrite_NeuronInput(float inputValue, int32_t dendriteID)
{
	Dendrite_InputCounter++;

	pDendrite_DataArray[dendriteID] = inputValue;
}

void CSimpleNeuron::Set_Dendrite_NeuronInput(float *pInputValueArray, int32_t numOfInputvalues, int32_t usedDendritesMinID)
{
	Dendrite_InputCounter = numOfInputvalues;
	UsedDendritesMinID = usedDendritesMinID;
	UsedDendritesMaxIDPlus1 = UsedDendritesMinID + numOfInputvalues;

	int32_t counter = 0;

	for (int32_t i = UsedDendritesMinID; i < UsedDendritesMaxIDPlus1; i++)
	{
		pDendrite_DataArray[i] = pInputValueArray[counter];
		counter++;
	}
	
}

bool CSimpleNeuron::Set_Dendrite_NeuronInput(int32_t posX_left, int32_t posY_top, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY)
{
	if (inputMapSizeX == localReceptiveFieldSizeX && inputMapSizeY == localReceptiveFieldSizeY)
	{
		Dendrite_InputCounter = localReceptiveFieldSizeX * localReceptiveFieldSizeY;

		UsedDendritesMinID = 0;
		UsedDendritesMaxIDPlus1 = Dendrite_InputCounter;

		for (int32_t i = 0; i < Dendrite_InputCounter; i++)
		{
			pDendrite_DataArray[i] = pInputMap[i];
		}

		return true;
	}

	if (posX_left < 0)
		return false;
	if (posY_top < 0)
		return false;
	if (posX_left > inputMapSizeX - localReceptiveFieldSizeX)
		return false;
	if (posY_top > inputMapSizeY - localReceptiveFieldSizeY)
		return false;

	int32_t ixStart = posX_left;
	int32_t ixStop = ixStart + localReceptiveFieldSizeX;

	int32_t iyStart = posY_top;
	int32_t iyStop = iyStart + localReceptiveFieldSizeY;

	int32_t iiy;
	int32_t counter = 0;

	for (int32_t iy = iyStart; iy < iyStop; iy++)
	{
		iiy = iy * inputMapSizeX;

		for (int32_t ix = ixStart; ix < ixStop; ix++)
		{
			pDendrite_DataArray[counter++] = pInputMap[ix + iiy];
		}
	}

	Dendrite_InputCounter = counter;

	UsedDendritesMinID = 0;
	UsedDendritesMaxIDPlus1 = Dendrite_InputCounter;

	return true;
}

bool CSimpleNeuron::Set_Dendrite_NeuronInput_UseCenterPos(int32_t posX_center, int32_t posY_center, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY)
{
	if (inputMapSizeX == localReceptiveFieldSizeX && inputMapSizeY == localReceptiveFieldSizeY)
	{
		Dendrite_InputCounter = localReceptiveFieldSizeX * localReceptiveFieldSizeY;

		UsedDendritesMinID = 0;
		UsedDendritesMaxIDPlus1 = Dendrite_InputCounter;

		for (int32_t i = 0; i < Dendrite_InputCounter; i++)
		{
			pDendrite_DataArray[i] = pInputMap[i];
		}

		return true;
	}

	int32_t posX_left = posX_center - localReceptiveFieldSizeX / 2;
	int32_t posY_top = posY_center - localReceptiveFieldSizeY / 2;

	if (posX_left < 0)
		return false;
	if (posY_top < 0)
		return false;
	if (posX_left > inputMapSizeX - localReceptiveFieldSizeX)
		return false;
	if (posY_top > inputMapSizeY - localReceptiveFieldSizeY)
		return false;

	int32_t ixStart = posX_left;
	int32_t ixStop = ixStart + localReceptiveFieldSizeX;

	int32_t iyStart = posY_top;
	int32_t iyStop = iyStart + localReceptiveFieldSizeY;

	int32_t iiy;
	int32_t counter = 0;

	for (int32_t iy = iyStart; iy < iyStop; iy++)
	{
		iiy = iy * inputMapSizeX;

		for (int32_t ix = ixStart; ix < ixStop; ix++)
		{
			pDendrite_DataArray[counter++] = pInputMap[ix + iiy];
		}
	}

	Dendrite_InputCounter = counter;

	UsedDendritesMinID = 0;
	UsedDendritesMaxIDPlus1 = Dendrite_InputCounter;

	return true;
}


void CSimpleNeuron::Execute_DendriticCalculations(void)
{
	pDendriticFunc(this);
}

void CSimpleNeuron::Calculate_NeuronOutput(void)
{
	pActivationFunc(this);
}



void CSimpleNeuron::Calculate_NeuronOutput_Ext(void)
{
	pDendriticFunc(this);
	pActivationFunc(this);
}







float CSimpleNeuron::Calculate_VarianceSq(float desiredNeuronOutput)
{
	// Abweichung:
	float variance = desiredNeuronOutput - ActivationValue;
	return variance * variance;
}

float CSimpleNeuron::Calculate_Error(float desiredNeuronOutput)
{
	// Abweichung:
	float variance = desiredNeuronOutput - ActivationValue;
	ErrorValue = variance * ErrorFactor1 * exp(-(ErrorFactor2 * ActivationValue * ActivationValue));

	/* Hinweis: Wenn bereits eine geringe Neuronenaktivit�t (ActivationValue)
	zu einer gro�en Abweichung f�hrt, ist auch der Fehler gro�. Abweichungen
	bei einer starken Neuronenaktivit�t f�hren hingegen zu einem kleineren
	Fehler. */

	return variance*variance;
}

float CSimpleNeuron::Calculate_Error(float desiredNeuronOutput, float errorFactor1, float errorFactor2)
{
	// Abweichung:
	float variance = desiredNeuronOutput - ActivationValue;
	ErrorValue = variance * errorFactor1 * exp(-(errorFactor2 * ActivationValue * ActivationValue));
	
	/* Hinweis: Wenn bereits eine geringe Neuronenaktivit�t (ActivationValue)
	zu einer gro�en Abweichung f�hrt, ist auch der Fehler gro�. Abweichungen
	bei einer starken Neuronenaktivit�t f�hren hingegen zu einem kleineren
	Fehler. */

	return variance*variance;
}

void CSimpleNeuron::Calculate_Error(void)
{
	int32_t receiverNeuronID;

	float errorSum = 0.0f;

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		receiverNeuronID = pReceiverNeuronIDArray[i];
		errorSum += pUsedNeuronArray[receiverNeuronID].ErrorValue * pOutputSynapsePlasticityArray[i];
	}

	ErrorValue = errorSum * ErrorFactor1 * exp(-(ErrorFactor2 * ActivationValue * ActivationValue));

	/* Hinweis: Abweichungen bei einer geringen Neuronenaktivit�t f�hren
	zu einem gr��eren Fehler. Abweichungen bei einer starken Neuronenaktivit�t
	f�hren hingegen zu einem kleineren Fehler. */
}





void CSimpleNeuron::Calculate_Error(float errorFactor1, float errorFactor2)
{
	int32_t receiverNeuronID;

	float errorSum = 0.0f;

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		receiverNeuronID = pReceiverNeuronIDArray[i];
		errorSum += pUsedNeuronArray[receiverNeuronID].ErrorValue * pOutputSynapsePlasticityArray[i];
	}

	ErrorValue = errorSum * errorFactor1 * exp(-(errorFactor2 * ActivationValue * ActivationValue));

	/* Hinweis: Abweichungen bei einer geringen Neuronenaktivit�t f�hren
	zu einem gr��eren Fehler. Abweichungen bei einer starken Neuronenaktivit�t
	f�hren hingegen zu einem kleineren Fehler. */
}

void CSimpleNeuron::Adjust_Dendrite_Factor_AfterErrorCalculations(float learningRate, int32_t dendriteID)
{
	pDendrite_FactorArray[dendriteID] += learningRate * ErrorValue * pDendrite_DataArray[dendriteID];
}

void CSimpleNeuron::Adjust_Dendrite_Factors_AfterErrorCalculations(float learningRate, int32_t firstDendriteID, int32_t lastDendriteID)
{
	lastDendriteID++;

	for (int32_t i = firstDendriteID; i < lastDendriteID; i++)
	{
		pDendrite_FactorArray[i] += learningRate * ErrorValue * pDendrite_DataArray[i];
	}
}

void CSimpleNeuron::Adjust_Dendrite_Factor_AfterErrorCalculations_ExternalInput(float learningRate, int32_t dendriteID)
{
	pDendrite_FactorArray[dendriteID] += learningRate * ErrorValue * pDendrite_DataArray_OtherNeuron[dendriteID];
}

void CSimpleNeuron::Adjust_Dendrite_Factor_AfterErrorCalculations_ExternalInput(int32_t connectionID, float learningRate, int32_t dendriteID)
{
	float *pArray = pDendrite_DataArray_OtherNeurons[connectionID];
	pDendrite_FactorArray[dendriteID] += learningRate * ErrorValue * pArray[dendriteID];
}

void CSimpleNeuron::Adjust_Dendrite_Factors_AfterErrorCalculations_ExternalInput(float learningRate, int32_t firstDendriteID, int32_t lastDendriteID)
{
	lastDendriteID++;

	for (int32_t i = firstDendriteID; i < lastDendriteID; i++)
	{
		pDendrite_FactorArray[i] += learningRate * ErrorValue * pDendrite_DataArray_OtherNeuron[i];
	}
}

void CSimpleNeuron::Adjust_Dendrite_Factors_AfterErrorCalculations_ExternalInput(int32_t connectionID, float learningRate)
{
	float *pArray = pDendrite_DataArray_OtherNeurons[connectionID];

	for (int32_t i = 0; i < NumOfDendriteElements; i++)
	{
		pDendrite_FactorArray[i] += learningRate * ErrorValue * pArray[i];
	}
}

void CSimpleNeuron::Adjust_Dendrite_Factors_AfterErrorCalculations_ExternalInput(int32_t connectionID, float learningRate, int32_t firstDendriteID, int32_t lastDendriteID)
{
	float *pArray = pDendrite_DataArray_OtherNeurons[connectionID];

	lastDendriteID++;

	for (int32_t i = firstDendriteID; i < lastDendriteID; i++)
	{
		pDendrite_FactorArray[i] += learningRate * ErrorValue * pArray[i];
	}
}

float CSimpleNeuron::Adjust_Dendrite_Factors(float desiredNeuronOutput, float learningRate, float errorFactor1, float errorFactor2)
{
	float outputError = Calculate_Error(desiredNeuronOutput, errorFactor1, errorFactor2);

	for (int32_t i = 0; i < NumOfDendriteElements; i++)
	{
		pDendrite_FactorArray[i] += learningRate * ErrorValue * pDendrite_DataArray[i];
	}

	return outputError;
}

void CSimpleNeuron::Adjust_Dendrite_Factors_AfterErrorCalculations(float learningRate)
{
	for (int32_t i = 0; i < NumOfDendriteElements; i++)
	{
		pDendrite_FactorArray[i] += learningRate * ErrorValue * pDendrite_DataArray[i];
	}
}

void CSimpleNeuron::SimpleAdjust_Dendrite_Factors_AfterErrorCalculations(float learningRate)
{
	for (int32_t i = 0; i < NumOfDendriteElements; i++)
	{
		pDendrite_FactorArray[i] += learningRate * ErrorValue;// *pDendrite_DataArray[i];
	}
}


void CSimpleNeuron::Propagate_SynapticOutput(void)
{
	uint32_t receiverNeuronID;

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		receiverNeuronID = pReceiverNeuronIDArray[i];
		pUsedNeuronArray[receiverNeuronID].AdditionalInputValue += ActivationValue*pOutputSynapsePlasticityArray[i];
	}
}

void CSimpleNeuron::Adjust_OutputSynapses_AfterErrorCalculations(void)
{
	uint32_t receiverNeuronID;

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		receiverNeuronID = pReceiverNeuronIDArray[i];
		pOutputSynapsePlasticityArray[i] += LearningRate * pUsedNeuronArray[receiverNeuronID].ErrorValue * ActivationValue;
	}
}

void CSimpleNeuron::Adjust_OutputSynapses_AfterErrorCalculations(float learningRate)
{
	uint32_t receiverNeuronID;

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		receiverNeuronID = pReceiverNeuronIDArray[i];
		pOutputSynapsePlasticityArray[i] += learningRate * pUsedNeuronArray[receiverNeuronID].ErrorValue * ActivationValue;
	}
}


float CSimpleNeuron::Adjust_Dendrite_Factors(float desiredNeuronOutput, float learningRate, float errorFactor1, float errorFactor2, int32_t firstDendriteID, int32_t lastDendriteID)
{
	lastDendriteID++;

	float outputError = Calculate_Error(desiredNeuronOutput, errorFactor1, errorFactor2);

	for (int32_t i = firstDendriteID; i < lastDendriteID; i++)
	{
		pDendrite_FactorArray[i] += learningRate * ErrorValue * pDendrite_DataArray[i];
	}

	return outputError;
}

/*void CSimpleNeuron::Adjust_Dendrite_Factors_AfterErrorCalculations(float learningRate, int32_t firstDendriteID, int32_t lastDendriteID)
{
	lastDendriteID++;

	for (int32_t i = firstDendriteID; i < lastDendriteID; i++)
	{
		pDendrite_FactorArray[i] += learningRate * ErrorValue * pDendrite_DataArray[i];
	}
}*/



float CSimpleNeuron::Adjust_Dendrite_Factors_ExternalInput(int32_t connectionID, float desiredNeuronOutput, float learningRate, float errorFactor1, float errorFactor2)
{
	float *pArray = pDendrite_DataArray_OtherNeurons[connectionID];

	float outputError = Calculate_Error(desiredNeuronOutput, errorFactor1, errorFactor2);

	for (int32_t i = 0; i < NumOfDendriteElements; i++)
	{
		pDendrite_FactorArray[i] += learningRate * ErrorValue * pArray[i];
	}

	return outputError;
}

float CSimpleNeuron::Adjust_Dendrite_Factors_ExternalInput(int32_t connectionID, float desiredNeuronOutput, float learningRate, float errorFactor1, float errorFactor2, int32_t firstDendriteID, int32_t lastDendriteID)
{
	lastDendriteID++;

	float *pArray = pDendrite_DataArray_OtherNeurons[connectionID];

	float outputError = Calculate_Error(desiredNeuronOutput, errorFactor1, errorFactor2);

	for (int32_t i = firstDendriteID; i < lastDendriteID; i++)
	{
		pDendrite_FactorArray[i] += learningRate * ErrorValue * pArray[i];
	}

	return outputError;
}


float CSimpleNeuron::Adjust_Dendrite_Factors_ExternalInput(float desiredNeuronOutput, float learningRate, float errorFactor1, float errorFactor2)
{
	float outputError = Calculate_Error(desiredNeuronOutput, errorFactor1, errorFactor2);

	for (int32_t i = 0; i < NumOfDendriteElements; i++)
	{
		pDendrite_FactorArray[i] += learningRate * ErrorValue * pDendrite_DataArray_OtherNeuron[i];
	}

	return outputError;
}

void CSimpleNeuron::Adjust_Dendrite_Factors_AfterErrorCalculations_ExternalInput(float learningRate)
{
	for (int32_t i = 0; i < NumOfDendriteElements; i++)
	{
		pDendrite_FactorArray[i] += learningRate * ErrorValue * pDendrite_DataArray_OtherNeuron[i];
	}
}

float CSimpleNeuron::Adjust_Dendrite_Factors_ExternalInput(float desiredNeuronOutput, float learningRate, float errorFactor1, float errorFactor2, int32_t firstDendriteID, int32_t lastDendriteID)
{
	lastDendriteID++;

	float outputError = Calculate_Error(desiredNeuronOutput, errorFactor1, errorFactor2);

	for (int32_t i = firstDendriteID; i < lastDendriteID; i++)
	{
		pDendrite_FactorArray[i] += learningRate * ErrorValue * pDendrite_DataArray_OtherNeuron[i];
	}

	return outputError;
}

/*void CSimpleNeuron::Adjust_Dendrite_Factors_AfterErrorCalculations_ExternalInput(float learningRate, int32_t firstDendriteID, int32_t lastDendriteID)
{
	lastDendriteID++;

	for (int32_t i = firstDendriteID; i < lastDendriteID; i++)
	{
		pDendrite_FactorArray[i] += learningRate * ErrorValue * pDendrite_DataArray_OtherNeuron[i];
	}
}*/






CSimpleNeuralNetData::CSimpleNeuralNetData()
{}

CSimpleNeuralNetData::~CSimpleNeuralNetData()
{
	delete[] ppNeuronArray;
	ppNeuronArray = nullptr;

	delete[] pNeuronCalculationSequenceArray;
	pNeuronCalculationSequenceArray = nullptr;
}

void CSimpleNeuralNetData::Set_NeuronCalculationSequenceEntry(int32_t neuronID, int32_t entryID)
{
	pNeuronCalculationSequenceArray[entryID] = neuronID;
}

void CSimpleNeuralNetData::Init_NeuronCalculationSequence(int32_t neuronCalculationSequenceLength, int32_t numOfInputNeurons, int32_t numOfOutputNeurons)
{
	NumOfInputNeurons = numOfInputNeurons;
	NumOfOutputNeurons = numOfOutputNeurons;

	if(neuronCalculationSequenceLength > NeuronCalculationSequenceLength)
	{
		delete[] pNeuronCalculationSequenceArray;
		pNeuronCalculationSequenceArray = nullptr;

		pNeuronCalculationSequenceArray = new (std::nothrow) int32_t[neuronCalculationSequenceLength];

	}

	NeuronCalculationSequenceLength = neuronCalculationSequenceLength;

	for (int32_t i = 0; i < neuronCalculationSequenceLength; i++)
	{
		pNeuronCalculationSequenceArray[i] = -1;
	}
}

void CSimpleNeuralNetData::Init_Data(int32_t numOfNeurons)
{
	if (numOfNeurons > NumOfNeurons)
	{
		delete[] ppNeuronArray;
		ppNeuronArray = nullptr;

		ppNeuronArray = new (std::nothrow) CSimpleNeuron*[numOfNeurons];
	}

	NumOfNeurons = numOfNeurons;

	for (int32_t i = 0; i < numOfNeurons; i++)
	{
		ppNeuronArray[i] = nullptr;
	}
}

void CSimpleNeuralNetData::Reset_Data(void)
{
	for (int32_t i = 0; i < NumOfNeurons; i++)
	{
		ppNeuronArray[i] = nullptr;
	}
}

void CSimpleNeuralNetData::Set_Neuron(CSimpleNeuron *pNeuron, int32_t neuronID)
{
	if (neuronID < 0)
		return;
	if (neuronID >= NumOfNeurons)
		return;

	ppNeuronArray[neuronID] = pNeuron;
}



void CSimpleNeuralNetData::Clone_Values(CSimpleNeuralNetData *pOriginalObject)
{
	NumLRFNeurons_Layer1 = pOriginalObject->NumLRFNeurons_Layer1;
	NumLRFNeurons_Layer2 = pOriginalObject->NumLRFNeurons_Layer2;

	for (int32_t i = 0; i < NumOfNeurons; i++)
	{
		if (ppNeuronArray[i] == nullptr)
		{
			continue;
		}

		ppNeuronArray[i]->Clone_Values(pOriginalObject->ppNeuronArray[i]);
	}

	NumOfInputNeurons = pOriginalObject->NumOfInputNeurons;
	NumOfOutputNeurons = pOriginalObject->NumOfOutputNeurons;

	NeuronCalculationSequenceLength = pOriginalObject->NeuronCalculationSequenceLength;

	for (int32_t i = 0; i < NeuronCalculationSequenceLength; i++)
	{
		pNeuronCalculationSequenceArray[i] = pOriginalObject->pNeuronCalculationSequenceArray[i];
	}
}



void Search_Pattern(int32_t *pOutPatternCount, int32_t *pOutPatternPosXArray, int32_t *pOutPatternPosYArray, int32_t numPatternPositionsMax, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CSimpleNeuron *pDetectionNeuron, float minActivationValue)
{
	int32_t numPatternPositionsMaxMinus1 = numPatternPositionsMax - 1;

	int32_t localReceptiveFieldSizeX = pDetectionNeuron->LocalReceptiveFieldSizeX;
	int32_t localReceptiveFieldSizeY = pDetectionNeuron->LocalReceptiveFieldSizeY;

	int32_t patternCounter = 0;

	//int32_t numOfDetectionTests = 0;

	for(int32_t iy = minPosY; iy < maxPosYPlus1; iy += strideY)
	{
		for (int32_t ix = minPosX; ix < maxPosXPlus1; ix += strideX)
		{
			//numOfDetectionTests++;

			if (pDetectionNeuron->Set_Dendrite_NeuronInput_UseCenterPos(ix, iy, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY) == true)
			{
				pDetectionNeuron->Calculate_NeuronOutput();

				if (pDetectionNeuron->ActivationValue > minActivationValue)
				{
					pOutPatternPosXArray[patternCounter] = ix;
					pOutPatternPosYArray[patternCounter] = iy;

					patternCounter++;
					patternCounter = min(patternCounter, numPatternPositionsMaxMinus1);
				}
			}
		}
	}

	*pOutPatternCount = patternCounter;

	//std::cout << "numOfDetectionTests: " << numOfDetectionTests << std::endl;
}

void Search_Pattern(float *pOutPatternCount, float *pOutPatternPosXArray, float *pOutPatternPosYArray, int32_t numPatternPositionsMax, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CSimpleNeuron *pDetectionNeuron, float minActivationValue)
{
	int32_t numPatternPositionsMaxMinus1 = numPatternPositionsMax - 1;

	int32_t localReceptiveFieldSizeX = pDetectionNeuron->LocalReceptiveFieldSizeX;
	int32_t localReceptiveFieldSizeY = pDetectionNeuron->LocalReceptiveFieldSizeY;

	int32_t patternCounter = 0;

	for (int32_t iy = minPosY; iy < maxPosYPlus1; iy += strideY)
	{
		for (int32_t ix = minPosX; ix < maxPosXPlus1; ix += strideX)
		{
			if (pDetectionNeuron->Set_Dendrite_NeuronInput_UseCenterPos(ix, iy, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY) == true)
			{
				pDetectionNeuron->Calculate_NeuronOutput();

				if (pDetectionNeuron->ActivationValue > minActivationValue)
				{
					pOutPatternPosXArray[patternCounter] = static_cast<float>(ix);
					pOutPatternPosYArray[patternCounter] = static_cast<float>(iy);

					patternCounter++;
					patternCounter = min(patternCounter, numPatternPositionsMaxMinus1);
				}
			}
		}
	}

	*pOutPatternCount = static_cast<float>(patternCounter);
}

void Search_Pattern(CSimpleFeatureMap *pFeatureMap, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CSimpleNeuron *pDetectionNeuron, bool addValuesToFeatureMap)
{
	int32_t localReceptiveFieldSizeX = pDetectionNeuron->LocalReceptiveFieldSizeX;
	int32_t localReceptiveFieldSizeY = pDetectionNeuron->LocalReceptiveFieldSizeY;

	if (addValuesToFeatureMap == false)
	{
		for (int32_t iy = minPosY; iy < maxPosYPlus1; iy += strideY)
		{
			for (int32_t ix = minPosX; ix < maxPosXPlus1; ix += strideX)
			{
				if (pDetectionNeuron->Set_Dendrite_NeuronInput_UseCenterPos(ix, iy, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY) == true)
				{
					pDetectionNeuron->Calculate_NeuronOutput();

					pFeatureMap->pDataArray[ix + inputMapSizeX * iy] = pDetectionNeuron->ActivationValue;
				}
			}
		}
	}
	else if (addValuesToFeatureMap == true)
	{
		for (int32_t iy = minPosY; iy < maxPosYPlus1; iy += strideY)
		{
			for (int32_t ix = minPosX; ix < maxPosXPlus1; ix += strideX)
			{
				if (pDetectionNeuron->Set_Dendrite_NeuronInput_UseCenterPos(ix, iy, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY) == true)
				{
					pDetectionNeuron->Calculate_NeuronOutput();

					pFeatureMap->pDataArray[ix + inputMapSizeX * iy] += pDetectionNeuron->ActivationValue;
				}
			}
		}
	}
}

void Search_Patterns(CSimpleFeatureMap *pFeatureMapArray, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CSimpleNeuron *pDetectionNeuronArray, int32_t numPatterns, bool addValuesToFeatureMap)
{
	if (addValuesToFeatureMap == false)
	{
		for (int32_t i = 0; i < numPatterns; i++)
		{
			int32_t localReceptiveFieldSizeX = pDetectionNeuronArray[i].LocalReceptiveFieldSizeX;
			int32_t localReceptiveFieldSizeY = pDetectionNeuronArray[i].LocalReceptiveFieldSizeY;


			for (int32_t iy = minPosY; iy < maxPosYPlus1; iy += strideY)
			{
				for (int32_t ix = minPosX; ix < maxPosXPlus1; ix += strideX)
				{
					//numOfDetectionTests++;

					if (pDetectionNeuronArray[i].Set_Dendrite_NeuronInput_UseCenterPos(ix, iy, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY) == true)
					{
						pDetectionNeuronArray[i].Calculate_NeuronOutput();

						pFeatureMapArray[i].pDataArray[ix + inputMapSizeX * iy] = pDetectionNeuronArray[i].ActivationValue;
					}
				}
			}
		}
	}

	else if (addValuesToFeatureMap == true)
	{
		for (int32_t i = 0; i < numPatterns; i++)
		{
			int32_t localReceptiveFieldSizeX = pDetectionNeuronArray[i].LocalReceptiveFieldSizeX;
			int32_t localReceptiveFieldSizeY = pDetectionNeuronArray[i].LocalReceptiveFieldSizeY;


			for (int32_t iy = minPosY; iy < maxPosYPlus1; iy += strideY)
			{
				for (int32_t ix = minPosX; ix < maxPosXPlus1; ix += strideX)
				{
					//numOfDetectionTests++;

					if (pDetectionNeuronArray[i].Set_Dendrite_NeuronInput_UseCenterPos(ix, iy, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY) == true)
					{
						pDetectionNeuronArray[i].Calculate_NeuronOutput();

						pFeatureMapArray[i].pDataArray[ix + inputMapSizeX * iy] += pDetectionNeuronArray[i].ActivationValue;
					}
				}
			}
		}
	}
}

void Search_Pattern(int32_t *pOutPatternCount, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CSimpleNeuron *pDetectionNeuron, float minActivationValue)
{
	int32_t localReceptiveFieldSizeX = pDetectionNeuron->LocalReceptiveFieldSizeX;
	int32_t localReceptiveFieldSizeY = pDetectionNeuron->LocalReceptiveFieldSizeY;

	int32_t patternCounter = 0;

	for (int32_t iy = minPosY; iy < maxPosYPlus1; iy += strideY)
	{
		for (int32_t ix = minPosX; ix < maxPosXPlus1; ix += strideX)
		{
			if (pDetectionNeuron->Set_Dendrite_NeuronInput_UseCenterPos(ix, iy, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY) == true)
			{
				pDetectionNeuron->Calculate_NeuronOutput();

				if (pDetectionNeuron->ActivationValue > minActivationValue)
				{
					patternCounter++;
				}
			}
		}
	}

	*pOutPatternCount = patternCounter;

	//std::cout << "numOfDetectionTests: " << numOfDetectionTests << std::endl;
}



void Search_Pattern(float *pOutPatternCount, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CSimpleNeuron *pDetectionNeuron, float minActivationValue)
{
	int32_t localReceptiveFieldSizeX = pDetectionNeuron->LocalReceptiveFieldSizeX;
	int32_t localReceptiveFieldSizeY = pDetectionNeuron->LocalReceptiveFieldSizeY;

	int32_t patternCounter = 0;

	//int32_t numOfDetectionTests = 0;

	for (int32_t iy = minPosY; iy < maxPosYPlus1; iy += strideY)
	{
		for (int32_t ix = minPosX; ix < maxPosXPlus1; ix += strideX)
		{
			//numOfDetectionTests++;

			if (pDetectionNeuron->Set_Dendrite_NeuronInput_UseCenterPos(ix, iy, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY) == true)
			{
				pDetectionNeuron->Calculate_NeuronOutput();

				if (pDetectionNeuron->ActivationValue > minActivationValue)
				{
					patternCounter++;
				}
			}
		}
	}

	*pOutPatternCount = static_cast<float>(patternCounter);

	//std::cout << "numOfDetectionTests: " << numOfDetectionTests << std::endl;
}

void Search_Pattern(int32_t *pOutPatternCount, float *pOutValueSum, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CSimpleNeuron *pDetectionNeuron, float minActivationValue)
{
	int32_t localReceptiveFieldSizeX = pDetectionNeuron->LocalReceptiveFieldSizeX;
	int32_t localReceptiveFieldSizeY = pDetectionNeuron->LocalReceptiveFieldSizeY;

	int32_t patternCounter = 0;
	float valueSum = 0.0f;

	//int32_t numOfDetectionTests = 0;

	for (int32_t iy = minPosY; iy < maxPosYPlus1; iy += strideY)
	{
		for (int32_t ix = minPosX; ix < maxPosXPlus1; ix += strideX)
		{
			//numOfDetectionTests++;

			if (pDetectionNeuron->Set_Dendrite_NeuronInput_UseCenterPos(ix, iy, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY) == true)
			{
				pDetectionNeuron->Calculate_NeuronOutput();

				if (pDetectionNeuron->ActivationValue > minActivationValue)
				{
					patternCounter++;
					valueSum += pDetectionNeuron->ActivationValue;
				}
			}
		}
	}

	*pOutPatternCount = patternCounter;
	*pOutValueSum = valueSum;

	//std::cout << "numOfDetectionTests: " << numOfDetectionTests << std::endl;
}

void Search_Pattern(float *pOutPatternCount, float *pOutValueSum, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CSimpleNeuron *pDetectionNeuron, float minActivationValue)
{
	int32_t localReceptiveFieldSizeX = pDetectionNeuron->LocalReceptiveFieldSizeX;
	int32_t localReceptiveFieldSizeY = pDetectionNeuron->LocalReceptiveFieldSizeY;

	int32_t patternCounter = 0;
	float valueSum = 0.0f;

	//int32_t numOfDetectionTests = 0;

	for (int32_t iy = minPosY; iy < maxPosYPlus1; iy += strideY)
	{
		for (int32_t ix = minPosX; ix < maxPosXPlus1; ix += strideX)
		{
			//numOfDetectionTests++;

			if (pDetectionNeuron->Set_Dendrite_NeuronInput_UseCenterPos(ix, iy, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY) == true)
			{
				pDetectionNeuron->Calculate_NeuronOutput();

				if (pDetectionNeuron->ActivationValue > minActivationValue)
				{
					patternCounter++;
					valueSum += pDetectionNeuron->ActivationValue;
				}
			}
		}
	}

	*pOutPatternCount = static_cast<float>(patternCounter);
	*pOutValueSum = valueSum;

	//std::cout << "numOfDetectionTests: " << numOfDetectionTests << std::endl;
}

void Search_Pattern(int32_t *pOutPatternCount, int32_t *pOutPatternPosXArray, int32_t *pOutPatternPosYArray, int32_t numPatternPositionsMax, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CSimpleNeuron *pSectorExaminationNeuron, CSimpleNeuron *pDetectionNeuron, float minActivationValue)
{
	int32_t numPatternPositionsMaxMinus1 = numPatternPositionsMax - 1;

	int32_t localReceptiveFieldSizeX = pDetectionNeuron->LocalReceptiveFieldSizeX;
	int32_t localReceptiveFieldSizeY = pDetectionNeuron->LocalReceptiveFieldSizeY;

	int32_t patternCounter = 0;

	int32_t firstOutputDendriteID = pSectorExaminationNeuron->FirstOutputDendriteID;
	int32_t numOfSectorsXDir = pSectorExaminationNeuron->NumOfOutputDendritesXDir;
	int32_t numOfSectorsYDir = pSectorExaminationNeuron->NumOfOutputDendritesYDir;

	int32_t valuesPerSectorXDir = inputMapSizeX / numOfSectorsXDir;
	int32_t valuesPerSectorYDir = inputMapSizeY / numOfSectorsYDir;

	float *pSectorDataArray = &pSectorExaminationNeuron->pDendrite_DataArray[firstOutputDendriteID];

	int32_t ix2, iy2;

	//int32_t numOfDetectionTests = 0;

	for (int32_t iy = minPosY; iy < maxPosYPlus1; iy += strideY)
	{
		iy2 = iy / valuesPerSectorYDir;
		iy2 *= numOfSectorsXDir;

		for (int32_t ix = minPosX; ix < maxPosXPlus1; ix += strideX)
		{
			ix2 = ix / valuesPerSectorXDir;

			if (pSectorDataArray[ix2 + iy2] < 1.0f)
			{
				continue;
			}

			//numOfDetectionTests++;

			if (pDetectionNeuron->Set_Dendrite_NeuronInput_UseCenterPos(ix, iy, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY) == true)
			{
				pDetectionNeuron->Calculate_NeuronOutput();

				if (pDetectionNeuron->ActivationValue > minActivationValue)
				{
					pOutPatternPosXArray[patternCounter] = ix;
					pOutPatternPosYArray[patternCounter] = iy;

					patternCounter++;
					patternCounter = min(patternCounter, numPatternPositionsMaxMinus1);
				}
			}
		}
	}

	*pOutPatternCount = patternCounter;

	//std::cout << "numOfDetectionTests: " << numOfDetectionTests << std::endl;
}

void Search_Pattern(CSimpleFeatureMap *pFeatureMap, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CSimpleNeuron *pSectorExaminationNeuron, CSimpleNeuron *pDetectionNeuron, bool addValuesToFeatureMap)
{
	int32_t localReceptiveFieldSizeX = pDetectionNeuron->LocalReceptiveFieldSizeX;
	int32_t localReceptiveFieldSizeY = pDetectionNeuron->LocalReceptiveFieldSizeY;

	int32_t firstOutputDendriteID = pSectorExaminationNeuron->FirstOutputDendriteID;
	int32_t numOfSectorsXDir = pSectorExaminationNeuron->NumOfOutputDendritesXDir;
	int32_t numOfSectorsYDir = pSectorExaminationNeuron->NumOfOutputDendritesYDir;

	int32_t valuesPerSectorXDir = inputMapSizeX / numOfSectorsXDir;
	int32_t valuesPerSectorYDir = inputMapSizeY / numOfSectorsYDir;

	float *pSectorDataArray = &pSectorExaminationNeuron->pDendrite_DataArray[firstOutputDendriteID];

	int32_t ix2, iy2;

	//int32_t numOfDetectionTests = 0;

	if (addValuesToFeatureMap == false)
	{
		for (int32_t iy = minPosY; iy < maxPosYPlus1; iy += strideY)
		{
			iy2 = iy / valuesPerSectorYDir;
			iy2 *= numOfSectorsXDir;

			for (int32_t ix = minPosX; ix < maxPosXPlus1; ix += strideX)
			{
				ix2 = ix / valuesPerSectorXDir;

				if (pSectorDataArray[ix2 + iy2] < 1.0f)
				{
					continue;
				}

				//numOfDetectionTests++;

				if (pDetectionNeuron->Set_Dendrite_NeuronInput_UseCenterPos(ix, iy, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY) == true)
				{
					pDetectionNeuron->Calculate_NeuronOutput();

					pFeatureMap->pDataArray[ix + inputMapSizeX * iy] = pDetectionNeuron->ActivationValue;
				}
			}
		}
	}
	else if (addValuesToFeatureMap == true)
	{
		for (int32_t iy = minPosY; iy < maxPosYPlus1; iy += strideY)
		{
			iy2 = iy / valuesPerSectorYDir;
			iy2 *= numOfSectorsXDir;

			for (int32_t ix = minPosX; ix < maxPosXPlus1; ix += strideX)
			{
				ix2 = ix / valuesPerSectorXDir;

				if (pSectorDataArray[ix2 + iy2] < 1.0f)
				{
					continue;
				}

				//numOfDetectionTests++;

				if (pDetectionNeuron->Set_Dendrite_NeuronInput_UseCenterPos(ix, iy, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY) == true)
				{
					pDetectionNeuron->Calculate_NeuronOutput();

					pFeatureMap->pDataArray[ix + inputMapSizeX * iy] += pDetectionNeuron->ActivationValue;
				}
			}
		}
	}

	//std::cout << "numOfDetectionTests: " << numOfDetectionTests << std::endl;
}

void Search_Patterns(CSimpleFeatureMap *pFeatureMapArray, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CSimpleNeuron *pSectorExaminationNeuron, CSimpleNeuron *pDetectionNeuronArray, int32_t numPatterns, bool addValuesToFeatureMap)
{
	int32_t firstOutputDendriteID = pSectorExaminationNeuron->FirstOutputDendriteID;
	int32_t numOfSectorsXDir = pSectorExaminationNeuron->NumOfOutputDendritesXDir;
	int32_t numOfSectorsYDir = pSectorExaminationNeuron->NumOfOutputDendritesYDir;

	int32_t valuesPerSectorXDir = inputMapSizeX / numOfSectorsXDir;
	int32_t valuesPerSectorYDir = inputMapSizeY / numOfSectorsYDir;

	float *pSectorDataArray = &pSectorExaminationNeuron->pDendrite_DataArray[firstOutputDendriteID];

	int32_t ix2, iy2;

	if (addValuesToFeatureMap == false)
	{
		for (int32_t i = 0; i < numPatterns; i++)
		{
			int32_t localReceptiveFieldSizeX = pDetectionNeuronArray[i].LocalReceptiveFieldSizeX;
			int32_t localReceptiveFieldSizeY = pDetectionNeuronArray[i].LocalReceptiveFieldSizeY;

			for (int32_t iy = minPosY; iy < maxPosYPlus1; iy += strideY)
			{
				iy2 = iy / valuesPerSectorYDir;
				iy2 *= numOfSectorsXDir;

				for (int32_t ix = minPosX; ix < maxPosXPlus1; ix += strideX)
				{
					ix2 = ix / valuesPerSectorXDir;

					if (pSectorDataArray[ix2 + iy2] < 1.0f)
					{
						continue;
					}

					if (pDetectionNeuronArray[i].Set_Dendrite_NeuronInput_UseCenterPos(ix, iy, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY) == true)
					{
						pDetectionNeuronArray[i].Calculate_NeuronOutput();

						pFeatureMapArray[i].pDataArray[ix + inputMapSizeX * iy] = pDetectionNeuronArray[i].ActivationValue;
					}
				}
			}
		}
	}
	else if (addValuesToFeatureMap == true)
	{
		for (int32_t i = 0; i < numPatterns; i++)
		{
			int32_t localReceptiveFieldSizeX = pDetectionNeuronArray[i].LocalReceptiveFieldSizeX;
			int32_t localReceptiveFieldSizeY = pDetectionNeuronArray[i].LocalReceptiveFieldSizeY;

			for (int32_t iy = minPosY; iy < maxPosYPlus1; iy += strideY)
			{
				iy2 = iy / valuesPerSectorYDir;
				iy2 *= numOfSectorsXDir;

				for (int32_t ix = minPosX; ix < maxPosXPlus1; ix += strideX)
				{
					ix2 = ix / valuesPerSectorXDir;

					if (pSectorDataArray[ix2 + iy2] < 1.0f)
					{
						continue;
					}

					//numOfDetectionTests++;

					if (pDetectionNeuronArray[i].Set_Dendrite_NeuronInput_UseCenterPos(ix, iy, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY) == true)
					{
						pDetectionNeuronArray[i].Calculate_NeuronOutput();

						pFeatureMapArray[i].pDataArray[ix + inputMapSizeX * iy] += pDetectionNeuronArray[i].ActivationValue;
					}
				}
			}
		}
	}
}

void Search_Pattern(float *pOutPatternCount, float *pOutPatternPosXArray, float *pOutPatternPosYArray, int32_t numPatternPositionsMax, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CSimpleNeuron *pSectorExaminationNeuron, CSimpleNeuron *pDetectionNeuron, float minActivationValue)
{
	int32_t numPatternPositionsMaxMinus1 = numPatternPositionsMax - 1;

	int32_t localReceptiveFieldSizeX = pDetectionNeuron->LocalReceptiveFieldSizeX;
	int32_t localReceptiveFieldSizeY = pDetectionNeuron->LocalReceptiveFieldSizeY;

	int32_t patternCounter = 0;

	int32_t firstOutputDendriteID = pSectorExaminationNeuron->FirstOutputDendriteID;
	int32_t numOfSectorsXDir = pSectorExaminationNeuron->NumOfOutputDendritesXDir;
	int32_t numOfSectorsYDir = pSectorExaminationNeuron->NumOfOutputDendritesYDir;

	int32_t valuesPerSectorXDir = inputMapSizeX / numOfSectorsXDir;
	int32_t valuesPerSectorYDir = inputMapSizeY / numOfSectorsYDir;

	float *pSectorDataArray = &pSectorExaminationNeuron->pDendrite_DataArray[firstOutputDendriteID];

	int32_t ix2, iy2;

	//int32_t numOfDetectionTests = 0;

	for (int32_t iy = minPosY; iy < maxPosYPlus1; iy += strideY)
	{
		iy2 = iy / valuesPerSectorYDir;
		iy2 *= numOfSectorsXDir;

		for (int32_t ix = minPosX; ix < maxPosXPlus1; ix += strideX)
		{
			ix2 = ix / valuesPerSectorXDir;

			if (pSectorDataArray[ix2 + iy2] < 1.0f)
			{
				continue;
			}

			//numOfDetectionTests++;

			if (pDetectionNeuron->Set_Dendrite_NeuronInput_UseCenterPos(ix, iy, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY) == true)
			{
				pDetectionNeuron->Calculate_NeuronOutput();

				if (pDetectionNeuron->ActivationValue > minActivationValue)
				{
					pOutPatternPosXArray[patternCounter] = static_cast<float>(ix);
					pOutPatternPosYArray[patternCounter] = static_cast<float>(iy);

					patternCounter++;
					patternCounter = min(patternCounter, numPatternPositionsMaxMinus1);
				}
			}
		}
	}

	*pOutPatternCount = static_cast<float>(patternCounter);

	//std::cout << "numOfDetectionTests: " << numOfDetectionTests << std::endl;
}

void Search_Pattern(int32_t *pOutPatternCount, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CSimpleNeuron *pSectorExaminationNeuron, CSimpleNeuron *pDetectionNeuron, float minActivationValue)
{
	int32_t localReceptiveFieldSizeX = pDetectionNeuron->LocalReceptiveFieldSizeX;
	int32_t localReceptiveFieldSizeY = pDetectionNeuron->LocalReceptiveFieldSizeY;

	int32_t patternCounter = 0;

	int32_t firstOutputDendriteID = pSectorExaminationNeuron->FirstOutputDendriteID;
	int32_t numOfSectorsXDir = pSectorExaminationNeuron->NumOfOutputDendritesXDir;
	int32_t numOfSectorsYDir = pSectorExaminationNeuron->NumOfOutputDendritesYDir;

	int32_t valuesPerSectorXDir = inputMapSizeX / numOfSectorsXDir;
	int32_t valuesPerSectorYDir = inputMapSizeY / numOfSectorsYDir;

	float *pSectorDataArray = &pSectorExaminationNeuron->pDendrite_DataArray[firstOutputDendriteID];

	int32_t ix2, iy2;

	//int32_t numOfDetectionTests = 0;

	for (int32_t iy = minPosY; iy < maxPosYPlus1; iy += strideY)
	{
		iy2 = iy / valuesPerSectorYDir;
		iy2 *= numOfSectorsXDir;

		for (int32_t ix = minPosX; ix < maxPosXPlus1; ix += strideX)
		{
			ix2 = ix / valuesPerSectorXDir;

			if (pSectorDataArray[ix2 + iy2] < 1.0f)
			{
				continue;
			}

			//numOfDetectionTests++;

			if (pDetectionNeuron->Set_Dendrite_NeuronInput_UseCenterPos(ix, iy, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY) == true)
			{
				pDetectionNeuron->Calculate_NeuronOutput();

				if (pDetectionNeuron->ActivationValue > minActivationValue)
				{
					patternCounter++;
				}
			}
		}
	}

	*pOutPatternCount = patternCounter;

	//std::cout << "numOfDetectionTests: " << numOfDetectionTests << std::endl;
}

void Search_Pattern(float *pOutPatternCount, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CSimpleNeuron *pSectorExaminationNeuron, CSimpleNeuron *pDetectionNeuron, float minActivationValue)
{
	int32_t localReceptiveFieldSizeX = pDetectionNeuron->LocalReceptiveFieldSizeX;
	int32_t localReceptiveFieldSizeY = pDetectionNeuron->LocalReceptiveFieldSizeY;

	int32_t patternCounter = 0;

	int32_t firstOutputDendriteID = pSectorExaminationNeuron->FirstOutputDendriteID;
	int32_t numOfSectorsXDir = pSectorExaminationNeuron->NumOfOutputDendritesXDir;
	int32_t numOfSectorsYDir = pSectorExaminationNeuron->NumOfOutputDendritesYDir;

	int32_t valuesPerSectorXDir = inputMapSizeX / numOfSectorsXDir;
	int32_t valuesPerSectorYDir = inputMapSizeY / numOfSectorsYDir;

	float *pSectorDataArray = &pSectorExaminationNeuron->pDendrite_DataArray[firstOutputDendriteID];

	int32_t ix2, iy2;

	//int32_t numOfDetectionTests = 0;

	for (int32_t iy = minPosY; iy < maxPosYPlus1; iy += strideY)
	{
		iy2 = iy / valuesPerSectorYDir;
		iy2 *= numOfSectorsXDir;

		for (int32_t ix = minPosX; ix < maxPosXPlus1; ix += strideX)
		{
			ix2 = ix / valuesPerSectorXDir;

			if (pSectorDataArray[ix2 + iy2] < 1.0f)
			{
				continue;
			}

			//numOfDetectionTests++;

			if (pDetectionNeuron->Set_Dendrite_NeuronInput_UseCenterPos(ix, iy, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY) == true)
			{
				pDetectionNeuron->Calculate_NeuronOutput();

				if (pDetectionNeuron->ActivationValue > minActivationValue)
				{
					patternCounter++;
				}
			}
		}
	}

	*pOutPatternCount = static_cast<float>(patternCounter);

	//std::cout << "numOfDetectionTests: " << numOfDetectionTests << std::endl;
}


void Search_Pattern(int32_t *pOutPatternCount, float *pOutValueSum, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CSimpleNeuron *pSectorExaminationNeuron, CSimpleNeuron *pDetectionNeuron, float minActivationValue)
{
	int32_t localReceptiveFieldSizeX = pDetectionNeuron->LocalReceptiveFieldSizeX;
	int32_t localReceptiveFieldSizeY = pDetectionNeuron->LocalReceptiveFieldSizeY;

	int32_t patternCounter = 0;
	float valueSum = 0.0f;

	int32_t firstOutputDendriteID = pSectorExaminationNeuron->FirstOutputDendriteID;
	int32_t numOfSectorsXDir = pSectorExaminationNeuron->NumOfOutputDendritesXDir;
	int32_t numOfSectorsYDir = pSectorExaminationNeuron->NumOfOutputDendritesYDir;

	int32_t valuesPerSectorXDir = inputMapSizeX / numOfSectorsXDir;
	int32_t valuesPerSectorYDir = inputMapSizeY / numOfSectorsYDir;

	float *pSectorDataArray = &pSectorExaminationNeuron->pDendrite_DataArray[firstOutputDendriteID];

	int32_t ix2, iy2;

	//int32_t numOfDetectionTests = 0;

	for (int32_t iy = minPosY; iy < maxPosYPlus1; iy += strideY)
	{
		iy2 = iy / valuesPerSectorYDir;
		iy2 *= numOfSectorsXDir;

		for (int32_t ix = minPosX; ix < maxPosXPlus1; ix += strideX)
		{
			ix2 = ix / valuesPerSectorXDir;

			if (pSectorDataArray[ix2 + iy2] < 1.0f)
			{
				continue;
			}

			//numOfDetectionTests++;

			if (pDetectionNeuron->Set_Dendrite_NeuronInput_UseCenterPos(ix, iy, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY) == true)
			{
				pDetectionNeuron->Calculate_NeuronOutput();

				if (pDetectionNeuron->ActivationValue > minActivationValue)
				{
					patternCounter++;
					valueSum += pDetectionNeuron->ActivationValue;
				}
			}
		}
	}

	*pOutPatternCount = patternCounter;
	*pOutValueSum = valueSum;

	//std::cout << "numOfDetectionTests: " << numOfDetectionTests << std::endl;
}

void Search_Pattern(float *pOutPatternCount, float *pOutValueSum, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1, CSimpleNeuron *pSectorExaminationNeuron, CSimpleNeuron *pDetectionNeuron, float minActivationValue)
{
	int32_t localReceptiveFieldSizeX = pDetectionNeuron->LocalReceptiveFieldSizeX;
	int32_t localReceptiveFieldSizeY = pDetectionNeuron->LocalReceptiveFieldSizeY;

	int32_t patternCounter = 0;
	float valueSum = 0.0f;

	int32_t firstOutputDendriteID = pSectorExaminationNeuron->FirstOutputDendriteID;
	int32_t numOfSectorsXDir = pSectorExaminationNeuron->NumOfOutputDendritesXDir;
	int32_t numOfSectorsYDir = pSectorExaminationNeuron->NumOfOutputDendritesYDir;

	int32_t valuesPerSectorXDir = inputMapSizeX / numOfSectorsXDir;
	int32_t valuesPerSectorYDir = inputMapSizeY / numOfSectorsYDir;

	float *pSectorDataArray = &pSectorExaminationNeuron->pDendrite_DataArray[firstOutputDendriteID];

	int32_t ix2, iy2;

	//int32_t numOfDetectionTests = 0;

	for (int32_t iy = minPosY; iy < maxPosYPlus1; iy += strideY)
	{
		iy2 = iy / valuesPerSectorYDir;
		iy2 *= numOfSectorsXDir;

		for (int32_t ix = minPosX; ix < maxPosXPlus1; ix += strideX)
		{
			ix2 = ix / valuesPerSectorXDir;

			if (pSectorDataArray[ix2 + iy2] < 1.0f)
			{
				continue;
			}

			//numOfDetectionTests++;

			if (pDetectionNeuron->Set_Dendrite_NeuronInput_UseCenterPos(ix, iy, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY) == true)
			{
				pDetectionNeuron->Calculate_NeuronOutput();

				if (pDetectionNeuron->ActivationValue > minActivationValue)
				{
					patternCounter++;
					valueSum += pDetectionNeuron->ActivationValue;
				}
			}
		}
	}

	*pOutPatternCount = static_cast<float>(patternCounter);
	*pOutValueSum = valueSum;

	//std::cout << "numOfDetectionTests: " << numOfDetectionTests << std::endl;
}



CSingleRecognitionNeuronEnsemble::CSingleRecognitionNeuronEnsemble()
{
}

CSingleRecognitionNeuronEnsemble::~CSingleRecognitionNeuronEnsemble()
{
	delete[] pNeuronArray;
	pNeuronArray = nullptr;

	delete[] pActivationValueArray;
	pActivationValueArray = nullptr;
}

bool CSingleRecognitionNeuronEnsemble::Load_Dendrite_Values(const char* pFilename)
{
	std::ifstream ReadFile;

	// eine existierende Datei zum Lesen �ffnen:
	ReadFile.open(pFilename);

	if (ReadFile.good() == false)
		return false;

	ReadFile >> NumOfUsedMemoryNeurons;

	int32_t numOfDendriteElements = pNeuronArray[0].NumOfDendriteElements;

	CSimpleNeuron *pNeuron = nullptr;

	for (int32_t i = 0; i < NumOfUsedMemoryNeurons; i++)
	{
		pNeuron = &pNeuronArray[i];

		for (int32_t j = 0; j < numOfDendriteElements; j++)
		{
			ReadFile >> pNeuron->pDendrite_CentroidValueArray[j];
			ReadFile >> pNeuron->pDendrite_FactorArray[j];
		}
	}

	ReadFile.close();

	return true;
}

bool CSingleRecognitionNeuronEnsemble::Load_Dendrite_Factors(const char* pFilename)
{
	std::ifstream ReadFile;

	// eine existierende Datei zum Lesen �ffnen:
	ReadFile.open(pFilename);

	if (ReadFile.good() == false)
		return false;

	ReadFile >> NumOfUsedMemoryNeurons;

	int32_t numOfDendriteElements = pNeuronArray[0].NumOfDendriteElements;

	CSimpleNeuron *pNeuron = nullptr;

	for (int32_t i = 0; i < NumOfUsedMemoryNeurons; i++)
	{
		pNeuron = &pNeuronArray[i];

		for (int32_t j = 0; j < numOfDendriteElements; j++)
		{
			//ReadFile >> pNeuron->pDendrite_CentroidValueArray[j];
			ReadFile >> pNeuron->pDendrite_FactorArray[j];
		}
	}

	ReadFile.close();

	return true;
}

bool CSingleRecognitionNeuronEnsemble::Load_Dendrite_Centroids(const char* pFilename)
{
	std::ifstream ReadFile;

	// eine existierende Datei zum Lesen �ffnen:
	ReadFile.open(pFilename);

	if (ReadFile.good() == false)
		return false;

	ReadFile >> NumOfUsedMemoryNeurons;

	int32_t numOfDendriteElements = pNeuronArray[0].NumOfDendriteElements;

	CSimpleNeuron *pNeuron = nullptr;

	for (int32_t i = 0; i < NumOfUsedMemoryNeurons; i++)
	{
		pNeuron = &pNeuronArray[i];

		for (int32_t j = 0; j < numOfDendriteElements; j++)
		{
			ReadFile >> pNeuron->pDendrite_CentroidValueArray[j];
			//ReadFile >> pNeuron->pDendrite_FactorArray[j];
		}
	}

	ReadFile.close();

	return true;
}

bool CSingleRecognitionNeuronEnsemble::Load_AdditionalMemoryValues(const char* pFilename)
{
	std::ifstream ReadFile;

	// eine existierende Datei zum Lesen �ffnen:
	ReadFile.open(pFilename);

	if (ReadFile.good() == false)
		return false;

	ReadFile >> NumOfUsedMemoryNeurons;

	NumOfUsedMemoryNeurons = min(NumOfNeurons, NumOfUsedMemoryNeurons);
	
	int32_t numOfAdditionalMemoryValues = pNeuronArray[0].NumOfAdditionalMemoryValues;

	CSimpleNeuron *pNeuron = nullptr;

	for (int32_t i = 0; i < NumOfUsedMemoryNeurons; i++)
	{
		pNeuron = &pNeuronArray[i];

		for (int32_t j = 0; j < numOfAdditionalMemoryValues; j++)
		{
			ReadFile >> pNeuron->pAdditionalMemoryValueArray[j];
		}
	}

	ReadFile.close();

	return true;
}

bool CSingleRecognitionNeuronEnsemble::Save_Dendrite_Values(const char* pFilename)
{
	std::ofstream WriteFile;

	// neue Datei erzeugen bzw. alte �berschreiben:
	WriteFile.open(pFilename);

	// neue Datei erzeugen bzw. Inhalt ans Ende einer bestehenden Datei schreiben: 
	//WriteFile.open(pFilename, ios::app);

	if (WriteFile.good() == false)
		return false;

	WriteFile << NumOfUsedMemoryNeurons << "  ";

	int32_t numOfDendriteElements = pNeuronArray[0].NumOfDendriteElements;

	CSimpleNeuron *pNeuron = nullptr;

	for (int32_t i = 0; i < NumOfUsedMemoryNeurons; i++)
	{
		pNeuron = &pNeuronArray[i];

		for (int32_t j = 0; j < numOfDendriteElements; j++)
		{
			WriteFile << pNeuron->pDendrite_CentroidValueArray[j] << "  ";
			WriteFile << pNeuron->pDendrite_FactorArray[j] << "  ";
		}
	}

	WriteFile.close();

	return true;
}

bool CSingleRecognitionNeuronEnsemble::Save_Dendrite_Factors(const char* pFilename)
{
	std::ofstream WriteFile;

	// neue Datei erzeugen bzw. alte �berschreiben:
	WriteFile.open(pFilename);

	// neue Datei erzeugen bzw. Inhalt ans Ende einer bestehenden Datei schreiben: 
	//WriteFile.open(pFilename, ios::app);

	if (WriteFile.good() == false)
		return false;

	WriteFile << NumOfUsedMemoryNeurons << "  ";

	int32_t numOfDendriteElements = pNeuronArray[0].NumOfDendriteElements;

	CSimpleNeuron *pNeuron = nullptr;

	for (int32_t i = 0; i < NumOfUsedMemoryNeurons; i++)
	{
		pNeuron = &pNeuronArray[i];

		for (int32_t j = 0; j < numOfDendriteElements; j++)
		{
			//WriteFile << pNeuron->pDendrite_CentroidValueArray[j] << "  ";
			WriteFile << pNeuron->pDendrite_FactorArray[j] << "  ";
		}
	}

	WriteFile.close();

	return true;
}

bool CSingleRecognitionNeuronEnsemble::Save_Dendrite_Centroids(const char* pFilename)
{
	std::ofstream WriteFile;

	// neue Datei erzeugen bzw. alte �berschreiben:
	WriteFile.open(pFilename);

	// neue Datei erzeugen bzw. Inhalt ans Ende einer bestehenden Datei schreiben: 
	//WriteFile.open(pFilename, ios::app);

	if (WriteFile.good() == false)
		return false;

	WriteFile << NumOfUsedMemoryNeurons << "  ";

	int32_t numOfDendriteElements = pNeuronArray[0].NumOfDendriteElements;

	CSimpleNeuron *pNeuron = nullptr;

	for (int32_t i = 0; i < NumOfUsedMemoryNeurons; i++)
	{
		pNeuron = &pNeuronArray[i];

		for (int32_t j = 0; j < numOfDendriteElements; j++)
		{
			WriteFile << pNeuron->pDendrite_CentroidValueArray[j] << "  ";
			//WriteFile << pNeuron->pDendrite_FactorArray[j] << "  ";
		}
	}

	WriteFile.close();

	return true;
}

bool CSingleRecognitionNeuronEnsemble::Save_AdditionalMemoryValues(const char* pFilename)
{
	std::ofstream WriteFile;

	// neue Datei erzeugen bzw. alte �berschreiben:
	WriteFile.open(pFilename);

	// neue Datei erzeugen bzw. Inhalt ans Ende einer bestehenden Datei schreiben: 
	//WriteFile.open(pFilename, ios::app);

	if (WriteFile.good() == false)
		return false;

	WriteFile << NumOfUsedMemoryNeurons << "  ";

	int32_t numOfAdditionalMemoryValues = pNeuronArray[0].NumOfAdditionalMemoryValues;

	CSimpleNeuron *pNeuron = nullptr;

	for (int32_t i = 0; i < NumOfUsedMemoryNeurons; i++)
	{
		pNeuron = &pNeuronArray[i];

		for (int32_t j = 0; j < numOfAdditionalMemoryValues; j++)
		{
			WriteFile << pNeuron->pAdditionalMemoryValueArray[j] << "  ";
		}
	}

	WriteFile.close();

	return true;
}

void CSingleRecognitionNeuronEnsemble::Init_NeuronArray(int32_t numOfNeurons, int32_t numOfDendriteElements, int32_t numOfAdditionalMemoryValues, pActivationFunction pFunc)
{
	if (numOfNeurons > NumOfNeurons)
	{
		delete[] pNeuronArray;
		pNeuronArray = nullptr;

		delete[] pActivationValueArray;
		pActivationValueArray = nullptr;

		pNeuronArray = new (std::nothrow) CSimpleNeuron[numOfNeurons];

		pActivationValueArray = new (std::nothrow) float[numOfNeurons];
	}

	NumOfNeurons = numOfNeurons;

	/*if (numOfDendriteElements > 0)
	{
		for (int32_t i = 0; i < numOfNeurons; i++)
		{
			pNeuronArray[i].Init_Dendrite_Arrays(numOfDendriteElements);
			pNeuronArray[i].Set_ActivationFunction(pFunc);
		}
	}*/

	if (numOfDendriteElements > 0)
	{
		for (int32_t i = 0; i < numOfNeurons; i++)
		{
			pNeuronArray[i].Init_Dendrite_Arrays(numOfDendriteElements);
		}
	}

	for (int32_t i = 0; i < numOfNeurons; i++)
	{
		pNeuronArray[i].Set_ActivationFunction(pFunc);
	}

	if (numOfAdditionalMemoryValues > 0)
	{
		for (int32_t i = 0; i < numOfNeurons; i++)
		{
			pNeuronArray[i].Init_AdditionalMemoryValues(numOfAdditionalMemoryValues);
		}
	}
}
void CSingleRecognitionNeuronEnsemble::Init_NeuronArray(int32_t numOfNeurons, int32_t numOfDendriteElements, pActivationFunction pFunc)
{
	if (numOfNeurons > NumOfNeurons)
	{
		delete[] pNeuronArray;
		pNeuronArray = nullptr;

		delete[] pActivationValueArray;
		pActivationValueArray = nullptr;

		pNeuronArray = new (std::nothrow) CSimpleNeuron[numOfNeurons];

		pActivationValueArray = new (std::nothrow) float[numOfNeurons];
	}

	NumOfNeurons = numOfNeurons;

	if (numOfDendriteElements > 0)
	{
		for (int32_t i = 0; i < numOfNeurons; i++)
		{
			pNeuronArray[i].Init_Dendrite_Arrays(numOfDendriteElements);
		}
	}

	for (int32_t i = 0; i < numOfNeurons; i++)
	{
		pNeuronArray[i].Set_ActivationFunction(pFunc);
	}
}

void CSingleRecognitionNeuronEnsemble::Reset_NumOfUsedMemoryNeurons(void)
{
	NumOfUsedMemoryNeurons = 0;
}

bool CSingleRecognitionNeuronEnsemble::Set_AdditionalMemoryValues(float *pMemoryValueArray)
{
	//pNeuronArray[NumOfUsedMemoryNeurons].Set_AdditionalMemoryValues(pMemoryValueArray);
	//NumOfUsedMemoryNeurons++;

	int32_t maxIDPlus1 = min(NumOfUsedMemoryNeurons, NumOfNeurons);

	for (int32_t i = 0; i < maxIDPlus1; i++)
	{
		if (pNeuronArray[i].Compare_DataWithMemory(pMemoryValueArray) == true)
		{
			return false;
		}
	}

	pNeuronArray[NumOfUsedMemoryNeurons % NumOfNeurons].Set_AdditionalMemoryValues(pMemoryValueArray);
	NumOfUsedMemoryNeurons++;

	return true;
}

int32_t CSingleRecognitionNeuronEnsemble::Compare_DataWithMemory(float *pDataArray)
{
	if (NumOfUsedMemoryNeurons == 0)
		return -1;

	int32_t maxIDPlus1 = min(NumOfUsedMemoryNeurons, NumOfNeurons);

	for (int32_t i = 0; i < maxIDPlus1; i++)
	{ 
		if (pNeuronArray[i].Compare_DataWithMemory(pDataArray) == true)
		{
			return i;
		}
	}

	return -1;
}

void CSingleRecognitionNeuronEnsemble::Reset_NumOfTrainingExamples(void)
{
	for (int32_t i = 0; i < NumOfNeurons; i++)
	{
		pNeuronArray[i].Reset_NumOfTrainingExamples();
	}
}



void CSingleRecognitionNeuronEnsemble::Reset_NumOfTrainingExamples(int32_t minNeuronID, int32_t maxNeuronID)
{
	maxNeuronID++;

	for (int32_t i = minNeuronID; i < maxNeuronID; i++)
	{
		pNeuronArray[i].Reset_NumOfTrainingExamples();
	}
}


int32_t CSingleRecognitionNeuronEnsemble::Get_ID_Of_MinimumTrainedNeuron(void)
{
	int32_t minTrainingExamples = 1000000;
	int32_t belongingNeuronID = 0;

	for (int32_t i = 0; i < NumOfNeurons; i++)
	{
		if (minTrainingExamples > pNeuronArray[i].NumOfTrainingExamples)
		{
			minTrainingExamples = pNeuronArray[i].NumOfTrainingExamples;
			belongingNeuronID = i;
		}
	}

	return belongingNeuronID;
}

int32_t CSingleRecognitionNeuronEnsemble::Get_ID_Of_MinimumTrainedNeuron(int32_t minNeuronID, int32_t maxNeuronID)
{
	maxNeuronID++;

	int32_t minTrainingExamples = 1000000;
	int32_t belongingNeuronID = 0;

	for (int32_t i = minNeuronID; i < maxNeuronID; i++)
	{
		if (minTrainingExamples > pNeuronArray[i].NumOfTrainingExamples)
		{
			minTrainingExamples = pNeuronArray[i].NumOfTrainingExamples;
			belongingNeuronID = i;
		}
	}

	return belongingNeuronID;
}

int32_t CSingleRecognitionNeuronEnsemble::Get_ID_Of_MaximumTrainedNeuron(void)
{
	int32_t maxTrainingExamples = 0;
	int32_t belongingNeuronID = 0;

	for (int32_t i = 0; i < NumOfNeurons; i++)
	{
		if (maxTrainingExamples < pNeuronArray[i].NumOfTrainingExamples)
		{
			maxTrainingExamples = pNeuronArray[i].NumOfTrainingExamples;
			belongingNeuronID = i;
		}
	}

	return belongingNeuronID;
}

int32_t CSingleRecognitionNeuronEnsemble::Get_ID_Of_MaximumTrainedNeuron(int32_t minNeuronID, int32_t maxNeuronID)
{
	maxNeuronID++;

	int32_t maxTrainingExamples = 0;
	int32_t belongingNeuronID = 0;

	for (int32_t i = minNeuronID; i < maxNeuronID; i++)
	{
		if (maxTrainingExamples < pNeuronArray[i].NumOfTrainingExamples)
		{
			maxTrainingExamples = pNeuronArray[i].NumOfTrainingExamples;
			belongingNeuronID = i;
		}
	}

	return belongingNeuronID;
}



void CSingleRecognitionNeuronEnsemble::Calculate_NeuronOutputs(void)
{
	for (int32_t i = 0; i < NumOfNeurons; i++)
	{
		pNeuronArray[i].Calculate_NeuronOutput();
		pActivationValueArray[i] = pNeuronArray[i].ActivationValue;
	}
}

void CSingleRecognitionNeuronEnsemble::Calculate_NeuronOutputs_Ext(void)
{
	for (int32_t i = 0; i < NumOfNeurons; i++)
	{
		pNeuronArray[i].Calculate_NeuronOutput_Ext();
		pActivationValueArray[i] = pNeuronArray[i].ActivationValue;
	}
}

void CSingleRecognitionNeuronEnsemble::Calculate_NeuronOutputs(int32_t minNeuronID, int32_t maxNeuronID)
{
	maxNeuronID++;

	for (int32_t i = minNeuronID; i < maxNeuronID; i++)
	{
		pNeuronArray[i].Calculate_NeuronOutput();
		pActivationValueArray[i] = pNeuronArray[i].ActivationValue;
	}
}

void CSingleRecognitionNeuronEnsemble::Calculate_NeuronOutputs_Ext(int32_t minNeuronID, int32_t maxNeuronID)
{
	maxNeuronID++;

	for (int32_t i = minNeuronID; i < maxNeuronID; i++)
	{
		pNeuronArray[i].Calculate_NeuronOutput_Ext();
		pActivationValueArray[i] = pNeuronArray[i].ActivationValue;
	}
}

void CSingleRecognitionNeuronEnsemble::Set_Dendrite_NeuronInput(int32_t posX_left, int32_t posY_top, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY)
{
	for (int32_t i = 0; i < NumOfNeurons; i++)
	{
		pNeuronArray[i].Set_Dendrite_NeuronInput(posX_left, posY_top, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY);
	}
}

void CSingleRecognitionNeuronEnsemble::Set_Dendrite_NeuronInput_UseCenterPos(int32_t posX_center, int32_t posY_center, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY)
{
	int32_t posX_left = posX_center - localReceptiveFieldSizeX / 2;
	int32_t posY_top = posY_center - localReceptiveFieldSizeY / 2;

	for (int32_t i = 0; i < NumOfNeurons; i++)
	{
		pNeuronArray[i].Set_Dendrite_NeuronInput(posX_left, posY_top, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY);
	}
}

void CSingleRecognitionNeuronEnsemble::Set_Dendrite_NeuronInput(int32_t posX_left, int32_t posY_top, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, int32_t minNeuronID, int32_t maxNeuronID)
{
	maxNeuronID++;

	for (int32_t i = minNeuronID; i < maxNeuronID; i++)
	{
		pNeuronArray[i].Set_Dendrite_NeuronInput(posX_left, posY_top, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY);
	}
}

void CSingleRecognitionNeuronEnsemble::Set_Dendrite_NeuronInput_UseCenterPos(int32_t posX_center, int32_t posY_center, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, int32_t minNeuronID, int32_t maxNeuronID)
{
	maxNeuronID++;

	int32_t posX_left = posX_center - localReceptiveFieldSizeX / 2;
	int32_t posY_top = posY_center - localReceptiveFieldSizeY / 2;

	for (int32_t i = minNeuronID; i < maxNeuronID; i++)
	{
		pNeuronArray[i].Set_Dendrite_NeuronInput(posX_left, posY_top, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY);
	}
}

void CSingleRecognitionNeuronEnsemble::Get_MaxActivationValue(float *pOutActivationValue, int32_t *pOutBelongingNeuronID)
{
	float maxActivationValue = -1000000.0f;
	int32_t belongingNeuronID = 0;

	for (int32_t i = 0; i < NumOfNeurons; i++)
	{
		if (maxActivationValue < pActivationValueArray[i])
		{
			maxActivationValue = pActivationValueArray[i];
			belongingNeuronID = i;
		}
	}

	*pOutActivationValue = maxActivationValue;
	*pOutBelongingNeuronID = belongingNeuronID;
}

void CSingleRecognitionNeuronEnsemble::Get_MinActivationValue(float *pOutActivationValue, int32_t *pOutBelongingNeuronID)
{
	float minActivationValue = 1000000.0f;
	int32_t belongingNeuronID = 0;

	for (int32_t i = 0; i < NumOfNeurons; i++)
	{
		if (minActivationValue > pActivationValueArray[i])
		{
			minActivationValue = pActivationValueArray[i];
			belongingNeuronID = i;
		}
	}

	*pOutActivationValue = minActivationValue;
	*pOutBelongingNeuronID = belongingNeuronID;
}

void CSingleRecognitionNeuronEnsemble::Get_MaxActivationValue(float *pOutActivationValue, int32_t *pOutBelongingNeuronID, int32_t minNeuronID, int32_t maxNeuronID)
{
	maxNeuronID++;
	float maxActivationValue = -1000000.0f;
	int32_t belongingNeuronID = 0;

	for (int32_t i = minNeuronID; i < maxNeuronID; i++)
	{
		if (maxActivationValue < pActivationValueArray[i])
		{
			maxActivationValue = pActivationValueArray[i];
			belongingNeuronID = i;
		}
	}

	*pOutActivationValue = maxActivationValue;
	*pOutBelongingNeuronID = belongingNeuronID;
}

void CSingleRecognitionNeuronEnsemble::Get_MinActivationValue(float *pOutActivationValue, int32_t *pOutBelongingNeuronID, int32_t minNeuronID, int32_t maxNeuronID)
{
	maxNeuronID++;
	float minActivationValue = 1000000.0f;
	int32_t belongingNeuronID = 0;

	for (int32_t i = minNeuronID; i < maxNeuronID; i++)
	{
		if (minActivationValue > pActivationValueArray[i])
		{
			minActivationValue = pActivationValueArray[i];
			belongingNeuronID = i;
		}
	}

	*pOutActivationValue = minActivationValue;
	*pOutBelongingNeuronID = belongingNeuronID;
}


int32_t  CSingleRecognitionNeuronEnsemble::Add_Dendrite_CentroidValues_And_Calculate_Dendrite_Factors_From_CentroidValues(int32_t posX_left, int32_t posY_top, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float fallback_RBF_Factor, float centroidWeightFactor, int32_t centroidExponent, float upperActivationThreshold, float lowerActivationThreshold)
{
	//int32_t IDOfMinimumTrainedNeuron = Get_ID_Of_MinimumTrainedNeuron();

	//pNeuronArray[IDOfMinimumTrainedNeuron].Add_TrainingExample(pInputMap);
	//pNeuronArray[IDOfMinimumTrainedNeuron].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	Set_Dendrite_NeuronInput(posX_left, posY_top, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY);
	Calculate_NeuronOutputs();

	float outActivationValue;
	int32_t outBelongingNeuronID;

	Get_MaxActivationValue(&outActivationValue, &outBelongingNeuronID);

	if (outActivationValue > upperActivationThreshold)
	{
		pNeuronArray[outBelongingNeuronID].Add_TrainingExample(pInputMap);
		pNeuronArray[outBelongingNeuronID].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
		return outBelongingNeuronID;
	}
	else
	{
		if (outActivationValue < lowerActivationThreshold)
		{
			int32_t IDOfMinimumTrainedNeuron = Get_ID_Of_MinimumTrainedNeuron();
			pNeuronArray[IDOfMinimumTrainedNeuron].Add_TrainingExample(pInputMap);
			pNeuronArray[IDOfMinimumTrainedNeuron].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
			return IDOfMinimumTrainedNeuron;
		}
		else
		{
			Get_MinActivationValue(&outActivationValue, &outBelongingNeuronID);
			pNeuronArray[outBelongingNeuronID].Add_TrainingExample(pInputMap);
			pNeuronArray[outBelongingNeuronID].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
			return outBelongingNeuronID;
		}
	}
}



int32_t  CSingleRecognitionNeuronEnsemble::Add_Dendrite_CentroidValues_And_Calculate_Dendrite_Factors_From_CentroidValues_UseCenterPos(int32_t posX_center, int32_t posY_center, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float fallback_RBF_Factor, float centroidWeightFactor, int32_t centroidExponent, float upperActivationThreshold, float lowerActivationThreshold)
{
	//int32_t IDOfMinimumTrainedNeuron = Get_ID_Of_MinimumTrainedNeuron();

	//pNeuronArray[IDOfMinimumTrainedNeuron].Add_TrainingExample(pInputMap);
	//pNeuronArray[IDOfMinimumTrainedNeuron].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	int32_t posX_left = posX_center - localReceptiveFieldSizeX / 2;
	int32_t posY_top = posY_center - localReceptiveFieldSizeY / 2;

	Set_Dendrite_NeuronInput(posX_left, posY_top, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY);
	Calculate_NeuronOutputs();

	float outActivationValue;
	int32_t outBelongingNeuronID;

	Get_MaxActivationValue(&outActivationValue, &outBelongingNeuronID);

	if (outActivationValue > upperActivationThreshold)
	{
		pNeuronArray[outBelongingNeuronID].Add_TrainingExample(pInputMap);
		pNeuronArray[outBelongingNeuronID].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
		return outBelongingNeuronID;
	}
	else
	{
		if (outActivationValue < lowerActivationThreshold)
		{
			int32_t IDOfMinimumTrainedNeuron = Get_ID_Of_MinimumTrainedNeuron();
			pNeuronArray[IDOfMinimumTrainedNeuron].Add_TrainingExample(pInputMap);
			pNeuronArray[IDOfMinimumTrainedNeuron].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
			return IDOfMinimumTrainedNeuron;
		}
		else
		{
			Get_MinActivationValue(&outActivationValue, &outBelongingNeuronID);
			pNeuronArray[outBelongingNeuronID].Add_TrainingExample(pInputMap);
			pNeuronArray[outBelongingNeuronID].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
			return outBelongingNeuronID;
		}
	}
}



int32_t  CSingleRecognitionNeuronEnsemble::Add_Dendrite_CentroidValues_And_Calculate_Dendrite_Factors_From_CentroidValues(int32_t posX_left, int32_t posY_top, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float fallback_RBF_Factor, float centroidWeightFactor, int32_t centroidExponent, int32_t minNeuronID, int32_t maxNeuronID, float upperActivationThreshold, float lowerActivationThreshold)
{
	Set_Dendrite_NeuronInput(posX_left, posY_top, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY, minNeuronID, maxNeuronID);
	Calculate_NeuronOutputs(minNeuronID, maxNeuronID);

	float outActivationValue;
	int32_t outBelongingNeuronID;

	Get_MaxActivationValue(&outActivationValue, &outBelongingNeuronID, minNeuronID, maxNeuronID);

	if (outActivationValue > upperActivationThreshold)
	{
		pNeuronArray[outBelongingNeuronID].Add_TrainingExample(pInputMap);
		pNeuronArray[outBelongingNeuronID].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
		return outBelongingNeuronID;
	}
	else
	{ 
		if (outActivationValue < lowerActivationThreshold)
		{
			int32_t IDOfMinimumTrainedNeuron = Get_ID_Of_MinimumTrainedNeuron(minNeuronID, maxNeuronID);
			pNeuronArray[IDOfMinimumTrainedNeuron].Add_TrainingExample(pInputMap);
			pNeuronArray[IDOfMinimumTrainedNeuron].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
			return IDOfMinimumTrainedNeuron;
		}
		else
		{
			Get_MinActivationValue(&outActivationValue, &outBelongingNeuronID, minNeuronID, maxNeuronID);
			pNeuronArray[outBelongingNeuronID].Add_TrainingExample(pInputMap);
			pNeuronArray[outBelongingNeuronID].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
			return outBelongingNeuronID;
		}
	}
}



int32_t  CSingleRecognitionNeuronEnsemble::Add_Dendrite_CentroidValues_And_Calculate_Dendrite_Factors_From_CentroidValues_UseCenterPos(int32_t posX_center, int32_t posY_center, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, float fallback_RBF_Factor, float centroidWeightFactor, int32_t centroidExponent, int32_t minNeuronID, int32_t maxNeuronID, float upperActivationThreshold, float lowerActivationThreshold)
{
	int32_t posX_left = posX_center - localReceptiveFieldSizeX / 2;
	int32_t posY_top = posY_center - localReceptiveFieldSizeY / 2;

	Set_Dendrite_NeuronInput(posX_left, posY_top, pInputMap, inputMapSizeX, inputMapSizeY, localReceptiveFieldSizeX, localReceptiveFieldSizeY, minNeuronID, maxNeuronID);
	Calculate_NeuronOutputs(minNeuronID, maxNeuronID);

	float outActivationValue;
	int32_t outBelongingNeuronID;

	Get_MaxActivationValue(&outActivationValue, &outBelongingNeuronID, minNeuronID, maxNeuronID);

	if (outActivationValue > upperActivationThreshold)
	{
		pNeuronArray[outBelongingNeuronID].Add_TrainingExample(pInputMap);
		pNeuronArray[outBelongingNeuronID].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
		return outBelongingNeuronID;
	}
	else
	{
		if (outActivationValue < lowerActivationThreshold)
		{
			int32_t IDOfMinimumTrainedNeuron = Get_ID_Of_MinimumTrainedNeuron(minNeuronID, maxNeuronID);
			pNeuronArray[IDOfMinimumTrainedNeuron].Add_TrainingExample(pInputMap);
			pNeuronArray[IDOfMinimumTrainedNeuron].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
			return IDOfMinimumTrainedNeuron;
		}
		else
		{
			Get_MinActivationValue(&outActivationValue, &outBelongingNeuronID, minNeuronID, maxNeuronID);
			pNeuronArray[outBelongingNeuronID].Add_TrainingExample(pInputMap);
			pNeuronArray[outBelongingNeuronID].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
			return outBelongingNeuronID;
		}
	}
}





CSimpleNeuronPopulation::CSimpleNeuronPopulation()
{
	for (int32_t i = 0; i < constNumOfBestFittedBrains; i++)
	{
		IDArrayOfBestFittedBrains[i] = 0;
		FitnessArrayOfBestFittedBrains[i] = 0.0f;
	}

	for (int32_t i = 0; i < constNumOfWorstFittedBrains; i++)
	{
		IDArrayOfWorstFittedBrains[i] = 0;
		FitnessArrayOfWorstFittedBrains[i] = 0.0f;
	}
}

CSimpleNeuralNetPopulation::CSimpleNeuralNetPopulation()
{
	for (int32_t i = 0; i < constNumOfBestFittedBrains; i++)
	{
		IDArrayOfBestFittedBrains[i] = 0;
		FitnessArrayOfBestFittedBrains[i] = 0.0f;
	}

	for (int32_t i = 0; i < constNumOfWorstFittedBrains; i++)
	{
		IDArrayOfWorstFittedBrains[i] = 0;
		FitnessArrayOfWorstFittedBrains[i] = 0.0f;
	}
}

CSimpleNeuronPopulation::~CSimpleNeuronPopulation()
{
	delete[] pFitnessScoreArray;
	pFitnessScoreArray = nullptr;

	delete[] ppNeuronArray;
	ppNeuronArray = nullptr;
}

CSimpleNeuralNetPopulation::~CSimpleNeuralNetPopulation()
{
	delete[] pFitnessScoreArray;
	pFitnessScoreArray = nullptr;

	delete[] ppSimpleNeuralNetDataArray;
	ppSimpleNeuralNetDataArray = nullptr;
}

bool CSimpleNeuronPopulation::Initialize(int32_t populationSize)
{
	int32_t minPopulationSize = constNumOfBestFittedBrains + constNumOfWorstFittedBrains + constNumOfAdditionalBrains + 10;

	//if (populationSize < minPopulationSize)
	//populationSize = minPopulationSize;

	for (int32_t i = 0; i < constNumOfBestFittedBrains; i++)
	{
		IDArrayOfBestFittedBrains[i] = 0;
		FitnessArrayOfBestFittedBrains[i] = 0.0f;
	}

	for (int32_t i = 0; i < constNumOfWorstFittedBrains; i++)
	{
		IDArrayOfWorstFittedBrains[i] = 0;
		FitnessArrayOfWorstFittedBrains[i] = 0.0f;
	}

	UseAdditionalMutatedBestBrain = false;
	UseAdditionalMutatedSecondBestBrain = false;
	UseAdditionalBestBrainsChild = false;

	RandomBrainsChildCounter = 0;

	for (int32_t i = 0; i < constNumOfRandomBrainsChildren; i++)
		UseAdditionalRandomBrainsChild[i] = false;

	delete[] pFitnessScoreArray;
	pFitnessScoreArray = nullptr;

	delete[] ppNeuronArray;
	ppNeuronArray = nullptr;

	PopulationSizePlusX = populationSize;
	PopulationSize = PopulationSizePlusX - constNumOfAdditionalBrains;

	//PopulationSize = populationSize;
	//PopulationSizePlusX = populationSize + constNumOfAdditionalBrains;

	pFitnessScoreArray = new (std::nothrow) float[PopulationSizePlusX];
	ppNeuronArray = new (std::nothrow) CSimpleNeuron*[PopulationSizePlusX];

	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFitnessScoreArray[i] = 0.0f;
		ppNeuronArray[i] = nullptr;
	}

	if (populationSize < minPopulationSize)
		return false;

	return true;
}

bool CSimpleNeuralNetPopulation::Initialize(int32_t populationSize)
{
	int32_t minPopulationSize = constNumOfBestFittedBrains + constNumOfWorstFittedBrains + constNumOfAdditionalBrains + 10;

	//if (populationSize < minPopulationSize)
	//populationSize = minPopulationSize;

	for (int32_t i = 0; i < constNumOfBestFittedBrains; i++)
	{
		IDArrayOfBestFittedBrains[i] = 0;
		FitnessArrayOfBestFittedBrains[i] = 0.0f;
	}

	for (int32_t i = 0; i < constNumOfWorstFittedBrains; i++)
	{
		IDArrayOfWorstFittedBrains[i] = 0;
		FitnessArrayOfWorstFittedBrains[i] = 0.0f;
	}

	UseAdditionalMutatedBestBrain = false;
	UseAdditionalMutatedSecondBestBrain = false;
	UseAdditionalBestBrainsChild = false;

	RandomBrainsChildCounter = 0;

	for (int32_t i = 0; i < constNumOfRandomBrainsChildren; i++)
		UseAdditionalRandomBrainsChild[i] = false;

	delete[] pFitnessScoreArray;
	pFitnessScoreArray = nullptr;

	delete[] ppSimpleNeuralNetDataArray;
	ppSimpleNeuralNetDataArray = nullptr;

	PopulationSizePlusX = populationSize;
	PopulationSize = PopulationSizePlusX - constNumOfAdditionalBrains;

	//PopulationSize = populationSize;
	//PopulationSizePlusX = populationSize + constNumOfAdditionalBrains;

	pFitnessScoreArray = new (std::nothrow) float[PopulationSizePlusX];
	ppSimpleNeuralNetDataArray = new (std::nothrow) CSimpleNeuralNetData*[PopulationSizePlusX];

	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFitnessScoreArray[i] = 0.0f;
		ppSimpleNeuralNetDataArray[i] = nullptr;
	}

	if (populationSize < minPopulationSize)
		return false;

	return true;
}

void CSimpleNeuronPopulation::Set_Neuron(CSimpleNeuron *pNeuron, int32_t id)
{
	ppNeuronArray[id] = pNeuron;
}

void CSimpleNeuralNetPopulation::Set_SimpleNeuralNet(CSimpleNeuralNetData *pNeuronNetData, int32_t id)
{
	ppSimpleNeuralNetDataArray[id] = pNeuronNetData;
}

void CSimpleNeuralNetPopulation::Calculate_FitnessScore_FromError(int32_t neuralNetID, float error)
{
	ppSimpleNeuralNetDataArray[neuralNetID]->FitnessScore = 1.0f / (error + 0.01f);
}

void CSimpleNeuronPopulation::Init_Or_Reinitialize_AdditionalMemoryValues(int32_t numOfAdditionalMemoryValues)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Init_AdditionalMemoryValues(numOfAdditionalMemoryValues);
	}
}

void  CSimpleNeuronPopulation::Set_AdditionalMemoryValues(int32_t neuronID, float *pMemoryValueArray)
{
	ppNeuronArray[neuronID]->Set_AdditionalMemoryValues(pMemoryValueArray);
}

void  CSimpleNeuronPopulation::Set_AdditionalMemoryValues(float *pMemoryValueArray)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Set_AdditionalMemoryValues(pMemoryValueArray);
	}	
}

void CSimpleNeuronPopulation::Init_Or_Reinitialize_Dendrite_Arrays(int32_t numOfDendriteElements)
{
	for (int32_t i = 0; i < constNumOfBestFittedBrains; i++)
	{
		IDArrayOfBestFittedBrains[i] = 0;
		FitnessArrayOfBestFittedBrains[i] = 0.0f;
	}

	for (int32_t i = 0; i < constNumOfWorstFittedBrains; i++)
	{
		IDArrayOfWorstFittedBrains[i] = 0;
		FitnessArrayOfWorstFittedBrains[i] = 0.0f;
	}

	UseAdditionalMutatedBestBrain = false;
	UseAdditionalMutatedSecondBestBrain = false;
	UseAdditionalBestBrainsChild = false;

	RandomBrainsChildCounter = 0;

	for (int32_t i = 0; i < constNumOfRandomBrainsChildren; i++)
		UseAdditionalRandomBrainsChild[i] = false;


	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFitnessScoreArray[i] = 0.0f;
		ppNeuronArray[i]->Init_Dendrite_Arrays(numOfDendriteElements);
	}
}

void CSimpleNeuronPopulation::Set_ActivationFunction(pActivationFunction pFunc)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Set_ActivationFunction(pFunc);
	}
}

void CSimpleNeuronPopulation::Set_DendriticFunction(pDendriticFunction pFunc)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Set_DendriticFunction(pFunc);
	}
}

CSimpleNeuron* CSimpleNeuronPopulation::Get_Best_Evolved_Neuron(void)
{
	return ppNeuronArray[IDArrayOfBestFittedBrains[0]];
}

CSimpleNeuralNetData* CSimpleNeuralNetPopulation::Get_Best_Evolved_NeuralNet(void)
{
	return ppSimpleNeuralNetDataArray[IDArrayOfBestFittedBrains[0]];
}

void CSimpleNeuronPopulation::Get_Best_Evolved_Neuron(CSimpleNeuron* pOutNeuron)
{
	pOutNeuron->Clone(ppNeuronArray[IDArrayOfBestFittedBrains[0]]);
}

void CSimpleNeuralNetPopulation::Get_Best_Evolved_NeuralNet(CSimpleNeuralNetData* pOutSimpleNeuralNet)
{
	pOutSimpleNeuralNet->Clone_Values(ppSimpleNeuralNetDataArray[IDArrayOfBestFittedBrains[0]]);
}

void CSimpleNeuronPopulation::Change_Seed(uint64_t seed)
{
	Seed = seed;
}

void CSimpleNeuralNetPopulation::Change_Seed(uint64_t seed)
{
	Seed = seed;
}

void CSimpleNeuronPopulation::Reset_MinErrorSum_ActualGeneration(float value)
{
	MinErrorSum_ActualGeneration = value;
}

void CSimpleNeuralNetPopulation::Reset_MinErrorSum_ActualGeneration(float value)
{
	MinErrorSum_ActualGeneration = value;
}

void CSimpleNeuronPopulation::Update_MinErrorSum_ActualGeneration(float value)
{
	if (value < MinErrorSum_ActualGeneration)
		MinErrorSum_ActualGeneration = value;
}

void CSimpleNeuralNetPopulation::Update_MinErrorSum_ActualGeneration(float value)
{
	if (value < MinErrorSum_ActualGeneration)
		MinErrorSum_ActualGeneration = value;
}

void CSimpleNeuronPopulation::Set_Dendrite_Data(int32_t neuronID, float *pDendrite_CentroidValueArray, float *pDendrite_FactorArray)
{
	ppNeuronArray[neuronID]->Set_Dendrite_Data(pDendrite_CentroidValueArray, pDendrite_FactorArray);
}

void CSimpleNeuronPopulation::Set_Dendrite_Data(float *pDendrite_CentroidValueArray, float *pDendrite_FactorArray)
{
	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Set_Dendrite_Data(pDendrite_CentroidValueArray, pDendrite_FactorArray);
	}
}

void CSimpleNeuronPopulation::Set_Dendrite_CentroidValues(int32_t neuronID, float *pDendrite_CentroidValueArray)
{
	ppNeuronArray[neuronID]->Set_Dendrite_CentroidValues(pDendrite_CentroidValueArray);
}

void CSimpleNeuronPopulation::Set_Dendrite_CentroidValues(float *pDendrite_CentroidValueArray)
{
	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Set_Dendrite_CentroidValues(pDendrite_CentroidValueArray);
	}
}

void CSimpleNeuronPopulation::Set_Dendrite_Factors(int32_t neuronID, float *pDendrite_FactorArray)
{
	ppNeuronArray[neuronID]->Set_Dendrite_Factors(pDendrite_FactorArray);
}

void CSimpleNeuronPopulation::Set_Dendrite_Factors(float *pDendrite_FactorArray)
{
	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Set_Dendrite_Factors(pDendrite_FactorArray);
	}
}



void CSimpleNeuronPopulation::Round_Dendrite_CentroidValues(float precision)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Round_Dendrite_CentroidValues(precision);
	}
}

void CSimpleNeuralNetPopulation::Round_Dendrite_CentroidValues(float precision)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		int32_t numOfNeurons = ppSimpleNeuralNetDataArray[i]->NumOfNeurons;
		CSimpleNeuron **ppNeuronArray = ppSimpleNeuralNetDataArray[i]->ppNeuronArray;

		for (int32_t j = 0; j < numOfNeurons; j++)
		{
			if (ppNeuronArray[j] == nullptr)
			{
				continue;
			}

			ppNeuronArray[j]->Round_Dendrite_CentroidValues(precision);
		}
	}
}

void CSimpleNeuronPopulation::Round_Dendrite_Factors(float precision)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Round_Dendrite_Factors(precision);
	}
}

void CSimpleNeuralNetPopulation::Round_Dendrite_Factors(float precision)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		int32_t numOfNeurons = ppSimpleNeuralNetDataArray[i]->NumOfNeurons;
		CSimpleNeuron **ppNeuronArray = ppSimpleNeuralNetDataArray[i]->ppNeuronArray;

		for (int32_t j = 0; j < numOfNeurons; j++)
		{
			if (ppNeuronArray[j] == nullptr)
			{
				continue;
			}

			ppNeuronArray[j]->Round_Dendrite_Factors(precision);
		}
	}
}

void  CSimpleNeuronPopulation::Round_AdditionalMemoryValues(float precision)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Round_AdditionalMemoryValues(precision);
	}
}

void  CSimpleNeuralNetPopulation::Round_AdditionalMemoryValues(float precision)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		int32_t numOfNeurons = ppSimpleNeuralNetDataArray[i]->NumOfNeurons;
		CSimpleNeuron **ppNeuronArray = ppSimpleNeuralNetDataArray[i]->ppNeuronArray;

		for (int32_t j = 0; j < numOfNeurons; j++)
		{
			if (ppNeuronArray[j] == nullptr)
			{
				continue;
			}

			ppNeuronArray[j]->Round_AdditionalMemoryValues(precision);
		}
	}
}

void  CSimpleNeuronPopulation::Round_AdditionalMemoryValues(float precision, int32_t minValueID, int32_t maxValueID)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Round_AdditionalMemoryValues(precision, minValueID,  maxValueID);
	}
}

void  CSimpleNeuronPopulation::Round_Dendrite_CentroidValues(float precision, int32_t minDendriteID, int32_t maxDendriteID)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Round_Dendrite_CentroidValues(precision, minDendriteID, maxDendriteID);
	}
}

void  CSimpleNeuronPopulation::Round_Dendrite_Factors(float precision, int32_t minDendriteID, int32_t maxDendriteID)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Round_Dendrite_Factors(precision, minDendriteID, maxDendriteID);
	}
}

void CSimpleNeuronPopulation::Randomize_Dendrite_CentroidValues(float minValue, float maxValue)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Randomize_Dendrite_CentroidValues(&RandomNumbers, minValue, maxValue);
	}
}

void CSimpleNeuralNetPopulation::Randomize_Dendrite_CentroidValues(float minValue, float maxValue)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		int32_t numOfNeurons = ppSimpleNeuralNetDataArray[i]->NumOfNeurons;
		CSimpleNeuron **ppNeuronArray = ppSimpleNeuralNetDataArray[i]->ppNeuronArray;

		for (int32_t j = 0; j < numOfNeurons; j++)
		{
			if (ppNeuronArray[j] == nullptr)
			{
				continue;
			}

			ppNeuronArray[j]->Randomize_Dendrite_CentroidValues(&RandomNumbers, minValue, maxValue);
		}
	}
}

void CSimpleNeuralNetPopulation::Randomize_Dendrite_Factors(float minValue, float maxValue)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		int32_t numOfNeurons = ppSimpleNeuralNetDataArray[i]->NumOfNeurons;
		CSimpleNeuron **ppNeuronArray = ppSimpleNeuralNetDataArray[i]->ppNeuronArray;

		for (int32_t j = 0; j < numOfNeurons; j++)
		{
			if (ppNeuronArray[j] == nullptr)
			{
				continue;
			}

			ppNeuronArray[j]->Randomize_Dendrite_Factors(&RandomNumbers, minValue, maxValue);
		}
	}
}

void CSimpleNeuralNetPopulation::Randomize_AdditionalMemoryValues(float minValue, float maxValue)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		int32_t numOfNeurons = ppSimpleNeuralNetDataArray[i]->NumOfNeurons;
		CSimpleNeuron **ppNeuronArray = ppSimpleNeuralNetDataArray[i]->ppNeuronArray;

		for (int32_t j = 0; j < numOfNeurons; j++)
		{
			if (ppNeuronArray[j] == nullptr)
			{
				continue;
			}

			ppNeuronArray[j]->Randomize_AdditionalMemoryValues(&RandomNumbers, minValue, maxValue);
		}
	}
}

void CSimpleNeuralNetPopulation::Modify_Dendrite_CentroidValues(float minVariance, float maxVariance)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		int32_t numOfNeurons = ppSimpleNeuralNetDataArray[i]->NumOfNeurons;
		CSimpleNeuron **ppNeuronArray = ppSimpleNeuralNetDataArray[i]->ppNeuronArray;

		for (int32_t j = 0; j < numOfNeurons; j++)
		{
			if (ppNeuronArray[j] == nullptr)
			{
				continue;
			}

			ppNeuronArray[j]->Modify_Dendrite_CentroidValues(&RandomNumbers, minVariance, maxVariance);
		}
	}
}

void CSimpleNeuralNetPopulation::Modify_Dendrite_CentroidValues(float minVariance, float maxVariance, float mutationRate)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		int32_t numOfNeurons = ppSimpleNeuralNetDataArray[i]->NumOfNeurons;
		CSimpleNeuron **ppNeuronArray = ppSimpleNeuralNetDataArray[i]->ppNeuronArray;

		for (int32_t j = 0; j < numOfNeurons; j++)
		{
			if (ppNeuronArray[j] == nullptr)
			{
				continue;
			}

			ppNeuronArray[j]->Modify_Dendrite_CentroidValues(&RandomNumbers, minVariance, maxVariance, mutationRate);
		}
	}
}

void CSimpleNeuralNetPopulation::Modify_Dendrite_Factors(float minVariance, float maxVariance)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		int32_t numOfNeurons = ppSimpleNeuralNetDataArray[i]->NumOfNeurons;
		CSimpleNeuron **ppNeuronArray = ppSimpleNeuralNetDataArray[i]->ppNeuronArray;

		for (int32_t j = 0; j < numOfNeurons; j++)
		{
			if (ppNeuronArray[j] == nullptr)
			{
				continue;
			}

			ppNeuronArray[j]->Modify_Dendrite_Factors(&RandomNumbers, minVariance, maxVariance);
		}
	}
}

void CSimpleNeuralNetPopulation::Modify_Dendrite_Factors(float minVariance, float maxVariance, float mutationRate)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		int32_t numOfNeurons = ppSimpleNeuralNetDataArray[i]->NumOfNeurons;
		CSimpleNeuron **ppNeuronArray = ppSimpleNeuralNetDataArray[i]->ppNeuronArray;

		for (int32_t j = 0; j < numOfNeurons; j++)
		{
			if (ppNeuronArray[j] == nullptr)
			{
				continue;
			}

			ppNeuronArray[j]->Modify_Dendrite_Factors(&RandomNumbers, minVariance, maxVariance, mutationRate);
		}
	}
}

void CSimpleNeuralNetPopulation::Modify_AdditionalMemoryValues(float minVariance, float maxVariance, float mutationRate)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		int32_t numOfNeurons = ppSimpleNeuralNetDataArray[i]->NumOfNeurons;
		CSimpleNeuron **ppNeuronArray = ppSimpleNeuralNetDataArray[i]->ppNeuronArray;

		for (int32_t j = 0; j < numOfNeurons; j++)
		{
			if (ppNeuronArray[j] == nullptr)
			{
				continue;
			}

			ppNeuronArray[j]->Modify_AdditionalMemoryValues(&RandomNumbers, minVariance, maxVariance, mutationRate);
		}
	}
}

void CSimpleNeuralNetPopulation::Modify_AdditionalMemoryValues(float minVariance, float maxVariance)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		int32_t numOfNeurons = ppSimpleNeuralNetDataArray[i]->NumOfNeurons;
		CSimpleNeuron **ppNeuronArray = ppSimpleNeuralNetDataArray[i]->ppNeuronArray;

		for (int32_t j = 0; j < numOfNeurons; j++)
		{
			if (ppNeuronArray[j] == nullptr)
			{
				continue;
			}

			ppNeuronArray[j]->Modify_AdditionalMemoryValues(&RandomNumbers, minVariance, maxVariance);
		}
	}
}

void CSimpleNeuralNetPopulation::Randomize_Dendrite_CentroidValues(float minValue, float maxValue, float mutationRate)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		int32_t numOfNeurons = ppSimpleNeuralNetDataArray[i]->NumOfNeurons;
		CSimpleNeuron **ppNeuronArray = ppSimpleNeuralNetDataArray[i]->ppNeuronArray;

		for (int32_t j = 0; j < numOfNeurons; j++)
		{
			if (ppNeuronArray[j] == nullptr)
			{
				continue;
			}

			ppNeuronArray[j]->Randomize_Dendrite_CentroidValues(&RandomNumbers, minValue, maxValue, mutationRate);
		}
	}
}

void CSimpleNeuralNetPopulation::Randomize_Dendrite_Factors(float minValue, float maxValue, float mutationRate)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		int32_t numOfNeurons = ppSimpleNeuralNetDataArray[i]->NumOfNeurons;
		CSimpleNeuron **ppNeuronArray = ppSimpleNeuralNetDataArray[i]->ppNeuronArray;

		for (int32_t j = 0; j < numOfNeurons; j++)
		{
			if (ppNeuronArray[j] == nullptr)
			{
				continue;
			}

			ppNeuronArray[j]->Randomize_Dendrite_Factors(&RandomNumbers, minValue, maxValue, mutationRate);
		}
	}
}

void CSimpleNeuralNetPopulation::Randomize_AdditionalMemoryValues(float minValue, float maxValue, float mutationRate)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		int32_t numOfNeurons = ppSimpleNeuralNetDataArray[i]->NumOfNeurons;
		CSimpleNeuron **ppNeuronArray = ppSimpleNeuralNetDataArray[i]->ppNeuronArray;

		for (int32_t j = 0; j < numOfNeurons; j++)
		{
			if (ppNeuronArray[j] == nullptr)
			{
				continue;
			}

			ppNeuronArray[j]->Randomize_AdditionalMemoryValues(&RandomNumbers, minValue, maxValue, mutationRate);
		}
	}
}

void CSimpleNeuronPopulation::Randomize_Dendrite_CentroidValues(float minValue, float maxValue, float mutationRate)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Randomize_Dendrite_CentroidValues(&RandomNumbers, minValue, maxValue, mutationRate);
	}
}

void CSimpleNeuronPopulation::Modify_Dendrite_CentroidValues(float minVariance, float maxVariance)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Modify_Dendrite_CentroidValues(&RandomNumbers, minVariance, maxVariance);
	}
}

void CSimpleNeuronPopulation::Modify_Dendrite_CentroidValues(float minVariance, float maxVariance, float mutationRate)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Modify_Dendrite_CentroidValues(&RandomNumbers, minVariance, maxVariance, mutationRate);
	}
}

void CSimpleNeuronPopulation::Modify_Dendrite_CentroidValues(float minVariance, float maxVariance, int32_t minDendriteID, int32_t maxDendriteID)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Modify_Dendrite_CentroidValues(&RandomNumbers, minVariance, maxVariance, minDendriteID, maxDendriteID);
	}
}

void CSimpleNeuronPopulation::Modify_Dendrite_CentroidValues(float minVariance, float maxVariance, float mutationRate, int32_t minDendriteID, int32_t maxDendriteID)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Modify_Dendrite_CentroidValues(&RandomNumbers, minVariance, maxVariance, mutationRate, minDendriteID, maxDendriteID);
	}
}


void CSimpleNeuronPopulation::Modify_AdditionalMemoryValues(float minVariance, float maxVariance)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Modify_AdditionalMemoryValues(&RandomNumbers, minVariance, maxVariance);
	}
}

void CSimpleNeuronPopulation::Modify_AdditionalMemoryValues(float minVariance, float maxVariance, int32_t minValueID, int32_t maxValueID)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Modify_AdditionalMemoryValues(&RandomNumbers, minVariance, maxVariance, minValueID, maxValueID);
	}
}

void CSimpleNeuronPopulation::Modify_Dendrite_Factors(float minVariance, float maxVariance)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Modify_Dendrite_Factors(&RandomNumbers, minVariance, maxVariance);
	}
}

void CSimpleNeuronPopulation::Modify_AdditionalMemoryValues(float minVariance, float maxVariance, float mutationRate)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Modify_AdditionalMemoryValues(&RandomNumbers, minVariance, maxVariance, mutationRate);
	}
}

void CSimpleNeuronPopulation::Modify_AdditionalMemoryValues(float minVariance, float maxVariance, float mutationRate, int32_t minValueID, int32_t maxValueID)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Modify_AdditionalMemoryValues(&RandomNumbers, minVariance, maxVariance, mutationRate, minValueID, maxValueID);
	}
}

void CSimpleNeuronPopulation::Modify_Dendrite_Factors(float minVariance, float maxVariance, float mutationRate)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Modify_Dendrite_Factors(&RandomNumbers, minVariance, maxVariance, mutationRate);
	}
}

void CSimpleNeuronPopulation::Randomize_AdditionalMemoryValues(float minValue, float maxValue)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Randomize_AdditionalMemoryValues(&RandomNumbers, minValue, maxValue);
	}
}

void CSimpleNeuronPopulation::Randomize_AdditionalMemoryValues(float minValue, float maxValue, int32_t minValueID, int32_t maxValueID)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Randomize_AdditionalMemoryValues(&RandomNumbers, minValue, maxValue, minValueID, maxValueID);
	}
}

void CSimpleNeuronPopulation::Randomize_Dendrite_Factors(float minValue, float maxValue)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Randomize_Dendrite_Factors(&RandomNumbers, minValue, maxValue);
	}
}

void CSimpleNeuronPopulation::Randomize_AdditionalMemoryValues(float minValue, float maxValue, float mutationRate)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Randomize_AdditionalMemoryValues(&RandomNumbers, minValue, maxValue, mutationRate);
	}
}

void CSimpleNeuronPopulation::Randomize_AdditionalMemoryValues(float minValue, float maxValue, float mutationRate, int32_t minValueID, int32_t maxValueID)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Randomize_AdditionalMemoryValues(&RandomNumbers, minValue, maxValue, mutationRate, minValueID, maxValueID);
	}
}

void CSimpleNeuronPopulation::Randomize_Dendrite_Factors(float minValue, float maxValue, float mutationRate)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Randomize_Dendrite_Factors(&RandomNumbers, minValue, maxValue, mutationRate);
	}
}

void CSimpleNeuronPopulation::Randomize_Dendrite_CentroidValues(float minValue, float maxValue, int32_t minDendriteID, int32_t maxDendriteID)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Randomize_Dendrite_CentroidValues(&RandomNumbers, minValue, maxValue, minDendriteID, maxDendriteID);
	}
}

void CSimpleNeuronPopulation::Randomize_Dendrite_CentroidValues(float minValue, float maxValue, float mutationRate, int32_t minDendriteID, int32_t maxDendriteID)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Randomize_Dendrite_CentroidValues(&RandomNumbers, minValue, maxValue, mutationRate, minDendriteID, maxDendriteID);
	}
}

void CSimpleNeuronPopulation::Randomize_Dendrite_Factors(float minValue, float maxValue, int32_t minDendriteID, int32_t maxDendriteID)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Randomize_Dendrite_Factors(&RandomNumbers, minValue, maxValue, minDendriteID, maxDendriteID);
	}
}

void CSimpleNeuronPopulation::Randomize_Dendrite_Factors(float minValue, float maxValue, float mutationRate, int32_t minDendriteID, int32_t maxDendriteID)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Randomize_Dendrite_Factors(&RandomNumbers, minValue, maxValue, mutationRate, minDendriteID, maxDendriteID);
	}
}

void CSimpleNeuronPopulation::Modify_Dendrite_Factors(float minVariance, float maxVariance, int32_t minDendriteID, int32_t maxDendriteID)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Modify_Dendrite_Factors(&RandomNumbers, minVariance, maxVariance, minDendriteID, maxDendriteID);
	}
}

void CSimpleNeuronPopulation::Modify_Dendrite_Factors(float minVariance, float maxVariance, float mutationRate, int32_t minDendriteID, int32_t maxDendriteID)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Modify_Dendrite_Factors(&RandomNumbers, minVariance, maxVariance, mutationRate, minDendriteID, maxDendriteID);
	}
}

void CSimpleNeuronPopulation::Reinitialize_Dendrite_Values(pReinitializationFunction pFunc, void *pParam)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFunc(ppNeuronArray[i], &RandomNumbers, pParam);
	}
}

void CSimpleNeuralNetPopulation::Reinitialize_Dendrite_Values(pNetReinitializationFunction pFunc, void *pParam)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFunc(ppSimpleNeuralNetDataArray[i], &RandomNumbers, pParam);
	}
}

void CSimpleNeuronPopulation::Reinitialize_AdditionalMemoryValues(pReinitializationFunction pFunc, void *pParam)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFunc(ppNeuronArray[i], &RandomNumbers, pParam);
	}
}

void CSimpleNeuralNetPopulation::Reinitialize_AdditionalMemoryValues(pNetReinitializationFunction pFunc, void *pParam)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFunc(ppSimpleNeuralNetDataArray[i], &RandomNumbers, pParam);
	}
}

void CSimpleNeuronPopulation::Mutate_Dendrite_Values(pMutationFunction pFunc, void *pParam)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFunc(ppNeuronArray[i], &RandomNumbers, pParam);
	}
}

void CSimpleNeuralNetPopulation::Mutate_Dendrite_Values(pNetMutationFunction pFunc, void *pParam)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFunc(ppSimpleNeuralNetDataArray[i], &RandomNumbers, pParam);
	}
}

void CSimpleNeuronPopulation::Mutate_AdditionalMemoryValues(pMutationFunction pFunc, void *pParam)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFunc(ppNeuronArray[i], &RandomNumbers, pParam);
	}
}

void CSimpleNeuralNetPopulation::Mutate_AdditionalMemoryValues(pNetMutationFunction pFunc, void *pParam)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFunc(ppSimpleNeuralNetDataArray[i], &RandomNumbers, pParam);
	}
}

void CSimpleNeuronPopulation::Permute_Dendrite_Values(pPermutationFunction pFunc, void *pParam)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFunc(ppNeuronArray[i], &RandomNumbers, pParam);
	}	
}

void CSimpleNeuralNetPopulation::Permute_Dendrite_Values(pNetPermutationFunction pFunc, void *pParam)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFunc(ppSimpleNeuralNetDataArray[i], &RandomNumbers, pParam);
	}
}

void CSimpleNeuronPopulation::Permute_AdditionalMemoryValues(pPermutationFunction pFunc, void *pParam)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFunc(ppNeuronArray[i], &RandomNumbers, pParam);
	}
}

void CSimpleNeuralNetPopulation::Permute_AdditionalMemoryValues(pNetPermutationFunction pFunc, void *pParam)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFunc(ppSimpleNeuralNetDataArray[i], &RandomNumbers, pParam);
	}
}

void CSimpleNeuronPopulation::Update_Evolution_Combine_BestTwoBrains(pRecombinationFunction pFunc, void *pParam)
{
	if (UseAdditionalBestBrainsChild == true)
		return;

	pFunc(ppNeuronArray[PopulationSize + 2], ppNeuronArray[IDArrayOfBestFittedBrains[0]], ppNeuronArray[IDArrayOfBestFittedBrains[1]], &RandomNumbers, pParam);

	UseAdditionalBestBrainsChild = true;
}

void CSimpleNeuralNetPopulation::Update_Evolution_Combine_BestTwoBrains(pNetRecombinationFunction pFunc, void *pParam)
{
	if (UseAdditionalBestBrainsChild == true)
		return;

	pFunc(ppSimpleNeuralNetDataArray[PopulationSize + 2], ppSimpleNeuralNetDataArray[IDArrayOfBestFittedBrains[0]], ppSimpleNeuralNetDataArray[IDArrayOfBestFittedBrains[1]], &RandomNumbers, pParam);

	UseAdditionalBestBrainsChild = true;
}

void CSimpleNeuronPopulation::Update_Evolution_Combine_TwoBrains(pRecombinationFunction pFunc, void *pParam)
{
	if (UseAdditionalRandomBrainsChild[RandomBrainsChildCounter] == true)
		return;

	int32_t id1, id2;

	for (int32_t i = 0; i < constNumPopulationSearchStepsMax; i++)
	{
		id1 = RandomNumbers.Get_IntegerNumber(0, PopulationSize);

		// die am schlechtesten angepassten Individuen d�rfen sich nicht vermehren:
		if (pFitnessScoreArray[id1] <= FitnessArrayOfWorstFittedBrains[constNumOfWorstFittedBrains - 1])
			continue;

		id2 = RandomNumbers.Get_IntegerNumber(0, PopulationSize);

		// die am schlechtesten angepassten Individuen d�rfen sich nicht vermehren:
		if (pFitnessScoreArray[id2] <= FitnessArrayOfWorstFittedBrains[constNumOfWorstFittedBrains - 1])
			continue;

		if (id1 == id2)
			continue;

		pFunc(ppNeuronArray[PopulationSize + 3 + RandomBrainsChildCounter], ppNeuronArray[id1], ppNeuronArray[id2], &RandomNumbers, pParam);

		UseAdditionalRandomBrainsChild[RandomBrainsChildCounter] = true;

		if (RandomBrainsChildCounter < constNumOfRandomBrainsChildren - 1)
			RandomBrainsChildCounter++;

		break;
	}
}

void CSimpleNeuralNetPopulation::Update_Evolution_Combine_TwoBrains(pNetRecombinationFunction pFunc, void *pParam)
{
	if (UseAdditionalRandomBrainsChild[RandomBrainsChildCounter] == true)
		return;

	int32_t id1, id2;

	for (int32_t i = 0; i < constNumPopulationSearchStepsMax; i++)
	{
		id1 = RandomNumbers.Get_IntegerNumber(0, PopulationSize);

		// die am schlechtesten angepassten Individuen d�rfen sich nicht vermehren:
		if (pFitnessScoreArray[id1] <= FitnessArrayOfWorstFittedBrains[constNumOfWorstFittedBrains - 1])
			continue;

		id2 = RandomNumbers.Get_IntegerNumber(0, PopulationSize);

		// die am schlechtesten angepassten Individuen d�rfen sich nicht vermehren:
		if (pFitnessScoreArray[id2] <= FitnessArrayOfWorstFittedBrains[constNumOfWorstFittedBrains - 1])
			continue;

		if (id1 == id2)
			continue;

		pFunc(ppSimpleNeuralNetDataArray[PopulationSize + 3 + RandomBrainsChildCounter], ppSimpleNeuralNetDataArray[id1], ppSimpleNeuralNetDataArray[id2], &RandomNumbers, pParam);
		

		UseAdditionalRandomBrainsChild[RandomBrainsChildCounter] = true;	

		if (RandomBrainsChildCounter < constNumOfRandomBrainsChildren - 1)
			RandomBrainsChildCounter++;

		break;
	}
}

void CSimpleNeuronPopulation::Update_BaseEvolution(pMutationFunction pFunc, void *pParam)
{
	bool bestFittedBrains;

	for (int32_t i = 0; i < PopulationSize; i++)
	{
		bestFittedBrains = false;

		for (int32_t j = 0; j < constNumOfBestFittedBrains; j++)
		{
			if (i == IDArrayOfBestFittedBrains[j])
			{
				bestFittedBrains = true;
				break;
			}
		}

		if (bestFittedBrains == false)
		{
			pFunc(ppNeuronArray[i], &RandomNumbers, pParam);
		}
	}
}

void CSimpleNeuralNetPopulation::Update_BaseEvolution(pNetMutationFunction pFunc, void *pParam)
{
	bool bestFittedBrains;

	for (int32_t i = 0; i < PopulationSize; i++)
	{
		bestFittedBrains = false;

		for (int32_t j = 0; j < constNumOfBestFittedBrains; j++)
		{
			if (i == IDArrayOfBestFittedBrains[j])
			{
				bestFittedBrains = true;
				break;
			}
		}

		if (bestFittedBrains == false)
		{
			pFunc(ppSimpleNeuralNetDataArray[i], &RandomNumbers, pParam);
		}
	}
}

void CSimpleNeuronPopulation::Update_BaseEvolution2(pPermutationFunction pFunc, void *pParam)
{
	bool bestFittedBrains;

	for (int32_t i = 0; i < PopulationSize; i++)
	{
		bestFittedBrains = false;

		for (int32_t j = 0; j < constNumOfBestFittedBrains; j++)
		{
			if (i == IDArrayOfBestFittedBrains[j])
			{
				bestFittedBrains = true;
				break;
			}
		}

		if (bestFittedBrains == false)
		{	
			pFunc(ppNeuronArray[i], &RandomNumbers, pParam);
		}
	}
}

void CSimpleNeuralNetPopulation::Update_BaseEvolution2(pNetPermutationFunction pFunc, void *pParam)
{
	bool bestFittedBrains;

	for (int32_t i = 0; i < PopulationSize; i++)
	{
		bestFittedBrains = false;

		for (int32_t j = 0; j < constNumOfBestFittedBrains; j++)
		{
			if (i == IDArrayOfBestFittedBrains[j])
			{
				bestFittedBrains = true;
				break;
			}
		}

		if (bestFittedBrains == false)
		{
			pFunc(ppSimpleNeuralNetDataArray[i], &RandomNumbers, pParam);
		}
	}
}

void CSimpleNeuronPopulation::Update_Evolution_BestBrainOnly(pMutationFunction pFunc, void *pParam)
{
	if (UseAdditionalMutatedBestBrain == true)
		return;

	ppNeuronArray[PopulationSize]->Clone_Values(ppNeuronArray[IDArrayOfBestFittedBrains[0]]);

	pFunc(ppNeuronArray[PopulationSize], &RandomNumbers, pParam);

	UseAdditionalMutatedBestBrain = true;
}

void CSimpleNeuralNetPopulation::Update_Evolution_BestBrainOnly(pNetMutationFunction pFunc, void *pParam)
{
	if (UseAdditionalMutatedBestBrain == true)
		return;

	ppSimpleNeuralNetDataArray[PopulationSize]->Clone_Values(ppSimpleNeuralNetDataArray[IDArrayOfBestFittedBrains[0]]);

	pFunc(ppSimpleNeuralNetDataArray[PopulationSize], &RandomNumbers, pParam);

	UseAdditionalMutatedBestBrain = true;
}

void CSimpleNeuronPopulation::Update_Evolution_BestBrainOnly2(pPermutationFunction pFunc, void *pParam)
{
	if (UseAdditionalMutatedBestBrain == true)
		return;

	ppNeuronArray[PopulationSize]->Clone_Values(ppNeuronArray[IDArrayOfBestFittedBrains[0]]);

	
	pFunc(ppNeuronArray[PopulationSize], &RandomNumbers, pParam);

	UseAdditionalMutatedBestBrain = true;
}

void CSimpleNeuralNetPopulation::Update_Evolution_BestBrainOnly2(pNetPermutationFunction pFunc, void *pParam)
{
	if (UseAdditionalMutatedBestBrain == true)
		return;

	ppSimpleNeuralNetDataArray[PopulationSize]->Clone_Values(ppSimpleNeuralNetDataArray[IDArrayOfBestFittedBrains[0]]);


	pFunc(ppSimpleNeuralNetDataArray[PopulationSize], &RandomNumbers, pParam);

	UseAdditionalMutatedBestBrain = true;
}

void CSimpleNeuronPopulation::Update_Evolution_SecondBestBrainOnly(pMutationFunction pFunc, void *pParam)
{
	if (UseAdditionalMutatedSecondBestBrain == true)
		return;

	ppNeuronArray[PopulationSize + 1]->Clone_Values(ppNeuronArray[IDArrayOfBestFittedBrains[1]]);

	pFunc(ppNeuronArray[PopulationSize + 1], &RandomNumbers, pParam);

	UseAdditionalMutatedSecondBestBrain = true;
}

void CSimpleNeuralNetPopulation::Update_Evolution_SecondBestBrainOnly(pNetMutationFunction pFunc, void *pParam)
{
	if (UseAdditionalMutatedSecondBestBrain == true)
		return;

	ppSimpleNeuralNetDataArray[PopulationSize + 1]->Clone_Values(ppSimpleNeuralNetDataArray[IDArrayOfBestFittedBrains[1]]);

	pFunc(ppSimpleNeuralNetDataArray[PopulationSize + 1], &RandomNumbers, pParam);

	UseAdditionalMutatedSecondBestBrain = true;
}

void CSimpleNeuronPopulation::Update_Evolution_SecondBestBrainOnly2(pPermutationFunction pFunc, void *pParam)
{
	if (UseAdditionalMutatedSecondBestBrain == true)
		return;

	ppNeuronArray[PopulationSize + 1]->Clone_Values(ppNeuronArray[IDArrayOfBestFittedBrains[1]]);

	
	pFunc(ppNeuronArray[PopulationSize + 1], &RandomNumbers, pParam);

	UseAdditionalMutatedSecondBestBrain = true;
}

void CSimpleNeuralNetPopulation::Update_Evolution_SecondBestBrainOnly2(pNetPermutationFunction pFunc, void *pParam)
{
	if (UseAdditionalMutatedSecondBestBrain == true)
		return;

	ppSimpleNeuralNetDataArray[PopulationSize + 1]->Clone_Values(ppSimpleNeuralNetDataArray[IDArrayOfBestFittedBrains[1]]);


	pFunc(ppSimpleNeuralNetDataArray[PopulationSize + 1], &RandomNumbers, pParam);

	UseAdditionalMutatedSecondBestBrain = true;
}


void CSimpleNeuronPopulation::Update_Population(float *pFitnessValueArray)
{
	if (pFitnessValueArray != nullptr)
	{
		for (int32_t i = 0; i < PopulationSizePlusX; i++)
		{
			pFitnessScoreArray[i] = pFitnessValueArray[i];
		}
	}

	for (int32_t i = 0; i < constNumOfBestFittedBrains; i++)
	{
		IDArrayOfBestFittedBrains[i] = 0;
		FitnessArrayOfBestFittedBrains[i] = -100000000.0f;
	}

	for (int32_t i = 0; i < constNumOfWorstFittedBrains; i++)
	{
		IDArrayOfWorstFittedBrains[i] = 0;
		FitnessArrayOfWorstFittedBrains[i] = 100000000.0f;
	}

	for (int32_t i = 0; i < PopulationSize; i++)
	{
		for (int32_t j = 0; j < constNumOfBestFittedBrains; j++)
		{
			if (pFitnessScoreArray[i] > FitnessArrayOfBestFittedBrains[j])
			{
				for (uint32_t k = constNumOfBestFittedBrains - 1; k > j; k--)
				{
					IDArrayOfBestFittedBrains[k] = IDArrayOfBestFittedBrains[k - 1];
					FitnessArrayOfBestFittedBrains[k] = FitnessArrayOfBestFittedBrains[k - 1];
				}

				FitnessArrayOfBestFittedBrains[j] = pFitnessScoreArray[i];
				IDArrayOfBestFittedBrains[j] = i;

				break;
			}
		}

		for (int32_t j = 0; j < constNumOfWorstFittedBrains; j++)
		{
			if (pFitnessScoreArray[i] < FitnessArrayOfWorstFittedBrains[j])
			{
				for (int32_t k = constNumOfWorstFittedBrains - 1; k > j; k--)
				{
					IDArrayOfWorstFittedBrains[k] = IDArrayOfWorstFittedBrains[k - 1];
					FitnessArrayOfWorstFittedBrains[k] = FitnessArrayOfWorstFittedBrains[k - 1];
				}

				FitnessArrayOfWorstFittedBrains[j] = pFitnessScoreArray[i];
				IDArrayOfWorstFittedBrains[j] = i;

				break;
			}
		}

	} // end of for (int32_t i = 0; i < PopulationSize; i++)


	  //HelperStuff::Add_To_Log(0, "best fitness", pFitnessScoreArray[IDArrayOfBestFittedBrains[0]]);

	float fitnessScoreOfBestFittedAdditionalBrain = -1000000.0f;
	int32_t idOfBestFittedAdditionalBrain = 0;

	for (int32_t i = 0; i < constNumOfAdditionalBrains; i++)
	{
		if (pFitnessScoreArray[PopulationSize + i] > fitnessScoreOfBestFittedAdditionalBrain)
		{
			fitnessScoreOfBestFittedAdditionalBrain = pFitnessScoreArray[PopulationSize + i];
			idOfBestFittedAdditionalBrain = PopulationSize + i;
		}
	}

	if (pFitnessScoreArray[idOfBestFittedAdditionalBrain] > pFitnessScoreArray[IDArrayOfBestFittedBrains[0]])
	{
		ppNeuronArray[IDArrayOfBestFittedBrains[0]]->Clone_Values(ppNeuronArray[idOfBestFittedAdditionalBrain]);
	}
	else if (pFitnessScoreArray[idOfBestFittedAdditionalBrain] > pFitnessScoreArray[IDArrayOfBestFittedBrains[1]])
	{
		ppNeuronArray[IDArrayOfBestFittedBrains[1]]->Clone_Values(ppNeuronArray[idOfBestFittedAdditionalBrain]);
	}
	else if (pFitnessScoreArray[idOfBestFittedAdditionalBrain] > pFitnessScoreArray[IDArrayOfBestFittedBrains[2]])
	{
		ppNeuronArray[IDArrayOfBestFittedBrains[2]]->Clone_Values(ppNeuronArray[idOfBestFittedAdditionalBrain]);
	}

	UseAdditionalMutatedBestBrain = false;
	UseAdditionalMutatedSecondBestBrain = false;
	UseAdditionalBestBrainsChild = false;

	RandomBrainsChildCounter = 0;

	for (int32_t i = 0; i < constNumOfRandomBrainsChildren; i++)
		UseAdditionalRandomBrainsChild[i] = false;
}



void CSimpleNeuronPopulation::Update_Population_Ext(float *pFitnessValueArray)
{
	if (pFitnessValueArray != nullptr)
	{
		for (int32_t i = 0; i < PopulationSizePlusX; i++)
		{
			pFitnessScoreArray[i] = pFitnessValueArray[i];
		}
	}

	for (int32_t i = 0; i < constNumOfBestFittedBrains; i++)
	{
		IDArrayOfBestFittedBrains[i] = 0;
		FitnessArrayOfBestFittedBrains[i] = -100000000.0f;
	}

	for (int32_t i = 0; i < constNumOfWorstFittedBrains; i++)
	{
		IDArrayOfWorstFittedBrains[i] = 0;
		FitnessArrayOfWorstFittedBrains[i] = 100000000.0f;
	}

	for (int32_t i = 0; i < PopulationSize; i++)
	{
		for (int32_t j = 0; j < constNumOfBestFittedBrains; j++)
		{
			if (pFitnessScoreArray[i] > FitnessArrayOfBestFittedBrains[j])
			{
				for (uint32_t k = constNumOfBestFittedBrains - 1; k > j; k--)
				{
					IDArrayOfBestFittedBrains[k] = IDArrayOfBestFittedBrains[k - 1];
					FitnessArrayOfBestFittedBrains[k] = FitnessArrayOfBestFittedBrains[k - 1];
				}

				FitnessArrayOfBestFittedBrains[j] = pFitnessScoreArray[i];
				IDArrayOfBestFittedBrains[j] = i;

				break;
			}
		}

		for (int32_t j = 0; j < constNumOfWorstFittedBrains; j++)
		{
			if (pFitnessScoreArray[i] < FitnessArrayOfWorstFittedBrains[j])
			{
				for (int32_t k = constNumOfWorstFittedBrains - 1; k > j; k--)
				{
					IDArrayOfWorstFittedBrains[k] = IDArrayOfWorstFittedBrains[k - 1];
					FitnessArrayOfWorstFittedBrains[k] = FitnessArrayOfWorstFittedBrains[k - 1];
				}

				FitnessArrayOfWorstFittedBrains[j] = pFitnessScoreArray[i];
				IDArrayOfWorstFittedBrains[j] = i;

				break;
			}
		}

	} // end of for (int32_t i = 0; i < PopulationSize; i++)


	  //HelperStuff::Add_To_Log(0, "best fitness", pFitnessScoreArray[IDArrayOfBestFittedBrains[0]]);

	float fitnessScoreOfBestFittedAdditionalBrain = -1000000.0f;
	int32_t idOfBestFittedAdditionalBrain = 0;

	for (int32_t i = 0; i < constNumOfAdditionalBrains; i++)
	{
		if (pFitnessScoreArray[PopulationSize + i] > fitnessScoreOfBestFittedAdditionalBrain)
		{
			fitnessScoreOfBestFittedAdditionalBrain = pFitnessScoreArray[PopulationSize + i];
			idOfBestFittedAdditionalBrain = PopulationSize + i;
		}
	}

	for (int32_t i = constNumOfBestFittedBrains - 1; i > -1; i--)
	{
		if (pFitnessScoreArray[idOfBestFittedAdditionalBrain] > pFitnessScoreArray[IDArrayOfBestFittedBrains[i]])
		{
			ppNeuronArray[IDArrayOfBestFittedBrains[i]]->Clone_Values(ppNeuronArray[idOfBestFittedAdditionalBrain]);
			break;
		}
	}

	UseAdditionalMutatedBestBrain = false;
	UseAdditionalMutatedSecondBestBrain = false;
	UseAdditionalBestBrainsChild = false;

	RandomBrainsChildCounter = 0;

	for (int32_t i = 0; i < constNumOfRandomBrainsChildren; i++)
		UseAdditionalRandomBrainsChild[i] = false;
}



void CSimpleNeuronPopulation::Update_Population(void)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFitnessScoreArray[i] = ppNeuronArray[i]->ActivationValue;
	}

	for (int32_t i = 0; i < constNumOfBestFittedBrains; i++)
	{
		IDArrayOfBestFittedBrains[i] = 0;
		FitnessArrayOfBestFittedBrains[i] = -100000000.0f;
	}

	for (int32_t i = 0; i < constNumOfWorstFittedBrains; i++)
	{
		IDArrayOfWorstFittedBrains[i] = 0;
		FitnessArrayOfWorstFittedBrains[i] = 100000000.0f;
	}

	for (int32_t i = 0; i < PopulationSize; i++)
	{
		for (int32_t j = 0; j < constNumOfBestFittedBrains; j++)
		{
			if (pFitnessScoreArray[i] > FitnessArrayOfBestFittedBrains[j])
			{
				for (uint32_t k = constNumOfBestFittedBrains - 1; k > j; k--)
				{
					IDArrayOfBestFittedBrains[k] = IDArrayOfBestFittedBrains[k - 1];
					FitnessArrayOfBestFittedBrains[k] = FitnessArrayOfBestFittedBrains[k - 1];
				}

				FitnessArrayOfBestFittedBrains[j] = pFitnessScoreArray[i];
				IDArrayOfBestFittedBrains[j] = i;

				break;
			}
		}

		for (int32_t j = 0; j < constNumOfWorstFittedBrains; j++)
		{
			if (pFitnessScoreArray[i] < FitnessArrayOfWorstFittedBrains[j])
			{
				for (int32_t k = constNumOfWorstFittedBrains - 1; k > j; k--)
				{
					IDArrayOfWorstFittedBrains[k] = IDArrayOfWorstFittedBrains[k - 1];
					FitnessArrayOfWorstFittedBrains[k] = FitnessArrayOfWorstFittedBrains[k - 1];
				}

				FitnessArrayOfWorstFittedBrains[j] = pFitnessScoreArray[i];
				IDArrayOfWorstFittedBrains[j] = i;

				break;
			}
		}

	} // end of for (int32_t i = 0; i < PopulationSize; i++)


	  //HelperStuff::Add_To_Log(0, "best fitness", pFitnessScoreArray[IDArrayOfBestFittedBrains[0]]);

	float fitnessScoreOfBestFittedAdditionalBrain = -1000000.0f;
	int32_t idOfBestFittedAdditionalBrain = 0;

	for (int32_t i = 0; i < constNumOfAdditionalBrains; i++)
	{
		if (pFitnessScoreArray[PopulationSize + i] > fitnessScoreOfBestFittedAdditionalBrain)
		{
			fitnessScoreOfBestFittedAdditionalBrain = pFitnessScoreArray[PopulationSize + i];
			idOfBestFittedAdditionalBrain = PopulationSize + i;
		}
	}

	if (pFitnessScoreArray[idOfBestFittedAdditionalBrain] > pFitnessScoreArray[IDArrayOfBestFittedBrains[0]])
	{
		ppNeuronArray[IDArrayOfBestFittedBrains[0]]->Clone_Values(ppNeuronArray[idOfBestFittedAdditionalBrain]);
	}
	else if (pFitnessScoreArray[idOfBestFittedAdditionalBrain] > pFitnessScoreArray[IDArrayOfBestFittedBrains[1]])
	{
		ppNeuronArray[IDArrayOfBestFittedBrains[1]]->Clone_Values(ppNeuronArray[idOfBestFittedAdditionalBrain]);
	}
	else if (pFitnessScoreArray[idOfBestFittedAdditionalBrain] > pFitnessScoreArray[IDArrayOfBestFittedBrains[2]])
	{
		ppNeuronArray[IDArrayOfBestFittedBrains[2]]->Clone_Values(ppNeuronArray[idOfBestFittedAdditionalBrain]);
	}

	UseAdditionalMutatedBestBrain = false;
	UseAdditionalMutatedSecondBestBrain = false;
	UseAdditionalBestBrainsChild = false;

	RandomBrainsChildCounter = 0;

	for (int32_t i = 0; i < constNumOfRandomBrainsChildren; i++)
		UseAdditionalRandomBrainsChild[i] = false;
}

void CSimpleNeuralNetPopulation::Update_Population(void)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFitnessScoreArray[i] = ppSimpleNeuralNetDataArray[i]->FitnessScore;
	}

	for (int32_t i = 0; i < constNumOfBestFittedBrains; i++)
	{
		IDArrayOfBestFittedBrains[i] = 0;
		FitnessArrayOfBestFittedBrains[i] = -100000000.0f;
	}

	for (int32_t i = 0; i < constNumOfWorstFittedBrains; i++)
	{
		IDArrayOfWorstFittedBrains[i] = 0;
		FitnessArrayOfWorstFittedBrains[i] = 100000000.0f;
	}

	for (int32_t i = 0; i < PopulationSize; i++)
	{
		for (int32_t j = 0; j < constNumOfBestFittedBrains; j++)
		{
			if (pFitnessScoreArray[i] > FitnessArrayOfBestFittedBrains[j])
			{
				for (uint32_t k = constNumOfBestFittedBrains - 1; k > j; k--)
				{
					IDArrayOfBestFittedBrains[k] = IDArrayOfBestFittedBrains[k - 1];
					FitnessArrayOfBestFittedBrains[k] = FitnessArrayOfBestFittedBrains[k - 1];
				}

				FitnessArrayOfBestFittedBrains[j] = pFitnessScoreArray[i];
				IDArrayOfBestFittedBrains[j] = i;

				break;
			}
		}

		for (int32_t j = 0; j < constNumOfWorstFittedBrains; j++)
		{
			if (pFitnessScoreArray[i] < FitnessArrayOfWorstFittedBrains[j])
			{
				for (int32_t k = constNumOfWorstFittedBrains - 1; k > j; k--)
				{
					IDArrayOfWorstFittedBrains[k] = IDArrayOfWorstFittedBrains[k - 1];
					FitnessArrayOfWorstFittedBrains[k] = FitnessArrayOfWorstFittedBrains[k - 1];
				}

				FitnessArrayOfWorstFittedBrains[j] = pFitnessScoreArray[i];
				IDArrayOfWorstFittedBrains[j] = i;

				break;
			}
		}

	} // end of for (int32_t i = 0; i < PopulationSize; i++)


	  //HelperStuff::Add_To_Log(0, "best fitness", pFitnessScoreArray[IDArrayOfBestFittedBrains[0]]);

	float fitnessScoreOfBestFittedAdditionalBrain = -1000000.0f;
	int32_t idOfBestFittedAdditionalBrain = 0;

	for (int32_t i = 0; i < constNumOfAdditionalBrains; i++)
	{
		if (pFitnessScoreArray[PopulationSize + i] > fitnessScoreOfBestFittedAdditionalBrain)
		{
			fitnessScoreOfBestFittedAdditionalBrain = pFitnessScoreArray[PopulationSize + i];
			idOfBestFittedAdditionalBrain = PopulationSize + i;
		}
	}

	if (pFitnessScoreArray[idOfBestFittedAdditionalBrain] > pFitnessScoreArray[IDArrayOfBestFittedBrains[0]])
	{
		ppSimpleNeuralNetDataArray[IDArrayOfBestFittedBrains[0]]->Clone_Values(ppSimpleNeuralNetDataArray[idOfBestFittedAdditionalBrain]);
	}
	else if (pFitnessScoreArray[idOfBestFittedAdditionalBrain] > pFitnessScoreArray[IDArrayOfBestFittedBrains[1]])
	{
		ppSimpleNeuralNetDataArray[IDArrayOfBestFittedBrains[1]]->Clone_Values(ppSimpleNeuralNetDataArray[idOfBestFittedAdditionalBrain]);
	}
	else if (pFitnessScoreArray[idOfBestFittedAdditionalBrain] > pFitnessScoreArray[IDArrayOfBestFittedBrains[2]])
	{
		ppSimpleNeuralNetDataArray[IDArrayOfBestFittedBrains[2]]->Clone_Values(ppSimpleNeuralNetDataArray[idOfBestFittedAdditionalBrain]);
	}

	UseAdditionalMutatedBestBrain = false;
	UseAdditionalMutatedSecondBestBrain = false;
	UseAdditionalBestBrainsChild = false;

	RandomBrainsChildCounter = 0;

	for (int32_t i = 0; i < constNumOfRandomBrainsChildren; i++)
		UseAdditionalRandomBrainsChild[i] = false;
}

void CSimpleNeuronPopulation::Update_Population_Ext(void)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFitnessScoreArray[i] = ppNeuronArray[i]->ActivationValue;
	}

	for (int32_t i = 0; i < constNumOfBestFittedBrains; i++)
	{
		IDArrayOfBestFittedBrains[i] = 0;
		FitnessArrayOfBestFittedBrains[i] = -100000000.0f;
	}

	for (int32_t i = 0; i < constNumOfWorstFittedBrains; i++)
	{
		IDArrayOfWorstFittedBrains[i] = 0;
		FitnessArrayOfWorstFittedBrains[i] = 100000000.0f;
	}

	for (int32_t i = 0; i < PopulationSize; i++)
	{
		for (int32_t j = 0; j < constNumOfBestFittedBrains; j++)
		{
			if (pFitnessScoreArray[i] > FitnessArrayOfBestFittedBrains[j])
			{
				for (uint32_t k = constNumOfBestFittedBrains - 1; k > j; k--)
				{
					IDArrayOfBestFittedBrains[k] = IDArrayOfBestFittedBrains[k - 1];
					FitnessArrayOfBestFittedBrains[k] = FitnessArrayOfBestFittedBrains[k - 1];
				}

				FitnessArrayOfBestFittedBrains[j] = pFitnessScoreArray[i];
				IDArrayOfBestFittedBrains[j] = i;

				break;
			}
		}

		for (int32_t j = 0; j < constNumOfWorstFittedBrains; j++)
		{
			if (pFitnessScoreArray[i] < FitnessArrayOfWorstFittedBrains[j])
			{
				for (int32_t k = constNumOfWorstFittedBrains - 1; k > j; k--)
				{
					IDArrayOfWorstFittedBrains[k] = IDArrayOfWorstFittedBrains[k - 1];
					FitnessArrayOfWorstFittedBrains[k] = FitnessArrayOfWorstFittedBrains[k - 1];
				}

				FitnessArrayOfWorstFittedBrains[j] = pFitnessScoreArray[i];
				IDArrayOfWorstFittedBrains[j] = i;

				break;
			}
		}

	} // end of for (int32_t i = 0; i < PopulationSize; i++)


	  //HelperStuff::Add_To_Log(0, "best fitness", pFitnessScoreArray[IDArrayOfBestFittedBrains[0]]);

	float fitnessScoreOfBestFittedAdditionalBrain = -1000000.0f;
	int32_t idOfBestFittedAdditionalBrain = 0;

	for (int32_t i = 0; i < constNumOfAdditionalBrains; i++)
	{
		if (pFitnessScoreArray[PopulationSize + i] > fitnessScoreOfBestFittedAdditionalBrain)
		{
			fitnessScoreOfBestFittedAdditionalBrain = pFitnessScoreArray[PopulationSize + i];
			idOfBestFittedAdditionalBrain = PopulationSize + i;
		}
	}

	for (int32_t i = constNumOfBestFittedBrains - 1; i > -1; i--)
	{
		if (pFitnessScoreArray[idOfBestFittedAdditionalBrain] > pFitnessScoreArray[IDArrayOfBestFittedBrains[i]])
		{
			ppNeuronArray[IDArrayOfBestFittedBrains[i]]->Clone_Values(ppNeuronArray[idOfBestFittedAdditionalBrain]);
			break;
		}
	}



	UseAdditionalMutatedBestBrain = false;
	UseAdditionalMutatedSecondBestBrain = false;
	UseAdditionalBestBrainsChild = false;

	RandomBrainsChildCounter = 0;

	for (int32_t i = 0; i < constNumOfRandomBrainsChildren; i++)
		UseAdditionalRandomBrainsChild[i] = false;
}

void CSimpleNeuralNetPopulation::Update_Population_Ext(void)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFitnessScoreArray[i] = ppSimpleNeuralNetDataArray[i]->FitnessScore;
	}

	for (int32_t i = 0; i < constNumOfBestFittedBrains; i++)
	{
		IDArrayOfBestFittedBrains[i] = 0;
		FitnessArrayOfBestFittedBrains[i] = -100000000.0f;
	}

	for (int32_t i = 0; i < constNumOfWorstFittedBrains; i++)
	{
		IDArrayOfWorstFittedBrains[i] = 0;
		FitnessArrayOfWorstFittedBrains[i] = 100000000.0f;
	}

	for (int32_t i = 0; i < PopulationSize; i++)
	{
		for (int32_t j = 0; j < constNumOfBestFittedBrains; j++)
		{
			if (pFitnessScoreArray[i] > FitnessArrayOfBestFittedBrains[j])
			{
				for (uint32_t k = constNumOfBestFittedBrains - 1; k > j; k--)
				{
					IDArrayOfBestFittedBrains[k] = IDArrayOfBestFittedBrains[k - 1];
					FitnessArrayOfBestFittedBrains[k] = FitnessArrayOfBestFittedBrains[k - 1];
				}

				FitnessArrayOfBestFittedBrains[j] = pFitnessScoreArray[i];
				IDArrayOfBestFittedBrains[j] = i;

				break;
			}
		}

		for (int32_t j = 0; j < constNumOfWorstFittedBrains; j++)
		{
			if (pFitnessScoreArray[i] < FitnessArrayOfWorstFittedBrains[j])
			{
				for (int32_t k = constNumOfWorstFittedBrains - 1; k > j; k--)
				{
					IDArrayOfWorstFittedBrains[k] = IDArrayOfWorstFittedBrains[k - 1];
					FitnessArrayOfWorstFittedBrains[k] = FitnessArrayOfWorstFittedBrains[k - 1];
				}

				FitnessArrayOfWorstFittedBrains[j] = pFitnessScoreArray[i];
				IDArrayOfWorstFittedBrains[j] = i;

				break;
			}
		}

	} // end of for (int32_t i = 0; i < PopulationSize; i++)


	  //HelperStuff::Add_To_Log(0, "best fitness", pFitnessScoreArray[IDArrayOfBestFittedBrains[0]]);

	float fitnessScoreOfBestFittedAdditionalBrain = -1000000.0f;
	int32_t idOfBestFittedAdditionalBrain = 0;

	for (int32_t i = 0; i < constNumOfAdditionalBrains; i++)
	{
		if (pFitnessScoreArray[PopulationSize + i] > fitnessScoreOfBestFittedAdditionalBrain)
		{
			fitnessScoreOfBestFittedAdditionalBrain = pFitnessScoreArray[PopulationSize + i];
			idOfBestFittedAdditionalBrain = PopulationSize + i;
		}
	}

	for (int32_t i = constNumOfBestFittedBrains - 1; i > -1; i--)
	{
		if (pFitnessScoreArray[idOfBestFittedAdditionalBrain] > pFitnessScoreArray[IDArrayOfBestFittedBrains[i]])
		{
			ppSimpleNeuralNetDataArray[IDArrayOfBestFittedBrains[i]]->Clone_Values(ppSimpleNeuralNetDataArray[idOfBestFittedAdditionalBrain]);
			break;
		}
	}



	UseAdditionalMutatedBestBrain = false;
	UseAdditionalMutatedSecondBestBrain = false;
	UseAdditionalBestBrainsChild = false;

	RandomBrainsChildCounter = 0;

	for (int32_t i = 0; i < constNumOfRandomBrainsChildren; i++)
		UseAdditionalRandomBrainsChild[i] = false;
}


void CSimpleNeuronPopulation::Update_PopulationKnowledge(int32_t minDendriteID, int32_t maxDendriteID, int32_t minMemoryValueID, int32_t maxMemoryValueID)
{
	maxDendriteID++;
	maxMemoryValueID++;

	CSimpleNeuron *pNeuron = nullptr;
	CSimpleNeuron *pBestNeuron = ppNeuronArray[IDArrayOfBestFittedBrains[0]];

	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pNeuron = ppNeuronArray[i];

		if (pNeuron->pDendrite_CentroidValueArray != nullptr)
		{
			for (int32_t j = minDendriteID; j < maxDendriteID; j++)
			{
				pNeuron->pDendrite_CentroidValueArray[j] = pBestNeuron->pDendrite_CentroidValueArray[j];
				pNeuron->pDendrite_FactorArray[j] = pBestNeuron->pDendrite_FactorArray[j];
			}
		}

		if (pNeuron->pAdditionalMemoryValueArray != nullptr)
		{
			for (int32_t j = minMemoryValueID; j < maxMemoryValueID; j++)
			{
				pNeuron->pAdditionalMemoryValueArray[j] = pBestNeuron->pAdditionalMemoryValueArray[j];
			}
		}
	}
}

void CSimpleNeuralNetPopulation::Update_PopulationKnowledge(void)
{
	CSimpleNeuralNetData *pBestNeuralNet = ppSimpleNeuralNetDataArray[IDArrayOfBestFittedBrains[0]];

	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppSimpleNeuralNetDataArray[i]->Clone_Values(pBestNeuralNet);
	}
}



void CSimpleNeuronPopulation::Replace_WorstFitted_Brain(pReinitializationFunction pFunc, void *pParam)
{
	pFunc(ppNeuronArray[IDArrayOfWorstFittedBrains[0]], &RandomNumbers, pParam);
}

void CSimpleNeuralNetPopulation::Replace_WorstFitted_Brain(pNetReinitializationFunction pFunc, void *pParam)
{
	pFunc(ppSimpleNeuralNetDataArray[IDArrayOfWorstFittedBrains[0]], &RandomNumbers, pParam);
}

void CSimpleNeuronPopulation::Replace_SecondWorstFitted_Brain(pReinitializationFunction pFunc, void *pParam)
{
	pFunc(ppNeuronArray[IDArrayOfWorstFittedBrains[1]], &RandomNumbers, pParam);
}

void CSimpleNeuralNetPopulation::Replace_SecondWorstFitted_Brain(pNetReinitializationFunction pFunc, void *pParam)
{
	pFunc(ppSimpleNeuralNetDataArray[IDArrayOfWorstFittedBrains[1]], &RandomNumbers, pParam);
}

void CSimpleNeuronPopulation::Replace_ThirdWorstFitted_Brain(pReinitializationFunction pFunc, void *pParam)
{
	pFunc(ppNeuronArray[IDArrayOfWorstFittedBrains[2]], &RandomNumbers, pParam);
}

void CSimpleNeuralNetPopulation::Replace_ThirdWorstFitted_Brain(pNetReinitializationFunction pFunc, void *pParam)
{
	pFunc(ppSimpleNeuralNetDataArray[IDArrayOfWorstFittedBrains[2]], &RandomNumbers, pParam);
}

void CSimpleNeuronPopulation::Replace_WorstFitted_Brain(uint64_t seed, pReinitializationFunction pFunc, void *pParam)
{
	RandomNumbers.Change_Seed(seed);
	pFunc(ppNeuronArray[IDArrayOfWorstFittedBrains[0]], &RandomNumbers, pParam);
}

void CSimpleNeuralNetPopulation::Replace_WorstFitted_Brain(uint64_t seed, pNetReinitializationFunction pFunc, void *pParam)
{
	RandomNumbers.Change_Seed(seed);
	pFunc(ppSimpleNeuralNetDataArray[IDArrayOfWorstFittedBrains[0]], &RandomNumbers, pParam);
}

void CSimpleNeuronPopulation::Replace_SecondWorstFitted_Brain(uint64_t seed, pReinitializationFunction pFunc, void *pParam)
{
	RandomNumbers.Change_Seed(seed);
	pFunc(ppNeuronArray[IDArrayOfWorstFittedBrains[1]], &RandomNumbers, pParam);
}

void CSimpleNeuralNetPopulation::Replace_SecondWorstFitted_Brain(uint64_t seed, pNetReinitializationFunction pFunc, void *pParam)
{
	RandomNumbers.Change_Seed(seed);
	pFunc(ppSimpleNeuralNetDataArray[IDArrayOfWorstFittedBrains[1]], &RandomNumbers, pParam);
}

void CSimpleNeuronPopulation::Replace_ThirdWorstFitted_Brain(uint64_t seed, pReinitializationFunction pFunc, void *pParam)
{
	RandomNumbers.Change_Seed(seed);
	pFunc(ppNeuronArray[IDArrayOfWorstFittedBrains[2]], &RandomNumbers, pParam);
}

void CSimpleNeuralNetPopulation::Replace_ThirdWorstFitted_Brain(uint64_t seed, pNetReinitializationFunction pFunc, void *pParam)
{
	RandomNumbers.Change_Seed(seed);
	pFunc(ppSimpleNeuralNetDataArray[IDArrayOfWorstFittedBrains[2]], &RandomNumbers, pParam);
}


CSimpleNeuronAutoEncoder::CSimpleNeuronAutoEncoder()
{}

CSimpleNeuralNet_1HiddenLayer::CSimpleNeuralNet_1HiddenLayer()
{}



CSimpleNeuronAutoEncoder::~CSimpleNeuronAutoEncoder()
{
	delete[] pOutputNeuronArray;
	pOutputNeuronArray = nullptr;
}

bool CSimpleNeuronAutoEncoder::Load_Data(char *pFileName, pDendriticFunction pDendriticFunc, pActivationFunction pActivationFunc)
{
	std::ifstream ReadFile;

	ReadFile.open(pFileName);


	if (ReadFile.good() == false)
	{
		Add_To_Log(0, "cannot open file", pFileName);
		return false;
	}

	int32_t numOfInputOutputValues;

	ReadFile >> numOfInputOutputValues;

	int32_t numOfEncodingDendrites;

	ReadFile >> numOfEncodingDendrites;

	int32_t numOfAdditionalMemoryValues;

	ReadFile >> numOfAdditionalMemoryValues;

	PrecedingNeuron.Init_Dendrite_Arrays(numOfInputOutputValues + numOfEncodingDendrites);
	PrecedingNeuron.Set_InputDendriteInfo(0, numOfInputOutputValues);
	PrecedingNeuron.Set_OutputDendriteInfo(numOfInputOutputValues, numOfEncodingDendrites);
	PrecedingNeuron.Set_DendriticFunction(pDendriticFunc);
	PrecedingNeuron.Init_AdditionalMemoryValues(numOfAdditionalMemoryValues);


	for (int32_t i = 0; i < numOfAdditionalMemoryValues; i++)
	{
		ReadFile >> PrecedingNeuron.pAdditionalMemoryValueArray[i];
	}

	if (numOfInputOutputValues > NumOfInputOutputValues)
	{
		delete[] pOutputNeuronArray;
		pOutputNeuronArray = nullptr;

		pOutputNeuronArray = new (std::nothrow) CSimpleNeuron[numOfInputOutputValues];
	}

	NumOfInputOutputValues = numOfInputOutputValues;

	CSimpleNeuron *pOutputNeuron = nullptr;

	for (int32_t i = 0; i < numOfInputOutputValues; i++)
	{
		pOutputNeuronArray[i].Init_Dendrite_Arrays(numOfEncodingDendrites);
		pOutputNeuronArray[i].Use_OtherNeuron_Dendrite_DataArray(PrecedingNeuron.pDendrite_DataArray, numOfInputOutputValues);
		pOutputNeuronArray[i].Set_ActivationFunction(pActivationFunc);
		
		pOutputNeuron = &pOutputNeuronArray[i];

		for (int32_t j = 0; j < numOfEncodingDendrites; j++)
		{
			ReadFile >> pOutputNeuron->pDendrite_FactorArray[j];
		}
	}

	ReadFile.close();

	return true;
}

bool CSimpleNeuronAutoEncoder::Save_Data(char *pFileName)
{
	std::ofstream WriteFile;

	// neue Datei erzeugen bzw. alte �berschreiben:
	WriteFile.open(pFileName);

	if (WriteFile.good() == false)
	{
		Add_To_Log(0, "cannot create file", pFileName);
		return false;
	}

	WriteFile << NumOfInputOutputValues << "  ";

	int32_t numOfEncodingDendrites = PrecedingNeuron.NumOfOutputDendrites;

	WriteFile << numOfEncodingDendrites << "  ";

	int32_t numOfAdditionalMemoryValues = PrecedingNeuron.NumOfAdditionalMemoryValues;;

	WriteFile << numOfAdditionalMemoryValues << "  ";

	for (int32_t i = 0; i < numOfAdditionalMemoryValues; i++)
	{
		WriteFile << PrecedingNeuron.pAdditionalMemoryValueArray[i] << "  ";
	}

	CSimpleNeuron *pOutputNeuron = nullptr;

	for (int32_t i = 0; i < NumOfInputOutputValues; i++)
	{
		pOutputNeuron = &pOutputNeuronArray[i];

		for (int32_t j = 0; j < numOfEncodingDendrites; j++)
		{
			WriteFile << pOutputNeuron->pDendrite_FactorArray[j] << "  ";
		}
	}

	WriteFile.close();

	return true;
}

CSimpleNeuralNet_1HiddenLayer::~CSimpleNeuralNet_1HiddenLayer()
{
	delete[] pOutputNeuronArray;
	pOutputNeuronArray = nullptr;
}


bool CSimpleNeuralNet_1HiddenLayer::Load_Data(char *pFileName, pDendriticFunction pDendriticFunc, pActivationFunction pActivationFunc)
{
	// numOfOfEncodingDendrites := ProcessingNeuralNet_NumOfHiddenDendrites

	std::ifstream ReadFile;

	ReadFile.open(pFileName);


	if (ReadFile.good() == false)
	{
		Add_To_Log(0, "cannot open file", pFileName);
		return false;
	}

	
	ReadFile >> NumOfInputValues;

	int32_t numOfOutputValues;

	ReadFile >> numOfOutputValues;

	int32_t numOfHiddenDendrites;

	ReadFile >> numOfHiddenDendrites;

	int32_t numOfAdditionalMemoryValues;

	ReadFile >> numOfAdditionalMemoryValues;

	PrecedingNeuron.Init_Dendrite_Arrays(NumOfInputValues + numOfHiddenDendrites);
	PrecedingNeuron.Set_InputDendriteInfo(0, NumOfInputValues);
	PrecedingNeuron.Set_OutputDendriteInfo(NumOfInputValues, numOfHiddenDendrites);
	PrecedingNeuron.Set_DendriticFunction(pDendriticFunc);
	PrecedingNeuron.Init_AdditionalMemoryValues(numOfAdditionalMemoryValues);

	
	for (int32_t i = 0; i < numOfAdditionalMemoryValues; i++)
	{
		ReadFile >> PrecedingNeuron.pAdditionalMemoryValueArray[i];
	}

	if (numOfOutputValues > NumOfOutputValues)
	{
		delete[] pOutputNeuronArray;
		pOutputNeuronArray = nullptr;

		pOutputNeuronArray = new (std::nothrow) CSimpleNeuron[numOfOutputValues];
	}

	NumOfOutputValues = numOfOutputValues;

	CSimpleNeuron *pOutputNeuron = nullptr;

	for (int32_t i = 0; i < numOfOutputValues; i++)
	{
		pOutputNeuronArray[i].Init_Dendrite_Arrays(numOfHiddenDendrites);
		pOutputNeuronArray[i].Use_OtherNeuron_Dendrite_DataArray(PrecedingNeuron.pDendrite_DataArray, NumOfInputValues);
		pOutputNeuronArray[i].Set_ActivationFunction(pActivationFunc);
		
		pOutputNeuron = &pOutputNeuronArray[i];

		for (int32_t j = 0; j < numOfHiddenDendrites; j++)
		{
			ReadFile >> pOutputNeuron->pDendrite_FactorArray[j];
		}
	}

	ReadFile.close();

	return true;
}

bool CSimpleNeuralNet_1HiddenLayer::Save_Data(char *pFileName)
{
	std::ofstream WriteFile;

	// neue Datei erzeugen bzw. alte �berschreiben:
	WriteFile.open(pFileName);

	if (WriteFile.good() == false)
	{
		Add_To_Log(0, "cannot create file", pFileName);
		return false;
	}

	WriteFile << NumOfInputValues << "  ";
	WriteFile << NumOfOutputValues << "  ";

	int32_t numOfHiddenDendrites = PrecedingNeuron.NumOfOutputDendrites;

	WriteFile << numOfHiddenDendrites << "  ";

	int32_t numOfAdditionalMemoryValues = PrecedingNeuron.NumOfAdditionalMemoryValues;;

	WriteFile << numOfAdditionalMemoryValues << "  ";

	for (int32_t i = 0; i < numOfAdditionalMemoryValues; i++)
	{
		WriteFile << PrecedingNeuron.pAdditionalMemoryValueArray[i] << "  ";
	}

	CSimpleNeuron *pOutputNeuron = nullptr;

	for (int32_t i = 0; i < NumOfOutputValues; i++)
	{
		pOutputNeuron = &pOutputNeuronArray[i];

		for (int32_t j = 0; j < numOfHiddenDendrites; j++)
		{
			WriteFile << pOutputNeuron->pDendrite_FactorArray[j] << "  ";
		}
	}

	WriteFile.close();

	return true;
}


void CSimpleNeuronAutoEncoder::Set_ExternalSingleRecognitionNeuron(CSimpleNeuron *pNeuron)
{
	pExternalSingleRecognitionNeuron = pNeuron;
}


void CSimpleNeuronAutoEncoder::Init_PrecedingNeuron(int32_t numOfInputOutputValues, int32_t numOfOfEncodingDendrites, pDendriticFunction pFunc, CRandomNumbersNN *pRandomNumbers, float minDendriteFactor, float maxDendriteFactor, float minDendriteAbsFactor, float maxDendriteAbsFactor)
{
	//NumOfInputOutputValues = numOfInputOutputValues;

	int32_t numOfAdditionalMemoryValues = numOfInputOutputValues * numOfOfEncodingDendrites;

	float *pMemoryValueArray = new (std::nothrow) float[numOfAdditionalMemoryValues];

	Init_RandomNumbersTableExt3(pMemoryValueArray, numOfAdditionalMemoryValues, pRandomNumbers, minDendriteFactor, maxDendriteFactor, minDendriteAbsFactor, maxDendriteAbsFactor);

	PrecedingNeuron.Init_Dendrite_Arrays(numOfInputOutputValues + numOfOfEncodingDendrites);
	PrecedingNeuron.Set_InputDendriteInfo(0, numOfInputOutputValues);
	PrecedingNeuron.Set_OutputDendriteInfo(numOfInputOutputValues, numOfOfEncodingDendrites);
	PrecedingNeuron.Set_DendriticFunction(pFunc);
	PrecedingNeuron.Init_AdditionalMemoryValues(pMemoryValueArray, numOfAdditionalMemoryValues);

	delete[] pMemoryValueArray;
	pMemoryValueArray = nullptr;
}

void CSimpleNeuronAutoEncoder::Init_PrecedingNeuron(int32_t numOfInputOutputValues, int32_t numOfOfEncodingDendrites, pDendriticFunction pFunc, float *pMemoryValueArray, int32_t numOfAdditionalMemoryValues)
{
	//NumOfInputOutputValues = numOfInputOutputValues;

	PrecedingNeuron.Init_Dendrite_Arrays(numOfInputOutputValues + numOfOfEncodingDendrites);
	PrecedingNeuron.Set_InputDendriteInfo(0, numOfInputOutputValues);
	PrecedingNeuron.Set_OutputDendriteInfo(numOfInputOutputValues, numOfOfEncodingDendrites);
	PrecedingNeuron.Set_DendriticFunction(pFunc);
	PrecedingNeuron.Init_AdditionalMemoryValues(pMemoryValueArray, numOfAdditionalMemoryValues);
}

void CSimpleNeuronAutoEncoder::Get_SimpleNeuralNetData(CSimpleNeuralNetData *pOutData)
{
	int32_t numOfNeurons = NumOfInputOutputValues + /*PrecedingNeuron*/ 1;

	pOutData->Init_Data(numOfNeurons);

	int32_t neuronCounter = 0;

	pOutData->Set_Neuron(&PrecedingNeuron, neuronCounter);
	neuronCounter++;

	for (int32_t i = 0; i < NumOfInputOutputValues; i++)
	{
		pOutData->Set_Neuron(&pOutputNeuronArray[i], neuronCounter);
		neuronCounter++;
	}
}

void CSimpleNeuralNet_1HiddenLayer::Get_SimpleNeuralNetData(CSimpleNeuralNetData *pOutData)
{
	int32_t numOfNeurons = NumOfOutputValues + /*PrecedingNeuron*/ 1;

	pOutData->Init_Data(numOfNeurons);

	int32_t neuronCounter = 0;

	pOutData->Set_Neuron(&PrecedingNeuron, neuronCounter);
	neuronCounter++;

	for (int32_t i = 0; i < NumOfOutputValues; i++)
	{
		pOutData->Set_Neuron(&pOutputNeuronArray[i], neuronCounter);
		neuronCounter++;
	}
}

void CSimpleNeuralNet_1HiddenLayer::Init_PrecedingNeuron(int32_t numOfInputValues, int32_t numOfHiddenDendrites, pDendriticFunction pFunc, CRandomNumbersNN *pRandomNumbers, float minDendriteFactor, float maxDendriteFactor, float minDendriteAbsFactor, float maxDendriteAbsFactor)
{
	int32_t numOfAdditionalMemoryValues = numOfInputValues * numOfHiddenDendrites;

	float *pMemoryValueArray = new (std::nothrow) float[numOfAdditionalMemoryValues];

	Init_RandomNumbersTableExt3(pMemoryValueArray, numOfAdditionalMemoryValues, pRandomNumbers, minDendriteFactor, maxDendriteFactor, minDendriteAbsFactor, maxDendriteAbsFactor);

	NumOfInputValues = numOfInputValues;

	PrecedingNeuron.Init_Dendrite_Arrays(numOfInputValues + numOfHiddenDendrites);
	PrecedingNeuron.Set_InputDendriteInfo(0, numOfInputValues);
	PrecedingNeuron.Set_OutputDendriteInfo(numOfInputValues, numOfHiddenDendrites);
	PrecedingNeuron.Set_DendriticFunction(pFunc);
	PrecedingNeuron.Init_AdditionalMemoryValues(pMemoryValueArray, numOfAdditionalMemoryValues);

	delete[] pMemoryValueArray;
	pMemoryValueArray = nullptr;
}

void CSimpleNeuralNet_1HiddenLayer::Init_PrecedingNeuron(int32_t numOfInputValues, int32_t numOfHiddenDendrites, pDendriticFunction pFunc, float *pMemoryValueArray, int32_t numOfAdditionalMemoryValues)
{
	NumOfInputValues = numOfInputValues;

	PrecedingNeuron.Init_Dendrite_Arrays(numOfInputValues + numOfHiddenDendrites);
	PrecedingNeuron.Set_InputDendriteInfo(0, numOfInputValues);
	PrecedingNeuron.Set_OutputDendriteInfo(numOfInputValues, numOfHiddenDendrites);
	PrecedingNeuron.Set_DendriticFunction(pFunc);
	PrecedingNeuron.Init_AdditionalMemoryValues(pMemoryValueArray, numOfAdditionalMemoryValues);
}

void CSimpleNeuronAutoEncoder::Init_OutputNeuronArray(int32_t numOfInputOutputValues, int32_t numOfEncodingDendrites, pActivationFunction pFunc, CRandomNumbersNN *pRandomNumbers, float minDendriteFactor, float maxDendriteFactor)
{
	if (numOfInputOutputValues > NumOfInputOutputValues)
	{
		delete[] pOutputNeuronArray;
		pOutputNeuronArray = nullptr;

		pOutputNeuronArray = new (std::nothrow) CSimpleNeuron[numOfInputOutputValues];
	}

	NumOfInputOutputValues = numOfInputOutputValues;

	for (int32_t i = 0; i < numOfInputOutputValues; i++)
	{
		pOutputNeuronArray[i].Init_Dendrite_Arrays(numOfEncodingDendrites);
		pOutputNeuronArray[i].Use_OtherNeuron_Dendrite_DataArray(PrecedingNeuron.pDendrite_DataArray, numOfInputOutputValues);
		pOutputNeuronArray[i].Set_ActivationFunction(pFunc);
		pOutputNeuronArray[i].Randomize_Dendrite_Factors(pRandomNumbers, minDendriteFactor, maxDendriteFactor);
	}
}

void CSimpleNeuronAutoEncoder::Init_OutputNeuronArray(int32_t numOfInputOutputValues, int32_t numOfEncodingDendrites, pActivationFunction pFunc)
{
	if (numOfInputOutputValues > NumOfInputOutputValues)
	{
		delete[] pOutputNeuronArray;
		pOutputNeuronArray = nullptr;

		pOutputNeuronArray = new (std::nothrow) CSimpleNeuron[numOfInputOutputValues];
	}

	NumOfInputOutputValues = numOfInputOutputValues;

	for (int32_t i = 0; i < numOfInputOutputValues; i++)
	{
		pOutputNeuronArray[i].Init_Dendrite_Arrays(numOfEncodingDendrites);
		pOutputNeuronArray[i].Use_OtherNeuron_Dendrite_DataArray(PrecedingNeuron.pDendrite_DataArray, numOfInputOutputValues);
		pOutputNeuronArray[i].Set_ActivationFunction(pFunc);
	}
}

void CSimpleNeuralNet_1HiddenLayer::Init_OutputNeuronArray(int32_t numOfOutputValues, int32_t numOfHiddenDendrites, pActivationFunction pFunc, CRandomNumbersNN *pRandomNumbers, float minDendriteFactor, float maxDendriteFactor)
{
	if (numOfOutputValues > NumOfOutputValues)
	{
		delete[] pOutputNeuronArray;
		pOutputNeuronArray = nullptr;

		pOutputNeuronArray = new (std::nothrow) CSimpleNeuron[numOfOutputValues];
	}

	NumOfOutputValues = numOfOutputValues;

	for (int32_t i = 0; i < numOfOutputValues; i++)
	{
		pOutputNeuronArray[i].Init_Dendrite_Arrays(numOfHiddenDendrites);
		pOutputNeuronArray[i].Use_OtherNeuron_Dendrite_DataArray(PrecedingNeuron.pDendrite_DataArray, NumOfInputValues);
		pOutputNeuronArray[i].Set_ActivationFunction(pFunc);
		pOutputNeuronArray[i].Randomize_Dendrite_Factors(pRandomNumbers, minDendriteFactor, maxDendriteFactor);
	}
}

void CSimpleNeuronAutoEncoder::Calculate_Output(void)
{
	PrecedingNeuron.Execute_DendriticCalculations();

	for (int32_t i = 0; i < NumOfInputOutputValues; i++)
	{
		pOutputNeuronArray[i].Calculate_NeuronOutput();
	}
}


void CSimpleNeuralNet_1HiddenLayer::Use_OtherNeuralNetOutput_As_Input(CSimpleNeuralNet_1HiddenLayer* pNeuralNet, int32_t firstInputDendriteID)
{
	int32_t numInputValues = pNeuralNet->NumOfOutputValues;
	int32_t dendriteID = firstInputDendriteID;

	for (int32_t i = 0; i < numInputValues; i++)
	{
		PrecedingNeuron.Set_Dendrite_NeuronInput(pNeuralNet->pOutputNeuronArray[i].ActivationValue, dendriteID);
		dendriteID++;
	}
}

void CSimpleNeuralNet_1HiddenLayer::Calculate_Output(void)
{
	PrecedingNeuron.Execute_DendriticCalculations();

	for (int32_t i = 0; i < NumOfOutputValues; i++)
	{
		pOutputNeuronArray[i].Calculate_NeuronOutput();
	}
}

float CSimpleNeuralNet_1HiddenLayer::CalculateAndReturn_MaxOutput(void)
{
	float maxOutput = -1000000.0f;

	PrecedingNeuron.Execute_DendriticCalculations();

	for (int32_t i = 0; i < NumOfOutputValues; i++)
	{
		pOutputNeuronArray[i].Calculate_NeuronOutput();

		maxOutput = max(maxOutput, pOutputNeuronArray[i].ActivationValue);
	}

	return maxOutput;
}

float CSimpleNeuralNet_1HiddenLayer::CalculateAndReturn_MinOutput(void)
{
	float minOutput = 1000000.0f;

	PrecedingNeuron.Execute_DendriticCalculations();

	for (int32_t i = 0; i < NumOfOutputValues; i++)
	{
		pOutputNeuronArray[i].Calculate_NeuronOutput();

		minOutput = min(minOutput, pOutputNeuronArray[i].ActivationValue);
	}

	return minOutput;
}


void CSimpleNeuralNet_1HiddenLayer::CalculateAndReturn_Output(float *pOutputValueArray)
{
	for (int32_t i = 0; i < NumOfOutputValues; i++)
	{
		pOutputNeuronArray[i].Calculate_NeuronOutput();
	}

	for (int32_t i = 0; i < NumOfOutputValues; i++)
	{
		pOutputValueArray[i] = pOutputNeuronArray[i].ActivationValue;
	}
}

float CSimpleNeuronAutoEncoder::Calculate_Output_Return_VarianceSq(float *pDesiredOutputValueArray)
{
	PrecedingNeuron.Execute_DendriticCalculations();

	for (int32_t i = 0; i < NumOfInputOutputValues; i++)
	{
		pOutputNeuronArray[i].Calculate_NeuronOutput();
	}

	int32_t usedDendritesMinID = PrecedingNeuron.UsedDendritesMinID;
	int32_t usedDendritesMaxIDPlus1 = PrecedingNeuron.UsedDendritesMaxIDPlus1;
	int32_t counter = 0;

	float varianceSqSum = 0;
	float varianceSq;

	for (int32_t i = usedDendritesMinID; i < usedDendritesMaxIDPlus1; i++)
	{
		varianceSq = pOutputNeuronArray[counter].ActivationValue - pDesiredOutputValueArray[i];
		varianceSq *= varianceSq;
		varianceSqSum += varianceSq;
		counter++;
	}

	if (pExternalSingleRecognitionNeuron != nullptr)
	{
		pExternalSingleRecognitionNeuron->Set_AdditionalInputValue(varianceSqSum);
	}

	return varianceSqSum;
}

float CSimpleNeuronAutoEncoder::Calculate_Output_Return_InputOutputVarianceSq(void)
{
	PrecedingNeuron.Execute_DendriticCalculations();

	for (int32_t i = 0; i < NumOfInputOutputValues; i++)
	{
		pOutputNeuronArray[i].Calculate_NeuronOutput();
	}

	int32_t usedDendritesMinID = PrecedingNeuron.UsedDendritesMinID;
	int32_t usedDendritesMaxIDPlus1 = PrecedingNeuron.UsedDendritesMaxIDPlus1;
	int32_t counter = 0;

	float varianceSqSum = 0;
	float varianceSq;

	for (int32_t i = usedDendritesMinID; i < usedDendritesMaxIDPlus1; i++)
	{
		varianceSq = pOutputNeuronArray[counter].ActivationValue - /*neuralNetInputValues:*/ PrecedingNeuron.pDendrite_DataArray[i];
		varianceSq *= varianceSq;
		varianceSqSum += varianceSq;
		counter++;
	}

	if (pExternalSingleRecognitionNeuron != nullptr)
	{
		pExternalSingleRecognitionNeuron->Set_AdditionalInputValue(varianceSqSum);
	}

	return varianceSqSum;
}

void CSimpleNeuronAutoEncoder::Calculate_Output(float *pOutputValueArray)
{
	PrecedingNeuron.Execute_DendriticCalculations();

	for (int32_t i = 0; i < NumOfInputOutputValues; i++)
	{
		pOutputNeuronArray[i].Calculate_NeuronOutput();
	}

	for (int32_t i = 0; i < NumOfInputOutputValues; i++)
	{
		pOutputValueArray[i] = pOutputNeuronArray[i].ActivationValue;
	}
}

float CSimpleNeuronAutoEncoder::CalculateAndReturn_Output_Return_VarianceSq(float *pOutputValueArray, float *pDesiredOutputValueArray)
{
	PrecedingNeuron.Execute_DendriticCalculations();

	for (int32_t i = 0; i < NumOfInputOutputValues; i++)
	{
		pOutputNeuronArray[i].Calculate_NeuronOutput();
	}

	for (int32_t i = 0; i < NumOfInputOutputValues; i++)
	{
		pOutputValueArray[i] = pOutputNeuronArray[i].ActivationValue;
	}

	int32_t usedDendritesMinID = PrecedingNeuron.UsedDendritesMinID;
	int32_t usedDendritesMaxIDPlus1 = PrecedingNeuron.UsedDendritesMaxIDPlus1;
	int32_t counter = 0;

	float varianceSqSum = 0;
	float varianceSq;

	for (int32_t i = usedDendritesMinID; i < usedDendritesMaxIDPlus1; i++)
	{
		varianceSq = pOutputNeuronArray[counter].ActivationValue - pDesiredOutputValueArray[i];
		varianceSq *= varianceSq;
		varianceSqSum += varianceSq;
		counter++;
	}

	if (pExternalSingleRecognitionNeuron != nullptr)
	{
		pExternalSingleRecognitionNeuron->Set_AdditionalInputValue(varianceSqSum);
	}

	return varianceSqSum;
}

float CSimpleNeuronAutoEncoder::CalculateAndReturn_Output_Return_InputOutputVarianceSq(float *pOutputValueArray)
{
	PrecedingNeuron.Execute_DendriticCalculations();

	for (int32_t i = 0; i < NumOfInputOutputValues; i++)
	{
		pOutputNeuronArray[i].Calculate_NeuronOutput();
	}

	for (int32_t i = 0; i < NumOfInputOutputValues; i++)
	{
		pOutputValueArray[i] = pOutputNeuronArray[i].ActivationValue;
	}

	int32_t usedDendritesMinID = PrecedingNeuron.UsedDendritesMinID;
	int32_t usedDendritesMaxIDPlus1 = PrecedingNeuron.UsedDendritesMaxIDPlus1;
	int32_t counter = 0;

	float varianceSqSum = 0;
	float varianceSq;

	for (int32_t i = usedDendritesMinID; i < usedDendritesMaxIDPlus1; i++)
	{
		varianceSq = pOutputNeuronArray[counter].ActivationValue - /*neuralNetInputValues:*/ PrecedingNeuron.pDendrite_DataArray[i];
		varianceSq *= varianceSq;
		varianceSqSum += varianceSq;
		counter++;
	}

	if (pExternalSingleRecognitionNeuron != nullptr)
	{
		pExternalSingleRecognitionNeuron->Set_AdditionalInputValue(varianceSqSum);
	}

	return varianceSqSum;
}

void CSimpleNeuronAutoEncoder::OutputNeurons_Adjust_Dendrite_Factors_AfterErrorCalculations(float learningRate)
{
	for (int32_t i = 0; i < NumOfInputOutputValues; i++)
	{
		pOutputNeuronArray[i].Adjust_Dendrite_Factors_AfterErrorCalculations_ExternalInput(learningRate);
	}
}

void CSimpleNeuralNet_1HiddenLayer::OutputNeurons_Adjust_Dendrite_Factors_AfterErrorCalculations(float learningRate)
{
	for (int32_t i = 0; i < NumOfOutputValues; i++)
	{
		pOutputNeuronArray[i].Adjust_Dendrite_Factors_AfterErrorCalculations_ExternalInput(learningRate);
	}
}

float CSimpleNeuronAutoEncoder::OutputNeurons_Adjust_Dendrite_Factors(float learningRate, float errorFactor1, float errorFactor2)
{
	float  errorSum = 0.0f;

	for (int32_t i = 0; i < NumOfInputOutputValues; i++)
	{
		errorSum += pOutputNeuronArray[i].Adjust_Dendrite_Factors_ExternalInput(/*neuralNetInputValues:*/ PrecedingNeuron.pDendrite_DataArray[i], learningRate, errorFactor1, errorFactor2);
	}

	return errorSum;
}

float CSimpleNeuralNet_1HiddenLayer::OutputNeurons_Adjust_Dendrite_Factors(float *pDesiredOutputValueArray, float learningRate, float errorFactor1, float errorFactor2)
{
	float  errorSum = 0.0f;

	for (int32_t i = 0; i < NumOfOutputValues; i++)
	{
		errorSum += pOutputNeuronArray[i].Adjust_Dendrite_Factors_ExternalInput(pDesiredOutputValueArray[i], learningRate, errorFactor1, errorFactor2);
	}

	return errorSum;
}

float CSimpleNeuronAutoEncoder::OutputNeurons_Adjust_Dendrite_Factors(float *pDesiredOutputValueArray, float learningRate, float errorFactor1, float errorFactor2)
{
	float  errorSum = 0.0f;

	for (int32_t i = 0; i < NumOfInputOutputValues; i++)
	{
		errorSum += pOutputNeuronArray[i].Adjust_Dendrite_Factors_ExternalInput(pDesiredOutputValueArray[i], learningRate, errorFactor1, errorFactor2);
	}

	return errorSum;
}

float CSimpleNeuronAutoEncoder::OutputNeurons_ErrorCalculations(float errorFactor1, float errorFactor2)
{
	float  errorSum = 0.0f;

	for (int32_t i = 0; i < NumOfInputOutputValues; i++)
	{
		errorSum += pOutputNeuronArray[i].Calculate_Error(/*neuralNetInputValues:*/ PrecedingNeuron.pDendrite_DataArray[i], errorFactor1, errorFactor2);
	}

	return errorSum;
}

float CSimpleNeuronAutoEncoder::OutputNeurons_ErrorCalculations(float *pDesiredOutputValueArray, float errorFactor1, float errorFactor2)
{
	float  errorSum = 0.0f;

	for (int32_t i = 0; i < NumOfInputOutputValues; i++)
	{
		errorSum += pOutputNeuronArray[i].Calculate_Error(pDesiredOutputValueArray[i], errorFactor1, errorFactor2);
	}

	return errorSum;
}

float CSimpleNeuralNet_1HiddenLayer::OutputNeurons_Calculate_VarianceSq(float *pDesiredOutputValueArray)
{
	float  varianceSqSum = 0;

	for (int32_t i = 0; i < NumOfOutputValues; i++)
	{
		varianceSqSum += pOutputNeuronArray[i].Calculate_VarianceSq(pDesiredOutputValueArray[i]);
	}

	return varianceSqSum;
}

float CSimpleNeuronAutoEncoder::OutputNeurons_Calculate_VarianceSq(float *pDesiredOutputValueArray)
{
	float  varianceSqSum = 0;

	for (int32_t i = 0; i < NumOfInputOutputValues; i++)
	{
		varianceSqSum += pOutputNeuronArray[i].Calculate_VarianceSq(pDesiredOutputValueArray[i]);
	}

	return varianceSqSum;
}

float CSimpleNeuralNet_1HiddenLayer::OutputNeurons_ErrorCalculations(float *pDesiredOutputValueArray, float errorFactor1, float errorFactor2)
{
	float  errorSum = 0.0f;

	for (int32_t i = 0; i < NumOfOutputValues; i++)
	{
		errorSum += pOutputNeuronArray[i].Calculate_Error(pDesiredOutputValueArray[i], errorFactor1, errorFactor2);
	}

	return errorSum;
}

CSimpleDeepNeuralNet_Test1::CSimpleDeepNeuralNet_Test1()
{}

CSimpleDeepNeuralNet_Base::CSimpleDeepNeuralNet_Base()
{}

CSimpleDeepNeuralNet_Test1::~CSimpleDeepNeuralNet_Test1()
{
	delete[] pLRFNeuronArray_Layer1;
	pLRFNeuronArray_Layer1 = nullptr;

	delete[] pLRFNeuronArray_Layer2;
	pLRFNeuronArray_Layer2 = nullptr;  

	delete[] pFeatureMapArray_Layer1;
	pFeatureMapArray_Layer1 = nullptr;

	delete[] pHalfResFeatureMapArray_Layer1;
	pHalfResFeatureMapArray_Layer1 = nullptr;

	delete[] pFeatureMapArray_Layer2;
	pFeatureMapArray_Layer2 = nullptr;

	delete[] pHalfResFeatureMapArray_Layer2;
	pHalfResFeatureMapArray_Layer2 = nullptr;
}

CSimpleDeepNeuralNet_Base::~CSimpleDeepNeuralNet_Base()
{
	delete[] pLRFNeuronArray_Layer1;
	pLRFNeuronArray_Layer1 = nullptr;

	delete[] pFeatureMapArray_Layer1;
	pFeatureMapArray_Layer1 = nullptr;

	delete[] pHalfResFeatureMapArray_Layer1;
	pHalfResFeatureMapArray_Layer1 = nullptr;

	delete[] pQuarterResFeatureMapArray_Layer1;
	pQuarterResFeatureMapArray_Layer1 = nullptr;
}

void CSimpleDeepNeuralNet_Test1::Get_SimpleNeuralNetData(CSimpleNeuralNetData *pOutData)
{
	int32_t numOfNeurons = NumLRFNeurons_Layer1 + NumLRFNeurons_Layer2 + /*ProcessingNeuralNet.PrecedingNeuron:*/ 1 + ProcessingNeuralNet_NumOfOutputValues;

	pOutData->Init_Data(numOfNeurons);

	pOutData->NumLRFNeurons_Layer1 = NumLRFNeurons_Layer1;
	pOutData->NumLRFNeurons_Layer2 = NumLRFNeurons_Layer2;
	

	int32_t neuronCounter = 0;

	for (int32_t i = 0; i < NumLRFNeurons_Layer1; i++)
	{
		pOutData->Set_Neuron(&pLRFNeuronArray_Layer1[i], neuronCounter);
		neuronCounter++;
	}

	for (int32_t i = 0; i < NumLRFNeurons_Layer2; i++)
	{
		pOutData->Set_Neuron(&pLRFNeuronArray_Layer2[i], neuronCounter);
		neuronCounter++;
	}

	pOutData->Set_Neuron(&ProcessingNeuralNet.PrecedingNeuron, neuronCounter);
	neuronCounter++;

	for (int32_t i = 0; i < ProcessingNeuralNet_NumOfOutputValues; i++)
	{
		pOutData->Set_Neuron(&ProcessingNeuralNet.pOutputNeuronArray[i], neuronCounter);
		neuronCounter++;
	}
}

void CSimpleDeepNeuralNet_Base::Get_SimpleNeuralNetData(CSimpleNeuralNetData *pOutData)
{
	int32_t numOfNeurons = NumLRFNeurons_Layer1 + /*ProcessingNeuralNet.PrecedingNeuron:*/ 1 + ProcessingNeuralNet_NumOfOutputValues;

	pOutData->Init_Data(numOfNeurons);

	pOutData->NumLRFNeurons_Layer1 = NumLRFNeurons_Layer1;

	int32_t neuronCounter = 0;

	for (int32_t i = 0; i < NumLRFNeurons_Layer1; i++)
	{
		pOutData->Set_Neuron(&pLRFNeuronArray_Layer1[i], neuronCounter);
		neuronCounter++;
	}

	pOutData->Set_Neuron(&ProcessingNeuralNet.PrecedingNeuron, neuronCounter);
	neuronCounter++;

	for (int32_t i = 0; i < ProcessingNeuralNet_NumOfOutputValues; i++)
	{
		pOutData->Set_Neuron(&ProcessingNeuralNet.pOutputNeuronArray[i], neuronCounter);
		neuronCounter++;
	}
}


float CSimpleDeepNeuralNet_Test1::OutputNeurons_Calculate_VarianceSq(float *pDesiredOutputValueArray)
{
	return ProcessingNeuralNet.OutputNeurons_Calculate_VarianceSq(pDesiredOutputValueArray);
}

float CSimpleDeepNeuralNet_Base::OutputNeurons_Calculate_VarianceSq(float *pDesiredOutputValueArray)
{
	return ProcessingNeuralNet.OutputNeurons_Calculate_VarianceSq(pDesiredOutputValueArray);
}

void  CSimpleDeepNeuralNet_Base::BackpropagationTraining(float *pInOutError, float *pDesiredOutputValuesArray)
{
	/*
	*pInOutError += ProcessingNeuralNet.OutputNeurons_ErrorCalculations(pDesiredOutputValuesArray, 1.0f, 0.005f);
	PrecedingNeuronErrorCalculations(&ProcessingNeuralNet.PrecedingNeuron, &ProcessingNeuralNet.pOutputNeuronArray[0], ProcessingNeuralNet_NumOfOutputValues, 1.0f, 0.005f);
	PrecedingNeuronLearning(&ProcessingNeuralNet.PrecedingNeuron, 0.01f);
	ProcessingNeuralNet.OutputNeurons_Adjust_Dendrite_Factors_AfterErrorCalculations(0.01f);
	*/

	// extreme learning:
	// *pInOutError += ProcessingNeuralNet.OutputNeurons_Adjust_Dendrite_Factors(pDesiredOutputValuesArray, 0.02f, 1.0f, 0.005f);

	// normal learning:
	*pInOutError += ProcessingNeuralNet.OutputNeurons_ErrorCalculations(pDesiredOutputValuesArray, 1.0f, 0.005f);
	//*pInOutError += ProcessingNeuralNet.OutputNeurons_ErrorCalculations(pDesiredOutputValuesArray, 2.0f, 0.005f);
	
	PrecedingNeuronErrorCalculations(&ProcessingNeuralNet.PrecedingNeuron, &ProcessingNeuralNet.pOutputNeuronArray[0], ProcessingNeuralNet_NumOfOutputValues, 1.0f, 0.005f);

	Calculate_InputDendritesErrorValues(&ProcessingNeuralNet.PrecedingNeuron, 1.0f, 0.005f);

	PrecedingNeuronLearning(&ProcessingNeuralNet.PrecedingNeuron, 0.01f);
	ProcessingNeuralNet.OutputNeurons_Adjust_Dendrite_Factors_AfterErrorCalculations(0.005f);

	int32_t inputDendriteCounter = 0;

	for (int32_t i = 0; i < NumLRFNeurons_Layer1; i++)
	{
		float maxNegErrorValue = 0.0f;
		float maxPosErrorValue = 0.0f;

		//int32_t size = pHalfResFeatureMapArray_Layer1[i].Size;
		int32_t size = pQuarterResFeatureMapArray_Layer1[i].Size;

		for (int32_t j = 0; j < size; j++)
		{
			float errorValue = ProcessingNeuralNet.PrecedingNeuron.pDendrite_ErrorValueArray[inputDendriteCounter];

			maxNegErrorValue = min(maxNegErrorValue, errorValue);
			maxPosErrorValue = max(maxPosErrorValue, errorValue);

			inputDendriteCounter++;
		}

		if (abs(maxNegErrorValue) > abs(maxPosErrorValue))
			pLRFNeuronArray_Layer1[i].ErrorValue = maxNegErrorValue;
		else
			pLRFNeuronArray_Layer1[i].ErrorValue = maxPosErrorValue;

		//pLRFNeuronArray_Layer1[i].SimpleAdjust_Dendrite_Factors_AfterErrorCalculations(0.005f);
		pLRFNeuronArray_Layer1[i].SimpleAdjust_Dendrite_Factors_AfterErrorCalculations(0.0025f);
	}
}

void CSimpleDeepNeuralNet_Test1::Initialize(CRandomNumbersNN *pLRFRandomNumbers, CRandomNumbersNN *pNeuralNetRandomNumbers, int32_t numLRFNeurons_Layer1, int32_t LRFSizeX_Layer1, int32_t LRFSizeY_Layer1, int32_t numLRFNeurons_Layer2, int32_t LRFSizeX_Layer2, int32_t LRFSizeY_Layer2, float LRF_MinRandomFactor, float LRF_MaxRandomFactor, int32_t inputVectorSizeX, int32_t inputVectorSizeY, int32_t processingNeuralNet_NumOfHiddenDendrites, int32_t processingNeuralNet_NumOfOutputValues)
{
	ProcessingNeuralNet_NumOfOutputValues = processingNeuralNet_NumOfOutputValues;
	ProcessingNeuralNet_NumOfHiddenDendrites = processingNeuralNet_NumOfHiddenDendrites;

	LRFSizeX_Layer1 = min(LRFSizeX_Layer1, 11);
	LRFSizeY_Layer1 = min(LRFSizeY_Layer1, 11);

	LRFSizeX_Layer2 = min(LRFSizeX_Layer2, 11);
	LRFSizeY_Layer2 = min(LRFSizeY_Layer2, 11);

	NumLRFNeurons_Layer1 = numLRFNeurons_Layer1;
	NumLRFNeurons_Layer2 = numLRFNeurons_Layer2;

	delete[] pLRFNeuronArray_Layer1;
	pLRFNeuronArray_Layer1 = nullptr;

	delete[] pLRFNeuronArray_Layer2;
	pLRFNeuronArray_Layer2 = nullptr;

	delete[] pFeatureMapArray_Layer1;
	pFeatureMapArray_Layer1 = nullptr;

	delete[] pHalfResFeatureMapArray_Layer1;
	pHalfResFeatureMapArray_Layer1 = nullptr;

	delete[] pFeatureMapArray_Layer2;
	pFeatureMapArray_Layer2 = nullptr;

	delete[] pHalfResFeatureMapArray_Layer2;
	pHalfResFeatureMapArray_Layer2 = nullptr;

	pLRFNeuronArray_Layer1 = new (std::nothrow) CSimpleNeuron[numLRFNeurons_Layer1];
	pFeatureMapArray_Layer1 = new (std::nothrow) CSimpleFeatureMap[numLRFNeurons_Layer1];
	pHalfResFeatureMapArray_Layer1 = new (std::nothrow) CSimpleFeatureMap[numLRFNeurons_Layer1];

	pLRFNeuronArray_Layer2 = new (std::nothrow) CSimpleNeuron[numLRFNeurons_Layer2];
	pFeatureMapArray_Layer2 = new (std::nothrow) CSimpleFeatureMap[numLRFNeurons_Layer2];
	pHalfResFeatureMapArray_Layer2 = new (std::nothrow) CSimpleFeatureMap[numLRFNeurons_Layer2];

	float LRF_CentroidValueArray[11 * 11 + 1];
	float LRF_FactorArray[11 * 11 + 1];

	float LRFSize = LRFSizeX_Layer1 * LRFSizeY_Layer1;

	for (int32_t i = 0; i < NumLRFNeurons_Layer1; i++)
	{
		for (int32_t j = 0; j <= LRFSize; j++)
		{
			LRF_FactorArray[j] = pLRFRandomNumbers->Get_FloatNumber(LRF_MinRandomFactor, LRF_MaxRandomFactor);
			LRF_CentroidValueArray[j] = LRF_FactorArray[j];
		}

		pLRFNeuronArray_Layer1[i].Init_Dendrite_Arrays(LRFSizeX_Layer1 * LRFSizeY_Layer1 + /*bias:*/ 1);
		pLRFNeuronArray_Layer1[i].Set_ActivationFunction(ConvolutionalKernel);
		pLRFNeuronArray_Layer1[i].Set_LocalReceptiveFieldSizeInfo(LRFSizeX_Layer1, LRFSizeY_Layer1);
		pLRFNeuronArray_Layer1[i].Set_Dendrite_Data(LRF_CentroidValueArray, LRF_FactorArray);
		
	}

	LRFSize = LRFSizeX_Layer2 * LRFSizeY_Layer2;

	for (int32_t i = 0; i < NumLRFNeurons_Layer2; i++)
	{
		for (int32_t j = 0; j <= LRFSize; j++)
		{
			LRF_FactorArray[j] = pLRFRandomNumbers->Get_FloatNumber(LRF_MinRandomFactor, LRF_MaxRandomFactor);
			LRF_CentroidValueArray[j] = LRF_FactorArray[j];
		}

		pLRFNeuronArray_Layer2[i].Init_Dendrite_Arrays(LRFSizeX_Layer1 * LRFSizeY_Layer1 + /*bias:*/ 1);
		pLRFNeuronArray_Layer2[i].Set_ActivationFunction(ConvolutionalKernel);
		pLRFNeuronArray_Layer2[i].Set_LocalReceptiveFieldSizeInfo(LRFSizeX_Layer1, LRFSizeY_Layer1);
		pLRFNeuronArray_Layer2[i].Set_Dendrite_Data(LRF_CentroidValueArray, LRF_FactorArray);
	}

	InputVectorSizeX = inputVectorSizeX;
	InputVectorSizeY = inputVectorSizeY;

	HalfInputVectorSizeX = InputVectorSizeX / 2;
	HalfInputVectorSizeY = InputVectorSizeY / 2;

	QuarterInputVectorSizeX = HalfInputVectorSizeX / 2;
	QuarterInputVectorSizeY = HalfInputVectorSizeY / 2;

	QuarterInputVectorSizeXY = QuarterInputVectorSizeX * QuarterInputVectorSizeY;

	for (int32_t i = 0; i < NumLRFNeurons_Layer1; i++)
	{
		pFeatureMapArray_Layer1[i].Init_Map(InputVectorSizeX, InputVectorSizeY);
		pHalfResFeatureMapArray_Layer1[i].Init_Map(HalfInputVectorSizeX, HalfInputVectorSizeY);
	}

	for (int32_t i = 0; i < NumLRFNeurons_Layer2; i++)
	{
		pFeatureMapArray_Layer2[i].Init_Map(HalfInputVectorSizeX, HalfInputVectorSizeY);
		pHalfResFeatureMapArray_Layer2[i].Init_Map(QuarterInputVectorSizeX, QuarterInputVectorSizeY);
	}

	ProcessingNeuralNet_NumOfInputValues = NumLRFNeurons_Layer2 * QuarterInputVectorSizeXY + /*bias:*/ 1;

	
	int32_t processingNeuralNet_NumOfAdditionalMemoryValues = ProcessingNeuralNet_NumOfInputValues * processingNeuralNet_NumOfHiddenDendrites;

	float *pRandomPlasticityArray = new (std::nothrow) float[processingNeuralNet_NumOfAdditionalMemoryValues];

	Init_RandomNumbersTableExt2(pRandomPlasticityArray, processingNeuralNet_NumOfAdditionalMemoryValues, pNeuralNetRandomNumbers, -1.0f, 1.0f, 0.5f);

	ProcessingNeuralNet.Init_PrecedingNeuron(ProcessingNeuralNet_NumOfInputValues, ProcessingNeuralNet_NumOfHiddenDendrites, ProcessingNeuralNet_DendriticFunction, pRandomPlasticityArray, processingNeuralNet_NumOfAdditionalMemoryValues);

	ProcessingNeuralNet.Init_OutputNeuronArray(ProcessingNeuralNet_NumOfOutputValues, ProcessingNeuralNet_NumOfHiddenDendrites, ProcessingNeuralNet_ActivationFunction, pNeuralNetRandomNumbers, -0.2f, 0.2f);

	delete[] pRandomPlasticityArray;
	pRandomPlasticityArray = nullptr;

}

void CSimpleDeepNeuralNet_Base::Initialize(CRandomNumbersNN *pLRFRandomNumbers, CRandomNumbersNN *pNeuralNetRandomNumbers, int32_t numLRFNeurons_Layer1, int32_t LRFSizeX_Layer1, int32_t LRFSizeY_Layer1, float LRF_MinRandomFactor, float LRF_MaxRandomFactor, int32_t inputVectorSizeX, int32_t inputVectorSizeY, int32_t processingNeuralNet_NumOfHiddenDendrites, int32_t processingNeuralNet_NumOfOutputValues)
{
	ProcessingNeuralNet_NumOfOutputValues = processingNeuralNet_NumOfOutputValues;
	ProcessingNeuralNet_NumOfHiddenDendrites = processingNeuralNet_NumOfHiddenDendrites;

	LRFSizeX_Layer1 = min(LRFSizeX_Layer1, 11);
	LRFSizeY_Layer1 = min(LRFSizeY_Layer1, 11);

	          //numLRFNeurons_Layer1 = 1;
	          //numLRFNeurons_Layer1 = 4;
	NumLRFNeurons_Layer1 = numLRFNeurons_Layer1;
	
	delete[] pLRFNeuronArray_Layer1;
	pLRFNeuronArray_Layer1 = nullptr;

	delete[] pFeatureMapArray_Layer1;
	pFeatureMapArray_Layer1 = nullptr;

	delete[] pHalfResFeatureMapArray_Layer1;
	pHalfResFeatureMapArray_Layer1 = nullptr;

	pLRFNeuronArray_Layer1 = new (std::nothrow) CSimpleNeuron[numLRFNeurons_Layer1];
	pFeatureMapArray_Layer1 = new (std::nothrow) CSimpleFeatureMap[numLRFNeurons_Layer1];
	pHalfResFeatureMapArray_Layer1 = new (std::nothrow) CSimpleFeatureMap[numLRFNeurons_Layer1];
	pQuarterResFeatureMapArray_Layer1 = new (std::nothrow) CSimpleFeatureMap[numLRFNeurons_Layer1];

	float LRF_CentroidValueArray[11 * 11 + 1];
	float LRF_FactorArray[11 * 11 + 1];

	float LRFSize = LRFSizeX_Layer1 * LRFSizeY_Layer1;

	for (int32_t i = 0; i < NumLRFNeurons_Layer1; i++)
	{
		/*if (i == 0)
		{
			LRF_FactorArray[0] = 0.0f; LRF_FactorArray[1] = 0.0f; LRF_FactorArray[2] = 0.0f;
			LRF_FactorArray[3] = 0.0f; LRF_FactorArray[4] = 1.0f; LRF_FactorArray[5] = 0.0f;
			LRF_FactorArray[6] = 0.0f; LRF_FactorArray[7] = 0.0f; LRF_FactorArray[8] = 0.0f;
			LRF_FactorArray[9] = 0.0f;

			for (int32_t j = 0; j <= LRFSize; j++)
				LRF_CentroidValueArray[j] = LRF_FactorArray[j];
		}

		if (i == 0)
		{
			LRF_FactorArray[0] = -0.5f; LRF_FactorArray[1] = -0.5f; LRF_FactorArray[2] = -0.5f;
			LRF_FactorArray[3] = 1.0f; LRF_FactorArray[4] = 1.0f; LRF_FactorArray[5] = 1.0f;
			LRF_FactorArray[6] = -0.5f; LRF_FactorArray[7] = -0.5f; LRF_FactorArray[8] = -0.5f;
			LRF_FactorArray[9] = 0.0f;

			for (int32_t j = 0; j <= LRFSize; j++)
				LRF_CentroidValueArray[j] = LRF_FactorArray[j];
		}
		else if (i == 1)
		{
			LRF_FactorArray[0] = -0.5f; LRF_FactorArray[1] = 1.0f; LRF_FactorArray[2] = -0.5f;
			LRF_FactorArray[3] = -0.5f; LRF_FactorArray[4] = 1.0f; LRF_FactorArray[5] = -0.5f;
			LRF_FactorArray[6] = -0.5f; LRF_FactorArray[7] = 1.0f; LRF_FactorArray[8] = -0.5f;
			LRF_FactorArray[9] = 0.0f;

			for (int32_t j = 0; j <= LRFSize; j++)
				LRF_CentroidValueArray[j] = LRF_FactorArray[j];
		}
		else if (i == 2)
		{
			LRF_FactorArray[0] = 1.0f; LRF_FactorArray[1] = -0.5f; LRF_FactorArray[2] = -0.5f;
			LRF_FactorArray[3] = -0.5f; LRF_FactorArray[4] = 1.0f; LRF_FactorArray[5] = -0.5f;
			LRF_FactorArray[6] = -0.5f; LRF_FactorArray[7] = -0.5f; LRF_FactorArray[8] = 1.0f;
			LRF_FactorArray[9] = 0.0f;

			for (int32_t j = 0; j <= LRFSize; j++)
				LRF_CentroidValueArray[j] = LRF_FactorArray[j];
		}
		else if (i == 3)
		{
			LRF_FactorArray[0] = -0.5f; LRF_FactorArray[1] = -0.5f; LRF_FactorArray[2] = 1.0f;
			LRF_FactorArray[3] = -0.5f; LRF_FactorArray[4] = 1.0f; LRF_FactorArray[5] = -0.5f;
			LRF_FactorArray[6] = 1.0f; LRF_FactorArray[7] = -0.5f; LRF_FactorArray[8] = -0.5f;
			LRF_FactorArray[9] = 0.0f;

			for (int32_t j = 0; j <= LRFSize; j++)
				LRF_CentroidValueArray[j] = LRF_FactorArray[j];
		}*/

		for (int32_t j = 0; j <= LRFSize; j++)
		{
			LRF_FactorArray[j] = pLRFRandomNumbers->Get_FloatNumber(LRF_MinRandomFactor, LRF_MaxRandomFactor);
			LRF_CentroidValueArray[j] = LRF_FactorArray[j];
		}

		pLRFNeuronArray_Layer1[i].Init_Dendrite_Arrays(LRFSizeX_Layer1 * LRFSizeY_Layer1 +  1); // bias: 1
		pLRFNeuronArray_Layer1[i].Set_ActivationFunction(ConvolutionalKernel);
		pLRFNeuronArray_Layer1[i].Set_LocalReceptiveFieldSizeInfo(LRFSizeX_Layer1, LRFSizeY_Layer1);
		pLRFNeuronArray_Layer1[i].Set_Dendrite_Data(LRF_CentroidValueArray, LRF_FactorArray);

	}

	InputVectorSizeX = inputVectorSizeX;
	InputVectorSizeY = inputVectorSizeY;

	HalfInputVectorSizeX = InputVectorSizeX / 2;
	HalfInputVectorSizeY = InputVectorSizeY / 2;
	HalfInputVectorSizeXY = HalfInputVectorSizeX * HalfInputVectorSizeY;

	QuarterInputVectorSizeX = HalfInputVectorSizeX / 2;
	QuarterInputVectorSizeY = HalfInputVectorSizeY / 2;
	QuarterInputVectorSizeXY = QuarterInputVectorSizeX * QuarterInputVectorSizeY;

	for (int32_t i = 0; i < NumLRFNeurons_Layer1; i++)
	{
		pFeatureMapArray_Layer1[i].Init_Map(InputVectorSizeX, InputVectorSizeY);
		pHalfResFeatureMapArray_Layer1[i].Init_Map(HalfInputVectorSizeX, HalfInputVectorSizeY);
		pQuarterResFeatureMapArray_Layer1[i].Init_Map(QuarterInputVectorSizeX, QuarterInputVectorSizeY);
	}

	
	//ProcessingNeuralNet_NumOfInputValues = NumLRFNeurons_Layer1 * HalfInputVectorSizeXY +  1;
	ProcessingNeuralNet_NumOfInputValues = NumLRFNeurons_Layer1 * QuarterInputVectorSizeXY + 1;

	int32_t processingNeuralNet_NumOfAdditionalMemoryValues = ProcessingNeuralNet_NumOfInputValues * ProcessingNeuralNet_NumOfHiddenDendrites;

	float *pRandomPlasticityArray = new (std::nothrow) float[processingNeuralNet_NumOfAdditionalMemoryValues];

	Init_RandomNumbersTableExt2(pRandomPlasticityArray, processingNeuralNet_NumOfAdditionalMemoryValues, pNeuralNetRandomNumbers, -1.0f, 1.0f, 0.5f);

	ProcessingNeuralNet.Init_PrecedingNeuron(ProcessingNeuralNet_NumOfInputValues, ProcessingNeuralNet_NumOfHiddenDendrites, ProcessingNeuralNet_DendriticFunction, pRandomPlasticityArray, processingNeuralNet_NumOfAdditionalMemoryValues);

	ProcessingNeuralNet.Init_OutputNeuronArray(ProcessingNeuralNet_NumOfOutputValues, ProcessingNeuralNet_NumOfHiddenDendrites, ProcessingNeuralNet_ActivationFunction, pNeuralNetRandomNumbers, -0.2f, 0.2f);

	delete[] pRandomPlasticityArray;
	pRandomPlasticityArray = nullptr;

	
	/*
	ProcessingNeuralNet_NumOfInputValues = 32 *  32 + 1;


	int32_t processingNeuralNet_NumOfAdditionalMemoryValues = ProcessingNeuralNet_NumOfInputValues * ProcessingNeuralNet_NumOfHiddenDendrites;

	float *pRandomPlasticityArray = new (std::nothrow) float[processingNeuralNet_NumOfAdditionalMemoryValues];

	Init_RandomNumbersTableExt2(pRandomPlasticityArray, processingNeuralNet_NumOfAdditionalMemoryValues, pNeuralNetRandomNumbers, -1.0f, 1.0f, 0.5f);

	ProcessingNeuralNet.Init_PrecedingNeuron(ProcessingNeuralNet_NumOfInputValues, ProcessingNeuralNet_NumOfHiddenDendrites, ProcessingNeuralNet_DendriticFunction, pRandomPlasticityArray, processingNeuralNet_NumOfAdditionalMemoryValues);

	ProcessingNeuralNet.Init_OutputNeuronArray(ProcessingNeuralNet_NumOfOutputValues, ProcessingNeuralNet_NumOfHiddenDendrites, ProcessingNeuralNet_ActivationFunction, pNeuralNetRandomNumbers, -0.2f, 0.2f);

	delete[] pRandomPlasticityArray;
	pRandomPlasticityArray = nullptr;
	*/
}

void CSimpleDeepNeuralNet_Test1::Calculate_Output(float *pInputMap, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1)
{
	/*for (int32_t i = 0; i < NumLRFNeurons_Layer1; i++)
	{
		pFeatureMapArray_Layer1[i].Reset_Values(0.0f);
	}*/

	for (int32_t i = 0; i < NumLRFNeurons_Layer2; i++)
	{
		pFeatureMapArray_Layer2[i].Reset_Values(0.0f);
	}
	


	int32_t halfLRFSizeX = pLRFNeuronArray_Layer1[0].LocalReceptiveFieldSizeX / 2;
	int32_t halfLRFSizeY = pLRFNeuronArray_Layer1[0].LocalReceptiveFieldSizeY / 2;

	minPosX = max(minPosX, halfLRFSizeX);
	minPosY = max(minPosY, halfLRFSizeY);

	maxPosXPlus1 = min(maxPosXPlus1, InputVectorSizeX - halfLRFSizeX);
	maxPosYPlus1 = min(maxPosYPlus1, InputVectorSizeY - halfLRFSizeY);


	Search_Patterns(pFeatureMapArray_Layer1, pInputMap, InputVectorSizeX, InputVectorSizeY, 1, 1, minPosX, maxPosXPlus1, minPosY, maxPosYPlus1, pLRFNeuronArray_Layer1, NumLRFNeurons_Layer1, false);

	

	for (int32_t i = 0; i < NumLRFNeurons_Layer1; i++)
	{
		//pFeatureMapArray_Layer1[i].Apply_ReLU_Activation();
		MaxPooling2x2(pHalfResFeatureMapArray_Layer1[i].pDataArray, pFeatureMapArray_Layer1[i].pDataArray, InputVectorSizeX, InputVectorSizeY);
	}

	for (int32_t i = 0; i < NumLRFNeurons_Layer1; i++)
	{
		pHalfResFeatureMapArray_Layer1[i].Apply_ReLU_Activation();
		//pHalfResFeatureMapArray_Layer1[i].Apply_TanH_Activation();
	}

	halfLRFSizeX = pLRFNeuronArray_Layer2[0].LocalReceptiveFieldSizeX / 2;
	halfLRFSizeY = pLRFNeuronArray_Layer2[0].LocalReceptiveFieldSizeY / 2;

	minPosX = max(minPosX, halfLRFSizeX);
	minPosY = max(minPosY, halfLRFSizeY);

	maxPosXPlus1 = min(maxPosXPlus1, HalfInputVectorSizeX - halfLRFSizeX);
	maxPosYPlus1 = min(maxPosYPlus1, HalfInputVectorSizeY - halfLRFSizeY);

	for (int32_t i = 0; i < NumLRFNeurons_Layer1; i++)
	{
		Search_Patterns(pFeatureMapArray_Layer2, pHalfResFeatureMapArray_Layer1[i].pDataArray, HalfInputVectorSizeX, HalfInputVectorSizeY, 1, 1, minPosX, maxPosXPlus1, minPosY, maxPosYPlus1, pLRFNeuronArray_Layer1, NumLRFNeurons_Layer2, true);
	}

	for (int32_t i = 0; i < NumLRFNeurons_Layer2; i++)
	{
		//pFeatureMapArray_Layer2[i].Apply_ReLU_Activation();
		MaxPooling2x2(pHalfResFeatureMapArray_Layer2[i].pDataArray, pFeatureMapArray_Layer2[i].pDataArray, HalfInputVectorSizeX, HalfInputVectorSizeY);
	}

	for (int32_t i = 0; i < NumLRFNeurons_Layer2; i++)
	{
		pHalfResFeatureMapArray_Layer2[i].Apply_ReLU_Activation();
		//pHalfResFeatureMapArray_Layer2[i].Apply_TanH_Activation();
	}

	for (int32_t i = 0; i < NumLRFNeurons_Layer2; i++)
	{
		ProcessingNeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(pHalfResFeatureMapArray_Layer2[i].pDataArray, QuarterInputVectorSizeXY, i * QuarterInputVectorSizeXY);
	}

	ProcessingNeuralNet.Calculate_Output();

		
}

void CSimpleDeepNeuralNet_Base::Calculate_Output(float *pInputMap, int32_t minPosX, int32_t maxPosXPlus1, int32_t minPosY, int32_t maxPosYPlus1)
{
	int32_t halfLRFSizeX = pLRFNeuronArray_Layer1[0].LocalReceptiveFieldSizeX / 2;
	int32_t halfLRFSizeY = pLRFNeuronArray_Layer1[0].LocalReceptiveFieldSizeY / 2;

	minPosX = max(minPosX, halfLRFSizeX);
	minPosY = max(minPosY, halfLRFSizeY);

	maxPosXPlus1 = min(maxPosXPlus1, InputVectorSizeX - halfLRFSizeX);
	maxPosYPlus1 = min(maxPosYPlus1, InputVectorSizeY - halfLRFSizeY);


	Search_Patterns(pFeatureMapArray_Layer1, pInputMap, InputVectorSizeX, InputVectorSizeY, 1, 1, minPosX, maxPosXPlus1, minPosY, maxPosYPlus1, pLRFNeuronArray_Layer1, NumLRFNeurons_Layer1, false);



	for (int32_t i = 0; i < NumLRFNeurons_Layer1; i++)
	{
		//pFeatureMapArray_Layer1[i].Apply_ReLU_Activation();
		MaxPooling2x2(pHalfResFeatureMapArray_Layer1[i].pDataArray, pFeatureMapArray_Layer1[i].pDataArray, InputVectorSizeX, InputVectorSizeY);
		MaxPooling2x2(pQuarterResFeatureMapArray_Layer1[i].pDataArray, pHalfResFeatureMapArray_Layer1[i].pDataArray, HalfInputVectorSizeX, HalfInputVectorSizeY);
	}

	for (int32_t i = 0; i < NumLRFNeurons_Layer1; i++)
	{
		//pHalfResFeatureMapArray_Layer1[i].Apply_ReLU_Activation();
		//pHalfResFeatureMapArray_Layer1[i].Apply_LeakyReLU_Activation(0.1f);

		//pQuarterResFeatureMapArray_Layer1[i].Apply_ReLU_Activation();
		pQuarterResFeatureMapArray_Layer1[i].Apply_LeakyReLU_Activation(0.1f);
	}


	for (int32_t i = 0; i < NumLRFNeurons_Layer1; i++)
	{
		//ProcessingNeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(pHalfResFeatureMapArray_Layer1[i].pDataArray, HalfInputVectorSizeXY, i * HalfInputVectorSizeXY);

		ProcessingNeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(pQuarterResFeatureMapArray_Layer1[i].pDataArray, QuarterInputVectorSizeXY, i * QuarterInputVectorSizeXY);
	}


	ProcessingNeuralNet.Calculate_Output();

	//ProcessingNeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(pInputMap);
	//ProcessingNeuralNet.Calculate_Output();
}



CCellularState::CCellularState()
{}

CCellularState::~CCellularState()
{
	delete[] pStaticValueArray;
	pStaticValueArray = nullptr;

	delete[] pChangeableValueArray;
	pChangeableValueArray = nullptr;

	delete[] pTrainableValueArray;
	pTrainableValueArray = nullptr;
}

void CCellularState::Set_StaticValues(float *pValueArray, int32_t minArrayID, int32_t maxArrayIDPlus1)
{
	if (pSharedStaticValueArray == nullptr)
	{
		for (int32_t i = minArrayID; i < maxArrayIDPlus1; i++)
		{
			pStaticValueArray[i] = pValueArray[i];
		}

		return;
	}

	for (int32_t i = minArrayID; i < maxArrayIDPlus1; i++)
	{
		pSharedStaticValueArray[i] = pValueArray[i];
	}
}

void CCellularState::Set_ChangeableValues(float *pValueArray, int32_t minArrayID, int32_t maxArrayIDPlus1)
{
	for (int32_t i = minArrayID; i < maxArrayIDPlus1; i++)
	{
		pChangeableValueArray[i] = pValueArray[i];
	}
}

void CCellularState::Set_TrainableValues(float *pValueArray, int32_t minArrayID, int32_t maxArrayIDPlus1)
{
	for (int32_t i = minArrayID; i < maxArrayIDPlus1; i++)
	{
		pTrainableValueArray[i] = pValueArray[i];
	}
}

void CCellularState::Set_StaticValues(float *pValueArray)
{
	if (pSharedStaticValueArray == nullptr)
	{
		for(int32_t i = 0; i < NumOfStaticValues; i++)
		{
			pStaticValueArray[i] = pValueArray[i];
		}
		
		return;
	}

	for (int32_t i = 0; i < NumOfStaticValues; i++)
	{
		pSharedStaticValueArray[i] = pValueArray[i];
	}
}

void CCellularState::Set_ChangeableValues(float *pValueArray)
{
	for (int32_t i = 0; i < NumOfChangeableValues; i++)
	{
		pChangeableValueArray[i] = pValueArray[i];
	}
}

void CCellularState::Set_TrainableValues(float *pValueArray)
{
	for (int32_t i = 0; i < NumOfTrainableValues; i++)
	{
		pTrainableValueArray[i] = pValueArray[i];
	}
}

void CCellularState::Set_StaticValue(float value, int32_t arrayID)
{
	if (pSharedStaticValueArray == nullptr)
	{
		pStaticValueArray[arrayID] = value;
		return;
	}

	pSharedStaticValueArray[arrayID] = value;
}

void CCellularState::Set_ChangeableValue(float value, int32_t arrayID)
{
	pChangeableValueArray[arrayID] = value;
}

void CCellularState::Set_TrainableValue(float value, int32_t arrayID)
{
	pTrainableValueArray[arrayID] = value;
}




void CCellularState::Initialize(int32_t numOfStaticValues, int32_t numOfChangeableValues, int32_t numOfTrainableValues)
{
	pSharedStaticValueArray = nullptr;

	delete[] pStaticValueArray;
	pStaticValueArray = nullptr;

	delete[] pChangeableValueArray;
	pChangeableValueArray = nullptr;

	delete[] pTrainableValueArray;
	pTrainableValueArray = nullptr;

	Type = -1;

	NumOfStaticValues = numOfStaticValues;

	pStaticValueArray = new (std::nothrow) float[numOfStaticValues];

	for (int32_t i = 0; i < numOfStaticValues; i++)
	{
		pStaticValueArray[i] = 0.0f;
	}

	NumOfChangeableValues = numOfChangeableValues;

	pChangeableValueArray = new (std::nothrow) float[numOfChangeableValues];

	for (int32_t i = 0; i < numOfChangeableValues; i++)
	{
		pChangeableValueArray[i] = 0.0f;
	}

	NumOfTrainableValues = numOfTrainableValues;

	pTrainableValueArray = new (std::nothrow) float[numOfTrainableValues];

	for (int32_t i = 0; i < numOfTrainableValues; i++)
	{
		pTrainableValueArray[i] = 0.0f;
	}
}

void CCellularState::Initialize(int32_t numOfStaticValues, float *pExternalStaticValueArray, int32_t numOfChangeableValues, int32_t numOfTrainableValues)
{
	pSharedStaticValueArray = pExternalStaticValueArray;

	delete[] pStaticValueArray;
	pStaticValueArray = nullptr;

	delete[] pChangeableValueArray;
	pChangeableValueArray = nullptr;

	delete[] pTrainableValueArray;
	pTrainableValueArray = nullptr;

	Type = -1;

	NumOfStaticValues = numOfStaticValues;

	/*pStaticValueArray = new (std::nothrow) float[numOfStaticValues];

	for (int32_t i = 0; i < numOfStaticValues; i++)
	{
		pStaticValueArray[i] = 0.0f;
	}*/

	NumOfChangeableValues = numOfChangeableValues;

	pChangeableValueArray = new (std::nothrow) float[numOfChangeableValues];

	for (int32_t i = 0; i < numOfChangeableValues; i++)
	{
		pChangeableValueArray[i] = 0.0f;
	}

	NumOfTrainableValues = numOfTrainableValues;

	pTrainableValueArray = new (std::nothrow) float[numOfTrainableValues];

	for (int32_t i = 0; i < numOfTrainableValues; i++)
	{
		pTrainableValueArray[i] = 0.0f;
	}
}

void CCellularState::Clone_StaticValues(CCellularState *pOriginalObject)
{
	if (pSharedStaticValueArray == nullptr)
	{
		float *pOriginalStaticValueArray = pOriginalObject->pStaticValueArray;

		for (int32_t i = 0; i < NumOfStaticValues; i++)
		{
			pStaticValueArray[i] = pOriginalStaticValueArray[i];
		}

		return;
	}

	//pUsedStaticValueArray = pOriginalObject->pUsedStaticValueArray;
}

void CCellularState::Clone_ChangeableValues(CCellularState *pOriginalObject)
{
	float *pOriginalChangeableValueArray = pOriginalObject->pChangeableValueArray;

	for (int32_t i = 0; i < NumOfChangeableValues; i++)
	{
		pChangeableValueArray[i] = pOriginalChangeableValueArray[i];
	}
}

void CCellularState::Clone_TrainableValues(CCellularState *pOriginalObject)
{
	float *pOriginalTrainableValueArray = pOriginalObject->pTrainableValueArray;

	for (int32_t i = 0; i < NumOfTrainableValues; i++)
	{
		pTrainableValueArray[i] = pOriginalTrainableValueArray[i];
	}
}


void CCellularState::Clone_StateValues(CCellularState *pOriginalObject)
{
	Type = pOriginalObject->Type;

	float *pOriginalStaticValueArray = pOriginalObject->pStaticValueArray;

	for (int32_t i = 0; i < NumOfStaticValues; i++)
	{
		pStaticValueArray[i] = pOriginalStaticValueArray[i];
	}

	float *pOriginalChangeableValueArray = pOriginalObject->pChangeableValueArray;

	for (int32_t i = 0; i < NumOfChangeableValues; i++)
	{
		pChangeableValueArray[i] = pOriginalChangeableValueArray[i];
	}

	float *pOriginalTrainableValueArray = pOriginalObject->pTrainableValueArray;

	for (int32_t i = 0; i < NumOfTrainableValues; i++)
	{
		pTrainableValueArray[i] = pOriginalTrainableValueArray[i];
	}
}

CCellularData::CCellularData()
{}

CCellularData::~CCellularData()
{
	delete[] pPrevStateArray;
	pPrevStateArray = nullptr;
}

void CCellularData::Initialize(int32_t numOfStaticValues, int32_t numOfChangeableValues, int32_t numOfTrainableValues, int32_t numOfPrevStates)
{
	delete[] pPrevStateArray;
	pPrevStateArray = nullptr;

	NumOfPrevStates = numOfPrevStates;
	NumOfPrevStatesMinus1 = numOfPrevStates - 1;

	ActualState.Initialize(numOfStaticValues, numOfChangeableValues, numOfTrainableValues);
	NewState.Initialize(numOfStaticValues, numOfChangeableValues, numOfTrainableValues);

	if (numOfPrevStates > 0)
	{
		pPrevStateArray = new (std::nothrow) CCellularState[numOfPrevStates];

		for (int32_t i = 0; i < numOfPrevStates; i++)
		{
			pPrevStateArray[i].Initialize(numOfStaticValues, numOfChangeableValues, numOfTrainableValues);
		}
	}
}

void CCellularData::Initialize(int32_t numOfStaticValues, float *pExternalStaticValueArray, int32_t numOfChangeableValues, int32_t numOfTrainableValues, int32_t numOfPrevStates)
{
	delete[] pPrevStateArray;
	pPrevStateArray = nullptr;

	NumOfPrevStates = numOfPrevStates;
	NumOfPrevStatesMinus1 = numOfPrevStates - 1;

	ActualState.Initialize(numOfStaticValues, pExternalStaticValueArray, numOfChangeableValues, numOfTrainableValues);
	NewState.Initialize(numOfStaticValues, pExternalStaticValueArray, numOfChangeableValues, numOfTrainableValues);

	if (numOfPrevStates > 0)
	{
		pPrevStateArray = new (std::nothrow) CCellularState[numOfPrevStates];

		for (int32_t i = 0; i < numOfPrevStates; i++)
		{
			pPrevStateArray[i].Initialize(numOfStaticValues, pExternalStaticValueArray, numOfChangeableValues, numOfTrainableValues);
		}
	}
}


void CCellularData::Prepare_Update(void)
{
	if (NumOfPrevStates > 1)
	{
		for (int32_t i = 0; i < NumOfPrevStatesMinus1; i++)
		{
			pPrevStateArray[i].Clone_StateValues(&pPrevStateArray[i + 1]);
		}
	}

	if (NumOfPrevStates > 0)
	{
		pPrevStateArray[NumOfPrevStatesMinus1].Clone_StateValues(&ActualState);
	}

	ActualState.Clone_StateValues(&NewState);
}

void CCellularData::Set_ActualStaticValues(float *pValueArray)
{
	int32_t numOfStaticValues = ActualState.NumOfStaticValues;

	if (ActualState.pSharedStaticValueArray == nullptr)
	{
		float *pStaticValueArray = ActualState.pStaticValueArray;

		for (int32_t i = 0; i < numOfStaticValues; i++)
		{
			pStaticValueArray[i] = pValueArray[i];
		}

		return;
	}

	float *pStaticValueArray = ActualState.pSharedStaticValueArray;

	for (int32_t i = 0; i < numOfStaticValues; i++)
	{
		pStaticValueArray[i] = pValueArray[i];
	}
}

void CCellularData::Set_ActualStaticValues(float *pValueArray, int32_t minArrayID, int32_t maxArrayIDPlus1)
{
	if (ActualState.pSharedStaticValueArray == nullptr)
	{
		float *pStaticValueArray = ActualState.pStaticValueArray;

		for (int32_t i = minArrayID; i < maxArrayIDPlus1; i++)
		{
			pStaticValueArray[i] = pValueArray[i];
		}

		return;
	}

	float *pStaticValueArray = ActualState.pStaticValueArray;

	for (int32_t i = minArrayID; i < maxArrayIDPlus1; i++)
	{
		pStaticValueArray[i] = pValueArray[i];
	}
}

void CCellularData::Set_ActualChangeableValues(float *pValueArray)
{
	int32_t numOfChangeableValues = ActualState.NumOfChangeableValues;

	float *pChangeableValueArray = ActualState.pChangeableValueArray;
	
	for (int32_t i = 0; i < numOfChangeableValues; i++)
	{
		pChangeableValueArray[i] = pValueArray[i];
	}
}

void CCellularData::Set_ActualChangeableValues(float *pValueArray, int32_t minArrayID, int32_t maxArrayIDPlus1)
{
	float *pChangeableValueArray = ActualState.pChangeableValueArray;

	for (int32_t i = minArrayID; i < maxArrayIDPlus1; i++)
	{
		pChangeableValueArray[i] = pValueArray[i];
	}
}

void CCellularData::Set_ActualTrainableValues(float *pValueArray)
{
	int32_t numOfTrainableValues = ActualState.NumOfTrainableValues;

	float *pTrainableValueArray = ActualState.pTrainableValueArray;

	for (int32_t i = 0; i < numOfTrainableValues; i++)
	{
		pTrainableValueArray[i] = pValueArray[i];
	}
}

void CCellularData::Set_ActualTrainableValues(float *pValueArray, int32_t minArrayID, int32_t maxArrayIDPlus1)
{
	float *pTrainableValueArray = ActualState.pTrainableValueArray;

	for (int32_t i = minArrayID; i < maxArrayIDPlus1; i++)
	{
		pTrainableValueArray[i] = pValueArray[i];
	}
}


void CCellularData::Set_ActualStaticValue(float value, int32_t arrayID)
{
	if (ActualState.pSharedStaticValueArray == nullptr)
	{
		ActualState.pStaticValueArray[arrayID] = value;
		return;
	}

	ActualState.pSharedStaticValueArray[arrayID] = value;
}

void CCellularData::Set_ActualChangeableValue(float value, int32_t arrayID)
{
	ActualState.pChangeableValueArray[arrayID] = value;
}

void CCellularData::Set_ActualTrainableValue(float value, int32_t arrayID)
{
	ActualState.pTrainableValueArray[arrayID] = value;
}


void CCellularData::Clone_StateValues(CCellularData *pOriginalObject)
{
	ActualState.Clone_StateValues(&pOriginalObject->ActualState);
	NewState.Clone_StateValues(&pOriginalObject->NewState);

	if (NumOfPrevStates > 0)
	{
		for (int32_t i = 0; i < NumOfPrevStates; i++)
		{
			pPrevStateArray[i].Clone_StateValues(&pOriginalObject->pPrevStateArray[i]);
		}
	}
}

void CCellularData::Clone_StaticValues(CCellularData *pOriginalObject)
{
	ActualState.Clone_StaticValues(&pOriginalObject->ActualState);
	NewState.Clone_StaticValues(&pOriginalObject->NewState);

	if (NumOfPrevStates > 0)
	{
		for (int32_t i = 0; i < NumOfPrevStates; i++)
		{
			pPrevStateArray[i].Clone_StaticValues(&pOriginalObject->pPrevStateArray[i]);
		}
	}
}

void CCellularData::Clone_ChangeableValues(CCellularData *pOriginalObject)
{
	ActualState.Clone_ChangeableValues(&pOriginalObject->ActualState);
	NewState.Clone_ChangeableValues(&pOriginalObject->NewState);

	if (NumOfPrevStates > 0)
	{
		for (int32_t i = 0; i < NumOfPrevStates; i++)
		{
			pPrevStateArray[i].Clone_ChangeableValues(&pOriginalObject->pPrevStateArray[i]);
		}
	}
}

void CCellularData::Clone_TrainableValues(CCellularData *pOriginalObject)
{
	ActualState.Clone_TrainableValues(&pOriginalObject->ActualState);
	NewState.Clone_TrainableValues(&pOriginalObject->NewState);

	if (NumOfPrevStates > 0)
	{
		for (int32_t i = 0; i < NumOfPrevStates; i++)
		{
			pPrevStateArray[i].Clone_TrainableValues(&pOriginalObject->pPrevStateArray[i]);
		}
	}
}


CCellularAutomaton::CCellularAutomaton()
{}

CCellularAutomaton::~CCellularAutomaton()
{}

void CCellularAutomaton::Connect_With_CellInstance(CCellularData *pInstance)
{
	pCellInstance = pInstance;
}

void CCellularAutomaton::Connect_With_Population(CCellularAutomaton *pCellularAutomatonArray)
{
	pUsedCellularAutomatonArray = pCellularAutomatonArray;
}

void CCellularAutomaton::Set_Position(int32_t posX)
{
	PosX = posX;
	PosY = 0;
	PosZ = 0;

	PosID = posX;
}

void CCellularAutomaton::Set_Position(int32_t posX, int32_t posY)
{
	PosX = posX;
	PosY = posY;
	PosZ = 0;

	PosID = posX + PopulationSizeX * posY;
}

void CCellularAutomaton::Set_Position(int32_t posX, int32_t posY, int32_t posZ)
{
	PosX = posX;
	PosY = posY;
	PosZ = posZ;

	PosID = posX + PopulationSizeX * posY + PopulationSizeXY * posZ;
}

void CCellularAutomaton::Set_1DimPositionFromID(int32_t posID)
{
	PosID = posID;

	PosX = posID;
	PosY = 0;
	PosZ = 0;
}

void CCellularAutomaton::Set_2DimPositionFromID(int32_t posID)
{
	PosID = posID;

	PosX = posID % PopulationSizeX;
	PosY = posID / PopulationSizeX;

	PosZ = 0;
}

void CCellularAutomaton::Set_3DimPositionFromID(int32_t posID)
{
	PosID = posID;

	int32_t iz = posID / PopulationSizeXY;
	posID -= iz * PopulationSizeXY;

	PosX = posID % PopulationSizeX;
	PosY = posID / PopulationSizeX;
	PosZ = iz;
}

void CCellularAutomaton::Set_PopulationSize(int32_t sizeX)
{
	PopulationSizeX = sizeX;
	PopulationSizeY = 0;
	PopulationSizeZ = 0;
	PopulationSizeXY = 0;
}

void CCellularAutomaton::Set_PopulationSize(int32_t sizeX, int32_t sizeY)
{
	PopulationSizeX = sizeX;
	PopulationSizeY = sizeY;
	PopulationSizeZ = 0;
	PopulationSizeXY = sizeX * sizeY;
}

void CCellularAutomaton::Set_PopulationSize(int32_t sizeX, int32_t sizeY, int32_t sizeZ)
{
	PopulationSizeX = sizeX;
	PopulationSizeY = sizeY;
	PopulationSizeZ = sizeZ;
	PopulationSizeXY = sizeX * sizeY;
}

void CCellularAutomaton::Set_ActualStaticValue_PositionBased(float *pPositionBasedValueArray, int32_t staticValueArrayID)
{
	//pCellInstance->Set_ActualStaticValue(pPositionBasedValueArray[PosID], staticValueArrayID);

	if (pCellInstance->ActualState.pSharedStaticValueArray == nullptr)
	{
		pCellInstance->ActualState.pStaticValueArray[staticValueArrayID] = pPositionBasedValueArray[PosID];
		return;
	}

	pCellInstance->ActualState.pSharedStaticValueArray[staticValueArrayID] = pPositionBasedValueArray[PosID];
}

void CCellularAutomaton::Set_ActualChangeableValue_PositionBased(float *pPositionBasedValueArray, int32_t changeableValueArrayID)
{
	pCellInstance->ActualState.pChangeableValueArray[changeableValueArrayID] = pPositionBasedValueArray[PosID];
}

void CCellularAutomaton::Set_ActualTrainableValue_PositionBased(float *pPositionBasedValueArray, int32_t trainableValueArrayID)
{
	pCellInstance->ActualState.pTrainableValueArray[trainableValueArrayID] = pPositionBasedValueArray[PosID];
}









