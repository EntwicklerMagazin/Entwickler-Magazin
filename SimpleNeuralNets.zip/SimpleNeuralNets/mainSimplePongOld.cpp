#include <iostream>
//#include <chrono>
#include <thread>
#include "ConsoleHelperFunctions.h"
#include "RandomNumbers.h"
#include "NeuralNet.h"
#include "Pong.h"


using namespace std;
using namespace chrono;



#define KEYDOWN(vk_code) ((GetAsyncKeyState(vk_code) & 0x8000) ? 1 : 0)
#define KEYUP(vk_code)   ((GetAsyncKeyState(vk_code) & 0x8000) ? 0 : 1)



static char g_InputBuffer[100];



static int32_t g_PosX_ScoringTextString = 1;
static int32_t g_PosY_ScoringTextString = ConstGameBoardSizeY + 4;

static int32_t g_PosX_StartGameTextString = 1;
static int32_t g_PosY_StartGameTextString = ConstGameBoardSizeY + 2;



static void Output_GameBoard(CWindowsConsoleScreenBuffer *pWinConsole, COLOR_PALETTE colorValueBall, COLOR_PALETTE colorValuePaddle, COLOR_PALETTE colorValueBorder)
{
	uint32_t ix, iy;

	for (iy = 0; iy < ConstGameBoardSizeY; iy++)
	{
		for (ix = 0; ix < ConstGameBoardSizeX; ix++)
		{
			if(g_GameBoard[iy][ix] == ConstGameBoard_Ball)
				pWinConsole->Write_Pixel_Into_BackBuffer(ix, iy, colorValueBall);
			else if (g_GameBoard[iy][ix] == ConstGameBoard_PaddleElement)
				pWinConsole->Write_Pixel_Into_BackBuffer(ix, iy, colorValuePaddle);
			else if (g_GameBoard[iy][ix] == ConstGameBoard_BorderElement)
				pWinConsole->Write_Pixel_Into_BackBuffer(ix, iy, colorValueBorder);
			//else
				//pWinConsole->Write_Pixel_Into_BackBuffer(ix, iy, BackgroundColor);
		}
	}
}

static void Init_Or_Reset_GameBoardArray(uint8_t emptyValue = ConstGameBoard_EmptyElement)
{
	for (uint32_t iy = 0; iy < ConstGameBoardSizeY; iy++)
	{
		for (uint32_t ix = 0; ix < ConstGameBoardSizeX; ix++)
		{
			g_GameBoard[iy][ix] = emptyValue;
		}
	}
}

static void Init_Or_Reset_fGameBoardArray(float emptyValue = fConstGameBoard_EmptyElement)
{
	for (uint32_t iy = 0; iy < ConstGameBoardSizeY; iy++)
	{
		for (uint32_t ix = 0; ix < ConstGameBoardSizeX; ix++)
		{
			g_fGameBoard[iy][ix] = emptyValue;
		}
	}
}

static void Init_GameBoardBorders(uint8_t borderValue = ConstGameBoard_BorderElement)
{
	for (uint32_t iy = 0; iy < ConstGameBoardSizeY; iy++)
	{
		if (iy == 0 || iy == ConstGameBoardSizeYMinus1)
		{
			for (uint32_t ix = 0; ix < ConstGameBoardSizeX; ix++)
			{
				g_GameBoard[iy][ix] = borderValue;
			}
		}
		else
		{
			for (uint32_t ix = 0; ix < ConstGameBoardSizeX; ix++)
			{
				if (ix == 0 || ix == ConstGameBoardSizeXMinus1)
				{
					g_GameBoard[iy][ix] = borderValue;
				}
			}
		}
	}
}

static void Init_fGameBoardBorders(float borderValue = fConstGameBoard_BorderElement)
{
	for (uint32_t iy = 0; iy < ConstGameBoardSizeY; iy++)
	{
		if (iy == 0 || iy == ConstGameBoardSizeYMinus1)
		{
			for (uint32_t ix = 0; ix < ConstGameBoardSizeX; ix++)
			{
				g_fGameBoard[iy][ix] = borderValue;
			}
		}
		else
		{
			for (uint32_t ix = 0; ix < ConstGameBoardSizeX; ix++)
			{
				if (ix == 0 || ix == ConstGameBoardSizeXMinus1)
				{
					g_fGameBoard[iy][ix] = borderValue;
				}
			}
		}
	}
}


static void Set_ProcessPriority(unsigned long priority)
{
	HANDLE ProcessHandle = GetCurrentProcess();

	if (priority == 0)
		SetPriorityClass(ProcessHandle, NORMAL_PRIORITY_CLASS);
	else if (priority == 1)
		SetPriorityClass(ProcessHandle, ABOVE_NORMAL_PRIORITY_CLASS);
	else if (priority == 2)
		SetPriorityClass(ProcessHandle, HIGH_PRIORITY_CLASS);
	else
		SetPriorityClass(ProcessHandle, REALTIME_PRIORITY_CLASS);
}


/*
int main()
{
	Set_ProcessPriority(2);

	CWindowsConsoleScreenBuffer WinConsole;

	Set_Title("Simple Pong Type Game");

	WinConsole.Initialize(ConstGameBoardSizeX + 5, ConstGameBoardSizeY + 10, false, BackgroundColor);

	WinConsole.Set_CursorVisibilityAndSize(FALSE);
	WinConsole.Set_Font(L"Consolas", 15, 15);
	//WinConsole.Set_BackgroundColor(RGB(100, 50, 25));
	WinConsole.Set_BackgroundColor(BackgroundColor);

	uint64_t seed = 1;
	CRandomNumbersNN RandomNumbers;

	char strBuffer[100];



	float MaxPlayBallSpeed = 0.0f;

	cout << "MaxPlayBallSpeed (good value: 0.5): ";
	cin.getline(g_InputBuffer, 100);
	MaxPlayBallSpeed = atof(g_InputBuffer);

	//MaxPlayBallSpeed = min(1.0f, MaxPlayBallSpeed);


	float PlayBallVelocityX = 1.0f;
	float PlayBallVelocityY = -1.0f;

	PlayBallVelocityX = RandomNumbers.Get_FloatNumber(-1.0f, 1.0f);

	float velXX = PlayBallVelocityX * PlayBallVelocityX;
	float velYY = 1.0f;

	float lengthSq = velXX + velYY;
	float invLength = MaxPlayBallSpeed / (0.0001f + sqrt(lengthSq));

	PlayBallVelocityX *= invLength;
	PlayBallVelocityY *= invLength;



	Set_CursorVisibilityAndSize(false);

	Init_Or_Reset_GameBoardArray();
	Init_GameBoardBorders();

	bool Started = false;

	CPaddle HumanPlayerPaddle(4);
	CPaddle AIPlayerPaddle(4);
	CBall PlayBall(MaxPlayBallSpeed);


	int32_t PlayerScore = 0;
	int32_t AIScore = 0;

	Init_New_Game(&HumanPlayerPaddle, &AIPlayerPaddle, &PlayBall, PlayBallVelocityX, PlayBallVelocityY, &Started, &PlayerScore, &AIScore);


	int32_t counter = 0;

	do
	{
		//auto last_timepoint = std::chrono::steady_clock::now();
		//auto last_timepoint = steady_clock::now();
		auto last_timepoint = system_clock::now();

		WinConsole.Clear_BackBuffer();

		if (Started == true)
		{
			
			HumanPlayerPaddle.HumanPlayer_SimpleMovement(2.0f);
			//HumanPlayerPaddle.HumanPlayer_Movement(0.5f, 0.9f);

			AIPlayerPaddle.Simple_MovementAI(&PlayBall, 1.0f, 0.9f);
			

			PlayBall.Movement();

			HumanPlayerPaddle.Handle_Possible_PlayBallCollision(&PlayBall, false);
			AIPlayerPaddle.Handle_Possible_PlayBallCollision(&PlayBall, true);


			if (PlayBall.Check_Possible_LowerWallCollision() == true)
			{
				PlayBallVelocityX = RandomNumbers.Get_FloatNumber(-1.0f, 1.0f);
				PlayBallVelocityY = -1.0f;			
				//PlayBallVelocityY = 1.0f;
				AIScore++;
				

				float velXX = PlayBallVelocityX * PlayBallVelocityX;
				float velYY = 1.0f;

				float lengthSq = velXX + velYY;
				float invLength = MaxPlayBallSpeed / (0.0001f + sqrt(lengthSq));

				PlayBallVelocityX *= invLength;
				PlayBallVelocityY *= invLength;

				Init_New_Game(&HumanPlayerPaddle, &AIPlayerPaddle, &PlayBall, PlayBallVelocityX, PlayBallVelocityY, &Started, &PlayerScore, &AIScore);
			}
			else if (PlayBall.Check_Possible_UpperWallCollision() == true)
			{
				PlayBallVelocityX = RandomNumbers.Get_FloatNumber(-1.0f, 1.0f);
				PlayBallVelocityY = -1.0f;
				//PlayBallVelocityY = 1.0f;
				PlayerScore++;
				

				float velXX = PlayBallVelocityX * PlayBallVelocityX;
				float velYY = 1.0f;

				float lengthSq = velXX + velYY;
				float invLength = MaxPlayBallSpeed / (0.0001f + sqrt(lengthSq));

				PlayBallVelocityX *= invLength;
				PlayBallVelocityY *= invLength;

				Init_New_Game(&HumanPlayerPaddle, &AIPlayerPaddle, &PlayBall, PlayBallVelocityX, PlayBallVelocityY, &Started, &PlayerScore, &AIScore);
			}

			PlayBall.Handle_Possible_WallCollisions();


			
			PlayBall.Draw();
			AIPlayerPaddle.Draw();
			HumanPlayerPaddle.Draw();
			

			counter++;

		EndOfSceneCalculation:;

		} // end of if (Started == true)



		Output_GameBoard(&WinConsole, lightgreen, lightaqua, lightred);


		sprintf(strBuffer, "Human Score: %03d - AI Score: %03d           ", PlayerScore, AIScore);


		WinConsole.Write_String_Into_BackBuffer(g_PosX_ScoringTextString, g_PosY_ScoringTextString, strBuffer, lightgreen, BackgroundColor);

		if (Started == false)
		{
			
			sprintf(strBuffer, "SPACE or ESC: start or end game");
			WinConsole.Write_String_Into_BackBuffer(g_PosX_StartGameTextString, g_PosY_StartGameTextString, strBuffer, lightgreen, BackgroundColor);
			

			if (GetAsyncKeyState(VK_SPACE))
			{
				Started = true;
				counter = 0;
			}
		}

		WinConsole.Present_BackBuffer();

	
		//Frame-Bremse:

		//auto current_timepoint = steady_clock::now();
		auto current_timepoint = system_clock::now();

		while (current_timepoint - last_timepoint < 16ms) // 16 ms: maximal 60 Frames pro Sekunde	
		{
			//current_timepoint = steady_clock::now();
			current_timepoint = system_clock::now();
		}
		


		if (KEYDOWN(VK_ESCAPE) == true)
			break;


	} while (true);

	WinConsole.Clear_BackBuffer();
	WinConsole.CeanUp();


	Set_CursorVisibilityAndSize(true);
	Reset_CursorPos();
	//Set_CursorPos(0, 0);

	//cout << "bye bye (Press Return)" << endl;

	//getchar();
	return 0;
}
*/





/*
int main()
{
	Set_ProcessPriority(2);

	HelperStuff::Begin_Log(0, "Begin Log ...", "LogFile.txt");

	CWindowsConsoleScreenBuffer WinConsole;

	Set_Title("Simple Pong Type Game");

	WinConsole.Initialize(ConstGameBoardSizeX + 5, ConstGameBoardSizeY + 10, false, BackgroundColor);

	WinConsole.Set_CursorVisibilityAndSize(FALSE);
	WinConsole.Set_Font(L"Consolas", 15, 15);
	//WinConsole.Set_BackgroundColor(RGB(100, 50, 25));
	WinConsole.Set_BackgroundColor(BackgroundColor);

	uint64_t seed = 1;
	CRandomNumbersNN RandomNumbers;

	char strBuffer[100];



	int32_t NumTrainingStepsMax = 0;
	int32_t NumTrainingSteps = 0;

	cout << "NumTrainingStepsMax: ";
	cin.getline(g_InputBuffer, 100);
	NumTrainingStepsMax = atoi(g_InputBuffer);

	int32_t TrainingGameLengthMax = 0;

	cout << "TrainingGameLengthMax: ";
	cin.getline(g_InputBuffer, 100);
	TrainingGameLengthMax = atoi(g_InputBuffer);


	int32_t NumOfTrainingRepetitions = 0;

	cout << "NumOfTrainingRepetitions: ";
	cin.getline(g_InputBuffer, 100);
	NumOfTrainingRepetitions = atoi(g_InputBuffer);

	float MaxPlayBallSpeed = 0.0f;

	cout << "MaxPlayBallSpeed (try 0.75): ";
	cin.getline(g_InputBuffer, 100);
	MaxPlayBallSpeed = atof(g_InputBuffer);

	MaxPlayBallSpeed = max(MaxPlayBallSpeed, 0.1f);

	int32_t NumOfHiddenNeuronsL1 = 0;

	cout << "NumOfHiddenNeuronsL1 (try 3-10): ";
	cin.getline(g_InputBuffer, 100);
	NumOfHiddenNeuronsL1 = atoi(g_InputBuffer);

	NumOfHiddenNeuronsL1 = max(NumOfHiddenNeuronsL1, 1);

	int32_t NumOfHiddenNeuronsL2 = 0;

	cout << "NumOfHiddenNeuronsL2 (try 0): ";
	cin.getline(g_InputBuffer, 100);
	NumOfHiddenNeuronsL2 = atoi(g_InputBuffer);

	int32_t tempInt;

	cout << "ExtremeLearning (0/1): ";
	cin.getline(g_InputBuffer, 100);
	tempInt = atoi(g_InputBuffer);

	bool ExtremeLearning = false;

	if (tempInt == 1)
		ExtremeLearning = true;

	int32_t AdditionalMutations = 0;

	cout << "AdditionalMutations (0/1): ";
	cin.getline(g_InputBuffer, 100);
	AdditionalMutations = atoi(g_InputBuffer);

	float PlayBallVelocityX = 1.0f;
	float PlayBallVelocityY = -1.0f;

	PlayBallVelocityX = RandomNumbers.Get_FloatNumber(-1.0f, 1.0f);

	float velXX = PlayBallVelocityX * PlayBallVelocityX;
	float velYY = 1.0f;

	float lengthSq = velXX + velYY;
	float invLength = MaxPlayBallSpeed / (0.0001f + sqrt(lengthSq));

	PlayBallVelocityX *= invLength;
	PlayBallVelocityY *= invLength;



	Set_CursorVisibilityAndSize(false);

	Init_Or_Reset_GameBoardArray();
	Init_GameBoardBorders();


	Init_Or_Reset_fGameBoardArray();
	Init_fGameBoardBorders();

	bool Started = false;

	CPaddle HumanPlayerPaddle(4);
	CPaddle AIPlayerPaddle(4);
	CBall PlayBall(MaxPlayBallSpeed);


	CSimpleAIPlayer_Pong1 SimulatedHumanPlayer;
	CSimpleAIPlayer_Pong1 AIPlayer;  // training parameter: 1000 10 0 0.75 // 1000 1000 0 0.75  (try NumOfHiddenNeuronsL1: 3, try NumOfHiddenNeuronsL2: 0)

	//CSimpleAIPlayer_Pong2 SimulatedHumanPlayer;
	//CSimpleAIPlayer_Pong2 AIPlayer;  // training parameter: 10000 10 10 0.75  (try NumOfHiddenNeuronsL1: 3, try NumOfHiddenNeuronsL2: 0)

									 
	SimulatedHumanPlayer.Initialize(&HumanPlayerPaddle, &PlayBall, NumOfHiddenNeuronsL1, NumOfHiddenNeuronsL2, false);
	AIPlayer.Initialize(&AIPlayerPaddle, &PlayBall, NumOfHiddenNeuronsL1, NumOfHiddenNeuronsL2);

	int32_t PlayerScore = 0;
	int32_t AIScore = 0;

	Init_New_Game(&HumanPlayerPaddle, &AIPlayerPaddle, &PlayBall, PlayBallVelocityX, PlayBallVelocityY, &Started, &PlayerScore, &AIScore);


	int32_t counter = 0;

	do
	{
		//auto last_timepoint = std::chrono::steady_clock::now();
		//auto last_timepoint = steady_clock::now();
		auto last_timepoint = system_clock::now();

		WinConsole.Clear_BackBuffer();

		if (Started == true)
		{
			AIPlayer.Identify_GamesWorldPositionValues();
			SimulatedHumanPlayer.Identify_GamesWorldPositionValues();
			Init_Or_Reset_fGameBoardArray();

			if (NumTrainingSteps < NumTrainingStepsMax)
				SimulatedHumanPlayer.Calculate_PaddleMovement(0.5f, 0.0f, 0.99f);
			else
				HumanPlayerPaddle.HumanPlayer_SimpleMovement(2.0f);
				//HumanPlayerPaddle.HumanPlayer_Movement(0.5f, 0.9f);

		
			if (NumTrainingSteps < NumTrainingStepsMax)
			{
				if (NumTrainingSteps > 5)
				{
					AIPlayer.Train_NeuralNet(0.99f, ExtremeLearning);

					for (uint32_t i = 0; i < NumOfTrainingRepetitions; i++)
						AIPlayer.Train_NeuralNet(0.99f, ExtremeLearning);
				}

				NumTrainingSteps++;

				//AIPlayer.Calculate_PaddleMovement(0.5f, 0.0f, 0.99f);
				AIPlayer.Calculate_NeuralNetPaddleMovement(0.5f, 0.0f, 0.99f);

				if (counter % 100 == 0)
				{
					if(AdditionalMutations == 1)
						//AIPlayer.Brain.RandomChange_OutputSynapsePlasticities2_HiddenLayer1(seed++, -0.005f, 0.005f, 0.5f);
						AIPlayer.Brain.RandomChange_OutputSynapsePlasticities2(seed++, -0.005f, 0.005f, 0.5f);
				}
			}
			else
				AIPlayer.Calculate_NeuralNetPaddleMovement(0.5f, 0.0f, 0.99f);
				//AIPlayer.Calculate_PaddleMovement(0.5f, 0.0f, 0.99f);


			PlayBall.Movement();

			HumanPlayerPaddle.Handle_Possible_PlayBallCollision(&PlayBall, false);
			AIPlayerPaddle.Handle_Possible_PlayBallCollision(&PlayBall, true);


			if (NumTrainingSteps == NumTrainingStepsMax)
			{
				PlayBallVelocityX = RandomNumbers.Get_FloatNumber(-1.0f, 1.0f);
				//PlayBallVelocityY = 1.0f;
				PlayBallVelocityY = -1.0f;

				float velXX = PlayBallVelocityX * PlayBallVelocityX;
				float velYY = 1.0f;

				float lengthSq = velXX + velYY;
				float invLength = MaxPlayBallSpeed / (0.0001f + sqrt(lengthSq));

				PlayBallVelocityX *= invLength;
				PlayBallVelocityY *= invLength;

				Init_New_Game(&HumanPlayerPaddle, &AIPlayerPaddle, &PlayBall, PlayBallVelocityX, PlayBallVelocityY, &Started, &PlayerScore, &AIScore);

				AIPlayer.Reset_Memories();

				Init_Or_Reset_fGameBoardArray();

				NumTrainingSteps++;
				goto EndOfSceneCalculation;
			}

			if (counter == TrainingGameLengthMax && NumTrainingSteps < NumTrainingStepsMax)
			{
				PlayBallVelocityX = RandomNumbers.Get_FloatNumber(-1.0f, 1.0f);
				PlayBallVelocityY = -1.0f;

				float velXX = PlayBallVelocityX * PlayBallVelocityX;
				float velYY = 1.0f;

				float lengthSq = velXX + velYY;
				float invLength = MaxPlayBallSpeed / (0.0001f + sqrt(lengthSq));

				PlayBallVelocityX *= invLength;
				PlayBallVelocityY *= invLength;

				Init_New_Game(&HumanPlayerPaddle, &AIPlayerPaddle, &PlayBall, PlayBallVelocityX, PlayBallVelocityY, &Started, &PlayerScore, &AIScore);

				AIPlayer.Reset_Memories();

				Init_Or_Reset_fGameBoardArray();

				goto EndOfSceneCalculation;
			}



			if (PlayBall.Check_Possible_LowerWallCollision() == true)
			{
				PlayBallVelocityX = RandomNumbers.Get_FloatNumber(-1.0f, 1.0f);
				PlayBallVelocityY = -1.0f;

				if (NumTrainingSteps >= NumTrainingStepsMax)
				{
					//PlayBallVelocityY = 1.0f;
					AIScore++;
				}

				float velXX = PlayBallVelocityX * PlayBallVelocityX;
				float velYY = 1.0f;

				float lengthSq = velXX + velYY;
				float invLength = MaxPlayBallSpeed / (0.0001f + sqrt(lengthSq));

				PlayBallVelocityX *= invLength;
				PlayBallVelocityY *= invLength;

				Init_New_Game(&HumanPlayerPaddle, &AIPlayerPaddle, &PlayBall, PlayBallVelocityX, PlayBallVelocityY, &Started, &PlayerScore, &AIScore);

				AIPlayer.Reset_Memories();

				Init_Or_Reset_fGameBoardArray();

			}
			else if (PlayBall.Check_Possible_UpperWallCollision() == true)
			{
				PlayBallVelocityX = RandomNumbers.Get_FloatNumber(-1.0f, 1.0f);
				PlayBallVelocityY = -1.0f;

				if (NumTrainingSteps >= NumTrainingStepsMax)
				{
					//PlayBallVelocityY = 1.0f;
					PlayerScore++;
				}

				float velXX = PlayBallVelocityX * PlayBallVelocityX;
				float velYY = 1.0f;

				float lengthSq = velXX + velYY;
				float invLength = MaxPlayBallSpeed / (0.0001f + sqrt(lengthSq));

				PlayBallVelocityX *= invLength;
				PlayBallVelocityY *= invLength;

				Init_New_Game(&HumanPlayerPaddle, &AIPlayerPaddle, &PlayBall, PlayBallVelocityX, PlayBallVelocityY, &Started, &PlayerScore, &AIScore);

				AIPlayer.Reset_Memories();

				Init_Or_Reset_fGameBoardArray();
			}

			PlayBall.Handle_Possible_WallCollisions();


			if (NumTrainingSteps >= NumTrainingStepsMax)
			{
				PlayBall.Draw();
				AIPlayerPaddle.Draw();
				HumanPlayerPaddle.Draw();
			}

			PlayBall.fDraw();
			AIPlayerPaddle.fDraw();

			counter++;

		EndOfSceneCalculation:;

		} // end of if (Started == true)



		if (NumTrainingSteps >= NumTrainingStepsMax)
			Output_GameBoard(&WinConsole, lightgreen, lightaqua, lightred);



		if (NumTrainingSteps < NumTrainingStepsMax)
			sprintf(strBuffer, "training ...                                 ");
		else
			sprintf(strBuffer, "Human Score: %03d - AI Score: %03d           ", PlayerScore, AIScore);
			

		WinConsole.Write_String_Into_BackBuffer(g_PosX_ScoringTextString, g_PosY_ScoringTextString, strBuffer, lightgreen, BackgroundColor);

		if (Started == false)
		{
			if (NumTrainingSteps >= NumTrainingStepsMax)
			{
				sprintf(strBuffer, "SPACE or ESC: start or end game");

				WinConsole.Write_String_Into_BackBuffer(g_PosX_StartGameTextString, g_PosY_StartGameTextString, strBuffer, lightgreen, BackgroundColor);
			}

			if (GetAsyncKeyState(VK_SPACE) || NumTrainingSteps < NumTrainingStepsMax)
			{

				Started = true;

				counter = 0;
			}
		}

		WinConsole.Present_BackBuffer();

		if (NumTrainingSteps >= NumTrainingStepsMax)
		{
			//Frame-Bremse:

			//auto current_timepoint = steady_clock::now();
			auto current_timepoint = system_clock::now();

			while (current_timepoint - last_timepoint < 16ms) // 16 ms: maximal 60 Frames pro Sekunde	
			{
				//current_timepoint = steady_clock::now();
				current_timepoint = system_clock::now();
			}
		}


		if (KEYDOWN(VK_ESCAPE) == true)
			break;


	} while (true);

	WinConsole.Clear_BackBuffer();
	WinConsole.CeanUp();


	Set_CursorVisibilityAndSize(true);
	Reset_CursorPos();
	//Set_CursorPos(0, 0);

	//cout << "bye bye (Press Return)" << endl;

	//getchar();
	return 0;
}
*/



///*
int main()
{
	Set_ProcessPriority(2);

	HelperStuff::Begin_Log(0, "Begin Log ...", "LogFile.txt");

	CWindowsConsoleScreenBuffer WinConsole;

	Set_Title("Simple Pong Type Game");

	WinConsole.Initialize(ConstGameBoardSizeX + 10, ConstGameBoardSizeY + 10, false, BackgroundColor);

	WinConsole.Set_CursorVisibilityAndSize(FALSE);
	WinConsole.Set_Font(L"Consolas", 15, 15);
	//WinConsole.Set_BackgroundColor(RGB(100, 50, 25));
	WinConsole.Set_BackgroundColor(BackgroundColor);

	uint64_t seed = 1;
	CRandomNumbersNN RandomNumbers;

	char strBuffer[100];



	int32_t NumTrainingGenerationsMax = 0;
	
	cout << "TrainingGenerationsMax (try 100): ";
	cin.getline(g_InputBuffer, 100);
	NumTrainingGenerationsMax = atoi(g_InputBuffer);

	int32_t NumSimpleMutationGenerations = 0;

	cout << "SimpleMutationGenerations (try<100): ";
	cin.getline(g_InputBuffer, 100);
	NumSimpleMutationGenerations = atoi(g_InputBuffer);

	int32_t NumTrainingGamesPerEpoch = 0;

	cout << "NumTrainingGamesPerEpoch (>10): ";
	cin.getline(g_InputBuffer, 100);
	NumTrainingGamesPerEpoch = atoi(g_InputBuffer);

	int32_t TrainingGameLengthMax = 0;

	cout << "TrainingGameLengthMax (try 10): ";
	cin.getline(g_InputBuffer, 100);
	TrainingGameLengthMax = atoi(g_InputBuffer);


	int32_t TrainingPopulationSize = 0;

	cout << "TrainingPopulationSize (try 100): ";
	cin.getline(g_InputBuffer, 100);
	TrainingPopulationSize = atoi(g_InputBuffer);

	float MaxPlayBallSpeed = 0.0f;

	cout << "MaxPlayBallSpeed (try 0.75): ";
	cin.getline(g_InputBuffer, 100);
	MaxPlayBallSpeed = atof(g_InputBuffer);

	MaxPlayBallSpeed = max(MaxPlayBallSpeed, 0.1f);

	int32_t NumOfHiddenNeuronsL1 = 0;

	cout << "NumOfHiddenNeuronsL1 (try 4-10): ";
	cin.getline(g_InputBuffer, 100);
	NumOfHiddenNeuronsL1 = atoi(g_InputBuffer);

	NumOfHiddenNeuronsL1 = max(NumOfHiddenNeuronsL1, 1);

	int32_t NumOfHiddenNeuronsL2 = 0;

	cout << "NumOfHiddenNeuronsL2 (try 0-4): ";
	cin.getline(g_InputBuffer, 100);
	NumOfHiddenNeuronsL2 = atoi(g_InputBuffer);

	float LearningPenaltyValue;

	cout << "LearningPenaltyValue (try 0.0): ";
	cin.getline(g_InputBuffer, 100);
	LearningPenaltyValue = atof(g_InputBuffer);


	float MinSynapticPlasticity;

	cout << "MinPlasticity (try -0.001): ";
	cin.getline(g_InputBuffer, 100);
	MinSynapticPlasticity = atof(g_InputBuffer);

	float MaxSynapticPlasticity;

	cout << "MaxPlasticity (try 0.001): ";
	cin.getline(g_InputBuffer, 100);
	MaxSynapticPlasticity = atof(g_InputBuffer);

	float MinSynapticPlasticityVariance;

	cout << "MinPlasticityVariance (try -0.0001): ";
	cin.getline(g_InputBuffer, 100);
	MinSynapticPlasticityVariance = atof(g_InputBuffer);

	float MaxSynapticPlasticityVariance;

	cout << "MaxPlasticityVariance (try 0.0001): ";
	cin.getline(g_InputBuffer, 100);
	MaxSynapticPlasticityVariance = atof(g_InputBuffer);

	int32_t tempInt;

	cout << "ExtremeLearning (0/1): ";
	cin.getline(g_InputBuffer, 100);
	tempInt = atoi(g_InputBuffer);

	bool ExtremeLearning = false;

	if (tempInt == 1)
	    ExtremeLearning = true;

	float PlasticityMutationRate;

	cout << "PlasticityMutationRate (< 0.1): ";
	cin.getline(g_InputBuffer, 100);
	PlasticityMutationRate = atof(g_InputBuffer);

	float PlasticityMutationRateL1;

	cout << "PlasticityMutationRateL1 (< 0.1): ";
	cin.getline(g_InputBuffer, 100);
	PlasticityMutationRateL1 = atof(g_InputBuffer);

	float PlasticityMutationRateL2;

	cout << "PlasticityMutationRateL2 (< 0.1): ";
	cin.getline(g_InputBuffer, 100);
	PlasticityMutationRateL2 = atof(g_InputBuffer);

	float PlasticityMutationRateL3;

	cout << "PlasticityMutationRateL3 (< 0.1): ";
	cin.getline(g_InputBuffer, 100);
	PlasticityMutationRateL3 = atof(g_InputBuffer);

	float TopologyMutationRateL1;

	cout << "TopologyMutationRateL1 (< 0.1): ";
	cin.getline(g_InputBuffer, 100);
	TopologyMutationRateL1 = atof(g_InputBuffer);


	float TopologyMutationRateL2;

	cout << "TopologyMutationRateL2 (< 0.1): ";
	cin.getline(g_InputBuffer, 100);
	TopologyMutationRateL2 = atof(g_InputBuffer);

	float TopologyMutationRateL3;

	cout << "TopologyMutationRateL3 (< 0.1): ";
	cin.getline(g_InputBuffer, 100);
	TopologyMutationRateL3 = atof(g_InputBuffer);

	
	float PlayBallVelocityX = 1.0f;
	float PlayBallVelocityY = -1.0f;

	PlayBallVelocityX = RandomNumbers.Get_FloatNumber(-1.0f, 1.0f);

	float velXX = PlayBallVelocityX * PlayBallVelocityX;
	float velYY = 1.0f;

	float lengthSq = velXX + velYY;
	float invLength = MaxPlayBallSpeed / (0.0001f + sqrt(lengthSq));

	PlayBallVelocityX *= invLength;
	PlayBallVelocityY *= invLength;



	Set_CursorVisibilityAndSize(false);

	Init_Or_Reset_GameBoardArray();
	Init_GameBoardBorders();


	Init_Or_Reset_fGameBoardArray();
	Init_fGameBoardBorders();

	bool Started = false;

	CPaddle HumanPlayerPaddle(4);
	CPaddle AIPlayerPaddle(4);
	CBall PlayBall(MaxPlayBallSpeed);

	CSimpleAIPlayerPopulation_Pong1 AIPlayerPopulation;
	CSimpleAIPlayer_Pong1 SimulatedHumanPlayer;
	CSimpleAIPlayer_Pong1 AIPlayer;

	//CSimpleAIPlayerPopulation_Pong2 AIPlayerPopulation;
	//CSimpleAIPlayer_Pong2 SimulatedHumanPlayer;
	//CSimpleAIPlayer_Pong2 AIPlayer;

	AIPlayerPopulation.Initialize(TrainingPopulationSize, NumOfHiddenNeuronsL1, NumOfHiddenNeuronsL2, MaxPlayBallSpeed);

	AIPlayerPopulation.RandomChange_OutputSynapsePlasticities(MinSynapticPlasticity, MaxSynapticPlasticity);

	if (TopologyMutationRateL1 != 0.0f || TopologyMutationRateL2 != 0.0f || TopologyMutationRateL3 != 0.0f)
	{
		AIPlayerPopulation.RandomChange_BrainTopologies(TopologyMutationRateL1, TopologyMutationRateL2, TopologyMutationRateL3);
	}

	cout << endl << "Evolution started ... " << endl;


	for (uint32_t i = 0; i < NumSimpleMutationGenerations; i++)
	{
		AIPlayerPopulation.Init_and_Play_New_TrainingSequence(TrainingGameLengthMax, NumTrainingGamesPerEpoch);
		AIPlayerPopulation.Update_Population(LearningPenaltyValue);
	
	
		if (PlasticityMutationRate != 0.0f)
		{
			AIPlayerPopulation.Update_Evolution_SynapticPlasticityMutationsOnly(MinSynapticPlasticity, MaxSynapticPlasticity, PlasticityMutationRate, ExtremeLearning);
		}
		else if(PlasticityMutationRate == 0.0f)
		{
			AIPlayerPopulation.Update_Evolution_SynapticPlasticityMutationsOnly(MinSynapticPlasticity, MaxSynapticPlasticity, PlasticityMutationRateL1, PlasticityMutationRateL2, PlasticityMutationRateL3, ExtremeLearning);
		}
		
		if (TopologyMutationRateL1 != 0.0f || TopologyMutationRateL2 != 0.0f || TopologyMutationRateL3 != 0.0f)
		{
			AIPlayerPopulation.Update_Evolution_TopologyMutationsOnly(MinSynapticPlasticity, MaxSynapticPlasticity, TopologyMutationRateL1, TopologyMutationRateL2, TopologyMutationRateL3, true);
		}

		if (PlasticityMutationRate != 0.0f)
		{
			AIPlayerPopulation.Update_Evolution_BestBrainOnly(MinSynapticPlasticityVariance, MaxSynapticPlasticityVariance, PlasticityMutationRate);
			AIPlayerPopulation.Update_Evolution_SecondBestBrainOnly(MinSynapticPlasticityVariance, MaxSynapticPlasticityVariance, PlasticityMutationRate);
		}
		else if (PlasticityMutationRate == 0.0f)
		{
			AIPlayerPopulation.Update_Evolution_BestBrainOnly(MinSynapticPlasticityVariance, MaxSynapticPlasticityVariance, PlasticityMutationRateL1, PlasticityMutationRateL2, PlasticityMutationRateL3);
			AIPlayerPopulation.Update_Evolution_SecondBestBrainOnly(MinSynapticPlasticityVariance, MaxSynapticPlasticityVariance, PlasticityMutationRateL1, PlasticityMutationRateL2, PlasticityMutationRateL3);
		}

		if (TopologyMutationRateL1 != 0.0f || TopologyMutationRateL2 != 0.0f || TopologyMutationRateL3 != 0.0f)
		{
			AIPlayerPopulation.Restore_Topology_WorstFitted_Brain(MinSynapticPlasticity, MaxSynapticPlasticity);
			AIPlayerPopulation.Restore_Topology_SecondWorstFitted_Brain(MinSynapticPlasticity, MaxSynapticPlasticity);
			AIPlayerPopulation.Restore_Topology_ThirdWorstFitted_Brain(MinSynapticPlasticity, MaxSynapticPlasticity);
		}

		//AIPlayerPopulation.Round_OutputWeights(0.00001f);
	}

	for(uint32_t i = NumSimpleMutationGenerations; i < NumTrainingGenerationsMax; i++)
	{
		AIPlayerPopulation.Init_and_Play_New_TrainingSequence(TrainingGameLengthMax, NumTrainingGamesPerEpoch);
		AIPlayerPopulation.Update_Population(LearningPenaltyValue);

		if (PlasticityMutationRate != 0.0f)
		{
			AIPlayerPopulation.Update_Evolution_SynapticPlasticityMutationsOnly(MinSynapticPlasticity, MaxSynapticPlasticity, PlasticityMutationRate, ExtremeLearning);
		}
		else if (PlasticityMutationRate == 0.0f)
		{
			AIPlayerPopulation.Update_Evolution_SynapticPlasticityMutationsOnly(MinSynapticPlasticity, MaxSynapticPlasticity, PlasticityMutationRateL1, PlasticityMutationRateL2, PlasticityMutationRateL3, ExtremeLearning);
		}


	
		if (TopologyMutationRateL1 != 0.0f || TopologyMutationRateL2 != 0.0f || TopologyMutationRateL3 != 0.0f)
		{
			AIPlayerPopulation.Update_Evolution_TopologyMutationsOnly(MinSynapticPlasticity, MaxSynapticPlasticity, TopologyMutationRateL1, TopologyMutationRateL2, TopologyMutationRateL3, true);
		}

		if (PlasticityMutationRate != 0.0f)
		{
			AIPlayerPopulation.Update_Evolution_BestBrainOnly(MinSynapticPlasticityVariance, MaxSynapticPlasticityVariance, PlasticityMutationRate);
			AIPlayerPopulation.Update_Evolution_SecondBestBrainOnly(MinSynapticPlasticityVariance, MaxSynapticPlasticityVariance, PlasticityMutationRate);
		}
		else if (PlasticityMutationRate == 0.0f)
		{
			AIPlayerPopulation.Update_Evolution_BestBrainOnly(MinSynapticPlasticityVariance, MaxSynapticPlasticityVariance, PlasticityMutationRateL1, PlasticityMutationRateL2, PlasticityMutationRateL3);
			AIPlayerPopulation.Update_Evolution_SecondBestBrainOnly(MinSynapticPlasticityVariance, MaxSynapticPlasticityVariance, PlasticityMutationRateL1, PlasticityMutationRateL2, PlasticityMutationRateL3);
		}


		AIPlayerPopulation.Update_Evolution_Combine_BestTwoBrains();
		AIPlayerPopulation.Update_Evolution_Combine_TwoBrains();

		if (TopologyMutationRateL1 != 0.0f || TopologyMutationRateL2 != 0.0f || TopologyMutationRateL3 != 0.0f)
		{
			AIPlayerPopulation.Restore_Topology_WorstFitted_Brain(MinSynapticPlasticity, MaxSynapticPlasticity);
			AIPlayerPopulation.Restore_Topology_SecondWorstFitted_Brain(MinSynapticPlasticity, MaxSynapticPlasticity);
			AIPlayerPopulation.Restore_Topology_ThirdWorstFitted_Brain(MinSynapticPlasticity, MaxSynapticPlasticity);
		}

		//AIPlayerPopulation.Round_OutputWeights(0.00001f);
	}

	cout << "Evolution completed (press Return) ";
	getchar();


	

							
	SimulatedHumanPlayer.Initialize(&HumanPlayerPaddle, &PlayBall, 0, 0, false);
	AIPlayer.Initialize(&AIPlayerPaddle, &PlayBall, NumOfHiddenNeuronsL1, NumOfHiddenNeuronsL2);

	//AIPlayer.Brain.Clone_OutputSynapsePlasticities(AIPlayerPopulation.Get_Best_Evolved_NeuralNet());
	AIPlayerPopulation.Get_Best_Evolved_NeuralNet_Ext(&AIPlayer.Brain);

	int32_t PlayerScore = 0;
	int32_t AIScore = 0;

	Init_New_Game(&HumanPlayerPaddle, &AIPlayerPaddle, &PlayBall, PlayBallVelocityX, PlayBallVelocityY, &Started, &PlayerScore, &AIScore);


	do
	{
		//auto last_timepoint = std::chrono::steady_clock::now();
		//auto last_timepoint = steady_clock::now();
		auto last_timepoint = system_clock::now();

		WinConsole.Clear_BackBuffer();

		if (Started == true)
		{
			AIPlayer.Identify_GamesWorldPositionValues();
			SimulatedHumanPlayer.Identify_GamesWorldPositionValues();
			Init_Or_Reset_fGameBoardArray();

			
			HumanPlayerPaddle.HumanPlayer_SimpleMovement(2.0f);
			//HumanPlayerPaddle.HumanPlayer_Movement(0.5f, 0.9f);


			AIPlayer.Calculate_NeuralNetPaddleMovement(0.5f, 0.0f, 0.99f);
			//AIPlayer.Calculate_PaddleMovement(0.5f, 0.0f, 0.99f);


			PlayBall.Movement();

			HumanPlayerPaddle.Handle_Possible_PlayBallCollision(&PlayBall, false);
			AIPlayerPaddle.Handle_Possible_PlayBallCollision(&PlayBall, true);


			

			if (PlayBall.Check_Possible_LowerWallCollision() == true)
			{
				PlayBallVelocityX = RandomNumbers.Get_FloatNumber(-1.0f, 1.0f);
				PlayBallVelocityY = -1.0f;

				
				//PlayBallVelocityY = 1.0f;
				AIScore++;
				

				float velXX = PlayBallVelocityX * PlayBallVelocityX;
				float velYY = 1.0f;

				float lengthSq = velXX + velYY;
				float invLength = MaxPlayBallSpeed / (0.0001f + sqrt(lengthSq));

				PlayBallVelocityX *= invLength;
				PlayBallVelocityY *= invLength;

				Init_New_Game(&HumanPlayerPaddle, &AIPlayerPaddle, &PlayBall, PlayBallVelocityX, PlayBallVelocityY, &Started, &PlayerScore, &AIScore);

				AIPlayer.Reset_Memories();

				Init_Or_Reset_fGameBoardArray();

			}
			else if (PlayBall.Check_Possible_UpperWallCollision() == true)
			{
				PlayBallVelocityX = RandomNumbers.Get_FloatNumber(-1.0f, 1.0f);
				PlayBallVelocityY = -1.0f;

				
				//PlayBallVelocityY = 1.0f;
				PlayerScore++;
				

				float velXX = PlayBallVelocityX * PlayBallVelocityX;
				float velYY = 1.0f;

				float lengthSq = velXX + velYY;
				float invLength = MaxPlayBallSpeed / (0.0001f + sqrt(lengthSq));

				PlayBallVelocityX *= invLength;
				PlayBallVelocityY *= invLength;

				Init_New_Game(&HumanPlayerPaddle, &AIPlayerPaddle, &PlayBall, PlayBallVelocityX, PlayBallVelocityY, &Started, &PlayerScore, &AIScore);

				AIPlayer.Reset_Memories();

				Init_Or_Reset_fGameBoardArray();
			}

			PlayBall.Handle_Possible_WallCollisions();
		
			PlayBall.Draw();
			AIPlayerPaddle.Draw();
			HumanPlayerPaddle.Draw();
			
			PlayBall.fDraw();
			AIPlayerPaddle.fDraw();

		} // end of if (Started == true)



		
		Output_GameBoard(&WinConsole, lightgreen, lightaqua, lightred);



		
		sprintf(strBuffer, "Human Score: %03d - AI Score: %03d           ", PlayerScore, AIScore);


		WinConsole.Write_String_Into_BackBuffer(g_PosX_ScoringTextString, g_PosY_ScoringTextString, strBuffer, lightgreen, BackgroundColor);

		if (Started == false)
		{
			
			sprintf(strBuffer, "SPACE or ESC: start or end game");

			WinConsole.Write_String_Into_BackBuffer(g_PosX_StartGameTextString, g_PosY_StartGameTextString, strBuffer, lightgreen, BackgroundColor);
			

			if (GetAsyncKeyState(VK_SPACE))
				Started = true;
		}

		WinConsole.Present_BackBuffer();

		
		//Frame-Bremse:

		//auto current_timepoint = steady_clock::now();
		auto current_timepoint = system_clock::now();

		while (current_timepoint - last_timepoint < 16ms) // 16 ms: maximal 60 Frames pro Sekunde	
		{
			//current_timepoint = steady_clock::now();
			current_timepoint = system_clock::now();
		}
		


		if (KEYDOWN(VK_ESCAPE) == true)
			break;


	} while (true);

	WinConsole.Clear_BackBuffer();
	WinConsole.CeanUp();


	Set_CursorVisibilityAndSize(true);
	Reset_CursorPos();
	//Set_CursorPos(0, 0);

	//cout << "bye bye (Press Return)" << endl;

	//getchar();
	return 0;
}
//*/



/*
int main()
{
	Set_ProcessPriority(2);

	HelperStuff::Begin_Log(0, "Begin Log ...", "LogFile.txt");

	CWindowsConsoleScreenBuffer WinConsole;

	Set_Title("Simple Pong Type Game");

	WinConsole.Initialize(ConstGameBoardSizeX + 10, ConstGameBoardSizeY + 10, false, BackgroundColor);

	WinConsole.Set_CursorVisibilityAndSize(FALSE);
	WinConsole.Set_Font(L"Consolas", 15, 15);
	//WinConsole.Set_BackgroundColor(RGB(100, 50, 25));
	WinConsole.Set_BackgroundColor(BackgroundColor);

	uint64_t seed = 1;
	CRandomNumbersNN RandomNumbers;

	char strBuffer[100];



	int32_t NumTrainingGenerationsMax = 0;

	cout << "TrainingGenerationsMax (try 20): ";
	cin.getline(g_InputBuffer, 100);
	NumTrainingGenerationsMax = atoi(g_InputBuffer);

	int32_t NumSimpleMutationGenerations = 0;

	cout << "SimpleMutationGenerations (try<20): ";
	cin.getline(g_InputBuffer, 100);
	NumSimpleMutationGenerations = atoi(g_InputBuffer);

	int32_t NumTrainingGamesPerEpoch = 0;

	cout << "NumTrainingGamesPerEpoch (>10): ";
	cin.getline(g_InputBuffer, 100);
	NumTrainingGamesPerEpoch = atoi(g_InputBuffer);

	int32_t TrainingGameLengthMax = 0;

	cout << "TrainingGameLengthMax (try 10): ";
	cin.getline(g_InputBuffer, 100);
	TrainingGameLengthMax = atoi(g_InputBuffer);


	int32_t TrainingPopulationSize = 0;

	cout << "TrainingPopulationSize (try 100): ";
	cin.getline(g_InputBuffer, 100);
	TrainingPopulationSize = atoi(g_InputBuffer);

	float MaxPlayBallSpeed = 0.0f;

	cout << "MaxPlayBallSpeed (try 0.75): ";
	cin.getline(g_InputBuffer, 100);
	MaxPlayBallSpeed = atof(g_InputBuffer);

	MaxPlayBallSpeed = max(MaxPlayBallSpeed, 0.1f);

	int32_t NumOfHiddenNeuronsL1_Min = 0;

	cout << "NumOfHiddenNeuronsL1_Min (try 4): ";
	cin.getline(g_InputBuffer, 100);
	NumOfHiddenNeuronsL1_Min = atoi(g_InputBuffer);

	NumOfHiddenNeuronsL1_Min = max(NumOfHiddenNeuronsL1_Min, 1);

	int32_t NumOfHiddenNeuronsL1_Max = 0;

	cout << "NumOfHiddenNeuronsL1_Max (try 10): ";
	cin.getline(g_InputBuffer, 100);
	NumOfHiddenNeuronsL1_Max = atoi(g_InputBuffer);

	NumOfHiddenNeuronsL1_Max = max(NumOfHiddenNeuronsL1_Max, NumOfHiddenNeuronsL1_Min);

	int32_t NumOfHiddenNeuronsL2_Min = 0;

	cout << "NumOfHiddenNeuronsL2_Min (try 0): ";
	cin.getline(g_InputBuffer, 100);
	NumOfHiddenNeuronsL2_Min = atoi(g_InputBuffer);

	int32_t NumOfHiddenNeuronsL2_Max = 0;

	cout << "NumOfHiddenNeuronsL2_Max (try 6): ";
	cin.getline(g_InputBuffer, 100);
	NumOfHiddenNeuronsL2_Max = atoi(g_InputBuffer);

	NumOfHiddenNeuronsL2_Max = max(NumOfHiddenNeuronsL2_Max, NumOfHiddenNeuronsL2_Min);

	float LearningPenaltyValue;

	cout << "LearningPenaltyValue (try 0.0): ";
	cin.getline(g_InputBuffer, 100);
	LearningPenaltyValue = atof(g_InputBuffer);


	float MinSynapticPlasticity;

	cout << "MinPlasticity (try -0.001): ";
	cin.getline(g_InputBuffer, 100);
	MinSynapticPlasticity = atof(g_InputBuffer);

	float MaxSynapticPlasticity;

	cout << "MaxPlasticity (try 0.001): ";
	cin.getline(g_InputBuffer, 100);
	MaxSynapticPlasticity = atof(g_InputBuffer);

	float MinSynapticPlasticityVariance;

	cout << "MinPlasticityVariance (try -0.0001): ";
	cin.getline(g_InputBuffer, 100);
	MinSynapticPlasticityVariance = atof(g_InputBuffer);

	float MaxSynapticPlasticityVariance;

	cout << "MaxPlasticityVariance (try 0.0001): ";
	cin.getline(g_InputBuffer, 100);
	MaxSynapticPlasticityVariance = atof(g_InputBuffer);

	int32_t tempInt;

	cout << "ExtremeLearning (0/1): ";
	cin.getline(g_InputBuffer, 100);
	tempInt = atoi(g_InputBuffer);

	bool ExtremeLearning = false;

	if (tempInt == 1)
		ExtremeLearning = true;



	float PlasticityMutationRate;

	cout << "PlasticityMutationRate (try 0.1): ";
	cin.getline(g_InputBuffer, 100);
	PlasticityMutationRate = atof(g_InputBuffer);

	float PlasticityMutationRateL1;

	cout << "PlasticityMutationRateL1 (< 0.1): ";
	cin.getline(g_InputBuffer, 100);
	PlasticityMutationRateL1 = atof(g_InputBuffer);

	float PlasticityMutationRateL2;

	cout << "PlasticityMutationRateL2 (< 0.1): ";
	cin.getline(g_InputBuffer, 100);
	PlasticityMutationRateL2 = atof(g_InputBuffer);

	float PlasticityMutationRateL3;

	cout << "PlasticityMutationRateL3 (< 0.1): ";
	cin.getline(g_InputBuffer, 100);
	PlasticityMutationRateL3 = atof(g_InputBuffer);

	float TopologyMutationRateL1;

	cout << "TopologyMutationRateL1 (< 0.1): ";
	cin.getline(g_InputBuffer, 100);
	TopologyMutationRateL1 = atof(g_InputBuffer);


	float TopologyMutationRateL2;

	cout << "TopologyMutationRateL2 (< 0.1): ";
	cin.getline(g_InputBuffer, 100);
	TopologyMutationRateL2 = atof(g_InputBuffer);

	float TopologyMutationRateL3;

	cout << "TopologyMutationRateL3 (< 0.1): ";
	cin.getline(g_InputBuffer, 100);
	TopologyMutationRateL3 = atof(g_InputBuffer);

	float NewSpeciesEvolutionProbability;

	cout << "SpeciesEvolutionProbability (try 0.1): ";
	cin.getline(g_InputBuffer, 100);
	NewSpeciesEvolutionProbability = atof(g_InputBuffer);


	float PlayBallVelocityX = 1.0f;
	float PlayBallVelocityY = -1.0f;

	PlayBallVelocityX = RandomNumbers.Get_FloatNumber(-1.0f, 1.0f);

	float velXX = PlayBallVelocityX * PlayBallVelocityX;
	float velYY = 1.0f;

	float lengthSq = velXX + velYY;
	float invLength = MaxPlayBallSpeed / (0.0001f + sqrt(lengthSq));

	PlayBallVelocityX *= invLength;
	PlayBallVelocityY *= invLength;



	Set_CursorVisibilityAndSize(false);

	Init_Or_Reset_GameBoardArray();
	Init_GameBoardBorders();


	Init_Or_Reset_fGameBoardArray();
	Init_fGameBoardBorders();

	bool Started = false;

	CPaddle HumanPlayerPaddle(4);
	CPaddle AIPlayerPaddle(4);
	CBall PlayBall(MaxPlayBallSpeed);

	CSimpleAIPlayerPopulation_Pong1 AIPlayerPopulation;
	CSimpleAIPlayer_Pong1 SimulatedHumanPlayer;
	CSimpleAIPlayer_Pong1 AIPlayer;

	//CSimpleAIPlayerPopulation_Pong2 AIPlayerPopulation;
	//CSimpleAIPlayer_Pong2 SimulatedHumanPlayer;
	//CSimpleAIPlayer_Pong2 AIPlayer;

	AIPlayerPopulation.Initialize_Ext(TrainingPopulationSize, NumOfHiddenNeuronsL1_Min, NumOfHiddenNeuronsL1_Max, NumOfHiddenNeuronsL2_Min, NumOfHiddenNeuronsL2_Max, MaxPlayBallSpeed);

	AIPlayerPopulation.RandomChange_OutputSynapsePlasticities(MinSynapticPlasticity, MaxSynapticPlasticity);

	if (TopologyMutationRateL1 != 0.0f || TopologyMutationRateL2 != 0.0f || TopologyMutationRateL3 != 0.0f)
	{
		AIPlayerPopulation.RandomChange_BrainTopologies(TopologyMutationRateL1, TopologyMutationRateL2, TopologyMutationRateL3);
	}

	cout << endl << "Evolution started ... " << endl;


	

	for (uint32_t i = 0; i < NumSimpleMutationGenerations; i++)
	{
		AIPlayerPopulation.Init_and_Play_New_TrainingSequence(TrainingGameLengthMax, NumTrainingGamesPerEpoch);
		AIPlayerPopulation.Update_Population_Ext(LearningPenaltyValue);
		

		if (PlasticityMutationRate != 0.0f)
		{
			AIPlayerPopulation.Update_Evolution_SynapticPlasticityMutationsOnly(MinSynapticPlasticity, MaxSynapticPlasticity, PlasticityMutationRate, ExtremeLearning);
		}
		else if (PlasticityMutationRate == 0.0f)
		{
			AIPlayerPopulation.Update_Evolution_SynapticPlasticityMutationsOnly(MinSynapticPlasticity, MaxSynapticPlasticity, PlasticityMutationRateL1, PlasticityMutationRateL2, PlasticityMutationRateL3, ExtremeLearning);
		}

		if (TopologyMutationRateL1 != 0.0f || TopologyMutationRateL2 != 0.0f || TopologyMutationRateL3 != 0.0f)
		{
			AIPlayerPopulation.Update_Evolution_TopologyMutationsOnly(MinSynapticPlasticity, MaxSynapticPlasticity, TopologyMutationRateL1, TopologyMutationRateL2, TopologyMutationRateL3, true);
		}

		if (PlasticityMutationRate != 0.0f)
		{
			AIPlayerPopulation.Update_Evolution_BestBrainOnly_Ext(MinSynapticPlasticityVariance, MaxSynapticPlasticityVariance, PlasticityMutationRate);
			AIPlayerPopulation.Update_Evolution_SecondBestBrainOnly_Ext(MinSynapticPlasticityVariance, MaxSynapticPlasticityVariance, PlasticityMutationRate);
		}
		else if (PlasticityMutationRate == 0.0f)
		{
			AIPlayerPopulation.Update_Evolution_BestBrainOnly_Ext(MinSynapticPlasticityVariance, MaxSynapticPlasticityVariance, PlasticityMutationRateL1, PlasticityMutationRateL2, PlasticityMutationRateL3);

			AIPlayerPopulation.Update_Evolution_SecondBestBrainOnly_Ext(MinSynapticPlasticityVariance, MaxSynapticPlasticityVariance, PlasticityMutationRateL1, PlasticityMutationRateL2, PlasticityMutationRateL3);
		}

		
		AIPlayerPopulation.Replace_WorstFitted_Brain(NewSpeciesEvolutionProbability);
		AIPlayerPopulation.Replace_SecondWorstFitted_Brain(0.5f*NewSpeciesEvolutionProbability);
		AIPlayerPopulation.Replace_ThirdWorstFitted_Brain(0.25f*NewSpeciesEvolutionProbability);

		if (TopologyMutationRateL1 != 0.0f || TopologyMutationRateL2 != 0.0f || TopologyMutationRateL3 != 0.0f)
		{
			AIPlayerPopulation.Restore_Topology_WorstFitted_Brain(MinSynapticPlasticity, MaxSynapticPlasticity);
			AIPlayerPopulation.Restore_Topology_SecondWorstFitted_Brain(MinSynapticPlasticity, MaxSynapticPlasticity);
			AIPlayerPopulation.Restore_Topology_ThirdWorstFitted_Brain(MinSynapticPlasticity, MaxSynapticPlasticity);
		}
	}

	for (uint32_t i = NumSimpleMutationGenerations; i < NumTrainingGenerationsMax; i++)
	{
		AIPlayerPopulation.Init_and_Play_New_TrainingSequence(TrainingGameLengthMax, NumTrainingGamesPerEpoch);
		AIPlayerPopulation.Update_Population_Ext(LearningPenaltyValue);
		
		if (PlasticityMutationRate != 0.0f)
		{
			AIPlayerPopulation.Update_Evolution_SynapticPlasticityMutationsOnly(MinSynapticPlasticity, MaxSynapticPlasticity, PlasticityMutationRate, ExtremeLearning);
		}
		else if (PlasticityMutationRate == 0.0f)
		{
			AIPlayerPopulation.Update_Evolution_SynapticPlasticityMutationsOnly(MinSynapticPlasticity, MaxSynapticPlasticity, PlasticityMutationRateL1, PlasticityMutationRateL2, PlasticityMutationRateL3, ExtremeLearning);
		}

		if (TopologyMutationRateL1 != 0.0f || TopologyMutationRateL2 != 0.0f || TopologyMutationRateL3 != 0.0f)
		{
			AIPlayerPopulation.Update_Evolution_TopologyMutationsOnly(MinSynapticPlasticity, MaxSynapticPlasticity, TopologyMutationRateL1, TopologyMutationRateL2, TopologyMutationRateL3, true);
		}

		if (PlasticityMutationRate != 0.0f)
		{
			AIPlayerPopulation.Update_Evolution_BestBrainOnly_Ext(MinSynapticPlasticityVariance, MaxSynapticPlasticityVariance, PlasticityMutationRate);
			AIPlayerPopulation.Update_Evolution_SecondBestBrainOnly_Ext(MinSynapticPlasticityVariance, MaxSynapticPlasticityVariance, PlasticityMutationRate);
		}
		else if (PlasticityMutationRate == 0.0f)
		{
			AIPlayerPopulation.Update_Evolution_BestBrainOnly_Ext(MinSynapticPlasticityVariance, MaxSynapticPlasticityVariance, PlasticityMutationRateL1, PlasticityMutationRateL2, PlasticityMutationRateL3);

			AIPlayerPopulation.Update_Evolution_SecondBestBrainOnly_Ext(MinSynapticPlasticityVariance, MaxSynapticPlasticityVariance, PlasticityMutationRateL1, PlasticityMutationRateL2, PlasticityMutationRateL3);
		}

		AIPlayerPopulation.Update_Evolution_Combine_BestTwoBrains_Ext();
		AIPlayerPopulation.Update_Evolution_Combine_TwoBrains_Ext();

		AIPlayerPopulation.Replace_WorstFitted_Brain(NewSpeciesEvolutionProbability);
		AIPlayerPopulation.Replace_SecondWorstFitted_Brain(0.5f*NewSpeciesEvolutionProbability);
		AIPlayerPopulation.Replace_ThirdWorstFitted_Brain(0.25f*NewSpeciesEvolutionProbability);

		if (TopologyMutationRateL1 != 0.0f || TopologyMutationRateL2 != 0.0f || TopologyMutationRateL3 != 0.0f)
		{
			AIPlayerPopulation.Restore_Topology_WorstFitted_Brain(MinSynapticPlasticity, MaxSynapticPlasticity);
			AIPlayerPopulation.Restore_Topology_SecondWorstFitted_Brain(MinSynapticPlasticity, MaxSynapticPlasticity);
			AIPlayerPopulation.Restore_Topology_ThirdWorstFitted_Brain(MinSynapticPlasticity, MaxSynapticPlasticity);
		}
	}

	
	uint32_t NumOfHiddenNeuronsL1, NumOfHiddenNeuronsL2;

	AIPlayerPopulation.Get_HiddenNeuronNumbers_Of_Best_Evolved_NeuralNet(&NumOfHiddenNeuronsL1, &NumOfHiddenNeuronsL2);


	SimulatedHumanPlayer.Initialize(&HumanPlayerPaddle, &PlayBall, 0, 0, false);
	AIPlayer.Initialize(&AIPlayerPaddle, &PlayBall, NumOfHiddenNeuronsL1, NumOfHiddenNeuronsL2);

	//AIPlayer.Brain.Clone_OutputSynapsePlasticities(AIPlayerPopulation.Get_Best_Evolved_NeuralNet());
	AIPlayerPopulation.Get_Best_Evolved_NeuralNet_Ext(&AIPlayer.Brain);

	cout << "Evolution completed" << endl;
	cout << "NumOfHiddenNeuronsL1: " << NumOfHiddenNeuronsL1 << endl;
	cout << "NumOfHiddenNeuronsL2: " << NumOfHiddenNeuronsL2 << endl;
	cout << "Press Return: ";
	getchar();

	int32_t PlayerScore = 0;
	int32_t AIScore = 0;

	Init_New_Game(&HumanPlayerPaddle, &AIPlayerPaddle, &PlayBall, PlayBallVelocityX, PlayBallVelocityY, &Started, &PlayerScore, &AIScore);


	do
	{
		//auto last_timepoint = std::chrono::steady_clock::now();
		//auto last_timepoint = steady_clock::now();
		auto last_timepoint = system_clock::now();

		WinConsole.Clear_BackBuffer();

		if (Started == true)
		{
			AIPlayer.Identify_GamesWorldPositionValues();
			SimulatedHumanPlayer.Identify_GamesWorldPositionValues();
			Init_Or_Reset_fGameBoardArray();


			HumanPlayerPaddle.HumanPlayer_SimpleMovement(2.0f);
			//HumanPlayerPaddle.HumanPlayer_Movement(0.5f, 0.9f);


			AIPlayer.Calculate_NeuralNetPaddleMovement(0.5f, 0.0f, 0.99f);
			//AIPlayer.Calculate_PaddleMovement(0.5f, 0.0f, 0.99f);


			PlayBall.Movement();

			HumanPlayerPaddle.Handle_Possible_PlayBallCollision(&PlayBall, false);
			AIPlayerPaddle.Handle_Possible_PlayBallCollision(&PlayBall, true);




			if (PlayBall.Check_Possible_LowerWallCollision() == true)
			{
				PlayBallVelocityX = RandomNumbers.Get_FloatNumber(-1.0f, 1.0f);
				PlayBallVelocityY = -1.0f;


				//PlayBallVelocityY = 1.0f;
				AIScore++;


				float velXX = PlayBallVelocityX * PlayBallVelocityX;
				float velYY = 1.0f;

				float lengthSq = velXX + velYY;
				float invLength = MaxPlayBallSpeed / (0.0001f + sqrt(lengthSq));

				PlayBallVelocityX *= invLength;
				PlayBallVelocityY *= invLength;

				Init_New_Game(&HumanPlayerPaddle, &AIPlayerPaddle, &PlayBall, PlayBallVelocityX, PlayBallVelocityY, &Started, &PlayerScore, &AIScore);

				AIPlayer.Reset_Memories();

				Init_Or_Reset_fGameBoardArray();

			}
			else if (PlayBall.Check_Possible_UpperWallCollision() == true)
			{
				PlayBallVelocityX = RandomNumbers.Get_FloatNumber(-1.0f, 1.0f);
				PlayBallVelocityY = -1.0f;


				//PlayBallVelocityY = 1.0f;
				PlayerScore++;


				float velXX = PlayBallVelocityX * PlayBallVelocityX;
				float velYY = 1.0f;

				float lengthSq = velXX + velYY;
				float invLength = MaxPlayBallSpeed / (0.0001f + sqrt(lengthSq));

				PlayBallVelocityX *= invLength;
				PlayBallVelocityY *= invLength;

				Init_New_Game(&HumanPlayerPaddle, &AIPlayerPaddle, &PlayBall, PlayBallVelocityX, PlayBallVelocityY, &Started, &PlayerScore, &AIScore);

				AIPlayer.Reset_Memories();

				Init_Or_Reset_fGameBoardArray();
			}

			PlayBall.Handle_Possible_WallCollisions();

			PlayBall.Draw();
			AIPlayerPaddle.Draw();
			HumanPlayerPaddle.Draw();

			PlayBall.fDraw();
			AIPlayerPaddle.fDraw();

		} // end of if (Started == true)




		Output_GameBoard(&WinConsole, lightgreen, lightaqua, lightred);




		sprintf(strBuffer, "Human Score: %03d - AI Score: %03d           ", PlayerScore, AIScore);


		WinConsole.Write_String_Into_BackBuffer(g_PosX_ScoringTextString, g_PosY_ScoringTextString, strBuffer, lightgreen, BackgroundColor);

		if (Started == false)
		{

			sprintf(strBuffer, "SPACE or ESC: start or end game");

			WinConsole.Write_String_Into_BackBuffer(g_PosX_StartGameTextString, g_PosY_StartGameTextString, strBuffer, lightgreen, BackgroundColor);


			if (GetAsyncKeyState(VK_SPACE))
				Started = true;
		}

		WinConsole.Present_BackBuffer();


		//Frame-Bremse:

		//auto current_timepoint = steady_clock::now();
		auto current_timepoint = system_clock::now();

		while (current_timepoint - last_timepoint < 16ms) // 16 ms: maximal 60 Frames pro Sekunde	
		{
			//current_timepoint = steady_clock::now();
			current_timepoint = system_clock::now();
		}



		if (KEYDOWN(VK_ESCAPE) == true)
			break;


	} while (true);

	WinConsole.Clear_BackBuffer();
	WinConsole.CeanUp();


	Set_CursorVisibilityAndSize(true);
	Reset_CursorPos();
	//Set_CursorPos(0, 0);

	//cout << "bye bye (Press Return)" << endl;

	//getchar();
	return 0;
}
*/






