#include "MultiThreading.h"

using namespace std;

static mutex UnblockingMutex[
	g_NumOfUsableThreadsMax];

static condition_variable ThreadCondition[
	g_NumOfUsableThreadsMax];

static bool ReadyToUnblockThread[
	g_NumOfUsableThreadsMax];

static bool StopThread[g_NumOfUsableThreadsMax];

static atomic_bool TaskCompleted[
	g_NumOfUsableThreadsMax];


void CThreadManager::Set_ThreadID(uint32_t id)
{
	ThreadID = 0;

	if (id < g_NumOfUsableThreadsMax)
		ThreadID = id;

	StopThread[ThreadID] = false;
	TaskCompleted[ThreadID].store(false);
}


/* Operatormethode, die im Zuge des wait()-Aufrufs
einer Bedingungsvariablen zum Einsatz kommt: */
bool CThreadManager::operator()(void)
{
	return ReadyToUnblockThread[ThreadID];
}


void CThreadManager::Unblock_Thread(void)
{

	{
		lock_guard<mutex> lockObject(UnblockingMutex[ThreadID]);
		ReadyToUnblockThread[ThreadID] = true;
		TaskCompleted[ThreadID].store(false);
	} // Mutex wurde wieder automatisch unlocked

	  // Aufwachsignal an Thread versenden:
	ThreadCondition[ThreadID].notify_one();
}


void CThreadManager::Stop_Thread(void)
{

	{
		lock_guard<mutex> lockObject(UnblockingMutex[ThreadID]);
		ReadyToUnblockThread[ThreadID] = true;
		//TaskCompleted[ThreadID].store(false);
		StopThread[ThreadID] = true;
	} // Mutex wurde wieder automatisch unlocked

	  // Aufwachsignal an Thread versenden:
	ThreadCondition[ThreadID].notify_one();
}


bool CThreadManager::
Wait_For_UnblockingSignal_And_Continue(void)
{
	unique_lock<mutex> lockObject(UnblockingMutex[ThreadID]);

	/* Solange ReadyToUnblock[ThreadID] gleich false ist,
	bleibt der f�r den Aufruf verantwortliche Thread
	weiter blockiert!  */

	ThreadCondition[ThreadID].wait(lockObject,
		/*Pr�dikat:*/ *this);

	// alternativ:
	/*
	while (ReadyToUnblockThread[ThreadID] == false)
	{
	ThreadCondition[ThreadID].wait(lockObject);
	}
	*/

	ReadyToUnblockThread[ThreadID] = false;

	if (StopThread[ThreadID] == true)
		return false;
	else
		return true;
}


void CThreadManager::Set_BlockingStatus(bool status)
{
	lock_guard<mutex> lockObject(UnblockingMutex[ThreadID]);
	ReadyToUnblockThread[ThreadID] = status;
}


void CThreadManager::Wait_For_Results(void)
{
	while (TaskCompleted[ThreadID].load() == false);
}


void CThreadManager::Task_Completed(void)
{
	TaskCompleted[ThreadID].store(true);
}
