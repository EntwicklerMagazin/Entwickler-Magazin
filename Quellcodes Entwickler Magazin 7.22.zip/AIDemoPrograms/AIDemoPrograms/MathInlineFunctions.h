// Schutz vor Mehrfachdeklarationen:

#ifndef _MathInlineFunctions_H_
#define _MathInlineFunctions_H_

#pragma warning( disable: 4996)

#include <iostream>
#include <omp.h>
#include "RandomNumbers.h"

#ifndef max
#define max(a,b)    ( ((a) > (b)) ? (a) : (b) )
#endif

#ifndef min
#define min(a,b)    ( ((a) < (b)) ? (a) : (b) )
#endif



inline void Swap_ArrayValues(float* pOutArray, float* pInArray, float value1, float value2, int32_t numArrayElements)
{
	for (int32_t i = 0; i < numArrayElements; i++)
	{
		pOutArray[i] = pInArray[i];

		if (pOutArray[i] == value1)
			pOutArray[i] = value2;

		continue;

		if (pOutArray[i] == value2)
			pOutArray[i] = value1;
	}
}

inline void Swap_ArrayValues(float* pInOutArray, float value1, float value2, int32_t numArrayElements)
{
	for (int32_t i = 0; i < numArrayElements; i++)
	{
		if (pInOutArray[i] == value1)
			pInOutArray[i] = value2;

		continue;

		if (pInOutArray[i] == value2)
			pInOutArray[i] = value1;
	}
}

inline void Set_ArrayValue(float* pOutArray, float value, int32_t id1)
{
	pOutArray[id1] = value;
}

inline void Set_ArrayValue(float* pOutArray, float value, int32_t id1, int32_t id2, int32_t numArrayElements_Dir1)
{
	pOutArray[id1 + id2 * numArrayElements_Dir1] = value;
}

// numArrayElements_Dir1XDir2 = numArrayElements_Dir1 * numArrayElements_Dir2
inline void Set_ArrayValue(float* pOutArray, float value, int32_t id1, int32_t id2, int32_t id3,
	int32_t numArrayElements_Dir1, int32_t numArrayElements_Dir1XDir2)
{
	pOutArray[id1 + id2 * numArrayElements_Dir1 + id3 * numArrayElements_Dir1XDir2] = value;
}

/* numArrayElements_Dir1XDir2 = numArrayElements_Dir1 * numArrayElements_Dir2
   numArrayElements_Dir1XDir2XDir3 = numArrayElements_Dir1 * numArrayElements_Dir2 * numArrayElements_Dir3 */
inline void Set_ArrayValue(float* pOutArray, float value, int32_t id1, int32_t id2, int32_t id3, int32_t id4,
	int32_t numArrayElements_Dir1, int32_t numArrayElements_Dir1XDir2, int32_t numArrayElements_Dir1XDir2XDir3)
{
	pOutArray[id1 + id2 * numArrayElements_Dir1 + id3 * numArrayElements_Dir1XDir2 + id4 * numArrayElements_Dir1XDir2XDir3] = value;
}



inline float Get_ArrayValue(float *pArray, int32_t id1)
{
	return pArray[id1];
}

inline float Get_ArrayValue(float* pArray, int32_t id1, int32_t id2, int32_t NumArrayElements_Dir1)
{
	return pArray[id1 + id2 * NumArrayElements_Dir1];
}

// NumArrayElements_Dir1XDir2 = NumArrayElements_Dir1 * NumArrayElements_Dir2
inline float Get_ArrayValue(float* pArray, int32_t id1, int32_t id2, int32_t id3,
	int32_t NumArrayElements_Dir1, int32_t NumArrayElements_Dir1XDir2)
{
	return pArray[id1 + id2 * NumArrayElements_Dir1 + id3 * NumArrayElements_Dir1XDir2];
}

/* NumArrayElements_Dir1XDir2 = NumArrayElements_Dir1 * NumArrayElements_Dir2
   NumArrayElements_Dir1XDir2XDir3 = NumArrayElements_Dir1 * NumArrayElements_Dir2 * NumArrayElements_Dir3 */
inline float Get_ArrayValue(float* pArray, int32_t id1, int32_t id2, int32_t id3, int32_t id4,
	int32_t NumArrayElements_Dir1, int32_t NumArrayElements_Dir1XDir2, int32_t NumArrayElements_Dir1XDir2XDir3)
{
	return pArray[id1 + id2 * NumArrayElements_Dir1 + id3 * NumArrayElements_Dir1XDir2 + id4 * NumArrayElements_Dir1XDir2XDir3];
}







static float Conv3x3Matrix_Identity[9] =
{ 0.0f, 0.0f, 0.0f,
0.0f, 1.0f, 0.0f,
0.0f, 0.0f, 0.0f };

static float Conv3x3Matrix_Sharpen[9] =
{ 0.0f, -1.0f,  0.0f,
-1.0f,  5.0f, -1.0f,
0.0f, -1.0f,  0.0f };

static float Conv3x3Matrix_Edge[9] =
{ -1.0f, -1.0f, -1.0f,
-1.0f,  8.0f, -1.0f,
-1.0f, -1.0f, -1.0f };

static float Conv3x3Matrix_SobelX[9] =
{ 1.0f, 0.0f, -1.0f,
2.0f,  0.0f, -2.0f,
1.0f, 0.0f, -1.0f };

static float Conv3x3Matrix_SobelY[9] =
{ 1.0f, 2.0f, 1.0f,
0.0f,  0.0f, 0.0f,
-1.0f, -2.0f, -1.0f };

static float Conv5x5Matrix_Edge[25] =
{ 0.0f,  0.0f, -1.0f,  0.0f,  0.0f,
0.0f, -1.0f, -2.0f, -1.0f,  0.0f,
-1.0f, -2.0f, 16.0f, -2.0f, -1.0f,
0.0f, -1.0f, -2.0f, -1.0f,  0.0f,
0.0f,  0.0f, -1.0f,  0.0f,  0.0f };

static float Conv3x3Matrix_HorLine[9] =
{ -1.0f, -1.0f, -1.0f,
2.0f,  2.0f,  2.0f,
-1.0f, -1.0f, -1.0f };

static float Conv3x3Matrix_VertLine[9] =
{ -1.0f, 2.0f, -1.0f,
-1.0f, 2.0f, -1.0f,
-1.0f, 2.0f, -1.0f };

static float Conv3x3Matrix_DiagLine1[9] =
{ 2.0f, -1.0f, -1.0f,
-1.0f,  2.0f, -1.0f,
-1.0f, -1.0f,  2.0f };

static float Conv3x3Matrix_DiagLine2[9] =
{ -1.0f, -1.0f,  2.0f,
-1.0f,  2.0f, -1.0f,
2.0f, -1.0f, -1.0f };

static float Conv3x3Matrix_BoxBlur[9] =
{ 0.11f, 0.11f, 0.11f,
0.11f, 0.11f, 0.11f,
0.11f, 0.11f, 0.11f };

static float Conv3x3Matrix_GaussianBlur[9] =
{ 0.0625f, 0.125f, 0.0625f,
0.125f,  0.25f, 0.125f,
0.0625f, 0.125f, 0.0625f };

static float Conv5x5Matrix_GaussianBlur[25] =
{ 1.0f / 256.0f, 4.0f / 256.0f, 6.0f / 256.0f, 4.0f / 256.0f, 1.0f / 256.0f,
4.0f / 256.0f, 16.0f / 256.0f, 24.0f / 256.0f, 16.0f / 256.0f, 4.0f / 256.0f,
6.0f / 256.0f, 24.0f / 256.0f, 36.0f / 256.0f, 24.0f / 256.0f, 6.0f / 256.0f,
4.0f / 256.0f, 16.0f / 256.0f, 24.0f / 256.0f, 16.0f / 256.0f, 4.0f / 256.0f,
1.0f / 256.0f, 4.0f / 256.0f, 6.0f / 256.0f, 4.0f / 256.0f, 1.0f / 256.0f };



inline int32_t factorial(int32_t n)
{
	n++;

	int32_t f = 1;

	for (int32_t i = 1; i < n; i++)
	{
		f *= i;
	}
		
	return f;
}



inline float BinaryToDecimal(float *pInBinaryArray, int32_t numOfArrayElements)
{
	float value = 0;

	int32_t counter = numOfArrayElements - 1;

	for (int32_t i = 0; i < numOfArrayElements; i++)
	{
		value += pow(2.0f, i) *  pInBinaryArray[counter--];
	}

	return value;
}

inline int32_t BinaryToDecimal(int32_t *pInBinaryArray, int32_t numOfArrayElements)
{
	int32_t value = 0;

	int32_t counter = numOfArrayElements - 1;

	for (int32_t i = 0; i < numOfArrayElements; i++)
	{
		value += static_cast<int32_t>(pow(2.0f, i)) *  pInBinaryArray[counter--];
	}

	return value;
}

inline void DecimalToBinary(float *pOutBinaryArray, int32_t numOfArrayElements, float inValue)
{
	int32_t value = static_cast<int32_t>(inValue);

	for (int32_t i = numOfArrayElements - 1; i > -1; i--)
	{
		pOutBinaryArray[i] = static_cast<float>(value % 2);
		value /= 2;
	}
}

inline void DecimalToBinary(int32_t *pOutBinaryArray, int32_t numOfArrayElements, int32_t inValue)
{
	for (int32_t i = numOfArrayElements - 1; i > -1; i--)
	{
		pOutBinaryArray[i] = inValue % 2;
		inValue /= 2;
	}
}

inline void Add_Vectors(float *pOutVector, float *pInVector1, float *pInVector2, int32_t numVectorElements)
{
	for (int32_t i = 0; i < numVectorElements; i++)
	{
		pOutVector[i] = pInVector1[i] + pInVector2[i];
	}
}

inline void Add_Vectors(float *pOutVector, float *pInVector1, float *pInVector2, int32_t minElementID, int32_t maxElementIDPlus1)
{
	for (int32_t i = minElementID; i < maxElementIDPlus1; i++)
	{
		pOutVector[i] = pInVector1[i] + pInVector2[i];
	}
}

inline void Subtract_Vectors(float *pOutVector, float *pInVector1, float *pInVector2, int32_t numVectorElements)
{
	for (int32_t i = 0; i < numVectorElements; i++)
	{
		pOutVector[i] = pInVector1[i] - pInVector2[i];
	}
}

inline void Subtract_Vectors(float *pOutVector, float *pInVector1, float *pInVector2, int32_t minElementID, int32_t maxElementIDPlus1)
{
	for (int32_t i = minElementID; i < maxElementIDPlus1; i++)
	{
		pOutVector[i] = pInVector1[i] - pInVector2[i];
	}
}

inline void Get_MinVector(float *pOutVector, float *pInVector1, float *pInVector2, int32_t numVectorElements)
{
	for (int32_t i = 0; i < numVectorElements; i++)
	{
		pOutVector[i] = min(pInVector1[i], pInVector2[i]);
	}
}

inline void Get_MinVector(float *pOutVector, float *pInVector1, float *pInVector2, int32_t minElementID, int32_t maxElementIDPlus1)
{
	for (int32_t i = minElementID; i < maxElementIDPlus1; i++)
	{
		pOutVector[i] = min(pInVector1[i], pInVector2[i]);
	}
}

inline void Get_MaxVector(float *pOutVector, float *pInVector1, float *pInVector2, int32_t numVectorElements)
{
	for (int32_t i = 0; i < numVectorElements; i++)
	{
		pOutVector[i] = max(pInVector1[i], pInVector2[i]);
	}
}

inline void Get_MaxVector(float *pOutVector, float *pInVector1, float *pInVector2, int32_t minElementID, int32_t maxElementIDPlus1)
{
	for (int32_t i = minElementID; i < maxElementIDPlus1; i++)
	{
		pOutVector[i] = max(pInVector1[i], pInVector2[i]);
	}
}

/* Unterschiede lassen sich nach Vergr��erung des Datensatzes mitunter besser erkennen: */

inline void Double_InputVector(float *pOutVector, float *pInVector, int32_t sizeInVector)
{
	for (int32_t i = 0; i < sizeInVector; i++)
	{
		int32_t j = 2 * i;

		float value = pInVector[i];

		pOutVector[j++] = value;
		pOutVector[j++] = value;
	}
}

inline void Triple_InputVector(float *pOutVector, float *pInVector, int32_t sizeInVector)
{
	for (int32_t i = 0; i < sizeInVector; i++)
	{
		int32_t j = 3 * i;

		float value = pInVector[i];

		pOutVector[j++] = value;
		pOutVector[j++] = value;
		pOutVector[j++] = value;
	}
}

inline void Quadruple_InputVector(float *pOutVector, float *pInVector, int32_t sizeInVector)
{
	for (int32_t i = 0; i < sizeInVector; i++)
	{
		int32_t j = 4 * i;

		float value = pInVector[i];

		pOutVector[j++] = value;
		pOutVector[j++] = value;
		pOutVector[j++] = value;
		pOutVector[j++] = value;
	}
}




/*inline uint8_t* Read_Bitmap_BGR(const char* pFilename)
{
FILE* pFile = fopen(pFilename, "rb");
uint8_t info[54];
fread(info, sizeof(uint8_t), 54, pFile); // read bitmap header

// extract image height and width from header
int32_t width = *(int32_t*)&info[18];
int32_t height = *(int32_t*)&info[22];

int32_t size = 3 * width * height; //  3 color channels
uint8_t* pData = new (std::nothrow) uint8_t[size];
fread(pData, sizeof(uint8_t), size, pFile);
fclose(pFile);

return pData;
}*/




inline uint8_t* Read_Bitmap_BGR(const char* pFilename)
{
	FILE* pFile = fopen(pFilename, "rb");

	int32_t width, height, padding, bitcount, size;
	uint8_t info[54] = { 0 };

	fread(info, 1, 54, pFile);
	width = *(int32_t*)(info + 18);
	height = *(int32_t*)(info + 22);
	bitcount = *(int32_t*)(info + 28);
	size = ((width * bitcount + 31) / 32) * 4 * height;
	padding = width % 4;

	uint8_t* pTempData = new (std::nothrow) uint8_t[size];

	fread(pTempData, 1, size, pFile);

	uint8_t* pData = new (std::nothrow) uint8_t[3 * width * height];

	int32_t id;
	int32_t counter = 0;

	for (int32_t row = 0; row < height; row++)
	{
		for (int32_t col = 0; col < width; col++)
		{
			id = (row * width + col) * 3 + row * padding;

			pData[counter++] = pTempData[id + 0];
			pData[counter++] = pTempData[id + 1];
			pData[counter++] = pTempData[id + 2];

		}
	}

	delete[] pTempData;
	pTempData = nullptr;

	fclose(pFile);

	return pData;
}

class CRGBImageValues
{
public:

	uint8_t *pImageValues = nullptr;

	CRGBImageValues()
	{}

	~CRGBImageValues()
	{
		delete[] pImageValues;
		pImageValues = nullptr;
	}

	// Kopierkonstruktor l�schen:
	CRGBImageValues(const CRGBImageValues  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CRGBImageValues & operator=(const CRGBImageValues  &originalObject) = delete;

	void Reset(void)
	{
		delete[] pImageValues;
		pImageValues = nullptr;
	}
};

inline void Read_Bitmap_BGR(CRGBImageValues *pImage, const char* pFilename)
{
	pImage->Reset();

	FILE* pFile = fopen(pFilename, "rb");

	int32_t width, height, padding, bitcount, size;
	uint8_t info[54] = { 0 };

	fread(info, 1, 54, pFile);
	width = *(int32_t*)(info + 18);
	height = *(int32_t*)(info + 22);
	bitcount = *(int32_t*)(info + 28);
	size = ((width * bitcount + 31) / 32) * 4 * height;
	padding = width % 4;

	uint8_t* pTempData = new (std::nothrow) uint8_t[size];

	fread(pTempData, 1, size, pFile);

	//uint8_t* pData = new (std::nothrow) uint8_t[3 * width * height];
	pImage->pImageValues = new (std::nothrow) uint8_t[3 * width * height];
	uint8_t* pData = pImage->pImageValues;

	int32_t id;
	int32_t counter = 0;

	for (int32_t row = 0; row < height; row++)
	{
		for (int32_t col = 0; col < width; col++)
		{
			id = (row * width + col) * 3 + row * padding;

			pData[counter++] = pTempData[id + 0];
			pData[counter++] = pTempData[id + 1];
			pData[counter++] = pTempData[id + 2];

		}
	}

	delete[] pTempData;
	pTempData = nullptr;

	fclose(pFile);
}


inline void Transform_InputValues(float *pOutputArray, int32_t numOutputArrayElements, const float *pInputArray, int32_t numInputArrayElements)
{
	float scale = 1.0f / static_cast<float>(numInputArrayElements);

	int32_t counter = 0;

	for(int32_t i = 0; i < numOutputArrayElements; i++)
	{ 
		pOutputArray[i] = 0.0f;

		for (int32_t j = 0; j < numInputArrayElements; j++)
		{
			pOutputArray[i] += pInputArray[j] * g_fRandomNumbersTable[counter++];

			if (counter == ConstRandomNumbersTableSize)
				counter = 0;
		}

		pOutputArray[i] *= scale;
	}

}

inline void Transform_InputValuesOMP(float *pOutputArray, int32_t numOutputArrayElements, const float *pInputArray, int32_t numInputArrayElements)
{
	float scale = 1.0f / static_cast<float>(numInputArrayElements);

	int32_t counterArray[8];
	counterArray[0] = 0;
	counterArray[1] = 0;
	counterArray[2] = 0;
	counterArray[3] = 0;
	counterArray[4] = 0;
	counterArray[5] = 0;
	counterArray[6] = 0;
	counterArray[7] = 0;

	for (int32_t i = 0; i < numOutputArrayElements; i++)
	{
		pOutputArray[i] = 0.0f;

#pragma omp parallel for num_threads(4)
//#pragma omp parallel for num_threads(8)
		for (int32_t j = 0; j < numInputArrayElements; j++)
		{
			int32_t threadID = omp_get_thread_num();

			float tempValue = pInputArray[j] * g_fRandomNumbersTable[counterArray[threadID]++];

			if (counterArray[threadID] == ConstRandomNumbersTableSize)
				counterArray[threadID] = 0;

			#pragma omp critical
			{
				pOutputArray[i] += tempValue;
			}	
		}

		pOutputArray[i] *= scale;
	}

}


inline void Transform_InputValues(float *pOutputArray, int32_t numOutputArrayElements, const float *pInputArray, int32_t numInputArrayElements, float weightScale)
{
	float scale = 1.0f / static_cast<float>(numInputArrayElements);

	int32_t counter = 0;

	for (int32_t i = 0; i < numOutputArrayElements; i++)
	{
		pOutputArray[i] = 0.0f;

		for (int32_t j = 0; j < numInputArrayElements; j++)
		{
			pOutputArray[i] += pInputArray[j];// *g_fRandomNumbersTable[counter++];

			if (counter == ConstRandomNumbersTableSize)
				counter = 0;
		}

		pOutputArray[i] *= (scale * weightScale);
		//pOutputArray[i] = 0.5f + 0.5f*(pOutputArray[i] / (1.0f + abs(pOutputArray[i])));
		//pOutputArray[i] = 1.0f / (1.0f + exp(-pOutputArray[i]));
	}
}

inline void Transform_InputValuesOMP(float *pOutputArray, int32_t numOutputArrayElements, const float *pInputArray, int32_t numInputArrayElements, float weightScale)
{
	float scale = 1.0f / static_cast<float>(numInputArrayElements);

	int32_t counterArray[8];
	counterArray[0] = 0;
	counterArray[1] = 0;
	counterArray[2] = 0;
	counterArray[3] = 0;
	counterArray[4] = 0;
	counterArray[5] = 0;
	counterArray[6] = 0;
	counterArray[7] = 0;

	for (int32_t i = 0; i < numOutputArrayElements; i++)
	{
		pOutputArray[i] = 0.0f;

#pragma omp parallel for num_threads(4)
		//#pragma omp parallel for num_threads(8)
		for (int32_t j = 0; j < numInputArrayElements; j++)
		{
			int32_t threadID = omp_get_thread_num();

			float tempValue = pInputArray[j] * g_fRandomNumbersTable[counterArray[threadID]++];

			if (counterArray[threadID] == ConstRandomNumbersTableSize)
				counterArray[threadID] = 0;

			#pragma omp critical
			{
				pOutputArray[i] += tempValue;
			}

			
		}

		pOutputArray[i] *= (scale * weightScale);
	}
}






// LowResImage could be interpreted as a SectorMap
inline void Generate_LowResImageCopy(float *pOutLowResImage, int32_t lowResSizeX, int32_t lowResSizeY, float*pInImage, int32_t sizeX, int32_t sizeY)
{
	int32_t ratioX = sizeX / lowResSizeX;
	int32_t ratioY = sizeY / lowResSizeY;

	for (int32_t iy = 0; iy < sizeY; iy++)
	{
		int32_t iiy = iy * sizeX;

		int32_t iy_reduced = iy / ratioY;
		int32_t iiy_reduced = iy_reduced * lowResSizeX;

		for (int32_t ix = 0; ix < sizeX; ix++)
		{
			int32_t ix_reduced = ix / ratioX;

			int32_t id = ix + iiy;
			int32_t id_reduced = ix_reduced + iiy_reduced;

			float pixelValue_Original = pInImage[id];
			float pixelValue_Reduced = pOutLowResImage[id_reduced];

			pOutLowResImage[id_reduced] = max(pixelValue_Reduced, pixelValue_Original);
		}
	}
}

// LowResImage could be interpreted as a SectorMap
inline void Generate_LowResImageCopy(float *pOutLowResImage, int32_t lowResSizeX, int32_t lowResSizeY, float*pInImage, int32_t sizeX, int32_t sizeY, float threshold)
{
	int32_t ratioX = sizeX / lowResSizeX;
	int32_t ratioY = sizeY / lowResSizeY;

	for (int32_t iy = 0; iy < sizeY; iy++)
	{
		int32_t iiy = iy * sizeX;

		int32_t iy_reduced = iy / ratioY;
		int32_t iiy_reduced = iy_reduced * lowResSizeX;

		for (int32_t ix = 0; ix < sizeX; ix++)
		{
			int32_t ix_reduced = ix / ratioX;

			int32_t id = ix + iiy;
			int32_t id_reduced = ix_reduced + iiy_reduced;

			pOutLowResImage[id_reduced] += pInImage[id];
		}
	}

	int32_t lowResSizeXY = lowResSizeX * lowResSizeY;

	for (int32_t i = 0; i < lowResSizeXY; i++)
	{
		if (pOutLowResImage[i] >= threshold)
		{
			pOutLowResImage[i] = 1.0f;
		}
		else
		{
			pOutLowResImage[i] = 0.0f;
		}
	}

}


// LowResImage could be interpreted as a SectorMap
inline void Generate_InvertedLowResImageCopy(float *pOutLowResImage, int32_t lowResSizeX, int32_t lowResSizeY, float*pInImage, int32_t sizeX, int32_t sizeY)
{
	int32_t ratioX = sizeX / lowResSizeX;
	int32_t ratioY = sizeY / lowResSizeY;

	for (int32_t iy = 0; iy < sizeY; iy++)
	{
		int32_t iiy = iy * sizeX;

		int32_t iy_reduced = iy / ratioY;
		int32_t iiy_reduced = iy_reduced * lowResSizeX;

		for (int32_t ix = 0; ix < sizeX; ix++)
		{
			int32_t ix_reduced = ix / ratioX;

			int32_t id = ix + iiy;
			int32_t id_reduced = ix_reduced + iiy_reduced;

			float pixelValue_Original = pInImage[id];
			float pixelValue_Reduced = pOutLowResImage[id_reduced];

			pOutLowResImage[id_reduced] = 1.0f - min(pixelValue_Reduced, pixelValue_Original);
		}
	}
}

// LowResImage could be interpreted as a SectorMap
inline void Generate_InvertedLowResImageCopy(float *pOutLowResImage, int32_t lowResSizeX, int32_t lowResSizeY, float*pInImage, int32_t sizeX, int32_t sizeY, float threshold)
{
	int32_t ratioX = sizeX / lowResSizeX;
	int32_t ratioY = sizeY / lowResSizeY;

	for (int32_t iy = 0; iy < sizeY; iy++)
	{
		int32_t iiy = iy * sizeX;

		int32_t iy_reduced = iy / ratioY;
		int32_t iiy_reduced = iy_reduced * lowResSizeX;

		for (int32_t ix = 0; ix < sizeX; ix++)
		{
			int32_t ix_reduced = ix / ratioX;

			int32_t id = ix + iiy;
			int32_t id_reduced = ix_reduced + iiy_reduced;

			pOutLowResImage[id_reduced] -= pInImage[id];
		}
	}

	threshold = -threshold;

	int32_t lowResSizeXY = lowResSizeX * lowResSizeY;

	for (int32_t i = 0; i < lowResSizeXY; i++)
	{
		if (pOutLowResImage[i] <= threshold)
		{
			pOutLowResImage[i] = 0.0f;
		}
		else
		{
			pOutLowResImage[i] = 1.0f;
		}
	}
}


inline bool Get_PixelCoord(float *pOutPosX, float *pOutPosY, float *pInImage, int32_t pixelID, int32_t imageSizeX, float intensityThreshold)
{
	if (pInImage[pixelID] < intensityThreshold)
	{
		return false;
	}

	*pOutPosX = static_cast<float>(pixelID % imageSizeX);
	*pOutPosY = static_cast<float>(pixelID / imageSizeX);

	return true;
}

inline void Get_ImageData_RedChannel(float *pOutputArray, const uint8_t *pImageData, int32_t sizeX, int32_t sizeY, float dataBiasValue = 0.0f)
{
	int32_t ix, iy, iy2, id;

	int32_t counter = 2;

	for (iy = sizeY - 1; iy > -1; iy--)
	{
		iy2 = iy * sizeX;

		for (ix = 0; ix < sizeX; ix++)
		{
			id = ix + iy2;

			pOutputArray[id] = static_cast<float>(pImageData[counter]);
			pOutputArray[id] += dataBiasValue;

			counter += 3;
		}
	}
}

inline void Get_BinaryImageData_RedChannel(float *pOutputArray, const uint8_t *pImageData, int32_t sizeX, int32_t sizeY, bool use_0_And_1_Values = true)
{
	int32_t ix, iy, iy2, id;

	int32_t counter = 2;

	for (iy = sizeY - 1; iy > -1; iy--)
	{
		iy2 = iy * sizeX;

		for (ix = 0; ix < sizeX; ix++)
		{
			id = ix + iy2;

			pOutputArray[id] = static_cast<float>(pImageData[counter]);

			pOutputArray[id] = min(1.0f, pOutputArray[id]);

			counter += 3;
		}
	}

	if (use_0_And_1_Values == false)
	{
		int32_t size = sizeX * sizeY;

		for (int32_t i = 0; i < size; i++)
		{
			if (pOutputArray[i] == 0.0f)
				pOutputArray[i] = -1.0f;
		}
	}
}

inline void Get_ImageData_GreenChannel(float *pOutputArray, const uint8_t *pImageData, int32_t sizeX, int32_t sizeY, float dataBiasValue = 0.0f)
{
	int32_t ix, iy, iy2, id;

	int32_t counter = 1;

	for (iy = sizeY - 1; iy > -1; iy--)
	{
		iy2 = iy * sizeX;

		for (ix = 0; ix < sizeX; ix++)
		{
			id = ix + iy2;

			pOutputArray[id] = static_cast<float>(pImageData[counter]);
			pOutputArray[id] += dataBiasValue;

			counter += 3;
		}
	}
}

inline void Get_BinaryImageData_GreenChannel(float *pOutputArray, const uint8_t *pImageData, int32_t sizeX, int32_t sizeY, bool use_0_And_1_Values = true)
{
	int32_t ix, iy, iy2, id;

	int32_t counter = 1;

	for (iy = sizeY - 1; iy > -1; iy--)
	{
		iy2 = iy * sizeX;

		for (ix = 0; ix < sizeX; ix++)
		{
			id = ix + iy2;

			pOutputArray[id] = static_cast<float>(pImageData[counter]);

			pOutputArray[id] = min(1.0f, pOutputArray[id]);

			counter += 3;
		}
	}

	if (use_0_And_1_Values == false)
	{
		int32_t size = sizeX * sizeY;

		for (int32_t i = 0; i < size; i++)
		{
			if (pOutputArray[i] == 0.0f)
				pOutputArray[i] = -1.0f;
		}
	}
}

inline void Get_ImageData_BlueChannel(float *pOutputArray, const uint8_t *pImageData, int32_t sizeX, int32_t sizeY, float dataBiasValue = 0.0f)
{
	int32_t ix, iy, iy2, id;

	int32_t counter = 0;

	for (iy = sizeY - 1; iy > -1; iy--)
	{
		iy2 = iy * sizeX;

		for (ix = 0; ix < sizeX; ix++)
		{
			id = ix + iy2;

			pOutputArray[id] = static_cast<float>(pImageData[counter]);
			pOutputArray[id] += dataBiasValue;

			counter += 3;
		}
	}
}

inline void Get_BinaryImageData_BlueChannel(float *pOutputArray, const uint8_t *pImageData, int32_t sizeX, int32_t sizeY, bool use_0_And_1_Values = true)
{
	int32_t ix, iy, iy2, id;

	int32_t counter = 0;

	for (iy = sizeY - 1; iy > -1; iy--)
	{
		iy2 = iy * sizeX;

		for (ix = 0; ix < sizeX; ix++)
		{
			id = ix + iy2;

			pOutputArray[id] = static_cast<float>(pImageData[counter]);

			pOutputArray[id] = min(1.0f, pOutputArray[id]);

			counter += 3;
		}
	}

	if (use_0_And_1_Values == false)
	{
		int32_t size = sizeX * sizeY;

		for (int32_t i = 0; i < size; i++)
		{
			if (pOutputArray[i] == 0.0f)
				pOutputArray[i] = -1.0f;
		}
	}
}



inline void Output_RawImageData(float *pImage, int32_t sizeX, int32_t sizeY)
{
	int32_t iy, ix, id, iy2;

	for (iy = 0; iy < sizeY; iy++)
	{
		iy2 = iy * sizeX;

		for (ix = 0; ix < sizeX; ix++)
		{
			id = ix + iy2;

			std::cout << pImage[id] << " ";
		}

		std::cout << std::endl;
	}
}

inline void Output_PosImageData(float *pImage, int32_t sizeX, int32_t sizeY)
{
	int32_t iy, ix, id, iy2;

	for (iy = 0; iy < sizeY; iy++)
	{
		iy2 = iy * sizeX;

		for (ix = 0; ix < sizeX; ix++)
		{
			id = ix + iy2;

			std::cout << max(0.0f, pImage[id]) << " ";
		}

		std::cout << std::endl;
	}
}

inline void Output_BinaryImageData(float *pImage, int32_t sizeX, int32_t sizeY)
{
	int32_t iy, ix, id, iy2;

	for (iy = 0; iy < sizeY; iy++)
	{
		iy2 = iy * sizeX;

		for (ix = 0; ix < sizeX; ix++)
		{
			id = ix + iy2;

			if (pImage[id] > 0.0f)
				std::cout << 1 << " ";
			else
				std::cout << 0 << " ";
		}

		std::cout << std::endl;
	}
}

inline void Output_BinaryImageData2(float *pImage, int32_t sizeX, int32_t sizeY)
{
	int32_t iy, ix, id, iy2;

	for (iy = 0; iy < sizeY; iy++)
	{
		iy2 = iy * sizeX;

		for (ix = 0; ix < sizeX; ix++)
		{
			id = ix + iy2;

			if (pImage[id] > 0.0f)
				std::cout << 1 << " ";
			else
				std::cout << "  ";
		}

		std::cout << std::endl;
	}
}

inline void NearestPointImageScaling(float* pOutputImage, int32_t outputSizeX, int32_t outputSizeY, const float *pInputImage, int32_t inputSizeX, int32_t inputSizeY)
{
	int32_t iiy_OutputImage;
	int32_t iiy_InputImage;

	for (int32_t iy = 0; iy < outputSizeY; iy++)
	{
		iiy_OutputImage = iy * outputSizeX;
		iiy_InputImage = inputSizeY * iy / outputSizeY * inputSizeX;

		for (int32_t ix = 0; ix < outputSizeX; ix++)
			pOutputImage[ix + iiy_OutputImage] = pInputImage[inputSizeX * ix / outputSizeX + iiy_InputImage];
	}
}







// old resolution => new resolution
// 32x32 => 16x16
// 30x30 => 15x15
// 15x15 => 8x8

inline void Bisect_Resolution(float *pOutputArray, const float *pInputArray, int32_t inputArraySizeX, int32_t inputArraySizeY)
{
	int32_t inputArraySizeXMinus1 = inputArraySizeX - 1;
	int32_t inputArraySizeYMinus1 = inputArraySizeY - 1;

	int32_t ixInput, iyInput, tempIy1, tempIy2, idInput;
	int32_t ixInputPlus1, iyInputPlus1;
	int32_t counter = 0;

	float tempValue;

	for (iyInput = 0; iyInput < inputArraySizeY; iyInput += 2)
	{
		tempIy1 = inputArraySizeX*iyInput;
		iyInputPlus1 = min(inputArraySizeYMinus1, (iyInput + 1));
		tempIy2 = inputArraySizeX*iyInputPlus1;

		for (ixInput = 0; ixInput < inputArraySizeX; ixInput += 2)
		{
			ixInputPlus1 = min(inputArraySizeXMinus1, (ixInput + 1));

			idInput = ixInput + tempIy1;
			tempValue = pInputArray[idInput];

			idInput = ixInputPlus1 + tempIy1;
			tempValue += pInputArray[idInput];

			idInput = ixInput + tempIy2;
			tempValue += pInputArray[idInput];

			idInput = ixInputPlus1 + tempIy2;
			tempValue += pInputArray[idInput];

			tempValue *= 0.25f;

			pOutputArray[counter] = tempValue;
			counter++;
		}
	}
}

inline void Bisect_Resolution(float *pOutputArray, const float *pInputArray, int32_t inputArraySize)
{
	int32_t inputArraySizeMinus1 = inputArraySize - 1;

	int32_t inputPlus1;

	int32_t counter = 0;

	float tempValue;

	for (int32_t i = 0; i < inputArraySize; i += 2)
	{
		inputPlus1 = min(inputArraySizeMinus1, (i + 1));

		tempValue = pInputArray[i];
		tempValue += pInputArray[inputPlus1];

		tempValue *= 0.5f;

		pOutputArray[counter] = tempValue;
		counter++;
	}
}


inline void MaxPooling2x2(float *pOutputArray, const float *pInputArray, int32_t inputArraySizeX, int32_t inputArraySizeY)
{
	int32_t inputArraySizeXMinus1 = inputArraySizeX - 1;
	int32_t inputArraySizeYMinus1 = inputArraySizeY - 1;


	int32_t ixInput, iyInput, tempIy1, tempIy2, idInput;
	int32_t ixInputPlus1, iyInputPlus1;
	int32_t counter = 0;

	float maxValue;

	for (iyInput = 0; iyInput < inputArraySizeY; iyInput += 2)
	{
		tempIy1 = inputArraySizeX*iyInput;
		iyInputPlus1 = min(inputArraySizeYMinus1, (iyInput + 1));
		tempIy2 = inputArraySizeX*iyInputPlus1;

		for (ixInput = 0; ixInput < inputArraySizeX; ixInput += 2)
		{
			ixInputPlus1 = min(inputArraySizeXMinus1, (ixInput + 1));

			idInput = ixInput + tempIy1;
			maxValue = pInputArray[idInput];

			idInput = ixInputPlus1 + tempIy1;
			maxValue = max(maxValue, pInputArray[idInput]);

			idInput = ixInput + tempIy2;
			maxValue = max(maxValue, pInputArray[idInput]);

			idInput = ixInputPlus1 + tempIy2;
			maxValue = max(maxValue, pInputArray[idInput]);

			pOutputArray[counter] = maxValue;
			counter++;
		}
	}
}

inline void MaxPooling2x1(float *pOutputArray, const float *pInputArray, int32_t inputArraySize)
{
	int32_t inputArraySizeMinus1 = inputArraySize - 1;

	int32_t inputPlus1;

	int32_t counter = 0;

	float maxValue;

	for (int32_t i = 0; i < inputArraySize; i += 2)
	{
		inputPlus1 = min(inputArraySizeMinus1, (i + 1));

		maxValue = pInputArray[i];
		maxValue = max(maxValue, pInputArray[inputPlus1]);

		pOutputArray[counter] = maxValue;
		counter++;
	}
}


inline void L2Pooling2x2(float *pOutputArray, const float *pInputArray, int32_t inputArraySizeX, int32_t inputArraySizeY)
{
	int32_t inputArraySizeXMinus1 = inputArraySizeX - 1;
	int32_t inputArraySizeYMinus1 = inputArraySizeY - 1;

	int32_t ixInput, iyInput, tempIy1, tempIy2, idInput;
	int32_t ixInputPlus1, iyInputPlus1;
	int32_t counter = 0;

	float tempValue, tempValue2;

	for (iyInput = 0; iyInput < inputArraySizeY; iyInput += 2)
	{
		tempIy1 = inputArraySizeX*iyInput;
		iyInputPlus1 = min(inputArraySizeYMinus1, (iyInput + 1));
		tempIy2 = inputArraySizeX*iyInputPlus1;

		for (ixInput = 0; ixInput < inputArraySizeX; ixInput += 2)
		{
			ixInputPlus1 = min(inputArraySizeXMinus1, (ixInput + 1));

			idInput = ixInput + tempIy1;
			tempValue2 = pInputArray[idInput];
			tempValue = tempValue2 * tempValue2;

			idInput = ixInputPlus1 + tempIy1;
			tempValue2 = pInputArray[idInput];
			tempValue += tempValue2 * tempValue2;

			idInput = ixInput + tempIy2;
			tempValue2 = pInputArray[idInput];
			tempValue += tempValue2 * tempValue2;

			idInput = ixInputPlus1 + tempIy2;
			tempValue2 = pInputArray[idInput];
			tempValue += tempValue2 * tempValue2;

			pOutputArray[counter] = sqrt(tempValue);
			counter++;
		}
	}
}

inline void L2Pooling2x1(float *pOutputArray, const float *pInputArray, int32_t inputArraySize)
{
	int32_t inputArraySizeMinus1 = inputArraySize - 1;

	int32_t inputPlus1;

	int32_t counter = 0;

	float tempValue, tempValue2;

	for (int32_t i = 0; i < inputArraySize; i += 2)
	{
		inputPlus1 = min(inputArraySizeMinus1, (i + 1));

		tempValue2 = pInputArray[i];
		tempValue = tempValue2 * tempValue2;

		tempValue2 = pInputArray[inputPlus1];
		tempValue += tempValue2 * tempValue2;

		pOutputArray[counter] = sqrt(tempValue);
		counter++;
	}
}

inline void Scale_Data(float *pInputOutputArray, /*numArrayElements:*/ int32_t arraySize, float scaleFactor)
{
	for (int32_t i = 0; i < arraySize; i++)
		pInputOutputArray[i] *= scaleFactor;
}

inline void Scale_Data(float *pOutputArray, const float *pInputArray, /*numArrayElements:*/ int32_t arraySize, float scaleFactor)
{
	for (int32_t i = 0; i < arraySize; i++)
		pOutputArray[i] = scaleFactor * pInputArray[i];
}


inline void Init_1DimArray(float *pInputOutputArray, /*numArrayElements:*/ int32_t arraySize, float value)
{
	for (int32_t i = 0; i < arraySize; i++)
		pInputOutputArray[i] = value;
}

inline void Init_1DimArray(float *pInputOutputArray, int32_t minArrayElement, int32_t maxArrayElement, float value)
{
	maxArrayElement++;

	for (int32_t i = minArrayElement; i < maxArrayElement; i++)
		pInputOutputArray[i] = value;
}



inline void Init_Random1DimArray(float *pInputOutputArray, /*numArrayElements:*/ int32_t arraySize, CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue)
{
	for (int32_t i = 0; i < arraySize; i++)
		pInputOutputArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minValue, maxValue);
}

inline void Init_Random1DimArray(float *pInputOutputArray, int32_t minArrayElement, int32_t maxArrayElement, CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue)
{
	maxArrayElement++;

	for (int32_t i = minArrayElement; i < maxArrayElement++; i++)
		pInputOutputArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minValue, maxValue);
}



inline void Copy_1DimArray(float *pOutputArray, const float *pInputArray, /*numArrayElements:*/ int32_t arraySize)
{
	for (int32_t i = 0; i < arraySize; i++)
		pOutputArray[i] = pInputArray[i];
}

inline void Copy_1DimArray(float *pOutputArray, const float *pInputArray, int32_t minArrayElement, int32_t maxArrayElement)
{
	maxArrayElement++;

	for (int32_t i = minArrayElement; i < maxArrayElement++; i++)
		pOutputArray[i] = pInputArray[i];
}


inline void Init_2DimArray(float *pInputOutputArray, int32_t arraySizeX, int32_t arraySizeY, float value)
{
	int32_t numArrayElements = arraySizeX * arraySizeY;

	for (int32_t i = 0; i < numArrayElements; i++)
		pInputOutputArray[i] = value;
}

inline void Init_Random2DimArray(float *pInputOutputArray, uint32_t arraySizeX, uint32_t arraySizeY, CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue)
{
	uint32_t numArrayElements = arraySizeX * arraySizeY;

	for (uint32_t i = 0; i < numArrayElements; i++)
		pInputOutputArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minValue, maxValue);
}


inline void Copy_2DimArray(float *pOutputArray, const float *pInputArray, uint32_t arraySizeX, uint32_t arraySizeY)
{
	uint32_t numArrayElements = arraySizeX * arraySizeY;

	for (uint32_t i = 0; i < numArrayElements; i++)
		pOutputArray[i] = pInputArray[i];
}


inline void Copy_FromInputToOutputArray(float *pOutputArray, uint32_t outputArraySizeX, const float *pInputArray, uint32_t inputArraySizeX, uint32_t inputArraySizeY, uint32_t copySizeX, uint32_t copySizeY, uint32_t inputArrayOffsetX, uint32_t inputArrayOffsetY)
{
	uint32_t ixInputMin = inputArrayOffsetX;
	uint32_t ixInputMax = min(inputArraySizeX, ixInputMin + copySizeX);

	uint32_t iyInputMin = inputArrayOffsetY;
	uint32_t iyInputMax = min(inputArraySizeY, iyInputMin + copySizeY);

	uint32_t ixInput, iyInput, iiy_input, iiy_output;


	uint32_t counterX = 0;
	uint32_t counterY = 0;


	for (iyInput = iyInputMin; iyInput < iyInputMax; iyInput++)
	{
		iiy_output = outputArraySizeX * counterY;
		iiy_input = inputArraySizeX * iyInput;

		counterX = 0;

		for (ixInput = ixInputMin; ixInput < ixInputMax; ixInput++)
		{
			pOutputArray[counterX + iiy_output] = pInputArray[ixInput + iiy_input];
			counterX++;
		}

		counterY++;
	}
}

inline void Copy_FromInputToOutputArray(float *pOutputArray, uint32_t outputArraySizeX, uint32_t outputArrayOffsetX, uint32_t outputArrayOffsetY, const float *pInputArray, uint32_t inputArraySizeX, uint32_t inputArraySizeY, uint32_t copySizeX, uint32_t copySizeY, uint32_t inputArrayOffsetX, uint32_t inputArrayOffsetY)
{
	uint32_t ixInputMin = inputArrayOffsetX;
	uint32_t ixInputMax = min(inputArraySizeX, ixInputMin + copySizeX);

	uint32_t iyInputMin = inputArrayOffsetY;
	uint32_t iyInputMax = min(inputArraySizeY, iyInputMin + copySizeY);

	uint32_t ixInput, iyInput, iiy_input, iiy_output;


	uint32_t counterX = outputArrayOffsetX;
	uint32_t counterY = outputArrayOffsetY;


	for (iyInput = iyInputMin; iyInput < iyInputMax; iyInput++)
	{
		iiy_output = outputArraySizeX * counterY;
		iiy_input = inputArraySizeX * iyInput;

		counterX = outputArrayOffsetX;

		for (ixInput = ixInputMin; ixInput < ixInputMax; ixInput++)
		{
			pOutputArray[counterX + iiy_output] = pInputArray[ixInput + iiy_input];
			counterX++;
		}

		counterY++;
	}
}


inline void Copy_FromInputToOutputArray(float *pOutputArray, const float *pInputArray, uint32_t inputArraySize, uint32_t copySize, uint32_t inputArrayOffset)
{
	uint32_t inputMin = inputArrayOffset;
	uint32_t inputMax = min(inputArraySize, inputMin + copySize);

	uint32_t counter = 0;

	for (uint32_t i = inputMin; i < inputMax; i++)
	{
		pOutputArray[counter] = pInputArray[i];
		counter++;
	}
}

inline void Copy_FromInputToOutputArray(float *pOutputArray, uint32_t outputArrayOffset, const float *pInputArray, uint32_t inputArraySize, uint32_t copySize, uint32_t inputArrayOffset)
{
	uint32_t inputMin = inputArrayOffset;
	uint32_t inputMax = min(inputArraySize, inputMin + copySize);

	uint32_t counter = outputArrayOffset;

	for (uint32_t i = inputMin; i < inputMax; i++)
	{
		pOutputArray[counter] = pInputArray[i];
		counter++;
	}
}

inline void SoftMax(float* pOutputData, const float* pInputData, uint32_t numElements)
{
	float maxValue = pInputData[0];

	for (uint32_t i = 1; i < numElements; i++)
	{
		if (pInputData[i] > maxValue)
			maxValue = pInputData[i];
	}

	float tempfloat = 0.00000001f;

	for (uint32_t i = 0; i < numElements; i++)
		tempfloat += exp(pInputData[i] - maxValue);

	/*tempfloat = 1.0f / tempfloat;

	for (uint32_t i = 0; i < numElements; i++)
	pOutputData[i] = exp(pInputData[i] - maxValue)*tempfloat;*/

	float offset = maxValue + log(tempfloat);

	for (uint32_t i = 0; i < numElements; i++)
		pOutputData[i] = exp(pInputData[i] - offset);
}

inline void SoftMax(float* pInputOutputData, uint32_t numElements)
{
	float maxValue = pInputOutputData[0];

	for (uint32_t i = 1; i < numElements; i++)
	{
		if (pInputOutputData[i] > maxValue)
			maxValue = pInputOutputData[i];
	}

	float tempfloat = 0.00000001f;

	for (uint32_t i = 0; i < numElements; i++)
		tempfloat += exp(pInputOutputData[i] - maxValue);

	/*tempfloat = 1.0f / tempfloat;

	for (uint32_t i = 0; i < numElements; i++)
	pInputOutputData[i] = exp(pInputOutputData[i] - maxValue)*tempfloat;*/

	float offset = maxValue + log(tempfloat);

	for (uint32_t i = 0; i < numElements; i++)
		pInputOutputData[i] = exp(pInputOutputData[i] - offset);
}

inline void Normalize(float* pOutputData, const float* pInputData, uint32_t numElements)
{
	float tempfloat = 0.0f;

	for (uint32_t i = 0; i < numElements; i++)
		tempfloat += pInputData[i] * pInputData[i];

	if (tempfloat == 0.0f)
		return;

	tempfloat = sqrtf(tempfloat);
	tempfloat = 1.0f / tempfloat;

	for (uint32_t i = 0; i < numElements; i++)
		pOutputData[i] = tempfloat * pInputData[i];
}

inline void Normalize(float *pInputOutputData, int32_t numElements)
{
	float tempfloat = 0.0f;

	for (int32_t i = 0; i < numElements; i++)
		tempfloat += pInputOutputData[i] * pInputOutputData[i];

	if (tempfloat == 0.0f)
		return;

	tempfloat = sqrtf(tempfloat);
	tempfloat = 1.0f / tempfloat;

	for (int32_t i = 0; i < numElements; i++)
		pInputOutputData[i] = tempfloat * pInputOutputData[i];
}

inline void Normalize(float *pInputOutputX, float *pInputOutputY, float *pInputOutputZ)
{
	float x = *pInputOutputX;
	float y = *pInputOutputY;
	float z = *pInputOutputZ;

	float tempfloat = x * x + y * y + z * z;

	if (tempfloat == 0.0f)
		return;

	tempfloat = sqrtf(tempfloat);
	tempfloat = 1.0f / tempfloat;

	*pInputOutputX = tempfloat * x;
	*pInputOutputY = tempfloat * y;
	*pInputOutputZ = tempfloat * z;
}

inline void Normalize(float *pInputOutputX, float *pInputOutputY)
{
	float x = *pInputOutputX;
	float y = *pInputOutputY;


	float tempfloat = x * x + y * y;

	if (tempfloat == 0.0f)
		return;

	tempfloat = sqrtf(tempfloat);
	tempfloat = 1.0f / tempfloat;

	*pInputOutputX = tempfloat * x;
	*pInputOutputY = tempfloat * y;
}

inline void Normalize(float *pOutX, float *pOutY, float *pOutZ, float inX, float inY, float inZ)
{
	float tempfloat = inX * inX + inY * inY + inZ * inZ;

	if (tempfloat == 0.0f)
		return;

	tempfloat = sqrtf(tempfloat);
	tempfloat = 1.0f / tempfloat;

	*pOutX = tempfloat * inX;
	*pOutY = tempfloat * inY;
	*pOutZ = tempfloat * inZ;
}

inline void Normalize(float *pOutX, float *pOutY, float inX, float inY)
{
	float tempfloat = inX * inX + inY * inY;

	if (tempfloat == 0.0f)
		return;

	tempfloat = sqrtf(tempfloat);
	tempfloat = 1.0f / tempfloat;

	*pOutX = tempfloat * inX;
	*pOutY = tempfloat * inY;
}

inline void CrossProduct(float *pOutX, float *pOutY, float *pOutZ, float inX1, float inY1, float inZ1, float inX2, float inY2, float inZ2)
{
	//v.x = pV1->y * pV2->z - pV1->z * pV2->y;
	//v.y = pV1->z * pV2->x - pV1->x * pV2->z;
	//v.z = pV1->x * pV2->y - pV1->y * pV2->x;

	*pOutX = inY1 * inZ2 - inZ1 * inY2;
	*pOutY = inZ1 * inX2 - inX1 * inZ2;
	*pOutZ = inX1 * inY2 - inY1 * inX2;

	/*
	Beispiel 1:  V1 = (1, 0, 0) (Daumen linke Hand)  V2 = (0, 1, 0) (Zeigefinger linke Hand)

	Out = (0, 0, 1) (Mittelfinger linke Hand)

	Beispiel 2:  V1 = (0, 1, 0) (Daumen linke Hand)  V2 = (1, 0, 0) (Zeigefinger linke Hand)

	Out = (0, 0, -1) (Mittelfinger linke Hand)

	*/
}



inline float DotProduct(const float *pVector1, const float *pVector2, int32_t numVectorElements)
{
	float dot = 0.0f;

	for (int32_t i = 0; i < numVectorElements; i++)
		dot += pVector1[i] * pVector2[i];

	return dot;
}

inline float DotProduct(float x1, float y1, float z1, float x2, float y2, float z2)
{
	return x1 * x2 + y1 * y2 + z1 * z2;
}

inline float DotProduct(float x1, float y1, float x2, float y2)
{
	return x1 * x2 + y1 * y2;
}

inline float VectorLengthSq(const float *pVector, int32_t numVectorElements)
{
	float lengthSq = 0.0f;

	for (int32_t i = 0; i < numVectorElements; i++)
		lengthSq += pVector[i] * pVector[i];

	return lengthSq;
}

inline float VectorLengthSq(float x, float y, float z)
{
	return x * x + y * y + z * z;
}

inline float VectorLength(float x, float y, float z)
{
	return sqrt(x * x + y * y + z * z);
}

inline float VectorLengthSq(float x, float y)
{
	return x * x + y * y;
}

inline float VectorLength(float x, float y)
{
	return sqrt(x * x + y * y);
}

inline void Clone_Matrix(float *pOutMat, const float *pInMat, int32_t numColumns, int32_t numRows)
{
	int32_t sizeXY = numColumns * numRows;

	for (int32_t i = 0; i < sizeXY; i++)
		pOutMat[i] = pInMat[i];
}

inline void Init_ZeroMatrix(float *pOutMat, int32_t numColumns, int32_t numRows)
{
	int32_t sizeXY = numColumns * numRows;

	for (int32_t i = 0; i < sizeXY; i++)
		pOutMat[i] = 0.0f;
}

inline void Init_IdentityMatrix(float *pOutMat, int32_t numColumns, int32_t numRows)
{
	int32_t sizeXY = numColumns * numRows;

	for (int32_t i = 0; i < sizeXY; i++)
		pOutMat[i] = 0.0f;

	int32_t delta = numColumns + 1;

	for (int32_t i = 0; i <  numColumns; i++)
		pOutMat[i * delta] = 1.0f;
}

inline void Init_ScaleMatrix(float *pOutMat, int32_t numColumns, int32_t numRows, float *pInScaleVector)
{
	int32_t sizeXY = numColumns * numRows;

	for (int32_t i = 0; i < sizeXY; i++)
		pOutMat[i] = 0.0f;

	int32_t delta = numColumns + 1;

	for (int32_t i = 0; i < numColumns; i++)
		pOutMat[i * delta] = pInScaleVector[i];
}

inline void MatrixAddition(float *pOutMat, const float *pInMat1, const float *pInMat2, int32_t numColumns, int32_t numRows)
{
	int32_t sizeXY = numColumns * numRows;

	for (int32_t i = 0; i < sizeXY; i++)
		pOutMat[i] = pInMat1[i] + pInMat2[i];
}

inline void MatrixSubtraction(float *pOutMat, const float *pInMat1, const float *pInMat2, int32_t numColumns, int32_t numRows)
{
	int32_t sizeXY = numColumns * numRows;

	for (int32_t i = 0; i < sizeXY; i++)
		pOutMat[i] = pInMat1[i] - pInMat2[i];
}

inline void Calculate_DegreeMatrix(float *pOutMat, const float *pInAdjacencyMat, int32_t numColumns, int32_t numRows)
{
	Init_ZeroMatrix(pOutMat, numColumns, numRows);

	for (int32_t iy = 0; iy < numRows; iy++)
	{
		int32_t iiy = iy *numColumns;

		float sum = 0.0f;

		for (int32_t ix = 0; ix < numColumns; ix++)
		{
			sum += pInAdjacencyMat[iiy + ix];
		}

		pOutMat[iy + iiy] = sum;
	}
}

inline void Substitute_NonZeroMatrixValues(float *pInOutMat, int32_t numColumns, int32_t numRows, float substitutionValue)
{
	int32_t sizeXY = numColumns * numRows;

	for (int32_t i = 0; i < sizeXY; i++)
	{
		if (pInOutMat[i] != 0.0f)
			pInOutMat[i] = substitutionValue;
	}
}

inline bool Compare_Matrices(const float *pInMat1, const float *pInMat2, int32_t numColumns, int32_t numRows)
{
	int32_t sizeXY = numColumns * numRows;

	for (int32_t i = 0; i < sizeXY; i++)
	{
		if (pInMat1[i] != pInMat2[i])
			return false;
	}

	return true;
}

inline void MatrixMultiplication(float *pOutMat, const float *pInMat1, const float *pInTransposeMat2, int32_t numColumnsMat1, int32_t numRowsTransposeMat2, int32_t outputMatrixElements)
{
	for (int32_t outMatElementID = 0; outMatElementID < outputMatrixElements; outMatElementID++)
	{
		int32_t elementIDMat1 = outMatElementID / numRowsTransposeMat2;
		elementIDMat1 *= numColumnsMat1;

		int32_t elementIDMat2 = outMatElementID % numRowsTransposeMat2;
		elementIDMat2 *= numColumnsMat1;

		float sum = 0.0f;

		for (int32_t vecElementID = 0; vecElementID < numColumnsMat1; vecElementID++)
		{
			sum += pInMat1[elementIDMat1] * pInTransposeMat2[elementIDMat2];
			elementIDMat1++;
			elementIDMat2++;
		}

		pOutMat[outMatElementID] = sum;
	}
}

inline void MatrixMultiplication_OMP(float *pOutMat, const float *pInMat1, const float *pInTransposeMat2, int32_t numColumnsMat1, int32_t numRowsTransposeMat2, int32_t outputMatrixElements)
{
//#pragma omp parallel for num_threads(2)
#pragma omp parallel for
	for (int32_t outMatElementID = 0; outMatElementID < outputMatrixElements; outMatElementID++)
	{
		int32_t elementIDMat1 = outMatElementID / numRowsTransposeMat2;
		elementIDMat1 *= numColumnsMat1;

		int32_t elementIDMat2 = outMatElementID % numRowsTransposeMat2;
		elementIDMat2 *= numColumnsMat1;

		float sum = 0.0f;

		for (int32_t vecElementID = 0; vecElementID < numColumnsMat1; vecElementID++)
		{
			sum += pInMat1[elementIDMat1] * pInTransposeMat2[elementIDMat2];
			elementIDMat1++;
			elementIDMat2++;
		}

		pOutMat[outMatElementID] = sum;
	}
}

inline void MatrixMultiplication2(float *pOutMat, const float *pInMat1, const float *pInMat2, int32_t numColumnsMat1, int32_t numColumnsMat2, int32_t outputMatrixElements)
{
	for (int32_t outMatElementID = 0; outMatElementID < outputMatrixElements; outMatElementID++)
	{
		int32_t elementIDMat1 = outMatElementID / numColumnsMat2;
		elementIDMat1 *= numColumnsMat1;

		int32_t elementIDMat2 = outMatElementID % numColumnsMat2;
		

		float sum = 0.0f;

		for (int32_t vecElementID = 0; vecElementID < numColumnsMat1; vecElementID++)
		{
			sum += pInMat1[elementIDMat1] * pInMat2[elementIDMat2];
			elementIDMat1++;
			elementIDMat2 += numColumnsMat2;
		}

		pOutMat[outMatElementID] = sum;
	}
}

inline void MatrixMultiplication2_OMP(float *pOutMat, const float *pInMat1, const float *pInMat2, int32_t numColumnsMat1, int32_t numColumnsMat2, int32_t outputMatrixElements)
{
//#pragma omp parallel for num_threads(2)
#pragma omp parallel for
	for (int32_t outMatElementID = 0; outMatElementID < outputMatrixElements; outMatElementID++)
	{
		int32_t elementIDMat1 = outMatElementID / numColumnsMat2;
		elementIDMat1 *= numColumnsMat1;

		int32_t elementIDMat2 = outMatElementID % numColumnsMat2;


		float sum = 0.0f;

		for (int32_t vecElementID = 0; vecElementID < numColumnsMat1; vecElementID++)
		{
			sum += pInMat1[elementIDMat1] * pInMat2[elementIDMat2];
			elementIDMat1++;
			elementIDMat2 += numColumnsMat2;
		}

		pOutMat[outMatElementID] = sum;
	}
}


inline void MatrixMultiplication(float *pOutMat, const float *pInMat1, int32_t numColumnsMat1, int32_t numRowsMat1, const float *pInMat2, int32_t numColumnsMat2, int32_t numRowsMat2)
{
	if (numColumnsMat1 != numRowsMat2)
		return;

	int32_t iy, ix, k, iiy, iiyProduct, idProduct;

	for (iy = 0; iy < numRowsMat1; iy++)
	{
		iiy = iy * numColumnsMat1;
		iiyProduct = iy*numColumnsMat2;

		for (ix = 0; ix < numColumnsMat2; ix++)
		{
			idProduct = ix + iiyProduct;

			pOutMat[idProduct] = 0.0f;

			for (k = 0; k < numRowsMat2; k++)
				pOutMat[idProduct] += pInMat1[k + iiy] * pInMat2[ix + k * numColumnsMat2];
		}
	}
}





inline int32_t Calculate_ReachabilityMatrix(float *pOutMat, const float *pInAdjacencyMat, float *pTempMat1, float *pTempMat2, float *pTempMat3, int32_t numColumns, int32_t numRows)
{

	int32_t counter = 0;

	do
	{
		Init_IdentityMatrix(pOutMat, numColumns, numRows);
		MatrixAddition(pOutMat, pOutMat, pInAdjacencyMat, numColumns, numRows);
		Clone_Matrix(pTempMat1, pOutMat, numColumns, numRows);

		Clone_Matrix(pTempMat2, pInAdjacencyMat, numColumns, numRows);
		//Clone_Matrix(pTempMat3, pInAdjacencyMat, numColumns, numRows);

		for (int32_t i = 0; i < counter; i++)
		{
			if (i % 2 == 0)
			{
				MatrixMultiplication(pTempMat3, pTempMat2, numColumns, numRows, pInAdjacencyMat, numColumns, numRows);
				MatrixAddition(pOutMat, pOutMat, pTempMat3, numColumns, numRows);
				MatrixAddition(pTempMat1, pTempMat1, pTempMat3, numColumns, numRows);
			}
			else
			{
				MatrixMultiplication(pTempMat2, pTempMat3, numColumns, numRows, pInAdjacencyMat, numColumns, numRows);
				MatrixAddition(pOutMat, pOutMat, pTempMat2, numColumns, numRows);
				MatrixAddition(pTempMat1, pTempMat1, pTempMat2, numColumns, numRows);
			}
		}

	

		if (counter % 2 == 0)
		{
			MatrixMultiplication(pTempMat3, pTempMat2, numColumns, numRows, pInAdjacencyMat, numColumns, numRows);
			MatrixAddition(pTempMat1, pTempMat1, pTempMat3, numColumns, numRows);
		}
		else
		{
			MatrixMultiplication(pTempMat2, pTempMat3, numColumns, numRows, pInAdjacencyMat, numColumns, numRows);
			MatrixAddition(pTempMat1, pTempMat1, pTempMat2, numColumns, numRows);
		}

		Substitute_NonZeroMatrixValues(pOutMat, numColumns, numRows, 1.0f);
		Substitute_NonZeroMatrixValues(pTempMat1, numColumns, numRows, 1.0f);

		if (Compare_Matrices(pOutMat, pTempMat1, numColumns, numRows) == true)
			return (counter + 2);

		counter++;

	} while (true);

	return -1;
}


inline void TransposeMatrix_OMP(float *pOutMat, const float *pInMat, int32_t numColumnsInMat, int32_t numRowsInMat)
{
//#pragma omp parallel for num_threads(2)
#pragma omp parallel for
	for (int32_t iy = 0; iy < numRowsInMat; iy++)
	{
		int32_t iiy = iy * numColumnsInMat;

		for (int32_t ix = 0; ix < numColumnsInMat; ix++)
		{
			pOutMat[iy + ix * numRowsInMat] = pInMat[ix + iiy];
		}
	}
}


inline void TransposeMatrix(float *pOutMat, const float *pInMat, int32_t numColumnsInMat, int32_t numRowsInMat)
{
	for (int32_t iy = 0; iy < numRowsInMat; iy++)
	{
		int32_t iiy = iy * numColumnsInMat;

		for (int32_t ix = 0; ix < numColumnsInMat; ix++)
		{
			pOutMat[iy + ix * numRowsInMat] = pInMat[ix + iiy];
		}
	}
}

inline void TransposeMatrix2(float *pOutMat, const float *pInMat, int32_t numColumnsInMat, int32_t numRowsInMat)
{
	int32_t matrixElements = numColumnsInMat * numRowsInMat;

	for (int32_t i = 0; i < matrixElements; i++)
	{
		int32_t ix = i % numRowsInMat;
		int32_t iy = i / numRowsInMat;

		pOutMat[i] = pInMat[iy + ix * numColumnsInMat];
	}
}

inline void TransposeMatrix2_OMP(float *pOutMat, const float *pInMat, int32_t numColumnsInMat, int32_t numRowsInMat)
{
	int32_t matrixElements = numColumnsInMat * numRowsInMat;

//#pragma omp parallel for num_threads(2)
#pragma omp parallel for
	for (int32_t i = 0; i < matrixElements; i++)
	{
		int32_t ix = i % numRowsInMat;
		int32_t iy = i / numRowsInMat;

		pOutMat[i] = pInMat[iy + ix * numColumnsInMat];
	}
}






inline void Set_MatrixRowVector(float *pInOutMat, int32_t numColumns, const float *pInVector, int32_t rowID)
{
	int32_t iiy = rowID * numColumns;

	for (int32_t ix = 0; ix < numColumns; ix++)
		pInOutMat[iiy + ix] = pInVector[ix];
}

inline void Get_MatrixRowVector(const float *pInMat, int32_t numColumns, float *pOutVector, int32_t rowID)
{
	int32_t iiy = rowID * numColumns;

	for (int32_t ix = 0; ix < numColumns; ix++)
		pOutVector[ix] = pInMat[iiy + ix];
}

inline void Set_MatrixColumnVector(float *pInOutMat, uint32_t numColumns, uint32_t numRows, const float *pInVector, uint32_t columnID)
{
	for (uint32_t iy = 0; iy < numRows; iy++)
		pInOutMat[columnID + iy * numColumns] = pInVector[iy];
}

inline void Get_MatrixColumnVector(const float *pInMat, uint32_t numColumns, uint32_t numRows, float *pOutVector, uint32_t columnID)
{
	for (uint32_t iy = 0; iy < numRows; iy++)
		pOutVector[iy] = pInMat[columnID + iy * numColumns];
}

inline void Normalize_MatrixRowVectors(float *pInOutMat, int32_t numColumns, int32_t numRows)
{
	int32_t i, j, ii, id;

	float lengthSq, invLength;

	for (i = 0; i < numRows; i++)
	{
		ii = i * numColumns;

		lengthSq = 0.0001f;

		for (j = 0; j < numColumns; j++)
		{
			id = j + ii;

			lengthSq += pInOutMat[id] * pInOutMat[id];
		}

		invLength = 1.0f / sqrt(lengthSq);

		for (j = 0; j < numColumns; j++)
		{
			pInOutMat[j + ii] *= invLength;
		}
	}
}

inline void Normalize_MatrixRowVectors(float *pOutMat, const float *pInMat, uint32_t numColumns, uint32_t numRows)
{
	uint32_t i, j, ii, id;

	float lengthSq, invLength;

	for (i = 0; i < numRows; i++)
	{
		ii = i * numColumns;

		lengthSq = 0.0001f;

		for (j = 0; j < numColumns; j++)
		{
			id = j + ii;

			lengthSq += pInMat[id] * pInMat[id];
		}

		invLength = 1.0f / sqrt(lengthSq);

		for (j = 0; j < numColumns; j++)
		{
			id = j + ii;
			pOutMat[id] = pInMat[id] * invLength;
		}
	}
}

inline void Normalize_MatrixColumnVectors(float *pInOutMat, uint32_t numColumns, uint32_t numRows)
{
	uint32_t i, j, id;

	float lengthSq, invLength;

	for (j = 0; j < numColumns; j++)
	{
		lengthSq = 0.0001f;

		for (i = 0; i < numRows; i++)
		{
			id = j + i * numColumns;

			lengthSq += pInOutMat[id] * pInOutMat[id];
		}

		invLength = 1.0f / sqrt(lengthSq);

		for (i = 0; i < numRows; i++)
		{
			pInOutMat[j + i * numColumns] *= invLength;
		}
	}
}

inline void Normalize_MatrixColumnVectors(float *pOutMat, const float *pInMat, uint32_t numColumns, uint32_t numRows)
{
	uint32_t i, j, id;

	float lengthSq, invLength;

	for (j = 0; j < numColumns; j++)
	{
		lengthSq = 0.0001f;

		for (i = 0; i < numRows; i++)
		{
			id = j + i * numColumns;

			lengthSq += pInMat[id] * pInMat[id];
		}

		invLength = 1.0f / sqrt(lengthSq);

		for (i = 0; i < numRows; i++)
		{
			id = j + i * numColumns;
			pOutMat[id] = pInMat[id] * invLength;
		}
	}
}

inline bool Check_MatrixOrthogonality(float *pOutTransposeMat, const float *pInMat, uint32_t numColumns, uint32_t numRows, float *pTempMat)
{
	TransposeMatrix(pOutTransposeMat, pInMat, numColumns, numRows);

	MatrixMultiplication(pTempMat, pInMat, numColumns, numRows, pOutTransposeMat, numRows, numColumns);

	uint32_t i, j, ii, id;

	for (i = 0; i < numRows; i++)
	{
		ii = i * numColumns;

		for (j = 0; j < numColumns; j++)
		{
			id = j + ii;

			if (i == j)
			{
				if (pTempMat[id] < 0.99f || pTempMat[id] > 1.01f)
					return false;
			}
			else
			{
				if (pTempMat[id] < -0.01f || pTempMat[id] > 0.01f)
					return false;
			}
		}
	}

	return true;
}

inline bool Check_MatrixDiagonality(float *pOutTransposeMat, const float *pInMat, uint32_t numColumns, uint32_t numRows, float *pTempMat)
{
	TransposeMatrix(pOutTransposeMat, pInMat, numColumns, numRows);

	MatrixMultiplication(pTempMat, pInMat, numColumns, numRows, pOutTransposeMat, numRows, numColumns);

	uint32_t i, j, ii, id;

	for (i = 0; i < numRows; i++)
	{
		ii = i * numColumns;

		for (j = 0; j < numColumns; j++)
		{
			id = j + ii;

			if (i != j)
			{
				if (pTempMat[id] < -0.01f || pTempMat[id] > 0.01f)
					return false;
			}
		}
	}

	return true;
}

inline float Check_MatrixOrthogonality2(float *pOutTransposeMat, const float *pInMat, uint32_t numColumns, uint32_t numRows, float *pTempMat)
{
	TransposeMatrix(pOutTransposeMat, pInMat, numColumns, numRows);

	MatrixMultiplication(pTempMat, pInMat, numColumns, numRows, pOutTransposeMat, numRows, numColumns);


	uint32_t i, j, ii, id;

	float error = 0.0f;

	for (i = 0; i < numRows; i++)
	{
		ii = i * numColumns;

		for (j = 0; j < numColumns; j++)
		{
			id = j + ii;

			if (i == j)
				error += abs(pTempMat[id] - 1.0f);
			else
				error += abs(pTempMat[id]);
		}
	}

	return error;
}

inline float Check_MatrixDiagonality2(float *pOutTransposeMat, const float *pInMat, uint32_t numColumns, uint32_t numRows, float *pTempMat)
{
	TransposeMatrix(pOutTransposeMat, pInMat, numColumns, numRows);

	MatrixMultiplication(pTempMat, pInMat, numColumns, numRows, pOutTransposeMat, numRows, numColumns);


	Output_RawImageData(pTempMat, numColumns, numRows);
	getchar();

	uint32_t i, j, ii, id;

	float error = 0.0f;

	for (i = 0; i < numRows; i++)
	{
		ii = i * numColumns;

		for (j = 0; j < numColumns; j++)
		{
			id = j + ii;

			if (i != j)
				error += abs(pTempMat[id]);
		}
	}

	return error;
}




inline void Init_RandomNormalVector(float *pOutVec, CRandomNumbersNN *pRandomNumbers, int32_t numVectorElements)
{
	for (int32_t i = 0; i < numVectorElements; i++)
		pOutVec[i] = pRandomNumbers->Get_FloatNumber(-1.0f, 1.0f);

	Normalize(pOutVec, numVectorElements);
}

inline void Init_RandomVector(float *pOutVec, CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, int32_t numVectorElements)
{
	for (int32_t i = 0; i < numVectorElements; i++)
		pOutVec[i] = pRandomNumbers->Get_FloatNumber(minValue, maxValue);
}

inline void Init_RandomVector(float *pOutVec, CRandomNumbersNN *pRandomNumbers, int32_t minValue, int32_t maxValue, int32_t numVectorElements)
{
	for (int32_t i = 0; i < numVectorElements; i++)
	{
		pOutVec[i] = pRandomNumbers->Get_IntegerNumber2(minValue, maxValue);

		if (pOutVec[i] == 0.0f)
		{
			pOutVec[i] = 1.0f;

			if (pRandomNumbers->Get_IntegerNumber2(1, 2) == 1)
				pOutVec[i] = -1.0f;
		}
	}
}

inline void Find_RandomOrthogonalVector(float *pOutVec, float *pInVec, CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, int32_t numVectorElements)
{
	for (int32_t i = 1; i < numVectorElements; i++)
		pOutVec[i] = pRandomNumbers->Get_FloatNumber(minValue, maxValue);


	pOutVec[0] = 0.0f;

	for (int32_t i = 1; i < numVectorElements; i++)
		pOutVec[0] -= pOutVec[i] * pInVec[i];

	float tempfloat = pInVec[0];

	if (tempfloat == 0.0f)
		tempfloat = 0.0001f;

	pOutVec[0] *= 1.0f / tempfloat;
}



inline void Find_RandomOrthonormalVector(float *pOutVec, float *pInVec, CRandomNumbersNN *pRandomNumbers, int32_t numVectorElements)
{
	for (int32_t i = 1; i < numVectorElements; i++)
		pOutVec[i] = pRandomNumbers->Get_FloatNumber(-1.0f, 1.0f);


	pOutVec[0] = 0.0f;

	for (int32_t i = 1; i < numVectorElements; i++)
		pOutVec[0] -= pOutVec[i] * pInVec[i];

	float tempfloat = pInVec[0];

	if (tempfloat == 0.0f)
		tempfloat = 0.0001f;

	pOutVec[0] *= 1.0f / tempfloat;

	Normalize(pOutVec, numVectorElements);
}

inline void Find_RandomOrthonormalVector(float *pOutVec, float *pInVec1, float *pInVec2, float *pInTempVec, CRandomNumbersNN *pRandomNumbers, int32_t numVectorElements, int32_t numIterations)
{
	Find_RandomOrthonormalVector(pOutVec, pInVec2, pRandomNumbers, numVectorElements);

	float dotProductMin = abs(DotProduct(pOutVec, pInVec1, numVectorElements));
	float dotProduct;

	for (int32_t i = 0; i < numIterations; i++)
	{
		Find_RandomOrthonormalVector(pInTempVec, pInVec2, pRandomNumbers, numVectorElements);

		dotProduct = abs(DotProduct(pInTempVec, pInVec1, numVectorElements));

		if (dotProduct < dotProductMin)
		{
			dotProductMin = dotProduct;

			Copy_1DimArray(pOutVec, pInTempVec, numVectorElements);

			if (dotProductMin < 0.01f)
				return;
		}
	}
}



inline void Find_RandomOrthonormalVector(float *pOutVec, float *pInVec1, float *pInVec2, float *pInVec3, float *pInTempVec, CRandomNumbersNN *pRandomNumbers, int32_t numVectorElements, int32_t numIterations)
{
	Find_RandomOrthonormalVector(pOutVec, pInVec3, pRandomNumbers, numVectorElements);

	float sumOfDotProductsMin = abs(DotProduct(pOutVec, pInVec1, numVectorElements)) + abs(DotProduct(pOutVec, pInVec2, numVectorElements));

	float sumOfDotProducts;

	for (int32_t i = 0; i < numIterations; i++)
	{
		Find_RandomOrthonormalVector(pInTempVec, pInVec3, pRandomNumbers, numVectorElements);

		sumOfDotProducts = abs(DotProduct(pInTempVec, pInVec1, numVectorElements)) + abs(DotProduct(pInTempVec, pInVec2, numVectorElements));


		if (sumOfDotProducts < sumOfDotProductsMin)
		{
			sumOfDotProductsMin = sumOfDotProducts;

			Copy_1DimArray(pOutVec, pInTempVec, numVectorElements);

			if (sumOfDotProductsMin < 0.01f)
				return;
		}
	}
}





inline void Approximate_OrthonormalMatrix(float *pInOutMat, uint32_t numColumns, uint32_t numRows, CRandomNumbersNN *pRandomNumbers, uint32_t *pNumIterationsArray, float *pTempVec1, float *pTempVec2, float *pTempVec3)
{
	Init_RandomNormalVector(pTempVec1, pRandomNumbers, numColumns);

	Set_MatrixRowVector(pInOutMat, numColumns, pTempVec1, 0);

	Find_RandomOrthonormalVector(pTempVec2, pTempVec1, pRandomNumbers, numColumns);

	Set_MatrixRowVector(pInOutMat, numColumns, pTempVec2, 1);

	float sumOfDotProductsMin, sumOfDotProducts;


	for (uint32_t i = 2; i < numRows; i++)
	{
		Get_MatrixRowVector(pInOutMat, numColumns, pTempVec1, i - 1);
		Find_RandomOrthonormalVector(pTempVec3, pTempVec1, pRandomNumbers, numColumns);

		sumOfDotProductsMin = 0.0f;

		for (uint32_t j = 0; j < i; j++)
		{
			Get_MatrixRowVector(pInOutMat, numColumns, pTempVec1, j);
			sumOfDotProductsMin += abs(DotProduct(pTempVec3, pTempVec1, numColumns));
		}



		for (uint32_t ii = 0; ii < pNumIterationsArray[i]; ii++)
		{
			Find_RandomOrthonormalVector(pTempVec2, pTempVec1, pRandomNumbers, numColumns);

			sumOfDotProducts = 0.0f;

			for (uint32_t j = 0; j < i; j++)
			{
				Get_MatrixRowVector(pInOutMat, numColumns, pTempVec1, j);

				sumOfDotProducts += abs(DotProduct(pTempVec2, pTempVec1, numColumns));
			}

			if (sumOfDotProducts < sumOfDotProductsMin)
			{
				Copy_1DimArray(pTempVec3, pTempVec2, numColumns);

				sumOfDotProductsMin = sumOfDotProducts;

				if (sumOfDotProductsMin < 0.01f)
					break;
			}
		}

		Set_MatrixRowVector(pInOutMat, numColumns, pTempVec3, i);

	}
}





inline void Init_RandomFilter(float *pOutputKernel, /*numArrayElements:*/ uint32_t kernelSize, CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue)
{
	for (uint32_t i = 0; i < kernelSize; i++)
		pOutputKernel[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minValue, maxValue);
}

inline void Init_RandomFilter(float *pOutputKernel, /*numArrayElements:*/ uint32_t kernelSize, CRandomNumbersNN *pRandomNumbers, int32_t minValue, int32_t maxValue)
{
	for (uint32_t i = 0; i < kernelSize; i++)
	{
		pOutputKernel[i] = pRandomNumbers->Get_IntegerNumber2(minValue, maxValue);

		if (pOutputKernel[i] == 0.0f)
		{
			pOutputKernel[i] = 1.0f;

			if (pRandomNumbers->Get_IntegerNumber2(1, 2) == 1)
				pOutputKernel[i] = -1.0f;
		}
	}
}

inline void Init_RandomFilter(float *pOutputKernel, float *pReceptiveFieldDensityValues, /*numArrayElements:*/ uint32_t kernelSize, CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue)
{
	for (uint32_t i = 0; i < kernelSize; i++)
		pOutputKernel[i] = pReceptiveFieldDensityValues[i] * pRandomNumbers->Get_FloatNumber_IncludingZero(minValue, maxValue);
}


inline void Init_RandomFilter(float *pOutputKernel, uint32_t kernelSizeX, uint32_t kernelSizeY, CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue)
{
	uint32_t numArrayElements = kernelSizeX * kernelSizeY;

	for (uint32_t i = 0; i < numArrayElements; i++)
		pOutputKernel[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minValue, maxValue);
}

inline void Init_RandomFilter(float *pOutputKernel, uint32_t kernelSizeX, uint32_t kernelSizeY, CRandomNumbersNN *pRandomNumbers, int32_t minValue, int32_t maxValue)
{
	uint32_t numArrayElements = kernelSizeX * kernelSizeY;

	for (uint32_t i = 0; i < numArrayElements; i++)
	{
		pOutputKernel[i] = pRandomNumbers->Get_IntegerNumber2(minValue, maxValue);

		if (pOutputKernel[i] == 0.0f)
		{
			pOutputKernel[i] = 1.0f;

			if (pRandomNumbers->Get_IntegerNumber2(1, 2) == 1)
				pOutputKernel[i] = -1.0f;
		}
	}
}

inline void Init_RandomFilter(float *pOutputKernel, float *pReceptiveFieldDensityValues, uint32_t kernelSizeX, uint32_t kernelSizeY, CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue)
{
	uint32_t numArrayElements = kernelSizeX * kernelSizeY;

	for (uint32_t i = 0; i < numArrayElements; i++)
		pOutputKernel[i] = pReceptiveFieldDensityValues[i] * pRandomNumbers->Get_FloatNumber_IncludingZero(minValue, maxValue);
}

inline void Init_RandomFilter2(float *pOutputKernelWithBias, /*numArrayElements:*/ uint32_t kernelSizeWithoutBias, CRandomNumbersNN *pRandomNumbers, float minFilterValue, float maxFilterValue, float minBiasValue, float maxBiasValue)
{
	for (uint32_t i = 0; i < kernelSizeWithoutBias; i++)
		pOutputKernelWithBias[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minFilterValue, maxFilterValue);

	pOutputKernelWithBias[kernelSizeWithoutBias] = pRandomNumbers->Get_FloatNumber_IncludingZero(minBiasValue, maxBiasValue);
}

inline void Init_RandomFilter2(float *pOutputKernelWithBias, /*numArrayElements:*/ uint32_t kernelSizeWithoutBias, CRandomNumbersNN *pRandomNumbers, int32_t minFilterValue, int32_t maxFilterValue, float minBiasValue, float maxBiasValue)
{
	for (uint32_t i = 0; i < kernelSizeWithoutBias; i++)
	{
		pOutputKernelWithBias[i] = pRandomNumbers->Get_IntegerNumber2(minFilterValue, maxFilterValue);

		if (pOutputKernelWithBias[i] == 0.0f)
		{
			pOutputKernelWithBias[i] = 1.0f;

			if (pRandomNumbers->Get_IntegerNumber2(1, 2) == 1)
				pOutputKernelWithBias[i] = -1.0f;
		}
	}

	pOutputKernelWithBias[kernelSizeWithoutBias] = pRandomNumbers->Get_FloatNumber_IncludingZero(minBiasValue, maxBiasValue);
}

inline void Init_RandomFilter2(float *pOutputKernelWithBias, float *pReceptiveFieldDensityValues, /*numArrayElements:*/ uint32_t kernelSizeWithoutBias, CRandomNumbersNN *pRandomNumbers, float minFilterValue, float maxFilterValue, float minBiasValue, float maxBiasValue)
{
	for (uint32_t i = 0; i < kernelSizeWithoutBias; i++)
		pOutputKernelWithBias[i] = pReceptiveFieldDensityValues[i] * pRandomNumbers->Get_FloatNumber_IncludingZero(minFilterValue, maxFilterValue);

	pOutputKernelWithBias[kernelSizeWithoutBias] = pReceptiveFieldDensityValues[kernelSizeWithoutBias] * pRandomNumbers->Get_FloatNumber_IncludingZero(minBiasValue, maxBiasValue);
}

inline void Init_RandomFilter2(float *pOutputKernelWithBias, uint32_t kernelSizeWithoutBiasX, uint32_t kernelSizeWithoutBiasY, CRandomNumbersNN *pRandomNumbers, float minFilterValue, float maxFilterValue, float minBiasValue, float maxBiasValue)
{
	uint32_t numArrayElements = kernelSizeWithoutBiasX * kernelSizeWithoutBiasY;

	for (uint32_t i = 0; i < numArrayElements; i++)
		pOutputKernelWithBias[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minFilterValue, maxFilterValue);

	pOutputKernelWithBias[numArrayElements] = pRandomNumbers->Get_FloatNumber_IncludingZero(minBiasValue, maxBiasValue);
}

inline void Init_RandomFilter2(float *pOutputKernelWithBias, uint32_t kernelSizeWithoutBiasX, uint32_t kernelSizeWithoutBiasY, CRandomNumbersNN *pRandomNumbers, int32_t minFilterValue, int32_t maxFilterValue, float minBiasValue, float maxBiasValue)
{
	uint32_t numArrayElements = kernelSizeWithoutBiasX * kernelSizeWithoutBiasY;

	for (uint32_t i = 0; i < numArrayElements; i++)
	{
		pOutputKernelWithBias[i] = pRandomNumbers->Get_IntegerNumber2(minFilterValue, maxFilterValue);

		if (pOutputKernelWithBias[i] == 0.0f)
		{
			pOutputKernelWithBias[i] = 1.0f;

			if (pRandomNumbers->Get_IntegerNumber2(1, 2) == 1)
				pOutputKernelWithBias[i] = -1.0f;
		}
	}

	pOutputKernelWithBias[numArrayElements] = pRandomNumbers->Get_FloatNumber_IncludingZero(minBiasValue, maxBiasValue);
}

inline void Init_RandomFilter2(float *pOutputKernelWithBias, float *pReceptiveFieldDensityValues, uint32_t kernelSizeWithoutBiasX, uint32_t kernelSizeWithoutBiasY, CRandomNumbersNN *pRandomNumbers, float minFilterValue, float maxFilterValue, float minBiasValue, float maxBiasValue)
{
	uint32_t numArrayElements = kernelSizeWithoutBiasX * kernelSizeWithoutBiasY;

	for (uint32_t i = 0; i < numArrayElements; i++)
		pOutputKernelWithBias[i] = pReceptiveFieldDensityValues[i] * pRandomNumbers->Get_FloatNumber_IncludingZero(minFilterValue, maxFilterValue);

	pOutputKernelWithBias[numArrayElements] = pReceptiveFieldDensityValues[numArrayElements] * pRandomNumbers->Get_FloatNumber_IncludingZero(minBiasValue, maxBiasValue);
}

inline void Calculate_RandomModifications(float *pOutVector, const float *pInVector, int32_t numVectorElements, CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue)
{
	for (int32_t i = 0; i < numVectorElements; i++)
	{
		pOutVector[i] = pInVector[i];
		pOutVector[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minValue, maxValue);
	}
}

inline void Calculate_RandomModifications(float *pOutVector, const float *pInVector, int32_t minVectorElement, int32_t maxVectorElement, CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue)
{
	maxVectorElement++;

	for (int32_t i = minVectorElement; i < maxVectorElement; i++)
	{
		pOutVector[i] = pInVector[i];
		pOutVector[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minValue, maxValue);
	}
}

inline void Calculate_RandomModifications(float *pInOutVector, int32_t numVectorElements, CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue)
{
	for (int32_t i = 0; i < numVectorElements; i++)
	{
		pInOutVector[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minValue, maxValue);
	}
}

inline void Calculate_RandomModifications(float *pInOutVector, int32_t minVectorElement, int32_t maxVectorElement, CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue)
{
	maxVectorElement++;

	for (int32_t i = minVectorElement; i < maxVectorElement; i++)
	{
		pInOutVector[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minValue, maxValue);
	}
}


inline float Calculate_VarianceSum(const float *pVector1, const float *pVector2, int32_t numVectorElements)
{
	float diff;

	float sum = 0.0f;

	for(int32_t i = 0; i < numVectorElements; i++)
	{
		diff = pVector1[i] - pVector2[i];
		diff *= diff;
		sum += diff;
	}

	return sum;
}

inline float Calculate_VarianceSum(const float *pVector1, const float *pVector2, int32_t minVectorElement, int32_t maxVectorElement)
{
	maxVectorElement++;

	float diff;

	float sum = 0.0f;

	for (int32_t i = minVectorElement; i < maxVectorElement; i++)
	{
		diff = pVector1[i] - pVector2[i];
		diff *= diff;
		sum += diff;
	}

	return sum;
}

inline float Calculate_MaxVariance(const float *pVector1, const float *pVector2, int32_t numVectorElements)
{
	float diff;

	float maxVariance = 0.0f;

	for (int32_t i = 0; i < numVectorElements; i++)
	{
		diff = pVector1[i] - pVector2[i];
		diff *= diff;

		if (diff > maxVariance)
			maxVariance = diff;
	}

	return maxVariance;
}

inline float Calculate_MaxVariance(const float *pVector1, const float *pVector2, int32_t minVectorElement, int32_t maxVectorElement)
{
	maxVectorElement++;

	float diff;

	float maxVariance = 0.0f;

	for (int32_t i = minVectorElement; i < maxVectorElement; i++)
	{
		diff = pVector1[i] - pVector2[i];
		diff *= diff;

		if (diff > maxVariance)
			maxVariance = diff;
	}

	return maxVariance;
}


inline float Calculate_MinVariance(const float *pVector1, const float *pVector2, int32_t numVectorElements)
{
	float diff;

	float minVariance = 10000000.0f;

	for (int32_t i = 0; i < numVectorElements; i++)
	{
		diff = pVector1[i] - pVector2[i];
		diff *= diff;

		if (diff < minVariance)
			minVariance = diff;
	}

	return minVariance;
}

inline float Calculate_MinVariance(const float *pVector1, const float *pVector2, int32_t minVectorElement, int32_t maxVectorElement)
{
	maxVectorElement++;

	float diff;

	float minVariance = 10000000.0f;

	for (int32_t i = minVectorElement; i < maxVectorElement; i++)
	{
		diff = pVector1[i] - pVector2[i];
		diff *= diff;

		if (diff < minVariance)
			minVariance = diff;
	}

	return minVariance;
}



inline float Calculate_VarianceSum(const float *pVector1, const float *pVector2, int32_t numVectorElements, float minVariance)
{
	float diff;

	float sum = 0.0f;

	for (int32_t i = 0; i < numVectorElements; i++)
	{
		diff = pVector1[i] - pVector2[i];
		diff *= diff;

		if(diff > minVariance)
			sum += diff;
	}

	return sum;
}

inline float Calculate_VarianceSum(const float *pVector1, const float *pVector2, int32_t minVectorElement, int32_t maxVectorElement, float minVariance)
{
	maxVectorElement++;

	float diff;

	float sum = 0.0f;

	for (int32_t i = minVectorElement; i < maxVectorElement; i++)
	{
		diff = pVector1[i] - pVector2[i];
		diff *= diff;

		if (diff > minVariance)
			sum += diff;
	}

	return sum;
}


inline int32_t Find_BestMatchedVectorFromList(float **ppBestVectorFromList, float *pTestVector, int32_t numVectorElements, float **ppVectorList, int32_t numOfVectors)
{
	float *pVector = ppVectorList[0];

	float minVarianceSum = Calculate_VarianceSum(pTestVector, ppVectorList[0], numVectorElements);
	int32_t id = 0;
	float varianceSum;

	for (int32_t i = 1; i < numOfVectors; i++)
	{
		varianceSum = Calculate_VarianceSum(pTestVector, ppVectorList[i], numVectorElements);

		if (varianceSum < minVarianceSum)
		{
			minVarianceSum = varianceSum;
			pVector = ppVectorList[i];
			id = i;
		}
	}

	*ppBestVectorFromList = pVector;
	return id;
}

inline int32_t Find_BestMatchedVectorFromList(float **ppBestVectorFromList, float *pTestVector, int32_t minVectorElement, int32_t maxVectorElement, float **ppVectorList, int32_t numOfVectors)
{
	float *pVector = ppVectorList[0];

	float minVarianceSum = Calculate_VarianceSum(pTestVector, ppVectorList[0], minVectorElement, maxVectorElement);
	int32_t id = 0;
	float varianceSum;

	for (int32_t i = 1; i < numOfVectors; i++)
	{
		varianceSum = Calculate_VarianceSum(pTestVector, ppVectorList[i], minVectorElement, maxVectorElement);

		if (varianceSum < minVarianceSum)
		{
			minVarianceSum = varianceSum;
			pVector = ppVectorList[i];
			id = i;
		}
	}

	*ppBestVectorFromList = pVector;
	return id;
}


inline int32_t Find_BestMatchedVectorFromList(float *pTestVector, int32_t numVectorElements, float **ppVectorList, int32_t numOfVectors)
{
	float minVarianceSum = Calculate_VarianceSum(pTestVector, ppVectorList[0], numVectorElements);
	int32_t id = 0;
	float varianceSum;

	for (int32_t i = 1; i < numOfVectors; i++)
	{
		varianceSum = Calculate_VarianceSum(pTestVector, ppVectorList[i], numVectorElements);

		if (varianceSum < minVarianceSum)
		{
			minVarianceSum = varianceSum;
			id = i;
		}
	}

	return id;
}

inline int32_t Find_BestMatchedVectorFromList(float *pTestVector, int32_t minVectorElement, int32_t maxVectorElement, float **ppVectorList, int32_t numOfVectors)
{
	float minVarianceSum = Calculate_VarianceSum(pTestVector, ppVectorList[0], minVectorElement, maxVectorElement);
	int32_t id = 0;
	float varianceSum;

	for (int32_t i = 1; i < numOfVectors; i++)
	{
		varianceSum = Calculate_VarianceSum(pTestVector, ppVectorList[i], minVectorElement, maxVectorElement);

		if (varianceSum < minVarianceSum)
		{
			minVarianceSum = varianceSum;
			id = i;
		}
	}

	return id;
}



class CCombinedData
{
public:

	int32_t NumOfTrainingExamples = 0;

	void Reset_Data(/*combined data:*/float *pInOutDataArray, int32_t minDataElement, int32_t numDataElements)
	{
		NumOfTrainingExamples = 0;

		for (int32_t i = minDataElement; i < numDataElements; i++)
			pInOutDataArray[i] = 0.0f;

	}

	void Add_Data(/*combined data:*/ float *pInOutDataArray, /*added data:*/ float *pNewDataArray, int32_t minDataElement, int32_t numDataElements)
	{
		float weight1 = 1.0f / (static_cast<float>(NumOfTrainingExamples) + 1.0f);
		float weight2 = 1.0f - weight1;

		for (int32_t i = minDataElement; i < numDataElements; i++)
		{
			pInOutDataArray[i] = weight1 * pNewDataArray[i] + weight2 * pInOutDataArray[i];
		}

		NumOfTrainingExamples++;
	}

	void ModifyData(/*combined data:*/ float *pInOutDataArray, float searchValue, float replacementValue, int32_t minDataElement, int32_t numDataElements)
	{
		for (int32_t i = minDataElement; i < numDataElements; i++)
		{
			if (pInOutDataArray[i] == searchValue)
				pInOutDataArray[i] = replacementValue;
		}
	}
};

inline void Binarize_Pixels(float *pOutputArray, const float *pInputArray, int32_t inputArraySizeX, int32_t inputArraySizeY, float threshold)
{
	int32_t sizeXY = inputArraySizeX * inputArraySizeY;

	for (int32_t i = 0; i < sizeXY; i++)
	{
		if (pInputArray[i] > threshold)
			pOutputArray[i] = 1.0f;
		else
			pOutputArray[i] = 0.0f;
	}
}

inline void Square_Pixels(float *pOutputArray, const float *pInputArray, int32_t inputArraySizeX, int32_t inputArraySizeY)
{
	int32_t sizeXY = inputArraySizeX * inputArraySizeY;

	for (int32_t i = 0; i < sizeXY; i++)
	{
		float tempFloat = pInputArray[i];
		pOutputArray[i] = tempFloat * tempFloat;
	}
}

inline void Binarize_Pixels(float *pOutputArray, const float *pInputArray, int32_t inputArraySizeXY, float threshold)
{
	for (int32_t i = 0; i < inputArraySizeXY; i++)
	{
		if (pInputArray[i] > threshold)
			pOutputArray[i] = 1.0f;
		else
			pOutputArray[i] = 0.0f;
	}
}

inline void Square_Pixels(float *pOutputArray, const float *pInputArray, int32_t inputArraySizeXY)
{
	for (int32_t i = 0; i < inputArraySizeXY; i++)
	{
		float tempFloat = pInputArray[i];
		
	}
}

inline void Binarize_Pixels(float *pInputOutputArray, int32_t inputArraySizeX, int32_t inputArraySizeY, float threshold)
{
	int32_t sizeXY = inputArraySizeX * inputArraySizeY;

	for (int32_t i = 0; i < sizeXY; i++)
	{
		if (pInputOutputArray[i] > threshold)
			pInputOutputArray[i] = 1.0f;
		else
			pInputOutputArray[i] = 0.0f;
	}
}

inline void Square_Pixels(float *pInputOutputArray, int32_t inputArraySizeX, int32_t inputArraySizeY)
{
	int32_t sizeXY = inputArraySizeX * inputArraySizeY;

	for (int32_t i = 0; i < sizeXY; i++)
	{
		float tempFloat = pInputOutputArray[i];
		pInputOutputArray[i] = tempFloat * tempFloat;
	}
}

inline void Binarize_Pixels(float *pInputOutputArray, int32_t inputArraySizeXY, float threshold)
{
	for (int32_t i = 0; i < inputArraySizeXY; i++)
	{
		if (pInputOutputArray[i] > threshold)
			pInputOutputArray[i] = 1.0f;
		else
			pInputOutputArray[i] = 0.0f;
	}
}

inline void Square_Pixels(float *pInputOutputArray, int32_t inputArraySizeXY)
{
	for (int32_t i = 0; i < inputArraySizeXY; i++)
	{
		float tempFloat = pInputOutputArray[i];
		pInputOutputArray[i] = tempFloat * tempFloat;
	}
}

inline void Remove_NonEdgePixels(float *pOutputArray, const float *pInputArray, int32_t inputArraySizeX, int32_t inputArraySizeY, float threshold)
{
	int32_t inputArraySizeXMinus1 = inputArraySizeX - 1;
	int32_t inputArraySizeYMinus1 = inputArraySizeY - 1;

	for (int32_t iyInput = 1; iyInput < inputArraySizeYMinus1; iyInput++)
	{
		int32_t iiyInput = iyInput * inputArraySizeX;

		for (int32_t ixInput = 1; ixInput < inputArraySizeXMinus1; ixInput++)
		{
			int32_t iyMin = iyInput - 1;
			int32_t iyMaxPlus1 = iyMin + 3;

			int32_t ixMin = ixInput - 1;
			int32_t ixMaxPlus1 = ixMin + 3;

			int32_t sum = 0;

			for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
			{
				int32_t iiy = iy * inputArraySizeX;

				for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
				{
					if (ix == ixInput && iy == iyInput)
						continue;

					if (pInputArray[ix + iiy] > threshold)
						sum++;
					
					
				}
			}

			int32_t id = ixInput + iiyInput;

			if(sum == 8)
				pOutputArray[id] = 0;
			else
				pOutputArray[id] = pInputArray[id];
		}
	}
}
inline void Convolution3x3(float *pOutputArray, const float *pInputArray, int32_t inputArraySizeX, int32_t inputArraySizeY, float *pConvMatrix)
{
	int32_t inputArraySizeXMinus1 = inputArraySizeX - 1;
	int32_t inputArraySizeYMinus1 = inputArraySizeY - 1;

	for (int32_t iyInput = 1; iyInput < inputArraySizeYMinus1; iyInput++)
	{
		int32_t iiyInput = iyInput * inputArraySizeX;

		for (int32_t ixInput = 1; ixInput < inputArraySizeXMinus1; ixInput++)
		{
			int32_t iyMin = iyInput - 1;
			int32_t iyMaxPlus1 = iyMin + 3;

			int32_t ixMin = ixInput - 1;
			int32_t ixMaxPlus1 = ixMin + 3;

			int32_t counter = 0;
			float sum = 0.0f;

			for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
			{
				int32_t iiy = iy * inputArraySizeX;

				for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
				{
					sum += pConvMatrix[counter] * pInputArray[ix + iiy];
					counter++;
				}
			}

			pOutputArray[ixInput + iiyInput] = sum;
		}
	}
}

inline void Add_Convolution3x3(float *pOutputArray, const float *pInputArray, int32_t inputArraySizeX, int32_t inputArraySizeY, float *pConvMatrix)
{
	int32_t inputArraySizeXMinus1 = inputArraySizeX - 1;
	int32_t inputArraySizeYMinus1 = inputArraySizeY - 1;

	for (int32_t iyInput = 1; iyInput < inputArraySizeYMinus1; iyInput++)
	{
		int32_t iiyInput = iyInput * inputArraySizeX;

		for (int32_t ixInput = 1; ixInput < inputArraySizeXMinus1; ixInput++)
		{
			int32_t iyMin = iyInput - 1;
			int32_t iyMaxPlus1 = iyMin + 3;

			int32_t ixMin = ixInput - 1;
			int32_t ixMaxPlus1 = ixMin + 3;

			int32_t counter = 0;
			float sum = 0.0f;

			for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
			{
				int32_t iiy = iy * inputArraySizeX;

				for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
				{
					sum += pConvMatrix[counter] * pInputArray[ix + iiy];
					counter++;
				}
			}

			pOutputArray[ixInput + iiyInput] += sum;
		}
	}
}

inline void Convolution5x5(float *pOutputArray, const float *pInputArray, int32_t inputArraySizeX, int32_t inputArraySizeY, float *pConvMatrix)
{
	int32_t inputArraySizeXMinus2 = inputArraySizeX - 2;
	int32_t inputArraySizeYMinus2 = inputArraySizeY - 2;

	for (int32_t iyInput = 2; iyInput < inputArraySizeYMinus2; iyInput++)
	{
		int32_t iiyInput = iyInput * inputArraySizeX;

		for (int32_t ixInput = 2; ixInput < inputArraySizeXMinus2; ixInput++)
		{
			int32_t iyMin = iyInput - 2;
			int32_t iyMaxPlus1 = iyMin + 5;

			int32_t ixMin = ixInput - 2;
			int32_t ixMaxPlus1 = ixMin + 5;

			int32_t counter = 0;
			float sum = 0.0f;

			for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
			{
				int32_t iiy = iy * inputArraySizeX;

				for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
				{
					sum += pConvMatrix[counter] * pInputArray[ix + iiy];
					counter++;
				}
			}

			pOutputArray[ixInput + iiyInput] = sum;
		}
	}
}

inline void Add_Convolution5x5(float *pOutputArray, const float *pInputArray, int32_t inputArraySizeX, int32_t inputArraySizeY, float *pConvMatrix)
{
	int32_t inputArraySizeXMinus2 = inputArraySizeX - 2;
	int32_t inputArraySizeYMinus2 = inputArraySizeY - 2;

	for (int32_t iyInput = 2; iyInput < inputArraySizeYMinus2; iyInput++)
	{
		int32_t iiyInput = iyInput * inputArraySizeX;

		for (int32_t ixInput = 2; ixInput < inputArraySizeXMinus2; ixInput++)
		{
			int32_t iyMin = iyInput - 2;
			int32_t iyMaxPlus1 = iyMin + 5;

			int32_t ixMin = ixInput - 2;
			int32_t ixMaxPlus1 = ixMin + 5;

			int32_t counter = 0;
			float sum = 0.0f;

			for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
			{
				int32_t iiy = iy * inputArraySizeX;

				for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
				{
					sum += pConvMatrix[counter] * pInputArray[ix + iiy];
					counter++;
				}
			}

			pOutputArray[ixInput + iiyInput] += sum;
		}
	}
}

inline void CopyData_Into_RedChannel(uint8_t *pOutImage, float *pInputArray, int32_t inputArraySizeX, int32_t inputArraySizeY)
{
	for (int32_t iy = 0; iy < inputArraySizeY; iy++)
	{
		int32_t iiyFlipped = (inputArraySizeY - 1 - iy) * inputArraySizeX;

		int32_t iiy = iy * 3 * inputArraySizeX;

		for (int32_t ix = 0; ix < inputArraySizeX; ix++)
		{
			int32_t iix = ix * 3;

			pOutImage[2 + iix + iiy] = static_cast<uint8_t>(255.0f * pInputArray[ix + iiyFlipped]); // red
			pOutImage[1 + iix + iiy] = 0.0f; // green
			pOutImage[    iix + iiy] = 0.0f; // blue			
		}
	}
}

inline void CopyData_Into_GreenChannel(uint8_t *pOutImage, float *pInputArray, int32_t inputArraySizeX, int32_t inputArraySizeY)
{
	for (int32_t iy = 0; iy < inputArraySizeY; iy++)
	{
		int32_t iiyFlipped = (inputArraySizeY - 1 - iy) * inputArraySizeX;

		int32_t iiy = iy * 3 * inputArraySizeX;

		for (int32_t ix = 0; ix < inputArraySizeX; ix++)
		{
			int32_t iix = ix * 3;

			pOutImage[2 + iix + iiy] = 0.0f; // red
			pOutImage[1 + iix + iiy] = static_cast<uint8_t>(255.0f * pInputArray[ix + iiyFlipped]); // green
			pOutImage[    iix + iiy] = 0.0f; // blue			
		}
	}
}

inline void CopyData_Into_BlueChannel(uint8_t *pOutImage, float *pInputArray, int32_t inputArraySizeX, int32_t inputArraySizeY)
{
	for (int32_t iy = 0; iy < inputArraySizeY; iy++)
	{
		int32_t iiyFlipped = (inputArraySizeY - 1 - iy) * inputArraySizeX;

		int32_t iiy = iy * 3 * inputArraySizeX;

		for (int32_t ix = 0; ix < inputArraySizeX; ix++)
		{
			int32_t iix = ix * 3;

			pOutImage[2 + iix + iiy] = 0.0f; // red
			pOutImage[1 + iix + iiy] = 0.0f; // green
			pOutImage[    iix + iiy] = static_cast<uint8_t>(255.0f * pInputArray[ix + iiyFlipped]); // blue			
		}
	}
}

inline void CopyData_Into_RGBChannels(uint8_t *pOutImage, float *pInputArray, int32_t inputArraySizeX, int32_t inputArraySizeY)
{
	for (int32_t iy = 0; iy < inputArraySizeY; iy++)
	{
		int32_t iiyFlipped = (inputArraySizeY - 1 - iy) * inputArraySizeX;

		int32_t iiy = iy * 3 * inputArraySizeX;

		for (int32_t ix = 0; ix < inputArraySizeX; ix++)
		{
			int32_t iix = ix * 3;
			uint8_t value = static_cast<uint8_t>(255.0f * pInputArray[ix + iiyFlipped]);

			pOutImage[2 + iix + iiy] = value; // red
			pOutImage[1 + iix + iiy] = value; // green
			pOutImage[    iix + iiy] = value; // blue			
		}
	}
}

inline void CopyData_Into_RGBChannels(uint8_t *pOutImage, float *pInputArray_Red, float *pInputArray_Green, float *pInputArray_Blue, int32_t inputArraySizeX, int32_t inputArraySizeY)
{
	for (int32_t iy = 0; iy < inputArraySizeY; iy++)
	{
		int32_t iiyFlipped = (inputArraySizeY - 1 - iy) * inputArraySizeX;

		int32_t iiy = iy * 3 * inputArraySizeX;

		for (int32_t ix = 0; ix < inputArraySizeX; ix++)
		{
			int32_t iix = ix * 3;

			pOutImage[2 + iix + iiy] = static_cast<uint8_t>(255.0f * pInputArray_Red[ix + iiyFlipped]); // red
			pOutImage[1 + iix + iiy] = static_cast<uint8_t>(255.0f * pInputArray_Green[ix + iiyFlipped]); // green
			pOutImage[    iix + iiy] = static_cast<uint8_t>(255.0f * pInputArray_Blue[ix + iiyFlipped]); // blue			
		}
	}
}

static constexpr int32_t Const_RGB_BYTES_PER_PIXEL = 3; /// red, green, & blue
static constexpr int32_t Const_FILE_HEADER_SIZE = 14;
static constexpr int32_t Const_INFO_HEADER_SIZE = 40;




inline uint8_t* Create_BitmapFileHeader(int32_t height, int32_t stride)
{
	int32_t fileSize = Const_FILE_HEADER_SIZE + Const_INFO_HEADER_SIZE + (stride * height);

	static uint8_t fileHeader[] =
	{
		0,0,     // signature
		0,0,0,0, // image file size in bytes
		0,0,0,0, // reserved
		0,0,0,0, // start of pixel array
	};

	fileHeader[0] = static_cast<uint8_t>('B');
	fileHeader[1] = static_cast<uint8_t>('M');
	fileHeader[2] = static_cast<uint8_t>(fileSize);
	fileHeader[3] = static_cast<uint8_t>(fileSize >> 8);
	fileHeader[4] = static_cast<uint8_t>(fileSize >> 16);
	fileHeader[5] = static_cast<uint8_t>(fileSize >> 24);
	fileHeader[10] = static_cast<uint8_t>(Const_FILE_HEADER_SIZE + Const_INFO_HEADER_SIZE);

	return fileHeader;
}

inline uint8_t* Create_RGB_BitmapInfoHeader(int32_t width, int32_t height)
{
	static uint8_t infoHeader[] =
	{
		0,0,0,0, // header size
		0,0,0,0, // image width
		0,0,0,0, // image height
		0,0,     // number of color planes
		0,0,     // bits per pixel
		0,0,0,0, // compression
		0,0,0,0, // image size
		0,0,0,0, // horizontal resolution
		0,0,0,0, // vertical resolution
		0,0,0,0, // colors in color table
		0,0,0,0, // important color count
	};

	infoHeader[0] = static_cast<uint8_t>(Const_INFO_HEADER_SIZE);
	infoHeader[4] = static_cast<uint8_t>(width);
	infoHeader[5] = static_cast<uint8_t>(width >> 8);
	infoHeader[6] = static_cast<uint8_t>(width >> 16);
	infoHeader[7] = static_cast<uint8_t>(width >> 24);
	infoHeader[8] = static_cast<uint8_t>(height);
	infoHeader[9] = static_cast<uint8_t>(height >> 8);
	infoHeader[10] = static_cast<uint8_t>(height >> 16);
	infoHeader[11] = static_cast<uint8_t>(height >> 24);
	infoHeader[12] = static_cast<uint8_t>(1);
	infoHeader[14] = static_cast<uint8_t>(Const_RGB_BYTES_PER_PIXEL * 8);

	return infoHeader;
}

inline void Save_RGB_BitmapImage(uint8_t *pImage, int32_t inputArraySizeX, int32_t inputArraySizeY, const char *pFilename)
{
	int32_t widthInBytes = inputArraySizeX *  Const_RGB_BYTES_PER_PIXEL;

	uint8_t padding[3] = { 0, 0, 0 };
	int32_t paddingSize = (4 - (widthInBytes) % 4) % 4;

	int32_t stride = (widthInBytes)+paddingSize;

	FILE* imageFile = fopen(pFilename, "wb");

	uint8_t* fileHeader = Create_BitmapFileHeader(inputArraySizeY, stride);
	fwrite(fileHeader, 1, Const_FILE_HEADER_SIZE, imageFile);

	uint8_t* infoHeader = Create_RGB_BitmapInfoHeader(inputArraySizeX, inputArraySizeY);
	fwrite(infoHeader, 1, Const_INFO_HEADER_SIZE, imageFile);

	for (int32_t iy = 0; iy < inputArraySizeY; iy++)
	{
		fwrite(pImage + (iy * widthInBytes), Const_RGB_BYTES_PER_PIXEL, inputArraySizeX, imageFile);
		fwrite(padding, 1, paddingSize, imageFile);
	}

	fclose(imageFile);
}


inline uint8_t* Init_RGB_ImageArray(int32_t sizeX, int32_t sizeY)
{
	uint8_t* pImage = new (std::nothrow) uint8_t[sizeX * sizeY * Const_RGB_BYTES_PER_PIXEL];
	return pImage;
}



inline void Init_RGB_ImageArray(CRGBImageValues *pImage, int32_t sizeX, int32_t sizeY)
{
	pImage->Reset();
	pImage->pImageValues = new (std::nothrow) uint8_t[sizeX * sizeY * Const_RGB_BYTES_PER_PIXEL];
}



#endif