#include <iostream>
#include "NeuralNet_V2.h"

using namespace std;


inline void PrecedingNeuronDendriticFunctionBase(CNeuronV2 *pNeuron)
{
	pNeuron->Dendrite_InputCounter = 0;
}

inline void PrecedingNeuronDendriticFunction1(CNeuronV2 *pNeuron)
{
	pNeuron->Dendrite_InputCounter = 0;

	int32_t numDendrites = pNeuron->Num_Of_Dendrite_Elements;

	float *pInputArray = pNeuron->pDendrite_InputValueArray;

	for (int32_t i = 0; i < numDendrites; i++)
		pInputArray[i] = 2.0f * pInputArray[i] - 1.0f;
}


inline void ActivationFunction1(CNeuronV2 *pNeuron)
{
	float output = 0.0f;

	int32_t numDendrites = pNeuron->Num_Of_Dendrite_Elements;

	for (int32_t i = 0; i < numDendrites; i++)
	{
		output += pNeuron->pDendrite_FactorArray[i] * pNeuron->pDendrite_InputValueArray_OtherNeuron[i];
	}

	output *= 10.0f;
	pNeuron->NeuronOutput = output / (1.0f + abs(output));

	//pNeuron->NeuronInput = 0.0f;
}

inline void ActivationFunction2(CNeuronV2 *pNeuron)
{
	float output = 0.0f;

	int32_t numDendrites = pNeuron->Num_Of_Dendrite_Elements;

	for (int32_t i = 0; i < numDendrites; i++)
	{
		output += pNeuron->pDendrite_FactorArray[i] * pNeuron->pDendrite_InputValueArray_OtherNeuron[i];
	}

	output *= 100.0f;
	pNeuron->NeuronOutput = output / (1.0f + abs(output));

	//pNeuron->NeuronInput = 0.0f;
}

inline void ActivationFunction3(CNeuronV2 *pNeuron)
{
	float output = 0.0f;

	int32_t numDendrites = pNeuron->Num_Of_Dendrite_Elements;

	for (int32_t i = 0; i < numDendrites; i++)
	{
		output += pNeuron->pDendrite_FactorArray[i] * pNeuron->pDendrite_InputValueArray_OtherNeuron[i];
	}

	pNeuron->NeuronOutput = max(0.0f, output);
	//pNeuron->NeuronInput = 0.0f;
}

inline float OutputLayerActivationFunction1(float neuronInput)
{
	//return max(0.0f, neuronInput);
	return neuronInput;
}

inline float OutputLayerActivationFunction2(float neuronInput)
{
	neuronInput *= 100.0f;
	return 0.5f + 0.5f * neuronInput / (1.0f + abs(neuronInput));
}

inline float OutputLayerActivationFunction3(float neuronInput)
{
	return neuronInput / (1.0f + abs(neuronInput));
}






/*
int main(void)
{
	static constexpr int32_t ConstNumOfInputArrays = 3;

	CRandomNumbersNN RandomNumbers;

	float InputArray1[6] = { 0.0f, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f };
	float InputArray2[6] = { 0.0f, 1.0f, 1.0f, 0.0f, 1.0f, 0.0f };
	float InputArray3[6] = { 1.0f, 1.0f, 0.0f, 0.0f, 1.0f, 1.0f };

	float *pInputArrayPointer[ConstNumOfInputArrays];

	pInputArrayPointer[0] = InputArray1;
	pInputArrayPointer[1] = InputArray2;
	pInputArrayPointer[2] = InputArray3;

	float OutputArray[6];
	float tempArray[6];

	CNeuronV2 PrecedingNeuron;

	//PrecedingNeuron.Init_Dendrite_Arrays(6);
	PrecedingNeuron.Init_Dendrite_Arrays(12);
	PrecedingNeuron.Set_DendriticFunction(PrecedingNeuronDendriticFunction1);
	
	//static constexpr int32_t ConstNumHiddenNeurons = 4;
	static constexpr int32_t ConstNumHiddenNeurons = 6;

	CNeuronLayerV2 HiddenNeuronArray;
	HiddenNeuronArray.Initialize(ConstNumHiddenNeurons);

	

	for (int32_t i = 0; i < ConstNumHiddenNeurons; i++)
	{
		HiddenNeuronArray.pNeuronArray[i].Init_Dendrite_Arrays(12);
		//HiddenNeuronArray.pNeuronArray[i].Init_Dendrite_Arrays(6);
		HiddenNeuronArray.pNeuronArray[i].Use_OtherNeuron_Dendrite_InputValueArray(PrecedingNeuron.pDendrite_InputValueArray, 0);
		HiddenNeuronArray.pNeuronArray[i].Init_OutputSynapses(6);
		HiddenNeuronArray.pNeuronArray[i].Randomize_OutputSynapsePlasticities(&RandomNumbers, -0.1f, 0.1f);
		HiddenNeuronArray.pNeuronArray[i].Randomize_Dendrite_Factors(&RandomNumbers, -0.1f, 0.1f);
		HiddenNeuronArray.pNeuronArray[i].Set_ActivationFunction(ActivationFunction2);
	}

	
	COutputLayerV2 OutputLayer;
	OutputLayer.Initialize(6);
	OutputLayer.Set_ActivationFunction(OutputLayerActivationFunction1);

	int32_t maxCount = 100000;
	int32_t epoch = 0;
	float errorSum;



	for (int32_t i = 0; i < maxCount; i++)
	{
		epoch++;
		errorSum = 0.0f;

		for (int32_t j = 0; j < ConstNumOfInputArrays; j++)
		{
			PrecedingNeuron.Set_NeuronInput_For_All_Dendrites(0.0f);

			//Calculate_RandomModifications(tempArray, pInputArrayPointer[j], 6, &RandomNumbers, -0.1f, 0.1f);
			//PrecedingNeuron.Set_Dendrite_NeuronInput(tempArray, 6);

			PrecedingNeuron.Set_Dendrite_NeuronInput(pInputArrayPointer[j], 6);

			PrecedingNeuron.Execute_DendriticCalculations();

			OutputLayer.Calculate_Input(&HiddenNeuronArray);
			OutputLayer.Calculate_Output();
			errorSum += OutputLayer.Calculate_ErrorValues(pInputArrayPointer[j], 1.0f, 0.001f);
			OutputLayer.Calculate_PrecedingNeuronErrorValues(&HiddenNeuronArray, 1.0f, 0.001f);
			OutputLayer.Adjust_PrecedingNeuronOutputSynapses_AfterErrorCalculations(&HiddenNeuronArray, 0.01f);

			for (int32_t k = 0; k < ConstNumHiddenNeurons; k++)
				HiddenNeuronArray.pNeuronArray[k].Adjust_Dendrite_Factors_AfterErrorCalculations_ExternalInput(0.001f);
		}

		if (errorSum < 0.00001f)
			break;
	}

	// training completed

	// training statistics:


	cout << "epoch: " << epoch << endl;
	cout << "error: " << errorSum << endl << endl;

	

	cout << endl;

	float TestArray1[6] = { 0.0f, 0.0f, 1.0f, 0.1f, 1.0f, 0.2f };


	cout << "input pattern: ";

	for (int32_t i = 0; i < 6; i++)
		cout << TestArray1[i] << " ";


	cout << endl;

	PrecedingNeuron.Set_NeuronInput_For_All_Dendrites(0.0);
	PrecedingNeuron.Set_Dendrite_NeuronInput(TestArray1, 6);
	PrecedingNeuron.Execute_DendriticCalculations();

	OutputLayer.Calculate_Input(&HiddenNeuronArray);
	OutputLayer.Calculate_Output();
	OutputLayer.Get_NeuronOutputValues(OutputArray);

	cout << "output pattern: ";

	for (int32_t i = 0; i < 6; i++)
		cout << OutputArray[i] << " ";

	cout << endl;

	float *pArray = nullptr;

	Find_BestMatchedVectorFromList(&pArray, OutputArray, 6, pInputArrayPointer, 3);

	

	cout << "learned pattern: ";

	for (int32_t i = 0; i < 6; i++)
		cout << pArray[i] << " ";

	cout << endl << endl;



	float TestArray2[6] = { 0.0f, 0.7f, 1.0f, 0.0f, 1.0f, 0.2f };


	cout << "input pattern: ";

	for (int32_t i = 0; i < 6; i++)
		cout << TestArray2[i] << " ";


	cout << endl;

	PrecedingNeuron.Set_NeuronInput_For_All_Dendrites(0.0);
	PrecedingNeuron.Set_Dendrite_NeuronInput(TestArray2, 6);
	PrecedingNeuron.Execute_DendriticCalculations();

	OutputLayer.Calculate_Input(&HiddenNeuronArray);
	OutputLayer.Calculate_Output();
	OutputLayer.Get_NeuronOutputValues(OutputArray);

	cout << "output pattern: ";

	for (int32_t i = 0; i < 6; i++)
		cout << OutputArray[i] << " ";

	cout << endl;

	

	Find_BestMatchedVectorFromList(&pArray, OutputArray, 6, pInputArrayPointer, 3);

	cout << "learned pattern: ";

	for (int32_t i = 0; i < 6; i++)
		cout << pArray[i] << " ";

	cout << endl << endl;


	float TestArray3[6] = { 1.0f, 1.0f, 0.1f, 0.0f, 1.0f, 0.8f };

	cout << "input pattern: ";

	for (int32_t i = 0; i < 6; i++)
		cout << TestArray3[i] << " ";


	cout << endl;

	PrecedingNeuron.Set_NeuronInput_For_All_Dendrites(0.0);
	PrecedingNeuron.Set_Dendrite_NeuronInput(TestArray3, 6);
	PrecedingNeuron.Execute_DendriticCalculations();

	OutputLayer.Calculate_Input(&HiddenNeuronArray);
	OutputLayer.Calculate_Output();
	OutputLayer.Get_NeuronOutputValues(OutputArray);

	cout << "output pattern: ";

	for (int32_t i = 0; i < 6; i++)
		cout << OutputArray[i] << " ";

	cout << endl;

	

	Find_BestMatchedVectorFromList(&pArray, OutputArray, 6, pInputArrayPointer, 3);

	cout << "learned pattern: ";

	for (int32_t i = 0; i < 6; i++)
		cout << pArray[i] << " ";

	cout << endl << endl;

	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	static float Image_B_1[32 * 32];
	static float Image_B_2[32 * 32];
	static float Image_B_3[32 * 32];
	static float Image_B_4[32 * 32];
	static float Image_B_5[32 * 32];
	static float Image_B_6[32 * 32];

	static float Image_8_1[32 * 32];
	static float Image_8_2[32 * 32];
	static float Image_8_3[32 * 32];
	static float Image_8_4[32 * 32];
	static float Image_8_5[32 * 32];
	static float Image_8_6[32 * 32];

	static constexpr int32_t ConstNumOfImages = 12;

	float *pImagePointer[ConstNumOfImages];

	pImagePointer[0] = Image_B_1;
	pImagePointer[1] = Image_B_2;
	pImagePointer[2] = Image_B_3;
	pImagePointer[3] = Image_B_4;
	pImagePointer[4] = Image_B_5;
	pImagePointer[5] = Image_B_6;

	pImagePointer[6] = Image_8_1;
	pImagePointer[7] = Image_8_2;
	pImagePointer[8] = Image_8_3;
	pImagePointer[9] = Image_8_4;
	pImagePointer[10] = Image_8_5;
	pImagePointer[11] = Image_8_6;

	

	static constexpr int32_t ConstNumOfTrainingImages = 8;

	float *pTrainingImagePointer[ConstNumOfTrainingImages];

	pTrainingImagePointer[0] = Image_B_1;
	pTrainingImagePointer[1] = Image_B_2;
	pTrainingImagePointer[2] = Image_B_3;
	pTrainingImagePointer[3] = Image_B_4;
	
	pTrainingImagePointer[4] = Image_8_1;
	pTrainingImagePointer[5] = Image_8_2;
	pTrainingImagePointer[6] = Image_8_3;
	pTrainingImagePointer[7] = Image_8_4;
	


	uint8_t *pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_4.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_4, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_5.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_5, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_6.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_6, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_4.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_4, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_5.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_5, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_6.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_6, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	static float OutputArray[32 * 32];
	

	CNeuronV2 PrecedingNeuron;

	PrecedingNeuron.Init_Dendrite_Arrays(32 * 32);
	PrecedingNeuron.Set_DendriticFunction(PrecedingNeuronDendriticFunctionBase);

	//static constexpr int32_t ConstNumHiddenNeurons = 32;
	static constexpr int32_t ConstNumHiddenNeurons = 16;

	CNeuronLayerV2 HiddenNeuronArray;
	HiddenNeuronArray.Initialize(ConstNumHiddenNeurons);

	for (int32_t i = 0; i < ConstNumHiddenNeurons; i++)
	{
		HiddenNeuronArray.pNeuronArray[i].Init_Dendrite_Arrays(32 * 32);
		HiddenNeuronArray.pNeuronArray[i].Use_OtherNeuron_Dendrite_InputValueArray(PrecedingNeuron.pDendrite_InputValueArray, 0);
		HiddenNeuronArray.pNeuronArray[i].Init_OutputSynapses(32 * 32);
		HiddenNeuronArray.pNeuronArray[i].Randomize_OutputSynapsePlasticities(&RandomNumbers, -0.1f, 0.1f);
		HiddenNeuronArray.pNeuronArray[i].Randomize_Dendrite_Factors(&RandomNumbers, -0.1f, 0.1f);
		HiddenNeuronArray.pNeuronArray[i].Set_ActivationFunction(ActivationFunction1);
	}


	COutputLayerV2 OutputLayer;
	OutputLayer.Initialize(32 * 32);
	OutputLayer.Set_ActivationFunction(OutputLayerActivationFunction1);

	int32_t maxCount = 4000;
	int32_t epoch = 0;
	float errorSum;

	for (int32_t i = 0; i < maxCount; i++)
	{
		epoch++;
		errorSum = 0.0f;

		for (int32_t j = 0; j < ConstNumOfTrainingImages; j++)
		{
			PrecedingNeuron.Set_Dendrite_NeuronInput(pTrainingImagePointer[j], 32 * 32);

			PrecedingNeuron.Execute_DendriticCalculations();

			OutputLayer.Calculate_Input(&HiddenNeuronArray);
			OutputLayer.Calculate_Output();
			errorSum += OutputLayer.Calculate_ErrorValues(pTrainingImagePointer[j], 1.0f, 0.001f);
			OutputLayer.Calculate_PrecedingNeuronErrorValues(&HiddenNeuronArray, 1.0f, 0.001f);

			OutputLayer.Adjust_PrecedingNeuronOutputSynapses_AfterErrorCalculations(&HiddenNeuronArray, 0.01f);
			
			for (int32_t k = 0; k < ConstNumHiddenNeurons; k++)
				HiddenNeuronArray.pNeuronArray[k].Adjust_Dendrite_Factors_AfterErrorCalculations_ExternalInput(0.01f);
			
		}

		//if (epoch % 10 == 0)
		//{
		//cout << "epoch: " << epoch << " ";
		//cout << "error: " << errorSum << endl;
		//}

		if (errorSum < 0.0001f)
			break;
	}

	// training completed

	// training statistics:


	cout << "epoch: " << epoch << endl;
	cout << "error: " << errorSum << endl << endl;

	cout << endl;

	int32_t idOfLearnedImage;

	for (int32_t i = 0; i < ConstNumOfImages; i++)
	{
		PrecedingNeuron.Set_Dendrite_NeuronInput(pImagePointer[i], 32 * 32);
		PrecedingNeuron.Execute_DendriticCalculations();
		OutputLayer.Calculate_Input(&HiddenNeuronArray);
		OutputLayer.Calculate_Output();
		OutputLayer.Get_NeuronOutputValues(OutputArray);

		idOfLearnedImage = Find_BestMatchedVectorFromList(OutputArray, 32 * 32, pTrainingImagePointer, ConstNumOfTrainingImages);
		cout << "idOfLearnedImage: " << idOfLearnedImage;

		if (idOfLearnedImage < 4)
			cout << " => B" << endl;
		else
			cout << " => 8" << endl;
	}

	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	static float Image_B_1[32 * 32];
	static float Image_B_2[32 * 32];
	static float Image_B_3[32 * 32];
	static float Image_B_4[32 * 32];
	static float Image_B_5[32 * 32];
	static float Image_B_6[32 * 32];

	static float Image_8_1[32 * 32];
	static float Image_8_2[32 * 32];
	static float Image_8_3[32 * 32];
	static float Image_8_4[32 * 32];
	static float Image_8_5[32 * 32];
	static float Image_8_6[32 * 32];

	static constexpr int32_t ConstNumOfImages = 12;

	float *pImagePointer[ConstNumOfImages];

	pImagePointer[0] = Image_B_1;
	pImagePointer[1] = Image_B_2;
	pImagePointer[2] = Image_B_3;
	pImagePointer[3] = Image_B_4;
	pImagePointer[4] = Image_B_5;
	pImagePointer[5] = Image_B_6;

	pImagePointer[6] = Image_8_1;
	pImagePointer[7] = Image_8_2;
	pImagePointer[8] = Image_8_3;
	pImagePointer[9] = Image_8_4;
	pImagePointer[10] = Image_8_5;
	pImagePointer[11] = Image_8_6;


	uint8_t *pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_4.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_4, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_5.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_5, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_6.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_6, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_4.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_4, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_5.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_5, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_6.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_6, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	static float CombinedImage_B[32 * 32];
	static float CombinedImage_8[32 * 32];

	CCombinedData CombinedData;

	CombinedData.Reset_Data(CombinedImage_B, 0, 32 * 32);
	CombinedData.Add_Data(CombinedImage_B, Image_B_1, 0, 32 * 32);
	CombinedData.Add_Data(CombinedImage_B, Image_B_2, 0, 32 * 32);
	CombinedData.Add_Data(CombinedImage_B, Image_B_3, 0, 32 * 32);
	CombinedData.Add_Data(CombinedImage_B, Image_B_4, 0, 32 * 32);
	CombinedData.Add_Data(CombinedImage_B, Image_B_5, 0, 32 * 32);
	CombinedData.Add_Data(CombinedImage_B, Image_B_6, 0, 32 * 32);


	CombinedData.Reset_Data(CombinedImage_8, 0, 32 * 32);
	CombinedData.Add_Data(CombinedImage_8, Image_8_1, 0, 32 * 32);
	CombinedData.Add_Data(CombinedImage_8, Image_8_2, 0, 32 * 32);
	CombinedData.Add_Data(CombinedImage_8, Image_8_3, 0, 32 * 32);
	CombinedData.Add_Data(CombinedImage_8, Image_8_4, 0, 32 * 32);
	CombinedData.Add_Data(CombinedImage_8, Image_8_5, 0, 32 * 32);
	CombinedData.Add_Data(CombinedImage_8, Image_8_6, 0, 32 * 32);


	static constexpr int32_t ConstNumOfCombinedImages = 2;

	float *pCombinedImagePointer[ConstNumOfCombinedImages];
	pCombinedImagePointer[0] = CombinedImage_B;
	pCombinedImagePointer[1] = CombinedImage_8;


	static float OutputArray[32 * 32];
	

	CNeuronV2 PrecedingNeuron;

	PrecedingNeuron.Init_Dendrite_Arrays(32 * 32);
	PrecedingNeuron.Set_DendriticFunction(PrecedingNeuronDendriticFunctionBase);

	static constexpr int32_t ConstNumHiddenNeurons = 16;
	//static constexpr int32_t ConstNumHiddenNeurons = 32;
	

	CNeuronLayerV2 HiddenNeuronArray;
	HiddenNeuronArray.Initialize(ConstNumHiddenNeurons);

	for (int32_t i = 0; i < ConstNumHiddenNeurons; i++)
	{
		HiddenNeuronArray.pNeuronArray[i].Init_Dendrite_Arrays(32 * 32);
		HiddenNeuronArray.pNeuronArray[i].Use_OtherNeuron_Dendrite_InputValueArray(PrecedingNeuron.pDendrite_InputValueArray, 0);
		HiddenNeuronArray.pNeuronArray[i].Init_OutputSynapses(32 * 32);
		HiddenNeuronArray.pNeuronArray[i].Randomize_OutputSynapsePlasticities(&RandomNumbers, -0.1f, 0.1f);
		HiddenNeuronArray.pNeuronArray[i].Randomize_Dendrite_Factors(&RandomNumbers, -0.1f, 0.1f);
		HiddenNeuronArray.pNeuronArray[i].Set_ActivationFunction(ActivationFunction1);
	}


	COutputLayerV2 OutputLayer;
	OutputLayer.Initialize(32 * 32);
	OutputLayer.Set_ActivationFunction(OutputLayerActivationFunction1);

	int32_t maxCount = 4000;
	int32_t epoch = 0;
	float errorSum;



	for (int32_t i = 0; i < maxCount; i++)
	{
		epoch++;
		errorSum = 0.0f;

		for (int32_t j = 0; j < ConstNumOfCombinedImages; j++)
		{
			PrecedingNeuron.Set_Dendrite_NeuronInput(pCombinedImagePointer[j], 32 * 32);

			PrecedingNeuron.Execute_DendriticCalculations();

			OutputLayer.Calculate_Input(&HiddenNeuronArray);
			OutputLayer.Calculate_Output();
			errorSum += OutputLayer.Calculate_ErrorValues(pCombinedImagePointer[j], 1.0f, 0.001f);
			OutputLayer.Calculate_PrecedingNeuronErrorValues(&HiddenNeuronArray, 1.0f, 0.001f);
			OutputLayer.Adjust_PrecedingNeuronOutputSynapses_AfterErrorCalculations(&HiddenNeuronArray, 0.01f);

			for (int32_t k = 0; k < ConstNumHiddenNeurons; k++)
			    HiddenNeuronArray.pNeuronArray[k].Adjust_Dendrite_Factors_AfterErrorCalculations_ExternalInput(0.01f);
		}



		//if (epoch % 10 == 0)
		//{
		//cout << "epoch: " << epoch << " ";
		//cout << "error: " << errorSum << endl;
		//}

		if (errorSum < 0.0001f)
			break;
	}

	// training completed

	// training statistics:


	cout << "epoch: " << epoch << endl;
	cout << "error: " << errorSum << endl << endl;

	cout << endl;

	int32_t idOfLearnedImage;

	for (int32_t i = 0; i < ConstNumOfImages; i++)
	{
		PrecedingNeuron.Set_Dendrite_NeuronInput(pImagePointer[i], 32 * 32);
		PrecedingNeuron.Execute_DendriticCalculations();
		OutputLayer.Calculate_Input(&HiddenNeuronArray);
		OutputLayer.Calculate_Output();
		OutputLayer.Get_NeuronOutputValues(OutputArray);

		idOfLearnedImage = Find_BestMatchedVectorFromList(OutputArray, 32 * 32, pCombinedImagePointer, ConstNumOfCombinedImages);
		cout << "idOfLearnedImage: " << idOfLearnedImage;

		if (idOfLearnedImage == 0)
			cout << " => B" << endl;
		else if (idOfLearnedImage == 1)
			cout << " => 8" << endl;
	}

	getchar();
	return 0;
}
*/


