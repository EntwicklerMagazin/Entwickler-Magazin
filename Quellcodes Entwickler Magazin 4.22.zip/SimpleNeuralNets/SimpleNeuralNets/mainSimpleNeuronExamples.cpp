#include <iostream>
#include "SimpleNeuron.h"
#include "Graph.h"
#include "NeuralNetInlineFunctions.h"

using namespace std;
using namespace HelperStuff;

static constexpr int32_t NumSurfaceMapElementsPerDir = 7;
static constexpr int32_t NumSurfaceMapElements = 49;


static constexpr int32_t NumCities_TSP = 12;
static constexpr int32_t NumCities_TSP_Plus1 = NumCities_TSP + 1;


static constexpr int32_t NumWaypoints = 12;
static constexpr int32_t NumWaypointsMaxPerPath = 10;


static void SimpleRecognitionNetNeuralNet_DendriticFunction(CSimpleNeuron *pNeuron)
{
	float *pInputArray = pNeuron->pDendrite_DataArray;

	float *pPlasticityArray = pNeuron->pAdditionalMemoryValueArray;
	int32_t numOfAdditionalConnections = pNeuron->NumOfAdditionalMemoryValues;


	int32_t numOfOutputSynapses = pNeuron->NumOfOutputDendrites;
	int32_t numOfInputValues = pNeuron->NumOfInputDendrites;

	float *pOutputArray = &pNeuron->pDendrite_DataArray[pNeuron->FirstOutputDendriteID];

	// Bias:
	pInputArray[numOfInputValues - 1] = 1.0f;

	int32_t counter = pNeuron->RandomSeedValue;

	for (int32_t i = 0; i < numOfOutputSynapses; i++)
	{
		pOutputArray[i] = 0.0f;
	}

	for (int32_t j = 0; j < numOfInputValues; j++)
	{
		float inputValue = pInputArray[j];

		for (int32_t i = 0; i < numOfOutputSynapses; i++)
		{
			pOutputArray[i] += pPlasticityArray[counter] * inputValue;
			//Add_To_Log(0, "counter", counter);

			counter++;
			counter = counter % numOfAdditionalConnections;
		}
	}

	float tempValue;

	for (int32_t i = 0; i < numOfOutputSynapses; i++)
	{
		tempValue = pOutputArray[i];
		pOutputArray[i] = tempValue / (1.0f + abs(tempValue));
	}
}

static void SimpleRecognitionNetNeuralNet_ActivationFunction(CSimpleNeuron *pNeuron)
{
	float output = 0.0f;

	int32_t numDendrites = pNeuron->NumOfDendriteElements;

	for (int32_t i = 0; i < numDendrites; i++)
	{
		output += pNeuron->pDendrite_FactorArray[i] * pNeuron->pDendrite_DataArray_OtherNeuron[i];
	}

	pNeuron->ActivationValue = output;
	//pNeuron->ActivationValue = output / (1.0f + abs(output));
}




static void AdditionalInputRBFOutputFunction(CSimpleNeuron *pNeuron)
{
	pNeuron->ActivationValue = exp(-0.1f * pNeuron->AdditionalInputValue);
}

static void SimpleRecognitionOutputFunction(CSimpleNeuron *pNeuron)
{
	float output = 0.0f;
	float tempValue;
	int32_t numDendrites = pNeuron->NumOfDendriteElements;

	for (int32_t i = 0; i < numDendrites; i++)
	{
		tempValue = pNeuron->pDendrite_DataArray[i] - pNeuron->pDendrite_CentroidValueArray[i];
		tempValue *= tempValue;

		output += pNeuron->pDendrite_FactorArray[i] * tempValue;
	}

	pNeuron->ActivationValue = exp(-output);
}


static void SimpleRecognitionOutputFunction32x32(CSimpleNeuron *pNeuron)
{
	float output = 0.0f;
	float tempValue;
	int32_t numDendrites = pNeuron->NumOfDendriteElements;

	for (int32_t i = 0; i < numDendrites; i++)
	{
		tempValue = pNeuron->pDendrite_DataArray[i] - pNeuron->pDendrite_CentroidValueArray[i];
		tempValue *= tempValue;

		//if (pNeuron->pDendrite_CentroidValueArray[i] > pNeuron->pDendrite_DataArray[i])
			//tempValue *= 0.001f;

		// wenn Pixel kein Teil des Symbols/Pattern:
		//if (pNeuron->pDendrite_DataArray[i] <= 0.0f)
			//tempValue *= 4.0f;

		output += pNeuron->pDendrite_FactorArray[i] * tempValue;
	}

	pNeuron->ActivationValue = 1.0f - tanh(0.025f * output);
	//pNeuron->ActivationValue = exp(-0.1f * output);
}

static void SimpleRecognitionOutputFunction16x16(CSimpleNeuron *pNeuron)
{
	float output = 0.0f;
	float tempValue;
	int32_t numDendrites = pNeuron->NumOfDendriteElements;

	for (int32_t i = 0; i < numDendrites; i++)
	{
		tempValue = pNeuron->pDendrite_DataArray[i] - pNeuron->pDendrite_CentroidValueArray[i];
		tempValue *= tempValue;

		//if (pNeuron->pDendrite_CentroidValueArray[i] > pNeuron->pDendrite_DataArray[i])
			//tempValue *= 0.001f;

		// wenn Pixel kein Teil des Symbols/Pattern:
		//if (pNeuron->pDendrite_DataArray[i] <= 0.0f)
			//tempValue *= 4.0f;

		output += pNeuron->pDendrite_FactorArray[i] * tempValue;
	}

	pNeuron->ActivationValue = 1.0f - tanh(0.025f * output);
	//pNeuron->ActivationValue = exp(-0.1f * output);
}


static void SectorExaminationDendriticFunction_16x16Image_8x8Sectors(CSimpleNeuron *pNeuron)
{
	static constexpr int32_t ConstNumInputValuesPerDir = 16;
	static constexpr int32_t ConstNumInputValues = ConstNumInputValuesPerDir * ConstNumInputValuesPerDir;

	float *pInputDataArray = &pNeuron->pDendrite_DataArray[0];
	float *pOutputDataArray = &pNeuron->pDendrite_DataArray[ConstNumInputValues];

	static constexpr int32_t ConstNumOutputValuesPerDir = 8;
	static constexpr int32_t ConstNumOutputValues = ConstNumOutputValuesPerDir * ConstNumOutputValuesPerDir;


	static constexpr int32_t ConstNumValuesPerSectorPerDir = ConstNumInputValuesPerDir / ConstNumOutputValuesPerDir;


	static float sectorOutputArray[ConstNumOutputValues];

	for (int32_t i = 0; i < ConstNumOutputValues; i++)
	{
		sectorOutputArray[i] = 0.0f;
	}


	int32_t ix, iy;
	int32_t ix2, iy2;

	for (int32_t i = 0; i < ConstNumInputValues; i++)
	{
		ix = i % ConstNumInputValuesPerDir;
		iy = i / ConstNumInputValuesPerDir;

		ix2 = ix / ConstNumValuesPerSectorPerDir;
		iy2 = iy / ConstNumValuesPerSectorPerDir;

		// wenn Pixel im Sektor (ix2, iY2):
		if (pInputDataArray[i] > 0.0f)
		{
			sectorOutputArray[ix2 + ConstNumOutputValuesPerDir * iy2] += 1.0f;
		}
	}

	for (int32_t i = 0; i < ConstNumOutputValues; i++)
	{
		pOutputDataArray[i] = sectorOutputArray[i];
	}
}

static void SectorExaminationDendriticFunction_32x32Image_8x8Sectors(CSimpleNeuron *pNeuron)
{
	static constexpr int32_t ConstNumInputValuesPerDir = 32;
	static constexpr int32_t ConstNumInputValues = ConstNumInputValuesPerDir * ConstNumInputValuesPerDir;

	float *pInputDataArray = &pNeuron->pDendrite_DataArray[0];
	float *pOutputDataArray = &pNeuron->pDendrite_DataArray[ConstNumInputValues];

	static constexpr int32_t ConstNumOutputValuesPerDir = 8;
	static constexpr int32_t ConstNumOutputValues = ConstNumOutputValuesPerDir * ConstNumOutputValuesPerDir;
	

	static constexpr int32_t ConstNumValuesPerSectorPerDir = ConstNumInputValuesPerDir / ConstNumOutputValuesPerDir;


	static float sectorOutputArray[ConstNumOutputValues];

	for (int32_t i = 0; i < ConstNumOutputValues; i++)
	{
		sectorOutputArray[i] = 0.0f;
	}

	
	int32_t ix, iy;
	int32_t ix2, iy2;

	for (int32_t i = 0; i < ConstNumInputValues; i++)
	{
		ix = i % ConstNumInputValuesPerDir;
		iy = i / ConstNumInputValuesPerDir;

		ix2 = ix / ConstNumValuesPerSectorPerDir;
		iy2 = iy / ConstNumValuesPerSectorPerDir;

		// wenn Pixel im Sektor (ix2, iY2):
		if (pInputDataArray[i] > 0.0f)
		{
			sectorOutputArray[ix2 + ConstNumOutputValuesPerDir * iy2] += 1.0f;
		}
	}

	for (int32_t i = 0; i < ConstNumOutputValues; i++)
	{
		pOutputDataArray[i] = sectorOutputArray[i];
	}
}





static void LogicFunctionApproximationDendriticFunction(CSimpleNeuron *pNeuron)
{
	float *pInputArray = pNeuron->pDendrite_DataArray;

	float *pPlasticityArray = pNeuron->pAdditionalMemoryValueArray;
	int32_t numOfAdditionalConnections = pNeuron->NumOfAdditionalMemoryValues;


	int32_t numOfOutputSynapses = pNeuron->NumOfOutputDendrites;
	int32_t numOfInputValues = pNeuron->NumOfInputDendrites;

	float *pOutputArray = &pNeuron->pDendrite_DataArray[pNeuron->FirstOutputDendriteID];

	// Bias:
	pInputArray[numOfInputValues - 1] = 1.0f;

	int32_t counter = pNeuron->RandomSeedValue;

	for (int32_t i = 0; i < numOfOutputSynapses; i++)
	{
		pOutputArray[i] = 0.0f;
	}

	for (int32_t j = 0; j < numOfInputValues; j++)
	{
		float inputValue = 10.0f * pInputArray[j];

		for (int32_t i = 0; i < numOfOutputSynapses; i++)
		{
			pOutputArray[i] += pPlasticityArray[counter] * inputValue;
			//Add_To_Log(0, "counter", counter);

			counter++;
			counter = counter % numOfAdditionalConnections;
		}
	}

	float tempValue;

	for (int32_t i = 0; i < numOfOutputSynapses; i++)
	{
		tempValue = pOutputArray[i];
		pOutputArray[i] = tempValue / (1.0f + abs(tempValue));
	}
}

static void LogicFunctionApproximationDendriticFunction2(CSimpleNeuron *pNeuron)
{
	float *pInputArray = pNeuron->pDendrite_DataArray;

	float *pPlasticityArray = pNeuron->pAdditionalMemoryValueArray;
	int32_t numOfAdditionalConnections = pNeuron->NumOfAdditionalMemoryValues;


	int32_t numOfOutputSynapses = pNeuron->NumOfOutputDendrites;
	int32_t numOfInputValues = pNeuron->NumOfInputDendrites;

	float *pOutputArray = &pNeuron->pDendrite_DataArray[pNeuron->FirstOutputDendriteID];

	// Bias:
	pInputArray[numOfInputValues - 1] = 1.0f;

	int32_t counter = pNeuron->RandomSeedValue;

	for (int32_t i = 0; i < numOfOutputSynapses; i++)
	{
		pOutputArray[i] = 0.0f;
	}

	for (int32_t j = 0; j < numOfInputValues; j++)
	{
		float inputValue = 10.0f * pInputArray[j];
		
		for (int32_t i = 0; i < numOfOutputSynapses; i++)
		{
			pOutputArray[i] += pPlasticityArray[counter] * inputValue;
			//Add_To_Log(0, "counter", counter);

			counter++;
			counter = counter % numOfAdditionalConnections;
		}
	}

	float tempValue;

	for (int32_t i = 0; i < numOfOutputSynapses; i++)
	{
		tempValue = pOutputArray[i];
		pOutputArray[i] = tempValue / (1.0f + abs(tempValue));
	}
}

static void AutoencoderDendriticFunction(CSimpleNeuron *pNeuron)
{
	float *pInputArray = pNeuron->pDendrite_DataArray;

	float *pPlasticityArray = pNeuron->pAdditionalMemoryValueArray;
	int32_t numOfAdditionalConnections = pNeuron->NumOfAdditionalMemoryValues;


	int32_t numOfOutputSynapses = pNeuron->NumOfOutputDendrites;
	int32_t numOfInputValues = pNeuron->NumOfInputDendrites;

	float *pOutputArray = &pNeuron->pDendrite_DataArray[pNeuron->FirstOutputDendriteID];

	int32_t counter = pNeuron->RandomSeedValue;

	for (int32_t i = 0; i < numOfOutputSynapses; i++)
	{
		pOutputArray[i] = 0.0f;
	}

	for (int32_t j = 0; j < numOfInputValues; j++)
	{
		float inputValue = pInputArray[j];

		for (int32_t i = 0; i < numOfOutputSynapses; i++)
		{
			pOutputArray[i] += pPlasticityArray[counter] * inputValue;

			counter++;
			counter = counter % numOfAdditionalConnections;
		}
	}

	float tempValue;

	for (int32_t i = 0; i < numOfOutputSynapses; i++)
	{
		tempValue = pOutputArray[i];
		pOutputArray[i] = tempValue / (1.0f + abs(tempValue));
	}
}

static void AutoencoderDendriticFunction2(CSimpleNeuron *pNeuron)
{
	float *pInputArray = pNeuron->pDendrite_DataArray;

	float *pPlasticityArray = pNeuron->pAdditionalMemoryValueArray;
	int32_t numOfAdditionalConnections = pNeuron->NumOfAdditionalMemoryValues;


	int32_t numOfOutputSynapses = pNeuron->NumOfOutputDendrites;
	int32_t numOfInputValues = pNeuron->NumOfInputDendrites;

	float *pOutputArray = &pNeuron->pDendrite_DataArray[pNeuron->FirstOutputDendriteID];

	int32_t counter = pNeuron->RandomSeedValue;

	for (int32_t i = 0; i < numOfOutputSynapses; i++)
	{
		pOutputArray[i] = 0.0f;
	}

	for (int32_t j = 0; j < numOfInputValues; j++)
	{
		float inputValue = pInputArray[j];

		for (int32_t i = 0; i < numOfOutputSynapses; i++)
		{
			pOutputArray[i] += pPlasticityArray[counter] * inputValue;

			counter++;
			counter = counter % numOfAdditionalConnections;
		}
	}

	float tempValue;

	for (int32_t i = 0; i < numOfOutputSynapses; i++)
	{
		//pOutputArray[i] = tanh(pOutputArray[i]);
		//pOutputArray[i] = 1.0f / (1.0f + exp(-pOutputArray[i]));
		tempValue = pOutputArray[i];
		pOutputArray[i] = tempValue / (1.0f + abs(tempValue));
	}
}


static void AutoencoderOutputFunction(CSimpleNeuron *pNeuron)
{
	float output = 0.0f;

	int32_t numDendrites = pNeuron->NumOfDendriteElements;

	for (int32_t i = 0; i < numDendrites; i++)
	{
		output += pNeuron->pDendrite_FactorArray[i] * pNeuron->pDendrite_DataArray_OtherNeuron[i];
	}


	pNeuron->ActivationValue = output;
}






static void LogicFunctionApproximationOutputFunction(CSimpleNeuron *pNeuron)
{
	float output = 0.0f;

	int32_t numDendrites = pNeuron->NumOfDendriteElements;

	for (int32_t i = 0; i < numDendrites; i++)
	{
		output += pNeuron->pDendrite_FactorArray[i] * pNeuron->pDendrite_DataArray_OtherNeuron[i];
	}


	pNeuron->ActivationValue = output;
}


static void LogicFunctionApproximation_MutationFunction(CSimpleNeuralNetData *pInOutNeuralNet, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	float minVariance1 = -0.01f;
	float maxVariance1 = 0.01f;
	float mutationRate1 = 0.75f;

	float minVariance2 = -0.05f;
	float maxVariance2 = 0.05f;
	float mutationRate2 = 0.75f;

	int32_t numOfNeurons = pInOutNeuralNet->NumOfNeurons;
	CSimpleNeuron **ppNeuron = pInOutNeuralNet->ppNeuronArray;

	for (int32_t j = 0; j < numOfNeurons; j++)
	{
		ppNeuron[j]->Modify_AdditionalMemoryValues(pRandomNumbers, minVariance1, maxVariance1, mutationRate1);
		ppNeuron[j]->Modify_Dendrite_Factors(pRandomNumbers, minVariance2, maxVariance2, mutationRate2);
	}
}

static void SimpleDeepLearning_MutationFunction(CSimpleNeuralNetData *pInOutNeuralNet, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	float minVarianceLRF = -0.05f;
	float maxVarianceLRF = 0.05f;
	float mutationRateLRF = 0.25f;

	float minVariance1 = -0.05f;
	float maxVariance1 = 0.05f;
	float mutationRate1 = 0.5f;

	float minVariance2 = -0.05f;
	float maxVariance2 = 0.05f;
	float mutationRate2 = 0.5f;

	int32_t numOfNeurons = pInOutNeuralNet->NumOfNeurons;
	int32_t numLRFNeurons = pInOutNeuralNet->NumLRFNeurons_Layer1;
	CSimpleNeuron **ppNeuron = pInOutNeuralNet->ppNeuronArray;

	for (int32_t j = 0; j < numLRFNeurons; j++)
	{
		ppNeuron[j]->Modify_Dendrite_Factors(pRandomNumbers, minVarianceLRF, maxVarianceLRF, mutationRateLRF);
	}

	for (int32_t j = numLRFNeurons; j < numOfNeurons; j++)
	{
		ppNeuron[j]->Modify_AdditionalMemoryValues(pRandomNumbers, minVariance1, maxVariance1, mutationRate1);
		ppNeuron[j]->Modify_Dendrite_Factors(pRandomNumbers, minVariance2, maxVariance2, mutationRate2);
	}
}

static void SimpleDeepLearning_NeuralNet_MutationFunction(CSimpleNeuralNetData *pInOutNeuralNet, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	float minVariance1 = -0.05f;
	float maxVariance1 = 0.05f;
	float mutationRate1 = 0.5f;

	float minVariance2 = -0.05f;
	float maxVariance2 = 0.05f;
	float mutationRate2 = 0.5f;

	int32_t numOfNeurons = pInOutNeuralNet->NumOfNeurons;
	int32_t numLRFNeurons = pInOutNeuralNet->NumLRFNeurons_Layer1;
	CSimpleNeuron **ppNeuron = pInOutNeuralNet->ppNeuronArray;

	
	for (int32_t j = numLRFNeurons; j < numOfNeurons; j++)
	{
		ppNeuron[j]->Modify_AdditionalMemoryValues(pRandomNumbers, minVariance1, maxVariance1, mutationRate1);
		ppNeuron[j]->Modify_Dendrite_Factors(pRandomNumbers, minVariance2, maxVariance2, mutationRate2);
	}
}

static void SimpleDeepLearning_LRF_MutationFunction(CSimpleNeuralNetData *pInOutNeuralNet, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	float minVarianceLRF = -0.05f;
	float maxVarianceLRF = 0.05f;
	float mutationRateLRF = 0.25f;

	int32_t numLRFNeurons = pInOutNeuralNet->NumLRFNeurons_Layer1;
	CSimpleNeuron **ppNeuron = pInOutNeuralNet->ppNeuronArray;

	for (int32_t j = 0; j < numLRFNeurons; j++)
	{
		ppNeuron[j]->Modify_Dendrite_Factors(pRandomNumbers, minVarianceLRF, maxVarianceLRF, mutationRateLRF);
	}
}

static void LogicFunctionApproximation_RecombinationFunction(CSimpleNeuralNetData *pOffspring, const CSimpleNeuralNetData *pParent1, const CSimpleNeuralNetData *pParent2, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	float weight1, weight2;

	int32_t numOfNeurons = pOffspring->NumOfNeurons;

	CSimpleNeuron **ppNeuron_Offspring = pOffspring->ppNeuronArray;
	CSimpleNeuron **ppNeuron_Parent1 = pParent1->ppNeuronArray;
	CSimpleNeuron **ppNeuron_Parent2 = pParent2->ppNeuronArray;

	for (int32_t j = 0; j < numOfNeurons; j++)
	{
		int32_t numOfDendriteElements = ppNeuron_Offspring[j]->NumOfDendriteElements;

		for (int32_t i = 0; i < numOfDendriteElements; i++)
		{
			weight1 = pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f);
			weight2 = 1.0f - weight1;

			ppNeuron_Offspring[j]->pDendrite_FactorArray[i] = weight1 * ppNeuron_Parent1[j]->pDendrite_FactorArray[i] +
				weight2 * ppNeuron_Parent2[j]->pDendrite_FactorArray[i];
		}
	}

	for (int32_t j = 0; j < numOfNeurons; j++)
	{
		int32_t numOfAdditionalMemoryValues = ppNeuron_Offspring[j]->NumOfAdditionalMemoryValues;

		for (int32_t i = 0; i < numOfAdditionalMemoryValues; i++)
		{
			weight1 = pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f);
			weight2 = 1.0f - weight1;

			ppNeuron_Offspring[j]->pAdditionalMemoryValueArray[i] = weight1 * ppNeuron_Parent1[j]->pAdditionalMemoryValueArray[i] +
				weight2 * ppNeuron_Parent2[j]->pAdditionalMemoryValueArray[i];
		}
	}
}

static void SimpleDeepLearning_RecombinationFunction(CSimpleNeuralNetData *pOffspring, const CSimpleNeuralNetData *pParent1, const CSimpleNeuralNetData *pParent2, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	float weight1, weight2;

	int32_t numOfNeurons = pOffspring->NumOfNeurons;
	int32_t numLRFNeurons = pOffspring->NumLRFNeurons_Layer1;

	CSimpleNeuron **ppNeuron_Offspring = pOffspring->ppNeuronArray;
	CSimpleNeuron **ppNeuron_Parent1 = pParent1->ppNeuronArray;
	CSimpleNeuron **ppNeuron_Parent2 = pParent2->ppNeuronArray;


	for (int32_t j = 0; j < numLRFNeurons; j++)
	{
		int32_t numOfDendriteElements = ppNeuron_Offspring[j]->NumOfDendriteElements;

		for (int32_t i = 0; i < numOfDendriteElements; i++)
		{
			weight1 = pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f);
			weight2 = 1.0f - weight1;

			ppNeuron_Offspring[j]->pDendrite_FactorArray[i] = weight1 * ppNeuron_Parent1[j]->pDendrite_FactorArray[i] +
				weight2 * ppNeuron_Parent2[j]->pDendrite_FactorArray[i];
		}
	}

	for (int32_t j = numLRFNeurons; j < numOfNeurons; j++)
	{
		int32_t numOfDendriteElements = ppNeuron_Offspring[j]->NumOfDendriteElements;

		for (int32_t i = 0; i < numOfDendriteElements; i++)
		{
			weight1 = pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f);
			weight2 = 1.0f - weight1;

			ppNeuron_Offspring[j]->pDendrite_FactorArray[i] = weight1 * ppNeuron_Parent1[j]->pDendrite_FactorArray[i] +
				weight2 * ppNeuron_Parent2[j]->pDendrite_FactorArray[i];
		}
	}

	for (int32_t j = numLRFNeurons; j < numOfNeurons; j++)
	{
		int32_t numOfAdditionalMemoryValues = ppNeuron_Offspring[j]->NumOfAdditionalMemoryValues;

		for (int32_t i = 0; i < numOfAdditionalMemoryValues; i++)
		{
			weight1 = pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f);
			weight2 = 1.0f - weight1;

			ppNeuron_Offspring[j]->pAdditionalMemoryValueArray[i] = weight1 * ppNeuron_Parent1[j]->pAdditionalMemoryValueArray[i] +
				weight2 * ppNeuron_Parent2[j]->pAdditionalMemoryValueArray[i];
		}
	}
}

static void SimpleDeepLearning_NeuralNet_RecombinationFunction(CSimpleNeuralNetData *pOffspring, const CSimpleNeuralNetData *pParent1, const CSimpleNeuralNetData *pParent2, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	float weight1, weight2;

	int32_t numOfNeurons = pOffspring->NumOfNeurons;
	int32_t numLRFNeurons = pOffspring->NumLRFNeurons_Layer1;

	CSimpleNeuron **ppNeuron_Offspring = pOffspring->ppNeuronArray;
	CSimpleNeuron **ppNeuron_Parent1 = pParent1->ppNeuronArray;
	CSimpleNeuron **ppNeuron_Parent2 = pParent2->ppNeuronArray;


	for (int32_t j = numLRFNeurons; j < numOfNeurons; j++)
	{
		int32_t numOfDendriteElements = ppNeuron_Offspring[j]->NumOfDendriteElements;

		for (int32_t i = 0; i < numOfDendriteElements; i++)
		{
			weight1 = pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f);
			weight2 = 1.0f - weight1;

			ppNeuron_Offspring[j]->pDendrite_FactorArray[i] = weight1 * ppNeuron_Parent1[j]->pDendrite_FactorArray[i] +
				weight2 * ppNeuron_Parent2[j]->pDendrite_FactorArray[i];
		}
	}

	for (int32_t j = numLRFNeurons; j < numOfNeurons; j++)
	{
		int32_t numOfAdditionalMemoryValues = ppNeuron_Offspring[j]->NumOfAdditionalMemoryValues;

		for (int32_t i = 0; i < numOfAdditionalMemoryValues; i++)
		{
			weight1 = pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f);
			weight2 = 1.0f - weight1;

			ppNeuron_Offspring[j]->pAdditionalMemoryValueArray[i] = weight1 * ppNeuron_Parent1[j]->pAdditionalMemoryValueArray[i] +
				weight2 * ppNeuron_Parent2[j]->pAdditionalMemoryValueArray[i];
		}
	}
}

static void SimpleDeepLearning_LRF_RecombinationFunction(CSimpleNeuralNetData *pOffspring, const CSimpleNeuralNetData *pParent1, const CSimpleNeuralNetData *pParent2, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	float weight1, weight2;

	
	int32_t numLRFNeurons = pOffspring->NumLRFNeurons_Layer1;

	CSimpleNeuron **ppNeuron_Offspring = pOffspring->ppNeuronArray;
	CSimpleNeuron **ppNeuron_Parent1 = pParent1->ppNeuronArray;
	CSimpleNeuron **ppNeuron_Parent2 = pParent2->ppNeuronArray;


	for (int32_t j = 0; j < numLRFNeurons; j++)
	{
		int32_t numOfDendriteElements = ppNeuron_Offspring[j]->NumOfDendriteElements;

		for (int32_t i = 0; i < numOfDendriteElements; i++)
		{
			weight1 = pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f);
			weight2 = 1.0f - weight1;

			ppNeuron_Offspring[j]->pDendrite_FactorArray[i] = weight1 * ppNeuron_Parent1[j]->pDendrite_FactorArray[i] +
				weight2 * ppNeuron_Parent2[j]->pDendrite_FactorArray[i];
		}
	}
}


static void LinearApproximationOutputFunction(CSimpleNeuron *pNeuron)
{
	float input = pNeuron->AdditionalInputValue;
	
	pNeuron->pDendrite_DataArray[0] = 1.0f;
	pNeuron->pDendrite_DataArray[1] = input;

	float output = pNeuron->pDendrite_FactorArray[0];

	output += input * pNeuron->pDendrite_FactorArray[1];
	
	pNeuron->ActivationValue = output;
}

static void PolynomApproximationOutputFunction(CSimpleNeuron *pNeuron)
{
	float input = pNeuron->AdditionalInputValue;
	float input2 = input * input;
	float input3 = input * input * input;
	float input4 = input * input * input * input;

	pNeuron->pDendrite_DataArray[0] = 1.0f;
	pNeuron->pDendrite_DataArray[1] = input;
	pNeuron->pDendrite_DataArray[2] = input2;
	pNeuron->pDendrite_DataArray[3] = input3;
	pNeuron->pDendrite_DataArray[4] = input4;

	pNeuron->pDendrite_DataArray[5] = input;
	pNeuron->pDendrite_DataArray[6] = input2;
	pNeuron->pDendrite_DataArray[7] = input3;
	pNeuron->pDendrite_DataArray[8] = input4;

	pNeuron->pDendrite_DataArray[9] = input;
	pNeuron->pDendrite_DataArray[10] = input2;
	pNeuron->pDendrite_DataArray[11] = input3;
	pNeuron->pDendrite_DataArray[12] = input4;

	float output = pNeuron->pDendrite_FactorArray[0];

	output += input * pNeuron->pDendrite_FactorArray[1];
	output += input2 * pNeuron->pDendrite_FactorArray[2];
	output += input3 * pNeuron->pDendrite_FactorArray[3];
	output += input4 * pNeuron->pDendrite_FactorArray[4];

	output += input * pNeuron->pDendrite_FactorArray[5];
	output += input2 * pNeuron->pDendrite_FactorArray[6];
	output += input3 * pNeuron->pDendrite_FactorArray[7];
	output += input4 * pNeuron->pDendrite_FactorArray[8];

	output += input * pNeuron->pDendrite_FactorArray[9];
	output += input2 * pNeuron->pDendrite_FactorArray[10];
	output += input3 * pNeuron->pDendrite_FactorArray[11];
	output += input4 * pNeuron->pDendrite_FactorArray[12];

	pNeuron->ActivationValue = output;
}

static void SimplePolynomApproximationOutputFunction(CSimpleNeuron *pNeuron)
{
	float input = pNeuron->AdditionalInputValue;
	float input2 = input * input;
	float input3 = input * input * input;
	float input4 = input * input * input * input;

	pNeuron->pDendrite_DataArray[0] = 1.0f;
	pNeuron->pDendrite_DataArray[1] = input;
	pNeuron->pDendrite_DataArray[2] = input2;
	pNeuron->pDendrite_DataArray[3] = input3;
	pNeuron->pDendrite_DataArray[4] = input4;


	float output = pNeuron->pDendrite_FactorArray[0];

	output += input * pNeuron->pDendrite_FactorArray[1];
	output += input2 * pNeuron->pDendrite_FactorArray[2];
	output += input3 * pNeuron->pDendrite_FactorArray[3];
	output += input4 * pNeuron->pDendrite_FactorArray[4];

	pNeuron->ActivationValue = output;
}

static void PolynomApproximation_MutationFunction(CSimpleNeuron *pInOutNeuron, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	float minVariance = -0.01f;
	float maxVariance = 0.01f;
	float mutationRate = 0.75f;

	pInOutNeuron->Modify_Dendrite_Factors(pRandomNumbers, minVariance, maxVariance, mutationRate);
}

static void PolynomApproximation_RecombinationFunction(CSimpleNeuron *pOffspring, const CSimpleNeuron *pParent1, const CSimpleNeuron *pParent2, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	float weight1, weight2;

	int32_t numOfDendriteElements = pOffspring->NumOfDendriteElements;

	for (int32_t i = 0; i < numOfDendriteElements; i++)
	{
		weight1 = pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f);
		weight2 = 1.0f - weight1;

		pOffspring->pDendrite_FactorArray[i] = weight1 * pParent1->pDendrite_FactorArray[i] + weight2 * pParent2->pDendrite_FactorArray[i];
	}
}


static void Output_SurfaceMapData(char *pData)
{
	uint32_t ix, iy, id;

	for (iy = 0; iy < NumSurfaceMapElementsPerDir; iy++)
	{
		for (ix = 0; ix < NumSurfaceMapElementsPerDir; ix++)
		{
			id = ix + iy * NumSurfaceMapElementsPerDir;
			cout << pData[id] << " ";
		}

		cout << endl;
	}

	cout << endl << endl;
}

static void Set_SurfaceMapData(char *pOutData, uint32_t ix, uint32_t iy, char sign)
{
	uint32_t id = ix + iy * NumSurfaceMapElementsPerDir;
	pOutData[id] = sign;
}

static void Init_SurfaceMap(char *pOutData, char sign)
{
	uint32_t ix, iy, id;

	for (iy = 0; iy < NumSurfaceMapElementsPerDir; iy++)
	{
		for (ix = 0; ix < NumSurfaceMapElementsPerDir; ix++)
		{
			id = ix + iy * NumSurfaceMapElementsPerDir;
			pOutData[id] = sign;
		}
	}
}

static void Update_Fitnessvalues(CGraphNode *pGraphNodeArray, CSimpleNeuronPopulation *pNeuronPopulation)
{
	CSimpleNeuron *pNeuronArray = pNeuronPopulation->ppNeuronArray[0];

	int32_t populationSizePlusX = pNeuronPopulation->PopulationSizePlusX;
	int32_t num_Of_Dendrite_Elements = pNeuronArray[0].NumOfDendriteElements;

	float distSq;

	for (int32_t i = 0; i < populationSizePlusX; i++)
	{
		distSq = pGraphNodeArray->Calculate_PathDistSq(pNeuronArray[i].pDendrite_FactorArray, num_Of_Dendrite_Elements);
		// Fitnessvalue:
		pNeuronArray[i].ActivationValue = 1.0f / distSq;
	}
}

static void Update_Fitnessvalues2(CGraphNode *pGraphNodeArray, CSimpleNeuronPopulation *pNeuronPopulation)
{
	CSimpleNeuron *pNeuronArray = pNeuronPopulation->ppNeuronArray[0];

	int32_t populationSizePlusX = pNeuronPopulation->PopulationSizePlusX;
	int32_t numOfWaypoints = pNeuronArray[0].NumOfAdditionalMemoryValues;

	float distSq;

	for (int32_t i = 0; i < populationSizePlusX; i++)
	{
		distSq = pGraphNodeArray->Calculate_PathDistSq(pNeuronArray[i].pAdditionalMemoryValueArray, numOfWaypoints);
		// Fitnessvalue:
		pNeuronArray[i].ActivationValue = 1.0f / distSq;
	}
}

static void Update_FitnessvaluesExt(CGraphNode *pGraphNodeArray, CWeightMatrix *pWeightMatrix, CSimpleNeuronPopulation *pNeuronPopulation)
{
	CSimpleNeuron *pNeuronArray = pNeuronPopulation->ppNeuronArray[0];

	int32_t populationSizePlusX = pNeuronPopulation->PopulationSizePlusX;
	int32_t num_Of_Dendrite_Elements = pNeuronArray[0].NumOfDendriteElements;

	float distSq;

	for (int32_t i = 0; i < populationSizePlusX; i++)
	{
		distSq = pGraphNodeArray->Calculate_WeightedPathDistSq(pNeuronArray[i].pDendrite_FactorArray, pWeightMatrix, num_Of_Dendrite_Elements);
		// Fitnessvalue:
		pNeuronArray[i].ActivationValue = 1.0f / distSq;
	}
}

static void Update_FitnessvaluesExt2(CGraphNode *pGraphNodeArray, CWeightMatrix *pWeightMatrix, CSimpleNeuronPopulation *pNeuronPopulation)
{
	CSimpleNeuron *pNeuronArray = pNeuronPopulation->ppNeuronArray[0];

	int32_t populationSizePlusX = pNeuronPopulation->PopulationSizePlusX;
	int32_t numOfWaypoints = pNeuronArray[0].NumOfAdditionalMemoryValues;

	float distSq;

	for (int32_t i = 0; i < populationSizePlusX; i++)
	{
		distSq = pGraphNodeArray->Calculate_WeightedPathDistSq(pNeuronArray[i].pAdditionalMemoryValueArray, pWeightMatrix, numOfWaypoints);
		// Fitnessvalue:
		pNeuronArray[i].ActivationValue = 1.0f / distSq;
	}
}

struct CPermutationInfo
{
	int32_t minDendriteID;
	int32_t maxDendriteID;
	int32_t permutationSteps;
};

static void TSP_PermutationFunction(CSimpleNeuron *pInOutNeuron, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	CPermutationInfo *pPermutationInfo = static_cast<CPermutationInfo*>(pParam);

	int32_t minDendriteID = pPermutationInfo->minDendriteID;
	int32_t maxDendriteID = pPermutationInfo->maxDendriteID;
	int32_t permutationSteps = pPermutationInfo->permutationSteps;

	pInOutNeuron->Permute_Dendrite_Values(pRandomNumbers, minDendriteID, maxDendriteID, permutationSteps);
}

struct CPermutationInfo2
{
	int32_t minWaypointID;
	int32_t maxWaypointID;
	int32_t permutationSteps;
};

static void TSP_PermutationFunction2(CSimpleNeuron *pInOutNeuron, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	CPermutationInfo2 *pPermutationInfo = static_cast<CPermutationInfo2*>(pParam);

	int32_t minWaypointID = pPermutationInfo->minWaypointID;
	int32_t maxWaypointID = pPermutationInfo->maxWaypointID;
	int32_t permutationSteps = pPermutationInfo->permutationSteps;

	pInOutNeuron->Permute_AdditionalMemoryValues(pRandomNumbers, minWaypointID, maxWaypointID, permutationSteps);
}


static void TSP_RecombinationFunction(CSimpleNeuron *pOffspring, const CSimpleNeuron *pParent1, const CSimpleNeuron *pParent2, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	static float tempValueArray[1000];

	int32_t numVectorElements = pOffspring->NumOfDendriteElements;
	int32_t numVectorElementsMinus1 = numVectorElements - 1;

	float *pInputVector1 = pParent1->pDendrite_FactorArray;
	float *pInputVector2 = pParent2->pDendrite_FactorArray;
	float *pOutputVector = pOffspring->pDendrite_FactorArray;


	int32_t counter = 0;

	/* Route 1 von Individuum 1 mit Ausnahme des Zielpunkts zwischenspeichern: */
	for (int32_t i = 0; i < numVectorElementsMinus1; i++)
	{
		tempValueArray[counter] = pInputVector1[i];
		counter++;
	}

	/* Route 2 von Individuum 2 mit Ausnahme des Startpunkts zwischenspeichern: */
	for (int32_t i = 1; i < numVectorElements; i++)
	{
		tempValueArray[counter] = pInputVector2[i];
		counter++;
	}


	counter--;

	for (int32_t i = 1; i < counter; i++)
	{
		/* entweder Wegpunkt von Route 1 deaktivieren (durch negatives Vorzeichen kennzeichnen): */
		if (pRandomNumbers->Get_IntegerNumber(1, 3) == 1)
		{
			for (int32_t j = 1; j < numVectorElementsMinus1; j++)
			{
				if (tempValueArray[j] == static_cast<float>(i))
				{
					tempValueArray[j] = static_cast<float>(-i);
					break;
				}
			}
		}
		/* oder Wegpunkt von Route 2 deaktivieren (durch negatives Vorzeichen kennzeichnen): */
		else
		{
			for (int32_t j = numVectorElementsMinus1; j < counter; j++)
			{
				if (tempValueArray[j] == static_cast<float>(i))
				{
					tempValueArray[j] = static_cast<float>(-i);
					break;
				}
			}
		}
	}

	/* Neue Route aus nicht deaktivierten Wegpunkten generieren: */

	pOutputVector[0] = 0.0f;
	pOutputVector[numVectorElementsMinus1] = 0.0f;

	int32_t counter2 = 1;
	//counter--;
	for (int32_t i = 1; i < counter; i++)
	{
		/* pos. Vorzeichen => nicht deaktivierter Wegpunkt: */
		if (tempValueArray[i] > 0.0f)
		{
			pOutputVector[counter2] = tempValueArray[i];
			counter2++;
		}
	}
}

static void TSP_RecombinationFunction2(CSimpleNeuron *pOffspring, const CSimpleNeuron *pParent1, const CSimpleNeuron *pParent2, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	static float tempValueArray[1000];

	int32_t numVectorElements = pOffspring->NumOfAdditionalMemoryValues;
	int32_t numVectorElementsMinus1 = numVectorElements - 1;

	float *pInputVector1 = pParent1->pAdditionalMemoryValueArray;
	float *pInputVector2 = pParent2->pAdditionalMemoryValueArray;
	float *pOutputVector = pOffspring->pAdditionalMemoryValueArray;


	int32_t counter = 0;

	/* Route 1 von Individuum 1 mit Ausnahme des Zielpunkts zwischenspeichern: */
	for (int32_t i = 0; i < numVectorElementsMinus1; i++)
	{
		tempValueArray[counter] = pInputVector1[i];
		counter++;
	}

	/* Route 2 von Individuum 2 mit Ausnahme des Startpunkts zwischenspeichern: */
	for (int32_t i = 1; i < numVectorElements; i++)
	{
		tempValueArray[counter] = pInputVector2[i];
		counter++;
	}


	counter--;

	for (int32_t i = 1; i < counter; i++)
	{
		/* entweder Wegpunkt von Route 1 deaktivieren (durch negatives Vorzeichen kennzeichnen): */
		if (pRandomNumbers->Get_IntegerNumber(1, 3) == 1)
		{
			for (int32_t j = 1; j < numVectorElementsMinus1; j++)
			{
				if (tempValueArray[j] == static_cast<float>(i))
				{
					tempValueArray[j] = static_cast<float>(-i);
					break;
				}
			}
		}
		/* oder Wegpunkt von Route 2 deaktivieren (durch negatives Vorzeichen kennzeichnen): */
		else
		{
			for (int32_t j = numVectorElementsMinus1; j < counter; j++)
			{
				if (tempValueArray[j] == static_cast<float>(i))
				{
					tempValueArray[j] = static_cast<float>(-i);
					break;
				}
			}
		}
	}

	/* Neue Route aus nicht deaktivierten Wegpunkten generieren: */

	pOutputVector[0] = 0.0f;
	pOutputVector[numVectorElementsMinus1] = 0.0f;

	int32_t counter2 = 1;
	//counter--;
	for (int32_t i = 1; i < counter; i++)
	{
		/* pos. Vorzeichen => nicht deaktivierter Wegpunkt: */
		if (tempValueArray[i] > 0.0f)
		{
			pOutputVector[counter2] = tempValueArray[i];
			counter2++;
		}
	}
}


static void Pathfinding_MutationFunction(CSimpleNeuron *pInOutNeuron, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	int32_t numDendrites = pInOutNeuron->NumOfDendriteElements;

	int32_t iDofMutatedPathElement = pRandomNumbers->Get_IntegerNumber(1, numDendrites - 1);

	float *pDendrite_FactorArray = pInOutNeuron->pDendrite_FactorArray;

	int32_t startID = static_cast<int32_t>(pDendrite_FactorArray[0]);
	int32_t destinationID = static_cast<int32_t>(pDendrite_FactorArray[numDendrites - 1]);

	do
	{
		int32_t waypontID = pRandomNumbers->Get_IntegerNumber(0, numDendrites);

		if (waypontID == startID)
			continue;
		if (waypontID == destinationID)
			continue;
		if (waypontID == static_cast<int32_t>(pDendrite_FactorArray[iDofMutatedPathElement]))
			continue;

		pDendrite_FactorArray[iDofMutatedPathElement] = static_cast<float>(waypontID);
		break;

	} while (true);
}

static void Pathfinding_MutationFunction2(CSimpleNeuron *pInOutNeuron, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	int32_t numWaypoints = pInOutNeuron->NumOfAdditionalMemoryValues;

	int32_t iDofMutatedPathElement = pRandomNumbers->Get_IntegerNumber(1, numWaypoints - 1);

	float *pAdditionalMemoryValueArray = pInOutNeuron->pAdditionalMemoryValueArray;

	int32_t startID = static_cast<int32_t>(pAdditionalMemoryValueArray[0]);
	int32_t destinationID = static_cast<int32_t>(pAdditionalMemoryValueArray[numWaypoints - 1]);

	do
	{
		int32_t waypontID = pRandomNumbers->Get_IntegerNumber(0, numWaypoints);

		if (waypontID == startID)
			continue;
		if (waypontID == destinationID)
			continue;
		if (waypontID == static_cast<int32_t>(pAdditionalMemoryValueArray[iDofMutatedPathElement]))
			continue;

		pAdditionalMemoryValueArray[iDofMutatedPathElement] = static_cast<float>(waypontID);
		break;

	} while (true);
}

static void Pathfinding_RecombinationFunction(CSimpleNeuron *pOffspring, const CSimpleNeuron *pParent1, const CSimpleNeuron *pParent2, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	float *pDendrite_FactorArray_Parent1 = pParent1->pDendrite_FactorArray;
	float *pDendrite_FactorArray_Parent2 = pParent2->pDendrite_FactorArray;
	float *pDendrite_FactorArray_Offspring = pOffspring->pDendrite_FactorArray;

	int32_t numDendrites = pOffspring->NumOfDendriteElements;
	int32_t numDendritesMinus1 = numDendrites - 1;

	for (int32_t i = 0; i < numDendrites; i++)
		pDendrite_FactorArray_Offspring[i] = pDendrite_FactorArray_Parent1[i];

	for (int32_t i = 1; i < numDendritesMinus1; i++)
	{
		if (pRandomNumbers->Get_IntegerNumber2(1, 2) == 2)
			pDendrite_FactorArray_Offspring[i] = pDendrite_FactorArray_Parent2[i];
	}
}

static void Pathfinding_RecombinationFunction2(CSimpleNeuron *pOffspring, const CSimpleNeuron *pParent1, const CSimpleNeuron *pParent2, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	float *pAdditionalMemoryValueArray_Parent1 = pParent1->pAdditionalMemoryValueArray;
	float *pAdditionalMemoryValueArray_Parent2 = pParent2->pAdditionalMemoryValueArray;
	float *pAdditionalMemoryValueArray_Offspring = pOffspring->pAdditionalMemoryValueArray;

	int32_t numWaypoints = pOffspring->NumOfAdditionalMemoryValues;
	int32_t numWaypointsMinus1 = numWaypoints - 1;

	for (int32_t i = 0; i < numWaypoints; i++)
		pAdditionalMemoryValueArray_Offspring[i] = pAdditionalMemoryValueArray_Parent1[i];

	for (int32_t i = 1; i < numWaypointsMinus1; i++)
	{
		if (pRandomNumbers->Get_IntegerNumber2(1, 2) == 2)
			pAdditionalMemoryValueArray_Offspring[i] = pAdditionalMemoryValueArray_Parent2[i];
	}
}

static void Get_Path(int32_t *pOutPath, int32_t *pOutNumWaypoints, const CSimpleNeuron *pNeuron)
{
	int32_t counter = 0;

	float *pDendrite_FactorArray = pNeuron->pDendrite_FactorArray;

	int32_t numDendritesMinus1 = pNeuron->NumOfDendriteElements - 1;

	int32_t id1, id2;

	for (int32_t i = 0; i < numDendritesMinus1; i++)
	{
		id1 = static_cast<int32_t>(pDendrite_FactorArray[i]);
		id2 = static_cast<int32_t>(pDendrite_FactorArray[i + 1]);

		if (id1 != id2)
		{
			pOutPath[counter] = id1;
			counter++;
		}
	}

	pOutPath[counter] = static_cast<int32_t>(pDendrite_FactorArray[numDendritesMinus1]);
	counter++;

	*pOutNumWaypoints = counter;
}

static void Get_Path2(int32_t *pOutPath, int32_t *pOutNumWaypoints, const CSimpleNeuron *pNeuron)
{
	int32_t counter = 0;

	float *pAdditionalMemoryValueArray = pNeuron->pAdditionalMemoryValueArray;

	int32_t numWaypointsMinus1 = pNeuron->NumOfAdditionalMemoryValues - 1;

	int32_t id1, id2;

	for (int32_t i = 0; i < numWaypointsMinus1; i++)
	{
		id1 = static_cast<int32_t>(pAdditionalMemoryValueArray[i]);
		id2 = static_cast<int32_t>(pAdditionalMemoryValueArray[i + 1]);

		if (id1 != id2)
		{
			pOutPath[counter] = id1;
			counter++;
		}
	}

	pOutPath[counter] = static_cast<int32_t>(pAdditionalMemoryValueArray[numWaypointsMinus1]);
	counter++;

	*pOutNumWaypoints = counter;
}

static void Get_Best_Path(int32_t *pOutPath, int32_t *pOutNumWaypoints, CSimpleNeuronPopulation *pPopulation)
{
	CSimpleNeuron *pBestNeuron = pPopulation->ppNeuronArray[pPopulation->IDArrayOfBestFittedBrains[0]];
	//int32_t num_Of_Dendrite_Elements = pBestNeuron->NumOfDendriteElements;

	int32_t counter = 0;

	float *pDendrite_FactorArray = pBestNeuron->pDendrite_FactorArray;

	int32_t numDendritesMinus1 = pBestNeuron->NumOfDendriteElements - 1;

	int32_t id1, id2;

	for (int32_t i = 0; i < numDendritesMinus1; i++)
	{
		id1 = static_cast<int32_t>(pDendrite_FactorArray[i]);
		id2 = static_cast<int32_t>(pDendrite_FactorArray[i + 1]);

		if (id1 != id2)
		{
			pOutPath[counter] = id1;
			counter++;
		}
	}

	pOutPath[counter] = static_cast<int32_t>(pDendrite_FactorArray[numDendritesMinus1]);
	counter++;

	*pOutNumWaypoints = counter;
}

static void Get_Best_Path2(int32_t *pOutPath, int32_t *pOutNumWaypoints, CSimpleNeuronPopulation *pPopulation)
{
	CSimpleNeuron *pBestNeuron = pPopulation->ppNeuronArray[pPopulation->IDArrayOfBestFittedBrains[0]];
	//int32_t numWaypoints = pBestNeuron->NumOfAdditionalMemoryValues;

	int32_t counter = 0;

	float *pAdditionalMemoryValueArray = pBestNeuron->pAdditionalMemoryValueArray;

	int32_t numWaypointsMinus1 = pBestNeuron->NumOfAdditionalMemoryValues - 1;

	int32_t id1, id2;

	for (int32_t i = 0; i < numWaypointsMinus1; i++)
	{
		id1 = static_cast<int32_t>(pAdditionalMemoryValueArray[i]);
		id2 = static_cast<int32_t>(pAdditionalMemoryValueArray[i + 1]);

		if (id1 != id2)
		{
			pOutPath[counter] = id1;
			counter++;
		}
	}

	pOutPath[counter] = static_cast<int32_t>(pAdditionalMemoryValueArray[numWaypointsMinus1]);
	counter++;

	*pOutNumWaypoints = counter;
}


static void Get_Path(int32_t *pOutPath, CSimpleNeuron *pNeuron)
{
	int32_t num_Of_Dendrite_Elements = pNeuron->NumOfDendriteElements;

	for (int32_t i = 0; i < num_Of_Dendrite_Elements; i++)
		pOutPath[i] = static_cast<int32_t>(pNeuron->pDendrite_FactorArray[i]);
}

static void Get_Path2(int32_t *pOutPath, CSimpleNeuron *pNeuron)
{
	int32_t numWaypoints = pNeuron->NumOfAdditionalMemoryValues;

	for (int32_t i = 0; i < numWaypoints; i++)
		pOutPath[i] = static_cast<int32_t>(pNeuron->pAdditionalMemoryValueArray[i]);
}

static void Get_Shortest_TSP_Path(int32_t *pOutPath, CSimpleNeuronPopulation *pPopulation)
{
	CSimpleNeuron *pBestNeuron = pPopulation->ppNeuronArray[pPopulation->IDArrayOfBestFittedBrains[0]];
	int32_t num_Of_Dendrite_Elements = pBestNeuron->NumOfDendriteElements;

	for (int32_t i = 0; i < num_Of_Dendrite_Elements; i++)
		pOutPath[i] = static_cast<int32_t>(pBestNeuron->pDendrite_FactorArray[i]);
}

static void Get_Shortest_TSP_Path2(int32_t *pOutPath, CSimpleNeuronPopulation *pPopulation)
{
	CSimpleNeuron *pBestNeuron = pPopulation->ppNeuronArray[pPopulation->IDArrayOfBestFittedBrains[0]];
	int32_t numWaypoints = pBestNeuron->NumOfAdditionalMemoryValues;

	for (int32_t i = 0; i < numWaypoints; i++)
		pOutPath[i] = static_cast<int32_t>(pBestNeuron->pAdditionalMemoryValueArray[i]);
}

/*
int main(void)
{
	static float adjacencyMatrix[16];
	static float reachabilityMatrix[16];
	static float tempMatrix1[16];
	static float tempMatrix2[16];
	static float tempMatrix3[16];

	adjacencyMatrix[0] = 0; adjacencyMatrix[1] = 1; adjacencyMatrix[2] = 0; adjacencyMatrix[3] = 0;
	adjacencyMatrix[4] = 1; adjacencyMatrix[5] = 0; adjacencyMatrix[6] = 1; adjacencyMatrix[7] = 0;
	adjacencyMatrix[8] = 0; adjacencyMatrix[9] = 0; adjacencyMatrix[10] = 0; adjacencyMatrix[11] = 1;
	adjacencyMatrix[12] = 0; adjacencyMatrix[13] = 0; adjacencyMatrix[14] = 1; adjacencyMatrix[15] = 0;

	for (int32_t iy = 0; iy < 4; iy++)
	{
		for (int32_t ix = 0; ix < 4; ix++)
		{
			cout << adjacencyMatrix[ix + iy * 4] << " ";
		}

		cout << endl;
	}

	cout << endl;

	int32_t counter = Calculate_ReachabilityMatrix(reachabilityMatrix, adjacencyMatrix, tempMatrix1, tempMatrix2, tempMatrix3, 4, 4);

	cout << counter << endl;

	for (int32_t iy = 0; iy < 4; iy++)
	{
		for (int32_t ix = 0; ix < 4; ix++)
		{
			cout << reachabilityMatrix[ix + iy * 4] << " ";
		}

		cout << endl;
	}

	getchar();
	return 0;
}
*/
/*
int main(void)
{
	float fValueArray[4];

	fValueArray[0] = 1.0f;
	fValueArray[1] = 2.0f;
	fValueArray[2] = 3.0f;
	fValueArray[3] = 4.0f;
	

	float *pfValueArray[4];

	pfValueArray[0] = &fValueArray[0];
	pfValueArray[1] = &fValueArray[1];
	pfValueArray[2] = nullptr;
	pfValueArray[3] = &fValueArray[3];


	for (int32_t i = 0; i < 4; i++)
	{
		if (pfValueArray[i] == nullptr)
		{
			continue;
		}

		cout << *pfValueArray[i] << endl;
	}

	float **ppf = pfValueArray;

	for (int32_t i = 0; i < 4; i++)
	{
		if (ppf[i] == nullptr)
		{
			continue;
		}

		cout << *ppf[i] << endl;
	}


	getchar();
	return 0;
}
*/

/*
int main(void)
{
	float fValueArray[7];

	fValueArray[0] = 0.0f;
	fValueArray[1] = 0.0f;
	fValueArray[2] = 0.0f;
	fValueArray[3] = 0.0f;
	fValueArray[4] = 0.0f;
	fValueArray[5] = 0.0f;
	fValueArray[6] = 0.0f;

	cout << BinaryToDecimal(fValueArray, 7) << endl;

	fValueArray[0] = 0.0f;
	fValueArray[1] = 0.0f;
	fValueArray[2] = 0.0f;
	fValueArray[3] = 0.0f;
	fValueArray[4] = 0.0f;
	fValueArray[5] = 0.0f;
	fValueArray[6] = 1.0f;

	cout << BinaryToDecimal(fValueArray, 7) << endl;

	fValueArray[0] = 0.0f;
	fValueArray[1] = 0.0f;
	fValueArray[2] = 0.0f;
	fValueArray[3] = 0.0f;
	fValueArray[4] = 0.0f;
	fValueArray[5] = 1.0f;
	fValueArray[6] = 0.0f;

	cout << BinaryToDecimal(fValueArray, 7) << endl;

	fValueArray[0] = 0.0f;
	fValueArray[1] = 0.0f;
	fValueArray[2] = 0.0f;
	fValueArray[3] = 0.0f;
	fValueArray[4] = 0.0f;
	fValueArray[5] = 1.0f;
	fValueArray[6] = 1.0f;

	cout << BinaryToDecimal(fValueArray, 7) << endl;


	fValueArray[0] = 1.0f;
	fValueArray[1] = 0.0f;
	fValueArray[2] = 0.0f;
	fValueArray[3] = 0.0f;
	fValueArray[4] = 0.0f;
	fValueArray[5] = 0.0f;
	fValueArray[6] = 0.0f;

	cout << BinaryToDecimal(fValueArray, 7) << endl;

	fValueArray[0] = 1.0f;
	fValueArray[1] = 1.0f;
	fValueArray[2] = 1.0f;
	fValueArray[3] = 1.0f;
	fValueArray[4] = 1.0f;
	fValueArray[5] = 1.0f;
	fValueArray[6] = 1.0f;

	cout << BinaryToDecimal(fValueArray, 7) << endl << endl;

	float iValueArray[7];

	DecimalToBinary(iValueArray, 7, 0);

	for (int32_t i = 0; i < 7; i++)
	{
		cout << iValueArray[i] << " ";
	}
	cout << endl;

	DecimalToBinary(iValueArray, 7, 1);

	for (int32_t i = 0; i < 7; i++)
	{
		cout << iValueArray[i] << " ";
	}
	cout << endl;

	DecimalToBinary(iValueArray, 7, 2);

	for (int32_t i = 0; i < 7; i++)
	{
		cout << iValueArray[i] << " ";
	}
	cout << endl;

	DecimalToBinary(iValueArray, 7, 3);

	for (int32_t i = 0; i < 7; i++)
	{
		cout << iValueArray[i] << " ";
	}
	cout << endl;

	DecimalToBinary(iValueArray, 7, 64);

	for (int32_t i = 0; i < 7; i++)
	{
		cout << iValueArray[i] << " ";
	}
	cout << endl;

	DecimalToBinary(iValueArray, 7, 127);

	for (int32_t i = 0; i < 7; i++)
	{
		cout << iValueArray[i] << " ";
	}
	cout << endl;


	getchar();
	return 0;
}
*/

/*
int main(void)
{
	static constexpr int32_t ConstPrecedingNeuron_NumOfInputDendrites = 3; // 2 + Bias
	static constexpr int32_t ConstPrecedingNeuron_NumOfOutputDendrites = 10;
	static constexpr int32_t ConstPrecedingNeuron_NumOfAdditionalMemoryValues = ConstPrecedingNeuron_NumOfInputDendrites * ConstPrecedingNeuron_NumOfOutputDendrites;

	static constexpr int32_t ConstNumOfInputArrays = 4;

	CRandomNumbersNN RandomNumbers;

	static float RandomPlasticityArray[ConstPrecedingNeuron_NumOfAdditionalMemoryValues];
	Init_RandomNumbersTableExt2(RandomPlasticityArray, ConstPrecedingNeuron_NumOfAdditionalMemoryValues, &RandomNumbers, -1.0f, 1.0f, 0.5f);

	float InputArray1[2] = { 0.0f, 0.0f };
	float InputArray2[2] = { 1.0f, 0.0f };
	float InputArray3[2] = { 0.0f, 1.0f };
	float InputArray4[2] = { 1.0f, 1.0f };

	float *pInputArrayPointer[ConstNumOfInputArrays];

	pInputArrayPointer[0] = InputArray1;
	pInputArrayPointer[1] = InputArray2;
	pInputArrayPointer[2] = InputArray3;
	pInputArrayPointer[3] = InputArray4;

	float DesiredXOROutputArray[ConstNumOfInputArrays] = {0.0f, 1.0f, 1.0f, 0.0f};



	CSimpleNeuron PrecedingNeuron;
	CSimpleNeuron Neuron_XOR;

	PrecedingNeuron.Init_Dendrite_Arrays(ConstPrecedingNeuron_NumOfInputDendrites + ConstPrecedingNeuron_NumOfOutputDendrites);
	PrecedingNeuron.Set_InputDendriteInfo(0, ConstPrecedingNeuron_NumOfInputDendrites);
	PrecedingNeuron.Set_OutputDendriteInfo(ConstPrecedingNeuron_NumOfInputDendrites, ConstPrecedingNeuron_NumOfOutputDendrites);
	PrecedingNeuron.Set_DendriticFunction(LogicFunctionApproximationDendriticFunction);
	PrecedingNeuron.Init_AdditionalMemoryValues(RandomPlasticityArray, ConstPrecedingNeuron_NumOfAdditionalMemoryValues);
	


	Neuron_XOR.Init_Dendrite_Arrays(ConstPrecedingNeuron_NumOfOutputDendrites);
	Neuron_XOR.Use_OtherNeuron_Dendrite_DataArray(PrecedingNeuron.pDendrite_DataArray, ConstPrecedingNeuron_NumOfInputDendrites);
	Neuron_XOR.Set_ActivationFunction(LogicFunctionApproximationOutputFunction);
	Neuron_XOR.Randomize_Dendrite_Factors(&RandomNumbers, -0.2f, 0.2f);

	int32_t maxCount = 400000;
	int32_t epoch = 0;
	float errorSum;

	for (int32_t j = 0; j < maxCount; j++)
	{
		epoch++;
		errorSum = 0.0f;

		for (int32_t i = 0; i < ConstNumOfInputArrays; i++)
		{
			PrecedingNeuron.Set_Dendrite_NeuronInput(pInputArrayPointer[i], 2);
			PrecedingNeuron.Execute_DendriticCalculations();
			Neuron_XOR.Calculate_NeuronOutput();

			//errorSum += Neuron_XOR.Adjust_Dendrite_Factors_ExternalInput(DesiredXOROutputArray[i], 0.2f, 1.0f, 0.005f);

			errorSum += Neuron_XOR.Calculate_Error(DesiredXOROutputArray[i], 1.0f, 1.0f);
			PrecedingNeuronLearning(&PrecedingNeuron, &Neuron_XOR, 0.2f, 1.0f, 1.0f);
			Neuron_XOR.Adjust_Dendrite_Factors_AfterErrorCalculations_ExternalInput(0.2f);
		}

		if (errorSum < 0.0001f)
			break;
	}

	// training completed

	// training statistics:


	cout << "epoch: " << epoch << endl;
	cout << "error: " << errorSum << endl << endl;

	cout << endl;

	for (int32_t i = 0; i < ConstNumOfInputArrays; i++)
	{
		PrecedingNeuron.Set_Dendrite_NeuronInput(pInputArrayPointer[i], 2);
		PrecedingNeuron.Execute_DendriticCalculations();
		Neuron_XOR.Calculate_NeuronOutput();

		cout << "input values: " << pInputArrayPointer[i][0] << " " << pInputArrayPointer[i][1] << endl;
		cout << "activation value: " << Neuron_XOR.ActivationValue << endl << endl;
	}

	float *pBestMatchedInputArray = nullptr;

	float TestInputArray1[2] = { 0.1f, 0.9f };

	Find_BestMatchedVectorFromList(&pBestMatchedInputArray, TestInputArray1, 2, pInputArrayPointer, ConstNumOfInputArrays);

	PrecedingNeuron.Set_Dendrite_NeuronInput(pBestMatchedInputArray, 2);
	PrecedingNeuron.Execute_DendriticCalculations();
	Neuron_XOR.Calculate_NeuronOutput();

	cout << "input values: " << TestInputArray1[0] << " " << TestInputArray1[1] << endl;
	cout << "best mached input values: " << pBestMatchedInputArray[0] << " " << pBestMatchedInputArray[1] << endl;
	cout << "activation value: " << Neuron_XOR.ActivationValue << endl << endl;

	////////////////

	cout << "press enter: ";
	getchar();
	cout << endl;

	float DesiredOutputArray2[ConstNumOfInputArrays] = { 1.0f, 0.0f, 1.0f, 0.0f };

	CSimpleNeuron Neuron2;

	Neuron2.Init_Dendrite_Arrays(10);
	Neuron2.Use_OtherNeuron_Dendrite_DataArray(PrecedingNeuron.pDendrite_DataArray, 3);
	Neuron2.Set_ActivationFunction(LogicFunctionApproximationOutputFunction);
	Neuron2.Randomize_Dendrite_Factors(&RandomNumbers, -0.2f, 0.2f);

	maxCount = 400000;
	epoch = 0;
	errorSum;

	for (int32_t j = 0; j < maxCount; j++)
	{
		epoch++;
		errorSum = 0.0f;

		for (int32_t i = 0; i < ConstNumOfInputArrays; i++)
		{
			PrecedingNeuron.Set_Dendrite_NeuronInput(pInputArrayPointer[i], 2);
			PrecedingNeuron.Execute_DendriticCalculations();
			Neuron2.Calculate_NeuronOutput();
			errorSum += Neuron2.Adjust_Dendrite_Factors_ExternalInput(DesiredOutputArray2[i], 0.2f, 1.0f, 0.005f);
		}

		if (errorSum < 0.0001f)
			break;
	}

	// training completed

	// training statistics:


	cout << "epoch: " << epoch << endl;
	cout << "error: " << errorSum << endl << endl;

	cout << endl;

	for (int32_t i = 0; i < ConstNumOfInputArrays; i++)
	{
		PrecedingNeuron.Set_Dendrite_NeuronInput(pInputArrayPointer[i], 2);
		PrecedingNeuron.Execute_DendriticCalculations();
		Neuron2.Calculate_NeuronOutput();

		cout << "input values: " << pInputArrayPointer[i][0] << " " << pInputArrayPointer[i][1] << endl;
		cout << "activation value: " << Neuron2.ActivationValue << endl << endl;
	}

	////////////////

	getchar();
	return 0;
}
*/

/*
int main(void)
{
	static constexpr int32_t ConstPrecedingNeuron_NumOfInputDendrites = 3; // 2 + Bias
	static constexpr int32_t ConstPrecedingNeuron_NumOfOutputDendrites = 10;
	static constexpr int32_t ConstPrecedingNeuron_NumOfAdditionalMemoryValues = ConstPrecedingNeuron_NumOfInputDendrites * ConstPrecedingNeuron_NumOfOutputDendrites;

	static constexpr int32_t ConstNumOfInputArrays = 6;

	float InputArray1[2] = { 1.2f, 0.7f };
	float InputArray2[2] = { -0.3f, 0.5f };
	float InputArray3[2] = { -3.0f, -1.0f };
	float InputArray4[2] = { 0.1f, 1.0f };
	float InputArray5[2] = { 3.0f, 1.1f };
	float InputArray6[2] = { 2.1f, -3.0f };

	float *pInputArrayPointer[ConstNumOfInputArrays];

	pInputArrayPointer[0] = InputArray1;
	pInputArrayPointer[1] = InputArray2;
	pInputArrayPointer[2] = InputArray3;
	pInputArrayPointer[3] = InputArray4;
	pInputArrayPointer[4] = InputArray5;
	pInputArrayPointer[5] = InputArray6;


	float DesiredOutputArray[ConstNumOfInputArrays] = { 1.0f, -1.0f, 1.0f, -1.0f, -1.0f, 1.0f };

	

	CRandomNumbersNN RandomNumbers;


	static float RandomPlasticityArray[ConstPrecedingNeuron_NumOfAdditionalMemoryValues];
	Init_RandomNumbersTableExt2(RandomPlasticityArray, ConstPrecedingNeuron_NumOfAdditionalMemoryValues, &RandomNumbers, -1.0f, 1.0f, 0.5f);

	CSimpleNeuron PrecedingNeuron;
	CSimpleNeuron Neuron;

	PrecedingNeuron.Init_Dendrite_Arrays(ConstPrecedingNeuron_NumOfInputDendrites + ConstPrecedingNeuron_NumOfOutputDendrites);
	PrecedingNeuron.Set_InputDendriteInfo(0, ConstPrecedingNeuron_NumOfInputDendrites);
	PrecedingNeuron.Set_OutputDendriteInfo(ConstPrecedingNeuron_NumOfInputDendrites, ConstPrecedingNeuron_NumOfOutputDendrites);
	PrecedingNeuron.Set_DendriticFunction(LogicFunctionApproximationDendriticFunction);
	PrecedingNeuron.Init_AdditionalMemoryValues(RandomPlasticityArray, ConstPrecedingNeuron_NumOfAdditionalMemoryValues);

	Neuron.Init_Dendrite_Arrays(ConstPrecedingNeuron_NumOfOutputDendrites);
	Neuron.Use_OtherNeuron_Dendrite_DataArray(PrecedingNeuron.pDendrite_DataArray, PrecedingNeuron.FirstOutputDendriteID);
	Neuron.Set_ActivationFunction(LogicFunctionApproximationOutputFunction);
	Neuron.Randomize_Dendrite_Factors(&RandomNumbers, -0.2f, 0.2f);

	int32_t maxCount = 400000;
	int32_t epoch = 0;
	float errorSum;

	for (int32_t j = 0; j < maxCount; j++)
	{
		epoch++;
		errorSum = 0.0f;

		for (int32_t i = 0; i < ConstNumOfInputArrays; i++)
		{
			PrecedingNeuron.Set_Dendrite_NeuronInput(pInputArrayPointer[i], 2);
			PrecedingNeuron.Execute_DendriticCalculations();
			Neuron.Calculate_NeuronOutput();
			//errorSum += Neuron.Adjust_Dendrite_Factors_ExternalInput(DesiredOutputArray[i], 0.2f, 1.0f, 0.005f);

			errorSum += Neuron.Calculate_Error(DesiredOutputArray[i], 1.0f, 0.5f);
			PrecedingNeuronLearning(&PrecedingNeuron, &Neuron, 0.2f, 1.0f, 1.0f);
			Neuron.Adjust_Dendrite_Factors_AfterErrorCalculations_ExternalInput(0.1f);
		}

		if (errorSum < 0.0001f)
			break;

		if (epoch % 100 == 0)
		{
			cout << "epoch: " << epoch << endl;
			cout << "error: " << errorSum << endl << endl;
		}
	}

	// training completed

	// training statistics:


	cout << "epoch: " << epoch << endl;
	cout << "error: " << errorSum << endl << endl;

	cout << endl;

	for (int32_t i = 0; i < ConstNumOfInputArrays; i++)
	{
		PrecedingNeuron.Set_Dendrite_NeuronInput(pInputArrayPointer[i], 2);
		PrecedingNeuron.Execute_DendriticCalculations();
		Neuron.Calculate_NeuronOutput();

		cout << "input values: " << pInputArrayPointer[i][0] << " " << pInputArrayPointer[i][1] << endl;
		cout << "activation value: " << Neuron.ActivationValue << endl << endl;
	}

	float *pBestMatchedInputArray = nullptr;

	float TestInputArray1[2] = { 0.1f, 0.9f };

	Find_BestMatchedVectorFromList(&pBestMatchedInputArray, TestInputArray1, 2, pInputArrayPointer, ConstNumOfInputArrays);

	//PrecedingNeuron.Set_Dendrite_NeuronInput(pBestMatchedInputArray, 2);
	PrecedingNeuron.Set_Dendrite_NeuronInput(TestInputArray1, 2);
	PrecedingNeuron.Execute_DendriticCalculations();
	Neuron.Calculate_NeuronOutput();

	cout << "input values: " << TestInputArray1[0] << " " << TestInputArray1[1] << endl;
	cout << "best mached input values: " << pBestMatchedInputArray[0] << " " << pBestMatchedInputArray[1] << endl;
	cout << "activation value: " << Neuron.ActivationValue << endl << endl;

	

	getchar();
	return 0;
}
*/

/*
int main(void)
{
	static constexpr int32_t ConstPrecedingNeuron_NumOfInputDendrites = 3; // 2 + Bias

	// NumOfHiddenDendrites:
	static constexpr int32_t ConstPrecedingNeuron_NumOfOutputDendrites = 10; 
	static constexpr int32_t ConstPrecedingNeuron_NumOfAdditionalMemoryValues = ConstPrecedingNeuron_NumOfInputDendrites * ConstPrecedingNeuron_NumOfOutputDendrites;

	static constexpr int32_t ConstNumOfInputArrays = 6;

	float InputArray1[2] = { 1.2f, 0.7f };
	float InputArray2[2] = { -0.3f, 0.5f };
	float InputArray3[2] = { -3.0f, -1.0f };
	float InputArray4[2] = { 0.1f, 1.0f };
	float InputArray5[2] = { 3.0f, 1.1f };
	float InputArray6[2] = { 2.1f, -3.0f };

	float *pInputArrayPointer[ConstNumOfInputArrays];

	pInputArrayPointer[0] = InputArray1;
	pInputArrayPointer[1] = InputArray2;
	pInputArrayPointer[2] = InputArray3;
	pInputArrayPointer[3] = InputArray4;
	pInputArrayPointer[4] = InputArray5;
	pInputArrayPointer[5] = InputArray6;


	float DesiredOutputArray[ConstNumOfInputArrays] = { 1.0f, -1.0f, 1.0f, -1.0f, -1.0f, 1.0f };



	CRandomNumbersNN RandomNumbers;


	static float RandomPlasticityArray[ConstPrecedingNeuron_NumOfAdditionalMemoryValues];
	Init_RandomNumbersTableExt2(RandomPlasticityArray, ConstPrecedingNeuron_NumOfAdditionalMemoryValues, &RandomNumbers, -1.0f, 1.0f, 0.5f);

	
	CSimpleNeuralNet_1HiddenLayer NeuralNet;

	NeuralNet.Init_PrecedingNeuron(ConstPrecedingNeuron_NumOfInputDendrites, ConstPrecedingNeuron_NumOfOutputDendrites, LogicFunctionApproximationDendriticFunction, RandomPlasticityArray, ConstPrecedingNeuron_NumOfAdditionalMemoryValues);

	NeuralNet.Init_OutputNeuronArray(1, ConstPrecedingNeuron_NumOfOutputDendrites, LogicFunctionApproximationOutputFunction, &RandomNumbers, -0.2f, 0.2f);


	int32_t maxCount = 400000;
	int32_t epoch = 0;
	float errorSum;

	for (int32_t j = 0; j < maxCount; j++)
	{
		epoch++;
		errorSum = 0.0f;

		for (int32_t i = 0; i < ConstNumOfInputArrays; i++)
		{
			NeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(pInputArrayPointer[i], 2);
			NeuralNet.Calculate_Output();

			// extreme learning:
			errorSum += NeuralNet.OutputNeurons_Adjust_Dendrite_Factors(&DesiredOutputArray[i], 0.2f, 1.0f, 0.005f);
			
			// normal learning:
			//errorSum += NeuralNet.OutputNeurons_ErrorCalculations(&DesiredOutputArray[i], 1.0f, 0.5f);
			//PrecedingNeuronLearning(&NeuralNet.PrecedingNeuron, &NeuralNet.pOutputNeuronArray[0], 0.2f, 1.0f, 1.0f);
			//NeuralNet.OutputNeurons_Adjust_Dendrite_Factors_AfterErrorCalculations(0.1f);
		}

		if (errorSum < 0.0001f)
			break;

		if (epoch % 100 == 0)
		{
			cout << "epoch: " << epoch << endl;
			cout << "error: " << errorSum << endl << endl;
		}
	}

	// training completed

	// training statistics:


	cout << "epoch: " << epoch << endl;
	cout << "error: " << errorSum << endl << endl;

	cout << endl;

	for (int32_t i = 0; i < ConstNumOfInputArrays; i++)
	{
		NeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(pInputArrayPointer[i], 2);
		NeuralNet.Calculate_Output();

		cout << "input values: " << pInputArrayPointer[i][0] << " " << pInputArrayPointer[i][1] << endl;
		cout << "activation value: " << NeuralNet.pOutputNeuronArray[0].ActivationValue << endl << endl;
	}

	float *pBestMatchedInputArray = nullptr;

	float TestInputArray1[2] = { 0.1f, 0.9f };

	Find_BestMatchedVectorFromList(&pBestMatchedInputArray, TestInputArray1, 2, pInputArrayPointer, ConstNumOfInputArrays);


	//NeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(pBestMatchedInputArray, 2);
	NeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(TestInputArray1, 2);
	NeuralNet.Calculate_Output();

	cout << "input values: " << TestInputArray1[0] << " " << TestInputArray1[1] << endl;
	cout << "best mached input values: " << pBestMatchedInputArray[0] << " " << pBestMatchedInputArray[1] << endl;
	cout << "activation value: " << NeuralNet.pOutputNeuronArray[0].ActivationValue << endl << endl;



	getchar();
	return 0;
}
*/

/*
int main(void)
{
	static constexpr int32_t ConstPrecedingNeuron_NumOfInputDendrites = 3; // 2 + Bias

	// NumOfHiddenDendrites:
	static constexpr int32_t ConstPrecedingNeuron_NumOfOutputDendrites = 80;
	static constexpr int32_t ConstPrecedingNeuron_NumOfAdditionalMemoryValues = ConstPrecedingNeuron_NumOfInputDendrites * ConstPrecedingNeuron_NumOfOutputDendrites;

	static constexpr int32_t ConstNumOfInputArrays = 4;

	float InputArray1[2] = { 1.0f, 0.0f };
	float InputArray2[2] = { 0.0f, 1.0f };
	float InputArray3[2] = { 0.0f, 0.0f };
	float InputArray4[2] = { 1.0f, 1.0f };
	

	float *pInputArrayPointer[ConstNumOfInputArrays];

	pInputArrayPointer[0] = InputArray1;
	pInputArrayPointer[1] = InputArray2;
	pInputArrayPointer[2] = InputArray3;
	pInputArrayPointer[3] = InputArray4;
	


	float DesiredOutputArray[ConstNumOfInputArrays] = { 1.0f, 1.0f, 0.0f, 0.0f };



	CRandomNumbersNN RandomNumbers;


	static float RandomPlasticityArray[ConstPrecedingNeuron_NumOfAdditionalMemoryValues];
	Init_RandomNumbersTableExt2(RandomPlasticityArray, ConstPrecedingNeuron_NumOfAdditionalMemoryValues, &RandomNumbers, -1.0f, 1.0f, 0.5f);


	CSimpleNeuralNet_1HiddenLayer NeuralNet;

	//NeuralNet.Init_PrecedingNeuron(ConstPrecedingNeuron_NumOfInputDendrites, ConstPrecedingNeuron_NumOfOutputDendrites, LogicFunctionApproximationDendriticFunction, RandomPlasticityArray, ConstPrecedingNeuron_NumOfAdditionalMemoryValues);

	NeuralNet.Init_PrecedingNeuron(ConstPrecedingNeuron_NumOfInputDendrites, ConstPrecedingNeuron_NumOfOutputDendrites, LogicFunctionApproximationDendriticFunction, &RandomNumbers, -1.0f, 1.0f);

	NeuralNet.Init_OutputNeuronArray(1, ConstPrecedingNeuron_NumOfOutputDendrites, LogicFunctionApproximationOutputFunction, &RandomNumbers, -0.2f, 0.2f);


	static constexpr int32_t ConstNumOfInputSamples = 40 * ConstNumOfInputArrays;

	int32_t maxCount = 20000;
	int32_t epoch = 0;
	float errorSum;

	float tempInputArray[2];

	for (int32_t j = 0; j < maxCount; j++)
	{
		epoch++;
		errorSum = 0.0f;

		for (int32_t i = 0; i < ConstNumOfInputSamples; i++)
		{
			int32_t k = i % ConstNumOfInputArrays;
			
			if(RandomNumbers.Get_IntegerNumber2(2, 3) == 2)
				tempInputArray[0] = pInputArrayPointer[k][0] + RandomNumbers.Get_FloatNumber(-0.45f, 0.45f, 0.1f);
			else
				tempInputArray[0] = pInputArrayPointer[k][0] + RandomNumbers.Get_FloatNumber(-0.45f, 0.45f, -0.1f);

			if (RandomNumbers.Get_IntegerNumber2(2, 3) == 2)
				tempInputArray[1] = pInputArrayPointer[k][1] + RandomNumbers.Get_FloatNumber(-0.45f, 0.45f, 0.1f);
			else
				tempInputArray[1] = pInputArrayPointer[k][1] + RandomNumbers.Get_FloatNumber(-0.45f, 0.45f, -0.1f);

			NeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(tempInputArray, 2);
			NeuralNet.Calculate_Output();
			
			errorSum += NeuralNet.OutputNeurons_ErrorCalculations(&DesiredOutputArray[k], 1.0f, 0.5f);
			PrecedingNeuronLearning(&NeuralNet.PrecedingNeuron, &NeuralNet.pOutputNeuronArray[0], 0.005f, 1.0f, 1.0f);
			NeuralNet.OutputNeurons_Adjust_Dendrite_Factors_AfterErrorCalculations(0.0025f);
		}

		//if (errorSum < 0.0001f)
			//break;

		if (epoch % 500 == 0)
		{
			cout << "epoch: " << epoch << endl;
			cout << "error: " << errorSum << endl << endl;
		}
	}

	// training completed

	// training statistics:


	cout << "epoch: " << epoch << endl;
	cout << "error: " << errorSum << endl << endl;

	cout << endl;

	for (int32_t i = 0; i < ConstNumOfInputArrays; i++)
	{
		NeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(pInputArrayPointer[i], 2);
		NeuralNet.Calculate_Output();

		cout << "input values: " << pInputArrayPointer[i][0] << " " << pInputArrayPointer[i][1] << endl;
		cout << "activation value: " << NeuralNet.pOutputNeuronArray[0].ActivationValue << endl << endl;
	}

	float *pBestMatchedInputArray = nullptr;

	float TestInputArray1[2] = { 0.1f, 0.9f };

	Find_BestMatchedVectorFromList(&pBestMatchedInputArray, TestInputArray1, 2, pInputArrayPointer, ConstNumOfInputArrays);


	//NeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(pBestMatchedInputArray, 2);
	NeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(TestInputArray1, 2);
	NeuralNet.Calculate_Output();

	cout << "input values: " << TestInputArray1[0] << " " << TestInputArray1[1] << endl;
	cout << "best mached input values: " << pBestMatchedInputArray[0] << " " << pBestMatchedInputArray[1] << endl;
	cout << "activation value: " << NeuralNet.pOutputNeuronArray[0].ActivationValue << endl << endl;

	float TestInputArray2[2] = { 1.4f, 0.4f };

	Find_BestMatchedVectorFromList(&pBestMatchedInputArray, TestInputArray2, 2, pInputArrayPointer, ConstNumOfInputArrays);

	//NeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(pBestMatchedInputArray, 2);
	NeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(TestInputArray2, 2);
	NeuralNet.Calculate_Output();

	cout << "input values: " << TestInputArray2[0] << " " << TestInputArray2[1] << endl;
	cout << "best mached input values: " << pBestMatchedInputArray[0] << " " << pBestMatchedInputArray[1] << endl;
	cout << "activation value: " << NeuralNet.pOutputNeuronArray[0].ActivationValue << endl << endl;
	
	float TestInputArray3[2] = { 0.3f, 0.1f };

	Find_BestMatchedVectorFromList(&pBestMatchedInputArray, TestInputArray3, 2, pInputArrayPointer, ConstNumOfInputArrays);

	//NeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(pBestMatchedInputArray, 2);
	NeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(TestInputArray3, 2);
	NeuralNet.Calculate_Output();

	cout << "input values: " << TestInputArray3[0] << " " << TestInputArray3[1] << endl;
	cout << "best mached input values: " << pBestMatchedInputArray[0] << " " << pBestMatchedInputArray[1] << endl;
	cout << "activation value: " << NeuralNet.pOutputNeuronArray[0].ActivationValue << endl << endl;

	float TestInputArray4[2] = { 0.8f, 0.9f };

	Find_BestMatchedVectorFromList(&pBestMatchedInputArray, TestInputArray4, 2, pInputArrayPointer, ConstNumOfInputArrays);

	//NeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(pBestMatchedInputArray, 2);
	NeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(TestInputArray4, 2);
	NeuralNet.Calculate_Output();

	cout << "input values: " << TestInputArray4[0] << " " << TestInputArray4[1] << endl;
	cout << "best mached input values: " << pBestMatchedInputArray[0] << " " << pBestMatchedInputArray[1] << endl;
	cout << "activation value: " << NeuralNet.pOutputNeuronArray[0].ActivationValue << endl << endl;


	getchar();
	return 0;
}
*/

/*
int main(void)
{
	static constexpr int32_t ConstPrecedingNeuron_NumOfInputDendrites = 3; // 2 + Bias

	// NumOfHiddenDendrites:
	//static constexpr int32_t ConstPrecedingNeuron_NumOfOutputDendrites = 80;
	// NumOfHiddenDendrites:
	static constexpr int32_t ConstPrecedingNeuron_NumOfOutputDendrites = 100;

	static constexpr int32_t ConstPrecedingNeuron_NumOfAdditionalMemoryValues = ConstPrecedingNeuron_NumOfInputDendrites * ConstPrecedingNeuron_NumOfOutputDendrites;

	static constexpr int32_t ConstNumOfInputArrays = 4;

	float InputArray1[2] = { 1.0f, 0.0f };
	float InputArray2[2] = { 0.0f, 1.0f };
	float InputArray3[2] = { 0.0f, 0.0f };
	float InputArray4[2] = { 1.0f, 1.0f };


	float *pInputArrayPointer[ConstNumOfInputArrays];

	pInputArrayPointer[0] = InputArray1;
	pInputArrayPointer[1] = InputArray2;
	pInputArrayPointer[2] = InputArray3;
	pInputArrayPointer[3] = InputArray4;


	CRandomNumbersNN RandomNumbers;


	static float RandomPlasticityArray[ConstPrecedingNeuron_NumOfAdditionalMemoryValues];
	Init_RandomNumbersTableExt2(RandomPlasticityArray, ConstPrecedingNeuron_NumOfAdditionalMemoryValues, &RandomNumbers, -1.0f, 1.0f, 0.5f);


	CSimpleNeuralNet_1HiddenLayer NeuralNet;

	//NeuralNet.Init_PrecedingNeuron(ConstPrecedingNeuron_NumOfInputDendrites, ConstPrecedingNeuron_NumOfOutputDendrites, LogicFunctionApproximationDendriticFunction, RandomPlasticityArray, ConstPrecedingNeuron_NumOfAdditionalMemoryValues);

	NeuralNet.Init_PrecedingNeuron(ConstPrecedingNeuron_NumOfInputDendrites, ConstPrecedingNeuron_NumOfOutputDendrites, LogicFunctionApproximationDendriticFunction, &RandomNumbers, -1.0f, 1.0f);

	NeuralNet.Init_OutputNeuronArray(2, ConstPrecedingNeuron_NumOfOutputDendrites, LogicFunctionApproximationOutputFunction, &RandomNumbers, -0.2f, 0.2f);


	static constexpr int32_t ConstNumOfInputSamples = 40 * ConstNumOfInputArrays;
	

	int32_t maxCount = 4000;
	int32_t epoch = 0;
	float errorSum;

	float tempInputArray[2];

	for (int32_t j = 0; j < maxCount; j++)
	{
		epoch++;
		errorSum = 0.0f;

		for (int32_t i = 0; i < ConstNumOfInputSamples; i++)
		{
			int32_t k = i % ConstNumOfInputArrays;
			//int32_t k = i % 2;

			if (RandomNumbers.Get_IntegerNumber2(2, 3) == 2)
				tempInputArray[0] = pInputArrayPointer[k][0] + RandomNumbers.Get_FloatNumber(-0.45f, 0.45f, 0.1f);
			else
				tempInputArray[0] = pInputArrayPointer[k][0] + RandomNumbers.Get_FloatNumber(-0.45f, 0.45f, -0.1f);

			if (RandomNumbers.Get_IntegerNumber2(2, 3) == 2)
				tempInputArray[1] = pInputArrayPointer[k][1] + RandomNumbers.Get_FloatNumber(-0.45f, 0.45f, 0.1f);
			else
				tempInputArray[1] = pInputArrayPointer[k][1] + RandomNumbers.Get_FloatNumber(-0.45f, 0.45f, -0.1f);

			NeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(tempInputArray, 2);
			NeuralNet.Calculate_Output();

			errorSum += NeuralNet.OutputNeurons_ErrorCalculations(pInputArrayPointer[k], 1.0f, 0.5f);
			//errorSum += NeuralNet.OutputNeurons_ErrorCalculations(tempInputArray, 1.0f, 0.5f);
			PrecedingNeuronLearning(&NeuralNet.PrecedingNeuron, &NeuralNet.pOutputNeuronArray[0], 2, 0.005f, 1.0f, 1.0f);
			NeuralNet.OutputNeurons_Adjust_Dendrite_Factors_AfterErrorCalculations(0.0025f);
		}

		//if (errorSum < 0.0001f)
		//break;

		if (epoch % 500 == 0)
		{
			cout << "epoch: " << epoch << endl;
			cout << "error: " << errorSum << endl << endl;
		}
	}

	// training completed

	// training statistics:


	cout << "epoch: " << epoch << endl;
	cout << "error: " << errorSum << endl << endl;

	cout << endl;

	for (int32_t i = 0; i < ConstNumOfInputArrays; i++)
	{
		NeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(pInputArrayPointer[i], 2);
		NeuralNet.Calculate_Output();

		cout << "input values: " << pInputArrayPointer[i][0] << " " << pInputArrayPointer[i][1] << endl;
		cout << "activation values: " << NeuralNet.pOutputNeuronArray[0].ActivationValue << " "
			 << NeuralNet.pOutputNeuronArray[1].ActivationValue <<  endl << endl;
	}

	float *pBestMatchedInputArray = nullptr;

	float TestInputArray1[2] = { 0.1f, 0.9f };

	Find_BestMatchedVectorFromList(&pBestMatchedInputArray, TestInputArray1, 2, pInputArrayPointer, ConstNumOfInputArrays);


	//NeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(pBestMatchedInputArray, 2);
	NeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(TestInputArray1, 2);
	NeuralNet.Calculate_Output();

	cout << "input values: " << TestInputArray1[0] << " " << TestInputArray1[1] << endl;
	cout << "best mached input values: " << pBestMatchedInputArray[0] << " " << pBestMatchedInputArray[1] << endl;
	cout << "activation values: " << NeuralNet.pOutputNeuronArray[0].ActivationValue << " "
		<< NeuralNet.pOutputNeuronArray[1].ActivationValue << endl << endl;

	float TestInputArray2[2] = { 1.4f, 0.4f };

	Find_BestMatchedVectorFromList(&pBestMatchedInputArray, TestInputArray2, 2, pInputArrayPointer, ConstNumOfInputArrays);

	//NeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(pBestMatchedInputArray, 2);
	NeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(TestInputArray2, 2);
	NeuralNet.Calculate_Output();

	cout << "input values: " << TestInputArray2[0] << " " << TestInputArray2[1] << endl;
	cout << "best mached input values: " << pBestMatchedInputArray[0] << " " << pBestMatchedInputArray[1] << endl;
	cout << "activation values: " << NeuralNet.pOutputNeuronArray[0].ActivationValue << " "
		<< NeuralNet.pOutputNeuronArray[1].ActivationValue << endl << endl;

	float TestInputArray3[2] = { 0.3f, 0.1f };

	Find_BestMatchedVectorFromList(&pBestMatchedInputArray, TestInputArray3, 2, pInputArrayPointer, ConstNumOfInputArrays);

	//NeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(pBestMatchedInputArray, 2);
	NeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(TestInputArray3, 2);
	NeuralNet.Calculate_Output();

	cout << "input values: " << TestInputArray3[0] << " " << TestInputArray3[1] << endl;
	cout << "best mached input values: " << pBestMatchedInputArray[0] << " " << pBestMatchedInputArray[1] << endl;
	cout << "activation values: " << NeuralNet.pOutputNeuronArray[0].ActivationValue << " "
		<< NeuralNet.pOutputNeuronArray[1].ActivationValue << endl << endl;

	float TestInputArray4[2] = { 0.8f, 0.9f };

	Find_BestMatchedVectorFromList(&pBestMatchedInputArray, TestInputArray4, 2, pInputArrayPointer, ConstNumOfInputArrays);

	//NeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(pBestMatchedInputArray, 2);
	NeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(TestInputArray4, 2);
	NeuralNet.Calculate_Output();

	cout << "input values: " << TestInputArray4[0] << " " << TestInputArray4[1] << endl;
	cout << "best mached input values: " << pBestMatchedInputArray[0] << " " << pBestMatchedInputArray[1] << endl;
	cout << "activation values: " << NeuralNet.pOutputNeuronArray[0].ActivationValue << " "
		<< NeuralNet.pOutputNeuronArray[1].ActivationValue << endl << endl;
	

	getchar();
	return 0;
}
*/

/*
int main(void)
{
	static constexpr int32_t ConstPrecedingNeuron_NumOfInputDendrites = 3; // 2 + Bias

																		   // NumOfHiddenDendrites:
																		   //static constexpr int32_t ConstPrecedingNeuron_NumOfOutputDendrites = 80;
																		   // NumOfHiddenDendrites:
	static constexpr int32_t ConstPrecedingNeuron_NumOfOutputDendrites = 100;

	static constexpr int32_t ConstPrecedingNeuron_NumOfAdditionalMemoryValues = ConstPrecedingNeuron_NumOfInputDendrites * ConstPrecedingNeuron_NumOfOutputDendrites;

	static constexpr int32_t ConstNumOfInputOutputArrays = 4;

	float InputArray1[2] = { 1.0f, 0.0f };
	float InputArray2[2] = { 0.0f, 1.0f };
	float InputArray3[2] = { 0.0f, 0.0f };
	float InputArray4[2] = { 1.0f, 1.0f };

	float OutputArray1[2] = { 1.0f, 0.0f };
	float OutputArray2[2] = { 1.0f, 0.0f };
	float OutputArray3[2] = { 0.0f, 0.0f };
	float OutputArray4[2] = { 0.0f, 0.0f };


	float *pInputArrayPointer[ConstNumOfInputOutputArrays];

	pInputArrayPointer[0] = InputArray1;
	pInputArrayPointer[1] = InputArray2;
	pInputArrayPointer[2] = InputArray3;
	pInputArrayPointer[3] = InputArray4;

	float *pOutputArrayPointer[ConstNumOfInputOutputArrays];

	pOutputArrayPointer[0] = OutputArray1;
	pOutputArrayPointer[1] = OutputArray2;
	pOutputArrayPointer[2] = OutputArray3;
	pOutputArrayPointer[3] = OutputArray4;


	CRandomNumbersNN RandomNumbers;


	static float RandomPlasticityArray[ConstPrecedingNeuron_NumOfAdditionalMemoryValues];
	Init_RandomNumbersTableExt2(RandomPlasticityArray, ConstPrecedingNeuron_NumOfAdditionalMemoryValues, &RandomNumbers, -1.0f, 1.0f, 0.5f);


	CSimpleNeuralNet_1HiddenLayer NeuralNet;

	//NeuralNet.Init_PrecedingNeuron(ConstPrecedingNeuron_NumOfInputDendrites, ConstPrecedingNeuron_NumOfOutputDendrites, LogicFunctionApproximationDendriticFunction, RandomPlasticityArray, ConstPrecedingNeuron_NumOfAdditionalMemoryValues);

	NeuralNet.Init_PrecedingNeuron(ConstPrecedingNeuron_NumOfInputDendrites, ConstPrecedingNeuron_NumOfOutputDendrites, LogicFunctionApproximationDendriticFunction, &RandomNumbers, -1.0f, 1.0f);

	NeuralNet.Init_OutputNeuronArray(2, ConstPrecedingNeuron_NumOfOutputDendrites, LogicFunctionApproximationOutputFunction, &RandomNumbers, -0.2f, 0.2f);


	static constexpr int32_t ConstNumOfInputSamples = 40 * ConstNumOfInputOutputArrays;


	int32_t maxCount = 10000;
	int32_t epoch = 0;
	float errorSum;

	float tempInputArray[2];

	for (int32_t j = 0; j < maxCount; j++)
	{
		epoch++;
		errorSum = 0.0f;

		for (int32_t i = 0; i < ConstNumOfInputSamples; i++)
		{
			int32_t k = i % ConstNumOfInputOutputArrays;
			//int32_t k = i % 2;

			if (RandomNumbers.Get_IntegerNumber2(2, 3) == 2)
				tempInputArray[0] = pInputArrayPointer[k][0] + RandomNumbers.Get_FloatNumber(-0.45f, 0.45f, 0.1f);
			else
				tempInputArray[0] = pInputArrayPointer[k][0] + RandomNumbers.Get_FloatNumber(-0.45f, 0.45f, -0.1f);

			if (RandomNumbers.Get_IntegerNumber2(2, 3) == 2)
				tempInputArray[1] = pInputArrayPointer[k][1] + RandomNumbers.Get_FloatNumber(-0.45f, 0.45f, 0.1f);
			else
				tempInputArray[1] = pInputArrayPointer[k][1] + RandomNumbers.Get_FloatNumber(-0.45f, 0.45f, -0.1f);

			NeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(tempInputArray, 2);
			NeuralNet.Calculate_Output();

			errorSum += NeuralNet.OutputNeurons_ErrorCalculations(pOutputArrayPointer[k], 1.0f, 0.5f);
			//errorSum += NeuralNet.OutputNeurons_ErrorCalculations(tempInputArray, 1.0f, 0.5f);
			PrecedingNeuronLearning(&NeuralNet.PrecedingNeuron, &NeuralNet.pOutputNeuronArray[0], 2, 0.005f, 1.0f, 1.0f);
			NeuralNet.OutputNeurons_Adjust_Dendrite_Factors_AfterErrorCalculations(0.0025f);
		}

		//if (errorSum < 0.0001f)
		//break;

		if (epoch % 500 == 0)
		{
			cout << "epoch: " << epoch << endl;
			cout << "error: " << errorSum << endl << endl;
		}
	}

	// training completed

	// training statistics:


	cout << "epoch: " << epoch << endl;
	cout << "error: " << errorSum << endl << endl;

	cout << endl;

	for (int32_t i = 0; i < ConstNumOfInputOutputArrays; i++)
	{
		NeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(pInputArrayPointer[i], 2);
		NeuralNet.Calculate_Output();

		cout << "input values: " << pInputArrayPointer[i][0] << " " << pInputArrayPointer[i][1] << endl;
		cout << "activation values: " << NeuralNet.pOutputNeuronArray[0].ActivationValue << " "
			<< NeuralNet.pOutputNeuronArray[1].ActivationValue << endl << endl;
	}

	float *pBestMatchedInputArray = nullptr;

	float TestInputArray1[2] = { 0.1f, 0.9f };

	Find_BestMatchedVectorFromList(&pBestMatchedInputArray, TestInputArray1, 2, pInputArrayPointer, ConstNumOfInputOutputArrays);


	//NeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(pBestMatchedInputArray, 2);
	NeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(TestInputArray1, 2);
	NeuralNet.Calculate_Output();

	cout << "input values: " << TestInputArray1[0] << " " << TestInputArray1[1] << endl;
	cout << "best mached input values: " << pBestMatchedInputArray[0] << " " << pBestMatchedInputArray[1] << endl;
	cout << "activation values: " << NeuralNet.pOutputNeuronArray[0].ActivationValue << " "
		<< NeuralNet.pOutputNeuronArray[1].ActivationValue <<  endl << endl;

	float TestInputArray2[2] = { 1.4f, 0.4f };

	Find_BestMatchedVectorFromList(&pBestMatchedInputArray, TestInputArray2, 2, pInputArrayPointer, ConstNumOfInputOutputArrays);

	//NeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(pBestMatchedInputArray, 2);
	NeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(TestInputArray2, 2);
	NeuralNet.Calculate_Output();

	cout << "input values: " << TestInputArray2[0] << " " << TestInputArray2[1] << endl;
	cout << "best mached input values: " << pBestMatchedInputArray[0] << " " << pBestMatchedInputArray[1] << endl;
	cout << "activation values: " << NeuralNet.pOutputNeuronArray[0].ActivationValue << " "
		<< NeuralNet.pOutputNeuronArray[1].ActivationValue <<  endl << endl;

	float TestInputArray3[2] = { 0.3f, 0.1f };

	Find_BestMatchedVectorFromList(&pBestMatchedInputArray, TestInputArray3, 2, pInputArrayPointer, ConstNumOfInputOutputArrays);

	//NeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(pBestMatchedInputArray, 2);
	NeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(TestInputArray3, 2);
	NeuralNet.Calculate_Output();

	cout << "input values: " << TestInputArray3[0] << " " << TestInputArray3[1] << endl;
	cout << "best mached input values: " << pBestMatchedInputArray[0] << " " << pBestMatchedInputArray[1] << endl;
	cout << "activation values: " << NeuralNet.pOutputNeuronArray[0].ActivationValue << " "
		<< NeuralNet.pOutputNeuronArray[1].ActivationValue <<  endl << endl;

	float TestInputArray4[2] = { 0.8f, 0.9f };

	Find_BestMatchedVectorFromList(&pBestMatchedInputArray, TestInputArray4, 2, pInputArrayPointer, ConstNumOfInputOutputArrays);

	//NeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(pBestMatchedInputArray, 2);
	NeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(TestInputArray4, 2);
	NeuralNet.Calculate_Output();

	cout << "input values: " << TestInputArray4[0] << " " << TestInputArray4[1] << endl;
	cout << "best mached input values: " << pBestMatchedInputArray[0] << " " << pBestMatchedInputArray[1] << endl;
	cout << "activation values: " << NeuralNet.pOutputNeuronArray[0].ActivationValue << " "
		<< NeuralNet.pOutputNeuronArray[1].ActivationValue <<  endl << endl;


	getchar();
	return 0;
}
*/



/*
int main(void)
{
	static constexpr int32_t ConstPrecedingNeuron_NumOfInputDendrites = 3; // 2 + bias
	static constexpr int32_t ConstPrecedingNeuron_NumOfOutputDendrites = 10;
	static constexpr int32_t ConstPrecedingNeuron_NumOfAdditionalMemoryValues = ConstPrecedingNeuron_NumOfInputDendrites * ConstPrecedingNeuron_NumOfOutputDendrites;

	static constexpr int32_t TrainingPopulationSize = 50;
	static constexpr int32_t NumTrainingGenerationsMax = 20000;

	static constexpr int32_t ConstNumOfInputArrays = 6;

	float InputArray1[2] = { 1.2f, 0.7f };
	float InputArray2[2] = { -0.3f, 0.5f };
	float InputArray3[2] = { -3.0f, -1.0f };
	float InputArray4[2] = { 0.1f, 1.0f };
	float InputArray5[2] = { 3.0f, 1.1f };
	float InputArray6[2] = { 2.1f, -3.0f };

	float *pInputArrayPointer[ConstNumOfInputArrays];

	pInputArrayPointer[0] = InputArray1;
	pInputArrayPointer[1] = InputArray2;
	pInputArrayPointer[2] = InputArray3;
	pInputArrayPointer[3] = InputArray4;
	pInputArrayPointer[4] = InputArray5;
	pInputArrayPointer[5] = InputArray6;


	float DesiredOutputArray[ConstNumOfInputArrays] = { 1.0f, -1.0f, 1.0f, -1.0f, -1.0f, 1.0f };

	CRandomNumbersNN RandomNumbers;

	static float RandomPlasticityArray[ConstPrecedingNeuron_NumOfAdditionalMemoryValues];

	

	static CSimpleNeuralNet_1HiddenLayer NeuralNetArray[TrainingPopulationSize];
	
	CSimpleNeuralNet_1HiddenLayer BestNeuralNet;

	BestNeuralNet.Init_PrecedingNeuron(ConstPrecedingNeuron_NumOfInputDendrites, ConstPrecedingNeuron_NumOfOutputDendrites, LogicFunctionApproximationDendriticFunction, nullptr, ConstPrecedingNeuron_NumOfAdditionalMemoryValues);
	BestNeuralNet.Init_OutputNeuronArray(1, ConstPrecedingNeuron_NumOfOutputDendrites, LogicFunctionApproximationOutputFunction, &RandomNumbers, -0.2f, 0.2f);


	for (int32_t i = 0; i < TrainingPopulationSize; i++)
	{
		Init_RandomNumbersTableExt2(RandomPlasticityArray, ConstPrecedingNeuron_NumOfAdditionalMemoryValues, &RandomNumbers, -1.0f, 1.0f, 0.5f);

		NeuralNetArray[i].Init_PrecedingNeuron(ConstPrecedingNeuron_NumOfInputDendrites, ConstPrecedingNeuron_NumOfOutputDendrites, LogicFunctionApproximationDendriticFunction, RandomPlasticityArray, ConstPrecedingNeuron_NumOfAdditionalMemoryValues);
		NeuralNetArray[i].Init_OutputNeuronArray(1, ConstPrecedingNeuron_NumOfOutputDendrites, LogicFunctionApproximationOutputFunction, &RandomNumbers, -0.2f, 0.2f);
	}

	static CSimpleNeuralNetData NeuralNetDataArray[TrainingPopulationSize];


	for (int32_t i = 0; i < TrainingPopulationSize; i++)
	{
		NeuralNetDataArray[i].Init_Data(2);
		NeuralNetDataArray[i].Set_Neuron(&NeuralNetArray[i].PrecedingNeuron, 0);
		NeuralNetDataArray[i].Set_Neuron(&NeuralNetArray[i].pOutputNeuronArray[0], 1);
	}

	CSimpleNeuralNetPopulation SimpleNeuralNetPopulation;
	SimpleNeuralNetPopulation.Initialize(TrainingPopulationSize);

	for (int32_t i = 0; i < TrainingPopulationSize; i++)
	{
		SimpleNeuralNetPopulation.Set_SimpleNeuralNet(&NeuralNetDataArray[i], i);
	}

	float output;
	float desiredOutput;
	float errorSum;

	for (int32_t j = 0; j < NumTrainingGenerationsMax; j++)
	{
		SimpleNeuralNetPopulation.Reset_MinErrorSum_ActualGeneration();

		for (int32_t i = 0; i < TrainingPopulationSize; i++)
		{
			errorSum = 0.0f;

			for (int32_t k = 0; k < ConstNumOfInputArrays; k++)
			{
				NeuralNetArray[i].PrecedingNeuron.Set_Dendrite_NeuronInput(pInputArrayPointer[k], 2);
				NeuralNetArray[i].Calculate_Output();
				errorSum += NeuralNetArray[i].OutputNeurons_Calculate_VarianceSq(&DesiredOutputArray[k]);
			}

			SimpleNeuralNetPopulation.Calculate_FitnessScore_FromError(i, errorSum);

			SimpleNeuralNetPopulation.Update_MinErrorSum_ActualGeneration(errorSum);
		}

		SimpleNeuralNetPopulation.Update_Population();

		if (j % 100 == 0)
		{
			cout << "minErrorSum: " << SimpleNeuralNetPopulation.MinErrorSum_ActualGeneration << endl;
		}

		//if (SimpleNeuralNetPopulation.MinErrorSum_ActualGeneration < 0.01f)
		if (SimpleNeuralNetPopulation.MinErrorSum_ActualGeneration < 0.00125f)
		{
			cout << "actual generation: " << j << endl;
			cout << "training completed" << endl << endl;
			break;
		}

		SimpleNeuralNetPopulation.Update_BaseEvolution(LogicFunctionApproximation_MutationFunction, nullptr);
		SimpleNeuralNetPopulation.Update_Evolution_BestBrainOnly(LogicFunctionApproximation_MutationFunction, nullptr);
		SimpleNeuralNetPopulation.Update_Evolution_SecondBestBrainOnly(LogicFunctionApproximation_MutationFunction, nullptr);
		SimpleNeuralNetPopulation.Update_Evolution_Combine_BestTwoBrains(LogicFunctionApproximation_RecombinationFunction, nullptr);
		SimpleNeuralNetPopulation.Update_Evolution_Combine_TwoBrains(LogicFunctionApproximation_RecombinationFunction, nullptr);
		SimpleNeuralNetPopulation.Update_Evolution_Combine_TwoBrains(LogicFunctionApproximation_RecombinationFunction, nullptr);
	}

	

	CSimpleNeuralNetData BestNeuralNetData;
	BestNeuralNetData.Init_Data(2);
	BestNeuralNetData.Set_Neuron(&BestNeuralNet.PrecedingNeuron, 0);
	BestNeuralNetData.Set_Neuron(&BestNeuralNet.pOutputNeuronArray[0], 1);

	SimpleNeuralNetPopulation.Get_Best_Evolved_NeuralNet(&BestNeuralNetData);


	for (int32_t i = 0; i < ConstNumOfInputArrays; i++)
	{
		BestNeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(pInputArrayPointer[i], 2);
		BestNeuralNet.Calculate_Output();

		cout << "input values: " << pInputArrayPointer[i][0] << " " << pInputArrayPointer[i][1] << endl;
		cout << "activation value: " << BestNeuralNet.pOutputNeuronArray[0].ActivationValue << endl << endl;
	}

	float *pBestMatchedInputArray = nullptr;

	float TestInputArray1[2] = { 0.1f, 0.9f };

	Find_BestMatchedVectorFromList(&pBestMatchedInputArray, TestInputArray1, 2, pInputArrayPointer, ConstNumOfInputArrays);

	//BestNeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(pBestMatchedInputArray, 2);
	BestNeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(TestInputArray1, 2);
	BestNeuralNet.Calculate_Output();

	cout << "input values: " << TestInputArray1[0] << " " << TestInputArray1[1] << endl;
	cout << "best mached input values: " << pBestMatchedInputArray[0] << " " << pBestMatchedInputArray[1] << endl;
	cout << "activation value: " << BestNeuralNet.pOutputNeuronArray[0].ActivationValue << endl << endl;


	getchar();
	return 0;
}
*/

/*
int main(void)
{
	static constexpr int32_t ConstPrecedingNeuron_NumOfInputDendrites = 3;
	static constexpr int32_t ConstPrecedingNeuron_NumOfOutputDendrites = 10;
	static constexpr int32_t ConstPrecedingNeuron_NumOfAdditionalMemoryValues = ConstPrecedingNeuron_NumOfInputDendrites * ConstPrecedingNeuron_NumOfOutputDendrites;

	static constexpr int32_t TrainingPopulationSize = 50;
	static constexpr int32_t NumTrainingGenerationsMax = 20000;

	static constexpr int32_t ConstNumOfInputArrays = 6;

	float InputArray1[2] = { 1.2f, 0.7f };
	float InputArray2[2] = { -0.3f, 0.5f };
	float InputArray3[2] = { -3.0f, -1.0f };
	float InputArray4[2] = { 0.1f, 1.0f };
	float InputArray5[2] = { 3.0f, 1.1f };
	float InputArray6[2] = { 2.1f, -3.0f };

	float *pInputArrayPointer[ConstNumOfInputArrays];

	pInputArrayPointer[0] = InputArray1;
	pInputArrayPointer[1] = InputArray2;
	pInputArrayPointer[2] = InputArray3;
	pInputArrayPointer[3] = InputArray4;
	pInputArrayPointer[4] = InputArray5;
	pInputArrayPointer[5] = InputArray6;


	float DesiredOutputArray[ConstNumOfInputArrays] = { 1.0f, -1.0f, 1.0f, -1.0f, -1.0f, 1.0f };

	CRandomNumbersNN RandomNumbers;

	static float RandomPlasticityArray[ConstPrecedingNeuron_NumOfAdditionalMemoryValues];
	
	static CSimpleNeuron PrecedingNeuronArray[TrainingPopulationSize];
	static CSimpleNeuron NeuronArray[TrainingPopulationSize];

	for (int32_t i = 0; i < TrainingPopulationSize; i++)
	{
		Init_RandomNumbersTableExt2(RandomPlasticityArray, ConstPrecedingNeuron_NumOfAdditionalMemoryValues, &RandomNumbers, -1.0f, 1.0f, 0.5f);

		PrecedingNeuronArray[i].Init_Dendrite_Arrays(ConstPrecedingNeuron_NumOfInputDendrites + ConstPrecedingNeuron_NumOfOutputDendrites);
		PrecedingNeuronArray[i].Set_InputDendriteInfo(0, ConstPrecedingNeuron_NumOfInputDendrites);
		PrecedingNeuronArray[i].Set_OutputDendriteInfo(ConstPrecedingNeuron_NumOfInputDendrites, ConstPrecedingNeuron_NumOfOutputDendrites);
		PrecedingNeuronArray[i].Set_DendriticFunction(LogicFunctionApproximationDendriticFunction2);
		PrecedingNeuronArray[i].Init_AdditionalMemoryValues(RandomPlasticityArray, ConstPrecedingNeuron_NumOfAdditionalMemoryValues);

		NeuronArray[i].Init_Dendrite_Arrays(ConstPrecedingNeuron_NumOfOutputDendrites);
		NeuronArray[i].Use_OtherNeuron_Dendrite_DataArray(PrecedingNeuronArray[i].pDendrite_DataArray, PrecedingNeuronArray[i].FirstOutputDendriteID);
		NeuronArray[i].Set_ActivationFunction(LogicFunctionApproximationOutputFunction);
		NeuronArray[i].Randomize_Dendrite_Factors(&RandomNumbers, -0.2f, 0.2f);
	}

	static CSimpleNeuralNetData NeuralNetDataArray[TrainingPopulationSize];
	

	for (int32_t i = 0; i < TrainingPopulationSize; i++)
	{
		NeuralNetDataArray[i].Init_Data(2);
		NeuralNetDataArray[i].Set_Neuron(&PrecedingNeuronArray[i], 0);
		NeuralNetDataArray[i].Set_Neuron(&NeuronArray[i], 1);
	}

	CSimpleNeuralNetPopulation SimpleNeuralNetPopulation;
	SimpleNeuralNetPopulation.Initialize(TrainingPopulationSize);

	for (int32_t i = 0; i < TrainingPopulationSize; i++)
	{
		SimpleNeuralNetPopulation.Set_SimpleNeuralNet(&NeuralNetDataArray[i], i);
	}

	float output;
	float desiredOutput;
	float errorSum;

	for (int32_t j = 0; j < NumTrainingGenerationsMax; j++)
	{
		SimpleNeuralNetPopulation.Reset_MinErrorSum_ActualGeneration();

		for (int32_t i = 0; i < TrainingPopulationSize; i++)
		{
			errorSum = 0.0f;

			for (int32_t k = 0; k < ConstNumOfInputArrays; k++)
			{
				PrecedingNeuronArray[i].Set_Dendrite_NeuronInput(pInputArrayPointer[k], 2);
				PrecedingNeuronArray[i].Execute_DendriticCalculations();
				NeuronArray[i].Calculate_NeuronOutput();
				errorSum += NeuronArray[i].Calculate_VarianceSq(DesiredOutputArray[k]);
			}

			SimpleNeuralNetPopulation.Calculate_FitnessScore_FromError(i, errorSum);
			
			SimpleNeuralNetPopulation.Update_MinErrorSum_ActualGeneration(errorSum);
		}

		SimpleNeuralNetPopulation.Update_Population();

		if(j % 100 == 0)
			cout << "minErrorSum: " << SimpleNeuralNetPopulation.MinErrorSum_ActualGeneration << endl;

		//if (SimpleNeuralNetPopulation.MinErrorSum_ActualGeneration < 0.01f)
		if (SimpleNeuralNetPopulation.MinErrorSum_ActualGeneration < 0.00125f)
		{
			cout << "actual generation: " << j << endl;
			cout << "training completed" << endl << endl;
			break;
		}

		SimpleNeuralNetPopulation.Update_BaseEvolution(LogicFunctionApproximation_MutationFunction, nullptr);
		SimpleNeuralNetPopulation.Update_Evolution_BestBrainOnly(LogicFunctionApproximation_MutationFunction, nullptr);
		SimpleNeuralNetPopulation.Update_Evolution_SecondBestBrainOnly(LogicFunctionApproximation_MutationFunction, nullptr);
		SimpleNeuralNetPopulation.Update_Evolution_Combine_BestTwoBrains(LogicFunctionApproximation_RecombinationFunction, nullptr);
		SimpleNeuralNetPopulation.Update_Evolution_Combine_TwoBrains(LogicFunctionApproximation_RecombinationFunction, nullptr);
		SimpleNeuralNetPopulation.Update_Evolution_Combine_TwoBrains(LogicFunctionApproximation_RecombinationFunction, nullptr);
	}

	CSimpleNeuron BestPrecedingNeuron;
	CSimpleNeuron BestNeuron;

	BestPrecedingNeuron.Init_Dendrite_Arrays(ConstPrecedingNeuron_NumOfInputDendrites + ConstPrecedingNeuron_NumOfOutputDendrites);
	BestPrecedingNeuron.Set_InputDendriteInfo(0, ConstPrecedingNeuron_NumOfInputDendrites);
	BestPrecedingNeuron.Set_OutputDendriteInfo(ConstPrecedingNeuron_NumOfInputDendrites, ConstPrecedingNeuron_NumOfOutputDendrites);
	BestPrecedingNeuron.Set_DendriticFunction(LogicFunctionApproximationDendriticFunction2);
	BestPrecedingNeuron.Init_AdditionalMemoryValues(ConstPrecedingNeuron_NumOfAdditionalMemoryValues);

	BestNeuron.Init_Dendrite_Arrays(ConstPrecedingNeuron_NumOfOutputDendrites);
	BestNeuron.Use_OtherNeuron_Dendrite_DataArray(BestPrecedingNeuron.pDendrite_DataArray, BestPrecedingNeuron.FirstOutputDendriteID);
	BestNeuron.Set_ActivationFunction(LogicFunctionApproximationOutputFunction);

	CSimpleNeuralNetData BestNeuralNetData;
	BestNeuralNetData.Init_Data(2);
	BestNeuralNetData.Set_Neuron(&BestPrecedingNeuron, 0);
	BestNeuralNetData.Set_Neuron(&BestNeuron, 1);

	SimpleNeuralNetPopulation.Get_Best_Evolved_NeuralNet(&BestNeuralNetData);
	

	for (int32_t i = 0; i < ConstNumOfInputArrays; i++)
	{
		BestPrecedingNeuron.Set_Dendrite_NeuronInput(pInputArrayPointer[i], 2);
		BestPrecedingNeuron.Execute_DendriticCalculations();
		BestNeuron.Calculate_NeuronOutput();

		cout << "input values: " << pInputArrayPointer[i][0] << " " << pInputArrayPointer[i][1] << endl;
		cout << "activation value: " << BestNeuron.ActivationValue << endl << endl;	
	}

	float *pBestMatchedInputArray = nullptr;

	float TestInputArray1[2] = { 0.1f, 0.9f };

	Find_BestMatchedVectorFromList(&pBestMatchedInputArray, TestInputArray1, 2, pInputArrayPointer, ConstNumOfInputArrays);

	//BestPrecedingNeuron.Set_Dendrite_NeuronInput(pBestMatchedInputArray, 2);
	BestPrecedingNeuron.Set_Dendrite_NeuronInput(TestInputArray1, 2);
	BestPrecedingNeuron.Execute_DendriticCalculations();
	BestNeuron.Calculate_NeuronOutput();

	cout << "input values: " << TestInputArray1[0] << " " << TestInputArray1[1] << endl;
	cout << "best mached input values: " << pBestMatchedInputArray[0] << " " << pBestMatchedInputArray[1] << endl;
	cout << "activation value: " << BestNeuron.ActivationValue << endl << endl;


	getchar();
	return 0;
}
*/


/*
int main(void)
{
	static constexpr int32_t ConstNumOfInputOutputValues = 6;
	static constexpr int32_t ConstNumOfEncodingDendrites = 4;

	CRandomNumbersNN RandomNumbers;

	static float RandomPlasticityArray[ConstNumOfInputOutputValues * ConstNumOfEncodingDendrites];
	Init_RandomNumbersTableExt2(RandomPlasticityArray, ConstNumOfInputOutputValues * ConstNumOfEncodingDendrites, &RandomNumbers, -1.0f, 1.0f, 0.5f);

	static constexpr int32_t ConstNumOfInputArrays = 3;

	float InputArray1[ConstNumOfInputOutputValues] = { 0.0f, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f };
	float InputArray2[ConstNumOfInputOutputValues] = { 0.0f, 1.0f, 1.0f, 0.0f, 1.0f, 0.0f };
	float InputArray3[ConstNumOfInputOutputValues] = { 1.0f, 1.0f, 0.0f, 0.0f, 1.0f, 1.0f };

	float *pInputArrayPointer[ConstNumOfInputArrays];

	pInputArrayPointer[0] = InputArray1;
	pInputArrayPointer[1] = InputArray2;
	pInputArrayPointer[2] = InputArray3;

	float OutputArray[ConstNumOfInputOutputValues];

	CSimpleNeuron PrecedingNeuron;

	PrecedingNeuron.Init_Dendrite_Arrays(ConstNumOfInputOutputValues + ConstNumOfEncodingDendrites);
	PrecedingNeuron.Set_InputDendriteInfo(0, ConstNumOfInputOutputValues);
	PrecedingNeuron.Set_OutputDendriteInfo(ConstNumOfInputOutputValues, ConstNumOfEncodingDendrites);
	PrecedingNeuron.Set_DendriticFunction(AutoencoderDendriticFunction);
	PrecedingNeuron.Init_AdditionalMemoryValues(RandomPlasticityArray, ConstNumOfInputOutputValues * ConstNumOfEncodingDendrites);

	static CSimpleNeuron OutputNeuronArray[ConstNumOfInputOutputValues];

	for (int32_t i = 0; i < ConstNumOfInputOutputValues; i++)
	{
		OutputNeuronArray[i].Init_Dendrite_Arrays(ConstNumOfEncodingDendrites);
		OutputNeuronArray[i].Use_OtherNeuron_Dendrite_DataArray(PrecedingNeuron.pDendrite_DataArray, ConstNumOfInputOutputValues);
		OutputNeuronArray[i].Set_ActivationFunction(AutoencoderOutputFunction);
		OutputNeuronArray[i].Randomize_Dendrite_Factors(&RandomNumbers, -0.2f, 0.2f);
	}

	int32_t maxCount = 100000;
	int32_t epoch = 0;
	float errorSum;



	for (int32_t i = 0; i < maxCount; i++)
	{
		epoch++;
		errorSum = 0.0f;

		for (int32_t j = 0; j < ConstNumOfInputArrays; j++)
		{
			PrecedingNeuron.Set_Dendrite_NeuronInput(pInputArrayPointer[j], ConstNumOfInputOutputValues);
			PrecedingNeuron.Execute_DendriticCalculations();

			for (int32_t k = 0; k < ConstNumOfInputOutputValues; k++)
			{
				OutputNeuronArray[k].Calculate_NeuronOutput();
			}

			for (int32_t k = 0; k < ConstNumOfInputOutputValues; k++)
			{
				//errorSum += OutputNeuronArray[k].Calculate_Error(pInputArrayPointer[j][k], 1.0f, 1.0f);	
				errorSum += OutputNeuronArray[k].Calculate_Error(PrecedingNeuron.pDendrite_DataArray[k], 1.0f, 1.0f);	
			}

			PrecedingNeuronLearning(&PrecedingNeuron, OutputNeuronArray, ConstNumOfInputOutputValues, 0.2f, 1.0f, 1.0f);

			for (int32_t k = 0; k < ConstNumOfInputOutputValues; k++)
			{
				OutputNeuronArray[k].Adjust_Dendrite_Factors_AfterErrorCalculations_ExternalInput(0.2f);
			}
		}

		if (errorSum < 0.00001f)
			break;
	}

	// training completed

	// training statistics:


	cout << "epoch: " << epoch << endl;
	cout << "error: " << errorSum << endl << endl;



	cout << endl;

	float TestArray1[ConstNumOfInputOutputValues] = { 0.0f, 0.0f, 1.0f, 0.1f, 1.0f, 0.2f };

	cout << "input pattern: ";

	for (int32_t i = 0; i < ConstNumOfInputOutputValues; i++)
	{
		cout << TestArray1[i] << " ";
	}

	cout << endl;

	PrecedingNeuron.Set_Dendrite_NeuronInput(TestArray1, ConstNumOfInputOutputValues);
	PrecedingNeuron.Execute_DendriticCalculations();

	for (int32_t i = 0; i < ConstNumOfInputOutputValues; i++)
	{
		OutputNeuronArray[i].Calculate_NeuronOutput();
	}

	cout << "output pattern: ";

	for (int32_t i = 0; i < ConstNumOfInputOutputValues; i++)
	{
		OutputArray[i] = OutputNeuronArray[i].ActivationValue;
		cout << OutputNeuronArray[i].ActivationValue << " ";
	}

	cout << endl;

	float *pArray = nullptr;

	Find_BestMatchedVectorFromList(&pArray, OutputArray, ConstNumOfInputOutputValues, pInputArrayPointer, ConstNumOfInputArrays);

	cout << "learned pattern: ";

	for (int32_t i = 0; i < 6; i++)
	{
		cout << pArray[i] << " ";
	}

	cout << endl << endl;


	float TestArray2[ConstNumOfInputOutputValues] = { 0.0f, 0.7f, 1.0f, 0.0f, 1.0f, 0.2f };


	cout << "input pattern: ";

	for (int32_t i = 0; i < ConstNumOfInputOutputValues; i++)
	{
		cout << TestArray2[i] << " ";
	}


	cout << endl;


	PrecedingNeuron.Set_Dendrite_NeuronInput(TestArray2, ConstNumOfInputOutputValues);
	PrecedingNeuron.Execute_DendriticCalculations();

	for (int32_t i = 0; i < ConstNumOfInputOutputValues; i++)
	{
		OutputNeuronArray[i].Calculate_NeuronOutput();
	}

	cout << "output pattern: ";

	for (int32_t i = 0; i < ConstNumOfInputOutputValues; i++)
	{
		OutputArray[i] = OutputNeuronArray[i].ActivationValue;
		cout << OutputNeuronArray[i].ActivationValue << " ";
	}

	cout << endl;



	Find_BestMatchedVectorFromList(&pArray, OutputArray, ConstNumOfInputOutputValues, pInputArrayPointer, ConstNumOfInputArrays);

	cout << "learned pattern: ";

	for (int32_t i = 0; i < ConstNumOfInputOutputValues; i++)
		cout << pArray[i] << " ";

	cout << endl << endl;


	float TestArray3[ConstNumOfInputOutputValues] = { 1.0f, 1.0f, 0.1f, 0.0f, 1.0f, 0.8f };

	cout << "input pattern: ";

	for (int32_t i = 0; i < ConstNumOfInputOutputValues; i++)
		cout << TestArray3[i] << " ";


	cout << endl;

	PrecedingNeuron.Set_Dendrite_NeuronInput(TestArray3, ConstNumOfInputOutputValues);
	PrecedingNeuron.Execute_DendriticCalculations();

	for (int32_t i = 0; i < ConstNumOfInputOutputValues; i++)
	{
		OutputNeuronArray[i].Calculate_NeuronOutput();
	}

	cout << "output pattern: ";

	for (int32_t i = 0; i < ConstNumOfInputOutputValues; i++)
	{
		OutputArray[i] = OutputNeuronArray[i].ActivationValue;
		cout << OutputNeuronArray[i].ActivationValue << " ";
	}

	cout << endl;



	Find_BestMatchedVectorFromList(&pArray, OutputArray, ConstNumOfInputOutputValues, pInputArrayPointer, ConstNumOfInputArrays);

	cout << "learned pattern: ";

	for (int32_t i = 0; i < ConstNumOfInputOutputValues; i++)
		cout << pArray[i] << " ";

	cout << endl << endl;

	getchar();
	return 0;
}
*/




/*
int main(void)
{
	static constexpr int32_t ConstNumOfInputOutputValues = 6;
	static constexpr int32_t ConstNumOfEncodingDendrites = 4;

	CRandomNumbersNN RandomNumbers;

	static constexpr int32_t ConstPrecedingNeuron_NumOfAdditionalMemoryValues = ConstNumOfInputOutputValues * ConstNumOfEncodingDendrites;


	static float RandomPlasticityArray[ConstPrecedingNeuron_NumOfAdditionalMemoryValues];
	Init_RandomNumbersTableExt2(RandomPlasticityArray, ConstPrecedingNeuron_NumOfAdditionalMemoryValues, &RandomNumbers, -1.0f, 1.0f, 0.5f);

	static constexpr int32_t ConstNumOfInputArrays = 3;

	float InputArray1[ConstNumOfInputOutputValues] = { 0.0f, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f };
	float InputArray2[ConstNumOfInputOutputValues] = { 0.0f, 1.0f, 1.0f, 0.0f, 1.0f, 0.0f };
	float InputArray3[ConstNumOfInputOutputValues] = { 1.0f, 1.0f, 0.0f, 0.0f, 1.0f, 1.0f };

	float *pInputArrayPointer[ConstNumOfInputArrays];

	pInputArrayPointer[0] = InputArray1;
	pInputArrayPointer[1] = InputArray2;
	pInputArrayPointer[2] = InputArray3;

	float OutputArray[ConstNumOfInputOutputValues];

	CSimpleNeuronAutoEncoder SimpleNeuronAutoEncoder;

	SimpleNeuronAutoEncoder.Init_PrecedingNeuron(ConstNumOfInputOutputValues, ConstNumOfEncodingDendrites, AutoencoderDendriticFunction, RandomPlasticityArray, ConstPrecedingNeuron_NumOfAdditionalMemoryValues);
	
	SimpleNeuronAutoEncoder.Init_OutputNeuronArray(ConstNumOfInputOutputValues, ConstNumOfEncodingDendrites, AutoencoderOutputFunction, &RandomNumbers, -0.2f, 0.2f);

	int32_t maxCount = 100000;
	int32_t epoch = 0;
	float errorSum;

	for (int32_t i = 0; i < maxCount; i++)
	{
		epoch++;
		errorSum = 0.0f;

		for (int32_t j = 0; j < ConstNumOfInputArrays; j++)
		{
			SimpleNeuronAutoEncoder.PrecedingNeuron.Set_Dendrite_NeuronInput(pInputArrayPointer[j], ConstNumOfInputOutputValues);
			SimpleNeuronAutoEncoder.Calculate_Output();

			errorSum += SimpleNeuronAutoEncoder.OutputNeurons_ErrorCalculations(1.0f, 1.0f);
	
			PrecedingNeuronLearning(&SimpleNeuronAutoEncoder.PrecedingNeuron, SimpleNeuronAutoEncoder.pOutputNeuronArray, ConstNumOfInputOutputValues, 0.2f, 1.0f, 1.0f);

			SimpleNeuronAutoEncoder.OutputNeurons_Adjust_Dendrite_Factors_AfterErrorCalculations(0.2f);
		}

		if (errorSum < 0.00001f)
			break;
	}

	// training completed

	// training statistics:


	cout << "epoch: " << epoch << endl;
	cout << "error: " << errorSum << endl << endl;


	cout << "InputOutputVarianceSq (training samples):" << endl;
	SimpleNeuronAutoEncoder.PrecedingNeuron.Set_Dendrite_NeuronInput(InputArray1, ConstNumOfInputOutputValues);
	cout << "InputOutputVarianceSq: " << SimpleNeuronAutoEncoder.Calculate_Output_ReturnInputOutputVarianceSq() << endl;

	SimpleNeuronAutoEncoder.PrecedingNeuron.Set_Dendrite_NeuronInput(InputArray2, ConstNumOfInputOutputValues);
	cout << "InputOutputVarianceSq: " << SimpleNeuronAutoEncoder.Calculate_Output_ReturnInputOutputVarianceSq() << endl;

	SimpleNeuronAutoEncoder.PrecedingNeuron.Set_Dendrite_NeuronInput(InputArray3, ConstNumOfInputOutputValues);
	cout << "InputOutputVarianceSq: " << SimpleNeuronAutoEncoder.Calculate_Output_ReturnInputOutputVarianceSq() << endl;


	cout << endl;



	float TestArray1[ConstNumOfInputOutputValues] = { 0.0f, 0.0f, 1.0f, 0.1f, 1.0f, 0.2f };

	cout << "input pattern: ";

	for (int32_t i = 0; i < ConstNumOfInputOutputValues; i++)
	{
		cout << TestArray1[i] << " ";
	}

	cout << endl;

	SimpleNeuronAutoEncoder.PrecedingNeuron.Set_Dendrite_NeuronInput(TestArray1, ConstNumOfInputOutputValues);
	cout << "InputOutputVarianceSq: " << SimpleNeuronAutoEncoder.Calculate_Output_ReturnInputOutputVarianceSq(OutputArray) << endl;

	cout << "output pattern: ";

	for (int32_t i = 0; i < ConstNumOfInputOutputValues; i++)
	{
		cout << OutputArray[i] << " ";
	}

	cout << endl;

	float *pArray = nullptr;

	Find_BestMatchedVectorFromList(&pArray, OutputArray, ConstNumOfInputOutputValues, pInputArrayPointer, ConstNumOfInputArrays);

	cout << "learned pattern: ";

	for (int32_t i = 0; i < 6; i++)
	{
		cout << pArray[i] << " ";
	}

	cout << endl << endl;


	float TestArray2[ConstNumOfInputOutputValues] = { 0.0f, 0.7f, 1.0f, 0.0f, 1.0f, 0.2f };


	cout << "input pattern: ";

	for (int32_t i = 0; i < ConstNumOfInputOutputValues; i++)
	{
		cout << TestArray2[i] << " ";
	}


	cout << endl;


	SimpleNeuronAutoEncoder.PrecedingNeuron.Set_Dendrite_NeuronInput(TestArray2, ConstNumOfInputOutputValues);
	cout << "InputOutputVarianceSq: " << SimpleNeuronAutoEncoder.Calculate_Output_ReturnInputOutputVarianceSq(OutputArray) << endl;

	cout << "output pattern: ";

	for (int32_t i = 0; i < ConstNumOfInputOutputValues; i++)
	{
		cout << OutputArray[i] << " ";
	}

	cout << endl;



	Find_BestMatchedVectorFromList(&pArray, OutputArray, ConstNumOfInputOutputValues, pInputArrayPointer, ConstNumOfInputArrays);

	cout << "learned pattern: ";

	for (int32_t i = 0; i < ConstNumOfInputOutputValues; i++)
		cout << pArray[i] << " ";

	cout << endl << endl;


	float TestArray3[ConstNumOfInputOutputValues] = { 1.0f, 1.0f, 0.1f, 0.0f, 1.0f, 0.8f };
	

	cout << "input pattern: ";

	for (int32_t i = 0; i < ConstNumOfInputOutputValues; i++)
		cout << TestArray3[i] << " ";


	cout << endl;

	SimpleNeuronAutoEncoder.PrecedingNeuron.Set_Dendrite_NeuronInput(TestArray3, ConstNumOfInputOutputValues);
	cout << "InputOutputVarianceSq: " << SimpleNeuronAutoEncoder.Calculate_Output_ReturnInputOutputVarianceSq(OutputArray) << endl;

	cout << "output pattern: ";

	for (int32_t i = 0; i < ConstNumOfInputOutputValues; i++)
	{
		cout << OutputArray[i] << " ";
	}

	cout << endl;



	Find_BestMatchedVectorFromList(&pArray, OutputArray, ConstNumOfInputOutputValues, pInputArrayPointer, ConstNumOfInputArrays);

	cout << "learned pattern: ";

	for (int32_t i = 0; i < ConstNumOfInputOutputValues; i++)
		cout << pArray[i] << " ";

	cout << endl << endl;

	getchar();
	return 0;
}
*/

/*
int main(void)
{
	static float Image_B_Mean[16 * 16];

	static float Image_B_1[16 * 16];
	static float Image_B_2[16 * 16];
	static float Image_B_3[16 * 16];
	static float Image_B_4[16 * 16];
	static float Image_B_5[16 * 16];
	static float Image_B_6[16 * 16];

	static float Image_8_1[16 * 16];
	static float Image_8_2[16 * 16];
	static float Image_8_3[16 * 16];
	static float Image_8_4[16 * 16];
	static float Image_8_5[16 * 16];
	static float Image_8_6[16 * 16];

	

	static float tempImage[32 * 32];

	

	uint8_t *pImageData = nullptr;


	pImageData = Read_Bitmap_BGR("Sample_B_1.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_B_1, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_2.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_B_2, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_3.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_B_3, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_4.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_B_4, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_5.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_B_5, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_6.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_B_6, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	///////////////////////////////



	pImageData = Read_Bitmap_BGR("Sample_8_1.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_8_1, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_2.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_8_2, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_3.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_8_3, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_4.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_8_4, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_5.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_8_5, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_6.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_8_6, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	

	//////////////////////////////

	float fallback_RBF_Factor = 0.5f;
	float centroidWeightFactor = 0.025f;
	int32_t centroidExponent = 4;

	//float fallback_RBF_Factor = 10.0f;
	//float centroidWeightFactor = 0.025f;
	//int32_t centroidExponent = 2;

	CSimpleNeuron RecognitionNeuron;
	RecognitionNeuron.Init_Dendrite_Arrays(16 * 16);

	RecognitionNeuron.Add_TrainingExample(Image_B_1);
	RecognitionNeuron.Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuron.Add_TrainingExample(Image_B_2);
	RecognitionNeuron.Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuron.Add_TrainingExample(Image_B_3);
	RecognitionNeuron.Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuron.Add_TrainingExample(Image_B_4);
	RecognitionNeuron.Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuron.Add_TrainingExample(Image_B_5);
	RecognitionNeuron.Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuron.Add_TrainingExample(Image_B_6);
	RecognitionNeuron.Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);


	for (int32_t i = 0; i < 256; i++)
	{
		Image_B_Mean[i] = RecognitionNeuron.pDendrite_CentroidValueArray[i];
		//Image_B_Mean[i] = RecognitionNeuron.pDendrite_FactorArray[i];
	}

	

	static constexpr int32_t ConstNumOfInputOutputValues = 16 * 16;
	//static constexpr int32_t ConstNumOfEncodingDendrites = 4;
	static constexpr int32_t ConstNumOfEncodingDendrites = 8 * 8;
	//static constexpr int32_t ConstNumOfEncodingDendrites = 8;
	

	CRandomNumbersNN RandomNumbers;

	static constexpr int32_t ConstPrecedingNeuron_NumOfAdditionalMemoryValues = ConstNumOfInputOutputValues * ConstNumOfEncodingDendrites;

	static float RandomPlasticityArray[ConstPrecedingNeuron_NumOfAdditionalMemoryValues];
	Init_RandomNumbersTableExt2(RandomPlasticityArray, ConstPrecedingNeuron_NumOfAdditionalMemoryValues, &RandomNumbers, -1.0f, 1.0f, 0.5f);


	float OutputArray[ConstNumOfInputOutputValues];

	CSimpleNeuronAutoEncoder SimpleNeuronAutoEncoder;

	SimpleNeuronAutoEncoder.Init_PrecedingNeuron(ConstNumOfInputOutputValues, ConstNumOfEncodingDendrites, AutoencoderDendriticFunction2, RandomPlasticityArray, ConstPrecedingNeuron_NumOfAdditionalMemoryValues);

	SimpleNeuronAutoEncoder.Init_OutputNeuronArray(ConstNumOfInputOutputValues, ConstNumOfEncodingDendrites, AutoencoderOutputFunction, &RandomNumbers, -0.2f, 0.2f);


	

	int32_t maxCount = 20000;
	int32_t epoch = 0;
	float errorSum;

	
	for (int32_t i = 0; i < maxCount; i++)
	{
		epoch++;
		errorSum = 0.0f;

		SimpleNeuronAutoEncoder.PrecedingNeuron.Set_Dendrite_NeuronInput(Image_B_1, ConstNumOfInputOutputValues);
		SimpleNeuronAutoEncoder.Calculate_Output();

		
		errorSum += SimpleNeuronAutoEncoder.OutputNeurons_ErrorCalculations(Image_B_Mean, 1.0f, 1.0f);

		PrecedingNeuronLearning(&SimpleNeuronAutoEncoder.PrecedingNeuron, SimpleNeuronAutoEncoder.pOutputNeuronArray, ConstNumOfInputOutputValues, 0.02f, 1.0f, 1.0f);

		SimpleNeuronAutoEncoder.OutputNeurons_Adjust_Dendrite_Factors_AfterErrorCalculations(0.01f);
		////

		SimpleNeuronAutoEncoder.PrecedingNeuron.Set_Dendrite_NeuronInput(Image_B_2, ConstNumOfInputOutputValues);
		SimpleNeuronAutoEncoder.Calculate_Output();

		
		errorSum += SimpleNeuronAutoEncoder.OutputNeurons_ErrorCalculations(Image_B_Mean, 1.0f, 1.0f);

		PrecedingNeuronLearning(&SimpleNeuronAutoEncoder.PrecedingNeuron, SimpleNeuronAutoEncoder.pOutputNeuronArray, ConstNumOfInputOutputValues, 0.02f, 1.0f, 1.0f);

		SimpleNeuronAutoEncoder.OutputNeurons_Adjust_Dendrite_Factors_AfterErrorCalculations(0.01f);
		////

		SimpleNeuronAutoEncoder.PrecedingNeuron.Set_Dendrite_NeuronInput(Image_B_3, ConstNumOfInputOutputValues);
		SimpleNeuronAutoEncoder.Calculate_Output();

		
		errorSum += SimpleNeuronAutoEncoder.OutputNeurons_ErrorCalculations(Image_B_Mean, 1.0f, 1.0f);

		PrecedingNeuronLearning(&SimpleNeuronAutoEncoder.PrecedingNeuron, SimpleNeuronAutoEncoder.pOutputNeuronArray, ConstNumOfInputOutputValues, 0.02f, 1.0f, 1.0f);

		SimpleNeuronAutoEncoder.OutputNeurons_Adjust_Dendrite_Factors_AfterErrorCalculations(0.01f);
		////

		
		SimpleNeuronAutoEncoder.PrecedingNeuron.Set_Dendrite_NeuronInput(Image_B_4, ConstNumOfInputOutputValues);
		SimpleNeuronAutoEncoder.Calculate_Output();

		
		errorSum += SimpleNeuronAutoEncoder.OutputNeurons_ErrorCalculations(Image_B_Mean, 1.0f, 1.0f);

		PrecedingNeuronLearning(&SimpleNeuronAutoEncoder.PrecedingNeuron, SimpleNeuronAutoEncoder.pOutputNeuronArray, ConstNumOfInputOutputValues, 0.02f, 1.0f, 1.0f);

		SimpleNeuronAutoEncoder.OutputNeurons_Adjust_Dendrite_Factors_AfterErrorCalculations(0.01f);
		////

		
		SimpleNeuronAutoEncoder.PrecedingNeuron.Set_Dendrite_NeuronInput(Image_B_5, ConstNumOfInputOutputValues);
		SimpleNeuronAutoEncoder.Calculate_Output();

		
		errorSum += SimpleNeuronAutoEncoder.OutputNeurons_ErrorCalculations(Image_B_Mean, 1.0f, 1.0f);

		PrecedingNeuronLearning(&SimpleNeuronAutoEncoder.PrecedingNeuron, SimpleNeuronAutoEncoder.pOutputNeuronArray, ConstNumOfInputOutputValues, 0.02f, 1.0f, 1.0f);

		SimpleNeuronAutoEncoder.OutputNeurons_Adjust_Dendrite_Factors_AfterErrorCalculations(0.01f);
		////

		
		SimpleNeuronAutoEncoder.PrecedingNeuron.Set_Dendrite_NeuronInput(Image_B_6, ConstNumOfInputOutputValues);
		SimpleNeuronAutoEncoder.Calculate_Output();

		
		errorSum += SimpleNeuronAutoEncoder.OutputNeurons_ErrorCalculations(Image_B_Mean, 1.0f, 1.0f);

		PrecedingNeuronLearning(&SimpleNeuronAutoEncoder.PrecedingNeuron, SimpleNeuronAutoEncoder.pOutputNeuronArray, ConstNumOfInputOutputValues, 0.02f, 1.0f, 1.0f);

		SimpleNeuronAutoEncoder.OutputNeurons_Adjust_Dendrite_Factors_AfterErrorCalculations(0.01f);
		////

		if (errorSum < 1.0f)
		//if (errorSum < 0.00001f)
			break;

		if (epoch % 100 == 0)
		{
			cout << "epoch: " << epoch << endl;
			cout << "error: " << errorSum << endl << endl;
		}
	}

	// training completed

	// training statistics:


	cout << "epoch: " << epoch << endl;
	cout << "error: " << errorSum << endl << endl;

	CRandomNumbersNN RandomNumbers2;

	for (int32_t i = 0; i < 1; i++)
	{
		int32_t id = RandomNumbers2.Get_IntegerNumber(0, 256);

		if (Image_B_1[id] > 0.9f)
			Image_B_1[id] = 0.0f;
		else if (Image_B_1[id] < 0.1f)
			Image_B_1[id] = 1.0f;
	}
	

	cout << "InputOutputVarianceSq (training samples):" << endl;
	SimpleNeuronAutoEncoder.PrecedingNeuron.Set_Dendrite_NeuronInput(Image_B_1, ConstNumOfInputOutputValues);	
	cout << "InputOutputVarianceSq: " << SimpleNeuronAutoEncoder.Calculate_Output_Return_VarianceSq(Image_B_Mean) << endl;

	cout << "InputOutputVarianceSq (training samples):" << endl;
	SimpleNeuronAutoEncoder.PrecedingNeuron.Set_Dendrite_NeuronInput(Image_B_2, ConstNumOfInputOutputValues);
	cout << "InputOutputVarianceSq: " << SimpleNeuronAutoEncoder.Calculate_Output_Return_VarianceSq(Image_B_Mean) << endl;

	cout << "InputOutputVarianceSq (training samples):" << endl;
	SimpleNeuronAutoEncoder.PrecedingNeuron.Set_Dendrite_NeuronInput(Image_B_3, ConstNumOfInputOutputValues);
	cout << "InputOutputVarianceSq: " << SimpleNeuronAutoEncoder.Calculate_Output_Return_VarianceSq(Image_B_Mean) << endl;

	cout << "InputOutputVarianceSq (training samples):" << endl;
	SimpleNeuronAutoEncoder.PrecedingNeuron.Set_Dendrite_NeuronInput(Image_B_4, ConstNumOfInputOutputValues);
	cout << "InputOutputVarianceSq: " << SimpleNeuronAutoEncoder.Calculate_Output_Return_VarianceSq(Image_B_Mean) << endl;
	
	cout << "InputOutputVarianceSq (training samples):" << endl;
	SimpleNeuronAutoEncoder.PrecedingNeuron.Set_Dendrite_NeuronInput(Image_B_5, ConstNumOfInputOutputValues);	
	cout << "InputOutputVarianceSq: " << SimpleNeuronAutoEncoder.Calculate_Output_Return_VarianceSq(Image_B_Mean) << endl;

	cout << "InputOutputVarianceSq (training samples):" << endl;
	SimpleNeuronAutoEncoder.PrecedingNeuron.Set_Dendrite_NeuronInput(Image_B_6, ConstNumOfInputOutputValues);
	cout << "InputOutputVarianceSq: " << SimpleNeuronAutoEncoder.Calculate_Output_Return_VarianceSq(Image_B_Mean) << endl;

	cout << "InputOutputVarianceSq (training samples):" << endl;
	SimpleNeuronAutoEncoder.PrecedingNeuron.Set_Dendrite_NeuronInput(Image_8_1, ConstNumOfInputOutputValues);
	cout << "InputOutputVarianceSq: " << SimpleNeuronAutoEncoder.Calculate_Output_Return_VarianceSq(Image_B_Mean) << endl;

	cout << "InputOutputVarianceSq (training samples):" << endl;
	SimpleNeuronAutoEncoder.PrecedingNeuron.Set_Dendrite_NeuronInput(Image_8_2, ConstNumOfInputOutputValues);
	cout << "InputOutputVarianceSq: " << SimpleNeuronAutoEncoder.Calculate_Output_Return_VarianceSq(Image_B_Mean) << endl;

	cout << "InputOutputVarianceSq (training samples):" << endl;
	SimpleNeuronAutoEncoder.PrecedingNeuron.Set_Dendrite_NeuronInput(Image_8_3, ConstNumOfInputOutputValues);
	cout << "InputOutputVarianceSq: " << SimpleNeuronAutoEncoder.Calculate_Output_Return_VarianceSq(Image_B_Mean) << endl;

	cout << "InputOutputVarianceSq (training samples):" << endl;
	SimpleNeuronAutoEncoder.PrecedingNeuron.Set_Dendrite_NeuronInput(Image_8_4, ConstNumOfInputOutputValues);
	cout << "InputOutputVarianceSq: " << SimpleNeuronAutoEncoder.Calculate_Output_Return_VarianceSq(Image_B_Mean) << endl;

	cout << "InputOutputVarianceSq (training samples):" << endl;
	SimpleNeuronAutoEncoder.PrecedingNeuron.Set_Dendrite_NeuronInput(Image_8_5, ConstNumOfInputOutputValues);
	cout << "InputOutputVarianceSq: " << SimpleNeuronAutoEncoder.Calculate_Output_Return_VarianceSq(Image_B_Mean) << endl;

	cout << "InputOutputVarianceSq (training samples):" << endl;
	SimpleNeuronAutoEncoder.PrecedingNeuron.Set_Dendrite_NeuronInput(Image_8_6, ConstNumOfInputOutputValues);
	cout << "InputOutputVarianceSq: " << SimpleNeuronAutoEncoder.Calculate_Output_Return_VarianceSq(Image_B_Mean) << endl;

	cout << endl;

	getchar();
	return 0;
}
*/


/*
int main(void)
{
	static constexpr int32_t ConstNumOfRandomTestImages = 20;
	static float RandomTestImageArray[ConstNumOfRandomTestImages][16 * 16];


	static float Image_B_Mean1[16 * 16];
	static float Image_B_Mean2[16 * 16];

	static float Image_B_1[16 * 16];
	static float Image_B_2[16 * 16];
	static float Image_B_3[16 * 16];
	static float Image_B_4[16 * 16];
	static float Image_B_5[16 * 16];
	static float Image_B_6[16 * 16];

	static float Image_8_1[16 * 16];
	static float Image_8_2[16 * 16];
	static float Image_8_3[16 * 16];
	static float Image_8_4[16 * 16];
	static float Image_8_5[16 * 16];
	static float Image_8_6[16 * 16];



	static float tempImage[32 * 32];



	uint8_t *pImageData = nullptr;


	pImageData = Read_Bitmap_BGR("Sample_B_1.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_B_1, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_2.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_B_2, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_3.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_B_3, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_4.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_B_4, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_5.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_B_5, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_6.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_B_6, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	///////////////////////////////



	pImageData = Read_Bitmap_BGR("Sample_8_1.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_8_1, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_2.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_8_2, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_3.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_8_3, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_4.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_8_4, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_5.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_8_5, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_6.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_8_6, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;



	//////////////////////////////

	float fallback_RBF_Factor = 0.5f;
	float centroidWeightFactor = 0.025f;
	int32_t centroidExponent = 4;

	//float fallback_RBF_Factor = 10.0f;
	//float centroidWeightFactor = 0.025f;
	//int32_t centroidExponent = 2;

	CSimpleNeuron RecognitionNeuron;
	RecognitionNeuron.Init_Dendrite_Arrays(16 * 16);

	RecognitionNeuron.Add_TrainingExample(Image_B_1);
	RecognitionNeuron.Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuron.Add_TrainingExample(Image_B_2);
	RecognitionNeuron.Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	
	RecognitionNeuron.Add_TrainingExample(Image_B_3);
	RecognitionNeuron.Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuron.Add_TrainingExample(Image_B_4);
	RecognitionNeuron.Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuron.Add_TrainingExample(Image_B_5);
	RecognitionNeuron.Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuron.Add_TrainingExample(Image_B_6);
	RecognitionNeuron.Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);


	for (int32_t i = 0; i < 256; i++)
	{
		Image_B_Mean1[i] = RecognitionNeuron.pDendrite_CentroidValueArray[i];
		Image_B_Mean2[i] = Image_B_Mean1[i];
		Image_B_Mean1[i] *= Image_B_Mean1[i];
	}


	CRandomNumbersNN RandomNumbers2;

	

	static constexpr int32_t ConstNumOfInputOutputValues = 16 * 16;
	//static constexpr int32_t ConstNumOfEncodingDendrites = 4;
	//static constexpr int32_t ConstNumOfEncodingDendrites = 8;
	static constexpr int32_t ConstNumOfEncodingDendrites = 4 * 4;
	//static constexpr int32_t ConstNumOfEncodingDendrites = 8 * 8;
	

	CRandomNumbersNN RandomNumbers;

	static constexpr int32_t ConstPrecedingNeuron_NumOfAdditionalMemoryValues = ConstNumOfInputOutputValues * ConstNumOfEncodingDendrites;

	static float RandomPlasticityArray[ConstPrecedingNeuron_NumOfAdditionalMemoryValues];
	Init_RandomNumbersTableExt2(RandomPlasticityArray, ConstPrecedingNeuron_NumOfAdditionalMemoryValues, &RandomNumbers, -1.0f, 1.0f, 0.5f);


	float OutputArray[ConstNumOfInputOutputValues];

	CSimpleNeuronAutoEncoder SimpleNeuronAutoEncoder;

	SimpleNeuronAutoEncoder.Init_PrecedingNeuron(ConstNumOfInputOutputValues, ConstNumOfEncodingDendrites, AutoencoderDendriticFunction2, RandomPlasticityArray, ConstPrecedingNeuron_NumOfAdditionalMemoryValues);

	SimpleNeuronAutoEncoder.Init_OutputNeuronArray(ConstNumOfInputOutputValues, ConstNumOfEncodingDendrites, AutoencoderOutputFunction, &RandomNumbers, -0.2f, 0.2f);




	int32_t maxCount = 20000;
	int32_t epoch = 0;
	float errorSum;

	for (int32_t ii = 0; ii < maxCount; ii++)
	{
		for (int32_t j = 0; j < ConstNumOfRandomTestImages; j++)
		{
			float *pImageValue = &RandomTestImageArray[j][0];

			for (int32_t i = 0; i < 256; i++)
			{
				if (Image_B_Mean1[i] == 0.0f)
				{
					pImageValue[i] = 0.0f;
				}
				else if (Image_B_Mean1[i] == 1.0f)
				{
					pImageValue[i] = 1.0f;
				}
				else
				{
					if (RandomNumbers2.Get_FloatNumber_IncludingZero(0.0f, 1.0f) > Image_B_Mean1[i])
					{
						pImageValue[i] = 0.0f;
					}
					else
					{
						pImageValue[i] = 1.0f;
					}
				}
			}
		}

		epoch++;
		errorSum = 0.0f;

		for (int32_t jj = 0; jj < ConstNumOfRandomTestImages; jj++)
		{

			SimpleNeuronAutoEncoder.PrecedingNeuron.Set_Dendrite_NeuronInput(&RandomTestImageArray[jj][0], ConstNumOfInputOutputValues);
			SimpleNeuronAutoEncoder.Calculate_Output();

			errorSum += SimpleNeuronAutoEncoder.OutputNeurons_ErrorCalculations(Image_B_Mean2, 1.0f, 1.0f);

			PrecedingNeuronLearning(&SimpleNeuronAutoEncoder.PrecedingNeuron, SimpleNeuronAutoEncoder.pOutputNeuronArray, ConstNumOfInputOutputValues, 0.02f, 1.0f, 1.0f);

			SimpleNeuronAutoEncoder.OutputNeurons_Adjust_Dendrite_Factors_AfterErrorCalculations(0.01f);
		}

		if (errorSum < 0.01f)
			//if (errorSum < 0.00001f)
			break;

		if (epoch % 100 == 0)
		{
			cout << "epoch: " << epoch << endl;
			cout << "error: " << errorSum << endl << endl;
		}
	}


	

	// training completed

	// training statistics:


	cout << "epoch: " << epoch << endl;
	cout << "error: " << errorSum << endl << endl;


	cout << "Image_B_1:" << endl;
	SimpleNeuronAutoEncoder.PrecedingNeuron.Set_Dendrite_NeuronInput(Image_B_1, ConstNumOfInputOutputValues);
	//cout << "RecognitionVarianceSq: " << SimpleNeuronAutoEncoder.Calculate_Output_Return_VarianceSq(Image_B_Mean2) << endl;
	cout << "RecognitionVarianceSq: " << static_cast<int32_t>(100.0f*SimpleNeuronAutoEncoder.Calculate_Output_Return_VarianceSq(Image_B_Mean2)) << endl;

	cout << "Image_B_2:" << endl;
	SimpleNeuronAutoEncoder.PrecedingNeuron.Set_Dendrite_NeuronInput(Image_B_2, ConstNumOfInputOutputValues);
	//cout << "RecognitionVarianceSq: " << SimpleNeuronAutoEncoder.Calculate_Output_Return_VarianceSq(Image_B_Mean2) << endl;
	cout << "RecognitionVarianceSq: " << static_cast<int32_t>(100.0f*SimpleNeuronAutoEncoder.Calculate_Output_Return_VarianceSq(Image_B_Mean2)) << endl;

	cout << "Image_B_3:" << endl;
	SimpleNeuronAutoEncoder.PrecedingNeuron.Set_Dendrite_NeuronInput(Image_B_3, ConstNumOfInputOutputValues);
	//cout << "RecognitionVarianceSq: " << SimpleNeuronAutoEncoder.Calculate_Output_Return_VarianceSq(Image_B_Mean2) << endl;
	cout << "RecognitionVarianceSq: " << static_cast<int32_t>(100.0f*SimpleNeuronAutoEncoder.Calculate_Output_Return_VarianceSq(Image_B_Mean2)) << endl;

	cout << "Image_B_4:" << endl;
	SimpleNeuronAutoEncoder.PrecedingNeuron.Set_Dendrite_NeuronInput(Image_B_4, ConstNumOfInputOutputValues);
	//cout << "RecognitionVarianceSq: " << SimpleNeuronAutoEncoder.Calculate_Output_Return_VarianceSq(Image_B_Mean2) << endl;
	cout << "RecognitionVarianceSq: " << static_cast<int32_t>(100.0f*SimpleNeuronAutoEncoder.Calculate_Output_Return_VarianceSq(Image_B_Mean2)) << endl;

	cout << "Image_B_5:" << endl;
	SimpleNeuronAutoEncoder.PrecedingNeuron.Set_Dendrite_NeuronInput(Image_B_5, ConstNumOfInputOutputValues);
	//cout << "RecognitionVarianceSq: " << SimpleNeuronAutoEncoder.Calculate_Output_Return_VarianceSq(Image_B_Mean2) << endl;
	cout << "RecognitionVarianceSq: " << static_cast<int32_t>(100.0f*SimpleNeuronAutoEncoder.Calculate_Output_Return_VarianceSq(Image_B_Mean2)) << endl;

	cout << "Image_B_6:" << endl;
	SimpleNeuronAutoEncoder.PrecedingNeuron.Set_Dendrite_NeuronInput(Image_B_6, ConstNumOfInputOutputValues);
	//cout << "RecognitionVarianceSq: " << SimpleNeuronAutoEncoder.Calculate_Output_Return_VarianceSq(Image_B_Mean2) << endl;
	cout << "RecognitionVarianceSq: " << static_cast<int32_t>(100.0f*SimpleNeuronAutoEncoder.Calculate_Output_Return_VarianceSq(Image_B_Mean2)) << endl;

	cout << "Image_8_1:" << endl;
	SimpleNeuronAutoEncoder.PrecedingNeuron.Set_Dendrite_NeuronInput(Image_8_1, ConstNumOfInputOutputValues);
	//cout << "RecognitionVarianceSq: " << SimpleNeuronAutoEncoder.Calculate_Output_Return_VarianceSq(Image_B_Mean2) << endl;
	cout << "RecognitionVarianceSq: " << static_cast<int32_t>(100.0f*SimpleNeuronAutoEncoder.Calculate_Output_Return_VarianceSq(Image_B_Mean2)) << endl;

	cout << "Image_8_2:" << endl;
	SimpleNeuronAutoEncoder.PrecedingNeuron.Set_Dendrite_NeuronInput(Image_8_2, ConstNumOfInputOutputValues);
	//cout << "RecognitionVarianceSq: " << SimpleNeuronAutoEncoder.Calculate_Output_Return_VarianceSq(Image_B_Mean2) << endl;
	cout << "RecognitionVarianceSq: " << static_cast<int32_t>(100.0f*SimpleNeuronAutoEncoder.Calculate_Output_Return_VarianceSq(Image_B_Mean2)) << endl;

	cout << "Image_8_3:" << endl;
	SimpleNeuronAutoEncoder.PrecedingNeuron.Set_Dendrite_NeuronInput(Image_8_3, ConstNumOfInputOutputValues);
	//cout << "RecognitionVarianceSq: " << SimpleNeuronAutoEncoder.Calculate_Output_Return_VarianceSq(Image_B_Mean2) << endl;
	cout << "RecognitionVarianceSq: " << static_cast<int32_t>(100.0f*SimpleNeuronAutoEncoder.Calculate_Output_Return_VarianceSq(Image_B_Mean2)) << endl;

	cout << "Image_8_4:" << endl;
	SimpleNeuronAutoEncoder.PrecedingNeuron.Set_Dendrite_NeuronInput(Image_8_4, ConstNumOfInputOutputValues);
	//cout << "RecognitionVarianceSq: " << SimpleNeuronAutoEncoder.Calculate_Output_Return_VarianceSq(Image_B_Mean2) << endl;
	cout << "RecognitionVarianceSq: " << static_cast<int32_t>(100.0f*SimpleNeuronAutoEncoder.Calculate_Output_Return_VarianceSq(Image_B_Mean2)) << endl;

	cout << "Image_8_5:" << endl;
	SimpleNeuronAutoEncoder.PrecedingNeuron.Set_Dendrite_NeuronInput(Image_8_5, ConstNumOfInputOutputValues);
	//cout << "RecognitionVarianceSq: " << SimpleNeuronAutoEncoder.Calculate_Output_Return_VarianceSq(Image_B_Mean2) << endl;
	cout << "RecognitionVarianceSq: " << static_cast<int32_t>(100.0f*SimpleNeuronAutoEncoder.Calculate_Output_Return_VarianceSq(Image_B_Mean2)) << endl;

	cout << "Image_8_6:" << endl;
	SimpleNeuronAutoEncoder.PrecedingNeuron.Set_Dendrite_NeuronInput(Image_8_6, ConstNumOfInputOutputValues);
	//cout << "RecognitionVarianceSq: " << SimpleNeuronAutoEncoder.Calculate_Output_Return_VarianceSq(Image_B_Mean2) << endl;
	cout << "RecognitionVarianceSq: " << static_cast<int32_t>(100.0f*SimpleNeuronAutoEncoder.Calculate_Output_Return_VarianceSq(Image_B_Mean2)) << endl;

	cout << endl;

	getchar();
	return 0;
}
*/

//LinearApproximationOutputFunction

/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	static constexpr int32_t NumInputOutputValues_Training = 11;

	float InputData[NumInputOutputValues_Training];
	float DesiredOutputData[NumInputOutputValues_Training];

	InputData[0] = -5.0f;
	InputData[1] = -4.0f;
	InputData[2] = -3.0f;
	InputData[3] = -2.0f;
	InputData[4] = 1.0f;
	InputData[5] = 0.0f;
	InputData[6] = 1.0f;
	InputData[7] = 2.0f;
	InputData[8] = 3.0f;
	InputData[9] = 4.0f;
	InputData[10] = 5.0f;

	// Output = a * Input  + offset

	float a = 1.0f;
	float offset = 1.0f;

	DesiredOutputData[0] = a * InputData[0] + offset + RandomNumbers.Get_FloatNumber_IncludingZero(-0.2f, 0.2f);
	DesiredOutputData[1] = a * InputData[1] + offset + RandomNumbers.Get_FloatNumber_IncludingZero(-0.2f, 0.2f);
	DesiredOutputData[2] = a * InputData[2] + offset + RandomNumbers.Get_FloatNumber_IncludingZero(-0.2f, 0.2f);
	DesiredOutputData[3] = a * InputData[3] + offset + RandomNumbers.Get_FloatNumber_IncludingZero(-0.2f, 0.2f);
	DesiredOutputData[4] = a * InputData[4] + offset + RandomNumbers.Get_FloatNumber_IncludingZero(-0.2f, 0.2f);
	DesiredOutputData[5] = a * InputData[5] + offset + RandomNumbers.Get_FloatNumber_IncludingZero(-0.2f, 0.2f);
	DesiredOutputData[6] = a * InputData[6] + offset + RandomNumbers.Get_FloatNumber_IncludingZero(-0.2f, 0.2f);
	DesiredOutputData[7] = a * InputData[7] + offset + RandomNumbers.Get_FloatNumber_IncludingZero(-0.2f, 0.2f);
	DesiredOutputData[8] = a * InputData[8] + offset + RandomNumbers.Get_FloatNumber_IncludingZero(-0.2f, 0.2f);
	DesiredOutputData[9] = a * InputData[9] + offset + RandomNumbers.Get_FloatNumber_IncludingZero(-0.2f, 0.2f);
	DesiredOutputData[10] = a * InputData[10] + offset + RandomNumbers.Get_FloatNumber_IncludingZero(-0.2f, 0.2f);


	for (int32_t i = 0; i < NumInputOutputValues_Training; i++)
	{
		cout << "input: " << InputData[i] << " => desired output: " << DesiredOutputData[i] << endl;
	}

	cout << endl;

	RandomNumbers.Change_Seed(12145);

	CSimpleNeuron Neuron;

	Neuron.Init_Dendrite_Arrays(2);
	Neuron.Set_ActivationFunction(LinearApproximationOutputFunction);
	Neuron.Randomize_Dendrite_Factors(&RandomNumbers, -2.2f, 2.2f);

	int32_t maxCount = 10000;
	int32_t epoch = 0;
	float errorSum;

	for (int32_t j = 0; j < maxCount; j++)
	{
		epoch++;
		errorSum = 0.0f;

		for (int32_t i = 0; i < NumInputOutputValues_Training; i++)
		{
			Neuron.Set_AdditionalInputValue(InputData[i]);
			Neuron.Calculate_NeuronOutput();
			errorSum += Neuron.Calculate_Error(DesiredOutputData[i], 1.0f, 0.001f);
			Neuron.Adjust_Dendrite_Factor_AfterErrorCalculations(0.01f, 0);
			Neuron.Adjust_Dendrite_Factors_AfterErrorCalculations(0.0001f, 1, Neuron.MaxDendriteID);
		}

		//if(j % 100 == 0)
			//cout << "error: " << errorSum << endl;

		if (errorSum < 0.0001f)
			break;
	}

	// training completed

	// training statistics:


	cout << "epoch: " << epoch << endl;
	cout << "error: " << errorSum << endl << endl;

	for (int32_t i = 0; i < NumInputOutputValues_Training; i++)
	{
		Neuron.Set_AdditionalInputValue(InputData[i]);
		Neuron.Calculate_NeuronOutput();

		cout << "input: " << InputData[i] << " => output: " << Neuron.ActivationValue << " => desired output: " << DesiredOutputData[i] << endl;
	}

	float testInput1 = 2.5f;
	float testOutput1 = a * testInput1 + offset;
	
	Neuron.Set_AdditionalInputValue(testInput1);
	Neuron.Calculate_NeuronOutput();

	cout << "test1: " << testInput1 << " => output: " << Neuron.ActivationValue << " => desired output: " << testOutput1 << endl;

	cout << endl;

	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	static constexpr int32_t NumInputOutputValues_Training = 11;

	float InputData[NumInputOutputValues_Training];
	float DesiredOutputData[NumInputOutputValues_Training];

	InputData[0] = -5.0f;
	InputData[1] = -4.0f;
	InputData[2] = -3.0f;
	InputData[3] = -2.0f;
	InputData[4] = 1.0f;
	InputData[5] = 0.0f;
	InputData[6] = 1.0f;
	InputData[7] = 2.0f;
	InputData[8] = 3.0f;
	InputData[9] = 4.0f;
	InputData[10] = 5.0f;


	// Output = (a * Input * Input * Input * Input + b * Input * Input * Input + c * Input * Input + d * Input + offset)

	float a = -0.1f;
	float b = 0.5f;
	float c = 1.65f;
	float d = -0.85f;
	float offset = 1.0f;

	for (int32_t i = 0; i < NumInputOutputValues_Training; i++)
	{
		DesiredOutputData[i] = offset;
		DesiredOutputData[i] += a * InputData[i] * InputData[i] * InputData[i] * InputData[i];
		DesiredOutputData[i] += b * InputData[i] * InputData[i] * InputData[i];
		DesiredOutputData[i] += c * InputData[i] * InputData[i];
		DesiredOutputData[i] += d * InputData[i];
	}


	for (int32_t i = 0; i <NumInputOutputValues_Training; i++)
	{
		cout << "input: " << InputData[i] << " => desired output: " << DesiredOutputData[i] << endl;
	}

	cout << endl;

	CSimpleNeuron Neuron;

	Neuron.Init_Dendrite_Arrays(13);
	Neuron.Set_ActivationFunction(PolynomApproximationOutputFunction);
	Neuron.Randomize_Dendrite_Factors(&RandomNumbers, -2.2f, 2.2f);

	int32_t maxCount = 4000000;
	int32_t epoch = 0;
	float errorSum;

	for (int32_t j = 0; j < maxCount; j++)
	{
		epoch++;
		errorSum = 0.0f;

		for (int32_t i = 0; i < NumInputOutputValues_Training; i++)
		{
			Neuron.Set_AdditionalInputValue(InputData[i]);
			Neuron.Calculate_NeuronOutput();
			errorSum += Neuron.Calculate_Error(DesiredOutputData[i], 1.0f, 0.001f);
			Neuron.Adjust_Dendrite_Factor_AfterErrorCalculations(0.001f, 0);
			Neuron.Adjust_Dendrite_Factors_AfterErrorCalculations(0.00001f, 1, Neuron.MaxDendriteID);
		}

		if (errorSum < 0.0001f)
			break;
	}

	// training completed

	// training statistics:


	cout << "epoch: " << epoch << endl;
	cout << "error: " << errorSum << endl << endl;

	for (int32_t i = 0; i < NumInputOutputValues_Training; i++)
	{
		Neuron.Set_AdditionalInputValue(InputData[i]);
		Neuron.Calculate_NeuronOutput();

		cout << "input: " << InputData[i] << " => output: " << Neuron.ActivationValue << " => desired output: " << DesiredOutputData[i] << endl;
	}

	float testInput1 = 2.5f;

	float testOutput1 = offset;
	testOutput1 += a * testInput1 * testInput1 * testInput1 * testInput1;
	testOutput1 += b * testInput1 * testInput1 * testInput1;
	testOutput1 += c * testInput1 * testInput1;
	testOutput1 += d * testInput1;

	Neuron.Set_AdditionalInputValue(testInput1);
	Neuron.Calculate_NeuronOutput();

	cout << "test1: " << testInput1 << " => output: " << Neuron.ActivationValue << " => desired output: " << testOutput1 << endl;

	cout << endl;

	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	static constexpr int32_t NumInputOutputValues_Training = 11;
	//static constexpr int32_t TrainingPopulationSize = 100;
	static constexpr int32_t TrainingPopulationSize = 50;
	static constexpr int32_t NumTrainingGenerationsMax = 200000;

	float InputData[NumInputOutputValues_Training];
	float DesiredOutputData[NumInputOutputValues_Training];

	InputData[0] = -5.0f;
	InputData[1] = -4.0f;
	InputData[2] = -3.0f;
	InputData[3] = -2.0f;
	InputData[4] = 1.0f;
	InputData[5] = 0.0f;
	InputData[6] = 1.0f;
	InputData[7] = 2.0f;
	InputData[8] = 3.0f;
	InputData[9] = 4.0f;
	InputData[10] = 5.0f;


	// Output = (a * Input * Input * Input * Input + b * Input * Input * Input + c * Input * Input + d * Input + offset)

	float a = -0.1f;
	float b = 0.5f;
	float c = 1.65f;
	float d = -0.85f;
	float offset = 1.0f;

	for (int32_t i = 0; i < NumInputOutputValues_Training; i++)
	{
		DesiredOutputData[i] = offset;
		DesiredOutputData[i] += a * InputData[i] * InputData[i] * InputData[i] * InputData[i];
		DesiredOutputData[i] += b * InputData[i] * InputData[i] * InputData[i];
		DesiredOutputData[i] += c * InputData[i] * InputData[i];
		DesiredOutputData[i] += d * InputData[i];
	}


	for (int32_t i = 0; i <NumInputOutputValues_Training; i++)
	{
		cout << "input: " << InputData[i] << " => desired output: " << DesiredOutputData[i] << endl;
	}

	cout << endl;


	static CSimpleNeuron NeuronArray[TrainingPopulationSize];
	static float FitnessScoreArray[TrainingPopulationSize];

	CSimpleNeuronPopulation NeuronPopulation;

	NeuronPopulation.Initialize(TrainingPopulationSize);

	for (int32_t i = 0; i < TrainingPopulationSize; i++)
	{
		NeuronPopulation.Set_Neuron(&NeuronArray[i], i);
		FitnessScoreArray[i] = 0.0f;
	}

	NeuronPopulation.Set_ActivationFunction(SimplePolynomApproximationOutputFunction);
	NeuronPopulation.Init_Or_Reinitialize_Dendrite_Arrays(5);

	NeuronPopulation.Randomize_Dendrite_Factors(-2.0f, 2.0f);

	float output;
	float desiredOutput;
	float errorSum;

	for (int32_t j = 0; j < NumTrainingGenerationsMax; j++)
	{
		NeuronPopulation.Reset_MinErrorSum_ActualGeneration();

		for (int32_t i = 0; i < TrainingPopulationSize; i++)
		{
			FitnessScoreArray[i] = 0.0f;
			errorSum = 0.0f;

			for (int32_t k = 0; k < NumInputOutputValues_Training; k++)
			{
				NeuronArray[i].Set_AdditionalInputValue(InputData[k]);
				NeuronArray[i].Calculate_NeuronOutput();

				errorSum += NeuronArray[i].Calculate_VarianceSq(DesiredOutputData[k]);
			}

			FitnessScoreArray[i] = 1.0f / (errorSum + 0.01f);

			NeuronPopulation.Update_MinErrorSum_ActualGeneration(errorSum);
		}

		NeuronPopulation.Update_Population(FitnessScoreArray);

		if (NeuronPopulation.MinErrorSum_ActualGeneration < 0.1f)
		{
			cout << "actual generation: " << j << endl;
			cout << "training completed" << endl << endl;
			break;
		}

		NeuronPopulation.Update_BaseEvolution(PolynomApproximation_MutationFunction, nullptr);
		NeuronPopulation.Update_Evolution_BestBrainOnly(PolynomApproximation_MutationFunction, nullptr);
		NeuronPopulation.Update_Evolution_SecondBestBrainOnly(PolynomApproximation_MutationFunction, nullptr);
		NeuronPopulation.Update_Evolution_Combine_BestTwoBrains(PolynomApproximation_RecombinationFunction, nullptr);
		NeuronPopulation.Update_Evolution_Combine_TwoBrains(PolynomApproximation_RecombinationFunction, nullptr);
		//NeuronPopulation.Update_Evolution_Combine_TwoBrains(PolynomApproximation_RecombinationFunction, nullptr);
	}

	CSimpleNeuron BestNeuron;

	NeuronPopulation.Get_Best_Evolved_Neuron(&BestNeuron);

	for (int32_t i = 0; i < NumInputOutputValues_Training; i++)
	{
		BestNeuron.Set_AdditionalInputValue(InputData[i]);
		BestNeuron.Calculate_NeuronOutput();

		cout << "input: " << InputData[i] << " => output: " << BestNeuron.ActivationValue << " => desired output: " << DesiredOutputData[i] << endl;
	}

	float testInput1 = 2.5f;

	float testOutput1 = offset;
	testOutput1 += a * testInput1 * testInput1 * testInput1 * testInput1;
	testOutput1 += b * testInput1 * testInput1 * testInput1;
	testOutput1 += c * testInput1 * testInput1;
	testOutput1 += d * testInput1;

	BestNeuron.Set_AdditionalInputValue(testInput1);
	BestNeuron.Calculate_NeuronOutput();

	cout << "test1: " << testInput1 << " => output: " << BestNeuron.ActivationValue << " => desired output: " << testOutput1 << endl;

	cout << endl;

	getchar();
	return 0;
}
//*/





/*
int main(void)
{
	static float Image_B_1[16 * 16];
	static float Image_B_2[16 * 16];
	static float Image_B_3[16 * 16];
	static float Image_B_4[16 * 16];
	static float Image_B_5[16 * 16];
	static float Image_B_6[16 * 16];

	static float Image_8_1[16 * 16];
	static float Image_8_2[16 * 16];
	static float Image_8_3[16 * 16];
	static float Image_8_4[16 * 16];
	static float Image_8_5[16 * 16];
	static float Image_8_6[16 * 16];

	static float Image_5_1[16 * 16];
	static float Image_5_2[16 * 16];
	static float Image_5_3[16 * 16];
	static float Image_5_4[16 * 16];
	static float Image_5_5[16 * 16];
	static float Image_5_6[16 * 16];

	static float Image_6_1[16 * 16];
	static float Image_6_2[16 * 16];
	static float Image_6_3[16 * 16];
	static float Image_6_4[16 * 16];
	static float Image_6_5[16 * 16];
	static float Image_6_6[16 * 16];

	static float Image_G_1[16 * 16];
	static float Image_G_2[16 * 16];
	static float Image_G_3[16 * 16];
	static float Image_G_4[16 * 16];
	static float Image_G_5[16 * 16];
	static float Image_G_6[16 * 16];

	static float Image_S_1[16 * 16];
	static float Image_S_2[16 * 16];
	static float Image_S_3[16 * 16];
	static float Image_S_4[16 * 16];
	static float Image_S_5[16 * 16];
	static float Image_S_6[16 * 16];

	static float tempImage[32 * 32];

	uint8_t *pImageData = nullptr;

	

	pImageData = Read_Bitmap_BGR("Sample_B_1.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_B_1, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_2.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_B_2, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_3.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_B_3, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_4.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_B_4, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_5.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_B_5, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_6.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_B_6, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	///////////////////////////////

	

	pImageData = Read_Bitmap_BGR("Sample_8_1.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_8_1, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_2.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_8_2, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_3.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_8_3, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_4.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_8_4, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_5.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_8_5, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_6.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_8_6, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	//////////////////////////////

	

	pImageData = Read_Bitmap_BGR("Sample_5_1.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_5_1, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_2.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_5_2, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_3.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_5_3, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_4.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_5_4, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_5.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_5_5, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_6.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_5_6, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	//////////////////////////////

	

	pImageData = Read_Bitmap_BGR("Sample_6_1.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_6_1, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_2.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_6_2, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_3.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_6_3, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_4.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_6_4, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_5.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_6_5, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_6.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_6_6, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	//////////////////////////////

	

	pImageData = Read_Bitmap_BGR("Sample_G_1.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_G_1, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_2.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_G_2, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_3.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_G_3, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_4.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_G_4, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_5.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_G_5, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_6.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_G_6, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	//////////////////////////////

	

	pImageData = Read_Bitmap_BGR("Sample_S_1.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_S_1, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_2.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_S_2, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_3.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_S_3, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_4.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_S_4, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_5.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_S_5, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_6.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_S_6, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	//////////////////////////////


	CSingleRecognitionNeuronEnsemble RecognitionNeuronEnsemble;

	char RecognizedSymbolArray[7] = { 'B', '8', '5', '6', 'G', 'S', '\0' };

	// 6 Symbols (B, 8, 5, 6, G, S) => 6 Neurons
	RecognitionNeuronEnsemble.Init_NeuronArray(6, 16 * 16, SimpleRecognitionOutputFunction16x16);
	RecognitionNeuronEnsemble.Reset_NumOfTrainingExamples();

	float fallback_RBF_Factor = 0.5f;
	float centroidWeightFactor = 0.025f;
	int32_t centroidExponent = 4;

	//float fallback_RBF_Factor = 10.0f;
	//float centroidWeightFactor = 0.025f;
	//int32_t centroidExponent = 2;

	

	RecognitionNeuronEnsemble.pNeuronArray[0].Add_TrainingExample(Image_B_1);
	RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[0].Add_TrainingExample(Image_B_2);
	RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[0].Add_TrainingExample(Image_B_3);
	RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[0].Add_TrainingExample(Image_B_4);
	RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	
	/////////

	RecognitionNeuronEnsemble.pNeuronArray[0].Add_TrainingExample(Image_B_5);
	RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[0].Add_TrainingExample(Image_B_6);
	RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);



	
	RecognitionNeuronEnsemble.pNeuronArray[1].Add_TrainingExample(Image_8_1);
	RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[1].Add_TrainingExample(Image_8_2);
	RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[1].Add_TrainingExample(Image_8_3);
	RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[1].Add_TrainingExample(Image_8_4);
	RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	
	///////////

	RecognitionNeuronEnsemble.pNeuronArray[1].Add_TrainingExample(Image_8_5);
	RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[1].Add_TrainingExample(Image_8_6);
	RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);


	
	RecognitionNeuronEnsemble.pNeuronArray[2].Add_TrainingExample(Image_5_1);
	RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[2].Add_TrainingExample(Image_5_2);
	RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[2].Add_TrainingExample(Image_5_3);
	RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[2].Add_TrainingExample(Image_5_4);
	RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	
	//////

	RecognitionNeuronEnsemble.pNeuronArray[2].Add_TrainingExample(Image_5_5);
	RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[2].Add_TrainingExample(Image_5_6);
	RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);


	
	RecognitionNeuronEnsemble.pNeuronArray[3].Add_TrainingExample(Image_6_1);
	RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[3].Add_TrainingExample(Image_6_2);
	RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[3].Add_TrainingExample(Image_6_3);
	RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[3].Add_TrainingExample(Image_6_4);
	RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	
	//
	RecognitionNeuronEnsemble.pNeuronArray[3].Add_TrainingExample(Image_6_5);
	RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[3].Add_TrainingExample(Image_6_6);
	RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);




	RecognitionNeuronEnsemble.pNeuronArray[4].Add_TrainingExample(Image_G_1);
	RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[4].Add_TrainingExample(Image_G_2);
	RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[4].Add_TrainingExample(Image_G_3);
	RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[4].Add_TrainingExample(Image_G_4);
	RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	
	//
	RecognitionNeuronEnsemble.pNeuronArray[4].Add_TrainingExample(Image_G_5);
	RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[4].Add_TrainingExample(Image_G_6);
	RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);


	
	RecognitionNeuronEnsemble.pNeuronArray[5].Add_TrainingExample(Image_S_1);
	RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[5].Add_TrainingExample(Image_S_2);
	RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[5].Add_TrainingExample(Image_S_3);
	RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[5].Add_TrainingExample(Image_S_4);
	RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	
	//
	RecognitionNeuronEnsemble.pNeuronArray[5].Add_TrainingExample(Image_S_5);
	RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[5].Add_TrainingExample(Image_S_6);
	RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	

	//////////////////////////////

	float maxActivationValue;
	int32_t belongingNeuronID;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_B_1, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_B_2, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_B_3, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_B_4, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_B_5, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_B_6, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl << endl;

	cout << "press enter: ";
	getchar();

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_8_1, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_8_2, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_8_3, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_8_4, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_8_5, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_8_6, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl << endl;

	cout << "press enter: ";
	getchar();

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_5_1, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_5_2, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_5_3, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_5_4, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_5_5, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_5_6, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl << endl;

	cout << "press enter: ";
	getchar();


	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_6_1, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_6_2, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_6_3, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_6_4, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_6_5, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_6_6, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl << endl;

	cout << "press enter: ";
	getchar();

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_G_1, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_G_2, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_G_3, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_G_4, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_G_5, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_G_6, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl << endl;

	cout << "press enter: ";
	getchar();

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_S_1, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;


	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_S_2, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;


	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_S_3, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_S_4, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_S_5, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_S_6, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl << endl;

	//////////////////////////////


	getchar();
	return 0;
}
*/

/*
int main(void)
{
	static float Image_B_1[16 * 16];
	static float Image_B_2[16 * 16];
	static float Image_B_3[16 * 16];
	static float Image_B_4[16 * 16];
	static float Image_B_5[16 * 16];
	static float Image_B_6[16 * 16];

	static float Image_8_1[16 * 16];
	static float Image_8_2[16 * 16];
	static float Image_8_3[16 * 16];
	static float Image_8_4[16 * 16];
	static float Image_8_5[16 * 16];
	static float Image_8_6[16 * 16];

	static float Image_5_1[16 * 16];
	static float Image_5_2[16 * 16];
	static float Image_5_3[16 * 16];
	static float Image_5_4[16 * 16];
	static float Image_5_5[16 * 16];
	static float Image_5_6[16 * 16];

	static float Image_6_1[16 * 16];
	static float Image_6_2[16 * 16];
	static float Image_6_3[16 * 16];
	static float Image_6_4[16 * 16];
	static float Image_6_5[16 * 16];
	static float Image_6_6[16 * 16];

	static float Image_G_1[16 * 16];
	static float Image_G_2[16 * 16];
	static float Image_G_3[16 * 16];
	static float Image_G_4[16 * 16];
	static float Image_G_5[16 * 16];
	static float Image_G_6[16 * 16];

	static float Image_S_1[16 * 16];
	static float Image_S_2[16 * 16];
	static float Image_S_3[16 * 16];
	static float Image_S_4[16 * 16];
	static float Image_S_5[16 * 16];
	static float Image_S_6[16 * 16];

	static float tempImage[32 * 32];

	uint8_t *pImageData = nullptr;



	pImageData = Read_Bitmap_BGR("Sample_B_1.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_B_1, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_2.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_B_2, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_3.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_B_3, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_4.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_B_4, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_5.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_B_5, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_6.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_B_6, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	///////////////////////////////



	pImageData = Read_Bitmap_BGR("Sample_8_1.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_8_1, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_2.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_8_2, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_3.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_8_3, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_4.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_8_4, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_5.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_8_5, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_6.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_8_6, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	//////////////////////////////



	pImageData = Read_Bitmap_BGR("Sample_5_1.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_5_1, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_2.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_5_2, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_3.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_5_3, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_4.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_5_4, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_5.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_5_5, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_6.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_5_6, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	//////////////////////////////



	pImageData = Read_Bitmap_BGR("Sample_6_1.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_6_1, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_2.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_6_2, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_3.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_6_3, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_4.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_6_4, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_5.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_6_5, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_6.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_6_6, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	//////////////////////////////



	pImageData = Read_Bitmap_BGR("Sample_G_1.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_G_1, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_2.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_G_2, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_3.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_G_3, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_4.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_G_4, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_5.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_G_5, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_6.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_G_6, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	//////////////////////////////



	pImageData = Read_Bitmap_BGR("Sample_S_1.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_S_1, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_2.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_S_2, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_3.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_S_3, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_4.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_S_4, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_5.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_S_5, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_6.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	MaxPooling2x2(Image_S_6, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	//////////////////////////////


	CSingleRecognitionNeuronEnsemble RecognitionNeuronEnsemble;

	char RecognizedSymbolArray[7] = { 'B', '8', '5', '6', 'G', 'S', '\0' };

	// 6 Symbols (B, 8, 5, 6, G, S) => 6 Neurons
	RecognitionNeuronEnsemble.Init_NeuronArray(6, 16 * 16, SimpleRecognitionOutputFunction16x16);
	RecognitionNeuronEnsemble.Reset_NumOfTrainingExamples();

	float fallback_RBF_Factor = 0.5f;
	float centroidWeightFactor = 0.025f;
	int32_t centroidExponent = 4;

	//float fallback_RBF_Factor = 10.0f;
	//float centroidWeightFactor = 0.025f;
	//int32_t centroidExponent = 2;

	float recognitionThreshold = 0.98f;

	RecognitionNeuronEnsemble.pNeuronArray[0].Add_TrainingExample(Image_B_1);
	RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[0].Set_Dendrite_NeuronInput(0, 0, Image_B_2, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[0].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_B_2" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[0].Add_TrainingExample(Image_B_2);
		RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[0].Set_Dendrite_NeuronInput(0, 0, Image_B_3, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[0].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_B_3" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[0].Add_TrainingExample(Image_B_3);
		RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[0].Set_Dendrite_NeuronInput(0, 0, Image_B_4, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[0].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_B_4" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[0].Add_TrainingExample(Image_B_4);
		RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}
	
	RecognitionNeuronEnsemble.pNeuronArray[0].Set_Dendrite_NeuronInput(0, 0, Image_B_5, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[0].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_B_5" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[0].Add_TrainingExample(Image_B_5);
		RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[0].Set_Dendrite_NeuronInput(0, 0, Image_B_6, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[0].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_B_6" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[0].Add_TrainingExample(Image_B_6);
		RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}



	RecognitionNeuronEnsemble.pNeuronArray[1].Add_TrainingExample(Image_8_1);
	RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[1].Set_Dendrite_NeuronInput(0, 0, Image_8_2, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[1].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_8_2" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[1].Add_TrainingExample(Image_8_2);
		RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[1].Set_Dendrite_NeuronInput(0, 0, Image_8_3, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[1].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_8_3" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[1].Add_TrainingExample(Image_8_3);
		RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[1].Set_Dendrite_NeuronInput(0, 0, Image_8_4, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[1].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_8_4" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[1].Add_TrainingExample(Image_8_4);
		RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}
	

	RecognitionNeuronEnsemble.pNeuronArray[1].Set_Dendrite_NeuronInput(0, 0, Image_8_5, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[1].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_8_5" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[1].Add_TrainingExample(Image_8_5);
		RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[1].Set_Dendrite_NeuronInput(0, 0, Image_8_6, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[1].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_8_6" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[1].Add_TrainingExample(Image_8_6);
		RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}


	RecognitionNeuronEnsemble.pNeuronArray[2].Add_TrainingExample(Image_5_1);
	RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[2].Set_Dendrite_NeuronInput(0, 0, Image_5_2, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[2].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_5_2" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[2].Add_TrainingExample(Image_5_2);
		RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[2].Set_Dendrite_NeuronInput(0, 0, Image_5_3, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[2].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_5_3" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[2].Add_TrainingExample(Image_5_3);
		RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[2].Set_Dendrite_NeuronInput(0, 0, Image_5_4, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[2].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_5_4" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[2].Add_TrainingExample(Image_5_4);
		RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[2].Set_Dendrite_NeuronInput(0, 0, Image_5_5, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[2].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_5_5" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[2].Add_TrainingExample(Image_5_5);
		RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[2].Set_Dendrite_NeuronInput(0, 0, Image_5_6, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[2].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_5_6" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[2].Add_TrainingExample(Image_5_6);
		RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}


	RecognitionNeuronEnsemble.pNeuronArray[3].Add_TrainingExample(Image_6_1);
	RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[3].Set_Dendrite_NeuronInput(0, 0, Image_6_2, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[3].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_6_2" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[3].Add_TrainingExample(Image_6_2);
		RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[3].Set_Dendrite_NeuronInput(0, 0, Image_6_3, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[3].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_6_3" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[3].Add_TrainingExample(Image_6_3);
		RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[3].Set_Dendrite_NeuronInput(0, 0, Image_6_4, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[3].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_6_4" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[3].Add_TrainingExample(Image_6_4);
		RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}
	
	RecognitionNeuronEnsemble.pNeuronArray[3].Set_Dendrite_NeuronInput(0, 0, Image_6_5, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[3].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_6_5" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[3].Add_TrainingExample(Image_6_5);
		RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[3].Set_Dendrite_NeuronInput(0, 0, Image_6_6, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[3].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_6_6" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[3].Add_TrainingExample(Image_6_6);
		RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}



	RecognitionNeuronEnsemble.pNeuronArray[4].Add_TrainingExample(Image_G_1);
	RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[4].Set_Dendrite_NeuronInput(0, 0, Image_G_2, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[4].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_G_2" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[4].Add_TrainingExample(Image_G_2);
		RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[4].Set_Dendrite_NeuronInput(0, 0, Image_G_3, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[4].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_G_3" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[4].Add_TrainingExample(Image_G_3);
		RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[4].Set_Dendrite_NeuronInput(0, 0, Image_G_4, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[4].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_G_4" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[4].Add_TrainingExample(Image_G_4);
		RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[4].Set_Dendrite_NeuronInput(0, 0, Image_G_5, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[4].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_G_5" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[4].Add_TrainingExample(Image_G_5);
		RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[4].Set_Dendrite_NeuronInput(0, 0, Image_G_6, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[4].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_G_6" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[4].Add_TrainingExample(Image_G_6);
		RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}


	RecognitionNeuronEnsemble.pNeuronArray[5].Add_TrainingExample(Image_S_1);
	RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[5].Set_Dendrite_NeuronInput(0, 0, Image_S_2, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[5].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_S_2" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[5].Add_TrainingExample(Image_S_2);
		RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[5].Set_Dendrite_NeuronInput(0, 0, Image_S_3, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[5].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_S_3" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[5].Add_TrainingExample(Image_S_3);
		RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[5].Set_Dendrite_NeuronInput(0, 0, Image_S_4, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[5].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_S_4" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[5].Add_TrainingExample(Image_S_4);
		RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}
	
	RecognitionNeuronEnsemble.pNeuronArray[5].Set_Dendrite_NeuronInput(0, 0, Image_S_5, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[5].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_S_5" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[5].Add_TrainingExample(Image_S_5);
		RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[5].Set_Dendrite_NeuronInput(0, 0, Image_S_6, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[5].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_S_6" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[5].Add_TrainingExample(Image_S_6);
		RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	cout << endl;
	//////////////////////////////

	float maxActivationValue;
	int32_t belongingNeuronID;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_B_1, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_B_2, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_B_3, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_B_4, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_B_5, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_B_6, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl << endl;

	cout << "press enter: ";
	getchar();

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_8_1, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_8_2, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_8_3, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_8_4, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_8_5, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_8_6, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl << endl;

	cout << "press enter: ";
	getchar();

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_5_1, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_5_2, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_5_3, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_5_4, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_5_5, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_5_6, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl << endl;

	cout << "press enter: ";
	getchar();


	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_6_1, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_6_2, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_6_3, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_6_4, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_6_5, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_6_6, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl << endl;

	cout << "press enter: ";
	getchar();

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_G_1, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_G_2, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_G_3, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_G_4, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_G_5, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_G_6, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl << endl;

	cout << "press enter: ";
	getchar();

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_S_1, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;


	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_S_2, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;


	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_S_3, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_S_4, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_S_5, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_S_6, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl << endl;

	//////////////////////////////


	getchar();
	return 0;
}
*/


/*
int main(void)
{
	static float Image_B_1[16 * 16];
	static float Image_B_2[16 * 16];
	static float Image_B_3[16 * 16];
	static float Image_B_4[16 * 16];
	static float Image_B_5[16 * 16];
	static float Image_B_6[16 * 16];

	static float Image_8_1[16 * 16];
	static float Image_8_2[16 * 16];
	static float Image_8_3[16 * 16];
	static float Image_8_4[16 * 16];
	static float Image_8_5[16 * 16];
	static float Image_8_6[16 * 16];

	static float Image_5_1[16 * 16];
	static float Image_5_2[16 * 16];
	static float Image_5_3[16 * 16];
	static float Image_5_4[16 * 16];
	static float Image_5_5[16 * 16];
	static float Image_5_6[16 * 16];

	static float Image_6_1[16 * 16];
	static float Image_6_2[16 * 16];
	static float Image_6_3[16 * 16];
	static float Image_6_4[16 * 16];
	static float Image_6_5[16 * 16];
	static float Image_6_6[16 * 16];

	static float Image_G_1[16 * 16];
	static float Image_G_2[16 * 16];
	static float Image_G_3[16 * 16];
	static float Image_G_4[16 * 16];
	static float Image_G_5[16 * 16];
	static float Image_G_6[16 * 16];

	static float Image_S_1[16 * 16];
	static float Image_S_2[16 * 16];
	static float Image_S_3[16 * 16];
	static float Image_S_4[16 * 16];
	static float Image_S_5[16 * 16];
	static float Image_S_6[16 * 16];

	static float tempImage[32 * 32];

	uint8_t *pImageData = nullptr;


	pImageData = Read_Bitmap_BGR("Sample_B_1.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	NearestPointImageScaling(Image_B_1, 16, 16, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_2.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	NearestPointImageScaling(Image_B_2, 16, 16, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_3.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	NearestPointImageScaling(Image_B_3, 16, 16, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_4.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	NearestPointImageScaling(Image_B_4, 16, 16, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_5.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	NearestPointImageScaling(Image_B_5, 16, 16, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_6.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	NearestPointImageScaling(Image_B_6, 16, 16, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	///////////////////////////////

	pImageData = Read_Bitmap_BGR("Sample_8_1.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	NearestPointImageScaling(Image_8_1, 16, 16, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_2.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	NearestPointImageScaling(Image_8_2, 16, 16, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_3.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	NearestPointImageScaling(Image_8_3, 16, 16, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_4.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	NearestPointImageScaling(Image_8_4, 16, 16, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_5.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	NearestPointImageScaling(Image_8_5, 16, 16, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_6.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	NearestPointImageScaling(Image_8_6, 16, 16, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	//////////////////////////////

	pImageData = Read_Bitmap_BGR("Sample_5_1.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	NearestPointImageScaling(Image_5_1, 16, 16, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_2.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	NearestPointImageScaling(Image_5_2, 16, 16, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_3.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	NearestPointImageScaling(Image_5_3, 16, 16, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_4.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	NearestPointImageScaling(Image_5_4, 16, 16, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_5.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	NearestPointImageScaling(Image_5_5, 16, 16, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_6.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	NearestPointImageScaling(Image_5_5, 16, 16, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	//////////////////////////////

	pImageData = Read_Bitmap_BGR("Sample_6_1.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	NearestPointImageScaling(Image_6_1, 16, 16, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_2.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	NearestPointImageScaling(Image_6_2, 16, 16, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_3.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	NearestPointImageScaling(Image_6_3, 16, 16, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_4.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	NearestPointImageScaling(Image_6_4, 16, 16, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_5.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	NearestPointImageScaling(Image_6_5, 16, 16, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_6.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	NearestPointImageScaling(Image_6_6, 16, 16, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	//////////////////////////////

	pImageData = Read_Bitmap_BGR("Sample_G_1.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	NearestPointImageScaling(Image_G_1, 16, 16, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_2.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	NearestPointImageScaling(Image_G_2, 16, 16, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_3.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	NearestPointImageScaling(Image_G_3, 16, 16, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_4.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	NearestPointImageScaling(Image_G_4, 16, 16, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_5.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	NearestPointImageScaling(Image_G_5, 16, 16, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_6.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	NearestPointImageScaling(Image_G_6, 16, 16, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	//////////////////////////////

	pImageData = Read_Bitmap_BGR("Sample_S_1.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	NearestPointImageScaling(Image_S_1, 16, 16, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_2.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	NearestPointImageScaling(Image_S_2, 16, 16, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_3.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	NearestPointImageScaling(Image_S_3, 16, 16, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_4.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	NearestPointImageScaling(Image_S_4, 16, 16, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_5.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	NearestPointImageScaling(Image_S_5, 16, 16, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_6.bmp");
	Get_BinaryImageData_BlueChannel(tempImage, pImageData, 32, 32);
	NearestPointImageScaling(Image_S_6, 16, 16, tempImage, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	//////////////////////////////


	CSingleRecognitionNeuronEnsemble RecognitionNeuronEnsemble;

	char RecognizedSymbolArray[7] = { 'B', '8', '5', '6', 'G', 'S', '\0' };

	// 6 Symbols (B, 8, 5, 6, G, S) => 6 Neurons
	RecognitionNeuronEnsemble.Init_NeuronArray(6, 16 * 16, SimpleRecognitionOutputFunction16x16);
	RecognitionNeuronEnsemble.Reset_NumOfTrainingExamples();

	float fallback_RBF_Factor = 0.5f;
	float centroidWeightFactor = 0.025f;
	int32_t centroidExponent = 4;

	//float fallback_RBF_Factor = 10.0f;
	//float centroidWeightFactor = 0.025f;
	//int32_t centroidExponent = 2;

	float recognitionThreshold = 0.98f;

	RecognitionNeuronEnsemble.pNeuronArray[0].Add_TrainingExample(Image_B_1);
	RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[0].Set_Dendrite_NeuronInput(0, 0, Image_B_2, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[0].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_B_2" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[0].Add_TrainingExample(Image_B_2);
		RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[0].Set_Dendrite_NeuronInput(0, 0, Image_B_3, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[0].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_B_3" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[0].Add_TrainingExample(Image_B_3);
		RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[0].Set_Dendrite_NeuronInput(0, 0, Image_B_4, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[0].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_B_4" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[0].Add_TrainingExample(Image_B_4);
		RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[0].Set_Dendrite_NeuronInput(0, 0, Image_B_5, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[0].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_B_5" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[0].Add_TrainingExample(Image_B_5);
		RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[0].Set_Dendrite_NeuronInput(0, 0, Image_B_6, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[0].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_B_6" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[0].Add_TrainingExample(Image_B_6);
		RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}



	RecognitionNeuronEnsemble.pNeuronArray[1].Add_TrainingExample(Image_8_1);
	RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[1].Set_Dendrite_NeuronInput(0, 0, Image_8_2, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[1].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_8_2" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[1].Add_TrainingExample(Image_8_2);
		RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[1].Set_Dendrite_NeuronInput(0, 0, Image_8_3, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[1].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_8_3" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[1].Add_TrainingExample(Image_8_3);
		RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[1].Set_Dendrite_NeuronInput(0, 0, Image_8_4, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[1].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_8_4" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[1].Add_TrainingExample(Image_8_4);
		RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}


	RecognitionNeuronEnsemble.pNeuronArray[1].Set_Dendrite_NeuronInput(0, 0, Image_8_5, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[1].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_8_5" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[1].Add_TrainingExample(Image_8_5);
		RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[1].Set_Dendrite_NeuronInput(0, 0, Image_8_6, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[1].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_8_6" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[1].Add_TrainingExample(Image_8_6);
		RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}


	RecognitionNeuronEnsemble.pNeuronArray[2].Add_TrainingExample(Image_5_1);
	RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[2].Set_Dendrite_NeuronInput(0, 0, Image_5_2, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[2].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_5_2" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[2].Add_TrainingExample(Image_5_2);
		RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[2].Set_Dendrite_NeuronInput(0, 0, Image_5_3, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[2].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_5_3" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[2].Add_TrainingExample(Image_5_3);
		RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[2].Set_Dendrite_NeuronInput(0, 0, Image_5_4, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[2].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_5_4" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[2].Add_TrainingExample(Image_5_4);
		RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[2].Set_Dendrite_NeuronInput(0, 0, Image_5_5, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[2].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_5_5" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[2].Add_TrainingExample(Image_5_5);
		RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[2].Set_Dendrite_NeuronInput(0, 0, Image_5_6, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[2].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_5_6" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[2].Add_TrainingExample(Image_5_6);
		RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}


	RecognitionNeuronEnsemble.pNeuronArray[3].Add_TrainingExample(Image_6_1);
	RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[3].Set_Dendrite_NeuronInput(0, 0, Image_6_2, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[3].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_6_2" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[3].Add_TrainingExample(Image_6_2);
		RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[3].Set_Dendrite_NeuronInput(0, 0, Image_6_3, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[3].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_6_3" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[3].Add_TrainingExample(Image_6_3);
		RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[3].Set_Dendrite_NeuronInput(0, 0, Image_6_4, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[3].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_6_4" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[3].Add_TrainingExample(Image_6_4);
		RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[3].Set_Dendrite_NeuronInput(0, 0, Image_6_5, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[3].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_6_5" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[3].Add_TrainingExample(Image_6_5);
		RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[3].Set_Dendrite_NeuronInput(0, 0, Image_6_6, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[3].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_6_6" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[3].Add_TrainingExample(Image_6_6);
		RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}



	RecognitionNeuronEnsemble.pNeuronArray[4].Add_TrainingExample(Image_G_1);
	RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[4].Set_Dendrite_NeuronInput(0, 0, Image_G_2, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[4].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_G_2" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[4].Add_TrainingExample(Image_G_2);
		RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[4].Set_Dendrite_NeuronInput(0, 0, Image_G_3, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[4].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_G_3" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[4].Add_TrainingExample(Image_G_3);
		RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[4].Set_Dendrite_NeuronInput(0, 0, Image_G_4, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[4].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_G_4" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[4].Add_TrainingExample(Image_G_4);
		RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[4].Set_Dendrite_NeuronInput(0, 0, Image_G_5, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[4].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_G_5" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[4].Add_TrainingExample(Image_G_5);
		RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[4].Set_Dendrite_NeuronInput(0, 0, Image_G_6, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[4].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_G_6" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[4].Add_TrainingExample(Image_G_6);
		RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}


	RecognitionNeuronEnsemble.pNeuronArray[5].Add_TrainingExample(Image_S_1);
	RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[5].Set_Dendrite_NeuronInput(0, 0, Image_S_2, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[5].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_S_2" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[5].Add_TrainingExample(Image_S_2);
		RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[5].Set_Dendrite_NeuronInput(0, 0, Image_S_3, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[5].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_S_3" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[5].Add_TrainingExample(Image_S_3);
		RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[5].Set_Dendrite_NeuronInput(0, 0, Image_S_4, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[5].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_S_4" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[5].Add_TrainingExample(Image_S_4);
		RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[5].Set_Dendrite_NeuronInput(0, 0, Image_S_5, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[5].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_S_5" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[5].Add_TrainingExample(Image_S_5);
		RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[5].Set_Dendrite_NeuronInput(0, 0, Image_S_6, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[5].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_S_6" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[5].Add_TrainingExample(Image_S_6);
		RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	cout << endl;

	//////////////////////////////

	float maxActivationValue;
	int32_t belongingNeuronID;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_B_1, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_B_2, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_B_3, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_B_4, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_B_5, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_B_6, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl << endl;

	cout << "press enter: ";
	getchar();

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_8_1, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_8_2, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_8_3, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_8_4, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_8_5, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_8_6, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl << endl;

	cout << "press enter: ";
	getchar();

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_5_1, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_5_2, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_5_3, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_5_4, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_5_5, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_5_6, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl << endl;

	cout << "press enter: ";
	getchar();

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_6_1, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_6_2, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_6_3, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_6_4, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_6_5, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_6_6, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl << endl;

	cout << "press enter: ";
	getchar();

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_G_1, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_G_2, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_G_3, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_G_4, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_G_5, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_G_6, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl << endl;

	cout << "press enter: ";
	getchar();

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_S_1, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;


	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_S_2, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;


	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_S_3, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_S_4, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_S_5, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_S_6, 16, 16, 16, 16);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl << endl;

	//////////////////////////////


	getchar();
	return 0;
}
*/

/*
int main(void)
{
	static float Image_B_1[32 * 32];
	static float Image_B_2[32 * 32];

	static float Image_S_1[32 * 32];
	static float Image_S_2[32 * 32];

	uint8_t *pImageData = nullptr;


	pImageData = Read_Bitmap_BGR("Sample_B_1.bmp");
	Get_BinaryImageData_BlueChannel(Image_B_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_2.bmp");
	Get_BinaryImageData_BlueChannel(Image_B_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;


	pImageData = Read_Bitmap_BGR("Sample_S_1.bmp");
	Get_BinaryImageData_BlueChannel(Image_S_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_2.bmp");
	Get_BinaryImageData_BlueChannel(Image_S_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;



	CSimpleNeuron Neuron_B;

	Neuron_B.Init_Dendrite_Arrays(32 * 32 + 8 * 8);
	Neuron_B.Set_DendriticFunction(SectorExaminationDendriticFunction32x32);

	

	Neuron_B.Set_Dendrite_NeuronInput(0, 0, Image_B_1, 32, 32, 32, 32);
	Neuron_B.Execute_DendriticCalculations();

	int32_t counter = 32 * 32;

	for (int32_t iy = 0; iy < 8; iy++)
	{
		for (int32_t ix = 0; ix < 8; ix++)
		{
			if (Neuron_B.pDendrite_DataArray[counter] < 1.0f)
				cout << " ";
			else
				cout << "X";

			counter++;
		}

		cout << endl;
	}

	cout << endl;

	cout << "press enter: ";
	getchar();

	Neuron_B.Set_Dendrite_NeuronInput(0, 0, Image_B_2, 32, 32, 32, 32);
	Neuron_B.Execute_DendriticCalculations();

	counter = 32 * 32;

	for (int32_t iy = 0; iy < 8; iy++)
	{
		for (int32_t ix = 0; ix < 8; ix++)
		{
			if (Neuron_B.pDendrite_DataArray[counter] < 1.0f)
				cout << " ";
			else
				cout << "X";

			counter++;
		}

		cout << endl;
	}

	cout << endl;

	cout << "press enter: ";
	getchar();

	Neuron_B.Set_Dendrite_NeuronInput(0, 0, Image_S_1, 32, 32, 32, 32);
	Neuron_B.Execute_DendriticCalculations();

	counter = 32 * 32;

	for (int32_t iy = 0; iy < 8; iy++)
	{
		for (int32_t ix = 0; ix < 8; ix++)
		{
			if (Neuron_B.pDendrite_DataArray[counter] < 1.0f)
				cout << " ";
			else
				cout << "X";

			counter++;
		}

		cout << endl;
	}

	cout << endl;

	cout << "press enter: ";
	getchar();

	Neuron_B.Set_Dendrite_NeuronInput(0, 0, Image_S_2, 32, 32, 32, 32);
	Neuron_B.Execute_DendriticCalculations();

	counter = 32 * 32;

	for (int32_t iy = 0; iy < 8; iy++)
	{
		for (int32_t ix = 0; ix < 8; ix++)
		{
			if (Neuron_B.pDendrite_DataArray[counter] < 1.0f)
				cout << " ";
			else
				cout << "X";

			counter++;
		}

		cout << endl;
	}

	cout << endl;


	getchar();
	return 0;
}
*/

/*
int main(void)
{
	static float ObjectTestImage1[32 * 32];

	uint8_t *pImageData = nullptr;


	pImageData = Read_Bitmap_BGR("ObjectTestImage1.bmp");
	Get_BinaryImageData_BlueChannel(ObjectTestImage1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;


	// local receptive field values:


	float LRF_CentroidValueArray1[3 * 3] = {1.0f, 0.0f, 1.0f,
	                                        0.0f, 1.0f, 0.0f,
	                                        1.0f, 0.0f, 1.0f};

	float LRF_FactorArray1[3 * 3] = { 1.0f, 1.0f, 1.0f,
									  1.0f, 1.0f, 1.0f,
								      1.0f, 1.0f, 1.0f };

	float LRF_CentroidValueArray2[3 * 3] = { 0.0f, 1.0f, 0.0f,
											 1.0f, 1.0f, 1.0f,
											 0.0f, 1.0f, 0.0f };

	float LRF_FactorArray2[3 * 3] = { 1.0f, 1.0f, 1.0f,
									  1.0f, 1.0f, 1.0f,
								 	  1.0f, 1.0f, 1.0f };
	

	CSimpleNeuron DetectionNeuron1;
	DetectionNeuron1.Init_Dendrite_Arrays(3 * 3);
	DetectionNeuron1.Set_ActivationFunction(SimpleRecognitionOutputFunction);
	DetectionNeuron1.Set_LocalReceptiveFieldSizeInfo(3, 3);
	DetectionNeuron1.Set_Dendrite_Data(LRF_CentroidValueArray1, LRF_FactorArray1);
	
	
	CSimpleNeuron DetectionNeuron2;
	DetectionNeuron2.Init_Dendrite_Arrays(3 * 3);
	DetectionNeuron2.Set_ActivationFunction(SimpleRecognitionOutputFunction);
	DetectionNeuron2.Set_LocalReceptiveFieldSizeInfo(3, 3);
	DetectionNeuron2.Set_Dendrite_Data(LRF_CentroidValueArray2, LRF_FactorArray2);


	int32_t outPatternCount;
	int32_t outPatternPosXArray[2];
	int32_t outPatternPosYArray[2];

	Search_Pattern(&outPatternCount, outPatternPosXArray, outPatternPosYArray, 2, ObjectTestImage1, 32, 32, 1, 1, 1, 31, 1, 31, &DetectionNeuron1, 0.999f);

	cout << outPatternCount << endl;
	cout << outPatternPosXArray[0] << " " << outPatternPosYArray[0] << endl;
	cout << outPatternPosXArray[1] << " " << outPatternPosYArray[1] << endl;

	Search_Pattern(&outPatternCount, outPatternPosXArray, outPatternPosYArray, 2, ObjectTestImage1, 32, 32, 1, 1, 1, 31, 1, 31, &DetectionNeuron2, 0.999f);

	cout << outPatternCount << endl;
	cout << outPatternPosXArray[0] << " " << outPatternPosYArray[0] << endl;
	cout << outPatternPosXArray[1] << " " << outPatternPosYArray[1] << endl;



	getchar();
	return 0;
}
*/

/*
int main(void)
{
	static float ObjectTestImage1[32 * 32];

	uint8_t *pImageData = nullptr;


	pImageData = Read_Bitmap_BGR("ObjectTestImage1.bmp");
	Get_BinaryImageData_BlueChannel(ObjectTestImage1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;


	// local receptive field values:


	float LRF_CentroidValueArray1[3 * 3] = { 1.0f, 0.0f, 1.0f,
		0.0f, 1.0f, 0.0f,
		1.0f, 0.0f, 1.0f };

	float LRF_FactorArray1[3 * 3] = { 1.0f, 1.0f, 1.0f,
		1.0f, 1.0f, 1.0f,
		1.0f, 1.0f, 1.0f };

	float LRF_CentroidValueArray2[3 * 3] = { 0.0f, 1.0f, 0.0f,
		1.0f, 1.0f, 1.0f,
		0.0f, 1.0f, 0.0f };

	float LRF_FactorArray2[3 * 3] = { 1.0f, 1.0f, 1.0f,
		1.0f, 1.0f, 1.0f,
		1.0f, 1.0f, 1.0f };


	CSimpleNeuron DetectionNeuron1;
	DetectionNeuron1.Init_Dendrite_Arrays(3 * 3);
	DetectionNeuron1.Set_ActivationFunction(SimpleRecognitionOutputFunction);
	DetectionNeuron1.Set_LocalReceptiveFieldSizeInfo(3, 3);
	DetectionNeuron1.Set_Dendrite_Data(LRF_CentroidValueArray1, LRF_FactorArray1);


	CSimpleNeuron DetectionNeuron2;
	DetectionNeuron2.Init_Dendrite_Arrays(3 * 3);
	DetectionNeuron2.Set_ActivationFunction(SimpleRecognitionOutputFunction);
	DetectionNeuron2.Set_LocalReceptiveFieldSizeInfo(3, 3);
	DetectionNeuron2.Set_Dendrite_Data(LRF_CentroidValueArray2, LRF_FactorArray2);

	CSimpleNeuron SectorExaminationNeuron;

	// 32*32-Image in 8*8 Sektoren aufteilen (32*32 Input-Dendriten, 8*8 Output-Dendriten):
	SectorExaminationNeuron.Init_Dendrite_Arrays(32 * 32 + 8 * 8);
	SectorExaminationNeuron.Set_OutputDendriteInfo(32 * 32, 8, 8);
	SectorExaminationNeuron.Set_DendriticFunction(SectorExaminationDendriticFunction_32x32Image_8x8Sectors);

	int32_t outPatternCount;
	int32_t outPatternPosXArray[2];
	int32_t outPatternPosYArray[2];

	SectorExaminationNeuron.Set_Dendrite_NeuronInput(0, 0, ObjectTestImage1, 32, 32, 32, 32);
	SectorExaminationNeuron.Execute_DendriticCalculations();

	Search_Pattern(&outPatternCount, outPatternPosXArray, outPatternPosYArray, 2, ObjectTestImage1, 32, 32, 1, 1, 1, 31, 1, 31, &SectorExaminationNeuron, &DetectionNeuron1, 0.999f);

	cout << outPatternCount << endl;
	cout << outPatternPosXArray[0] << " " << outPatternPosYArray[0] << endl;
	cout << outPatternPosXArray[1] << " " << outPatternPosYArray[1] << endl;

	Search_Pattern(&outPatternCount, outPatternPosXArray, outPatternPosYArray, 2, ObjectTestImage1, 32, 32, 1, 1, 1, 31, 1, 31, &SectorExaminationNeuron, &DetectionNeuron2, 0.999f);

	cout << outPatternCount << endl;
	cout << outPatternPosXArray[0] << " " << outPatternPosYArray[0] << endl;
	cout << outPatternPosXArray[1] << " " << outPatternPosYArray[1] << endl;



	getchar();
	return 0;
}
*/

/*
int main(void)
{
	static float Image_B_1[32 * 32];
	static float Image_B_2[32 * 32];
	static float Image_B_3[32 * 32];
	static float Image_B_4[32 * 32];
	static float Image_B_5[32 * 32];
	static float Image_B_6[32 * 32];

	static float Image_8_1[32 * 32];
	static float Image_8_2[32 * 32];
	static float Image_8_3[32 * 32];
	static float Image_8_4[32 * 32];
	static float Image_8_5[32 * 32];
	static float Image_8_6[32 * 32];

	static float Image_5_1[32 * 32];
	static float Image_5_2[32 * 32];
	static float Image_5_3[32 * 32];
	static float Image_5_4[32 * 32];
	static float Image_5_5[32 * 32];
	static float Image_5_6[16 * 16];

	static float Image_6_1[32 * 32];
	static float Image_6_2[32 * 32];
	static float Image_6_3[32 * 32];
	static float Image_6_4[32 * 32];
	static float Image_6_5[32 * 32];
	static float Image_6_6[32 * 32];

	static float Image_G_1[32 * 32];
	static float Image_G_2[32 * 32];
	static float Image_G_3[32 * 32];
	static float Image_G_4[32 * 32];
	static float Image_G_5[32 * 32];
	static float Image_G_6[32 * 32];

	static float Image_S_1[32 * 32];
	static float Image_S_2[32 * 32];
	static float Image_S_3[32 * 32];
	static float Image_S_4[32 * 32];
	static float Image_S_5[32 * 32];
	static float Image_S_6[32 * 32];

	uint8_t *pImageData = nullptr;

	

	pImageData = Read_Bitmap_BGR("Sample_B_1.bmp");
	Get_BinaryImageData_BlueChannel(Image_B_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_2.bmp");
	Get_BinaryImageData_BlueChannel(Image_B_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_3.bmp");
	Get_BinaryImageData_BlueChannel(Image_B_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_4.bmp");
	Get_BinaryImageData_BlueChannel(Image_B_4, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_5.bmp");
	Get_BinaryImageData_BlueChannel(Image_B_5, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_6.bmp");
	Get_BinaryImageData_BlueChannel(Image_B_6, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	///////////////////////////////

	

	pImageData = Read_Bitmap_BGR("Sample_8_1.bmp");
	Get_BinaryImageData_BlueChannel(Image_8_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_2.bmp");
	Get_BinaryImageData_BlueChannel(Image_8_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_3.bmp");
	Get_BinaryImageData_BlueChannel(Image_8_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_4.bmp");
	Get_BinaryImageData_BlueChannel(Image_8_4, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_5.bmp");
	Get_BinaryImageData_BlueChannel(Image_8_5, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_6.bmp");
	Get_BinaryImageData_BlueChannel(Image_8_6, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	//////////////////////////////

	

	pImageData = Read_Bitmap_BGR("Sample_5_1.bmp");
	Get_BinaryImageData_BlueChannel(Image_5_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_2.bmp");
	Get_BinaryImageData_BlueChannel(Image_5_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_3.bmp");
	Get_BinaryImageData_BlueChannel(Image_5_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_4.bmp");
	Get_BinaryImageData_BlueChannel(Image_5_4, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_5.bmp");
	Get_BinaryImageData_BlueChannel(Image_5_5, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_6.bmp");
	Get_BinaryImageData_BlueChannel(Image_5_6, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	//////////////////////////////

	

	pImageData = Read_Bitmap_BGR("Sample_6_1.bmp");
	Get_BinaryImageData_BlueChannel(Image_6_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_2.bmp");
	Get_BinaryImageData_BlueChannel(Image_6_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_3.bmp");
	Get_BinaryImageData_BlueChannel(Image_6_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_4.bmp");
	Get_BinaryImageData_BlueChannel(Image_6_4, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_5.bmp");
	Get_BinaryImageData_BlueChannel(Image_6_5, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_6.bmp");
	Get_BinaryImageData_BlueChannel(Image_6_6, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	//////////////////////////////

	

	pImageData = Read_Bitmap_BGR("Sample_G_1.bmp");
	Get_BinaryImageData_BlueChannel(Image_G_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_2.bmp");
	Get_BinaryImageData_BlueChannel(Image_G_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_3.bmp");
	Get_BinaryImageData_BlueChannel(Image_G_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_4.bmp");
	Get_BinaryImageData_BlueChannel(Image_G_4, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_5.bmp");
	Get_BinaryImageData_BlueChannel(Image_G_5, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_6.bmp");
	Get_BinaryImageData_BlueChannel(Image_G_6, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	//////////////////////////////

	

	pImageData = Read_Bitmap_BGR("Sample_S_1.bmp");
	Get_BinaryImageData_BlueChannel(Image_S_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_2.bmp");
	Get_BinaryImageData_BlueChannel(Image_S_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_3.bmp");
	Get_BinaryImageData_BlueChannel(Image_S_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_4.bmp");
	Get_BinaryImageData_BlueChannel(Image_S_4, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_5.bmp");
	Get_BinaryImageData_BlueChannel(Image_S_5, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_6.bmp");
	Get_BinaryImageData_BlueChannel(Image_S_6, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	//////////////////////////////


	CSingleRecognitionNeuronEnsemble RecognitionNeuronEnsemble;

	char RecognizedSymbolArray[7] = { 'B', '8', '5', '6', 'G', 'S', '\0' };

	// 6 Symbols (B, 8, 5, 6, G, S) => 6 Neurons
	RecognitionNeuronEnsemble.Init_NeuronArray(6, 32 * 32, SimpleRecognitionOutputFunction32x32);
	RecognitionNeuronEnsemble.Reset_NumOfTrainingExamples();

	float fallback_RBF_Factor = 0.5f;
	float centroidWeightFactor = 0.025f;
	int32_t centroidExponent = 4;

	//float fallback_RBF_Factor = 10.0f;
	//float centroidWeightFactor = 0.025f;
	//int32_t centroidExponent = 2;

	
	RecognitionNeuronEnsemble.pNeuronArray[0].Add_TrainingExample(Image_B_1);
	RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[0].Add_TrainingExample(Image_B_2);
	RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[0].Add_TrainingExample(Image_B_3);
	RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[0].Add_TrainingExample(Image_B_4);
	RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[0].Add_TrainingExample(Image_B_5);
	RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[0].Add_TrainingExample(Image_B_6);
	RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	


	
	RecognitionNeuronEnsemble.pNeuronArray[1].Add_TrainingExample(Image_8_1);
	RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[1].Add_TrainingExample(Image_8_2);
	RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[1].Add_TrainingExample(Image_8_3);
	RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[1].Add_TrainingExample(Image_8_4);
	RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[1].Add_TrainingExample(Image_8_5);
	RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[1].Add_TrainingExample(Image_8_6);
	RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	
	


	
	RecognitionNeuronEnsemble.pNeuronArray[2].Add_TrainingExample(Image_5_1);
	RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[2].Add_TrainingExample(Image_5_2);
	RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[2].Add_TrainingExample(Image_5_3);
	RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[2].Add_TrainingExample(Image_5_4);
	RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[2].Add_TrainingExample(Image_5_5);
	RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[2].Add_TrainingExample(Image_5_6);
	RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	

	

	RecognitionNeuronEnsemble.pNeuronArray[3].Add_TrainingExample(Image_6_1);
	RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[3].Add_TrainingExample(Image_6_2);
	RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[3].Add_TrainingExample(Image_6_3);
	RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[3].Add_TrainingExample(Image_6_4);
	RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[3].Add_TrainingExample(Image_6_5);
	RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[3].Add_TrainingExample(Image_6_6);
	RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	
	

	
	RecognitionNeuronEnsemble.pNeuronArray[4].Add_TrainingExample(Image_G_1);
	RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[4].Add_TrainingExample(Image_G_2);
	RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[4].Add_TrainingExample(Image_G_3);
	RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[4].Add_TrainingExample(Image_G_4);
	RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[4].Add_TrainingExample(Image_G_5);
	RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[4].Add_TrainingExample(Image_G_6);
	RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	
	
	
	RecognitionNeuronEnsemble.pNeuronArray[5].Add_TrainingExample(Image_S_1);
	RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[5].Add_TrainingExample(Image_S_2);
	RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[5].Add_TrainingExample(Image_S_3);
	RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[5].Add_TrainingExample(Image_S_4);
	RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[5].Add_TrainingExample(Image_S_5);
	RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[5].Add_TrainingExample(Image_S_6);
	RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	
	


	//////////////////////////////

	float maxActivationValue;
	int32_t belongingNeuronID;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_B_1, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_B_2, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_B_3, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_B_4, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_B_5, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_B_6, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl << endl;

	cout << "press enter: ";
	getchar();

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_8_1, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_8_2, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_8_3, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_8_4, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_8_5, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_8_6, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl << endl;

	cout << "press enter: ";
	getchar();

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_5_1, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_5_2, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_5_3, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_5_4, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_5_5, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_5_6, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl << endl;

	cout << "press enter: ";
	getchar();

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_6_1, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_6_2, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_6_3, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_6_4, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_6_5, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_6_6, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl << endl;

	cout << "press enter: ";
	getchar();

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_G_1, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_G_2, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_G_3, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_G_4, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_G_5, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_G_6, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl << endl;

	cout << "press enter: ";
	getchar();

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_S_1, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;


	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_S_2, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;


	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_S_3, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_S_4, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_S_5, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_S_6, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl << endl;

	//////////////////////////////


	getchar();
	return 0;
}
*/

/*
int main(void)
{
	static float Image_B_1[32 * 32];
	static float Image_B_2[32 * 32];
	static float Image_B_3[32 * 32];
	static float Image_B_4[32 * 32];
	static float Image_B_5[32 * 32];
	static float Image_B_6[32 * 32];

	static float Image_8_1[32 * 32];
	static float Image_8_2[32 * 32];
	static float Image_8_3[32 * 32];
	static float Image_8_4[32 * 32];
	static float Image_8_5[32 * 32];
	static float Image_8_6[32 * 32];

	static float Image_5_1[32 * 32];
	static float Image_5_2[32 * 32];
	static float Image_5_3[32 * 32];
	static float Image_5_4[32 * 32];
	static float Image_5_5[32 * 32];
	static float Image_5_6[16 * 16];

	static float Image_6_1[32 * 32];
	static float Image_6_2[32 * 32];
	static float Image_6_3[32 * 32];
	static float Image_6_4[32 * 32];
	static float Image_6_5[32 * 32];
	static float Image_6_6[32 * 32];

	static float Image_G_1[32 * 32];
	static float Image_G_2[32 * 32];
	static float Image_G_3[32 * 32];
	static float Image_G_4[32 * 32];
	static float Image_G_5[32 * 32];
	static float Image_G_6[32 * 32];

	static float Image_S_1[32 * 32];
	static float Image_S_2[32 * 32];
	static float Image_S_3[32 * 32];
	static float Image_S_4[32 * 32];
	static float Image_S_5[32 * 32];
	static float Image_S_6[32 * 32];

	uint8_t *pImageData = nullptr;



	pImageData = Read_Bitmap_BGR("Sample_B_1.bmp");
	Get_BinaryImageData_BlueChannel(Image_B_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_2.bmp");
	Get_BinaryImageData_BlueChannel(Image_B_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_3.bmp");
	Get_BinaryImageData_BlueChannel(Image_B_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_4.bmp");
	Get_BinaryImageData_BlueChannel(Image_B_4, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_5.bmp");
	Get_BinaryImageData_BlueChannel(Image_B_5, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_6.bmp");
	Get_BinaryImageData_BlueChannel(Image_B_6, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	///////////////////////////////



	pImageData = Read_Bitmap_BGR("Sample_8_1.bmp");
	Get_BinaryImageData_BlueChannel(Image_8_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_2.bmp");
	Get_BinaryImageData_BlueChannel(Image_8_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_3.bmp");
	Get_BinaryImageData_BlueChannel(Image_8_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_4.bmp");
	Get_BinaryImageData_BlueChannel(Image_8_4, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_5.bmp");
	Get_BinaryImageData_BlueChannel(Image_8_5, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_6.bmp");
	Get_BinaryImageData_BlueChannel(Image_8_6, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	//////////////////////////////



	pImageData = Read_Bitmap_BGR("Sample_5_1.bmp");
	Get_BinaryImageData_BlueChannel(Image_5_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_2.bmp");
	Get_BinaryImageData_BlueChannel(Image_5_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_3.bmp");
	Get_BinaryImageData_BlueChannel(Image_5_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_4.bmp");
	Get_BinaryImageData_BlueChannel(Image_5_4, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_5.bmp");
	Get_BinaryImageData_BlueChannel(Image_5_5, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_6.bmp");
	Get_BinaryImageData_BlueChannel(Image_5_6, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	//////////////////////////////



	pImageData = Read_Bitmap_BGR("Sample_6_1.bmp");
	Get_BinaryImageData_BlueChannel(Image_6_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_2.bmp");
	Get_BinaryImageData_BlueChannel(Image_6_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_3.bmp");
	Get_BinaryImageData_BlueChannel(Image_6_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_4.bmp");
	Get_BinaryImageData_BlueChannel(Image_6_4, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_5.bmp");
	Get_BinaryImageData_BlueChannel(Image_6_5, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_6.bmp");
	Get_BinaryImageData_BlueChannel(Image_6_6, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	//////////////////////////////



	pImageData = Read_Bitmap_BGR("Sample_G_1.bmp");
	Get_BinaryImageData_BlueChannel(Image_G_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_2.bmp");
	Get_BinaryImageData_BlueChannel(Image_G_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_3.bmp");
	Get_BinaryImageData_BlueChannel(Image_G_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_4.bmp");
	Get_BinaryImageData_BlueChannel(Image_G_4, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_5.bmp");
	Get_BinaryImageData_BlueChannel(Image_G_5, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_6.bmp");
	Get_BinaryImageData_BlueChannel(Image_G_6, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	//////////////////////////////



	pImageData = Read_Bitmap_BGR("Sample_S_1.bmp");
	Get_BinaryImageData_BlueChannel(Image_S_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_2.bmp");
	Get_BinaryImageData_BlueChannel(Image_S_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_3.bmp");
	Get_BinaryImageData_BlueChannel(Image_S_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_4.bmp");
	Get_BinaryImageData_BlueChannel(Image_S_4, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_5.bmp");
	Get_BinaryImageData_BlueChannel(Image_S_5, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_6.bmp");
	Get_BinaryImageData_BlueChannel(Image_S_6, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	//////////////////////////////


	CSingleRecognitionNeuronEnsemble RecognitionNeuronEnsemble;

	char RecognizedSymbolArray[7] = { 'B', '8', '5', '6', 'G', 'S', '\0' };

	// 6 Symbols (B, 8, 5, 6, G, S) => 6 Neurons
	RecognitionNeuronEnsemble.Init_NeuronArray(6, 32 * 32, SimpleRecognitionOutputFunction32x32);
	RecognitionNeuronEnsemble.Reset_NumOfTrainingExamples();

	float fallback_RBF_Factor = 0.5f;
	float centroidWeightFactor = 0.025f;
	int32_t centroidExponent = 4;

	//float fallback_RBF_Factor = 10.0f;
	//float centroidWeightFactor = 0.025f;
	//int32_t centroidExponent = 2;


	float recognitionThreshold = 0.98f;

	RecognitionNeuronEnsemble.pNeuronArray[0].Add_TrainingExample(Image_B_1);
	RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[0].Set_Dendrite_NeuronInput(0, 0, Image_B_2, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[0].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_B_2" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[0].Add_TrainingExample(Image_B_2);
		RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[0].Set_Dendrite_NeuronInput(0, 0, Image_B_3, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[0].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_B_3" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[0].Add_TrainingExample(Image_B_3);
		RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[0].Set_Dendrite_NeuronInput(0, 0, Image_B_4, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[0].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_B_4" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[0].Add_TrainingExample(Image_B_4);
		RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[0].Set_Dendrite_NeuronInput(0, 0, Image_B_5, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[0].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_B_5" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[0].Add_TrainingExample(Image_B_5);
		RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[0].Set_Dendrite_NeuronInput(0, 0, Image_B_6, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[0].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_B_6" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[0].Add_TrainingExample(Image_B_6);
		RecognitionNeuronEnsemble.pNeuronArray[0].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}



	RecognitionNeuronEnsemble.pNeuronArray[1].Add_TrainingExample(Image_8_1);
	RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[1].Set_Dendrite_NeuronInput(0, 0, Image_8_2, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[1].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_8_2" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[1].Add_TrainingExample(Image_8_2);
		RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[1].Set_Dendrite_NeuronInput(0, 0, Image_8_3, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[1].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_8_3" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[1].Add_TrainingExample(Image_8_3);
		RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[1].Set_Dendrite_NeuronInput(0, 0, Image_8_4, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[1].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_8_4" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[1].Add_TrainingExample(Image_8_4);
		RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}


	RecognitionNeuronEnsemble.pNeuronArray[1].Set_Dendrite_NeuronInput(0, 0, Image_8_5, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[1].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_8_5" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[1].Add_TrainingExample(Image_8_5);
		RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[1].Set_Dendrite_NeuronInput(0, 0, Image_8_6, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[1].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_8_6" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[1].Add_TrainingExample(Image_8_6);
		RecognitionNeuronEnsemble.pNeuronArray[1].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}


	RecognitionNeuronEnsemble.pNeuronArray[2].Add_TrainingExample(Image_5_1);
	RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[2].Set_Dendrite_NeuronInput(0, 0, Image_5_2, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[2].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_5_2" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[2].Add_TrainingExample(Image_5_2);
		RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[2].Set_Dendrite_NeuronInput(0, 0, Image_5_3, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[2].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_5_3" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[2].Add_TrainingExample(Image_5_3);
		RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[2].Set_Dendrite_NeuronInput(0, 0, Image_5_4, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[2].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_5_4" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[2].Add_TrainingExample(Image_5_4);
		RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[2].Set_Dendrite_NeuronInput(0, 0, Image_5_5, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[2].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_5_5" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[2].Add_TrainingExample(Image_5_5);
		RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[2].Set_Dendrite_NeuronInput(0, 0, Image_5_6, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[2].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_5_6" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[2].Add_TrainingExample(Image_5_6);
		RecognitionNeuronEnsemble.pNeuronArray[2].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}


	RecognitionNeuronEnsemble.pNeuronArray[3].Add_TrainingExample(Image_6_1);
	RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[3].Set_Dendrite_NeuronInput(0, 0, Image_6_2, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[3].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_6_2" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[3].Add_TrainingExample(Image_6_2);
		RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[3].Set_Dendrite_NeuronInput(0, 0, Image_6_3, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[3].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_6_3" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[3].Add_TrainingExample(Image_6_3);
		RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[3].Set_Dendrite_NeuronInput(0, 0, Image_6_4, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[3].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_6_4" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[3].Add_TrainingExample(Image_6_4);
		RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[3].Set_Dendrite_NeuronInput(0, 0, Image_6_5, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[3].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_6_5" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[3].Add_TrainingExample(Image_6_5);
		RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[3].Set_Dendrite_NeuronInput(0, 0, Image_6_6, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[3].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_6_6" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[3].Add_TrainingExample(Image_6_6);
		RecognitionNeuronEnsemble.pNeuronArray[3].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}



	RecognitionNeuronEnsemble.pNeuronArray[4].Add_TrainingExample(Image_G_1);
	RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[4].Set_Dendrite_NeuronInput(0, 0, Image_G_2, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[4].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_G_2" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[4].Add_TrainingExample(Image_G_2);
		RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[4].Set_Dendrite_NeuronInput(0, 0, Image_G_3, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[4].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_G_3" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[4].Add_TrainingExample(Image_G_3);
		RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[4].Set_Dendrite_NeuronInput(0, 0, Image_G_4, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[4].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_G_4" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[4].Add_TrainingExample(Image_G_4);
		RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[4].Set_Dendrite_NeuronInput(0, 0, Image_G_5, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[4].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_G_5" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[4].Add_TrainingExample(Image_G_5);
		RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[4].Set_Dendrite_NeuronInput(0, 0, Image_G_6, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[4].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_G_6" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[4].Add_TrainingExample(Image_G_6);
		RecognitionNeuronEnsemble.pNeuronArray[4].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}


	RecognitionNeuronEnsemble.pNeuronArray[5].Add_TrainingExample(Image_S_1);
	RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

	RecognitionNeuronEnsemble.pNeuronArray[5].Set_Dendrite_NeuronInput(0, 0, Image_S_2, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[5].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_S_2" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[5].Add_TrainingExample(Image_S_2);
		RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[5].Set_Dendrite_NeuronInput(0, 0, Image_S_3, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[5].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_S_3" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[5].Add_TrainingExample(Image_S_3);
		RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[5].Set_Dendrite_NeuronInput(0, 0, Image_S_4, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[5].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_S_4" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[5].Add_TrainingExample(Image_S_4);
		RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[5].Set_Dendrite_NeuronInput(0, 0, Image_S_5, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[5].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_S_5" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[5].Add_TrainingExample(Image_S_5);
		RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	RecognitionNeuronEnsemble.pNeuronArray[5].Set_Dendrite_NeuronInput(0, 0, Image_S_6, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_NeuronOutput();

	if (RecognitionNeuronEnsemble.pNeuronArray[5].ActivationValue < recognitionThreshold)
	{
		cout << "new pattern: Image_S_6" << endl;
		RecognitionNeuronEnsemble.pNeuronArray[5].Add_TrainingExample(Image_S_6);
		RecognitionNeuronEnsemble.pNeuronArray[5].Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	cout << endl;



	//////////////////////////////

	float maxActivationValue;
	int32_t belongingNeuronID;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_B_1, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_B_2, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_B_3, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_B_4, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_B_5, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_B_6, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl << endl;

	cout << "press enter: ";
	getchar();

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_8_1, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_8_2, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_8_3, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_8_4, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_8_5, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_8_6, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl << endl;

	cout << "press enter: ";
	getchar();

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_5_1, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_5_2, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_5_3, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_5_4, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_5_5, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_5_6, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl << endl;

	cout << "press enter: ";
	getchar();

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_6_1, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_6_2, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_6_3, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_6_4, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_6_5, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_6_6, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl << endl;

	cout << "press enter: ";
	getchar();

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_G_1, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_G_2, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_G_3, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_G_4, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_G_5, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_G_6, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl << endl;

	cout << "press enter: ";
	getchar();

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_S_1, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;


	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_S_2, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;


	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_S_3, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_S_4, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_S_5, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl;

	RecognitionNeuronEnsemble.Set_Dendrite_NeuronInput(0, 0, Image_S_6, 32, 32, 32, 32);
	RecognitionNeuronEnsemble.Calculate_NeuronOutputs();
	RecognitionNeuronEnsemble.Get_MaxActivationValue(&maxActivationValue, &belongingNeuronID);

	cout << "symbol: " << RecognizedSymbolArray[belongingNeuronID] << " maxActivationValue: " << maxActivationValue << endl << endl;

	//////////////////////////////


	getchar();
	return 0;
}
*/


/*
int main(void)
{
	static constexpr int32_t NeuralNet_NumOfHiddenDendrites = 96;//48;
	static constexpr int32_t NeuralNet_NumOfInputValues = 32 * 32 + 1; // 1: bias
	static constexpr int32_t NeuralNet_NumOfOutputValues = 6;

	static constexpr int32_t NeuralNet_NumOfAdditionalMemoryValues = NeuralNet_NumOfInputValues * NeuralNet_NumOfHiddenDendrites;

	static float Image_B_1[32 * 32];
	static float Image_B_2[32 * 32];
	static float Image_B_3[32 * 32];
	static float Image_B_4[32 * 32];
	static float Image_B_5[32 * 32];
	static float Image_B_6[32 * 32];

	static float Image_8_1[32 * 32];
	static float Image_8_2[32 * 32];
	static float Image_8_3[32 * 32];
	static float Image_8_4[32 * 32];
	static float Image_8_5[32 * 32];
	static float Image_8_6[32 * 32];

	static float Image_5_1[32 * 32];
	static float Image_5_2[32 * 32];
	static float Image_5_3[32 * 32];
	static float Image_5_4[32 * 32];
	static float Image_5_5[32 * 32];
	static float Image_5_6[16 * 16];

	static float Image_6_1[32 * 32];
	static float Image_6_2[32 * 32];
	static float Image_6_3[32 * 32];
	static float Image_6_4[32 * 32];
	static float Image_6_5[32 * 32];
	static float Image_6_6[32 * 32];

	static float Image_G_1[32 * 32];
	static float Image_G_2[32 * 32];
	static float Image_G_3[32 * 32];
	static float Image_G_4[32 * 32];
	static float Image_G_5[32 * 32];
	static float Image_G_6[32 * 32];

	static float Image_S_1[32 * 32];
	static float Image_S_2[32 * 32];
	static float Image_S_3[32 * 32];
	static float Image_S_4[32 * 32];
	static float Image_S_5[32 * 32];
	static float Image_S_6[32 * 32];

	uint8_t *pImageData = nullptr;

	static float DesiredOutputArray_Image_B[6] = { 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f };
	static float DesiredOutputArray_Image_8[6] = { 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f };
	static float DesiredOutputArray_Image_5[6] = { 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f };
	static float DesiredOutputArray_Image_6[6] = { 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f };
	static float DesiredOutputArray_Image_G[6] = { 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f };
	static float DesiredOutputArray_Image_S[6] = { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f };

	

	pImageData = Read_Bitmap_BGR("Sample_B_1.bmp");
	Get_BinaryImageData_BlueChannel(Image_B_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_2.bmp");
	Get_BinaryImageData_BlueChannel(Image_B_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_3.bmp");
	Get_BinaryImageData_BlueChannel(Image_B_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_4.bmp");
	Get_BinaryImageData_BlueChannel(Image_B_4, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_5.bmp");
	Get_BinaryImageData_BlueChannel(Image_B_5, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_6.bmp");
	Get_BinaryImageData_BlueChannel(Image_B_6, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	///////////////////////////////



	pImageData = Read_Bitmap_BGR("Sample_8_1.bmp");
	Get_BinaryImageData_BlueChannel(Image_8_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_2.bmp");
	Get_BinaryImageData_BlueChannel(Image_8_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_3.bmp");
	Get_BinaryImageData_BlueChannel(Image_8_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_4.bmp");
	Get_BinaryImageData_BlueChannel(Image_8_4, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_5.bmp");
	Get_BinaryImageData_BlueChannel(Image_8_5, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_6.bmp");
	Get_BinaryImageData_BlueChannel(Image_8_6, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	//////////////////////////////



	pImageData = Read_Bitmap_BGR("Sample_5_1.bmp");
	Get_BinaryImageData_BlueChannel(Image_5_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_2.bmp");
	Get_BinaryImageData_BlueChannel(Image_5_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_3.bmp");
	Get_BinaryImageData_BlueChannel(Image_5_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_4.bmp");
	Get_BinaryImageData_BlueChannel(Image_5_4, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_5.bmp");
	Get_BinaryImageData_BlueChannel(Image_5_5, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_6.bmp");
	Get_BinaryImageData_BlueChannel(Image_5_6, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	//////////////////////////////



	pImageData = Read_Bitmap_BGR("Sample_6_1.bmp");
	Get_BinaryImageData_BlueChannel(Image_6_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_2.bmp");
	Get_BinaryImageData_BlueChannel(Image_6_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_3.bmp");
	Get_BinaryImageData_BlueChannel(Image_6_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_4.bmp");
	Get_BinaryImageData_BlueChannel(Image_6_4, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_5.bmp");
	Get_BinaryImageData_BlueChannel(Image_6_5, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_6.bmp");
	Get_BinaryImageData_BlueChannel(Image_6_6, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	//////////////////////////////



	pImageData = Read_Bitmap_BGR("Sample_G_1.bmp");
	Get_BinaryImageData_BlueChannel(Image_G_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_2.bmp");
	Get_BinaryImageData_BlueChannel(Image_G_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_3.bmp");
	Get_BinaryImageData_BlueChannel(Image_G_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_4.bmp");
	Get_BinaryImageData_BlueChannel(Image_G_4, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_5.bmp");
	Get_BinaryImageData_BlueChannel(Image_G_5, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_6.bmp");
	Get_BinaryImageData_BlueChannel(Image_G_6, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	//////////////////////////////



	pImageData = Read_Bitmap_BGR("Sample_S_1.bmp");
	Get_BinaryImageData_BlueChannel(Image_S_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_2.bmp");
	Get_BinaryImageData_BlueChannel(Image_S_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_3.bmp");
	Get_BinaryImageData_BlueChannel(Image_S_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_4.bmp");
	Get_BinaryImageData_BlueChannel(Image_S_4, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_5.bmp");
	Get_BinaryImageData_BlueChannel(Image_S_5, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_6.bmp");
	Get_BinaryImageData_BlueChannel(Image_S_6, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	//////////////////////////////

	static constexpr int32_t ConstNumOfInputArrays = 36;

	float *pInputArrayPointer[ConstNumOfInputArrays];

	pInputArrayPointer[0] = Image_B_1;
	pInputArrayPointer[1] = Image_B_2;
	pInputArrayPointer[2] = Image_B_3;
	pInputArrayPointer[3] = Image_B_4;
	pInputArrayPointer[4] = Image_B_5;
	pInputArrayPointer[5] = Image_B_6;

	pInputArrayPointer[6] = Image_8_1;
	pInputArrayPointer[7] = Image_8_2;
	pInputArrayPointer[8] = Image_8_3;
	pInputArrayPointer[9] = Image_8_4;
	pInputArrayPointer[10] = Image_8_5;
	pInputArrayPointer[11] = Image_8_6;

	pInputArrayPointer[12] = Image_5_1;
	pInputArrayPointer[13] = Image_5_2;
	pInputArrayPointer[14] = Image_5_3;
	pInputArrayPointer[15] = Image_5_4;
	pInputArrayPointer[16] = Image_5_5;
	pInputArrayPointer[17] = Image_5_6;

	pInputArrayPointer[18] = Image_6_1;
	pInputArrayPointer[19] = Image_6_2;
	pInputArrayPointer[20] = Image_6_3;
	pInputArrayPointer[21] = Image_6_4;
	pInputArrayPointer[22] = Image_6_5;
	pInputArrayPointer[23] = Image_6_6;

	pInputArrayPointer[24] = Image_G_1;
	pInputArrayPointer[25] = Image_G_2;
	pInputArrayPointer[26] = Image_G_3;
	pInputArrayPointer[27] = Image_G_4;
	pInputArrayPointer[28] = Image_G_5;
	pInputArrayPointer[29] = Image_G_6;

	pInputArrayPointer[30] = Image_S_1;
	pInputArrayPointer[31] = Image_S_2;
	pInputArrayPointer[32] = Image_S_3;
	pInputArrayPointer[33] = Image_S_4;
	pInputArrayPointer[34] = Image_S_5;
	pInputArrayPointer[35] = Image_S_6;



	

	char RecognizedSymbolArray[NeuralNet_NumOfOutputValues + 1] = { 'B', '8', '5', '6', 'G', 'S', '\0' };


	CSimpleNeuron RecognitionNeuron_B;
	RecognitionNeuron_B.Init_Dendrite_Arrays(32 * 32);

	static float Image_B_Mean[32 * 32];
	

	CSimpleNeuron RecognitionNeuron_8;
	RecognitionNeuron_8.Init_Dendrite_Arrays(32 * 32);

	static float Image_8_Mean[32 * 32];
	

	CSimpleNeuron RecognitionNeuron_5;
	RecognitionNeuron_5.Init_Dendrite_Arrays(32 * 32);

	static float Image_5_Mean[32 * 32];
	

	CSimpleNeuron RecognitionNeuron_6;
	RecognitionNeuron_6.Init_Dendrite_Arrays(32 * 32);

	static float Image_6_Mean[32 * 32];
	

	CSimpleNeuron RecognitionNeuron_G;
	RecognitionNeuron_G.Init_Dendrite_Arrays(32 * 32);

	static float Image_G_Mean[32 * 32];
	

	CSimpleNeuron RecognitionNeuron_S;
	RecognitionNeuron_S.Init_Dendrite_Arrays(32 * 32);

	static float Image_S_Mean[32 * 32];
	

	float fallback_RBF_Factor = 0.5f;
	float centroidWeightFactor = 0.025f;
	int32_t centroidExponent = 4;

	//float fallback_RBF_Factor = 10.0f;
	//float centroidWeightFactor = 0.025f;
	//int32_t centroidExponent = 2;

	for (int32_t i = 0; i < 6; i++)
	{
		RecognitionNeuron_B.Add_TrainingExample(pInputArrayPointer[i]);
		RecognitionNeuron_B.Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

		RecognitionNeuron_8.Add_TrainingExample(pInputArrayPointer[i + 6]);
		RecognitionNeuron_8.Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

		RecognitionNeuron_5.Add_TrainingExample(pInputArrayPointer[i + 12]);
		RecognitionNeuron_5.Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

		RecognitionNeuron_6.Add_TrainingExample(pInputArrayPointer[i + 18]);
		RecognitionNeuron_6.Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

		RecognitionNeuron_G.Add_TrainingExample(pInputArrayPointer[i + 24]);
		RecognitionNeuron_G.Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

		RecognitionNeuron_S.Add_TrainingExample(pInputArrayPointer[i + 30]);
		RecognitionNeuron_S.Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}

	for (int32_t i = 0; i < 1024; i++)
	{
		Image_B_Mean[i] = RecognitionNeuron_B.pDendrite_CentroidValueArray[i];
		Image_B_Mean[i] *= Image_B_Mean[i];
		//Image_B_Mean[i] = sqrt(Image_B_Mean[i]);
		
	
		Image_8_Mean[i] = RecognitionNeuron_8.pDendrite_CentroidValueArray[i];
		Image_8_Mean[i] *= Image_8_Mean[i];
		//Image_8_Mean[i] = sqrt(Image_8_Mean[i]);
		

		Image_5_Mean[i] = RecognitionNeuron_5.pDendrite_CentroidValueArray[i];
		Image_5_Mean[i] *= Image_5_Mean[i];
		//Image_5_Mean[i] = sqrt(Image_5_Mean[i]);
		

		Image_6_Mean[i] = RecognitionNeuron_6.pDendrite_CentroidValueArray[i];
		Image_6_Mean[i] *= Image_6_Mean[i];
		//Image_6_Mean[i] = sqrt(Image_6_Mean[i]);
		

		Image_G_Mean[i] = RecognitionNeuron_G.pDendrite_CentroidValueArray[i];
		Image_G_Mean[i] *= Image_G_Mean[i];
		//Image_G_Mean[i] = sqrt(Image_G_Mean[i]);
		

		Image_S_Mean[i] = RecognitionNeuron_S.pDendrite_CentroidValueArray[i];
		Image_S_Mean[i] *= Image_S_Mean[i];
		//Image_S_Mean[i] = sqrt(Image_S_Mean[i]);
		
	}

	static constexpr int32_t ConstNumOfRandomTestImages = 20;
	
	static float RandomTestImage_B_Array[ConstNumOfRandomTestImages][32 * 32];
	static float RandomTestImage_8_Array[ConstNumOfRandomTestImages][32 * 32];
	static float RandomTestImage_5_Array[ConstNumOfRandomTestImages][32 * 32];
	static float RandomTestImage_6_Array[ConstNumOfRandomTestImages][32 * 32];
	static float RandomTestImage_G_Array[ConstNumOfRandomTestImages][32 * 32];
	static float RandomTestImage_S_Array[ConstNumOfRandomTestImages][32 * 32];

	CRandomNumbersNN RandomNumbers;

	
	static float RandomPlasticityArray[NeuralNet_NumOfAdditionalMemoryValues];

	Init_RandomNumbersTableExt2(RandomPlasticityArray, NeuralNet_NumOfAdditionalMemoryValues, &RandomNumbers, -1.0f, 1.0f, 0.5f);

	CSimpleNeuralNet_1HiddenLayer NeuralNet;

	NeuralNet.Init_PrecedingNeuron(NeuralNet_NumOfInputValues, NeuralNet_NumOfHiddenDendrites, SimpleRecognitionNetNeuralNet_DendriticFunction, RandomPlasticityArray, NeuralNet_NumOfAdditionalMemoryValues);

	NeuralNet.Init_OutputNeuronArray(NeuralNet_NumOfOutputValues, NeuralNet_NumOfHiddenDendrites, SimpleRecognitionNetNeuralNet_ActivationFunction, &RandomNumbers, -0.2f, 0.2f);

	
	float output;
	float desiredOutput;
	float errorSum;


	int32_t maxCount = 100;
	//int32_t maxCount = 400;
	//int32_t maxCount = 4000;
	int32_t epoch = 0;


	for (int32_t jj = 0; jj < maxCount; jj++)
	{
		////////////////////////

		for (int32_t j = 0; j < ConstNumOfRandomTestImages; j++)
		{
			float *pImageValue = &RandomTestImage_B_Array[j][0];

			for (int32_t i = 0; i < 1024; i++)
			{
				if (Image_B_Mean[i] == 0.0f)
				{
					pImageValue[i] = 0.0f;
				}
				else if (Image_B_Mean[i] == 1.0f)
				{
					pImageValue[i] = 1.0f;
				}
				else
				{
					if (RandomNumbers.Get_FloatNumber_IncludingZero(0.0f, 1.0f) > Image_B_Mean[i])
					{
						pImageValue[i] = 0.0f;
					}
					else
					{
						pImageValue[i] = 1.0f;
					}
				}
			}

			////////////////////////

			pImageValue = &RandomTestImage_8_Array[j][0];

			for (int32_t i = 0; i < 1024; i++)
			{
				if (Image_8_Mean[i] == 0.0f)
				{
					pImageValue[i] = 0.0f;
				}
				else if (Image_8_Mean[i] == 1.0f)
				{
					pImageValue[i] = 1.0f;
				}
				else
				{
					if (RandomNumbers.Get_FloatNumber_IncludingZero(0.0f, 1.0f) > Image_8_Mean[i])
					{
						pImageValue[i] = 0.0f;
					}
					else
					{
						pImageValue[i] = 1.0f;
					}
				}
			}

			////////////////////////

			pImageValue = &RandomTestImage_5_Array[j][0];

			for (int32_t i = 0; i < 1024; i++)
			{
				if (Image_5_Mean[i] == 0.0f)
				{
					pImageValue[i] = 0.0f;
				}
				else if (Image_5_Mean[i] == 1.0f)
				{
					pImageValue[i] = 1.0f;
				}
				else
				{
					if (RandomNumbers.Get_FloatNumber_IncludingZero(0.0f, 1.0f) > Image_5_Mean[i])
					{
						pImageValue[i] = 0.0f;
					}
					else
					{
						pImageValue[i] = 1.0f;
					}
				}
			}

			////////////////////////

			pImageValue = &RandomTestImage_6_Array[j][0];

			for (int32_t i = 0; i < 1024; i++)
			{
				if (Image_6_Mean[i] == 0.0f)
				{
					pImageValue[i] = 0.0f;
				}
				else if (Image_6_Mean[i] == 1.0f)
				{
					pImageValue[i] = 1.0f;
				}
				else
				{
					if (RandomNumbers.Get_FloatNumber_IncludingZero(0.0f, 1.0f) > Image_6_Mean[i])
					{
						pImageValue[i] = 0.0f;
					}
					else
					{
						pImageValue[i] = 1.0f;
					}
				}
			}

			////////////////////////

			pImageValue = &RandomTestImage_G_Array[j][0];

			for (int32_t i = 0; i < 1024; i++)
			{
				if (Image_G_Mean[i] == 0.0f)
				{
					pImageValue[i] = 0.0f;
				}
				else if (Image_G_Mean[i] == 1.0f)
				{
					pImageValue[i] = 1.0f;
				}
				else
				{
					if (RandomNumbers.Get_FloatNumber_IncludingZero(0.0f, 1.0f) > Image_G_Mean[i])
					{
						pImageValue[i] = 0.0f;
					}
					else
					{
						pImageValue[i] = 1.0f;
					}
				}
			}

			////////////////////////

			pImageValue = &RandomTestImage_S_Array[j][0];

			for (int32_t i = 0; i < 1024; i++)
			{
				if (Image_S_Mean[i] == 0.0f)
				{
					pImageValue[i] = 0.0f;
				}
				else if (Image_S_Mean[i] == 1.0f)
				{
					pImageValue[i] = 1.0f;
				}
				else
				{
					if (RandomNumbers.Get_FloatNumber_IncludingZero(0.0f, 1.0f) > Image_S_Mean[i])
					{
						pImageValue[i] = 0.0f;
					}
					else
					{
						pImageValue[i] = 1.0f;
					}
				}
			}
		}

		////////////////////////

		epoch++;
		errorSum = 0.0f;

		for (int32_t ii = 0; ii < ConstNumOfRandomTestImages; ii++)
		{
			NeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(&RandomTestImage_B_Array[ii][0]);
			NeuralNet.Calculate_Output();

			errorSum += NeuralNet.OutputNeurons_ErrorCalculations(DesiredOutputArray_Image_B, 1.0f, 0.005f);			
			PrecedingNeuronErrorCalculations(&NeuralNet.PrecedingNeuron, &NeuralNet.pOutputNeuronArray[0], NeuralNet_NumOfOutputValues, 1.0f, 0.005f);
			PrecedingNeuronLearning(&NeuralNet.PrecedingNeuron, 0.01f);
			NeuralNet.OutputNeurons_Adjust_Dendrite_Factors_AfterErrorCalculations(0.01f);
			
		}
		for (int32_t ii = 0; ii < ConstNumOfRandomTestImages; ii++)
		{
			NeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(&RandomTestImage_8_Array[ii][0]);
			NeuralNet.Calculate_Output();

			errorSum += NeuralNet.OutputNeurons_ErrorCalculations(DesiredOutputArray_Image_8, 1.0f, 0.005f);
			PrecedingNeuronErrorCalculations(&NeuralNet.PrecedingNeuron, &NeuralNet.pOutputNeuronArray[0], NeuralNet_NumOfOutputValues, 1.0f, 0.005f);
			PrecedingNeuronLearning(&NeuralNet.PrecedingNeuron, 0.01f);
			NeuralNet.OutputNeurons_Adjust_Dendrite_Factors_AfterErrorCalculations(0.01f);
		}
		for (int32_t ii = 0; ii < ConstNumOfRandomTestImages; ii++)
		{
			NeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(&RandomTestImage_5_Array[ii][0]);
			NeuralNet.Calculate_Output();

			errorSum += NeuralNet.OutputNeurons_ErrorCalculations(DesiredOutputArray_Image_5, 1.0f, 0.005f);
			PrecedingNeuronErrorCalculations(&NeuralNet.PrecedingNeuron, &NeuralNet.pOutputNeuronArray[0], NeuralNet_NumOfOutputValues, 1.0f, 0.005f);
			PrecedingNeuronLearning(&NeuralNet.PrecedingNeuron, 0.01f);
			NeuralNet.OutputNeurons_Adjust_Dendrite_Factors_AfterErrorCalculations(0.01f);
		}
		for (int32_t ii = 0; ii < ConstNumOfRandomTestImages; ii++)
		{
			NeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(&RandomTestImage_6_Array[ii][0]);
			NeuralNet.Calculate_Output();

			errorSum += NeuralNet.OutputNeurons_ErrorCalculations(DesiredOutputArray_Image_6, 1.0f, 0.005f);
			PrecedingNeuronErrorCalculations(&NeuralNet.PrecedingNeuron, &NeuralNet.pOutputNeuronArray[0], NeuralNet_NumOfOutputValues, 1.0f, 0.005f);
			PrecedingNeuronLearning(&NeuralNet.PrecedingNeuron, 0.01f);
			NeuralNet.OutputNeurons_Adjust_Dendrite_Factors_AfterErrorCalculations(0.01f);
		}
		for (int32_t ii = 0; ii < ConstNumOfRandomTestImages; ii++)
		{
			NeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(&RandomTestImage_G_Array[ii][0]);
			NeuralNet.Calculate_Output();

			errorSum += NeuralNet.OutputNeurons_ErrorCalculations(DesiredOutputArray_Image_G, 1.0f, 0.005f);
			PrecedingNeuronErrorCalculations(&NeuralNet.PrecedingNeuron, &NeuralNet.pOutputNeuronArray[0], NeuralNet_NumOfOutputValues, 1.0f, 0.005f);
			PrecedingNeuronLearning(&NeuralNet.PrecedingNeuron, 0.01f);
			NeuralNet.OutputNeurons_Adjust_Dendrite_Factors_AfterErrorCalculations(0.01f);
		}
		for (int32_t ii = 0; ii < ConstNumOfRandomTestImages; ii++)
		{
			NeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(&RandomTestImage_S_Array[ii][0]);
			NeuralNet.Calculate_Output();

			errorSum += NeuralNet.OutputNeurons_ErrorCalculations(DesiredOutputArray_Image_S, 1.0f, 0.005f);
			PrecedingNeuronErrorCalculations(&NeuralNet.PrecedingNeuron, &NeuralNet.pOutputNeuronArray[0], NeuralNet_NumOfOutputValues, 1.0f, 0.005f);
			PrecedingNeuronLearning(&NeuralNet.PrecedingNeuron, 0.01f);
			NeuralNet.OutputNeurons_Adjust_Dendrite_Factors_AfterErrorCalculations(0.01f);
		}
		

		if (errorSum < 0.0001f)
			break;

		if (epoch % 10 == 0)
		{
			cout << "epoch: " << epoch << endl;
			cout << "error: " << errorSum << endl << endl;
		}
	}

	for (int32_t i = 0; i < ConstNumOfInputArrays; i++)
	{
		NeuralNet.PrecedingNeuron.Set_Dendrite_NeuronInput(pInputArrayPointer[i]);
		NeuralNet.Calculate_Output();
	
		float maxValue = -10000.0f;
		int32_t belongingID = 0;

		for (int32_t j = 0; j < 6; j++)
		{
			if (NeuralNet.pOutputNeuronArray[j].ActivationValue > maxValue)
			{
				maxValue = NeuralNet.pOutputNeuronArray[j].ActivationValue;
				belongingID = j;
			}
		}

		cout << RecognizedSymbolArray[belongingID] << " --- ";

		for (int32_t j = 0; j < 6; j++)
		{
			cout << NeuralNet.pOutputNeuronArray[j].ActivationValue << " ";
		}

		cout << endl;
		getchar();
	}





	cout << "press enter to quit program: ";
	
	getchar();
	

	return 0;
}
*/

/*
int main(void)
{
	static constexpr int32_t ProcessingNeuralNet_NumOfHiddenDendrites = 96;
	//static constexpr int32_t ProcessingNeuralNet_NumOfHiddenDendrites = 24;
	static constexpr int32_t ProcessingNeuralNet_NumOfOutputValues = 6;

	static float Image_B_1[32 * 32];
	static float Image_B_2[32 * 32];
	static float Image_B_3[32 * 32];
	static float Image_B_4[32 * 32];
	static float Image_B_5[32 * 32];
	static float Image_B_6[32 * 32];

	static float Image_8_1[32 * 32];
	static float Image_8_2[32 * 32];
	static float Image_8_3[32 * 32];
	static float Image_8_4[32 * 32];
	static float Image_8_5[32 * 32];
	static float Image_8_6[32 * 32];

	static float Image_5_1[32 * 32];
	static float Image_5_2[32 * 32];
	static float Image_5_3[32 * 32];
	static float Image_5_4[32 * 32];
	static float Image_5_5[32 * 32];
	static float Image_5_6[16 * 16];

	static float Image_6_1[32 * 32];
	static float Image_6_2[32 * 32];
	static float Image_6_3[32 * 32];
	static float Image_6_4[32 * 32];
	static float Image_6_5[32 * 32];
	static float Image_6_6[32 * 32];

	static float Image_G_1[32 * 32];
	static float Image_G_2[32 * 32];
	static float Image_G_3[32 * 32];
	static float Image_G_4[32 * 32];
	static float Image_G_5[32 * 32];
	static float Image_G_6[32 * 32];

	static float Image_S_1[32 * 32];
	static float Image_S_2[32 * 32];
	static float Image_S_3[32 * 32];
	static float Image_S_4[32 * 32];
	static float Image_S_5[32 * 32];
	static float Image_S_6[32 * 32];

	uint8_t *pImageData = nullptr;

	static float DesiredOutputArray_Image_B[6] = { 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f };
	static float DesiredOutputArray_Image_8[6] = { 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f };
	static float DesiredOutputArray_Image_5[6] = { 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f };
	static float DesiredOutputArray_Image_6[6] = { 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f };
	static float DesiredOutputArray_Image_G[6] = { 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f };
	static float DesiredOutputArray_Image_S[6] = { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f };



	pImageData = Read_Bitmap_BGR("Sample_B_1.bmp");
	Get_BinaryImageData_BlueChannel(Image_B_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_2.bmp");
	Get_BinaryImageData_BlueChannel(Image_B_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_3.bmp");
	Get_BinaryImageData_BlueChannel(Image_B_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_4.bmp");
	Get_BinaryImageData_BlueChannel(Image_B_4, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_5.bmp");
	Get_BinaryImageData_BlueChannel(Image_B_5, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_6.bmp");
	Get_BinaryImageData_BlueChannel(Image_B_6, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	///////////////////////////////



	pImageData = Read_Bitmap_BGR("Sample_8_1.bmp");
	Get_BinaryImageData_BlueChannel(Image_8_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_2.bmp");
	Get_BinaryImageData_BlueChannel(Image_8_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_3.bmp");
	Get_BinaryImageData_BlueChannel(Image_8_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_4.bmp");
	Get_BinaryImageData_BlueChannel(Image_8_4, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_5.bmp");
	Get_BinaryImageData_BlueChannel(Image_8_5, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_6.bmp");
	Get_BinaryImageData_BlueChannel(Image_8_6, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	//////////////////////////////



	pImageData = Read_Bitmap_BGR("Sample_5_1.bmp");
	Get_BinaryImageData_BlueChannel(Image_5_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_2.bmp");
	Get_BinaryImageData_BlueChannel(Image_5_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_3.bmp");
	Get_BinaryImageData_BlueChannel(Image_5_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_4.bmp");
	Get_BinaryImageData_BlueChannel(Image_5_4, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_5.bmp");
	Get_BinaryImageData_BlueChannel(Image_5_5, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_6.bmp");
	Get_BinaryImageData_BlueChannel(Image_5_6, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	//////////////////////////////



	pImageData = Read_Bitmap_BGR("Sample_6_1.bmp");
	Get_BinaryImageData_BlueChannel(Image_6_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_2.bmp");
	Get_BinaryImageData_BlueChannel(Image_6_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_3.bmp");
	Get_BinaryImageData_BlueChannel(Image_6_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_4.bmp");
	Get_BinaryImageData_BlueChannel(Image_6_4, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_5.bmp");
	Get_BinaryImageData_BlueChannel(Image_6_5, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_6.bmp");
	Get_BinaryImageData_BlueChannel(Image_6_6, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	//////////////////////////////



	pImageData = Read_Bitmap_BGR("Sample_G_1.bmp");
	Get_BinaryImageData_BlueChannel(Image_G_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_2.bmp");
	Get_BinaryImageData_BlueChannel(Image_G_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_3.bmp");
	Get_BinaryImageData_BlueChannel(Image_G_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_4.bmp");
	Get_BinaryImageData_BlueChannel(Image_G_4, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_5.bmp");
	Get_BinaryImageData_BlueChannel(Image_G_5, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_6.bmp");
	Get_BinaryImageData_BlueChannel(Image_G_6, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	//////////////////////////////



	pImageData = Read_Bitmap_BGR("Sample_S_1.bmp");
	Get_BinaryImageData_BlueChannel(Image_S_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_2.bmp");
	Get_BinaryImageData_BlueChannel(Image_S_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_3.bmp");
	Get_BinaryImageData_BlueChannel(Image_S_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_4.bmp");
	Get_BinaryImageData_BlueChannel(Image_S_4, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_5.bmp");
	Get_BinaryImageData_BlueChannel(Image_S_5, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_6.bmp");
	Get_BinaryImageData_BlueChannel(Image_S_6, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	//////////////////////////////

	static constexpr int32_t ConstNumOfInputArrays = 36;

	float *pInputArrayPointer[ConstNumOfInputArrays];

	pInputArrayPointer[0] = Image_B_1;
	pInputArrayPointer[1] = Image_B_2;
	pInputArrayPointer[2] = Image_B_3;
	pInputArrayPointer[3] = Image_B_4;
	pInputArrayPointer[4] = Image_B_5;
	pInputArrayPointer[5] = Image_B_6;

	pInputArrayPointer[6] = Image_8_1;
	pInputArrayPointer[7] = Image_8_2;
	pInputArrayPointer[8] = Image_8_3;
	pInputArrayPointer[9] = Image_8_4;
	pInputArrayPointer[10] = Image_8_5;
	pInputArrayPointer[11] = Image_8_6;

	pInputArrayPointer[12] = Image_5_1;
	pInputArrayPointer[13] = Image_5_2;
	pInputArrayPointer[14] = Image_5_3;
	pInputArrayPointer[15] = Image_5_4;
	pInputArrayPointer[16] = Image_5_5;
	pInputArrayPointer[17] = Image_5_6;

	pInputArrayPointer[18] = Image_6_1;
	pInputArrayPointer[19] = Image_6_2;
	pInputArrayPointer[20] = Image_6_3;
	pInputArrayPointer[21] = Image_6_4;
	pInputArrayPointer[22] = Image_6_5;
	pInputArrayPointer[23] = Image_6_6;

	pInputArrayPointer[24] = Image_G_1;
	pInputArrayPointer[25] = Image_G_2;
	pInputArrayPointer[26] = Image_G_3;
	pInputArrayPointer[27] = Image_G_4;
	pInputArrayPointer[28] = Image_G_5;
	pInputArrayPointer[29] = Image_G_6;

	pInputArrayPointer[30] = Image_S_1;
	pInputArrayPointer[31] = Image_S_2;
	pInputArrayPointer[32] = Image_S_3;
	pInputArrayPointer[33] = Image_S_4;
	pInputArrayPointer[34] = Image_S_5;
	pInputArrayPointer[35] = Image_S_6;





	char RecognizedSymbolArray[ProcessingNeuralNet_NumOfOutputValues + 1] = { 'B', '8', '5', '6', 'G', 'S', '\0' };


	CSimpleNeuron RecognitionNeuron_B;
	RecognitionNeuron_B.Init_Dendrite_Arrays(32 * 32);

	static float Image_B_Mean[32 * 32];


	CSimpleNeuron RecognitionNeuron_8;
	RecognitionNeuron_8.Init_Dendrite_Arrays(32 * 32);

	static float Image_8_Mean[32 * 32];


	CSimpleNeuron RecognitionNeuron_5;
	RecognitionNeuron_5.Init_Dendrite_Arrays(32 * 32);

	static float Image_5_Mean[32 * 32];


	CSimpleNeuron RecognitionNeuron_6;
	RecognitionNeuron_6.Init_Dendrite_Arrays(32 * 32);

	static float Image_6_Mean[32 * 32];


	CSimpleNeuron RecognitionNeuron_G;
	RecognitionNeuron_G.Init_Dendrite_Arrays(32 * 32);

	static float Image_G_Mean[32 * 32];


	CSimpleNeuron RecognitionNeuron_S;
	RecognitionNeuron_S.Init_Dendrite_Arrays(32 * 32);

	static float Image_S_Mean[32 * 32];


	float fallback_RBF_Factor = 0.5f;
	float centroidWeightFactor = 0.025f;
	int32_t centroidExponent = 4;

	//float fallback_RBF_Factor = 10.0f;
	//float centroidWeightFactor = 0.025f;
	//int32_t centroidExponent = 2;

	
	for (int32_t i = 0; i < 6; i++)
	{
		RecognitionNeuron_B.Add_TrainingExample(pInputArrayPointer[i]);
		RecognitionNeuron_B.Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

		RecognitionNeuron_8.Add_TrainingExample(pInputArrayPointer[i + 6]);
		RecognitionNeuron_8.Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

		RecognitionNeuron_5.Add_TrainingExample(pInputArrayPointer[i + 12]);
		RecognitionNeuron_5.Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

		RecognitionNeuron_6.Add_TrainingExample(pInputArrayPointer[i + 18]);
		RecognitionNeuron_6.Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

		RecognitionNeuron_G.Add_TrainingExample(pInputArrayPointer[i + 24]);
		RecognitionNeuron_G.Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

		RecognitionNeuron_S.Add_TrainingExample(pInputArrayPointer[i + 30]);
		RecognitionNeuron_S.Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}
	

		
#ifdef test1234

	static float tempImage1[32 * 32];
	static float tempImage2[32 * 32];

	for (int32_t i = 0; i < 6; i++)
	{
		Convolution3x3(tempImage1, pInputArrayPointer[i], 32, 32, Conv3x3Matrix_BoxBlur);
		RecognitionNeuron_B.Add_TrainingExample(tempImage1);
		RecognitionNeuron_B.Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

		Convolution3x3(tempImage1, pInputArrayPointer[i + 6], 32, 32, Conv3x3Matrix_BoxBlur);
		RecognitionNeuron_8.Add_TrainingExample(tempImage1);
		RecognitionNeuron_8.Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

		Convolution3x3(tempImage1, pInputArrayPointer[i + 12], 32, 32, Conv3x3Matrix_BoxBlur);
		RecognitionNeuron_5.Add_TrainingExample(tempImage1);
		RecognitionNeuron_5.Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

		Convolution3x3(tempImage1, pInputArrayPointer[i + 18], 32, 32, Conv3x3Matrix_BoxBlur);
		RecognitionNeuron_6.Add_TrainingExample(tempImage1);
		RecognitionNeuron_6.Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

		Convolution3x3(tempImage1, pInputArrayPointer[i + 24], 32, 32, Conv3x3Matrix_BoxBlur);
		RecognitionNeuron_G.Add_TrainingExample(tempImage1);
		RecognitionNeuron_G.Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);

		Convolution3x3(tempImage1, pInputArrayPointer[i + 30], 32, 32, Conv3x3Matrix_BoxBlur);
		RecognitionNeuron_S.Add_TrainingExample(tempImage1);
		RecognitionNeuron_S.Calculate_Dendrite_Factors_From_CentroidValues(fallback_RBF_Factor, centroidWeightFactor, centroidExponent);
	}
#endif

	for (int32_t i = 0; i < 1024; i++)
	{
		Image_B_Mean[i] = RecognitionNeuron_B.pDendrite_CentroidValueArray[i];
		Image_B_Mean[i] *= Image_B_Mean[i];
		//Image_B_Mean[i] = sqrt(Image_B_Mean[i]);


		Image_8_Mean[i] = RecognitionNeuron_8.pDendrite_CentroidValueArray[i];
		Image_8_Mean[i] *= Image_8_Mean[i];
		//Image_8_Mean[i] = sqrt(Image_8_Mean[i]);


		Image_5_Mean[i] = RecognitionNeuron_5.pDendrite_CentroidValueArray[i];
		Image_5_Mean[i] *= Image_5_Mean[i];
		//Image_5_Mean[i] = sqrt(Image_5_Mean[i]);


		Image_6_Mean[i] = RecognitionNeuron_6.pDendrite_CentroidValueArray[i];
		Image_6_Mean[i] *= Image_6_Mean[i];
		//Image_6_Mean[i] = sqrt(Image_6_Mean[i]);


		Image_G_Mean[i] = RecognitionNeuron_G.pDendrite_CentroidValueArray[i];
		Image_G_Mean[i] *= Image_G_Mean[i];
		//Image_G_Mean[i] = sqrt(Image_G_Mean[i]);


		Image_S_Mean[i] = RecognitionNeuron_S.pDendrite_CentroidValueArray[i];
		Image_S_Mean[i] *= Image_S_Mean[i];
		//Image_S_Mean[i] = sqrt(Image_S_Mean[i]);

	}

	static constexpr int32_t ConstNumOfRandomTestImages = 20;

	static float RandomTestImage_B_Array[ConstNumOfRandomTestImages][32 * 32];
	static float RandomTestImage_8_Array[ConstNumOfRandomTestImages][32 * 32];
	static float RandomTestImage_5_Array[ConstNumOfRandomTestImages][32 * 32];
	static float RandomTestImage_6_Array[ConstNumOfRandomTestImages][32 * 32];
	static float RandomTestImage_G_Array[ConstNumOfRandomTestImages][32 * 32];
	static float RandomTestImage_S_Array[ConstNumOfRandomTestImages][32 * 32];



	int32_t NumLRFNeurons_Layer1 = 4;
	int32_t LRFSizeX_Layer1 = 5;
	int32_t LRFSizeY_Layer1 = 5;
	//int32_t NumLRFNeurons_Layer1 = 12;
	//int32_t LRFSizeX_Layer1 = 3;
	//int32_t LRFSizeY_Layer1 = 3;


	int32_t InputVectorSizeX = 32;
	int32_t InputVectorSizeY = 32;

	float LRF_MinRandomFactor = -1.0f;
	float LRF_MaxRandomFactor = 1.0f;

	CRandomNumbersNN RandomNumbers;


	CSimpleDeepNeuralNet_Base NeuralNet;

	NeuralNet.Initialize(&RandomNumbers, &RandomNumbers, NumLRFNeurons_Layer1, LRFSizeX_Layer1, LRFSizeY_Layer1, LRF_MinRandomFactor, LRF_MaxRandomFactor, InputVectorSizeX, InputVectorSizeY, ProcessingNeuralNet_NumOfHiddenDendrites, ProcessingNeuralNet_NumOfOutputValues);

	float output;
	float desiredOutput;
	float errorSum;


	//int32_t maxCount = 100;
	//int32_t maxCount = 200;
	//int32_t maxCount = 400;
	//int32_t maxCount = 500;
	int32_t maxCount = 1000;
	//int32_t maxCount = 2000;
	//int32_t maxCount = 4000;
	int32_t epoch = 0;


	for (int32_t jj = 0; jj < maxCount; jj++)
	{
		////////////////////////

		for (int32_t j = 0; j < ConstNumOfRandomTestImages; j++)
		{
			float *pImageValue = &RandomTestImage_B_Array[j][0];

			for (int32_t i = 0; i < 1024; i++)
			{
				if (Image_B_Mean[i] == 0.0f)
				{
					pImageValue[i] = 0.0f;
				}
				else if (Image_B_Mean[i] == 1.0f)
				{
					pImageValue[i] = 1.0f;		
				}
				else
				{
					if (RandomNumbers.Get_FloatNumber_IncludingZero(0.0f, 1.0f) > Image_B_Mean[i])
					{
						pImageValue[i] = 0.0f;
					}
					else
					{
						pImageValue[i] = 1.0f;
					}
				}
			}

			////////////////////////

			pImageValue = &RandomTestImage_8_Array[j][0];

			for (int32_t i = 0; i < 1024; i++)
			{
				if (Image_8_Mean[i] == 0.0f)
				{
					pImageValue[i] = 0.0f;
				}
				else if (Image_8_Mean[i] == 1.0f)
				{
					pImageValue[i] = 1.0f;
				}
				else
				{
					if (RandomNumbers.Get_FloatNumber_IncludingZero(0.0f, 1.0f) > Image_8_Mean[i])
					{
						pImageValue[i] = 0.0f;
					}
					else
					{
						pImageValue[i] = 1.0f;
					}
				}
			}

			////////////////////////

			pImageValue = &RandomTestImage_5_Array[j][0];

			for (int32_t i = 0; i < 1024; i++)
			{
				if (Image_5_Mean[i] == 0.0f)
				{
					pImageValue[i] = 0.0f;
				}
				else if (Image_5_Mean[i] == 1.0f)
				{
					pImageValue[i] = 1.0f;
				}
				else
				{
					if (RandomNumbers.Get_FloatNumber_IncludingZero(0.0f, 1.0f) > Image_5_Mean[i])
					{
						pImageValue[i] = 0.0f;
					}
					else
					{
						pImageValue[i] = 1.0f;
					}
				}
			}

			////////////////////////

			pImageValue = &RandomTestImage_6_Array[j][0];

			for (int32_t i = 0; i < 1024; i++)
			{
				if (Image_6_Mean[i] == 0.0f)
				{
					pImageValue[i] = 0.0f;
				}
				else if (Image_6_Mean[i] == 1.0f)
				{
					pImageValue[i] = 1.0f;
				}
				else
				{
					if (RandomNumbers.Get_FloatNumber_IncludingZero(0.0f, 1.0f) > Image_6_Mean[i])
					{
						pImageValue[i] = 0.0f;
					}
					else
					{
						pImageValue[i] = 1.0f;
					}
				}
			}

			////////////////////////

			pImageValue = &RandomTestImage_G_Array[j][0];

			for (int32_t i = 0; i < 1024; i++)
			{
				if (Image_G_Mean[i] == 0.0f)
				{
					pImageValue[i] = 0.0f;
				}
				else if (Image_G_Mean[i] == 1.0f)
				{
					pImageValue[i] = 1.0f;
				}
				else
				{
					if (RandomNumbers.Get_FloatNumber_IncludingZero(0.0f, 1.0f) > Image_G_Mean[i])
					{
						pImageValue[i] = 0.0f;
					}
					else
					{
						pImageValue[i] = 1.0f;
					}
				}
			}

			////////////////////////

			pImageValue = &RandomTestImage_S_Array[j][0];

			for (int32_t i = 0; i < 1024; i++)
			{
				if (Image_S_Mean[i] == 0.0f)
				{
					pImageValue[i] = 0.0f;
				}
				else if (Image_S_Mean[i] == 1.0f)
				{
					pImageValue[i] = 1.0f;
				}
				else
				{
					if (RandomNumbers.Get_FloatNumber_IncludingZero(0.0f, 1.0f) > Image_S_Mean[i])
					{
						pImageValue[i] = 0.0f;
					}
					else
					{
						pImageValue[i] = 1.0f;
					}
				}
			}
		}

		////////////////////////

		epoch++;
		errorSum = 0.0f;

		for (int32_t ii = 0; ii < ConstNumOfRandomTestImages; ii++)	
		{
			NeuralNet.Calculate_Output(&RandomTestImage_B_Array[ii][0], 0, InputVectorSizeX, 0, InputVectorSizeY);	
			NeuralNet.BackpropagationTraining(&errorSum, DesiredOutputArray_Image_B);
		}
		for (int32_t ii = 0; ii < ConstNumOfRandomTestImages; ii++)
		{
			NeuralNet.Calculate_Output(&RandomTestImage_8_Array[ii][0], 0, InputVectorSizeX, 0, InputVectorSizeY);
			NeuralNet.BackpropagationTraining(&errorSum, DesiredOutputArray_Image_8);
		}
		for (int32_t ii = 0; ii < ConstNumOfRandomTestImages; ii++)
		{
			NeuralNet.Calculate_Output(&RandomTestImage_5_Array[ii][0], 0, InputVectorSizeX, 0, InputVectorSizeY);
			NeuralNet.BackpropagationTraining(&errorSum, DesiredOutputArray_Image_5);
		}
		for (int32_t ii = 0; ii < ConstNumOfRandomTestImages; ii++)
		{
			NeuralNet.Calculate_Output(&RandomTestImage_6_Array[ii][0], 0, InputVectorSizeX, 0, InputVectorSizeY);
			NeuralNet.BackpropagationTraining(&errorSum, DesiredOutputArray_Image_6);
		}
		for (int32_t ii = 0; ii < ConstNumOfRandomTestImages; ii++)
		{
			NeuralNet.Calculate_Output(&RandomTestImage_G_Array[ii][0], 0, InputVectorSizeX, 0, InputVectorSizeY);
			NeuralNet.BackpropagationTraining(&errorSum, DesiredOutputArray_Image_G);
		}
		for (int32_t ii = 0; ii < ConstNumOfRandomTestImages; ii++)
		{
			NeuralNet.Calculate_Output(&RandomTestImage_S_Array[ii][0], 0, InputVectorSizeX, 0, InputVectorSizeY);
			NeuralNet.BackpropagationTraining(&errorSum, DesiredOutputArray_Image_S);
		}


		if (errorSum < 0.0001f)
			break;

		if (epoch % 10 == 0)
		{
			cout << "epoch: " << epoch << endl;
			cout << "error: " << errorSum << endl << endl;
		}
	}

	for (int32_t i = 0; i < ConstNumOfInputArrays; i++)
	{
		NeuralNet.Calculate_Output(pInputArrayPointer[i], 0, InputVectorSizeX, 0, InputVectorSizeY);
		
		float maxValue = -10000.0f;
		int32_t belongingID = 0;

		for (int32_t j = 0; j < 6; j++)
		{
			if (NeuralNet.ProcessingNeuralNet.pOutputNeuronArray[j].ActivationValue > maxValue)
			{
				maxValue = NeuralNet.ProcessingNeuralNet.pOutputNeuronArray[j].ActivationValue;
				belongingID = j;
			}
		}

		cout << RecognizedSymbolArray[belongingID] << " --- ";

		for (int32_t j = 0; j < 6; j++)
		{
			cout << NeuralNet.ProcessingNeuralNet.pOutputNeuronArray[j].ActivationValue << " ";
		}

		cout << endl;
		getchar();
	}





	cout << "press enter to quit program: ";

	getchar();


	return 0;
}
*/






/*
int main(void)
{
	static constexpr int32_t TrainingPopulationSize = 100;
	static constexpr int32_t NumTrainingGenerationsMax = 20000;

	// Visualisierung der einzelnen St�dte:

	static char SurfaceMap[NumSurfaceMapElements];

	Init_SurfaceMap(SurfaceMap, '*');

	Set_SurfaceMapData(SurfaceMap, 2, 0, '0');
	Set_SurfaceMapData(SurfaceMap, 4, 0, '1');
	Set_SurfaceMapData(SurfaceMap, 0, 1, '2');
	Set_SurfaceMapData(SurfaceMap, 4, 2, '3');
	Set_SurfaceMapData(SurfaceMap, 0, 4, '4');
	Set_SurfaceMapData(SurfaceMap, 2, 3, '5');
	Set_SurfaceMapData(SurfaceMap, 3, 4, '6');
	Set_SurfaceMapData(SurfaceMap, 5, 5, '7');
	Set_SurfaceMapData(SurfaceMap, 6, 3, '8');
	Set_SurfaceMapData(SurfaceMap, 1, 6, '9');
	Set_SurfaceMapData(SurfaceMap, 6, 1, 'A');
	Set_SurfaceMapData(SurfaceMap, 3, 6, 'B');


	Output_SurfaceMapData(SurfaceMap);

	// Visualisierung der einzelnen St�dte abgeschlossen

	static CGraphNode GraphNodeArray[NumCities_TSP_Plus1];

	GraphNodeArray[0].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[0].Set_Position(2.0f, 0.0f, 0.0f);
	GraphNodeArray[1].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[1].Set_Position(4.0f, 0.0f, 0.0f);
	GraphNodeArray[2].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[2].Set_Position(0.0f, 1.0f, 0.0f);
	GraphNodeArray[3].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[3].Set_Position(4.0f, 2.0f, 0.0f);
	GraphNodeArray[4].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[4].Set_Position(0.0f, 4.0f, 0.0f);
	GraphNodeArray[5].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[5].Set_Position(2.0f, 3.0f, 0.0f);
	GraphNodeArray[6].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[6].Set_Position(3.0f, 4.0f, 0.0f);
	GraphNodeArray[7].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[7].Set_Position(5.0f, 5.0f, 0.0f);
	GraphNodeArray[8].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[8].Set_Position(6.0f, 3.0f, 0.0f);
	GraphNodeArray[9].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[9].Set_Position(1.0f, 6.0f, 0.0f);
	GraphNodeArray[10].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[10].Set_Position(6.0f, 1.0f, 0.0f);
	GraphNodeArray[11].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[11].Set_Position(3.0f, 6.0f, 0.0f);
	GraphNodeArray[12].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[12].Set_Position(2.0f, 0.0f, 0.0f);

	CSimpleNeuron NeuronArray[TrainingPopulationSize];

	CSimpleNeuronPopulation NeuronPopulation;

	NeuronPopulation.Initialize(TrainingPopulationSize);

	for (int32_t i = 0; i < TrainingPopulationSize; i++)
	{
		NeuronPopulation.Set_Neuron(&NeuronArray[i], i);
	}

	NeuronPopulation.Init_Or_Reinitialize_Dendrite_Arrays(NumCities_TSP_Plus1);

	static float InitialPath[NumCities_TSP_Plus1];

	for (int32_t i = 0; i < NumCities_TSP; i++)
		InitialPath[i] = static_cast<float>(i);

	// Ziel der Rundreise:
	InitialPath[NumCities_TSP] = 0.0f;

	for (int32_t i = 0; i < NumCities_TSP_Plus1; i++)
	{
		cout << InitialPath[i] << " ";
	}

	cout << endl;

	NeuronPopulation.Set_Dendrite_Factors(InitialPath);

	CPermutationInfo PermutationInfo;
	PermutationInfo.minDendriteID = 1;
	PermutationInfo.maxDendriteID = NumCities_TSP_Plus1 - 2;
	PermutationInfo.permutationSteps = 3;

	NeuronPopulation.Permute_Dendrite_Values(TSP_PermutationFunction, &PermutationInfo);

	PermutationInfo.permutationSteps = 1;

	for (int32_t i = 0; i < NumTrainingGenerationsMax; i++)
	{
		Update_Fitnessvalues(GraphNodeArray, &NeuronPopulation);

		NeuronPopulation.Update_Population();

		NeuronPopulation.Update_BaseEvolution2(TSP_PermutationFunction, &PermutationInfo);
		NeuronPopulation.Update_Evolution_BestBrainOnly2(TSP_PermutationFunction, &PermutationInfo);
		NeuronPopulation.Update_Evolution_SecondBestBrainOnly2(TSP_PermutationFunction, &PermutationInfo);
		NeuronPopulation.Update_Evolution_Combine_BestTwoBrains(TSP_RecombinationFunction, nullptr);
		NeuronPopulation.Update_Evolution_Combine_TwoBrains(TSP_RecombinationFunction, nullptr);
		NeuronPopulation.Update_Evolution_Combine_TwoBrains(TSP_RecombinationFunction, nullptr);
	}

	static int32_t ShortestPath[NumCities_TSP_Plus1];

	Get_Shortest_TSP_Path(ShortestPath, &NeuronPopulation);

	float minPathDistSq = GraphNodeArray[0].Calculate_PathDistSq(ShortestPath, NumCities_TSP_Plus1);

	cout << endl << "minPathDistSq: " << minPathDistSq << endl;

	static int32_t RearrangedPath[NumCities_TSP_Plus1];

	Rearrange_TSP_Path(RearrangedPath, ShortestPath, NumCities_TSP_Plus1, 3);

	for (int32_t i = 0; i < NumCities_TSP_Plus1; i++)
	{
		cout << ShortestPath[i] << " ";
	}

	cout << endl;

	for (int32_t i = 0; i < NumCities_TSP_Plus1; i++)
	{
		cout << RearrangedPath[i] << " ";
	}

	cout << endl;


	getchar();

	return 0;
}
*/

/*
int main(void)
{
	static constexpr int32_t TrainingPopulationSize = 100;
	static constexpr int32_t NumTrainingGenerationsMax = 20000;

	// Visualisierung der einzelnen St�dte:

	static char SurfaceMap[NumSurfaceMapElements];

	Init_SurfaceMap(SurfaceMap, '*');

	Set_SurfaceMapData(SurfaceMap, 2, 0, '0');
	Set_SurfaceMapData(SurfaceMap, 4, 0, '1');
	Set_SurfaceMapData(SurfaceMap, 0, 1, '2');
	Set_SurfaceMapData(SurfaceMap, 4, 2, '3');
	Set_SurfaceMapData(SurfaceMap, 0, 4, '4');
	Set_SurfaceMapData(SurfaceMap, 2, 3, '5');
	Set_SurfaceMapData(SurfaceMap, 3, 4, '6');
	Set_SurfaceMapData(SurfaceMap, 5, 5, '7');
	Set_SurfaceMapData(SurfaceMap, 6, 3, '8');
	Set_SurfaceMapData(SurfaceMap, 1, 6, '9');
	Set_SurfaceMapData(SurfaceMap, 6, 1, 'A');
	Set_SurfaceMapData(SurfaceMap, 3, 6, 'B');


	Output_SurfaceMapData(SurfaceMap);

	// Visualisierung der einzelnen St�dte abgeschlossen

	static CGraphNode GraphNodeArray[NumCities_TSP_Plus1];

	GraphNodeArray[0].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[0].Set_Position(2.0f, 0.0f, 0.0f);
	GraphNodeArray[1].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[1].Set_Position(4.0f, 0.0f, 0.0f);
	GraphNodeArray[2].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[2].Set_Position(0.0f, 1.0f, 0.0f);
	GraphNodeArray[3].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[3].Set_Position(4.0f, 2.0f, 0.0f);
	GraphNodeArray[4].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[4].Set_Position(0.0f, 4.0f, 0.0f);
	GraphNodeArray[5].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[5].Set_Position(2.0f, 3.0f, 0.0f);
	GraphNodeArray[6].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[6].Set_Position(3.0f, 4.0f, 0.0f);
	GraphNodeArray[7].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[7].Set_Position(5.0f, 5.0f, 0.0f);
	GraphNodeArray[8].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[8].Set_Position(6.0f, 3.0f, 0.0f);
	GraphNodeArray[9].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[9].Set_Position(1.0f, 6.0f, 0.0f);
	GraphNodeArray[10].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[10].Set_Position(6.0f, 1.0f, 0.0f);
	GraphNodeArray[11].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[11].Set_Position(3.0f, 6.0f, 0.0f);
	GraphNodeArray[12].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[12].Set_Position(2.0f, 0.0f, 0.0f);

	CSimpleNeuron NeuronArray[TrainingPopulationSize];

	CSimpleNeuronPopulation NeuronPopulation;

	NeuronPopulation.Initialize(TrainingPopulationSize);

	for (int32_t i = 0; i < TrainingPopulationSize; i++)
	{
		NeuronPopulation.Set_Neuron(&NeuronArray[i], i);
	}

	NeuronPopulation.Init_Or_Reinitialize_AdditionalMemoryValues(NumCities_TSP_Plus1);

	static float InitialPath[NumCities_TSP_Plus1];

	for (int32_t i = 0; i < NumCities_TSP; i++)
		InitialPath[i] = static_cast<float>(i);

	// Ziel der Rundreise:
	InitialPath[NumCities_TSP] = 0.0f;

	for (int32_t i = 0; i < NumCities_TSP_Plus1; i++)
	{
		cout << InitialPath[i] << " ";
	}

	cout << endl;

	NeuronPopulation.Set_AdditionalMemoryValues(InitialPath);

	CPermutationInfo2 PermutationInfo;
	PermutationInfo.minWaypointID = 1;
	PermutationInfo.maxWaypointID = NumCities_TSP_Plus1 - 2;
	PermutationInfo.permutationSteps = 3;

	NeuronPopulation.Permute_AdditionalMemoryValues(TSP_PermutationFunction2, &PermutationInfo);

	PermutationInfo.permutationSteps = 1;

	for (int32_t i = 0; i < NumTrainingGenerationsMax; i++)
	{
		Update_Fitnessvalues2(GraphNodeArray, &NeuronPopulation);

		NeuronPopulation.Update_Population();

		NeuronPopulation.Update_BaseEvolution2(TSP_PermutationFunction2, &PermutationInfo);
		NeuronPopulation.Update_Evolution_BestBrainOnly2(TSP_PermutationFunction2, &PermutationInfo);
		NeuronPopulation.Update_Evolution_SecondBestBrainOnly2(TSP_PermutationFunction2, &PermutationInfo);
		NeuronPopulation.Update_Evolution_Combine_BestTwoBrains(TSP_RecombinationFunction2, nullptr);
		NeuronPopulation.Update_Evolution_Combine_TwoBrains(TSP_RecombinationFunction2, nullptr);
		NeuronPopulation.Update_Evolution_Combine_TwoBrains(TSP_RecombinationFunction2, nullptr);
	}

	static int32_t ShortestPath[NumCities_TSP_Plus1];

	Get_Shortest_TSP_Path2(ShortestPath, &NeuronPopulation);

	float minPathDistSq = GraphNodeArray[0].Calculate_PathDistSq(ShortestPath, NumCities_TSP_Plus1);

	cout << endl << "minPathDistSq: " << minPathDistSq << endl;

	static int32_t RearrangedPath[NumCities_TSP_Plus1];

	Rearrange_TSP_Path(RearrangedPath, ShortestPath, NumCities_TSP_Plus1, 3);

	for (int32_t i = 0; i < NumCities_TSP_Plus1; i++)
	{
		cout << ShortestPath[i] << " ";
	}

	cout << endl;

	for (int32_t i = 0; i < NumCities_TSP_Plus1; i++)
	{
		cout << RearrangedPath[i] << " ";
	}

	cout << endl;


	getchar();

	return 0;
}
*/

/*
int main(void)
{
	static constexpr int32_t TrainingPopulationSize = 100;
	static constexpr int32_t NumTrainingGenerationsMax = 5000;

	// Visualisierung der einzelnen St�dte:

	static char SurfaceMap[NumSurfaceMapElements];

	Init_SurfaceMap(SurfaceMap, '*');

	Set_SurfaceMapData(SurfaceMap, 2, 0, '0');
	Set_SurfaceMapData(SurfaceMap, 4, 0, '1');
	Set_SurfaceMapData(SurfaceMap, 0, 1, '2');
	Set_SurfaceMapData(SurfaceMap, 4, 2, '3');
	Set_SurfaceMapData(SurfaceMap, 0, 4, '4');
	Set_SurfaceMapData(SurfaceMap, 2, 3, '5');
	Set_SurfaceMapData(SurfaceMap, 3, 4, '6');
	Set_SurfaceMapData(SurfaceMap, 5, 5, '7');
	Set_SurfaceMapData(SurfaceMap, 6, 3, '8');
	Set_SurfaceMapData(SurfaceMap, 1, 6, '9');
	Set_SurfaceMapData(SurfaceMap, 6, 1, 'A');
	Set_SurfaceMapData(SurfaceMap, 3, 6, 'B');


	Output_SurfaceMapData(SurfaceMap);

	// Visualisierung der einzelnen St�dte abgeschlossen

	static CGraphNode GraphNodeArray[NumWaypoints];

	GraphNodeArray[0].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[0].Set_Position(2.0f, 0.0f, 0.0f);
	GraphNodeArray[1].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[1].Set_Position(4.0f, 0.0f, 0.0f);
	GraphNodeArray[2].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[2].Set_Position(0.0f, 1.0f, 0.0f);
	GraphNodeArray[3].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[3].Set_Position(4.0f, 2.0f, 0.0f);
	GraphNodeArray[4].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[4].Set_Position(0.0f, 4.0f, 0.0f);
	GraphNodeArray[5].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[5].Set_Position(2.0f, 3.0f, 0.0f);
	GraphNodeArray[6].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[6].Set_Position(3.0f, 4.0f, 0.0f);
	GraphNodeArray[7].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[7].Set_Position(5.0f, 5.0f, 0.0f);
	GraphNodeArray[8].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[8].Set_Position(6.0f, 3.0f, 0.0f);
	GraphNodeArray[9].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[9].Set_Position(1.0f, 6.0f, 0.0f);
	GraphNodeArray[10].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[10].Set_Position(6.0f, 1.0f, 0.0f);
	GraphNodeArray[11].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[11].Set_Position(3.0f, 6.0f, 0.0f);

	int32_t StartID = 1;
	int32_t DestinationID = 11;



	CWeightMatrix WeightMatrix;
	WeightMatrix.Init_Matrix(NumWaypoints, NumWaypoints, 1.0f);

	WeightMatrix.Set_Weight(StartID, DestinationID, 1000.0f);
	WeightMatrix.Set_Weight(DestinationID, StartID, 1000.0f);

	WeightMatrix.Set_Weight(0, 5, 1000.0f);
	WeightMatrix.Set_Weight(5, 0, 1000.0f);

	WeightMatrix.Set_Weight(0, 1, 1000.0f);
	WeightMatrix.Set_Weight(1, 0, 1000.0f);


	CSimpleNeuron NeuronArray[TrainingPopulationSize];

	CSimpleNeuronPopulation NeuronPopulation;

	NeuronPopulation.Initialize(TrainingPopulationSize);

	for (int32_t i = 0; i < TrainingPopulationSize; i++)
	{
		NeuronPopulation.Set_Neuron(&NeuronArray[i], i);
	}

	NeuronPopulation.Init_Or_Reinitialize_Dendrite_Arrays(NumWaypointsMaxPerPath);

	static float InitialPath[NumWaypointsMaxPerPath];

	for (int32_t i = 0; i < NumWaypointsMaxPerPath; i++)
		InitialPath[i] = StartID;
	InitialPath[NumWaypointsMaxPerPath - 1] = DestinationID;


	for (int32_t i = 0; i < NumWaypointsMaxPerPath; i++)
	{
		cout << InitialPath[i] << " ";
	}

	cout << endl;



	NeuronPopulation.Set_Dendrite_Factors(InitialPath);

	NeuronPopulation.Mutate_Dendrite_Values(Pathfinding_MutationFunction, nullptr);

	for (int32_t i = 0; i < NumTrainingGenerationsMax; i++)
	{
		Update_FitnessvaluesExt(GraphNodeArray, &WeightMatrix, &NeuronPopulation);

		NeuronPopulation.Update_Population();

		NeuronPopulation.Update_BaseEvolution(Pathfinding_MutationFunction, nullptr);
		NeuronPopulation.Update_Evolution_BestBrainOnly(Pathfinding_MutationFunction, nullptr);
		NeuronPopulation.Update_Evolution_SecondBestBrainOnly(Pathfinding_MutationFunction, nullptr);
		NeuronPopulation.Update_Evolution_Combine_BestTwoBrains(Pathfinding_RecombinationFunction, nullptr);
		NeuronPopulation.Update_Evolution_Combine_TwoBrains(Pathfinding_RecombinationFunction, nullptr);
	}

	static int32_t BestPath[NumWaypointsMaxPerPath];
	int32_t NumWaypoints;

	Get_Best_Path(BestPath, &NumWaypoints, &NeuronPopulation);

	float minPathDistSq = GraphNodeArray[0].Calculate_PathDistSq(BestPath, NumWaypoints);

	cout << endl << "minPathDistSq: " << minPathDistSq << endl;

	for (int32_t i = 0; i < NumWaypoints; i++)
	{
		cout << BestPath[i] << " ";
	}

	cout << endl;

	getchar();

	return 0;
}
*/

/*
int main(void)
{
	static constexpr int32_t TrainingPopulationSize = 100;
	static constexpr int32_t NumTrainingGenerationsMax = 5000;

	// Visualisierung der einzelnen St�dte:

	static char SurfaceMap[NumSurfaceMapElements];

	Init_SurfaceMap(SurfaceMap, '*');

	Set_SurfaceMapData(SurfaceMap, 2, 0, '0');
	Set_SurfaceMapData(SurfaceMap, 4, 0, '1');
	Set_SurfaceMapData(SurfaceMap, 0, 1, '2');
	Set_SurfaceMapData(SurfaceMap, 4, 2, '3');
	Set_SurfaceMapData(SurfaceMap, 0, 4, '4');
	Set_SurfaceMapData(SurfaceMap, 2, 3, '5');
	Set_SurfaceMapData(SurfaceMap, 3, 4, '6');
	Set_SurfaceMapData(SurfaceMap, 5, 5, '7');
	Set_SurfaceMapData(SurfaceMap, 6, 3, '8');
	Set_SurfaceMapData(SurfaceMap, 1, 6, '9');
	Set_SurfaceMapData(SurfaceMap, 6, 1, 'A');
	Set_SurfaceMapData(SurfaceMap, 3, 6, 'B');


	Output_SurfaceMapData(SurfaceMap);

	// Visualisierung der einzelnen St�dte abgeschlossen

	static CGraphNode GraphNodeArray[NumWaypoints];

	GraphNodeArray[0].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[0].Set_Position(2.0f, 0.0f, 0.0f);
	GraphNodeArray[1].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[1].Set_Position(4.0f, 0.0f, 0.0f);
	GraphNodeArray[2].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[2].Set_Position(0.0f, 1.0f, 0.0f);
	GraphNodeArray[3].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[3].Set_Position(4.0f, 2.0f, 0.0f);
	GraphNodeArray[4].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[4].Set_Position(0.0f, 4.0f, 0.0f);
	GraphNodeArray[5].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[5].Set_Position(2.0f, 3.0f, 0.0f);
	GraphNodeArray[6].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[6].Set_Position(3.0f, 4.0f, 0.0f);
	GraphNodeArray[7].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[7].Set_Position(5.0f, 5.0f, 0.0f);
	GraphNodeArray[8].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[8].Set_Position(6.0f, 3.0f, 0.0f);
	GraphNodeArray[9].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[9].Set_Position(1.0f, 6.0f, 0.0f);
	GraphNodeArray[10].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[10].Set_Position(6.0f, 1.0f, 0.0f);
	GraphNodeArray[11].Connect_With_Graph(GraphNodeArray);
	GraphNodeArray[11].Set_Position(3.0f, 6.0f, 0.0f);

	int32_t StartID = 1;
	int32_t DestinationID = 11;



	CWeightMatrix WeightMatrix;
	WeightMatrix.Init_Matrix(NumWaypoints, NumWaypoints, 1.0f);

	WeightMatrix.Set_Weight(StartID, DestinationID, 1000.0f);
	WeightMatrix.Set_Weight(DestinationID, StartID, 1000.0f);

	WeightMatrix.Set_Weight(0, 5, 1000.0f);
	WeightMatrix.Set_Weight(5, 0, 1000.0f);

	WeightMatrix.Set_Weight(0, 1, 1000.0f);
	WeightMatrix.Set_Weight(1, 0, 1000.0f);


	CSimpleNeuron NeuronArray[TrainingPopulationSize];

	CSimpleNeuronPopulation NeuronPopulation;

	NeuronPopulation.Initialize(TrainingPopulationSize);

	for (int32_t i = 0; i < TrainingPopulationSize; i++)
	{
		NeuronPopulation.Set_Neuron(&NeuronArray[i], i);
	}

	NeuronPopulation.Init_Or_Reinitialize_AdditionalMemoryValues(NumWaypointsMaxPerPath);

	static float InitialPath[NumWaypointsMaxPerPath];

	for (int32_t i = 0; i < NumWaypointsMaxPerPath; i++)
		InitialPath[i] = StartID;
	InitialPath[NumWaypointsMaxPerPath - 1] = DestinationID;


	for (int32_t i = 0; i < NumWaypointsMaxPerPath; i++)
	{
		cout << InitialPath[i] << " ";
	}

	cout << endl;



	NeuronPopulation.Set_AdditionalMemoryValues(InitialPath);

	NeuronPopulation.Mutate_AdditionalMemoryValues(Pathfinding_MutationFunction2, nullptr);

	for (int32_t i = 0; i < NumTrainingGenerationsMax; i++)
	{
		Update_FitnessvaluesExt2(GraphNodeArray, &WeightMatrix, &NeuronPopulation);

		NeuronPopulation.Update_Population();

		NeuronPopulation.Update_BaseEvolution(Pathfinding_MutationFunction2, nullptr);
		NeuronPopulation.Update_Evolution_BestBrainOnly(Pathfinding_MutationFunction2, nullptr);
		NeuronPopulation.Update_Evolution_SecondBestBrainOnly(Pathfinding_MutationFunction2, nullptr);
		NeuronPopulation.Update_Evolution_Combine_BestTwoBrains(Pathfinding_RecombinationFunction2, nullptr);
		NeuronPopulation.Update_Evolution_Combine_TwoBrains(Pathfinding_RecombinationFunction2, nullptr);
	}

	static int32_t BestPath[NumWaypointsMaxPerPath];
	int32_t NumWaypoints;

	Get_Best_Path2(BestPath, &NumWaypoints, &NeuronPopulation);

	float minPathDistSq = GraphNodeArray[0].Calculate_PathDistSq(BestPath, NumWaypoints);

	cout << endl << "minPathDistSq: " << minPathDistSq << endl;

	for (int32_t i = 0; i < NumWaypoints; i++)
	{
		cout << BestPath[i] << " ";
	}

	cout << endl;

	getchar();

	return 0;
}
*/





/*
int main(void)
{
	static float Image_Test[32 * 32];
	static float tempImage[32 * 32];

	CRGBImageValues OriginalRGBImage;
	Read_Bitmap_BGR(&OriginalRGBImage, "Sample_B_1.bmp");
	Get_BinaryImageData_BlueChannel(Image_Test, OriginalRGBImage.pImageValues, 32, 32);

	//uint8_t *pImageData = nullptr;

	//pImageData = Read_Bitmap_BGR("Sample_B_1.bmp");
	//Get_BinaryImageData_BlueChannel(Image_Test, pImageData, 32, 32);

	//delete[] pImageData;
	//pImageData = nullptr;

	Convolution3x3(tempImage, Image_Test, 32, 32, Conv3x3Matrix_SobelX);
	Add_Convolution3x3(tempImage, Image_Test, 32, 32, Conv3x3Matrix_SobelY);

	//Convolution5x5(tempImage, Image_Test, 32, 32, Conv5x5Matrix_GaussianBlur);
	//Convolution3x3(tempImage, Image_Test, 32, 32, Conv3x3Matrix_BoxBlur);
	//Square_Pixels(tempImage, 32, 32);
	//Square_Pixels(tempImage, 32, 32);
	//Square_Pixels(tempImage, 32, 32);
	//Remove_NonEdgePixels(tempImage, Image_Test, 32, 32, 0.0f);
	//Convolution3x3(tempImage, Image_Test, 32, 32, Conv3x3Matrix_Edge);
	//Convolution3x3(tempImage, Image_Test, 32, 32, Conv3x3Matrix_VertLine);
	//Add_Convolution3x3(tempImage, Image_Test, 32, 32, Conv3x3Matrix_HorLine);
	

	CRGBImageValues RGBImageValues;
	Init_RGB_ImageArray(&RGBImageValues, 32, 32);


	CopyData_Into_RGBChannels(RGBImageValues.pImageValues, tempImage, 32, 32);
	//CopyData_Into_RGBChannels(RGBImageValues.pImageValues, Image_Test, 32, 32);
	Save_RGB_BitmapImage(RGBImageValues.pImageValues, 32, 32, "ImageTest.bmp");

	//uint8_t *pImage = nullptr;

	//pImage = Init_RGB_ImageArray(32, 32);

	//CopyData_Into_RGBChannels(pImage, tempImage, 32, 32);
	//CopyData_Into_RGBChannels(pImage, Image_Test, 32, 32);
	//Save_RGB_BitmapImage(pImage, 32, 32, "ImageTest.bmp");

	//delete[] pImage;
	//pImage = nullptr;

	getchar();
	return 0;
}
*/




