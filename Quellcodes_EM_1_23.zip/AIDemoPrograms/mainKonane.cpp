#pragma warning(disable: 4996)

#include <iostream>
//#include <chrono>
#include <omp.h>
#include <thread>
#include "ConsoleHelperFunctions.h"
#include "LogFile.h"
#include "NeuralCalculationNet.h"
#include "Konane.h"

using namespace std;
using namespace chrono;
using namespace HelperStuff;

#define KEYDOWN(vk_code) ((GetAsyncKeyState(vk_code) & 0x8000) ? 1 : 0)
#define KEYUP(vk_code)   ((GetAsyncKeyState(vk_code) & 0x8000) ? 0 : 1)



static COLOR_PALETTE g_GameBoardColorArray[3] = { lightblue, lightgreen, lightred };

static void Update_KonaneGameBoardGraphics(CWindowsConsole2DObject* pGameBoard, int8_t* pData)
{
	for (int32_t iy = 0; iy < ConstGameBoardSizePerDir; iy++)
	{
		int32_t iyy = iy * ConstGameBoardSizePerDir;

		for (int32_t ix = 0; ix < ConstGameBoardSizePerDir; ix++)
		{
			int32_t id = ix + iyy;

			pGameBoard->Set_Pixel(ix, iy, g_GameBoardColorArray[pData[id]]);
			//pGameBoard->Set_Pixel(ix, iy, g_GameBoardColorArray[static_cast<int32_t>(pData[id])]);
		}
	}
}

static void Update_CheckersKonaneGameBoardGraphics(CWindowsConsole2DObject* pGameBoard, int8_t* pData)
{
	for (int32_t iy = 0; iy < ConstGameBoardSizePerDir; iy++)
	{
		int32_t iyy = iy * ConstGameBoardSizePerDir;

		for (int32_t ix = 0; ix < ConstGameBoardSizePerDir; ix++)
		{
			int32_t id = ix + iyy;

			COLOR_PALETTE backgroundColor = lightblue;
			//COLOR_PALETTE backgroundColor = blue;

			//if ((ix + iy) % 2 == 0)
				//backgroundColor = lightblue;

			int8_t value = pData[id];

			if (value == ConstGameBoard_Empty)
			{
				pGameBoard->Set_Pixel(ix, iy, backgroundColor);
				continue;
			}
			
			if (value == ConstGameBoard_Player1_Man)
			{
				pGameBoard->Set_Character(ix, iy, 'M', lightgreen, backgroundColor);
				continue;
			}

			if (value == ConstGameBoard_Player2_Man)
			{
				pGameBoard->Set_Character(ix, iy, 'M', lightred, backgroundColor);
				continue;
			}

			if (value == ConstGameBoard_Player1_King)
			{
				pGameBoard->Set_Character(ix, iy, 'K', lightgreen, backgroundColor);
				continue;
			}

			if (value == ConstGameBoard_Player2_King)
			{
				pGameBoard->Set_Character(ix, iy, 'K', lightred, backgroundColor);
				continue;
			}
		}
	}
}

static void Set_ProcessPriority(unsigned long priority)
{
	HANDLE ProcessHandle = GetCurrentProcess();

	if (priority == 0)
		SetPriorityClass(ProcessHandle, NORMAL_PRIORITY_CLASS);
	else if (priority == 1)
		SetPriorityClass(ProcessHandle, ABOVE_NORMAL_PRIORITY_CLASS);
	else if (priority == 2)
		SetPriorityClass(ProcessHandle, HIGH_PRIORITY_CLASS);
	else
		SetPriorityClass(ProcessHandle, REALTIME_PRIORITY_CLASS);
}

/*
int main(void)
{
	//Set_ProcessPriority(2);

	Begin_Log(0, "start AI_Log",
		"AI_Log.txt");

	Set_Title("Konane (ESC: Exit)");
	Set_ConsolePos(10, 10);

	CInitialGameBoards InitialKonaneBoards;
	InitialKonaneBoards.Initialize("InitialKonaneBoards.txt", ConstGameBoardSizePerDir, ConstGameBoardSizePerDir);

	CMovePatternList Player1MoveList;
	Player1MoveList.Initialize("KonanePlayer1MovesList.txt");

	CMovePatternList Player2MoveList;
	Player2MoveList.Initialize("KonanePlayer2MovesList.txt");


	CGameStateValues OldGameState;
	OldGameState.Initialize(ConstGameBoardSizePerDir, ConstGameBoardSizePerDir);

	CGameStateValues* pActualGameStateObject = nullptr;

	char inputBuffer[100];
	int32_t RecalculatePlacementStrategies = 0;

	cout << "Player Nr (1/2): ";

	cin.getline(inputBuffer, 100);

	int32_t HumanPlayer = 1;

	if (atoi(inputBuffer) != 1)
	{
		HumanPlayer = 2;
	}

	sprintf(inputBuffer, "InitialBoardID (0-%d): ", InitialKonaneBoards.NumOfInitialBoards - 1);
	cout << inputBuffer;

	cin.getline(inputBuffer, 100);
	int32_t InitialBoardID = min(InitialKonaneBoards.NumOfInitialBoards - 1, max(0, atoi(inputBuffer)));

	int32_t NumTestGameStatesMax = 20000;
	int32_t NumTestGameStatesMaxPerDepthLayer = 20000;

	cout << "AI-Type (0 / 1 / 2): ";

	int32_t AIType = 0;

	cin.getline(inputBuffer, 100);
	AIType = atoi(inputBuffer);

	cout << "MaxSearchDepth (2, 3, ...): ";

	cin.getline(inputBuffer, 100);
	int32_t MaxSearchDepth = atoi(inputBuffer);
	MaxSearchDepth = max(2, MaxSearchDepth);


	CKonaneBreadthFirstSearchAI KonaneBreadthFirstSearchAI;
	CKonaneDepthFirstSearchAI KonaneDepthFirstSearchAI;

	if (AIType == 0)
	{
		KonaneDepthFirstSearchAI.Initialize(&Player1MoveList, &Player2MoveList, 100000, MaxSearchDepth);
		KonaneDepthFirstSearchAI.Prepare_KonaneGame();
	}


	static float SearchDepthMovementProbabilityArray[10];

	if (AIType == 1)
	{
		cout << "NumTestGameStatesMax (try 100000 perDepthLayer): ";
		cin.getline(inputBuffer, 100);
		NumTestGameStatesMax = atoi(inputBuffer);

		cout << "NumTestGameStatesMaxPerDepthLayer: ";
		cin.getline(inputBuffer, 100);
		NumTestGameStatesMaxPerDepthLayer = atoi(inputBuffer);

		KonaneBreadthFirstSearchAI.Initialize(&Player1MoveList, &Player2MoveList, NumTestGameStatesMax, NumTestGameStatesMaxPerDepthLayer, MaxSearchDepth);
		KonaneBreadthFirstSearchAI.Prepare_KonaneGame();
	}
	else if (AIType > 1)
	{
		cout << "NumTestGameStatesMax (try 100000 perDepthLayer): ";
		cin.getline(inputBuffer, 100);
		NumTestGameStatesMax = atoi(inputBuffer);

		cout << "NumTestGameStatesMaxPerDepthLayer: ";
		cin.getline(inputBuffer, 100);
		NumTestGameStatesMaxPerDepthLayer = atoi(inputBuffer);

		for (int32_t i = 0; i < MaxSearchDepth; i++)
		{
			cout << "movementProbability_SearchDepth" << i + 1 << " (0-1): ";
			cin.getline(inputBuffer, 100);
			SearchDepthMovementProbabilityArray[i] = max(0.0f, atof(inputBuffer));
			SearchDepthMovementProbabilityArray[i] = min(SearchDepthMovementProbabilityArray[i], 1.0f);
		}

		KonaneBreadthFirstSearchAI.Initialize(&Player1MoveList, &Player2MoveList, NumTestGameStatesMax, NumTestGameStatesMaxPerDepthLayer, MaxSearchDepth);
		KonaneBreadthFirstSearchAI.Prepare_KonaneGame();
	}


	int32_t RandomSeed = 1;

	cout << "RandomSeed (> 0): ";

	cin.getline(inputBuffer, 100);
	RandomSeed = atoi(inputBuffer);
	RandomSeed = max(1, RandomSeed);

	KonaneBreadthFirstSearchAI.Change_Seed(RandomSeed);

	CInputHandling InputHandling;
	InputHandling.Initialize();

	Clear_Terminal_And_Reset_CursorPos();

	CWindowsConsoleScreenBuffer WinConsole;
	WinConsole.Initialize(40, 30, false, BackgroundColor);

	Set_Title("Konane (ESC: Exit)");
	Set_ConsolePos(10, 10);

	WinConsole.Set_CursorVisibilityAndSize(FALSE);
	//WinConsole.Set_Font(L"Consolas", 15, 15);
	//WinConsole.Set_Font(L"Consolas", 4, 4);
	//WinConsole.Set_Font(L"Consolas", 8, 8);
	WinConsole.Set_Font_Ext(L"Consolas", 90, 15, 15);


	//WinConsole.Set_BackgroundColor(RGB(100, 50, 25));
	WinConsole.Set_BackgroundColor(BackgroundColor);

	Set_CursorVisibilityAndSize(false);



	char strBuffer[100];

	bool leftMouseButtonClick = false;
	bool middleMouseButtonClick = false; // undo move
	bool rightMouseButtonClick = false;

	float FrameTime = 1.0f;
	float FrameRate = 1.0f;

	int32_t GameBoardPosX_Left = 2;
	int32_t GameBoardPosY_Top = 5;

	int32_t HumanPlayerMoveCompleteButtonPosX = 12;
	int32_t HumanPlayerMoveCompleteButtonPosY = 5;

	CWindowsConsole2DObject GameBoard;
	GameBoard.Initialize(ConstGameBoardSizePerDir, ConstGameBoardSizePerDir);


	CGameStateRingBuffer GameStateRingBuffer;
	GameStateRingBuffer.Initialize(100, ConstGameBoardSizePerDir, ConstGameBoardSizePerDir);



	int8_t* pActualGameStateData = nullptr;
	GameStateRingBuffer.Get_ActualBufferElement(&pActualGameStateData);

	Init_GameBoard(pActualGameStateData, &InitialKonaneBoards, InitialBoardID, ConstGameBoardSize);


	int32_t Player1Score = 0;
	int32_t Player2Score = 0;


	int32_t firstSelectedPosX_HumanPlayer = -1;
	int32_t firstSelectedPosY_HumanPlayer = -1;

	int32_t secondSelectedPosX_HumanPlayer = -1;
	int32_t secondSelectedPosY_HumanPlayer = -1;

	int32_t firstSelectedPosX_AIPlayer = -1;
	int32_t firstSelectedPosY_AIPlayer = -1;

	int32_t secondSelectedPosX_AIPlayer = -1;
	int32_t secondSelectedPosY_AIPlayer = -1;


	bool StartNewGame = false;
	bool GameFinished = false;

	bool HumanPlayerMoveFinishedButtonClicked = false;
	bool HumanPlayerMoveFinished = false;

	int32_t MovementCounter = 0;

	bool Player1IsWinner = false;
	bool Player2IsWinner = false;

#pragma omp parallel num_threads(2)
	{
		do
		{
			if (KEYDOWN(VK_ESCAPE) == true)
				break;

			if (KEYDOWN(VK_F1) == true && StartNewGame == false)
			{
				StartNewGame = true;
				HumanPlayer = 1;
			}
			if (KEYDOWN(VK_F2) == true && StartNewGame == false)
			{
				StartNewGame = true;
				HumanPlayer = 2;
			}

			int32_t threadID = omp_get_thread_num();

			if (threadID == 1)
			{
				InputHandling.Check_For_Input();
			}
			else if (threadID == 0) // master thread
			{
				if (StartNewGame == true)
				{
					Player1IsWinner = false;
					Player2IsWinner = false;

					HumanPlayerMoveFinished = false;

					firstSelectedPosX_HumanPlayer = -1;
					firstSelectedPosY_HumanPlayer = -1;

					secondSelectedPosX_HumanPlayer = -1;
					secondSelectedPosY_HumanPlayer = -1;

					Player1Score = 0;
					Player2Score = 0;

					GameStateRingBuffer.Reset_ActualBufferElement();
					int8_t* pGameStateData = nullptr;
					GameStateRingBuffer.Get_ActualBufferElement(&pGameStateData);
					Init_GameBoard(pActualGameStateData, &InitialKonaneBoards, InitialBoardID, ConstGameBoardSize);

					MovementCounter = 0;
					GameFinished = false;

					StartNewGame = false;
				}
				else if (StartNewGame == false)
				{
					//auto last_timepoint = std::chrono::steady_clock::now();
					auto last_timepoint = steady_clock::now();




					if (InputHandling.LeftMouseButtonPressed == true)
					{
						if (leftMouseButtonClick == false)
							leftMouseButtonClick = true;
						else
							leftMouseButtonClick = false;
					}

					if (InputHandling.MiddleMouseButtonPressed == true)
					{
						if (middleMouseButtonClick == false)
							middleMouseButtonClick = true;
						else
							middleMouseButtonClick = false;
					}

					if (InputHandling.RightMouseButtonPressed == true)
					{
						if (rightMouseButtonClick == false)
							rightMouseButtonClick = true;
						else
							rightMouseButtonClick = false;
					}

					InputHandling.Reset_MouseButtons();

					int32_t mousePosX = InputHandling.MousePosX;
					int32_t mousePosY = InputHandling.MousePosY;

					int32_t relativeMousePosX = mousePosX - GameBoardPosX_Left;
					int32_t relativeMousePosY = mousePosY - GameBoardPosY_Top;


					if (middleMouseButtonClick == true)
					{
						firstSelectedPosX_HumanPlayer = -1;
						firstSelectedPosY_HumanPlayer = -1;

						secondSelectedPosX_HumanPlayer = -1;
						secondSelectedPosY_HumanPlayer = -1;
					}

					if (rightMouseButtonClick == true && MovementCounter > 1 && GameFinished == false && HumanPlayerMoveFinished == false)
					{
						GameStateRingBuffer.Decrease_ActualBufferElement();
						MovementCounter--;
						GameStateRingBuffer.Decrease_ActualBufferElement();
						MovementCounter--;

						GameStateRingBuffer.Get_ActualBufferElement(&pActualGameStateData);
					}


					GameStateRingBuffer.Get_ActualBufferElement(&pActualGameStateData);
					Update_KonaneGameBoardGraphics(&GameBoard, pActualGameStateData);

					if (GameFinished == false)
					{
						if (Check_PossibleKonanePlayer1Moves(pActualGameStateData) == false)
						{
							//Add_To_Log(0, "check_PossibleKonanePlayer1Moves(pActualGameStateData) == false");
							Player2IsWinner = true;
							GameFinished = true;
						}
						else if (Check_PossibleKonanePlayer2Moves(pActualGameStateData) == false)
						{
							//Add_To_Log(0, "Check_PossibleKonanePlayer2Moves(pActualGameStateData) == false");
							Player1IsWinner = true;
							GameFinished = true;
						}
					}

					if (GameFinished == true)
					{
						goto MovesCompleted;
					}

					


					// Player 1:
					if (MovementCounter % 2 == 0 && GameFinished == false)
					{
						if (Check_PossibleKonanePlayer1Moves(pActualGameStateData) == false)
						{
							Player2IsWinner = true;
							GameFinished = true;
							goto MovesCompleted;
						}

						// Human Player Move:
						if (HumanPlayer == 1)
						{

							if (relativeMousePosX > -1 && relativeMousePosX < ConstGameBoardSizePerDir)
							{
								if (relativeMousePosY > -1 && relativeMousePosY < ConstGameBoardSizePerDir)
								{

									if (firstSelectedPosX_HumanPlayer > -1 && firstSelectedPosY_HumanPlayer > -1)
									{
										GameBoard.Set_Pixel(relativeMousePosX, relativeMousePosY, lightyello);
									}
									else
									{
										GameBoard.Set_Pixel(relativeMousePosX, relativeMousePosY, yello);
									}

									if (leftMouseButtonClick == true)
									{
										if (firstSelectedPosX_HumanPlayer < 0)
										{
											int32_t id = relativeMousePosX + ConstGameBoardSizePerDir * relativeMousePosY;

											if (pActualGameStateData[id] == ConstGameBoard_Player1)
											{
												firstSelectedPosX_HumanPlayer = relativeMousePosX;
												firstSelectedPosY_HumanPlayer = relativeMousePosY;
											}
										}
										else if (firstSelectedPosX_HumanPlayer > -1)
										{
											secondSelectedPosX_HumanPlayer = relativeMousePosX;
											secondSelectedPosY_HumanPlayer = relativeMousePosY;
										}
									} // end of if (leftMouseButtonClick == true)
								} // end of if (relativeMousePosY > -1 && relativeMousePosY < ConstGameBoardSizePerDir)
							}  // end of if (relativeMousePosX > -1 && relativeMousePosX < ConstGameBoardSizePerDir)

							if (firstSelectedPosX_HumanPlayer > -1 && secondSelectedPosX_HumanPlayer > -1)
							{
								int32_t numOfPossiblePlayerMoves = Player1MoveList.NumOfMoves;

								int32_t firstSelectedPosID = firstSelectedPosX_HumanPlayer + ConstGameBoardSizePerDir * firstSelectedPosY_HumanPlayer;
								int32_t secondSelectedPosID = secondSelectedPosX_HumanPlayer + ConstGameBoardSizePerDir * secondSelectedPosY_HumanPlayer;

								bool possibleMove = false;
								int32_t idOfSelectedMove = 0;

								for (int32_t moveID = 0; moveID < numOfPossiblePlayerMoves; moveID++)
								{
									possibleMove = Player1MoveList.Validate_PossibleMove(moveID, firstSelectedPosX_HumanPlayer, firstSelectedPosY_HumanPlayer, firstSelectedPosID, secondSelectedPosID, pActualGameStateData);

									if (possibleMove == true)
									{
										idOfSelectedMove = moveID;
										break;
									}
								} // end of for (int32_t moveID = 0; moveID < numOfPossiblePlayerMoves; moveID++)

								if (possibleMove == false)
								{
									firstSelectedPosX_HumanPlayer = -1;
									firstSelectedPosY_HumanPlayer = -1;

									secondSelectedPosX_HumanPlayer = -1;
									secondSelectedPosY_HumanPlayer = -1;
								}
								else if (possibleMove == true)
								{
									if (HumanPlayerMoveFinished == false)
									{
										GameStateRingBuffer.Increase_ActualBufferElement();
										GameStateRingBuffer.Get_ActualBufferElement(&pActualGameStateData);
									}

									//Player1MoveList.Make_Move_If_Possible(idOfSelectedMove, firstSelectedPosX_HumanPlayer, firstSelectedPosY_HumanPlayer, firstSelectedPosID, secondSelectedPosID, pActualGameStateData);
									Player1MoveList.Make_Move(idOfSelectedMove, firstSelectedPosX_HumanPlayer, firstSelectedPosY_HumanPlayer, firstSelectedPosID, pActualGameStateData);


									Update_KonaneGameBoardGraphics(&GameBoard, pActualGameStateData);

									HumanPlayerMoveFinished = true;

									//MovementCounter++;

									firstSelectedPosX_HumanPlayer = -1;
									firstSelectedPosY_HumanPlayer = -1;

									secondSelectedPosX_HumanPlayer = -1;
									secondSelectedPosY_HumanPlayer = -1;

								} // end of else if (possibleMove == true)

							} // end of if (firstSelectedPosX_HumanPlayer > -1 && secondSelectedPosX_HumanPlayer > -1)


						}  // if (HumanPlayer == 1)

						 // AI Player Move:
						else if (HumanPlayer == 2)
						{
							GameStateRingBuffer.Increase_ActualBufferElement();

							GameStateRingBuffer.Get_ActualBufferElement(&pActualGameStateObject);

							OldGameState.Clone_GameStateValues(pActualGameStateData);


							if (AIType == 0)
							{
								KonaneDepthFirstSearchAI.Execute_Player1AI(pActualGameStateObject, &OldGameState);
							}
							else if (AIType == 1)
							{
								KonaneBreadthFirstSearchAI.Execute_Player1AI(pActualGameStateObject, &OldGameState);
							}
							else
							{
								KonaneBreadthFirstSearchAI.Execute_Player1AI(pActualGameStateObject, &OldGameState, SearchDepthMovementProbabilityArray);
							}


							GameStateRingBuffer.Get_ActualBufferElement(&pActualGameStateData);
							Update_KonaneGameBoardGraphics(&GameBoard, pActualGameStateData);

							//GameStateRingBuffer.Get_ActualBufferElement(&pActualGameStateData);
							//Random_Player1(pActualGameStateData, &RandomNumbers);
							MovementCounter++;
						} // end of else if (HumanPlayer == 2)

					}
					// Player 2:
					else if (MovementCounter % 2 == 1 && GameFinished == false)
					{
						if (Check_PossibleKonanePlayer2Moves(pActualGameStateData) == false)
						{
							Player1IsWinner = true;
							GameFinished = true;
							goto MovesCompleted;
						}

						// AI Player Move:
						if (HumanPlayer == 1)
						{
							GameStateRingBuffer.Increase_ActualBufferElement();

							GameStateRingBuffer.Get_ActualBufferElement(&pActualGameStateObject);

							OldGameState.Clone_GameStateValues(pActualGameStateData);


							if (AIType == 0)
							{
								KonaneDepthFirstSearchAI.Execute_Player2AI(pActualGameStateObject, &OldGameState);
							}
							else if (AIType == 1)
							{
								KonaneBreadthFirstSearchAI.Execute_Player2AI(pActualGameStateObject, &OldGameState);
							}
							else
							{
								KonaneBreadthFirstSearchAI.Execute_Player2AI(pActualGameStateObject, &OldGameState, SearchDepthMovementProbabilityArray);
							}


							GameStateRingBuffer.Get_ActualBufferElement(&pActualGameStateData);
							Update_KonaneGameBoardGraphics(&GameBoard, pActualGameStateData);

							//GameStateRingBuffer.Get_ActualBufferElement(&pActualGameStateData);
							//Random_Player2(pActualGameStateData, &RandomNumbers);
							MovementCounter++;
						} // end of if (HumanPlayer == 2)

						// Human Player Move:
						else if (HumanPlayer == 2)
						{
							if (relativeMousePosX > -1 && relativeMousePosX < ConstGameBoardSizePerDir)
							{
								if (relativeMousePosY > -1 && relativeMousePosY < ConstGameBoardSizePerDir)
								{

									if (firstSelectedPosX_HumanPlayer > -1 && firstSelectedPosY_HumanPlayer > -1)
									{
										GameBoard.Set_Pixel(relativeMousePosX, relativeMousePosY, lightyello);
									}
									else
									{
										GameBoard.Set_Pixel(relativeMousePosX, relativeMousePosY, yello);
									}


									if (leftMouseButtonClick == true)
									{
										if (firstSelectedPosX_HumanPlayer < 0)
										{
											int32_t id = relativeMousePosX + ConstGameBoardSizePerDir * relativeMousePosY;

											if (pActualGameStateData[id] == ConstGameBoard_Player2)
											{
												firstSelectedPosX_HumanPlayer = relativeMousePosX;
												firstSelectedPosY_HumanPlayer = relativeMousePosY;
											}
										}
										else if (firstSelectedPosX_HumanPlayer > -1)
										{
											secondSelectedPosX_HumanPlayer = relativeMousePosX;
											secondSelectedPosY_HumanPlayer = relativeMousePosY;
										}
									} // end of if (leftMouseButtonClick == true)
								} // end of if (relativeMousePosY > -1 && relativeMousePosY < ConstGameBoardSizePerDir)
							}  // end of if (relativeMousePosX > -1 && relativeMousePosX < ConstGameBoardSizePerDir)

							if (firstSelectedPosX_HumanPlayer > -1 && secondSelectedPosX_HumanPlayer > -1)
							{
								int32_t numOfPossiblePlayerMoves = Player2MoveList.NumOfMoves;

								int32_t firstSelectedPosID = firstSelectedPosX_HumanPlayer + ConstGameBoardSizePerDir * firstSelectedPosY_HumanPlayer;
								int32_t secondSelectedPosID = secondSelectedPosX_HumanPlayer + ConstGameBoardSizePerDir * secondSelectedPosY_HumanPlayer;

								bool possibleMove = false;
								int32_t idOfSelectedMove = 0;

								for (int32_t moveID = 0; moveID < numOfPossiblePlayerMoves; moveID++)
								{
									possibleMove = Player2MoveList.Validate_PossibleMove(moveID, firstSelectedPosX_HumanPlayer, firstSelectedPosY_HumanPlayer, firstSelectedPosID, secondSelectedPosID, pActualGameStateData);

									if (possibleMove == true)
									{
										idOfSelectedMove = moveID;
										break;
									}
								} // end of for (int32_t moveID = 0; moveID < numOfPossiblePlayerMoves; moveID++)

								if (possibleMove == false)
								{
									firstSelectedPosX_HumanPlayer = -1;
									firstSelectedPosY_HumanPlayer = -1;

									secondSelectedPosX_HumanPlayer = -1;
									secondSelectedPosY_HumanPlayer = -1;
								}
								else if (possibleMove == true)
								{
									if (HumanPlayerMoveFinished == false)
									{
										GameStateRingBuffer.Increase_ActualBufferElement();
										GameStateRingBuffer.Get_ActualBufferElement(&pActualGameStateData);
									}

									//Player2MoveList.Make_Move_If_Possible(idOfSelectedMove, firstSelectedPosX_HumanPlayer, firstSelectedPosY_HumanPlayer, firstSelectedPosID, secondSelectedPosID, pActualGameStateData);
									Player2MoveList.Make_Move(idOfSelectedMove, firstSelectedPosX_HumanPlayer, firstSelectedPosY_HumanPlayer, firstSelectedPosID, pActualGameStateData);


									Update_KonaneGameBoardGraphics(&GameBoard, pActualGameStateData);

									HumanPlayerMoveFinished = true;

									//MovementCounter++;

									firstSelectedPosX_HumanPlayer = -1;
									firstSelectedPosY_HumanPlayer = -1;

									secondSelectedPosX_HumanPlayer = -1;
									secondSelectedPosY_HumanPlayer = -1;

								} // end of else if (possibleMove == true)
							} // end of if (firstSelectedPosX_HumanPlayer > -1 && secondSelectedPosX_HumanPlayer > -1)
						}  // else if (HumanPlayer == 2)
					}


				MovesCompleted:;


					HumanPlayerMoveFinishedButtonClicked = false;

					bool HumanPlayerMoveFinishedButtonSelected = false;

					if (mousePosX == HumanPlayerMoveCompleteButtonPosX)
					{
						if (mousePosY == HumanPlayerMoveCompleteButtonPosY)
						{
							HumanPlayerMoveFinishedButtonSelected = true;
						}
					}

					if (HumanPlayerMoveFinished == true)
					{
						if (HumanPlayerMoveFinishedButtonSelected == true)
						{
							if ((MovementCounter % 2 == 0 && HumanPlayer == 1) || (MovementCounter % 2 == 1 && HumanPlayer == 2))
							{

								if (leftMouseButtonClick == true)
								{
									HumanPlayerMoveFinished = false;
									HumanPlayerMoveFinishedButtonClicked = true;
									MovementCounter++;
								}
							}
						}
					}

					leftMouseButtonClick = false;
					rightMouseButtonClick = false;
					middleMouseButtonClick = false;

					Calculate_KonaneScore(&Player1Score, &Player2Score, pActualGameStateData);

					//if (Player1Score == 0 || Player2Score == 0)
					//{
						//GameFinished = true;
					//}
					if (Player1Score > 0 && Player2Score == 0)
					{
						Player1IsWinner = true;
						GameFinished = true;
					}
					else if (Player1Score == 0 && Player2Score > 0)
					{
						Player2IsWinner = true;
						GameFinished = true;
					}
					else if (Player1Score == 0 && Player2Score == 0)
					{
						GameFinished = true;
					}

					WinConsole.Clear_BackBuffer();

					WinConsole.Draw_2DObject_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top, GameBoard.pDataArray, GameBoard.NumCharactersPerRow, GameBoard.NumCharactersPerColumn);

					if (GameFinished == false)
					{
						if ((MovementCounter % 2 == 0 && HumanPlayer == 1) || (MovementCounter % 2 == 1 && HumanPlayer == 2))
						{
							if (HumanPlayerMoveFinishedButtonSelected == true)
								WinConsole.Write_Pixel_Into_BackBuffer(HumanPlayerMoveCompleteButtonPosX, HumanPlayerMoveCompleteButtonPosY, lightyello);
							else
								WinConsole.Write_Pixel_Into_BackBuffer(HumanPlayerMoveCompleteButtonPosX, HumanPlayerMoveCompleteButtonPosY, graywhite);


							sprintf(strBuffer, "click to finish move");
							WinConsole.Write_String_Into_BackBuffer(HumanPlayerMoveCompleteButtonPosX + 2, HumanPlayerMoveCompleteButtonPosY, strBuffer, lightaqua, black);

							sprintf(strBuffer, "(left mButton)");
							WinConsole.Write_String_Into_BackBuffer(HumanPlayerMoveCompleteButtonPosX + 2, HumanPlayerMoveCompleteButtonPosY + 1, strBuffer, lightaqua, black);
						}
					}

					sprintf(strBuffer, "move counter: %03d", MovementCounter);
					WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 12, strBuffer, lightaqua, black);

					sprintf(strBuffer, "score (player1/player2): %03d/%03d", Player1Score, Player2Score);
					WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 13, strBuffer, lightaqua, black);

					sprintf(strBuffer, "F1/F2: new game (player1/player2)");
					WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 15, strBuffer, lightaqua, black);

					if (GameFinished == true)
					{
						sprintf(strBuffer, "Game Finished");
						WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left + ConstGameBoardSizePerDir + 2, GameBoardPosY_Top, strBuffer, lightyello, black);

						if (Player1IsWinner == true)
						{
							sprintf(strBuffer, "Winner: Player1");
							WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left + ConstGameBoardSizePerDir + 2, GameBoardPosY_Top + 1, strBuffer, lightgreen, black);
						}
						else if (Player2IsWinner == true)
						{
							sprintf(strBuffer, "Winner: Player2");
							WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left + ConstGameBoardSizePerDir + 2, GameBoardPosY_Top + 1, strBuffer, lightred, black);
						}
					}

					if (HumanPlayer == 1)
					{
						sprintf(strBuffer, "Player1 (Human): green");
						WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, 1, strBuffer, lightgreen, black);
					}
					else if (HumanPlayer == 2)
					{
						sprintf(strBuffer, "Player2 (Human): red");
						WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, 1, strBuffer, lightred, black);
					}

					if (GameFinished == false)
					{
						if ((MovementCounter % 2 == 0 && HumanPlayer == 1) || (MovementCounter % 2 == 1 && HumanPlayer == 2))
						{
							if (firstSelectedPosX_HumanPlayer < 0)
							{
								sprintf(strBuffer, "left mButton: select player piece");
								WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 17, strBuffer, lightaqua, black);
							}
							else if (firstSelectedPosX_HumanPlayer > -1)
							{
								sprintf(strBuffer, "left mButton: select new pos");
								WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 17, strBuffer, lightaqua, black);
							}
						}
						else
						{
							sprintf(strBuffer, "AI is thinking ...");
							WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 17, strBuffer, lightyello, black);
						}
					}

					sprintf(strBuffer, "right mButton: undo move");
					WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 19, strBuffer, lightaqua, black);
					sprintf(strBuffer, "middle mButton: abort move");
					WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 21, strBuffer, lightaqua, black);


					WinConsole.Present_BackBuffer();

					//Frame-Bremse:

					auto current_timepoint = steady_clock::now();

					//while (current_timepoint - last_timepoint < 250ms)
					//while (current_timepoint - last_timepoint < 50ms)
					while (current_timepoint - last_timepoint < 16ms)
						//while (current_timepoint - last_timepoint < 16666us) // 16.7 Millisekunden (ms)  bzw. 16666 Mikrosekunden (us): maximal 60 Frames pro Sekunde					
					{
						current_timepoint = steady_clock::now();
					}

					FrameTime = 0.000000001f * (current_timepoint - last_timepoint).count();
					FrameRate = 1.0f / FrameTime;
				} //else if (StartNewGame == false)
			} // end of else if (threadID == 0) // master thread

		} while (true);
	} // end of #pragma omp parallel num_threads(2)

	InputHandling.CleanUp();
	WinConsole.Clear_BackBuffer();
	WinConsole.Present_BackBuffer();
	WinConsole.CleanUp();

	Set_CursorVisibilityAndSize(true);
	Reset_CursorPos();
	Set_CursorPos(0, 0);

	cout << "bye bye (Press Return)" << endl;

	//getchar();

	return 0;
}
*/

/*
int main(void)
{
	//Set_ProcessPriority(2);

	Begin_Log(0, "start AI_Log",
		"AI_Log.txt");

	Set_Title("Checkers-Konane (ESC: Exit)");
	Set_ConsolePos(10, 10);

	CInitialGameBoards InitialKonaneBoards;
	InitialKonaneBoards.Initialize("InitialCheckersKonaneBoards.txt", ConstGameBoardSizePerDir, ConstGameBoardSizePerDir);

	CMovePatternList Player1MoveList;
	Player1MoveList.Initialize("CheckersKonanePlayer1MovesList.txt");

	CMovePatternList Player2MoveList;
	Player2MoveList.Initialize("CheckersKonanePlayer2MovesList.txt");


	CGameStateValues OldGameState;
	OldGameState.Initialize(ConstGameBoardSizePerDir, ConstGameBoardSizePerDir);

	CGameStateValues* pActualGameStateObject = nullptr;

	char inputBuffer[100];
	int32_t RecalculatePlacementStrategies = 0;

	cout << "Player Nr (1/2): ";

	cin.getline(inputBuffer, 100);

	int32_t HumanPlayer = 1;

	if (atoi(inputBuffer) != 1)
	{
		HumanPlayer = 2;
	}

	sprintf(inputBuffer, "InitialBoardID (0-%d): ", InitialKonaneBoards.NumOfInitialBoards - 1);
	cout << inputBuffer;

	cin.getline(inputBuffer, 100);
	int32_t InitialBoardID = min(InitialKonaneBoards.NumOfInitialBoards - 1, max(0, atoi(inputBuffer)));

	int32_t NumTestGameStatesMax = 20000;
	int32_t NumTestGameStatesMaxPerDepthLayer = 20000;

	cout << "AI-Type (0 / 1 / 2): ";

	int32_t AIType = 0;

	cin.getline(inputBuffer, 100);
	AIType = atoi(inputBuffer);

	cout << "MaxSearchDepth (2, 3, ...): ";

	cin.getline(inputBuffer, 100);
	int32_t MaxSearchDepth = atoi(inputBuffer);
	MaxSearchDepth = max(2, MaxSearchDepth);


	CKonaneBreadthFirstSearchAI KonaneBreadthFirstSearchAI;
	CKonaneDepthFirstSearchAI KonaneDepthFirstSearchAI;

	if (AIType == 0)
	{
		KonaneDepthFirstSearchAI.Initialize(&Player1MoveList, &Player2MoveList, 100000, MaxSearchDepth);
		KonaneDepthFirstSearchAI.Prepare_CheckersKonaneGame();
	}


	static float SearchDepthMovementProbabilityArray[10];

	if (AIType == 1)
	{
		cout << "NumTestGameStatesMax (try 100000 perDepthLayer): ";
		cin.getline(inputBuffer, 100);
		NumTestGameStatesMax = atoi(inputBuffer);

		cout << "NumTestGameStatesMaxPerDepthLayer: ";
		cin.getline(inputBuffer, 100);
		NumTestGameStatesMaxPerDepthLayer = atoi(inputBuffer);

		KonaneBreadthFirstSearchAI.Initialize(&Player1MoveList, &Player2MoveList, NumTestGameStatesMax, NumTestGameStatesMaxPerDepthLayer, MaxSearchDepth);
		KonaneBreadthFirstSearchAI.Prepare_CheckersKonaneGame();
	}
	else if (AIType > 1)
	{
		cout << "NumTestGameStatesMax (try 100000 perDepthLayer): ";
		cin.getline(inputBuffer, 100);
		NumTestGameStatesMax = atoi(inputBuffer);

		cout << "NumTestGameStatesMaxPerDepthLayer: ";
		cin.getline(inputBuffer, 100);
		NumTestGameStatesMaxPerDepthLayer = atoi(inputBuffer);

		for (int32_t i = 0; i < MaxSearchDepth; i++)
		{
			cout << "movementProbability_SearchDepth" << i + 1 << " (0-1): ";
			cin.getline(inputBuffer, 100);
			SearchDepthMovementProbabilityArray[i] = max(0.0f, atof(inputBuffer));
			SearchDepthMovementProbabilityArray[i] = min(SearchDepthMovementProbabilityArray[i], 1.0f);
		}

		KonaneBreadthFirstSearchAI.Initialize(&Player1MoveList, &Player2MoveList, NumTestGameStatesMax, NumTestGameStatesMaxPerDepthLayer, MaxSearchDepth);
		KonaneBreadthFirstSearchAI.Prepare_CheckersKonaneGame();
	}


	int32_t RandomSeed = 1;

	cout << "RandomSeed (> 0): ";

	cin.getline(inputBuffer, 100);
	RandomSeed = atoi(inputBuffer);
	RandomSeed = max(1, RandomSeed);

	KonaneBreadthFirstSearchAI.Change_Seed(RandomSeed);

	CInputHandling InputHandling;
	InputHandling.Initialize();

	Clear_Terminal_And_Reset_CursorPos();

	CWindowsConsoleScreenBuffer WinConsole;
	WinConsole.Initialize(40, 30, false, BackgroundColor);

	Set_Title("Checkers-Konane (ESC: Exit)");
	Set_ConsolePos(10, 10);

	WinConsole.Set_CursorVisibilityAndSize(FALSE);
	//WinConsole.Set_Font(L"Consolas", 15, 15);
	//WinConsole.Set_Font(L"Consolas", 4, 4);
	//WinConsole.Set_Font(L"Consolas", 8, 8);
	WinConsole.Set_Font_Ext(L"Consolas", 90, 15, 15);


	//WinConsole.Set_BackgroundColor(RGB(100, 50, 25));
	WinConsole.Set_BackgroundColor(BackgroundColor);

	Set_CursorVisibilityAndSize(false);



	char strBuffer[100];

	bool leftMouseButtonClick = false;
	bool middleMouseButtonClick = false; // undo move
	bool rightMouseButtonClick = false;

	float FrameTime = 1.0f;
	float FrameRate = 1.0f;

	int32_t GameBoardPosX_Left = 2;
	int32_t GameBoardPosY_Top = 5;

	int32_t HumanPlayerMoveCompleteButtonPosX = 12;
	int32_t HumanPlayerMoveCompleteButtonPosY = 5;

	CWindowsConsole2DObject GameBoard;
	GameBoard.Initialize(ConstGameBoardSizePerDir, ConstGameBoardSizePerDir);


	CGameStateRingBuffer GameStateRingBuffer;
	GameStateRingBuffer.Initialize(100, ConstGameBoardSizePerDir, ConstGameBoardSizePerDir);



	int8_t* pActualGameStateData = nullptr;
	GameStateRingBuffer.Get_ActualBufferElement(&pActualGameStateData);

	Init_GameBoard(pActualGameStateData, &InitialKonaneBoards, InitialBoardID, ConstGameBoardSize);


	int32_t Player1Score = 0;
	int32_t Player2Score = 0;


	int32_t firstSelectedPosX_HumanPlayer = -1;
	int32_t firstSelectedPosY_HumanPlayer = -1;

	int32_t secondSelectedPosX_HumanPlayer = -1;
	int32_t secondSelectedPosY_HumanPlayer = -1;

	int32_t firstSelectedPosX_AIPlayer = -1;
	int32_t firstSelectedPosY_AIPlayer = -1;

	int32_t secondSelectedPosX_AIPlayer = -1;
	int32_t secondSelectedPosY_AIPlayer = -1;


	bool StartNewGame = false;
	bool GameFinished = false;

	bool HumanPlayerMoveFinishedButtonClicked = false;
	bool HumanPlayerMoveFinished = false;

	int32_t MovementCounter = 0;

	bool Player1IsWinner = false;
	bool Player2IsWinner = false;

#pragma omp parallel num_threads(2)
	{
		do
		{
			if (KEYDOWN(VK_ESCAPE) == true)
				break;

			if (KEYDOWN(VK_F1) == true && StartNewGame == false)
			{
				StartNewGame = true;
				HumanPlayer = 1;
			}
			if (KEYDOWN(VK_F2) == true && StartNewGame == false)
			{
				StartNewGame = true;
				HumanPlayer = 2;
			}

			int32_t threadID = omp_get_thread_num();

			if (threadID == 1)
			{
				InputHandling.Check_For_Input();
			}
			else if (threadID == 0) // master thread
			{
				if (StartNewGame == true)
				{
					Player1IsWinner = false;
					Player2IsWinner = false;

					HumanPlayerMoveFinished = false;

					firstSelectedPosX_HumanPlayer = -1;
					firstSelectedPosY_HumanPlayer = -1;

					secondSelectedPosX_HumanPlayer = -1;
					secondSelectedPosY_HumanPlayer = -1;

					Player1Score = 0;
					Player2Score = 0;

					GameStateRingBuffer.Reset_ActualBufferElement();
					int8_t* pGameStateData = nullptr;
					GameStateRingBuffer.Get_ActualBufferElement(&pGameStateData);
					Init_GameBoard(pActualGameStateData, &InitialKonaneBoards, InitialBoardID, ConstGameBoardSize);

					MovementCounter = 0;
					GameFinished = false;

					StartNewGame = false;
				}
				else if (StartNewGame == false)
				{
					//auto last_timepoint = std::chrono::steady_clock::now();
					auto last_timepoint = steady_clock::now();




					if (InputHandling.LeftMouseButtonPressed == true)
					{
						if (leftMouseButtonClick == false)
							leftMouseButtonClick = true;
						else
							leftMouseButtonClick = false;
					}

					if (InputHandling.MiddleMouseButtonPressed == true)
					{
						if (middleMouseButtonClick == false)
							middleMouseButtonClick = true;
						else
							middleMouseButtonClick = false;
					}

					if (InputHandling.RightMouseButtonPressed == true)
					{
						if (rightMouseButtonClick == false)
							rightMouseButtonClick = true;
						else
							rightMouseButtonClick = false;
					}

					InputHandling.Reset_MouseButtons();

					int32_t mousePosX = InputHandling.MousePosX;
					int32_t mousePosY = InputHandling.MousePosY;

					int32_t relativeMousePosX = mousePosX - GameBoardPosX_Left;
					int32_t relativeMousePosY = mousePosY - GameBoardPosY_Top;


					if (middleMouseButtonClick == true)
					{
						firstSelectedPosX_HumanPlayer = -1;
						firstSelectedPosY_HumanPlayer = -1;

						secondSelectedPosX_HumanPlayer = -1;
						secondSelectedPosY_HumanPlayer = -1;
					}

					if (rightMouseButtonClick == true && MovementCounter > 1 && GameFinished == false && HumanPlayerMoveFinished == false)
					{
						GameStateRingBuffer.Decrease_ActualBufferElement();
						MovementCounter--;
						GameStateRingBuffer.Decrease_ActualBufferElement();
						MovementCounter--;

						GameStateRingBuffer.Get_ActualBufferElement(&pActualGameStateData);
					}


					GameStateRingBuffer.Get_ActualBufferElement(&pActualGameStateData);
					Update_CheckersKonaneGameBoardGraphics(&GameBoard, pActualGameStateData);

					if (GameFinished == false)
					{
						if (Check_PossibleCheckersKonanePlayer1Moves(pActualGameStateData, &Player1MoveList) == false)
						{
							//Add_To_Log(0, "check_PossibleKonanePlayer1Moves(pActualGameStateData) == false");
							Player2IsWinner = true;
							GameFinished = true;
						}
						else if (Check_PossibleCheckersKonanePlayer2Moves(pActualGameStateData, &Player2MoveList) == false)
						{
							//Add_To_Log(0, "Check_PossibleKonanePlayer2Moves(pActualGameStateData) == false");
							Player1IsWinner = true;
							GameFinished = true;
						}
					}

					if (GameFinished == true)
					{
						goto MovesCompleted;
					}




					// Player 1:
					if (MovementCounter % 2 == 0 && GameFinished == false)
					{
						if (Check_PossibleCheckersKonanePlayer1Moves(pActualGameStateData, &Player1MoveList) == false)
						{
							Player2IsWinner = true;
							GameFinished = true;
							goto MovesCompleted;
						}

						// Human Player Move:
						if (HumanPlayer == 1)
						{

							if (relativeMousePosX > -1 && relativeMousePosX < ConstGameBoardSizePerDir)
							{
								if (relativeMousePosY > -1 && relativeMousePosY < ConstGameBoardSizePerDir)
								{

									if (firstSelectedPosX_HumanPlayer > -1 && firstSelectedPosY_HumanPlayer > -1)
									{
										GameBoard.Set_Pixel(relativeMousePosX, relativeMousePosY, lightyello);
									}
									else
									{
										GameBoard.Set_Pixel(relativeMousePosX, relativeMousePosY, yello);
									}

									if (leftMouseButtonClick == true)
									{
										if (firstSelectedPosX_HumanPlayer < 0)
										{
											int32_t id = relativeMousePosX + ConstGameBoardSizePerDir * relativeMousePosY;

											int8_t value = pActualGameStateData[id];
											if (value == ConstGameBoard_Player1_Man || value == ConstGameBoard_Player1_King)
											{
												firstSelectedPosX_HumanPlayer = relativeMousePosX;
												firstSelectedPosY_HumanPlayer = relativeMousePosY;
											}
										}
										else if (firstSelectedPosX_HumanPlayer > -1)
										{
											secondSelectedPosX_HumanPlayer = relativeMousePosX;
											secondSelectedPosY_HumanPlayer = relativeMousePosY;
										}
									} // end of if (leftMouseButtonClick == true)
								} // end of if (relativeMousePosY > -1 && relativeMousePosY < ConstGameBoardSizePerDir)
							}  // end of if (relativeMousePosX > -1 && relativeMousePosX < ConstGameBoardSizePerDir)

							if (firstSelectedPosX_HumanPlayer > -1 && secondSelectedPosX_HumanPlayer > -1)
							{
								int32_t numOfPossiblePlayerMoves = Player1MoveList.NumOfMoves;

								int32_t firstSelectedPosID = firstSelectedPosX_HumanPlayer + ConstGameBoardSizePerDir * firstSelectedPosY_HumanPlayer;
								int32_t secondSelectedPosID = secondSelectedPosX_HumanPlayer + ConstGameBoardSizePerDir * secondSelectedPosY_HumanPlayer;

						
								bool possibleMove = false;
								int32_t idOfSelectedMove = 0;

								for (int32_t moveID = 0; moveID < numOfPossiblePlayerMoves; moveID++)
								{
									possibleMove = Player1MoveList.Validate_PossibleMove(moveID, firstSelectedPosX_HumanPlayer, firstSelectedPosY_HumanPlayer, firstSelectedPosID, secondSelectedPosID, pActualGameStateData);

									if (possibleMove == true)
									{
										idOfSelectedMove = moveID;
										break;
									}
								} // end of for (int32_t moveID = 0; moveID < numOfPossiblePlayerMoves; moveID++)

								

								if (possibleMove == false)
								{
									firstSelectedPosX_HumanPlayer = -1;
									firstSelectedPosY_HumanPlayer = -1;

									secondSelectedPosX_HumanPlayer = -1;
									secondSelectedPosY_HumanPlayer = -1;
								}
								else if (possibleMove == true)
								{
									if (HumanPlayerMoveFinished == false)
									{
										GameStateRingBuffer.Increase_ActualBufferElement();
										GameStateRingBuffer.Get_ActualBufferElement(&pActualGameStateData);
									}

									
									//Player1MoveList.Make_Move_If_Possible(idOfSelectedMove, firstSelectedPosX_HumanPlayer, firstSelectedPosY_HumanPlayer, firstSelectedPosID, secondSelectedPosID, pActualGameStateData);
									Player1MoveList.Make_Move(idOfSelectedMove, firstSelectedPosX_HumanPlayer, firstSelectedPosY_HumanPlayer, firstSelectedPosID, pActualGameStateData);


									Update_CheckersKonaneGameBoardGraphics(&GameBoard, pActualGameStateData);

									HumanPlayerMoveFinished = true;

									//MovementCounter++;

									firstSelectedPosX_HumanPlayer = -1;
									firstSelectedPosY_HumanPlayer = -1;

									secondSelectedPosX_HumanPlayer = -1;
									secondSelectedPosY_HumanPlayer = -1;

								} // end of else if (possibleMove == true)

							} // end of if (firstSelectedPosX_HumanPlayer > -1 && secondSelectedPosX_HumanPlayer > -1)


						}  // if (HumanPlayer == 1)

						 // AI Player Move:
						else if (HumanPlayer == 2)
						{
							GameStateRingBuffer.Increase_ActualBufferElement();

							GameStateRingBuffer.Get_ActualBufferElement(&pActualGameStateObject);

							OldGameState.Clone_GameStateValues(pActualGameStateData);


							if (AIType == 0)
							{
								KonaneDepthFirstSearchAI.Execute_Player1AI_CheckersKonane(pActualGameStateObject, &OldGameState);
							}
							else if (AIType == 1)
							{
								KonaneBreadthFirstSearchAI.Execute_Player1AI_CheckersKonane(pActualGameStateObject, &OldGameState);
							}
							else
							{
								KonaneBreadthFirstSearchAI.Execute_Player1AI_CheckersKonane(pActualGameStateObject, &OldGameState, SearchDepthMovementProbabilityArray);
							}


							GameStateRingBuffer.Get_ActualBufferElement(&pActualGameStateData);
							Update_CheckersKonaneGameBoardGraphics(&GameBoard, pActualGameStateData);

							//GameStateRingBuffer.Get_ActualBufferElement(&pActualGameStateData);
							//Random_Player1(pActualGameStateData, &RandomNumbers);
							MovementCounter++;
						} // end of else if (HumanPlayer == 2)

					}
					// Player 2:
					else if (MovementCounter % 2 == 1 && GameFinished == false)
					{
						if (Check_PossibleCheckersKonanePlayer2Moves(pActualGameStateData, &Player2MoveList) == false)
						{
							Player1IsWinner = true;
							GameFinished = true;
							goto MovesCompleted;
						}

						// AI Player Move:
						if (HumanPlayer == 1)
						{
							GameStateRingBuffer.Increase_ActualBufferElement();

							GameStateRingBuffer.Get_ActualBufferElement(&pActualGameStateObject);

							OldGameState.Clone_GameStateValues(pActualGameStateData);


							if (AIType == 0)
							{
								KonaneDepthFirstSearchAI.Execute_Player2AI_CheckersKonane(pActualGameStateObject, &OldGameState);
							}
							else if (AIType == 1)
							{
								KonaneBreadthFirstSearchAI.Execute_Player2AI_CheckersKonane(pActualGameStateObject, &OldGameState);
							}
							else
							{
								KonaneBreadthFirstSearchAI.Execute_Player2AI_CheckersKonane(pActualGameStateObject, &OldGameState, SearchDepthMovementProbabilityArray);
							}


							GameStateRingBuffer.Get_ActualBufferElement(&pActualGameStateData);
							Update_CheckersKonaneGameBoardGraphics(&GameBoard, pActualGameStateData);

							//GameStateRingBuffer.Get_ActualBufferElement(&pActualGameStateData);
							//Random_Player2(pActualGameStateData, &RandomNumbers);
							MovementCounter++;
						} // end of if (HumanPlayer == 2)

						// Human Player Move:
						else if (HumanPlayer == 2)
						{
							if (relativeMousePosX > -1 && relativeMousePosX < ConstGameBoardSizePerDir)
							{
								if (relativeMousePosY > -1 && relativeMousePosY < ConstGameBoardSizePerDir)
								{

									if (firstSelectedPosX_HumanPlayer > -1 && firstSelectedPosY_HumanPlayer > -1)
									{
										GameBoard.Set_Pixel(relativeMousePosX, relativeMousePosY, lightyello);
									}
									else
									{
										GameBoard.Set_Pixel(relativeMousePosX, relativeMousePosY, yello);
									}


									if (leftMouseButtonClick == true)
									{
										if (firstSelectedPosX_HumanPlayer < 0)
										{
											int32_t id = relativeMousePosX + ConstGameBoardSizePerDir * relativeMousePosY;

											int8_t value = pActualGameStateData[id];
											if (value == ConstGameBoard_Player2_Man || value == ConstGameBoard_Player2_King)
											{
												firstSelectedPosX_HumanPlayer = relativeMousePosX;
												firstSelectedPosY_HumanPlayer = relativeMousePosY;
											}
										}
										else if (firstSelectedPosX_HumanPlayer > -1)
										{
											secondSelectedPosX_HumanPlayer = relativeMousePosX;
											secondSelectedPosY_HumanPlayer = relativeMousePosY;
										}
									} // end of if (leftMouseButtonClick == true)
								} // end of if (relativeMousePosY > -1 && relativeMousePosY < ConstGameBoardSizePerDir)
							}  // end of if (relativeMousePosX > -1 && relativeMousePosX < ConstGameBoardSizePerDir)

							if (firstSelectedPosX_HumanPlayer > -1 && secondSelectedPosX_HumanPlayer > -1)
							{
								int32_t numOfPossiblePlayerMoves = Player2MoveList.NumOfMoves;

								int32_t firstSelectedPosID = firstSelectedPosX_HumanPlayer + ConstGameBoardSizePerDir * firstSelectedPosY_HumanPlayer;
								int32_t secondSelectedPosID = secondSelectedPosX_HumanPlayer + ConstGameBoardSizePerDir * secondSelectedPosY_HumanPlayer;

								bool possibleMove = false;
								int32_t idOfSelectedMove = 0;

								for (int32_t moveID = 0; moveID < numOfPossiblePlayerMoves; moveID++)
								{
									possibleMove = Player2MoveList.Validate_PossibleMove(moveID, firstSelectedPosX_HumanPlayer, firstSelectedPosY_HumanPlayer, firstSelectedPosID, secondSelectedPosID, pActualGameStateData);

									if (possibleMove == true)
									{
										idOfSelectedMove = moveID;
										break;
									}
								} // end of for (int32_t moveID = 0; moveID < numOfPossiblePlayerMoves; moveID++)

								if (possibleMove == false)
								{
									firstSelectedPosX_HumanPlayer = -1;
									firstSelectedPosY_HumanPlayer = -1;

									secondSelectedPosX_HumanPlayer = -1;
									secondSelectedPosY_HumanPlayer = -1;
								}
								else if (possibleMove == true)
								{
									if (HumanPlayerMoveFinished == false)
									{
										GameStateRingBuffer.Increase_ActualBufferElement();
										GameStateRingBuffer.Get_ActualBufferElement(&pActualGameStateData);
									}

									//Player2MoveList.Make_Move_If_Possible(idOfSelectedMove, firstSelectedPosX_HumanPlayer, firstSelectedPosY_HumanPlayer, firstSelectedPosID, secondSelectedPosID, pActualGameStateData);
									Player2MoveList.Make_Move(idOfSelectedMove, firstSelectedPosX_HumanPlayer, firstSelectedPosY_HumanPlayer, firstSelectedPosID, pActualGameStateData);


									Update_CheckersKonaneGameBoardGraphics(&GameBoard, pActualGameStateData);

									HumanPlayerMoveFinished = true;

									//MovementCounter++;

									firstSelectedPosX_HumanPlayer = -1;
									firstSelectedPosY_HumanPlayer = -1;

									secondSelectedPosX_HumanPlayer = -1;
									secondSelectedPosY_HumanPlayer = -1;

								} // end of else if (possibleMove == true)
							} // end of if (firstSelectedPosX_HumanPlayer > -1 && secondSelectedPosX_HumanPlayer > -1)
						}  // else if (HumanPlayer == 2)
					}


				MovesCompleted:;


					HumanPlayerMoveFinishedButtonClicked = false;

					bool HumanPlayerMoveFinishedButtonSelected = false;

					if (mousePosX == HumanPlayerMoveCompleteButtonPosX)
					{
						if (mousePosY == HumanPlayerMoveCompleteButtonPosY)
						{
							HumanPlayerMoveFinishedButtonSelected = true;
						}
					}

					if (HumanPlayerMoveFinished == true)
					{
						if (HumanPlayerMoveFinishedButtonSelected == true)
						{
							if ((MovementCounter % 2 == 0 && HumanPlayer == 1) || (MovementCounter % 2 == 1 && HumanPlayer == 2))
							{

								if (leftMouseButtonClick == true)
								{
									HumanPlayerMoveFinished = false;
									HumanPlayerMoveFinishedButtonClicked = true;
									MovementCounter++;
								}
							}
						}
					}

					leftMouseButtonClick = false;
					rightMouseButtonClick = false;
					middleMouseButtonClick = false;

					Calculate_CheckersKonaneScore(&Player1Score, &Player2Score, pActualGameStateData);

					if (Player1Score > 0 && Player2Score == 0)
					{
						Player1IsWinner = true;
						GameFinished = true;
					}
					else if (Player1Score == 0 && Player2Score > 0)
					{
						Player2IsWinner = true;
						GameFinished = true;
					}
					else if (Player1Score == 0 && Player2Score == 0)
					{
						GameFinished = true;
					}

					WinConsole.Clear_BackBuffer();

					WinConsole.Draw_2DObject_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top, GameBoard.pDataArray, GameBoard.NumCharactersPerRow, GameBoard.NumCharactersPerColumn);

					if (GameFinished == false)
					{
						if ((MovementCounter % 2 == 0 && HumanPlayer == 1) || (MovementCounter % 2 == 1 && HumanPlayer == 2))
						{
							if (HumanPlayerMoveFinishedButtonSelected == true)
								WinConsole.Write_Pixel_Into_BackBuffer(HumanPlayerMoveCompleteButtonPosX, HumanPlayerMoveCompleteButtonPosY, lightyello);
							else
								WinConsole.Write_Pixel_Into_BackBuffer(HumanPlayerMoveCompleteButtonPosX, HumanPlayerMoveCompleteButtonPosY, graywhite);


							sprintf(strBuffer, "click to finish move");
							WinConsole.Write_String_Into_BackBuffer(HumanPlayerMoveCompleteButtonPosX + 2, HumanPlayerMoveCompleteButtonPosY, strBuffer, lightaqua, black);

							sprintf(strBuffer, "(left mButton)");
							WinConsole.Write_String_Into_BackBuffer(HumanPlayerMoveCompleteButtonPosX + 2, HumanPlayerMoveCompleteButtonPosY + 1, strBuffer, lightaqua, black);
						}
					}

					sprintf(strBuffer, "move counter: %03d", MovementCounter);
					WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 12, strBuffer, lightaqua, black);

					sprintf(strBuffer, "score (player1/player2): %03d/%03d", Player1Score, Player2Score);
					WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 13, strBuffer, lightaqua, black);

					sprintf(strBuffer, "F1/F2: new game (player1/player2)");
					WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 15, strBuffer, lightaqua, black);

					if (GameFinished == true)
					{
						sprintf(strBuffer, "Game Finished");
						WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left + ConstGameBoardSizePerDir + 2, GameBoardPosY_Top, strBuffer, lightyello, black);

						if (Player1IsWinner == true)
						{
							sprintf(strBuffer, "Winner: Player1");
							WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left + ConstGameBoardSizePerDir + 2, GameBoardPosY_Top + 1, strBuffer, lightgreen, black);
						}
						else if (Player2IsWinner == true)
						{
							sprintf(strBuffer, "Winner: Player2");
							WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left + ConstGameBoardSizePerDir + 2, GameBoardPosY_Top + 1, strBuffer, lightred, black);
						}
					}

					if (HumanPlayer == 1)
					{
						sprintf(strBuffer, "Player1 (Human): green");
						WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, 1, strBuffer, lightgreen, black);
					}
					else if (HumanPlayer == 2)
					{
						sprintf(strBuffer, "Player2 (Human): red");
						WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, 1, strBuffer, lightred, black);
					}

					if (GameFinished == false)
					{
						if ((MovementCounter % 2 == 0 && HumanPlayer == 1) || (MovementCounter % 2 == 1 && HumanPlayer == 2))
						{
							if (firstSelectedPosX_HumanPlayer < 0)
							{
								sprintf(strBuffer, "left mButton: select player piece");
								WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 17, strBuffer, lightaqua, black);
							}
							else if (firstSelectedPosX_HumanPlayer > -1)
							{
								sprintf(strBuffer, "left mButton: select new pos");
								WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 17, strBuffer, lightaqua, black);
							}
						}
						else
						{
							sprintf(strBuffer, "AI is thinking ...");
							WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 17, strBuffer, lightyello, black);
						}
					}

					sprintf(strBuffer, "right mButton: undo move");
					WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 19, strBuffer, lightaqua, black);
					sprintf(strBuffer, "middle mButton: abort move");
					WinConsole.Write_String_Into_BackBuffer(GameBoardPosX_Left, GameBoardPosY_Top + 21, strBuffer, lightaqua, black);


					WinConsole.Present_BackBuffer();

					//Frame-Bremse:

					auto current_timepoint = steady_clock::now();

					//while (current_timepoint - last_timepoint < 250ms)
					//while (current_timepoint - last_timepoint < 50ms)
					while (current_timepoint - last_timepoint < 16ms)
						//while (current_timepoint - last_timepoint < 16666us) // 16.7 Millisekunden (ms)  bzw. 16666 Mikrosekunden (us): maximal 60 Frames pro Sekunde					
					{
						current_timepoint = steady_clock::now();
					}

					FrameTime = 0.000000001f * (current_timepoint - last_timepoint).count();
					FrameRate = 1.0f / FrameTime;
				} //else if (StartNewGame == false)
			} // end of else if (threadID == 0) // master thread

		} while (true);
	} // end of #pragma omp parallel num_threads(2)

	InputHandling.CleanUp();
	WinConsole.Clear_BackBuffer();
	WinConsole.Present_BackBuffer();
	WinConsole.CleanUp();

	Set_CursorVisibilityAndSize(true);
	Reset_CursorPos();
	Set_CursorPos(0, 0);

	cout << "bye bye (Press Return)" << endl;

	//getchar();

	return 0;
}
*/