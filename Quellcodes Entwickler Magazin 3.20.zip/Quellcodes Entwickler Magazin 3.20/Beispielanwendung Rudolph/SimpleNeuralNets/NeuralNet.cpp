#include "NeuralNet.h"

using namespace std;



static CRandomNumbersNN RandomNumbers;

static constexpr float constMinRandomOutputSynapsePlasticity = -0.0001f;
static constexpr float constMaxRandomOutputSynapsePlasticity = 0.0001f;



// Konstruktor:
CRandomNumbersNN::
CRandomNumbersNN() : newValue(1)
{}

// Destruktor:
CRandomNumbersNN::
~CRandomNumbersNN()
{}

/* Neuen Startwert f�r die Berechnung der
Zufallszahlen festlegen */
void CRandomNumbersNN::Change_Seed(
	uint64_t newSeed)
{
	newValue = newSeed;
}

/* Startwert f�r die Berechnung der Zufallszahlen
auf 1 zur�cksetzen */
void CRandomNumbersNN::Reset_Seed(void)
{
	newValue = 1;
}

// zuf�llige 32-Bit-Flie�kommazahlen:
float CRandomNumbersNN::
Get_FloatNumber(float low, float high)
{
	

	newValue = (newValue*constParkMillerMultiplier) %
		constParkMillerModulus;

	float value = low + (high - low)*
		((double)newValue / fconstParkMillerModulus);

	if (value == 0.0f)
		value = 0.0001f;

	return value;
}

float CRandomNumbersNN::
Get_FloatNumber_IncludingZero(float low, float high)
{
	

	newValue = (newValue*constParkMillerMultiplier) %
		constParkMillerModulus;

	float value = low + (high - low)*
		((double)newValue / fconstParkMillerModulus);

	return value;
}

// zuf�llige 64-Bit-Flie�kommazahlen:
double CRandomNumbersNN::
Get_DoubleNumber(double low, double high)
{
	

	newValue = (newValue*constParkMillerMultiplier) %
		constParkMillerModulus;

	double value = low + (high - low)*
		((double)newValue / fconstParkMillerModulus);

	if (value == 0.0)
		value = 0.0001;

	return value;
}

// zuf�llige 64-Bit-Flie�kommazahlen:
double CRandomNumbersNN::
Get_DoubleNumber_IncludingZero(double low, double high)
{
	

	newValue = (newValue*constParkMillerMultiplier) %
		constParkMillerModulus;

	double value = low + (high - low)*
		((double)newValue / fconstParkMillerModulus);

	return value;
}

// zuf�llige 32-Bit-Ganzzahlen:
int32_t CRandomNumbersNN::
Get_IntegerNumber(int32_t low,
	int32_t high_excluded)
{
	newValue = (newValue*constParkMillerMultiplier) %
		constParkMillerModulus;

	int32_t tempVal = low + (high_excluded - low)*
		((double)newValue / fconstParkMillerModulus);

	if (tempVal < high_excluded)
		return tempVal;
	else
		return low;
}

// zuf�llige positive 32-Bit-Ganzzahlen:
uint32_t CRandomNumbersNN::
Get_UnsignedIntegerNumber(uint32_t low,
	uint32_t high_excluded)
{
	newValue = (newValue*constParkMillerMultiplier) %
		constParkMillerModulus;

	uint32_t tempVal = low + (high_excluded - low)*
		((double)newValue / fconstParkMillerModulus);

	if (tempVal < high_excluded)
		return tempVal;
	else
		return low;
}






CGeometricNeuron::CGeometricNeuron()
{}

CGeometricNeuron::~CGeometricNeuron()
{
	delete[] pSynapsePlasticityArray;
	pSynapsePlasticityArray = nullptr;
	delete[] pConnectionWeightArray;
	pConnectionWeightArray = nullptr;
	delete[] pDistanceArray;
	pDistanceArray = nullptr;
	delete[] pReceiverNeuronIDArray;
	pReceiverNeuronIDArray = nullptr;
}

void CGeometricNeuron::Connect_With_Brain(CGeometricNeuron* pNeuronArray)
{
	pUsedNeuronArray = pNeuronArray;
}

void CGeometricNeuron::Set_Position(float x, float y, float z)
{
	PosX = x;
	PosY = y;
	PosZ = z;
}

void CGeometricNeuron::Calculate_ConnectionDistances(void)
{
	//cout << "NeuronID: " << NeuronID << endl;
	float diffX, diffY, diffZ;
	int32_t neuronID;


	for (int32_t i = 0; i < NumConnections; i++)
	{
		neuronID = pReceiverNeuronIDArray[i];

		diffX = PosX - pUsedNeuronArray[neuronID].PosX;
		diffY = PosY - pUsedNeuronArray[neuronID].PosY;
		diffZ = PosZ - pUsedNeuronArray[neuronID].PosZ;

		pDistanceArray[i] = sqrt(diffX*diffX + diffY*diffY + diffZ*diffZ);
		//cout << "Distance: " << pDistanceArray[i] << endl;
	}
}

void CGeometricNeuron::Calculate_ConnectionSquareDistances(void)
{
	//cout << "NeuronID: " << NeuronID << endl;
	float diffX, diffY, diffZ;
	int32_t neuronID;


	for (int32_t i = 0; i < NumConnections; i++)
	{
		neuronID = pReceiverNeuronIDArray[i];

		diffX = PosX - pUsedNeuronArray[neuronID].PosX;
		diffY = PosY - pUsedNeuronArray[neuronID].PosY;
		diffZ = PosZ - pUsedNeuronArray[neuronID].PosZ;

		pDistanceArray[i] = diffX*diffX + diffY*diffY + diffZ*diffZ;
		//cout << "Distance: " << pDistanceArray[i] << endl;
	}
}

void CGeometricNeuron::Set_ConnectionWeight(float weight, int32_t synapseID)
{
	pConnectionWeightArray[synapseID] = weight;
}

void CGeometricNeuron::Connect_With_ReceiverNeuron(int32_t neuronID, int32_t synapseID)
{
	pSynapsePlasticityArray[synapseID] = 0.0f;
	pDistanceArray[synapseID] = 10000.0f;
	pReceiverNeuronIDArray[synapseID] = neuronID;
}

void CGeometricNeuron::Connect_With_ReceiverNeurons(int32_t *pNeuronIDArray)
{
	for (int32_t i = 0; i < NumConnections; i++)
	{
		pSynapsePlasticityArray[i] = 0.0f;
		pDistanceArray[i] = 10000.0f;
		pReceiverNeuronIDArray[i] = pNeuronIDArray[i];
	}
}

void CGeometricNeuron::Init_Neuron(int32_t neuronID, int32_t numConnections)
{
	delete[] pSynapsePlasticityArray;
	pSynapsePlasticityArray = nullptr;
	delete[] pConnectionWeightArray;
	pConnectionWeightArray = nullptr;
	delete[] pDistanceArray;
	pDistanceArray = nullptr;
	delete[] pReceiverNeuronIDArray;
	pReceiverNeuronIDArray = nullptr;

	NeuronID = neuronID;

	Activity = 0.0f;
	ReceiverSynapseID = -1;
	ReceiverNeuronID = -1;
	NumConnections = numConnections;

	pSynapsePlasticityArray = new (std::nothrow) float[NumConnections];
	pConnectionWeightArray = new (std::nothrow) float[NumConnections];
	pDistanceArray = new (std::nothrow) float[NumConnections];
	pReceiverNeuronIDArray = new (std::nothrow) int32_t[NumConnections];

	for (int32_t i = 0; i < NumConnections; i++)
	{
		pSynapsePlasticityArray[i] = 0.0f;
		pConnectionWeightArray[i] = 0.99f;//1.0f;
		pDistanceArray[i] = 10000.0f;
		pReceiverNeuronIDArray[i] = -1;
	}
}

void CGeometricNeuron::Init_FullyConnectedNeuron(int32_t neuronID, int32_t numNeurons)
{
	delete[] pSynapsePlasticityArray;
	pSynapsePlasticityArray = nullptr;
	delete[] pConnectionWeightArray;
	pConnectionWeightArray = nullptr;
	delete[] pDistanceArray;
	pDistanceArray = nullptr;
	delete[] pReceiverNeuronIDArray;
	pReceiverNeuronIDArray = nullptr;

	NeuronID = neuronID;

	Activity = 0.0f;
	ReceiverSynapseID = -1;
	ReceiverNeuronID = -1;
	NumConnections = numNeurons - 1;

	pSynapsePlasticityArray = new (std::nothrow) float[NumConnections];
	pConnectionWeightArray = new (std::nothrow) float[NumConnections];
	pDistanceArray = new (std::nothrow) float[NumConnections];
	pReceiverNeuronIDArray = new (std::nothrow) int32_t[NumConnections];

	int32_t i;

	for (i = 0; i < NumConnections; i++)
	{
		pSynapsePlasticityArray[i] = 0.0f;
		pConnectionWeightArray[i] = 1.0f;
		pDistanceArray[i] = 10000.0f;
		pReceiverNeuronIDArray[i] = -1;
	}

	int32_t counter = 0;

	for (i = 0; i < numNeurons; i++)
	{
		if (i == NeuronID)
			continue;

		pReceiverNeuronIDArray[counter] = i;
		counter++;
	}
}

void CGeometricNeuron::Reset_Activity(void)
{
	ReceiverSynapseID = -1;
	ReceiverNeuronID = -1;
	Activity = 0.0f;
}

void CGeometricNeuron::Set_Activity(float value)
{
	Activity = value;
}

int32_t CGeometricNeuron::Get_ID_Of_Strongest_ConnectedNeuron(void)
{
	float maxPlasticity = -100000.0f;
	int32_t belongingSynapseID = -1;

	for (int32_t i = 0; i < NumConnections; i++)
	{
		if(maxPlasticity < pSynapsePlasticityArray[i])
		{
			maxPlasticity = pSynapsePlasticityArray[i];
			belongingSynapseID = i;
		}
	}

	return pReceiverNeuronIDArray[belongingSynapseID];
}



void CGeometricNeuron::Reduce_PlasticityValues(float decreaseValue, float minPlasticityValue)
{
	for (int32_t i = 0; i < NumConnections; i++)
	{
		pSynapsePlasticityArray[i] -= decreaseValue;
		pSynapsePlasticityArray[i] = max(minPlasticityValue, pSynapsePlasticityArray[i]);
	}
}

void CGeometricNeuron::Reset_PlasticityValues(void)
{
	for (int32_t i = 0; i < NumConnections; i++)
		pSynapsePlasticityArray[i] = 0.0f;
}

void CGeometricNeuron::Update_PlasticityValues(float finalActivity, float learningRate)
{
	if (ReceiverSynapseID < 0)
		return;

	pSynapsePlasticityArray[ReceiverSynapseID] += learningRate * finalActivity;

	ReceiverSynapseID = -1;
}



void CGeometricNeuron::Propagate_Signal(int32_t receiverNeuronID)
{
	int32_t receiverSynapseID = -1;

	int32_t i;

	for (i = 0; i < NumConnections; i++)
	{
		if (pReceiverNeuronIDArray[i] == receiverNeuronID)
		{
			receiverSynapseID = i;
			break;
		}
	}

	if (receiverSynapseID < 0)
		return;

	ReceiverSynapseID = receiverSynapseID;
	pUsedNeuronArray[receiverNeuronID].Activity = pConnectionWeightArray[receiverSynapseID] * Activity / pDistanceArray[receiverSynapseID];
}

int32_t CGeometricNeuron::Propagate_Signal_To_NonActivatedNeuron(CRandomNumbersNN *pRandomNumbers)
{
	float maxPlasticity = -1000000.0f;

	int32_t IDofSynapseWithMaxPlasticity = 0;

	float plasticity;

	for (uint32_t i = 0; i < NumConnections; i++)
	{
		plasticity = pSynapsePlasticityArray[i];

		if(plasticity > maxPlasticity)
		{
			maxPlasticity = plasticity;
			IDofSynapseWithMaxPlasticity = i;
		}
	}

	int32_t testReceiverNeuronID;
	int32_t testReceiverSynapseID;

	do
	{
		testReceiverSynapseID = pRandomNumbers->Get_IntegerNumber(0, NumConnections);

		if(testReceiverSynapseID != IDofSynapseWithMaxPlasticity)
			testReceiverSynapseID = pRandomNumbers->Get_IntegerNumber(0, NumConnections);

		///
		//if (testReceiverSynapseID != IDofSynapseWithMaxPlasticity)
			//testReceiverSynapseID = pRandomNumbers->Get_IntegerNumber(0, NumConnections);
		///

		testReceiverNeuronID = pReceiverNeuronIDArray[testReceiverSynapseID];

		if (pUsedNeuronArray[testReceiverNeuronID].Activity == 0.0f)
			break;

	} while (true);

	ReceiverSynapseID = testReceiverSynapseID;
	ReceiverNeuronID = pReceiverNeuronIDArray[ReceiverSynapseID];
	pUsedNeuronArray[ReceiverNeuronID].Activity = pConnectionWeightArray[ReceiverSynapseID] * Activity / pDistanceArray[ReceiverSynapseID];
	return ReceiverNeuronID;
}

int32_t CGeometricNeuron::Propagate_Signal(CRandomNumbersNN *pRandomNumbers)
{
	float maxPlasticity = -1000000.0f;

	int32_t IDofSynapseWithMaxPlasticity = 0;

	float plasticity;

	for (uint32_t i = 0; i < NumConnections; i++)
	{
		plasticity = pSynapsePlasticityArray[i];

		if (plasticity > maxPlasticity)
		{
			maxPlasticity = plasticity;
			IDofSynapseWithMaxPlasticity = i;
		}
	}

	int32_t testReceiverSynapseID = pRandomNumbers->Get_IntegerNumber(0, NumConnections);

	if (testReceiverSynapseID != IDofSynapseWithMaxPlasticity)
		testReceiverSynapseID = pRandomNumbers->Get_IntegerNumber(0, NumConnections);

	ReceiverSynapseID = testReceiverSynapseID;
	ReceiverNeuronID = pReceiverNeuronIDArray[ReceiverSynapseID];
	pUsedNeuronArray[ReceiverNeuronID].Activity = pConnectionWeightArray[ReceiverSynapseID] * Activity / pDistanceArray[ReceiverSynapseID];
	return ReceiverNeuronID;
}

int32_t CGeometricNeuron::Propagate_Signal_Randomly(CRandomNumbersNN *pRandomNumbers)
{
	int32_t randomReceiverSynapseID = pRandomNumbers->Get_IntegerNumber(0, NumConnections);
	
	ReceiverSynapseID = randomReceiverSynapseID;
	ReceiverNeuronID = pReceiverNeuronIDArray[ReceiverSynapseID];
	pUsedNeuronArray[ReceiverNeuronID].Activity = pConnectionWeightArray[ReceiverSynapseID] * Activity / pDistanceArray[ReceiverSynapseID];
	return ReceiverNeuronID;
}

int32_t CGeometricNeuron::Select_Connected_Neuron_Randomly(CRandomNumbersNN *pRandomNumbers)
{
	int32_t randomReceiverSynapseID = pRandomNumbers->Get_IntegerNumber(0, NumConnections);

	ReceiverSynapseID = randomReceiverSynapseID;
	ReceiverNeuronID = pReceiverNeuronIDArray[ReceiverSynapseID];
	return ReceiverNeuronID;
}



CGeometricNeuralNet::CGeometricNeuralNet()
{}

CGeometricNeuralNet::~CGeometricNeuralNet()
{
	delete[] pNeuronArray;
	pNeuronArray = nullptr;
}

float CGeometricNeuralNet::Find_MaxPlasticityValue(void)
{
	MaxPlasticityValue = -1000000.0f;

	//int32_t numConnectionsPerNeuron = NumNeurons - 1;
	int32_t numConnectionsPerNeuron;

	float plasticityValue;
	int32_t i, j;

	for (i = 0; i < NumNeurons; i++)
	{
		numConnectionsPerNeuron = pNeuronArray[i].NumConnections;

		for (j = 0; j < numConnectionsPerNeuron; j++)
		{
			plasticityValue = pNeuronArray[i].pSynapsePlasticityArray[j];

			if (plasticityValue == 0.0f)
				continue;

			if (MaxPlasticityValue < plasticityValue)
				MaxPlasticityValue = plasticityValue;
		}
	}

	return MaxPlasticityValue;
}

float CGeometricNeuralNet::Find_MinNonZeroPlasticityValue(void)
{
	MinNonZeroPlasticityValue = 1000000.0f;

	//int32_t numConnectionsPerNeuron = NumNeurons - 1;
	int32_t numConnectionsPerNeuron;

	float plasticityValue;
	int32_t i, j;

	for (i = 0; i < NumNeurons; i++)
	{
		numConnectionsPerNeuron = pNeuronArray[i].NumConnections;

		for (j = 0; j < numConnectionsPerNeuron; j++)
		{
			plasticityValue = pNeuronArray[i].pSynapsePlasticityArray[j];

			if (plasticityValue == 0.0f)
				continue;

			if (MinNonZeroPlasticityValue > plasticityValue)
				MinNonZeroPlasticityValue = plasticityValue;
		}
	}

	return MinNonZeroPlasticityValue;
}

int32_t CGeometricNeuralNet::Get_ID_Of_Strongest_ConnectedNeuron(int32_t lastNeuronID)
{
	return pNeuronArray[lastNeuronID].Get_ID_Of_Strongest_ConnectedNeuron();
}

void CGeometricNeuralNet::Reduce_PlasticityValues(float decreaseValue, float minPlasticityValue)
{
	for (int32_t i = 0; i < NumNeurons; i++)
		pNeuronArray[i].Reduce_PlasticityValues(decreaseValue, minPlasticityValue);
}

void CGeometricNeuralNet::Train_NeuralNet_PathFinding(int32_t IDofFirstNeuron, int32_t IDofLastNeuron, float initialActivity, float learningRate)
{
	int32_t i, idOfNextNeuron;

	for (i = 0; i < NumNeurons; i++)
		pNeuronArray[i].Reset_Activity();

	pNeuronArray[IDofFirstNeuron].Set_Activity(initialActivity);

	idOfNextNeuron = pNeuronArray[IDofFirstNeuron].Propagate_Signal(&RandomNumbers);

	if (idOfNextNeuron == IDofLastNeuron)
	{
		float finalActivity = pNeuronArray[IDofLastNeuron].Activity;

		for (i = 0; i < NumNeurons; i++)
			pNeuronArray[i].Update_PlasticityValues(finalActivity, learningRate);

		return;
	}

	do
	{
		idOfNextNeuron = pNeuronArray[idOfNextNeuron].Propagate_Signal(&RandomNumbers);

		if (idOfNextNeuron == IDofLastNeuron)
			break;

	} while (true);

	float finalActivity = pNeuronArray[IDofLastNeuron].Activity;

	for (i = 0; i < NumNeurons; i++)
		pNeuronArray[i].Update_PlasticityValues(finalActivity, learningRate);
}

void CGeometricNeuralNet::Start_Training(void)
{
	for (int32_t i = 0; i < NumNeurons; i++)
	{
		pNeuronArray[i].Reset_Activity();
		pNeuronArray[i].Reset_PlasticityValues();
	}
}

void CGeometricNeuralNet::Random_PathFinding(int32_t IDofFirstNeuron, int32_t IDofLastNeuron, float initialActivity, float learningRate)
{
	/*
	int32_t i, idOfNextNeuron;

	for (i = 0; i < NumNeurons; i++)
		pNeuronArray[i].Reset_Activity();

	pNeuronArray[IDofFirstNeuron].Set_Activity(initialActivity);

	idOfNextNeuron = pNeuronArray[IDofFirstNeuron].Propagate_Signal_Randomly(&RandomNumbers);
	
	if (idOfNextNeuron == IDofLastNeuron)
	{
		float finalActivity = pNeuronArray[IDofLastNeuron].Activity;

		for (i = 0; i < NumNeurons; i++)
			pNeuronArray[i].Update_PlasticityValues(finalActivity, learningRate);

		return;
	}

	do
	{
		idOfNextNeuron = pNeuronArray[idOfNextNeuron].Propagate_Signal_Randomly(&RandomNumbers);

		if (idOfNextNeuron == IDofLastNeuron)
			break;

	} while (true);

	float finalActivity = pNeuronArray[IDofLastNeuron].Activity;

	for (i = 0; i < NumNeurons; i++)
		pNeuronArray[i].Update_PlasticityValues(finalActivity, learningRate);
	*/

	int32_t i, idOfNextNeuron, idOfActualNeuron;

	for (i = 0; i < NumNeurons; i++)
		pNeuronArray[i].Reset_Activity();
	

	idOfNextNeuron = pNeuronArray[IDofFirstNeuron].Select_Connected_Neuron_Randomly(&RandomNumbers);

	do
	{
		idOfNextNeuron = pNeuronArray[idOfNextNeuron].Select_Connected_Neuron_Randomly(&RandomNumbers);

		if (idOfNextNeuron == IDofLastNeuron)
			break;

	} while (true);

	int32_t receiverSynapseID;

	
	pNeuronArray[IDofFirstNeuron].Set_Activity(initialActivity);
	idOfNextNeuron = pNeuronArray[IDofFirstNeuron].ReceiverNeuronID;

	receiverSynapseID = pNeuronArray[IDofFirstNeuron].ReceiverSynapseID;
	pNeuronArray[idOfNextNeuron].Activity = pNeuronArray[IDofFirstNeuron].pConnectionWeightArray[receiverSynapseID] * pNeuronArray[IDofFirstNeuron].Activity / pNeuronArray[IDofFirstNeuron].pDistanceArray[receiverSynapseID];
	//cout << pNeuronArray[idOfNextNeuron].Activity << endl;
	
	do
	{
		idOfActualNeuron = idOfNextNeuron;
		idOfNextNeuron = pNeuronArray[idOfActualNeuron].ReceiverNeuronID;

		receiverSynapseID = pNeuronArray[idOfActualNeuron].ReceiverSynapseID;
		pNeuronArray[idOfNextNeuron].Activity = pNeuronArray[idOfActualNeuron].pConnectionWeightArray[receiverSynapseID] * pNeuronArray[idOfActualNeuron].Activity / pNeuronArray[idOfActualNeuron].pDistanceArray[receiverSynapseID];
		//cout << pNeuronArray[idOfNextNeuron].Activity << endl;

		if (idOfNextNeuron == IDofLastNeuron)
			break;

	} while (true);

	
	float finalActivity = pNeuronArray[IDofLastNeuron].Activity;

	for (i = 0; i < NumNeurons; i++)
		pNeuronArray[i].Update_PlasticityValues(finalActivity, learningRate);
}

void CGeometricNeuralNet::Train_NeuralNet_TSP(int32_t IDofFirstAndLastNeuron, float initialActivity, float learningRate)
{
	int32_t i, idOfNextNeuron;

	for (i = 0; i < NumNeurons; i++)
		pNeuronArray[i].Reset_Activity();

	pNeuronArray[IDofFirstAndLastNeuron].Set_Activity(initialActivity);
	
	idOfNextNeuron = pNeuronArray[IDofFirstAndLastNeuron].Propagate_Signal_To_NonActivatedNeuron(&RandomNumbers);

	int32_t pathCounter = 1;

	do
	{
		if (pathCounter == NumNeurons - 1)
		{
			pNeuronArray[idOfNextNeuron].Propagate_Signal(IDofFirstAndLastNeuron);
			break;
		}
		else
		{
			idOfNextNeuron = pNeuronArray[idOfNextNeuron].Propagate_Signal_To_NonActivatedNeuron(&RandomNumbers);
			pathCounter++;
		}

	} while (true);

	float finalActivity = pNeuronArray[IDofFirstAndLastNeuron].Activity;


	for (i = 0; i < NumNeurons; i++)
		pNeuronArray[i].Update_PlasticityValues(finalActivity, learningRate);
}



void CGeometricNeuralNet::Set_Position(int32_t neuronID, float x, float y, float z)
{
	pNeuronArray[neuronID].Set_Position(x, y, z);
}

void CGeometricNeuralNet::Calculate_ConnectionDistances(void)
{
	for (int32_t i = 0; i < NumNeurons; i++)
		pNeuronArray[i].Calculate_ConnectionDistances();
}

void CGeometricNeuralNet::Calculate_ConnectionSquareDistances(void)
{
	for (int32_t i = 0; i < NumNeurons; i++)
		pNeuronArray[i].Calculate_ConnectionSquareDistances();
}

void CGeometricNeuralNet::Set_ConnectionWeight(int32_t neuronID, float weight, int32_t synapseID)
{
	pNeuronArray[neuronID].Set_ConnectionWeight(weight, synapseID);
}

void CGeometricNeuralNet::Set_ConnectionWeight(int32_t neuronID, int32_t receiverNeuronID, float weight)
{
	int32_t numConnections = pNeuronArray[neuronID].NumConnections;

	for(int32_t i = 0; i < numConnections; i++)
	{
		if(pNeuronArray[neuronID].pReceiverNeuronIDArray[i] == receiverNeuronID)
		{
			pNeuronArray[neuronID].pConnectionWeightArray[i] = weight;
			return;
		}
	}
}

void CGeometricNeuralNet::Connect_With_ReceiverNeuron(int32_t neuronID, int32_t receiverNeuronID, int32_t synapseID)
{
	pNeuronArray[neuronID].Connect_With_ReceiverNeuron(receiverNeuronID, synapseID);
}

void CGeometricNeuralNet::Init_Neuron(int32_t neuronID, int32_t numConnections)
{
	pNeuronArray[neuronID].Init_Neuron(neuronID, numConnections);
}

void CGeometricNeuralNet::Initialize_NeuralNet(int32_t numNeurons)
{
	delete[] pNeuronArray;
	pNeuronArray = nullptr;

	MinNonZeroPlasticityValue = 0.0f;
	MaxPlasticityValue = 0.0f;

	NumNeurons = numNeurons;

	pNeuronArray = new (std::nothrow) CGeometricNeuron[numNeurons];

	for (int32_t i = 0; i < numNeurons; i++)
		pNeuronArray[i].Connect_With_Brain(pNeuronArray);
}

void CGeometricNeuralNet::Initialize_FullyConnected_NeuralNet(int32_t numNeurons)
{
	delete[] pNeuronArray;
	pNeuronArray = nullptr;

	MinNonZeroPlasticityValue = 0.0f;
	MaxPlasticityValue = 0.0f;

	NumNeurons = numNeurons;

	pNeuronArray = new (std::nothrow) CGeometricNeuron[numNeurons];

	for (int32_t i = 0; i < numNeurons; i++)
	{
		pNeuronArray[i].Init_FullyConnectedNeuron(i, numNeurons);
		pNeuronArray[i].Connect_With_Brain(pNeuronArray);
	}
}






CNeuron::CNeuron()
{}

CNeuron::~CNeuron()
{
	delete[] pOutputSynapsePlasticityArray;
	pOutputSynapsePlasticityArray = nullptr;

	delete[] pOutputSynapseMinBlockingValueArray;
	pOutputSynapseMinBlockingValueArray = nullptr;

	delete[] pOutputSynapseMaxBlockingValueArray;
	pOutputSynapseMaxBlockingValueArray = nullptr;

	delete[] pReceiverNeuronIDArray;
	pReceiverNeuronIDArray = nullptr;
}



void CNeuron::Set_Input(float value)
{
	if (UsedAsInputNeuron == false)
		return;

	NeuronOutput = value;
}

void CNeuron::Add_Input(float value)
{
	if (UsedAsInputNeuron == false)
		return;

	NeuronOutput += value;
}

void CNeuron::Use_As_InputNeuron(void)
{
	UsedAsInputNeuron = true;
	UsedAsHiddenNeuron = false;
	UsedAsOutputNeuron = false;
	UsedAsBiasNeuron = false;
}

void CNeuron::Use_As_HiddenNeuron(void)
{
	UsedAsInputNeuron = false;
	UsedAsHiddenNeuron = true;
	UsedAsOutputNeuron = false;
	UsedAsBiasNeuron = false;
	UsedAsMemoryNeuron = false;
}

void CNeuron::Use_As_OutputNeuron(void)
{
	UsedAsInputNeuron = false;
	UsedAsHiddenNeuron = false;
	UsedAsOutputNeuron = true;
	UsedAsBiasNeuron = false;
	UsedAsMemoryNeuron = false;
}

void CNeuron::Use_As_BiasNeuron(void)
{
	UsedAsInputNeuron = false;
	UsedAsHiddenNeuron = false;
	UsedAsOutputNeuron = false;
	UsedAsBiasNeuron = true;
	UsedAsMemoryNeuron = false;

	NeuronOutput = -1.0f;
}

void CNeuron::Use_As_MemoryNeuron(void)
{
	UsedAsInputNeuron = false;
	UsedAsHiddenNeuron = false;
	UsedAsOutputNeuron = false;
	UsedAsBiasNeuron = false;
	UsedAsMemoryNeuron = true;
}


void CNeuron::Set_OutputSynapseBlockingValue(float minValue, float maxValue, uint32_t synapseID)
{
	pOutputSynapseMinBlockingValueArray[synapseID] = minValue;
	pOutputSynapseMaxBlockingValueArray[synapseID] = maxValue;
}

void CNeuron::Set_OutputSynapsePlasticity(float value, uint32_t synapseID)
{
	pOutputSynapsePlasticityArray[synapseID] = value;
}

void CNeuron::Set_LearningRate(float learningRate)
{
	LearningRate = learningRate;
}

void CNeuron::Connect_With_Brain(CNeuron* pNeuronArray)
{
	Dropout = false;
	pUsedNeuronArray = pNeuronArray;
}

void CNeuron::Set_ActivationFunction(pActivationFunc pFunc)
{
	pActivationFunction = pFunc;
}

void CNeuron::Set_UserDefErrorFunction(pErrorFunc pFunc)
{
	pUserDefErrorFunction = pFunc;
}

void CNeuron::Set_ErrorFactors(float factor1, float factor2)
{
	ErrorFactor1 = factor1;
	ErrorFactor2 = factor2;
}

void CNeuron::Reset_NeuronInput(void)
{
	NeuronInput = 0.0f;
}

float CNeuron::Get_NeuronInput(void)
{
	return NeuronInput;
}

void CNeuron::Set_NeuronInput(float value)
{
	NeuronInput = value;
}

void CNeuron::Init_OutputSynapses(uint32_t numOfOutputSynapses)
{
	Dropout = false;

	delete[] pOutputSynapsePlasticityArray;
	pOutputSynapsePlasticityArray = nullptr;

	delete[] pOutputSynapseMinBlockingValueArray;
	pOutputSynapseMinBlockingValueArray = nullptr;

	delete[] pOutputSynapseMaxBlockingValueArray;
	pOutputSynapseMaxBlockingValueArray = nullptr;

	delete[] pReceiverNeuronIDArray;
	pReceiverNeuronIDArray = nullptr;

	NumOfOutputSynapses = numOfOutputSynapses;
	pOutputSynapsePlasticityArray = new (std::nothrow) float[NumOfOutputSynapses];
	pReceiverNeuronIDArray = new (std::nothrow) uint32_t[NumOfOutputSynapses];

	pOutputSynapseMinBlockingValueArray = new (std::nothrow) float[NumOfOutputSynapses];
	pOutputSynapseMaxBlockingValueArray = new (std::nothrow) float[NumOfOutputSynapses];
	

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		pOutputSynapsePlasticityArray[i] = 0.0f;
		pReceiverNeuronIDArray[i] = 0;
		pOutputSynapseMinBlockingValueArray[i] = 0.0f;
		pOutputSynapseMaxBlockingValueArray[i] = 1.0f;
	}
}

void CNeuron::Connect_With_ReceiverNeuron(uint32_t neuronID, uint32_t synapseID)
{
	pReceiverNeuronIDArray[synapseID] = neuronID;
}

void CNeuron::Connect_With_ReceiverNeurons(uint32_t *pNeuronIDArray)
{
	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
		pReceiverNeuronIDArray[i] = pNeuronIDArray[i];
}

void CNeuron::Modify_OutputSynapsePlasticities(float multiplier)
{
	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
		pOutputSynapsePlasticityArray[i] *= multiplier;
}

void CNeuron::Randomize_OutputSynapsePlasticities(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue)
{
	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
		pOutputSynapsePlasticityArray[i] = pRandomNumbers->Get_FloatNumber(minValue, maxValue);
}

void CNeuron::Add_Randomized_OutputSynapsePlasticities(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float weight1, float weight2)
{
	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
		pOutputSynapsePlasticityArray[i] = weight1 * pOutputSynapsePlasticityArray[i] + weight2 * pRandomNumbers->Get_FloatNumber(minValue, maxValue);
}

void CNeuron::Randomize_OutputSynapsePlasticities(CRandomNumbersNN *pRandomNumbers, float *pRandomValueArray, uint32_t numArrayElements)
{
	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
		pOutputSynapsePlasticityArray[i] = pRandomValueArray[pRandomNumbers->Get_UnsignedIntegerNumber(0, numArrayElements)];
}

void CNeuron::Add_Randomized_OutputSynapsePlasticities(CRandomNumbersNN *pRandomNumbers, float *pRandomValueArray, uint32_t numArrayElements, float weight1, float weight2)
{
	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
		pOutputSynapsePlasticityArray[i] = weight1 * pOutputSynapsePlasticityArray[i] + weight2 * pRandomValueArray[pRandomNumbers->Get_UnsignedIntegerNumber(0, numArrayElements)];
}

void CNeuron::Clone_OutputSynapsePlasticities(const CNeuron &originalObject)
{
	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
		pOutputSynapsePlasticityArray[i] = originalObject.pOutputSynapsePlasticityArray[i];
}

void CNeuron::Clone_OutputSynapsePlasticities(const CNeuron &originalObject, CRandomNumbersNN *pRandomNumbers, float variance)
{
	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		pOutputSynapsePlasticityArray[i] = originalObject.pOutputSynapsePlasticityArray[i];
		pOutputSynapsePlasticityArray[i] += pRandomNumbers->Get_FloatNumber(-variance, variance);
	}
}

void CNeuron::Clone_OutputSynapsePlasticities(const CNeuron &originalObject, CRandomNumbersNN *pRandomNumbers, float minVariance, float maxVariance)
{
	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		pOutputSynapsePlasticityArray[i] = originalObject.pOutputSynapsePlasticityArray[i];
		pOutputSynapsePlasticityArray[i] += pRandomNumbers->Get_FloatNumber(minVariance, maxVariance);
	}
}

void CNeuron::Combine_OutputSynapsePlasticities(CNeuron *pParentNeuron1, CNeuron *pParentNeuron2, CRandomNumbersNN *pRandomNumbers, float minWeight1)
{
	float weight1, weight2;

	float newPlasticity;

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		weight1 = pRandomNumbers->Get_FloatNumber(minWeight1, 1.0f);
		weight2 = 1.0f - weight1;
		newPlasticity = weight1*pParentNeuron1->pOutputSynapsePlasticityArray[i];
		newPlasticity += weight2*pParentNeuron2->pOutputSynapsePlasticityArray[i];

		pOutputSynapsePlasticityArray[i] = newPlasticity;
	}
}



bool CNeuron::Save_OutputSynapsePlasticities(const char* pFilename)
{
	std::ofstream WriteFile;

	// neue Datei erzeugen bzw. alte �berschreiben:
	WriteFile.open(pFilename);

	// neue Datei erzeugen bzw. Inhalt ans Ende einer bestehenden Datei schreiben: 
	//WriteFile.open(pFilename, ios::app);

	if (WriteFile.good() == false)
		return false;

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		WriteFile << pOutputSynapsePlasticityArray[i] << "  ";
	}

	WriteFile.close();

	return true;
}

bool CNeuron::Load_OutputSynapsePlasticities(const char* pFilename)
{
	std::ifstream ReadFile;

	// eine existierende Datei zum Lesen �ffnen:
	ReadFile.open(pFilename);

	if (ReadFile.good() == false)
		return false;

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		//pOutputSynapsePlasticityArray[i] = 0.0f;
		ReadFile >> pOutputSynapsePlasticityArray[i];
		//cout << pOutputSynapsePlasticityArray[i] << endl;
	}


	ReadFile.close();

	//getchar();

	return true;
}


void CNeuron::Propagate_BinaryValue(uint32_t synapseID)
{
	if (Dropout == true)
		return;

	if (NeuronOutput < pOutputSynapseMinBlockingValueArray[synapseID])
		return;
	if (NeuronOutput > pOutputSynapseMaxBlockingValueArray[synapseID])
		return;

	uint32_t receiverNeuronID = pReceiverNeuronIDArray[synapseID];
	pUsedNeuronArray[receiverNeuronID].NeuronInput += 1.0f;
}

void CNeuron::Propagate_BinaryValue(void)
{
	if (Dropout == true)
		return;

	uint32_t receiverNeuronID;

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		if(NeuronOutput < pOutputSynapseMinBlockingValueArray[i])
			continue;
		if (NeuronOutput > pOutputSynapseMaxBlockingValueArray[i])
			continue;

		receiverNeuronID = pReceiverNeuronIDArray[i];
		pUsedNeuronArray[receiverNeuronID].NeuronInput += 1.0f;
	}
}

void CNeuron::Propagate_SynapticOutput(uint32_t synapseID)
{
	if (Dropout == true)
		return;

	if (NeuronOutput == 0.0f)
		return;

	uint32_t receiverNeuronID = pReceiverNeuronIDArray[synapseID];
	pUsedNeuronArray[receiverNeuronID].NeuronInput += NeuronOutput*pOutputSynapsePlasticityArray[synapseID];
}

void CNeuron::Propagate_SynapticOutput(void)
{
	if(Dropout == true)
		return;

	if (NeuronOutput == 0.0f)
		return;

	uint32_t receiverNeuronID;

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		receiverNeuronID = pReceiverNeuronIDArray[i];
		pUsedNeuronArray[receiverNeuronID].NeuronInput += NeuronOutput*pOutputSynapsePlasticityArray[i];
	}
}

void CNeuron::Propagate_MaximumAbsolutSynapticOutput(uint32_t synapseID)
{
	if (Dropout == true)
		return;

	//if (NeuronOutput == 0.0f)
		//return;

	uint32_t receiverNeuronID = pReceiverNeuronIDArray[synapseID];

	float absValue = abs(pUsedNeuronArray[receiverNeuronID].NeuronInput);
	float value = NeuronOutput*pOutputSynapsePlasticityArray[synapseID];

	if (abs(value) > absValue)
		pUsedNeuronArray[receiverNeuronID].NeuronInput = value;
}

void CNeuron::Propagate_MaximumAbsolutSynapticOutput(void)
{
	if (Dropout == true)
		return;

	//if (NeuronOutput == 0.0f)
		//return;

	uint32_t receiverNeuronID;
	float value, absValue;

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		receiverNeuronID = pReceiverNeuronIDArray[i];

		absValue = abs(pUsedNeuronArray[receiverNeuronID].NeuronInput);
		value = NeuronOutput*pOutputSynapsePlasticityArray[i];
	
		if(abs(value) > absValue)
			pUsedNeuronArray[receiverNeuronID].NeuronInput = value;
	}
}

void CNeuron::Propagate_MaximumSynapticOutput(uint32_t synapseID)
{
	if (Dropout == true)
		return;

	//if (NeuronOutput == 0.0f)
		//return;

	uint32_t receiverNeuronID = pReceiverNeuronIDArray[synapseID];
	pUsedNeuronArray[receiverNeuronID].NeuronInput = max(NeuronOutput*pOutputSynapsePlasticityArray[synapseID], pUsedNeuronArray[receiverNeuronID].NeuronInput);
}

void CNeuron::Propagate_MinimumSynapticOutput(uint32_t synapseID)
{
	if (Dropout == true)
		return;

	//if (NeuronOutput == 0.0f)
		//return;

	uint32_t receiverNeuronID = pReceiverNeuronIDArray[synapseID];
	pUsedNeuronArray[receiverNeuronID].NeuronInput = min(NeuronOutput*pOutputSynapsePlasticityArray[synapseID], pUsedNeuronArray[receiverNeuronID].NeuronInput);
}

void CNeuron::Propagate_MaximumSynapticOutput(void)
{
	if (Dropout == true)
		return;

	//if (NeuronOutput == 0.0f)
		//return;

	uint32_t receiverNeuronID;

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		receiverNeuronID = pReceiverNeuronIDArray[i];
		pUsedNeuronArray[receiverNeuronID].NeuronInput = max(NeuronOutput*pOutputSynapsePlasticityArray[i], pUsedNeuronArray[receiverNeuronID].NeuronInput);
	}
}

void CNeuron::Propagate_MinimumSynapticOutput(void)
{
	if (Dropout == true)
		return;

	//if (NeuronOutput == 0.0f)
		//return;

	uint32_t receiverNeuronID;

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		receiverNeuronID = pReceiverNeuronIDArray[i];
		pUsedNeuronArray[receiverNeuronID].NeuronInput = min(NeuronOutput*pOutputSynapsePlasticityArray[i], pUsedNeuronArray[receiverNeuronID].NeuronInput);
	}
}


void CNeuron::Calculate_NeuronOutput_And_Retain_Input(void)
{
	NeuronOutput_LastCalculationStep = NeuronOutput;
	NeuronOutput = pActivationFunction(NeuronInput);
}

void CNeuron::Calculate_NeuronOutput(void)
{
	NeuronOutput_LastCalculationStep = NeuronOutput;
	NeuronOutput = pActivationFunction(NeuronInput);
	NeuronInput = 0.0f;
}

void CNeuron::Accumulate_NeuronInput_And_Calculate_NeuronOutput(float minOutputValue)
{
	NeuronOutput_LastCalculationStep = NeuronOutput;
	NeuronOutput = pActivationFunction(NeuronInput);

	if (NeuronOutput < minOutputValue)
		return;

	NeuronInput = 0.0f;
}

void CNeuron::Accumulate_NeuronInput_And_Calculate_NeuronOutput(float minOutputValue, float maxOutputValue)
{
	NeuronOutput_LastCalculationStep = NeuronOutput;
	NeuronOutput = pActivationFunction(NeuronInput);

	if (NeuronOutput < minOutputValue)
		return;
	if (NeuronOutput > maxOutputValue)
		return;

	NeuronInput = 0.0f;
}

void CNeuron::Calculate_NeuronOutput(float inputDecrease, float minInputValue)
{
	NeuronOutput_LastCalculationStep = NeuronOutput;
	NeuronOutput = pActivationFunction(NeuronInput);
	NeuronInput -= inputDecrease;
	NeuronInput = max(minInputValue, NeuronInput);
}

void CNeuron::Accumulate_NeuronInput_And_Calculate_NeuronOutput(float minOutputValue, float inputDecrease, float minInputValue)
{
	NeuronOutput_LastCalculationStep = NeuronOutput;
	NeuronOutput = pActivationFunction(NeuronInput);

	if (NeuronOutput < minOutputValue)
		return;

	NeuronInput -= inputDecrease;
	NeuronInput = max(minInputValue, NeuronInput);
}

void CNeuron::Accumulate_NeuronInput_And_Calculate_NeuronOutput(float minOutputValue, float maxOutputValue, float inputDecrease, float minInputValue)
{
	NeuronOutput_LastCalculationStep = NeuronOutput;
	NeuronOutput = pActivationFunction(NeuronInput);

	if (NeuronOutput < minOutputValue)
		return;
	if (NeuronOutput > maxOutputValue)
		return;

	NeuronInput -= inputDecrease;
	NeuronInput = max(minInputValue, NeuronInput);
}

void CNeuron::Reset_NeuronOutput(void)
{
	NeuronOutput_LastCalculationStep = 0.0f;
	NeuronOutput = 0.0f;
	NeuronInput = 0.0f;
}



float CNeuron::Get_NeuronOutput(void)
{
	return NeuronOutput;
}

void CNeuron::Set_BiasNeuronOutput(float value)
{
	if (UsedAsBiasNeuron == false)
		return;

	NeuronOutput = value;
}

void CNeuron::Set_NeuronOutput(float value)
{
	if (UsedAsBiasNeuron == true)
		return;

	NeuronOutput = value;
}





void CNeuron::Set_Error(float value)
{
	ErrorValue = value;
}

float CNeuron::Calculate_Error(float desiredNeuronOutputValue)
{
	if (UsedAsInputNeuron == true)
	{
		ErrorValue = 0.0f;
		return 0.0f;
	}

	// Abweichung:
	float variance = desiredNeuronOutputValue - NeuronOutput;
	ErrorValue = variance * ErrorFactor1 * exp(-(ErrorFactor2 * NeuronOutput * NeuronOutput));

	/* Hinweis: Wenn bereits eine geringe Neuronenaktivit�t (NeuronOutput)
	zu einer gro�en Abweichung f�hrt, ist auch der Fehler gro�. Abweichungen
	bei einer starken Neuronenaktivit�t f�hren hingegen zu einem kleineren
	Fehler. */


	return variance*variance;
}

float CNeuron::Calculate_Error_WithUserDefFunction(float desiredNeuronOutput)
{
	if (UsedAsInputNeuron == true)
	{
		ErrorValue = 0.0f;
		return 0.0f;
	}

	// Abweichung:
	float variance = desiredNeuronOutput - NeuronOutput;
	ErrorValue = variance * pUserDefErrorFunction(NeuronOutput);

	return variance*variance;
}

void CNeuron::Calculate_Error(void)
{
	if (UsedAsInputNeuron == true)
	{
		ErrorValue = 0.0f;
		return;
	}


	uint32_t receiverNeuronID;

	float errorSum = 0.0f;

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		receiverNeuronID = pReceiverNeuronIDArray[i];
		errorSum += pUsedNeuronArray[receiverNeuronID].ErrorValue * pOutputSynapsePlasticityArray[i];
	}

	ErrorValue = errorSum * ErrorFactor1 * exp(-(ErrorFactor2 * NeuronOutput * NeuronOutput));

	/* Hinweis: Abweichungen bei einer geringen Neuronenaktivit�t f�hren
	zu einem gr��eren Fehler. Abweichungen bei einer starken Neuronenaktivit�t
	f�hren hingegen zu einem kleineren Fehler. */
}

void CNeuron::Calculate_Error_WithUserDefFunction(void)
{
	if (UsedAsInputNeuron == true)
	{
		ErrorValue = 0.0f;
		return;
	}


	uint32_t receiverNeuronID;

	float errorSum = 0.0f;

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		receiverNeuronID = pReceiverNeuronIDArray[i];
		errorSum += pUsedNeuronArray[receiverNeuronID].ErrorValue * pOutputSynapsePlasticityArray[i];
	}

	ErrorValue = errorSum * pUserDefErrorFunction(NeuronOutput);

	
}


void CNeuron::Remove_Unused_Connections(void)
{
	/*uint32_t counter = 0;

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		if (pOutputSynapsePlasticityArray[i] == 0.0f)
			counter++;
	}

	
	uint32_t numOfUsedConnections = NumOfOutputSynapses - counter;

	float *pTempPlasticityArray = new (std::nothrow) float[numOfUsedConnections];
	uint32_t *pTempReceiverNeuronIDArray = new (std::nothrow) uint32_t[numOfUsedConnections];

	counter = 0;*/

	uint32_t numOfUsedConnections = 0;

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		if (pOutputSynapsePlasticityArray[i] != 0.0f)
			numOfUsedConnections++;
	}

	float *pTempPlasticityArray = new (std::nothrow) float[numOfUsedConnections];
	uint32_t *pTempReceiverNeuronIDArray = new (std::nothrow) uint32_t[numOfUsedConnections];

	uint32_t counter = 0;

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		if (pOutputSynapsePlasticityArray[i] != 0.0f)
		{
			pTempPlasticityArray[counter] = pOutputSynapsePlasticityArray[i];
			pTempReceiverNeuronIDArray[counter] = pReceiverNeuronIDArray[i];

			counter++;
		}
	}

	delete[] pOutputSynapsePlasticityArray;
	pOutputSynapsePlasticityArray = nullptr;

	delete[] pReceiverNeuronIDArray;
	pReceiverNeuronIDArray = nullptr;

	NumOfOutputSynapses = numOfUsedConnections;

	pOutputSynapsePlasticityArray = new (std::nothrow) float[NumOfOutputSynapses];
	pReceiverNeuronIDArray = new (std::nothrow) uint32_t[NumOfOutputSynapses];

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		pOutputSynapsePlasticityArray[i] = pTempPlasticityArray[i];
		pReceiverNeuronIDArray[i] = pTempReceiverNeuronIDArray[i];
	}

	delete[] pTempReceiverNeuronIDArray;
	pTempReceiverNeuronIDArray = nullptr;

	delete[] pTempPlasticityArray;
	pTempPlasticityArray = nullptr;
}

void CNeuron::Round_OutputWeights(float precision, float invPrecision)
{
	float fValue;
	int32_t iValue;

	
	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		iValue = static_cast<int32_t>(invPrecision * pOutputSynapsePlasticityArray[i]);
		fValue = static_cast<float>(iValue);
		fValue *= precision;

		pOutputSynapsePlasticityArray[i] = fValue;
	}
}

void CNeuron::Adjust_OutputSynapses_AfterErrorCalculations(void)
{
	if (UsedAsOutputNeuron == true)
		return;

	uint32_t receiverNeuronID;

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		receiverNeuronID = pReceiverNeuronIDArray[i];
		pOutputSynapsePlasticityArray[i] += LearningRate * pUsedNeuronArray[receiverNeuronID].ErrorValue * NeuronOutput;
	}
}

void CNeuron::Adjust_OutputSynapse_AfterErrorCalculations(uint32_t synapseID)
{
	if (UsedAsOutputNeuron == true)
		return;

	uint32_t receiverNeuronID = pReceiverNeuronIDArray[synapseID];
	pOutputSynapsePlasticityArray[synapseID] += LearningRate * pUsedNeuronArray[receiverNeuronID].ErrorValue * NeuronOutput;
}

void CNeuron::Adjust_OutputSynapse_AfterErrorCalculations2(uint32_t receiverNeuronID)
{
	if (UsedAsOutputNeuron == true)
		return;

	uint32_t synapseID = 0;

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		if (pReceiverNeuronIDArray[i] == receiverNeuronID)
		{
			synapseID = i;
			break;
		}
	}

	pOutputSynapsePlasticityArray[synapseID] += LearningRate * pUsedNeuronArray[receiverNeuronID].ErrorValue * NeuronOutput;
}

void CNeuron::Adjust_OutputSynapses_AfterErrorCalculationsExt(void)
{
	if (UsedAsOutputNeuron == true)
		return;

	uint32_t receiverNeuronID;

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		receiverNeuronID = pReceiverNeuronIDArray[i];
		//pOutputSynapsePlasticityArray[i] += LearningRate * (RandomNumbers.Get_FloatNumber(constMinRandomOutputSynapsePlasticity, constMaxRandomOutputSynapsePlasticity) + pUsedNeuronArray[receiverNeuronID].ErrorValue * NeuronOutput);
		pOutputSynapsePlasticityArray[i] += LearningRate * (pUsedNeuronArray[receiverNeuronID].ErrorValue + RandomNumbers.Get_FloatNumber(constMinRandomOutputSynapsePlasticity, constMaxRandomOutputSynapsePlasticity)) * NeuronOutput;
	}
}

void CNeuron::Adjust_OutputSynapse_AfterErrorCalculationsExt(uint32_t synapseID)
{
	if (UsedAsOutputNeuron == true)
		return;

	uint32_t receiverNeuronID = pReceiverNeuronIDArray[synapseID];
	//pOutputSynapsePlasticityArray[synapseID] += LearningRate * (RandomNumbers.Get_FloatNumber(constMinRandomOutputSynapsePlasticity, constMaxRandomOutputSynapsePlasticity) + pUsedNeuronArray[receiverNeuronID].ErrorValue * NeuronOutput);
	pOutputSynapsePlasticityArray[synapseID] += LearningRate * (pUsedNeuronArray[receiverNeuronID].ErrorValue + RandomNumbers.Get_FloatNumber(constMinRandomOutputSynapsePlasticity, constMaxRandomOutputSynapsePlasticity)) * NeuronOutput;
}

void CNeuron::Adjust_OutputSynapse_AfterErrorCalculationsExt2(uint32_t receiverNeuronID)
{
	if (UsedAsOutputNeuron == true)
		return;

	uint32_t synapseID = 0;

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		if (pReceiverNeuronIDArray[i] == receiverNeuronID)
		{
			synapseID = i;
			break;
		}
	}

	//pOutputSynapsePlasticityArray[synapseID] += LearningRate * (RandomNumbers.Get_FloatNumber(constMinRandomOutputSynapsePlasticity, constMaxRandomOutputSynapsePlasticity) + pUsedNeuronArray[receiverNeuronID].ErrorValue * NeuronOutput);
	pOutputSynapsePlasticityArray[synapseID] += LearningRate * (pUsedNeuronArray[receiverNeuronID].ErrorValue + RandomNumbers.Get_FloatNumber(constMinRandomOutputSynapsePlasticity, constMaxRandomOutputSynapsePlasticity)) * NeuronOutput;
}


void CNeuron::Set_DropoutState(bool state)
{
	Dropout = state;
}

void CNeuron::Clone(const CNeuron &originalObject)
{
	delete[] pOutputSynapsePlasticityArray;
	pOutputSynapsePlasticityArray = nullptr;

	delete[] pOutputSynapseMinBlockingValueArray;
	pOutputSynapseMinBlockingValueArray = nullptr;

	delete[] pOutputSynapseMaxBlockingValueArray;
	pOutputSynapseMaxBlockingValueArray = nullptr;

	delete[] pReceiverNeuronIDArray;
	pReceiverNeuronIDArray = nullptr;

	Dropout = originalObject.Dropout;
	UsedAsInputNeuron = originalObject.UsedAsInputNeuron;
	UsedAsHiddenNeuron = originalObject.UsedAsHiddenNeuron;
	UsedAsOutputNeuron = originalObject.UsedAsOutputNeuron;
	UsedAsBiasNeuron = originalObject.UsedAsBiasNeuron;
	UsedAsMemoryNeuron = originalObject.UsedAsMemoryNeuron;

	NeuronInput = originalObject.NeuronInput;
	NeuronOutput = originalObject.NeuronOutput;
	NeuronOutput_LastCalculationStep = originalObject.NeuronOutput_LastCalculationStep;

	ErrorValue = originalObject.ErrorValue;
	ErrorFactor1 = originalObject.ErrorFactor1;
	ErrorFactor2 = originalObject.ErrorFactor2;

	LearningRate = originalObject.LearningRate;

	pActivationFunction = originalObject.pActivationFunction;

	NumOfOutputSynapses = originalObject.NumOfOutputSynapses;
	pOutputSynapsePlasticityArray = new (std::nothrow) float[NumOfOutputSynapses];
	pOutputSynapseMinBlockingValueArray = new (std::nothrow) float[NumOfOutputSynapses];
	pOutputSynapseMaxBlockingValueArray = new (std::nothrow) float[NumOfOutputSynapses];
	pReceiverNeuronIDArray = new (std::nothrow) uint32_t[NumOfOutputSynapses];

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		pOutputSynapsePlasticityArray[i] = originalObject.pOutputSynapsePlasticityArray[i];
		pOutputSynapseMinBlockingValueArray[i] = originalObject.pOutputSynapseMinBlockingValueArray[i];
		pOutputSynapseMaxBlockingValueArray[i] = originalObject.pOutputSynapseMaxBlockingValueArray[i];
		pReceiverNeuronIDArray[i] = originalObject.pReceiverNeuronIDArray[i];
	}
}

void CNeuron::Clone_Data(const CNeuron &originalObject)
{
	Dropout = originalObject.Dropout;

	UsedAsInputNeuron = originalObject.UsedAsInputNeuron;
	UsedAsHiddenNeuron = originalObject.UsedAsHiddenNeuron;
	UsedAsOutputNeuron = originalObject.UsedAsOutputNeuron;
	UsedAsBiasNeuron = originalObject.UsedAsBiasNeuron;
	UsedAsMemoryNeuron = originalObject.UsedAsMemoryNeuron;

	NeuronInput = originalObject.NeuronInput;
	NeuronOutput = originalObject.NeuronOutput;
	NeuronOutput_LastCalculationStep = originalObject.NeuronOutput_LastCalculationStep;

	ErrorValue = originalObject.ErrorValue;
	ErrorFactor1 = originalObject.ErrorFactor1;
	ErrorFactor2 = originalObject.ErrorFactor2;

	LearningRate = originalObject.LearningRate;

	pActivationFunction = originalObject.pActivationFunction;

	NumOfOutputSynapses = originalObject.NumOfOutputSynapses;
	

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		pOutputSynapsePlasticityArray[i] = originalObject.pOutputSynapsePlasticityArray[i];
		pOutputSynapseMinBlockingValueArray[i] = originalObject.pOutputSynapseMinBlockingValueArray[i];
		pOutputSynapseMaxBlockingValueArray[i] = originalObject.pOutputSynapseMaxBlockingValueArray[i];
		pReceiverNeuronIDArray[i] = originalObject.pReceiverNeuronIDArray[i];
	}
}


CLongTermMemoryNeuron::CLongTermMemoryNeuron()
{}

CLongTermMemoryNeuron::~CLongTermMemoryNeuron()
{
	delete[] pSynapsePlasticityArray;
	pSynapsePlasticityArray = nullptr;
}

void CLongTermMemoryNeuron::Init_Neuron(uint32_t numOfMemorySynapses)
{
	delete[] pSynapsePlasticityArray;
	pSynapsePlasticityArray = nullptr;

	Activity = 0.0f;

	Counter = 0.0f;
	InvCounter = 1.0f;

	NumOfMemorySynapses = numOfMemorySynapses;
	NumOfMemorySynapsesPlus1 = numOfMemorySynapses + 1;

	pSynapsePlasticityArray = new (std::nothrow) float[NumOfMemorySynapsesPlus1];

	for (uint32_t i = 0; i < NumOfMemorySynapsesPlus1; i++)
		pSynapsePlasticityArray[i] = 0.0f;
}

void CLongTermMemoryNeuron::Connect_With_Brain(CNeuron* pNeuronArray)
{
	pUsedNeuronArray = pNeuronArray;
}

void CLongTermMemoryNeuron::Reduce_PlasticityValues(float decreaseValue, float minPlasticityValue)
{
	for (uint32_t i = 0; i < NumOfMemorySynapses; i++)
	{
		pSynapsePlasticityArray[i] -= decreaseValue;
		pSynapsePlasticityArray[i] = max(minPlasticityValue, pSynapsePlasticityArray[i]);
	}
}

void CLongTermMemoryNeuron::Reset_Memory(void)
{
	Counter = 0.0f;
	InvCounter = 1.0f;

	for (uint32_t i = 0; i < NumOfMemorySynapsesPlus1; i++)
		pSynapsePlasticityArray[i] = 0.0f;
}

void CLongTermMemoryNeuron::Add_MemoryValue(int32_t synapseID, float value)
{
	pSynapsePlasticityArray[synapseID] += value;
}

void CLongTermMemoryNeuron::Set_MemoryValue(int32_t synapseID, float value)
{
	pSynapsePlasticityArray[synapseID] = value;
}

float CLongTermMemoryNeuron::Get_MemoryValue(int32_t synapseID)
{
	return pSynapsePlasticityArray[synapseID];
}

void CLongTermMemoryNeuron::Update_Memory(int32_t synapseID, int32_t inputNeuronID, float learningRate)
{
	if (synapseID == 0)
	{
		Counter += 1.0f;
		InvCounter = 1.0f / Counter;
	}

	pSynapsePlasticityArray[synapseID] += learningRate*pUsedNeuronArray[inputNeuronID].NeuronOutput;
}




void CLongTermMemoryNeuron::Transfer_Plasticity_To_DestinationNeuron(int32_t synapseID, int32_t destinationNeuronID, int32_t destinationNeuronSynapseID, float plasticityMultiplier)
{
	pUsedNeuronArray[destinationNeuronID].pOutputSynapsePlasticityArray[destinationNeuronSynapseID] = plasticityMultiplier * pSynapsePlasticityArray[synapseID];
}

void CLongTermMemoryNeuron::Transfer_Plasticity_To_DestinationNeuron(int32_t synapseID, int32_t destinationNeuronID, int32_t destinationNeuronSynapseID)
{
	float plasticityMultiplier = InvCounter / static_cast<float>(NumOfMemorySynapses);
	pUsedNeuronArray[destinationNeuronID].pOutputSynapsePlasticityArray[destinationNeuronSynapseID] = plasticityMultiplier * pSynapsePlasticityArray[synapseID];
}






void CLongTermMemoryNeuron::Propagate_Memory(int32_t synapseID, int32_t receiverNeuronID)
{
	pUsedNeuronArray[receiverNeuronID].NeuronInput += Activity * pSynapsePlasticityArray[synapseID];
}


void CLongTermMemoryNeuron::Reset_Activity(void)
{
	Activity = 0.0f;
}

void CLongTermMemoryNeuron::Set_Activity(float value)
{
	Activity = value;
}


C2State2DCellularAutomatonRules::C2State2DCellularAutomatonRules()
{
	for (int32_t i = 0; i < 8; i++)
	{
		BirthRuleArray[i] = 0;
		SurvivingRuleArray[i] = 0;
	}
}

void C2State2DCellularAutomatonRules::Reset(void)
{
	NumBirthRules = 0;
	NumSurvivingRules = 0;

	for (int32_t i = 0; i < 8; i++)
	{
		BirthRuleArray[i] = 0;
		SurvivingRuleArray[i] = 0;
	}
}

C2DCellularAutomata::C2DCellularAutomata()
{}

C2DCellularAutomataF::C2DCellularAutomataF()
{}

C2DCellularAutomata::~C2DCellularAutomata()
{
	delete[] pCellMap1;
	pCellMap1 = nullptr;

	delete[] pCellMap2;
	pCellMap2 = nullptr;
}

C2DCellularAutomataF::~C2DCellularAutomataF()
{
	delete[] pCellMap1;
	pCellMap1 = nullptr;

	delete[] pCellMap2;
	pCellMap2 = nullptr;
}

void C2DCellularAutomata::Set_CellValue(int32_t cellIID, int32_t value)
{
	PtrToLastUpdatedCellMap[cellIID] = value;
}

void C2DCellularAutomataF::Set_CellValue(int32_t cellIID, float value)
{
	PtrToLastUpdatedCellMap[cellIID] = value;
}

void C2DCellularAutomata::Set_CellValue(int32_t cellPosX, int32_t cellPosY, int32_t value)
{
	PtrToLastUpdatedCellMap[cellPosX + cellPosY * NumCellsXDir] = value;
}

void C2DCellularAutomataF::Set_CellValue(int32_t cellPosX, int32_t cellPosY, float value)
{
	PtrToLastUpdatedCellMap[cellPosX + cellPosY * NumCellsXDir] = value;
}

int32_t C2DCellularAutomata::Get_CellValue(int32_t cellIID)
{
	return PtrToLastUpdatedCellMap[cellIID];
}

int32_t C2DCellularAutomata::Get_PrevCellValue(int32_t cellIID)
{
	if(PtrToLastUpdatedCellMap = pCellMap1)
		return pCellMap2[cellIID];
	else
		return pCellMap1[cellIID];
}


float C2DCellularAutomataF::Get_CellValue(int32_t cellIID)
{
	return PtrToLastUpdatedCellMap[cellIID];
}

float C2DCellularAutomataF::Get_PrevCellValue(int32_t cellIID)
{
	if (PtrToLastUpdatedCellMap = pCellMap1)
		return pCellMap2[cellIID];
	else
		return pCellMap1[cellIID];
}


int32_t C2DCellularAutomata::Get_CellValue(int32_t cellPosX, int32_t cellPosY)
{
	return PtrToLastUpdatedCellMap[cellPosX + cellPosY * NumCellsXDir];
}

int32_t C2DCellularAutomata::Get_PrevCellValue(int32_t cellPosX, int32_t cellPosY)
{
	if (PtrToLastUpdatedCellMap = pCellMap1)
		return pCellMap2[cellPosX + cellPosY * NumCellsXDir];
	else
		return pCellMap1[cellPosX + cellPosY * NumCellsXDir];
}

float C2DCellularAutomataF::Get_CellValue(int32_t cellPosX, int32_t cellPosY)
{
	return PtrToLastUpdatedCellMap[cellPosX + cellPosY * NumCellsXDir];
}

float C2DCellularAutomataF::Get_PrevCellValue(int32_t cellPosX, int32_t cellPosY)
{
	if (PtrToLastUpdatedCellMap = pCellMap1)
		return pCellMap2[cellPosX + cellPosY * NumCellsXDir];
	else
		return pCellMap1[cellPosX + cellPosY * NumCellsXDir];
}

void C2DCellularAutomata::Get_PtrToLastUpdatedCellMap(int32_t **ppOut)
{
	*ppOut = PtrToLastUpdatedCellMap;
}

void C2DCellularAutomataF::Get_PtrToLastUpdatedCellMap(float **ppOut)
{
	*ppOut = PtrToLastUpdatedCellMap;
}

void C2DCellularAutomata::Init_CellularAutomata(int32_t numCellsXDir, int32_t numCellsYDir)
{
	delete[] pCellMap1;
	pCellMap1 = nullptr;

	delete[] pCellMap2;
	pCellMap2 = nullptr;

	NumCellsXDir = numCellsXDir;
	NumCellsYDir = numCellsYDir;

	NumCellsXDirMinus1 = numCellsXDir - 1;
	NumCellsYDirMinus1 = numCellsYDir - 1;

	NumCells = numCellsXDir * numCellsYDir;

	pCellMap1 = new int32_t[NumCells];
	pCellMap2 = new int32_t[NumCells];

	int32_t ix, iy, id;

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			id = ix + iy * NumCellsXDir;

			pCellMap1[id] = Value_DeadCell;
			pCellMap2[id] = Value_DeadCell;
		}
	}

	PtrToLastUpdatedCellMap = pCellMap1;
}

void C2DCellularAutomataF::Init_CellularAutomata(int32_t numCellsXDir, int32_t numCellsYDir)
{
	delete[] pCellMap1;
	pCellMap1 = nullptr;

	delete[] pCellMap2;
	pCellMap2 = nullptr;

	NumCellsXDir = numCellsXDir;
	NumCellsYDir = numCellsYDir;

	NumCellsXDirMinus1 = numCellsXDir - 1;
	NumCellsYDirMinus1 = numCellsYDir - 1;

	NumCells = numCellsXDir * numCellsYDir;

	pCellMap1 = new float[NumCells];
	pCellMap2 = new float[NumCells];

	int32_t ix, iy, id;

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			id = ix + iy * NumCellsXDir;

			pCellMap1[id] = Value_DeadCell;
			pCellMap2[id] = Value_DeadCell;
		}
	}

	PtrToLastUpdatedCellMap = pCellMap1;
}

void C2DCellularAutomata::Reset_CellMap(int32_t cellValue)
{
	int32_t ix, iy, id;

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			id = ix + iy * NumCellsXDir;

			pCellMap1[id] = cellValue;
			pCellMap2[id] = cellValue;
		}
	}

	PtrToLastUpdatedCellMap = pCellMap1;
}

void C2DCellularAutomataF::Reset_CellMap(float cellValue)
{
	int32_t ix, iy, id;

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			id = ix + iy * NumCellsXDir;

			pCellMap1[id] = cellValue;
			pCellMap2[id] = cellValue;
		}
	}

	PtrToLastUpdatedCellMap = pCellMap1;
}

void C2DCellularAutomata::Kill_All_Cells(void)
{
	int32_t ix, iy, id;

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			id = ix + iy * NumCellsXDir;

			pCellMap1[id] = Value_DeadCell;
			pCellMap2[id] = Value_DeadCell;
		}
	}

	PtrToLastUpdatedCellMap = pCellMap1;
}

void C2DCellularAutomataF::Kill_All_Cells(void)
{
	int32_t ix, iy, id;

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			id = ix + iy * NumCellsXDir;

			pCellMap1[id] = Value_DeadCell;
			pCellMap2[id] = Value_DeadCell;
		}
	}

	PtrToLastUpdatedCellMap = pCellMap1;
}

void C2DCellularAutomata::Init_CellMap(CRandomNumbersNN *pRandomNumbers, int32_t minXPos, int32_t maxXPos, int32_t minYPos, int32_t maxYPos, int32_t densityValue, int32_t invDensity)
{
	/*minXPos = max(minXPos, 0);
	maxXPos = min(maxXPos, NumCellsXDir);

	minYPos = max(minYPos, 0);
	maxYPos = min(maxYPos, NumCellsYDir);*/

	int32_t ix, iy, id;

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			id = ix + iy * NumCellsXDir;

			pCellMap1[id] = Value_DeadCell;
			pCellMap2[id] = Value_DeadCell;
		}
	}

	for (iy = minYPos; iy < maxYPos; iy++)
	{
		for (ix = minXPos; ix < maxXPos; ix++)
		{
			if (pRandomNumbers->Get_IntegerNumber(0, invDensity) < densityValue)
			{
				id = ix + iy * NumCellsXDir;

				pCellMap1[id] = Value_LivingCell;
			}
		}
	}

	PtrToLastUpdatedCellMap = pCellMap1;
}

void C2DCellularAutomataF::Init_CellMap(CRandomNumbersNN *pRandomNumbers, int32_t minXPos, int32_t maxXPos, int32_t minYPos, int32_t maxYPos, int32_t densityValue, int32_t invDensity)
{
	/*minXPos = max(minXPos, 0);
	maxXPos = min(maxXPos, NumCellsXDir);

	minYPos = max(minYPos, 0);
	maxYPos = min(maxYPos, NumCellsYDir);*/

	int32_t ix, iy, id;

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			id = ix + iy * NumCellsXDir;

			pCellMap1[id] = Value_DeadCell;
			pCellMap2[id] = Value_DeadCell;
		}
	}

	for (iy = minYPos; iy < maxYPos; iy++)
	{
		for (ix = minXPos; ix < maxXPos; ix++)
		{
			if (pRandomNumbers->Get_IntegerNumber(0, invDensity) < densityValue)
			{
				id = ix + iy * NumCellsXDir;

				pCellMap1[id] = Value_LivingCell;
			}
		}
	}

	PtrToLastUpdatedCellMap = pCellMap1;
}

void C2DCellularAutomata::Init_CellMap(CRandomNumbersNN *pRandomNumbers, int32_t densityValue, int32_t invDensity)
{
	int32_t ix, iy, id;

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			id = ix + iy * NumCellsXDir;

			pCellMap1[id] = Value_DeadCell;
			pCellMap2[id] = Value_DeadCell;
		}
	}

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			if (pRandomNumbers->Get_IntegerNumber(0, invDensity) < densityValue)
			{
				id = ix + iy * NumCellsXDir;

				pCellMap1[id] = Value_LivingCell;
			}
		}
	}

	PtrToLastUpdatedCellMap = pCellMap1;
}

void C2DCellularAutomataF::Init_CellMap(CRandomNumbersNN *pRandomNumbers, int32_t densityValue, int32_t invDensity)
{
	int32_t ix, iy, id;

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			id = ix + iy * NumCellsXDir;

			pCellMap1[id] = Value_DeadCell;
			pCellMap2[id] = Value_DeadCell;
		}
	}

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			if (pRandomNumbers->Get_IntegerNumber(0, invDensity) < densityValue)
			{
				id = ix + iy * NumCellsXDir;

				pCellMap1[id] = Value_LivingCell;
			}
		}
	}

	PtrToLastUpdatedCellMap = pCellMap1;
}

void C2DCellularAutomata::Set_CellMapBoarderValue(int32_t value)
{
	int32_t ix;
	int32_t offset = NumCellsYDirMinus1 * NumCellsXDir;

	for (ix = 0; ix < NumCellsXDir; ix++)
	{
		PtrToLastUpdatedCellMap[ix] = value;
		PtrToLastUpdatedCellMap[ix + offset] = value;
	}

	int32_t iy, id;

	for (iy = 1; iy < NumCellsYDirMinus1; iy++)
	{
		id = iy * NumCellsXDir;
		PtrToLastUpdatedCellMap[id] = value;

		id += NumCellsXDirMinus1;
		PtrToLastUpdatedCellMap[id] = value;
	}
}

void C2DCellularAutomataF::Set_CellMapBoarderValue(float value)
{
	int32_t ix;
	int32_t offset = NumCellsYDirMinus1 * NumCellsXDir;

	for (ix = 0; ix < NumCellsXDir; ix++)
	{
		PtrToLastUpdatedCellMap[ix] = value;
		PtrToLastUpdatedCellMap[ix + offset] = value;
	}

	int32_t iy, id;

	for (iy = 1; iy < NumCellsYDirMinus1; iy++)
	{
		id = iy * NumCellsXDir;
		PtrToLastUpdatedCellMap[id] = value;

		id += NumCellsXDirMinus1;
		PtrToLastUpdatedCellMap[id] = value;
	}
}

void C2DCellularAutomata::Exchange_CellsValue(int32_t oldValue, int32_t newValue)
{
	int32_t ix, iy, id;

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			id = ix + iy * NumCellsXDir;

			if (PtrToLastUpdatedCellMap[id] == oldValue)
				PtrToLastUpdatedCellMap[id] = newValue;
		}
	}
}

void C2DCellularAutomataF::Exchange_CellsValue(float oldValue, float newValue)
{
	int32_t ix, iy, id;

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			id = ix + iy * NumCellsXDir;

			if (PtrToLastUpdatedCellMap[id] == oldValue)
				PtrToLastUpdatedCellMap[id] = newValue;
		}
	}
}

void C2DCellularAutomata::Exchange_LivingAndDeadCells(void)
{
	int32_t ix, iy, id;

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			id = ix + iy * NumCellsXDir;
			
			if (PtrToLastUpdatedCellMap[id] == Value_DeadCell)
				PtrToLastUpdatedCellMap[id] = Value_LivingCell;
			else
				PtrToLastUpdatedCellMap[id] = Value_DeadCell;
		}
	}
}

void C2DCellularAutomataF::Exchange_LivingAndDeadCells(void)
{
	int32_t ix, iy, id;

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			id = ix + iy * NumCellsXDir;

			if (PtrToLastUpdatedCellMap[id] == Value_DeadCell)
				PtrToLastUpdatedCellMap[id] = Value_LivingCell;
			else
				PtrToLastUpdatedCellMap[id] = Value_DeadCell;
		}
	}
}

void C2DCellularAutomata::Output_CellMap(void)
{
	int32_t ix, iy, id;

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			id = ix + iy * NumCellsXDir;
			cout << PtrToLastUpdatedCellMap[id] << " ";
		}

		cout << endl;
	}

	cout << endl << endl;
}

void C2DCellularAutomataF::Output_CellMap(void)
{
	int32_t ix, iy, id;

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			id = ix + iy * NumCellsXDir;
			cout << PtrToLastUpdatedCellMap[id] << " ";
		}

		cout << endl;
	}

	cout << endl << endl;
}

bool C2DCellularAutomata::Save_CellMap(const char* pFilename, int32_t valueLivingCell, int32_t valueDeadCell)
{
	std::ofstream WriteFile;

	// neue Datei erzeugen bzw. alte �berschreiben:
	WriteFile.open(pFilename);

	// neue Datei erzeugen bzw. Inhalt ans Ende einer bestehenden Datei schreiben: 
	//WriteFile.open(pFilename, ios::app);

	if (WriteFile.good() == false)
		return false;

	int32_t ix, iy, id;

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			id = ix + iy * NumCellsXDir;

			if (PtrToLastUpdatedCellMap[id] == Value_LivingCell)
				WriteFile << valueLivingCell << " ";
			else
				WriteFile << valueDeadCell << " ";
		}

		WriteFile << endl;
	}

	WriteFile.close();

	return true;
}

bool C2DCellularAutomataF::Save_CellMap(const char* pFilename, float valueLivingCell, float valueDeadCell)
{
	std::ofstream WriteFile;

	// neue Datei erzeugen bzw. alte �berschreiben:
	WriteFile.open(pFilename);

	// neue Datei erzeugen bzw. Inhalt ans Ende einer bestehenden Datei schreiben: 
	//WriteFile.open(pFilename, ios::app);

	if (WriteFile.good() == false)
		return false;

	int32_t ix, iy, id;

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			id = ix + iy * NumCellsXDir;

			if (PtrToLastUpdatedCellMap[id] == Value_LivingCell)
				WriteFile << valueLivingCell << " ";
			else
				WriteFile << valueDeadCell << " ";
		}

		WriteFile << endl;
	}

	WriteFile.close();

	return true;
}

bool C2DCellularAutomata::Save_CellMap(const char* pFilename)
{
	std::ofstream WriteFile;

	// neue Datei erzeugen bzw. alte �berschreiben:
	WriteFile.open(pFilename);

	// neue Datei erzeugen bzw. Inhalt ans Ende einer bestehenden Datei schreiben: 
	//WriteFile.open(pFilename, ios::app);

	if (WriteFile.good() == false)
		return false;

	int32_t ix, iy, id;

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			id = ix + iy * NumCellsXDir;

			WriteFile << PtrToLastUpdatedCellMap[id] << " ";
		}

		WriteFile <<  endl;
	}

	WriteFile.close();

	return true;
}

bool C2DCellularAutomataF::Save_CellMap(const char* pFilename)
{
	std::ofstream WriteFile;

	// neue Datei erzeugen bzw. alte �berschreiben:
	WriteFile.open(pFilename);

	// neue Datei erzeugen bzw. Inhalt ans Ende einer bestehenden Datei schreiben: 
	//WriteFile.open(pFilename, ios::app);

	if (WriteFile.good() == false)
		return false;

	int32_t ix, iy, id;

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			id = ix + iy * NumCellsXDir;

			WriteFile << PtrToLastUpdatedCellMap[id] << " ";
		}

		WriteFile << endl;
	}

	WriteFile.close();

	return true;
}

bool C2DCellularAutomata::Save_CellMapPattern(const char* pFilename, int32_t value)
{
	std::ofstream WriteFile;

	// neue Datei erzeugen bzw. alte �berschreiben:
	WriteFile.open(pFilename);

	// neue Datei erzeugen bzw. Inhalt ans Ende einer bestehenden Datei schreiben: 
	//WriteFile.open(pFilename, ios::app);

	if (WriteFile.good() == false)
		return false;

	int32_t ix, iy, id;

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			id = ix + iy * NumCellsXDir;
	
			WriteFile << value << " ";
			
		}

		WriteFile << endl;
	}

	WriteFile.close();

	return true;
}

bool C2DCellularAutomataF::Save_CellMapPattern(const char* pFilename, float value)
{
	std::ofstream WriteFile;

	// neue Datei erzeugen bzw. alte �berschreiben:
	WriteFile.open(pFilename);

	// neue Datei erzeugen bzw. Inhalt ans Ende einer bestehenden Datei schreiben: 
	//WriteFile.open(pFilename, ios::app);

	if (WriteFile.good() == false)
		return false;

	int32_t ix, iy, id;

	for (iy = 0; iy < NumCellsYDir; iy++)
	{
		for (ix = 0; ix < NumCellsXDir; ix++)
		{
			id = ix + iy * NumCellsXDir;

			WriteFile << value << " ";

		}

		WriteFile << endl;
	}

	WriteFile.close();

	return true;
}

void C2DCellularAutomata::Smooth_BorderlessCellMap(int32_t smoothingValue)
{
	int32_t ix, iy;
	int32_t iix, iiy;
	int32_t id;

	int32_t numOfAdjacentCells_Alive;

	if (PtrToLastUpdatedCellMap == pCellMap1)
	{
		for (iy = 0; iy < NumCellsYDir; iy++)
		{
			for (ix = 0; ix < NumCellsXDir; ix++)
			{
				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						id = ((ix + iix) % NumCellsXDir) + ((iy + iiy) % NumCellsYDir) * NumCellsXDir;

						if (pCellMap1[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = (ix % NumCellsXDir) + (iy % NumCellsYDir) * NumCellsXDir;

				if (pCellMap1[id] == Value_BlockingCell)
				{
					pCellMap2[id] = Value_BlockingCell;
					continue;
				}

				pCellMap2[id] = pCellMap1[id];

				if (numOfAdjacentCells_Alive < smoothingValue)
					pCellMap2[id] = Value_DeadCell;
			}
		}

		PtrToLastUpdatedCellMap = pCellMap2;
	}
	else if (PtrToLastUpdatedCellMap == pCellMap2)
	{
		for (iy = 0; iy < NumCellsYDir; iy++)
		{
			for (ix = 0; ix < NumCellsXDir; ix++)
			{
				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						id = ((ix + iix) % NumCellsXDir) + ((iy + iiy) % NumCellsYDir) * NumCellsXDir;
						
						if (pCellMap2[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = (ix % NumCellsXDir) + (iy % NumCellsYDir) * NumCellsXDir;

				if (pCellMap2[id] == Value_BlockingCell)
				{
					pCellMap1[id] = Value_BlockingCell;
					continue;
				}

				pCellMap1[id] = pCellMap2[id];

				if (numOfAdjacentCells_Alive < smoothingValue)
					pCellMap1[id] = Value_DeadCell;
			}
		}

		PtrToLastUpdatedCellMap = pCellMap1;
	}
}

void C2DCellularAutomataF::Smooth_BorderlessCellMap(int32_t smoothingValue)
{
	int32_t ix, iy;
	int32_t iix, iiy;
	int32_t id;

	int32_t numOfAdjacentCells_Alive;

	if (PtrToLastUpdatedCellMap == pCellMap1)
	{
		for (iy = 0; iy < NumCellsYDir; iy++)
		{
			for (ix = 0; ix < NumCellsXDir; ix++)
			{
				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						id = ((ix + iix) % NumCellsXDir) + ((iy + iiy) % NumCellsYDir) * NumCellsXDir;

						if (pCellMap1[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = (ix % NumCellsXDir) + (iy % NumCellsYDir) * NumCellsXDir;

				if (pCellMap1[id] == Value_BlockingCell)
				{
					pCellMap2[id] = Value_BlockingCell;
					continue;
				}

				pCellMap2[id] = pCellMap1[id];

				if (numOfAdjacentCells_Alive < smoothingValue)
					pCellMap2[id] = Value_DeadCell;
			}
		}

		PtrToLastUpdatedCellMap = pCellMap2;
	}
	else if (PtrToLastUpdatedCellMap == pCellMap2)
	{
		for (iy = 0; iy < NumCellsYDir; iy++)
		{
			for (ix = 0; ix < NumCellsXDir; ix++)
			{
				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						id = ((ix + iix) % NumCellsXDir) + ((iy + iiy) % NumCellsYDir) * NumCellsXDir;

						if (pCellMap2[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = (ix % NumCellsXDir) + (iy % NumCellsYDir) * NumCellsXDir;

				if (pCellMap2[id] == Value_BlockingCell)
				{
					pCellMap1[id] = Value_BlockingCell;
					continue;
				}

				pCellMap1[id] = pCellMap2[id];

				if (numOfAdjacentCells_Alive < smoothingValue)
					pCellMap1[id] = Value_DeadCell;
			}
		}

		PtrToLastUpdatedCellMap = pCellMap1;
	}
}

void C2DCellularAutomata::Detect_Edges(int32_t valueEdgeCell)
{
	int32_t ix, iy;
	int32_t iix, iiy;
	int32_t id;

	int32_t numOfAdjacentCells_Alive;

	if (PtrToLastUpdatedCellMap == pCellMap1)
	{
		for (iy = 1; iy < NumCellsYDirMinus1; iy++)
		{
			for (ix = 1; ix < NumCellsXDirMinus1; ix++)
			{

				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						id = ix + iix + (iy + iiy) * NumCellsXDir;

						if (pCellMap1[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = ix + iy * NumCellsXDir;

				if (pCellMap1[id] == Value_BlockingCell)
				{
					pCellMap2[id] = Value_BlockingCell;
					continue;
				}

				if (pCellMap1[id] == Value_DeadCell)
				{
					pCellMap2[id] = Value_DeadCell;
					continue;
				}

				pCellMap2[id] = pCellMap1[id];

				if (numOfAdjacentCells_Alive < 8)
					pCellMap2[id] = valueEdgeCell;
			}
		}

		PtrToLastUpdatedCellMap = pCellMap2;
	}
	else if (PtrToLastUpdatedCellMap == pCellMap2)
	{
		for (iy = 1; iy < NumCellsYDirMinus1; iy++)
		{
			for (ix = 1; ix < NumCellsXDirMinus1; ix++)
			{

				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						id = ix + iix + (iy + iiy) * NumCellsXDir;

						if (pCellMap2[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = ix + iy * NumCellsXDir;

				if (pCellMap2[id] == Value_BlockingCell)
				{
					pCellMap1[id] = Value_BlockingCell;
					continue;
				}

				if (pCellMap2[id] == Value_DeadCell)
				{
					pCellMap1[id] = Value_DeadCell;
					continue;
				}

				pCellMap1[id] = pCellMap2[id];

				if (numOfAdjacentCells_Alive < 8)
					pCellMap1[id] = valueEdgeCell;
			}
		}

		PtrToLastUpdatedCellMap = pCellMap1;
	}
}

void C2DCellularAutomata::Detect_Edges2(int32_t valueNonEdgeCell)
{
	int32_t ix, iy;
	int32_t iix, iiy;
	int32_t id;

	int32_t numOfAdjacentCells_Alive;

	if (PtrToLastUpdatedCellMap == pCellMap1)
	{
		for (iy = 1; iy < NumCellsYDirMinus1; iy++)
		{
			for (ix = 1; ix < NumCellsXDirMinus1; ix++)
			{

				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						id = ix + iix + (iy + iiy) * NumCellsXDir;

						if (pCellMap1[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = ix + iy * NumCellsXDir;

				if (pCellMap1[id] == Value_BlockingCell)
				{
					pCellMap2[id] = Value_BlockingCell;
					continue;
				}

				if (pCellMap1[id] == Value_DeadCell)
				{
					pCellMap2[id] = Value_DeadCell;
					continue;
				}

				pCellMap2[id] = pCellMap1[id];

				if (numOfAdjacentCells_Alive == 8)
					pCellMap2[id] = valueNonEdgeCell;
			}
		}

		PtrToLastUpdatedCellMap = pCellMap2;
	}
	else if (PtrToLastUpdatedCellMap == pCellMap2)
	{
		for (iy = 1; iy < NumCellsYDirMinus1; iy++)
		{
			for (ix = 1; ix < NumCellsXDirMinus1; ix++)
			{

				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						id = ix + iix + (iy + iiy) * NumCellsXDir;

						if (pCellMap2[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = ix + iy * NumCellsXDir;

				if (pCellMap2[id] == Value_BlockingCell)
				{
					pCellMap1[id] = Value_BlockingCell;
					continue;
				}

				if (pCellMap2[id] == Value_DeadCell)
				{
					pCellMap1[id] = Value_DeadCell;
					continue;
				}

				pCellMap1[id] = pCellMap2[id];

				if (numOfAdjacentCells_Alive == 8)
					pCellMap1[id] = valueNonEdgeCell;
			}
		}

		PtrToLastUpdatedCellMap = pCellMap1;
	}
}

void C2DCellularAutomataF::Detect_Edges2(float valueNonEdgeCell)
{
	int32_t ix, iy;
	int32_t iix, iiy;
	int32_t id;

	int32_t numOfAdjacentCells_Alive;

	if (PtrToLastUpdatedCellMap == pCellMap1)
	{
		for (iy = 1; iy < NumCellsYDirMinus1; iy++)
		{
			for (ix = 1; ix < NumCellsXDirMinus1; ix++)
			{

				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						id = ix + iix + (iy + iiy) * NumCellsXDir;

						if (pCellMap1[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = ix + iy * NumCellsXDir;

				if (pCellMap1[id] == Value_BlockingCell)
				{
					pCellMap2[id] = Value_BlockingCell;
					continue;
				}

				if (pCellMap1[id] == Value_DeadCell)
				{
					pCellMap2[id] = Value_DeadCell;
					continue;
				}

				pCellMap2[id] = pCellMap1[id];

				if (numOfAdjacentCells_Alive == 8)
					pCellMap2[id] = valueNonEdgeCell;
			}
		}

		PtrToLastUpdatedCellMap = pCellMap2;
	}
	else if (PtrToLastUpdatedCellMap == pCellMap2)
	{
		for (iy = 1; iy < NumCellsYDirMinus1; iy++)
		{
			for (ix = 1; ix < NumCellsXDirMinus1; ix++)
			{

				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						id = ix + iix + (iy + iiy) * NumCellsXDir;

						if (pCellMap2[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = ix + iy * NumCellsXDir;

				if (pCellMap2[id] == Value_BlockingCell)
				{
					pCellMap1[id] = Value_BlockingCell;
					continue;
				}

				if (pCellMap2[id] == Value_DeadCell)
				{
					pCellMap1[id] = Value_DeadCell;
					continue;
				}

				pCellMap1[id] = pCellMap2[id];

				if (numOfAdjacentCells_Alive == 8)
					pCellMap1[id] = valueNonEdgeCell;
			}
		}

		PtrToLastUpdatedCellMap = pCellMap1;
	}
}

void C2DCellularAutomataF::Detect_Edges(float valueEdgeCell)
{
	int32_t ix, iy;
	int32_t iix, iiy;
	int32_t id;

	int32_t numOfAdjacentCells_Alive;

	if (PtrToLastUpdatedCellMap == pCellMap1)
	{
		for (iy = 1; iy < NumCellsYDirMinus1; iy++)
		{
			for (ix = 1; ix < NumCellsXDirMinus1; ix++)
			{

				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						id = ix + iix + (iy + iiy) * NumCellsXDir;

						if (pCellMap1[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = ix + iy * NumCellsXDir;

				if (pCellMap1[id] == Value_BlockingCell)
				{
					pCellMap2[id] = Value_BlockingCell;
					continue;
				}

				if (pCellMap1[id] == Value_DeadCell)
				{
					pCellMap2[id] = Value_DeadCell;
					continue;
				}

				pCellMap2[id] = pCellMap1[id];

				if (numOfAdjacentCells_Alive < 8)
					pCellMap2[id] = valueEdgeCell;
			}
		}

		PtrToLastUpdatedCellMap = pCellMap2;
	}
	else if (PtrToLastUpdatedCellMap == pCellMap2)
	{
		for (iy = 1; iy < NumCellsYDirMinus1; iy++)
		{
			for (ix = 1; ix < NumCellsXDirMinus1; ix++)
			{

				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						id = ix + iix + (iy + iiy) * NumCellsXDir;

						if (pCellMap2[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = ix + iy * NumCellsXDir;

				if (pCellMap2[id] == Value_BlockingCell)
				{
					pCellMap1[id] = Value_BlockingCell;
					continue;
				}

				if (pCellMap2[id] == Value_DeadCell)
				{
					pCellMap1[id] = Value_DeadCell;
					continue;
				}

				pCellMap1[id] = pCellMap2[id];

				if (numOfAdjacentCells_Alive < 8)
					pCellMap1[id] = valueEdgeCell;
			}
		}

		PtrToLastUpdatedCellMap = pCellMap1;
	}
}

void C2DCellularAutomata::Smooth_CellMap(int32_t smoothingValue)
{
	int32_t ix, iy;
	int32_t iix, iiy;
	int32_t id;

	int32_t numOfAdjacentCells_Alive;

	if (PtrToLastUpdatedCellMap == pCellMap1)
	{
		for (iy = 1; iy < NumCellsYDirMinus1; iy++)
		{
			for (ix = 1; ix < NumCellsXDirMinus1; ix++)
			{

				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						id = ix + iix + (iy + iiy) * NumCellsXDir;

						if (pCellMap1[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = ix + iy * NumCellsXDir;

				if (pCellMap1[id] == Value_BlockingCell)
				{
					pCellMap2[id] = Value_BlockingCell;
					continue;
				}

				pCellMap2[id] = pCellMap1[id];

				if (numOfAdjacentCells_Alive < smoothingValue)
					pCellMap2[id] = Value_DeadCell;
			}
		}

		PtrToLastUpdatedCellMap = pCellMap2;
	}
	else if (PtrToLastUpdatedCellMap == pCellMap2)
	{
		for (iy = 1; iy < NumCellsYDirMinus1; iy++)
		{
			for (ix = 1; ix < NumCellsXDirMinus1; ix++)
			{

				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						id = ix + iix + (iy + iiy) * NumCellsXDir;

						if (pCellMap2[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = ix + iy * NumCellsXDir;

				if (pCellMap2[id] == Value_BlockingCell)
				{
					pCellMap1[id] = Value_BlockingCell;
					continue;
				}

				pCellMap1[id] = pCellMap2[id];

				if (numOfAdjacentCells_Alive < smoothingValue)
					pCellMap1[id] = Value_DeadCell;
			}
		}

		PtrToLastUpdatedCellMap = pCellMap1;
	}
}

void C2DCellularAutomataF::Smooth_CellMap(int32_t smoothingValue)
{
	int32_t ix, iy;
	int32_t iix, iiy;
	int32_t id;

	int32_t numOfAdjacentCells_Alive;

	if (PtrToLastUpdatedCellMap == pCellMap1)
	{
		for (iy = 1; iy < NumCellsYDirMinus1; iy++)
		{
			for (ix = 1; ix < NumCellsXDirMinus1; ix++)
			{

				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						id = ix + iix + (iy + iiy) * NumCellsXDir;

						if (pCellMap1[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = ix + iy * NumCellsXDir;

				if (pCellMap1[id] == Value_BlockingCell)
				{
					pCellMap2[id] = Value_BlockingCell;
					continue;
				}

				pCellMap2[id] = pCellMap1[id];

				if (numOfAdjacentCells_Alive < smoothingValue)
					pCellMap2[id] = Value_DeadCell;
			}
		}

		PtrToLastUpdatedCellMap = pCellMap2;
	}
	else if (PtrToLastUpdatedCellMap == pCellMap2)
	{
		for (iy = 1; iy < NumCellsYDirMinus1; iy++)
		{
			for (ix = 1; ix < NumCellsXDirMinus1; ix++)
			{

				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						id = ix + iix + (iy + iiy) * NumCellsXDir;

						if (pCellMap2[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = ix + iy * NumCellsXDir;

				if (pCellMap2[id] == Value_BlockingCell)
				{
					pCellMap1[id] = Value_BlockingCell;
					continue;
				}

				pCellMap1[id] = pCellMap2[id];

				if (numOfAdjacentCells_Alive < smoothingValue)
					pCellMap1[id] = Value_DeadCell;
			}
		}

		PtrToLastUpdatedCellMap = pCellMap1;
	}
}

void C2DCellularAutomata::Update_CellMap(C2State2DCellularAutomatonRules *pRules)
{
	int32_t ix, iy;
	int32_t iix, iiy;
	int32_t i;
	int32_t id;

	int32_t numOfAdjacentCells_Alive;

	if (PtrToLastUpdatedCellMap == pCellMap1)
	{
		for (iy = 1; iy < NumCellsYDirMinus1; iy++)
		{
			for (ix = 1; ix < NumCellsXDirMinus1; ix++)
			{

				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						id = ix + iix + (iy + iiy) * NumCellsXDir;

						if (pCellMap1[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = ix + iy * NumCellsXDir;

				if (pCellMap1[id] == Value_BlockingCell)
				{
					pCellMap2[id] = Value_BlockingCell;
					continue;
				}

				// apply surviving rules:
				if (pCellMap1[id] == Value_LivingCell)
				{
					pCellMap2[id] = Value_DeadCell;

					for (i = 0; i < pRules->NumSurvivingRules; i++)
					{
						if (numOfAdjacentCells_Alive == pRules->SurvivingRuleArray[i])
						{
							pCellMap2[id] = Value_LivingCell;
							break;
						}
					}
				}

				// apply birth rules:
				else if (pCellMap1[id] == Value_DeadCell)
				{
					pCellMap2[id] = Value_DeadCell;

					for (i = 0; i < pRules->NumBirthRules; i++)
					{
						if (numOfAdjacentCells_Alive == pRules->BirthRuleArray[i])
						{
							pCellMap2[id] = Value_LivingCell;
							break;
						}
					}
				}
			}
		}

		PtrToLastUpdatedCellMap = pCellMap2;
	}
	else if (PtrToLastUpdatedCellMap == pCellMap2)
	{
		for (iy = 1; iy < NumCellsYDirMinus1; iy++)
		{
			for (ix = 1; ix < NumCellsXDirMinus1; ix++)
			{
				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						id = ix + iix + (iy + iiy) * NumCellsXDir;

						if (pCellMap2[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = ix + iy * NumCellsXDir;

				if (pCellMap2[id] == Value_BlockingCell)
				{
					pCellMap1[id] = Value_BlockingCell;
					continue;
				}

				// apply surviving rules:
				if (pCellMap2[id] == Value_LivingCell)
				{
					pCellMap1[id] = Value_DeadCell;

					for (i = 0; i < pRules->NumSurvivingRules; i++)
					{
						if (numOfAdjacentCells_Alive == pRules->SurvivingRuleArray[i])
						{
							pCellMap1[id] = Value_LivingCell;
							break;
						}
					}
				}

				// apply birth rules:
				else if (pCellMap2[id] == Value_DeadCell)
				{
					pCellMap1[id] = Value_DeadCell;

					for (i = 0; i < pRules->NumBirthRules; i++)
					{
						if (numOfAdjacentCells_Alive == pRules->BirthRuleArray[i])
						{
							pCellMap1[id] = Value_LivingCell;
							break;
						}
					}
				}
			}
		}

		PtrToLastUpdatedCellMap = pCellMap1;
	}
}

void C2DCellularAutomata::Update_BorderlessCellMap(C2State2DCellularAutomatonRules *pRules)
{
	int32_t ix, iy;
	int32_t iix, iiy;
	int32_t i;
	int32_t id;

	int32_t numOfAdjacentCells_Alive;

	if (PtrToLastUpdatedCellMap == pCellMap1)
	{
		for (iy = 0; iy < NumCellsYDir; iy++)
		{
			for (ix = 0; ix < NumCellsXDir; ix++)
			{

				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						
						id = ((ix + iix) % NumCellsXDir) + ((iy + iiy) % NumCellsYDir) * NumCellsXDir;

						if (pCellMap1[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = (ix % NumCellsXDir) + (iy % NumCellsYDir) * NumCellsXDir;

				if (pCellMap1[id] == Value_BlockingCell)
				{
					pCellMap2[id] = Value_BlockingCell;
					continue;
				}

				// apply surviving rules:
				if (pCellMap1[id] == Value_LivingCell)
				{
					pCellMap2[id] = Value_DeadCell;

					for (i = 0; i < pRules->NumSurvivingRules; i++)
					{
						if (numOfAdjacentCells_Alive == pRules->SurvivingRuleArray[i])
						{
							pCellMap2[id] = Value_LivingCell;
							break;
						}
					}
				}

				// apply birth rules:
				else if (pCellMap1[id] == Value_DeadCell)
				{
					pCellMap2[id] = Value_DeadCell;

					for (i = 0; i < pRules->NumBirthRules; i++)
					{
						if (numOfAdjacentCells_Alive == pRules->BirthRuleArray[i])
						{
							pCellMap2[id] = Value_LivingCell;
							break;
						}
					}
				}
			}
		}

		PtrToLastUpdatedCellMap = pCellMap2;
	}
	else if (PtrToLastUpdatedCellMap == pCellMap2)
	{
		for (iy = 0; iy < NumCellsYDir; iy++)
		{
			for (ix = 0; ix < NumCellsXDir; ix++)
			{
				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						id = ((ix + iix) % NumCellsXDir) + ((iy + iiy) % NumCellsYDir) * NumCellsXDir;

						if (pCellMap2[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = (ix % NumCellsXDir) + (iy % NumCellsYDir) * NumCellsXDir;

				if (pCellMap2[id] == Value_BlockingCell)
				{
					pCellMap1[id] = Value_BlockingCell;
					continue;
				}

				// apply surviving rules:
				if (pCellMap2[id] == Value_LivingCell)
				{
					pCellMap1[id] = Value_DeadCell;

					for (i = 0; i < pRules->NumSurvivingRules; i++)
					{
						if (numOfAdjacentCells_Alive == pRules->SurvivingRuleArray[i])
						{
							pCellMap1[id] = Value_LivingCell;
							break;
						}
					}
				}

				// apply birth rules:
				else if (pCellMap2[id] == Value_DeadCell)
				{
					pCellMap1[id] = Value_DeadCell;

					for (i = 0; i < pRules->NumBirthRules; i++)
					{
						if (numOfAdjacentCells_Alive == pRules->BirthRuleArray[i])
						{
							pCellMap1[id] = Value_LivingCell;
							break;
						}
					}
				}
			}
		}

		PtrToLastUpdatedCellMap = pCellMap1;
	}
}

void C2DCellularAutomataF::Update_BorderlessCellMap(C2State2DCellularAutomatonRules *pRules)
{
	int32_t ix, iy;
	int32_t iix, iiy;
	int32_t i;
	int32_t id;

	int32_t numOfAdjacentCells_Alive;

	if (PtrToLastUpdatedCellMap == pCellMap1)
	{
		for (iy = 0; iy < NumCellsYDir; iy++)
		{
			for (ix = 0; ix < NumCellsXDir; ix++)
			{

				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;


						id = ((ix + iix) % NumCellsXDir) + ((iy + iiy) % NumCellsYDir) * NumCellsXDir;

						if (pCellMap1[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = (ix % NumCellsXDir) + (iy % NumCellsYDir) * NumCellsXDir;

				if (pCellMap1[id] == Value_BlockingCell)
				{
					pCellMap2[id] = Value_BlockingCell;
					continue;
				}

				// apply surviving rules:
				if (pCellMap1[id] == Value_LivingCell)
				{
					pCellMap2[id] = Value_DeadCell;

					for (i = 0; i < pRules->NumSurvivingRules; i++)
					{
						if (numOfAdjacentCells_Alive == pRules->SurvivingRuleArray[i])
						{
							pCellMap2[id] = Value_LivingCell;
							break;
						}
					}
				}

				// apply birth rules:
				else if (pCellMap1[id] == Value_DeadCell)
				{
					pCellMap2[id] = Value_DeadCell;

					for (i = 0; i < pRules->NumBirthRules; i++)
					{
						if (numOfAdjacentCells_Alive == pRules->BirthRuleArray[i])
						{
							pCellMap2[id] = Value_LivingCell;
							break;
						}
					}
				}
			}
		}

		PtrToLastUpdatedCellMap = pCellMap2;
	}
	else if (PtrToLastUpdatedCellMap == pCellMap2)
	{
		for (iy = 0; iy < NumCellsYDir; iy++)
		{
			for (ix = 0; ix < NumCellsXDir; ix++)
			{
				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						id = ((ix + iix) % NumCellsXDir) + ((iy + iiy) % NumCellsYDir) * NumCellsXDir;

						if (pCellMap2[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = (ix % NumCellsXDir) + (iy % NumCellsYDir) * NumCellsXDir;

				if (pCellMap2[id] == Value_BlockingCell)
				{
					pCellMap1[id] = Value_BlockingCell;
					continue;
				}

				// apply surviving rules:
				if (pCellMap2[id] == Value_LivingCell)
				{
					pCellMap1[id] = Value_DeadCell;

					for (i = 0; i < pRules->NumSurvivingRules; i++)
					{
						if (numOfAdjacentCells_Alive == pRules->SurvivingRuleArray[i])
						{
							pCellMap1[id] = Value_LivingCell;
							break;
						}
					}
				}

				// apply birth rules:
				else if (pCellMap2[id] == Value_DeadCell)
				{
					pCellMap1[id] = Value_DeadCell;

					for (i = 0; i < pRules->NumBirthRules; i++)
					{
						if (numOfAdjacentCells_Alive == pRules->BirthRuleArray[i])
						{
							pCellMap1[id] = Value_LivingCell;
							break;
						}
					}
				}
			}
		}

		PtrToLastUpdatedCellMap = pCellMap1;
	}
}

void C2DCellularAutomataF::Update_CellMap(C2State2DCellularAutomatonRules *pRules)
{
	int32_t ix, iy;
	int32_t iix, iiy;
	int32_t i;
	int32_t id;

	int32_t numOfAdjacentCells_Alive;

	if (PtrToLastUpdatedCellMap == pCellMap1)
	{
		for (iy = 1; iy < NumCellsYDirMinus1; iy++)
		{
			for (ix = 1; ix < NumCellsXDirMinus1; ix++)
			{

				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						id = ix + iix + (iy + iiy) * NumCellsXDir;

						if (pCellMap1[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = ix + iy * NumCellsXDir;

				if (pCellMap1[id] == Value_BlockingCell)
				{
					pCellMap2[id] = Value_BlockingCell;
					continue;
				}

				// apply surviving rules:
				if (pCellMap1[id] == Value_LivingCell)
				{
					pCellMap2[id] = Value_DeadCell;

					for (i = 0; i < pRules->NumSurvivingRules; i++)
					{
						if (numOfAdjacentCells_Alive == pRules->SurvivingRuleArray[i])
						{
							pCellMap2[id] = Value_LivingCell;
							break;
						}
					}
				}

				// apply birth rules:
				else if (pCellMap1[id] == Value_DeadCell)
				{
					pCellMap2[id] = Value_DeadCell;

					for (i = 0; i < pRules->NumBirthRules; i++)
					{
						if (numOfAdjacentCells_Alive == pRules->BirthRuleArray[i])
						{
							pCellMap2[id] = Value_LivingCell;
							break;
						}
					}
				}
			}
		}

		PtrToLastUpdatedCellMap = pCellMap2;
	}
	else if (PtrToLastUpdatedCellMap == pCellMap2)
	{
		for (iy = 1; iy < NumCellsYDirMinus1; iy++)
		{
			for (ix = 1; ix < NumCellsXDirMinus1; ix++)
			{
				numOfAdjacentCells_Alive = 0;

				for (iiy = -1; iiy < 2; iiy++)
				{
					for (iix = -1; iix < 2; iix++)
					{
						if (iiy == 0 && iix == 0)
							continue;

						id = ix + iix + (iy + iiy) * NumCellsXDir;

						if (pCellMap2[id] == Value_LivingCell)
							numOfAdjacentCells_Alive++;
					}
				}

				id = ix + iy * NumCellsXDir;

				if (pCellMap2[id] == Value_BlockingCell)
				{
					pCellMap1[id] = Value_BlockingCell;
					continue;
				}

				// apply surviving rules:
				if (pCellMap2[id] == Value_LivingCell)
				{
					pCellMap1[id] = Value_DeadCell;

					for (i = 0; i < pRules->NumSurvivingRules; i++)
					{
						if (numOfAdjacentCells_Alive == pRules->SurvivingRuleArray[i])
						{
							pCellMap1[id] = Value_LivingCell;
							break;
						}
					}
				}

				// apply birth rules:
				else if (pCellMap2[id] == Value_DeadCell)
				{
					pCellMap1[id] = Value_DeadCell;

					for (i = 0; i < pRules->NumBirthRules; i++)
					{
						if (numOfAdjacentCells_Alive == pRules->BirthRuleArray[i])
						{
							pCellMap1[id] = Value_LivingCell;
							break;
						}
					}
				}
			}
		}

		PtrToLastUpdatedCellMap = pCellMap1;
	}
}




