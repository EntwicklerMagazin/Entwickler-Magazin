#include <iostream>
#include "GravitationSamples.h"
#include <omp.h>

using namespace std;


//float g_AirFrictionConstant = 0.0f;
float g_AirFrictionConstant = 0.0125f;

#define KEYDOWN(vk_code) ((GetAsyncKeyState(vk_code) & 0x8000) ? 1 : 0)
#define KEYUP(vk_code)   ((GetAsyncKeyState(vk_code) & 0x8000) ? 0 : 1)


CSimplePhysicsObject::CSimplePhysicsObject()
{
	mass = 0.0f;
	posX = posY = posZ = 0.0f;
	velX = velY = velZ = 0.0f;
	velX_LastFrame = velY_LastFrame = velZ_LastFrame = 0.0f;
	velX_LastFrame2 = velY_LastFrame2 = velZ_LastFrame2 = 0.0f;
	accelX = accelY = accelZ = 0.0f;
}

CSimplePhysicsObject::~CSimplePhysicsObject() {}


void CSimplePhysicsObject::Reset_Values(void)
{
	mass = 0.0f;
	posX = posY = posZ = 0.0f;
	velX = velY = velZ = 0.0f;
	velX_LastFrame = velY_LastFrame = velZ_LastFrame = 0.0f;
	velX_LastFrame2 = velY_LastFrame2 = velZ_LastFrame2 = 0.0f;
	accelX = accelY = accelZ = 0.0f;
}

void CSimplePhysicsObject::Update(float timeStep)
{
	velX_LastFrame2 = velX_LastFrame;
	velY_LastFrame2 = velY_LastFrame;
	velZ_LastFrame2 = velZ_LastFrame;

	velX_LastFrame = velX;
	velY_LastFrame = velY;
	velZ_LastFrame = velZ;

	dvelX = accelX * timeStep;
	dvelY = accelY * timeStep;
	dvelZ = accelZ * timeStep;

	velX += dvelX;
	velY += dvelY;
	velZ += dvelZ;

	dposX = velX * timeStep;
	dposY = velY * timeStep;
	dposZ = velZ * timeStep;

	posX += dposX;
	posY += dposY;
	posZ += dposZ;
}



CArtilleryAI::CArtilleryAI()
{}

CArtilleryAI::~CArtilleryAI()
{}

void CArtilleryAI::Initialize(uint32_t numOfHiddenNeuronsL1, uint32_t numOfHiddenNeuronsL2)
{
	Brain.Init_NeuralNet(NumOfInputNeurons + NumOfOutputNeurons + numOfHiddenNeuronsL1 + numOfHiddenNeuronsL2);

	Brain.Init_Input_And_OutputNeurons(NumOfInputNeurons, 0.1f, false, NumOfOutputNeurons, FastTanHReplacementOutput);

	if(numOfHiddenNeuronsL2 == 0)
	{
		Brain.Init_HiddenLayer1(numOfHiddenNeuronsL1, false, true, LinearOutput, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
		//Brain.Init_HiddenLayer1(numOfHiddenNeuronsL1, false, true, FastTanHReplacementOutput, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
	}
	else 
	{
		Brain.Init_HiddenLayer1(numOfHiddenNeuronsL1, false, false, LinearOutput, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
		Brain.Init_HiddenLayer2(numOfHiddenNeuronsL2, false, true, LinearOutput, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
		//Brain.Init_HiddenLayer1(numOfHiddenNeuronsL1, false, false, FastTanHReplacementOutput, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
		//Brain.Init_HiddenLayer2(numOfHiddenNeuronsL2, false, true, FastTanHReplacementOutput, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
	}
}

void CArtilleryAI::Calculate_FiringSolution(float *pOutVelocityX, float *pOutVelocityY, float startPosX, float startPosY, float targetPosX, float targetPosY, float gravitationAccelerationX, float gravitationAccelerationY, float velocityScaleX, float velocityScaleY)
{
	/*float diffX = targetPosX - startPosX;
	float diffY = targetPosY - startPosY;

	float invDist = 1.0f / sqrt(diffX*diffX + diffY*diffY + 0.0001f);
	
	float dirX = invDist*diffX;
	float dirY = invDist*diffY;*/

	float InputData[NumOfInputNeurons];
	float OutputData[NumOfOutputNeurons];

	/*InputData[0] = startPosX;
	InputData[1] = startPosY;
	InputData[2] = targetPosX;
	InputData[3] = targetPosY;
	InputData[4] = dirX;
	InputData[5] = dirY;
	InputData[6] = gravitationAccelerationX;
	InputData[7] = gravitationAccelerationY;*/

	
	/*InputData[0] = startPosX;
	InputData[1] = startPosY;
	InputData[2] = targetPosX;
	InputData[3] = targetPosY;
	InputData[4] = gravitationAccelerationX;
	InputData[5] = gravitationAccelerationY;*/

	InputData[0] = targetPosX - startPosX;
	InputData[1] = targetPosY - startPosY;
	InputData[2] = gravitationAccelerationX;
	InputData[3] = gravitationAccelerationY;

	

	Brain.Calculate_Output(OutputData, InputData);

	// Hinweis - OutputData-Werte liegen in einem Bereich von -1 bis +1:
	*pOutVelocityX = velocityScaleX*OutputData[0];
	*pOutVelocityY = velocityScaleY*OutputData[1];
}


CArtilleryAIPopulation::CArtilleryAIPopulation()
{}

CArtilleryAIPopulation::~CArtilleryAIPopulation()
{
	delete[] pArtilleryAIArray;
	pArtilleryAIArray = nullptr;

	delete[] pFitnessScoreArray;
	pFitnessScoreArray = nullptr;
}

void CArtilleryAIPopulation::Initialize(uint32_t populationSize, uint32_t numOfHiddenNeuronsL1, uint32_t numOfHiddenNeuronsL2)
{
	delete[] pArtilleryAIArray;
	pArtilleryAIArray = nullptr;

	delete[] pFitnessScoreArray;
	pFitnessScoreArray = nullptr;

	PopulationSize = populationSize;

	populationSize += 4;
	PopulationSizePlus4 = populationSize;

	pArtilleryAIArray = new (std::nothrow) CArtilleryAI[populationSize];
	pFitnessScoreArray = new (std::nothrow) float[populationSize];

	for (uint32_t i = 0; i < populationSize; i++)
	{
		pFitnessScoreArray[i] = 0.0f;
		pArtilleryAIArray[i].Initialize(numOfHiddenNeuronsL1, numOfHiddenNeuronsL2);
	}
}

void CArtilleryAIPopulation::Change_Seed(uint64_t seed)
{
	Seed = seed;
}

void CArtilleryAIPopulation::RandomChange_OutputSynapsePlasticities(uint64_t seed, float minSynapticPlasticity, float maxSynapticPlasticity)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		pArtilleryAIArray[i].Brain.RandomChange_OutputSynapsePlasticities(seed++, minSynapticPlasticity, maxSynapticPlasticity);
	}
}

void CArtilleryAIPopulation::RandomChange_OutputSynapsePlasticities(uint64_t seed, float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRate)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		pArtilleryAIArray[i].Brain.RandomChange_OutputSynapsePlasticities(seed++, minSynapticPlasticity, maxSynapticPlasticity, mutationRate);
	}
}

void CArtilleryAIPopulation::RandomChange_OutputSynapsePlasticities(float minSynapticPlasticity, float maxSynapticPlasticity)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		pArtilleryAIArray[i].Brain.RandomChange_OutputSynapsePlasticities(Seed++, minSynapticPlasticity, maxSynapticPlasticity);
	}
}

void CArtilleryAIPopulation::RandomChange_OutputSynapsePlasticities(float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRate)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		pArtilleryAIArray[i].Brain.RandomChange_OutputSynapsePlasticities(Seed++, minSynapticPlasticity, maxSynapticPlasticity, mutationRate);
	}
}

void CArtilleryAIPopulation::RandomReduce_BrainConnections(uint64_t seed, float mutationRateL1, float mutationRateL2, float mutationRateL3)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		pArtilleryAIArray[i].Brain.Disable_Random_InputNeuron_OutputSynapses(seed++, mutationRateL1);
		pArtilleryAIArray[i].Brain.Disable_Random_HiddenLayer1Neuron_OutputSynapses(seed++, mutationRateL2);
		pArtilleryAIArray[i].Brain.Disable_Random_HiddenLayer2Neuron_OutputSynapses(seed++, mutationRateL3);
	}
}

void CArtilleryAIPopulation::RandomReduce_BrainConnections(float mutationRateL1, float mutationRateL2, float mutationRateL3)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		pArtilleryAIArray[i].Brain.Disable_Random_InputNeuron_OutputSynapses(Seed++, mutationRateL1);
		pArtilleryAIArray[i].Brain.Disable_Random_HiddenLayer1Neuron_OutputSynapses(Seed++, mutationRateL2);
		pArtilleryAIArray[i].Brain.Disable_Random_HiddenLayer2Neuron_OutputSynapses(Seed++, mutationRateL3);
	}
}

void CArtilleryAIPopulation::Init_Play_and_Evaluate_NewTrainingSequence(uint32_t trainingGameLength, uint32_t numTrainingGames, float gravitationAccelerationX, float gravitationAccelerationY, float timeStep, float velocityScaleX, float velocityScaleY)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
		pFitnessScoreArray[i] = 0.0f;

	RandomNumbers.Change_Seed(120);

	
	CSimplePhysicsObject *pSimplePhysicsObjectArray = new (std::nothrow) CSimplePhysicsObject[omp_get_max_threads()];

	for (uint32_t j = 0; j < numTrainingGames; j++)
	{
		int32_t iFirePosX = RandomNumbers.Get_IntegerNumber2(iFirePosXMin, iFirePosXMax);
		int32_t iFirePosY = RandomNumbers.Get_IntegerNumber2(iFirePosYMin, iFirePosYMax);

		int32_t iTargetPosX = RandomNumbers.Get_IntegerNumber2(iTargetPosXMin, iTargetPosXMax);
		int32_t iTargetPosY = RandomNumbers.Get_IntegerNumber2(iTargetPosYMin, iTargetPosYMax);

		float firePosX = static_cast<float>(iFirePosX);
		float firePosY = static_cast<float>(iFirePosY);
		float targetPosX = static_cast<float>(iTargetPosX);
		float targetPosY = static_cast<float>(iTargetPosY);

		
#pragma omp parallel for
		for (int32_t i = 0; i < PopulationSizePlus4; i++)
		{
			int32_t threadID = omp_get_thread_num();

			// gesucht:
			float velX, velY;

			pArtilleryAIArray[i].Calculate_FiringSolution(&velX, &velY, firePosX, firePosY, targetPosX, targetPosY, gravitationAccelerationX, gravitationAccelerationY, velocityScaleX, velocityScaleY);

		

			CSimplePhysicsObject *pSimplePhysicsObject = &pSimplePhysicsObjectArray[threadID];

			pSimplePhysicsObject->Reset_Values();
			pSimplePhysicsObject->posX = firePosX;
			pSimplePhysicsObject->posY = firePosY;
			pSimplePhysicsObject->velX = velX;
			pSimplePhysicsObject->velY = velY;

			
			float minDistSq = 100000000000.0f;
			float distSq, distXSq, distYSq;
			float movementDirX, movementDirY, tempFloat;

			uint32_t counter = 0;
			
			do
			{
				tempFloat = 1.0f / sqrt(pSimplePhysicsObject->velX*pSimplePhysicsObject->velX + pSimplePhysicsObject->velY*pSimplePhysicsObject->velY + 0.0001f);
				movementDirX = tempFloat * pSimplePhysicsObject->velX;
				movementDirY = tempFloat * pSimplePhysicsObject->velY;

				pSimplePhysicsObject->accelX = -movementDirX * g_AirFrictionConstant*pSimplePhysicsObject->velX*pSimplePhysicsObject->velX;
				pSimplePhysicsObject->accelY = gravitationAccelerationY - movementDirY*g_AirFrictionConstant*pSimplePhysicsObject->velY*pSimplePhysicsObject->velY;
				pSimplePhysicsObject->Update(timeStep);

				distXSq = pSimplePhysicsObject->posX - targetPosX;
				distXSq *= distXSq;

				distYSq = pSimplePhysicsObject->posY - targetPosY;
				distYSq *= distYSq;

				distSq = distXSq + distYSq;

				if (distSq < minDistSq)
					minDistSq = distSq;

				counter++;
	
				if (counter > trainingGameLength)
					break;

			} while (true);

			//pFitnessScoreArray[i] += 1.0f / (sqrt(minDistSq) + 0.0001f);
			pFitnessScoreArray[i] += exp(-0.01f*minDistSq);
		}
	}

	delete[] pSimplePhysicsObjectArray;
	pSimplePhysicsObjectArray = nullptr;
}

void Init_NeuralNetPopulation(CNeuralNetPopulation *pNeuralNetPopulation, CArtilleryAIPopulation *pArtilleryAIPopulation)
{
	for (uint32_t i = 0; i < pArtilleryAIPopulation->PopulationSizePlus4; i++)
	{
		pNeuralNetPopulation->ppUsedNeuralNetArray[i] = &pArtilleryAIPopulation->pArtilleryAIArray[i].Brain;
	}
}

CSimpleArtilleryAI::CSimpleArtilleryAI()
{}

CSimpleArtilleryAI::~CSimpleArtilleryAI()
{}

void CSimpleArtilleryAI::Initialize(uint32_t numOfHiddenNeuronsL1, uint32_t numOfHiddenNeuronsL2)
{
	Brain.Init_NeuralNet(NumOfInputNeurons + NumOfOutputNeurons + numOfHiddenNeuronsL1 + numOfHiddenNeuronsL2);

	Brain.Init_Input_And_OutputNeurons(NumOfInputNeurons, 0.1f, false, NumOfOutputNeurons, FastTanHReplacementOutput);

	if (numOfHiddenNeuronsL2 == 0)
	{
		Brain.Init_HiddenLayer1(numOfHiddenNeuronsL1, false, true, LinearOutput, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
	}
	else
	{
		Brain.Init_HiddenLayer1(numOfHiddenNeuronsL1, false, false, LinearOutput, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
		Brain.Init_HiddenLayer2(numOfHiddenNeuronsL2, false, true, LinearOutput, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
	}
}

void CSimpleArtilleryAI::Calculate_FiringSolution(float *pOutVelocityX, float *pOutVelocityY, float startPosX, float startPosY, float targetPosX, float targetPosY, float targetVelX, float targetVelY, float gravitationAccelerationX, float gravitationAccelerationY, float velocityScaleX, float velocityScaleY)
{
	float InputData[NumOfInputNeurons];
	float OutputData[NumOfOutputNeurons];

	/*InputData[0] = startPosX;
	InputData[1] = startPosY;
	InputData[2] = targetPosX;
	InputData[3] = targetPosY;
	InputData[4] = gravitationAccelerationX;
	InputData[5] = gravitationAccelerationY;*/

	
	InputData[0] = targetPosX - startPosX;
	InputData[1] = targetPosY - startPosY;
	InputData[2] = gravitationAccelerationX;
	InputData[3] = gravitationAccelerationY;

	Brain.Calculate_Output(OutputData, InputData);

	// Hinweis - OutputData-Werte liegen in einem Bereich von -1 bis +1:
	*pOutVelocityX = velocityScaleX*OutputData[0] + targetVelX;
	*pOutVelocityY = velocityScaleY*OutputData[1] + targetVelY;
}

CSimpleArtilleryAIPopulation::CSimpleArtilleryAIPopulation()
{}

CSimpleArtilleryAIPopulation::~CSimpleArtilleryAIPopulation()
{
	delete[] pArtilleryAIArray;
	pArtilleryAIArray = nullptr;

	delete[] pFitnessScoreArray;
	pFitnessScoreArray = nullptr;
}

void CSimpleArtilleryAIPopulation::Initialize(uint32_t populationSize, uint32_t numOfHiddenNeuronsL1, uint32_t numOfHiddenNeuronsL2)
{
	delete[] pArtilleryAIArray;
	pArtilleryAIArray = nullptr;

	delete[] pFitnessScoreArray;
	pFitnessScoreArray = nullptr;

	PopulationSize = populationSize;

	populationSize += 4;
	PopulationSizePlus4 = populationSize;

	pArtilleryAIArray = new (std::nothrow) CSimpleArtilleryAI[populationSize];
	pFitnessScoreArray = new (std::nothrow) float[populationSize];

	for (uint32_t i = 0; i < populationSize; i++)
	{
		pFitnessScoreArray[i] = 0.0f;
		pArtilleryAIArray[i].Initialize(numOfHiddenNeuronsL1, numOfHiddenNeuronsL2);
	}
}

void CSimpleArtilleryAIPopulation::Change_Seed(uint64_t seed)
{
	Seed = seed;
}

void CSimpleArtilleryAIPopulation::RandomChange_OutputSynapsePlasticities(uint64_t seed, float minSynapticPlasticity, float maxSynapticPlasticity)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		pArtilleryAIArray[i].Brain.RandomChange_OutputSynapsePlasticities(seed++, minSynapticPlasticity, maxSynapticPlasticity);
	}
}

void CSimpleArtilleryAIPopulation::RandomChange_OutputSynapsePlasticities(uint64_t seed, float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRate)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		pArtilleryAIArray[i].Brain.RandomChange_OutputSynapsePlasticities(seed++, minSynapticPlasticity, maxSynapticPlasticity, mutationRate);
	}
}

void CSimpleArtilleryAIPopulation::RandomChange_OutputSynapsePlasticities(float minSynapticPlasticity, float maxSynapticPlasticity)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		pArtilleryAIArray[i].Brain.RandomChange_OutputSynapsePlasticities(Seed++, minSynapticPlasticity, maxSynapticPlasticity);
	}
}

void CSimpleArtilleryAIPopulation::RandomChange_OutputSynapsePlasticities(float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRate)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		pArtilleryAIArray[i].Brain.RandomChange_OutputSynapsePlasticities(Seed++, minSynapticPlasticity, maxSynapticPlasticity, mutationRate);
	}
}

void CSimpleArtilleryAIPopulation::RandomReduce_BrainConnections(uint64_t seed, float mutationRateL1, float mutationRateL2, float mutationRateL3)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		pArtilleryAIArray[i].Brain.Disable_Random_InputNeuron_OutputSynapses(seed++, mutationRateL1);
		pArtilleryAIArray[i].Brain.Disable_Random_HiddenLayer1Neuron_OutputSynapses(seed++, mutationRateL2);
		pArtilleryAIArray[i].Brain.Disable_Random_HiddenLayer2Neuron_OutputSynapses(seed++, mutationRateL3);
	}
}

void CSimpleArtilleryAIPopulation::RandomReduce_BrainConnections(float mutationRateL1, float mutationRateL2, float mutationRateL3)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		pArtilleryAIArray[i].Brain.Disable_Random_InputNeuron_OutputSynapses(Seed++, mutationRateL1);
		pArtilleryAIArray[i].Brain.Disable_Random_HiddenLayer1Neuron_OutputSynapses(Seed++, mutationRateL2);
		pArtilleryAIArray[i].Brain.Disable_Random_HiddenLayer2Neuron_OutputSynapses(Seed++, mutationRateL3);
	}
}

void CSimpleArtilleryAIPopulation::Init_Play_and_Evaluate_NewTrainingSequence(uint32_t trainingGameLength, uint32_t numTrainingGames, float gravitationAccelerationX, float gravitationAccelerationY, float timeStep, float velocityScaleX, float velocityScaleY)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
		pFitnessScoreArray[i] = 0.0f;

	RandomNumbers.Change_Seed(10);

	CSimplePhysicsObject *pSimplePhysicsObjectArray = new (std::nothrow) CSimplePhysicsObject[omp_get_max_threads()];
	

	for (uint32_t j = 0; j < numTrainingGames; j++)
	{
		int32_t iFirePosX = RandomNumbers.Get_IntegerNumber2(iFirePosXMin, iFirePosXMax);
		int32_t iFirePosY = RandomNumbers.Get_IntegerNumber2(iFirePosYMin, iFirePosYMax);

		int32_t iTargetPosX = RandomNumbers.Get_IntegerNumber2(iTargetPosXMin, iTargetPosXMax);
		int32_t iTargetPosY = RandomNumbers.Get_IntegerNumber2(iTargetPosYMin, iTargetPosYMax);

		int32_t iTargetVelX = RandomNumbers.Get_IntegerNumber2(iTargetVelXMin, iTargetVelXMax);
		int32_t iTargetVelY = RandomNumbers.Get_IntegerNumber2(iTargetVelYMin, iTargetVelYMax);

		float firePosX = static_cast<float>(iFirePosX);
		float firePosY = static_cast<float>(iFirePosY);
		float targetPosX = static_cast<float>(iTargetPosX);
		float targetPosY = static_cast<float>(iTargetPosY);
		float targetVelX = static_cast<float>(iTargetVelX);
		float targetVelY = static_cast<float>(iTargetVelY);

		
#pragma omp parallel for
		for (int32_t i = 0; i < PopulationSizePlus4; i++)
		{
			int32_t threadID = omp_get_thread_num();

			// gesucht:
			float velX, velY;

			pArtilleryAIArray[i].Calculate_FiringSolution(&velX, &velY, firePosX, firePosY, targetPosX, targetPosY, targetVelX, targetVelY, gravitationAccelerationX, gravitationAccelerationY, velocityScaleX, velocityScaleY);

			CSimplePhysicsObject *pSimplePhysicsObject = &pSimplePhysicsObjectArray[threadID];

			pSimplePhysicsObject->Reset_Values();
			pSimplePhysicsObject->posX = firePosX;
			pSimplePhysicsObject->posY = firePosY;
			pSimplePhysicsObject->accelX = gravitationAccelerationX;
			pSimplePhysicsObject->accelY = gravitationAccelerationY;
			pSimplePhysicsObject->velX = velX;
			pSimplePhysicsObject->velY = velY;

			


			float actualTargetPosX = targetPosX;
			float actualTargetPosY = targetPosY;

			float minDistSq = 100000000000.0f;
			float distSq, distXSq, distYSq;

			uint32_t counter = 0;

			do
			{
				actualTargetPosX += targetVelX * timeStep;
				actualTargetPosY += targetVelY * timeStep;

				

				pSimplePhysicsObject->Update(timeStep);

				distXSq = pSimplePhysicsObject->posX - actualTargetPosX;
				distXSq *= distXSq;

				distYSq = pSimplePhysicsObject->posY - actualTargetPosY;
				distYSq *= distYSq;

				distSq = distXSq + distYSq;

				if (distSq < minDistSq)
					minDistSq = distSq;

				counter++;

				if (counter > trainingGameLength)
					break;

			} while (true);


			//pFitnessScoreArray[i] += 1.0f / (sqrt(minDistSq) + 0.0001f);
			pFitnessScoreArray[i] += exp(-0.01f*minDistSq);
		}
	}

	delete[] pSimplePhysicsObjectArray;
	pSimplePhysicsObjectArray = nullptr;
}

void Init_NeuralNetPopulation(CNeuralNetPopulation *pNeuralNetPopulation, CSimpleArtilleryAIPopulation *pArtilleryAIPopulation)
{
	for (uint32_t i = 0; i < pArtilleryAIPopulation->PopulationSizePlus4; i++)
	{
		pNeuralNetPopulation->ppUsedNeuralNetArray[i] = &pArtilleryAIPopulation->pArtilleryAIArray[i].Brain;
	}
}


COrbitalNavigationAI::COrbitalNavigationAI()
{}

COrbitalNavigationAI::~COrbitalNavigationAI()
{}

void COrbitalNavigationAI::Initialize(uint32_t numOfHiddenNeuronsL1, uint32_t numOfHiddenNeuronsL2)
{
	Brain.Init_NeuralNet(NumOfInputNeurons + NumOfOutputNeurons + numOfHiddenNeuronsL1 + numOfHiddenNeuronsL2);

	Brain.Init_Input_And_OutputNeurons(NumOfInputNeurons, 0.1f, false, NumOfOutputNeurons, SqrtOutput);
		
	if (numOfHiddenNeuronsL2 == 0)
	{
		Brain.Init_HiddenLayer1(numOfHiddenNeuronsL1, false, true, LinearOutput, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
	}
	else
	{
		Brain.Init_HiddenLayer1(numOfHiddenNeuronsL1, false, false, LinearOutput, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
		Brain.Init_HiddenLayer2(numOfHiddenNeuronsL2, false, true, LinearOutput, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
	}	

	/*Brain.Init_NeuralNet(NumOfInputNeurons + NumOfOutputNeurons + numOfHiddenNeuronsL1 + numOfHiddenNeuronsL2);

	Brain.Init_Input_And_OutputNeurons(NumOfInputNeurons, 0.1f, false, NumOfOutputNeurons, FastTanHReplacementOutput);

	if (numOfHiddenNeuronsL2 == 0)
	{
		Brain.Init_HiddenLayer1(numOfHiddenNeuronsL1, false, true, LinearOutput, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
	}
	else
	{
		Brain.Init_HiddenLayer1(numOfHiddenNeuronsL1, false, false, LinearOutput, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
		Brain.Init_HiddenLayer2(numOfHiddenNeuronsL2, false, true, LinearOutput, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
	}*/
}

void COrbitalNavigationAI::Calculate_InitialOrbitalVelocity(float *pOutVelocityX, float *pOutVelocityY, float startPosX, float startPosY, float targetPosX, float targetPosY, float gravitySourcePosX, float gravitySourcePosY, float gravitySourceMass)
{
	float distX_Start = startPosX - gravitySourcePosX;
	float distY_Start = startPosY - gravitySourcePosY;

	float radiusStartPosition = sqrt(distX_Start * distX_Start + distY_Start * distY_Start);

	float distX_Target = targetPosX - gravitySourcePosX;
	float distY_Target = targetPosY - gravitySourcePosY;

	float a = sqrt(distX_Target * distX_Target + distY_Target * distY_Target);

	a += radiusStartPosition;
	a *= 0.5f;


	Normalize(&distX_Start, &distY_Start);

	float movementDirX, movementDirY, movementDirZ;

	CrossProduct(&movementDirX, &movementDirY, &movementDirZ, -distX_Start, -distY_Start, 0.0f, 0.0f, 0.0f, 1.0f);

	/*
	float radialVelocity = sqrt(gravitySourceMass*(2.0f / radiusStartPosition - 1.0f / a));

	*pOutVelocityX = movementDirX * radialVelocity;
	*pOutVelocityY = movementDirY * radialVelocity;
	*/

	
	float InputData[NumOfInputNeurons];
	float OutputData[NumOfOutputNeurons];


	InputData[0] = gravitySourceMass / radiusStartPosition;
	InputData[1] = gravitySourceMass / a;

	Brain.Calculate_Output(OutputData, InputData);

	*pOutVelocityX = movementDirX * OutputData[0];
	*pOutVelocityY = movementDirY * OutputData[0];

	

	/*float InputData[NumOfInputNeurons];
	float OutputData[NumOfOutputNeurons];

	InputData[0] = gravitySourcePosX;
	InputData[1] = gravitySourcePosY;
	InputData[2] = startPosX;
	InputData[3] = startPosY;
	InputData[4] = targetPosX;
	InputData[5] = targetPosY;

	Brain.Calculate_Output(OutputData, InputData);

	*pOutVelocityX = 100.0f*movementDirX * OutputData[0];
	*pOutVelocityY = 100.0f*movementDirY * OutputData[0];*/
	

	


	
}






COrbitalNavigationAIPopulation::COrbitalNavigationAIPopulation()
{}

COrbitalNavigationAIPopulation::~COrbitalNavigationAIPopulation()
{
	delete[] pOrbitalNavigationAIArray;
	pOrbitalNavigationAIArray = nullptr;

	delete[] pFitnessScoreArray;
	pFitnessScoreArray = nullptr;
}

void COrbitalNavigationAIPopulation::Initialize(uint32_t populationSize, uint32_t numOfHiddenNeuronsL1, uint32_t numOfHiddenNeuronsL2)
{
	delete[] pOrbitalNavigationAIArray;
	pOrbitalNavigationAIArray = nullptr;

	delete[] pFitnessScoreArray;
	pFitnessScoreArray = nullptr;

	PopulationSize = populationSize;

	populationSize += 4;
	PopulationSizePlus4 = populationSize;

	pOrbitalNavigationAIArray = new (std::nothrow) COrbitalNavigationAI[populationSize];
	pFitnessScoreArray = new (std::nothrow) float[populationSize];

	for (uint32_t i = 0; i < populationSize; i++)
	{
		pFitnessScoreArray[i] = 0.0f;
		pOrbitalNavigationAIArray[i].Initialize(numOfHiddenNeuronsL1, numOfHiddenNeuronsL2);
	}
}

void COrbitalNavigationAIPopulation::Change_Seed(uint64_t seed)
{
	Seed = seed;
}

void COrbitalNavigationAIPopulation::RandomChange_OutputSynapsePlasticities(uint64_t seed, float minSynapticPlasticity, float maxSynapticPlasticity)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		pOrbitalNavigationAIArray[i].Brain.RandomChange_OutputSynapsePlasticities(seed++, minSynapticPlasticity, maxSynapticPlasticity);
	}
}

void COrbitalNavigationAIPopulation::RandomChange_OutputSynapsePlasticities(uint64_t seed, float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRate)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		pOrbitalNavigationAIArray[i].Brain.RandomChange_OutputSynapsePlasticities(seed++, minSynapticPlasticity, maxSynapticPlasticity, mutationRate);
	}
}

void COrbitalNavigationAIPopulation::RandomChange_OutputSynapsePlasticities(float minSynapticPlasticity, float maxSynapticPlasticity)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		pOrbitalNavigationAIArray[i].Brain.RandomChange_OutputSynapsePlasticities(Seed++, minSynapticPlasticity, maxSynapticPlasticity);
	}
}

void COrbitalNavigationAIPopulation::RandomChange_OutputSynapsePlasticities(float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRate)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		pOrbitalNavigationAIArray[i].Brain.RandomChange_OutputSynapsePlasticities(Seed++, minSynapticPlasticity, maxSynapticPlasticity, mutationRate);
	}
}

void COrbitalNavigationAIPopulation::RandomReduce_BrainConnections(uint64_t seed, float mutationRateL1, float mutationRateL2, float mutationRateL3)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		pOrbitalNavigationAIArray[i].Brain.Disable_Random_InputNeuron_OutputSynapses(seed++, mutationRateL1);
		pOrbitalNavigationAIArray[i].Brain.Disable_Random_HiddenLayer1Neuron_OutputSynapses(seed++, mutationRateL2);
		pOrbitalNavigationAIArray[i].Brain.Disable_Random_HiddenLayer2Neuron_OutputSynapses(seed++, mutationRateL3);
	}
}

void COrbitalNavigationAIPopulation::RandomReduce_BrainConnections(float mutationRateL1, float mutationRateL2, float mutationRateL3)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		pOrbitalNavigationAIArray[i].Brain.Disable_Random_InputNeuron_OutputSynapses(Seed++, mutationRateL1);
		pOrbitalNavigationAIArray[i].Brain.Disable_Random_HiddenLayer1Neuron_OutputSynapses(Seed++, mutationRateL2);
		pOrbitalNavigationAIArray[i].Brain.Disable_Random_HiddenLayer2Neuron_OutputSynapses(Seed++, mutationRateL3);
	}
}

void COrbitalNavigationAIPopulation::Init_Play_and_Evaluate_NewTrainingSequence(uint32_t trainingGameLength, uint32_t numTrainingGames, CSimplePhysicsObject* pGravitySource, float timeStep)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
		pFitnessScoreArray[i] = 0.0f;

	
	

	CSimplePhysicsObject *pSimplePhysicsObjectArray = new (std::nothrow) CSimplePhysicsObject[omp_get_max_threads()];

	RandomNumbers.Change_Seed(150);

	for (uint32_t j = 0; j < numTrainingGames; j++)
	{
		float dirX = -1.0f;
		float dirY = 0.0f;
		
		

		float distSq = dirX * dirX + dirY *  dirY + 0.00001f;
		float invLength = 1.0f / sqrt(distSq);

		dirX *= invLength;
		dirY *= invLength;

		float radiusStart = RandomNumbers.Get_FloatNumber(20.0f, 30.0f);

		float  startPosX = dirX *  radiusStart + pGravitySource->posX;
		float  startPosY = dirY *  radiusStart + pGravitySource->posY;

		dirX = 1.0f;
		dirY = 0.0f;

		distSq = dirX * dirX + dirY *  dirY + 0.00001f;
		invLength = 1.0f / sqrt(distSq);

		dirX *= invLength;
		dirY *= invLength;

		float radiusEnd = RandomNumbers.Get_FloatNumber(10.0f, 40.0f);

		float  targetPosX = dirX *  radiusEnd + pGravitySource->posX;
		float  targetPosY = dirY * radiusEnd + pGravitySource->posY;
	
		float radiusMin = min(radiusStart, radiusEnd);
		float radiusMinSq = radiusMin*radiusMin;

		

		float radiusMax = min(radiusStart, radiusEnd);
		float radiusMaxSq = radiusMax*radiusMax;

		

#pragma omp parallel for
		for (int32_t i = 0; i < PopulationSizePlus4; i++)
		{
			float velX, velY;

			int32_t threadID = omp_get_thread_num();

			CSimplePhysicsObject *pSimplePhysicsObject = &pSimplePhysicsObjectArray[threadID];
		
			pOrbitalNavigationAIArray[i].Calculate_InitialOrbitalVelocity(&velX, &velY, startPosX, startPosY, targetPosX, targetPosY, pGravitySource->posX, pGravitySource->posY, pGravitySource->mass);

			

			pSimplePhysicsObject->Reset_Values();
			pSimplePhysicsObject->posX = startPosX;
			pSimplePhysicsObject->posY = startPosY;
			pSimplePhysicsObject->accelX = 0.0f;
			pSimplePhysicsObject->accelY = 0.0f;
			pSimplePhysicsObject->velX = velX;
			pSimplePhysicsObject->velY = velY;

			float minDistSq = 100000000000.0f;
			float invDist, distXSq, distYSq;
			float velSq, invVel, acceleration, accelerationX, accelerationY;
			float moveDirX, moveDirY, distX, distY;

			

			velSq = pSimplePhysicsObject->velX * pSimplePhysicsObject->velX + pSimplePhysicsObject->velY * pSimplePhysicsObject->velY + 0.00001f;

			if (velSq < 0.2f)
				continue;

			
	
			uint32_t counter = 0;

			do
			{
				
				velSq = pSimplePhysicsObject->velX * pSimplePhysicsObject->velX + pSimplePhysicsObject->velY * pSimplePhysicsObject->velY + 0.00001f;
				invVel = 1.0f / sqrt(velSq);

				

				moveDirX = invVel * pSimplePhysicsObject->velX;
				moveDirY = invVel * pSimplePhysicsObject->velY;

				distX = pGravitySource->posX - pSimplePhysicsObject->posX;
				distY = pGravitySource->posY - pSimplePhysicsObject->posY;

				distSq = distX * distX + distY * distY;

				
				invDist = 1.0f / sqrt(distSq + 0.00001f);

				dirX = invDist * distX;
				dirY = invDist * distY;

				
				acceleration = pGravitySource->mass / distSq;

				accelerationX = dirX * acceleration;
				accelerationY = dirY * acceleration;

				

				pSimplePhysicsObject->accelX = accelerationX;
				pSimplePhysicsObject->accelY = accelerationY;

				pSimplePhysicsObject->Update(timeStep);

				distXSq = pSimplePhysicsObject->posX - targetPosX;
				distXSq *= distXSq;

				distYSq = pSimplePhysicsObject->posY - targetPosY;
				distYSq *= distYSq;


				distSq = distXSq + distYSq;

				if (distSq < minDistSq)
					minDistSq = distSq;

				counter++;

				if (counter > trainingGameLength)
					break;

			} while (true);

			pFitnessScoreArray[i] += exp(-0.01f*minDistSq);
		}
	}

	delete[] pSimplePhysicsObjectArray;
	pSimplePhysicsObjectArray = nullptr;
}

void Init_NeuralNetPopulation(CNeuralNetPopulation *pNeuralNetPopulation, COrbitalNavigationAIPopulation *pOrbitalNavigationAIPopulation)
{
	for (uint32_t i = 0; i < pOrbitalNavigationAIPopulation->PopulationSizePlus4; i++)
	{
		pNeuralNetPopulation->ppUsedNeuralNetArray[i] = &pOrbitalNavigationAIPopulation->pOrbitalNavigationAIArray[i].Brain;
	}
}


CLandingModuleNavigationAI::CLandingModuleNavigationAI()
{}

CLandingModuleNavigationAI::~CLandingModuleNavigationAI()
{}

void CLandingModuleNavigationAI::Initialize(uint32_t numOfHiddenNeuronsL1, uint32_t numOfHiddenNeuronsL2)
{
	Brain.Init_NeuralNet(NumOfInputNeurons + NumOfOutputNeurons + numOfHiddenNeuronsL1 + numOfHiddenNeuronsL2);

	Brain.Init_Input_And_OutputNeurons(NumOfInputNeurons, 0.1f, false, NumOfOutputNeurons, FastTanHReplacementOutput);

	if (numOfHiddenNeuronsL2 == 0)
	{
		//Brain.Init_HiddenLayer1(numOfHiddenNeuronsL1, false, true, FastTanHReplacementOutput, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
		Brain.Init_HiddenLayer1(numOfHiddenNeuronsL1, false, true, LinearOutput, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
	}
	else
	{
		//Brain.Init_HiddenLayer1(numOfHiddenNeuronsL1, false, false, FastTanHReplacementOutput, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
		//Brain.Init_HiddenLayer2(numOfHiddenNeuronsL2, false, true, FastTanHReplacementOutput, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
		Brain.Init_HiddenLayer1(numOfHiddenNeuronsL1, false, false, LinearOutput, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
		Brain.Init_HiddenLayer2(numOfHiddenNeuronsL2, false, true, LinearOutput, -0.1f, 0.1f, -0.1f, 0.1f, 0.1f);
	}

	
}

void CLandingModuleNavigationAI::Calculate_PossibleCourseCorrection(float *pOutputData, CSimplePhysicsObject * pLandingModule, float targetPosX, float targetPosY)
{
	
	float InputData[NumOfInputNeurons];

	
	InputData[0] = pLandingModule->velX;
	InputData[1] = pLandingModule->velY;
	InputData[2] = pLandingModule->velX_LastFrame;
	InputData[3] = pLandingModule->velY_LastFrame;
	InputData[4] = targetPosX - pLandingModule->posX;
	InputData[5] = targetPosY - pLandingModule->posY;
	InputData[6] = targetPosX - pLandingModule->posX - pLandingModule->velX;
	InputData[7] = targetPosY - pLandingModule->posY - pLandingModule->velY;
	
	Brain.Calculate_Output(pOutputData, InputData);
}

CLandingModuleNavigationAIPopulation::CLandingModuleNavigationAIPopulation()
{}

CLandingModuleNavigationAIPopulation::~CLandingModuleNavigationAIPopulation()
{
	delete[] pLandingModuleNavigationAIArray;
	pLandingModuleNavigationAIArray = nullptr;

	delete[] pFitnessScoreArray;
	pFitnessScoreArray = nullptr;
}

void CLandingModuleNavigationAIPopulation::Initialize(uint32_t populationSize, uint32_t numOfHiddenNeuronsL1, uint32_t numOfHiddenNeuronsL2)
{
	delete[] pLandingModuleNavigationAIArray;
	pLandingModuleNavigationAIArray = nullptr;

	delete[] pFitnessScoreArray;
	pFitnessScoreArray = nullptr;

	PopulationSize = populationSize;

	populationSize += 4;
	PopulationSizePlus4 = populationSize;

	pLandingModuleNavigationAIArray = new (std::nothrow) CLandingModuleNavigationAI[populationSize];
	pFitnessScoreArray = new (std::nothrow) float[populationSize];

	for (uint32_t i = 0; i < populationSize; i++)
	{
		pFitnessScoreArray[i] = 0.0f;
		pLandingModuleNavigationAIArray[i].Initialize(numOfHiddenNeuronsL1, numOfHiddenNeuronsL2);
	}
}

void CLandingModuleNavigationAIPopulation::Change_Seed(uint64_t seed)
{
	Seed = seed;
}

void CLandingModuleNavigationAIPopulation::RandomChange_OutputSynapsePlasticities(uint64_t seed, float minSynapticPlasticity, float maxSynapticPlasticity)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		pLandingModuleNavigationAIArray[i].Brain.RandomChange_OutputSynapsePlasticities(seed++, minSynapticPlasticity, maxSynapticPlasticity);
	}
}

void CLandingModuleNavigationAIPopulation::RandomChange_OutputSynapsePlasticities(uint64_t seed, float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRate)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		pLandingModuleNavigationAIArray[i].Brain.RandomChange_OutputSynapsePlasticities(seed++, minSynapticPlasticity, maxSynapticPlasticity, mutationRate);
	}
}

void CLandingModuleNavigationAIPopulation::RandomChange_OutputSynapsePlasticities(float minSynapticPlasticity, float maxSynapticPlasticity)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		pLandingModuleNavigationAIArray[i].Brain.RandomChange_OutputSynapsePlasticities(Seed++, minSynapticPlasticity, maxSynapticPlasticity);
	}
}

void CLandingModuleNavigationAIPopulation::RandomChange_OutputSynapsePlasticities(float minSynapticPlasticity, float maxSynapticPlasticity, float mutationRate)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		pLandingModuleNavigationAIArray[i].Brain.RandomChange_OutputSynapsePlasticities(Seed++, minSynapticPlasticity, maxSynapticPlasticity, mutationRate);
	}
}

void CLandingModuleNavigationAIPopulation::RandomReduce_BrainConnections(uint64_t seed, float mutationRateL1, float mutationRateL2, float mutationRateL3)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		pLandingModuleNavigationAIArray[i].Brain.Disable_Random_InputNeuron_OutputSynapses(seed++, mutationRateL1);
		pLandingModuleNavigationAIArray[i].Brain.Disable_Random_HiddenLayer1Neuron_OutputSynapses(seed++, mutationRateL2);
		pLandingModuleNavigationAIArray[i].Brain.Disable_Random_HiddenLayer2Neuron_OutputSynapses(seed++, mutationRateL3);
	}
}

void CLandingModuleNavigationAIPopulation::RandomReduce_BrainConnections(float mutationRateL1, float mutationRateL2, float mutationRateL3)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
	{
		pLandingModuleNavigationAIArray[i].Brain.Disable_Random_InputNeuron_OutputSynapses(Seed++, mutationRateL1);
		pLandingModuleNavigationAIArray[i].Brain.Disable_Random_HiddenLayer1Neuron_OutputSynapses(Seed++, mutationRateL2);
		pLandingModuleNavigationAIArray[i].Brain.Disable_Random_HiddenLayer2Neuron_OutputSynapses(Seed++, mutationRateL3);
	}
}

void CLandingModuleNavigationAIPopulation::Init_Play_and_Evaluate_NewTrainingSequence(uint32_t trainingGameLength, uint32_t numTrainingGames, float gravitationAccelerationX, float gravitationAccelerationY, float timeStep, float targetDistanceInvReward1, float targetDistanceReward2, float fuelConsumptionInvReward1, float fuelConsumptionReward2, float horizontalVelocityInvPenalty, float verticalVelocityInvPenalty, float velocityPenalty, float flightDurationInvPenalty1, float flightDurationPenalty2)
{
	for (uint32_t i = 0; i < PopulationSizePlus4; i++)
		pFitnessScoreArray[i] = 0.0f;

	CSimplePhysicsObject *pLandingModuleArray = new (std::nothrow) CSimplePhysicsObject[omp_get_max_threads()];

	RandomNumbers.Change_Seed(10);

	for (uint32_t j = 0; j < numTrainingGames; j++)
	{
		

		int32_t iStartPosX = RandomNumbers.Get_IntegerNumber2(iStartPosXMin, iStartPosXMax);
		int32_t iStartPosY = RandomNumbers.Get_IntegerNumber2(iStartPosYMin, iStartPosYMax);

		

		int32_t iTargetPosX = RandomNumbers.Get_IntegerNumber2(iTargetPosXMin, iTargetPosXMax);
		int32_t iTargetPosY = RandomNumbers.Get_IntegerNumber2(iTargetPosYMin, iTargetPosYMax);

		float startPosX = static_cast<float>(iStartPosX);
		float startPosY = static_cast<float>(iStartPosY);
		float targetPosX = static_cast<float>(iTargetPosX);
		float targetPosY = static_cast<float>(iTargetPosY);

		float initalVelocityX = RandomNumbers.Get_FloatNumber_IncludingZero(InitalVelocityXMin, InitalVelocityXMax);
		float initalVelocityY = RandomNumbers.Get_FloatNumber_IncludingZero(InitalVelocityYMin, InitalVelocityYMax);

		
#pragma omp parallel for
		for (int32_t i = 0; i < PopulationSizePlus4; i++)
		{
			int32_t threadID = omp_get_thread_num();

			float actualFuelCapacity;
			float velX, velY;

			CSimplePhysicsObject *pLandingModule = &pLandingModuleArray[threadID];
		
			actualFuelCapacity = FuelCapacityMax;

			pLandingModule->Reset_Values();

			pLandingModule->velX = initalVelocityX;
			pLandingModule->velY = initalVelocityY;

			pLandingModule->posX = startPosX;
			pLandingModule->posY = startPosY;

			

			uint32_t counter = 0;

			
			float outputData[NumOfOutputNeurons]; 

			do
			{
				pLandingModuleNavigationAIArray[i].Calculate_PossibleCourseCorrection(outputData, pLandingModule, targetPosX, targetPosY);

				float maxOutputValue = -100000.0f;
				uint32_t belongingArrayID = 0;

				for (uint32_t i = 0; i < NumOfOutputNeurons; i++)
				{
					if(outputData[i] > maxOutputValue)
					{
						maxOutputValue = outputData[i];
						belongingArrayID = i;
					}
				}

				pLandingModule->accelX = gravitationAccelerationX;
				pLandingModule->accelY = gravitationAccelerationY;

				if (belongingArrayID != 0)
				{
					if (outputData[1] > outputData[2] && outputData[1] > 0.0f)
					{
						pLandingModule->accelY += outputData[1] * ManeuverAccelerationY;
						actualFuelCapacity -= outputData[1] * FuelConsumptionY;
					}
					else if (outputData[2] > outputData[1] && outputData[2] > 0.0f)
					{
						pLandingModule->accelY -= outputData[2] * ManeuverAccelerationY;
						actualFuelCapacity -= outputData[2] * FuelConsumptionY;
					}
					
					if (outputData[3] > outputData[4] && outputData[3] > 0.0f)
					{
						pLandingModule->accelX += outputData[3] * ManeuverAccelerationX;
						actualFuelCapacity -= outputData[3] * FuelConsumptionX;
					}
					else if (outputData[4] > outputData[3] && outputData[4] > 0.0f)
					{
						pLandingModule->accelX -= outputData[4] * ManeuverAccelerationX;
						actualFuelCapacity -= outputData[4] * FuelConsumptionX;
					}			
				}

				pLandingModule->Update(timeStep);

				/* Wenn sich das Raumfahrzeug unterhalb der Landeplattform befindet,
				   gilt der Landevorgang als gescheitert: */
				if (pLandingModule->posY > targetPosY)
				{
					counter = trainingGameLength;
					break;
				}

				
				float distXSq = pLandingModule->posX - targetPosX;
				distXSq *= distXSq;

				
				

				float distYSq = pLandingModule->posY - targetPosY;
				distYSq *= distYSq;

				float distSq = distXSq + distYSq;

				if (distSq < MaxToleratedTargetDistanceSq && (pLandingModule->velX*pLandingModule->velX + pLandingModule->velY*pLandingModule->velY) < MaxToleratedLandingVelocityAmountSq)
					break;

			

				if (actualFuelCapacity < 2.0f*max(FuelConsumptionX, FuelConsumptionY))
					break;

				counter++;

				if (counter > trainingGameLength)
					break;

			} while (true);

			
			float distXSq = pLandingModule->posX - targetPosX;
			distXSq *= distXSq;

			float distYSq = pLandingModule->posY - targetPosY;
			distYSq *= distYSq;

			/* Raumfahrzeug oberhalb bzw. auf der Landeplattform: */
			if (pLandingModule->posY <= targetPosY)
			{
				pFitnessScoreArray[i] += targetDistanceReward2 * exp(-targetDistanceInvReward1 * (distXSq + distYSq));
				pFitnessScoreArray[i] += fuelConsumptionReward2*exp(-fuelConsumptionInvReward1*(FuelCapacityMax - actualFuelCapacity)*(FuelCapacityMax - actualFuelCapacity));
			}

			pFitnessScoreArray[i] -= flightDurationPenalty2 * (1.0f - exp(-flightDurationInvPenalty1*static_cast<float>(counter)));


			pFitnessScoreArray[i] -= velocityPenalty * max((1.0f - exp(-horizontalVelocityInvPenalty*pLandingModule->velX*pLandingModule->velX)),
				                         (1.0f - exp(-verticalVelocityInvPenalty*pLandingModule->velY*pLandingModule->velY)));
					
		}
	}

	delete[] pLandingModuleArray;
	pLandingModuleArray = nullptr;
}

void Init_NeuralNetPopulation(CNeuralNetPopulation *pNeuralNetPopulation, CLandingModuleNavigationAIPopulation *pLandingModuleNavigationAIPopulation)
{
	for (uint32_t i = 0; i < pLandingModuleNavigationAIPopulation->PopulationSizePlus4; i++)
	{
		pNeuralNetPopulation->ppUsedNeuralNetArray[i] = &pLandingModuleNavigationAIPopulation->pLandingModuleNavigationAIArray[i].Brain;
	}
}


