// Schutz vor Mehrfachdeklarationen :

#ifndef _Graph_H_
#define _Graph_H_

#include <iostream>
#include <fstream>
#include "LogFile.h"
#include "RandomNumbers.h"


#ifndef max
#define max(a,b)    ( ((a) > (b)) ? (a) : (b) )
#endif

#ifndef min
#define min(a,b)    ( ((a) < (b)) ? (a) : (b) )
#endif

class CWeightMatrix
{
public:

	int32_t SizeX = 0;
	int32_t SizeY = 0;
	int32_t Size = 0;

	float *pWeightArray = nullptr;

	CWeightMatrix();
	~CWeightMatrix();

	// Kopierkonstruktor l�schen:
	CWeightMatrix(const CWeightMatrix  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CWeightMatrix & operator=(const CWeightMatrix  &originalObject) = delete;

	void Init_Matrix(int32_t sizeX, int32_t sizeY, float initalWeight);

	float Get_Weight(int32_t ix, int32_t iy);
	void Set_Weight(int32_t ix, int32_t iy, float weight);
};

class CGraphNode
{
public:

	CGraphNode *pUsedNodeArray = nullptr;

	float PosX = 0.0f;
	float PosY = 0.0f;
	float PosZ = 0.0f;

	CGraphNode();
	~CGraphNode();

	// Kopierkonstruktor l�schen:
	CGraphNode(const CGraphNode  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CGraphNode & operator=(const CGraphNode  &originalObject) = delete;

	void Connect_With_Graph(CGraphNode *pNodeArray);

	void Set_Position(float x, float y, float z);
	float Get_Distance_to_Other_Node(int32_t nodeID);
	float Get_InvDistance_to_Other_Node(int32_t nodeID);
	float Get_DistanceSq_to_Other_Node(int32_t nodeID);
	float Get_InvDistanceSq_to_Other_Node(int32_t nodeID);

	float Calculate_PathDistSq(const int32_t *pPathArray, int32_t numNodes);
	float Calculate_PathDistSq(const float *pPathArray, int32_t numNodes);

	float Calculate_PathDist(const int32_t *pPathArray, int32_t numNodes);
	float Calculate_PathDist(const float *pPathArray, int32_t numNodes);

	float Calculate_WeightedPathDistSq(const int32_t *pPathArray, const float *pWeightArray, int32_t numNodes);
	float Calculate_WeightedPathDistSq(const float *pPathArray, const float *pWeightArray, int32_t numNodes);

	float Calculate_WeightedPathDistSq(const int32_t *pPathArray, CWeightMatrix *pWeightMatrix, int32_t numNodes);
	float Calculate_WeightedPathDistSq(const float *pPathArray, CWeightMatrix *pWeightMatrix, int32_t numNodes);


	float Calculate_WeightedPathDist(const int32_t *pPathArray, const float *pWeightArray, int32_t numNodes);
	float Calculate_WeightedPathDist(const float *pPathArray, const float *pWeightArray, int32_t numNodes);

	float Calculate_WeightedPathDist(const int32_t *pPathArray, CWeightMatrix *pWeightMatrix, int32_t numNodes);
	float Calculate_WeightedPathDist(const float *pPathArray, CWeightMatrix *pWeightMatrix, int32_t numNodes);
};

void Rearrange_TSP_Path(float *pOutPathArray, float *pInPathArray, int32_t arraySize, float iDofFirstAndLastWaypoint);
void Rearrange_TSP_Path(int32_t *pOutPathArray, int32_t *pInPathArray, int32_t arraySize, int32_t iDofFirstAndLastWaypoint);
void Rearrange_TSP_Path(int32_t *pOutPathArray, float *pInPathArray, int32_t arraySize, float iDofFirstAndLastWaypoint);










#endif