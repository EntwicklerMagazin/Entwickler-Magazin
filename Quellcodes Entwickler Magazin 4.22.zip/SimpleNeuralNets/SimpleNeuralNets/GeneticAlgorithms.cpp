#include "GeneticAlgorithms.h"

using namespace std;


CGeneralPopulation::CGeneralPopulation()
{
	for (int32_t i = 0; i < constNumOfBestFittedGenomes; i++)
	{
		IDArrayOfBestFittedGenomes[i] = 0;
		FitnessArrayOfBestFittedGenomes[i] = 0.0f;
	}

	for (int32_t i = 0; i < constNumOfWorstFittedGenomes; i++)
	{
		IDArrayOfWorstFittedGenomes[i] = 0;
		FitnessArrayOfWorstFittedGenomes[i] = 0.0f;
	}
}

CGeneralPopulation::~CGeneralPopulation()
{
	delete[] pFitnessScoreArray;
	pFitnessScoreArray = nullptr;

	delete[] ppGenomeArray;
	ppGenomeArray = nullptr;
}

void CGeneralPopulation::Set_GenomeValueCloningFunction(pGenomeValueCloning pFunc)
{
	GenomeValueCloningFunc = pFunc;
}

void CGeneralPopulation::Change_Seed(uint64_t seed)
{
	Seed = seed;
}

bool CGeneralPopulation::Initialize(int32_t populationSize)
{
	int32_t minPopulationSize = constNumOfBestFittedGenomes + constNumOfWorstFittedGenomes + constNumOfAdditionalGenomes + 10;

	//if (populationSize < minPopulationSize)
	//populationSize = minPopulationSize;

	for (int32_t i = 0; i < constNumOfBestFittedGenomes; i++)
	{
		IDArrayOfBestFittedGenomes[i] = 0;
		FitnessArrayOfBestFittedGenomes[i] = 0.0f;
	}

	for (int32_t i = 0; i < constNumOfWorstFittedGenomes; i++)
	{
		IDArrayOfWorstFittedGenomes[i] = 0;
		FitnessArrayOfWorstFittedGenomes[i] = 0.0f;
	}

	UseAdditionalMutatedBestGenome = false;
	UseAdditionalMutatedSecondBestGenome = false;
	UseAdditionalBestGenomesChild = false;

	RandomGenomesChildCounter = 0;

	for (int32_t i = 0; i < constNumOfRandomGenomesChildren; i++)
		UseAdditionalRandomGenomesChild[i] = false;

	delete[] pFitnessScoreArray;
	pFitnessScoreArray = nullptr;

	delete[] ppGenomeArray;
	ppGenomeArray = nullptr;

	PopulationSizePlusX = populationSize;
	PopulationSize = PopulationSizePlusX - constNumOfAdditionalGenomes;

	//PopulationSize = populationSize;
	//PopulationSizePlusX = populationSize + constNumOfAdditionalGenomes;

	pFitnessScoreArray = new (std::nothrow) float[PopulationSizePlusX];
	ppGenomeArray = new (std::nothrow) void*[PopulationSizePlusX];

	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFitnessScoreArray[i] = 0.0f;
		ppGenomeArray[i] = nullptr;
	}

	if (populationSize < minPopulationSize)
		return false;

	return true;
}

void CGeneralPopulation::Set_Genome(void *pInGenome, int32_t id)
{
	ppGenomeArray[id] = pInGenome;
}

void* CGeneralPopulation::Get_Best_Evolved_Genome(void)
{
	return ppGenomeArray[IDArrayOfBestFittedGenomes[0]];
}

void CGeneralPopulation::Get_Best_Evolved_Genome(void *pOutGenome)
{
	GenomeValueCloningFunc(pOutGenome, ppGenomeArray[IDArrayOfBestFittedGenomes[0]]);
}

void CGeneralPopulation::Reset_Population(void)
{
	for (int32_t i = 0; i < constNumOfBestFittedGenomes; i++)
	{
		IDArrayOfBestFittedGenomes[i] = 0;
		FitnessArrayOfBestFittedGenomes[i] = 0.0f;
	}

	for (int32_t i = 0; i < constNumOfWorstFittedGenomes; i++)
	{
		IDArrayOfWorstFittedGenomes[i] = 0;
		FitnessArrayOfWorstFittedGenomes[i] = 0.0f;
	}

	UseAdditionalMutatedBestGenome = false;
	UseAdditionalMutatedSecondBestGenome = false;
	UseAdditionalBestGenomesChild = false;

	RandomGenomesChildCounter = 0;

	for (int32_t i = 0; i < constNumOfRandomGenomesChildren; i++)
		UseAdditionalRandomGenomesChild[i] = false;


	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFitnessScoreArray[i] = 0.0f;
	}
}

void CGeneralPopulation::Reset_MinErrorSum_ActualGeneration(float value)
{
	MinErrorSum_ActualGeneration = value;
}

void CGeneralPopulation::Update_MinErrorSum_ActualGeneration(float value)
{
	if (value < MinErrorSum_ActualGeneration)
		MinErrorSum_ActualGeneration = value;
}

void CGeneralPopulation::Calculate_FitnessScore_FromError(int32_t genomeID, float error)
{
	pFitnessScoreArray[genomeID] = 1.0f / (error + 0.01f);
}

void CGeneralPopulation::Set_FitnessScore(int32_t genomeID, float score)
{
	pFitnessScoreArray[genomeID] = score;
}

void CGeneralPopulation::Update_Population(void)
{
	for (int32_t i = 0; i < constNumOfBestFittedGenomes; i++)
	{
		IDArrayOfBestFittedGenomes[i] = 0;
		FitnessArrayOfBestFittedGenomes[i] = -100000000.0f;
	}

	for (int32_t i = 0; i < constNumOfWorstFittedGenomes; i++)
	{
		IDArrayOfWorstFittedGenomes[i] = 0;
		FitnessArrayOfWorstFittedGenomes[i] = 100000000.0f;
	}

	for (int32_t i = 0; i < PopulationSize; i++)
	{
		for (int32_t j = 0; j < constNumOfBestFittedGenomes; j++)
		{
			if (pFitnessScoreArray[i] > FitnessArrayOfBestFittedGenomes[j])
			{
				for (uint32_t k = constNumOfBestFittedGenomes - 1; k > j; k--)
				{
					IDArrayOfBestFittedGenomes[k] = IDArrayOfBestFittedGenomes[k - 1];
					FitnessArrayOfBestFittedGenomes[k] = FitnessArrayOfBestFittedGenomes[k - 1];
				}

				FitnessArrayOfBestFittedGenomes[j] = pFitnessScoreArray[i];
				IDArrayOfBestFittedGenomes[j] = i;

				break;
			}
		}

		for (int32_t j = 0; j < constNumOfWorstFittedGenomes; j++)
		{
			if (pFitnessScoreArray[i] < FitnessArrayOfWorstFittedGenomes[j])
			{
				for (int32_t k = constNumOfWorstFittedGenomes - 1; k > j; k--)
				{
					IDArrayOfWorstFittedGenomes[k] = IDArrayOfWorstFittedGenomes[k - 1];
					FitnessArrayOfWorstFittedGenomes[k] = FitnessArrayOfWorstFittedGenomes[k - 1];
				}

				FitnessArrayOfWorstFittedGenomes[j] = pFitnessScoreArray[i];
				IDArrayOfWorstFittedGenomes[j] = i;

				break;
			}
		}

	} // end of for (int32_t i = 0; i < PopulationSize; i++)



	float fitnessScoreOfBestFittedAdditionalGenome = -1000000.0f;
	int32_t idOfBestFittedAdditionalGenome = 0;

	for (int32_t i = 0; i < constNumOfAdditionalGenomes; i++)
	{
		if (pFitnessScoreArray[PopulationSize + i] > fitnessScoreOfBestFittedAdditionalGenome)
		{
			fitnessScoreOfBestFittedAdditionalGenome = pFitnessScoreArray[PopulationSize + i];
			idOfBestFittedAdditionalGenome = PopulationSize + i;
		}
	}

	if (pFitnessScoreArray[idOfBestFittedAdditionalGenome] > pFitnessScoreArray[IDArrayOfBestFittedGenomes[0]])
	{
		GenomeValueCloningFunc(ppGenomeArray[IDArrayOfBestFittedGenomes[0]], ppGenomeArray[idOfBestFittedAdditionalGenome]);
	}
	else if (pFitnessScoreArray[idOfBestFittedAdditionalGenome] > pFitnessScoreArray[IDArrayOfBestFittedGenomes[1]])
	{
		GenomeValueCloningFunc(ppGenomeArray[IDArrayOfBestFittedGenomes[1]], ppGenomeArray[idOfBestFittedAdditionalGenome]);
	}
	else if (pFitnessScoreArray[idOfBestFittedAdditionalGenome] > pFitnessScoreArray[IDArrayOfBestFittedGenomes[2]])
	{
		GenomeValueCloningFunc(ppGenomeArray[IDArrayOfBestFittedGenomes[2]], ppGenomeArray[idOfBestFittedAdditionalGenome]);
	}

	UseAdditionalMutatedBestGenome = false;
	UseAdditionalMutatedSecondBestGenome = false;
	UseAdditionalBestGenomesChild = false;

	RandomGenomesChildCounter = 0;

	for (int32_t i = 0; i < constNumOfRandomGenomesChildren; i++)
		UseAdditionalRandomGenomesChild[i] = false;
}

void CGeneralPopulation::Update_Population_Ext(void)
{
	for (int32_t i = 0; i < constNumOfBestFittedGenomes; i++)
	{
		IDArrayOfBestFittedGenomes[i] = 0;
		FitnessArrayOfBestFittedGenomes[i] = -100000000.0f;
	}

	for (int32_t i = 0; i < constNumOfWorstFittedGenomes; i++)
	{
		IDArrayOfWorstFittedGenomes[i] = 0;
		FitnessArrayOfWorstFittedGenomes[i] = 100000000.0f;
	}

	for (int32_t i = 0; i < PopulationSize; i++)
	{
		for (int32_t j = 0; j < constNumOfBestFittedGenomes; j++)
		{
			if (pFitnessScoreArray[i] > FitnessArrayOfBestFittedGenomes[j])
			{
				for (uint32_t k = constNumOfBestFittedGenomes - 1; k > j; k--)
				{
					IDArrayOfBestFittedGenomes[k] = IDArrayOfBestFittedGenomes[k - 1];
					FitnessArrayOfBestFittedGenomes[k] = FitnessArrayOfBestFittedGenomes[k - 1];
				}

				FitnessArrayOfBestFittedGenomes[j] = pFitnessScoreArray[i];
				IDArrayOfBestFittedGenomes[j] = i;

				break;
			}
		}

		for (int32_t j = 0; j < constNumOfWorstFittedGenomes; j++)
		{
			if (pFitnessScoreArray[i] < FitnessArrayOfWorstFittedGenomes[j])
			{
				for (int32_t k = constNumOfWorstFittedGenomes - 1; k > j; k--)
				{
					IDArrayOfWorstFittedGenomes[k] = IDArrayOfWorstFittedGenomes[k - 1];
					FitnessArrayOfWorstFittedGenomes[k] = FitnessArrayOfWorstFittedGenomes[k - 1];
				}

				FitnessArrayOfWorstFittedGenomes[j] = pFitnessScoreArray[i];
				IDArrayOfWorstFittedGenomes[j] = i;

				break;
			}
		}

	} // end of for (int32_t i = 0; i < PopulationSize; i++)




	float fitnessScoreOfBestFittedAdditionalGenome = -1000000.0f;
	int32_t idOfBestFittedAdditionalGenome = 0;

	for (int32_t i = 0; i < constNumOfAdditionalGenomes; i++)
	{
		if (pFitnessScoreArray[PopulationSize + i] > fitnessScoreOfBestFittedAdditionalGenome)
		{
			fitnessScoreOfBestFittedAdditionalGenome = pFitnessScoreArray[PopulationSize + i];
			idOfBestFittedAdditionalGenome = PopulationSize + i;
		}
	}

	for (int32_t i = constNumOfBestFittedGenomes - 1; i > -1; i--)
	{
		if (pFitnessScoreArray[idOfBestFittedAdditionalGenome] > pFitnessScoreArray[IDArrayOfBestFittedGenomes[i]])
		{
			GenomeValueCloningFunc(ppGenomeArray[IDArrayOfBestFittedGenomes[i]], ppGenomeArray[idOfBestFittedAdditionalGenome]);
			break;
		}
	}



	UseAdditionalMutatedBestGenome = false;
	UseAdditionalMutatedSecondBestGenome = false;
	UseAdditionalBestGenomesChild = false;

	RandomGenomesChildCounter = 0;

	for (int32_t i = 0; i < constNumOfRandomGenomesChildren; i++)
		UseAdditionalRandomGenomesChild[i] = false;
}

void CGeneralPopulation::Update_PopulationKnowledge(void)
{
	void *pBestGenome = ppGenomeArray[IDArrayOfBestFittedGenomes[0]];

	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		GenomeValueCloningFunc(ppGenomeArray[i], pBestGenome);
	}
}

void CGeneralPopulation::Update_Evolution_Combine_BestTwoGenomes(pGeneralRecombination pFunc, void *pParam)
{
	if (UseAdditionalBestGenomesChild == true)
		return;

	pFunc(ppGenomeArray[PopulationSize + 2], ppGenomeArray[IDArrayOfBestFittedGenomes[0]], ppGenomeArray[IDArrayOfBestFittedGenomes[1]], &RandomNumbers, pParam);

	UseAdditionalBestGenomesChild = true;
}

void CGeneralPopulation::Update_Evolution_Combine_TwoGenomes(pGeneralRecombination pFunc, void *pParam)
{
	if (UseAdditionalRandomGenomesChild[RandomGenomesChildCounter] == true)
		return;

	int32_t id1, id2;

	for (int32_t i = 0; i < constNumPopulationSearchStepsMax; i++)
	{
		id1 = RandomNumbers.Get_IntegerNumber(0, PopulationSize);

		// die am schlechtesten angepassten Individuen d�rfen sich nicht vermehren:
		if (pFitnessScoreArray[id1] <= FitnessArrayOfWorstFittedGenomes[constNumOfWorstFittedGenomes - 1])
			continue;

		id2 = RandomNumbers.Get_IntegerNumber(0, PopulationSize);

		// die am schlechtesten angepassten Individuen d�rfen sich nicht vermehren:
		if (pFitnessScoreArray[id2] <= FitnessArrayOfWorstFittedGenomes[constNumOfWorstFittedGenomes - 1])
			continue;

		if (id1 == id2)
			continue;

		pFunc(ppGenomeArray[PopulationSize + 3 + RandomGenomesChildCounter], ppGenomeArray[id1], ppGenomeArray[id2], &RandomNumbers, pParam);


		UseAdditionalRandomGenomesChild[RandomGenomesChildCounter] = true;

		if (RandomGenomesChildCounter < constNumOfRandomGenomesChildren - 1)
			RandomGenomesChildCounter++;

		break;
	}
}

void CGeneralPopulation::Update_BaseEvolution(pGeneralMutation pFunc, void *pParam)
{
	bool bestFittedGenomes;

	for (int32_t i = 0; i < PopulationSize; i++)
	{
		bestFittedGenomes = false;

		for (int32_t j = 0; j < constNumOfBestFittedGenomes; j++)
		{
			if (i == IDArrayOfBestFittedGenomes[j])
			{
				bestFittedGenomes = true;
				break;
			}
		}

		if (bestFittedGenomes == false)
		{
			pFunc(ppGenomeArray[i], &RandomNumbers, pParam);
		}
	}
}

void CGeneralPopulation::Update_BaseEvolution2(pGeneralPermutation pFunc, void *pParam)
{
	bool bestFittedGenomes;

	for (int32_t i = 0; i < PopulationSize; i++)
	{
		bestFittedGenomes = false;

		for (int32_t j = 0; j < constNumOfBestFittedGenomes; j++)
		{
			if (i == IDArrayOfBestFittedGenomes[j])
			{
				bestFittedGenomes = true;
				break;
			}
		}

		if (bestFittedGenomes == false)
		{
			pFunc(ppGenomeArray[i], &RandomNumbers, pParam);
		}
	}
}

void CGeneralPopulation::Update_Evolution_BestGenomeOnly(pGeneralMutation pFunc, void *pParam)
{
	if (UseAdditionalMutatedBestGenome == true)
		return;

	GenomeValueCloningFunc(ppGenomeArray[PopulationSize], ppGenomeArray[IDArrayOfBestFittedGenomes[0]]);

	pFunc(ppGenomeArray[PopulationSize], &RandomNumbers, pParam);

	UseAdditionalMutatedBestGenome = true;
}

void CGeneralPopulation::Update_Evolution_BestGenomeOnly2(pGeneralPermutation pFunc, void *pParam)
{
	if (UseAdditionalMutatedBestGenome == true)
		return;


	GenomeValueCloningFunc(ppGenomeArray[PopulationSize], ppGenomeArray[IDArrayOfBestFittedGenomes[0]]);

	pFunc(ppGenomeArray[PopulationSize], &RandomNumbers, pParam);

	UseAdditionalMutatedBestGenome = true;
}

void CGeneralPopulation::Update_Evolution_SecondBestGenomeOnly(pGeneralMutation pFunc, void *pParam)
{
	if (UseAdditionalMutatedSecondBestGenome == true)
		return;

	GenomeValueCloningFunc(ppGenomeArray[PopulationSize + 1], ppGenomeArray[IDArrayOfBestFittedGenomes[1]]);

	pFunc(ppGenomeArray[PopulationSize + 1], &RandomNumbers, pParam);

	UseAdditionalMutatedSecondBestGenome = true;
}

void CGeneralPopulation::Update_Evolution_SecondBestGenomeOnly2(pGeneralPermutation pFunc, void *pParam)
{
	if (UseAdditionalMutatedSecondBestGenome == true)
		return;

	GenomeValueCloningFunc(ppGenomeArray[PopulationSize + 1], ppGenomeArray[IDArrayOfBestFittedGenomes[1]]);

	pFunc(ppGenomeArray[PopulationSize + 1], &RandomNumbers, pParam);

	UseAdditionalMutatedSecondBestGenome = true;
}

void CGeneralPopulation::Replace_WorstFitted_Genome(pGeneralReinitialization pFunc, void *pParam)
{
	pFunc(ppGenomeArray[IDArrayOfWorstFittedGenomes[0]], &RandomNumbers, pParam);
}

void CGeneralPopulation::Replace_SecondWorstFitted_Genome(pGeneralReinitialization pFunc, void *pParam)
{
	pFunc(ppGenomeArray[IDArrayOfWorstFittedGenomes[1]], &RandomNumbers, pParam);
}

void CGeneralPopulation::Replace_ThirdWorstFitted_Genome(pGeneralReinitialization pFunc, void *pParam)
{
	pFunc(ppGenomeArray[IDArrayOfWorstFittedGenomes[2]], &RandomNumbers, pParam);
}

void CGeneralPopulation::Replace_WorstFitted_Genome(uint64_t seed, pGeneralReinitialization pFunc, void *pParam)
{
	RandomNumbers.Change_Seed(seed);
	pFunc(ppGenomeArray[IDArrayOfWorstFittedGenomes[0]], &RandomNumbers, pParam);
}

void CGeneralPopulation::Replace_SecondWorstFitted_Genome(uint64_t seed, pGeneralReinitialization pFunc, void *pParam)
{
	RandomNumbers.Change_Seed(seed);
	pFunc(ppGenomeArray[IDArrayOfWorstFittedGenomes[1]], &RandomNumbers, pParam);
}

void CGeneralPopulation::Replace_ThirdWorstFitted_Genome(uint64_t seed, pGeneralReinitialization pFunc, void *pParam)
{
	RandomNumbers.Change_Seed(seed);
	pFunc(ppGenomeArray[IDArrayOfWorstFittedGenomes[2]], &RandomNumbers, pParam);
}


void CGeneralPopulation::Modify_All_Genomes(pGeneralMutation pFunc, void *pParam)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFunc(ppGenomeArray[i], &RandomNumbers, pParam);
	}
}

void CGeneralPopulation::Modify_All_Genomes2(pGeneralPermutation pFunc, void *pParam)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFunc(ppGenomeArray[i], &RandomNumbers, pParam);
	}
}
