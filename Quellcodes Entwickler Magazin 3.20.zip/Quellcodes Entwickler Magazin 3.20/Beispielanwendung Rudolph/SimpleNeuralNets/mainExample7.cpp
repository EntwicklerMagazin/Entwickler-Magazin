#include <iostream>
#include "NeuralNet.h"

using namespace std;

inline float BinaryOutput(float neuronInput)
{
	if (neuronInput > 0.9999f)
		return 1.0f;

	return 0.0f;
}

inline float TanHOutput(float neuronInput)
{
	// von -1.0f bis 1.0f:
	return tanh(neuronInput);
	//return neuronInput / (1.0f + abs(neuronInput)); // alternative

	//int32_t iValue = static_cast<int32_t>(10.0f*tanh(neuronInput));
	//float fValue = static_cast<float>(iValue);
	//return 0.1f*fValue;
}

inline float ClippedLinearOutput(float neuronInput)
{
	if (neuronInput > 1.0f)
		neuronInput = 1.0f;
	else if (neuronInput < -1.0f)
		neuronInput = -1.0f;

	return neuronInput;
}

inline float ClippedLeakyReLUOutput(float neuronInput)
{
	if (neuronInput < 0.0f)
		return max(-1.0f, 0.01f * neuronInput);
	
	return min(1.0f, neuronInput);
}

inline float ScaledSigmoidOutput(float neuronInput)
{
	// von 0.0f bis 1.0f:
	return 1.0f / (1.0f + exp(-100.0f*neuronInput));
}


//#define BINARY
#define TANH
//#define CLIPPEDLINEAR
//#define CLIPPEDLEAKYRELU
//#define SCALEDSIGMOID

class CExtendedLogicGateBrain
{
public:

	uint32_t NumInputNeurons = 2;
	uint32_t NumBiasNeurons = 1;
	uint32_t NumHiddenNeurons = 3;
	uint32_t NumOutputNeurons = 1;
	
	uint32_t NumNeurons = NumInputNeurons + NumOutputNeurons + NumHiddenNeurons + NumBiasNeurons;

	uint32_t InputNeuronID1 = 0;
	uint32_t InputNeuronID2 = 1;
	uint32_t BiasNeuronID = 2;
	uint32_t OutputNeuronID = NumNeurons - 1;
	uint32_t FirstHiddenNeuronID = 3;

	CNeuron *pNeuronArray = nullptr;

	CRandomNumbersNN RandomNumbers;

	CExtendedLogicGateBrain::CExtendedLogicGateBrain()
	{

		pNeuronArray = new (std::nothrow) CNeuron[NumNeurons];

		uint32_t i;

		for (i = 0; i < NumNeurons; i++)
			pNeuronArray[i].Connect_With_Brain(pNeuronArray);

		pNeuronArray[InputNeuronID1].Use_As_InputNeuron();
		pNeuronArray[InputNeuronID1].Init_OutputSynapses(NumHiddenNeurons);

		for (i = 0; i < NumHiddenNeurons; i++)
		{
			pNeuronArray[InputNeuronID1].Connect_With_ReceiverNeuron(i + FirstHiddenNeuronID,  /*SynapseID:*/ i);
		}

		pNeuronArray[InputNeuronID1].Randomize_OutputSynapsePlasticities(&RandomNumbers, -2.0f, 2.0);
		pNeuronArray[InputNeuronID1].Set_LearningRate(0.2f);



		pNeuronArray[InputNeuronID2].Use_As_InputNeuron();
		pNeuronArray[InputNeuronID2].Init_OutputSynapses(NumHiddenNeurons);

		for (i = 0; i < NumHiddenNeurons; i++)
		{
			pNeuronArray[InputNeuronID2].Connect_With_ReceiverNeuron(i + FirstHiddenNeuronID, /*SynapseID:*/ i);
		}

		pNeuronArray[InputNeuronID2].Randomize_OutputSynapsePlasticities(&RandomNumbers, -2.0f, 2.0);
		pNeuronArray[InputNeuronID2].Set_LearningRate(0.2f);



		pNeuronArray[BiasNeuronID].Use_As_BiasNeuron();
		pNeuronArray[BiasNeuronID].Set_BiasNeuronOutput(1.0f);
		pNeuronArray[BiasNeuronID].Init_OutputSynapses(NumHiddenNeurons);

		for (i = 0; i < NumHiddenNeurons; i++)
		{
			pNeuronArray[BiasNeuronID].Connect_With_ReceiverNeuron(i + FirstHiddenNeuronID,  /*SynapseID:*/ i);
		}

		pNeuronArray[BiasNeuronID].Randomize_OutputSynapsePlasticities(&RandomNumbers, -2.0f, 2.0);
		pNeuronArray[BiasNeuronID].Set_LearningRate(0.2f);

		uint32_t id;

		for (i = 0; i < NumHiddenNeurons; i++)
		{
			id = FirstHiddenNeuronID + i;

			pNeuronArray[id].Use_As_HiddenNeuron();
			pNeuronArray[id].Init_OutputSynapses(NumOutputNeurons);
			pNeuronArray[id].Connect_With_ReceiverNeuron(OutputNeuronID,  /*SynapseID:*/ 0);
			pNeuronArray[id].Set_ErrorFactors(1.0f, 1.0f);
			pNeuronArray[id].Set_LearningRate(0.2f);
			pNeuronArray[id].Randomize_OutputSynapsePlasticities(&RandomNumbers, -2.0f, 2.0f);

#ifdef BINARY
			pNeuronArray[id].Set_ActivationFunction(BinaryOutput);
#endif
#ifdef TANH
			pNeuronArray[id].Set_ActivationFunction(TanHOutput);
#endif
#ifdef CLIPPEDLINEAR
			pNeuronArray[id].Set_ActivationFunction(ClippedLinearOutput);
#endif
#ifdef CLIPPEDLEAKYRELU
			pNeuronArray[id].Set_ActivationFunction(ClippedLeakyReLUOutput);
#endif
#ifdef SCALEDSIGMOID
			pNeuronArray[id].Set_ActivationFunction(ScaledSigmoidOutput);
#endif

		} // end of for()

		pNeuronArray[OutputNeuronID].Use_As_OutputNeuron();
		pNeuronArray[OutputNeuronID].Set_ErrorFactors(1.0f, 1.0f);

#ifdef BINARY
		pNeuronArray[OutputNeuronID].Set_ActivationFunction(BinaryOutput);
#endif
#ifdef TANH
		pNeuronArray[OutputNeuronID].Set_ActivationFunction(TanHOutput);
#endif
#ifdef CLIPPEDLINEAR
		pNeuronArray[OutputNeuronID].Set_ActivationFunction(ClippedLinearOutput);
#endif
#ifdef CLIPPEDLEAKYRELU
		pNeuronArray[OutputNeuronID].Set_ActivationFunction(ClippedLeakyReLUOutput);
#endif
#ifdef SCALEDSIGMOID
		pNeuronArray[OutputNeuronID].Set_ActivationFunction(ScaledSigmoidOutput);
#endif



	}

	~CExtendedLogicGateBrain()
	{
		delete[] pNeuronArray;
		pNeuronArray = nullptr;
	}

	// Kopierkonstruktor l�schen:
	CExtendedLogicGateBrain(const CExtendedLogicGateBrain &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CExtendedLogicGateBrain& operator=(const CExtendedLogicGateBrain &originalObject) = delete;

	float Calculate_Output(float input1, float input2)
	{
		pNeuronArray[InputNeuronID1].Set_Input(input1);
		pNeuronArray[InputNeuronID1].Propagate_SynapticOutput();

		pNeuronArray[InputNeuronID2].Set_Input(input2);
		pNeuronArray[InputNeuronID2].Propagate_SynapticOutput();

		pNeuronArray[BiasNeuronID].Propagate_SynapticOutput();

		uint32_t id;

		for (uint32_t i = 0; i < NumHiddenNeurons; i++)
		{
			id = FirstHiddenNeuronID + i;

			pNeuronArray[id].Calculate_NeuronOutput();
			pNeuronArray[id].Propagate_SynapticOutput();
		}

		pNeuronArray[OutputNeuronID].Calculate_NeuronOutput();
		return pNeuronArray[OutputNeuronID].Get_NeuronOutput();
	}

	float Learning(float desiredOutput)
	{
		float error = pNeuronArray[OutputNeuronID].Calculate_Error(desiredOutput);

		uint32_t i, id;

		for (i = 0; i < NumHiddenNeurons; i++)
		{
			id = FirstHiddenNeuronID + i;
			pNeuronArray[id].Calculate_Error();
		}

		pNeuronArray[InputNeuronID1].Adjust_OutputSynapses_AfterErrorCalculations();
		pNeuronArray[InputNeuronID2].Adjust_OutputSynapses_AfterErrorCalculations();
		pNeuronArray[BiasNeuronID].Adjust_OutputSynapses_AfterErrorCalculations();

		for (i = 0; i < NumHiddenNeurons; i++)
		{
			id = FirstHiddenNeuronID + i;
			pNeuronArray[id].Adjust_OutputSynapses_AfterErrorCalculations();
		}

		return error;
	}
	

}; // end of class CExtendedLogicGateBrain



/*
int main(void)
{
	CExtendedLogicGateBrain Brain;

	float Input1a = 0.0f;
	float Input1b = 0.0f;

	float Input2a = 1.0f;
	float Input2b = 0.0f;

	float Input3a = 0.0f;
	float Input3b = 1.0f;

	float Input4a = 1.0f;
	float Input4b = 1.0f;

	uint32_t maxCount = 500000;
	uint32_t epoch = 0;
	float error;

	// start training:

	
	for (uint32_t i = 0; i < maxCount; i++)
	{
		epoch++;
		error = 0.0f;

		Brain.Calculate_Output(Input1a, Input1b);
		error += Brain.Learning(0.0f);
		

		Brain.Calculate_Output(Input2a, Input2b);
		error += Brain.Learning(1.0f);
	

		Brain.Calculate_Output(Input3a, Input3b);
		error += Brain.Learning(1.0f);
		

		Brain.Calculate_Output(Input4a, Input4b);
		error += Brain.Learning(0.0f);
	

		if (error < 0.001f)
			break;

	}
	

	

	// training completed

	// training statistics:

	cout << "epoch: " << epoch << endl;
	cout << "error: " << error << endl << endl;

	// neural network tests:

	cout << "input : " << Input1a << " --- " << Input1b;
	cout << "  output: " << Brain.Calculate_Output(Input1a, Input1b) << " --- desired output: " << 0.0f << endl;
	// => output: 0

	cout << "input : " << Input2a << " --- " << Input2b;
	cout << "  output: " << Brain.Calculate_Output(Input2a, Input2b) << " --- desired output: " << 1.0f << endl;
	// => output: 1

	cout << "input : " << Input3a << " --- " << Input3b;
	cout << "  output: " << Brain.Calculate_Output(Input3a, Input3b) << " --- desired output: " << 1.0f << endl;
	// => output: 1

	cout << "input : " << Input4a << " --- " << Input4b;
	cout << "  output: " << Brain.Calculate_Output(Input4a, Input4b) << " --- desired output: " << 0.0f << endl;
	// => output: 0

	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CNeuralNet Brain;
	Brain.Init_NeuralNet(7);
	Brain.Init_Input_And_OutputNeurons(2, 0.2f, true, 1, TanHOutput);
	Brain.Init_HiddenLayer1(3, false, true, TanHOutput, -2.0f, 2.0f, -2.0f, 2.0f, 0.2f);

	float InputArray1[2] = { 0.0f, 0.0f };
	float Input1a = 0.0f;
	float Input1b = 0.0f;

	float InputArray2[2] = { 1.0f, 0.0f };
	float Input2a = 1.0f;
	float Input2b = 0.0f;

	float InputArray3[2] = { 0.0f, 1.0f };
	float Input3a = 0.0f;
	float Input3b = 1.0f;

	float InputArray4[2] = { 1.0f, 1.0f };
	float Input4a = 1.0f;
	float Input4b = 1.0f;

	uint32_t maxcount = 500000;
	uint32_t epoch = 0;
	float error;
	float output;
	float desiredOutput;

	uint64_t seed = 1;

	// start training:


	for (uint32_t i = 0; i < maxcount; i++)
	{
		epoch++;
		error = 0.0f;

		Brain.Calculate_Output(&output, InputArray1);
		desiredOutput = 0.0f;
		error += Brain.Learning(&desiredOutput);
		
		Brain.Calculate_Output(&output, InputArray2);
		desiredOutput = 1.0f;
		error += Brain.Learning(&desiredOutput);
		
		Brain.Calculate_Output(&output, InputArray3);
		desiredOutput = 1.0f;
		error += Brain.Learning(&desiredOutput);
		

		Brain.Calculate_Output(&output, InputArray4);
		desiredOutput = 0.0f;
		error += Brain.Learning(&desiredOutput);
		

		if (error < 0.001f)
			break;

		// etwas Mutation (hilfreich, um einem eventuellen lokalen Fehlerminimum zu entkommen)
		// In unserem Fall wird der Lernvorgang sogar ein wenig beschleunigt!
		//Brain.RandomChange_OutputSynapsePlasticities2(seed++, -0.0015f, 0.0015f, 0.75f);
		//Brain.RandomChange_OutputSynapsePlasticities2_HiddenLayer1(seed++, -0.0015f, 0.0015f, 0.75f);

	}




	// training completed

	// training statistics:

	cout << "epoch: " << epoch << endl;
	cout << "error: " << error << endl << endl;

	// neural network tests:

	Brain.Calculate_Output(&output, InputArray1);
	

	cout << "input : " << Input1a << " --- " << Input1b;
	cout << "  output: " << output << " --- desired output: " << 0.0f << endl;
	// => output: 0

	Brain.Calculate_Output(&output, InputArray2);
	

	cout << "input : " << Input2a << " --- " << Input2b;
	cout << "  output: " << output << " --- desired output: " << 1.0f << endl;
	// => output: 1

	Brain.Calculate_Output(&output, InputArray3);

	cout << "input : " << Input3a << " --- " << Input3b;
	cout << "  output: " << output << " --- desired output: " << 1.0f << endl;
	// => output: 1

	Brain.Calculate_Output(&output, InputArray4);

	cout << "input : " << Input4a << " --- " << Input4b;
	cout << "  output: " << output << " --- desired output: " << 0.0f << endl;
	// => output: 0

	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CNeuralNet Brain;
	Brain.Init_NeuralNet(9);
	Brain.Init_Input_And_OutputNeurons(2, 0.2f, true, 1, TanHOutput);
	Brain.Init_HiddenLayer1(5, false, true, TanHOutput, -2.0f, 2.0f, -2.0f, 2.0f, 0.2f);

	float InputArray1[2] = { 0.0f, 0.0f };
	float Input1a = 0.0f;
	float Input1b = 0.0f;

	float InputArray2[2] = { 1.0f, 0.0f };
	float Input2a = 1.0f;
	float Input2b = 0.0f;

	float InputArray3[2] = { 0.0f, 1.0f };
	float Input3a = 0.0f;
	float Input3b = 1.0f;

	float InputArray4[2] = { 1.0f, 1.0f };
	float Input4a = 1.0f;
	float Input4b = 1.0f;

	uint32_t maxcount = 500000;
	uint32_t epoch = 0;
	float error;
	float output;
	float desiredOutput;

	uint64_t seed = 1;

	// start training:


	for (uint32_t i = 0; i < maxcount; i++)
	{
		epoch++;
		error = 0.0f;

		Brain.Calculate_Output(&output, InputArray1);
		desiredOutput = 0.0f;
		error += Brain.ExtremeLearning(&desiredOutput);

		Brain.Calculate_Output(&output, InputArray2);
		desiredOutput = 1.0f;
		error += Brain.ExtremeLearning(&desiredOutput);

		Brain.Calculate_Output(&output, InputArray3);
		desiredOutput = 1.0f;
		error += Brain.ExtremeLearning(&desiredOutput);


		Brain.Calculate_Output(&output, InputArray4);
		desiredOutput = 0.0f;
		error += Brain.ExtremeLearning(&desiredOutput);


		if (error < 0.001f)
			break;

	}




	// training completed

	// training statistics:

	cout << "epoch: " << epoch << endl;
	cout << "error: " << error << endl << endl;

	// neural network tests:

	Brain.Calculate_Output(&output, InputArray1);


	cout << "input : " << Input1a << " --- " << Input1b;
	cout << "  output: " << output << " --- desired output: " << 0.0f << endl;
	// => output: 0

	Brain.Calculate_Output(&output, InputArray2);


	cout << "input : " << Input2a << " --- " << Input2b;
	cout << "  output: " << output << " --- desired output: " << 1.0f << endl;
	// => output: 1

	Brain.Calculate_Output(&output, InputArray3);

	cout << "input : " << Input3a << " --- " << Input3b;
	cout << "  output: " << output << " --- desired output: " << 1.0f << endl;
	// => output: 1

	Brain.Calculate_Output(&output, InputArray4);

	cout << "input : " << Input4a << " --- " << Input4b;
	cout << "  output: " << output << " --- desired output: " << 0.0f << endl;
	// => output: 0

	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CNeuralNet Brain;
	Brain.Init_NeuralNet(7);
	Brain.Init_Input_And_OutputNeurons(2, 0.2f, true, 1, TanHOutput);
	Brain.Init_HiddenLayer1(3, false, true, TanHOutput, -2.0f, 2.0f, -2.0f, 2.0f, 0.2f);

	uint32_t ActivationSequenceArray[7] = { 0, 1, 2, 4, 5, 6, 3 };
	Brain.Init_ActivationSequenceArray(7, ActivationSequenceArray);

	float InputArray1[2] = { 0.0f, 0.0f };
	float Input1a = 0.0f;
	float Input1b = 0.0f;

	float InputArray2[2] = { 1.0f, 0.0f };
	float Input2a = 1.0f;
	float Input2b = 0.0f;

	float InputArray3[2] = { 0.0f, 1.0f };
	float Input3a = 0.0f;
	float Input3b = 1.0f;

	float InputArray4[2] = { 1.0f, 1.0f };
	float Input4a = 1.0f;
	float Input4b = 1.0f;

	uint32_t maxcount = 500000;
	uint32_t epoch = 0;
	float error;
	float output;
	float desiredOutput;

	// start training:


	for (uint32_t i = 0; i < maxcount; i++)
	{
		epoch++;
		error = 0.0f;

		//Brain.Calculate_Output(&output, InputArray1);
		Brain.Calculate_Output_UseActivationSequence(&output, InputArray1);
		desiredOutput = 0.0f;
		//error += Brain.Learning(&desiredOutput);
		error += Brain.Learning_UseActivationSequence(&desiredOutput);

		//Brain.Calculate_Output(&output, InputArray2);
		Brain.Calculate_Output_UseActivationSequence(&output, InputArray2);
		desiredOutput = 1.0f;
		//error += Brain.Learning(&desiredOutput);
		error += Brain.Learning_UseActivationSequence(&desiredOutput);

		//Brain.Calculate_Output(&output, InputArray3);
		Brain.Calculate_Output_UseActivationSequence(&output, InputArray3);
		desiredOutput = 1.0f;
		//error += Brain.Learning(&desiredOutput);
		error += Brain.Learning_UseActivationSequence(&desiredOutput);

		//Brain.Calculate_Output(&output, InputArray4);
		Brain.Calculate_Output_UseActivationSequence(&output, InputArray4);
		desiredOutput = 0.0f;
		//error += Brain.Learning(&desiredOutput);
		error += Brain.Learning_UseActivationSequence(&desiredOutput);

		if (error < 0.001f)
			break;

	}




	// training completed

	// training statistics:

	cout << "epoch: " << epoch << endl;
	cout << "error: " << error << endl << endl;

	// neural network tests:

	//Brain.Calculate_Output(&output, InputArray1);
	Brain.Calculate_Output_UseActivationSequence(&output, InputArray1);

	cout << "input : " << Input1a << " --- " << Input1b;
	cout << "  output: " << output << " --- desired output: " << 0.0f << endl;
	// => output: 0

	//Brain.Calculate_Output(&output, InputArray2);
	Brain.Calculate_Output_UseActivationSequence(&output, InputArray2);

	cout << "input : " << Input2a << " --- " << Input2b;
	cout << "  output: " << output << " --- desired output: " << 1.0f << endl;
	// => output: 1

	//Brain.Calculate_Output(&output, InputArray3);
	Brain.Calculate_Output_UseActivationSequence(&output, InputArray3);

	cout << "input : " << Input3a << " --- " << Input3b;
	cout << "  output: " << output << " --- desired output: " << 1.0f << endl;
	// => output: 1

	//Brain.Calculate_Output(&output, InputArray4);
	Brain.Calculate_Output_UseActivationSequence(&output, InputArray4);

	cout << "input : " << Input4a << " --- " << Input4b;
	cout << "  output: " << output << " --- desired output: " << 0.0f << endl;
	// => output: 0

	getchar();
	return 0;
}
*/

