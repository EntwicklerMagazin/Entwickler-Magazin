#include <iostream>
//#include <chrono>
#include <omp.h>
#include <thread>
#include "ConsoleHelperFunctions.h"
#include "LogFile.h"
#include "HelpfulTemplates.h"
#include "RandomNumbers.h"
#include "Graph.h"
#include "MemoryManagement.h"
#include "SparseVectorMatrix.h"

using namespace std;
using namespace chrono;
using namespace HelperStuff;


#define KEYDOWN(vk_code) ((GetAsyncKeyState(vk_code) & 0x8000) ? 1 : 0)
#define KEYUP(vk_code)   ((GetAsyncKeyState(vk_code) & 0x8000) ? 0 : 1)

/*
int main(void)
{
	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/



/*
int main(void)
{
	int32_t counter = 0;

	for (int32_t i = 0; i < 5; i++)
	{
		for (int32_t j = 0; j < 5; j++)
		{
			cout << counter << endl;
			counter++;

			if (counter == 15)
			{
				goto endOfOuterLoop;
			}
		}
	}

endOfOuterLoop:;

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/



static int32_t g_RecursionTestOutputFuncCallCounter = 0;


void RecursionTestOutput(int32_t num)
{
	cout << "(" << g_RecursionTestOutputFuncCallCounter << ") " << num << " ";
}


// Tail-Rekursion: Der rekursive Funktionsaufruf erfolgt innerhalb der sich
// selbst aufrufenden (also rekursiven) Funktion im letzten Schritt.
// Tail-rekursive Funktionen lassen sich vom Compiler optimieren und
// und gehen sparsam mit dem Stack-Speicher um, da alle Berechnungen,
// die den Stack involvieren, bereits vor dem rekursiven Funktionsaufruf 
// abgeschlossen sind.

 // Bildschirmausgabe: (1) 0, (2) 1, (3) 2, (4) 3

void TailRecursiveTestFunction(int32_t counter, int32_t maxCount)
{
	g_RecursionTestOutputFuncCallCounter++;

	if (counter >= maxCount)
	{
		return;
	}

	RecursionTestOutput(counter);

	TailRecursiveTestFunction(counter + 1, maxCount);
}

// Head-Rekursion: Der rekursive Funktionsaufruf erfolgt innerhalb der sich selbst
// aufrufenden (also rekursiven) Funktion, bevor die besagte Funktion mit der
// Verrichtung der ihr zugewiesenen Arbeit beginnt

// Bildschirmausgabe: (5) 3, (5) 2, (5) 1, (5) 0
// Erst nachdem die HeadRecursiveTestFunction() f�nfmal aufgerufen wurde, erfolgt
// mit jedem Funktions-R�cksprung ein Aufruf der RecursionTestOutput()-Funktion.
// Im Vergleich zur Tail-rekursiven Funktion findet dar�ber hinaus ein zus�tzlicher
// Aufruf der HeadRecursiveTestFunction statt.

void HeadRecursiveTestFunction(int32_t counter, int32_t maxCount)
{
	g_RecursionTestOutputFuncCallCounter++;

	if (counter >= maxCount)
	{
		return;
	}

	HeadRecursiveTestFunction(counter + 1, maxCount);

	RecursionTestOutput(counter);
}

/*
int main(void)
{
	g_RecursionTestOutputFuncCallCounter = 0;
	HeadRecursiveTestFunction(0, 4);

	cout << endl;

	g_RecursionTestOutputFuncCallCounter = 0;
	TailRecursiveTestFunction(0, 4);

	cout << endl;

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/

int32_t RecursiveCounter(int32_t counter, int32_t maxCount)
{
	g_RecursionTestOutputFuncCallCounter++;

	if (counter == maxCount)
	{
		return counter;
	}

	counter++;

	cout << g_RecursionTestOutputFuncCallCounter << " " << counter << endl;

	return RecursiveCounter(counter, maxCount);
}

/*
int main(void)
{
	g_RecursionTestOutputFuncCallCounter = 0;
	cout << RecursiveCounter(0, 0) << endl;

	g_RecursionTestOutputFuncCallCounter = 0;
	cout << RecursiveCounter(0, 1) << endl;

	g_RecursionTestOutputFuncCallCounter = 0;
	cout << RecursiveCounter(0, 2) << endl;

	g_RecursionTestOutputFuncCallCounter = 0;
	cout << RecursiveCounter(0, 3) << endl;

	g_RecursionTestOutputFuncCallCounter = 0;
	cout << RecursiveCounter(0, 4) << endl;
	

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/


int32_t RecursiveBinarySearch(int32_t *pValueArray, int32_t searchedValue, int32_t startIndex, int32_t endIndex)
{
	if (endIndex < startIndex)
	{
		// Wenn Element nicht gefunden, dann -1 zur�ckgeben
		return -1;
	}
	int32_t centerIndex = (startIndex + endIndex) / 2;

	if (pValueArray[centerIndex] == searchedValue)
	{
		// Wenn Element gefunden, dann Index zur�ckgeben
		return centerIndex;
	}
	else
	{
		if (pValueArray[centerIndex] > searchedValue)
		{
			// Rekursiver Aufruf der Funktion f�r die Suche in der vordere Array-H�lfte:
			return RecursiveBinarySearch(pValueArray, searchedValue, startIndex, centerIndex - 1);
			
		}
		else
		{
			// Rekursiver Aufruf der Funktion f�r die Suche in der hinteren Array-H�lfte:
			return RecursiveBinarySearch(pValueArray, searchedValue, centerIndex + 1, endIndex);
		}
	}
}

/*
int main(void)
{
	static constexpr int32_t constArraySize = 10;
	static constexpr int32_t constArraySizeMinus1 = constArraySize - 1;
	
	int32_t testArray[constArraySize] = {0, 10, 20, 30, 40, 50, 60, 70, 80, 90};

	int32_t searchedValue = 60;
	int32_t resultIndex = RecursiveBinarySearch(testArray, searchedValue, 0, constArraySizeMinus1);

	cout << resultIndex << endl;

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/


int32_t IterativeFibonacciSequenceCalc(int32_t maxSequenceElement)
{
	if (maxSequenceElement == 0)
	{
		return 0;
	}
	if (maxSequenceElement == 1)
	{
		return 1;
	}

	int32_t prevPrevFibonacciValue = 0;
	int32_t prevFibonacciValue = 1;
	int32_t fibonacciValue = 1;


	//for (int32_t i = maxSequenceElement; i >= 2; i--)
	for (int32_t i = 2; i <= maxSequenceElement; i++)
	{
		fibonacciValue = prevFibonacciValue + prevPrevFibonacciValue;
		prevPrevFibonacciValue = prevFibonacciValue;
		prevFibonacciValue = fibonacciValue;
	}

	return fibonacciValue;
}


int32_t TailRecursiveFibonacciSequenceCalc(int32_t sequenceElementCounter, int32_t fibonacciValue = 1, int32_t prevFibonacciValue = 0)
{
	if (sequenceElementCounter == 0)
		return prevFibonacciValue;

	return TailRecursiveFibonacciSequenceCalc(sequenceElementCounter - 1, /*sumOfLastSequenceElements:*/ fibonacciValue + prevFibonacciValue, fibonacciValue);
}

/*
int main(void)
{
	//Fibonacci sequence: 0, 1, 1, 2, 3, 5, 8, 13, 21, 34, ...

	cout << "recursive Fibonacci sequence Calculation:" << endl;

	int32_t result = TailRecursiveFibonacciSequenceCalc(0);
	cout << result << endl;

	result = TailRecursiveFibonacciSequenceCalc(1);
	cout << result << endl;

	result = TailRecursiveFibonacciSequenceCalc(2);
	cout << result << endl;

	result = TailRecursiveFibonacciSequenceCalc(3);
	cout << result << endl;

	result = TailRecursiveFibonacciSequenceCalc(4);
	cout << result << endl;

	result = TailRecursiveFibonacciSequenceCalc(5);
	cout << result << endl;

	result = TailRecursiveFibonacciSequenceCalc(6);
	cout << result << endl;

	result = TailRecursiveFibonacciSequenceCalc(7);
	cout << result << endl;

	result = TailRecursiveFibonacciSequenceCalc(8);
	cout << result << endl;

	cout << "iterative Fibonacci sequence Calculation:" << endl;

	result = IterativeFibonacciSequenceCalc(0);
	cout << result << endl;

	result = IterativeFibonacciSequenceCalc(1);
	cout << result << endl;

	result = IterativeFibonacciSequenceCalc(2);
	cout << result << endl;

	result = IterativeFibonacciSequenceCalc(3);
	cout << result << endl;

	result = IterativeFibonacciSequenceCalc(4);
	cout << result << endl;

	result = IterativeFibonacciSequenceCalc(5);
	cout << result << endl;

	result = IterativeFibonacciSequenceCalc(6);
	cout << result << endl;

	result = IterativeFibonacciSequenceCalc(7);
	cout << result << endl;

	result = IterativeFibonacciSequenceCalc(8);
	cout << result << endl;


	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/


/*
int main(void)
{
	CRandomNumbersWithoutRepetition RandomNumbers;
	RandomNumbers.Init_Numbers(6);
	RandomNumbers.Change_Seed(45454);

	cout << RandomNumbers.Get_Number() << " ";
	cout << RandomNumbers.Get_Number() << " ";
	cout << RandomNumbers.Get_Number() << " ";
	cout << RandomNumbers.Get_Number() << " ";
	cout << RandomNumbers.Get_Number() << " ";
	cout << RandomNumbers.Get_Number() << " " << endl;

	cout << RandomNumbers.Undo_GetOrSelectNumber() << " ";
	cout << RandomNumbers.Undo_GetOrSelectNumber() << " ";
	cout << RandomNumbers.Undo_GetOrSelectNumber() << " ";
	cout << RandomNumbers.Undo_GetOrSelectNumber() << " ";
	cout << RandomNumbers.Undo_GetOrSelectNumber() << " ";
	cout << RandomNumbers.Undo_GetOrSelectNumber() << " " << endl;

	cout << RandomNumbers.Get_Number() << " ";
	cout << RandomNumbers.Get_Number() << " ";
	cout << RandomNumbers.Get_Number() << " ";
	cout << RandomNumbers.Get_Number() << " ";
	cout << RandomNumbers.Get_Number() << " ";
	cout << RandomNumbers.Get_Number() << " " << endl;

	RandomNumbers.Reset_Numbers();

	cout << RandomNumbers.Get_GreaterNumber(3) << " ";
	cout << RandomNumbers.Get_GreaterNumber(3) << " ";
	cout << RandomNumbers.Get_GreaterNumber(3) << " ";
	cout << RandomNumbers.Get_GreaterNumber(3) << " ";
	cout << RandomNumbers.Get_GreaterNumber(3) << " ";
	cout << RandomNumbers.Get_GreaterNumber(3) << " " << endl;
	
	RandomNumbers.Reset_Numbers();

	cout << RandomNumbers.Get_SmallerNumber(4) << " ";
	cout << RandomNumbers.Get_SmallerNumber(4) << " ";
	cout << RandomNumbers.Get_SmallerNumber(4) << " ";
	cout << RandomNumbers.Get_SmallerNumber(4) << " ";
	cout << RandomNumbers.Get_SmallerNumber(4) << " ";
	cout << RandomNumbers.Get_SmallerNumber(4) << " " << endl;

	RandomNumbers.Reset_Numbers();

	cout << RandomNumbers.Get_Number2(2, 5) << " ";
	cout << RandomNumbers.Get_Number2(2, 5) << " ";
	cout << RandomNumbers.Get_Number2(2, 5) << " ";
	cout << RandomNumbers.Get_Number2(2, 5) << " ";
	cout << RandomNumbers.Get_Number2(2, 5) << " ";
	cout << RandomNumbers.Get_Number2(2, 5) << " " << endl;


	cout << endl;
	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/


/*
int main(void)
{
	CRandomNumbersWithoutRepetition RandomNumbers;
	RandomNumbers.Init_Numbers(10);
	RandomNumbers.Change_Seed(9454);

	int32_t ExcludedNumberArray[2] = { 3, 5 };

	cout << RandomNumbers.Get_Number(ExcludedNumberArray, 2, 10) << " ";
	cout << RandomNumbers.Get_Number(ExcludedNumberArray, 2, 10) << " ";
	cout << RandomNumbers.Get_Number(ExcludedNumberArray, 2, 10) << " ";
	cout << RandomNumbers.Get_Number(ExcludedNumberArray, 2, 10) << " ";
	cout << RandomNumbers.Get_Number(ExcludedNumberArray, 2, 10) << " ";
	cout << RandomNumbers.Get_Number(ExcludedNumberArray, 2, 10) << " ";
	cout << RandomNumbers.Get_Number(ExcludedNumberArray, 2, 10) << " " << endl;

	cout << endl;
	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CMultiDimFloatArray TestArray;

	TestArray.Set_DimensionNumber(3);
	TestArray.Set_Dimension(0, 3);
	TestArray.Set_Dimension(1, 4);
	TestArray.Set_Dimension(2, 5);
	TestArray.Init_Array();

	for (int32_t i = 0; i < TestArray.NumOfArrayElements; i++)
	{
		TestArray.pArray[i] = static_cast<float>(i);
	}

	cout << TestArray.NumOfArrayElements << endl;

	TestArray.Set_ElementInsideDimension(0, 1);
	TestArray.Set_ElementInsideDimension(1, 0);
	TestArray.Set_ElementInsideDimension(2, 0);

	cout << TestArray.Get_ArrayValue() << endl;

	TestArray.Set_ElementInsideDimension(0, 0);
	TestArray.Set_ElementInsideDimension(1, 1);
	TestArray.Set_ElementInsideDimension(2, 0);

	cout << TestArray.Get_ArrayValue() << endl;

	TestArray.Set_ElementInsideDimension(0, 0);
	TestArray.Set_ElementInsideDimension(1, 0);
	TestArray.Set_ElementInsideDimension(2, 1);

	cout << TestArray.Get_ArrayValue() << endl;

	cout << endl;

	for (int32_t i = 0; i < 5; i++)
	{
		TestArray.Set_ElementInsideDimension(2, i);

		for (int32_t j = 0; j < 4; j++)
		{
			TestArray.Set_ElementInsideDimension(1, j);

			for (int32_t k = 0; k < 3; k++)
			{
				TestArray.Set_ElementInsideDimension(0, k);
				
				cout << TestArray.Get_ArrayValue();
				getchar();
			}
		}
	}

	cout << endl << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CSparseBinaryVector SparseBinaryVector1;
	SparseBinaryVector1.Initialize(5);

	CSparseBinaryVector2 SparseBinaryVector2;
	SparseBinaryVector2.Initialize(5);

	bool InputVector1[5] = { true, false, true, true, false };
	bool InputVector2[5] = { false, false, false, true, true };

	SparseBinaryVector1.Set_Vector(InputVector1);
	SparseBinaryVector2.Set_Vector(InputVector2);

	bool OutputVector1[5];
	bool OutputVector2[5];

	SparseBinaryVector1.Get_Vector(OutputVector1);
	SparseBinaryVector2.Get_Vector(OutputVector2);

	for (int32_t i = 0; i < 5; i++)
	{
		cout << static_cast<int32_t>(OutputVector1[i]) << " ";
	}

	cout << endl;

	for (int32_t i = 0; i < 5; i++)
	{
		cout << static_cast<int32_t>(OutputVector2[i]) << " ";
	}

	cout << endl;

	int32_t NonZeroElementIDArray[5];

	int32_t NumOfNonZeroElements = SparseBinaryVector1.Get_IDs_Of_NonZero_Elements(NonZeroElementIDArray);

	cout << NumOfNonZeroElements << endl;

	for (int32_t i = 0; i < NumOfNonZeroElements; i++)
	{
		cout << NonZeroElementIDArray[i] << " ";
	}

	cout << endl;

	NumOfNonZeroElements = SparseBinaryVector2.Get_IDs_Of_NonZero_Elements(NonZeroElementIDArray);

	cout << NumOfNonZeroElements << endl;

	for (int32_t i = 0; i < NumOfNonZeroElements; i++)
	{
		cout << NonZeroElementIDArray[i] << " ";
	}

	cout << endl;

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CSparseVector SparseVector1;
	SparseVector1.Initialize(5);

	CSparseVector2 SparseVector2;
	SparseVector2.Initialize(5);

	float InputVector1[5] = { 1.0f, 0.0f, 1.0f, 1.0f, 0.0f };
	float InputVector2[5] = { 0.0f, 0.0f, 0.0f, 1.0f, 1.0f };

	SparseVector1.Set_Vector(InputVector1);
	SparseVector2.Set_Vector(InputVector2);

	float OutputVector1[5];
	float OutputVector2[5];

	SparseVector1.Get_Vector(OutputVector1);
	SparseVector2.Get_Vector(OutputVector2);

	for (int32_t i = 0; i < 5; i++)
	{
		cout << static_cast<int32_t>(OutputVector1[i]) << " ";
	}

	cout << endl;

	for (int32_t i = 0; i < 5; i++)
	{
		cout << static_cast<int32_t>(OutputVector2[i]) << " ";
	}

	cout << endl;

	int32_t NonZeroElementIDArray[5];

	int32_t NumOfNonZeroElements = SparseVector1.Get_IDs_Of_NonZero_Elements(NonZeroElementIDArray);

	cout << NumOfNonZeroElements << endl;

	for (int32_t i = 0; i < NumOfNonZeroElements; i++)
	{
		cout << NonZeroElementIDArray[i] << " ";
	}

	cout << endl;

	NumOfNonZeroElements = SparseVector2.Get_IDs_Of_NonZero_Elements(NonZeroElementIDArray);

	cout << NumOfNonZeroElements << endl;

	for (int32_t i = 0; i < NumOfNonZeroElements; i++)
	{
		cout << NonZeroElementIDArray[i] << " ";
	}

	cout << endl;


	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/


/*
void TestFunction(CSecuredArray<float, 10>& refArray)
{
	for (size_t i = 0; i < 10; i++)
		cout << refArray[i] << endl;
}

int main(void)
{
	CRandomNumbersNN RandomNumbers;

	CSecuredArray<float, 10> testArray;

	for (int32_t i = 0; i < 10; i++)
	{
		//testArray[i] = 5 + i;
		testArray[i] = RandomNumbers.Get_IntegerNumber2(-2, 2);
	}

	TestFunction(testArray);

	cout << endl;

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/


/*
// Console Graphics Game Loop Test:
int main(void)
{
	Begin_Log(0, "Begin Log", "LogFile.txt");
	Set_Title("Test App");
	Set_ConsolePos(10, 10);
	Set_FontSize(10, 20);

	CInputHandling InputHandling;
	InputHandling.Initialize();

	Clear_Terminal_And_Reset_CursorPos();

	CWindowsConsoleScreenBuffer WinConsole;
	WinConsole.Initialize(65, 40, false, BackgroundColor);

	Set_Title("Test App");

	Set_ConsolePos(10, 10);

	WinConsole.Set_CursorVisibilityAndSize(FALSE);
	//WinConsole.Set_Font(L"Consolas", 15, 15);
	//WinConsole.Set_Font(L"Consolas", 4, 4);
	//WinConsole.Set_Font(L"Consolas", 8, 8);
	WinConsole.Set_Font_Ext(L"Consolas", 90, 15, 15);
	//WinConsole.Set_Font_Ext(L"Consolas", 90, 10, 20);

	//WinConsole.Set_BackgroundColor(RGB(100, 50, 25));
	WinConsole.Set_BackgroundColor(BackgroundColor);

	Set_CursorVisibilityAndSize(false);


	char strBuffer[100];

	bool leftMouseButtonClick = false;
	bool middleMouseButtonClick = false; 
	bool rightMouseButtonClick = false;

	float FrameTime = 1.0f;
	float FrameRate = 1.0f;

	CWindowsConsole2DObject TestObject;
	TestObject.Initialize(5, 5);

	

#pragma omp parallel num_threads(2)
	{
		do
		{
			if (KEYDOWN(VK_ESCAPE) == true)
				break;

			int32_t threadID = omp_get_thread_num();

			if (threadID == 1)
			{
				InputHandling.Check_For_Input();
			}
			else if (threadID == 0) // master thread
			{
				//auto last_timepoint = std::chrono::steady_clock::now();
				auto last_timepoint = steady_clock::now();

				if (InputHandling.LeftMouseButtonPressed == true)
				{
					if (leftMouseButtonClick == false)
						leftMouseButtonClick = true;
					else
						leftMouseButtonClick = false;
				}

				if (InputHandling.MiddleMouseButtonPressed == true)
				{
					if (middleMouseButtonClick == false)
						middleMouseButtonClick = true;
					else
						middleMouseButtonClick = false;
				}

				if (InputHandling.RightMouseButtonPressed == true)
				{
					if (rightMouseButtonClick == false)
						rightMouseButtonClick = true;
					else
						rightMouseButtonClick = false;
				}

				InputHandling.Reset_MouseButtons();

				int32_t mousePosX = InputHandling.MousePosX;
				int32_t mousePosY = InputHandling.MousePosY;

				TestObject.Set_Character(2, 2, 'B', lightgreen, yello);
				TestObject.Set_Pixel(2, 1, lightred);
				TestObject.Set_Pixel(1, 2, lightred);
				TestObject.Set_Pixel(3, 2, lightred);
				TestObject.Set_Pixel(2, 3, lightred);
				
				WinConsole.Clear_BackBuffer();

				WinConsole.Draw_2DObject_Into_BackBuffer(15, 15, TestObject.pDataArray, TestObject.NumCharactersPerRow, TestObject.NumCharactersPerColumn);

				sprintf(strBuffer, "Hello World. Press ESC to exit game loop");
				WinConsole.Write_String_Into_BackBuffer(2, 2, strBuffer, lightaqua, black);

				sprintf(strBuffer, "FrameRate: %f", FrameRate);
				WinConsole.Write_String_Into_BackBuffer(2, 4, strBuffer, lightaqua, black);

				sprintf(strBuffer, "mousePosX: %d --- mousePosY: %d", mousePosX, mousePosY);
				WinConsole.Write_String_Into_BackBuffer(2, 6, strBuffer, lightaqua, black);

				int32_t tempInt1 = static_cast<int32_t>(leftMouseButtonClick);
				int32_t tempInt2 = static_cast<int32_t>(rightMouseButtonClick);
				int32_t tempInt3 = static_cast<int32_t>(middleMouseButtonClick);

				sprintf(strBuffer, "%d --- %d --- %d", tempInt1, tempInt2, tempInt3);
				WinConsole.Write_String_Into_BackBuffer(2, 8, strBuffer, lightaqua, black);

				WinConsole.Present_BackBuffer();

				leftMouseButtonClick = false;
				rightMouseButtonClick = false;
				middleMouseButtonClick = false;

				//Frame-Bremse:

				auto current_timepoint = steady_clock::now();

				//while (current_timepoint - last_timepoint < 250ms)
				//while (current_timepoint - last_timepoint < 50ms)
				while (current_timepoint - last_timepoint < 16ms)
				//while (current_timepoint - last_timepoint < 16666us) // 16.7 Millisekunden (ms)  bzw. 16666 Mikrosekunden (us): maximal 60 Frames pro Sekunde					
				{
					current_timepoint = steady_clock::now();
				}

				FrameTime = 0.000000001f * (current_timepoint - last_timepoint).count();
				FrameRate = 1.0f / FrameTime;

			} // end of else if (threadID == 0) // master thread
		} while (true);
	} // end of #pragma omp parallel num_threads(2)


	InputHandling.CleanUp();
	WinConsole.Clear_BackBuffer();
	WinConsole.Present_BackBuffer();
	WinConsole.CleanUp();

	Set_CursorVisibilityAndSize(true);
	Reset_CursorPos();
	Set_CursorPos(0, 0);

	cout << "bye bye (Press Return)" << endl;
	getchar();
	Add_To_Log(0, "bye bye");
	return 0;
}
*/


/*
int main(void)
{
	CGeneralNode GeneralNode;

	GeneralNode.Init_FeatureValueArray(3);
	GeneralNode.Init_AdjacentNodes(10);

	GeneralNode.Add_AdjacentNode(7);
	GeneralNode.Add_AdjacentNode(45);
	GeneralNode.Add_AdjacentNode(2);
	GeneralNode.Remove_AdjacentNode(5);
	GeneralNode.Add_AdjacentNode(15);

	cout << "NumOfAdjacentNodes: " << GeneralNode.NumOfAdjacentNodes << endl;
	GeneralNode.Output_Init_AdjacentNodeIDs();

	GeneralNode.Remove_AdjacentNode(2);

	cout << "NumOfAdjacentNodes: " << GeneralNode.NumOfAdjacentNodes << endl;
	GeneralNode.Output_Init_AdjacentNodeIDs();

	cout << endl;

	cout << "NumOfAdjacentNodes: " << GeneralNode.NumOfAdjacentNodes << endl;

	for (int32_t i = 0; i < GeneralNode.NumOfAdjacentNodes; i++)
	{
		cout << GeneralNode.pAdjacentNodeIDArray[i] << " ";
	}

	cout << endl;

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/






