#include "LogFile.h"

#pragma warning( disable: 4996)

using namespace std;



namespace HelperStuff
{


#define NumUseableLogFilesMax 5
#define NumUseableLogFilesMaxMinus1 4
char LogFileNameList[NumUseableLogFilesMax][200];

void Begin_Log(uint32_t logFileID, const char *pMessage,
	const char *pLogFileName)
{
	if (logFileID > NumUseableLogFilesMaxMinus1)
		return;

	if (pLogFileName == nullptr)
		sprintf(LogFileNameList[logFileID], "LogFile.txt");
	else
		sprintf(LogFileNameList[logFileID], pLogFileName);

	FILE *pfile;

	if ((pfile = fopen(LogFileNameList[logFileID], "w")) == nullptr)
		return;

	fprintf(pfile, "%s\n", pMessage);

	// Ausgabepuffer leeren und Inhalt sofort indie Datei schreiben (optional): 
	//fflush(pfile);

	fclose(pfile);
}

void Add_To_Log(uint32_t logFileID, const char* pMessage)
{
	if (logFileID > NumUseableLogFilesMaxMinus1)
		return;

	FILE* pfile;

	if ((pfile = fopen(LogFileNameList[logFileID], "a")) == nullptr)
		return;

	fprintf(pfile, "\n%s\n", pMessage);
	//fflush(pfile); //  Ausgabepuffer leeren
	fclose(pfile);
}

void Add_To_Log(uint32_t logFileID, const char* pMessage, const char* pProblem)
{
	if (logFileID > NumUseableLogFilesMaxMinus1)
		return;

	FILE* pfile;

	if ((pfile = fopen(LogFileNameList[logFileID], "a")) == nullptr)
		return;

	fprintf(pfile, "\n%s: %s\n", pMessage, pProblem);
	//fflush(pfile); //  Ausgabepuffer leeren
	fclose(pfile);
}

void Add_To_Log(uint32_t logFileID, const char *pMessage, float value)
{
	if (logFileID > NumUseableLogFilesMaxMinus1)
		return;

	FILE *pfile;

	if ((pfile = fopen(LogFileNameList[logFileID], "a")) == nullptr)
		return;

	
	fprintf(pfile, "\n%s: %f\n", pMessage, value);

	/*  Ausgabepuffer leeren und Inhalt sofort in
	die Datei schreiben (optional): */
	//fflush(pfile);
	fclose(pfile);
}


void Add_To_Log(uint32_t logFileID, const char *pMessage, long value)
{
	if (logFileID > NumUseableLogFilesMaxMinus1)
		return;

	FILE *pfile;

	if ((pfile = fopen(LogFileNameList[logFileID], "a")) == nullptr)
		return;

	fprintf(pfile, "\n%s: %d\n", pMessage, value);

	/*  Ausgabepuffer leeren und Inhalt sofort in
	die Datei schreiben (optional): */
	//fflush(pfile);
	fclose(pfile);
}

void Add_To_Log(uint32_t logFileID, const char* pMessage, unsigned long value)
{
	if (logFileID > NumUseableLogFilesMaxMinus1)
		return;

	FILE *pfile;

	if ((pfile = fopen(LogFileNameList[logFileID], "a")) == nullptr)
		return;

	fprintf(pfile, "\n%s: %u\n", pMessage, value);
	//fflush(pfile); //  Ausgabepuffer leeren
	fclose(pfile);
}


void Add_To_Log(uint32_t logFileID, const char *pMessage, int32_t value)
{
	if (logFileID > NumUseableLogFilesMaxMinus1)
		return;

	FILE *pfile;

	if ((pfile = fopen(LogFileNameList[logFileID], "a")) == nullptr)
		return;

	
	fprintf(pfile, "\n%s: %I32d\n", pMessage, value);

	/*  Ausgabepuffer leeren und Inhalt sofort in
	die Datei schreiben (optional): */
	//fflush(pfile);
	fclose(pfile);
}

void Add_To_Log(uint32_t logFileID, const char *pMessage, int64_t value)
{
	if (logFileID > NumUseableLogFilesMaxMinus1)
		return;

	FILE *pfile;

	if ((pfile = fopen(LogFileNameList[logFileID], "a")) == nullptr)
		return;


	fprintf(pfile, "\n%s: %I64d\n", pMessage, value);

	/*  Ausgabepuffer leeren und Inhalt sofort in
	die Datei schreiben (optional): */
	//fflush(pfile);
	fclose(pfile);
	
}

void Add_To_Log(uint32_t logFileID, const char *pMessage, uint32_t value)
{
	if (logFileID > NumUseableLogFilesMaxMinus1)
		return;

	FILE *pfile;

	if ((pfile = fopen(LogFileNameList[logFileID], "a")) == nullptr)
		return;

	
	fprintf(pfile, "\n%s: %I32u\n", pMessage, value);
	/*  Ausgabepuffer leeren und Inhalt sofort in
	die Datei schreiben (optional): */
	//fflush(pfile);
	fclose(pfile);
	
}

void Add_To_Log(uint32_t logFileID, const char *pMessage, uint64_t value)
{
	if (logFileID > NumUseableLogFilesMaxMinus1)
		return;

	FILE *pfile;

	if ((pfile = fopen(LogFileNameList[logFileID], "a")) == nullptr)
		return;

	
	fprintf(pfile, "\n%s: %I64u\n", pMessage, value);

	/*  Ausgabepuffer leeren und Inhalt sofort in
	die Datei schreiben (optional): */
	//fflush(pfile);
	fclose(pfile);	
}

} /* end of namespace HelperStuff */

