// Schutz vor Mehrfachdeklarationen :

#ifndef _NeuralNet_V2_H_
#define _NeuralNet_V2_H_

#include <iostream>
#include <fstream>
#include "LogFile.h"
#include "RandomNumbers.h"
#include "NeuralNetInlineFunctions.h"


static constexpr float ConstPI = 3.1415927f;
static constexpr float Const2PI = 2.0f * ConstPI;
static constexpr float ConstHalfPI = 0.5f * ConstPI;
static constexpr float ConstInvPI = 1.0f / ConstPI;
static constexpr float ConstPIDevidedBy180 = ConstPI / 180.0f;
static constexpr float ConstInvPIDevidedBy180 = 180.0f / ConstPI;


#ifndef max
#define max(a,b)    ( ((a) > (b)) ? (a) : (b) )
#endif

#ifndef min
#define min(a,b)    ( ((a) < (b)) ? (a) : (b) )
#endif

void _Calculate_Error(float *pOutErrorValue, float *pOutVariance, float desiredValue, float actualValue, float errorFactor1 = 1.0f, float errorFactor2 = 1.0f);
void _Calculate_Errors(int32_t numOfValues, float *pOutErrorValueArray, float *pOutVarianceArray, float *pInDesiredValueArray, float *pInActualValueArray, float errorFactor1 = 1.0f, float errorFactor2 = 1.0f);


// not final
struct CEvolutionParameter
{
	uint64_t seed = 1;
	int32_t neuronID;
	int32_t firstNeuronID;
	int32_t lastNeuronID;
	int32_t minVectorElement;
	int32_t maxVectorElement;
	int32_t permutationSteps;
	float minValue1;
	float maxValue1;
	float minValue2;
	float maxValue2;
	float minVariance1;
	float maxVariance1;
	float minVariance2;
	float maxVariance2;
	float minWeight;
	float maxWeight;
	float mutationRate;
	float probabilityValue;
	float precision_RBF_CentroidValues;
	float precision_RBF_Factors;
	float precision_SynapticPlasticity;
};

struct CEvolutionParameter_2IntegerValues
{
	int32_t value1;
	int32_t value2;
};


class CNeuronV2;
class CNeuralNetV2;

// Definition eines Funktionszeiger-Typs:
typedef float(*pDendriteCentroidDistanceFunc)(float neuronInput, float centroidValue);
typedef float(*pSimpleActivationFunc)(float neuronInput);
typedef void(*pActivationFuncV2)(CNeuronV2 *pNeuron);
typedef void(*pSynapticFuncV2)(CNeuronV2 *pNeuron);
typedef void(*pDendriticFuncV2)(CNeuronV2 *pNeuron);

typedef void(*pRecombinationFunc)(CNeuronV2 *pOffspring, const CNeuronV2 *pParent1, const CNeuronV2 *pParent2, CRandomNumbersNN *pRandomNumbers, void *pParam);
typedef void(*pMutationFunc)(CNeuronV2 *pInOutNeuron, CRandomNumbersNN *pRandomNumbers, void *pParam);
typedef void(*pReinitializationFunc)(CNeuronV2 *pInOutNeuron, CRandomNumbersNN *pRandomNumbers, void *pParam);



typedef void(*pNeuronV2PopulationLearningFunc)(CNeuronV2 *pNeuron, const CNeuronV2 *pBestNeuron, CRandomNumbersNN *pRandomNumbers, float learningRate, float learningRateVariance, float errorFactor1, float errorFactor2);


typedef void(*pNeuralNetV2RecombinationFunc)(CNeuralNetV2 *pOffspring, const CNeuralNetV2 *pParent1, const CNeuralNetV2 *pParent2, void *pParam);
typedef void(*pNeuralNetV2MutationFunc)(CNeuralNetV2 *pInOutNeuralNet, void *pParam);
typedef void(*pNeuralNetV2ReinitializationFunc)(CNeuralNetV2 *pInOutNeuralNet, void *pParam);

void LinearActivationFunction(CNeuronV2 *pNeuron);
void NegLinearActivationFunction(CNeuronV2 *pNeuron);
void BiasActivationFunction(CNeuronV2 *pNeuron);
void StandardRBFActivationFunction(CNeuronV2 *pNeuron);
void StandardRBFActivationFunction2(CNeuronV2 *pNeuron);
void StandardInvRBFActivationFunction(CNeuronV2 *pNeuron);
void TanHActivationFunction(CNeuronV2 *pNeuron);
void FastTanHApproxActivationFunction(CNeuronV2 *pNeuron);
void SigmoidActivationFunction(CNeuronV2 *pNeuron);
void FastSigmoidApproxActivationFunction(CNeuronV2 *pNeuron);
void ReLUActivationFunction(CNeuronV2 *pNeuron);
void LeakyReLUActivationFunction(CNeuronV2 *pNeuron);
void BinaryActivationFunction(CNeuronV2 *pNeuron);
void BinaryActivationFunctionExt(CNeuronV2 *pNeuron);


void FindMaximumDendriteActivation1(CNeuronV2 *pNeuron);
void FindMaximumDendriteActivation2(CNeuronV2 *pNeuron);

void StandardSynapticFunction_Use_All_Connections(CNeuronV2 *pNeuron);
void StandardSynapticFunction(CNeuronV2 *pNeuron);


void RBF_SynapticTransferFunction(CNeuronV2 *pNeuron);

void RBF_SynapticFunction(CNeuronV2 *pNeuron);
void RBF_SynapticFunction2(CNeuronV2 *pNeuron);

void RBF_SynapticFunction_Use_All_Connections(CNeuronV2 *pNeuron);
void RBF_SynapticFunction2_Use_All_Connections(CNeuronV2 *pNeuron);


float DendriteCentroidDistance(float neuronInput, float centroidValue);
float MinDendriteCentroidDistance(float neuronInput, float centroidValue);
float MaxDendriteCentroidDistance(float neuronInput, float centroidValue);



class CActivationSequence
{
public:

	int32_t Length = 0;
	int32_t *pNeuronIDArray = nullptr;

	CActivationSequence();
	~CActivationSequence();

	// Kopierkonstruktor l�schen:
	CActivationSequence(const CActivationSequence  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CActivationSequence & operator=(const CActivationSequence  &originalObject) = delete;

	void Init_ActivationSequence(int32_t length);
	void Init_Or_Set_ActivationSequence(int32_t *pNeuronIDs, int32_t length);

	bool Change_ActivationSequence(int32_t neuronID, int32_t sequenceElement);
	void Set_ActivationSequence(int32_t *pNeuronIDs);

	void Clone_Data(const CActivationSequence *pOoriginalObject);
	void Clone(const CActivationSequence *pOoriginalObject);

	bool Save_Data(const char* pFilename);
	bool Load_Data(const char* pFilename);
};

class CNeuralConnections
{
public:

	int32_t Number = 0;
	int32_t *pNeuronIDArray = nullptr;
	float *pSynapticPlasticityArray = nullptr;

	CNeuralConnections();
	~CNeuralConnections();

	// Kopierkonstruktor l�schen:
	CNeuralConnections(const CNeuralConnections  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CNeuralConnections & operator=(const CNeuralConnections  &originalObject) = delete;

	void Init_NeuralConnections(int32_t number);
	void Init_Or_Set_NeuralConnections(int32_t *pNeuronIDs, int32_t number);
	void Init_Or_Set_NeuralConnections(int32_t *pNeuronIDs, float *pSynapticPlasticities, int32_t number);
	void Init_Or_Set_NeuralConnections(int32_t *pNeuronIDs, int32_t number, CRandomNumbersNN *pRandomNumbers, float minSynapticPlasticity, float maxSynapticPlasticity);
	void Randomize_SynapticPlasticities(CRandomNumbersNN *pRandomNumbers, float minSynapticPlasticity, float maxSynapticPlasticity);

	bool Change_SynapticPlasticity(float plasticity, int32_t connectionID);
	bool Change_NeuronID(int32_t neuronID, int32_t connectionID);

	void Set_NeuralConnections(int32_t *pNeuronIDs);
	void Set_NeuralConnections(float *pSynapticPlasticities);
	void Set_NeuralConnections(int32_t *pNeuronIDs, float *pSynapticPlasticities);

	void Clone_Data(const CNeuralConnections *pOriginalObject);
	void Clone(const CNeuralConnections *pOriginalObject);

	bool Save_Data(const char* pFilename);
	bool Load_Data(const char* pFilename);
};



class CNeuronV2
{
public:

	CNeuronV2 *pUsedNeuronArray = nullptr;

	int32_t NeuronID = -1;
	int32_t RandomSeedValue = 0;

	bool BiasNeuron = false;

	pActivationFuncV2 pActivationFunction = nullptr;
	pSynapticFuncV2 pSynapticFunction = nullptr;
	pDendriticFuncV2 pDendriticFunction = nullptr;

	bool Dropout = false;

	float NeuronInput = 0.0f;
	float NeuronOutput = 0.0f;
	float NeuronOutput_LastCalculationStep = 0.0f;

	float MinNeuronOutputTreshold = 0.0f;
	float MaxNeuronOutputValue = 1.0f;

	float ErrorValue = 0.0f;
	float ErrorFactor1 = 1.0f;
	float ErrorFactor2 = 1.0f;
	// Hinweis: Bei linearen Aktivierungsfunktionen sollte ErrorFactor2 kleiner als 1.0f sein (z. B. 0.5f oder 0.25f) 

	float LearningRate = 0.2f;

	float PosX = 0.0f;
	float PosY = 0.0f;
	float PosZ = 0.0f;

	int32_t Num_Of_Dendrite_Elements = 0;
	float *pDendrite_InputValueArray = nullptr;
	float *pDendrite_InputValueArray_OtherNeuron = nullptr;
	float *pDendrite_CentroidValueArray = nullptr;
	float *pDendrite_CentroidValueArray_OtherNeuron = nullptr;
	float *pDendrite_FactorArray = nullptr;
	float *pDendrite_FactorArray_OtherNeuron = nullptr;
	int32_t *pDendrite_CentroidDistanceFuncIDArray = nullptr;
	int32_t Dendrite_InputCounter = 0;

	int32_t UsedDendritesMinID = 0;
	int32_t UsedDendritesMaxIDPlus1 = 0;

	int32_t NumOfOutputSynapses = 0;

	bool *pOutputSynapseActivityStatusArray = nullptr;
	int32_t *pReceiverNeuronIDArray = nullptr;
	// auch bekannt als OutputWeightArray: 
	float *pOutputSynapsePlasticityArray = nullptr;

	int32_t NumOfTrainingExamples = 0;

	
	pDendriteCentroidDistanceFunc pDendriteCentroidDistanceFuncArray[3] = { DendriteCentroidDistance, MinDendriteCentroidDistance, MaxDendriteCentroidDistance };

	CNeuronV2();
	~CNeuronV2();

	// Kopierkonstruktor l�schen:
	CNeuronV2(const CNeuronV2  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CNeuronV2 & operator=(const CNeuronV2  &originalObject) = delete;

	void Use_OtherNeuron_Dendrite_InputValueArray(float *pArray);
	void Use_OtherNeuron_Dendrite_InputValueArray(float *pArray, int32_t idFirstSourceDendrite);

	void Use_OtherNeuron_Dendrite_CentroidValueArray(float *pArray);
	void Use_OtherNeuron_Dendrite_CentroidValueArray(float *pArray, int32_t idFirstSourceDendrite);

	void Use_OtherNeuron_Dendrite_FactorArray(float *pArray);
	void Use_OtherNeuron_Dendrite_FactorArray(float *pArray, int32_t idFirstSourceDendrite);

	void Clone(const CNeuronV2 *pOriginalObject);
	void Clone_Data(const CNeuronV2 *pOriginalObject);

	void Clone_Synaptic_Data(const CNeuronV2 *pOriginalObject);
	void Clone_Dendrite_Data(const CNeuronV2 *pOriginalObject);

	void Set_RandomSeedValue(int32_t newSeed);

	void Set_MinNeuronOutputTreshold(float value);
	void Set_MaxNeuronOutputValue(float value);

	void Set_NumOfTrainingExamples(int32_t number);
	

	int32_t Get_NumOfTrainingExamples(void);

	void Set_NumOfTrainingExamples(int32_t minDendriteID, int32_t maxDendriteID, int32_t number);
	

	void Set_Dendrite_Data(float *pCentroidValueArray, float *pFactorArray);
	void Set_Dendrite_Data(int32_t minDendriteID, int32_t maxDendriteID, float *pCentroidValueArray, float *pFactorArray);

	void Set_Dendrite_CentroidValues(float *pCentroidValueArray);
	void Set_Dendrite_CentroidValues(int32_t minDendriteID, int32_t maxDendriteID, float *pCentroidValueArray);

	void Set_Dendrite_Factors(float *pFactorArray);
	void Set_Dendrite_Factors(int32_t minDendriteID, int32_t maxDendriteID, float *pFactorArray);

	void Set_Dendrite_Factors(float value);
	void Set_Dendrite_Factors(int32_t minDendriteID, int32_t maxDendriteID, float value);

	void Set_Dendrite_CentroidDistanceFunctionsIDs(int32_t *pIDArray);

	void Add_Dendrite_CentroidValues(float *pCentroidValueArray);
	void Add_Dendrite_CentroidValues(int32_t minDendriteID, int32_t maxDendriteID, float *pCentroidValueArray);

	void SimpleAdd_Dendrite_CentroidValues(float *pCentroidValueArray);
	void SimpleAdd_Dendrite_CentroidValues(int32_t minDendriteID, int32_t maxDendriteID, float *pCentroidValueArray);

	void Add_Dendrite_CentroidValues(float *pCentroidValueArray, float centroidScale);
	void Add_Dendrite_CentroidValues(int32_t minDendriteID, int32_t maxDendriteID, float *pCentroidValueArray, float centroidScale);

	void SimpleAdd_Dendrite_CentroidValues(float *pCentroidValueArray, float centroidScale);
	void SimpleAdd_Dendrite_CentroidValues(int32_t minDendriteID, int32_t maxDendriteID, float *pCentroidValueArray, float centroidScale);

	void Add_Dendrite_CentroidValues(int32_t *pCentroidValueArray, float centroidScale);
	void Add_Dendrite_CentroidValues(int32_t minDendriteID, int32_t maxDendriteID, int32_t *pCentroidValueArray, float centroidScale);

	void SimpleAdd_Dendrite_CentroidValues(int32_t *pCentroidValueArray, float centroidScale);
	void SimpleAdd_Dendrite_CentroidValues(int32_t minDendriteID, int32_t maxDendriteID, int32_t *pCentroidValueArray, float centroidScale);

	void Add_Dendrite_Factors(float *pFactorArray);
	void Add_Dendrite_Factors(int32_t minDendriteID, int32_t maxDendriteID, float *pFactorArray);

	void Add_Dendrite_Factors(float *pFactorArray, float factorScale);
	void Add_Dendrite_Factors(int32_t minDendriteID, int32_t maxDendriteID, float *pFactorArray, float factorScale);

	void Add_Dendrite_Factors(int32_t *pFactorArray, float factorScale);
	void Add_Dendrite_Factors(int32_t minDendriteID, int32_t maxDendriteID, int32_t *pFactorArray, float factorScale);

	/* Hinweis: Wenn factor == 0.0f => Deaktivierung der betreffenden Dendriten. Dies ist bsp. f�r die Erkennung eines einzelnen Features (Merkmals) erforderlich. */
	void Set_Dendrite_Factor(float factor, float regardedCentroidValue);
	/* Hinweis: Wenn factor == 0.0f => Deaktivierung der betreffenden Dendriten. Dies ist bsp. f�r die Erkennung eines einzelnen Features (Merkmals) erforderlich. */
	void Set_Dendrite_Factor(int32_t minDendriteID, int32_t maxDendriteID, float factor, float regardedCentroidValue);
	/* Hinweis: Wenn factor == 0.0f => Deaktivierung der betreffenden Dendriten. Dies ist bsp. f�r die Erkennung eines einzelnen Features (Merkmals) erforderlich. */
	void Set_Dendrite_Factor(float factor, float lowerCentroidValueThreshold, float upperCentroidValueThreshold);
	/* Hinweis: Wenn factor == 0.0f => Deaktivierung der betreffenden Dendriten. Dies ist bsp. f�r die Erkennung eines einzelnen Features (Merkmals) erforderlich. */
	void Set_Dendrite_Factor(int32_t minDendriteID, int32_t maxDendriteID, float factor, float lowerCentroidValueThreshold, float upperCentroidValueThreshold);
	

	/* Ein Aufruf der nachstehenden Methode bietet sich bsp. im Anschluss an einen Aufruf der Add_Dendrite_CentroidValues()-Methode an: */
	void Calculate_Dendrite_Factors_From_CentroidValues(float fallback_RBF_Factor = 0.0f, float centroidWeightFactor = 0.025f, int32_t centroidExponent = 2);
	/* Ein Aufruf der nachstehenden Methode bietet sich bsp. im Anschluss an einen Aufruf der Add_Dendrite_CentroidValues()-Methode an: */
	void Calculate_Dendrite_Factors_From_CentroidValues(int32_t minDendriteID, int32_t maxDendriteID, float fallback_RBF_Factor = 0.0f, float centroidWeightFactor = 0.025f, int32_t centroidExponent = 2);


	void Scale_Dendrite_CentroidValues_Up_To_One(void);
	void Scale_Dendrite_Factors_Up_To_One(void);

	void Normalize_Dendrite_CentroidValues(void);
	void Normalize_Dendrite_Factors(void);

	void Combine_Synaptic_Data(CRandomNumbersNN *pRandomNumbers, const CNeuronV2 *pParentObject1, const CNeuronV2 *pParentObject2);
	void Combine_Dendrite_Data(CRandomNumbersNN *pRandomNumbers, const CNeuronV2 *pParentObject1, const CNeuronV2 *pParentObject2);

	// min/max weight: 0 to 100
	void Combine_Synaptic_Data(CRandomNumbersNN *pRandomNumbers, const CNeuronV2 *pParentObject1, const CNeuronV2 *pParentObject2, float weightFactorParent1);
	// min/max weight: 0 to 100
	void Combine_Dendrite_Data(CRandomNumbersNN *pRandomNumbers, const CNeuronV2 *pParentObject1, const CNeuronV2 *pParentObject2, float weightFactorParent1);

	void Combine_Synaptic_Data_RandomWeighted(CRandomNumbersNN *pRandomNumbers, const CNeuronV2 *pParentObject1, const CNeuronV2 *pParentObject2);

	// min/max weight: 0 to 1
	void Combine_Synaptic_Data_RandomWeighted(CRandomNumbersNN *pRandomNumbers, const CNeuronV2 *pParentObject1, const CNeuronV2 *pParentObject2, float minParent1Weight, float maxParent1Weight);

	void Combine_Dendrite_Data_RandomWeighted(CRandomNumbersNN *pRandomNumbers, const CNeuronV2 *pParentObject1, const CNeuronV2 *pParentObject2);

	// min/max weight: 0 to 1
	void Combine_Dendrite_Data_RandomWeighted(CRandomNumbersNN *pRandomNumbers, const CNeuronV2 *pParentObject1, const CNeuronV2 *pParentObject2, float minParent1Weight, float maxParent1Weight);

	void Permute_Dendrite_Values(CRandomNumbersNN *pRandomNumbers, int32_t permutationSteps);
	void Permute_Dendrite_Values(CRandomNumbersNN *pRandomNumbers, int32_t minDendriteID, int32_t maxDendriteID, int32_t permutationSteps);

	void Permute_Dendrite_CentroidValues(CRandomNumbersNN *pRandomNumbers, int32_t permutationSteps);
	void Permute_Dendrite_CentroidValues(CRandomNumbersNN *pRandomNumbers, int32_t minDendriteID, int32_t maxDendriteID, int32_t permutationSteps);

	void Permute_Dendrite_Factors(CRandomNumbersNN *pRandomNumbers, int32_t permutationSteps);
	void Permute_Dendrite_Factors(CRandomNumbersNN *pRandomNumbers, int32_t minDendriteID, int32_t maxDendriteID, int32_t permutationSteps);
	
	void Init_OutputSynapses(int32_t numOfOutputSynapses);
	void Init_OutputSynapses(const CNeuralConnections * pNeuralConnections);

	void Init_Dendrite_Arrays(int32_t num_Of_Dendrite_Elements);

	void Use_As_BiasNeuron(bool state);
	
	void Round_SynapticPlasticities(float precision, float invPrecision);
	void Round_SynapticPlasticities(float precision);

	void Round_Dendrite_Values(float precision, float invPrecision);
	void Round_Dendrite_CentroidValues(float precision, float invPrecision);
	void Round_Dendrite_Factors(float precision, float invPrecision);

	void Round_Dendrite_Values(float precision, float invPrecision, int32_t minDendriteID, int32_t maxDendriteID);
	void Round_Dendrite_CentroidValues(float precision, float invPrecision, int32_t minDendriteID, int32_t maxDendriteID);
	void Round_Dendrite_Factors(float precision, float invPrecision, int32_t minDendriteID, int32_t maxDendriteID);
	
	void Round_Dendrite_Values(float precision);
	void Round_Dendrite_CentroidValues(float precision);
	void Round_Dendrite_Factors(float precision);

	void Round_Dendrite_Values(float precision, int32_t minDendriteID, int32_t maxDendriteID);
	void Round_Dendrite_CentroidValues(float precision, int32_t minDendriteID, int32_t maxDendriteID);
	void Round_Dendrite_Factors(float precision, int32_t minDendriteID, int32_t maxDendriteID);

	void Remove_Unused_Connections(void);

	void Connect_With_Brain(CNeuronV2 *pNeuronArray);

	// Hinweis: Bei linearen (quadtatischen usw.) Aktivierungsfunktionen sollte ErrorFactor2 kleiner als 1.0f sein (z. B. 0.5f, 0.25f, 0.01f) 
	void Set_ErrorFactors(float factor1, float factor2);
	void Set_LearningRate(float learningRate);

	void Set_ActivationFunction(pActivationFuncV2 pFunc);

	void Set_DendriticFunction(pDendriticFuncV2 pFunc);

	// last initialization step:
	void Set_SynapticFunction(pSynapticFuncV2 pFunc);

	void Set_Position(float x, float y, float z);
	float Get_Distance_to_Other_Neuron(int32_t neuronID);
	float Get_InvDistance_to_Other_Neuron(int32_t neuronID);
	float Get_DistanceSq_to_Other_Neuron(int32_t neuronID);
	float Get_InvDistanceSq_to_Other_Neuron(int32_t neuronID);

	void Set_DropoutState(bool state);

	void Connect_With_ReceiverNeurons(int32_t *pNeuronIDArray, float *pPlasticityValueArray);
	void Connect_With_ReceiverNeurons(int32_t *pNeuronIDArray, float *pPlasticityValueArray, bool *pSynapseActivityStatusArray);

	void Connect_With_ReceiverNeuron(int32_t neuronID, int32_t synapseID);
	void Set_OutputSynapsePlasticity(float value, int32_t synapseID);
	void Set_OutputSynapseActivityStatus(bool status, int32_t synapseID);
	
	void Execute_DendriticCalculations(void);
	
	// execute selected activation function:
	void Calculate_NeuronOutput(void);

	// step1: execute selected dendritic function, step 2: execute activation function:
	void Calculate_NeuronOutput_Ext(void);
	void Propagate_SynapticOutput(void);
	
	float Calculate_VarianceSq(float desiredNeuronOutput);
	float Calculate_Error(float desiredNeuronOutput);

	// Hinweis: Bei linearen (quadtatischen usw.) Aktivierungsfunktionen sollte errorFactor2 kleiner als 1.0f sein (z. B. 0.5f, 0.25f, 0.01f) 
	float Calculate_Error(float desiredNeuronOutput, float errorFactor1, float errorFactor2);

	/* Fehlerberechnung (Input-Neuronen sind ausgenommen) unter Ber�cksichtigung der bereits berechneten Fehler von
	s�mtlichen Receiver-Neuronen (nachgeschalteten Neuronen): */
	void Calculate_Error(void);

	/* Fehlerberechnung (Input-Neuronen sind ausgenommen) unter Ber�cksichtigung der bereits berechneten Fehler von
	s�mtlichen Receiver-Neuronen (nachgeschalteten Neuronen): */
	void Calculate_Error(float *pInErrorValueArray, float errorFactor1, float errorFactor2);

	

	void Adjust_Dendrite_CentroidValue_AfterErrorCalculations(int32_t dendriteID, float learningRate);
	void Adjust_Dendrite_Factor_AfterErrorCalculations(int32_t dendriteID, float learningRate);

	void Adjust_Dendrite_CentroidValue_AfterErrorCalculations_ExternalInput(int32_t dendriteID, float learningRate);
	void Adjust_Dendrite_Factor_AfterErrorCalculations_ExternalInput(int32_t dendriteID, float learningRate);

	void Adjust_Dendrite_CentroidValues_AfterErrorCalculations(float learningRate);
	void Adjust_Dendrite_Factors_AfterErrorCalculations(float learningRate);

	void Adjust_Dendrite_CentroidValues_AfterErrorCalculations_ExternalInput(float learningRate);
	void Adjust_Dendrite_Factors_AfterErrorCalculations_ExternalInput(float learningRate);

	void Adjust_Dendrite_CentroidValues_AfterErrorCalculations(float learningRate, int32_t minDendriteID, int32_t maxDendriteID);
	void Adjust_Dendrite_Factors_AfterErrorCalculations(float learningRate, int32_t minDendriteID, int32_t maxDendriteID);

	void Adjust_Dendrite_CentroidValues_AfterErrorCalculations_ExternalInput(float learningRate, int32_t minDendriteID, int32_t maxDendriteID);
	void Adjust_Dendrite_Factors_AfterErrorCalculations_ExternalInput(float learningRate, int32_t minDendriteID, int32_t maxDendriteID);

	float Adjust_Dendrite_CentroidValues(float desiredNeuronOutput, float learningRate, float errorFactor1, float errorFactor2);
	float Adjust_Dendrite_Factors(float desiredNeuronOutput, float learningRate, float errorFactor1, float errorFactor2);

	float Adjust_Dendrite_CentroidValues_ExternalInput(float desiredNeuronOutput, float learningRate, float errorFactor1, float errorFactor2);
	float Adjust_Dendrite_Factors_ExternalInput(float desiredNeuronOutput, float learningRate, float errorFactor1, float errorFactor2);

	float Adjust_Dendrite_CentroidValues(float desiredNeuronOutput, float learningRate, float errorFactor1, float errorFactor2, int32_t minDendriteID, int32_t maxDendriteID);
	float Adjust_Dendrite_Factors(float desiredNeuronOutput, float learningRate, float errorFactor1, float errorFactor2, int32_t minDendriteID, int32_t maxDendriteID);

	float Adjust_Dendrite_CentroidValues_ExternalInput(float desiredNeuronOutput, float learningRate, float errorFactor1, float errorFactor2, int32_t minDendriteID, int32_t maxDendriteID);
	float Adjust_Dendrite_Factors_ExternalInput(float desiredNeuronOutput, float learningRate, float errorFactor1, float errorFactor2, int32_t minDendriteID, int32_t maxDendriteID);

	void Adjust_Dendrite_CentroidValues(const CNeuronV2 *pBestNeuron);
	void Adjust_Dendrite_Factors(const CNeuronV2 *pBestNeuron);

	void Adjust_Dendrite_CentroidValues(const CNeuronV2 *pBestNeuron, CRandomNumbersNN *pRandomNumbers, float learningRate, float learningRateVariance, float errorFactor1 = 1.0f, float errorFactor2 = 1.0f);

	void Adjust_Dendrite_Factors(const CNeuronV2 *pBestNeuron, CRandomNumbersNN *pRandomNumbers, float learningRate, float learningRateVariance, float errorFactor1 = 1.0f, float errorFactor2 = 1.0f);


	// Anpassung der Synapsen-Pastizit�t unter Ber�cksichtigung der zuvor berechneten Fehlerwerte:
	void Adjust_OutputSynapses_AfterErrorCalculations(void);
	void Adjust_OutputSynapses_AfterErrorCalculations(float learningRate);

	void Adjust_OutputSynapse_AfterErrorCalculations(int32_t synapseID);
	void Adjust_OutputSynapse_AfterErrorCalculations(int32_t synapseID, float learningRate);

	void Adjust_OutputSynapses(const CNeuronV2 *pBestNeuron);
	void Adjust_OutputSynapses(const CNeuronV2 *pBestNeuron, CRandomNumbersNN *pRandomNumbers, float learningRate, float learningRateVariance, float errorFactor1 = 1.0f, float errorFactor2 = 1.0f);

	

	bool Save_SynapticData(const char* pFilename);
	bool Load_SynapticData(const char* pFilename);

	bool Save_Dendrite_Values(const char* pFilename);
	bool Load_Dendrite_Values(const char* pFilename);

	float Get_NeuronOutput(void);
	void Get_WeightedNeuronOutput(float *pOutputValueArray);

	void Set_NeuronOutput(float value);
	void Reset_NeuronOutput(void);

	float Get_NeuronInput(void);
	void Set_NeuronInput(float value);

	void Set_Dendrite_NeuronInput(float value, int32_t dendriteID);
	void Set_And_Count_Dendrite_NeuronInput(float value, int32_t dendriteID);

	void Set_Dendrite_NeuronInput(float value);
	void Set_NeuronInput_For_All_Dendrites(float value);

	void Set_Dendrite_NeuronInput(float *pValueArray, int32_t numArrayElements);
	void Set_And_Count_Dendrite_NeuronInput(float *pValueArray, int32_t numArrayElements);

	void Set_Dendrite_NeuronInput(float *pValueArray, int32_t numArrayElements, int32_t firstDendriteID);
	void Set_And_Count_Dendrite_NeuronInput(float *pValueArray, int32_t numArrayElements, int32_t firstDendriteID);

	void Select_UsedDendrites(int32_t minID, int32_t numDendrites);
	

	void Set_RBF_NeuronInput(float value, int32_t dendriteID);

	// CentroidDistanceFunction usage
	void Set_RBF_NeuronInput2(float value, int32_t dendriteID);

	void Set_MinRBF_NeuronInput(float value, int32_t dendriteID);
	void Set_MaxRBF_NeuronInput(float value, int32_t dendriteID);

	void Set_RBF_NeuronInput(float value);
	void Set_RBF_NeuronInput2(float value);
	void Set_MinRBF_NeuronInput(float value);
	void Set_MaxRBF_NeuronInput(float value);

	void Set_RBF_NeuronInput(float *pValueArray, int32_t numArrayElements, int32_t minDendriteID);

	// CentroidDistanceFunction usage
	void Set_RBF_NeuronInput2(float *pValueArray, int32_t numArrayElements, int32_t minDendriteID);

	void Set_MinRBF_NeuronInput(float *pValueArray, int32_t numArrayElements, int32_t minDendriteID);
	void Set_MaxRBF_NeuronInput(float *pValueArray, int32_t numArrayElements, int32_t minDendriteID);

	void Set_RBF_NeuronInput_Ext(float *pValueArray, int32_t numArrayElements);

	// CentroidDistanceFunction usage
	void Set_RBF_NeuronInput2_Ext(float *pValueArray, int32_t numArrayElements);

	void Set_MinRBF_NeuronInput_Ext(float *pValueArray, int32_t numArrayElements);
	void Set_MaxRBF_NeuronInput_Ext(float *pValueArray, int32_t numArrayElements);

	void Set_RBF_NeuronInput_Ext(float *pValueArray, int32_t numArrayElements, int32_t minDendriteID);

	// CentroidDistanceFunction usage
	void Set_RBF_NeuronInput2_Ext(float *pValueArray, int32_t numArrayElements, int32_t minDendriteID);

	void Set_MinRBF_NeuronInput_Ext(float *pValueArray, int32_t numArrayElements, int32_t minDendriteID);
	void Set_MaxRBF_NeuronInput_Ext(float *pValueArray, int32_t numArrayElements, int32_t minDendriteID);

	void Set_RBF_NeuronInput_Ext(float *pValueArray, int32_t numArrayElements, int32_t minDendriteID, int32_t maxDendriteID);

	// CentroidDistanceFunction usage
	void Set_RBF_NeuronInput2_Ext(float *pValueArray, int32_t numArrayElements, int32_t minDendriteID, int32_t maxDendriteID);

	void Set_MinRBF_NeuronInput_Ext(float *pValueArray, int32_t numArrayElements, int32_t minDendriteID, int32_t maxDendriteID);
	void Set_MaxRBF_NeuronInput_Ext(float *pValueArray, int32_t numArrayElements, int32_t minDendriteID, int32_t maxDendriteID);

	
	bool Set_Dendrite_NeuronInput(int32_t posX_left, int32_t posY_top, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY);

	bool Set_Dendrite_NeuronInput2(int32_t posX_right, int32_t posY_bottom, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY);

	bool Set_Dendrite_NeuronInput3(int32_t posX_right, int32_t posY_top, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY);

	bool Set_Dendrite_NeuronInput4(int32_t posX_left, int32_t posY_bottom, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY);

	void Set_Dendrite_NeuronInput(int32_t posX_center, int32_t posY_center, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldNegRangeX, int32_t localReceptiveFieldPosRangeX, int32_t localReceptiveFieldNegRangeY, int32_t localReceptiveFieldPosRangeY, float fallBackInputValue = 0.0f);

	
	bool Set_Dendrite_NeuronInput(int32_t posX_left, int32_t posY_top, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, int32_t minDendriteID);

	bool Set_Dendrite_NeuronInput2(int32_t posX_right, int32_t posY_bottom, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, int32_t minDendriteID);

	bool Set_Dendrite_NeuronInput3(int32_t posX_right, int32_t posY_top, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, int32_t minDendriteID);

	bool Set_Dendrite_NeuronInput4(int32_t posX_left, int32_t posY_bottom, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, int32_t minDendriteID);

	void Set_Dendrite_NeuronInput(int32_t posX_center, int32_t posY_center, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldNegRangeX, int32_t localReceptiveFieldPosRangeX, int32_t localReceptiveFieldNegRangeY, int32_t localReceptiveFieldPosRangeY, int32_t minDendriteID, float fallBackInputValue = 0.0f);

	void Reset_NeuronInput();
	
	//void Randomize_OutputSynapsePlasticities(CRandomNumbersNN *pRandomNumbers, float pValueArray, int32_t numOfValues);
	//void Randomize_OutputSynapsePlasticities(CRandomNumbersNN *pRandomNumbers, float pValueArray, int32_t numOfValues, float mutationRate);

	void Randomize_OutputSynapsePlasticities(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue);
	void Randomize_OutputSynapsePlasticities(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float mutationRate);

	void Modify_OutputSynapsePlasticities(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue);
	void Modify_OutputSynapsePlasticities(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float mutationRate);

	void Randomize_Dendrite_CentroidValues(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue);
	void Randomize_Dendrite_CentroidValues(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float mutationRate);

	void Randomize_Dendrite_CentroidValues(CRandomNumbersNN *pRandomNumbers, int32_t minDendriteID, int32_t maxDendriteID, float minValue, float maxValue);
	void Randomize_Dendrite_CentroidValues(CRandomNumbersNN *pRandomNumbers, int32_t minDendriteID, int32_t maxDendriteID, float minValue, float maxValue, float mutationRate);

	void Modify_Dendrite_CentroidValues(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue);
	void Modify_Dendrite_CentroidValues(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float mutationRate);

	void Modify_Dendrite_CentroidValues(CRandomNumbersNN *pRandomNumbers, int32_t minDendriteID, int32_t maxDendriteID, float minValue, float maxValue);
	void Modify_Dendrite_CentroidValues(CRandomNumbersNN *pRandomNumbers, int32_t minDendriteID, int32_t maxDendriteID, float minValue, float maxValue, float mutationRate);
	
	void Randomize_Dendrite_Factors(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue);
	void Randomize_Dendrite_Factors(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float mutationRate);

	void Randomize_Dendrite_Factors(CRandomNumbersNN *pRandomNumbers, int32_t minDendriteID, int32_t maxDendriteID, float minValue, float maxValue);
	void Randomize_Dendrite_Factors(CRandomNumbersNN *pRandomNumbers, int32_t minDendriteID, int32_t maxDendriteID, float minValue, float maxValue, float mutationRate);

	void Modify_Dendrite_Factors(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue);
	void Modify_Dendrite_Factors(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float mutationRate);

	void Modify_Dendrite_Factors(CRandomNumbersNN *pRandomNumbers, int32_t minDendriteID, int32_t maxDendriteID, float minValue, float maxValue);
	void Modify_Dendrite_Factors(CRandomNumbersNN *pRandomNumbers, int32_t minDendriteID, int32_t maxDendriteID, float minValue, float maxValue, float mutationRate);

	void Randomize_Dendrite_Values(CRandomNumbersNN *pRandomNumbers, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor);
	void Randomize_Dendrite_Values(CRandomNumbersNN *pRandomNumbers, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor, float mutationRate);

	void Randomize_Dendrite_Values_WithNonZeroCentroids(CRandomNumbersNN *pRandomNumbers, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor);
	void Randomize_Dendrite_Values_WithNonZeroCentroids(CRandomNumbersNN *pRandomNumbers, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor, float mutationRate);

	void Randomize_Dendrite_Values(CRandomNumbersNN *pRandomNumbers, int32_t minDendriteID, int32_t maxDendriteID, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor);
	void Randomize_Dendrite_Values(CRandomNumbersNN *pRandomNumbers, int32_t minDendriteID, int32_t maxDendriteID, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor, float mutationRate);

	void Randomize_Dendrite_Values_WithNonZeroCentroids(CRandomNumbersNN *pRandomNumbers, int32_t minDendriteID, int32_t maxDendriteID, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor);
	void Randomize_Dendrite_Values_WithNonZeroCentroids(CRandomNumbersNN *pRandomNumbers, int32_t minDendriteID, int32_t maxDendriteID, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor, float mutationRate);

	void Modify_Dendrite_Values(CRandomNumbersNN *pRandomNumbers, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance);
	void Modify_Dendrite_Values(CRandomNumbersNN *pRandomNumbers, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance, float mutationRate);

	void Modify_Dendrite_Values(CRandomNumbersNN *pRandomNumbers, int32_t minDendriteID, int32_t maxDendriteID, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance);
	void Modify_Dendrite_Values(CRandomNumbersNN *pRandomNumbers, int32_t minDendriteID, int32_t maxDendriteID, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance, float mutationRate);

	void Disable_Random_OutputSynapses(CRandomNumbersNN *pRandomNumbers, float probabilityValue);
	void Random_Enable_Disabled_OutputSynapses(CRandomNumbersNN *pRandomNumbers, float probabilityValue);
	void Enable_Disabled_OutputSynapses(void);
};


class CNeuronEnsembleV2
{
public:

	int32_t NumOfNeurons = 0;
	CNeuronV2 **ppNeuronArray = nullptr;
	float *pModifiedOutputArray = nullptr;

	int32_t LastCalculatedID = 0;

	CNeuronEnsembleV2();
	~CNeuronEnsembleV2();

	// Kopierkonstruktor l�schen:
	CNeuronEnsembleV2(const CNeuronEnsembleV2  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CNeuronEnsembleV2 & operator=(const CNeuronEnsembleV2  &originalObject) = delete;

	void Set_NumOfNeurons(int32_t numOfNeurons);

	void Set_Neuron(CNeuronV2 *pNeuron, int32_t neuronId);

	float Get_NeuronOutput(int32_t neuronId);
	float Get_ModifiedNeuronOutput(int32_t neuronId);

	float Get_NeuronOutputSum(float minValue, float maxValue);

	void Get_NeuronOutputValues(float *pOutValueArray);
	void Get_ModifiedNeuronOutputValues(float *pOutValueArray);

	void Calculate_ProbabilityValues(void);
	void Calculate_NormalizedOutputValues(void);
	void Calculate_SoftmaxValues(void);

	int32_t Get_ID_Of_NeuronWithMaxOutput(void);
	int32_t Get_ID_Of_NeuronWithMinOutput(void);

	void Get_ID_And_Output_Of_NeuronWithMaxOutput(int32_t *pOutNeuronID, float *pOutNeuronOutput);
	void Get_ID_And_Output_Of_NeuronWithMinOutput(int32_t *pOutNeuronID, float *pOutNeuronOutput);

	int32_t Get_LastCalculatedID(void);

	void Use_OtherNeuron_Dendrite_InputValueArray(int32_t idDestinationNeuron, int32_t idSourceNeuron);
	void Use_OtherNeuron_Dendrite_CentroidValueArray(int32_t idDestinationNeuron, int32_t idSourceNeuron);
	void Use_OtherNeuron_Dendrite_FactorArray(int32_t idDestinationNeuron, int32_t idSourceNeuron);
};


class CNeuralNetV2
{
public:

	int32_t NumOfNeurons = 0;
	int32_t NumOfUsedNeurons = 0;

	CNeuronV2 *pNeuronArray = nullptr;

	int32_t NumOfInputValues = 0;
	int32_t NumOfOutputValues = 0;
	int32_t IdOfFirstInputNeuron = 0;

	CRandomNumbersNN RandomNumbers;

	// for hidden and bias neurons:
	CActivationSequence *pUsedActivationSequence = nullptr;
	CActivationSequence *pUsedActivationSequence_LastHiddenLayer = nullptr;

	int32_t NumOfDendriteNeurons = 0;
	int32_t *pDendriteNeuronIDArray = nullptr;

	CNeuralNetV2();
	~CNeuralNetV2();

	// Kopierkonstruktor l�schen:
	CNeuralNetV2(const CNeuralNetV2  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CNeuralNetV2 & operator=(const CNeuralNetV2  &originalObject) = delete;

	void Clone(const CNeuralNetV2 *pOriginalObject);
	void Clone_Data(const CNeuralNetV2 *pOriginalObject);

	// first:
	void Init_NeuralNet(int32_t numOfNeurons);
	// second:
	void Set_NumOfOutputValues(int32_t number);
	// third:
	void Set_NumOfInputValues(int32_t number);

	void Change_Seed(uint64_t newSeed);
	
	void Init_DendriteNeuronIDArray(int32_t numOfRBFNeurons);

	void Set_DendriteNeuronID(int32_t neuronID, int32_t arrayPos);
	void Set_DendriteNeuronIDs(int32_t *pNeuronIDArray);

	void Set_DendriteNeuronID_And_Init_RBF_Arrays(int32_t neuronID, int32_t arrayPos, int32_t num_Of_Dendrite_Elements);
	void Set_DendriteNeuronIDs_And_Init_Dendrite_Arrays(int32_t *pNeuronIDArray, int32_t num_Of_Dendrite_Elements);

	void Set_InputNeuron_LearningRate(float learningRate);
	void Set_InputNeuron_SynapticFunction(pSynapticFuncV2 pFunc);
	
	void Set_OutputNeuron_ErrorFactors(float factor1, float factor2);

	void Set_OutputNeuron_ActivationFunction(pActivationFuncV2 pFunc);

	void Set_ActivationFunction(int32_t firstNeuronID, int32_t lastNeuronID, pActivationFuncV2 pFunc);

	// last initialization step:
	void Set_SynapticFunction(int32_t firstNeuronID, int32_t lastNeuronID, pSynapticFuncV2 pFunc);

	void Set_LearningRate(int32_t firstNeuronID, int32_t lastNeuronID, float learningRate);
	void Set_ErrorFactors(int32_t firstNeuronID, int32_t lastNeuronID, float factor1, float factor2);

	void Use_As_BiasNeuron(int32_t neuronID, bool status);

	void Init_OutputSynapses(int32_t neuronID, const CNeuralConnections  *pNeuralConnections);
	void Init_OutputSynapses(int32_t firstNeuronID, int32_t lastNeuronID, const CNeuralConnections *pNeuralConnections);

	void Init_OutputSynapses(int32_t neuronID, CNeuralConnections *pNeuralConnections, float minSynapticPlasticity, float maxSynapticPlasticity);
	void Init_OutputSynapses(int32_t firstNeuronID, int32_t lastNeuronID, CNeuralConnections *pNeuralConnections, float minSynapticPlasticity, float maxSynapticPlasticity);

	void Randomize_OutputSynapsePlasticities(float minValue, float maxValue);
	void Randomize_OutputSynapsePlasticities(float minValue, float maxValue, float mutationRate);
	void Randomize_OutputSynapsePlasticities(int32_t neuronID, float minValue, float maxValue);
	void Randomize_OutputSynapsePlasticities(int32_t neuronID, float minValue, float maxValue, float mutationRate);
	void Randomize_OutputSynapsePlasticities(int32_t firstNeuronID, int32_t lastNeuronID, float minValue, float maxValue);
	void Randomize_OutputSynapsePlasticities(int32_t firstNeuronID, int32_t lastNeuronID, float minValue, float maxValue, float mutationRate);

	void Randomize_OutputSynapsePlasticities(uint64_t newSeed, float minValue, float maxValue);
	void Randomize_OutputSynapsePlasticities(uint64_t newSeed, float minValue, float maxValue, float mutationRate);
	void Randomize_OutputSynapsePlasticities(uint64_t newSeed, int32_t neuronID, float minValue, float maxValue);
	void Randomize_OutputSynapsePlasticities(uint64_t newSeed, int32_t neuronID, float minValue, float maxValue, float mutationRate);
	void Randomize_OutputSynapsePlasticities(uint64_t newSeed, int32_t firstNeuronID, int32_t lastNeuronID, float minValue, float maxValue);
	void Randomize_OutputSynapsePlasticities(uint64_t newSeed, int32_t firstNeuronID, int32_t lastNeuronID, float minValue, float maxValue, float mutationRate);

	void Modify_OutputSynapsePlasticities(float minValue, float maxValue);
	void Modify_OutputSynapsePlasticities(float minValue, float maxValue, float mutationRate);
	void Modify_OutputSynapsePlasticities(int32_t neuronID, float minValue, float maxValue);
	void Modify_OutputSynapsePlasticities(int32_t neuronID, float minValue, float maxValue, float mutationRate);
	void Modify_OutputSynapsePlasticities(int32_t firstNeuronID, int32_t lastNeuronID, float minValue, float maxValue);
	void Modify_OutputSynapsePlasticities(int32_t firstNeuronID, int32_t lastNeuronID, float minValue, float maxValue, float mutationRate);

	void Modify_OutputSynapsePlasticities(uint64_t newSeed, float minValue, float maxValue);
	void Modify_OutputSynapsePlasticities(uint64_t newSeed, float minValue, float maxValue, float mutationRate);
	void Modify_OutputSynapsePlasticities(uint64_t newSeed, int32_t neuronID, float minValue, float maxValue);
	void Modify_OutputSynapsePlasticities(uint64_t newSeed, int32_t neuronID, float minValue, float maxValue, float mutationRate);
	void Modify_OutputSynapsePlasticities(uint64_t newSeed, int32_t firstNeuronID, int32_t lastNeuronID, float minValue, float maxValue);
	void Modify_OutputSynapsePlasticities(uint64_t newSeed, int32_t firstNeuronID, int32_t lastNeuronID, float minValue, float maxValue, float mutationRate);

	void Clone_OutputSynapsePlasticities(const CNeuralNetV2 *pOriginalObject, int32_t firstNeuronID = -1, int32_t lastNeuronID = -1);

	void Combine_OutputSynapsePlasticities_RandomWeighted(const CNeuralNetV2 *pParentObject1, const CNeuralNetV2 *pParentObject2, int32_t firstNeuronID = -1, int32_t lastNeuronID = -1);
	void Combine_OutputSynapsePlasticities_RandomWeighted(uint64_t newSeed, const CNeuralNetV2 *pParentObject1, const CNeuralNetV2 *pParentObject2, int32_t firstNeuronID = -1, int32_t lastNeuronID = -1);

	// min/max weight: 0 to 1
	void Combine_OutputSynapsePlasticities_RandomWeighted(const CNeuralNetV2 *pParentObject1, const CNeuralNetV2 *pParentObject2, float minParent1Weight, float maxParent1Weight, int32_t firstNeuronID = -1, int32_t lastNeuronID = -1);
	void Combine_OutputSynapsePlasticities_RandomWeighted(uint64_t newSeed, const CNeuralNetV2 *pParentObject1, const CNeuralNetV2 *pParentObject2, float minParent1Weight, float maxParent1Weight, int32_t firstNeuronID = -1, int32_t lastNeuronID = -1);

	// min/max weight: 0 to 100
	void Combine_OutputSynapsePlasticities(const CNeuralNetV2 *pParentObject1, const CNeuralNetV2 *pParentObject2, float weightFactorParent1, int32_t firstNeuronID = -1, int32_t lastNeuronID = -1);
	void Combine_OutputSynapsePlasticities(uint64_t newSeed, const CNeuralNetV2 *pParentObject1, const CNeuralNetV2 *pParentObject2, float weightFactorParent1, int32_t firstNeuronID = -1, int32_t lastNeuronID = -1);
	
	void Combine_OutputSynapsePlasticities(const CNeuralNetV2 *pParentObject1, const CNeuralNetV2 *pParentObject2, pRecombinationFunc pFunc, void *pParam, int32_t firstNeuronID = -1, int32_t lastNeuronID = -1);
	void Combine_OutputSynapsePlasticities(uint64_t newSeed, const CNeuralNetV2 *pParentObject1, const CNeuralNetV2 *pParentObject2, pRecombinationFunc pFunc, void *pParam, int32_t firstNeuronID = -1, int32_t lastNeuronID = -1);
	

	void Disable_Random_OutputSynapses(int32_t firstNeuronID, int32_t lastNeuronID, float probabilityValue);
	void Disable_Random_OutputSynapses(uint64_t newSeed, int32_t firstNeuronID, int32_t lastNeuronID, float probabilityValue);

	void Random_Enable_Disabled_OutputSynapses(int32_t firstNeuronID, int32_t lastNeuronID, float probabilityValue);
	void Random_Enable_Disabled_OutputSynapses(uint64_t newSeed, int32_t firstNeuronID, int32_t lastNeuronID, float probabilityValue);

	void Enable_Disabled_OutputSynapses(int32_t firstNeuronID, int32_t lastNeuronID);

	
	// for hidden and bias neurons:
	void Set_ActivationSequence(CActivationSequence *pSequence);

	// for extreme learning:
	void Set_ActivationSequence_LastHiddenLayer(CActivationSequence *pSequence);

	void Remove_Unused_Connections(void);

	void Round_SynapticPlasticities(float precision);

	void Round_Dendrite_Values(float precision);
	void Round_Dendrite_CentroidValues(float precision);
	void Round_Dendrite_Factors(float precision);
	
	void Randomize_Dendrite_Values(float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor);
	void Randomize_Dendrite_Values(int32_t neuronID, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor);
	void Randomize_Dendrite_Values(float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor, float mutationRate);
	void Randomize_Dendrite_Values(int32_t neuronID, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor, float mutationRate);

	void Randomize_Dendrite_Values(uint64_t newSeed, float minCentroidValue, float maxCentroidValue, float minvactor, float maxFactor);
	void Randomize_Dendrite_Values(uint64_t newSeed, int32_t neuronID, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor);
	void Randomize_Dendrite_Values(uint64_t newSeed, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor, float mutationRate);
	void Randomize_Dendrite_Values(uint64_t newSeed, int32_t neuronID, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor, float mutationRate);

	void Modify_Dendrite_Values(float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance);
	void Modify_RBF_Values(int32_t neuronID, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance);
	void Modify_RBF_Values(float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance, float mutationRate);
	void Modify_Dendrite_Values(int32_t neuronID, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance, float mutationRate);

	void Modify_Dendrite_Values(uint64_t newSeed, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance);
	void Modify_Dendrite_Values(uint64_t newSeed, int32_t neuronID, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance);
	void Modify_Dendrite_Values(uint64_t newSeed, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance, float mutationRate);
	void Modify_Dendrite_Values(uint64_t newSeed, int32_t neuronID, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance, float mutationRate);

	void Combine_Dendrite_Data(const CNeuralNetV2 *pParentObject1, const CNeuralNetV2 *pParentObject2);
	void Combine_Dendrite_Data(uint64_t newSeed, const CNeuralNetV2 *pParentObject1, const CNeuralNetV2 *pParentObject2);

	// min/max weight: 0 to 100
	void Combine_Dendrite_Data(const CNeuralNetV2 *pParentObject1, const CNeuralNetV2 *pParentObject2, float weightFactorParent1);
	void Combine_Dendrite_Data(uint64_t newSeed, const CNeuralNetV2 *pParentObject1, const CNeuralNetV2 *pParentObject2, float weightFactorParent1);

	void Combine_Dendrite_Data_RandomWeighted(const CNeuralNetV2 *pParentObject1, const CNeuralNetV2 *pParentObject2);
	void Combine_Dendrite_Data_RandomWeighted(uint64_t newSeed, const CNeuralNetV2 *pParentObject1, const CNeuralNetV2 *pParentObject2);

	// min/max weight: 0 to 1
	void Combine_Dendrite_Data_RandomWeighted(const CNeuralNetV2 *pParentObject1, const CNeuralNetV2 *pParentObject2, float minParent1Weight, float maxParent1Weight);
	void Combine_Dendrite_Data_RandomWeighted(uint64_t newSeed, const CNeuralNetV2 *pParentObject1, const CNeuralNetV2 *pParentObject2, float minParent1Weight, float maxParent1Weight);

	void Combine_Dendrite_Data(const CNeuralNetV2 *pParentObject1, const CNeuralNetV2 *pParentObject2, pRecombinationFunc pFunc, void *pParam);
	void Combine_Dendrite_Data(uint64_t newSeed, const CNeuralNetV2 *pParentObject1, const CNeuralNetV2 *pParentObject2, pRecombinationFunc pFunc, void *pParam);
	
	void Calculate_Output(float *pOutputValueArray, const float *pInputValueArray);
	float Calculate_Output_With_Error(float *pOutputValueArray, const float *pInputValueArray);
	
	float Calculate_VarianceSq(const float *pDesiredOutputValueArray);
	float Calculate_Error(const float *pDesiredOutputValueArray);
	float Learning(const float *pDesiredOutputValueArray);

	// Nur die Plastizit�tswerte der mit den Output-Neuronen verbundenen Synapsen werden modifiziert:
	float ExtremeLearning(const float *pDesiredOutputValueArray);

	// Nur die Plastizit�tswerte der mit den Output-Neuronen verbundenen Synapsen werden modifiziert:
	float ExtremeLearning(float desiredOutputValue, int32_t idOfOutputNeuron);

	void Adjust_OutputSynapses(const CNeuralNetV2 *pBestNeuralNet);
	void Adjust_OutputSynapses(const CNeuralNetV2 *pBestNeuralNet, float learningRate, float learningRateVariance, float errorFactor1 = 1.0f, float errorFactor2 = 1.0f);
};

class CShortTermMemoryElementV2
{
public:

	int32_t NumOfNeurons = 0;
	int32_t NumOfMemoryNeurons = 0;
	int32_t NumOfOutputNeurons = 0;

	CNeuronV2 *pNeuronArray = nullptr;

	int32_t FirstOutputNeuronID = 0;
	int32_t FirstMemoryNeuronID = 0;

	CShortTermMemoryElementV2();
	~CShortTermMemoryElementV2();

	// Kopierkonstruktor l�schen:
	CShortTermMemoryElementV2(const CShortTermMemoryElementV2 &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CShortTermMemoryElementV2& operator=(const CShortTermMemoryElementV2 &originalObject) = delete;

	void Set_MemoryNeuronActivationFunction(pActivationFuncV2 pFunc, int32_t idOfMemeoryNeuron);
	void Set_OutputNeuronActivationFunction(pActivationFuncV2 pFunc, int32_t idOfOutputNeuron);

	void Reset_Memory(void);
	float Get_Actual_Output(void);
	void Get_Actual_Output(float *pOutputValueArray);
	float Get_MemoryNeuronOutput(int32_t idOfMemeoryNeuron);

	void Initialize_SingleInput_SingleOutput(int32_t numOfMemoryNeurons, pActivationFuncV2 pFunc, float memoryDrecreaseFactor = 1.0f);
	void Initialize_SingleInput_SingleOutput(int32_t numOfMemoryNeurons, pActivationFuncV2 pFunc1, pActivationFuncV2 pFunc_LastMemoryNeuron, float memoryDrecreaseFactor = 1.0f);
	void Initialize_SingleInput_OutputArray(int32_t numOfOutputNeurons, pActivationFuncV2 pFunc, float memoryDrecreaseFactor = 1.0f);

	float Calculate_Output(float inputValue);
	void Calculate_Output(float *pOutputValueArray, float inputValue);

	void Clone_Memory(CShortTermMemoryElementV2 *pMemoryNetwork);
	void Permute_Memory_Randomly(CRandomNumbersNN *pRandomNumbers);
	void Permute_Memory(int32_t id1, int32_t id2);
};

class C2DPatternDetectorV2
{
public:

	uint32_t SizeXDir;
	uint32_t SizeYDir;
	uint32_t Size;  // SizeXDir * SizeYDir

	float *pValueArray = nullptr;

	//int32_t Num_Of_RBF_Elements = 0;
	float *pUsed_RBF_CentroidValueArray = nullptr;
	float *pUsed_RBF_FactorArray = nullptr;
	
	C2DPatternDetectorV2();
	~C2DPatternDetectorV2();

	// Kopierkonstruktor l�schen:
	C2DPatternDetectorV2(const C2DPatternDetectorV2 &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	C2DPatternDetectorV2& operator=(const C2DPatternDetectorV2 &originalObject) = delete;


	void Connect_With_Neuron(CNeuronV2 *pNeuron);
	void Connect_With_Neuron(CNeuronV2 *pNeuron, int32_t first_RBF_ElementID);

	void Initialize(uint32_t sizeXDir, uint32_t sizeYDir);
	void Set_SizeOnly(uint32_t sizeXDir, uint32_t sizeYDir);

	bool Load_Data(const char* pFilename);
	bool Save_Data(const char* pFilename);

	bool Load_Binary_Data_From_Bitmap(const char* pDescFilename /*not the bitmap*/, bool binaryImageData, bool use_0_And_1_Values = true);
	bool Load_Data_From_Bitmap(const char* pDescFilename /*not the bitmap*/, float dataBiasValue = 0.0f);

	// ok
	bool Search_Pattern(int32_t *pOutPatternCount, int32_t *pOutPatternPosXArray, int32_t *pOutPatternPosYArray, int32_t maxPosArrayElements, const float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, float minActivationValue);

	// ok
	bool Search_Pattern_RBF(int32_t *pOutPatternCount, int32_t *pOutPatternPosXArray, int32_t *pOutPatternPosYArray, int32_t maxPosArrayElements, const float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, pSimpleActivationFunc pActivationFunction, float minActivationValue);

	// ok
	bool Search_Pattern(int32_t *pOutPatternCount, int32_t *pOutPatternPosXArray, int32_t *pOutPatternPosYArray, int32_t maxPosArrayElements, const float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, float activationValue, float minTolerance, float maxTolerance);

	bool Search_Pattern_RBF(int32_t *pOutPatternCount, int32_t *pOutPatternPosXArray, int32_t *pOutPatternPosYArray, int32_t maxPosArrayElements, const float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, pSimpleActivationFunc pActivationFunction, float activationValue, float minTolerance, float maxTolerance);

	// ok
	bool Check_For_Pattern(int32_t patternTestPosX, int32_t patternTestPosY, const float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, float minActivationValue);

	// ok
	bool Check_For_Pattern_RBF(int32_t patternTestPosX, int32_t patternTestPosY, const float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, pSimpleActivationFunc pActivationFunction, float minActivationValue);

	// ok
	bool Check_For_Pattern(float *pOutActivationvalue, int32_t patternTestPosX, int32_t patternTestPosY, const float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, float minActivationValue);

	//ok
	bool Check_For_Pattern_RBF(float *pOutActivationvalue, int32_t patternTestPosX, int32_t patternTestPosY, const float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, pSimpleActivationFunc pActivationFunction, float minActivationValue);

	// ok
	bool Check_For_Pattern(int32_t patternTestPosX, int32_t patternTestPosY, const float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, float activationValue, float minTolerance, float maxTolerance);

	// ok
	bool Check_For_Pattern_RBF(int32_t patternTestPosX, int32_t patternTestPosY, const float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, pSimpleActivationFunc pActivationFunction, float activationValue, float minTolerance, float maxTolerance);

	// ok
	bool Check_For_Pattern(float *pOutActivationvalue, int32_t patternTestPosX, int32_t patternTestPosY, const float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, float activationValue, float minTolerance, float maxTolerance);

	bool Check_For_Pattern_RBF(float *pOutActivationvalue, int32_t patternTestPosX, int32_t patternTestPosY, const float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, pSimpleActivationFunc pActivationFunction, float activationValue, float minTolerance, float maxTolerance);
};

class CNeuralNetPopulationV2
{
public:

	uint64_t Seed = 1;
	CRandomNumbersNN RandomNumbers;

	int32_t PopulationSize;
	int32_t PopulationSizePlusX;

	static constexpr int32_t constNumOfAdditionalBrains = 5;
	static constexpr int32_t constNumOfRandomBrainsChilds = constNumOfAdditionalBrains - 3;

	CNeuralNetV2 **ppUsedNeuralNetArray = nullptr;

	float *pFitnessScoreArray = nullptr;

	static constexpr int32_t constNumOfBestFittedBrains = 10;
	int32_t IDArrayOfBestFittedBrains[constNumOfBestFittedBrains];
	float FitnessArrayOfBestFittedBrains[constNumOfBestFittedBrains];

	static constexpr int32_t constNumOfWorstFittedBrains = 10;
	int32_t IDArrayOfWorstFittedBrains[constNumOfWorstFittedBrains];
	float FitnessArrayOfWorstFittedBrains[constNumOfWorstFittedBrains];

	bool UseAdditionalMutatedBestBrain = false;
	bool UseAdditionalMutatedSecondBestBrain = false;
	bool UseAdditionalBestBrainsChild = false;
	bool UseAdditionalRandomBrainsChild[constNumOfRandomBrainsChilds];

	int32_t RandomBrainsChildCounter = 0;

	static constexpr int32_t constNumPopulationSearchStepsMax = 3;


	float MinErrorSum_ActualGeneration;

	CNeuralNetPopulationV2();
	~CNeuralNetPopulationV2();

	// Kopierkonstruktor l�schen:
	CNeuralNetPopulationV2(const CNeuralNetPopulationV2 &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CNeuralNetPopulationV2& operator=(const CNeuralNetPopulationV2 &originalObject) = delete;

	bool Initialize(uint32_t populationSize);

	void Set_NeuralNet(CNeuralNetV2 *pNeuralNet, int32_t id);

	void Change_Seed(uint64_t seed);

	void Reset_MinErrorSum_ActualGeneration(float value = 1000000.0f);
	void Update_MinErrorSum_ActualGeneration(float value);

	void Round_SynapticPlasticities(float precision);

	void Round_Dendrite_Values(float precision);
	void Round_Dendrite_CentroidValues(float precision);
	void Round_Dendrite_Factors(float precision);

	
	void Randomize_OutputSynapsePlasticities(float minValue, float maxValue);
	void Randomize_OutputSynapsePlasticities(int32_t neuronID, float minValue, float maxValue);
	void Randomize_OutputSynapsePlasticities(int32_t firstNeuronID, int32_t lastNeuronID, float minValue, float maxValue);
	
	void Randomize_OutputSynapsePlasticities(float minValue, float maxValue, float mutationRate);
	void Randomize_OutputSynapsePlasticities(int32_t neuronID, float minValue, float maxValue, float mutationRate);
	void Randomize_OutputSynapsePlasticities(int32_t firstNeuronID, int32_t lastNeuronID, float minValue, float maxValue, float mutationRate);

	void Randomize_OutputSynapsePlasticities(uint64_t seed, float minValue, float maxValue);
	void Randomize_OutputSynapsePlasticities(uint64_t seed, int32_t neuronID, float minValue, float maxValue);
	void Randomize_OutputSynapsePlasticities(uint64_t seed, int32_t firstNeuronID, int32_t lastNeuronID, float minValue, float maxValue);

	void Randomize_OutputSynapsePlasticities(uint64_t seed, float minValue, float maxValue, float mutationRate);
	void Randomize_OutputSynapsePlasticities(uint64_t seed, int32_t neuronID, float minValue, float maxValue, float mutationRate);
	void Randomize_OutputSynapsePlasticities(uint64_t seed, int32_t firstNeuronID, int32_t lastNeuronID, float minValue, float maxValue, float mutationRate);
	
	void Modify_OutputSynapsePlasticities(float minValue, float maxValue);
	void Modify_OutputSynapsePlasticities(int32_t neuronID, float minValue, float maxValue);
	void Modify_OutputSynapsePlasticities(int32_t firstNeuronID, int32_t lastNeuronID, float minValue, float maxValue);

	void Modify_OutputSynapsePlasticities(float minValue, float maxValue, float mutationRate);
	void Modify_OutputSynapsePlasticities(int32_t neuronID, float minValue, float maxValue, float mutationRate);
	void Modify_OutputSynapsePlasticities(int32_t firstNeuronID, int32_t lastNeuronID, float minValue, float maxValue, float mutationRate);

	void Modify_OutputSynapsePlasticities(uint64_t seed, float minValue, float maxValue);
	void Modify_OutputSynapsePlasticities(uint64_t seed, int32_t neuronID, float minValue, float maxValue);
	void Modify_OutputSynapsePlasticities(uint64_t seed, int32_t firstNeuronID, int32_t lastNeuronID, float minValue, float maxValue);

	void Modify_OutputSynapsePlasticities(uint64_t seed, float minValue, float maxValue, float mutationRate);
	void Modify_OutputSynapsePlasticities(uint64_t seed, int32_t neuronID, float minValue, float maxValue, float mutationRate);
	void Modify_OutputSynapsePlasticities(uint64_t seed, int32_t firstNeuronID, int32_t lastNeuronID, float minValue, float maxValue, float mutationRate);


	// For user-defined calculations e. g. Randomization or Permutation:
	void Reinitialize_Dendrite_Values(pNeuralNetV2ReinitializationFunc pFunc, void *pParam);
	// For user-defined calculations e. g. Randomization or Permutation:
	void Reinitialize_Dendrite_Values(uint64_t seed, pNeuralNetV2ReinitializationFunc pFunc, void *pParam);

	// For user-defined calculations e. g. Mutation, Modification or Permutation:
	void Mutate_Dendrite_Values(pNeuralNetV2MutationFunc pFunc, void *pParam);
	// For user-defined calculations e. g. Mutation, Modification or Permutation:
	void Mutate_Dendrite_Values(uint64_t seed, pNeuralNetV2MutationFunc pFunc, void *pParam);


	void Randomize_Dendrite_Values(float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor);
	void Randomize_Dendrite_Values(int32_t neuronID, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor);
	void Randomize_Dendrite_Values(float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor, float mutationRate);
	void Randomize_Dendrite_Values(int32_t neuronID, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor, float mutationRate);

	void Randomize_Dendrite_Values(uint64_t seed, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor);
	void Randomize_Dendrite_Values(uint64_t seed, int32_t neuronID, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor);
	void Randomize_Dendrite_Values(uint64_t seed, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor, float mutationRate);
	void Randomize_Dendrite_Values(uint64_t seed, int32_t neuronID, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor, float mutationRate);


	void Modify_Dendrite_Values(float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance);
	void Modify_Dendrite_Values(int32_t neuronID, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance);
	void Modify_Dendrite_Values(float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance, float mutationRate);
	void Modify_Dendrite_Values(int32_t neuronID, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance, float mutationRate);

	void Modify_Dendrite_Values(uint64_t seed, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance);
	void Modify_Dendrite_Values(uint64_t seed, int32_t neuronID, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance);
	void Modify_Dendrite_Values(uint64_t seed, float minCentroidValue, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance, float mutationRate);
	void Modify_Dendrite_Values(uint64_t seed, int32_t neuronID, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactor, float mutationRate);

	


	CNeuralNetV2* Get_Best_Evolved_NeuralNet(void);
	void Get_Best_Evolved_NeuralNet(CNeuralNetV2* pOutNeuralNet);

	void Update_BaseEvolution(pNeuralNetV2MutationFunc pFunc, void *pParam);

	void Update_Evolution_Combine_TwoBrains(pNeuralNetV2RecombinationFunc pFunc, void *pParam);
	void Update_Evolution_Combine_BestTwoBrains(pNeuralNetV2RecombinationFunc pFunc, void *pParam);
	
	void Update_Evolution_BestBrainOnly(pNeuralNetV2MutationFunc pFunc, void *pParam);
	void Update_Evolution_SecondBestBrainOnly(pNeuralNetV2MutationFunc pFunc, void *pParam);

	void Update_Population(float *pFitnessValueArray);

	void Replace_WorstFitted_Brain(pNeuralNetV2ReinitializationFunc pFunc, void *pParam);
	void Replace_SecondWorstFitted_Brain(pNeuralNetV2ReinitializationFunc pFunc, void *pParam);
	void Replace_ThirdWorstFitted_Brain(pNeuralNetV2ReinitializationFunc pFunc, void *pParam);

	void Learning(int32_t neuralNetID);
	void Learning(int32_t neuralNetID, float learningRate, float learningRateVariance, float errorFactor1 = 1.0f, float errorFactor2 = 1.0f);

};


class CDendriteNeuronPopulation
{
public:

	uint64_t Seed = 1;
	CRandomNumbersNN RandomNumbers;

	int32_t PopulationSize;
	int32_t PopulationSizePlusX;

	static constexpr int32_t constNumOfAdditionalBrains = 5;
	static constexpr int32_t constNumOfRandomBrainsChilds = constNumOfAdditionalBrains - 3;

	CNeuronV2 **ppNeuronArray = nullptr;
	float *pFitnessScoreArray = nullptr;

	static constexpr int32_t constNumOfBestFittedBrains = 10;
	int32_t IDArrayOfBestFittedBrains[constNumOfBestFittedBrains];
	float FitnessArrayOfBestFittedBrains[constNumOfBestFittedBrains];

	static constexpr int32_t constNumOfWorstFittedBrains = 10;
	int32_t IDArrayOfWorstFittedBrains[constNumOfWorstFittedBrains];
	float FitnessArrayOfWorstFittedBrains[constNumOfWorstFittedBrains];

	bool UseAdditionalMutatedBestBrain = false;
	bool UseAdditionalMutatedSecondBestBrain = false;
	bool UseAdditionalBestBrainsChild = false;
	bool UseAdditionalRandomBrainsChild[constNumOfRandomBrainsChilds];

	int32_t RandomBrainsChildCounter = 0;

	static constexpr int32_t constNumPopulationSearchStepsMax = 3;

	float MinErrorSum_ActualGeneration;

	CDendriteNeuronPopulation();
	~CDendriteNeuronPopulation();

	// Kopierkonstruktor l�schen:
	CDendriteNeuronPopulation(const CDendriteNeuronPopulation &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CDendriteNeuronPopulation& operator=(const CDendriteNeuronPopulation &originalObject) = delete;

	bool Initialize(int32_t populationSize);
	void Set_Neuron(CNeuronV2 *pNeuron, int32_t id);

	void Init_Or_Reinitialize_Dendrite_Arrays(int32_t num_Of_Dendrite_Elements);

	void Select_UsedDendrites(int32_t minID, int32_t numDendrites);

	void Set_ActivationFunction(pActivationFuncV2 pFunc);
	void Set_DendriticFunction(pDendriticFuncV2 pFunc);

	CNeuronV2* Get_Best_Evolved_Neuron(void);
	void Get_Best_Evolved_Neuron(CNeuronV2* pOutNeuron);

	void Change_Seed(uint64_t seed);

	void Reset_MinErrorSum_ActualGeneration(float value = 10000000.0f);
	void Update_MinErrorSum_ActualGeneration(float value);

	void Set_Dendrite_Data(float *pRBF_CentroidValueArray, float *pRBF_FactorArray);
	void Set_Dendrite_CentroidValues(float *pRBF_CentroidValueArray);
	void Set_Dendrite_Factors(float *pRBF_FactorArray);

	void Round_Dendrite_Values(float precision);
	void Round_Dendrite_CentroidValues(float precision);
	void Round_Dendrite_Factors(float precision);

	void Round_Dendrite_Values(float precision, int32_t minDendriteID, int32_t maxDendriteID);
	void Round_Dendrite_CentroidValues(float precision, int32_t minDendriteID, int32_t maxDendriteID);
	void Round_Dendrite_Factors(float precision, int32_t minDendriteID, int32_t maxDendriteID);

	// For user-defined calculations e. g. Randomization or Permutation:
	void Reinitialize_Dendrite_Values(pReinitializationFunc pFunc, void *pParam);
	// For user-defined calculations e. g. Randomization or Permutation:
	void Reinitialize_Dendrite_Values(uint64_t seed, pReinitializationFunc pFunc, void *pParam);

	// For user-defined calculations e. g. Mutation, Modification or Permutation:
	void Mutate_Dendrite_Values(pMutationFunc pFunc, void *pParam);
	// For user-defined calculations e. g. Mutation, Modification or Permutation:
	void Mutate_Dendrite_Values(uint64_t seed, pMutationFunc pFunc, void *pParam);


	void Permute_Dendrite_Values(int32_t minDendriteID, int32_t maxDendriteID, int32_t permutationSteps);
	void Permute_Dendrite_Values(uint64_t seed, int32_t minDendriteID, int32_t maxDendriteID, int32_t permutationSteps);

	void Permute_Dendrite_CentroidValues(int32_t minDendriteID, int32_t maxDendriteID, int32_t permutationSteps);
	void Permute_Dendrite_CentroidValues(uint64_t seed, int32_t minDendriteID, int32_t maxDendriteID, int32_t permutationSteps);

	void Permute_Dendrite_Factors(int32_t minDendriteID, int32_t maxDendriteID, int32_t permutationSteps);
	void Permute_Dendrite_Factors(uint64_t seed, int32_t minDendriteID, int32_t maxDendriteID, int32_t permutationSteps);



	void Randomize_Dendrite_Values(float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor);
	void Randomize_Dendrite_Values(uint64_t seed, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor);
	void Randomize_Dendrite_Values(float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor, float mutationRate);
	void Randomize_Dendrite_Values(uint64_t seed, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor, float mutationRate);
	void Randomize_Dendrite_Values(int32_t minDendriteID, int32_t maxDendriteID, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor);
	void Randomize_Dendrite_Values(uint64_t seed, int32_t minDendriteID, int32_t maxDendriteID, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor);
	void Randomize_Dendrite_Values(int32_t minDendriteID, int32_t maxDendriteID, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor, float mutationRate);
	void Randomize_Dendrite_Values(uint64_t seed, int32_t minDendriteID, int32_t maxDendriteID, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor, float mutationRate);

	void Randomize_Dendrite_Factors(float minValue, float maxValue);
	void Randomize_Dendrite_Factors(uint64_t seed, float minValue, float maxValue);
	void Randomize_Dendrite_Factors(float minValue, float maxValue, float mutationRate);
	void Randomize_Dendrite_Factors(uint64_t seed, float minValue, float maxValue, float mutationRate);
	void Randomize_Dendrite_Factors(int32_t minDendriteID, int32_t maxDendriteID, float minValue, float maxValue);
	void Randomize_Dendrite_Factors(uint64_t seed, int32_t minDendriteID, int32_t maxDendriteID, float minValue, float maxValue);
	void Randomize_Dendrite_Factors(int32_t minDendriteID, int32_t maxDendriteID, float minValue, float maxValue, float mutationRate);
	void Randomize_Dendrite_Factors(uint64_t seed, int32_t minDendriteID, int32_t maxDendriteID, float minValue, float maxValue, float mutationRate);

	void Randomize_Dendrite_CentroidValues(float minValue, float maxValue);
	void Randomize_Dendrite_CentroidValues(uint64_t seed, float minValue, float maxValue);
	void Randomize_Dendrite_CentroidValues(float minValue, float maxValue, float mutationRate);
	void Randomize_Dendrite_CentroidValues(uint64_t seed, float minValue, float maxValue, float mutationRate);
	void Randomize_Dendrite_CentroidValues(int32_t minDendriteID, int32_t maxDendriteID, float minValue, float maxValue);
	void Randomize_Dendrite_CentroidValues(uint64_t seed, int32_t minDendriteID, int32_t maxDendriteID, float minValue, float maxValue);
	void Randomize_Dendrite_CentroidValues(int32_t minDendriteID, int32_t maxDendriteID, float minValue, float maxValue, float mutationRate);
	void Randomize_Dendrite_CentroidValues(uint64_t seed, int32_t minDendriteID, int32_t maxDendriteID, float minValue, float maxValue, float mutationRate);



	void Modify_Dendrite_Values(float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance);
	void Modify_Dendrite_Values(uint64_t seed, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance);
	void Modify_Dendrite_Values(float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance, float mutationRate);
	void Modify_Dendrite_Values(uint64_t seed, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance, float mutationRate);
	void Modify_Dendrite_Values(int32_t minDendriteID, int32_t maxDendriteID, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance);
	void Modify_Dendrite_Values(uint64_t seed, int32_t minDendriteID, int32_t maxDendriteID, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance);
	void Modify_Dendrite_Values(int32_t minDendriteID, int32_t maxDendriteID, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance, float mutationRate);
	void Modify_Dendrite_Values(uint64_t seed, int32_t minDendriteID, int32_t maxDendriteID, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance, float mutationRate);


	void Modify_Dendrite_Factors(float minVariance, float maxVariance);
	void Modify_Dendrite_Factors(uint64_t seed, float minVariance, float maxVariance);
	void Modify_Dendrite_Factors(float minVariance, float maxVariance, float mutationRate);
	void Modify_Dendrite_Factors(uint64_t seed, float minVariance, float maxVariance, float mutationRate);
	void Modify_Dendrite_Factors(int32_t minDendriteID, int32_t maxDendriteID, float minVariance, float maxVariance);
	void Modify_Dendrite_Factors(uint64_t seed, int32_t minDendriteID, int32_t maxDendriteID, float minVariance, float maxVariance);
	void Modify_Dendrite_Factors(int32_t minDendriteID, int32_t maxDendriteID, float minVariance, float maxVariance, float mutationRate);
	void Modify_Dendrite_Factors(uint64_t seed, int32_t minDendriteID, int32_t maxDendriteID, float minVariance, float maxVariance, float mutationRate);


	void Modify_Dendrite_CentroidValues(float minVariance, float maxVariance);
	void Modify_Dendrite_CentroidValues(uint64_t seed, float minVariance, float maxVariance);
	void Modify_Dendrite_CentroidValues(float minVariance, float maxVariance, float mutationRate);
	void Modify_Dendrite_CentroidValues(uint64_t seed, float minVariance, float maxVariance, float mutationRate);
	void Modify_Dendrite_CentroidValues(int32_t minDendriteID, int32_t maxDendriteID, float minVariance, float maxVariance);
	void Modify_Dendrite_CentroidValues(uint64_t seed, int32_t minDendriteID, int32_t maxDendriteID, float minVariance, float maxVariance);
	void Modify_Dendrite_CentroidValues(int32_t minDendriteID, int32_t maxDendriteID, float minVariance, float maxVariance, float mutationRate);
	void Modify_Dendrite_CentroidValues(uint64_t seed, int32_t minDendriteID, int32_t maxDendriteID, float minVariance, float maxVariance, float mutationRate);

	

	void Update_Evolution_Combine_BestTwoBrains(void);
	void Update_Evolution_Combine_BestTwoBrains(pRecombinationFunc pFunc, void *pParam);

	void Update_Evolution_Combine_TwoBrains(void);
	void Update_Evolution_Combine_TwoBrains(pRecombinationFunc pFunc, void *pParam);
	

	void Update_BaseEvolution(pMutationFunc pFunc, void *pParam);

	void Update_BaseEvolution_Dendrite_Values(float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance, float mutationRate);
	void Update_BaseEvolution_Dendrite_Values(int32_t minDendriteID, int32_t maxDendriteID, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance, float mutationRate);


	void Update_BaseEvolution_Dendrite_Factors(float minVariance, float maxVariance, float mutationRate);
	void Update_BaseEvolution_Dendrite_Factors(int32_t minDendriteID, int32_t maxDendriteID, float minVariance, float maxVariance, float mutationRate);

	void Update_BaseEvolution_Dendrite_CentroidValues(float minVariance, float maxVariance, float mutationRate);
	void Update_BaseEvolution_Dendrite_CentroidValues(int32_t minDendriteID, int32_t maxDendriteID, float minVariance, float maxVariance, float mutationRate);


	void Update_BaseEvolution_Dendrite_Permutations(int32_t minDendriteID, int32_t maxDendriteID, int32_t permutationSteps);
	void Update_BaseEvolution_Dendrite_CentroidValue_Permutations(int32_t minDendriteID, int32_t maxDendriteID, int32_t permutationSteps);
	void Update_BaseEvolution_Dendrite_Factor_Permutations(int32_t minDendriteID, int32_t maxDendriteID, int32_t permutationSteps);


	void Update_Evolution_BestBrainOnly(pMutationFunc pFunc, void *pParam);
	
	void Update_Evolution_BestBrainOnly_Dendrite_Values(float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance, float mutationRate);

	void Update_Evolution_BestBrainOnly_Dendrite_Values(int32_t minDendriteID, int32_t maxDendriteID, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance, float mutationRate);

	void Update_Evolution_BestBrainOnly_Dendrite_Factors(float minVariance, float maxVariance, float mutationRate);

	void Update_Evolution_BestBrainOnly_Dendrite_Factors(int32_t minDendriteID, int32_t maxDendriteID, float minVariance, float maxVariance, float mutationRate);

	void Update_Evolution_BestBrainOnly_Dendrite_CentroidValues(float minVariance, float maxVariance, float mutationRate);

	void Update_Evolution_BestBrainOnly_Dendrite_CentroidValues(int32_t minDendriteID, int32_t maxDendriteID, float minVariance, float maxVariance, float mutationRate);
	
	void Update_Evolution_BestBrainOnly_Dendrite_Permutations(int32_t minDendriteID, int32_t maxDendriteID, int32_t permutationSteps);
	void Update_Evolution_BestBrainOnly_Dendrite_CentroidValue_Permutations(int32_t minDendriteID, int32_t maxDendriteID, int32_t permutationSteps);
	void Update_Evolution_BestBrainOnly_Dendrite_Factor_Permutations(int32_t minDendriteID, int32_t maxDendriteID, int32_t permutationSteps);


	void Update_Evolution_SecondBestBrainOnly(pMutationFunc pFunc, void *pParam);

	void Update_Evolution_SecondBestBrainOnly_Dendrite_Values(float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance, float mutationRate);

	void Update_Evolution_SecondBestBrainOnly_Dendrite_Values(int32_t minDendriteID, int32_t maxDendriteID, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance, float mutationRate);
	
	void Update_Evolution_SecondBestBrainOnly_Dendrite_Factors(float minVariance, float maxVariance, float mutationRate);

	void Update_Evolution_SecondBestBrainOnly_Dendrite_Factors(int32_t minDendriteID, int32_t maxDendriteID, float minVariance, float maxVariance, float mutationRate);

	void Update_Evolution_SecondBestBrainOnly_Dendrite_CentroidValues(float minVariance, float maxVariance, float mutationRate);

	void Update_Evolution_SecondBestBrainOnly_Dendrite_CentroidValues(int32_t minDendriteID, int32_t maxDendriteID, float minVariance, float maxVariance, float mutationRate);


	void Update_Evolution_SecondBestBrainOnly_Dendrite_Permutations(int32_t minDendriteID, int32_t maxDendriteID, int32_t permutationSteps);
	void Update_Evolution_SecondBestBrainOnly_Dendrite_CentroidValue_Permutations(int32_t minDendriteID, int32_t maxDendriteID, int32_t permutationSteps);
	void Update_Evolution_SecondBestBrainOnly_Dendrite_Factor_Permutations(int32_t minDendriteID, int32_t maxDendriteID, int32_t permutationSteps);

	
	void Update_Population(float *pFitnessValueArray);
	void Update_Population(void);

	void Update_Population_Ext(float *pFitnessValueArray);
	void Update_Population_Ext(void);

	void Update_PopulationKnowledge(int32_t minDendriteID, int32_t maxDendriteID);

	void Learning(pNeuronV2PopulationLearningFunc pFunc, int32_t neuronID, float learningRate, float learningRateVariance, float errorFactor1 = 1.0f, float errorFactor2 = 1.0f);

	void Replace_WorstFitted_Brain(pReinitializationFunc pFunc, void *pParam);
	void Replace_SecondWorstFitted_Brain(pReinitializationFunc pFunc, void *pParam);
	void Replace_ThirdWorstFitted_Brain(pReinitializationFunc pFunc, void *pParam);

	void Replace_WorstFitted_Brain(uint64_t seed, pReinitializationFunc pFunc, void *pParam);
	void Replace_SecondWorstFitted_Brain(uint64_t seed, pReinitializationFunc pFunc, void *pParam);
	void Replace_ThirdWorstFitted_Brain(uint64_t seed, pReinitializationFunc pFunc, void *pParam);

};


class CInputValueArrayList
{
public:

	int32_t InputArraySize = 0;
	int32_t NumOfInputArrays = 0;

	float *pInputArrayValues = nullptr;

	CInputValueArrayList();
	~CInputValueArrayList();


	// Kopierkonstruktor l�schen:
	CInputValueArrayList(const CInputValueArrayList &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CInputValueArrayList& operator=(const CInputValueArrayList &originalObject) = delete;

	void Initialize(int32_t inputArraySize, int32_t numOfInputArrays);
	void Set_ArrayValues(float *pArrayValues, int32_t arrayID);

	float* Get_FirstArrayElement(int32_t arrayID);
	void Get_FirstArrayElement(float *pOutArrayElement, int32_t arrayID);
};




class CNeuronLayerV2
{
public:

	int32_t NumOfNeurons = 0;
	CNeuronV2 *pNeuronArray = nullptr;

	CNeuronLayerV2();
	~CNeuronLayerV2();

	// Kopierkonstruktor l�schen:
	CNeuronLayerV2(const CNeuronLayerV2  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CNeuronLayerV2 & operator=(const CNeuronLayerV2  &originalObject) = delete;

	void Initialize(int32_t numOfNeurons);
};

// Definition eines Funktionszeiger-Typs:
typedef float(*pOutputActivationFuncV2)(float neuronInput);


class COutputLayerV2
{
public:

	int32_t NumOfElements = 0;

	float *pNeuronValueArray = nullptr;
	float *pModifiedNeuronValueArray = nullptr;
	float *pErrorValueArray = nullptr;

	pOutputActivationFuncV2 pActivationFunction = nullptr;

	COutputLayerV2();
	~COutputLayerV2();

	// Kopierkonstruktor l�schen:
	COutputLayerV2(const COutputLayerV2  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	COutputLayerV2 & operator=(const COutputLayerV2  &originalObject) = delete;

	void Set_ActivationFunction(pOutputActivationFuncV2 pFunc);

	void Initialize(int32_t numOfElements);
	void Reset_InputValues(void);
	void Add_InputValues(float *pValueArray);
	void Add_InputValues(CNeuronV2 *pNeuron);

	void Calculate_Input(CNeuronV2 *pNeuronArray, int32_t numOfNeurons);
	void Calculate_Input(CNeuronLayerV2 *pNeuronLayer);

	void Calculate_Output(pOutputActivationFuncV2 pFunc);
	void Calculate_Output(void);

	float Calculate_ErrorValues(float *pInDesiredValueArray, float errorFactor1 = 1.0f, float errorFactor2 = 1.0f);
	float Calculate_ErrorValues(float *pOutVarianceArray, float *pInDesiredValueArray, float errorFactor1 = 1.0f, float errorFactor2 = 1.0f);

	void Calculate_PrecedingNeuronErrorValues(CNeuronV2 *pNeuron, float errorFactor1 = 1.0f, float errorFactor2 = 1.0f);
	void Calculate_PrecedingNeuronErrorValues(CNeuronV2 *pNeuronArray, int32_t numOfNeurons, float errorFactor1 = 1.0f, float errorFactor2 = 1.0f);
	void Calculate_PrecedingNeuronErrorValues(CNeuronLayerV2 *pNeuronLayer, float errorFactor1 = 1.0f, float errorFactor2 = 1.0f);

	void Adjust_PrecedingNeuronOutputSynapses_AfterErrorCalculations(CNeuronV2 *pNeuron, float learningRate);
	void Adjust_PrecedingNeuronOutputSynapses_AfterErrorCalculations(CNeuronV2 *pNeuronArray, int32_t numOfNeurons, float learningRate);
	void Adjust_PrecedingNeuronOutputSynapses_AfterErrorCalculations(CNeuronLayerV2 *pNeuronLayer, float learningRate);

	void Get_NeuronOutputValues(float *pOutValueArray);
	void Get_ModifiedNeuronOutputValues(float *pOutValueArray);
	
	float Get_NeuronOutputSum(float minValue, float maxValue);

	float Get_Output_Of_NeuronWithMaxOutput(void);
	float Get_Output_Of_NeuronWithMinOutput(void);

	void Get_ID_And_Output_Of_NeuronWithMaxOutput(int32_t *pOutNeuronID, float *pOutNeuronOutput);
	void Get_ID_And_Output_Of_NeuronWithMinOutput(int32_t *pOutNeuronID, float *pOutNeuronOutput);

	void Calculate_ProbabilityValues(void);
	void Calculate_NormalizedOutputValues(void);
	void Calculate_SoftmaxValues(void);
};














#endif