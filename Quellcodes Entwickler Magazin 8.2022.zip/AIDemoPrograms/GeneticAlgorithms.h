// Schutz vor Mehrfachdeklarationen :

#ifndef _GeneticAlgorithms_H_
#define _GeneticAlgorithms_H_

#pragma warning( disable: 4996)

#include <iostream>
#include "RandomNumbers.h"
#include "MemoryManagement.h"

#ifndef max
#define max(a,b)    ( ((a) > (b)) ? (a) : (b) )
#endif

#ifndef min
#define min(a,b)    ( ((a) < (b)) ? (a) : (b) )
#endif

typedef void(*pGeneralRecombination)(void *pOffspring, void *pParent1, void *pParent2, CRandomNumbersNN *pRandomNumbers, void *pParam);
typedef void(*pGeneralMutation)(void *pInOutGenome, CRandomNumbersNN *pRandomNumbers, void *pParam);
typedef void(*pGeneralPermutation)(void *pInOutGenome, CRandomNumbersNN *pRandomNumbers, void *pParam);
typedef void(*pGeneralReinitialization)(void *pInOutGenome, CRandomNumbersNN *pRandomNumbers, void *pParam);
typedef void(*pGeneralReinitialization2)(void *pInOutGenome, void *pInBaseGenome, CRandomNumbersNN *pRandomNumbers, void *pParam);

typedef void(*pGenomeValueCloning)(void *pOutGenome, void *pInGenome);

typedef void(*pGeneralSpeciesTransformation)(void *pInOutGenome, CRandomNumbersNN *pRandomNumbers, void *pParam);

// example: replacing old memory with new memory
typedef void(*pGeneralInterchange)(void *pInOutGenome1, void *pInOutGenome2, CRandomNumbersNN *pRandomNumbers, void *pParam);

struct CSimpleMutationInfo
{
	float minValue = -0.1f;
	float maxValue = 0.1f;
	float mutationRate = 0.75f;
};

struct CRBFMutationInfo
{
	float minValue_FunctionParam = -0.1f;
	float maxValue_FunctionParam = 0.1f;
	float mutationRate_FunctionParam = 0.75f;

	float minValue_Centroid = -0.1f;
	float maxValue_Centroid = 0.1f;
	float mutationRate_Centroid = 0.75f;

	float minValue_ExpFactor = -0.1f;
	float maxValue_ExpFactor = 0.1f;
	float mutationRate_ExpFactor = 0.75f;
};



struct CSimpleReinitializationInfo
{
	float minValue = -0.1f;
	float maxValue = 0.1f;
};

struct CRBFReinitializationInfo
{
	float minValue_FunctionParam = -0.1f;
	float maxValue_FunctionParam = 0.1f;
	
	float minValue_Centroid = -0.1f;
	float maxValue_Centroid = 0.1f;
	
	float minValue_ExpFactor = -0.1f;
	float maxValue_ExpFactor = 0.1f;
	
};




class CSimpleMultipleSpeciesReinitializationInfo
{
public:

	float minValue = -0.1f;
	float maxValue = 0.1f;
	float geneDeactivationRate = 0.75f;

	int32_t NumOfGenes = 0;
	bool *pGeneChangeableUsageArray = nullptr;

	CSimpleMultipleSpeciesReinitializationInfo() {};

	~CSimpleMultipleSpeciesReinitializationInfo()
	{
		delete[] pGeneChangeableUsageArray;
		pGeneChangeableUsageArray = nullptr;
	}

	// Kopierkonstruktor l�schen:
	CSimpleMultipleSpeciesReinitializationInfo(const CSimpleMultipleSpeciesReinitializationInfo &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CSimpleMultipleSpeciesReinitializationInfo& operator=(const CSimpleMultipleSpeciesReinitializationInfo &originalObject) = delete;

	void Initialize(int32_t numOfGenes)
	{
		delete[] pGeneChangeableUsageArray;
		pGeneChangeableUsageArray = nullptr;

		NumOfGenes = numOfGenes;
		pGeneChangeableUsageArray = new (std::nothrow) bool[NumOfGenes];

		for (int32_t i = 0; i < NumOfGenes; i++)
		{
			pGeneChangeableUsageArray[i] = false;
		}
	}
};




class CSimpleIntegerValueGenome
{
public:

	int32_t NumOfGenes = 0;
	int32_t *pGeneArray = nullptr;

	/* Zeiger, mit deren Hilfe der Zugriff auf die Simulationszeit (sofern erhoben) erm�glicht wird: */
	int32_t *iPtrToGlobalSimulationTime = nullptr;
	float *fPtrToGlobalSimulationTime = nullptr;

	CSimpleIntegerValueGenome();
	~CSimpleIntegerValueGenome();

	// Kopierkonstruktor l�schen:
	CSimpleIntegerValueGenome(const CSimpleIntegerValueGenome &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CSimpleIntegerValueGenome& operator=(const CSimpleIntegerValueGenome &originalObject) = delete;

	void Get_Access_To_iGlobalSimulationTime(int32_t *pGlobalSimulationTime);
	void Get_Access_To_fGlobalSimulationTime(float *pGlobalSimulationTime);

	void Initialize(int32_t numOfGenes);
	void Set_GeneData(int32_t *pData);
	void Permute_GeneData(CRandomNumbersNN *pRandomNumbers, int32_t minGeneID, int32_t maxGeneID, int32_t permutationSteps);
};

void CSimpleIntegerValueGenome_CloningFunction(void *pOutGenome, void *pInGenome);


class CIntegerValueGenome
{
public:

	int32_t NumOfGenes = 0;
	int32_t *pGeneArray = nullptr;
	bool *pGeneUsageArray = nullptr;
	bool *pGeneChangeabilityArray = nullptr;

	/* Zeiger, mit deren Hilfe der Zugriff auf die Simulationszeit (sofern erhoben) erm�glicht wird: */
	int32_t *iPtrToGlobalSimulationTime = nullptr;
	float *fPtrToGlobalSimulationTime = nullptr;

	CIntegerValueGenome();
	~CIntegerValueGenome();

	// Kopierkonstruktor l�schen:
	CIntegerValueGenome(const CIntegerValueGenome &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CIntegerValueGenome& operator=(const CIntegerValueGenome &originalObject) = delete;

	void Get_Access_To_iGlobalSimulationTime(int32_t *pGlobalSimulationTime);
	void Get_Access_To_fGlobalSimulationTime(float *pGlobalSimulationTime);

	void Initialize(int32_t numOfGenes);

	void Set_GeneData(int32_t *pData);
	void Set_GeneUsageData(bool *pUsageData);
	void Set_GeneChangeabilityData(bool *pChangeabilityData);

	void Permute_GeneData(CRandomNumbersNN *pRandomNumbers, int32_t minGeneID, int32_t maxGeneID, int32_t permutationSteps);

	int32_t Get_NumOfUsedGenes(void);
	float Get_fNumOfUsedGenes(void);
};

void CIntegerValueGenome_CloningFunction(void *pOutGenome, void *pInGenome);


class CSimpleFloatValueGenome
{
public:

	int32_t NumOfGenes = 0;
	float *pGeneArray = nullptr;

	/* Zeiger, mit deren Hilfe der Zugriff auf die Simulationszeit (sofern erhoben) erm�glicht wird: */
	int32_t *iPtrToGlobalSimulationTime = nullptr;
	float *fPtrToGlobalSimulationTime = nullptr;

	CSimpleFloatValueGenome();
	~CSimpleFloatValueGenome();

	// Kopierkonstruktor l�schen:
	CSimpleFloatValueGenome(const CSimpleFloatValueGenome &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CSimpleFloatValueGenome& operator=(const CSimpleFloatValueGenome &originalObject) = delete;

	void Get_Access_To_iGlobalSimulationTime(int32_t *pGlobalSimulationTime);
	void Get_Access_To_fGlobalSimulationTime(float *pGlobalSimulationTime);

	void Initialize(int32_t numOfGenes);
	void Set_GeneData(float *pData);
	void Permute_GeneData(CRandomNumbersNN *pRandomNumbers, int32_t minGeneID, int32_t maxGeneID, int32_t permutationSteps);
};

void CSimpleFloatValueGenome_CloningFunction(void *pOutGenome, void *pInGenome);


class CFloatValueGenome
{
public:

	int32_t NumOfGenes = 0;
	float *pGeneArray = nullptr;
	bool *pGeneUsageArray = nullptr;
	bool *pGeneChangeabilityArray = nullptr;

	/* Zeiger, mit deren Hilfe der Zugriff auf die Simulationszeit (sofern erhoben) erm�glicht wird: */
	int32_t *iPtrToGlobalSimulationTime = nullptr;
	float *fPtrToGlobalSimulationTime = nullptr;

	CFloatValueGenome();
	~CFloatValueGenome();

	// Kopierkonstruktor l�schen:
	CFloatValueGenome(const CFloatValueGenome &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CFloatValueGenome& operator=(const CFloatValueGenome &originalObject) = delete;

	void Get_Access_To_iGlobalSimulationTime(int32_t *pGlobalSimulationTime);
	void Get_Access_To_fGlobalSimulationTime(float *pGlobalSimulationTime);

	void Initialize(int32_t numOfGenes);

	void Set_GeneData(float *pData);
	void Set_GeneUsageData(bool *pUsageData);
	void Set_GeneChangeabilityData(bool *pChangeabilityData);

	void Permute_GeneData(CRandomNumbersNN *pRandomNumbers, int32_t minGeneID, int32_t maxGeneID, int32_t permutationSteps);

	int32_t Get_NumOfUsedGenes(void);
	float Get_fNumOfUsedGenes(void);
};

void CFloatValueGenome_CloningFunction(void *pOutGenome, void *pInGenome);


/* F�r den Zugriff auf die genetischen Informationen (char *pCValueArray) bietet sich die  CExternal4ByteMemoryArray-Kasse an: */
class CGene
{
public:

	/* a value could be:
	   a time stamp,
	   an id of an array element, 
	   a function parameter,
	   a memory value,
	   a memory vector,
	   etc.
	*/

	int32_t NumOfIntegerValues = 0;
	int32_t *pIValueArray = nullptr;

	int32_t NumOfFloatValues = 0;
	float *pFValueArray = nullptr;

	int32_t NumOfCharValues = 0;
	char *pCValueArray = nullptr;

	CGene();
	~CGene();

	// Kopierkonstruktor l�schen:
	CGene(const CGene &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CGene& operator=(const CGene &originalObject) = delete;

	void Initialize(int32_t numOfIntegerValues, int32_t numOfFloatValues, int32_t numOfCharValues);
	
	void Clone_Values(CGene *pOriginalObject);

};

class CGeneFitness
{
public:

	float Fitness = 0.0f;
	int32_t NumOfUpdates = 0;

	CGeneFitness()
	{}
	
	~CGeneFitness()
	{}

	void Reset(void)
	{
		Fitness = 0.0f;
		NumOfUpdates = 0;
	}

	void Set_Fitness(float value)
	{
		Fitness = value;
		NumOfUpdates = 1;
	}

	void Update_Fitness(float value)
	{
		if(NumOfUpdates == 0)
		{
			Fitness = value;
			NumOfUpdates = 1;
			return;
		}

		float weight1 = 1.0f / (static_cast<float>(NumOfUpdates) + 1.0f);
		float weight2 = 1.0f - weight1;

		Fitness = weight1 * value + weight2 * Fitness;
		NumOfUpdates++;
	}

	void Replace_With_HigherFitness_If_Possible(float value)
	{
		if (value > Fitness)
		{
			Fitness = value;
			NumOfUpdates = 1;
		}
	}
	void Replace_With_LowerFitness_If_Possible(float value)
	{
		if (value < Fitness)
		{
			Fitness = value;
			NumOfUpdates = 1;
		}
	}
};

class CChromosome
{
public:

	int32_t NumOfGenes = 0;
	int32_t MinGeneID = 0;
	int32_t MaxGeneIDPlus1 = 1;

	CChromosome();
	~CChromosome();

	void Set_Data1(int32_t numOfGenes, int32_t minGeneID);
	void Set_Data2(int32_t numOfGenes, int32_t minGeneID, int32_t maxGeneIDPlus1);
	void Set_Data3(int32_t minGeneID, int32_t maxGeneIDPlus1);

};

class CGenome
{
public:

	int32_t NumOfGenes = 0;
	CGene *pGeneArray = nullptr;
	bool *pGeneUsageArray = nullptr;
	bool *pGeneChangeabilityArray = nullptr;

	CGeneFitness *pGeneFitnessArray = nullptr;

	CGene TempGene;

	/* Zeiger, mit deren Hilfe der Zugriff auf die Simulationszeit (sofern erhoben) erm�glicht wird: */
	int32_t *iPtrToGlobalSimulationTime = nullptr;
	float *fPtrToGlobalSimulationTime = nullptr;


	/* Mit Hilfe von Chromosomen kann ein Genom besser strukturiert werden. So w�re es beispielsweise m�glich,
	   die Evolution lediglich auf einzelne Chromosomen zu beschr�nken. */
	int32_t NumOfChromosomes = 0;
	CChromosome *pChromosomeArray = nullptr;

	CGenome();
	~CGenome();

	// Kopierkonstruktor l�schen:
	CGenome(const CGenome &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CGenome& operator=(const CGenome &originalObject) = delete;

	void Get_Access_To_iGlobalSimulationTime(int32_t *pGlobalSimulationTime);
	void Get_Access_To_fGlobalSimulationTime(float *pGlobalSimulationTime);

	void Initialize(int32_t numOfGenes, int32_t numOfIntegerValuesPerGene, int32_t numOfFloatValuesPerGene, int32_t numOfCharValuesPerGene);
	void Initialize_GeneFitnessArray_If_Necessary(void);

	void Set_GeneFitness(float value, int32_t geneID);
	void Update_GeneFitness(float value, int32_t geneID);
	void Replace_With_HigherGeneFitness_If_Possible(float value, int32_t geneID);
	void Replace_With_LowerGeneFitness_If_Possible(float value, int32_t geneID);
	void Reset_GeneFitness(int32_t geneID);

	void Set_GeneData(CGene *pGenes);
	void Set_SingleGeneData(CGene *pGene, int32_t geneArrayElementID);

	void Set_GeneUsageData(bool *pUsageData);
	void Set_GeneChangeabilityData(bool *pChangeabilityData);

	void Permute_GeneData(CRandomNumbersNN *pRandomNumbers, int32_t minGeneID, int32_t maxGeneID, int32_t permutationSteps);

	void Initialize_Chromosomes_If_Necessary(int32_t numOfChromosomes);

	void Set_ChromosomeData1(int32_t chromosomeID, int32_t numOfGenes, int32_t minGeneID);
	void Set_ChromosomeData2(int32_t chromosomeID, int32_t numOfGenes, int32_t minGeneID, int32_t maxGeneIDPlus1);
	void Set_ChromosomeData3(int32_t chromosomeID, int32_t minGeneID, int32_t maxGeneIDPlus1);

	int32_t Get_NumOfUsedGenes(void);
	float Get_fNumOfUsedGenes(void);

	int32_t Get_NumOfUsedGenes(int32_t chromosomeID);
	float Get_fNumOfUsedGenes(int32_t chromosomeID);

};

void CGenome_CloningFunction(void *pOutGenome, void *pInGenome);



//-----------------------------------------------------------------------------

typedef void(*pGeneBasedCalculationFunction)(CGene *pGene, float *pDataArray);


//-----------------------------------------------------------------------------

static void Set_InputValueToZero(CGene *pGene, float *pDataArray)
{
	pDataArray[pGene->pIValueArray[2]] = 0.0f;
}

static void Set_InputValueBias(CGene *pGene, float *pDataArray)
{
	pDataArray[pGene->pIValueArray[2]] = pGene->pFValueArray[0];
}

static void Add_Bias_To_InputValue(CGene *pGene, float *pDataArray)
{
	pDataArray[pGene->pIValueArray[2]] += pGene->pFValueArray[0];
}

//-----------------------------------------------------------------------------

static void Set_OutputValueToZero(CGene *pGene, float *pDataArray)
{
	pDataArray[pGene->pIValueArray[1]] = 0.0f;
}

static void Set_OutputValueBias(CGene *pGene, float *pDataArray)
{
	pDataArray[pGene->pIValueArray[1]] = pGene->pFValueArray[0];
}

static void Add_Bias_To_OutputValue(CGene *pGene, float *pDataArray)
{
	pDataArray[pGene->pIValueArray[1]] += pGene->pFValueArray[0];
}

//-----------------------------------------------------------------------------

static void Calc_AbsDiff(CGene *pGene, float *pDataArray)
{
	float inputValue = pDataArray[pGene->pIValueArray[2]];
	pDataArray[pGene->pIValueArray[1]] = abs(inputValue - pGene->pFValueArray[0]);
}

static void Calc_WeightedAbsDiff(CGene *pGene, float *pDataArray)
{
	float inputValue = pDataArray[pGene->pIValueArray[2]];
	pDataArray[pGene->pIValueArray[1]] = pGene->pFValueArray[1] * abs(inputValue - pGene->pFValueArray[0]);
}

static void Calc_DiffSq(CGene *pGene, float *pDataArray)
{
	float diff = pDataArray[pGene->pIValueArray[2]] - pGene->pFValueArray[0];
	diff *= diff;
	pDataArray[pGene->pIValueArray[1]] = diff;
}

static void Calc_DiffSqSum_2DVecElements(CGene *pGene, float *pDataArray)
{
	float *pCentroidArray = &pGene->pFValueArray[0];
	int32_t *pInputIDArray = &pGene->pIValueArray[2];

	float diff = pDataArray[pInputIDArray[0]] - pCentroidArray[0];	
	float sum = diff * diff;

	diff = pDataArray[pInputIDArray[1]] - pCentroidArray[1];
	sum += diff * diff;

	int32_t resultID = pGene->pIValueArray[1];
	pDataArray[resultID] = sum;
}



static void Calc_WeightedDiffSq(CGene *pGene, float *pDataArray)
{
	float diff = pDataArray[pGene->pIValueArray[2]] - pGene->pFValueArray[0];
	diff *= diff;
	pDataArray[pGene->pIValueArray[1]] = pGene->pFValueArray[1] * diff;
}

//-----------------------------------------------------------------------------

static void Add(CGene *pGene, float *pDataArray)
{
	pDataArray[pGene->pIValueArray[1]] += pDataArray[pGene->pIValueArray[2]];
}

static void Add_Weighted(CGene *pGene, float *pDataArray)
{
	pDataArray[pGene->pIValueArray[1]] += pGene->pFValueArray[0] * pDataArray[pGene->pIValueArray[2]];
}

static void Sub(CGene *pGene, float *pDataArray)
{
	pDataArray[pGene->pIValueArray[1]] -= pDataArray[pGene->pIValueArray[2]];
}

static void Sub_Weighted(CGene *pGene, float *pDataArray)
{
	pDataArray[pGene->pIValueArray[1]] -= pGene->pFValueArray[0] * pDataArray[pGene->pIValueArray[2]];
}

//-----------------------------------------------------------------------------

static void Add_PolynomialTerm_1Degree(CGene *pGene, float *pDataArray)
{
	pDataArray[pGene->pIValueArray[1]] += pGene->pFValueArray[0] * pDataArray[pGene->pIValueArray[2]];
}

static void Add_PolynomialTerm_2Degree(CGene *pGene, float *pDataArray)
{
	float tempFloat = pDataArray[pGene->pIValueArray[2]];
	tempFloat *= tempFloat;
	pDataArray[pGene->pIValueArray[1]] += pGene->pFValueArray[0] * tempFloat;
}

static void Add_PolynomialTerm_3Degree(CGene *pGene, float *pDataArray)
{
	float tempFloat = pDataArray[pGene->pIValueArray[2]];
	pDataArray[pGene->pIValueArray[1]] += pGene->pFValueArray[0] * tempFloat * tempFloat * tempFloat;
}

static void Add_PolynomialTerm_4Degree(CGene *pGene, float *pDataArray)
{
	float tempFloat = pDataArray[pGene->pIValueArray[2]];
	tempFloat *= tempFloat;
	tempFloat *= tempFloat;
	pDataArray[pGene->pIValueArray[1]] += pGene->pFValueArray[0] * tempFloat;
}

//-----------------------------------------------------------------------------

static void Add_2DVecElements(CGene *pGene, float *pDataArray)
{
	int32_t resultID = pGene->pIValueArray[1];
	
	//pDataArray[resultID] += pDataArray[pGene->pIValueArray[2]];
	//pDataArray[resultID] += pDataArray[pGene->pIValueArray[2]];

	int32_t *pInputIDArray = &pGene->pIValueArray[2];

	pDataArray[resultID] += pDataArray[pInputIDArray[0]];
	pDataArray[resultID] += pDataArray[pInputIDArray[1]];
}

static void Add_Weighted_2DVecElements(CGene *pGene, float *pDataArray)
{
	int32_t resultID = pGene->pIValueArray[1];
	
	//pDataArray[resultID] += pGene->pFValueArray[0] * pDataArray[pGene->pIValueArray[2]];
	//pDataArray[resultID] += pGene->pFValueArray[1] * pDataArray[pGene->pIValueArray[3]];

	float *pWeightArray = &pGene->pFValueArray[0];
	int32_t *pInputIDArray = &pGene->pIValueArray[2];

	pDataArray[resultID] += pWeightArray[0] * pDataArray[pInputIDArray[0]];
	pDataArray[resultID] += pWeightArray[1] * pDataArray[pInputIDArray[1]];
}

//-----------------------------------------------------------------------------

static void TanH(CGene *pGene, float *pDataArray)
{
	// von -1.0f bis 1.0f:
	pDataArray[pGene->pIValueArray[1]] = tanh(pDataArray[pGene->pIValueArray[2]]);
	pDataArray[pGene->pIValueArray[2]] = 0.0f;
}

static void FastTanHReplacement(CGene *pGene, float *pDataArray)
{
	// von -1.0f bis 1.0f:
	float inputValue = pDataArray[pGene->pIValueArray[2]];

	pDataArray[pGene->pIValueArray[1]] = inputValue / (1.0f + abs(inputValue));
	pDataArray[pGene->pIValueArray[2]] = 0.0f;
}

static void Sigmoid(CGene *pGene, float *pDataArray)
{
	// von 0.0f bis 1.0f:
	pDataArray[pGene->pIValueArray[1]] = 1.0f / (1.0f + exp(-pDataArray[pGene->pIValueArray[2]]));
	pDataArray[pGene->pIValueArray[2]] = 0.0f;
}

static void ExpRBF(CGene *pGene, float *pDataArray)
{
	pDataArray[pGene->pIValueArray[1]] = exp(-pDataArray[pGene->pIValueArray[2]]);
	pDataArray[pGene->pIValueArray[2]] = 0.0f;
}

static void WeightedExpRBF(CGene *pGene, float *pDataArray)
{
	float rbfConst = pGene->pFValueArray[0];
	rbfConst *= rbfConst;

	pDataArray[pGene->pIValueArray[1]] = exp(-rbfConst * pDataArray[pGene->pIValueArray[2]]);
	pDataArray[pGene->pIValueArray[2]] = 0.0f;
}

static void ReLU(CGene *pGene, float *pDataArray)
{
	pDataArray[pGene->pIValueArray[1]] = max(0.0f, pDataArray[pGene->pIValueArray[2]]);
	pDataArray[pGene->pIValueArray[2]] = 0.0f;
}

static void LeakyReLU(CGene *pGene, float *pDataArray)
{
	float inputValue = pDataArray[pGene->pIValueArray[2]];

	if (inputValue < 0.0f)
		pDataArray[pGene->pIValueArray[1]] = pGene->pFValueArray[0] * inputValue;
	else
		pDataArray[pGene->pIValueArray[1]] = inputValue;

	pDataArray[pGene->pIValueArray[2]] = 0.0f;
}


static void Set_FunctionIdentifier_For_GeneBasedCalculations(CGene *pInOutGene, int32_t functionID)
{
	pInOutGene->pIValueArray[0] = functionID;
}

static void Set_OutputIdentifier_For_GeneBasedCalculations(CGene *pInOutGene, int32_t dataArrayElementID)
{
	pInOutGene->pIValueArray[1] = dataArrayElementID;
}

static void Set_InputIdentifier_For_GeneBasedCalculations(CGene *pInOutGene, int32_t dataArrayElementID, int32_t inputNo /*0, 1, 2, ...*/)
{
	pInOutGene->pIValueArray[2 + inputNo] = dataArrayElementID;
}

static void Set_Parameter_For_GeneBasedCalculations(CGene *pInOutGene, float parameter, int32_t parameterNo /*0, 1, 2, ...*/)
{
	pInOutGene->pFValueArray[parameterNo] = parameter;
}

class CGeneBasedCalculations
{
public:

	int32_t NumOfDataValues = 0;
	float *pDataArray = nullptr;

	
	int32_t NumOfCalculationFunctions = 0;
	pGeneBasedCalculationFunction *pCalculationFunctionArray = nullptr;

	CGeneBasedCalculations();
	~CGeneBasedCalculations();

	// Kopierkonstruktor l�schen:
	CGeneBasedCalculations(const CGeneBasedCalculations &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CGeneBasedCalculations& operator=(const CGeneBasedCalculations &originalObject) = delete;

	void Initialize_DataArray(int32_t numOfDataValues);
	void Initialize_CalculationFunctionArray(int32_t numOfFunctions);

	void Set_CalculationFunction(int32_t functionID, pGeneBasedCalculationFunction pFunc);

	void Execute_CalculationFunction(CGene *pGene);

	void Execute_CalculationFunctions(CGenome *pGenome);
	void Execute_CalculationFunctions(CGenome *pGenome, int32_t chromosomeID);

	void Execute_CalculationFunctionsExt(CGenome *pGenome);
	void Execute_CalculationFunctionsExt(CGenome *pGenome, int32_t chromosomeID);

	void Reset_DataArrayValues(void);

	void Set_DataArrayValue(int32_t dataArrayElementID, float value);
	float Get_DataArrayValue(int32_t dataArrayElementID);

	void Set_DataArrayValues(float *pInValueArray, int32_t firstDataArrayElementID, int32_t numOfValues);
	void Get_DataArrayValues(float *pOutValueArray, int32_t firstDataArrayElementID, int32_t numOfValues);

	// LRF: local receptive field
	bool Set_DataArrayValues_UseLRFCenterPos(int32_t posX_center, int32_t posY_center, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, int32_t firstDataArrayElementID);

	// LRF: local receptive field
	bool Set_DataArrayValues_UseLRFTopLeftPos(int32_t posX_left, int32_t posY_top, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, int32_t firstDataArrayElementID);
};




class CGeneralPopulation
{
public:

	uint64_t Seed = 1;
	CRandomNumbersNN RandomNumbers;

	int32_t PopulationSize;
	int32_t PopulationSizePlusX;

	static constexpr int32_t constNumOfAdditionalGenomes = 5;
	static constexpr int32_t constNumOfRandomGenomesChildren = constNumOfAdditionalGenomes - 3;

	void **ppGenomeArray = nullptr;
	float *pFitnessScoreArray = nullptr;

	static constexpr int32_t constNumOfBestFittedGenomes = 10;
	int32_t IDArrayOfBestFittedGenomes[constNumOfBestFittedGenomes];
	float FitnessArrayOfBestFittedGenomes[constNumOfBestFittedGenomes];

	static constexpr int32_t constNumOfWorstFittedGenomes = 10;
	int32_t IDArrayOfWorstFittedGenomes[constNumOfWorstFittedGenomes];
	float FitnessArrayOfWorstFittedGenomes[constNumOfWorstFittedGenomes];

	bool UseAdditionalMutatedBestGenome = false;
	bool UseAdditionalMutatedSecondBestGenome = false;
	bool UseAdditionalBestGenomesChild = false;
	bool UseAdditionalRandomGenomesChild[constNumOfRandomGenomesChildren];

	int32_t RandomGenomesChildCounter = 0;

	static constexpr int32_t constNumPopulationSearchStepsMax = 3;

	float MinErrorSum_LastGeneration = 0.0f;
	float MinErrorSum_ActualGeneration = 0.0f;

	pGenomeValueCloning GenomeValueCloningFunc = nullptr;

	CGeneralPopulation();
	~CGeneralPopulation();

	// Kopierkonstruktor l�schen:
	CGeneralPopulation(const CGeneralPopulation &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CGeneralPopulation& operator=(const CGeneralPopulation &originalObject) = delete;

	void Set_GenomeValueCloningFunction(pGenomeValueCloning pFunc);

	void Change_Seed(uint64_t seed);

	bool Initialize(int32_t populationSize);
	void Set_Genome(void *pInGenome, int32_t id);

	void* Get_Best_Evolved_Genome(void);
	void Get_Best_Evolved_Genome(void* pOutGenome);

	void Reset_Population(void);

	void Reset_MinErrorSum_ActualGeneration(float value = 10000000.0f);
	void Update_MinErrorSum_ActualGeneration(float value);

	void Calculate_FitnessScore_FromError(int32_t genomeID, float error);
	void Set_FitnessScore(int32_t genomeID, float score);
	void Add_FitnessScore(int32_t genomeID, float score);
	float Calculate_Error_From_FitnessScore(int32_t genomeID);
	float Get_FitnessScore(int32_t genomeID);
	void Reset_FitnessScore(int32_t genomeID);
	void Replace_With_MinFitnessScore(int32_t genomeID, float score);
	void Replace_With_MaxFitnessScore(int32_t genomeID, float score);

	void Update_Population(void);
	void Update_Population_Ext(void);

	void Update_PopulationKnowledge(void);

	void Update_Evolution_Combine_BestTwoGenomes(pGeneralRecombination pFunc, void *pParam);
	void Update_Evolution_Combine_BestTwoGenomes(pGeneralRecombination pFunc, CRandomNumbersNN *pRandomNumbers, void *pParam);

	void Update_Evolution_Combine_TwoGenomes(pGeneralRecombination pFunc, void *pParam);
	void Update_Evolution_Combine_TwoGenomes(pGeneralRecombination pFunc, CRandomNumbersNN *pRandomNumbers, void *pParam);

	void Update_Evolution_Combine_TwoOfTheBestGenomes(pGeneralRecombination pFunc, void *pParam);
	void Update_Evolution_Combine_TwoOfTheBestGenomes(pGeneralRecombination pFunc, CRandomNumbersNN *pRandomNumbers, void *pParam);

	void Update_Evolution_GenomeInterchange(pGeneralInterchange pFunc, void *pParam);
	void Update_Evolution_GenomeInterchange(pGeneralInterchange pFunc, CRandomNumbersNN *pRandomNumbers, void *pParam);

	// GlobalGenome could be an up-to-date memory representation used by all individuals:
	void Update_Evolution_GenomeInterchange(pGeneralInterchange pFunc, void *pInOutGlobalGenome, void *pParam);
	// GlobalGenome could be an up-to-date memory representation used by all individuals:
	void Update_Evolution_GenomeInterchange(pGeneralInterchange pFunc, void *pInOutGlobalGenome, CRandomNumbersNN *pRandomNumbers, void *pParam);

	void Update_BaseEvolution(pGeneralMutation pFunc, void *pParam);
	void Update_BaseEvolution(pGeneralMutation pFunc, CRandomNumbersNN *pRandomNumbers, void *pParam);

	void Update_BaseEvolution_SingleIndividual(pGeneralMutation pFunc, void* pParam);
	void Update_BaseEvolution_SingleIndividual(pGeneralMutation pFunc, CRandomNumbersNN* pRandomNumbers, void* pParam);

	void Update_BaseEvolution(int32_t numOfIndividuals, pGeneralMutation pFunc, void* pParam);
	void Update_BaseEvolution(int32_t numOfIndividuals, pGeneralMutation pFunc, CRandomNumbersNN* pRandomNumbers, void* pParam);

	void Update_BaseEvolution2(pGeneralPermutation pFunc, void *pParam);
	void Update_BaseEvolution2(pGeneralPermutation pFunc, CRandomNumbersNN *pRandomNumbers, void *pParam);

	void Update_BaseEvolution2_SingleIndividual(pGeneralPermutation pFunc, void* pParam);
	void Update_BaseEvolution2_SingleIndividual(pGeneralPermutation pFunc, CRandomNumbersNN* pRandomNumbers, void* pParam);

	void Update_BaseEvolution2(int32_t numOfIndividuals, pGeneralPermutation pFunc, void* pParam);
	void Update_BaseEvolution2(int32_t numOfIndividuals, pGeneralPermutation pFunc, CRandomNumbersNN* pRandomNumbers, void* pParam);

	void Update_Evolution_BestGenomeOnly(pGeneralMutation pFunc, void *pParam);
	void Update_Evolution_BestGenomeOnly(pGeneralMutation pFunc, CRandomNumbersNN *pRandomNumbers, void *pParam);

	void Update_Evolution_BestGenomeOnly2(pGeneralPermutation pFunc, void *pParam);
	void Update_Evolution_BestGenomeOnly2(pGeneralPermutation pFunc, CRandomNumbersNN *pRandomNumbers, void *pParam);

	void Update_Evolution_SecondBestGenomeOnly(pGeneralMutation pFunc, void *pParam);
	void Update_Evolution_SecondBestGenomeOnly(pGeneralMutation pFunc, CRandomNumbersNN *pRandomNumbers, void *pParam);

	void Update_Evolution_SecondBestGenomeOnly2(pGeneralPermutation pFunc, void *pParam);
	void Update_Evolution_SecondBestGenomeOnly2(pGeneralPermutation pFunc, CRandomNumbersNN *pRandomNumbers, void *pParam);


	void Replace_WorstFitted_Genome(pGeneralReinitialization pFunc, void *pParam);
	void Replace_SecondWorstFitted_Genome(pGeneralReinitialization pFunc, void *pParam);
	void Replace_ThirdWorstFitted_Genome(pGeneralReinitialization pFunc, void *pParam);

	void Replace_WorstFitted_Genome(pGeneralReinitialization pFunc, CRandomNumbersNN *pRandomNumbers, void *pParam);
	void Replace_SecondWorstFitted_Genome(pGeneralReinitialization pFunc, CRandomNumbersNN *pRandomNumbers, void *pParam);
	void Replace_ThirdWorstFitted_Genome(pGeneralReinitialization pFunc, CRandomNumbersNN *pRandomNumbers, void *pParam);

	void Replace_WorstFitted_Genome(pGeneralReinitialization2 pFunc, void *pInBaseGenome, void *pParam);
	void Replace_SecondWorstFitted_Genome(pGeneralReinitialization2 pFunc, void *pInBaseGenome, void *pParam);
	void Replace_ThirdWorstFitted_Genome(pGeneralReinitialization2 pFunc, void *pInBaseGenome, void *pParam);

	void Replace_WorstFitted_Genome(pGeneralReinitialization2 pFunc, void *pInBaseGenome, CRandomNumbersNN *pRandomNumbers, void *pParam);
	void Replace_SecondWorstFitted_Genome(pGeneralReinitialization2 pFunc, void *pInBaseGenome, CRandomNumbersNN *pRandomNumbers, void *pParam);
	void Replace_ThirdWorstFitted_Genome(pGeneralReinitialization2 pFunc, void *pInBaseGenome, CRandomNumbersNN *pRandomNumbers, void *pParam);


	void Modify_All_Genomes(pGeneralMutation pFunc, void *pParam);
	void Modify_All_Genomes2(pGeneralPermutation pFunc, void *pParam);

	void Modify_All_Genomes(pGeneralMutation pFunc, CRandomNumbersNN *pRandomNumbers, void *pParam);
	void Modify_All_Genomes2(pGeneralPermutation pFunc, CRandomNumbersNN *pRandomNumbers, void *pParam);

	// deactivation of unnecessary genes:
	void Transform_Species_If_Possible_BestGenomeOnly(pGeneralSpeciesTransformation pFunc, CRandomNumbersNN *pRandomNumbers, void *pParam);
	void Transform_Species_If_Possible_BestGenomeOnly(pGeneralSpeciesTransformation pFunc, void *pParam);
};



static void Reinitialization_Example1(void *pInOutGenome, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	CSimpleFloatValueGenome *pGenome = static_cast<CSimpleFloatValueGenome*>(pInOutGenome);

	int32_t numOfGenes = pGenome->NumOfGenes;

	for (int32_t i = 0; i < numOfGenes; i++)
	{
		pGenome->pGeneArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(-0.1f, 0.1f);
	}
}

static void Reinitialization_Example2(void *pInOutGenome, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	CSimpleFloatValueGenome *pGenome = static_cast<CSimpleFloatValueGenome*>(pInOutGenome);
	CSimpleReinitializationInfo *pReinitializationInfo = static_cast<CSimpleReinitializationInfo*>(pParam);

	float minValue = pReinitializationInfo->minValue;
	float maxValue = pReinitializationInfo->maxValue;

	int32_t numOfGenes = pGenome->NumOfGenes;

	for (int32_t i = 0; i < numOfGenes; i++)
	{
		pGenome->pGeneArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minValue, maxValue);
	}
}



static void Reinitialization_1DimRBFValues(void* pInOutGenome, CRandomNumbersNN* pRandomNumbers, void* pParam)
{
	CSimpleFloatValueGenome* pGenome = static_cast<CSimpleFloatValueGenome*>(pInOutGenome);
	CRBFReinitializationInfo* pReinitializationInfo = static_cast<CRBFReinitializationInfo*>(pParam);

	float minValue_FunctionParam = pReinitializationInfo->minValue_FunctionParam;
	float maxValue_FunctionParam = pReinitializationInfo->maxValue_FunctionParam;
	
	float minValue_Centroid = pReinitializationInfo->minValue_Centroid;
	float maxValue_Centroid = pReinitializationInfo->maxValue_Centroid;
	
	float minValue_ExpFactor = pReinitializationInfo->minValue_ExpFactor;
	float maxValue_ExpFactor = pReinitializationInfo->maxValue_ExpFactor;
	

	int32_t numOfGenes = pGenome->NumOfGenes;
	int32_t numOfGenomeParts = numOfGenes / 3;

	for (int32_t i = 0; i < numOfGenomeParts; i++)
	{
		pGenome->pGeneArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minValue_ExpFactor, maxValue_ExpFactor);	
	}

	int32_t maxIDPlus1 = 2 * numOfGenomeParts;

	for (int32_t i = numOfGenomeParts; i < maxIDPlus1; i++)
	{
		pGenome->pGeneArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minValue_FunctionParam, maxValue_FunctionParam);
	}

	maxIDPlus1 = 3 * numOfGenomeParts;
	
	for (int32_t i = 2 * numOfGenomeParts; i < maxIDPlus1; i++)
	{
		pGenome->pGeneArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minValue_Centroid, maxValue_Centroid);
	}	
}

static void Reinitialization_1DimAsymmetricRBFValues(void* pInOutGenome, CRandomNumbersNN* pRandomNumbers, void* pParam)
{
	CSimpleFloatValueGenome* pGenome = static_cast<CSimpleFloatValueGenome*>(pInOutGenome);
	CRBFReinitializationInfo* pReinitializationInfo = static_cast<CRBFReinitializationInfo*>(pParam);

	float minValue_FunctionParam = pReinitializationInfo->minValue_FunctionParam;
	float maxValue_FunctionParam = pReinitializationInfo->maxValue_FunctionParam;

	float minValue_Centroid = pReinitializationInfo->minValue_Centroid;
	float maxValue_Centroid = pReinitializationInfo->maxValue_Centroid;

	float minValue_ExpFactor = pReinitializationInfo->minValue_ExpFactor;
	float maxValue_ExpFactor = pReinitializationInfo->maxValue_ExpFactor;


	int32_t numOfGenes = pGenome->NumOfGenes;
	int32_t numOfGenomeParts = numOfGenes / 4;

	int32_t maxIDPlus1 = 2 * numOfGenomeParts;

	for (int32_t i = 0; i < maxIDPlus1; i++)
	{
		pGenome->pGeneArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minValue_ExpFactor, maxValue_ExpFactor);
	}

	maxIDPlus1 = 3 * numOfGenomeParts;

	for (int32_t i = 2 * numOfGenomeParts; i < maxIDPlus1; i++)
	{
		pGenome->pGeneArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minValue_FunctionParam, maxValue_FunctionParam);
	}

	maxIDPlus1 = 4 * numOfGenomeParts;

	for (int32_t i = 3 * numOfGenomeParts; i < maxIDPlus1; i++)
	{
		pGenome->pGeneArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minValue_Centroid, maxValue_Centroid);
	}
}



static void Reinitialization_1DimRBFValues_2OutputValues(void* pInOutGenome, CRandomNumbersNN* pRandomNumbers, void* pParam)
{
	CSimpleFloatValueGenome* pGenome = static_cast<CSimpleFloatValueGenome*>(pInOutGenome);
	CRBFReinitializationInfo* pReinitializationInfo = static_cast<CRBFReinitializationInfo*>(pParam);

	float minValue_FunctionParam = pReinitializationInfo->minValue_FunctionParam;
	float maxValue_FunctionParam = pReinitializationInfo->maxValue_FunctionParam;

	float minValue_Centroid = pReinitializationInfo->minValue_Centroid;
	float maxValue_Centroid = pReinitializationInfo->maxValue_Centroid;

	float minValue_ExpFactor = pReinitializationInfo->minValue_ExpFactor;
	float maxValue_ExpFactor = pReinitializationInfo->maxValue_ExpFactor;


	int32_t numOfGenes = pGenome->NumOfGenes;
	int32_t numOfGenomeParts = numOfGenes / 4;

	for (int32_t i = 0; i < numOfGenomeParts; i++)
	{
		pGenome->pGeneArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minValue_ExpFactor, maxValue_ExpFactor);
	}

	int32_t maxIDPlus1 = 3 * numOfGenomeParts;

	for (int32_t i = numOfGenomeParts; i < maxIDPlus1; i++)
	{
		pGenome->pGeneArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minValue_FunctionParam, maxValue_FunctionParam);
	}

	maxIDPlus1 = 4 * numOfGenomeParts;

	for (int32_t i = 3 * numOfGenomeParts; i < maxIDPlus1; i++)
	{
		pGenome->pGeneArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minValue_Centroid, maxValue_Centroid);
	}
}


static void Reinitialization_2DimRBFValues(void* pInOutGenome, CRandomNumbersNN* pRandomNumbers, void* pParam)
{
	CSimpleFloatValueGenome* pGenome = static_cast<CSimpleFloatValueGenome*>(pInOutGenome);
	CRBFReinitializationInfo* pReinitializationInfo = static_cast<CRBFReinitializationInfo*>(pParam);

	float minValue_FunctionParam = pReinitializationInfo->minValue_FunctionParam;
	float maxValue_FunctionParam = pReinitializationInfo->maxValue_FunctionParam;

	float minValue_Centroid = pReinitializationInfo->minValue_Centroid;
	float maxValue_Centroid = pReinitializationInfo->maxValue_Centroid;

	float minValue_ExpFactor = pReinitializationInfo->minValue_ExpFactor;
	float maxValue_ExpFactor = pReinitializationInfo->maxValue_ExpFactor;


	int32_t numOfGenes = pGenome->NumOfGenes;
	int32_t numOfGenomeParts = numOfGenes / 4;

	for (int32_t i = 0; i < numOfGenomeParts; i++)
	{
		pGenome->pGeneArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minValue_ExpFactor, maxValue_ExpFactor);		
	}

	int32_t maxIDPlus1 = 2 * numOfGenomeParts;

	for (int32_t i = numOfGenomeParts; i < maxIDPlus1; i++)
	{
		pGenome->pGeneArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minValue_FunctionParam, maxValue_FunctionParam);
	}

	maxIDPlus1 = 4 * numOfGenomeParts;

	for (int32_t i = 2 * numOfGenomeParts; i < maxIDPlus1; i++)
	{
		pGenome->pGeneArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minValue_Centroid, maxValue_Centroid);
	}
}

static void Reinitialization_2DimRBFValues_3OutputValues(void* pInOutGenome, CRandomNumbersNN* pRandomNumbers, void* pParam)
{
	CSimpleFloatValueGenome* pGenome = static_cast<CSimpleFloatValueGenome*>(pInOutGenome);
	CRBFReinitializationInfo* pReinitializationInfo = static_cast<CRBFReinitializationInfo*>(pParam);

	float minValue_FunctionParam = pReinitializationInfo->minValue_FunctionParam;
	float maxValue_FunctionParam = pReinitializationInfo->maxValue_FunctionParam;

	float minValue_Centroid = pReinitializationInfo->minValue_Centroid;
	float maxValue_Centroid = pReinitializationInfo->maxValue_Centroid;

	float minValue_ExpFactor = pReinitializationInfo->minValue_ExpFactor;
	float maxValue_ExpFactor = pReinitializationInfo->maxValue_ExpFactor;


	int32_t numOfGenes = pGenome->NumOfGenes;
	int32_t numOfGenomeParts = numOfGenes / 6;

	for (int32_t i = 0; i < numOfGenomeParts; i++)
	{
		pGenome->pGeneArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minValue_ExpFactor, maxValue_ExpFactor);
	}

	int32_t maxIDPlus1 = 4 * numOfGenomeParts;

	for (int32_t i = numOfGenomeParts; i < maxIDPlus1; i++)
	{
		pGenome->pGeneArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minValue_FunctionParam, maxValue_FunctionParam);
	}

	maxIDPlus1 = 6 * numOfGenomeParts;

	for (int32_t i = 4 * numOfGenomeParts; i < maxIDPlus1; i++)
	{
		pGenome->pGeneArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minValue_Centroid, maxValue_Centroid);
	}
}

static void Reinitialization_3DimRBFValues(void* pInOutGenome, CRandomNumbersNN* pRandomNumbers, void* pParam)
{
	CSimpleFloatValueGenome* pGenome = static_cast<CSimpleFloatValueGenome*>(pInOutGenome);
	CRBFReinitializationInfo* pReinitializationInfo = static_cast<CRBFReinitializationInfo*>(pParam);

	float minValue_FunctionParam = pReinitializationInfo->minValue_FunctionParam;
	float maxValue_FunctionParam = pReinitializationInfo->maxValue_FunctionParam;

	float minValue_Centroid = pReinitializationInfo->minValue_Centroid;
	float maxValue_Centroid = pReinitializationInfo->maxValue_Centroid;

	float minValue_ExpFactor = pReinitializationInfo->minValue_ExpFactor;
	float maxValue_ExpFactor = pReinitializationInfo->maxValue_ExpFactor;


	int32_t numOfGenes = pGenome->NumOfGenes;
	int32_t numOfGenomeParts = numOfGenes / 5;

	for (int32_t i = 0; i < numOfGenomeParts; i++)
	{
		pGenome->pGeneArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minValue_ExpFactor, maxValue_ExpFactor);	
	}

	int32_t maxIDPlus1 = 2 * numOfGenomeParts;

	for (int32_t i = numOfGenomeParts; i < maxIDPlus1; i++)
	{
		pGenome->pGeneArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minValue_FunctionParam, maxValue_FunctionParam);
	}

	maxIDPlus1 = 5 * numOfGenomeParts;

	for (int32_t i = 2 * numOfGenomeParts; i < maxIDPlus1; i++)
	{
		pGenome->pGeneArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minValue_Centroid, maxValue_Centroid);
	}
}


static void Reinitialization_Example3(void *pInOutGenome, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	CFloatValueGenome *pGenome = static_cast<CFloatValueGenome*>(pInOutGenome);
	CSimpleMultipleSpeciesReinitializationInfo *pReinitializationInfo = static_cast<CSimpleMultipleSpeciesReinitializationInfo*>(pParam);

	float minValue = pReinitializationInfo->minValue;
	float maxValue = pReinitializationInfo->maxValue;
	float geneDeactivationRate = pReinitializationInfo->geneDeactivationRate;

	int32_t numOfGenes = pGenome->NumOfGenes;

	for (int32_t i = 0; i < numOfGenes; i++)
	{
		pGenome->pGeneArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minValue, maxValue);
	}

	for (int32_t i = 0; i < numOfGenes; i++)
	{
		if (pReinitializationInfo->pGeneChangeableUsageArray[i] == true)
		{
			if (pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f) < geneDeactivationRate)
				pGenome->pGeneUsageArray[i] = false;
			else
				pGenome->pGeneUsageArray[i] = true;
		}
		else
			pGenome->pGeneUsageArray[i] = true;
	}
}

static void Reinitialization_Example4(void *pInOutGenome, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	CGenome *pGenome = static_cast<CGenome*>(pInOutGenome);
	CSimpleReinitializationInfo *pReinitializationInfo = static_cast<CSimpleReinitializationInfo*>(pParam);

	float minValue = pReinitializationInfo->minValue;
	float maxValue = pReinitializationInfo->maxValue;

	CGene *pGeneArray = pGenome->pGeneArray;

	int32_t numOfGenes = pGenome->NumOfGenes;
	int32_t numOfFloatValuesPerGene = pGeneArray[0].NumOfFloatValues;

	for (int32_t i = 0; i < numOfGenes; i++)
	{
		for (int32_t j = 0; j < numOfFloatValuesPerGene; j++)
		{
			pGeneArray[i].pFValueArray[j] = pRandomNumbers->Get_FloatNumber_IncludingZero(minValue, maxValue);
		}
	}
}

static void Reinitialization_Example5(void *pInOutGenome, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	CGenome *pGenome = static_cast<CGenome*>(pInOutGenome);
	CSimpleMultipleSpeciesReinitializationInfo *pReinitializationInfo = static_cast<CSimpleMultipleSpeciesReinitializationInfo*>(pParam);

	float minValue = pReinitializationInfo->minValue;
	float maxValue = pReinitializationInfo->maxValue;
	float geneDeactivationRate = pReinitializationInfo->geneDeactivationRate;

	CGene *pGeneArray = pGenome->pGeneArray;

	int32_t numOfGenes = pGenome->NumOfGenes;
	int32_t numOfFloatValuesPerGene = pGeneArray[0].NumOfFloatValues;

	for (int32_t i = 0; i < numOfGenes; i++)
	{
		for (int32_t j = 0; j < numOfFloatValuesPerGene; j++)
		{
			pGeneArray[i].pFValueArray[j] = pRandomNumbers->Get_FloatNumber_IncludingZero(minValue, maxValue);
		}
	}

	for (int32_t i = 0; i < numOfGenes; i++)
	{
		if (pReinitializationInfo->pGeneChangeableUsageArray[i] == true)
		{
			if (pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f) < geneDeactivationRate)
				pGenome->pGeneUsageArray[i] = false;
			else
				pGenome->pGeneUsageArray[i] = true;
		}
		else
			pGenome->pGeneUsageArray[i] = true;
	}
}





static void Mutation_Example1(void *pInOutGenome, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	CSimpleFloatValueGenome *pGenome = static_cast<CSimpleFloatValueGenome*>(pInOutGenome);

	int32_t numOfGenes = pGenome->NumOfGenes;

	for (int32_t i = 0; i < numOfGenes; i++)
	{
		pGenome->pGeneArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(-0.1f, 0.1f);
	}
}

static void Mutation_Example2(void *pInOutGenome, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	CSimpleFloatValueGenome *pGenome = static_cast<CSimpleFloatValueGenome*>(pInOutGenome);
	CSimpleMutationInfo *pMutationInfo = static_cast<CSimpleMutationInfo*>(pParam);

	float minValue = pMutationInfo->minValue;
	float maxValue = pMutationInfo->maxValue;
	float mutationRate = pMutationInfo->mutationRate;

	int32_t numOfGenes = pGenome->NumOfGenes;

	for (int32_t i = 0; i < numOfGenes; i++)
	{
		//if (pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f) > mutationRate)
		//continue;

		pGenome->pGeneArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minValue, maxValue);
	}
}

static void Mutation_Example2B(void* pInOutGenome, CRandomNumbersNN* pRandomNumbers, void* pParam)
{
	CSimpleFloatValueGenome* pGenome = static_cast<CSimpleFloatValueGenome*>(pInOutGenome);
	CSimpleMutationInfo* pMutationInfo = static_cast<CSimpleMutationInfo*>(pParam);

	float minValue = pMutationInfo->minValue;
	float maxValue = pMutationInfo->maxValue;
	float mutationRate = pMutationInfo->mutationRate;

	int32_t numOfGenes = pGenome->NumOfGenes;

	for (int32_t i = 0; i < numOfGenes; i++)
	{
		if (pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f) > mutationRate)
			continue;

		pGenome->pGeneArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minValue, maxValue);
	}
}

static void Mutation_1DimRBFValues(void* pInOutGenome, CRandomNumbersNN* pRandomNumbers, void* pParam)
{
	CSimpleFloatValueGenome* pGenome = static_cast<CSimpleFloatValueGenome*>(pInOutGenome);
	CRBFMutationInfo* pMutationInfo = static_cast<CRBFMutationInfo*>(pParam);

	float minValue_FunctionParam = pMutationInfo->minValue_FunctionParam;
	float maxValue_FunctionParam = pMutationInfo->maxValue_FunctionParam;
	float mutationRate_FunctionParam = pMutationInfo->mutationRate_FunctionParam;

	float minValue_Centroid = pMutationInfo->minValue_Centroid;
	float maxValue_Centroid = pMutationInfo->maxValue_Centroid;
	float mutationRate_Centroid = pMutationInfo->mutationRate_Centroid;

	float minValue_ExpFactor = pMutationInfo->minValue_ExpFactor;
	float maxValue_ExpFactor = pMutationInfo->maxValue_ExpFactor;
	float mutationRate_ExpFactor = pMutationInfo->mutationRate_ExpFactor;

	
	int32_t numOfGenes = pGenome->NumOfGenes;
	int32_t numOfGenomeParts = numOfGenes / 3;

	for (int32_t i = 0; i < numOfGenomeParts; i++)
	{
		if (pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f) > mutationRate_ExpFactor)
			continue;

		pGenome->pGeneArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minValue_ExpFactor, maxValue_ExpFactor);	
	}

	int32_t maxIDPlus1 = 2 * numOfGenomeParts;
	
	for (int32_t i = numOfGenomeParts; i < maxIDPlus1; i++)
	{
		if (pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f) > mutationRate_FunctionParam)
			continue;

		pGenome->pGeneArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minValue_FunctionParam, maxValue_FunctionParam);
	}

	maxIDPlus1 = 3 * numOfGenomeParts;

	for (int32_t i = 2 * numOfGenomeParts; i < maxIDPlus1; i++)
	{
		if (pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f) > mutationRate_Centroid)
			continue;

		pGenome->pGeneArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minValue_Centroid, maxValue_Centroid);
	}
}

static void Mutation_1DimAsymmetricRBFValues(void* pInOutGenome, CRandomNumbersNN* pRandomNumbers, void* pParam)
{
	CSimpleFloatValueGenome* pGenome = static_cast<CSimpleFloatValueGenome*>(pInOutGenome);
	CRBFMutationInfo* pMutationInfo = static_cast<CRBFMutationInfo*>(pParam);

	float minValue_FunctionParam = pMutationInfo->minValue_FunctionParam;
	float maxValue_FunctionParam = pMutationInfo->maxValue_FunctionParam;
	float mutationRate_FunctionParam = pMutationInfo->mutationRate_FunctionParam;

	float minValue_Centroid = pMutationInfo->minValue_Centroid;
	float maxValue_Centroid = pMutationInfo->maxValue_Centroid;
	float mutationRate_Centroid = pMutationInfo->mutationRate_Centroid;

	float minValue_ExpFactor = pMutationInfo->minValue_ExpFactor;
	float maxValue_ExpFactor = pMutationInfo->maxValue_ExpFactor;
	float mutationRate_ExpFactor = pMutationInfo->mutationRate_ExpFactor;


	int32_t numOfGenes = pGenome->NumOfGenes;
	int32_t numOfGenomeParts = numOfGenes / 4;

	int32_t maxIDPlus1 = 2 * numOfGenomeParts;

	for (int32_t i = 0; i < maxIDPlus1; i++)
	{
		if (pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f) > mutationRate_ExpFactor)
			continue;

		pGenome->pGeneArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minValue_ExpFactor, maxValue_ExpFactor);
	}

	maxIDPlus1 = 3 * numOfGenomeParts;

	for (int32_t i = 2 * numOfGenomeParts; i < maxIDPlus1; i++)
	{
		if (pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f) > mutationRate_FunctionParam)
			continue;

		pGenome->pGeneArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minValue_FunctionParam, maxValue_FunctionParam);
	}

	maxIDPlus1 = 4 * numOfGenomeParts;

	for (int32_t i = 3 * numOfGenomeParts; i < maxIDPlus1; i++)
	{
		if (pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f) > mutationRate_Centroid)
			continue;

		pGenome->pGeneArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minValue_Centroid, maxValue_Centroid);
	}
}

static void Mutation_1DimRBFValues_2OutputValues(void* pInOutGenome, CRandomNumbersNN* pRandomNumbers, void* pParam)
{
	CSimpleFloatValueGenome* pGenome = static_cast<CSimpleFloatValueGenome*>(pInOutGenome);
	CRBFMutationInfo* pMutationInfo = static_cast<CRBFMutationInfo*>(pParam);

	float minValue_FunctionParam = pMutationInfo->minValue_FunctionParam;
	float maxValue_FunctionParam = pMutationInfo->maxValue_FunctionParam;
	float mutationRate_FunctionParam = pMutationInfo->mutationRate_FunctionParam;

	float minValue_Centroid = pMutationInfo->minValue_Centroid;
	float maxValue_Centroid = pMutationInfo->maxValue_Centroid;
	float mutationRate_Centroid = pMutationInfo->mutationRate_Centroid;

	float minValue_ExpFactor = pMutationInfo->minValue_ExpFactor;
	float maxValue_ExpFactor = pMutationInfo->maxValue_ExpFactor;
	float mutationRate_ExpFactor = pMutationInfo->mutationRate_ExpFactor;


	int32_t numOfGenes = pGenome->NumOfGenes;
	int32_t numOfGenomeParts = numOfGenes / 4;

	for (int32_t i = 0; i < numOfGenomeParts; i++)
	{
		if (pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f) > mutationRate_ExpFactor)
			continue;

		pGenome->pGeneArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minValue_ExpFactor, maxValue_ExpFactor);
	}

	int32_t maxIDPlus1 = 3 * numOfGenomeParts;

	for (int32_t i = numOfGenomeParts; i < maxIDPlus1; i++)
	{
		if (pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f) > mutationRate_FunctionParam)
			continue;

		pGenome->pGeneArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minValue_FunctionParam, maxValue_FunctionParam);
	}

	maxIDPlus1 = 4 * numOfGenomeParts;

	for (int32_t i = 3 * numOfGenomeParts; i < maxIDPlus1; i++)
	{
		if (pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f) > mutationRate_Centroid)
			continue;

		pGenome->pGeneArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minValue_Centroid, maxValue_Centroid);
	}
}

static void Mutation_2DimRBFValues(void* pInOutGenome, CRandomNumbersNN* pRandomNumbers, void* pParam)
{
	CSimpleFloatValueGenome* pGenome = static_cast<CSimpleFloatValueGenome*>(pInOutGenome);
	CRBFMutationInfo* pMutationInfo = static_cast<CRBFMutationInfo*>(pParam);

	float minValue_FunctionParam = pMutationInfo->minValue_FunctionParam;
	float maxValue_FunctionParam = pMutationInfo->maxValue_FunctionParam;
	float mutationRate_FunctionParam = pMutationInfo->mutationRate_FunctionParam;

	float minValue_Centroid = pMutationInfo->minValue_Centroid;
	float maxValue_Centroid = pMutationInfo->maxValue_Centroid;
	float mutationRate_Centroid = pMutationInfo->mutationRate_Centroid;

	float minValue_ExpFactor = pMutationInfo->minValue_ExpFactor;
	float maxValue_ExpFactor = pMutationInfo->maxValue_ExpFactor;
	float mutationRate_ExpFactor = pMutationInfo->mutationRate_ExpFactor;


	int32_t numOfGenes = pGenome->NumOfGenes;
	int32_t numOfGenomeParts = numOfGenes / 4;

	for (int32_t i = 0; i < numOfGenomeParts; i++)
	{
		if (pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f) > mutationRate_ExpFactor)
			continue;

		pGenome->pGeneArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minValue_ExpFactor, maxValue_ExpFactor);		
	}

	int32_t maxIDPlus1 = 2 * numOfGenomeParts;

	for (int32_t i = numOfGenomeParts; i < maxIDPlus1; i++)
	{
		if (pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f) > mutationRate_FunctionParam)
			continue;

		pGenome->pGeneArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minValue_FunctionParam, maxValue_FunctionParam);
	}

	maxIDPlus1 = 4 * numOfGenomeParts;

	for (int32_t i = 2 * numOfGenomeParts; i < maxIDPlus1; i++)
	{
		if (pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f) > mutationRate_Centroid)
			continue;

		pGenome->pGeneArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minValue_Centroid, maxValue_Centroid);
	}
}

static void Mutation_2DimRBFValues_3OutputValues(void* pInOutGenome, CRandomNumbersNN* pRandomNumbers, void* pParam)
{
	CSimpleFloatValueGenome* pGenome = static_cast<CSimpleFloatValueGenome*>(pInOutGenome);
	CRBFMutationInfo* pMutationInfo = static_cast<CRBFMutationInfo*>(pParam);

	float minValue_FunctionParam = pMutationInfo->minValue_FunctionParam;
	float maxValue_FunctionParam = pMutationInfo->maxValue_FunctionParam;
	float mutationRate_FunctionParam = pMutationInfo->mutationRate_FunctionParam;

	float minValue_Centroid = pMutationInfo->minValue_Centroid;
	float maxValue_Centroid = pMutationInfo->maxValue_Centroid;
	float mutationRate_Centroid = pMutationInfo->mutationRate_Centroid;

	float minValue_ExpFactor = pMutationInfo->minValue_ExpFactor;
	float maxValue_ExpFactor = pMutationInfo->maxValue_ExpFactor;
	float mutationRate_ExpFactor = pMutationInfo->mutationRate_ExpFactor;


	int32_t numOfGenes = pGenome->NumOfGenes;
	int32_t numOfGenomeParts = numOfGenes / 6;

	for (int32_t i = 0; i < numOfGenomeParts; i++)
	{
		if (pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f) > mutationRate_ExpFactor)
			continue;

		pGenome->pGeneArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minValue_ExpFactor, maxValue_ExpFactor);
	}

	int32_t maxIDPlus1 = 4 * numOfGenomeParts;

	for (int32_t i = numOfGenomeParts; i < maxIDPlus1; i++)
	{
		if (pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f) > mutationRate_FunctionParam)
			continue;

		pGenome->pGeneArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minValue_FunctionParam, maxValue_FunctionParam);
	}

	maxIDPlus1 = 6 * numOfGenomeParts;

	for (int32_t i = 4 * numOfGenomeParts; i < maxIDPlus1; i++)
	{
		if (pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f) > mutationRate_Centroid)
			continue;

		pGenome->pGeneArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minValue_Centroid, maxValue_Centroid);
	}
}

static void Mutation_3DimRBFValues(void* pInOutGenome, CRandomNumbersNN* pRandomNumbers, void* pParam)
{
	CSimpleFloatValueGenome* pGenome = static_cast<CSimpleFloatValueGenome*>(pInOutGenome);
	CRBFMutationInfo* pMutationInfo = static_cast<CRBFMutationInfo*>(pParam);

	float minValue_FunctionParam = pMutationInfo->minValue_FunctionParam;
	float maxValue_FunctionParam = pMutationInfo->maxValue_FunctionParam;
	float mutationRate_FunctionParam = pMutationInfo->mutationRate_FunctionParam;

	float minValue_Centroid = pMutationInfo->minValue_Centroid;
	float maxValue_Centroid = pMutationInfo->maxValue_Centroid;
	float mutationRate_Centroid = pMutationInfo->mutationRate_Centroid;

	float minValue_ExpFactor = pMutationInfo->minValue_ExpFactor;
	float maxValue_ExpFactor = pMutationInfo->maxValue_ExpFactor;
	float mutationRate_ExpFactor = pMutationInfo->mutationRate_ExpFactor;


	int32_t numOfGenes = pGenome->NumOfGenes;
	int32_t numOfGenomeParts = numOfGenes / 5;

	for (int32_t i = 0; i < numOfGenomeParts; i++)
	{
		if (pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f) > mutationRate_ExpFactor)
			continue;

		pGenome->pGeneArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minValue_ExpFactor, maxValue_ExpFactor);
	}

	int32_t maxIDPlus1 = 2 * numOfGenomeParts;

	for (int32_t i = numOfGenomeParts; i < maxIDPlus1; i++)
	{
		if (pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f) > mutationRate_FunctionParam)
			continue;

		pGenome->pGeneArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minValue_FunctionParam, maxValue_FunctionParam);
	}

	maxIDPlus1 = 5 * numOfGenomeParts;

	for (int32_t i = 2 * numOfGenomeParts; i < maxIDPlus1; i++)
	{
		if (pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f) > mutationRate_Centroid)
			continue;

		pGenome->pGeneArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minValue_Centroid, maxValue_Centroid);
	}
}



static void Mutation_Example3(void *pInOutGenome, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	CFloatValueGenome *pGenome = static_cast<CFloatValueGenome*>(pInOutGenome);
	CSimpleMutationInfo *pMutationInfo = static_cast<CSimpleMutationInfo*>(pParam);

	float minValue = pMutationInfo->minValue;
	float maxValue = pMutationInfo->maxValue;
	float mutationRate = pMutationInfo->mutationRate;

	int32_t numOfGenes = pGenome->NumOfGenes;

	for (int32_t i = 0; i < numOfGenes; i++)
	{
		//if (pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f) > mutationRate)
		//continue;

		pGenome->pGeneArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minValue, maxValue);
	}
}

static void Mutation_Example4(void *pInOutGenome, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	CGenome *pGenome = static_cast<CGenome*>(pInOutGenome);
	CSimpleMutationInfo *pMutationInfo = static_cast<CSimpleMutationInfo*>(pParam);

	float minValue = pMutationInfo->minValue;
	float maxValue = pMutationInfo->maxValue;
	float mutationRate = pMutationInfo->mutationRate;

	CGene *pGeneArray = pGenome->pGeneArray;

	int32_t numOfGenes = pGenome->NumOfGenes;
	int32_t numOfFloatValuesPerGene = pGeneArray[0].NumOfFloatValues;

	

	for (int32_t i = 0; i < numOfGenes; i++)
	{
		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
			continue;

		for (int32_t j = 0; j < numOfFloatValuesPerGene; j++)
		{
			pGeneArray[i].pFValueArray[j] += pRandomNumbers->Get_FloatNumber_IncludingZero(minValue, maxValue);
		}
	}
}


static void Permutation_Example1(void *pInOutGenome, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	CSimpleFloatValueGenome *pGenome = static_cast<CSimpleFloatValueGenome*>(pInOutGenome);

	int32_t numOfGenes = pGenome->NumOfGenes;

	int32_t id1 = pRandomNumbers->Get_IntegerNumber(0, numOfGenes);
	int32_t id2 = pRandomNumbers->Get_IntegerNumber(0, numOfGenes);

	float tempValue = pGenome->pGeneArray[id1];

	pGenome->pGeneArray[id1] = pGenome->pGeneArray[id2];
	pGenome->pGeneArray[id2] = tempValue;
}

static void Recombination_Example1(void *pOffspring, void *pParent1, void *pParent2, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	CSimpleFloatValueGenome *pOffspringGenome = static_cast<CSimpleFloatValueGenome*>(pOffspring);
	CSimpleFloatValueGenome *pParent1Genome = static_cast<CSimpleFloatValueGenome*>(pParent1);
	CSimpleFloatValueGenome *pParent2Genome = static_cast<CSimpleFloatValueGenome*>(pParent2);

	int32_t numOfGenes = pOffspringGenome->NumOfGenes;

	for (int32_t i = 0; i < numOfGenes; i++)
	{
		if (pRandomNumbers->Get_IntegerNumber2(1, 2) == 1)
			pOffspringGenome->pGeneArray[i] = pParent1Genome->pGeneArray[i];
		else
			pOffspringGenome->pGeneArray[i] = pParent2Genome->pGeneArray[i];
	}
}

static void Recombination_Example2(void *pOffspring, void *pParent1, void *pParent2, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	CSimpleFloatValueGenome *pOffspringGenome = static_cast<CSimpleFloatValueGenome*>(pOffspring);
	CSimpleFloatValueGenome *pParent1Genome = static_cast<CSimpleFloatValueGenome*>(pParent1);
	CSimpleFloatValueGenome *pParent2Genome = static_cast<CSimpleFloatValueGenome*>(pParent2);

	int32_t numOfGenes = pOffspringGenome->NumOfGenes;

	for (int32_t i = 0; i < numOfGenes; i++)
	{
		float weight = pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f);
		float oneMinusWeight = 1.0f - weight;

		pOffspringGenome->pGeneArray[i] = weight * pParent1Genome->pGeneArray[i];
		pOffspringGenome->pGeneArray[i] += oneMinusWeight * pParent2Genome->pGeneArray[i];
	}
}


static void Recombination_Example3(void *pOffspring, void *pParent1, void *pParent2, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	CFloatValueGenome *pOffspringGenome = static_cast<CFloatValueGenome*>(pOffspring);
	CFloatValueGenome *pParent1Genome = static_cast<CFloatValueGenome*>(pParent1);
	CFloatValueGenome *pParent2Genome = static_cast<CFloatValueGenome*>(pParent2);

	int32_t numOfGenes = pOffspringGenome->NumOfGenes;

	bool sameSpecies = true;

	for (int32_t i = 0; i < numOfGenes; i++)
	{ 
		if (pParent1Genome->pGeneUsageArray[i] != pParent2Genome->pGeneUsageArray[i])
		{
			sameSpecies = false;
			break;
		}
	}

	if (sameSpecies == false)
	{
		/* Der Nachfahre ist ein Klon von Elternteil 1: */
		if (pRandomNumbers->Get_IntegerNumber2(1, 2) == 1)
		{
			for (int32_t i = 0; i < numOfGenes; i++)
			{
				pOffspringGenome->pGeneArray[i] = pParent1Genome->pGeneArray[i];

				/* An dieser Stelle k�nnte man noch einige zuf�llige Mutationen ins Genom einbauen. */
				pOffspringGenome->pGeneArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(-0.1f, 0.1f);
			}
		}
		/* Der Nachfahre ist ein Klon von Elternteil 2: */
		else
		{
			for (int32_t i = 0; i < numOfGenes; i++)
			{
				pOffspringGenome->pGeneArray[i] = pParent2Genome->pGeneArray[i];

				/* An dieser Stelle k�nnte man noch einige zuf�llige Mutationen ins Genom einbauen. */
				pOffspringGenome->pGeneArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(-0.1f, 0.1f);
			}
		}

		return;
	}

	/* Beide Elternteile geh�ren derselben Spezies an: */

	for (int32_t i = 0; i < numOfGenes; i++)
	{
		if (pRandomNumbers->Get_IntegerNumber2(1, 2) == 1)
			pOffspringGenome->pGeneArray[i] = pParent1Genome->pGeneArray[i];
		else
			pOffspringGenome->pGeneArray[i] = pParent2Genome->pGeneArray[i];
	}
}

static void Recombination_Example4(void *pOffspring, void *pParent1, void *pParent2, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	CFloatValueGenome *pOffspringGenome = static_cast<CFloatValueGenome*>(pOffspring);
	CFloatValueGenome *pParent1Genome = static_cast<CFloatValueGenome*>(pParent1);
	CFloatValueGenome *pParent2Genome = static_cast<CFloatValueGenome*>(pParent2);

	bool *pParent1GeneUsageArray = pParent1Genome->pGeneUsageArray;
	bool *pParent2GeneUsageArray = pParent2Genome->pGeneUsageArray;

	int32_t numOfGenes = pOffspringGenome->NumOfGenes;

	bool sameSpecies = true;

	for (int32_t i = 0; i < numOfGenes; i++)
	{
		if (pParent1GeneUsageArray[i] != pParent2GeneUsageArray[i])
		{
			sameSpecies = false;
			break;
		}
	}

	if (sameSpecies == false)
	{
		/* Der Nachfahre ist ein Klon von Elternteil 1: */
		if (pRandomNumbers->Get_IntegerNumber2(1, 2) == 1)
		{
			for (int32_t i = 0; i < numOfGenes; i++)
			{
				pOffspringGenome->pGeneArray[i] = pParent1Genome->pGeneArray[i];

				/* An dieser Stelle k�nnte man noch einige zuf�llige Mutationen ins Genom einbauen. */
				pOffspringGenome->pGeneArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(-0.1f, 0.1f);
			}
		}
		/* Der Nachfahre ist ein Klon von Elternteil 2: */
		else
		{
			for (int32_t i = 0; i < numOfGenes; i++)
			{
				pOffspringGenome->pGeneArray[i] = pParent2Genome->pGeneArray[i];

				/* An dieser Stelle k�nnte man noch einige zuf�llige Mutationen ins Genom einbauen. */
				pOffspringGenome->pGeneArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(-0.1f, 0.1f);
			}
		}

		return;
	}

	/* Beide Elternteile geh�ren derselben Spezies an: */

	for (int32_t i = 0; i < numOfGenes; i++)
	{
		float weight = pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f);
		float oneMinusWeight = 1.0f - weight;

		pOffspringGenome->pGeneArray[i] = weight * pParent1Genome->pGeneArray[i];
		pOffspringGenome->pGeneArray[i] += oneMinusWeight * pParent2Genome->pGeneArray[i];
	}
}


static void Recombination_Example5(void *pOffspring, void *pParent1, void *pParent2, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	CGenome *pOffspringGenome = static_cast<CGenome*>(pOffspring);
	CGenome *pParent1Genome = static_cast<CGenome*>(pParent1);
	CGenome *pParent2Genome = static_cast<CGenome*>(pParent2);

	CGene *pOffspringGeneArray = pOffspringGenome->pGeneArray;
	CGene *pParent1GeneArray = pParent1Genome->pGeneArray;
	CGene *pParent2GeneArray = pParent2Genome->pGeneArray;

	int32_t numOfGenes = pOffspringGenome->NumOfGenes;
	int32_t numOfFloatValuesPerGene = pOffspringGeneArray[0].NumOfFloatValues;

	for (int32_t i = 0; i < numOfGenes; i++)
	{
		for (int32_t j = 0; j < numOfFloatValuesPerGene; j++)
		{
			float weight = pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f);
			float oneMinusWeight = 1.0f - weight;

			pOffspringGeneArray[i].pFValueArray[j] = weight * pParent1GeneArray[i].pFValueArray[j];
			pOffspringGeneArray[i].pFValueArray[j] += oneMinusWeight * pParent2GeneArray[i].pFValueArray[j];
		}
	}
}

static void Recombination_Example6(void *pOffspring, void *pParent1, void *pParent2, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	CGenome *pOffspringGenome = static_cast<CGenome*>(pOffspring);
	CGenome *pParent1Genome = static_cast<CGenome*>(pParent1);
	CGenome *pParent2Genome = static_cast<CGenome*>(pParent2);

	CSimpleMutationInfo *pMutationInfo = static_cast<CSimpleMutationInfo*>(pParam);
	float minValue = pMutationInfo->minValue;
	float maxValue = pMutationInfo->maxValue;
	float mutationRate = pMutationInfo->mutationRate;

	CGene *pOffspringGeneArray = pOffspringGenome->pGeneArray;
	CGene *pParent1GeneArray = pParent1Genome->pGeneArray;
	CGene *pParent2GeneArray = pParent2Genome->pGeneArray;

	bool *pParent1GeneUsageArray = pParent1Genome->pGeneUsageArray;
	bool *pParent2GeneUsageArray = pParent2Genome->pGeneUsageArray;

	int32_t numOfGenes = pOffspringGenome->NumOfGenes;
	int32_t numOfFloatValuesPerGene = pOffspringGeneArray[0].NumOfFloatValues;

	bool sameSpecies = true;

	for (int32_t i = 0; i < numOfGenes; i++)
	{
		if (pParent1GeneUsageArray[i] != pParent2GeneUsageArray[i])
		{
			sameSpecies = false;
			break;
		}
	}

	if (sameSpecies == false)
	{
		/* Der Nachfahre ist ein Klon von Elternteil 1: */
		if (pRandomNumbers->Get_IntegerNumber2(1, 2) == 1)
		{
			for (int32_t i = 0; i < numOfGenes; i++)
			{
				pOffspringGeneArray[i].Clone_Values(&pParent1GeneArray[i]);

				/* An dieser Stelle k�nnte man noch einige zuf�llige Mutationen ins Genom einbauen. */

				if (pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f) > mutationRate)
					continue;

				for (int32_t j = 0; j < numOfFloatValuesPerGene; j++)
				{
					pOffspringGeneArray[i].pFValueArray[j] += pRandomNumbers->Get_FloatNumber_IncludingZero(minValue, maxValue);
				}
			}
		}
		/* Der Nachfahre ist ein Klon von Elternteil 2: */
		else
		{
			for (int32_t i = 0; i < numOfGenes; i++)
			{
				pOffspringGeneArray[i].Clone_Values(&pParent2GeneArray[i]);

				/* An dieser Stelle k�nnte man noch einige zuf�llige Mutationen ins Genom einbauen. */

				if (pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f) > mutationRate)
					continue;

				for (int32_t j = 0; j < numOfFloatValuesPerGene; j++)
				{
					pOffspringGeneArray[i].pFValueArray[j] += pRandomNumbers->Get_FloatNumber_IncludingZero(minValue, maxValue);
				}
			}
		}

		return;
	}

	
	/* Beide Elternteile geh�ren derselben Spezies an: */

	for (int32_t i = 0; i < numOfGenes; i++)
	{
		for (int32_t j = 0; j < numOfFloatValuesPerGene; j++)
		{
			float weight = pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f);
			float oneMinusWeight = 1.0f - weight;

			pOffspringGeneArray[i].pFValueArray[j] = weight * pParent1GeneArray[i].pFValueArray[j];
			pOffspringGeneArray[i].pFValueArray[j] += oneMinusWeight * pParent2GeneArray[i].pFValueArray[j];
		}
	}
}

static void SpeciesTransformation_Example1(void *pInOutGenome, CRandomNumbersNN *pRandomNumbers, void *pParam)
{
	CGenome *pGenome = static_cast<CGenome*>(pInOutGenome);
	
	CGene *pGeneArray = pGenome->pGeneArray;
	bool *pGeneUsageArray = pGenome->pGeneUsageArray;

	int32_t numOfGenes = pGenome->NumOfGenes;
	

	for (int32_t i = 0; i < numOfGenes; i++)
	{
		if (abs(pGeneArray[i].pFValueArray[0]) < 0.01f)
		{
			pGeneUsageArray[i] = false;
		}
	}
}

#endif