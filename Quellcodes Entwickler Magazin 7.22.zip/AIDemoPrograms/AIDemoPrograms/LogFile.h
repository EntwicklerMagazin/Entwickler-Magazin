#ifndef _LogFile_H_
#define _LogFile_H_

#include <iostream>

#pragma warning( disable: 4996)



namespace HelperStuff
{


void Begin_Log(uint32_t logFileID, const char *pMessage,
	const char *pLogFileName);

void Add_To_Log(uint32_t logFileID, const char *pMessage);

void Add_To_Log(uint32_t logFileID, const char *pMessage,
	const char *pProblem);

void Add_To_Log(uint32_t logFileID, const char *pMessage,
	float value);

void Add_To_Log(uint32_t logFileID, const char *pMessage,
	long value);

void Add_To_Log(uint32_t logFileID, const char *pMessage,
	unsigned long value);

void Add_To_Log(uint32_t logFileID, const char *pMessage,
	int32_t value);

void Add_To_Log(uint32_t logFileID, const char *pMessage,
	uint32_t value);

void Add_To_Log(uint32_t logFileID, const char *pMessage,
	int64_t value);

void Add_To_Log(uint32_t logFileID, const char *pMessage,
	uint64_t value);


} /* end of namespace HelperStuff */


#endif
