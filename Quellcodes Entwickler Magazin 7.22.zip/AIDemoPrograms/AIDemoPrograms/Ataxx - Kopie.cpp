#include "Ataxx.h"

using namespace std;
using namespace HelperStuff;

#ifndef max
#define max(a,b)    ( ((a) > (b)) ? (a) : (b) )
#endif

#ifndef min
#define min(a,b)    ( ((a) < (b)) ? (a) : (b) )
#endif


int32_t g_MaxSearchDepth = 1;
int32_t g_MaxSearchDepth_P1 = 1;
int32_t g_MaxSearchDepth_P2 = 1;

CInitialAtaxxBoards::CInitialAtaxxBoards()
{

}

CInitialAtaxxBoards::~CInitialAtaxxBoards()
{
	delete[] pInitialGameStateArray;
	pInitialGameStateArray = nullptr;
}

bool CInitialAtaxxBoards::Initialize(const char* pFilename)
{
	delete[] pInitialGameStateArray;
	pInitialGameStateArray = nullptr;

	std::ifstream ReadFile;

	// eine existierende Datei zum Lesen �ffnen:
	ReadFile.open(pFilename);

	if (ReadFile.good() == false)
		return false;

	char strBuffer[200];
	int32_t tempInt;

	ReadFile >> strBuffer;
	ReadFile >> NumOfInitialAtaxxBoards;

	pInitialGameStateArray = new (std::nothrow) CGameStateValues[NumOfInitialAtaxxBoards];

	for (int32_t i = 0; i < NumOfInitialAtaxxBoards; i++)
	{
		pInitialGameStateArray[i].Initialize(ConstGameBoardSizePerDir, ConstGameBoardSizePerDir);

		int8_t* pInitialBoardData = &pInitialGameStateArray[i].pValueArray[0];

		for (int32_t j = 0; j < ConstGameBoardSize; j++)
		{
			ReadFile >> tempInt;
			pInitialBoardData[j] = static_cast<int8_t>(tempInt);
		}
	}

	ReadFile.close();
	return true;
}

void Init_GameBoard_WithoutObstacles(int8_t* pInOutGameData)
{
	for (int32_t i = 0; i < ConstGameBoardSize; i++)
		pInOutGameData[i] = 0;

	int32_t ix1_Player1 = 0;
	int32_t iy1_Player1 = 0;

	int32_t id = ix1_Player1 + ConstGameBoardSizePerDir * iy1_Player1;
	pInOutGameData[id] = ConstGameBoard_Player1;

	int32_t ix2_Player1 = ConstGameBoardSizePerDir - 1;
	int32_t iy2_Player1 = ConstGameBoardSizePerDir - 1;

	id = ix2_Player1 + ConstGameBoardSizePerDir * iy2_Player1;
	pInOutGameData[id] = ConstGameBoard_Player1;

	int32_t ix1_Player2 = ConstGameBoardSizePerDir - 1;
	int32_t iy1_Player2 = 0;

	id = ix1_Player2 + ConstGameBoardSizePerDir * iy1_Player2;
	pInOutGameData[id] = ConstGameBoard_Player2;

	int32_t ix2_Player2 = 0;
	int32_t iy2_Player2 = ConstGameBoardSizePerDir - 1;

	id = ix2_Player2 + ConstGameBoardSizePerDir * iy2_Player2;
	pInOutGameData[id] = ConstGameBoard_Player2;
}

void Init_GameBoard(int8_t* pInOutGameData, CInitialAtaxxBoards* pInitialAtaxxBoards, int32_t boardID)
{
	int8_t* pInitialBoardData = &pInitialAtaxxBoards->pInitialGameStateArray[boardID].pValueArray[0];

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		pInOutGameData[i] = pInitialBoardData[i];
	}
}

void Clone_GameBoard(int8_t* pOutGameData, int8_t* pInGameData)
{
	for (int32_t i = 0; i < ConstGameBoardSize; i++)
		pOutGameData[i] = pInGameData[i];
}

void Calculate_Score(int32_t* pOutPlayer1Score, int32_t* pOutPlayer2Score, int8_t* pInGameData)
{
	int32_t player1Score = 0;
	int32_t player2Score = 0;

	int8_t value;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		value = pInGameData[i];

		if (value == ConstGameBoard_Player1)
		{
			player1Score++;
		}
		else if (value == ConstGameBoard_Player2)
		{
			player2Score++;
		}
	}

	*pOutPlayer1Score = player1Score;
	*pOutPlayer2Score = player2Score;
}

void Calculate_Player1Score(int32_t* pOutPlayer1Score, int8_t* pInGameData)
{
	int32_t player1Score = 0;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pInGameData[i] == ConstGameBoard_Player1)
		{
			player1Score++;
		}
	}

	*pOutPlayer1Score = player1Score;
}

void Calculate_Player2Score(int32_t* pOutPlayer2Score, int8_t* pInGameData)
{

	int32_t player2Score = 0;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pInGameData[i] == ConstGameBoard_Player2)
		{
			player2Score++;
		}
	}


	*pOutPlayer2Score = player2Score;
}

bool Check_PossiblePlayer1Move(int32_t oldX, int32_t oldY, int32_t newX, int32_t newY, int8_t* pInGameData)
{
	if (abs(newX - oldX) > 2 || abs(newY - oldY) > 2)
	{
		return false;
	}

	if (pInGameData[oldX + ConstGameBoardSizePerDir * oldY] != ConstGameBoard_Player1)
	{
		return false;
	}

	if (pInGameData[newX + ConstGameBoardSizePerDir * newY] != ConstGameBoard_Empty)
	{
		return false;
	}

	return true;
}

bool Check_PossiblePlayer2Move(int32_t oldX, int32_t oldY, int32_t newX, int32_t newY, int8_t* pInGameData)
{
	if (abs(newX - oldX) > 2 || abs(newY - oldY) > 2)
	{
		return false;
	}

	if (pInGameData[oldX + ConstGameBoardSizePerDir * oldY] != ConstGameBoard_Player2)
	{
		return false;
	}

	if (pInGameData[newX + ConstGameBoardSizePerDir * newY] != ConstGameBoard_Empty)
	{
		return false;
	}

	return true;
}

bool Check_PossiblePlayer1Moves(int8_t* pInGameData)
{
	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pInGameData[i] == ConstGameBoard_Player1)
		{
			int32_t ixOld = i % ConstGameBoardSizePerDir;
			int32_t iyOld = i / ConstGameBoardSizePerDir;

			int32_t ixMin = max(0, ixOld - 2);
			int32_t iyMin = max(0, iyOld - 2);

			int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
			int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

			for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
			{
				for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
				{
					if (pInGameData[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
					{
						return true;
					}
				}
			}
		}
	}

	return false;
}

bool Check_PossiblePlayer2Moves(int8_t* pInGameData)
{
	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pInGameData[i] == ConstGameBoard_Player2)
		{
			int32_t ixOld = i % ConstGameBoardSizePerDir;
			int32_t iyOld = i / ConstGameBoardSizePerDir;

			int32_t ixMin = max(0, ixOld - 2);
			int32_t iyMin = max(0, iyOld - 2);

			int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
			int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

			for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
			{
				for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
				{
					if (pInGameData[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
					{
						return true;
					}
				}
			}
		}
	}

	return false;
}

bool Check_For_PossibleMove(int8_t* pInGameData)
{
	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pInGameData[i] == ConstGameBoard_Empty)
		{
			return true;
		}
	}

	return false;
}

bool Check_PossiblePlayer1CloneMove(int32_t destinationX, int32_t destinationY, int8_t* pInGameData)
{
	int32_t id = destinationX + ConstGameBoardSizePerDir * destinationY;

	if (pInGameData[id] != ConstGameBoard_Empty)
	{
		return false;
	}


	int32_t ixMin = max(0, destinationX - 1);
	int32_t iyMin = max(0, destinationY - 1);

	int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, destinationX + 2);
	int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, destinationY + 2);

	for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
	{
		int32_t iiy = ConstGameBoardSizePerDir * iy;

		for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
		{
			if (pInGameData[ix + iiy] == ConstGameBoard_Player1)
			{
				return true;
			}
		}
	}

	return false;
}

bool Check_PossiblePlayer2CloneMove(int32_t destinationX, int32_t destinationY, int8_t* pInGameData)
{
	int32_t id = destinationX + ConstGameBoardSizePerDir * destinationY;

	if (pInGameData[id] != ConstGameBoard_Empty)
	{
		return false;
	}

	int32_t ixMin = max(0, destinationX - 1);
	int32_t iyMin = max(0, destinationY - 1);

	int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, destinationX + 2);
	int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, destinationY + 2);

	for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
	{
		int32_t iiy = ConstGameBoardSizePerDir * iy;

		for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
		{
			if (pInGameData[ix + iiy] == ConstGameBoard_Player2)
			{
				return true;
			}
		}
	}

	return false;

}

bool Check_PossiblePlayer1CloneMove(int32_t newPosID, int8_t* pInGameData)
{
	if (pInGameData[newPosID] != ConstGameBoard_Empty)
	{
		return false;
	}

	int32_t posX = newPosID % ConstGameBoardSizePerDir;
	int32_t posY = newPosID / ConstGameBoardSizePerDir;


	int32_t ixMin = max(0, posX - 1);
	int32_t iyMin = max(0, posY - 1);

	int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, posX + 2);
	int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, posY + 2);

	for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
	{
		int32_t iiy = ConstGameBoardSizePerDir * iy;

		for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
		{
			if (pInGameData[ix + iiy] == ConstGameBoard_Player1)
			{
				return true;
			}
		}
	}

	return false;
}

bool Check_PossiblePlayer2CloneMove(int32_t newPosID, int8_t* pInGameData)
{
	if (pInGameData[newPosID] != ConstGameBoard_Empty)
	{
		return false;
	}

	int32_t posX = newPosID % ConstGameBoardSizePerDir;
	int32_t posY = newPosID / ConstGameBoardSizePerDir;


	int32_t ixMin = max(0, posX - 1);
	int32_t iyMin = max(0, posY - 1);

	int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, posX + 2);
	int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, posY + 2);

	for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
	{
		int32_t iiy = ConstGameBoardSizePerDir * iy;

		for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
		{
			if (pInGameData[ix + iiy] == ConstGameBoard_Player2)
			{
				return true;
			}
		}
	}

	return false;
}

bool Get_PossiblePlayer1CloneMoveStartPos(int32_t* pOutStartX, int32_t* pOutStartY, int32_t newX, int32_t newY, int8_t* pInGameData)
{
	/*int32_t id = newX + ConstGameBoardSizePerDir * newY;

	if (pInGameData[id] != ConstGameBoard_Empty)
	{
	return false;
	}*/


	int32_t ixMin = max(0, newX - 1);
	int32_t iyMin = max(0, newY - 1);

	int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, newX + 2);
	int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, newY + 2);

	for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
	{
		int32_t iiy = ConstGameBoardSizePerDir * iy;

		for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
		{
			if (pInGameData[ix + iiy] == ConstGameBoard_Player1)
			{
				*pOutStartX = ix;
				*pOutStartY = iy;
				return true;
			}
		}
	}

	return false;
}

bool Get_PossiblePlayer2CloneMoveStartPos(int32_t* pOutStartX, int32_t* pOutStartY, int32_t newX, int32_t newY, int8_t* pInGameData)
{
	/*int32_t id = newX + ConstGameBoardSizePerDir * newY;

	if (pInGameData[id] != ConstGameBoard_Empty)
	{
	return false;
	}*/

	int32_t ixMin = max(0, newX - 1);
	int32_t iyMin = max(0, newY - 1);

	int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, newX + 2);
	int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, newY + 2);

	for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
	{
		int32_t iiy = ConstGameBoardSizePerDir * iy;

		for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
		{
			if (pInGameData[ix + iiy] == ConstGameBoard_Player2)
			{
				*pOutStartX = ix;
				*pOutStartY = iy;
				return true;
			}
		}
	}

	return false;

}

bool Get_PossiblePlayer1CloneMoveStartPos(int32_t* pOutStartX, int32_t* pOutStartY, int32_t newPosID, int8_t* pInGameData)
{
	/*if (pInGameData[newPosID] != ConstGameBoard_Empty)
	{
	return false;
	}*/

	int32_t posX = newPosID % ConstGameBoardSizePerDir;
	int32_t posY = newPosID / ConstGameBoardSizePerDir;


	int32_t ixMin = max(0, posX - 1);
	int32_t iyMin = max(0, posY - 1);

	int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, posX + 2);
	int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, posY + 2);

	for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
	{
		int32_t iiy = ConstGameBoardSizePerDir * iy;

		for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
		{
			if (pInGameData[ix + iiy] == ConstGameBoard_Player1)
			{
				*pOutStartX = ix;
				*pOutStartY = iy;
				return true;
			}
		}
	}

	return false;
}

bool Get_PossiblePlayer2CloneMoveStartPos(int32_t* pOutOldX, int32_t* pOutOldY, int32_t newPosID, int8_t* pInGameData)
{
	/*if (pInGameData[newPosID] != ConstGameBoard_Empty)
	{
	return false;
	}*/

	int32_t posX = newPosID % ConstGameBoardSizePerDir;
	int32_t posY = newPosID / ConstGameBoardSizePerDir;


	int32_t ixMin = max(0, posX - 1);
	int32_t iyMin = max(0, posY - 1);

	int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, posX + 2);
	int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, posY + 2);

	for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
	{
		int32_t iiy = ConstGameBoardSizePerDir * iy;

		for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
		{
			if (pInGameData[ix + iiy] == ConstGameBoard_Player2)
			{
				*pOutOldX = ix;
				*pOutOldY = iy;
				return true;
			}
		}
	}

	return false;
}

void Make_Player1Move(int32_t oldX, int32_t oldY, int32_t newX, int32_t newY, int8_t* pInOutGameData)
{
	pInOutGameData[newX + ConstGameBoardSizePerDir * newY] = ConstGameBoard_Player1;

	int32_t minX = max(0, newX - 1);
	int32_t minY = max(0, newY - 1);

	//int32_t maxXPlus1 = 1 + min(ConstGameBoardSizePerDirMinus1, newX + 1);
	//int32_t maxYPlus1 = 1 + min(ConstGameBoardSizePerDirMinus1, newY + 1);
	int32_t maxXPlus1 = min(ConstGameBoardSizePerDir, newX + 2);
	int32_t maxYPlus1 = min(ConstGameBoardSizePerDir, newY + 2);

	int32_t id, iiy;

	for (int32_t iy = minY; iy < maxYPlus1; iy++)
	{
		iiy = ConstGameBoardSizePerDir * iy;

		for (int32_t ix = minX; ix < maxXPlus1; ix++)
		{
			id = ix + iiy;

			if (pInOutGameData[id] == ConstGameBoard_Player2)
			{
				pInOutGameData[id] = ConstGameBoard_Player1;
			}
		} /* end of for (int32_t ix = minY; ix < maxXPlus1; ix++) */
	} /* end of for (int32_t iy = minY; iy < maxYPlus1; iy++) */

	if (abs(newX - oldX) > 1 || abs(newY - oldY) > 1)
	{
		id = oldX + ConstGameBoardSizePerDir * oldY;
		pInOutGameData[id] = ConstGameBoard_Empty;
	}
}

void Make_Player2Move(int32_t oldX, int32_t oldY, int32_t newX, int32_t newY, int8_t* pInOutGameData)
{
	pInOutGameData[newX + ConstGameBoardSizePerDir * newY] = ConstGameBoard_Player2;

	int32_t minX = max(0, newX - 1);
	int32_t minY = max(0, newY - 1);

	//int32_t maxXPlus1 = 1 + min(ConstGameBoardSizePerDirMinus1, newX + 1);
	//int32_t maxYPlus1 = 1 + min(ConstGameBoardSizePerDirMinus1, newY + 1);
	int32_t maxXPlus1 = min(ConstGameBoardSizePerDir, newX + 2);
	int32_t maxYPlus1 = min(ConstGameBoardSizePerDir, newY + 2);

	int32_t id, iiy;

	for (int32_t iy = minY; iy < maxYPlus1; iy++)
	{
		iiy = ConstGameBoardSizePerDir * iy;

		for (int32_t ix = minX; ix < maxXPlus1; ix++)
		{
			id = ix + iiy;

			if (pInOutGameData[id] == ConstGameBoard_Player1)
			{
				pInOutGameData[id] = ConstGameBoard_Player2;
			}
		} /* end of for (int32_t ix = minY; ix < maxXPlus1; ix++) */
	} /* end of for (int32_t iy = minY; iy < maxYPlus1; iy++) */

	if (abs(newX - oldX) > 1 || abs(newY - oldY) > 1)
	{
		id = oldX + ConstGameBoardSizePerDir * oldY;
		pInOutGameData[id] = ConstGameBoard_Empty;
	}
}

void Make_Player1CloneMove(int32_t newX, int32_t newY, int8_t* pInOutGameData)
{
	pInOutGameData[newX + ConstGameBoardSizePerDir * newY] = ConstGameBoard_Player1;

	int32_t minX = max(0, newX - 1);
	int32_t minY = max(0, newY - 1);

	//int32_t maxXPlus1 = 1 + min(ConstGameBoardSizePerDirMinus1, newX + 1);
	//int32_t maxYPlus1 = 1 + min(ConstGameBoardSizePerDirMinus1, newY + 1);
	int32_t maxXPlus1 = min(ConstGameBoardSizePerDir, newX + 2);
	int32_t maxYPlus1 = min(ConstGameBoardSizePerDir, newY + 2);

	int32_t id, iiy;

	for (int32_t iy = minY; iy < maxYPlus1; iy++)
	{
		iiy = ConstGameBoardSizePerDir * iy;

		for (int32_t ix = minX; ix < maxXPlus1; ix++)
		{
			id = ix + iiy;

			if (pInOutGameData[id] == ConstGameBoard_Player2)
			{
				pInOutGameData[id] = ConstGameBoard_Player1;
			}
		} /* end of for (int32_t ix = minY; ix < maxXPlus1; ix++) */
	} /* end of for (int32_t iy = minY; iy < maxYPlus1; iy++) */
}

void Make_Player2CloneMove(int32_t newX, int32_t newY, int8_t* pInOutGameData)
{
	pInOutGameData[newX + ConstGameBoardSizePerDir * newY] = ConstGameBoard_Player2;

	int32_t minX = max(0, newX - 1);
	int32_t minY = max(0, newY - 1);

	//int32_t maxXPlus1 = 1 + min(ConstGameBoardSizePerDirMinus1, newX + 1);
	//int32_t maxYPlus1 = 1 + min(ConstGameBoardSizePerDirMinus1, newY + 1);
	int32_t maxXPlus1 = min(ConstGameBoardSizePerDir, newX + 2);
	int32_t maxYPlus1 = min(ConstGameBoardSizePerDir, newY + 2);

	int32_t id, iiy;

	for (int32_t iy = minY; iy < maxYPlus1; iy++)
	{
		iiy = ConstGameBoardSizePerDir * iy;

		for (int32_t ix = minX; ix < maxXPlus1; ix++)
		{
			id = ix + iiy;

			if (pInOutGameData[id] == ConstGameBoard_Player1)
			{
				pInOutGameData[id] = ConstGameBoard_Player2;
			}
		} /* end of for (int32_t ix = minY; ix < maxXPlus1; ix++) */
	} /* end of for (int32_t iy = minY; iy < maxYPlus1; iy++) */
}

int32_t Minimax_Player1MoveEvaluation(CGameStateValues* pInActualGameState, CSimpleGameStatePool* pGameStatePool, int32_t searchDepth, int32_t searchDepthMax, bool searchForMaximum, int32_t alpha, int32_t beta)
{
	int8_t* pActualGameStateValueArray = &pInActualGameState->pValueArray[0];

	int32_t Player1Score, Player2Score;

	Calculate_Score(&Player1Score, &Player2Score, pActualGameStateValueArray);

	if (Player1Score > 0 && Player2Score == 0)
	{
		return ConstMaxEvaluationScore_Minimax;
	}
	else if (Player1Score == 0 && Player2Score > 0)
	{
		return ConstMinEvaluationScore_Minimax;
	}

	int32_t evaluationScore = Player1Score - Player2Score;// -searchDepth;

	if (searchDepth == searchDepthMax)
	{
		return evaluationScore;
	}


	if (searchForMaximum == true)
	{
		if (Check_PossiblePlayer1Moves(pActualGameStateValueArray) == false)
		{
			return evaluationScore;
		}

		int32_t maxValue = ConstMinEvaluationScore_Minimax;
		//bool stopEvaluation = false;

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer1CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					CGameStateValues* pGameStateObjectAfterTestMove = nullptr;
					int32_t GameStateObjectID = -1;

					pGameStatePool->Get_UnusedGameStateObject(&pGameStateObjectAfterTestMove, &GameStateObjectID);

					if (pGameStateObjectAfterTestMove == nullptr)
					{
						return maxValue;
					}

					pGameStateObjectAfterTestMove->Clone_GameStateValues(pInActualGameState);

					Make_Player1CloneMove(ixNew, iyNew, &pGameStateObjectAfterTestMove->pValueArray[0]);

					// Evaluate test move:
					maxValue = max(maxValue, Minimax_Player1MoveEvaluation(pGameStateObjectAfterTestMove, pGameStatePool, searchDepth + 1, searchDepthMax, !searchForMaximum, alpha, beta));
					alpha = max(alpha, maxValue);

					pGameStatePool->Stop_Using_GameStateObject(GameStateObjectID);

					if (beta <= alpha)
					{
						//alphaBetaPruningCounter++;
						//Programmschleife verlassen, innerhalb derer s�mtliche Testz�ge durchgef�hrt warden:
						break;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player1)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?

							// next test move:

							CGameStateValues* pGameStateObjectAfterTestMove = nullptr;
							int32_t GameStateObjectID = -1;

							pGameStatePool->Get_UnusedGameStateObject(&pGameStateObjectAfterTestMove, &GameStateObjectID);

							if (pGameStateObjectAfterTestMove == nullptr)
							{
								return maxValue;
							}

							pGameStateObjectAfterTestMove->Clone_GameStateValues(pInActualGameState);

							Make_Player1Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObjectAfterTestMove->pValueArray[0]);

							// Evaluate test move:
							maxValue = max(maxValue, Minimax_Player1MoveEvaluation(pGameStateObjectAfterTestMove, pGameStatePool, searchDepth + 1, searchDepthMax, !searchForMaximum, alpha, beta));
							alpha = max(alpha, maxValue);

							pGameStatePool->Stop_Using_GameStateObject(GameStateObjectID);

							if (beta <= alpha)
							{
								//alphaBetaPruningCounter++;
								//Programmschleife verlassen, innerhalb derer s�mtliche Testz�ge durchgef�hrt warden:
								break;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		return maxValue;

	} // end of if (searchForMaximum == true)
	else if (searchForMaximum == false)
	{
		if (Check_PossiblePlayer2Moves(pActualGameStateValueArray) == false)
		{
			return evaluationScore;
		}

		int32_t minValue = ConstMaxEvaluationScore_Minimax;
		//bool stopEvaluation = false;

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer2CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					CGameStateValues* pGameStateObjectAfterTestMove = nullptr;
					int32_t GameStateObjectID = -1;

					pGameStatePool->Get_UnusedGameStateObject(&pGameStateObjectAfterTestMove, &GameStateObjectID);

					if (pGameStateObjectAfterTestMove == nullptr)
					{
						return minValue;
					}

					pGameStateObjectAfterTestMove->Clone_GameStateValues(pInActualGameState);

					Make_Player2CloneMove(ixNew, iyNew, &pGameStateObjectAfterTestMove->pValueArray[0]);

					// Evaluate test move:
					minValue = min(minValue, Minimax_Player1MoveEvaluation(pGameStateObjectAfterTestMove, pGameStatePool, searchDepth + 1, searchDepthMax, !searchForMaximum, alpha, beta));
					beta = min(beta, minValue);

					pGameStatePool->Stop_Using_GameStateObject(GameStateObjectID);

					if (beta <= alpha)
					{
						//alphaBetaPruningCounter++;
						//Programmschleife verlassen, innerhalb derer s�mtliche Testz�ge durchgef�hrt warden:
						break;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player2)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?

							// next test move:

							CGameStateValues* pGameStateObjectAfterTestMove = nullptr;
							int32_t GameStateObjectID = -1;

							pGameStatePool->Get_UnusedGameStateObject(&pGameStateObjectAfterTestMove, &GameStateObjectID);

							if (pGameStateObjectAfterTestMove == nullptr)
							{
								return minValue;
							}

							pGameStateObjectAfterTestMove->Clone_GameStateValues(pInActualGameState);

							Make_Player2Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObjectAfterTestMove->pValueArray[0]);

							// Evaluate test move:
							minValue = min(minValue, Minimax_Player1MoveEvaluation(pGameStateObjectAfterTestMove, pGameStatePool, searchDepth + 1, searchDepthMax, !searchForMaximum, alpha, beta));
							beta = min(beta, minValue);

							pGameStatePool->Stop_Using_GameStateObject(GameStateObjectID);

							if (beta <= alpha)
							{
								//alphaBetaPruningCounter++;
								//Programmschleife verlassen, innerhalb derer s�mtliche Testz�ge durchgef�hrt warden:
								break;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		return minValue;

	} // end of else if (searchForMaximum == false)

	//return 0;
}

int32_t Minimax_Player2MoveEvaluation(CGameStateValues* pInActualGameState, CSimpleGameStatePool* pGameStatePool, int32_t searchDepth, int32_t searchDepthMax, bool searchForMaximum, int32_t alpha, int32_t beta)
{
	int8_t* pActualGameStateValueArray = &pInActualGameState->pValueArray[0];

	int32_t Player1Score, Player2Score;

	Calculate_Score(&Player1Score, &Player2Score, pActualGameStateValueArray);

	if (Player2Score > 0 && Player1Score == 0)
	{
		return ConstMaxEvaluationScore_Minimax;
	}
	else if (Player2Score == 0 && Player1Score > 0)
	{
		return ConstMinEvaluationScore_Minimax;
	}

	int32_t evaluationScore = Player2Score - Player1Score;// -searchDepth;

	if (searchDepth == searchDepthMax)
	{
		return evaluationScore;
	}


	if (searchForMaximum == true)
	{
		if (Check_PossiblePlayer2Moves(pActualGameStateValueArray) == false)
		{
			return evaluationScore;
		}

		int32_t maxValue = ConstMinEvaluationScore_Minimax;
		//bool stopEvaluation = false;

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer2CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					CGameStateValues* pGameStateObjectAfterTestMove = nullptr;
					int32_t GameStateObjectID = -1;

					pGameStatePool->Get_UnusedGameStateObject(&pGameStateObjectAfterTestMove, &GameStateObjectID);

					if (pGameStateObjectAfterTestMove == nullptr)
					{
						return maxValue;
					}

					pGameStateObjectAfterTestMove->Clone_GameStateValues(pInActualGameState);

					Make_Player2CloneMove(ixNew, iyNew, &pGameStateObjectAfterTestMove->pValueArray[0]);

					// Evaluate test move:
					maxValue = max(maxValue, Minimax_Player2MoveEvaluation(pGameStateObjectAfterTestMove, pGameStatePool, searchDepth + 1, searchDepthMax, !searchForMaximum, alpha, beta));
					alpha = max(alpha, maxValue);

					pGameStatePool->Stop_Using_GameStateObject(GameStateObjectID);

					if (beta <= alpha)
					{
						//alphaBetaPruningCounter++;
						//Programmschleife verlassen, innerhalb derer s�mtliche Testz�ge durchgef�hrt warden:
						break;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player2)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?

							// next test move:

							CGameStateValues* pGameStateObjectAfterTestMove = nullptr;
							int32_t GameStateObjectID = -1;

							pGameStatePool->Get_UnusedGameStateObject(&pGameStateObjectAfterTestMove, &GameStateObjectID);

							if (pGameStateObjectAfterTestMove == nullptr)
							{
								return maxValue;
							}

							pGameStateObjectAfterTestMove->Clone_GameStateValues(pInActualGameState);

							Make_Player2Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObjectAfterTestMove->pValueArray[0]);

							// Evaluate test move:
							maxValue = max(maxValue, Minimax_Player2MoveEvaluation(pGameStateObjectAfterTestMove, pGameStatePool, searchDepth + 1, searchDepthMax, !searchForMaximum, alpha, beta));
							alpha = max(alpha, maxValue);

							pGameStatePool->Stop_Using_GameStateObject(GameStateObjectID);

							if (beta <= alpha)
							{
								//alphaBetaPruningCounter++;
								//Programmschleife verlassen, innerhalb derer s�mtliche Testz�ge durchgef�hrt warden:
								break;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		return maxValue;

	} // end of if (searchForMaximum == true)
	else if (searchForMaximum == false)
	{
		if (Check_PossiblePlayer1Moves(pActualGameStateValueArray) == false)
		{
			return evaluationScore;
		}

		int32_t minValue = ConstMaxEvaluationScore_Minimax;
		//bool stopEvaluation = false;

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer1CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					CGameStateValues* pGameStateObjectAfterTestMove = nullptr;
					int32_t GameStateObjectID = -1;

					pGameStatePool->Get_UnusedGameStateObject(&pGameStateObjectAfterTestMove, &GameStateObjectID);

					if (pGameStateObjectAfterTestMove == nullptr)
					{
						return minValue;
					}

					pGameStateObjectAfterTestMove->Clone_GameStateValues(pInActualGameState);

					Make_Player1CloneMove(ixNew, iyNew, &pGameStateObjectAfterTestMove->pValueArray[0]);

					// Evaluate test move:
					minValue = min(minValue, Minimax_Player2MoveEvaluation(pGameStateObjectAfterTestMove, pGameStatePool, searchDepth + 1, searchDepthMax, !searchForMaximum, alpha, beta));
					beta = min(beta, minValue);

					pGameStatePool->Stop_Using_GameStateObject(GameStateObjectID);

					if (beta <= alpha)
					{
						//alphaBetaPruningCounter++;
						//Programmschleife verlassen, innerhalb derer s�mtliche Testz�ge durchgef�hrt warden:
						break;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player1)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?

							// next test move:

							CGameStateValues* pGameStateObjectAfterTestMove = nullptr;
							int32_t GameStateObjectID = -1;

							pGameStatePool->Get_UnusedGameStateObject(&pGameStateObjectAfterTestMove, &GameStateObjectID);

							if (pGameStateObjectAfterTestMove == nullptr)
							{
								return minValue;
							}

							pGameStateObjectAfterTestMove->Clone_GameStateValues(pInActualGameState);

							Make_Player1Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObjectAfterTestMove->pValueArray[0]);

							// Evaluate test move:
							minValue = min(minValue, Minimax_Player2MoveEvaluation(pGameStateObjectAfterTestMove, pGameStatePool, searchDepth + 1, searchDepthMax, !searchForMaximum, alpha, beta));
							beta = min(beta, minValue);

							pGameStatePool->Stop_Using_GameStateObject(GameStateObjectID);

							if (beta <= alpha)
							{
								//alphaBetaPruningCounter++;
								//Programmschleife verlassen, innerhalb derer s�mtliche Testz�ge durchgef�hrt warden:
								break;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		return minValue;

	} // end of else if (searchForMaximum == false)

	 //return 0;
}

void Minimax_Player1(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, CSimpleGameStatePool* pGameStatePool, int32_t maxSearchDepth)
{
	pGameStatePool->Stop_Using_AllGameStateObjects();

	pOutNewGameState->Clone_GameStateValues(pInActualGameState);

	int8_t* pActualGameStateValueArray = &pInActualGameState->pValueArray[0];

	int32_t bestEvaluation = ConstMinEvaluationScore_Minimax;


	//alphaBetaPruningCounter = 0;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
		{
			if (Check_PossiblePlayer1CloneMove(i, pActualGameStateValueArray) == true)
			{
				// next test move:

				int32_t ixNew = i % ConstGameBoardSizePerDir;
				int32_t iyNew = i / ConstGameBoardSizePerDir;

				CGameStateValues* pGameStateObjectAfterTestMove = nullptr;
				int32_t GameStateObjectID = -1;

				pGameStatePool->Get_UnusedGameStateObject(&pGameStateObjectAfterTestMove, &GameStateObjectID);

				pGameStateObjectAfterTestMove->Clone_GameStateValues(pInActualGameState);

				// test move:
				Make_Player1CloneMove(ixNew, iyNew, &pGameStateObjectAfterTestMove->pValueArray[0]);

				// evaluate test move:
				//int32_t Player1Score, Player2Score;
				//Calculate_Score(&Player1Score, &Player2Score, &pGameStateObjectAfterTestMove->pValueArray[0]);
				//int32_t actualEvaluation = Player1Score - Player2Score;

				// evaluate test move:
				int32_t actualEvaluation = Minimax_Player1MoveEvaluation(pGameStateObjectAfterTestMove, pGameStatePool, 0, maxSearchDepth, false, ConstMinEvaluationScore_Minimax, ConstMaxEvaluationScore_Minimax);


				if (actualEvaluation > bestEvaluation)
				{
					pOutNewGameState->Clone_GameStateValues(pGameStateObjectAfterTestMove);
					bestEvaluation = actualEvaluation;
				}

				pGameStatePool->Stop_Using_GameStateObject(GameStateObjectID);
			}
		}
		else if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		{
			int32_t ixOld = i % ConstGameBoardSizePerDir;
			int32_t iyOld = i / ConstGameBoardSizePerDir;

			int32_t ixMin = max(0, ixOld - 2);
			int32_t iyMin = max(0, iyOld - 2);

			int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
			int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

			for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
			{
				for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
				{
					// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
					if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
					{
						continue;
					}

					if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
					{
						// macht ein Sprung-Z�ge Sinn?
						/*{
							int32_t ixMin = max(0, ixNew - 1);
							int32_t iyMin = max(0, iyNew - 1);

							int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
							int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

							bool badMoveDecision = false;
							bool isolatedPos = true;

							int32_t iiy;
							int8_t gameStateValue;

							for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
							{
								iiy = ConstGameBoardSizePerDir * iy;

								for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
								{
									gameStateValue = pActualGameStateValueArray[ix + iiy];

									if (gameStateValue == ConstGameBoard_Player1)
									{
										isolatedPos = false;
										badMoveDecision = true;
										break;
									}
									if (gameStateValue != ConstGameBoard_Empty)
									{
										isolatedPos = false;
									}
								}

								if (badMoveDecision == true)
								{
									break;
								}

							}

							if (badMoveDecision == true || isolatedPos == true)
							{
								continue;
							}
						} // end of macht ein Sprung-Z�ge Sinn?
						*/
						// next test move:

						CGameStateValues* pGameStateObjectAfterTestMove = nullptr;
						int32_t GameStateObjectID = -1;

						pGameStatePool->Get_UnusedGameStateObject(&pGameStateObjectAfterTestMove, &GameStateObjectID);

						pGameStateObjectAfterTestMove->Clone_GameStateValues(pInActualGameState);

						// test move:
						Make_Player1Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObjectAfterTestMove->pValueArray[0]);

						// evaluate test move:
						//int32_t Player1Score, Player2Score;
						//Calculate_Score(&Player1Score, &Player2Score, &pGameStateObjectAfterTestMove->pValueArray[0]);
						//int32_t actualEvaluation = Player1Score - Player2Score;

						// evaluate test move:
						int32_t actualEvaluation = Minimax_Player1MoveEvaluation(pGameStateObjectAfterTestMove, pGameStatePool, 0, maxSearchDepth, false, ConstMinEvaluationScore_Minimax, ConstMaxEvaluationScore_Minimax);


						if (actualEvaluation > bestEvaluation)
						{
							pOutNewGameState->Clone_GameStateValues(pGameStateObjectAfterTestMove);
							bestEvaluation = actualEvaluation;
						}

						pGameStatePool->Stop_Using_GameStateObject(GameStateObjectID);
					}
				}
			}
		} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
	} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	//Add_To_Log(0, "alphaBetaPruningCounter", alphaBetaPruningCounter);
}

void Minimax_Player2(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, CSimpleGameStatePool* pGameStatePool, int32_t maxSearchDepth)
{
	pGameStatePool->Stop_Using_AllGameStateObjects();

	pOutNewGameState->Clone_GameStateValues(pInActualGameState);

	int8_t* pActualGameStateValueArray = &pInActualGameState->pValueArray[0];

	int32_t bestEvaluation = ConstMinEvaluationScore_Minimax;

	//alphaBetaPruningCounter = 0;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
		{
			if (Check_PossiblePlayer2CloneMove(i, pActualGameStateValueArray) == true)
			{
				// next test move:

				int32_t ixNew = i % ConstGameBoardSizePerDir;
				int32_t iyNew = i / ConstGameBoardSizePerDir;

				CGameStateValues* pGameStateObjectAfterTestMove = nullptr;
				int32_t GameStateObjectID = -1;

				pGameStatePool->Get_UnusedGameStateObject(&pGameStateObjectAfterTestMove, &GameStateObjectID);

				pGameStateObjectAfterTestMove->Clone_GameStateValues(pInActualGameState);

				// test move:
				Make_Player2CloneMove(ixNew, iyNew, &pGameStateObjectAfterTestMove->pValueArray[0]);



				// evaluate test move:
				int32_t actualEvaluation = Minimax_Player2MoveEvaluation(pGameStateObjectAfterTestMove, pGameStatePool, 0, maxSearchDepth, false, ConstMinEvaluationScore_Minimax, ConstMaxEvaluationScore_Minimax);


				if (actualEvaluation > bestEvaluation)
				{
					pOutNewGameState->Clone_GameStateValues(pGameStateObjectAfterTestMove);
					bestEvaluation = actualEvaluation;
				}

				pGameStatePool->Stop_Using_GameStateObject(GameStateObjectID);
			}
		}
		else if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
		{
			int32_t ixOld = i % ConstGameBoardSizePerDir;
			int32_t iyOld = i / ConstGameBoardSizePerDir;

			int32_t ixMin = max(0, ixOld - 2);
			int32_t iyMin = max(0, iyOld - 2);

			int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
			int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

			for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
			{
				for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
				{
					// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
					if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
					{
						continue;
					}

					if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
					{
						// macht ein Sprung-Z�ge Sinn?
						/*{
							int32_t ixMin = max(0, ixNew - 1);
							int32_t iyMin = max(0, iyNew - 1);

							int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
							int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

							bool badMoveDecision = false;
							bool isolatedPos = true;

							int32_t iiy;
							int8_t gameStateValue;

							for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
							{
								iiy = ConstGameBoardSizePerDir * iy;

								for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
								{
									gameStateValue = pActualGameStateValueArray[ix + iiy];

									if (gameStateValue == ConstGameBoard_Player2)
									{
										isolatedPos = false;
										badMoveDecision = true;
										break;
									}
									if (gameStateValue != ConstGameBoard_Empty)
									{
										isolatedPos = false;
									}
								}

								if (badMoveDecision == true)
								{
									break;
								}

							}

							if (badMoveDecision == true || isolatedPos == true)
							{
								continue;
							}
						} // end of macht ein Sprung-Z�ge Sinn?
						*/
						// next test move:

						CGameStateValues* pGameStateObjectAfterTestMove = nullptr;
						int32_t GameStateObjectID = -1;

						pGameStatePool->Get_UnusedGameStateObject(&pGameStateObjectAfterTestMove, &GameStateObjectID);

						pGameStateObjectAfterTestMove->Clone_GameStateValues(pInActualGameState);

						// test move:
						Make_Player2Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObjectAfterTestMove->pValueArray[0]);



						// evaluate test move:
						int32_t actualEvaluation = Minimax_Player2MoveEvaluation(pGameStateObjectAfterTestMove, pGameStatePool, 0, maxSearchDepth, false, ConstMinEvaluationScore_Minimax, ConstMaxEvaluationScore_Minimax);


						if (actualEvaluation > bestEvaluation)
						{
							pOutNewGameState->Clone_GameStateValues(pGameStateObjectAfterTestMove);
							bestEvaluation = actualEvaluation;
						}

						pGameStatePool->Stop_Using_GameStateObject(GameStateObjectID);
					}
				}
			}
		} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
	} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	//Add_To_Log(0, "alphaBetaPruningCounter", alphaBetaPruningCounter);
}

void ExtMinimax_Player1(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, CSimpleGameStatePool* pGameStatePool, int32_t maxSearchDepth)
{
	static constexpr int32_t ConstNumOfConsideredBestMoves = 4;

	static  C2DimMoveDesc BestMoveDescArray[ConstNumOfConsideredBestMoves];

	for (int32_t i = 0; i < ConstNumOfConsideredBestMoves; i++)
		BestMoveDescArray[i].Reset();

	C2DimMoveDesc MoveDesc;

	pGameStatePool->Stop_Using_AllGameStateObjects();

	pOutNewGameState->Clone_GameStateValues(pInActualGameState);

	int8_t* pActualGameStateValueArray = &pInActualGameState->pValueArray[0];

	int32_t bestEvaluation = ConstMinEvaluationScore_Minimax;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
		{
			int32_t ixOld;
			int32_t iyOld;

			if (Get_PossiblePlayer1CloneMoveStartPos(&ixOld, &iyOld, i, pActualGameStateValueArray) == true)
			{
				// next test move:

				int32_t ixNew = i % ConstGameBoardSizePerDir;
				int32_t iyNew = i / ConstGameBoardSizePerDir;

				CGameStateValues* pGameStateObjectAfterTestMove = nullptr;
				int32_t GameStateObjectID = -1;

				pGameStatePool->Get_UnusedGameStateObject(&pGameStateObjectAfterTestMove, &GameStateObjectID);

				pGameStateObjectAfterTestMove->Clone_GameStateValues(pInActualGameState);

				// test move:
				Make_Player1CloneMove(ixNew, iyNew, &pGameStateObjectAfterTestMove->pValueArray[0]);

				// evaluate test move:
				//int32_t Player1Score, Player2Score;
				//Calculate_Score(&Player1Score, &Player2Score, &pGameStateObjectAfterTestMove->pValueArray[0]);
				//int32_t actualEvaluation = Player1Score - Player2Score;

				// evaluate test move:
				int32_t actualEvaluation = Minimax_Player1MoveEvaluation(pGameStateObjectAfterTestMove, pGameStatePool, 0, maxSearchDepth, false, ConstMinEvaluationScore_Minimax, ConstMaxEvaluationScore_Minimax);

				MoveDesc.iEvaluation = actualEvaluation;
				MoveDesc.ix_Old = ixOld;
				MoveDesc.iy_Old = iyOld;
				MoveDesc.ix_New = ixNew;
				MoveDesc.iy_New = iyNew;

				Update_ListOfBestMoves_IntegerEvaluation(BestMoveDescArray, ConstNumOfConsideredBestMoves, &MoveDesc);

				if (actualEvaluation > bestEvaluation)
				{
					pOutNewGameState->Clone_GameStateValues(pGameStateObjectAfterTestMove);
					bestEvaluation = actualEvaluation;
				}

				pGameStatePool->Stop_Using_GameStateObject(GameStateObjectID);
			}
		}
		else if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		{
			int32_t ixOld = i % ConstGameBoardSizePerDir;
			int32_t iyOld = i / ConstGameBoardSizePerDir;

			int32_t ixMin = max(0, ixOld - 2);
			int32_t iyMin = max(0, iyOld - 2);

			int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
			int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

			for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
			{
				for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
				{
					// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
					if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
					{
						continue;
					}

					if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
					{
						// macht ein Sprung-Z�ge Sinn?
						/*{
							int32_t ixMin = max(0, ixNew - 1);
							int32_t iyMin = max(0, iyNew - 1);

							int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
							int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

							bool badMoveDecision = false;
							bool isolatedPos = true;

							int32_t iiy;
							int8_t gameStateValue;

							for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
							{
								iiy = ConstGameBoardSizePerDir * iy;

								for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
								{
									gameStateValue = pActualGameStateValueArray[ix + iiy];

									if (gameStateValue == ConstGameBoard_Player1)
									{
										isolatedPos = false;
										badMoveDecision = true;
										break;
									}
									if (gameStateValue != ConstGameBoard_Empty)
									{
										isolatedPos = false;
									}
								}

								if (badMoveDecision == true)
								{
									break;
								}

							}

							if (badMoveDecision == true || isolatedPos == true)
							{
								continue;
							}
						} // end of macht ein Sprung-Z�ge Sinn?
						*/
						// next test move:

						CGameStateValues* pGameStateObjectAfterTestMove = nullptr;
						int32_t GameStateObjectID = -1;

						pGameStatePool->Get_UnusedGameStateObject(&pGameStateObjectAfterTestMove, &GameStateObjectID);

						pGameStateObjectAfterTestMove->Clone_GameStateValues(pInActualGameState);

						// test move:
						Make_Player1Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObjectAfterTestMove->pValueArray[0]);

						// evaluate test move:
						//int32_t Player1Score, Player2Score;
						//Calculate_Score(&Player1Score, &Player2Score, &pGameStateObjectAfterTestMove->pValueArray[0]);
						//int32_t actualEvaluation = Player1Score - Player2Score;

						// evaluate test move:
						int32_t actualEvaluation = Minimax_Player1MoveEvaluation(pGameStateObjectAfterTestMove, pGameStatePool, 0, maxSearchDepth, false, ConstMinEvaluationScore_Minimax, ConstMaxEvaluationScore_Minimax);

						MoveDesc.iEvaluation = actualEvaluation;
						MoveDesc.ix_Old = ixOld;
						MoveDesc.iy_Old = iyOld;
						MoveDesc.ix_New = ixNew;
						MoveDesc.iy_New = iyNew;

						Update_ListOfBestMoves_IntegerEvaluation(BestMoveDescArray, ConstNumOfConsideredBestMoves, &MoveDesc);

						if (actualEvaluation > bestEvaluation)
						{
							pOutNewGameState->Clone_GameStateValues(pGameStateObjectAfterTestMove);
							bestEvaluation = actualEvaluation;
						}

						pGameStatePool->Stop_Using_GameStateObject(GameStateObjectID);
					}
				}
			}
		} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
	} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	//return;

	bestEvaluation = ConstMinEvaluationScore_Minimax;

	for (int32_t i = 0; i < ConstNumOfConsideredBestMoves; i++)
	{
		if (BestMoveDescArray[i].ix_Old < 0)
		{
			continue;
		}

		// next test move:

		CGameStateValues* pGameStateObjectAfterTestMove = nullptr;
		int32_t GameStateObjectID = -1;

		pGameStatePool->Get_UnusedGameStateObject(&pGameStateObjectAfterTestMove, &GameStateObjectID);

		pGameStateObjectAfterTestMove->Clone_GameStateValues(pInActualGameState);

		// test move:
		Make_Player1Move(BestMoveDescArray[i].ix_Old, BestMoveDescArray[i].iy_Old, BestMoveDescArray[i].ix_New, BestMoveDescArray[i].iy_New, &pGameStateObjectAfterTestMove->pValueArray[0]);

		// evaluate test move:
		int32_t actualEvaluation = Minimax_Player1MoveEvaluation(pGameStateObjectAfterTestMove, pGameStatePool, 0, maxSearchDepth + 2, false, ConstMinEvaluationScore_Minimax, ConstMaxEvaluationScore_Minimax);

		if (actualEvaluation > bestEvaluation)
		{
			pOutNewGameState->Clone_GameStateValues(pGameStateObjectAfterTestMove);
			bestEvaluation = actualEvaluation;
		}

		pGameStatePool->Stop_Using_GameStateObject(GameStateObjectID);
	} // end of for (int32_t i = 0; i < ConstNumOfConsideredBestMoves; i++)
}

void ExtMinimax_Player2(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, CSimpleGameStatePool* pGameStatePool, int32_t maxSearchDepth)
{
	static constexpr int32_t ConstNumOfConsideredBestMoves = 4;

	static C2DimMoveDesc BestMoveDescArray[ConstNumOfConsideredBestMoves];

	for (int32_t i = 0; i < ConstNumOfConsideredBestMoves; i++)
		BestMoveDescArray[i].Reset();

	C2DimMoveDesc MoveDesc;

	pGameStatePool->Stop_Using_AllGameStateObjects();

	pOutNewGameState->Clone_GameStateValues(pInActualGameState);

	int8_t* pActualGameStateValueArray = &pInActualGameState->pValueArray[0];

	int32_t bestEvaluation = ConstMinEvaluationScore_Minimax;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
		{
			int32_t ixOld;
			int32_t iyOld;

			if (Get_PossiblePlayer2CloneMoveStartPos(&ixOld, &iyOld, i, pActualGameStateValueArray) == true)
			{
				// next test move:

				int32_t ixNew = i % ConstGameBoardSizePerDir;
				int32_t iyNew = i / ConstGameBoardSizePerDir;

				CGameStateValues* pGameStateObjectAfterTestMove = nullptr;
				int32_t GameStateObjectID = -1;

				pGameStatePool->Get_UnusedGameStateObject(&pGameStateObjectAfterTestMove, &GameStateObjectID);

				pGameStateObjectAfterTestMove->Clone_GameStateValues(pInActualGameState);

				// test move:
				Make_Player2CloneMove(ixNew, iyNew, &pGameStateObjectAfterTestMove->pValueArray[0]);



				// evaluate test move:
				int32_t actualEvaluation = Minimax_Player2MoveEvaluation(pGameStateObjectAfterTestMove, pGameStatePool, 0, maxSearchDepth, false, ConstMinEvaluationScore_Minimax, ConstMaxEvaluationScore_Minimax);

				MoveDesc.iEvaluation = actualEvaluation;
				MoveDesc.ix_Old = ixOld;
				MoveDesc.iy_Old = iyOld;
				MoveDesc.ix_New = ixNew;
				MoveDesc.iy_New = iyNew;

				Update_ListOfBestMoves_IntegerEvaluation(BestMoveDescArray, ConstNumOfConsideredBestMoves, &MoveDesc);

				if (actualEvaluation > bestEvaluation)
				{
					pOutNewGameState->Clone_GameStateValues(pGameStateObjectAfterTestMove);
					bestEvaluation = actualEvaluation;
				}

				pGameStatePool->Stop_Using_GameStateObject(GameStateObjectID);
			}
		}
		else if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
		{
			int32_t ixOld = i % ConstGameBoardSizePerDir;
			int32_t iyOld = i / ConstGameBoardSizePerDir;

			int32_t ixMin = max(0, ixOld - 2);
			int32_t iyMin = max(0, iyOld - 2);

			int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
			int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

			for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
			{
				for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
				{
					// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
					if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
					{
						continue;
					}

					if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
					{
						// macht ein Sprung-Z�ge Sinn?
						/*{
							int32_t ixMin = max(0, ixNew - 1);
							int32_t iyMin = max(0, iyNew - 1);

							int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
							int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

							bool badMoveDecision = false;
							bool isolatedPos = true;

							int32_t iiy;
							int8_t gameStateValue;

							for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
							{
								iiy = ConstGameBoardSizePerDir * iy;

								for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
								{
									gameStateValue = pActualGameStateValueArray[ix + iiy];

									if (gameStateValue == ConstGameBoard_Player2)
									{
										isolatedPos = false;
										badMoveDecision = true;
										break;
									}
									if (gameStateValue != ConstGameBoard_Empty)
									{
										isolatedPos = false;
									}
								}

								if (badMoveDecision == true)
								{
									break;
								}

							}

							if (badMoveDecision == true || isolatedPos == true)
							{
								continue;
							}
						} // end of macht ein Sprung-Z�ge Sinn?
						*/
						// next test move:

						CGameStateValues* pGameStateObjectAfterTestMove = nullptr;
						int32_t GameStateObjectID = -1;

						pGameStatePool->Get_UnusedGameStateObject(&pGameStateObjectAfterTestMove, &GameStateObjectID);

						pGameStateObjectAfterTestMove->Clone_GameStateValues(pInActualGameState);

						// test move:
						Make_Player2Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObjectAfterTestMove->pValueArray[0]);



						// evaluate test move:
						int32_t actualEvaluation = Minimax_Player2MoveEvaluation(pGameStateObjectAfterTestMove, pGameStatePool, 0, maxSearchDepth, false, ConstMinEvaluationScore_Minimax, ConstMaxEvaluationScore_Minimax);

						MoveDesc.iEvaluation = actualEvaluation;
						MoveDesc.ix_Old = ixOld;
						MoveDesc.iy_Old = iyOld;
						MoveDesc.ix_New = ixNew;
						MoveDesc.iy_New = iyNew;

						Update_ListOfBestMoves_IntegerEvaluation(BestMoveDescArray, ConstNumOfConsideredBestMoves, &MoveDesc);

						if (actualEvaluation > bestEvaluation)
						{
							pOutNewGameState->Clone_GameStateValues(pGameStateObjectAfterTestMove);
							bestEvaluation = actualEvaluation;
						}

						pGameStatePool->Stop_Using_GameStateObject(GameStateObjectID);
					}
				}
			}
		} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
	} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	//return;

	bestEvaluation = ConstMinEvaluationScore_Minimax;

	for (int32_t i = 0; i < ConstNumOfConsideredBestMoves; i++)
	{
		if (BestMoveDescArray[i].ix_Old < 0)
		{
			continue;
		}

		// next test move:

		CGameStateValues* pGameStateObjectAfterTestMove = nullptr;
		int32_t GameStateObjectID = -1;

		pGameStatePool->Get_UnusedGameStateObject(&pGameStateObjectAfterTestMove, &GameStateObjectID);

		pGameStateObjectAfterTestMove->Clone_GameStateValues(pInActualGameState);

		// test move:
		Make_Player2Move(BestMoveDescArray[i].ix_Old, BestMoveDescArray[i].iy_Old, BestMoveDescArray[i].ix_New, BestMoveDescArray[i].iy_New, &pGameStateObjectAfterTestMove->pValueArray[0]);

		// evaluate test move:
		int32_t actualEvaluation = Minimax_Player2MoveEvaluation(pGameStateObjectAfterTestMove, pGameStatePool, 0, maxSearchDepth + 2, false, ConstMinEvaluationScore_Minimax, ConstMaxEvaluationScore_Minimax);

		if (actualEvaluation > bestEvaluation)
		{
			pOutNewGameState->Clone_GameStateValues(pGameStateObjectAfterTestMove);
			bestEvaluation = actualEvaluation;
		}

		pGameStatePool->Stop_Using_GameStateObject(GameStateObjectID);
	} // end of for (int32_t i = 0; i < ConstNumOfConsideredBestMoves; i++)
}




void Evaluate_LeafGameStates_Player1View(CExtendedGameStatePool* pGameStatePool)
{
	int32_t Player1Score, Player2Score;

	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;

	for (int32_t i = numOfDepthLayersMax - 1; i > -1; i--)
	{
		CSimpleLinkedListManager* pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[i];
		int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
		int32_t id = 0;

		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);

			if (pGameStatePool->pGameStateArray[id].LeafNode == false)
			{
				continue;
			}

			Calculate_Score(&Player1Score, &Player2Score, &pGameStatePool->pGameStateArray[id].pValueArray[0]);

			if (Player1Score > 0 && Player2Score == 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
			}
			else if (Player1Score == 0 && Player2Score > 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
			}
			else
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = Player1Score - Player2Score;
			}

		}
	}
}

void Evaluate_LeafGameStates_Player1View(CGameStatePool_SimpleGameTree* pGameStatePool)
{
	int32_t Player1Score, Player2Score;

	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;

	for (int32_t i = numOfDepthLayersMax - 1; i > -1; i--)
	{
		CSimpleGameTree_DepthLayerInfo* pDepthLayerInfo = &pGameStatePool->pDepthLayerInfoArray[i];
		int32_t NumObjectsUsed = pDepthLayerInfo->NumGameStatesUsed;
		int32_t id = 0;

		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			id = pDepthLayerInfo->pGameStateIDArray[j];

			if (pGameStatePool->pGameStateArray[id].LeafNode == false)
			{
				continue;
			}

			Calculate_Score(&Player1Score, &Player2Score, &pGameStatePool->pGameStateArray[id].pValueArray[0]);

			if (Player1Score > 0 && Player2Score == 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
			}
			else if (Player1Score == 0 && Player2Score > 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
			}
			else
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = Player1Score - Player2Score;
			}

		}
	}
}

void Evaluate_GameStates_Player1View(CExtendedGameStatePool* pGameStatePool)
{
	int32_t Player1Score, Player2Score;

	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;
	int32_t numOfDepthLayersMaxMinus1 = numOfDepthLayersMax - 1;

	for (int32_t i = 0; i < numOfDepthLayersMaxMinus1; i++)
	{
		CSimpleLinkedListManager* pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[i];
		int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
		int32_t id = 0;

		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);

			Calculate_Score(&Player1Score, &Player2Score, &pGameStatePool->pGameStateArray[id].pValueArray[0]);

			if (Player1Score > 0 && Player2Score == 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
			}
			else if (Player1Score == 0 && Player2Score > 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
			}
			else
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = Player1Score - Player2Score;
			}

		}
	}
}

void Evaluate_GameStates_Player1View(CGameStatePool_SimpleGameTree* pGameStatePool)
{
	int32_t Player1Score, Player2Score;

	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;
	int32_t numOfDepthLayersMaxMinus1 = numOfDepthLayersMax - 1;

	for (int32_t i = 0; i < numOfDepthLayersMaxMinus1; i++)
	{
		CSimpleGameTree_DepthLayerInfo* pDepthLayerInfo = &pGameStatePool->pDepthLayerInfoArray[i];
		int32_t NumObjectsUsed = pDepthLayerInfo->NumGameStatesUsed;
		int32_t id = 0;

		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			id = pDepthLayerInfo->pGameStateIDArray[j];

			Calculate_Score(&Player1Score, &Player2Score, &pGameStatePool->pGameStateArray[id].pValueArray[0]);

			if (Player1Score > 0 && Player2Score == 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
			}
			else if (Player1Score == 0 && Player2Score > 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
			}
			else
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = Player1Score - Player2Score;
			}

		}
	}
}

void Evaluate_LeafGameStates_Player2View(CExtendedGameStatePool* pGameStatePool)
{
	int32_t Player1Score, Player2Score;

	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;

	for (int32_t i = numOfDepthLayersMax - 1; i > -1; i--)
	{
		CSimpleLinkedListManager* pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[i];
		int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
		int32_t id = 0;

		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);

			if (pGameStatePool->pGameStateArray[id].LeafNode == false)
			{
				continue;
			}

			Calculate_Score(&Player1Score, &Player2Score, &pGameStatePool->pGameStateArray[id].pValueArray[0]);

			if (Player2Score > 0 && Player1Score == 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
			}
			else if (Player2Score == 0 && Player1Score > 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
			}
			else
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = Player2Score - Player1Score;
			}

		}
	}
}

void Evaluate_LeafGameStates_Player2View(CGameStatePool_SimpleGameTree* pGameStatePool)
{
	int32_t Player1Score, Player2Score;

	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;

	for (int32_t i = numOfDepthLayersMax - 1; i > -1; i--)
	{
		CSimpleGameTree_DepthLayerInfo* pDepthLayerInfo = &pGameStatePool->pDepthLayerInfoArray[i];
		int32_t NumObjectsUsed = pDepthLayerInfo->NumGameStatesUsed;
		int32_t id = 0;

		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			id = pDepthLayerInfo->pGameStateIDArray[j];

			if (pGameStatePool->pGameStateArray[id].LeafNode == false)
			{
				continue;
			}

			Calculate_Score(&Player1Score, &Player2Score, &pGameStatePool->pGameStateArray[id].pValueArray[0]);

			if (Player2Score > 0 && Player1Score == 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
			}
			else if (Player2Score == 0 && Player1Score > 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
			}
			else
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = Player2Score - Player1Score;
			}

		}
	}
}

void Evaluate_GameStates_Player2View(CExtendedGameStatePool* pGameStatePool)
{
	int32_t Player1Score, Player2Score;

	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;
	int32_t numOfDepthLayersMaxMinus1 = numOfDepthLayersMax - 1;

	for (int32_t i = 0; i < numOfDepthLayersMaxMinus1; i++)
	{
		CSimpleLinkedListManager* pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[i];
		int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
		int32_t id = 0;

		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);

			Calculate_Score(&Player1Score, &Player2Score, &pGameStatePool->pGameStateArray[id].pValueArray[0]);

			if (Player2Score > 0 && Player1Score == 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
			}
			else if (Player2Score == 0 && Player1Score > 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
			}
			else
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = Player2Score - Player1Score;
			}
		}
	}
}

void Evaluate_GameStates_Player2View(CGameStatePool_SimpleGameTree* pGameStatePool)
{
	int32_t Player1Score, Player2Score;

	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;
	int32_t numOfDepthLayersMaxMinus1 = numOfDepthLayersMax - 1;

	for (int32_t i = 0; i < numOfDepthLayersMaxMinus1; i++)
	{
		CSimpleGameTree_DepthLayerInfo* pDepthLayerInfo = &pGameStatePool->pDepthLayerInfoArray[i];
		int32_t NumObjectsUsed = pDepthLayerInfo->NumGameStatesUsed;
		int32_t id = 0;

		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			id = pDepthLayerInfo->pGameStateIDArray[j];

			Calculate_Score(&Player1Score, &Player2Score, &pGameStatePool->pGameStateArray[id].pValueArray[0]);

			if (Player2Score > 0 && Player1Score == 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMaxEvaluationScore_Minimax;
			}
			else if (Player2Score == 0 && Player1Score > 0)
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = ConstMinEvaluationScore_Minimax;
			}
			else
			{
				pGameStatePool->pGameStateArray[id].iEvaluation = Player2Score - Player1Score;
			}
		}
	}
}





void BreadthFirstSearch_Player1(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool* pGameStatePool, int32_t numTestGameStatesMaxPerDepthLayer, int32_t maxSearchDepth)
{
	pGameStatePool->Stop_Using_AllGameStateObjects();

	pOutNewGameState->Clone_GameStateValues(pInActualGameState);

	int8_t* pActualGameStateValueArray = &pInActualGameState->pValueArray[0];

	int32_t moveCounter = 0;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
		{
			if (Check_PossiblePlayer1CloneMove(i, pActualGameStateValueArray) == true)
			{
				int32_t ixNew = i % ConstGameBoardSizePerDir;
				int32_t iyNew = i / ConstGameBoardSizePerDir;

				CGameStateValues* pGameStateObject = nullptr;
				int32_t GameStateObjectID = -1;

				if (pGameStatePool->Get_UnusedGameStateObject(0, &pGameStateObject, &GameStateObjectID) == false)
				{
					//goto TestMoveGenerationCompleted;
					Evaluate_LeafGameStates_Player1View(pGameStatePool);
					Backpropagate_MinimaxIntegerEvaluationValues(pGameStatePool);


					pGameStatePool->Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID);
					pOutNewGameState->Clone_GameStateValues(pGameStateObject);

					return;
				}

				pGameStateObject->Clone_GameStateValues(pInActualGameState);

				// test move:
				Make_Player1CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
				pGameStateObject->PlayerID = 0;
				pGameStateObject->Use_As_Minimizer();
				moveCounter++;

				if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
				{
					goto Depth0_TestMoveGenerationCompleted;
				}
			}
		}
		else if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		{
			int32_t ixOld = i % ConstGameBoardSizePerDir;
			int32_t iyOld = i / ConstGameBoardSizePerDir;

			int32_t ixMin = max(0, ixOld - 2);
			int32_t iyMin = max(0, iyOld - 2);

			int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
			int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

			for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
			{
				for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
				{
					// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
					if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
					{
						continue;
					}

					if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
					{
						// macht ein Sprung-Z�ge Sinn?
						/*{
							int32_t ixMin = max(0, ixNew - 1);
							int32_t iyMin = max(0, iyNew - 1);

							int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
							int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

							bool badMoveDecision = false;
							bool isolatedPos = true;

							int32_t iiy;
							int8_t gameStateValue;

							for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
							{
								iiy = ConstGameBoardSizePerDir * iy;

								for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
								{
									gameStateValue = pActualGameStateValueArray[ix + iiy];

									if (gameStateValue == ConstGameBoard_Player1)
									{
										isolatedPos = false;
										badMoveDecision = true;
										break;
									}
									if (gameStateValue != ConstGameBoard_Empty)
									{
										isolatedPos = false;
									}
								}

								if (badMoveDecision == true)
								{
									break;
								}

							}

							if (badMoveDecision == true || isolatedPos == true)
							{
								continue;
							}
						} // end of macht ein Sprung-Z�ge Sinn?
						*/

						// next test move:

						CGameStateValues* pGameStateObject = nullptr;
						int32_t GameStateObjectID = -1;

						if (pGameStatePool->Get_UnusedGameStateObject(0, &pGameStateObject, &GameStateObjectID) == false)
						{
							//goto TestMoveGenerationCompleted;
							Evaluate_LeafGameStates_Player1View(pGameStatePool);
							Backpropagate_MinimaxIntegerEvaluationValues(pGameStatePool);


							pGameStatePool->Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID);
							pOutNewGameState->Clone_GameStateValues(pGameStateObject);

							return;
						}

						pGameStateObject->Clone_GameStateValues(pInActualGameState);

						// test move:
						Make_Player1Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
						pGameStateObject->PlayerID = 0;
						pGameStateObject->Use_As_Minimizer();
						moveCounter++;

						if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
						{
							goto Depth0_TestMoveGenerationCompleted;
						}
					}
				}
			}
		} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
	} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

Depth0_TestMoveGenerationCompleted:;

	

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	CGameStateValues* pActualGameState = nullptr;
	pActualGameStateValueArray = nullptr;
	CSimpleLinkedListManager* pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[0];
	int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	int32_t id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer2CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(1, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player2CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
					pGameStateObject->PlayerID = 1;
					pGameStateObject->Use_As_Maximizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth1_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							/*{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player2)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?
							*/
							// next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(1, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player2Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
							pGameStateObject->PlayerID = 1;
							pGameStateObject->Use_As_Maximizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth1_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth1_TestMoveGenerationCompleted:;

	if (maxSearchDepth < 2)
	{
		goto TestMoveGenerationCompleted;
	}

	pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[1];
	NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer1CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(2, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player1CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
					pGameStateObject->PlayerID = 0;
					pGameStateObject->Use_As_Minimizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth2_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							/*{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player1)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?
							*/
							// next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(2, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player1Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
							pGameStateObject->PlayerID = 0;
							pGameStateObject->Use_As_Minimizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth2_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth2_TestMoveGenerationCompleted:;

	if (maxSearchDepth < 3)
	{
		goto TestMoveGenerationCompleted;
	}

	pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[2];
	NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer2CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(3, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player2CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
					pGameStateObject->PlayerID = 1;
					pGameStateObject->Use_As_Maximizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth3_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							/*{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player2)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?
							*/
							// next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(3, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player2Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
							pGameStateObject->PlayerID = 1;
							pGameStateObject->Use_As_Maximizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth3_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth3_TestMoveGenerationCompleted:;

	if (maxSearchDepth < 4)
	{
		goto TestMoveGenerationCompleted;
	}

	pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[3];
	NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer1CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(4, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player1CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
					pGameStateObject->PlayerID = 0;
					pGameStateObject->Use_As_Minimizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth4_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							/*{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player1)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?
							*/
							// next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(4, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player1Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
							pGameStateObject->PlayerID = 0;
							pGameStateObject->Use_As_Minimizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth4_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth4_TestMoveGenerationCompleted:;


TestMoveGenerationCompleted:;

	Evaluate_LeafGameStates_Player1View(pGameStatePool);
	Backpropagate_MinimaxIntegerEvaluationValues(pGameStatePool);


	pGameStatePool->Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID);
	pOutNewGameState->Clone_GameStateValues(pGameStateObject);
}

void BreadthFirstSearch_Player2(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool* pGameStatePool, int32_t numTestGameStatesMaxPerDepthLayer, int32_t maxSearchDepth)
{
	pGameStatePool->Stop_Using_AllGameStateObjects();

	pOutNewGameState->Clone_GameStateValues(pInActualGameState);

	int8_t* pActualGameStateValueArray = &pInActualGameState->pValueArray[0];

	int32_t moveCounter = 0;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
		{
			if (Check_PossiblePlayer2CloneMove(i, pActualGameStateValueArray) == true)
			{
				// next test move:

				int32_t ixNew = i % ConstGameBoardSizePerDir;
				int32_t iyNew = i / ConstGameBoardSizePerDir;

				CGameStateValues* pGameStateObject = nullptr;
				int32_t GameStateObjectID = -1;

				if (pGameStatePool->Get_UnusedGameStateObject(0, &pGameStateObject, &GameStateObjectID) == false)
				{
					//goto TestMoveGenerationCompleted;
					Evaluate_LeafGameStates_Player2View(pGameStatePool);
					Backpropagate_MinimaxIntegerEvaluationValues(pGameStatePool);


					pGameStatePool->Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID);

					//int32_t Player1Score, Player2Score;
					//Calculate_Score(&Player1Score, &Player2Score, &pGameStateObject->pValueArray[0]);
					//Add_To_Log(0, "BestPlayer1Score", Player1Score);
					//Add_To_Log(0, "BestPlayer2Score", Player2Score);
					//Add_To_Log(0, "BestEval", pGameStateObject->iEvaluation);

					pOutNewGameState->Clone_GameStateValues(pGameStateObject);
					return;
				}

				pGameStateObject->Clone_GameStateValues(pInActualGameState);

				// test move:
				Make_Player2CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
				pGameStateObject->PlayerID = 1;
				pGameStateObject->Use_As_Minimizer();
				moveCounter++;

				if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
				{
					goto Depth0_TestMoveGenerationCompleted;
				}
			}
		}
		else if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
		{
			int32_t ixOld = i % ConstGameBoardSizePerDir;
			int32_t iyOld = i / ConstGameBoardSizePerDir;

			int32_t ixMin = max(0, ixOld - 2);
			int32_t iyMin = max(0, iyOld - 2);

			int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
			int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

			for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
			{
				for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
				{
					// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
					if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
					{
						continue;
					}

					if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
					{
						// macht ein Sprung-Z�ge Sinn?
						/*{
							int32_t ixMin = max(0, ixNew - 1);
							int32_t iyMin = max(0, iyNew - 1);

							int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
							int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

							bool badMoveDecision = false;
							bool isolatedPos = true;

							int32_t iiy;
							int8_t gameStateValue;

							for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
							{
								iiy = ConstGameBoardSizePerDir * iy;

								for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
								{
									gameStateValue = pActualGameStateValueArray[ix + iiy];

									if (gameStateValue == ConstGameBoard_Player2)
									{
										isolatedPos = false;
										badMoveDecision = true;
										break;
									}
									if (gameStateValue != ConstGameBoard_Empty)
									{
										isolatedPos = false;
									}
								}

								if (badMoveDecision == true)
								{
									break;
								}

							}

							if (badMoveDecision == true || isolatedPos == true)
							{
								continue;
							}
						} // end of macht ein Sprung-Z�ge Sinn?
						*/

						// next test move:

						CGameStateValues* pGameStateObject = nullptr;
						int32_t GameStateObjectID = -1;

						if (pGameStatePool->Get_UnusedGameStateObject(0, &pGameStateObject, &GameStateObjectID) == false)
						{
							//goto TestMoveGenerationCompleted;
							Evaluate_LeafGameStates_Player2View(pGameStatePool);
							Backpropagate_MinimaxIntegerEvaluationValues(pGameStatePool);


							pGameStatePool->Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID);

							//int32_t Player1Score, Player2Score;
							//Calculate_Score(&Player1Score, &Player2Score, &pGameStateObject->pValueArray[0]);
							//Add_To_Log(0, "BestPlayer1Score", Player1Score);
							//Add_To_Log(0, "BestPlayer2Score", Player2Score);
							//Add_To_Log(0, "BestEval", pGameStateObject->iEvaluation);

							pOutNewGameState->Clone_GameStateValues(pGameStateObject);
							return;
						}

						pGameStateObject->Clone_GameStateValues(pInActualGameState);

						// test move:
						Make_Player2Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
						pGameStateObject->PlayerID = 1;
						pGameStateObject->Use_As_Minimizer();
						moveCounter++;

						if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
						{
							goto Depth0_TestMoveGenerationCompleted;
						}
					}
				}
			}
		} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
	} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

Depth0_TestMoveGenerationCompleted:;

	

	CGameStateValues* pActualGameState = nullptr;
	pActualGameStateValueArray = nullptr;
	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	CSimpleLinkedListManager* pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[0];
	int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	int32_t id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer1CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(1, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player1CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
					pGameStateObject->PlayerID = 0;
					pGameStateObject->Use_As_Maximizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth1_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							/*{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player1)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?
							*/
							// next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(1, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player1Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
							pGameStateObject->PlayerID = 0;
							pGameStateObject->Use_As_Maximizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth1_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth1_TestMoveGenerationCompleted:;

	if (maxSearchDepth < 2)
	{
		goto TestMoveGenerationCompleted;
	}

	pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[1];
	NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer2CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(2, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player2CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
					pGameStateObject->PlayerID = 1;
					pGameStateObject->Use_As_Minimizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth2_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							/*{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player2)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?
							*/
							// next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(2, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player2Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
							pGameStateObject->PlayerID = 1;
							pGameStateObject->Use_As_Minimizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth2_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth2_TestMoveGenerationCompleted:;

	if (maxSearchDepth < 3)
	{
		goto TestMoveGenerationCompleted;
	}

	pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[2];
	NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer1CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(3, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player1CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
					pGameStateObject->PlayerID = 0;
					pGameStateObject->Use_As_Maximizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth3_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							/*{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player1)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?
							*/
							// next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(3, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player1Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
							pGameStateObject->PlayerID = 0;
							pGameStateObject->Use_As_Maximizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth3_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth3_TestMoveGenerationCompleted:;

	if (maxSearchDepth < 4)
	{
		goto TestMoveGenerationCompleted;
	}

	pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[3];
	NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer2CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(4, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player2CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
					pGameStateObject->PlayerID = 1;
					pGameStateObject->Use_As_Minimizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth4_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							/*{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player2)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?
							*/
							// next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(4, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player2Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
							pGameStateObject->PlayerID = 1;
							pGameStateObject->Use_As_Minimizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth4_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth4_TestMoveGenerationCompleted:;



TestMoveGenerationCompleted:;

	Evaluate_LeafGameStates_Player2View(pGameStatePool);
	Backpropagate_MinimaxIntegerEvaluationValues(pGameStatePool);


	pGameStatePool->Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID);

	//int32_t Player1Score, Player2Score;
	//Calculate_Score(&Player1Score, &Player2Score, &pGameStateObject->pValueArray[0]);
	//Add_To_Log(0, "BestPlayer1Score", Player1Score);
	//Add_To_Log(0, "BestPlayer2Score", Player2Score);
	//Add_To_Log(0, "BestEval", pGameStateObject->iEvaluation);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);
}

void BreadthFirstSearch_Player1(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool* pGameStatePool, int32_t numTestGameStatesMaxPerDepthLayer, int32_t maxSearchDepth, CRandomNumbersNN* pRandomNumbers, float movementProbability_SearchDepth2, float movementProbability_SearchDepth3, float movementProbability_SearchDepth4)
{
	pGameStatePool->Stop_Using_AllGameStateObjects();

	pOutNewGameState->Clone_GameStateValues(pInActualGameState);

	int8_t* pActualGameStateValueArray = &pInActualGameState->pValueArray[0];

	int32_t moveCounter = 0;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
		{
			if (Check_PossiblePlayer1CloneMove(i, pActualGameStateValueArray) == true)
			{
				int32_t ixNew = i % ConstGameBoardSizePerDir;
				int32_t iyNew = i / ConstGameBoardSizePerDir;

				CGameStateValues* pGameStateObject = nullptr;
				int32_t GameStateObjectID = -1;

				if (pGameStatePool->Get_UnusedGameStateObject(0, &pGameStateObject, &GameStateObjectID) == false)
				{
					//goto TestMoveGenerationCompleted;
					Evaluate_LeafGameStates_Player1View(pGameStatePool);
					Backpropagate_MinimaxIntegerEvaluationValues(pGameStatePool);


					pGameStatePool->Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID);
					pOutNewGameState->Clone_GameStateValues(pGameStateObject);
					return;
				}

				pGameStateObject->Clone_GameStateValues(pInActualGameState);

				// test move:
				Make_Player1CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
				pGameStateObject->PlayerID = 0;
				pGameStateObject->Use_As_Minimizer();
				moveCounter++;

				if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
				{
					goto Depth0_TestMoveGenerationCompleted;
				}
			}
		}
		else if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		{
			int32_t ixOld = i % ConstGameBoardSizePerDir;
			int32_t iyOld = i / ConstGameBoardSizePerDir;

			int32_t ixMin = max(0, ixOld - 2);
			int32_t iyMin = max(0, iyOld - 2);

			int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
			int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

			for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
			{
				for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
				{
					// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
					if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
					{
						continue;
					}

					if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
					{
						// macht ein Sprung-Z�ge Sinn?
						/*{
							int32_t ixMin = max(0, ixNew - 1);
							int32_t iyMin = max(0, iyNew - 1);

							int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
							int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

							bool badMoveDecision = false;
							bool isolatedPos = true;

							int32_t iiy;
							int8_t gameStateValue;

							for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
							{
								iiy = ConstGameBoardSizePerDir * iy;

								for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
								{
									gameStateValue = pActualGameStateValueArray[ix + iiy];

									if (gameStateValue == ConstGameBoard_Player1)
									{
										isolatedPos = false;
										badMoveDecision = true;
										break;
									}
									if (gameStateValue != ConstGameBoard_Empty)
									{
										isolatedPos = false;
									}
								}

								if (badMoveDecision == true)
								{
									break;
								}

							}

							if (badMoveDecision == true || isolatedPos == true)
							{
								continue;
							}
						} // end of macht ein Sprung-Z�ge Sinn?
						*/

						  // next test move:

						CGameStateValues* pGameStateObject = nullptr;
						int32_t GameStateObjectID = -1;

						if (pGameStatePool->Get_UnusedGameStateObject(0, &pGameStateObject, &GameStateObjectID) == false)
						{
							//goto TestMoveGenerationCompleted;
							Evaluate_LeafGameStates_Player1View(pGameStatePool);
							Backpropagate_MinimaxIntegerEvaluationValues(pGameStatePool);


							pGameStatePool->Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID);
							pOutNewGameState->Clone_GameStateValues(pGameStateObject);
							return;
						}

						pGameStateObject->Clone_GameStateValues(pInActualGameState);

						// test move:
						Make_Player1Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
						pGameStateObject->PlayerID = 0;
						pGameStateObject->Use_As_Minimizer();
						moveCounter++;

						if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
						{
							goto Depth0_TestMoveGenerationCompleted;
						}
					}
				}
			}
		} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
	} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

Depth0_TestMoveGenerationCompleted:;

	

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	CGameStateValues* pActualGameState = nullptr;
	pActualGameStateValueArray = nullptr;
	CSimpleLinkedListManager* pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[0];
	int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	int32_t id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer2CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(1, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player2CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
					pGameStateObject->PlayerID = 1;
					pGameStateObject->Use_As_Maximizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth1_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							/*{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player2)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?
							*/
							  // next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(1, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player2Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
							pGameStateObject->PlayerID = 1;
							pGameStateObject->Use_As_Maximizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth1_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth1_TestMoveGenerationCompleted:;

	if (maxSearchDepth < 2)
	{
		goto TestMoveGenerationCompleted;
	}

	pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[1];
	NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f) > movementProbability_SearchDepth2)
				continue;

			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer1CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(2, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player1CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
					pGameStateObject->PlayerID = 0;
					pGameStateObject->Use_As_Minimizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth2_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							/*{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player1)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?
							*/
							  // next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(2, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player1Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
							pGameStateObject->PlayerID = 0;
							pGameStateObject->Use_As_Minimizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth2_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth2_TestMoveGenerationCompleted:;

	if (maxSearchDepth < 3)
	{
		goto TestMoveGenerationCompleted;
	}

	pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[2];
	NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f) > movementProbability_SearchDepth3)
				continue;

			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer2CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(3, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player2CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
					pGameStateObject->PlayerID = 1;
					pGameStateObject->Use_As_Maximizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth3_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							/*{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player2)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?
							*/
							  // next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(3, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player2Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
							pGameStateObject->PlayerID = 1;
							pGameStateObject->Use_As_Maximizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth3_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth3_TestMoveGenerationCompleted:;

	if (maxSearchDepth < 4)
	{
		goto TestMoveGenerationCompleted;
	}

	pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[3];
	NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f) > movementProbability_SearchDepth4)
				continue;

			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer1CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(4, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player1CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
					pGameStateObject->PlayerID = 0;
					pGameStateObject->Use_As_Minimizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth4_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							/*{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player1)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?
							*/
							  // next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(4, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player1Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
							pGameStateObject->PlayerID = 0;
							pGameStateObject->Use_As_Minimizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth4_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth4_TestMoveGenerationCompleted:;


TestMoveGenerationCompleted:;

	Evaluate_LeafGameStates_Player1View(pGameStatePool);
	Backpropagate_MinimaxIntegerEvaluationValues(pGameStatePool);


	pGameStatePool->Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID);
	pOutNewGameState->Clone_GameStateValues(pGameStateObject);
}

void BreadthFirstSearch_Player2(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool* pGameStatePool, int32_t numTestGameStatesMaxPerDepthLayer, int32_t maxSearchDepth, CRandomNumbersNN* pRandomNumbers, float movementProbability_SearchDepth2, float movementProbability_SearchDepth3, float movementProbability_SearchDepth4)
{
	pGameStatePool->Stop_Using_AllGameStateObjects();

	pOutNewGameState->Clone_GameStateValues(pInActualGameState);

	int8_t* pActualGameStateValueArray = &pInActualGameState->pValueArray[0];

	int32_t moveCounter = 0;

	for (int32_t i = 0; i < ConstGameBoardSize; i++)
	{
		if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
		{
			if (Check_PossiblePlayer2CloneMove(i, pActualGameStateValueArray) == true)
			{
				// next test move:

				int32_t ixNew = i % ConstGameBoardSizePerDir;
				int32_t iyNew = i / ConstGameBoardSizePerDir;

				CGameStateValues* pGameStateObject = nullptr;
				int32_t GameStateObjectID = -1;

				if (pGameStatePool->Get_UnusedGameStateObject(0, &pGameStateObject, &GameStateObjectID) == false)
				{
					//goto TestMoveGenerationCompleted;
					Evaluate_LeafGameStates_Player2View(pGameStatePool);
					Backpropagate_MinimaxIntegerEvaluationValues(pGameStatePool);


					pGameStatePool->Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID);

					//int32_t Player1Score, Player2Score;
					//Calculate_Score(&Player1Score, &Player2Score, &pGameStateObject->pValueArray[0]);
					//Add_To_Log(0, "BestPlayer1Score", Player1Score);
					//Add_To_Log(0, "BestPlayer2Score", Player2Score);
					//Add_To_Log(0, "BestEval", pGameStateObject->iEvaluation);

					pOutNewGameState->Clone_GameStateValues(pGameStateObject);
					return;
				}

				pGameStateObject->Clone_GameStateValues(pInActualGameState);

				// test move:
				Make_Player2CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
				pGameStateObject->PlayerID = 1;
				pGameStateObject->Use_As_Minimizer();
				moveCounter++;

				if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
				{
					goto Depth0_TestMoveGenerationCompleted;
				}
			}
		}
		else if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
		{
			int32_t ixOld = i % ConstGameBoardSizePerDir;
			int32_t iyOld = i / ConstGameBoardSizePerDir;

			int32_t ixMin = max(0, ixOld - 2);
			int32_t iyMin = max(0, iyOld - 2);

			int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
			int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

			for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
			{
				for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
				{
					// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
					if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
					{
						continue;
					}

					if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
					{
						// macht ein Sprung-Z�ge Sinn?
						/*{
							int32_t ixMin = max(0, ixNew - 1);
							int32_t iyMin = max(0, iyNew - 1);

							int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
							int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

							bool badMoveDecision = false;
							bool isolatedPos = true;

							int32_t iiy;
							int8_t gameStateValue;

							for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
							{
								iiy = ConstGameBoardSizePerDir * iy;

								for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
								{
									gameStateValue = pActualGameStateValueArray[ix + iiy];

									if (gameStateValue == ConstGameBoard_Player2)
									{
										isolatedPos = false;
										badMoveDecision = true;
										break;
									}
									if (gameStateValue != ConstGameBoard_Empty)
									{
										isolatedPos = false;
									}
								}

								if (badMoveDecision == true)
								{
									break;
								}

							}

							if (badMoveDecision == true || isolatedPos == true)
							{
								continue;
							}
						} // end of macht ein Sprung-Z�ge Sinn?
						*/

						  // next test move:

						CGameStateValues* pGameStateObject = nullptr;
						int32_t GameStateObjectID = -1;

						if (pGameStatePool->Get_UnusedGameStateObject(0, &pGameStateObject, &GameStateObjectID) == false)
						{
							//goto TestMoveGenerationCompleted;
							Evaluate_LeafGameStates_Player2View(pGameStatePool);
							Backpropagate_MinimaxIntegerEvaluationValues(pGameStatePool);


							pGameStatePool->Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID);

							//int32_t Player1Score, Player2Score;
							//Calculate_Score(&Player1Score, &Player2Score, &pGameStateObject->pValueArray[0]);
							//Add_To_Log(0, "BestPlayer1Score", Player1Score);
							//Add_To_Log(0, "BestPlayer2Score", Player2Score);
							//Add_To_Log(0, "BestEval", pGameStateObject->iEvaluation);

							pOutNewGameState->Clone_GameStateValues(pGameStateObject);
							return;
						}

						pGameStateObject->Clone_GameStateValues(pInActualGameState);

						// test move:
						Make_Player2Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
						pGameStateObject->PlayerID = 1;
						pGameStateObject->Use_As_Minimizer();
						moveCounter++;

						if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
						{
							goto Depth0_TestMoveGenerationCompleted;
						}
					}
				}
			}
		} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
	} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

Depth0_TestMoveGenerationCompleted:;

	

	CGameStateValues* pActualGameState = nullptr;
	pActualGameStateValueArray = nullptr;
	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	CSimpleLinkedListManager* pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[0];
	int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	int32_t id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer1CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(1, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player1CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
					pGameStateObject->PlayerID = 0;
					pGameStateObject->Use_As_Maximizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth1_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							/*{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player1)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?
							*/
							  // next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(1, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player1Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
							pGameStateObject->PlayerID = 0;
							pGameStateObject->Use_As_Maximizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth1_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth1_TestMoveGenerationCompleted:;

	if (maxSearchDepth < 2)
	{
		goto TestMoveGenerationCompleted;
	}

	pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[1];
	NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f) > movementProbability_SearchDepth2)
				continue;

			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer2CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(2, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player2CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
					pGameStateObject->PlayerID = 1;
					pGameStateObject->Use_As_Minimizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth2_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							/*{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player2)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?
							*/
							  // next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(2, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player2Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
							pGameStateObject->PlayerID = 1;
							pGameStateObject->Use_As_Minimizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth2_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth2_TestMoveGenerationCompleted:;

	if (maxSearchDepth < 3)
	{
		goto TestMoveGenerationCompleted;
	}

	pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[2];
	NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f) > movementProbability_SearchDepth3)
				continue;

			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer1CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(3, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player1CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
					pGameStateObject->PlayerID = 0;
					pGameStateObject->Use_As_Maximizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth3_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player1)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							/*{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player1)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?
							*/
							  // next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(3, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player1Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
							pGameStateObject->PlayerID = 0;
							pGameStateObject->Use_As_Maximizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth3_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth3_TestMoveGenerationCompleted:;

	if (maxSearchDepth < 4)
	{
		goto TestMoveGenerationCompleted;
	}

	pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[3];
	NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	id = 0;

	moveCounter = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		pActualGameState = &pGameStatePool->pGameStateArray[id];
		pActualGameStateValueArray = &pActualGameState->pValueArray[0];

		for (int32_t i = 0; i < ConstGameBoardSize; i++)
		{
			if (pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f) > movementProbability_SearchDepth4)
				continue;

			if (pActualGameStateValueArray[i] == ConstGameBoard_Empty)
			{
				if (Check_PossiblePlayer2CloneMove(i, pActualGameStateValueArray) == true)
				{
					// next test move:

					int32_t ixNew = i % ConstGameBoardSizePerDir;
					int32_t iyNew = i / ConstGameBoardSizePerDir;

					if (pGameStatePool->Get_UnusedGameStateObject(4, &pGameStateObject, &GameStateObjectID) == false)
					{
						goto TestMoveGenerationCompleted;
					}

					pGameStateObject->Clone_GameStateValues(pActualGameState);

					// test move:
					Make_Player2CloneMove(ixNew, iyNew, &pGameStateObject->pValueArray[0]);
					pGameStateObject->PlayerID = 1;
					pGameStateObject->Use_As_Minimizer();
					pActualGameState->LeafNode = false;
					pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
					moveCounter++;

					if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
					{
						goto Depth4_TestMoveGenerationCompleted;
					}
				}
			}
			else if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
			{
				int32_t ixOld = i % ConstGameBoardSizePerDir;
				int32_t iyOld = i / ConstGameBoardSizePerDir;

				int32_t ixMin = max(0, ixOld - 2);
				int32_t iyMin = max(0, iyOld - 2);

				int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixOld + 3);
				int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyOld + 3);

				for (int32_t iyNew = iyMin; iyNew < iyMaxPlus1; iyNew++)
				{
					for (int32_t ixNew = ixMin; ixNew < ixMaxPlus1; ixNew++)
					{
						// An dieser Stelle nur Sprung-Z�ge ber�cksichtigen:
						if (abs(ixNew - ixOld) < 2 && abs(iyNew - iyOld) < 2)
						{
							continue;
						}

						if (pActualGameStateValueArray[ixNew + ConstGameBoardSizePerDir * iyNew] == ConstGameBoard_Empty)
						{
							// macht ein Sprung-Z�ge Sinn?
							/*{
								int32_t ixMin = max(0, ixNew - 1);
								int32_t iyMin = max(0, iyNew - 1);

								int32_t ixMaxPlus1 = min(ConstGameBoardSizePerDir, ixNew + 2);
								int32_t iyMaxPlus1 = min(ConstGameBoardSizePerDir, iyNew + 2);

								bool badMoveDecision = false;
								bool isolatedPos = true;

								int32_t iiy;
								int8_t gameStateValue;

								for (int32_t iy = iyMin; iy < iyMaxPlus1; iy++)
								{
									iiy = ConstGameBoardSizePerDir * iy;

									for (int32_t ix = ixMin; ix < ixMaxPlus1; ix++)
									{
										gameStateValue = pActualGameStateValueArray[ix + iiy];

										if (gameStateValue == ConstGameBoard_Player2)
										{
											isolatedPos = false;
											badMoveDecision = true;
											break;
										}
										if (gameStateValue != ConstGameBoard_Empty)
										{
											isolatedPos = false;
										}
									}

									if (badMoveDecision == true)
									{
										break;
									}

								}

								if (badMoveDecision == true || isolatedPos == true)
								{
									continue;
								}
							} // end of macht ein Sprung-Z�ge Sinn?
							*/
							  // next test move:

							if (pGameStatePool->Get_UnusedGameStateObject(4, &pGameStateObject, &GameStateObjectID) == false)
							{
								goto TestMoveGenerationCompleted;
							}

							pGameStateObject->Clone_GameStateValues(pActualGameState);

							// test move:
							Make_Player2Move(ixOld, iyOld, ixNew, iyNew, &pGameStateObject->pValueArray[0]);
							pGameStateObject->PlayerID = 1;
							pGameStateObject->Use_As_Minimizer();
							pActualGameState->LeafNode = false;
							pGameStateObject->IDofPrevGameState = pActualGameState->IDofGameState;
							moveCounter++;

							if (moveCounter >= numTestGameStatesMaxPerDepthLayer)
							{
								goto Depth4_TestMoveGenerationCompleted;
							}
						}
					}
				}
			} // end of if (pActualGameStateValueArray[i] == ConstGameBoard_Player2)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

Depth4_TestMoveGenerationCompleted:;



TestMoveGenerationCompleted:;

	Evaluate_LeafGameStates_Player2View(pGameStatePool);
	Backpropagate_MinimaxIntegerEvaluationValues(pGameStatePool);


	pGameStatePool->Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID);

	//int32_t Player1Score, Player2Score;
	//Calculate_Score(&Player1Score, &Player2Score, &pGameStateObject->pValueArray[0]);
	//Add_To_Log(0, "BestPlayer1Score", Player1Score);
	//Add_To_Log(0, "BestPlayer2Score", Player2Score);
	//Add_To_Log(0, "BestEval", pGameStateObject->iEvaluation);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);
}



