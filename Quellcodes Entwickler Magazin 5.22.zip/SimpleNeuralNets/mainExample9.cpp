#include <iostream>
#include "NeuralNet.h"

using namespace std;

//#define EvolutionVariant1
//#define EvolutionVariant2
//#define EvolutionVariant3
#define EvolutionVariant4

inline float ScaledSigmoidOutput(float neuronInput)
{
	// von 0.0f bis 1.0f:
	return 1.0f / (1.0f + exp(-10.0f * neuronInput));
}

inline float LinearOutput(float neuronInput)
{
	return neuronInput;
}

class CDecisionBrain2
{
public:

	uint32_t NumInputNeurons = 4;
	uint32_t NumBiasNeurons = 1;
	uint32_t NumHiddenNeurons = 20;
	uint32_t NumOutputNeurons = 1;

	uint32_t NumNeurons = NumInputNeurons + NumHiddenNeurons + NumOutputNeurons + NumBiasNeurons;

	uint32_t BiasNeuronID = NumInputNeurons;
	uint32_t FirstHiddenNeuronID = NumInputNeurons + NumBiasNeurons;
	uint32_t OutputNeuronID = NumInputNeurons + NumHiddenNeurons + NumBiasNeurons;

	CNeuron *pNeuronArray = nullptr;

	CRandomNumbersNN RandomNumbers;

	CDecisionBrain2()
	{
		pNeuronArray = new (std::nothrow) CNeuron[NumNeurons];

		uint32_t i, j, id;

		for (i = 0; i < NumNeurons; i++)
			pNeuronArray[i].Connect_With_Brain(pNeuronArray);

		for (i = 0; i < NumInputNeurons; i++)
		{
			pNeuronArray[i].Use_As_InputNeuron();
			pNeuronArray[i].Init_OutputSynapses(NumHiddenNeurons);
			pNeuronArray[i].Randomize_OutputSynapsePlasticities(&RandomNumbers, -0.2f, 0.2f);

			for (j = 0; j < NumHiddenNeurons; j++)
			{
				id = FirstHiddenNeuronID + j;

				pNeuronArray[i].Connect_With_ReceiverNeuron(id, /*SynapseID:*/ j);
			}
		}

		pNeuronArray[BiasNeuronID].Use_As_BiasNeuron();
		pNeuronArray[BiasNeuronID].Set_BiasNeuronOutput(-1.0f);
		pNeuronArray[BiasNeuronID].Init_OutputSynapses(NumHiddenNeurons);
		pNeuronArray[BiasNeuronID].Randomize_OutputSynapsePlasticities(&RandomNumbers, -0.2f, 0.2f);

		for (j = 0; j < NumHiddenNeurons; j++)
		{
			id = FirstHiddenNeuronID + j;

			pNeuronArray[BiasNeuronID].Connect_With_ReceiverNeuron(id, /*SynapseID:*/ j);
		}


		for (i = 0; i < NumHiddenNeurons; i++)
		{
			id = FirstHiddenNeuronID + i;
			pNeuronArray[id].Use_As_HiddenNeuron();
			pNeuronArray[id].Init_OutputSynapses(NumOutputNeurons);
			pNeuronArray[id].Randomize_OutputSynapsePlasticities(&RandomNumbers, -0.2f, 0.2f);
			pNeuronArray[id].Set_ActivationFunction(ScaledSigmoidOutput);
			pNeuronArray[id].Connect_With_ReceiverNeuron(OutputNeuronID, /*SynapseID:*/ 0);
		}

		pNeuronArray[OutputNeuronID].Use_As_OutputNeuron();
		pNeuronArray[OutputNeuronID].Set_ActivationFunction(LinearOutput);
		pNeuronArray[OutputNeuronID].Set_LearningRate(0.2f);
		pNeuronArray[OutputNeuronID].Set_ErrorFactors(1.0f, 0.005f);	
	}

	~CDecisionBrain2()
	{
		delete[] pNeuronArray;
		pNeuronArray = nullptr;
	}

	// Kopierkonstruktor l�schen:
	CDecisionBrain2(const CDecisionBrain2 &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CDecisionBrain2& operator=(const CDecisionBrain2 &originalObject) = delete;

	void RandomChange_OutputSynapsePlasticities(uint64_t newSeed, float minPlasticity, float maxPlasticity)
	{
		RandomNumbers.Change_Seed(newSeed);

		uint32_t i, id;

		for (i = 0; i < NumInputNeurons; i++)
			pNeuronArray[i].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticity, maxPlasticity);

		pNeuronArray[BiasNeuronID].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticity, maxPlasticity);

		for (i = 0; i < NumHiddenNeurons; i++)
		{
			id = FirstHiddenNeuronID + i;
			pNeuronArray[id].Randomize_OutputSynapsePlasticities(&RandomNumbers, minPlasticity, maxPlasticity);
		}
	}

	void Clone_OutputSynapsePlasticities(CDecisionBrain2 *pOriginalBrain)
	{
		uint32_t i, j, id, numOfOutputSynapses;

		for (i = 0; i < NumInputNeurons; i++)
		{
			numOfOutputSynapses = pNeuronArray[i].NumOfOutputSynapses;

			for (j = 0; j < numOfOutputSynapses; j++)
				pNeuronArray[i].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[i].pOutputSynapsePlasticityArray[j];
		}

		numOfOutputSynapses = pNeuronArray[BiasNeuronID].NumOfOutputSynapses;

		for (j = 0; j < numOfOutputSynapses; j++)
			pNeuronArray[BiasNeuronID].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[BiasNeuronID].pOutputSynapsePlasticityArray[j];

		for (i = 0; i < NumHiddenNeurons; i++)
		{
			id = FirstHiddenNeuronID + i;

			numOfOutputSynapses = pNeuronArray[id].NumOfOutputSynapses;

			for (j = 0; j < numOfOutputSynapses; j++)
				pNeuronArray[id].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[id].pOutputSynapsePlasticityArray[j];
		}
	}

	void Clone_OutputSynapsePlasticities(CDecisionBrain2 *pOriginalBrain, float variance, uint64_t newSeed)
	{
		RandomNumbers.Change_Seed(newSeed);

		uint32_t i, j, id, numOfOutputSynapses;

		for (i = 0; i < NumInputNeurons; i++)
		{
			numOfOutputSynapses = pNeuronArray[i].NumOfOutputSynapses;

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				pNeuronArray[i].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[i].pOutputSynapsePlasticityArray[j];
				pNeuronArray[i].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-variance, variance);
			}
		}

		numOfOutputSynapses = pNeuronArray[BiasNeuronID].NumOfOutputSynapses;

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			pNeuronArray[BiasNeuronID].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[BiasNeuronID].pOutputSynapsePlasticityArray[j];
			pNeuronArray[BiasNeuronID].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-variance, variance);
		}

		for (i = 0; i < NumHiddenNeurons; i++)
		{
			id = FirstHiddenNeuronID + i;

			numOfOutputSynapses = pNeuronArray[id].NumOfOutputSynapses;

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				pNeuronArray[id].pOutputSynapsePlasticityArray[j] = pOriginalBrain->pNeuronArray[id].pOutputSynapsePlasticityArray[j];
				pNeuronArray[id].pOutputSynapsePlasticityArray[j] += RandomNumbers.Get_FloatNumber(-variance, variance);
			}
		}
	}

	void Combine_OutputSynapsePlasticities(CDecisionBrain2 *pParentBrain1, CDecisionBrain2 *pParentBrain2, float minWeight1, uint64_t newSeed)
	{
		RandomNumbers.Change_Seed(newSeed);

		uint32_t i, j, id, numOfOutputSynapses;

		float weight1, weight2;

		float newPlasticity;

		for (i = 0; i < NumInputNeurons; i++)
		{
			numOfOutputSynapses = pNeuronArray[i].NumOfOutputSynapses;

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				weight1 = RandomNumbers.Get_FloatNumber(minWeight1, 1.0f);
				weight2 = 1.0f - weight1;
				newPlasticity = weight1*pParentBrain1->pNeuronArray[i].pOutputSynapsePlasticityArray[j];
				newPlasticity += weight2*pParentBrain2->pNeuronArray[i].pOutputSynapsePlasticityArray[j];

				pNeuronArray[i].pOutputSynapsePlasticityArray[j] = newPlasticity;
			}
		}

		numOfOutputSynapses = pNeuronArray[BiasNeuronID].NumOfOutputSynapses;

		for (j = 0; j < numOfOutputSynapses; j++)
		{
			weight1 = RandomNumbers.Get_FloatNumber(minWeight1, 1.0f);
			weight2 = 1.0f - weight1;
			newPlasticity = weight1*pParentBrain1->pNeuronArray[BiasNeuronID].pOutputSynapsePlasticityArray[j];
			newPlasticity += weight2*pParentBrain2->pNeuronArray[BiasNeuronID].pOutputSynapsePlasticityArray[j];

			pNeuronArray[BiasNeuronID].pOutputSynapsePlasticityArray[j] = newPlasticity;
		}

		for (i = 0; i < NumHiddenNeurons; i++)
		{
			id = FirstHiddenNeuronID + i;

			numOfOutputSynapses = pNeuronArray[id].NumOfOutputSynapses;

			for (j = 0; j < numOfOutputSynapses; j++)
			{
				weight1 = RandomNumbers.Get_FloatNumber(minWeight1, 1.0f);
				weight2 = 1.0f - weight1;
				newPlasticity = weight1*pParentBrain1->pNeuronArray[id].pOutputSynapsePlasticityArray[j];
				newPlasticity += weight2*pParentBrain2->pNeuronArray[id].pOutputSynapsePlasticityArray[j];

				pNeuronArray[id].pOutputSynapsePlasticityArray[j] = newPlasticity;
			}
		}
	}

	float Calculate_Output(const float *pInputPattern)
	{
		uint32_t i;

		for (i = 0; i < NumInputNeurons; i++)
		{
			pNeuronArray[i].Set_Input(pInputPattern[i]);
			pNeuronArray[i].Propagate_SynapticOutput();
		}

		pNeuronArray[BiasNeuronID].Propagate_SynapticOutput();

		uint32_t id;

		for (i = 0; i < NumHiddenNeurons; i++)
		{
			id = FirstHiddenNeuronID + i;

			pNeuronArray[id].Calculate_NeuronOutput();
			pNeuronArray[id].Propagate_SynapticOutput();
		}

		pNeuronArray[OutputNeuronID].Calculate_NeuronOutput();

		return pNeuronArray[OutputNeuronID].NeuronOutput;
	}

	float Calculate_Error(float desiredOutput)
	{
		return pNeuronArray[OutputNeuronID].Calculate_Error(desiredOutput);
	}

}; // end of class CDecisionBrain2





/*
Mit Hilfe der vom neuronalen Netz ausgegebenen Werte k�nnte man beispielsweise auf die in einem
Array gespeicherten Funktionszeiger zugreifen. 
Hinweis: Die Funktionen, auf welche die besagten Zeiger verweisen, k�nnten dann die vom
neuronalen Netz vorgeschlagenen Aktionen ausf�hren!
*/

/*
int main(void)
{
	// values unequal to -1.0f, 0.0f or 1.0f can also be used!

	float DecisionPattern1[4] = { 0.0f, 0.0f, 0.0f, 0.0f };
	float DecisionPattern2[4] = { 1.0f, 0.0f, 0.0f, 0.0f };
	float DecisionPattern3[4] = { 0.0f, 1.0f, 0.0f, 0.0f };
	float DecisionPattern4[4] = { 0.0f, 0.0f, 1.0f, 0.0f };
	float DecisionPattern5[4] = { 0.0f, 0.0f, 0.0f, 1.0f };
	float DecisionPattern6[4] = { 1.0f, 1.0f, 0.0f, 0.0f };
	float DecisionPattern7[4] = { 1.0f, 0.0f, 1.0f, 0.0f };
	float DecisionPattern8[4] = { 1.0f, 0.0f, 0.0f, 1.0f };
	float DecisionPattern9[4] = { 0.0f, 1.0f, 1.0f, 0.0f };
	float DecisionPattern10[4] = { 0.0f, 1.0f, 0.0f, 1.0f };
	float DecisionPattern11[4] = { 0.0f, 0.0f, 1.0f, 1.0f };
	float DecisionPattern12[4] = { 0.0f, 1.0f, 1.0f, 1.0f };
	float DecisionPattern13[4] = { 1.0f, 0.0f, 1.0f, 1.0f };
	float DecisionPattern14[4] = { 1.0f, 1.0f, 0.0f, 1.0f };
	float DecisionPattern15[4] = { 1.0f, 1.0f, 1.0f, 0.0f };
	float DecisionPattern16[4] = { 1.0f, 1.0f, 1.0f, 1.0f };
	
	
	static constexpr uint32_t PopulationSize = 10;

	static CDecisionBrain2 BrainArray[PopulationSize];

	static float errorArray[PopulationSize];

	CRandomNumbersNN RandomNumbers;

	uint32_t i;
	uint64_t seed = 1;

	
	float minPlasticity = -0.2f;
	float maxPlasticity = 0.2f;

	for (i = 0; i < PopulationSize; i++)
		BrainArray[i].RandomChange_OutputSynapsePlasticities(seed++, minPlasticity, maxPlasticity);

	uint32_t numGenerationsMax = 20000;
	uint32_t generation = 0;

	uint32_t IdOfBestFittedNet;
	uint32_t IdOfSecondBestFittedNet;


	uint32_t IdOfWorstFittedNet;
	uint32_t IdOfSecondWorstFittedNet;

	float minError;
	float secondMinError;

	float maxError;
	float secondMaxError;

	// start evolution:

	for (uint32_t j = 0; j < numGenerationsMax; j++)
	{
		generation++;

		for (i = 0; i < PopulationSize; i++)
		{
			errorArray[i] = 0.0f;

			BrainArray[i].Calculate_Output(DecisionPattern1);
			errorArray[i] += BrainArray[i].Calculate_Error(0.001f);

			BrainArray[i].Calculate_Output(DecisionPattern2);
			errorArray[i] += BrainArray[i].Calculate_Error(0.11f);

			BrainArray[i].Calculate_Output(DecisionPattern3);
			errorArray[i] += BrainArray[i].Calculate_Error(0.21f);

			BrainArray[i].Calculate_Output(DecisionPattern4);
			errorArray[i] += BrainArray[i].Calculate_Error(0.31f);

			BrainArray[i].Calculate_Output(DecisionPattern5);
			errorArray[i] += BrainArray[i].Calculate_Error(0.41f);

			BrainArray[i].Calculate_Output(DecisionPattern6);
			errorArray[i] += BrainArray[i].Calculate_Error(0.51f);

			BrainArray[i].Calculate_Output(DecisionPattern7);
			errorArray[i] += BrainArray[i].Calculate_Error(0.61f);

			BrainArray[i].Calculate_Output(DecisionPattern8);
			errorArray[i] += BrainArray[i].Calculate_Error(0.71f);

			BrainArray[i].Calculate_Output(DecisionPattern9);
			errorArray[i] += BrainArray[i].Calculate_Error(0.81f);

			BrainArray[i].Calculate_Output(DecisionPattern10);
			errorArray[i] += BrainArray[i].Calculate_Error(0.91f);

			BrainArray[i].Calculate_Output(DecisionPattern11);
			errorArray[i] += BrainArray[i].Calculate_Error(1.01f);

			BrainArray[i].Calculate_Output(DecisionPattern12);
			errorArray[i] += BrainArray[i].Calculate_Error(1.11f);

			BrainArray[i].Calculate_Output(DecisionPattern13);
			errorArray[i] += BrainArray[i].Calculate_Error(1.21f);

			BrainArray[i].Calculate_Output(DecisionPattern14);
			errorArray[i] += BrainArray[i].Calculate_Error(1.31f);

			BrainArray[i].Calculate_Output(DecisionPattern15);
			errorArray[i] += BrainArray[i].Calculate_Error(1.41f);

			BrainArray[i].Calculate_Output(DecisionPattern16);
			errorArray[i] += BrainArray[i].Calculate_Error(1.51f);
		}



		IdOfBestFittedNet = 0;
		IdOfSecondBestFittedNet = 0;


		IdOfWorstFittedNet = 0;
		IdOfSecondWorstFittedNet = 0;

		minError = 1000000.0f;
		maxError = -1000000.0f;

		for (i = 0; i < PopulationSize; i++)
		{
			if (errorArray[i] < minError)
			{
				secondMinError = minError;
				minError = errorArray[i];
				IdOfSecondBestFittedNet = IdOfBestFittedNet;
				IdOfBestFittedNet = i;
			}
			else
			{
				if (errorArray[i] < secondMinError)
				{
					secondMinError = errorArray[i];
					IdOfSecondBestFittedNet = i;
				}
			}

			if (errorArray[i] > maxError)
			{
				secondMaxError = maxError;
				maxError = errorArray[i];
				IdOfSecondWorstFittedNet = IdOfWorstFittedNet;
				IdOfWorstFittedNet = i;
			}
			else
			{
				if (errorArray[i] > secondMaxError)
				{
					secondMaxError = errorArray[i];
					IdOfSecondWorstFittedNet = i;
				}
			}
		}

		if (minError < 0.000125f)
			break;

#ifdef EvolutionVariant1

		for (uint32_t i = 0; i < PopulationSize; i++)
		{
			if (i != IdOfBestFittedNet && i != IdOfSecondBestFittedNet)
			{
				BrainArray[i].RandomChange_OutputSynapsePlasticities(seed++, minPlasticity, maxPlasticity);
			}
		}

#endif
#ifdef EvolutionVariant2

		for (uint32_t i = 0; i < PopulationSize; i++)
		{
			if (i != IdOfBestFittedNet && i != IdOfSecondBestFittedNet &&  i != IdOfWorstFittedNet && i != IdOfSecondWorstFittedNet)
			{
				if (RandomNumbers.Get_IntegerNumber(2, 4) == 2)
					BrainArray[i].Combine_OutputSynapsePlasticities(&BrainArray[IdOfBestFittedNet], &BrainArray[IdOfSecondBestFittedNet], 0.0f, seed++);
				else // Mutationen:
					BrainArray[i].RandomChange_OutputSynapsePlasticities(seed++, minPlasticity, maxPlasticity);
				//BrainArray[i].Clone_OutputSynapsePlasticities(&BrainArray[IdOfBestFittedNet], 0.001f, seed++);
			}
		}

		BrainArray[IdOfWorstFittedNet].Clone_OutputSynapsePlasticities(&BrainArray[IdOfBestFittedNet], 0.001f, seed++);
		BrainArray[IdOfSecondWorstFittedNet].Clone_OutputSynapsePlasticities(&BrainArray[IdOfBestFittedNet], 0.001f, seed++);

#endif
#ifdef EvolutionVariant3

		for (uint32_t i = 0; i < PopulationSize; i++)
		{
			if (i != IdOfBestFittedNet && i != IdOfSecondBestFittedNet &&  i != IdOfWorstFittedNet && i != IdOfSecondWorstFittedNet)
			{
				if (RandomNumbers.Get_IntegerNumber(2, 4) == 2)
					BrainArray[i].Combine_OutputSynapsePlasticities(&BrainArray[IdOfBestFittedNet], &BrainArray[IdOfSecondBestFittedNet], 0.0f, seed++);
				else
				{
					if (RandomNumbers.Get_IntegerNumber(2, 5) == 2)  // Mutationen:												
					{
						BrainArray[i].RandomChange_OutputSynapsePlasticities(seed++, minPlasticity, maxPlasticity);
						//BrainArray[i].Clone_OutputSynapsePlasticities(&BrainArray[IdOfBestFittedPlayer], 0.001f, seed++);
					}
					else
					{
						BrainArray[i].Combine_OutputSynapsePlasticities(&BrainArray[RandomNumbers.Get_UnsignedIntegerNumber(0, PopulationSize)], &BrainArray[RandomNumbers.Get_UnsignedIntegerNumber(0, PopulationSize)], 0.0f, seed++);
					}
				}
			}
		}

		BrainArray[IdOfWorstFittedNet].Clone_OutputSynapsePlasticities(&BrainArray[IdOfBestFittedNet], 0.001f, seed++);
		BrainArray[IdOfSecondWorstFittedNet].Clone_OutputSynapsePlasticities(&BrainArray[IdOfBestFittedNet], 0.001f, seed++);

#endif
#ifdef EvolutionVariant4

		for (uint32_t i = 0; i < PopulationSize; i++)
		{
			if (i == IdOfBestFittedNet || i == IdOfSecondBestFittedNet)
			{
			}
			else if (i == IdOfWorstFittedNet)
			{
				BrainArray[IdOfWorstFittedNet].Clone_OutputSynapsePlasticities(&BrainArray[IdOfBestFittedNet], 0.001f, seed++);
			}
			else if (i == IdOfSecondWorstFittedNet)
			{
				BrainArray[IdOfSecondWorstFittedNet].Clone_OutputSynapsePlasticities(&BrainArray[IdOfBestFittedNet], 0.001f, seed++);
			}
			else
			{
				if (RandomNumbers.Get_IntegerNumber(2, 6) == 2)  // Mutationen:
				{
					BrainArray[i].RandomChange_OutputSynapsePlasticities(seed++, minPlasticity, maxPlasticity);
				}
				else
				{
					if (RandomNumbers.Get_IntegerNumber(2, 5) == 2)
					{
						BrainArray[i].Combine_OutputSynapsePlasticities(&BrainArray[IdOfBestFittedNet], &BrainArray[IdOfSecondBestFittedNet], 0.0f, seed++);
					}
					else
					{
						BrainArray[i].Combine_OutputSynapsePlasticities(&BrainArray[RandomNumbers.Get_UnsignedIntegerNumber(0, PopulationSize)], &BrainArray[RandomNumbers.Get_UnsignedIntegerNumber(0, PopulationSize)], 0.0f, seed++);
					}
				}
			}
		}

#endif
	}

	
	// evolution completed

	// evolution statistics:

	for (i = 0; i < PopulationSize; i++)
		cout << "error: " << errorArray[i] << endl;

	cout << endl;

	cout << "simulated generations: " << generation << endl;
	cout << "minimum error: " << minError << endl;
	cout << "IdOfWorstFittedNet: " << IdOfWorstFittedNet << endl;
	cout << "IdOfSecondWorstFittedNet: " << IdOfSecondWorstFittedNet << endl;
	cout << "IdOfBestFittedNet: " << IdOfBestFittedNet << endl;
	cout << "IdOfSecondBestFittedNet: " << IdOfSecondBestFittedNet << endl << endl;
	
	// neural network tests:
	
	cout << "Decision Pattern 01: " << 10.0f*BrainArray[IdOfBestFittedNet].Calculate_Output(DecisionPattern1) << " --- desired output: " << 0.1f << endl;
	cout << "Decision Pattern 02: " << 10.0f*BrainArray[IdOfBestFittedNet].Calculate_Output(DecisionPattern2) << " --- desired output: " << 1.1f << endl;
	cout << "Decision Pattern 03: " << 10.0f*BrainArray[IdOfBestFittedNet].Calculate_Output(DecisionPattern3) << " --- desired output: " << 2.1f << endl;
	cout << "Decision Pattern 04: " << 10.0f*BrainArray[IdOfBestFittedNet].Calculate_Output(DecisionPattern4) << " --- desired output: " << 3.1f << endl;
	cout << "Decision Pattern 05: " << 10.0f*BrainArray[IdOfBestFittedNet].Calculate_Output(DecisionPattern5) << " --- desired output: " << 4.1f << endl;
	cout << "Decision Pattern 06: " << 10.0f*BrainArray[IdOfBestFittedNet].Calculate_Output(DecisionPattern6) << " --- desired output: " << 5.1f << endl;
	cout << "Decision Pattern 07: " << 10.0f*BrainArray[IdOfBestFittedNet].Calculate_Output(DecisionPattern7) << " --- desired output: " << 6.1f << endl;
	cout << "Decision Pattern 08: " << 10.0f*BrainArray[IdOfBestFittedNet].Calculate_Output(DecisionPattern8) << " --- desired output: " << 7.1f << endl;
	cout << "Decision Pattern 09: " << 10.0f*BrainArray[IdOfBestFittedNet].Calculate_Output(DecisionPattern9) << " --- desired output: " << 8.1f << endl;
	cout << "Decision Pattern 10: " << 10.0f*BrainArray[IdOfBestFittedNet].Calculate_Output(DecisionPattern10) << " --- desired output: " << 9.1f << endl;
	cout << "Decision Pattern 11: " << 10.0f*BrainArray[IdOfBestFittedNet].Calculate_Output(DecisionPattern11) << " --- desired output: " << 10.1f << endl;
	cout << "Decision Pattern 12: " << 10.0f*BrainArray[IdOfBestFittedNet].Calculate_Output(DecisionPattern12) << " --- desired output: " << 11.1f << endl;
	cout << "Decision Pattern 13: " << 10.0f*BrainArray[IdOfBestFittedNet].Calculate_Output(DecisionPattern13) << " --- desired output: " << 12.1f << endl;
	cout << "Decision Pattern 14: " << 10.0f*BrainArray[IdOfBestFittedNet].Calculate_Output(DecisionPattern14) << " --- desired output: " << 13.1f << endl;
	cout << "Decision Pattern 15: " << 10.0f*BrainArray[IdOfBestFittedNet].Calculate_Output(DecisionPattern15) << " --- desired output: " << 14.1f << endl;
	cout << "Decision Pattern 16: " << 10.0f*BrainArray[IdOfBestFittedNet].Calculate_Output(DecisionPattern16) << " --- desired output: " << 15.1f << endl;

	getchar();
	return 0;
}
*/