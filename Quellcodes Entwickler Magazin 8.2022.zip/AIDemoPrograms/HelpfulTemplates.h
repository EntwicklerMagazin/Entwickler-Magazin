#include <iostream>



namespace HelperStuff
{

#define UseSecuredDataAccess

template <typename UserDefType, size_t size>
class CSecuredArray
{
public:

	UserDefType UserDefArray[size];

	UserDefType& operator[](size_t index)
	{
#ifdef UseSecuredDataAccess
		if (index >= size)
			return UserDefArray[0];
#endif

		return UserDefArray[index];
	}

	// Die nachfolgende Methode liefert uns die Speicheradresse des ersten Array-Elements: 
	UserDefType* begin(void)
	{
		return UserDefArray;
	}

	// Die nachfolgende Methode liefert uns die Speicheradresse hinter(!) dem letzten Array-Element: 
	UserDefType* end(void)
	{
		return (UserDefArray + size);
	}
}; // end of CSecuredArray

/*
void TestFunction(CSecuredArray<float, 10> &refArray)
{
    for (size_t i = 0; i < 10; i++)
        cout << refArray[i] << endl;
}
*/

template <typename UserDefType>
class CSecuredPool
{
public:

	UserDefType *pUserDefArray;

	size_t NumEntriesMax;

	CSecuredPool()
	{
		pUserDefArray = new (std::nothrow) UserDefType[1];

		if (pUserDefArray == nullptr)
			NumEntriesMax = 0;
		else
			NumEntriesMax = 1;

	}

	CSecuredPool(size_t numEntriesMax)
	{
		pUserDefArray = new (std::nothrow) UserDefType[numEntriesMax];

		if (pUserDefArray == nullptr)
		{
			numEntriesMax = 1;
			pUserDefArray = new (std::nothrow) UserDefType[numEntriesMax];

			if (pUserDefArray == nullptr)
				numEntriesMax = 0;
		}



		NumEntriesMax = numEntriesMax;
	}

	// Verwendung des Kopierkonstruktors unterbinden: 
	CSecuredPool(const CSecuredPool &originalObject) = delete;

	// Verwendung des Zuweisungsoperators unterbinden: 
	CSecuredPool& operator=(const CSecuredPool &originalObject) = delete;


	~CSecuredPool()
	{
		delete[] pUserDefArray;
		pUserDefArray = nullptr;
	}

	void Initialize(size_t numEntriesMax)
	{
		delete[] pUserDefArray;
		pUserDefArray = nullptr;

		pUserDefArray = new (std::nothrow) UserDefType[numEntriesMax];

		if (pUserDefArray == nullptr)
		{
			numEntriesMax = 1;
			pUserDefArray = new (std::nothrow) UserDefType[numEntriesMax];

			if (pUserDefArray == nullptr)
				numEntriesMax = 0;

		}



		NumEntriesMax = numEntriesMax;
	}

	void Deallocate_Memory(void)
	{
		delete[] pUserDefArray;
		pUserDefArray = nullptr;

		NumEntriesMax = 0;
	}

	UserDefType& operator[] (size_t index)
	{
#ifdef UseSecuredDataAccess
		if (index >= NumEntriesMax)
			return pUserDefArray[0];
#endif

		return pUserDefArray[index];
	}

	// Die nachfolgende Methode liefert uns die Speicheradresse des ersten Datenelements: 
	UserDefType* begin(void)
	{
		return pUserDefArray;
	}

	// Die nachfolgende Methode liefert uns die Speicheradresse hinter(!) dem letzten Datenelement: 
	UserDefType* end(void)
	{
		return (pUserDefArray + NumEntriesMax);
	}
}; // end of CSecuredPool

template <typename UserDefType>
class CPtrToHeapObject
{
public:

	UserDefType *Ptr;

	bool ResponsibleForMemory;

	CPtrToHeapObject() : Ptr(nullptr), ResponsibleForMemory(false)
	{}

	CPtrToHeapObject(UserDefType *p) : Ptr(p), ResponsibleForMemory(true)
	{}

	~CPtrToHeapObject()
	{
		if (ResponsibleForMemory == true)
		{
			delete Ptr;
			Ptr = nullptr;
		}
	}

	// Kopierkonstruktor:  
	CPtrToHeapObject(const CPtrToHeapObject &originalObject)
	{
		ResponsibleForMemory = false;
		Ptr = originalObject.Ptr;
	}

	// Zuweisungsoperator: 
	CPtrToHeapObject& operator=(const CPtrToHeapObject &originalObject)
	{
		// Selbstzuweisung unterbinden:
		if (this == &originalObject)
			return *this;

		ResponsibleForMemory = false;
		Ptr = originalObject.Ptr;

		return *this;
	}

	void Acquire_MemoryResponsibility(CPtrToHeapObject &object)
	{
		if (ResponsibleForMemory == true)
			return;
		if (object.ResponsibleForMemory == false)
			return;


		object.ResponsibleForMemory = false;
		ResponsibleForMemory = true;
		Ptr = object.Ptr;
	}


	void Acquire_Memory(UserDefType *p)
	{
		if (ResponsibleForMemory == true)
			delete Ptr;

		Ptr = p;
		ResponsibleForMemory = true;
	}

	void Deallocate_Memory(void)
	{
		if (ResponsibleForMemory == true)
		{
			delete Ptr;
			Ptr = nullptr;
			ResponsibleForMemory = false;
		}
	}

	UserDefType& operator*(void)
	{
		return *Ptr;
	}

	UserDefType* operator->(void)
	{
		return Ptr;
	}
}; // end of class CPtrToHeapObject 

template <typename UserDefType>
class CSecuredPtrToHeapObjectArray
{
public:

	size_t NumArrayElements;
	UserDefType *Ptr;

	bool ResponsibleForMemory;

	CSecuredPtrToHeapObjectArray() : NumArrayElements(0), Ptr(nullptr), ResponsibleForMemory(false)
	{}

	CSecuredPtrToHeapObjectArray(size_t numArrayElements, UserDefType *p) : NumArrayElements(numArrayElements), Ptr(p), ResponsibleForMemory(true)
	{}

	~CSecuredPtrToHeapObjectArray()
	{
		if (ResponsibleForMemory == true)
		{
			delete[] Ptr;
			Ptr = nullptr;
		}
	}

	// Kopierkonstruktor:  
	CSecuredPtrToHeapObjectArray(const CSecuredPtrToHeapObjectArray &originalObject)
	{
		ResponsibleForMemory = false;
		Ptr = originalObject.Ptr;

		NumArrayElements = originalObject.NumArrayElements;
	}

	// Zuweisungsoperator: 
	CSecuredPtrToHeapObjectArray& operator=(const CSecuredPtrToHeapObjectArray &originalObject)
	{
		// Selbstzuweisung unterbinden:
		if (this == &originalObject)
			return *this;

		ResponsibleForMemory = false;
		Ptr = originalObject.Ptr;

		NumArrayElements = originalObject.NumArrayElements;

		return *this;
	}

	void Acquire_MemoryResponsibility(CSecuredPtrToHeapObjectArray &object)
	{
		if (ResponsibleForMemory == true)
			return;
		if (object.ResponsibleForMemory == false)
			return;

		NumArrayElements = object.NumArrayElements;

		object.ResponsibleForMemory = false;
		ResponsibleForMemory = true;
		Ptr = object.Ptr;
	}

	void Acquire_Memory(size_t numArrayElements,
		UserDefType *p)
	{
		if (ResponsibleForMemory == true)
			delete[] Ptr;

		Ptr = p;

		NumArrayElements = numArrayElements;
		ResponsibleForMemory = true;
	}

	void Deallocate_Memory(void)
	{
		if (ResponsibleForMemory == true)
		{
			delete[] Ptr;
			Ptr = nullptr;
			ResponsibleForMemory = false;
		}
	}

	UserDefType& operator[] (size_t index)
	{
#ifdef UseSecuredDataAccess
		if (index >= NumArrayElements)
			return Ptr[0];
#endif

		return Ptr[index];
	}

	UserDefType* begin(void) { return Ptr; }
	UserDefType* end(void) { return (Ptr + NumArrayElements); }
}; // end of class CSecuredPtrToHeapObjectArray 



} /* end of namespace HelperStuff */


