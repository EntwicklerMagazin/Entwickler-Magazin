#include <iostream>

using namespace std;

/*
void testFunction(int32_t num)
{
	cout << num << " ";
}

// counter, counter+1, counter+2, ..., counter+maxCount-1:
void RecursiveForAlternative(int32_t counter, int32_t maxCount) // tail recursion
{
	if (counter >= maxCount)
	{
		return;
	}

	testFunction(counter); // Ausgabereihenfolge: 0, 1, 2, 3

	RecursiveForAlternative(counter + 1, maxCount);
}

// counter+maxCount-1, ..., counter+2, counter+1, counter:
void RecursiveReverseForAlternative(int32_t counter, int32_t maxCount)
{
	if (counter >= maxCount)
	{
		return;
	}

	RecursiveForAlternative(counter + 1, maxCount);

	testFunction(counter); // Ausgabereihenfolge: 3, 2, 1, 0
}

int main(void)
{
	for (int32_t i = 0; i < 4; i++)
	{
		testFunction(i);
	}

	cout << endl;

	RecursiveForAlternative(0, 4);

	cout << endl;

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/