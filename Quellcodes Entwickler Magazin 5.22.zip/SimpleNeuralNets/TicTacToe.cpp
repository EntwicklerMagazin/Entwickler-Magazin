#include <iostream>
#include "TicTacToe.h"

#ifndef max
#define max(a,b)    ( ((a) > (b)) ? (a) : (b) )
#endif

#ifndef min
#define min(a,b)    ( ((a) < (b)) ? (a) : (b) )
#endif

using namespace std;

static constexpr int32_t ConstMaxSearchDepth_MiniMax = 100;
//static constexpr int32_t ConstMaxSearchDepth_MiniMax = 1;

static constexpr int32_t ConstMaxEvaluation = 1000;
static constexpr int32_t ConstMinEvaluation = -1000;

static CRandomNumbers_ParkMillerMLKG RandomNumbers;

CGameState::CGameState()
{
	LastMove_Row = LastMove_Column = LastMove_Index = 0;

	NumEmptyBoardPositions = ConstNumBoardRows * ConstNumBoardColumns;

	uint32_t i, j;

	for (i = 0; i < ConstNumBoardRows; i++)
	{
		for (j = 0; j < ConstNumBoardColumns; j++)
		{
			Board[i][j] = ConstBoardSymbol_Empty;
		}
	}

	for (i = 0; i < ConstBoardSize_2; i++)
		BoardDataArray[i] = 0.0f;

	for (i = 0; i < ConstBoardSize_2; i++)
		BoardDataArray2[i] = 0.0f;
	for (i = ConstBoardSize_2; i < ConstBoardSize_3; i++)
		BoardDataArray2[i] = 1.0f;
}

CGameState::~CGameState()
{
}

CGameState::CGameState(const CGameState &originalObject)
{
	LastMove_Row = originalObject.LastMove_Row;
	LastMove_Column = originalObject.LastMove_Column;
	LastMove_Index = originalObject.LastMove_Index;

	NumEmptyBoardPositions = originalObject.NumEmptyBoardPositions;

	uint32_t i, j;

	for (i = 0; i < ConstNumBoardRows; i++)
	{
		for (j = 0; j < ConstNumBoardColumns; j++)
		{
			Board[i][j] = originalObject.Board[i][j];
		}
	}

	for (i = 0; i < ConstBoardSize_2; i++)
		BoardDataArray[i] = originalObject.BoardDataArray[i];

	for (i = 0; i < ConstBoardSize_3; i++)
		BoardDataArray2[i] = originalObject.BoardDataArray2[i];
}



CGameState& CGameState::operator=(const CGameState &originalObject)
{
	if (this == &originalObject)
		return *this;

	LastMove_Row = originalObject.LastMove_Row;
	LastMove_Column = originalObject.LastMove_Column;
	LastMove_Index = originalObject.LastMove_Index;

	NumEmptyBoardPositions = originalObject.NumEmptyBoardPositions;

	uint32_t i, j;

	for (i = 0; i < ConstNumBoardRows; i++)
	{
		for (j = 0; j < ConstNumBoardColumns; j++)
		{
			Board[i][j] = originalObject.Board[i][j];
		}
	}

	for (i = 0; i < ConstBoardSize_2; i++)
		BoardDataArray[i] = originalObject.BoardDataArray[i];

	for (i = 0; i < ConstBoardSize_3; i++)
		BoardDataArray2[i] = originalObject.BoardDataArray2[i];

	return *this;
}

bool CGameState::operator==(CGameState &otherObject)
{
	uint32_t i, j;

	for (i = 0; i < ConstNumBoardRows; i++)
	{
		for (j = 0; j < ConstNumBoardColumns; j++)
		{
			if (Board[i][j] != otherObject.Board[i][j])
				return false;
		}
	}

	return true;
}


void CGameState::Get_BoardData(uint8_t pOutData[3][3])
{
	uint32_t i, j;
	
	for (i = 0; i < ConstNumBoardRows; i++)
	{
		for (j = 0; j < ConstNumBoardColumns; j++)
		{
			pOutData[i][j] = Board[i][j];
		}
	}
}

void CGameState::Reset_Bord(void)
{
	LastMove_Row = LastMove_Column = LastMove_Index = 0;

	NumEmptyBoardPositions = ConstNumBoardRows * ConstNumBoardColumns;

	uint32_t i, j;

	for (i = 0; i < ConstNumBoardRows; i++)
	{
		for (j = 0; j < ConstNumBoardColumns; j++)
		{
			Board[i][j] = ConstBoardSymbol_Empty;
		}
	}

	for (i = 0; i < ConstBoardSize_2; i++)
		BoardDataArray[i] = 0.0f;

	for (i = 0; i < ConstBoardSize_2; i++)
		BoardDataArray2[i] = 0.0f;
	for (i = ConstBoardSize_2; i < ConstBoardSize_3; i++)
		BoardDataArray2[i] = 1.0f;
}

void CGameState::Output(void)
{
	uint32_t i, j;

	for (i = 0; i < ConstNumBoardRows; i++)
	{
		for (j = 0; j < ConstNumBoardColumns; j++)
		{
			cout << Board[i][j] << " ";
		}

		cout << endl;
	}
	cout << endl;
}

inline void Output(uint8_t Board[3][3])
{
	cout << "Test Output:" << endl;

	uint32_t i, j;

	for (i = 0; i < ConstNumBoardRows; i++)
	{
		for (j = 0; j < ConstNumBoardColumns; j++)
		{
			cout << Board[i][j] << " ";
		}

		cout << endl;
	}
	cout << endl;

	getchar();
}


bool CGameState::Check_If_Player1_Could_Win(void)
{
	if (Board[0][0] == ConstBoardSymbol_Player1 && Board[0][1] == ConstBoardSymbol_Player1 && Board[0][2] == ConstBoardSymbol_Empty)
		return true;
	if (Board[0][0] == ConstBoardSymbol_Player1 && Board[0][1] == ConstBoardSymbol_Empty && Board[0][2] == ConstBoardSymbol_Player1)
		return true;
	if (Board[0][0] == ConstBoardSymbol_Empty && Board[0][1] == ConstBoardSymbol_Player1 && Board[0][2] == ConstBoardSymbol_Player1)
		return true;

	if (Board[1][0] == ConstBoardSymbol_Player1 && Board[1][1] == ConstBoardSymbol_Player1 && Board[1][2] == ConstBoardSymbol_Empty)
		return true;
	if (Board[1][0] == ConstBoardSymbol_Player1 && Board[1][1] == ConstBoardSymbol_Empty && Board[1][2] == ConstBoardSymbol_Player1)
		return true;
	if (Board[1][0] == ConstBoardSymbol_Empty && Board[1][1] == ConstBoardSymbol_Player1 && Board[1][2] == ConstBoardSymbol_Player1)
		return true;

	if (Board[2][0] == ConstBoardSymbol_Player1 && Board[2][1] == ConstBoardSymbol_Player1 && Board[2][2] == ConstBoardSymbol_Empty)
		return true;
	if (Board[2][0] == ConstBoardSymbol_Player1 && Board[2][1] == ConstBoardSymbol_Empty && Board[2][2] == ConstBoardSymbol_Player1)
		return true;
	if (Board[2][0] == ConstBoardSymbol_Empty && Board[2][1] == ConstBoardSymbol_Player1 && Board[2][2] == ConstBoardSymbol_Player1)
		return true;

	//////////////

	if (Board[0][0] == ConstBoardSymbol_Player1 && Board[1][0] == ConstBoardSymbol_Player1 && Board[2][0] == ConstBoardSymbol_Empty)
		return true;
	if (Board[0][0] == ConstBoardSymbol_Player1 && Board[1][0] == ConstBoardSymbol_Empty && Board[2][0] == ConstBoardSymbol_Player1)
		return true;
	if (Board[0][0] == ConstBoardSymbol_Empty && Board[1][0] == ConstBoardSymbol_Player1 && Board[2][0] == ConstBoardSymbol_Player1)
		return true;

	if (Board[0][1] == ConstBoardSymbol_Player1 && Board[1][1] == ConstBoardSymbol_Player1 && Board[2][1] == ConstBoardSymbol_Empty)
		return true;
	if (Board[0][1] == ConstBoardSymbol_Player1 && Board[1][1] == ConstBoardSymbol_Empty && Board[2][1] == ConstBoardSymbol_Player1)
		return true;
	if (Board[0][1] == ConstBoardSymbol_Empty && Board[1][1] == ConstBoardSymbol_Player1 && Board[2][1] == ConstBoardSymbol_Player1)
		return true;

	if (Board[0][2] == ConstBoardSymbol_Player1 && Board[1][2] == ConstBoardSymbol_Player1 && Board[2][2] == ConstBoardSymbol_Empty)
		return true;
	if (Board[0][2] == ConstBoardSymbol_Player1 && Board[1][2] == ConstBoardSymbol_Empty && Board[2][2] == ConstBoardSymbol_Player1)
		return true;
	if (Board[0][2] == ConstBoardSymbol_Empty && Board[1][2] == ConstBoardSymbol_Player1 && Board[2][2] == ConstBoardSymbol_Player1)
		return true;

	//////////////

	if (Board[0][0] == ConstBoardSymbol_Player1 && Board[1][1] == ConstBoardSymbol_Player1 && Board[2][2] == ConstBoardSymbol_Empty)
		return true;
	if (Board[0][0] == ConstBoardSymbol_Player1 && Board[1][1] == ConstBoardSymbol_Empty && Board[2][2] == ConstBoardSymbol_Player1)
		return true;
	if (Board[0][0] == ConstBoardSymbol_Empty && Board[1][1] == ConstBoardSymbol_Player1  && Board[2][2] == ConstBoardSymbol_Player1)
		return true;

	//////////////

	if (Board[0][2] == ConstBoardSymbol_Player1 && Board[1][1] == ConstBoardSymbol_Player1 && Board[2][0] == ConstBoardSymbol_Empty)
		return true;
	if (Board[0][2] == ConstBoardSymbol_Player1 && Board[1][1] == ConstBoardSymbol_Empty && Board[2][0] == ConstBoardSymbol_Player1)
		return true;
	if (Board[0][2] == ConstBoardSymbol_Empty && Board[1][1] == ConstBoardSymbol_Player1  && Board[2][0] == ConstBoardSymbol_Player1)
		return true;

	return false;
}

bool CGameState::Check_If_Player2_Could_Win(void)
{
	if (Board[0][0] == ConstBoardSymbol_Player2 && Board[0][1] == ConstBoardSymbol_Player2 && Board[0][2] == ConstBoardSymbol_Empty)
		return true;
	if (Board[0][0] == ConstBoardSymbol_Player2 && Board[0][1] == ConstBoardSymbol_Empty && Board[0][2] == ConstBoardSymbol_Player2)
		return true;
	if (Board[0][0] == ConstBoardSymbol_Empty && Board[0][1] == ConstBoardSymbol_Player2 && Board[0][2] == ConstBoardSymbol_Player2)
		return true;

	if (Board[1][0] == ConstBoardSymbol_Player2 && Board[1][1] == ConstBoardSymbol_Player2 && Board[1][2] == ConstBoardSymbol_Empty)
		return true;
	if (Board[1][0] == ConstBoardSymbol_Player2 && Board[1][1] == ConstBoardSymbol_Empty && Board[1][2] == ConstBoardSymbol_Player2)
		return true;
	if (Board[1][0] == ConstBoardSymbol_Empty && Board[1][1] == ConstBoardSymbol_Player2 && Board[1][2] == ConstBoardSymbol_Player2)
		return true;

	if (Board[2][0] == ConstBoardSymbol_Player2 && Board[2][1] == ConstBoardSymbol_Player2 && Board[2][2] == ConstBoardSymbol_Empty)
		return true;
	if (Board[2][0] == ConstBoardSymbol_Player2 && Board[2][1] == ConstBoardSymbol_Empty && Board[2][2] == ConstBoardSymbol_Player2)
		return true;
	if (Board[2][0] == ConstBoardSymbol_Empty && Board[2][1] == ConstBoardSymbol_Player2 && Board[2][2] == ConstBoardSymbol_Player2)
		return true;

	//////////////

	if (Board[0][0] == ConstBoardSymbol_Player2 && Board[1][0] == ConstBoardSymbol_Player2 && Board[2][0] == ConstBoardSymbol_Empty)
		return true;
	if (Board[0][0] == ConstBoardSymbol_Player2 && Board[1][0] == ConstBoardSymbol_Empty && Board[2][0] == ConstBoardSymbol_Player2)
		return true;
	if (Board[0][0] == ConstBoardSymbol_Empty && Board[1][0] == ConstBoardSymbol_Player2 && Board[2][0] == ConstBoardSymbol_Player2)
		return true;

	if (Board[0][1] == ConstBoardSymbol_Player2 && Board[1][1] == ConstBoardSymbol_Player2 && Board[2][1] == ConstBoardSymbol_Empty)
		return true;
	if (Board[0][1] == ConstBoardSymbol_Player2 && Board[1][1] == ConstBoardSymbol_Empty && Board[2][1] == ConstBoardSymbol_Player2)
		return true;
	if (Board[0][1] == ConstBoardSymbol_Empty && Board[1][1] == ConstBoardSymbol_Player2 && Board[2][1] == ConstBoardSymbol_Player2)
		return true;

	if (Board[0][2] == ConstBoardSymbol_Player2 && Board[1][2] == ConstBoardSymbol_Player2 && Board[2][2] == ConstBoardSymbol_Empty)
		return true;
	if (Board[0][2] == ConstBoardSymbol_Player2 && Board[1][2] == ConstBoardSymbol_Empty && Board[2][2] == ConstBoardSymbol_Player2)
		return true;
	if (Board[0][2] == ConstBoardSymbol_Empty && Board[1][2] == ConstBoardSymbol_Player2 && Board[2][2] == ConstBoardSymbol_Player2)
		return true;

	//////////////

	if (Board[0][0] == ConstBoardSymbol_Player2 && Board[1][1] == ConstBoardSymbol_Player2 && Board[2][2] == ConstBoardSymbol_Empty)
		return true;
	if (Board[0][0] == ConstBoardSymbol_Player2 && Board[1][1] == ConstBoardSymbol_Empty && Board[2][2] == ConstBoardSymbol_Player2)
		return true;
	if (Board[0][0] == ConstBoardSymbol_Empty && Board[1][1] == ConstBoardSymbol_Player2  && Board[2][2] == ConstBoardSymbol_Player2)
		return true;

	//////////////

	if (Board[0][2] == ConstBoardSymbol_Player2 && Board[1][1] == ConstBoardSymbol_Player2 && Board[2][0] == ConstBoardSymbol_Empty)
		return true;
	if (Board[0][2] == ConstBoardSymbol_Player2 && Board[1][1] == ConstBoardSymbol_Empty && Board[2][0] == ConstBoardSymbol_Player2)
		return true;
	if (Board[0][2] == ConstBoardSymbol_Empty && Board[1][1] == ConstBoardSymbol_Player2  && Board[2][0] == ConstBoardSymbol_Player2)
		return true;

	return false;
}

int32_t CGameState::Evaluate_Player1(void)
{
	if (Board[0][0] == ConstBoardSymbol_Player1 && Board[0][1] == ConstBoardSymbol_Player1 && Board[0][2] == ConstBoardSymbol_Player1)
		return 100;
	else if (Board[1][0] == ConstBoardSymbol_Player1 && Board[1][1] == ConstBoardSymbol_Player1 && Board[1][2] == ConstBoardSymbol_Player1)
		return 100;
	else if (Board[2][0] == ConstBoardSymbol_Player1 && Board[2][1] == ConstBoardSymbol_Player1 && Board[2][2] == ConstBoardSymbol_Player1)
		return 100;
	else if (Board[0][0] == ConstBoardSymbol_Player1 && Board[1][0] == ConstBoardSymbol_Player1 && Board[2][0] == ConstBoardSymbol_Player1)
		return 100;
	else if (Board[0][1] == ConstBoardSymbol_Player1 && Board[1][1] == ConstBoardSymbol_Player1 && Board[2][1] == ConstBoardSymbol_Player1)
		return 100;
	else if (Board[0][2] == ConstBoardSymbol_Player1 && Board[1][2] == ConstBoardSymbol_Player1 && Board[2][2] == ConstBoardSymbol_Player1)
		return 100;
	else if (Board[0][0] == ConstBoardSymbol_Player1 && Board[1][1] == ConstBoardSymbol_Player1 && Board[2][2] == ConstBoardSymbol_Player1)
		return 100;
	else if (Board[2][0] == ConstBoardSymbol_Player1 && Board[1][1] == ConstBoardSymbol_Player1 && Board[0][2] == ConstBoardSymbol_Player1)
		return 100;

	return 0;
}



int32_t CGameState::Evaluate_Player2(void)
{
	if (Board[0][0] == ConstBoardSymbol_Player2 && Board[0][1] == ConstBoardSymbol_Player2 && Board[0][2] == ConstBoardSymbol_Player2)
		return 100;
	else if (Board[1][0] == ConstBoardSymbol_Player2 && Board[1][1] == ConstBoardSymbol_Player2 && Board[1][2] == ConstBoardSymbol_Player2)
		return 100;
	else if (Board[2][0] == ConstBoardSymbol_Player2 && Board[2][1] == ConstBoardSymbol_Player2 && Board[2][2] == ConstBoardSymbol_Player2)
		return 100;
	else if (Board[0][0] == ConstBoardSymbol_Player2 && Board[1][0] == ConstBoardSymbol_Player2 && Board[2][0] == ConstBoardSymbol_Player2)
		return 100;
	else if (Board[0][1] == ConstBoardSymbol_Player2 && Board[1][1] == ConstBoardSymbol_Player2 && Board[2][1] == ConstBoardSymbol_Player2)
		return 100;
	else if (Board[0][2] == ConstBoardSymbol_Player2 && Board[1][2] == ConstBoardSymbol_Player2 && Board[2][2] == ConstBoardSymbol_Player2)
		return 100;
	else if (Board[0][0] == ConstBoardSymbol_Player2 && Board[1][1] == ConstBoardSymbol_Player2 && Board[2][2] == ConstBoardSymbol_Player2)
		return 100;
	else if (Board[2][0] == ConstBoardSymbol_Player2 && Board[1][1] == ConstBoardSymbol_Player2 && Board[0][2] == ConstBoardSymbol_Player2)
		return 100;

	return 0;
}



void CGameState::Reset_LastMove_RowColumn(void)
{
	uint8_t player = Board[LastMove_Row][LastMove_Column];

	if (player != ConstBoardSymbol_Empty)
	{
		Board[LastMove_Row][LastMove_Column] = ConstBoardSymbol_Empty;

		if (player == ConstBoardSymbol_Player1)
		{
			BoardDataArray[LastMove_Column + ConstNumBoardColumns * LastMove_Row] = 0.0f;

			BoardDataArray2[LastMove_Column + ConstNumBoardColumns * LastMove_Row] = 0.0f;
			BoardDataArray2[ConstBoardSize_2 + LastMove_Column + ConstNumBoardColumns * LastMove_Row] = 1.0f;
		}
		else if (player == ConstBoardSymbol_Player2)
		{
			BoardDataArray[ConstBoardSize + LastMove_Column + ConstNumBoardColumns * LastMove_Row] = 0.0f;

			BoardDataArray2[ConstBoardSize + LastMove_Column + ConstNumBoardColumns * LastMove_Row] = 0.0f;
			BoardDataArray2[ConstBoardSize_2 + LastMove_Column + ConstNumBoardColumns * LastMove_Row] = 1.0f;
		}

		


		NumEmptyBoardPositions++;
	}
}

void CGameState::Reset_LastMove_Index(void)
{
	uint32_t column = LastMove_Index % ConstNumBoardColumns;
	uint32_t row = LastMove_Index / ConstNumBoardColumns;

	uint8_t player = Board[row][column];

	if (player != ConstBoardSymbol_Empty)
	{
		Board[row][column] = ConstBoardSymbol_Empty;

		if (player == ConstBoardSymbol_Player1)
		{
			BoardDataArray[LastMove_Index] = 0.0f;

			BoardDataArray2[LastMove_Index] = 0.0f;
			BoardDataArray2[ConstBoardSize_2 + LastMove_Index] = 1.0f;
		}
		else if (player == ConstBoardSymbol_Player2)
		{
			BoardDataArray[ConstBoardSize + LastMove_Index] = 0.0f;

			BoardDataArray2[ConstBoardSize + LastMove_Index] = 0.0f;
			BoardDataArray2[ConstBoardSize_2 + LastMove_Index] = 1.0f;
		}

	

		NumEmptyBoardPositions++;
	}
}

bool CGameState::Make_Move(uint32_t row, uint32_t column, uint8_t player)
{
	if (NumEmptyBoardPositions == 0)
		return false;

	if (row > ConstNumBoardRowsMinus1)
		return false;
	if (column > ConstNumBoardColumnsMinus1)
		return false;

	if (Board[row][column] != ConstBoardSymbol_Empty)
		return false;

	Board[row][column] = player;

	NumEmptyBoardPositions--;

	LastMove_Row = row;
	LastMove_Column = column;

	if (player == ConstBoardSymbol_Player1)
	{
		BoardDataArray[column + ConstNumBoardColumns*row] = 1.0f;

		BoardDataArray2[column + ConstNumBoardColumns*row] = 1.0f;
		BoardDataArray2[ConstBoardSize_2 + column + ConstNumBoardColumns*row] = 0.0f;
	}
	else if (player == ConstBoardSymbol_Player2)
	{
		BoardDataArray[ConstBoardSize + column + ConstNumBoardColumns*row] = 1.0f;

		BoardDataArray2[ConstBoardSize + column + ConstNumBoardColumns*row] = 1.0f;
		BoardDataArray2[ConstBoardSize_2 + column + ConstNumBoardColumns*row] = 0.0f;
	}


	return true;
}

bool CGameState::Make_Move(uint32_t index, uint8_t player)
{
	if (NumEmptyBoardPositions == 0)
		return false;

	if (index > ConstBoardSizeMinus1)
		return false;

	uint32_t column = index % ConstNumBoardColumns;
	uint32_t row = index / ConstNumBoardColumns;

	if (Board[row][column] != ConstBoardSymbol_Empty)
		return false;

	Board[row][column] = player;

	NumEmptyBoardPositions--;

	LastMove_Index = index;

	if (player == ConstBoardSymbol_Player1)
	{
		BoardDataArray[index] = 1.0f;

		BoardDataArray2[index] = 1.0f;
		BoardDataArray2[ConstBoardSize_2 + index] = 0.0f;
	}
	else if (player == ConstBoardSymbol_Player2)
	{
		BoardDataArray[ConstBoardSize + index] = 1.0f;

		BoardDataArray2[ConstBoardSize + index] = 1.0f;
		BoardDataArray2[ConstBoardSize_2 + index] = 0.0f;
	}

	return true;
}

void CRecordedGame::Reset_Game(void)
{
	NumMoves = 0;
}

void CRecordedGame::Record_Move(int32_t row, int32_t column)
{
	MoveArray[NumMoves].row = row;
	MoveArray[NumMoves].column = column;
	NumMoves++;
}



bool Check_IfAnOtherMoveIsPossible(uint8_t board[3][3])
{
	for (int32_t i = 0; i < 3; i++)
	{
		for (int32_t j = 0; j < 3; j++)
		{
			if (board[i][j] == ConstBoardSymbol_Empty)
				return true;
		}
	}

	return false;
}


int32_t MiniMaxEvaluatePlayer1(uint8_t Board[ConstNumBoardRows][ConstNumBoardColumns])
{
	if (Board[0][0] == ConstBoardSymbol_Player1 && Board[0][1] == ConstBoardSymbol_Player1 && Board[0][2] == ConstBoardSymbol_Player1)
		return 100;
	else if (Board[1][0] == ConstBoardSymbol_Player1 && Board[1][1] == ConstBoardSymbol_Player1 && Board[1][2] == ConstBoardSymbol_Player1)
		return 100;
	else if (Board[2][0] == ConstBoardSymbol_Player1 && Board[2][1] == ConstBoardSymbol_Player1 && Board[2][2] == ConstBoardSymbol_Player1)
		return 100;
	else if (Board[0][0] == ConstBoardSymbol_Player1 && Board[1][0] == ConstBoardSymbol_Player1 && Board[2][0] == ConstBoardSymbol_Player1)
		return 100;
	else if (Board[0][1] == ConstBoardSymbol_Player1 && Board[1][1] == ConstBoardSymbol_Player1 && Board[2][1] == ConstBoardSymbol_Player1)
		return 100;
	else if (Board[0][2] == ConstBoardSymbol_Player1 && Board[1][2] == ConstBoardSymbol_Player1 && Board[2][2] == ConstBoardSymbol_Player1)
		return 100;
	else if (Board[0][0] == ConstBoardSymbol_Player1 && Board[1][1] == ConstBoardSymbol_Player1 && Board[2][2] == ConstBoardSymbol_Player1)
		return 100;
	else if (Board[2][0] == ConstBoardSymbol_Player1 && Board[1][1] == ConstBoardSymbol_Player1 && Board[0][2] == ConstBoardSymbol_Player1)
		return 100;

	if (Board[0][0] == ConstBoardSymbol_Player2 && Board[0][1] == ConstBoardSymbol_Player2 && Board[0][2] == ConstBoardSymbol_Player2)
		return -100;
	else if (Board[1][0] == ConstBoardSymbol_Player2 && Board[1][1] == ConstBoardSymbol_Player2 && Board[1][2] == ConstBoardSymbol_Player2)
		return -100;
	else if (Board[2][0] == ConstBoardSymbol_Player2 && Board[2][1] == ConstBoardSymbol_Player2 && Board[2][2] == ConstBoardSymbol_Player2)
		return -100;
	else if (Board[0][0] == ConstBoardSymbol_Player2 && Board[1][0] == ConstBoardSymbol_Player2 && Board[2][0] == ConstBoardSymbol_Player2)
		return -100;
	else if (Board[0][1] == ConstBoardSymbol_Player2 && Board[1][1] == ConstBoardSymbol_Player2 && Board[2][1] == ConstBoardSymbol_Player2)
		return -100;
	else if (Board[0][2] == ConstBoardSymbol_Player2 && Board[1][2] == ConstBoardSymbol_Player2 && Board[2][2] == ConstBoardSymbol_Player2)
		return -100;
	else if (Board[0][0] == ConstBoardSymbol_Player2 && Board[1][1] == ConstBoardSymbol_Player2 && Board[2][2] == ConstBoardSymbol_Player2)
		return -100;
	else if (Board[2][0] == ConstBoardSymbol_Player2 && Board[1][1] == ConstBoardSymbol_Player2 && Board[0][2] == ConstBoardSymbol_Player2)
		return -100;

	return 0;
}

int32_t MiniMaxEvaluatePlayer2(uint8_t Board[ConstNumBoardRows][ConstNumBoardColumns])
{
	if (Board[0][0] == ConstBoardSymbol_Player1 && Board[0][1] == ConstBoardSymbol_Player1 && Board[0][2] == ConstBoardSymbol_Player1)
		return -100;
	else if (Board[1][0] == ConstBoardSymbol_Player1 && Board[1][1] == ConstBoardSymbol_Player1 && Board[1][2] == ConstBoardSymbol_Player1)
		return -100;
	else if (Board[2][0] == ConstBoardSymbol_Player1 && Board[2][1] == ConstBoardSymbol_Player1 && Board[2][2] == ConstBoardSymbol_Player1)
		return -100;
	else if (Board[0][0] == ConstBoardSymbol_Player1 && Board[1][0] == ConstBoardSymbol_Player1 && Board[2][0] == ConstBoardSymbol_Player1)
		return -100;
	else if (Board[0][1] == ConstBoardSymbol_Player1 && Board[1][1] == ConstBoardSymbol_Player1 && Board[2][1] == ConstBoardSymbol_Player1)
		return -100;
	else if (Board[0][2] == ConstBoardSymbol_Player1 && Board[1][2] == ConstBoardSymbol_Player1 && Board[2][2] == ConstBoardSymbol_Player1)
		return -100;
	else if (Board[0][0] == ConstBoardSymbol_Player1 && Board[1][1] == ConstBoardSymbol_Player1 && Board[2][2] == ConstBoardSymbol_Player1)
		return -100;
	else if (Board[2][0] == ConstBoardSymbol_Player1 && Board[1][1] == ConstBoardSymbol_Player1 && Board[0][2] == ConstBoardSymbol_Player1)
		return -100;

	if (Board[0][0] == ConstBoardSymbol_Player2 && Board[0][1] == ConstBoardSymbol_Player2 && Board[0][2] == ConstBoardSymbol_Player2)
		return 100;
	else if (Board[1][0] == ConstBoardSymbol_Player2 && Board[1][1] == ConstBoardSymbol_Player2 && Board[1][2] == ConstBoardSymbol_Player2)
		return 100;
	else if (Board[2][0] == ConstBoardSymbol_Player2 && Board[2][1] == ConstBoardSymbol_Player2 && Board[2][2] == ConstBoardSymbol_Player2)
		return 100;
	else if (Board[0][0] == ConstBoardSymbol_Player2 && Board[1][0] == ConstBoardSymbol_Player2 && Board[2][0] == ConstBoardSymbol_Player2)
		return 100;
	else if (Board[0][1] == ConstBoardSymbol_Player2 && Board[1][1] == ConstBoardSymbol_Player2 && Board[2][1] == ConstBoardSymbol_Player2)
		return 100;
	else if (Board[0][2] == ConstBoardSymbol_Player2 && Board[1][2] == ConstBoardSymbol_Player2 && Board[2][2] == ConstBoardSymbol_Player2)
		return 100;
	else if (Board[0][0] == ConstBoardSymbol_Player2 && Board[1][1] == ConstBoardSymbol_Player2 && Board[2][2] == ConstBoardSymbol_Player2)
		return 100;
	else if (Board[2][0] == ConstBoardSymbol_Player2 && Board[1][1] == ConstBoardSymbol_Player2 && Board[0][2] == ConstBoardSymbol_Player2)
		return 100;

	return 0;
}



int32_t MiniMaxPlayer1Evaluation(uint8_t Board[ConstNumBoardRows][ConstNumBoardColumns], int32_t searchDepth, bool searchForMaximum, int32_t alpha, int32_t beta)
{
	int32_t evaluationScore = MiniMaxEvaluatePlayer1(Board);

	if (searchDepth == ConstMaxSearchDepth_MiniMax)
		return evaluationScore;

	// Player1 winner:
	if (evaluationScore == 100)
		return evaluationScore;

	// Player2 winner:
	if (evaluationScore == -100)
		return evaluationScore;

	// Draw:
	if (Check_IfAnOtherMoveIsPossible(Board) == false)
		return 0;

	if (searchForMaximum == true)
	{
		int32_t maxValue = ConstMinEvaluation;
		bool stopEvaluation = false;

		for (int32_t i = 0; i < 3; i++)
		{
			for (int32_t j = 0; j < 3; j++)
			{
				if (Board[i][j] == ConstBoardSymbol_Empty)
				{
					// Make a test move:
					Board[i][j] = ConstBoardSymbol_Player1;

					//Output(Board);

					// Evaluate test move:
					maxValue = max(maxValue, MiniMaxPlayer1Evaluation(Board, searchDepth + 1, !searchForMaximum, alpha, beta));
					alpha = max(alpha, maxValue);

					// Reset last move:
					Board[i][j] = ConstBoardSymbol_Empty;

					if (beta <= alpha)
					{
						stopEvaluation = true;
						break;
					}
				}
			}

			if (stopEvaluation == true)
				break;
		}
		return maxValue;
	}
	else if (searchForMaximum == false)
	{
		int32_t minValue = ConstMaxEvaluation;
		bool stopEvaluation = false;

		for (int32_t i = 0; i < 3; i++)
		{
			for (int32_t j = 0; j < 3; j++)
			{
				if (Board[i][j] == ConstBoardSymbol_Empty)
				{
					// Make a test move:
					Board[i][j] = ConstBoardSymbol_Player2;

					//Output(Board);

					// Evaluate test move:
					minValue = min(minValue, MiniMaxPlayer1Evaluation(Board, searchDepth + 1, !searchForMaximum, alpha, beta));
					beta = min(beta, minValue);

					// Reset last move:
					Board[i][j] = ConstBoardSymbol_Empty;

					if (beta <= alpha)
					{
						stopEvaluation = true;
						break;
					}
				}
			}

			if (stopEvaluation == true)
				break;
		}

		return minValue;
	}
}

int32_t MiniMaxPlayer2Evaluation(uint8_t Board[ConstNumBoardRows][ConstNumBoardColumns], int32_t searchDepth, bool searchForMaximum, int32_t alpha, int32_t beta)
{
	int32_t evaluationScore = MiniMaxEvaluatePlayer2(Board);

	if(searchDepth == ConstMaxSearchDepth_MiniMax)
		return evaluationScore;

	// Player2 winner:
	if (evaluationScore == 100)
		return evaluationScore;

	// Player1 winner:
	if (evaluationScore == -100)
		return evaluationScore;

	// Draw:
	if (Check_IfAnOtherMoveIsPossible(Board) == false)
		return 0;

	if (searchForMaximum == true)
	{
		int32_t maxValue = ConstMinEvaluation;
		bool stopEvaluation = false;

		for (int32_t i = 0; i < 3; i++)
		{
			for (int32_t j = 0; j < 3; j++)
			{
				if (Board[i][j] == ConstBoardSymbol_Empty)
				{
					// Make a test move:
					Board[i][j] = ConstBoardSymbol_Player2;

					// Evaluate test move:
					maxValue = max(maxValue, MiniMaxPlayer2Evaluation(Board, searchDepth + 1, !searchForMaximum, alpha, beta));
					alpha = max(alpha, maxValue);

					// Reset last move:
					Board[i][j] = ConstBoardSymbol_Empty;

					if (beta <= alpha)
					{
						stopEvaluation = true;
						break;
					}
				}
			}

			if (stopEvaluation == true)
				break;
		}

		return maxValue;
	}
	else if (searchForMaximum == false)
	{
		int32_t minValue = ConstMaxEvaluation;
		bool stopEvaluation = false;

		for (int32_t i = 0; i < 3; i++)
		{
			for (int32_t j = 0; j < 3; j++)
			{
				if (Board[i][j] == ConstBoardSymbol_Empty)
				{
					// Make a test move:
					Board[i][j] = ConstBoardSymbol_Player1;

					// Evaluate test move:
					minValue = min(minValue, MiniMaxPlayer2Evaluation(Board, searchDepth + 1, !searchForMaximum, alpha, beta));
					beta = min(beta, minValue);

					// Reset last move:
					Board[i][j] = ConstBoardSymbol_Empty;

					if (beta <= alpha)
					{
						stopEvaluation = true;
						break;
					}
				}
			}

			if (stopEvaluation == true)
				break;
		}

		return minValue;
	}
}

// This will return the best possible move for the player

CMove Find_BestMovePlayer1(uint8_t Board[ConstNumBoardRows][ConstNumBoardColumns])
{
	int32_t bestEvaluation = ConstMinEvaluation;
	CMove bestMove;

	for (int32_t i = 0; i<3; i++)
	{
		for (int32_t j = 0; j<3; j++)
		{
			if (Board[i][j] == ConstBoardSymbol_Empty)
			{
				// Make a test move:
				Board[i][j] = ConstBoardSymbol_Player1;

				// Evaluate test move:
				int32_t actualEvaluation = MiniMaxPlayer1Evaluation(Board, 0, false, ConstMinEvaluation, ConstMaxEvaluation);


				//  Reset last move:
				Board[i][j] = ConstBoardSymbol_Empty;


				if (actualEvaluation > bestEvaluation)
				{
					bestMove.row = i;
					bestMove.column = j;
					bestEvaluation = actualEvaluation;
				}
			}
		}
	}

	return bestMove;
}

CMove Find_BestMovePlayer2(uint8_t Board[ConstNumBoardRows][ConstNumBoardColumns])
{
	int32_t bestEvaluation = ConstMinEvaluation;
	CMove bestMove;

	for (int32_t i = 0; i<3; i++)
	{
		for (int32_t j = 0; j<3; j++)
		{
			if (Board[i][j] == ConstBoardSymbol_Empty)
			{
				// Make a test move:
				Board[i][j] = ConstBoardSymbol_Player2;

				// Evaluate test move:
				int32_t actualEvaluation = MiniMaxPlayer2Evaluation(Board, 0, false, ConstMinEvaluation, ConstMaxEvaluation);

				//  Reset last move:
				Board[i][j] = ConstBoardSymbol_Empty;


				if (actualEvaluation > bestEvaluation)
				{
					bestMove.row = i;
					bestMove.column = j;
					bestEvaluation = actualEvaluation;
				}
			}
		}
	}

	return bestMove;
}












