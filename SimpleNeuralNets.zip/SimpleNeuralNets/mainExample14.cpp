#include <iostream>
#include "NeuralNet.h"

using namespace std;

// LRF: Local Receptive Field

//#define Approximate_OrthonormalLRFs
//#define Use_IntegerLRFs
#define Use_FloatingPointLRFs


//#define LRF_Evolution
//#define Single_LRF_Evolution

#define LRF_Learning
#define LRF_Learning_2

inline float SigmoidOutput(float neuronInput)
{
	// von 0.0f bis 1.0f:
	return 1.0f / (1.0f + exp(-neuronInput));
}

inline float ScaledSigmoidOutput(float neuronInput)
{
	// von 0.0f bis 1.0f:
	return 1.0f / (1.0f + exp(-2.0f*neuronInput));
}

inline float TanHOutput(float neuronInput)
{
	// von -1.0f bis 1.0f:
	return tanh(neuronInput);
}

inline float FastTanHReplacementOutput(float neuronInput)
{
	// von -1.0f bis 1.0f:
	return neuronInput / (1.0f + abs(neuronInput));
}


inline float LinearOutput(float neuronInput)
{
	return neuronInput;
}

inline float ReLUOutput(float neuronInput)
{
	// von 0.0f bis unendlich:
	return max(0.0f, neuronInput);	
}


inline float BinaryOutput(float neuronInput)
{
	//if (neuronInput > 0.9999f)
	//return 1.0f;

	// less accuracy
	if (neuronInput > 0.9f)
		return 1.0f;

	return 0.0f;
}





/*
int main(void)
{
	int32_t MinIntegerLRFValue = -1;
	int32_t MaxIntegerLRFValue = 1;

	float MinFloatingPointLRFValue = -1.0f;
	float MaxFloatingPointLRFValue = 1.0f;

	float MinLRFBiasValue = -0.5f;
	float MaxLRFBiasValue = -0.5f;

	float MinPlasticityValue = -0.2f;
	float MaxPlasticityValue = 0.2f;

	float NeuralNetLearningRate = 0.5f;

	float LRF_LearningRate = 0.05f;
	float ReceiverNeuronErrorFactor1 = 1.0f;
	float ReceiverNeuronErrorFactor2 = 1.0f;
	float InputErrorFactor1 = 1.0f;
	float InputErrorFactor2 = 1.0f;
	float OutputErrorFactor1 = 1.0f;
	float OutputErrorFactor2 = 1.0f;


	static float Image_5_1[32 * 32];
	static float Image_5_2[32 * 32];

	static float Image_S_1[32 * 32];
	static float Image_S_2[32 * 32];

	static float Image_6_1[32 * 32];
	static float Image_6_2[32 * 32];

	static float Image_G_1[32 * 32];
	static float Image_G_2[32 * 32];

	static float Image_8_1[32 * 32];
	static float Image_8_2[32 * 32];

	static float Image_B_1[32 * 32];
	static float Image_B_2[32 * 32];

	// test image(s):

	static float Image_5_3[32 * 32];
	static float Image_S_3[32 * 32];
	static float Image_6_3[32 * 32];
	static float Image_G_3[32 * 32];
	static float Image_8_3[32 * 32];
	static float Image_B_3[32 * 32];


	uint8_t *pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_5_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_5_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;


	pImageData = Read_Bitmap_BGR("Sample_S_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_S_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_S_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;


	pImageData = Read_Bitmap_BGR("Sample_6_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_6_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_6_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_G_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_G_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;


	pImageData = Read_Bitmap_BGR("Sample_B_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;


	// test image(s):

	pImageData = Read_Bitmap_BGR("Sample_5_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_5_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_S_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_6_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_G_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	uint32_t imageSizeX = 32;
	uint32_t imageSizeY = 32;

#ifdef Single_LRF_Evolution
	uint32_t numFeatureMaps = 6;
#endif
#ifdef LRF_Evolution
	uint32_t numFeatureMaps = 12;
#endif
#ifdef LRF_Learning
	uint32_t numFeatureMaps = 3;
#endif

	uint32_t localReceptiveFieldSizeX = 5;
	uint32_t localReceptiveFieldSizeY = 5;
	uint32_t stride = 1;

#ifdef Approximate_OrthonormalLRFs
	CImageDataPreprocessing DataPreprocessing(imageSizeX, imageSizeY, numFeatureMaps, localReceptiveFieldSizeX, localReceptiveFieldSizeY, stride, MinLRFBiasValue, MaxLRFBiasValue);
#endif
#ifdef Use_IntegerLRFs
	CImageDataPreprocessing DataPreprocessing(imageSizeX, imageSizeY, numFeatureMaps, localReceptiveFieldSizeX, localReceptiveFieldSizeY, stride, MinIntegerLRFValue, MaxIntegerLRFValue, MinLRFBiasValue, MaxLRFBiasValue, true);
#endif
#ifdef Use_FloatingPointLRFs
	CImageDataPreprocessing DataPreprocessing(imageSizeX, imageSizeY, numFeatureMaps, localReceptiveFieldSizeX, localReceptiveFieldSizeY, stride, MinFloatingPointLRFValue, MaxFloatingPointLRFValue, MinLRFBiasValue, MaxLRFBiasValue);
#endif
	
	CNeuralNet Brain;
	Brain.Init_NeuralNet(numFeatureMaps * DataPreprocessing.FeatureMapSize + 6);
	Brain.Init_TwoLayerNetwork(numFeatureMaps * DataPreprocessing.FeatureMapSize, MinPlasticityValue, MaxPlasticityValue, NeuralNetLearningRate, false, 6, SigmoidOutput);

	uint32_t maxCount = 1000;
	uint32_t epoch = 0;
	float error;

	float OutputPattern[6];

	float DesiredOutputPattern1[6] = { 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f };
	float DesiredOutputPattern2[6] = { 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f };
	float DesiredOutputPattern3[6] = { 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f };
	float DesiredOutputPattern4[6] = { 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f };
	float DesiredOutputPattern5[6] = { 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f };
	float DesiredOutputPattern6[6] = { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f };

	uint64_t seed = 1;


#ifdef Single_LRF_Evolution

#ifdef Use_FloatingPointLRFs
	for (uint32_t i = 0; i < 2000; i++)
	{
		DataPreprocessing.Single_LocalReceptiveField_Evolution(Image_5_1, 0, MinFloatingPointLRFValue, MaxFloatingPointLRFValue, MinLRFBiasValue, MaxLRFBiasValue, ReLUOutput);
		DataPreprocessing.Single_LocalReceptiveField_Evolution(Image_5_2, 0, MinFloatingPointLRFValue, MaxFloatingPointLRFValue, MinLRFBiasValue, MaxLRFBiasValue, ReLUOutput);

		DataPreprocessing.Single_LocalReceptiveField_Evolution(Image_S_1, 1, MinFloatingPointLRFValue, MaxFloatingPointLRFValue, MinLRFBiasValue, MaxLRFBiasValue, ReLUOutput);
		DataPreprocessing.Single_LocalReceptiveField_Evolution(Image_S_2, 1, MinFloatingPointLRFValue, MaxFloatingPointLRFValue, MinLRFBiasValue, MaxLRFBiasValue, ReLUOutput);

		DataPreprocessing.Single_LocalReceptiveField_Evolution(Image_6_1, 2, MinFloatingPointLRFValue, MaxFloatingPointLRFValue, MinLRFBiasValue, MaxLRFBiasValue, ReLUOutput);
		DataPreprocessing.Single_LocalReceptiveField_Evolution(Image_6_2, 2, MinFloatingPointLRFValue, MaxFloatingPointLRFValue, MinLRFBiasValue, MaxLRFBiasValue, ReLUOutput);

		DataPreprocessing.Single_LocalReceptiveField_Evolution(Image_G_1, 3, MinFloatingPointLRFValue, MaxFloatingPointLRFValue, MinLRFBiasValue, MaxLRFBiasValue, ReLUOutput);
		DataPreprocessing.Single_LocalReceptiveField_Evolution(Image_G_2, 3, MinFloatingPointLRFValue, MaxFloatingPointLRFValue, MinLRFBiasValue, MaxLRFBiasValue, ReLUOutput);

		DataPreprocessing.Single_LocalReceptiveField_Evolution(Image_8_1, 4, MinFloatingPointLRFValue, MaxFloatingPointLRFValue, MinLRFBiasValue, MaxLRFBiasValue, ReLUOutput);
		DataPreprocessing.Single_LocalReceptiveField_Evolution(Image_8_2, 4, MinFloatingPointLRFValue, MaxFloatingPointLRFValue, MinLRFBiasValue, MaxLRFBiasValue, ReLUOutput);

		DataPreprocessing.Single_LocalReceptiveField_Evolution(Image_B_1, 5, MinFloatingPointLRFValue, MaxFloatingPointLRFValue, MinLRFBiasValue, MaxLRFBiasValue, ReLUOutput);
		DataPreprocessing.Single_LocalReceptiveField_Evolution(Image_B_2, 5, MinFloatingPointLRFValue, MaxFloatingPointLRFValue, MinLRFBiasValue, MaxLRFBiasValue, ReLUOutput);
	}
#endif

#ifdef Use_IntegerLRFs
	for (uint32_t i = 0; i < 2000; i++)
	{
		DataPreprocessing.Single_LocalReceptiveField_Evolution(Image_5_1, 0, MinIntegerLRFValue, MaxIntegerLRFValue, MinLRFBiasValue, MaxLRFBiasValue, ReLUOutput);
		DataPreprocessing.Single_LocalReceptiveField_Evolution(Image_5_2, 0, MinIntegerLRFValue, MaxIntegerLRFValue, MinLRFBiasValue, MaxLRFBiasValue, ReLUOutput);

		DataPreprocessing.Single_LocalReceptiveField_Evolution(Image_S_1, 1, MinIntegerLRFValue, MaxIntegerLRFValue, MinLRFBiasValue, MaxLRFBiasValue, ReLUOutput);
		DataPreprocessing.Single_LocalReceptiveField_Evolution(Image_S_2, 1, MinIntegerLRFValue, MaxIntegerLRFValue, MinLRFBiasValue, MaxLRFBiasValue, ReLUOutput);

		DataPreprocessing.Single_LocalReceptiveField_Evolution(Image_6_1, 2, MinIntegerLRFValue, MaxIntegerLRFValue, MinLRFBiasValue, MaxLRFBiasValue, ReLUOutput);
		DataPreprocessing.Single_LocalReceptiveField_Evolution(Image_6_2, 2, MinIntegerLRFValue, MaxIntegerLRFValue, MinLRFBiasValue, MaxLRFBiasValue, ReLUOutput);

		DataPreprocessing.Single_LocalReceptiveField_Evolution(Image_G_1, 3, MinIntegerLRFValue, MaxIntegerLRFValue, MinLRFBiasValue, MaxLRFBiasValue, ReLUOutput);
		DataPreprocessing.Single_LocalReceptiveField_Evolution(Image_G_2, 3, MinIntegerLRFValue, MaxIntegerLRFValue, MinLRFBiasValue, MaxLRFBiasValue, ReLUOutput);

		DataPreprocessing.Single_LocalReceptiveField_Evolution(Image_8_1, 4, MinIntegerLRFValue, MaxIntegerLRFValue, MinLRFBiasValue, MaxLRFBiasValue, ReLUOutput);
		DataPreprocessing.Single_LocalReceptiveField_Evolution(Image_8_2, 4, MinIntegerLRFValue, MaxIntegerLRFValue, MinLRFBiasValue, MaxLRFBiasValue, ReLUOutput);

		DataPreprocessing.Single_LocalReceptiveField_Evolution(Image_B_1, 5, MinIntegerLRFValue, MaxIntegerLRFValue, MinLRFBiasValue, MaxLRFBiasValue, ReLUOutput);
		DataPreprocessing.Single_LocalReceptiveField_Evolution(Image_B_2, 5, MinIntegerLRFValue, MaxIntegerLRFValue, MinLRFBiasValue, MaxLRFBiasValue, ReLUOutput);
	}
#endif

#endif

#ifdef LRF_Evolution

	for (uint32_t i = 0; i < 1000; i++)
	{
		DataPreprocessing.Prepare_LocalReceptiveField_Analysis();

		DataPreprocessing.Analyze_LocalReceptiveFields(Image_5_1, ReLUOutput);
		DataPreprocessing.Analyze_LocalReceptiveFields(Image_5_2, ReLUOutput);

		DataPreprocessing.Analyze_LocalReceptiveFields(Image_S_1, ReLUOutput);
		DataPreprocessing.Analyze_LocalReceptiveFields(Image_S_2, ReLUOutput);

		DataPreprocessing.Analyze_LocalReceptiveFields(Image_6_1, ReLUOutput);
		DataPreprocessing.Analyze_LocalReceptiveFields(Image_6_2, ReLUOutput);

		DataPreprocessing.Analyze_LocalReceptiveFields(Image_G_1, ReLUOutput);
		DataPreprocessing.Analyze_LocalReceptiveFields(Image_G_2, ReLUOutput);

		DataPreprocessing.Analyze_LocalReceptiveFields(Image_8_1, ReLUOutput);
		DataPreprocessing.Analyze_LocalReceptiveFields(Image_8_2, ReLUOutput);

		DataPreprocessing.Analyze_LocalReceptiveFields(Image_B_1, ReLUOutput);
		DataPreprocessing.Analyze_LocalReceptiveFields(Image_B_2, ReLUOutput);

#ifdef Use_FloatingPointLRFs
		DataPreprocessing.Update_Evolution(MinFloatingPointLRFValue, MaxFloatingPointLRFValue, MinLRFBiasValue, MaxLRFBiasValue);
#endif
#ifdef Use_IntegerLRFs
		DataPreprocessing.Update_Evolution(MinIntegerLRFValue, MaxIntegerLRFValue, MinLRFBiasValue, MaxLRFBiasValue);
#endif
	}

	DataPreprocessing.Display_LocalReceptiveField_Analysis();

	cout << endl << "end of LRF evolution (press Return) " << endl << endl;

	getchar();

#endif

	// start training:

	for (uint32_t i = 0; i < maxCount; i++)
	{
		epoch++;
		error = 0.0f;

		DataPreprocessing.Preprocess_Data(&Brain, Image_5_1, ReLUOutput, UseImageL2Pooling2x2);
		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);
		error += Brain.Learning(DesiredOutputPattern1);

#ifdef LRF_Learning
		DataPreprocessing.Train_Final_LocalReceptiveFields(&Brain, LRF_LearningRate, ReceiverNeuronErrorFactor1, ReceiverNeuronErrorFactor2, InputErrorFactor1, InputErrorFactor2, OutputErrorFactor1, OutputErrorFactor2);
#endif

		DataPreprocessing.Preprocess_Data(&Brain, Image_5_2, ReLUOutput, UseImageL2Pooling2x2);
		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);
		error += Brain.Learning(DesiredOutputPattern1);

#ifdef LRF_Learning
		DataPreprocessing.Train_Final_LocalReceptiveFields(&Brain, LRF_LearningRate, ReceiverNeuronErrorFactor1, ReceiverNeuronErrorFactor2, InputErrorFactor1, InputErrorFactor2, OutputErrorFactor1, OutputErrorFactor2);
#endif

		DataPreprocessing.Preprocess_Data(&Brain, Image_S_1, ReLUOutput, UseImageL2Pooling2x2);
		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);
		error += Brain.Learning(DesiredOutputPattern2);

#ifdef LRF_Learning
		DataPreprocessing.Train_Final_LocalReceptiveFields(&Brain, LRF_LearningRate, ReceiverNeuronErrorFactor1, ReceiverNeuronErrorFactor2, InputErrorFactor1, InputErrorFactor2, OutputErrorFactor1, OutputErrorFactor2);
#endif

		DataPreprocessing.Preprocess_Data(&Brain, Image_S_2, ReLUOutput, UseImageL2Pooling2x2);
		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);
		error += Brain.Learning(DesiredOutputPattern2);

#ifdef LRF_Learning
		DataPreprocessing.Train_Final_LocalReceptiveFields(&Brain, LRF_LearningRate, ReceiverNeuronErrorFactor1, ReceiverNeuronErrorFactor2, InputErrorFactor1, InputErrorFactor2, OutputErrorFactor1, OutputErrorFactor2);
#endif

		DataPreprocessing.Preprocess_Data(&Brain, Image_6_1, ReLUOutput, UseImageL2Pooling2x2);
		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);
		error += Brain.Learning(DesiredOutputPattern3);

#ifdef LRF_Learning
		DataPreprocessing.Train_Final_LocalReceptiveFields(&Brain, LRF_LearningRate, ReceiverNeuronErrorFactor1, ReceiverNeuronErrorFactor2, InputErrorFactor1, InputErrorFactor2, OutputErrorFactor1, OutputErrorFactor2);
#endif

		DataPreprocessing.Preprocess_Data(&Brain, Image_6_2, ReLUOutput, UseImageL2Pooling2x2);
		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);
		error += Brain.Learning(DesiredOutputPattern3);

#ifdef LRF_Learning
		DataPreprocessing.Train_Final_LocalReceptiveFields(&Brain, LRF_LearningRate, ReceiverNeuronErrorFactor1, ReceiverNeuronErrorFactor2, InputErrorFactor1, InputErrorFactor2, OutputErrorFactor1, OutputErrorFactor2);
#endif

		DataPreprocessing.Preprocess_Data(&Brain, Image_G_1, ReLUOutput, UseImageL2Pooling2x2);
		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);
		error += Brain.Learning(DesiredOutputPattern4);

#ifdef LRF_Learning
		DataPreprocessing.Train_Final_LocalReceptiveFields(&Brain, LRF_LearningRate, ReceiverNeuronErrorFactor1, ReceiverNeuronErrorFactor2, InputErrorFactor1, InputErrorFactor2, OutputErrorFactor1, OutputErrorFactor2);
#endif

		DataPreprocessing.Preprocess_Data(&Brain, Image_G_2, ReLUOutput, UseImageL2Pooling2x2);
		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);
		error += Brain.Learning(DesiredOutputPattern4);

#ifdef LRF_Learning
		DataPreprocessing.Train_Final_LocalReceptiveFields(&Brain, LRF_LearningRate, ReceiverNeuronErrorFactor1, ReceiverNeuronErrorFactor2, InputErrorFactor1, InputErrorFactor2, OutputErrorFactor1, OutputErrorFactor2);
#endif

		DataPreprocessing.Preprocess_Data(&Brain, Image_8_1, ReLUOutput, UseImageL2Pooling2x2);
		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);
		error += Brain.Learning(DesiredOutputPattern5);

#ifdef LRF_Learning
		DataPreprocessing.Train_Final_LocalReceptiveFields(&Brain, LRF_LearningRate, ReceiverNeuronErrorFactor1, ReceiverNeuronErrorFactor2, InputErrorFactor1, InputErrorFactor2, OutputErrorFactor1, OutputErrorFactor2);
#endif

		DataPreprocessing.Preprocess_Data(&Brain, Image_8_2, ReLUOutput, UseImageL2Pooling2x2);
		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);
		error += Brain.Learning(DesiredOutputPattern5);

#ifdef LRF_Learning
		DataPreprocessing.Train_Final_LocalReceptiveFields(&Brain, LRF_LearningRate, ReceiverNeuronErrorFactor1, ReceiverNeuronErrorFactor2, InputErrorFactor1, InputErrorFactor2, OutputErrorFactor1, OutputErrorFactor2);
#endif

		DataPreprocessing.Preprocess_Data(&Brain, Image_B_1, ReLUOutput, UseImageL2Pooling2x2);
		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);
		error += Brain.Learning(DesiredOutputPattern6);

#ifdef LRF_Learning
		DataPreprocessing.Train_Final_LocalReceptiveFields(&Brain, LRF_LearningRate, ReceiverNeuronErrorFactor1, ReceiverNeuronErrorFactor2, InputErrorFactor1, InputErrorFactor2, OutputErrorFactor1, OutputErrorFactor2);
#endif

		DataPreprocessing.Preprocess_Data(&Brain, Image_B_2, ReLUOutput, UseImageL2Pooling2x2);
		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);
		error += Brain.Learning(DesiredOutputPattern6);

#ifdef LRF_Learning
		DataPreprocessing.Train_Final_LocalReceptiveFields(&Brain, LRF_LearningRate, ReceiverNeuronErrorFactor1, ReceiverNeuronErrorFactor2, InputErrorFactor1, InputErrorFactor2, OutputErrorFactor1, OutputErrorFactor2);
#endif

		if (error < 0.0001f)
			//if (error < 0.01f)
			break;

		Brain.RandomChange_OutputSynapsePlasticities2(seed++, -0.005f, 0.005f, 0.5f);
	}



	// training completed

	// training statistics:

	cout << "epoch: " << epoch << endl;
	cout << "error: " << error << endl << endl;

	cout << fixed;
	cout.precision(1);


	DataPreprocessing.Preprocess_Data(&Brain, Image_5_1, ReLUOutput, UseImageL2Pooling2x2);
	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);

	cout << "5 (1)" << " " << "desired output: 1 0 0 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	DataPreprocessing.Preprocess_Data(&Brain, Image_5_2, ReLUOutput, UseImageL2Pooling2x2);
	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);

	cout << "5 (2)" << " " << "desired output: 1 0 0 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	DataPreprocessing.Preprocess_Data(&Brain, Image_S_1, ReLUOutput, UseImageL2Pooling2x2);
	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);

	cout << "S (1)" << " " << "desired output: 0 1 0 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	DataPreprocessing.Preprocess_Data(&Brain, Image_S_2, ReLUOutput, UseImageL2Pooling2x2);
	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);

	cout << "S (2)" << " " << "desired output: 0 1 0 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	DataPreprocessing.Preprocess_Data(&Brain, Image_6_1, ReLUOutput, UseImageL2Pooling2x2);
	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);

	cout << "6 (1)" << " " << "desired output: 0 0 1 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	DataPreprocessing.Preprocess_Data(&Brain, Image_6_2, ReLUOutput, UseImageL2Pooling2x2);
	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);

	cout << "6 (2)" << " " << "desired output: 0 0 1 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	DataPreprocessing.Preprocess_Data(&Brain, Image_G_1, ReLUOutput, UseImageL2Pooling2x2);
	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);

	cout << "G (1)" << " " << "desired output: 0 0 0 1 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	DataPreprocessing.Preprocess_Data(&Brain, Image_G_2, ReLUOutput, UseImageL2Pooling2x2);
	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);

	cout << "G (2)" << " " << "desired output: 0 0 0 1 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	DataPreprocessing.Preprocess_Data(&Brain, Image_8_1, ReLUOutput, UseImageL2Pooling2x2);
	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);

	cout << "8 (1)" << " " << "desired output: 0 0 0 0 1 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	DataPreprocessing.Preprocess_Data(&Brain, Image_8_2, ReLUOutput, UseImageL2Pooling2x2);
	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);

	cout << "8 (2)" << " " << "desired output: 0 0 0 0 1 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	DataPreprocessing.Preprocess_Data(&Brain, Image_B_1, ReLUOutput, UseImageL2Pooling2x2);
	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);

	cout << "B (1)" << " " << "desired output: 0 0 0 0 0 1" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	DataPreprocessing.Preprocess_Data(&Brain, Image_B_2, ReLUOutput, UseImageL2Pooling2x2);
	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);

	cout << "B (2)" << " " << "desired output: 0 0 0 0 0 1" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	// test image(s):

	DataPreprocessing.Preprocess_Data(&Brain, Image_5_3, ReLUOutput, UseImageL2Pooling2x2);
	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);

	//Normalize(OutputPattern, 6);

	cout << "unknown 5" << " " << "desired output: 1 0 0 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	DataPreprocessing.Preprocess_Data(&Brain, Image_S_3, ReLUOutput, UseImageL2Pooling2x2);
	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);

	//Normalize(OutputPattern, 6);

	cout << "unknown S" << " " << "desired output: 0 1 0 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	DataPreprocessing.Preprocess_Data(&Brain, Image_6_3, ReLUOutput, UseImageL2Pooling2x2);
	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);

	//Normalize(OutputPattern, 6);

	cout << "unknown 6" << " " << "desired output: 0 0 1 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	DataPreprocessing.Preprocess_Data(&Brain, Image_G_3, ReLUOutput, UseImageL2Pooling2x2);
	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);

	//Normalize(OutputPattern, 6);

	cout << "unknown G" << " " << "desired output: 0 0 0 1 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	DataPreprocessing.Preprocess_Data(&Brain, Image_8_3, ReLUOutput, UseImageL2Pooling2x2);
	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);

	//Normalize(OutputPattern, 6);

	cout << "unknown 8" << " " << "desired output: 0 0 0 0 1 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	DataPreprocessing.Preprocess_Data(&Brain, Image_B_3, ReLUOutput, UseImageL2Pooling2x2);
	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);

	//Normalize(OutputPattern, 6);

	cout << "unknown B" << " " << "desired output: 0 0 0 0 0 1" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	getchar();
	return 0;
}
*/


/*
int main(void)
{
    int32_t MinIntegerLRFValue = -1;
	int32_t MaxIntegerLRFValue = 1;

	float MinFloatingPointLRFValue = -1.0f;
	float MaxFloatingPointLRFValue = 1.0f;

	float MinLRFBiasValue = -0.5f;
	float MaxLRFBiasValue = -0.5f;

	float MinPlasticityValue = -0.2f;
	float MaxPlasticityValue = 0.2f;

	float NeuralNetLearningRate = 0.5f;

	float LRF_LearningRate_L2 = 0.001f;
	float ReceiverNeuronErrorFactor1_L2 = 1.0f;
	float ReceiverNeuronErrorFactor2_L2 = 1.0f;
	float InputErrorFactor1_L2 = 1.0f;
	float InputErrorFactor2_L2 = 1.0f;
	float OutputErrorFactor1_L2 = 1.0f;
	float OutputErrorFactor2_L2 = 1.0f;

	float LRF_LearningRate_L1 = 0.001f;
	float InputErrorFactor1_L1 = 1.0f;
	float InputErrorFactor2_L1 = 1.0f;
	float OutputErrorFactor1_L1 = 1.0f;
	float OutputErrorFactor2_L1 = 1.0f;


	static float Image_5_1[32 * 32];
	static float Image_5_2[32 * 32];

	static float Image_S_1[32 * 32];
	static float Image_S_2[32 * 32];

	static float Image_6_1[32 * 32];
	static float Image_6_2[32 * 32];

	static float Image_G_1[32 * 32];
	static float Image_G_2[32 * 32];

	static float Image_8_1[32 * 32];
	static float Image_8_2[32 * 32];

	static float Image_B_1[32 * 32];
	static float Image_B_2[32 * 32];

	// test image(s):

	static float Image_5_3[32 * 32];
	static float Image_S_3[32 * 32];
	static float Image_6_3[32 * 32];
	static float Image_G_3[32 * 32];
	static float Image_8_3[32 * 32];
	static float Image_B_3[32 * 32];


	uint8_t *pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_5_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_5_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;


	pImageData = Read_Bitmap_BGR("Sample_S_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_S_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_S_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;


	pImageData = Read_Bitmap_BGR("Sample_6_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_6_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_6_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_G_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_G_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;


	pImageData = Read_Bitmap_BGR("Sample_B_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;


	// test image(s):

	pImageData = Read_Bitmap_BGR("Sample_5_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_5_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_S_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_6_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_6_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_G_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_G_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;


	uint32_t imageSizeX_L1 = 32;
	uint32_t imageSizeY_L1 = 32;
	uint32_t numFeatureMaps_L1 = 4;
	uint32_t localReceptiveFieldSizeX_L1 = 3;
	uint32_t localReceptiveFieldSizeY_L1 = 3;
	uint32_t stride_L1 = 1;

#ifdef Approximate_OrthonormalLRFs
	CImageDataPreprocessing DataPreprocessingL1(imageSizeX_L1, imageSizeY_L1, numFeatureMaps_L1, localReceptiveFieldSizeX_L1, localReceptiveFieldSizeY_L1, stride_L1, MinLRFBiasValue, MaxLRFBiasValue);
#endif
#ifdef Use_IntegerLRFs
	CImageDataPreprocessing DataPreprocessingL1(imageSizeX_L1, imageSizeY_L1, numFeatureMaps_L1, localReceptiveFieldSizeX_L1, localReceptiveFieldSizeY_L1, stride_L1, MinIntegerLRFValue, MaxIntegerLRFValue, MinLRFBiasValue, MaxLRFBiasValue);
#endif
#ifdef Use_FloatingPointLRFs
	CImageDataPreprocessing DataPreprocessingL1(imageSizeX_L1, imageSizeY_L1, numFeatureMaps_L1, localReceptiveFieldSizeX_L1, localReceptiveFieldSizeY_L1, stride_L1,  MinFloatingPointLRFValue, MaxFloatingPointLRFValue, MinLRFBiasValue, MaxLRFBiasValue);
#endif

	uint32_t imageSizeX_L2 = DataPreprocessingL1.FeatureMapSizeX;
	uint32_t imageSizeY_L2 = DataPreprocessingL1.FeatureMapSizeY;
	uint32_t numFeatureMaps_L2 = 3;
	uint32_t localReceptiveFieldSizeX_L2 = 5;
	uint32_t localReceptiveFieldSizeY_L2 = 5;
	uint32_t stride_L2 = 1;

#ifdef Approximate_OrthonormalLRFs
	CImageDataPreprocessing DataPreprocessingL2(imageSizeX_L2, imageSizeY_L2, numFeatureMaps_L2, localReceptiveFieldSizeX_L2, localReceptiveFieldSizeY_L2, stride_L2, MinLRFBiasValue, MaxLRFBiasValue);
#endif
#ifdef Use_IntegerLRFs
	CImageDataPreprocessing DataPreprocessingL2(imageSizeX_L2, imageSizeY_L2, numFeatureMaps_L2, localReceptiveFieldSizeX_L2, localReceptiveFieldSizeY_L2, stride_L2, MinIntegerLRFValue, MaxIntegerLRFValue, MinLRFBiasValue, MaxLRFBiasValue);
#endif
#ifdef Use_FloatingPointLRFs
	CImageDataPreprocessing DataPreprocessingL2(imageSizeX_L2, imageSizeY_L2, numFeatureMaps_L2, localReceptiveFieldSizeX_L2, localReceptiveFieldSizeY_L2, stride_L2, MinFloatingPointLRFValue, MaxFloatingPointLRFValue, MinLRFBiasValue, MaxLRFBiasValue);
#endif

	CNeuralNet Brain;
	Brain.Init_NeuralNet(numFeatureMaps_L2 * DataPreprocessingL2.FeatureMapSize + 6);
	Brain.Init_TwoLayerNetwork(numFeatureMaps_L2 * DataPreprocessingL2.FeatureMapSize, MinPlasticityValue, MaxPlasticityValue, NeuralNetLearningRate, false, 6, SigmoidOutput);


	uint32_t maxCount = 1000;
	uint32_t epoch = 0;
	float error;

	
	float OutputPattern[6];

	float DesiredOutputPattern1[6] = { 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f };
	float DesiredOutputPattern2[6] = { 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f };
	float DesiredOutputPattern3[6] = { 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f };
	float DesiredOutputPattern4[6] = { 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f };
	float DesiredOutputPattern5[6] = { 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f };
	float DesiredOutputPattern6[6] = { 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f };


	uint64_t seed = 1;
	


	// start training:

	for (uint32_t i = 0; i < maxCount; i++)
	{
		epoch++;
		error = 0.0f;

		DataPreprocessingL1.Preprocess_Data(Image_5_1, ReLUOutput, UseImageL2Pooling2x2);
		DataPreprocessingL2.Preprocess_Data(&Brain, DataPreprocessingL1.pFeatureMapArray, DataPreprocessingL1.NumFeatureMaps, ReLUOutput, UseImageL2Pooling2x2);
		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);
		error += Brain.Learning(DesiredOutputPattern1);

#ifdef LRF_Learning
		DataPreprocessingL2.Train_Final_LocalReceptiveFields(&Brain, LRF_LearningRate_L2, ReceiverNeuronErrorFactor1_L2, ReceiverNeuronErrorFactor2_L2, InputErrorFactor1_L2, InputErrorFactor2_L2, OutputErrorFactor1_L2, OutputErrorFactor2_L2);
#endif
#ifdef LRF_Learning_2
		DataPreprocessingL1.Train_LocalReceptiveFields(&DataPreprocessingL2, LRF_LearningRate_L1, InputErrorFactor1_L1, InputErrorFactor2_L1, OutputErrorFactor1_L1, OutputErrorFactor2_L1);
#endif

		DataPreprocessingL1.Preprocess_Data(Image_5_2, ReLUOutput, UseImageL2Pooling2x2);
		DataPreprocessingL2.Preprocess_Data(&Brain, DataPreprocessingL1.pFeatureMapArray, DataPreprocessingL1.NumFeatureMaps, ReLUOutput, UseImageL2Pooling2x2);
		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);
		error += Brain.Learning(DesiredOutputPattern1);

#ifdef LRF_Learning
		DataPreprocessingL2.Train_Final_LocalReceptiveFields(&Brain, LRF_LearningRate_L2, ReceiverNeuronErrorFactor1_L2, ReceiverNeuronErrorFactor2_L2, InputErrorFactor1_L2, InputErrorFactor2_L2, OutputErrorFactor1_L2, OutputErrorFactor2_L2);
#endif
#ifdef LRF_Learning_2
		DataPreprocessingL1.Train_LocalReceptiveFields(&DataPreprocessingL2, LRF_LearningRate_L1, InputErrorFactor1_L1, InputErrorFactor2_L1, OutputErrorFactor1_L1, OutputErrorFactor2_L1);
#endif

		DataPreprocessingL1.Preprocess_Data(Image_S_1, ReLUOutput, UseImageL2Pooling2x2);
		DataPreprocessingL2.Preprocess_Data(&Brain, DataPreprocessingL1.pFeatureMapArray, DataPreprocessingL1.NumFeatureMaps, ReLUOutput, UseImageL2Pooling2x2);
		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);
		error += Brain.Learning(DesiredOutputPattern2);

#ifdef LRF_Learning
		DataPreprocessingL2.Train_Final_LocalReceptiveFields(&Brain, LRF_LearningRate_L2, ReceiverNeuronErrorFactor1_L2, ReceiverNeuronErrorFactor2_L2, InputErrorFactor1_L2, InputErrorFactor2_L2, OutputErrorFactor1_L2, OutputErrorFactor2_L2);
#endif
#ifdef LRF_Learning_2
		DataPreprocessingL1.Train_LocalReceptiveFields(&DataPreprocessingL2, LRF_LearningRate_L1, InputErrorFactor1_L1, InputErrorFactor2_L1, OutputErrorFactor1_L1, OutputErrorFactor2_L1);
#endif

		DataPreprocessingL1.Preprocess_Data(Image_S_2, ReLUOutput, UseImageL2Pooling2x2);
		DataPreprocessingL2.Preprocess_Data(&Brain, DataPreprocessingL1.pFeatureMapArray, DataPreprocessingL1.NumFeatureMaps, ReLUOutput, UseImageL2Pooling2x2);
		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);
		error += Brain.Learning(DesiredOutputPattern2);

#ifdef LRF_Learning
		DataPreprocessingL2.Train_Final_LocalReceptiveFields(&Brain, LRF_LearningRate_L2, ReceiverNeuronErrorFactor1_L2, ReceiverNeuronErrorFactor2_L2, InputErrorFactor1_L2, InputErrorFactor2_L2, OutputErrorFactor1_L2, OutputErrorFactor2_L2);
#endif
#ifdef LRF_Learning_2
		DataPreprocessingL1.Train_LocalReceptiveFields(&DataPreprocessingL2, LRF_LearningRate_L1, InputErrorFactor1_L1, InputErrorFactor2_L1, OutputErrorFactor1_L1, OutputErrorFactor2_L1);
#endif

		DataPreprocessingL1.Preprocess_Data(Image_6_1, ReLUOutput, UseImageL2Pooling2x2);
		DataPreprocessingL2.Preprocess_Data(&Brain, DataPreprocessingL1.pFeatureMapArray, DataPreprocessingL1.NumFeatureMaps, ReLUOutput, UseImageL2Pooling2x2);
		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);
		error += Brain.Learning(DesiredOutputPattern3);

#ifdef LRF_Learning
		DataPreprocessingL2.Train_Final_LocalReceptiveFields(&Brain, LRF_LearningRate_L2, ReceiverNeuronErrorFactor1_L2, ReceiverNeuronErrorFactor2_L2, InputErrorFactor1_L2, InputErrorFactor2_L2, OutputErrorFactor1_L2, OutputErrorFactor2_L2);
#endif
#ifdef LRF_Learning_2
		DataPreprocessingL1.Train_LocalReceptiveFields(&DataPreprocessingL2, LRF_LearningRate_L1, InputErrorFactor1_L1, InputErrorFactor2_L1, OutputErrorFactor1_L1, OutputErrorFactor2_L1);
#endif

		DataPreprocessingL1.Preprocess_Data(Image_6_2, ReLUOutput, UseImageL2Pooling2x2);
		DataPreprocessingL2.Preprocess_Data(&Brain, DataPreprocessingL1.pFeatureMapArray, DataPreprocessingL1.NumFeatureMaps, ReLUOutput, UseImageL2Pooling2x2);
		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);
		error += Brain.Learning(DesiredOutputPattern3);

#ifdef LRF_Learning
		DataPreprocessingL2.Train_Final_LocalReceptiveFields(&Brain, LRF_LearningRate_L2, ReceiverNeuronErrorFactor1_L2, ReceiverNeuronErrorFactor2_L2, InputErrorFactor1_L2, InputErrorFactor2_L2, OutputErrorFactor1_L2, OutputErrorFactor2_L2);
#endif
#ifdef LRF_Learning_2
		DataPreprocessingL1.Train_LocalReceptiveFields(&DataPreprocessingL2, LRF_LearningRate_L1, InputErrorFactor1_L1, InputErrorFactor2_L1, OutputErrorFactor1_L1, OutputErrorFactor2_L1);
#endif

		DataPreprocessingL1.Preprocess_Data(Image_G_1, ReLUOutput, UseImageL2Pooling2x2);
		DataPreprocessingL2.Preprocess_Data(&Brain, DataPreprocessingL1.pFeatureMapArray, DataPreprocessingL1.NumFeatureMaps, ReLUOutput, UseImageL2Pooling2x2);
		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);
		error += Brain.Learning(DesiredOutputPattern4);

#ifdef LRF_Learning
		DataPreprocessingL2.Train_Final_LocalReceptiveFields(&Brain, LRF_LearningRate_L2, ReceiverNeuronErrorFactor1_L2, ReceiverNeuronErrorFactor2_L2, InputErrorFactor1_L2, InputErrorFactor2_L2, OutputErrorFactor1_L2, OutputErrorFactor2_L2);
#endif
#ifdef LRF_Learning_2
		DataPreprocessingL1.Train_LocalReceptiveFields(&DataPreprocessingL2, LRF_LearningRate_L1, InputErrorFactor1_L1, InputErrorFactor2_L1, OutputErrorFactor1_L1, OutputErrorFactor2_L1);
#endif

		DataPreprocessingL1.Preprocess_Data(Image_G_2, ReLUOutput, UseImageL2Pooling2x2);
		DataPreprocessingL2.Preprocess_Data(&Brain, DataPreprocessingL1.pFeatureMapArray, DataPreprocessingL1.NumFeatureMaps, ReLUOutput, UseImageL2Pooling2x2);
		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);
		error += Brain.Learning(DesiredOutputPattern4);

#ifdef LRF_Learning
		DataPreprocessingL2.Train_Final_LocalReceptiveFields(&Brain, LRF_LearningRate_L2, ReceiverNeuronErrorFactor1_L2, ReceiverNeuronErrorFactor2_L2, InputErrorFactor1_L2, InputErrorFactor2_L2, OutputErrorFactor1_L2, OutputErrorFactor2_L2);
#endif
#ifdef LRF_Learning_2
		DataPreprocessingL1.Train_LocalReceptiveFields(&DataPreprocessingL2, LRF_LearningRate_L1, InputErrorFactor1_L1, InputErrorFactor2_L1, OutputErrorFactor1_L1, OutputErrorFactor2_L1);
#endif

		DataPreprocessingL1.Preprocess_Data(Image_8_1, ReLUOutput, UseImageL2Pooling2x2);
		DataPreprocessingL2.Preprocess_Data(&Brain, DataPreprocessingL1.pFeatureMapArray, DataPreprocessingL1.NumFeatureMaps, ReLUOutput, UseImageL2Pooling2x2);
		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);
		error += Brain.Learning(DesiredOutputPattern5);

#ifdef LRF_Learning
		DataPreprocessingL2.Train_Final_LocalReceptiveFields(&Brain, LRF_LearningRate_L2, ReceiverNeuronErrorFactor1_L2, ReceiverNeuronErrorFactor2_L2, InputErrorFactor1_L2, InputErrorFactor2_L2, OutputErrorFactor1_L2, OutputErrorFactor2_L2);
#endif
#ifdef LRF_Learning_2
		DataPreprocessingL1.Train_LocalReceptiveFields(&DataPreprocessingL2, LRF_LearningRate_L1, InputErrorFactor1_L1, InputErrorFactor2_L1, OutputErrorFactor1_L1, OutputErrorFactor2_L1);
#endif

		DataPreprocessingL1.Preprocess_Data(Image_8_2, ReLUOutput, UseImageL2Pooling2x2);
		DataPreprocessingL2.Preprocess_Data(&Brain, DataPreprocessingL1.pFeatureMapArray, DataPreprocessingL1.NumFeatureMaps, ReLUOutput, UseImageL2Pooling2x2);
		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);
		error += Brain.Learning(DesiredOutputPattern5);

#ifdef LRF_Learning
		DataPreprocessingL2.Train_Final_LocalReceptiveFields(&Brain, LRF_LearningRate_L2, ReceiverNeuronErrorFactor1_L2, ReceiverNeuronErrorFactor2_L2, InputErrorFactor1_L2, InputErrorFactor2_L2, OutputErrorFactor1_L2, OutputErrorFactor2_L2);
#endif
#ifdef LRF_Learning_2
		DataPreprocessingL1.Train_LocalReceptiveFields(&DataPreprocessingL2, LRF_LearningRate_L1, InputErrorFactor1_L1, InputErrorFactor2_L1, OutputErrorFactor1_L1, OutputErrorFactor2_L1);
#endif

		DataPreprocessingL1.Preprocess_Data(Image_B_1, ReLUOutput, UseImageL2Pooling2x2);
		DataPreprocessingL2.Preprocess_Data(&Brain, DataPreprocessingL1.pFeatureMapArray, DataPreprocessingL1.NumFeatureMaps, ReLUOutput, UseImageL2Pooling2x2);
		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);
		error += Brain.Learning(DesiredOutputPattern6);

#ifdef LRF_Learning
		DataPreprocessingL2.Train_Final_LocalReceptiveFields(&Brain, LRF_LearningRate_L2, ReceiverNeuronErrorFactor1_L2, ReceiverNeuronErrorFactor2_L2, InputErrorFactor1_L2, InputErrorFactor2_L2, OutputErrorFactor1_L2, OutputErrorFactor2_L2);
#endif
#ifdef LRF_Learning_2
		DataPreprocessingL1.Train_LocalReceptiveFields(&DataPreprocessingL2, LRF_LearningRate_L1, InputErrorFactor1_L1, InputErrorFactor2_L1, OutputErrorFactor1_L1, OutputErrorFactor2_L1);
#endif

		DataPreprocessingL1.Preprocess_Data(Image_B_2, ReLUOutput, UseImageL2Pooling2x2);
		DataPreprocessingL2.Preprocess_Data(&Brain, DataPreprocessingL1.pFeatureMapArray, DataPreprocessingL1.NumFeatureMaps, ReLUOutput, UseImageL2Pooling2x2);
		Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);
		error += Brain.Learning(DesiredOutputPattern6);

#ifdef LRF_Learning
		DataPreprocessingL2.Train_Final_LocalReceptiveFields(&Brain, LRF_LearningRate_L2, ReceiverNeuronErrorFactor1_L2, ReceiverNeuronErrorFactor2_L2, InputErrorFactor1_L2, InputErrorFactor2_L2, OutputErrorFactor1_L2, OutputErrorFactor2_L2);
#endif
#ifdef LRF_Learning_2
		DataPreprocessingL1.Train_LocalReceptiveFields(&DataPreprocessingL2, LRF_LearningRate_L1, InputErrorFactor1_L1, InputErrorFactor2_L1, OutputErrorFactor1_L1, OutputErrorFactor2_L1);
#endif

		if (error < 0.0001f)
			//if (error < 0.01f)
			break;

		
		//Brain.RandomChange_OutputSynapsePlasticities2(seed++, -0.005f, 0.005f, 0.5f);
	}


	// training completed

	// training statistics:

	cout << "epoch: " << epoch << endl;
	cout << "error: " << error << endl << endl;

	cout << fixed;
	cout.precision(1);


	DataPreprocessingL1.Preprocess_Data(Image_5_1, ReLUOutput, UseImageL2Pooling2x2);
	DataPreprocessingL2.Preprocess_Data(&Brain, DataPreprocessingL1.pFeatureMapArray, DataPreprocessingL1.NumFeatureMaps, ReLUOutput, UseImageL2Pooling2x2);
	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);

	cout << "5 (1)" << " " << "desired output: 1 0 0 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	DataPreprocessingL1.Preprocess_Data(Image_5_2, ReLUOutput, UseImageL2Pooling2x2);
	DataPreprocessingL2.Preprocess_Data(&Brain, DataPreprocessingL1.pFeatureMapArray, DataPreprocessingL1.NumFeatureMaps, ReLUOutput, UseImageL2Pooling2x2);
	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);

	cout << "5 (2)" << " " << "desired output: 1 0 0 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	DataPreprocessingL1.Preprocess_Data(Image_S_1, ReLUOutput, UseImageL2Pooling2x2);
	DataPreprocessingL2.Preprocess_Data(&Brain, DataPreprocessingL1.pFeatureMapArray, DataPreprocessingL1.NumFeatureMaps, ReLUOutput, UseImageL2Pooling2x2);
	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);

	cout << "S (1)" << " " << "desired output: 0 1 0 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	DataPreprocessingL1.Preprocess_Data(Image_S_2, ReLUOutput, UseImageL2Pooling2x2);
	DataPreprocessingL2.Preprocess_Data(&Brain, DataPreprocessingL1.pFeatureMapArray, DataPreprocessingL1.NumFeatureMaps, ReLUOutput, UseImageL2Pooling2x2);
	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);

	cout << "S (2)" << " " << "desired output: 0 1 0 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	DataPreprocessingL1.Preprocess_Data(Image_6_1, ReLUOutput, UseImageL2Pooling2x2);
	DataPreprocessingL2.Preprocess_Data(&Brain, DataPreprocessingL1.pFeatureMapArray, DataPreprocessingL1.NumFeatureMaps, ReLUOutput, UseImageL2Pooling2x2);
	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);

	cout << "6 (1)" << " " << "desired output: 0 0 1 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	DataPreprocessingL1.Preprocess_Data(Image_6_2, ReLUOutput, UseImageL2Pooling2x2);
	DataPreprocessingL2.Preprocess_Data(&Brain, DataPreprocessingL1.pFeatureMapArray, DataPreprocessingL1.NumFeatureMaps, ReLUOutput, UseImageL2Pooling2x2);
	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);

	cout << "6 (2)" << " " << "desired output: 0 0 1 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	DataPreprocessingL1.Preprocess_Data(Image_G_1, ReLUOutput, UseImageL2Pooling2x2);
	DataPreprocessingL2.Preprocess_Data(&Brain, DataPreprocessingL1.pFeatureMapArray, DataPreprocessingL1.NumFeatureMaps, ReLUOutput, UseImageL2Pooling2x2);
	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);

	cout << "G (1)" << " " << "desired output: 0 0 0 1 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	DataPreprocessingL1.Preprocess_Data(Image_G_2, ReLUOutput, UseImageL2Pooling2x2);
	DataPreprocessingL2.Preprocess_Data(&Brain, DataPreprocessingL1.pFeatureMapArray, DataPreprocessingL1.NumFeatureMaps, ReLUOutput, UseImageL2Pooling2x2);
	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);

	cout << "G (2)" << " " << "desired output: 0 0 0 1 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	DataPreprocessingL1.Preprocess_Data(Image_8_1, ReLUOutput, UseImageL2Pooling2x2);
	DataPreprocessingL2.Preprocess_Data(&Brain, DataPreprocessingL1.pFeatureMapArray, DataPreprocessingL1.NumFeatureMaps, ReLUOutput, UseImageL2Pooling2x2);
	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);

	cout << "8 (1)" << " " << "desired output: 0 0 0 0 1 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	DataPreprocessingL1.Preprocess_Data(Image_8_2, ReLUOutput, UseImageL2Pooling2x2);
	DataPreprocessingL2.Preprocess_Data(&Brain, DataPreprocessingL1.pFeatureMapArray, DataPreprocessingL1.NumFeatureMaps, ReLUOutput, UseImageL2Pooling2x2);
	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);

	cout << "8 (2)" << " " << "desired output: 0 0 0 0 1 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	DataPreprocessingL1.Preprocess_Data(Image_B_1, ReLUOutput, UseImageL2Pooling2x2);
	DataPreprocessingL2.Preprocess_Data(&Brain, DataPreprocessingL1.pFeatureMapArray, DataPreprocessingL1.NumFeatureMaps, ReLUOutput, UseImageL2Pooling2x2);
	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);

	cout << "B (1)" << " " << "desired output: 0 0 0 0 0 1" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	DataPreprocessingL1.Preprocess_Data(Image_B_2, ReLUOutput, UseImageL2Pooling2x2);
	DataPreprocessingL2.Preprocess_Data(&Brain, DataPreprocessingL1.pFeatureMapArray, DataPreprocessingL1.NumFeatureMaps, ReLUOutput, UseImageL2Pooling2x2);
	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);

	cout << "B (2)" << " " << "desired output: 0 0 0 0 0 1" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	// test image(s):

	DataPreprocessingL1.Preprocess_Data(Image_5_3, ReLUOutput, UseImageL2Pooling2x2);
	DataPreprocessingL2.Preprocess_Data(&Brain, DataPreprocessingL1.pFeatureMapArray, DataPreprocessingL1.NumFeatureMaps, ReLUOutput, UseImageL2Pooling2x2);
	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);

	//Normalize(OutputPattern, 6);

	cout << "unknown 5" << " " << "desired output: 1 0 0 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	DataPreprocessingL1.Preprocess_Data(Image_S_3, ReLUOutput, UseImageL2Pooling2x2);
	DataPreprocessingL2.Preprocess_Data(&Brain, DataPreprocessingL1.pFeatureMapArray, DataPreprocessingL1.NumFeatureMaps, ReLUOutput, UseImageL2Pooling2x2);
	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);

	//Normalize(OutputPattern, 6);

	cout << "unknown S" << " " << "desired output: 0 1 0 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	DataPreprocessingL1.Preprocess_Data(Image_6_3, ReLUOutput, UseImageL2Pooling2x2);
	DataPreprocessingL2.Preprocess_Data(&Brain, DataPreprocessingL1.pFeatureMapArray, DataPreprocessingL1.NumFeatureMaps, ReLUOutput, UseImageL2Pooling2x2);
	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);

	//Normalize(OutputPattern, 6);

	cout << "unknown 6" << " " << "desired output: 0 0 1 0 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	DataPreprocessingL1.Preprocess_Data(Image_G_3, ReLUOutput, UseImageL2Pooling2x2);
	DataPreprocessingL2.Preprocess_Data(&Brain, DataPreprocessingL1.pFeatureMapArray, DataPreprocessingL1.NumFeatureMaps, ReLUOutput, UseImageL2Pooling2x2);
	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);

	//Normalize(OutputPattern, 6);

	cout << "unknown G" << " " << "desired output: 0 0 0 1 0 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	DataPreprocessingL1.Preprocess_Data(Image_8_3, ReLUOutput, UseImageL2Pooling2x2);
	DataPreprocessingL2.Preprocess_Data(&Brain, DataPreprocessingL1.pFeatureMapArray, DataPreprocessingL1.NumFeatureMaps, ReLUOutput, UseImageL2Pooling2x2);
	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);

	//Normalize(OutputPattern, 6);

	cout << "unknown 8" << " " << "desired output: 0 0 0 0 1 0" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	DataPreprocessingL1.Preprocess_Data(Image_B_3, ReLUOutput, UseImageL2Pooling2x2);
	DataPreprocessingL2.Preprocess_Data(&Brain, DataPreprocessingL1.pFeatureMapArray, DataPreprocessingL1.NumFeatureMaps, ReLUOutput, UseImageL2Pooling2x2);
	Brain.Calculate_Output_TwoLayerNetwork(OutputPattern);

	//Normalize(OutputPattern, 6);

	cout << "unknown B" << " " << "desired output: 0 0 0 0 0 1" << endl;
	cout << OutputPattern[0] << " " << OutputPattern[1] << " ";
	cout << OutputPattern[2] << " " << OutputPattern[3] << " ";
	cout << OutputPattern[4] << " " << OutputPattern[5] << " " << endl;

	getchar();
	return 0;
}
*/