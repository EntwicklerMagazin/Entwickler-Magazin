#include <iostream>
#include "SokobanClone.h"
#include "LogFile.h"
#include "ConsoleHelperFunctions.h"
#include <omp.h>

using namespace std;
using namespace HelperStuff;

#define OpenMP_Pathfinding

void Get_PlayerPos(int32_t *pOutPosX, int32_t *pOutPosY, int8_t *pGamesWorldData, int32_t GamesWorldSizeX, int32_t GamesWorldSizeY)
{
	for(int32_t iy = 0; iy < GamesWorldSizeY; iy++)
	{
		int32_t iiy = iy * GamesWorldSizeX;

		for (int32_t ix = 0; ix < GamesWorldSizeX; ix++)
		{
			int8_t value = pGamesWorldData[ix + iiy];

			if(value == ConstGameBoard_Player || value == ConstGameBoard_DestinationWithPlayer)
			{
				*pOutPosX = ix;
				*pOutPosY = iy;
				return;
			}
		}
	}
}

int8_t Get_TileType_Of_GamesWorldPos(int32_t posX, int32_t posY, int8_t *pGamesWorldData, int32_t gamesWorldSizeX)
{
	return pGamesWorldData[posX + posY * gamesWorldSizeX];
}

bool Update_GamesWorld_AfterPlayerMovement(int32_t newPlayerPosX, int32_t newPlayerPosY, int32_t oldPlayerPosX, int32_t oldPlayerPosY, int8_t *pGamesWorldData, int32_t gamesWorldSizeX)
{
	int32_t newPlayerPosID = newPlayerPosX + newPlayerPosY * gamesWorldSizeX;

	int8_t tileType_newPlayerPos = pGamesWorldData[newPlayerPosID];

	if (tileType_newPlayerPos == ConstGameBoard_Wall)
	{
		return false;
	}

	int32_t oldPlayerPosID = oldPlayerPosX + oldPlayerPosY * gamesWorldSizeX;

	int8_t tileType_oldPlayerPos = pGamesWorldData[oldPlayerPosID];

	if (tileType_newPlayerPos == ConstGameBoard_Empty && tileType_oldPlayerPos == ConstGameBoard_Player)
	{
		pGamesWorldData[newPlayerPosID] = ConstGameBoard_Player;
		pGamesWorldData[oldPlayerPosID] = ConstGameBoard_Empty;
		return false;
	}
	if (tileType_newPlayerPos == ConstGameBoard_Destination && tileType_oldPlayerPos == ConstGameBoard_Player)
	{
		pGamesWorldData[newPlayerPosID] = ConstGameBoard_DestinationWithPlayer;
		pGamesWorldData[oldPlayerPosID] = ConstGameBoard_Empty;
		return false;
	}
	if (tileType_newPlayerPos == ConstGameBoard_Destination && tileType_oldPlayerPos == ConstGameBoard_DestinationWithPlayer)
	{
		pGamesWorldData[newPlayerPosID] = ConstGameBoard_DestinationWithPlayer;
		pGamesWorldData[oldPlayerPosID] = ConstGameBoard_Destination;
		return false;
	}
	if (tileType_newPlayerPos == ConstGameBoard_Empty && tileType_oldPlayerPos == ConstGameBoard_DestinationWithPlayer)
	{
		pGamesWorldData[newPlayerPosID] = ConstGameBoard_Player;
		pGamesWorldData[oldPlayerPosID] = ConstGameBoard_Destination;
		return false;
	}
	

	if (tileType_newPlayerPos == ConstGameBoard_Box && tileType_oldPlayerPos == ConstGameBoard_Player)
	{
		pGamesWorldData[newPlayerPosID] = ConstGameBoard_Player;
		pGamesWorldData[oldPlayerPosID] = ConstGameBoard_Empty;
		return true;
	}
	if (tileType_newPlayerPos == ConstGameBoard_Box && tileType_oldPlayerPos == ConstGameBoard_DestinationWithPlayer)
	{
		pGamesWorldData[newPlayerPosID] = ConstGameBoard_Player;
		pGamesWorldData[oldPlayerPosID] = ConstGameBoard_Destination;
		return true;
	}
	if (tileType_newPlayerPos == ConstGameBoard_DestinationWithBox && tileType_oldPlayerPos == ConstGameBoard_Player)
	{
		pGamesWorldData[newPlayerPosID] = ConstGameBoard_DestinationWithPlayer;
		pGamesWorldData[oldPlayerPosID] = ConstGameBoard_Empty;
		return true;
	}
	if (tileType_newPlayerPos == ConstGameBoard_DestinationWithBox && tileType_oldPlayerPos == ConstGameBoard_DestinationWithPlayer)
	{
		pGamesWorldData[newPlayerPosID] = ConstGameBoard_DestinationWithPlayer;
		pGamesWorldData[oldPlayerPosID] = ConstGameBoard_Destination;
		return true;
	}


	return false;
	
}


bool Pull_Box(int32_t oldPossibleBoxPosX, int32_t oldPossibleBoxPosY, int32_t oldPlayerPosX, int32_t oldPlayerPosY, int8_t tileTypeOldPlayerPos, int8_t *pGamesWorldData, int32_t gamesWorldSizeX)
{
	int8_t tileTypeOldPossibleBoxPos = pGamesWorldData[oldPossibleBoxPosX + oldPossibleBoxPosY * gamesWorldSizeX];
	
	if (tileTypeOldPossibleBoxPos == ConstGameBoard_Box)
	{
		if (tileTypeOldPlayerPos == ConstGameBoard_Player)
		{
			pGamesWorldData[oldPlayerPosX + oldPlayerPosY * gamesWorldSizeX] = ConstGameBoard_Box;
		}
		else if (tileTypeOldPlayerPos == ConstGameBoard_DestinationWithPlayer)
		{
			pGamesWorldData[oldPlayerPosX + oldPlayerPosY * gamesWorldSizeX] = ConstGameBoard_DestinationWithBox;
		}

		pGamesWorldData[oldPossibleBoxPosX + oldPossibleBoxPosY * gamesWorldSizeX] = ConstGameBoard_Empty;
		return true;

	}
	else if (tileTypeOldPossibleBoxPos == ConstGameBoard_DestinationWithBox)
	{
		if (tileTypeOldPlayerPos == ConstGameBoard_Player)
		{
			pGamesWorldData[oldPlayerPosX + oldPlayerPosY * gamesWorldSizeX] = ConstGameBoard_Box;
		}
		else if (tileTypeOldPlayerPos == ConstGameBoard_DestinationWithPlayer)
		{
			pGamesWorldData[oldPlayerPosX + oldPlayerPosY * gamesWorldSizeX] = ConstGameBoard_DestinationWithBox;
		}

		pGamesWorldData[oldPossibleBoxPosX + oldPossibleBoxPosY * gamesWorldSizeX] = ConstGameBoard_Destination;
		return true;
	}

	return false;
}

bool Check_PossibleWin(int32_t numOfBoxesInsideGamesWorld, int8_t *pGamesWorldData, int32_t gamesWorldSizeX, int32_t gamesWorldSizeY)
{
	int32_t sizeXY = gamesWorldSizeX * gamesWorldSizeY;

	int32_t sum = 0;

	for (int32_t i = 0; i < sizeXY; i++)
	{
		if (pGamesWorldData[i] == ConstGameBoard_DestinationWithBox)
			sum++;
	}

	if (sum == numOfBoxesInsideGamesWorld)
		return true;

	return false;
}

bool Set_BoxPos_If_Possible(int32_t boxPosX, int32_t boxPosY, int8_t *pGamesWorldData, int32_t gamesWorldSizeX)
{
	int32_t posID = boxPosX + boxPosY * gamesWorldSizeX;

	int8_t tileType = pGamesWorldData[posID];

	if (tileType == ConstGameBoard_Box)
		return false;
	if (tileType == ConstGameBoard_DestinationWithBox)
		return false;
	if (tileType == ConstGameBoard_Wall)
		return false;

	if (tileType == ConstGameBoard_Empty)
	{
		pGamesWorldData[posID] = ConstGameBoard_Box;
		return true;
	}
	if (tileType == ConstGameBoard_Destination)
	{
		pGamesWorldData[posID] = ConstGameBoard_DestinationWithBox;
		return true;
	}

	return false;
}
bool Check_PossibleBoxLeftPushMove(int32_t possibleBoxPosX, int32_t possibleBoxPosY, int8_t *pGamesWorldData, int32_t gamesWorldSizeX)
{
	int32_t oldPosID = possibleBoxPosX + possibleBoxPosY * gamesWorldSizeX;

	int8_t tileType_oldPos = pGamesWorldData[oldPosID];

	if (tileType_oldPos != ConstGameBoard_Box && tileType_oldPos != ConstGameBoard_DestinationWithBox)
		return false;
	
	possibleBoxPosX--;

	int32_t newPosID = possibleBoxPosX + possibleBoxPosY * gamesWorldSizeX;

	int8_t tileType_newPos = pGamesWorldData[newPosID];

	if (tileType_newPos == ConstGameBoard_Empty)
		return true;
	if (tileType_newPos == ConstGameBoard_Destination)
		return true;

	return false;
}

bool Check_PossibleBoxRightPushMove(int32_t possibleBoxPosX, int32_t possibleBoxPosY, int8_t *pGamesWorldData, int32_t gamesWorldSizeX)
{
	int32_t oldPosID = possibleBoxPosX + possibleBoxPosY * gamesWorldSizeX;

	int8_t tileType_oldPos = pGamesWorldData[oldPosID];

	if (tileType_oldPos != ConstGameBoard_Box && tileType_oldPos != ConstGameBoard_DestinationWithBox)
		return false;

	possibleBoxPosX++;

	int32_t newPosID = possibleBoxPosX + possibleBoxPosY * gamesWorldSizeX;

	int8_t tileType_newPos = pGamesWorldData[newPosID];

	if (tileType_newPos == ConstGameBoard_Empty)
		return true;
	if (tileType_newPos == ConstGameBoard_Destination)
		return true;

	return false;
}

bool Check_PossibleBoxUpwardPushMove(int32_t possibleBoxPosX, int32_t possibleBoxPosY, int8_t *pGamesWorldData, int32_t gamesWorldSizeX)
{
	int32_t oldPosID = possibleBoxPosX + possibleBoxPosY * gamesWorldSizeX;

	int8_t tileType_oldPos = pGamesWorldData[oldPosID];

	if (tileType_oldPos != ConstGameBoard_Box && tileType_oldPos != ConstGameBoard_DestinationWithBox)
		return false;

	possibleBoxPosY--;

	int32_t newPosID = possibleBoxPosX + possibleBoxPosY * gamesWorldSizeX;

	int8_t tileType_newPos = pGamesWorldData[newPosID];

	if (tileType_newPos == ConstGameBoard_Empty)
		return true;
	if (tileType_newPos == ConstGameBoard_Destination)
		return true;

	return false;
}

bool Check_PossibleBoxDownwardPushMove(int32_t possibleBoxPosX, int32_t possibleBoxPosY, int8_t *pGamesWorldData, int32_t gamesWorldSizeX)
{
	int32_t oldPosID = possibleBoxPosX + possibleBoxPosY * gamesWorldSizeX;

	int8_t tileType_oldPos = pGamesWorldData[oldPosID];

	if (tileType_oldPos != ConstGameBoard_Box && tileType_oldPos != ConstGameBoard_DestinationWithBox)
		return false;

	possibleBoxPosY++;

	int32_t newBoxPosID = possibleBoxPosX + possibleBoxPosY * gamesWorldSizeX;

	int8_t tileType_newPos = pGamesWorldData[newBoxPosID];

	if (tileType_newPos == ConstGameBoard_Empty)
		return true;
	if (tileType_newPos == ConstGameBoard_Destination)
		return true;

	return false;
}


CSokobanGameStateCharacteristics::CSokobanGameStateCharacteristics()
{}

CSokobanGameStateCharacteristics::~CSokobanGameStateCharacteristics()
{
	delete[] pBoxPosIDArray;
	pBoxPosIDArray = nullptr;
}

void CSokobanGameStateCharacteristics::Reset(void)
{
	fStatusValue = 0.0f;

	PlayerPosID = -1;

	for (int32_t i = 0; i < NumOfBoxes; i++)
	{
		pBoxPosIDArray[i] = -1;
	}
}

bool CSokobanGameStateCharacteristics::Check_Identity(CGameStateValues *pOtherObject)
{
	int8_t *pValueArray = pOtherObject->pValueArray;

	int8_t tileValue = pValueArray[PlayerPosID];

	if (tileValue != ConstGameBoard_Player && tileValue != ConstGameBoard_DestinationWithPlayer)
	{
		return false;
	}

	for (int32_t i = 0; i < NumOfBoxes; i++)
	{
		int8_t tileValue = pValueArray[pBoxPosIDArray[i]];

		if (tileValue != ConstGameBoard_Box && tileValue != ConstGameBoard_DestinationWithBox)
		{
			return false;
		}
	}

	return true;
}

bool CSokobanGameStateCharacteristics::Check_Identity_IgnorePlayer(CGameStateValues *pOtherObject)
{
	int8_t *pValueArray = pOtherObject->pValueArray;

	for (int32_t i = 0; i < NumOfBoxes; i++)
	{
		int8_t tileValue = pValueArray[pBoxPosIDArray[i]];

		if (tileValue != ConstGameBoard_Box && tileValue != ConstGameBoard_DestinationWithBox)
		{
			return false;
		}
	}

	return true;
}

bool CSokobanGameStateCharacteristics::Check_Identity_IgnorePlayer(CSokobanGameStateCharacteristics *pOtherObject)
{
	int32_t *pOtherBoxPosIDArray = pOtherObject->pBoxPosIDArray;

	for (int32_t i = 0; i < NumOfBoxes; i++)
	{
		int32_t posID = pBoxPosIDArray[i];

		bool posIdentityConfirmed = false;

		for (int32_t j = 0; j < NumOfBoxes; j++)
		{
			if (posID == pOtherBoxPosIDArray[j])
			{
				posIdentityConfirmed = true;
				break;
			}
		}

		if (posIdentityConfirmed == false)
		{
			return false;
		}
	}

	return true;
}

bool CSokobanGameStateCharacteristics::Check_Identity(CSokobanGameStateCharacteristics *pOtherObject)
{
	if (PlayerPosID != pOtherObject->PlayerPosID)
	{
		return false;
	}

	int32_t *pOtherBoxPosIDArray = pOtherObject->pBoxPosIDArray;

	for (int32_t i = 0; i < NumOfBoxes; i++)
	{
		int32_t posID = pBoxPosIDArray[i];

		bool posIdentityConfirmed = false;

		for (int32_t j = 0; j < NumOfBoxes; j++)
		{ 
			if (posID == pOtherBoxPosIDArray[j])
			{
				posIdentityConfirmed = true;
				break;
			}
		}

		if(posIdentityConfirmed == false)
		{
			return false;
		}
	}

	return true;
}

void CSokobanGameStateCharacteristics::Reconstruct_GameState(CGameStateValues *pInOutReconstructedGameState)
{
	int32_t numOfGameStateValues = pInOutReconstructedGameState->Size;

	int8_t *pValueArray = pInOutReconstructedGameState->pValueArray;

	for (int32_t i = 0; i < numOfGameStateValues; i++)
	{
		int8_t tileValue = pValueArray[i];

		if (tileValue == ConstGameBoard_Box)
		{
			pValueArray[i] = ConstGameBoard_Empty;
		}
		else if (tileValue == ConstGameBoard_DestinationWithBox)
		{
			pValueArray[i] = ConstGameBoard_Destination;
		}
		else if (tileValue == ConstGameBoard_Player)
		{
			pValueArray[i] = ConstGameBoard_Empty;
		}
		else if (tileValue == ConstGameBoard_DestinationWithPlayer)
		{
			pValueArray[i] = ConstGameBoard_Destination;
		}
	}

	int8_t tileValue = pValueArray[PlayerPosID];

	if (tileValue == ConstGameBoard_Empty)
	{
		pValueArray[PlayerPosID] = ConstGameBoard_Player;
	}
	else if (tileValue == ConstGameBoard_Destination)
	{
		pValueArray[PlayerPosID] = ConstGameBoard_DestinationWithPlayer;
	}

	for (int32_t i = 0; i < NumOfBoxes; i++)
	{
		int32_t boxID = pBoxPosIDArray[i];

		int8_t tileValue = pValueArray[boxID];

		if (tileValue == ConstGameBoard_Empty)
		{
			pValueArray[boxID] = ConstGameBoard_Box;
		}
		else if (tileValue == ConstGameBoard_Destination)
		{
			pValueArray[boxID] = ConstGameBoard_DestinationWithBox;
		}
	}
}

void CSokobanGameStateCharacteristics::Set_Values(CGameStateValues *pGameState)
{
	int32_t numOfGameStateValues = pGameState->Size;

	int8_t *pValueArray = pGameState->pValueArray;

	for (int32_t i = 0; i < numOfGameStateValues; i++)
	{
		int8_t tileValue = pValueArray[i];

		if (tileValue == ConstGameBoard_Player)
		{
			PlayerPosID = i;
			break;
		}
		else if (tileValue == ConstGameBoard_DestinationWithPlayer)
		{
			PlayerPosID = i;
			break;
		}
	}

	int32_t boxCounter = 0;

	for (int32_t i = 0; i < numOfGameStateValues; i++)
	{
		int8_t tileValue = pValueArray[i];

		if (tileValue == ConstGameBoard_Box)
		{
			pBoxPosIDArray[boxCounter] = i;
			boxCounter++;
		}
		else if (tileValue == ConstGameBoard_DestinationWithBox)
		{
			pBoxPosIDArray[boxCounter] = i;
			boxCounter++;
		}
	}
}

void CSokobanGameStateCharacteristics::Clone_Values(CSokobanGameStateCharacteristics *pOriginalObject)
{
	fStatusValue = pOriginalObject->fStatusValue;

	PlayerPosID = pOriginalObject->PlayerPosID;

	for (int32_t i = 0; i < NumOfBoxes; i++)
	{
		pBoxPosIDArray[i] = pOriginalObject->pBoxPosIDArray[i];
	}
}

void CSokobanGameStateCharacteristics::Initialize(int32_t numOfBoxes)
{
	delete[] pBoxPosIDArray;
	pBoxPosIDArray = nullptr;

	NumOfBoxes = numOfBoxes;

	fStatusValue = 0.0f;

	PlayerPosID = -1;

	pBoxPosIDArray = new (std::nothrow) int32_t[numOfBoxes];

	for (int32_t i = 0; i < numOfBoxes; i++)
	{
		pBoxPosIDArray[i] = -1;
	}
}


CSokobanBoxCharacteristics::CSokobanBoxCharacteristics()
{}

CSokobanBoxCharacteristics::~CSokobanBoxCharacteristics()
{}

void CSokobanBoxCharacteristics::Clone_Values(CSokobanBoxCharacteristics *pOriginalObject)
{
	MinDistanceToInitialPos = pOriginalObject->MinDistanceToInitialPos;

	PosID = pOriginalObject->PosID;
	PosX = pOriginalObject->PosX;
	PosY = pOriginalObject->PosY;

	LeftPushPossible = pOriginalObject->LeftPushPossible;
	RightPushPossible = pOriginalObject->RightPushPossible;
	UpwardPushPossible = pOriginalObject->UpwardPushPossible;
	DownwardPushPossible = pOriginalObject->DownwardPushPossible;

	LeftPullPossible = pOriginalObject->LeftPullPossible;
	RightPullPossible = pOriginalObject->RightPullPossible;
	UpwardPullPossible = pOriginalObject->UpwardPullPossible;
	DownwardPullPossible = pOriginalObject->DownwardPullPossible;

	LeftSideBlockedForPlayer = pOriginalObject->LeftSideBlockedForPlayer;
	RightSideBlockedForPlayer = pOriginalObject->RightSideBlockedForPlayer;
	UpperSideBlockedForPlayer = pOriginalObject->UpperSideBlockedForPlayer;
	LowerSideBlockedForPlayer = pOriginalObject->LowerSideBlockedForPlayer;
}

void CSokobanBoxCharacteristics::Reset(void)
{
	MinDistanceToInitialPos = 1000000;

	PosID = 0;
	PosX = 0;
	PosY = 0;

	LeftPushPossible = false;
	RightPushPossible = false;
	UpwardPushPossible = false;
	DownwardPushPossible = false;

	LeftPullPossible = false;
	RightPullPossible = false;
	UpwardPullPossible = false;
	DownwardPullPossible = false;

	LeftSideBlockedForPlayer = false;
	RightSideBlockedForPlayer = false;
	UpperSideBlockedForPlayer = false;
	LowerSideBlockedForPlayer = false;
}



CSokobanPuzzle::CSokobanPuzzle()
{
	pFileName = new (std::nothrow) char[100];
}

CSokobanPuzzle::~CSokobanPuzzle()
{
	delete[] pFileName;
	pFileName = nullptr;

	delete[] pInitialBoxPosIDArray;
	pInitialBoxPosIDArray = nullptr;

	delete[] pInitialBoxPosXArray;
	pInitialBoxPosXArray = nullptr;

	delete[] pInitialBoxPosYArray;
	pInitialBoxPosYArray = nullptr;
}

void CSokobanPuzzle::Set_Filename(const char* pFilename)
{
	sprintf(pFileName, pFilename);
}

bool CSokobanPuzzle::Load_Puzzle(const char* pFilename)
{
	delete[] pInitialBoxPosIDArray;
	pInitialBoxPosIDArray = nullptr;

	delete[] pInitialBoxPosXArray;
	pInitialBoxPosXArray = nullptr;

	delete[] pInitialBoxPosYArray;
	pInitialBoxPosYArray = nullptr;

	std::ifstream ReadFile;

	// eine existierende Datei zum Lesen �ffnen:
	ReadFile.open(pFilename);

	if (ReadFile.good() == false)
		return false;

	ReadFile >> SizeX;
	ReadFile >> SizeY;

	GameState.Initialize(SizeX, SizeY);

	SizeXY = SizeX * SizeY;

	int32_t tempInt;

	for (int32_t i = 0; i < SizeXY; i++)
	{
		ReadFile >> tempInt;
		GameState.pValueArray[i] = static_cast<int8_t>(tempInt);
	}

	ReadFile.close();

	NumOfBoxesInsideGamesWorld = 0;

	for (int32_t i = 0; i < SizeXY; i++)
	{
		int8_t tileType = GameState.pValueArray[i];

		if (tileType == ConstGameBoard_Box || tileType == ConstGameBoard_DestinationWithBox)
		{
			NumOfBoxesInsideGamesWorld++;
		}
	}

	pInitialBoxPosIDArray = new (std::nothrow) int32_t[NumOfBoxesInsideGamesWorld];
	pInitialBoxPosXArray = new (std::nothrow) int32_t[NumOfBoxesInsideGamesWorld];
	pInitialBoxPosYArray = new (std::nothrow) int32_t[NumOfBoxesInsideGamesWorld];

	int32_t boxCounter = 0;

	for (int32_t i = 0; i < SizeXY; i++)
	{
		int8_t tileType = GameState.pValueArray[i];

		if (tileType == ConstGameBoard_Box || tileType == ConstGameBoard_DestinationWithBox)
		{
			pInitialBoxPosIDArray[boxCounter] = i;
			pInitialBoxPosXArray[boxCounter] = i % SizeX;
			pInitialBoxPosYArray[boxCounter] = i / SizeX;

			boxCounter++;
		}
	}

	for (int32_t i = 0; i < constNumOfFeatureMaps; i++)
	{
		FeatureMapArray[i].Init_Map(SizeX, SizeY);
	}
	

	return true;
}

void CSokobanPuzzle::Clone_Puzzle(CSokobanPuzzle *pOriginalObject)
{
	delete[] pInitialBoxPosIDArray;
	pInitialBoxPosIDArray = nullptr;

	delete[] pInitialBoxPosXArray;
	pInitialBoxPosXArray = nullptr;

	delete[] pInitialBoxPosYArray;
	pInitialBoxPosYArray = nullptr;

	SizeX = pOriginalObject->SizeX;
	SizeY = pOriginalObject->SizeY;

	GameState.Initialize(SizeX, SizeY);

	SizeXY = SizeX * SizeY;

	int8_t *pOriginalValueArray = pOriginalObject->GameState.pValueArray;

	for (int32_t i = 0; i < SizeXY; i++)
	{
		GameState.pValueArray[i] = pOriginalValueArray[i];
	}

	NumOfBoxesInsideGamesWorld = pOriginalObject->NumOfBoxesInsideGamesWorld;

	pInitialBoxPosIDArray = new (std::nothrow) int32_t[NumOfBoxesInsideGamesWorld];
	pInitialBoxPosXArray = new (std::nothrow) int32_t[NumOfBoxesInsideGamesWorld];
	pInitialBoxPosYArray = new (std::nothrow) int32_t[NumOfBoxesInsideGamesWorld];

	for (int32_t i = 0; i < NumOfBoxesInsideGamesWorld; i++)
	{
		pInitialBoxPosIDArray[i] = pOriginalObject->pInitialBoxPosIDArray[i];
		pInitialBoxPosXArray[i] = pOriginalObject->pInitialBoxPosXArray[i];
		pInitialBoxPosYArray[i] = pOriginalObject->pInitialBoxPosYArray[i];
	}


	for (int32_t i = 0; i < constNumOfFeatureMaps; i++)
	{
		FeatureMapArray[i].Init_Map(SizeX, SizeY);
	}
}

bool CSokobanPuzzle::Load_Puzzle(void)
{
	std::ifstream ReadFile;

	// eine existierende Datei zum Lesen �ffnen:
	ReadFile.open(pFileName);

	if (ReadFile.good() == false)
		return false;

	ReadFile >> SizeX;
	ReadFile >> SizeY;

	GameState.Initialize(SizeX, SizeY);

	SizeXY = SizeX * SizeY;

	int32_t tempInt;

	for (int32_t i = 0; i < SizeXY; i++)
	{
		ReadFile >> tempInt;
		GameState.pValueArray[i] = static_cast<int8_t>(tempInt);
	}

	ReadFile.close();

	NumOfBoxesInsideGamesWorld = 0;

	for (int32_t i = 0; i < SizeXY; i++)
	{
		int8_t tileType = GameState.pValueArray[i];

		if (tileType == ConstGameBoard_Box || tileType == ConstGameBoard_DestinationWithBox)
			NumOfBoxesInsideGamesWorld++;
	}
	
	for (int32_t i = 0; i < constNumOfFeatureMaps; i++)
	{
		FeatureMapArray[i].Init_Map(SizeX, SizeY);
	}
	
	return true;
}

bool CSokobanPuzzle::Save_Puzzle(const char* pFilename)
{
	std::ofstream WriteFile;

	// neue Datei erzeugen bzw. alte �berschreiben:
	WriteFile.open(pFilename);

	// neue Datei erzeugen bzw. Inhalt ans Ende einer bestehenden Datei schreiben: 
	//WriteFile.open(pFilename, ios::app);

	if (WriteFile.good() == false)
		return false;

	WriteFile << SizeX << "  ";
	WriteFile << SizeY << "  ";
	WriteFile << endl;

	for (int32_t iy = 0; iy < SizeY; iy++)
	{
		int32_t iiy = iy * SizeX;

		for (int32_t ix = 0; ix < SizeX; ix++)
		{
			WriteFile << static_cast<int32_t>(GameState.pValueArray[ix + iiy]) << "  ";
		}

		WriteFile << endl;
	}

	WriteFile.close();

	return true;
}

bool CSokobanPuzzle::Save_Puzzle(void)
{
	std::ofstream WriteFile;

	// neue Datei erzeugen bzw. alte �berschreiben:
	WriteFile.open(pFileName);

	// neue Datei erzeugen bzw. Inhalt ans Ende einer bestehenden Datei schreiben: 
	//WriteFile.open(pFilename, ios::app);

	if (WriteFile.good() == false)
		return false;

	WriteFile << SizeX << "  ";
	WriteFile << SizeY << "  ";
	WriteFile << endl;

	for (int32_t iy = 0; iy < SizeY; iy++)
	{
		int32_t iiy = iy * SizeX;

		for (int32_t ix = 0; ix < SizeX; ix++)
		{
			WriteFile << static_cast<int32_t>(GameState.pValueArray[ix + iiy]) << "  ";
		}

		WriteFile << endl;
	}

	WriteFile.close();

	return true;
}

bool CSokobanPuzzle::Check_For_ShortestPaths(int32_t *pOutPathTileIDArray, int32_t *pOutNumOfPathSteps, int32_t startPosX, int32_t startPosY, int32_t destinationPosX, int32_t destinationPosY)
{
	*pOutNumOfPathSteps = 0;

	if (startPosX == destinationPosX)
	{
		if (startPosY == destinationPosY)
		{
			*pOutNumOfPathSteps = 1;
			pOutPathTileIDArray[0] = startPosX + SizeX * startPosY;

			return true;
		}
		else if (abs(startPosY - destinationPosY) == 1)
		{
			*pOutNumOfPathSteps = 2;
			pOutPathTileIDArray[0] = startPosX + SizeX * startPosY;
			pOutPathTileIDArray[1] = destinationPosX + SizeX * destinationPosY;

			return true;
		}
	}

	if (startPosY == destinationPosY)
	{
		if (abs(startPosX - destinationPosX) == 1)
		{
			*pOutNumOfPathSteps = 2;
			pOutPathTileIDArray[0] = startPosX + SizeX * startPosY;
			pOutPathTileIDArray[1] = destinationPosX + SizeX * destinationPosY;

			return true;
		}
	}

	return false;
}

bool CSokobanPuzzle::Check_For_ShortestPaths(int32_t startPosX, int32_t startPosY, int32_t destinationPosX, int32_t destinationPosY)
{
	if (startPosX == destinationPosX)
	{
		if (startPosY == destinationPosY)
		{
			return true;
		}
		else if (abs(startPosY - destinationPosY) == 1)
		{
			return true;
		}
	}

	if (startPosY == destinationPosY)
	{
		if (abs(startPosX - destinationPosX) == 1)
		{
			return true;
		}
	}

	return false;
}

bool CSokobanPuzzle::Check_For_ShortestPaths_IncludingDiagonalMovement(int32_t *pOutPathTileIDArray, int32_t *pOutNumOfPathSteps, int32_t startPosX, int32_t startPosY, int32_t destinationPosX, int32_t destinationPosY)
{
	*pOutNumOfPathSteps = 0;

	if (startPosX == destinationPosX)
	{
		if (startPosY == destinationPosY)
		{
			*pOutNumOfPathSteps = 1;
			pOutPathTileIDArray[0] = startPosX + SizeX * startPosY;

			return true;
		}
		else if (abs(startPosY - destinationPosY) == 1)
		{
			*pOutNumOfPathSteps = 2;
			pOutPathTileIDArray[0] = startPosX + SizeX * startPosY;
			pOutPathTileIDArray[1] = destinationPosX + SizeX * destinationPosY;

			return true;
		}
	}

	if (startPosY == destinationPosY)
	{
		if (abs(startPosX - destinationPosX) == 1)
		{
			*pOutNumOfPathSteps = 2;
			pOutPathTileIDArray[0] = startPosX + SizeX * startPosY;
			pOutPathTileIDArray[1] = destinationPosX + SizeX * destinationPosY;

			return true;
		}
	}
	// now the diagonals:

	if (abs(startPosX - destinationPosX) == 1 && abs(startPosY - destinationPosY) == 1)
	{
		*pOutNumOfPathSteps = 2;
		pOutPathTileIDArray[0] = startPosX + SizeX * startPosY;
		pOutPathTileIDArray[1] = destinationPosX + SizeX * destinationPosY;

		return true;
	}

	return false;
}

bool CSokobanPuzzle::Check_For_ShortestPaths_IncludingDiagonalMovement(int32_t startPosX, int32_t startPosY, int32_t destinationPosX, int32_t destinationPosY)
{
	if (startPosX == destinationPosX)
	{
		if (startPosY == destinationPosY)
		{
			return true;
		}
		else if (abs(startPosY - destinationPosY) == 1)
		{
			return true;
		}
	}

	if (startPosY == destinationPosY)
	{
		if (abs(startPosX - destinationPosX) == 1)
		{
			return true;
		}
	}
	// now the diagonals:

	if (abs(startPosX - destinationPosX) == 1 && abs(startPosY - destinationPosY) == 1)
	{
		return true;
	}

	return false;
}

void CSokobanPuzzle::Get_Path(int32_t *pOutPathTileIDArray, int32_t *pOutNumOfPathSteps, int32_t startPosX, int32_t startPosY, int32_t destinationPosX, int32_t destinationPosY, int32_t featureMapID)
{
	// Das erste Weg-Tile entspricht dem Startpunkt des Weges: 
	int32_t centerTileID = startPosX + SizeX * startPosY;

	*pOutNumOfPathSteps = 1;
	pOutPathTileIDArray[0] = centerTileID;

	if (startPosX == destinationPosX && startPosY == destinationPosY)
	{
		return;
	}

	float *pNeuralNetValueArray = FeatureMapArray[featureMapID].pDataArray;

	float adjacentDistance, minDistance;

	int32_t adjacentTileID, nextPathTileID;

	int32_t pathStep = 1;

	for (int32_t counter = 0; counter < SizeXY; counter++)
	{
		// Benachbartes Tile mit dem geringstm�glichen Abstand zum Ziel ermitteln: 

		// maximal m�glicher Manhatten-Abstand zwischen Start und Ziel:
		minDistance = 10000.0f;

		adjacentTileID = centerTileID - 1;

		adjacentDistance = pNeuralNetValueArray[adjacentTileID];

		if (adjacentDistance > 0.0f)
		{
			if (adjacentDistance < minDistance)
			{
				minDistance = adjacentDistance;
				nextPathTileID = adjacentTileID;
			}
		}

		adjacentTileID = centerTileID + 1;

		adjacentDistance = pNeuralNetValueArray[adjacentTileID];

		if (adjacentDistance > 0.0f)
		{
			if (adjacentDistance < minDistance)
			{
				minDistance = adjacentDistance;
				nextPathTileID = adjacentTileID;
			}
		}

		adjacentTileID = centerTileID - SizeX;

		adjacentDistance = pNeuralNetValueArray[adjacentTileID];

		if (adjacentDistance > 0.0f)
		{
			if (adjacentDistance < minDistance)
			{
				minDistance = adjacentDistance;
				nextPathTileID = adjacentTileID;
			}
		}

		adjacentTileID = centerTileID + SizeX;

		adjacentDistance = pNeuralNetValueArray[adjacentTileID];

		if (adjacentDistance > 0.0f)
		{
			if (adjacentDistance < minDistance)
			{
				minDistance = adjacentDistance;
				nextPathTileID = adjacentTileID;
			}
		}

		pOutPathTileIDArray[pathStep] = nextPathTileID;
		pathStep++;

		if (minDistance == 1.0f) // Nachbarschaft zum Ziel
		{
			// letztes Path-Tile entspricht dem Ziel:
			pOutPathTileIDArray[pathStep] = destinationPosX + SizeX * destinationPosY;
			break;
		}

		centerTileID = nextPathTileID;

	} // end of for (int32_t counter = 0; counter < SizeXY; counter++)

	*pOutNumOfPathSteps = pathStep + 1;
}

void CSokobanPuzzle::Get_Path_IncludingDiagonalMovement(int32_t *pOutPathTileIDArray, int32_t *pOutNumOfPathSteps, int32_t startPosX, int32_t startPosY, int32_t destinationPosX, int32_t destinationPosY, int32_t featureMapID)
{
	// Das erste Weg-Tile entspricht dem Startpunkt des Weges: 
	int32_t centerTileID = startPosX + SizeX * startPosY;

	*pOutNumOfPathSteps = 1;
	pOutPathTileIDArray[0] = centerTileID;

	if (startPosX == destinationPosX && startPosY == destinationPosY)
	{
		return;
	}

	float *pNeuralNetValueArray = FeatureMapArray[featureMapID].pDataArray;

	float adjacentDistance, minDistance;

	int32_t adjacentTileID, nextPathTileID;

	int32_t pathStep = 1;

	for (int32_t counter = 0; counter < SizeXY; counter++)
	{
		// Benachbartes Tile mit dem geringstm�glichen Abstand zum Ziel ermitteln: 

		// maximal m�glicher Manhatten-Abstand zwischen Start und Ziel:
		minDistance = 10000.0f;

		adjacentTileID = centerTileID - 1;

		adjacentDistance = pNeuralNetValueArray[adjacentTileID];

		if (adjacentDistance > 0.0f)
		{
			
			if (adjacentDistance < minDistance)
			{
				minDistance = adjacentDistance;
				nextPathTileID = adjacentTileID;
			}
		}

		adjacentTileID = centerTileID + 1;

		adjacentDistance = pNeuralNetValueArray[adjacentTileID];

		if (adjacentDistance > 0.0f)
		{
			if (adjacentDistance < minDistance)
			{
				minDistance = adjacentDistance;
				nextPathTileID = adjacentTileID;
			}
		}

		adjacentTileID = centerTileID - SizeX;

		adjacentDistance = pNeuralNetValueArray[adjacentTileID];

		if (adjacentDistance > 0.0f)
		{
			if (adjacentDistance < minDistance)
			{
				minDistance = adjacentDistance;
				nextPathTileID = adjacentTileID;
			}
		}

		adjacentTileID = centerTileID + SizeX;

		adjacentDistance = pNeuralNetValueArray[adjacentTileID];

		if (adjacentDistance > 0.0f)
		{
			if (adjacentDistance < minDistance)
			{
				minDistance = adjacentDistance;
				nextPathTileID = adjacentTileID;
			}
		}

		// now the diagonals:

		adjacentTileID = centerTileID - 1 - SizeX;

		adjacentDistance = pNeuralNetValueArray[adjacentTileID];

		if (adjacentDistance > 0.0f)
		{
			// Suche Tile mit dem geringstm�glichen Abstand zum Ziel
			if (adjacentDistance < minDistance)
			{
				minDistance = adjacentDistance;
				nextPathTileID = adjacentTileID;
			}
		}

		adjacentTileID = centerTileID + 1 - SizeX;

		adjacentDistance = pNeuralNetValueArray[adjacentTileID];

		if (adjacentDistance > 0.0f)
		{
			// Suche Tile mit dem geringstm�glichen Abstand zum Ziel
			if (adjacentDistance < minDistance)
			{
				minDistance = adjacentDistance;
				nextPathTileID = adjacentTileID;
			}
		}

		adjacentTileID = centerTileID - 1 + SizeX;

		adjacentDistance = pNeuralNetValueArray[adjacentTileID];

		if (adjacentDistance > 0.0f)
		{
			// Suche Tile mit dem geringstm�glichen Abstand zum Ziel
			if (adjacentDistance < minDistance)
			{
				minDistance = adjacentDistance;
				nextPathTileID = adjacentTileID;
			}
		}

		adjacentTileID = centerTileID + 1 + SizeX;

		adjacentDistance = pNeuralNetValueArray[adjacentTileID];

		if (adjacentDistance > 0.0f)
		{
			// Suche Tile mit dem geringstm�glichen Abstand zum Ziel
			if (adjacentDistance < minDistance)
			{
				minDistance = adjacentDistance;
				nextPathTileID = adjacentTileID;
			}
		}


		pOutPathTileIDArray[pathStep] = nextPathTileID;
		pathStep++;

		if (minDistance == 1.0f) // Nachbarschaft zum Ziel
		{
			// letztes Path-Tile entspricht dem Ziel:
			pOutPathTileIDArray[pathStep] = destinationPosX + SizeX * destinationPosY;
			break;
		}

		centerTileID = nextPathTileID;

	} // end of for (int32_t counter = 0; counter < SizeXY; counter++)

	*pOutNumOfPathSteps = pathStep + 1;
}

// return false: Wegfindung nicht m�glich, da Ziel-Tile nicht begehbar ist
bool CSokobanPuzzle::Start_Pathfinding(int32_t destinationPosX, int32_t destinationPosY, int32_t featureMapID)
{
	float *pNeuralNetValueArray = FeatureMapArray[featureMapID].pDataArray;

	int32_t centerTileID = destinationPosX + SizeX * destinationPosY;

	// Ziel-Tile nicht begehbar:
	if (pNeuralNetValueArray[centerTileID] < 0.0f)
	{
		return false;
	}

	int32_t adjacentTileID;

	adjacentTileID = centerTileID - 1;

	if (pNeuralNetValueArray[adjacentTileID] == 0.0f)
	{
		pNeuralNetValueArray[adjacentTileID] = 1.0f; // kleinstm�glicher Abstand vom Ziel
	}

	adjacentTileID = centerTileID + 1;

	if (pNeuralNetValueArray[adjacentTileID] == 0.0f)
	{
		pNeuralNetValueArray[adjacentTileID] = 1.0f;
	}

	adjacentTileID = centerTileID - SizeX;

	if (pNeuralNetValueArray[adjacentTileID] == 0.0f)
	{
		pNeuralNetValueArray[adjacentTileID] = 1.0f;
	}

	adjacentTileID = centerTileID + SizeX;

	if (pNeuralNetValueArray[adjacentTileID] == 0.0f)
	{
		pNeuralNetValueArray[adjacentTileID] = 1.0f;
	}

	return true;
}

CRandomNumbersNN g_RandomNumbers;

// return true: Pfad ermittelt
bool CSokobanPuzzle::Update_Pathfinding(int32_t searchStep, int32_t startPosX, int32_t startPosY, int32_t featureMapID)
{
	float *pNeuralNetValueArray = FeatureMapArray[featureMapID].pDataArray;

	int32_t adjacentTileID;

	int32_t startTileID = startPosX + SizeX * startPosY;

	adjacentTileID = startTileID - 1;

	// Wenn der Ausgangspunkt des Weges bereits erreicht ist, er�brigt sich die weitere Wegfindung:
	if (pNeuralNetValueArray[adjacentTileID] > 0.0f)
	{
		return true;
	}

	adjacentTileID = startTileID + 1;

	if (pNeuralNetValueArray[adjacentTileID] > 0.0f)
	{
		return true;
	}

	adjacentTileID = startTileID - SizeX;

	if (pNeuralNetValueArray[adjacentTileID] > 0.0f)
	{
		return true;
	}

	adjacentTileID = startTileID + SizeX;

	if (pNeuralNetValueArray[adjacentTileID] > 0.0f)
	{
		return true;
	}

	float centerTileValue, adjacentDistance;

	// Manhatten-Distanzwerte:
	float previousMaxDistance = static_cast<float>(searchStep);
	float newMaxDistance = previousMaxDistance + 1.0f;

	int32_t centerTileID;

	int32_t maxXPlus1 = SizeX - 1;
	int32_t maxYPlus1 = SizeY - 1;


	for (int32_t iy = 1; iy < maxYPlus1; iy++)
	{
		int32_t iiy = iy * SizeX;

		for (int32_t ix = 1; ix < maxXPlus1; ix++)
		{
			centerTileID = ix + iiy;

			centerTileValue = pNeuralNetValueArray[centerTileID];

			// begehbares, nicht evaluiertes Tile:
			if (centerTileValue == 0.0f)
			{
				/*
				float minAdjacentManhattenDist = 1000000.0f;
				float randomAdditionalMovementCosts = 0.0f;

				adjacentTileID = centerTileID - 1;

				adjacentDistance = pNeuralNetValueArray[adjacentTileID];

				if (adjacentDistance < minAdjacentManhattenDist && adjacentDistance > 0.0f)
				{
					minAdjacentManhattenDist = adjacentDistance;
					randomAdditionalMovementCosts = g_RandomNumbers.Get_FloatNumber_IncludingZero(0.0f, 3.0f);
					pNeuralNetValueArray[centerTileID] = adjacentDistance + 1.0f + randomAdditionalMovementCosts;
				}

				adjacentTileID = centerTileID + 1;

				adjacentDistance = pNeuralNetValueArray[adjacentTileID];

				if (adjacentDistance < minAdjacentManhattenDist && adjacentDistance > 0.0f)
				{
					minAdjacentManhattenDist = adjacentDistance;
					randomAdditionalMovementCosts = g_RandomNumbers.Get_FloatNumber_IncludingZero(0.0f, 3.0f);
					pNeuralNetValueArray[centerTileID] = adjacentDistance + 1.0f + randomAdditionalMovementCosts;
				}

				adjacentTileID = centerTileID - SizeX;

				adjacentDistance = pNeuralNetValueArray[adjacentTileID];

				if (adjacentDistance < minAdjacentManhattenDist && adjacentDistance > 0.0f)
				{
					minAdjacentManhattenDist = adjacentDistance;
					randomAdditionalMovementCosts = g_RandomNumbers.Get_FloatNumber_IncludingZero(0.0f, 3.0f);
					pNeuralNetValueArray[centerTileID] = adjacentDistance + 1.0f + randomAdditionalMovementCosts;
				}

				adjacentTileID = centerTileID + SizeX;

				adjacentDistance = pNeuralNetValueArray[adjacentTileID];

				if (adjacentDistance < minAdjacentManhattenDist && adjacentDistance > 0.0f)
				{
					minAdjacentManhattenDist = adjacentDistance;
					randomAdditionalMovementCosts = g_RandomNumbers.Get_FloatNumber_IncludingZero(0.0f, 3.0f);
					pNeuralNetValueArray[centerTileID] = adjacentDistance + 1.0f + randomAdditionalMovementCosts;
				}
				*/


				///*
				adjacentTileID = centerTileID - 1;

				adjacentDistance = pNeuralNetValueArray[adjacentTileID];

				if (adjacentDistance == previousMaxDistance)
				{
					pNeuralNetValueArray[centerTileID] = newMaxDistance;
					continue;
				}
				
				adjacentTileID = centerTileID + 1;

				adjacentDistance = pNeuralNetValueArray[adjacentTileID];

				if (adjacentDistance == previousMaxDistance)
				{
					pNeuralNetValueArray[centerTileID] = newMaxDistance;
					continue;
				}
				
				adjacentTileID = centerTileID - SizeX;

				adjacentDistance = pNeuralNetValueArray[adjacentTileID];

				if (adjacentDistance == previousMaxDistance)
				{
					pNeuralNetValueArray[centerTileID] = newMaxDistance;
					continue;
				}
				
				adjacentTileID = centerTileID + SizeX;

				adjacentDistance = pNeuralNetValueArray[adjacentTileID];

				if (adjacentDistance == previousMaxDistance)
				{
					pNeuralNetValueArray[centerTileID] = newMaxDistance;
					continue;
				}
				//*/

				
			} // end of if (centerValue == 0.0f)
		}
	}


	return false;

}

bool CSokobanPuzzle::Update_Pathfinding_OMP(int32_t searchStep, int32_t startPosX, int32_t startPosY, int32_t featureMapID)
{
	int32_t srcFeatureMapID = featureMapID;
	int32_t destFeatureMapID = constNumOfFeatureMapsMinus1;

	float *pSrcNeuralNetValueArray = FeatureMapArray[srcFeatureMapID].pDataArray;
	float *pDestNeuralNetValueArray = FeatureMapArray[destFeatureMapID].pDataArray;

	int32_t adjacentTileID;

	int32_t startTileID = startPosX + SizeX * startPosY;

	adjacentTileID = startTileID - 1;

	// Wenn der Ausgangspunkt des Weges bereits erreicht ist, er�brigt sich die weitere Wegfindung:
	if (pSrcNeuralNetValueArray[adjacentTileID] > 0.0f)
	{
		return true;
	}

	adjacentTileID = startTileID + 1;

	if (pSrcNeuralNetValueArray[adjacentTileID] > 0.0f)
	{
		return true;
	}

	adjacentTileID = startTileID - SizeX;

	if (pSrcNeuralNetValueArray[adjacentTileID] > 0.0f)
	{
		return true;
	}

	adjacentTileID = startTileID + SizeX;

	if (pSrcNeuralNetValueArray[adjacentTileID] > 0.0f)
	{
		return true;
	}

	// Manhatten-Distanzwerte:
	float previousMaxDistance = static_cast<float>(searchStep);
	float newMaxDistance = previousMaxDistance + 1.0f;

///*
	int32_t SizeXMinus1 = SizeX - 1;
	int32_t SizeYMinus1 = SizeY - 1;
	int32_t maxIDPlus1 = SizeX * SizeY;

//#pragma omp parallel for num_threads(2)
#pragma omp parallel for
	for (int32_t centerTileID = 0; centerTileID < maxIDPlus1; centerTileID++)
	{
		int32_t ix = centerTileID % SizeX;

		if (ix == 0 || ix == SizeXMinus1)
			continue;

		int32_t iy = centerTileID / SizeX;

		if (iy == 0 || iy == SizeYMinus1)
			continue;

		float centerTileValue = pSrcNeuralNetValueArray[centerTileID];

		// begehbares, nicht evaluiertes Tile:
		if (centerTileValue == 0.0f)
		{
			int32_t adjacentTileID = centerTileID - 1;
			
			float adjacentDistance = pSrcNeuralNetValueArray[adjacentTileID];

			if (adjacentDistance == previousMaxDistance)
			{
				pDestNeuralNetValueArray[centerTileID] = newMaxDistance;
				continue;
			}

			adjacentTileID = centerTileID + 1;

			adjacentDistance = pSrcNeuralNetValueArray[adjacentTileID];

			if (adjacentDistance == previousMaxDistance)
			{
				pDestNeuralNetValueArray[centerTileID] = newMaxDistance;
				continue;
			}

			adjacentTileID = centerTileID - SizeX;

			adjacentDistance = pSrcNeuralNetValueArray[adjacentTileID];

			if (adjacentDistance == previousMaxDistance)
			{
				pDestNeuralNetValueArray[centerTileID] = newMaxDistance;
				continue;
			}

			adjacentTileID = centerTileID + SizeX;

			adjacentDistance = pSrcNeuralNetValueArray[adjacentTileID];

			if (adjacentDistance == previousMaxDistance)
			{
				pDestNeuralNetValueArray[centerTileID] = newMaxDistance;
				continue;
			}

		} // end of if (centerValue == 0.0f)
	} // end of for (int32_t centerTileID = 0; centerTileID < maxIDPlus1; centerTileID++)
//*/
/*
	int32_t maxXPlus1 = SizeX - 1;
	int32_t maxYPlus1 = SizeY - 1;

#pragma omp parallel for num_threads(2)
//#pragma omp parallel for
	for (int32_t iy = 1; iy < maxYPlus1; iy++)
	{
		int32_t iiy = iy * SizeX;

		for (int32_t ix = 1; ix < maxXPlus1; ix++)
		{
			int32_t centerTileID = ix + iiy;

			float centerTileValue = pSrcNeuralNetValueArray[centerTileID];

			// begehbares, nicht evaluiertes Tile:
			if (centerTileValue == 0.0f)
			{
				int32_t adjacentTileID = centerTileID - 1;

				float adjacentDistance = pSrcNeuralNetValueArray[adjacentTileID];

				if (adjacentDistance == previousMaxDistance)
				{
					pDestNeuralNetValueArray[centerTileID] = newMaxDistance;
					continue;
				}

				adjacentTileID = centerTileID + 1;

				adjacentDistance = pSrcNeuralNetValueArray[adjacentTileID];

				if (adjacentDistance == previousMaxDistance)
				{
					pDestNeuralNetValueArray[centerTileID] = newMaxDistance;
					continue;
				}

				adjacentTileID = centerTileID - SizeX;

				adjacentDistance = pSrcNeuralNetValueArray[adjacentTileID];

				if (adjacentDistance == previousMaxDistance)
				{
					pDestNeuralNetValueArray[centerTileID] = newMaxDistance;
					continue;
				}

				adjacentTileID = centerTileID + SizeX;

				adjacentDistance = pSrcNeuralNetValueArray[adjacentTileID];

				if (adjacentDistance == previousMaxDistance)
				{
					pDestNeuralNetValueArray[centerTileID] = newMaxDistance;
					continue;
				}

			} // end of if (centerValue == 0.0f)
		} // end of for (int32_t ix = 1; ix < maxXPlus1; ix++)
	} // end of for (int32_t iy = 1; iy < maxYPlus1; iy++)
*/

	Clone_FeatureMapValues_OMP(srcFeatureMapID, destFeatureMapID);

	return false;

}

// Manhatten-Distanzwerte auf 0 zur�cksetzen:
void CSokobanPuzzle::Reset_NeuralNetValueArray_MovementSpace(int32_t featureMapID)
{
	float *pNeuralNetValueArray = FeatureMapArray[featureMapID].pDataArray;

	for (int32_t i = 0; i < SizeXY; i++)
	{
		//pNeuralNetValueArray[i] = min(pNeuralNetValueArray[i], 0.0f);

		if (pNeuralNetValueArray[i] > 0.0f)
		{
			pNeuralNetValueArray[i] = 0.0f;
		}
	}
}

// Manhatten-Distanzwerte auf 0 zur�cksetzen:
void CSokobanPuzzle::Reset_NeuralNetValueArray_MovementSpace_OMP(int32_t featureMapID)
{
	float *pNeuralNetValueArray = FeatureMapArray[featureMapID].pDataArray;

//#pragma omp parallel for num_threads(2)
#pragma omp parallel for
	for (int32_t i = 0; i < SizeXY; i++)
	{
		//pNeuralNetValueArray[i] = min(pNeuralNetValueArray[i], 0.0f);

		if (pNeuralNetValueArray[i] > 0.0f)
		{
			pNeuralNetValueArray[i] = 0.0f;
		}
	}
}

void CSokobanPuzzle::Calculate_NeuralNetValueArray_MovementSpace(int8_t *pActualGameStateData, int32_t featureMapID)
{
	float *pNeuralNetValueArray = FeatureMapArray[featureMapID].pDataArray;


	
	for (int32_t i = 0; i < SizeXY; i++)
	{
		int32_t tileType = pActualGameStateData[i];

		if (tileType == ConstGameBoard_Empty)
			pNeuralNetValueArray[i] = 0.0f;
		else if (tileType == ConstGameBoard_Wall)
			pNeuralNetValueArray[i] = -1.0f;
		else if (tileType == ConstGameBoard_Destination)
			pNeuralNetValueArray[i] = 0.0f;
		else if (tileType == ConstGameBoard_Player)
			pNeuralNetValueArray[i] = -0.1f;
		else if (tileType == ConstGameBoard_DestinationWithPlayer)
			pNeuralNetValueArray[i] = -0.1f;	
		else if (tileType == ConstGameBoard_Box)
			pNeuralNetValueArray[i] = -1.0f;
		else if (tileType == ConstGameBoard_DestinationWithBox)
			pNeuralNetValueArray[i] = -1.0f;


		
	}
}



void CSokobanPuzzle::Clone_FeatureMapValues(int32_t featureMapID_Destination, int32_t featureMapID_Source)
{
	FeatureMapArray[featureMapID_Destination].Clone_Values(&FeatureMapArray[featureMapID_Source]);
}

void CSokobanPuzzle::Clone_FeatureMapValues_OMP(int32_t featureMapID_Destination, int32_t featureMapID_Source)
{
	FeatureMapArray[featureMapID_Destination].Clone_Values_OMP(&FeatureMapArray[featureMapID_Source]);
}

void CSokobanPuzzle::Substitute_Update_NeuralNetArrayValue(float newValue, float oldValue, int32_t featureMapID)
{
	float *pNeuralNetValueArray = FeatureMapArray[featureMapID].pDataArray;

	for (int32_t i = 0; i < SizeXY; i++)
	{
		if (pNeuralNetValueArray[i] == oldValue)
			pNeuralNetValueArray[i] = newValue;
	}
}

void CSokobanPuzzle::Calculate_NeuralNetValueArray_MovementSpace(int32_t featureMapID_Destination, int32_t featureMapID_Source)
{
	float *pDestNeuralNetValueArray = FeatureMapArray[featureMapID_Destination].pDataArray;
	float *pSrcNeuralNetValueArray = FeatureMapArray[featureMapID_Source].pDataArray;

#ifdef CellularAutomata_Pathfinding
	float *pNeuralNetValueArray2 = FeatureMapArray[constNumOfFeatureMapsMinus1].pDataArray;
#endif

	for (int32_t i = 0; i < SizeXY; i++)
	{
		float tileType = pSrcNeuralNetValueArray[i];

		if (tileType == 0.0f)//ConstGameBoard_Empty)
			pDestNeuralNetValueArray[i] = 0.0f;
		else if (tileType == 10.0f)//ConstGameBoard_Wall)
			pDestNeuralNetValueArray[i] = -1.0f;
		else if (tileType == 0.01f)//ConstGameBoard_Destination)
			pDestNeuralNetValueArray[i] = 0.0f;
		else if (tileType == -0.1f)// ConstGameBoard_Player)
			pDestNeuralNetValueArray[i] = -0.1f;
		else if (tileType == -0.1f)//ConstGameBoard_DestinationWithPlayer)
			pDestNeuralNetValueArray[i] = -0.1f;
		else if (tileType == 0.5f)//ConstGameBoard_Box)
			pDestNeuralNetValueArray[i] = -1.0f;
		else if (tileType == 0.5f)//ConstGameBoard_DestinationWithBox)
			pDestNeuralNetValueArray[i] = -1.0f;

#ifdef CellularAutomata_Pathfinding
		pNeuralNetValueArray2[i] = pDestNeuralNetValueArray[i];
#endif
	}
}

void CSokobanPuzzle::Update_NeuralNetValueArray(int8_t *pActualGameStateData, int32_t featureMapID)
{
	float *pNeuralNetValueArray = FeatureMapArray[featureMapID].pDataArray;

	for (int32_t i = 0; i < SizeXY; i++)
	{
		int32_t tileType = pActualGameStateData[i];

		if (tileType == ConstGameBoard_Empty)
			pNeuralNetValueArray[i] = 0.0f;
		else if (tileType == ConstGameBoard_Wall)
			pNeuralNetValueArray[i] = 10.0f;
		else if (tileType == ConstGameBoard_Destination)
			pNeuralNetValueArray[i] = 0.01f;
		else if (tileType == ConstGameBoard_Player)
			pNeuralNetValueArray[i] = -0.1f;
		else if (tileType == ConstGameBoard_DestinationWithPlayer)
			pNeuralNetValueArray[i] = -0.1f;
		else if (tileType == ConstGameBoard_Box)
			pNeuralNetValueArray[i] = 0.5f;
		else if (tileType == ConstGameBoard_DestinationWithBox)
			//pNeuralNetValueArray[i] = 0.4f;	// damit w�rde f�r eine solche Box keine Deadlock-�berpr�fung stattfinden
			pNeuralNetValueArray[i] = 0.5f;
	}
}



CSokobanPuzzles::CSokobanPuzzles()
{}

CSokobanPuzzles::~CSokobanPuzzles()
{
	delete[] pPuzzleArray;
	pPuzzleArray = nullptr;

	delete[] pSolvedPuzzleArray;
	pSolvedPuzzleArray = nullptr;
}

bool CSokobanPuzzles::Initialize_Puzzle(int32_t puzzleID)
{
	if (puzzleID < 0)
		return false;
	if (puzzleID >= NumOfPuzzles)
		return false;

	pPuzzleArray[puzzleID].Load_Puzzle();
	
	return true;
}

bool CSokobanPuzzles::Initialize_SolvedPuzzle(int32_t puzzleID)
{
	if (puzzleID < 0)
		return false;
	if (puzzleID >= NumOfPuzzles)
		return false;

	pSolvedPuzzleArray[puzzleID].Load_Puzzle();

	return true;
}

bool CSokobanPuzzles::Initialize_Puzzle(CSokobanPuzzle **ppOutSokobanPuzzle, int32_t puzzleID)
{
	if (puzzleID < 0)
		return false;
	if (puzzleID >= NumOfPuzzles)
		return false;

	pPuzzleArray[puzzleID].Load_Puzzle();

	*ppOutSokobanPuzzle = &pPuzzleArray[puzzleID];

	return true;
}

bool CSokobanPuzzles::Initialize_SolvedPuzzle(CSokobanPuzzle **ppOutSokobanPuzzle, int32_t puzzleID)
{
	if (puzzleID < 0)
		return false;
	if (puzzleID >= NumOfPuzzles)
		return false;

	pSolvedPuzzleArray[puzzleID].Load_Puzzle();

	*ppOutSokobanPuzzle = &pSolvedPuzzleArray[puzzleID];

	return true;
}

void CSokobanPuzzles::Update_PlayerProgressInfo(void)
{
	IDofActualPlayedPuzzle++;
	IDofActualPlayedPuzzle = IDofActualPlayedPuzzle % NumOfPuzzles;
}

bool CSokobanPuzzles::Load_PlayerProgressInfo(const char* pFilename)
{
	std::ifstream ReadFile;

	// eine existierende Datei zum Lesen �ffnen:
	ReadFile.open(pFilename);

	if (ReadFile.good() == false)
		return false;

	char strBuffer[100];
	
	ReadFile >> strBuffer;
	ReadFile >> IDofActualPlayedPuzzle;

	ReadFile.close();

	IDofActualPlayedPuzzle = IDofActualPlayedPuzzle % NumOfPuzzles;

	return true;
}

bool CSokobanPuzzles::Save_PlayerProgressInfo(const char* pFilename)
{
	IDofActualPlayedPuzzle = IDofActualPlayedPuzzle % NumOfPuzzles;

	std::ofstream WriteFile;

	// neue Datei erzeugen bzw. alte �berschreiben:
	WriteFile.open(pFilename);

	// neue Datei erzeugen bzw. Inhalt ans Ende einer bestehenden Datei schreiben: 
	//WriteFile.open(pFilename, ios::app);

	if (WriteFile.good() == false)
		return false;

	WriteFile << "IDofActualPlayedPuzzle: "  << IDofActualPlayedPuzzle << endl;

	WriteFile.close();

	return true;
}

bool CSokobanPuzzles::Load_PuzzleInfos(const char* pFilename)
{
	delete[] pPuzzleArray;
	pPuzzleArray = nullptr;

	delete[] pSolvedPuzzleArray;
	pSolvedPuzzleArray = nullptr;

	std::ifstream ReadFile;

	// eine existierende Datei zum Lesen �ffnen:
	ReadFile.open(pFilename);

	if (ReadFile.good() == false)
		return false;

	char strBuffer[100];
	
	ReadFile >> strBuffer;
	ReadFile >> NumOfPuzzles;

	pPuzzleArray = new (std::nothrow) CSokobanPuzzle[NumOfPuzzles];
	pSolvedPuzzleArray = new (std::nothrow) CSokobanPuzzle[NumOfPuzzles];

	for (int32_t i = 0; i < NumOfPuzzles; i++)
	{
		ReadFile >> strBuffer;
		pPuzzleArray[i].Set_Filename(strBuffer);
		ReadFile >> strBuffer;
		pSolvedPuzzleArray[i].Set_Filename(strBuffer);
	}

	ReadFile.close();
	return true;
}

bool CSokobanPuzzles::Initialize_Puzzles(const char* pFilename)
{
	delete[] pPuzzleArray;
	pPuzzleArray = nullptr;

	delete[] pSolvedPuzzleArray;
	pSolvedPuzzleArray = nullptr;

	std::ifstream ReadFile;

	// eine existierende Datei zum Lesen �ffnen:
	ReadFile.open(pFilename);

	if (ReadFile.good() == false)
		return false;

	char strBuffer[100];
	
	ReadFile >> strBuffer;
	ReadFile >> NumOfPuzzles;

	pPuzzleArray = new (std::nothrow) CSokobanPuzzle[NumOfPuzzles];

	for (int32_t i = 0; i < NumOfPuzzles; i++)
	{
		ReadFile >> strBuffer;
		pPuzzleArray[i].Set_Filename(strBuffer);
		ReadFile >> strBuffer;
		pSolvedPuzzleArray[i].Set_Filename(strBuffer);
	}

	ReadFile.close();

	for (int32_t i = 0; i < NumOfPuzzles; i++)
	{
		pPuzzleArray[i].Load_Puzzle();
		pSolvedPuzzleArray[i].Load_Puzzle();
	}

	return true;
}

void Calculate_Path(int32_t *pOutPathTileIDArray, int32_t *pOutNumOfPathSteps, int32_t startPosX, int32_t startPosY, int32_t destinationPosX, int32_t destinationPosY, CSokobanPuzzle *pPuzzle, int32_t featureMapID, int32_t numOfSearchStepsMax)
{
	numOfSearchStepsMax = max(numOfSearchStepsMax, 1);

	*pOutNumOfPathSteps = 0;

	if (pPuzzle->Check_For_ShortestPaths(pOutPathTileIDArray, pOutNumOfPathSteps, startPosX, startPosY, destinationPosX, destinationPosY) == false)
	{
		pPuzzle->Reset_NeuralNetValueArray_MovementSpace(featureMapID);

		if (pPuzzle->Start_Pathfinding(destinationPosX, destinationPosY, featureMapID) == true)
		{
			bool pathCompleted = false;

			for (int32_t i = 1; i < numOfSearchStepsMax; i++)
			{
				if (pPuzzle->Update_Pathfinding(i, startPosX, startPosY, featureMapID) == true)
				{
					//Add_To_Log(0, "searchSteps", i);
					pathCompleted = true;
					break;
				}
			}

			//if (pathCompleted == false)
			//{
			//Add_To_Log(0, "no path found");
			//}

			if (pathCompleted == true)
			{
				pPuzzle->Get_Path(pOutPathTileIDArray, pOutNumOfPathSteps, startPosX, startPosY, destinationPosX, destinationPosY, featureMapID);
			}
		} // end of if (pPuzzle->Start_Pathfinding...
	} // end of if (pPuzzle->Check_For_ShortestPaths...
}

bool Verify_Path(int32_t startPosX, int32_t startPosY, int32_t destinationPosX, int32_t destinationPosY, CSokobanPuzzle *pPuzzle, int32_t featureMapID, int32_t numOfSearchStepsMax)
{
	if (pPuzzle->Check_For_ShortestPaths(startPosX, startPosY, destinationPosX, destinationPosY) == true)
	{
		return true;
	}

	pPuzzle->Reset_NeuralNetValueArray_MovementSpace(featureMapID);
	
	if (pPuzzle->Start_Pathfinding(destinationPosX, destinationPosY, featureMapID) == false)
	{
		return false;
	}

	numOfSearchStepsMax = max(numOfSearchStepsMax, 1);
	
	bool pathCompleted = false;

	for (int32_t i = 1; i < numOfSearchStepsMax; i++)
	{
		if (pPuzzle->Update_Pathfinding(i, startPosX, startPosY, featureMapID) == true)
		{
			//Add_To_Log(0, "searchSteps", i);
			pathCompleted = true;
			break;
		}
	}

	if (pathCompleted == true)
	{
		return true;
	}

	return false;
}

bool Verify_Path_IncludingDiagonalMovement(int32_t startPosX, int32_t startPosY, int32_t destinationPosX, int32_t destinationPosY, CSokobanPuzzle *pPuzzle, int32_t featureMapID, int32_t numOfSearchStepsMax)
{
	if (pPuzzle->Check_For_ShortestPaths_IncludingDiagonalMovement(startPosX, startPosY, destinationPosX, destinationPosY) == true)
	{
		return true;
	}


	pPuzzle->Reset_NeuralNetValueArray_MovementSpace(featureMapID);

	if (pPuzzle->Start_Pathfinding(destinationPosX, destinationPosY, featureMapID) == false)
	{
		return false;
	}

	numOfSearchStepsMax = max(numOfSearchStepsMax, 1);

	bool pathCompleted = false;

	for (int32_t i = 1; i < numOfSearchStepsMax; i++)
	{
		if (pPuzzle->Update_Pathfinding(i, startPosX, startPosY, featureMapID) == true)
		{
			//Add_To_Log(0, "searchSteps", i);
			pathCompleted = true;
			break;
		}
	}

	if (pathCompleted == true)
	{
		return true;
	}

	return false;
}

void Calculate_Path_IncludingDiagonalMovement(int32_t *pOutPathTileIDArray,
	int32_t *pOutNumOfPathSteps, int32_t startPosX, int32_t startPosY,
	int32_t destinationPosX, int32_t destinationPosY, CSokobanPuzzle *pPuzzle,
	int32_t featureMapID, int32_t numOfSearchStepsMax)
{
	numOfSearchStepsMax = max(numOfSearchStepsMax, 1);

	*pOutNumOfPathSteps = 0;

	if (pPuzzle->Check_For_ShortestPaths_IncludingDiagonalMovement(
		pOutPathTileIDArray, pOutNumOfPathSteps, startPosX, startPosY,
		destinationPosX, destinationPosY) == false)
	{

#ifdef OpenMP_Pathfinding
		pPuzzle->Reset_NeuralNetValueArray_MovementSpace_OMP(featureMapID);
		pPuzzle->Reset_NeuralNetValueArray_MovementSpace_OMP(
			pPuzzle->constNumOfFeatureMapsMinus1);
#else
		pPuzzle->Reset_NeuralNetValueArray_MovementSpace(featureMapID);
#endif

		if (pPuzzle->Start_Pathfinding(destinationPosX, destinationPosY,
			featureMapID) == true)
		{
#ifdef OpenMP_Pathfinding
			pPuzzle->Clone_FeatureMapValues_OMP(
				/*Destination:*/ pPuzzle->constNumOfFeatureMapsMinus1,
				/*Source:*/ featureMapID);
#endif

			bool pathCompleted = false;

			for (int32_t i = 1; i < numOfSearchStepsMax; i++)
			{
#ifdef OpenMP_Pathfinding
				if (pPuzzle->Update_Pathfinding_OMP(i, startPosX,
					startPosY, featureMapID) == true)
#else
				if (pPuzzle->Update_Pathfinding(i, startPosX,
					startPosY, featureMapID) == true)
#endif
				{
					pathCompleted = true;
					break;
				}
			} /* end of for (int32_t i = 1; i < numOfSearchStepsMax; i++) */

			if (pathCompleted == true)
			{
				pPuzzle->Get_Path_IncludingDiagonalMovement(pOutPathTileIDArray,
					pOutNumOfPathSteps, startPosX, startPosY, destinationPosX,
					destinationPosY, featureMapID);
			}
		} /* end of if (pPuzzle->Start_Pathfinding...*/
	} /* end of if (pPuzzle->Check_For_ShortestPaths...*/
}






CSimpleSokobanSolver::CSimpleSokobanSolver()
{
	PullMoveFunctionArray[0] = &CSimpleSokobanSolver::Make_LeftPullMove;
	PullMoveFunctionArray[1] = &CSimpleSokobanSolver::Make_RightPullMove;
	PullMoveFunctionArray[2] = &CSimpleSokobanSolver::Make_UpwardPullMove;
	PullMoveFunctionArray[3] = &CSimpleSokobanSolver::Make_DownwardPullMove;

	pSavedGameStateArray = new (std::nothrow) CGameStateValues[NumOfSavedGameStatesMax];
	pNumOfPossibleSubsequentMovesArray = new (std::nothrow) int32_t[NumOfSavedGameStatesMax];

	pDiscardedGameStateCharacteristicsArray = new (std::nothrow) CSokobanGameStateCharacteristics[NumOfDiscardedGameStatesMax];
	pVisitedGameStateCharacteristicsArray = new (std::nothrow) CSokobanGameStateCharacteristics[NumOfVisitedGameStatesMax];
}

CSimpleSokobanSolver::~CSimpleSokobanSolver()
{
	delete[] pBoxCharacteristicsArray;
	pBoxCharacteristicsArray = nullptr;

	delete[] pTempBoxCharacteristicsArray;
	pTempBoxCharacteristicsArray = nullptr;

	delete[] pSavedGameStateArray;
	pSavedGameStateArray = nullptr;

	delete[] pNumOfPossibleSubsequentMovesArray;
	pNumOfPossibleSubsequentMovesArray = nullptr;


	delete[] pDiscardedGameStateCharacteristicsArray;
	pDiscardedGameStateCharacteristicsArray = nullptr;

	delete[] pVisitedGameStateCharacteristicsArray;
	pVisitedGameStateCharacteristicsArray = nullptr;
}

/*void CSimpleSokobanSolver::Determine_NextTestMove(int32_t *pOutIDofMovingBox, int32_t *pOutMovementDir)
{
	static int32_t idOfMovingBox = 0;
	static int32_t movementDir = 0;
	static bool MovementPossibilityArray[4] = { false, false, false , false };

	MovementPossibilityArray[0] = pBoxCharacteristicsArray[idOfMovingBox].LeftPullPossible;
	MovementPossibilityArray[1] = pBoxCharacteristicsArray[idOfMovingBox].RightPullPossible;
	MovementPossibilityArray[2] = pBoxCharacteristicsArray[idOfMovingBox].UpwardPullPossible;
	MovementPossibilityArray[3] = pBoxCharacteristicsArray[idOfMovingBox].DownwardPullPossible;

	for (int32_t i = movementDir; i < 4; i++)
	{
		if (MovementPossibilityArray[i] == true)
		{
			*pOutIDofMovingBox = idOfMovingBox;
			*pOutMovementDir = i;
			movementDir = i + 1;

			if (movementDir == 4)
			{
				movementDir = 0;
				idOfMovingBox++;

				if (idOfMovingBox == NumOfBoxes)
				{
					idOfMovingBox = 0;
				}
			}

			return;
		}

		

	}
}*/

void CSimpleSokobanSolver::Decrease_StatusValues_Of_Visited_GameStates(float value)
{
	for (int32_t k = 0; k < NumOfVisitedGameStatesInUse; k++)
	{
		pVisitedGameStateCharacteristicsArray[k].fStatusValue -= value;
		pVisitedGameStateCharacteristicsArray[k].fStatusValue = max(0.0f, pVisitedGameStateCharacteristicsArray[k].fStatusValue);
	}
}

void CSimpleSokobanSolver::Increase_StatusValue_Of_Visited_GameState(CGameStateValues *pActualVisitedGameState, float value)
{
	TestVisitedGameStateCharacteristics.Set_Values(pActualVisitedGameState);

	bool visitedGameState = false;

	for (int32_t k = 0; k < NumOfVisitedGameStatesInUse; k++)
	{
		if (pVisitedGameStateCharacteristicsArray[k].Check_Identity(&TestVisitedGameStateCharacteristics) == true)
		{
			pVisitedGameStateCharacteristicsArray[k].fStatusValue += value;
			visitedGameState = true;
			break;
		}
	}

	if (visitedGameState == false)
	{
		if (NumOfVisitedGameStatesInUse < NumOfVisitedGameStatesMaxMinus1)
		{
			pVisitedGameStateCharacteristicsArray[NumOfVisitedGameStatesInUse].Set_Values(pActualVisitedGameState);
			pVisitedGameStateCharacteristicsArray[NumOfVisitedGameStatesInUse].fStatusValue += value;
			NumOfVisitedGameStatesInUse++;
		}
	}
}

void CSimpleSokobanSolver::Update_ActualGameState(void)
{
	ActualGameState.Clone_GameStateValues(&pSavedGameStateArray[ActualSearchDepth]);
	Update_BoxCharacteristics(ActualGameState.pValueArray);
	MaxDistBasedEvaluationValue = Calc_DistanceBasedEvaluationValue();
	Get_PlayerPosition(ActualGameState.pValueArray);
}

void CSimpleSokobanSolver::Restart_with_Solved_Puzzle(void)
{
	ActualSearchDepth = 0;
	pNumOfPossibleSubsequentMovesArray[0] = 0;
	ActualGameState.Clone_GameStateValues(&pSavedGameStateArray[ActualSearchDepth]);
	Update_BoxCharacteristics(ActualGameState.pValueArray);
	MaxDistBasedEvaluationValue = Calc_DistanceBasedEvaluationValue();
	Get_PlayerPosition(ActualGameState.pValueArray);
}

bool CSimpleSokobanSolver::Check_If_GameState_Is_Discarded(CGameStateValues *pGameState)
{
	DiscardedGameStateCharacteristics.Set_Values(pGameState);

	for (int32_t k = 0; k < NumOfDiscardedGameStatesInUse; k++)
	{
		if (pDiscardedGameStateCharacteristicsArray[k].Check_Identity(&DiscardedGameStateCharacteristics) == true)
		{
			return true;
		}
	}

	return false;
}

bool CSimpleSokobanSolver::Check_If_ActualGameState_Is_Discarded(void)
{
	DiscardedGameStateCharacteristics.Set_Values(&ActualGameState);

	for (int32_t k = 0; k < NumOfDiscardedGameStatesInUse; k++)
	{
		if (pDiscardedGameStateCharacteristicsArray[k].Check_Identity(&DiscardedGameStateCharacteristics) == true)
		{
			return true;
		}
	}

	return false;
}


bool CSimpleSokobanSolver::Make_TestPullMove_If_Possible(int32_t testMoveNumber, int32_t selectedBoxID)
{
	TestVisitedGameState.Clone_GameStateValues(&ActualGameState);

	Get_PlayerPosition(TestVisitedGameState.pValueArray);
	Puzzle.Calculate_NeuralNetValueArray_MovementSpace(TestVisitedGameState.pValueArray, 0);
	Update_BoxCharacteristics(TestVisitedGameState.pValueArray);

	/* Testzug ausf�hren wenn m�glich, oder andernfalls einen anderen Zug versuchen: */
	if ((this->*PullMoveFunctionArray[testMoveNumber])(TestVisitedGameState.pValueArray, selectedBoxID) == false)
	{
		return false;
	}

	Get_PlayerPosition(TestVisitedGameState.pValueArray);
	Puzzle.Calculate_NeuralNetValueArray_MovementSpace(TestVisitedGameState.pValueArray, 0);
	Update_BoxCharacteristics(TestVisitedGameState.pValueArray);

	return true;
}

void CSimpleSokobanSolver::Discard_ActualGameState(void)
{
	if (NumOfDiscardedGameStatesInUse < NumOfDiscardedGameStatesMaxMinus1)
	{
		pDiscardedGameStateCharacteristicsArray[NumOfDiscardedGameStatesInUse].Set_Values(&ActualGameState);
		NumOfDiscardedGameStatesInUse++;
		Add_To_Log(0, "NumOfDiscardedGameStatesInUse", NumOfDiscardedGameStatesInUse);
	}
}

void CSimpleSokobanSolver::Discard_GameState(CGameStateValues *pGameState)
{
	if (NumOfDiscardedGameStatesInUse < NumOfDiscardedGameStatesMaxMinus1)
	{
		pDiscardedGameStateCharacteristicsArray[NumOfDiscardedGameStatesInUse].Set_Values(pGameState);
		NumOfDiscardedGameStatesInUse++;
		Add_To_Log(0, "NumOfDiscardedGameStatesInUse", NumOfDiscardedGameStatesInUse);
	}
}

float CSimpleSokobanSolver::Evaluate_TestGameState(float distEvaluationBasedWeightingFactor)
{
	int32_t distBasedEvaluationValue = Calc_DistanceBasedEvaluationValue();

	float tempFloat = static_cast<float>(distBasedEvaluationValue); // Hinweis: tempFloat <= 0.0f
	tempFloat *= distEvaluationBasedWeightingFactor;

	float evaluationValue = RandomNumbers_Movement.Get_FloatNumber_IncludingZero(0.0f, 1.0f);
	//float evaluationValue = RandomNumbers_Movement.Get_FloatNumber_IncludingZero(0.0f, 10000000.0f);
	evaluationValue *= exp(tempFloat); // Maximalbewertung: tempRandomValue *= 1.0f; / Minimalbewertung: tempRandomValue *= 0.0f; 


	TestVisitedGameStateCharacteristics.Set_Values(&TestVisitedGameState);

	for (int32_t k = 0; k < NumOfVisitedGameStatesInUse; k++)
	{
		if (pVisitedGameStateCharacteristicsArray[k].Check_Identity(&TestVisitedGameStateCharacteristics) == true)
		{
			// Game-State bevorzugen, der noch nicht so h�ufig besucht wurde:
			evaluationValue *= exp(-pVisitedGameStateCharacteristicsArray[k].fStatusValue);
			break;
		}
	}

	return evaluationValue;
}

bool CSimpleSokobanSolver::Make_PullMove(int32_t searchDepthMax, float distEvaluationBasedWeightingFactor, float visitedGameStateStatusValueIncrease, float visitedGameStateStatusValueDecrease)
{
	static bool MovementPossibilityArray[4] = { false, false, false , false };

	if (PuzzleSolved == true)
	{
		return true;
	}

	Decrease_StatusValues_Of_Visited_GameStates(visitedGameStateStatusValueDecrease);
	
	searchDepthMax = min(searchDepthMax, NumOfSavedGameStatesMax - 1);

	/* Sofern die maximale Suchtiefe (Pull-Zug-Anzahl) erreicht ist, versuchen wir, ausgehend
	   vom Puzzle-Endzustand einen anderen L�sungsweg zu finden: */

	if (ActualSearchDepth >= searchDepthMax)
	{
		Restart_with_Solved_Puzzle();
	}

	/* Vorbereitungen f�r die m�gliche Durchf�hrung eines weiteren Spielzugs treffen: */

	int8_t *pActualGameStateData = ActualGameState.pValueArray;
	Puzzle.Calculate_NeuralNetValueArray_MovementSpace(pActualGameStateData, 0);
	Get_PlayerPosition(pActualGameStateData);
	Update_BoxCharacteristics(pActualGameStateData);

	/* �berpr�fen, ob die Durchf�hrung eines weiteren Spielzugs �berhaupt zielf�hrend ist: */

	for (int32_t boxID = 0; boxID < NumOfBoxes; boxID++)
	{
		/* Sofern es von der aktuellen Spielstellung aus keine M�glichkeit
		   mehr gibt, den Puzzle-Anfang zu erreichen, weil sich eine oder
		   mehrere Kisten nicht mehr verschieben lassen, versuchen wir
		   einen alternativen L�sungsweg zu finden: */

		if (Check_If_BoxIsPermanentlyBlockedForPullMove(pBoxCharacteristicsArray[boxID].PosID, pActualGameStateData) == true)
		{
			Add_To_Log(0, "BoxIsPermanentlyBlockedForPullMove", boxID);

			/* Spielstellung, sofern noch nicht erfolgt, im pDiscardedGameStateCharacteristicsArray hinterlegen und versuchen, einen anderen L�sungsweg zu finden: */

			if (Check_If_ActualGameState_Is_Discarded() == false)
			{
				Discard_ActualGameState();
			}

			// Variante 1:
			/*if (ActualSearchDepth > 0)
			{
			    ActualSearchDepth--;
			    Update_ActualGameState();
			}*/

			// Variante 2:
			Restart_with_Solved_Puzzle();

			return false;

		} /* end of if (Check_If_BoxIsPermanentlyBlockedForPullMove(pBoxCharacteristicsArray[i].PosID, pActualGameStateData) == true) */
	} /* for (int32_t boxID = 0; boxID < NumOfBoxes; boxID++) */


	  /* An dieser Stelle k�nnen wir mit der Suche nach einem weiteren
	     m�glichst vielversprechenden Testzug beginnen: */

	float maxEvaluationValue = -1.0f;
	int32_t numOfPromisingPullMoves = 0;
	int32_t numOfPossiblePullMoves = 0;
	bool playerDeadLockDetected = false;
	bool deadEndDetected = false;

	for (int32_t boxID = 0; boxID < NumOfBoxes; boxID++)
	{
		pTempBoxCharacteristicsArray[boxID].Clone_Values(&pBoxCharacteristicsArray[boxID]);
	}

	for (int32_t boxID = 0; boxID < NumOfBoxes; boxID++)
	{
		/* �berpr�fen, welche Pull-Z�ge f�r die betrachtete Kiste ausgef�hrt werden k�nnen: */

		MovementPossibilityArray[0] = pTempBoxCharacteristicsArray[boxID].LeftPullPossible;
		MovementPossibilityArray[1] = pTempBoxCharacteristicsArray[boxID].RightPullPossible;
		MovementPossibilityArray[2] = pTempBoxCharacteristicsArray[boxID].UpwardPullPossible;
		MovementPossibilityArray[3] = pTempBoxCharacteristicsArray[boxID].DownwardPullPossible;
		
		/* Alle vier m�glichen Pull-Zug-Richtungen durchprobieren: */
		for (int32_t testMoveNumber = 0; testMoveNumber < 4; testMoveNumber++)
		{
			if (MovementPossibilityArray[testMoveNumber] == false)
				continue;

			//if (MovementPossibilityArray[testMoveNumber] == true)
			//{
				/* Testzug ausf�hren wenn m�glich: */

				if (Make_TestPullMove_If_Possible(testMoveNumber, boxID) == false)
				{
					continue;
				}

				/* Falls wir mit dem zuletzt durchgef�hrten Testzug zur initialen Spielstellung des zu
				   l�senden Sokoban-Levels gelangen, haben wir unser Ziel erreicht und k�nnen auf
				   weitere Testz�ge verzichten: */

				if (Check_If_Puzzle_Is_Solved(&TestVisitedGameState) == true)
				{
					return true;
				}

				/* Sofern sich der KI-Spieler nach dem Testzug in eine Sackgasse
				   man�vriert hat und sich nicht mehr bewegen kann, m�ssen wir
				   einen anderen Zug versuchen, falls m�glich: */

				if (Check_PlayerDeadLock(TestVisitedGameState.pValueArray) == true)
				{
					playerDeadLockDetected = true;					
					continue;
				}

				/* Sofern eine aus einem Testzug resultierende Spielstellung bereits
				   zu einem fr�heren Zeitpunkt verworfen und als Konsequenz daraus
				   im pDiscardedGameStateCharacteristicsArray hinterlegt worden ist
				   (von der besagten Stellung aus kann der Puzzle-Anfang unm�glich
				   erreicht werden), m�ssen wir einen anderen Zug versuchen,
				   falls m�glich: */

				if (Check_If_GameState_Is_Discarded(&TestVisitedGameState) == true)
				{
					deadEndDetected = true;
					continue;
				}

				numOfPossiblePullMoves++;

				
				/* Neue Spielstellung nach Testzug bewerten. Am Ende soll derjenige Testzug ausgef�hrt werden,
				   der zu der am besten bewerteten Spielstellung f�hrt: */
				 
				float evaluationValue = Evaluate_TestGameState(distEvaluationBasedWeightingFactor);

				/* Jedes Mal, wenn ein Testzug zu einer besser bewerteten Spielstellung f�hrt, wird die zuvor gefundene,
				   schlechter bewertete Spielstellung wieder �berschrieben: */

				if (evaluationValue >= maxEvaluationValue)
				{
					numOfPromisingPullMoves++;
					maxEvaluationValue = evaluationValue;
					// Neue Spielstellung nach Testzug speichern:
					pSavedGameStateArray[ActualSearchDepth + 1].Clone_GameStateValues(&TestVisitedGameState);
				}


			//} /* end of if (MovementPossibilityArray[testMoveNumber] == true) */
		} /* for (int32_t testMoveNumber = 0; testMoveNumber < 4; testMoveNumber++) */
	} /* end of for (int32_t boxID = 0; boxID < NumOfBoxes; boxID++) */


	/* Es konnten ein oder mehrere erfolgversprechende Testz�ge
	   gefunden werden, von denen der am besten bewertete
	   ausgef�hrt wurde: */
	if (numOfPromisingPullMoves > 0)
	{
		/* Anzahl der m�glichen Testz�ge speichern, die sich von der
		   letzten Spielstellung aus durchf�hren lassen: */

		pNumOfPossibleSubsequentMovesArray[ActualSearchDepth] = numOfPossiblePullMoves;
		ActualSearchDepth++;

		Update_ActualGameState();

		/* Auch wenn ein Zug ausgef�hrt werden konnte, bedeutet das noch lange nicht, dass uns dieser Zug unserem Ziel,
		   den Puzzle-Anfang zu erreichen, auch tats�chlich n�her bringt. Genau das gilt es an dieser Stelle
		   zu �berpr�fen:*/

		if (ActualSearchDepth > 1)
		{
			/* Probleme k�nnen sich insbesondere immer dann ergeben, wenn von der letzten Spielstellung aus nur ein einziger Zug m�glich ist: */

			if (pNumOfPossibleSubsequentMovesArray[ActualSearchDepth - 1] == 1)
			{
				TestVisitedGameStateCharacteristics.Set_Values(&pSavedGameStateArray[ActualSearchDepth - 2]);
			
				/* Wenn die vorletzte Spielstellung (ActualSearchDepth - 2) mit der aktuellen Spielstellung (ActualSearchDepth) identisch ist und von der letzten   
			       Spielstellung (ActualSearchDepth - 1) aus nur ein einziger Zug m�glich ist, dann wird die letzte Spielstellung (ActualSearchDepth - 1)
				   als nicht zielf�hrend verworfen und als Konsequenz daraus im pDiscardedGameStateCharacteristicsArray hinterlegt: */

				if (TestVisitedGameStateCharacteristics.Check_Identity_IgnorePlayer(&pSavedGameStateArray[ActualSearchDepth]) == true)
				{
					Discard_GameState(&pSavedGameStateArray[ActualSearchDepth - 1]);
					Add_To_Log(0, "X - X");

					/* Wenn es dar�ber hinaus von der vorletzten Spielstellung
					(ActualSearchDepth - 2) aus auch nur einen m�glichen Zug gibt, der
					uns zu der zuvor verworfenen Spielstellung (ActualSearchDepth - 1)
					f�hrt, ist es nur folgerichtig, auch die vorletzte Spielstellung
					(ActualSearchDepth - 2) als nicht zielf�hrend zu verwerfen: */


					if (pNumOfPossibleSubsequentMovesArray[ActualSearchDepth - 2] == 1)
					{
						Discard_GameState(&pSavedGameStateArray[ActualSearchDepth - 2]);
						Add_To_Log(0, "(X) - X");
					}
				} /* end of if (TempVisitedGameState.Check_Identity_IgnorePlayer(&pSavedGameStateArray[ActualSearchDepth]) == true) */
			} /* end of if (pSavedGameStateNumOfPossibleSubsequentMoves[ActualSearchDepth - 1] == 1)*/
		} /* end of if (ActualSearchDepth > 1) */

		/* Jedes Mal, wenn ein Game-State erneut besucht wird, erh�hen wir dessen Statuswert (fStatusValue): */

		Increase_StatusValue_Of_Visited_GameState(&pSavedGameStateArray[ActualSearchDepth], visitedGameStateStatusValueIncrease);

		return true;
	} /* end of if (numOfConsideredPullMoves > 0) */
	/* Die Suche nach einem gewinnbringenden Testzug verlief ergebnislos: */
	else if (numOfPromisingPullMoves == 0)
	{
		/* Wenn sich von der aktuellen Spielstellung aus der Puzzle-Anfang nicht erreichen l�sst, dann hat das selbstverst�ndlich
		   auch Konsequenzen f�r die vorangegangenen Spielstellungen: */

		if (ActualSearchDepth > 0)
		{
			/* Die aktuelle Spielstellung wird im pDiscardedGameStateCharacteristicsArray hinterlegt, da der KI-Spieler von dieser
			   aus keinen Zug mehr ausf�hren kann: */
			if (Check_If_ActualGameState_Is_Discarded() == false)
			{
				Discard_ActualGameState();

				if (playerDeadLockDetected == true || deadEndDetected == true)
					Add_To_Log(0, "PlayerDeadLock or DeadEnd");
				else
					Add_To_Log(0, "no move possible");
			}

			/* Die vorangegangene Spielstellung wird ebenfalls im pDiscardedGameStateCharacteristicsArray hinterlegt, sofern
			   von dieser aus lediglich ein Zug erfolgen kann, der dann zu der zuvor verworfenen
			   Spielstellung f�hrt: */
			if (pNumOfPossibleSubsequentMovesArray[ActualSearchDepth - 1] == 1)
			{
				if (Check_If_GameState_Is_Discarded(&pSavedGameStateArray[ActualSearchDepth - 1]) == false)
				{
					Discard_GameState(&pSavedGameStateArray[ActualSearchDepth - 1]);

					if (playerDeadLockDetected == true || deadEndDetected == true)
						Add_To_Log(0, "PlayerDeadLock or DeadEnd (2)");
					else
						Add_To_Log(0, "no move possible (2)");
				}
			} 
		} /* end of if (ActualSearchDepth > 0) */
		
		/* Da wir keinen weiteren Spielzug mehr finden konnten, m�ssen wir nach einem alternativen L�sungsweg Ausschau halten: */

		// Variante 1:
		/*if (ActualSearchDepth > 0)
		{
			Restart_with_Solved_Puzzle();
		}*/

		// Variante 2:
		if (ActualSearchDepth == 1 || ActualSearchDepth == 2)
		{
			Restart_with_Solved_Puzzle();
		}
		else if (ActualSearchDepth > 2)
		{		
			ActualSearchDepth -= 3;
			Update_ActualGameState();
		}


		return false;
	} /* end of else if (numOfConsideredPullMoves == 0) */

	return false;
}

/*
bool CSimpleSokobanSolver::Make_PullMoveTest(int32_t searchDepthMax)
{
	static bool MovementPossibilityArray[4] = { false, false, false , false };


	if (PuzzleSolved == true)
	{
		return true;
	}

	
	searchDepthMax = min(searchDepthMax, NumOfPrevSavedGameStatesMax - 1);


	if (NumOfPrevSavedGameStatesInUse >= searchDepthMax)
	{
		ActualGameState.Clone_GameStateValues(pSolvedPuzzle->GameState.pValueArray);
		NumOfPrevSavedGameStatesInUse = 0;
		pPrevSavedGameStateArray[0].Clone_GameStateValues(&ActualGameState);
		Update_BoxCharacteristics(ActualGameState.pValueArray);
		MaxDistBasedEvaluationValue = Calc_DistanceBasedEvaluationValue();
		Get_PlayerPosition(ActualGameState.pValueArray);
	}

	int8_t *pActualGameStateData = ActualGameState.pValueArray;

	Puzzle.Calculate_NeuralNetValueArray_MovementSpace(pActualGameStateData, 0);

	Get_PlayerPosition(pActualGameStateData);

	if (Check_PossibleInitialPuzzleIdentity(&ActualGameState) == true)
	{
		Update_BoxCharacteristics(pActualGameStateData);

		int32_t distBasedEvaluationValue = Calc_DistanceBasedEvaluationValue();

		if (distBasedEvaluationValue > MaxDistBasedEvaluationValue)
		{
			MaxDistBasedEvaluationValue = distBasedEvaluationValue;
		}

		ActualGameState.Clone_GameStateValues(&pInitialPuzzle->GameState);
		PuzzleSolved = true;
		PlayerPosX = InitialPlayerPosX;
		PlayerPosY = InitialPlayerPosY;

		return true;
	}

	Update_BoxCharacteristics(pActualGameStateData);

	int32_t maxRandomValue = -1;

	int32_t  numOfPossiblePullMoves = 0;



	for (int32_t i = 0; i < NumOfBoxes; i++)
	{
		MovementPossibilityArray[0] = pBoxCharacteristicsArray[i].LeftPullPossible;
		MovementPossibilityArray[1] = pBoxCharacteristicsArray[i].RightPullPossible;
		MovementPossibilityArray[2] = pBoxCharacteristicsArray[i].UpwardPullPossible;
		MovementPossibilityArray[3] = pBoxCharacteristicsArray[i].DownwardPullPossible;

		for (int32_t j = 0; j < 4; j++)
		{
			if (MovementPossibilityArray[j] == true)
			{
				//Add_To_Log(0, "Possible MovementDir", j);

				// Make Test Move:

				TempGameState.Clone_GameStateValues(&ActualGameState);

				Puzzle.Calculate_NeuralNetValueArray_MovementSpace(TempGameState.pValueArray, 1);

				Clone_BoxCharacteristics();

				(this->*TempPullMoveFunctionArray[ j])(TempGameState.pValueArray,  i);

				

				TempDisardedGameState.Set_Values(&TempGameState);

				bool discardedGameState = false;

				for (int32_t k = 0; k < NumOfDisardedGameStatesInUse; k++)
				{
					if (pDisardedGameStateArray[k].Compare(&TempDisardedGameState) == true)
					{
						discardedGameState = true;
						break;
					}
				}

				if (discardedGameState == true)
				{
					continue;
				}

				
				//Update_TempPosBasedBoxCharacteristicsOnly(TempGameState.pValueArray);

				int32_t tempRandomValue = RandomNumbers_Movement.Get_IntegerNumber2(0, 10000000);

				if (tempRandomValue > maxRandomValue)
				{
					numOfPossiblePullMoves++;

					maxRandomValue = tempRandomValue;

					pPrevSavedGameStateArray[NumOfPrevSavedGameStatesInUse + 1].Clone_GameStateValues(&TempGameState);
				}
			} // end of if (MovementPossibilityArray[j] == true)
		}
	} // end of for (int32_t i = 0; i < NumOfBoxes; i++)

	if (numOfPossiblePullMoves > 0)
	{
		NumOfPrevSavedGameStatesInUse++;

		ActualGameState.Clone_GameStateValues(&pPrevSavedGameStateArray[NumOfPrevSavedGameStatesInUse]);

		Update_BoxCharacteristics(ActualGameState.pValueArray);

		MaxDistBasedEvaluationValue = Calc_DistanceBasedEvaluationValue();
	}
	else
	{
		ActualGameState.Clone_GameStateValues(pSolvedPuzzle->GameState.pValueArray);
		NumOfPrevSavedGameStatesInUse = 0;
		pPrevSavedGameStateArray[0].Clone_GameStateValues(&ActualGameState);
		Update_BoxCharacteristics(ActualGameState.pValueArray);
		MaxDistBasedEvaluationValue = Calc_DistanceBasedEvaluationValue();

		return false;
	}


	if (Check_PlayerDeadLock(ActualGameState.pValueArray) == true)
	{
		TempDisardedGameState.Set_Values(&ActualGameState);

		bool discardedGameState = false;

		for (int32_t k = 0; k < NumOfDisardedGameStatesInUse; k++)
		{
			if (pDisardedGameStateArray[k].Compare(&TempDisardedGameState) == true)
			{
				discardedGameState = true;
				break;
			}
		}

		if (discardedGameState == false)
		{
			if (NumOfDisardedGameStatesInUse < NumOfDisardedGameStatesMaxMinus1)
			{
				pDisardedGameStateArray[NumOfDisardedGameStatesInUse].Set_Values(&ActualGameState);
				NumOfDisardedGameStatesInUse++;
			}
		}


		ActualGameState.Clone_GameStateValues(pSolvedPuzzle->GameState.pValueArray);
		NumOfPrevSavedGameStatesInUse = 0;
		pPrevSavedGameStateArray[0].Clone_GameStateValues(&ActualGameState);
		Update_BoxCharacteristics(ActualGameState.pValueArray);
		MaxDistBasedEvaluationValue = Calc_DistanceBasedEvaluationValue();

		return false;
	}

	return true;


	if (numOfPossiblePullMoves > 0)
	{
		if (Check_PlayerDeadLock(pPrevSavedGameStateArray[NumOfPrevSavedGameStatesInUse + 1].pValueArray) == true)
		{
			TempDisardedGameState.Set_Values(&pPrevSavedGameStateArray[NumOfPrevSavedGameStatesInUse + 1]);

			bool discardedGameState = false;

			for (int32_t k = 0; k < NumOfDisardedGameStatesInUse; k++)
			{
				if (pDisardedGameStateArray[k].Compare(&TempDisardedGameState) == true)
				{
					discardedGameState = true;
					break;
				}
			}

			if (discardedGameState == false)
			{
				if (NumOfDisardedGameStatesInUse < NumOfDisardedGameStatesMaxMinus1)
				{
					pDisardedGameStateArray[NumOfDisardedGameStatesInUse].Set_Values(&pPrevSavedGameStateArray[NumOfPrevSavedGameStatesInUse + 1]);
					NumOfDisardedGameStatesInUse++;
				}
			}

			ActualGameState.Clone_GameStateValues(pSolvedPuzzle->GameState.pValueArray);
			NumOfPrevSavedGameStatesInUse = 0;
			pPrevSavedGameStateArray[0].Clone_GameStateValues(&ActualGameState);
			Update_BoxCharacteristics(ActualGameState.pValueArray);
			MaxDistBasedEvaluationValue = Calc_DistanceBasedEvaluationValue();

			return false;
		}

		NumOfPrevSavedGameStatesInUse++;

		ActualGameState.Clone_GameStateValues(&pPrevSavedGameStateArray[NumOfPrevSavedGameStatesInUse]);

		Update_BoxCharacteristics(ActualGameState.pValueArray);

		MaxDistBasedEvaluationValue = Calc_DistanceBasedEvaluationValue();

		return true;
	}
	else
	{
		if (NumOfPrevSavedGameStatesInUse > 0)
		{
			NumOfPrevSavedGameStatesInUse--;
			ActualGameState.Clone_GameStateValues(&pPrevSavedGameStateArray[NumOfPrevSavedGameStatesInUse]);
		}

		ActualGameState.Clone_GameStateValues(pSolvedPuzzle->GameState.pValueArray);
		NumOfPrevSavedGameStatesInUse = 0;
		pPrevSavedGameStateArray[0].Clone_GameStateValues(&ActualGameState);
		Update_BoxCharacteristics(ActualGameState.pValueArray);
		MaxDistBasedEvaluationValue = Calc_DistanceBasedEvaluationValue();

		return false;
	}

	return true;
	
}
*/
/*
Die suche nach einer L�sung erfolgt auf folgende Weise:

Spielstellung (i - 1) -> Spielstellung (i) -> Spielstellung (i + 1)

Wenn die Z�ge von Spielstellung (i) zu keiner Spielstellung (i + 1) mit einer h�heren Bewertung f�hren,
dann speichern wir Spielstellung (i) in einer Liste mit den schlechten Spielz�gen ab, kehren zu
Spielstellung (i - 1) zur�ck und suchen von dort nach einer besseren Nachfolge-Spielstellung.
*/

/*
bool CSimpleSokobanSolver::Make_PullMove(void)
{
	static bool MovementPossibilityArray[4] = { false, false, false , false };

	if (NumOfDisardedGameStatesInUse >= NumOfDisardedGameStatesMaxMinus1)
	{
		Add_To_Log(0, "NumOfDisardedGameStatesInUse >= NumOfDisardedGameStatesMaxMinus1");
		return false;
	}

	if (PuzzleSolved == true)
	{
		return true;
	}

	if (NumOfPrevSavedGameStatesInUse >= NumOfPrevSavedGameStatesMax)
	{
		return false;
	}

	int8_t *pActualGameStateData = ActualGameState.pValueArray;

	Puzzle.Calculate_NeuralNetValueArray_MovementSpace(pActualGameStateData, 0);

	Get_PlayerPosition(pActualGameStateData);

	if (Check_PossibleInitialPuzzleIdentity(&ActualGameState) == true)
	{
		Update_BoxCharacteristics(pActualGameStateData);

		int32_t distBasedEvaluationValue = Calc_DistanceBasedEvaluationValue();

		if (distBasedEvaluationValue > MaxDistBasedEvaluationValue)
		{
			MaxDistBasedEvaluationValue = distBasedEvaluationValue;
		}

		ActualGameState.Clone_GameStateValues(&pInitialPuzzle->GameState);
		PuzzleSolved = true;
		PlayerPosX = InitialPlayerPosX;
		PlayerPosY = InitialPlayerPosY;

		return true;
	}

	Update_BoxCharacteristics(pActualGameStateData);

	
	int32_t maxDistBasedEvaluationValue = LowestDistBasedEvaluationValue;

	

	bool pullMovePossible = false;

	for (int32_t i = 0; i < NumOfBoxes; i++)
	{
		MovementPossibilityArray[0] = pBoxCharacteristicsArray[i].LeftPullPossible;
		MovementPossibilityArray[1] = pBoxCharacteristicsArray[i].RightPullPossible;
		MovementPossibilityArray[2] = pBoxCharacteristicsArray[i].UpwardPullPossible;
		MovementPossibilityArray[3] = pBoxCharacteristicsArray[i].DownwardPullPossible;

		for (int32_t j = 0; j < 4; j++)
		{
			if (MovementPossibilityArray[j] == true)
			{
				//Add_To_Log(0, "Possible MovementDir", j);

				// Make Test Move:

				TempGameState.Clone_GameStateValues(&ActualGameState);

				Puzzle.Calculate_NeuralNetValueArray_MovementSpace(TempGameState.pValueArray, 1);

				Clone_BoxCharacteristics();

				(this->*TempPullMoveFunctionArray[ j])(TempGameState.pValueArray,  i);

				
				TempDisardedGameState.Set_Values(&TempGameState);

				bool discardedGameState = false;

				for (int32_t k = 0; k < NumOfDisardedGameStatesInUse; k++)
				{
					if (pDisardedGameStateArray[k].Compare(&TempDisardedGameState) == true)
					{
						discardedGameState = true;
						break;
					}
				}

				if (discardedGameState == true)
				{
					continue;
				}
				

				Update_TempPosBasedBoxCharacteristicsOnly(TempGameState.pValueArray);

				int32_t tempDistBasedEvaluationValue = Calc_TempDistanceBasedEvaluationValue();

				//Add_To_Log(0, "tempDistBasedEvaluationValue", tempDistBasedEvaluationValue);

				if (tempDistBasedEvaluationValue > maxDistBasedEvaluationValue)
				{
					pullMovePossible = true;

					maxDistBasedEvaluationValue = tempDistBasedEvaluationValue;

					pPrevSavedGameStateArray[NumOfPrevSavedGameStatesInUse + 1].Clone_GameStateValues(&TempGameState);
					pPrevDistBasedEvaluationValueArray[NumOfPrevSavedGameStatesInUse + 1] = tempDistBasedEvaluationValue;


					pPrevMovedBoxIDArray[NumOfPrevSavedGameStatesInUse] = i;
					pPrevBoxMovementDirArray[NumOfPrevSavedGameStatesInUse] = j;
				}
			} // end of if (MovementPossibilityArray[j] == true)
		}
	} // end of for (int32_t i = 0; i < NumOfBoxes; i++)
	
	if (pullMovePossible == true)
	{
		NumOfPrevSavedGameStatesInUse++;

		ActualGameState.Clone_GameStateValues(&pPrevSavedGameStateArray[NumOfPrevSavedGameStatesInUse]);
		MaxDistBasedEvaluationValue = maxDistBasedEvaluationValue;	
	}
	else
	{
		if (NumOfPrevSavedGameStatesInUse > 0)
		{
			if(NumOfDisardedGameStatesInUse < NumOfDisardedGameStatesMaxMinus1)
			{
				pDisardedGameStateArray[NumOfDisardedGameStatesInUse].Set_Values(&ActualGameState);
				NumOfDisardedGameStatesInUse++;
				Add_To_Log(0, "NumOfDisardedGameStatesInUse", NumOfDisardedGameStatesInUse);
			}
			
			NumOfPrevSavedGameStatesInUse--;
			ActualGameState.Clone_GameStateValues(&pPrevSavedGameStateArray[NumOfPrevSavedGameStatesInUse]);
		}
		else
		{
			Add_To_Log(0, "problem");
		}
	}

	return pullMovePossible;
}
*/


bool CSimpleSokobanSolver::Make_LeftPullMove(int8_t *pInOutActualGameStateData, int32_t boxID)
{
	if (pBoxCharacteristicsArray[boxID].LeftPullPossible == false)
	{
		return false;
	}
	if (pBoxCharacteristicsArray[boxID].LeftSideBlockedForPlayer == true)
	{
		return false;
	}

	int32_t boxPosID = pBoxCharacteristicsArray[boxID].PosID;
	int32_t boxPosX = pBoxCharacteristicsArray[boxID].PosX;
	int32_t boxPosY = pBoxCharacteristicsArray[boxID].PosY;

	if (Verify_Path(PlayerPosX, PlayerPosY, boxPosX - 1, boxPosY, &Puzzle, /*FeatureMapID:*/ 0, NumOfPathFindingSearchStepsMax) == false)
	{
		pBoxCharacteristicsArray[boxID].LeftSideBlockedForPlayer = true;
		return false;
	}

	if (pInOutActualGameStateData[PlayerPosID] == ConstGameBoard_Player)
	{
		pInOutActualGameStateData[PlayerPosID] = ConstGameBoard_Empty;
	}
	else if (pInOutActualGameStateData[PlayerPosID] == ConstGameBoard_DestinationWithPlayer)
	{
		pInOutActualGameStateData[PlayerPosID] = ConstGameBoard_Destination;
	}

	int32_t boxPosIDMinus1X = boxPosID - 1;

	if (pInOutActualGameStateData[boxPosIDMinus1X] == ConstGameBoard_Empty)
	{
		pInOutActualGameStateData[boxPosIDMinus1X] = ConstGameBoard_Player;
	}
	else if (pInOutActualGameStateData[boxPosIDMinus1X] == ConstGameBoard_Destination)
	{
		pInOutActualGameStateData[boxPosIDMinus1X] = ConstGameBoard_DestinationWithPlayer;
	}


	int32_t boxPosIDMinus2X = boxPosID - 2;

	int8_t tileTypeOldBoxPos = pInOutActualGameStateData[boxPosID];
	int8_t tileTypeNewBoxPos = pInOutActualGameStateData[boxPosIDMinus1X];
	int8_t tileTypeNewPlayerPos = pInOutActualGameStateData[boxPosIDMinus2X];

	if (tileTypeOldBoxPos == ConstGameBoard_Box)
	{
		pInOutActualGameStateData[boxPosID] = ConstGameBoard_Empty;
	}
	else if (tileTypeOldBoxPos == ConstGameBoard_DestinationWithBox)
	{
		pInOutActualGameStateData[boxPosID] = ConstGameBoard_Destination;
	}

	if (tileTypeNewBoxPos == ConstGameBoard_Player)
	{
		pInOutActualGameStateData[boxPosIDMinus1X] = ConstGameBoard_Box;
	}
	else if (tileTypeNewBoxPos == ConstGameBoard_DestinationWithPlayer)
	{
		pInOutActualGameStateData[boxPosIDMinus1X] = ConstGameBoard_DestinationWithBox;
	}

	if (tileTypeNewPlayerPos == ConstGameBoard_Empty)
	{
		pInOutActualGameStateData[boxPosIDMinus2X] = ConstGameBoard_Player;
	}
	else if (tileTypeNewPlayerPos == ConstGameBoard_Destination)
	{
		pInOutActualGameStateData[boxPosIDMinus2X] = ConstGameBoard_DestinationWithPlayer;
	}

	return true;
}

bool CSimpleSokobanSolver::Make_RightPullMove(int8_t *pInOutActualGameStateData, int32_t boxID)
{
	if (pBoxCharacteristicsArray[boxID].RightPullPossible == false)
	{
		return false;
	}
	if (pBoxCharacteristicsArray[boxID].RightSideBlockedForPlayer == true)
	{
		return false;
	}

	int32_t boxPosID = pBoxCharacteristicsArray[boxID].PosID;
	int32_t boxPosX = pBoxCharacteristicsArray[boxID].PosX;
	int32_t boxPosY = pBoxCharacteristicsArray[boxID].PosY;

	if (Verify_Path(PlayerPosX, PlayerPosY, boxPosX + 1, boxPosY, &Puzzle, /*FeatureMapID:*/ 0, NumOfPathFindingSearchStepsMax) == false)
	{
		pBoxCharacteristicsArray[boxID].RightSideBlockedForPlayer = true;
		return false;
	}

	if (pInOutActualGameStateData[PlayerPosID] == ConstGameBoard_Player)
	{
		pInOutActualGameStateData[PlayerPosID] = ConstGameBoard_Empty;
	}
	else if (pInOutActualGameStateData[PlayerPosID] == ConstGameBoard_DestinationWithPlayer)
	{
		pInOutActualGameStateData[PlayerPosID] = ConstGameBoard_Destination;
	}

	int32_t boxPosIDPlus1X = boxPosID + 1;

	if (pInOutActualGameStateData[boxPosIDPlus1X] == ConstGameBoard_Empty)
	{
		pInOutActualGameStateData[boxPosIDPlus1X] = ConstGameBoard_Player;
	}
	else if (pInOutActualGameStateData[boxPosIDPlus1X] == ConstGameBoard_Destination)
	{
		pInOutActualGameStateData[boxPosIDPlus1X] = ConstGameBoard_DestinationWithPlayer;
	}

	int32_t boxPosIDPlus2X = boxPosID + 2;

	int8_t tileTypeOldBoxPos = pInOutActualGameStateData[boxPosID];
	int8_t tileTypeNewBoxPos = pInOutActualGameStateData[boxPosIDPlus1X];
	int8_t tileTypeNewPlayerPos = pInOutActualGameStateData[boxPosIDPlus2X];

	if (tileTypeOldBoxPos == ConstGameBoard_Box)
	{
		pInOutActualGameStateData[boxPosID] = ConstGameBoard_Empty;
	}
	else if (tileTypeOldBoxPos == ConstGameBoard_DestinationWithBox)
	{
		pInOutActualGameStateData[boxPosID] = ConstGameBoard_Destination;
	}

	if (tileTypeNewBoxPos == ConstGameBoard_Player)
	{
		pInOutActualGameStateData[boxPosIDPlus1X] = ConstGameBoard_Box;
	}
	else if (tileTypeNewBoxPos == ConstGameBoard_DestinationWithPlayer)
	{
		pInOutActualGameStateData[boxPosIDPlus1X] = ConstGameBoard_DestinationWithBox;
	}

	if (tileTypeNewPlayerPos == ConstGameBoard_Empty)
	{
		pInOutActualGameStateData[boxPosIDPlus2X] = ConstGameBoard_Player;
	}
	else if (tileTypeNewPlayerPos == ConstGameBoard_Destination)
	{
		pInOutActualGameStateData[boxPosIDPlus2X] = ConstGameBoard_DestinationWithPlayer;
	}

	return true;
}

bool CSimpleSokobanSolver::Make_UpwardPullMove(int8_t *pInOutActualGameStateData, int32_t boxID)
{
	if (pBoxCharacteristicsArray[boxID].UpwardPullPossible == false)
	{
		return false;
	}
	if (pBoxCharacteristicsArray[boxID].UpperSideBlockedForPlayer == true)
	{
		return false;
	}

	int32_t boxPosID = pBoxCharacteristicsArray[boxID].PosID;
	int32_t boxPosX = pBoxCharacteristicsArray[boxID].PosX;
	int32_t boxPosY = pBoxCharacteristicsArray[boxID].PosY;

	if (Verify_Path(PlayerPosX, PlayerPosY, boxPosX, boxPosY - 1, &Puzzle, /*FeatureMapID:*/ 0, NumOfPathFindingSearchStepsMax) == false)
	{
		pBoxCharacteristicsArray[boxID].UpperSideBlockedForPlayer = true;
		return false;
	}

	if (pInOutActualGameStateData[PlayerPosID] == ConstGameBoard_Player)
	{
		pInOutActualGameStateData[PlayerPosID] = ConstGameBoard_Empty;
	}
	else if (pInOutActualGameStateData[PlayerPosID] == ConstGameBoard_DestinationWithPlayer)
	{
		pInOutActualGameStateData[PlayerPosID] = ConstGameBoard_Destination;
	}

	int32_t boxPosIDMinus1Y = boxPosID - PuzzleSizeX;

	if (pInOutActualGameStateData[boxPosIDMinus1Y] == ConstGameBoard_Empty)
	{
		pInOutActualGameStateData[boxPosIDMinus1Y] = ConstGameBoard_Player;
	}
	else if (pInOutActualGameStateData[boxPosIDMinus1Y] == ConstGameBoard_Destination)
	{
		pInOutActualGameStateData[boxPosIDMinus1Y] = ConstGameBoard_DestinationWithPlayer;
	}

	int32_t boxPosIDMinus2Y = boxPosID - PuzzleSize2X;

	int8_t tileTypeOldBoxPos = pInOutActualGameStateData[boxPosID];
	int8_t tileTypeNewBoxPos = pInOutActualGameStateData[boxPosIDMinus1Y];
	int8_t tileTypeNewPlayerPos = pInOutActualGameStateData[boxPosIDMinus2Y];

	if (tileTypeOldBoxPos == ConstGameBoard_Box)
	{
		pInOutActualGameStateData[boxPosID] = ConstGameBoard_Empty;
	}
	else if (tileTypeOldBoxPos == ConstGameBoard_DestinationWithBox)
	{
		pInOutActualGameStateData[boxPosID] = ConstGameBoard_Destination;
	}

	if (tileTypeNewBoxPos == ConstGameBoard_Player)
	{
		pInOutActualGameStateData[boxPosIDMinus1Y] = ConstGameBoard_Box;
	}
	else if (tileTypeNewBoxPos == ConstGameBoard_DestinationWithPlayer)
	{
		pInOutActualGameStateData[boxPosIDMinus1Y] = ConstGameBoard_DestinationWithBox;
	}

	if (tileTypeNewPlayerPos == ConstGameBoard_Empty)
	{
		pInOutActualGameStateData[boxPosIDMinus2Y] = ConstGameBoard_Player;
	}
	else if (tileTypeNewPlayerPos == ConstGameBoard_Destination)
	{
		pInOutActualGameStateData[boxPosIDMinus2Y] = ConstGameBoard_DestinationWithPlayer;
	}

	return true;
}

bool CSimpleSokobanSolver::Make_DownwardPullMove(int8_t *pInOutActualGameStateData, int32_t boxID)
{
	if (pBoxCharacteristicsArray[boxID].DownwardPullPossible == false)
	{
		return false;
	}
	if (pBoxCharacteristicsArray[boxID].LowerSideBlockedForPlayer == true)
	{
		return false;
	}

	int32_t boxPosID = pBoxCharacteristicsArray[boxID].PosID;
	int32_t boxPosX = pBoxCharacteristicsArray[boxID].PosX;
	int32_t boxPosY = pBoxCharacteristicsArray[boxID].PosY;

	if (Verify_Path(PlayerPosX, PlayerPosY, boxPosX, boxPosY + 1, &Puzzle, /*FeatureMapID:*/ 0, NumOfPathFindingSearchStepsMax) == false)
	{
		pBoxCharacteristicsArray[boxID].LowerSideBlockedForPlayer = true;
		return false;
	}

	if (pInOutActualGameStateData[PlayerPosID] == ConstGameBoard_Player)
	{
		pInOutActualGameStateData[PlayerPosID] = ConstGameBoard_Empty;
	}
	else if (pInOutActualGameStateData[PlayerPosID] == ConstGameBoard_DestinationWithPlayer)
	{
		pInOutActualGameStateData[PlayerPosID] = ConstGameBoard_Destination;
	}

	int32_t boxPosIDPlus1Y = boxPosID + PuzzleSizeX;

	if (pInOutActualGameStateData[boxPosIDPlus1Y] == ConstGameBoard_Empty)
	{
		pInOutActualGameStateData[boxPosIDPlus1Y] = ConstGameBoard_Player;
	}
	else if (pInOutActualGameStateData[boxPosIDPlus1Y] == ConstGameBoard_Destination)
	{
		pInOutActualGameStateData[boxPosIDPlus1Y] = ConstGameBoard_DestinationWithPlayer;
	}

	int32_t boxPosIDPlus2Y = boxPosID + PuzzleSize2X;

	int8_t tileTypeOldBoxPos = pInOutActualGameStateData[boxPosID];
	int8_t tileTypeNewBoxPos = pInOutActualGameStateData[boxPosIDPlus1Y];
	int8_t tileTypeNewPlayerPos = pInOutActualGameStateData[boxPosIDPlus2Y];

	if (tileTypeOldBoxPos == ConstGameBoard_Box)
	{
		pInOutActualGameStateData[boxPosID] = ConstGameBoard_Empty;
	}
	else if (tileTypeOldBoxPos == ConstGameBoard_DestinationWithBox)
	{
		pInOutActualGameStateData[boxPosID] = ConstGameBoard_Destination;
	}

	if (tileTypeNewBoxPos == ConstGameBoard_Player)
	{
		pInOutActualGameStateData[boxPosIDPlus1Y] = ConstGameBoard_Box;
	}
	else if (tileTypeNewBoxPos == ConstGameBoard_DestinationWithPlayer)
	{
		pInOutActualGameStateData[boxPosIDPlus1Y] = ConstGameBoard_DestinationWithBox;
	}

	if (tileTypeNewPlayerPos == ConstGameBoard_Empty)
	{
		pInOutActualGameStateData[boxPosIDPlus2Y] = ConstGameBoard_Player;
	}
	else if (tileTypeNewPlayerPos == ConstGameBoard_Destination)
	{
		pInOutActualGameStateData[boxPosIDPlus2Y] = ConstGameBoard_DestinationWithPlayer;
	}
	

	return true;
}

void CSimpleSokobanSolver::Get_PlayerPosition(int8_t *pActualGameStateData)
{
	for (int32_t i = 0; i < PuzzleSizeXY; i++)
	{
		int8_t tileType = pActualGameStateData[i];

		if (tileType == ConstGameBoard_Player || tileType == ConstGameBoard_DestinationWithPlayer)
		{
			PlayerPosX = i % PuzzleSizeX;
			PlayerPosY = i / PuzzleSizeX;
			PlayerPosID = i;

			return;
		}
	}
}

bool CSimpleSokobanSolver::Check_If_Puzzle_Is_Solved(CGameStateValues *pGameState)
{
	/* �berpr�fen, ob alle Kisten an den korrekten Anfangspositionen stehen: */
	if (Check_PossibleBoxPlacementIdentity(pGameState, &pInitialPuzzle->GameState) == false)
	{
		return false;
	}

	/* �berpr�fen, ob der Spieler seine Ausgangsposition erreichen kann: */
	if (Verify_Path(PlayerPosX, PlayerPosY, InitialPlayerPosX, InitialPlayerPosY, &Puzzle, /*FeatureMapID*/ 0, NumOfPathFindingSearchStepsMax) == false)
	{
		return false;
	}

	ActualSearchDepth++;
	//pSavedGameStateArray[ActualSearchDepth].Clone_GameStateValues(&TempGameState);

	// Alle Kisten stehen auf ihren Ausgangspositionen:
	MaxDistBasedEvaluationValue = 0;

	ActualGameState.Clone_GameStateValues(&pInitialPuzzle->GameState);
	PuzzleSolved = true;
	PlayerPosX = InitialPlayerPosX;
	PlayerPosY = InitialPlayerPosY;

	return true;
}

bool CSimpleSokobanSolver::Check_PossibleBoxPlacementIdentity(CGameStateValues *pGameState1, CGameStateValues *pGameState2)
{
	int8_t *pValueArray1 = pGameState1->pValueArray;
	int8_t *pValueArray2 = pGameState2->pValueArray;

	for (int32_t i = 0; i < PuzzleSizeXY; i++)
	{
		int8_t tileType1 = pValueArray1[i];

		if (tileType1 == ConstGameBoard_Box)
		{
			int8_t tileType2 = pValueArray2[i];

			if (tileType2 != ConstGameBoard_Box)
			{
				return false;
			}
		}
		else if (tileType1 == ConstGameBoard_DestinationWithBox)
		{
			int8_t tileType2 = pValueArray2[i];

			if (tileType2 != ConstGameBoard_DestinationWithBox)
			{
				return false;
			}
		}
	}
	return true;
}

bool CSimpleSokobanSolver::Check_PlayerDeadLock(int8_t *pActualGameStateData)
{
	Get_PlayerPosition(pActualGameStateData);

	int32_t adjacentTileValue = pActualGameStateData[PlayerPosID - 1];

	if (adjacentTileValue == ConstGameBoard_Empty || adjacentTileValue == ConstGameBoard_Destination)
	{
		return false;
	}

	adjacentTileValue = pActualGameStateData[PlayerPosID + 1];

	if (adjacentTileValue == ConstGameBoard_Empty || adjacentTileValue == ConstGameBoard_Destination)
	{
		return false;
	}

	adjacentTileValue = pActualGameStateData[PlayerPosID - PuzzleSizeX];

	if (adjacentTileValue == ConstGameBoard_Empty || adjacentTileValue == ConstGameBoard_Destination)
	{
		return false;
	}

	adjacentTileValue = pActualGameStateData[PlayerPosID + PuzzleSizeX];

	if (adjacentTileValue == ConstGameBoard_Empty || adjacentTileValue == ConstGameBoard_Destination)
	{
		return false;
	}

	return true;

}

void CSimpleSokobanSolver::Update_PosBasedBoxCharacteristicsOnly(int8_t *pActualGameStateData)
{
	int32_t boxCounter = 0;

	for (int32_t iy = 0; iy < PuzzleSizeY; iy++)
	{
		int32_t iiy = iy * PuzzleSizeX;

		for (int32_t ix = 0; ix < PuzzleSizeX; ix++)
		{
			int32_t id = ix + iiy;

			int8_t tileType = pActualGameStateData[id];

			if (tileType == ConstGameBoard_Box || tileType == ConstGameBoard_DestinationWithBox)
			{
				pBoxCharacteristicsArray[boxCounter].Reset();

				pBoxCharacteristicsArray[boxCounter].PosID = id;
				pBoxCharacteristicsArray[boxCounter].PosX = ix;
				pBoxCharacteristicsArray[boxCounter].PosY = iy;

				boxCounter++;

			} // end of if (tileType == ConstGameBoard_Box || tileType == ConstGameBoard_DestinationWithBox)
		} // end of for (int32_t ix = 0; ix < PuzzleSizeX; ix++)
	} // end of for (int32_t iy = 0; iy < PuzzleSizeY; iy++)

	for (int32_t i = 0; i < NumOfBoxes; i++) // alle Anfangspositionen durchgehen
	{
		int8_t tileType = pActualGameStateData[pInitialPuzzle->pInitialBoxPosIDArray[i]];

		for (int32_t j = 0; j < NumOfBoxes; j++)
		{
			int32_t distX = abs(pInitialPuzzle->pInitialBoxPosXArray[i] - pBoxCharacteristicsArray[j].PosX);
			int32_t distY = abs(pInitialPuzzle->pInitialBoxPosYArray[i] - pBoxCharacteristicsArray[j].PosY);
			int32_t manhattenDist = distX + distY;

			// Box befindet sich berteits auf einer initialen Box-Position (die Schwierigkeit ist, das wir nicht sicher sein k�nnen, ob es sich um die richtige Boc handelt, oder ob sich die Box zu einem falschen Zeitpunkt auf der betreffenden Position befindet!)
			if (manhattenDist == 0)
			{
				pBoxCharacteristicsArray[j].MinDistanceToInitialPos = 0;
				continue;
			}

			// Die Entfernung zu einer initialen Box-Position spielt nur dann eine Rolle, wenn sich dort keine andere Box befindet:
			if (tileType != ConstGameBoard_Box && tileType != ConstGameBoard_DestinationWithBox)
			{
				if (pBoxCharacteristicsArray[j].MinDistanceToInitialPos > manhattenDist)
				{
					pBoxCharacteristicsArray[j].MinDistanceToInitialPos = manhattenDist;
				}
			}
		}
	}
}





void CSimpleSokobanSolver::Update_BoxCharacteristics(int8_t *pActualGameStateData)
{
	int32_t boxCounter = 0;

	for (int32_t iy = 0; iy < PuzzleSizeY; iy++)
	{
		int32_t iiy = iy * PuzzleSizeX;

		for (int32_t ix = 0; ix < PuzzleSizeX; ix++)
		{
			int32_t id = ix + iiy;
			
			int8_t tileType = pActualGameStateData[id];

			if (tileType == ConstGameBoard_Box || tileType == ConstGameBoard_DestinationWithBox)
			{
				pBoxCharacteristicsArray[boxCounter].Reset();

				pBoxCharacteristicsArray[boxCounter].PosID = id;
				pBoxCharacteristicsArray[boxCounter].PosX = ix;
				pBoxCharacteristicsArray[boxCounter].PosY = iy;

				int32_t idMinus1X = id - 1;
				int32_t idPlus1X = id + 1;
				int32_t idMinus1Y = id - PuzzleSizeX;
				int32_t idPlus1Y = id + PuzzleSizeX;
				int32_t idMinus2X = id - 2;
				int32_t idPlus2X = id + 2;
				int32_t idMinus2Y = id - PuzzleSize2X;
				int32_t idPlus2Y = id + PuzzleSize2X;

				int8_t tileTypeMinus1X = pActualGameStateData[idMinus1X];
				int8_t tileTypePlus1X = pActualGameStateData[idPlus1X];
				int8_t tileTypeMinus1Y = pActualGameStateData[idMinus1Y];
				int8_t tileTypePlus1Y = pActualGameStateData[idPlus1Y];

				if (tileTypeMinus1X == ConstGameBoard_Player || tileTypeMinus1X == ConstGameBoard_DestinationWithPlayer ||
					tileTypeMinus1X == ConstGameBoard_Empty || tileTypeMinus1X == ConstGameBoard_Destination)
				{
					if (tileTypePlus1X == ConstGameBoard_Empty || tileTypePlus1X == ConstGameBoard_Destination)
					{
						pBoxCharacteristicsArray[boxCounter].RightPushPossible = true;
					}

					int8_t tileTypeMinus2X = pActualGameStateData[idMinus2X];

					if (tileTypeMinus2X == ConstGameBoard_Empty || tileTypeMinus2X == ConstGameBoard_Destination)
					{
						pBoxCharacteristicsArray[boxCounter].LeftPullPossible = true;
					}
				}

				if (tileTypePlus1X == ConstGameBoard_Player || tileTypePlus1X == ConstGameBoard_DestinationWithPlayer ||
					tileTypePlus1X == ConstGameBoard_Empty || tileTypePlus1X == ConstGameBoard_Destination)
				{
					if (tileTypeMinus1X == ConstGameBoard_Empty || tileTypeMinus1X == ConstGameBoard_Destination)
					{
						pBoxCharacteristicsArray[boxCounter].LeftPushPossible = true;
					}

					int8_t tileTypePlus2X = pActualGameStateData[idPlus2X];

					if (tileTypePlus2X == ConstGameBoard_Empty || tileTypePlus2X == ConstGameBoard_Destination)
					{
						pBoxCharacteristicsArray[boxCounter].RightPullPossible = true;
					}
				}

				/////

				if (tileTypeMinus1Y == ConstGameBoard_Player || tileTypeMinus1Y == ConstGameBoard_DestinationWithPlayer ||
					tileTypeMinus1Y == ConstGameBoard_Empty || tileTypeMinus1Y == ConstGameBoard_Destination)
				{
					if (tileTypePlus1Y == ConstGameBoard_Empty || tileTypePlus1Y == ConstGameBoard_Destination)
					{
						pBoxCharacteristicsArray[boxCounter].DownwardPushPossible = true;
					}

					int8_t tileTypeMinus2Y = pActualGameStateData[idMinus2Y];

					if (tileTypeMinus2Y == ConstGameBoard_Empty || tileTypeMinus2Y == ConstGameBoard_Destination)
					{
						pBoxCharacteristicsArray[boxCounter].UpwardPullPossible = true;
					}
				}

				if (tileTypePlus1Y == ConstGameBoard_Player || tileTypePlus1Y == ConstGameBoard_DestinationWithPlayer ||
					tileTypePlus1Y == ConstGameBoard_Empty || tileTypePlus1Y == ConstGameBoard_Destination)
				{
					if (tileTypeMinus1Y == ConstGameBoard_Empty || tileTypeMinus1Y == ConstGameBoard_Destination)
					{
						pBoxCharacteristicsArray[boxCounter].UpwardPushPossible = true;
					}

					int8_t tileTypePlus2Y = pActualGameStateData[idPlus2Y];

					if (tileTypePlus2Y == ConstGameBoard_Empty || tileTypePlus2Y == ConstGameBoard_Destination)
					{
						pBoxCharacteristicsArray[boxCounter].DownwardPullPossible = true;
					}
				}

				boxCounter++;

			} // end of if (tileType == ConstGameBoard_Box || tileType == ConstGameBoard_DestinationWithBox)
		} // end of for (int32_t ix = 0; ix < PuzzleSizeX; ix++)
	} // end of for (int32_t iy = 0; iy < PuzzleSizeY; iy++)

	for (int32_t i = 0; i < NumOfBoxes; i++)
	{
		int8_t tileType = pActualGameStateData[pInitialPuzzle->pInitialBoxPosIDArray[i]];

		for (int32_t j = 0; j < NumOfBoxes; j++)
		{
			int32_t distX = abs(pInitialPuzzle->pInitialBoxPosXArray[i] - pBoxCharacteristicsArray[j].PosX);
			int32_t distY = abs(pInitialPuzzle->pInitialBoxPosYArray[i] - pBoxCharacteristicsArray[j].PosY);
			int32_t manhattenDist = distX + distY;

			// Box befindet sich berteits auf einer initialen Box-Position (die Schwierigkeit ist, das wir nicht sicher sein k�nnen, ob es sich um die richtige Boc handelt, oder ob sich die Box zu einem falschen Zeitpunkt auf der betreffenden Position befindet!)
			if (manhattenDist == 0)
			{
				pBoxCharacteristicsArray[j].MinDistanceToInitialPos = 0;
				continue;
			}
			
			// Die Entfernung zu einer initialen Box-Position spielt nur dann eine Rolle, wenn sich dort keine andere Box befindet:
			if (tileType != ConstGameBoard_Box && tileType != ConstGameBoard_DestinationWithBox)
			{
				if (pBoxCharacteristicsArray[j].MinDistanceToInitialPos > manhattenDist)
				{
					pBoxCharacteristicsArray[j].MinDistanceToInitialPos = manhattenDist;
				}
			}			
		}
	}
}



void CSimpleSokobanSolver::Set_Puzzles(CSokobanPuzzle *pInitial_Puzzle, CSokobanPuzzle *pPuzzle_Solved)
{
	delete[] pBoxCharacteristicsArray;
	pBoxCharacteristicsArray = nullptr;

	MaxDistBasedEvaluationValue = -1000000;
	LowestDistBasedEvaluationValue = -1000000;
	LastEvaluationValue = -1000000;

	PuzzleSolved = false;
	
	pInitialPuzzle = pInitial_Puzzle;
	pSolvedPuzzle = pPuzzle_Solved;

	Puzzle.Clone_Puzzle(pSolvedPuzzle);
	
	

	PuzzleSizeX = pSolvedPuzzle->SizeX;
	PuzzleSize2X = 2 * PuzzleSizeX;
	PuzzleSizeY = pSolvedPuzzle->SizeY;
	PuzzleSizeXY = PuzzleSizeX * PuzzleSizeY;

	NumOfBoxes = pSolvedPuzzle->NumOfBoxesInsideGamesWorld;

	pBoxCharacteristicsArray = new (std::nothrow) CSokobanBoxCharacteristics[NumOfBoxes];
	pTempBoxCharacteristicsArray = new (std::nothrow) CSokobanBoxCharacteristics[NumOfBoxes];

	ActualSearchDepth = 0;

	for (int32_t i = 0; i < NumOfSavedGameStatesMax; i++)
	{
		pSavedGameStateArray[i].Initialize(PuzzleSizeX, PuzzleSizeY);
		pSavedGameStateArray[i].Clone_GameStateValues(pSolvedPuzzle->GameState.pValueArray);
		pNumOfPossibleSubsequentMovesArray[i] = 0;
	}

	TestVisitedGameState.Initialize(PuzzleSizeX, PuzzleSizeY);

	ActualGameState.Initialize(PuzzleSizeX, PuzzleSizeY);
	ActualGameState.Clone_GameStateValues(pSolvedPuzzle->GameState.pValueArray);

	pSavedGameStateArray[0].Clone_GameStateValues(&ActualGameState);

	Get_PlayerPosition(ActualGameState.pValueArray);

	Update_BoxCharacteristics(ActualGameState.pValueArray);

	MaxDistBasedEvaluationValue = Calc_DistanceBasedEvaluationValue();
	LastEvaluationValue = LowestDistBasedEvaluationValue;

	NumOfDiscardedGameStatesInUse = 0;

	for (int32_t i = 0; i < NumOfDiscardedGameStatesMax; i++)
	{
		pDiscardedGameStateCharacteristicsArray[i].Initialize(NumOfBoxes);
	}

	DiscardedGameStateCharacteristics.Initialize(NumOfBoxes);

	NumOfVisitedGameStatesInUse = 0;

	for (int32_t i = 0; i < NumOfVisitedGameStatesMax; i++)
	{
		pVisitedGameStateCharacteristicsArray[i].Initialize(NumOfBoxes);
	}

	TestVisitedGameStateCharacteristics.Initialize(NumOfBoxes);

	int8_t *pGameStateData = pInitialPuzzle->GameState.pValueArray;

	for (int32_t i = 0; i < PuzzleSizeXY; i++)
	{
		int8_t tileValue = pGameStateData[i];

		if(tileValue == ConstGameBoard_Player || tileValue == ConstGameBoard_DestinationWithPlayer)
		{
			InitialPlayerPosX = i % PuzzleSizeX;
			InitialPlayerPosY = i / PuzzleSizeX;
			break;
		}
	}

	
}
bool CSimpleSokobanSolver::Check_If_BoxIsPermanentlyBlockedForPullMove(int32_t boxPosID, int8_t *pActualGameStateData)
{
	if (pInitialPuzzle->GameState.pValueArray[boxPosID] == ConstGameBoard_Box)
	{
		return false;
	}

	bool leftBlocked = false;
	int8_t tileValue1 = pActualGameStateData[boxPosID - 1];

	if (tileValue1 == ConstGameBoard_Wall)
	{
		leftBlocked = true;
	}
	else
	{
		int8_t tileValue2 = pActualGameStateData[boxPosID - 2];

		if (tileValue2 == ConstGameBoard_Wall)
		{
			leftBlocked = true;
		}
	}

	bool rightBlocked = false;
	tileValue1 = pActualGameStateData[boxPosID + 1];

	if (tileValue1 == ConstGameBoard_Wall)
	{
		rightBlocked = true;
	}
	else
	{
		int8_t tileValue2 = pActualGameStateData[boxPosID + 2];

		if (tileValue2 == ConstGameBoard_Wall)
		{
			rightBlocked = true;
		}
	}

	bool upwardBlocked = false;
	tileValue1 = pActualGameStateData[boxPosID - PuzzleSizeX];

	if (tileValue1 == ConstGameBoard_Wall)
	{
		upwardBlocked = true;
	}
	else
	{
		int8_t tileValue2 = pActualGameStateData[boxPosID - PuzzleSize2X];

		if (tileValue2 == ConstGameBoard_Wall)
		{
			upwardBlocked = true;
		}
	}

	bool downwardBlocked = false;
	tileValue1 = pActualGameStateData[boxPosID + PuzzleSizeX];

	if (tileValue1 == ConstGameBoard_Wall)
	{
		downwardBlocked = true;
	}
	else
	{
		int8_t tileValue2 = pActualGameStateData[boxPosID + PuzzleSize2X];

		if (tileValue2 == ConstGameBoard_Wall)
		{
			downwardBlocked = true;
		}
	}

	if (leftBlocked == false)
	{
		return false;
	}

	if (rightBlocked == false)
	{
		return false;
	}

	if (upwardBlocked == false)
	{
		return false;
	}

	if (downwardBlocked == false)
	{
		return false;
	}

	return true;

}

int32_t CSimpleSokobanSolver::Calc_DistanceBasedEvaluationValue(void)
{
	int32_t distBasedEvaluationValue = 0;

	for (int32_t i = 0; i < NumOfBoxes; i++)
	{
		distBasedEvaluationValue -= pBoxCharacteristicsArray[i].MinDistanceToInitialPos;
	}

	/* Wenn alle Boxen auf ihren Ausgangspositionen stehen, �berpr�fen, ob der Spieler seine Ausgangsposition ebenfalls erreichen kann: */
	if (distBasedEvaluationValue == 0)
	{
		/* Wenn der Spieler seine Anfangsposition nicht erreichen kann, f�hrt das zu der schlechtest m�glichen Bewertung (LowestDistBasedEvaluationValue): */

		if (Verify_Path(PlayerPosX, PlayerPosY, InitialPlayerPosX, InitialPlayerPosY, &Puzzle, /*FeatureMapID:*/ 0, NumOfPathFindingSearchStepsMax) == false)
		{
			distBasedEvaluationValue = LowestDistBasedEvaluationValue;
		}
	}

	return distBasedEvaluationValue;
}


