// Schutz vor Mehrfachdeklarationen:
#ifndef _GameStateHandler_H_
#define _GameStateHandler_H_

#include <iostream>
#include <fstream>
#include "LogFile.h"
#include "RandomNumbers.h"
#include "MemoryManagement.h"

#ifndef max
#define max(a,b)    ( ((a) > (b)) ? (a) : (b) )
#endif

#ifndef min
#define min(a,b)    ( ((a) < (b)) ? (a) : (b) )
#endif

class C1DimMoveDesc
{
public:

	int32_t id_Old = -1;
	int32_t id_New = -1;
	                       
	int32_t iEvaluation = -2000000;
	float fEvaluation = -2000000.0f;

	C1DimMoveDesc();
	~C1DimMoveDesc();

	void Clone_Data(C1DimMoveDesc *pOriginalObject);

	void Reset(void);
};

class C2DimMoveDesc
{
public:

	int32_t ix_Old = -1;
	int32_t iy_Old = -1;

	int32_t ix_New = -1;
	int32_t iy_New = -1;

	int32_t iEvaluation = -2000000;
	float fEvaluation = -2000000.0f;

	C2DimMoveDesc();
	~C2DimMoveDesc();

	void Clone_Data(C2DimMoveDesc *pOriginalObject);

	void Reset(void);
};

class C3DimMoveDesc
{
public:

	int32_t ix_Old = -1;
	int32_t iy_Old = -1;
	int32_t iz_Old = -1;

	int32_t ix_New = -1;
	int32_t iy_New = -1;
	int32_t iz_New = -1;

	int32_t iEvaluation = -2000000;
	float fEvaluation = -2000000.0f;

	C3DimMoveDesc();
	~C3DimMoveDesc();

	void Clone_Data(C3DimMoveDesc *pOriginalObject);

	void Reset(void);
};

void Update_ListOfBestMoves_IntegerEvaluation(C1DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C1DimMoveDesc* pInMoveDesc);
void Update_ListOfBestMoves_FloatEvaluation(C1DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C1DimMoveDesc* pInMoveDesc);

void Update_ListOfBestMoves_IntegerEvaluation(C2DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C2DimMoveDesc* pInMoveDesc);
void Update_ListOfBestMoves_FloatEvaluation(C2DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C2DimMoveDesc* pInMoveDesc);

void Update_ListOfBestMoves_IntegerEvaluation(C3DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C3DimMoveDesc* pInMoveDesc);
void Update_ListOfBestMoves_FloatEvaluation(C3DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C3DimMoveDesc* pInMoveDesc);


void Generate_ListOfBestMoves_IntegerEvaluation(C1DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C1DimMoveDesc* pInMoveDescArray, int32_t numOfMoves);
void Generate_ListOfBestMoves_FloatEvaluation(C1DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C1DimMoveDesc* pInMoveDescArray, int32_t numOfMoves);

void Generate_ListOfBestMoves_IntegerEvaluation(C2DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C2DimMoveDesc* pInMoveDescArray, int32_t numOfMoves);
void Generate_ListOfBestMoves_FloatEvaluation(C2DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C2DimMoveDesc* pInMoveDescArray, int32_t numOfMoves);

void Generate_ListOfBestMoves_IntegerEvaluation(C3DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C3DimMoveDesc* pInMoveDescArray, int32_t numOfMoves);
void Generate_ListOfBestMoves_FloatEvaluation(C3DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C3DimMoveDesc* pInMoveDescArray, int32_t numOfMoves);


class CGameStateValues
{
public:

	CGameStateValues *pUsedGameStateArray = nullptr;

	bool LeafNode = false;
	int32_t PlayerID = -1;
	int32_t IDofGameState = -1;
	int32_t IDofPrevGameState = -1;
	// Ebene innerhalb eines Game-Trees:
	int32_t DepthValue = 0;
	bool Minimizer = false;
	int32_t iEvaluation = -2000000;
	int32_t iEvaluationChange = 0;
	float fEvaluation = -2000000.0f;
	float fEvaluationChange = 0.0f;
	bool FurtherExploration = true;
	
	int32_t SizeX = 0;
	int32_t SizeY = 0;
	int32_t SizeZ = 0;
	int32_t SizeXY = 0;
	int32_t Size = 0;
	int8_t *pValueArray = nullptr;

	CGameStateValues();
	CGameStateValues(int32_t size);
	CGameStateValues(int32_t sizeX, int32_t sizeY);
	CGameStateValues(int32_t sizeX, int32_t sizeY, int32_t sizeZ);

	~CGameStateValues();

	// Kopierkonstruktor l�schen:
	CGameStateValues(const CGameStateValues  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CGameStateValues & operator=(const CGameStateValues  &originalObject) = delete;

	void Initialize(int32_t size);
	void Initialize(int32_t sizeX, int32_t sizeY);
	void Initialize(int32_t sizeX, int32_t sizeY, int32_t sizeZ);

	void Connect_With_GameStateArray(CGameStateValues *pGameStateArray);

	bool Check_Identity(CGameStateValues *pOtherObject);

	void Use_As_Minimizer(void);
	void Use_As_Maximizer(void);
	void Reset_MinimaxEvaluation(void);
	
	bool Check_Usage(void);

	void Reset_Evaluation(void);

	void Reset(void);

	void Clone_Data(CGameStateValues *pOriginalObject);

	void Clone_GameStateValues(CGameStateValues *pOriginalObject);
	void Clone_GameStateValues(int8_t *pOriginalValueArray);

	int32_t Get_ID_From_CartesianCoord(int32_t ix, int32_t iy);
	int32_t Get_ID_From_CartesianCoord(int32_t ix, int32_t iy, int32_t iz);

	void Get_ID_From_CartesianCoord(int32_t *pOutID, int32_t ix, int32_t iy);
	void Get_ID_From_CartesianCoord(int32_t *pOutID, int32_t ix, int32_t iy, int32_t iz);

	void Get_CartesianCoord_From_ID(int32_t *pOut_ix, int32_t *pOut_iy, int32_t id);
	void Get_CartesianCoord_From_ID(int32_t *pOut_ix, int32_t *pOut_iy, int32_t *pOut_iz, int32_t id);

	void Set_Value(int8_t value, int32_t id);
	void Set_Value(int8_t value, int32_t ix, int32_t iy);
	void Set_Value(int8_t value, int32_t ix, int32_t iy, int32_t iz);

	int8_t Get_Value(int32_t id);
	int8_t Get_Value(int32_t ix, int32_t iy);
	int8_t Get_Value(int32_t ix, int32_t iy, int32_t iz);

	void Use_As_Root_GameState(bool leafNodeToo);

	void Set_TreeInfo_If_Desired(int32_t depth, int32_t IDPrevGameState, bool leafNode);

	void Backpropagate_MinimaxIntegerEvaluation(void);
	void Backpropagate_MinimaxFloatEvaluation(void);

	void Backpropagate_MinimaxIntegerEvaluation(int32_t intendedDepth);
	void Backpropagate_MinimaxFloatEvaluation(int32_t intendedDepth);

	void Backpropagate_IntegerEvaluationChange(void);
	void Backpropagate_FloatEvaluationChange(void);

	void Backpropagate_IntegerEvaluationChange(int32_t intendedDepth);
	void Backpropagate_FloatEvaluationChange(int32_t intendedDepth);

	void Set_EvaluationValue(float value);
	void Set_EvaluationValue(int32_t value);

	void Update_Evaluation(float valueOfChange);
	void Update_Evaluation(int32_t valueOfChange);
	
	
	// true if this game state is a successor of *pPrevGameState:
	bool Check_If_Possible_Successor(CGameStateValues *pPrevGameState);

	int32_t Get_PrevGameState(CGameStateValues **ppOutPrevGameState);
	int32_t Get_PrevGameStateID(void);

	int32_t Get_RootID(void);
	int32_t Get_Root_And_RootID(CGameStateValues **ppOutPrevGameState);
};






class CGameStateRingBuffer
{
public:

	int32_t Size = 0;
	CGameStateValues *pGameStateArray = nullptr;

	int32_t PreviousBufferElement = 0;
	int32_t ActualBufferElement = 0;

	CGameStateRingBuffer();
	~CGameStateRingBuffer();

	// Kopierkonstruktor l�schen:
	CGameStateRingBuffer(const CGameStateRingBuffer  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CGameStateRingBuffer & operator=(const CGameStateRingBuffer  &originalObject) = delete;

	void Initialize(int32_t bufferSize, int32_t gameStateSize);
	void Initialize(int32_t bufferSize, int32_t gameStateSizeX, int32_t gameStateSizeY);
	void Initialize(int32_t bufferSize, int32_t gameStateSizeX, int32_t gameStateSizeY, int32_t gameStateSizeZ);

	void Reset_ActualBufferElement(void);
	void Set_ActualBufferElement(int32_t value);

	void Increase_ActualBufferElement(void);
	void Decrease_ActualBufferElement(void);
	
	int32_t Get_ActualBufferElementID(void);
	int32_t Get_PreviousBufferElementID(void);

	int32_t Get_ActualBufferElement(CGameStateValues **ppOutGameStateObject);
	int32_t Get_PreviousBufferElement(CGameStateValues **ppOutGameStateObject);

	int32_t Get_ActualBufferElement(int8_t **ppOutGameState);
	int32_t Get_PreviousBufferElement(int8_t **ppOutGameState);

	void Set_ActualBufferElementData(CGameStateValues *pGameStateObject);
	void Set_PreviousBufferElementData(CGameStateValues *pGameStateObject);

	void Set_ActualBufferElementData(int8_t *pGameState);
	void Set_PreviousBufferElementData(int8_t *pGameState);
	
	
};

class CSimpleGameStatePool
{
public:

	int32_t Size = 0;
	CGameStateValues *pGameStateArray = nullptr;

	int32_t NumGameStateObjectsUsed = 0;

	CSimpleMemoryManager SimpleMemoryManager;
	
	CSimpleGameStatePool();
	~CSimpleGameStatePool();

	// Kopierkonstruktor l�schen:
	CSimpleGameStatePool(const CSimpleGameStatePool  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CSimpleGameStatePool & operator=(const CSimpleGameStatePool  &originalObject) = delete;

	void Initialize(int32_t poolSize, int32_t gameStateSize);
	void Initialize(int32_t poolSize, int32_t gameStateSizeX, int32_t gameStateSizeY);
	void Initialize(int32_t poolSize, int32_t gameStateSizeX, int32_t gameStateSizeY, int32_t gameStateSizeZ);

	bool Get_UnusedGameStateObject(int32_t* pOutBelongingID);
	bool Get_UnusedGameStateObject(CGameStateValues** ppOutGameStateObject, int32_t* pOutBelongingID);

	bool Stop_Using_GameStateObject(int32_t id);
	bool Stop_Using_GameStateObject(CGameStateValues** ppGameStateObject);

	void Stop_Using_AllGameStateObjects(void);
};

class CGameStatePool
{
public:

	int32_t Size = 0;
	CGameStateValues *pGameStateArray = nullptr;

	int32_t NumGameStateObjectsUsed = 0;

	CSimpleMemoryManager SimpleMemoryManager;
	CSimpleLinkedListManager SimpleLinkedListManager;

	CGameStatePool();
	~CGameStatePool();

	// Kopierkonstruktor l�schen:
	CGameStatePool(const CGameStatePool  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CGameStatePool & operator=(const CGameStatePool  &originalObject) = delete;

	void Initialize(int32_t poolSize, int32_t gameStateSize);
	void Initialize(int32_t poolSize, int32_t gameStateSizeX, int32_t gameStateSizeY);
	void Initialize(int32_t poolSize, int32_t gameStateSizeX, int32_t gameStateSizeY, int32_t gameStateSizeZ);

	bool Get_UnusedGameStateObject(int32_t* pBelongingID);
	bool Get_UnusedGameStateObject(CGameStateValues** ppOutGameStateObject, int32_t* pOutBelongingID);
	
	bool Stop_Using_GameStateObject(int32_t id);
	bool Stop_Using_GameStateObject(CGameStateValues** ppGameStateObject);
	
	void Stop_Using_AllGameStateObjects(void);
};

// Gamestate-Pool with Game-Tree-Handling
class CExtendedGameStatePool
{
public:

	int32_t Size = 0;
	CGameStateValues *pGameStateArray = nullptr;

	int32_t NumGameStateObjectsUsed = 0;

	CSimpleMemoryManager SimpleMemoryManager;

	int32_t NumOfDepthLayersMax = 0;
	CSimpleLinkedListManager *pSimpleLinkedListManagerArray = nullptr;

	CExtendedGameStatePool();
	~CExtendedGameStatePool();

	// Kopierkonstruktor l�schen:
	CExtendedGameStatePool(const CExtendedGameStatePool  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CExtendedGameStatePool & operator=(const CExtendedGameStatePool  &originalObject) = delete;

	void Initialize(int32_t numOfDepthLayersMax, int32_t poolSize, int32_t gameStateSize);
	void Initialize(int32_t numOfDepthLayersMax, int32_t poolSize, int32_t gameStateSizeX, int32_t gameStateSizeY);
	void Initialize(int32_t numOfDepthLayersMax, int32_t poolSize, int32_t gameStateSizeX, int32_t gameStateSizeY, int32_t gameStateSizeZ);

	bool Get_UnusedGameStateObject(int32_t depth, int32_t* pOutBelongingID);
	bool Get_UnusedGameStateObject(int32_t depth, CGameStateValues** ppOutGameStateObject, int32_t* pOutBelongingID);

	void Get_Best_GameState_IntegerEvaluation(CGameStateValues** ppOutGameStateObject, int32_t* pOutBelongingID);
	void Get_Best_GameState_FloatEvaluation(CGameStateValues** ppOutGameStateObject, int32_t* pOutBelongingID);

	bool Stop_Using_GameStateObject(int32_t id);
	bool Stop_Using_GameStateObject(CGameStateValues** ppGameStateObject);

	void Stop_Using_AllGameStateObjects(void);

	void Reset_EvaluationValues(void);

	int32_t Get_Random_GameStateID_LastDepthLayerExcluded(int32_t minDepth, int32_t maxDepth, int32_t numAttemptsMax, CRandomNumbersNN *pRandomNumbers);
	int32_t Get_Random_GameStateID(int32_t minDepth, int32_t maxDepth, int32_t numAttemptsMax, CRandomNumbersNN *pRandomNumbers);

	int32_t Get_RootID(CGameStateValues* pGameStateObject);
	int32_t Get_Root_And_RootID(CGameStateValues** ppOutGameStateObject, CGameStateValues* pInGameStateObject);
};

void Backpropagate_MinimaxIntegerEvaluationValues(CExtendedGameStatePool *pGameStatePool);
void Backpropagate_IntegerEvaluationChanges(CExtendedGameStatePool *pGameStatePool);


void Backpropagate_MinimaxFloatEvaluationValues(CExtendedGameStatePool *pGameStatePool);
void Backpropagate_FloatEvaluationChanges(CExtendedGameStatePool *pGameStatePool);


class CSimpleGameTree_DepthLayerInfo
{
public:

	int32_t NumGameStatesMax = 0;
	int32_t NumGameStatesUsed = 0;

	int32_t *pGameStateIDArray = nullptr;

	CSimpleGameTree_DepthLayerInfo();
	~CSimpleGameTree_DepthLayerInfo();

	// Kopierkonstruktor l�schen:
	CSimpleGameTree_DepthLayerInfo(const CSimpleGameTree_DepthLayerInfo  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CSimpleGameTree_DepthLayerInfo & operator=(const CSimpleGameTree_DepthLayerInfo  &originalObject) = delete;

	void Initialize(int32_t numGameStatesMax);
	void Add_GameState(int32_t gameStateID);
	void Reset(void);
};




class CGameStatePool_SimpleGameTree
{
public:

	int32_t Size = 0;
	CGameStateValues *pGameStateArray = nullptr;

	int32_t NumGameStateObjectsUsed = 0;

	CSimpleMemoryManager SimpleMemoryManager;
	CSimpleLinkedListManager SimpleLinkedListManager;

	int32_t NumOfDepthLayersMax = 0;
	CSimpleGameTree_DepthLayerInfo *pDepthLayerInfoArray = nullptr;

	CGameStatePool_SimpleGameTree();
	~CGameStatePool_SimpleGameTree();

	// Kopierkonstruktor l�schen:
	CGameStatePool_SimpleGameTree(const CGameStatePool_SimpleGameTree  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CGameStatePool_SimpleGameTree & operator=(const CGameStatePool_SimpleGameTree  &originalObject) = delete;

	void Initialize(int32_t poolSize, int32_t gameStateSize);
	void Initialize(int32_t poolSize, int32_t gameStateSizeX, int32_t gameStateSizeY);
	void Initialize(int32_t poolSize, int32_t gameStateSizeX, int32_t gameStateSizeY, int32_t gameStateSizeZ);

	void Initialize_DepthLayers(int32_t numOfDepthLayersMax, int32_t numOfGameStatesMaxPerLayer);
	void Initialize_DepthLayers(int32_t numOfDepthLayersMax, int32_t *pNumOfGameStatesMaxPerLayerArray);

	bool Get_UnusedGameStateObject(int32_t depth, int32_t* pBelongingID);
	bool Get_UnusedGameStateObject(int32_t depth, CGameStateValues** ppOutGameStateObject, int32_t* pOutBelongingID);

	void Stop_Using_AllGameStateObjects(void);
};

void Backpropagate_MinimaxIntegerEvaluationValues(CGameStatePool_SimpleGameTree *pGameStatePool);
void Backpropagate_IntegerEvaluationChanges(CGameStatePool_SimpleGameTree *pGameStatePool);


void Backpropagate_MinimaxFloatEvaluationValues(CGameStatePool_SimpleGameTree *pGameStatePool);
void Backpropagate_FloatEvaluationChanges(CGameStatePool_SimpleGameTree *pGameStatePool);



#endif