#pragma warning( disable: 4996)

#include <iostream>
//#include <chrono>
#include <omp.h>
#include <thread>
#include "ConsoleHelperFunctions.h"
#include "LogFile.h"
#include "NeuralCalculationNet.h"
#include "Physics.h"

using namespace std;
using namespace chrono;
using namespace HelperStuff;

#ifndef max
#define max(a,b)    ( ((a) > (b)) ? (a) : (b) )
#endif

#ifndef min
#define min(a,b)    ( ((a) < (b)) ? (a) : (b) )
#endif

#define KEYDOWN(vk_code) ((GetAsyncKeyState(vk_code) & 0x8000) ? 1 : 0)
#define KEYUP(vk_code)   ((GetAsyncKeyState(vk_code) & 0x8000) ? 0 : 1)

extern float g_AirFrictionConstant;

static constexpr int32_t ConstGameBoardSizeX = 140;
static constexpr int32_t ConstGameBoardSizeY = 100;

static constexpr float fConstGameBoardSizeX = 140.0f;
static constexpr float fConstGameBoardSizeY = 100.0f;

static constexpr int32_t ConstGameBoardSizeXMinus1 = 139;
static constexpr int32_t ConstGameBoardSizeYMinus1 = 99;

static constexpr float fConstGameBoardSizeXMinus1 = 139.0f;
static constexpr float fConstGameBoardSizeYMinus1 = 99.0f;

static constexpr float fConstGameBoardSizeXMinus2 = 138.0f;
static constexpr float fConstGameBoardSizeYMinus2 = 98.0f;


static void Reinitialization(CNeuralCalculationNetDesc* pInOutNetDesc, CRandomNumbersNN* pRandomNumbers, void* pParam)
{
	CEvolutionParameter_NeuralCalculationNet *pParameter = static_cast<CEvolutionParameter_NeuralCalculationNet*>(pParam);

	float minRandomPlasticity = pParameter->value1;
	float maxRandomPlasticity = pParameter->value2;

	int32_t numOfNeuralConnections = pInOutNetDesc->NumOfNeuralConnections;

	for (int32_t i = 0; i < numOfNeuralConnections; i++)
	{
		if (pInOutNetDesc->pConnectionStatusArray[i] == 0.0f)
			continue;

		pInOutNetDesc->pPlasticityValueArray[i] = pRandomNumbers->Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
	}

}

static void Mutation(CNeuralCalculationNetDesc* pInOutNetDesc, CRandomNumbersNN* pRandomNumbers, void* pParam)
{
	CEvolutionParameter_NeuralCalculationNet *pParameter = static_cast<CEvolutionParameter_NeuralCalculationNet*>(pParam);

	float minDeltaPlasticity = pParameter->value3;
	float maxDeltaPlasticity = pParameter->value4;
	float mutationRate = pParameter->value5;


	int32_t numOfNeuralConnections = pInOutNetDesc->NumOfNeuralConnections;

	for (int32_t i = 0; i < numOfNeuralConnections; i++)
	{
		if (pInOutNetDesc->pConnectionStatusArray[i] == 0.0f)
			continue;

		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
			continue;

		pInOutNetDesc->pPlasticityValueArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minDeltaPlasticity, maxDeltaPlasticity);
	}

}

static void Recombination(CNeuralCalculationNetDesc* pOffspring, const CNeuralCalculationNetDesc* pParent1, const CNeuralCalculationNetDesc* pParent2, CRandomNumbersNN* pRandomNumbers, void* pParam)
{
	CEvolutionParameter_NeuralCalculationNet *pParameter = static_cast<CEvolutionParameter_NeuralCalculationNet*>(pParam);

	float crossoverRate = pParameter->value6;

	int32_t numOfNeuralConnections = pOffspring->NumOfNeuralConnections;

	if (pRandomNumbers->Get_IntegerNumber2(1, 2) == 1)
	{
		for (int32_t i = 0; i < numOfNeuralConnections; i++)
		{
			if (pOffspring->pConnectionStatusArray[i] == 0.0f)
				continue;

			pOffspring->pPlasticityValueArray[i] = pParent1->pPlasticityValueArray[i];
		}
	}
	else
	{
		for (int32_t i = 0; i < numOfNeuralConnections; i++)
		{
			if (pOffspring->pConnectionStatusArray[i] == 0.0f)
				continue;

			pOffspring->pPlasticityValueArray[i] = pParent2->pPlasticityValueArray[i];
		}
	}

	for (int32_t i = 0; i < numOfNeuralConnections; i++)
	{
		if (pOffspring->pConnectionStatusArray[i] == 0.0f)
			continue;

		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > crossoverRate)
			continue;

		float weight1 = pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f);
		float weight2 = 1.0f - weight1;

		pOffspring->pPlasticityValueArray[i] = weight1 * pParent1->pPlasticityValueArray[i] + weight2 * pParent2->pPlasticityValueArray[i];
	}
}



/*
int main(void)
{
	Begin_Log(0, "Begin Log", "LogFile.txt");

	int32_t numCpuCores = omp_get_num_procs();
	int32_t maxThreads = omp_get_max_threads();

	Add_To_Log(0, "numCpuCores", numCpuCores);
	Add_To_Log(0, "maxThreads", maxThreads);

	CRandomNumbersNN RandomNumbers;

	CWindowsConsoleScreenBuffer WinConsole;
	WinConsole.Initialize(ConstGameBoardSizeX, ConstGameBoardSizeY, false, BackgroundColor);

	Set_Title("Orbital Navigation (neuro-evolution running ... )");
	Set_ConsolePos(10, 10);

	WinConsole.Set_CursorVisibilityAndSize(FALSE);
	//WinConsole.Set_Font(L"Consolas", 15, 15);
	WinConsole.Set_Font(L"Consolas", 4, 4);
	//WinConsole.Set_Font(L"Consolas", 8, 8);
	//WinConsole.Set_Font_Ext(L"Consolas", 90, 10, 10);


	//WinConsole.Set_BackgroundColor(RGB(100, 50, 25));
	WinConsole.Set_BackgroundColor(BackgroundColor);

	Set_CursorVisibilityAndSize(false);

	CWindowsConsole2DObject Target;
	Target.Initialize(5, 5);

	Target.Set_Pixel(0, 0, lightred);
	Target.Set_Pixel(4, 0, lightred);
	Target.Set_Pixel(1, 1, lightred);
	Target.Set_Pixel(3, 1, lightred);
	Target.Set_Pixel(2, 2, lightred);
	Target.Set_Pixel(1, 3, lightred);
	Target.Set_Pixel(3, 3, lightred);
	Target.Set_Pixel(0, 4, lightred);
	Target.Set_Pixel(4, 4, lightred);

	CWindowsConsole2DObject Ball;
	Ball.Initialize(5, 5);

	Ball.Set_Pixel(0, 0, black);
	Ball.Set_Pixel(1, 0, lightgreen);
	Ball.Set_Pixel(2, 0, lightgreen);
	Ball.Set_Pixel(3, 0, lightgreen);
	Ball.Set_Pixel(4, 0, black);

	Ball.Set_Pixel(0, 1, lightgreen);
	Ball.Set_Pixel(1, 1, lightgreen);
	Ball.Set_Pixel(2, 1, lightgreen);
	Ball.Set_Pixel(3, 1, lightgreen);
	Ball.Set_Pixel(4, 1, lightgreen);

	Ball.Set_Pixel(0, 2, lightgreen);
	Ball.Set_Pixel(1, 2, lightgreen);
	Ball.Set_Pixel(2, 2, lightgreen);
	Ball.Set_Pixel(3, 2, lightgreen);
	Ball.Set_Pixel(4, 2, lightgreen);

	Ball.Set_Pixel(0, 3, lightgreen);
	Ball.Set_Pixel(1, 3, lightgreen);
	Ball.Set_Pixel(2, 3, lightgreen);
	Ball.Set_Pixel(3, 3, lightgreen);
	Ball.Set_Pixel(4, 3, lightgreen);

	Ball.Set_Pixel(0, 4, black);
	Ball.Set_Pixel(1, 4, lightgreen);
	Ball.Set_Pixel(2, 4, lightgreen);
	Ball.Set_Pixel(3, 4, lightgreen);
	Ball.Set_Pixel(4, 4, black);

	CWindowsConsole2DObject GravitySourceObject;
	GravitySourceObject.Initialize(7, 7);

	GravitySourceObject.Set_Pixel(0, 0, black);
	GravitySourceObject.Set_Pixel(1, 0, gray);
	GravitySourceObject.Set_Pixel(2, 0, gray);
	GravitySourceObject.Set_Pixel(3, 0, gray);
	GravitySourceObject.Set_Pixel(4, 0, gray);
	GravitySourceObject.Set_Pixel(5, 0, gray);
	GravitySourceObject.Set_Pixel(6, 0, black);

	GravitySourceObject.Set_Pixel(0, 1, gray);
	GravitySourceObject.Set_Pixel(1, 1, gray);
	GravitySourceObject.Set_Pixel(2, 1, gray);
	GravitySourceObject.Set_Pixel(3, 1, gray);
	GravitySourceObject.Set_Pixel(4, 1, gray);
	GravitySourceObject.Set_Pixel(5, 1, gray);
	GravitySourceObject.Set_Pixel(6, 1, gray);

	GravitySourceObject.Set_Pixel(0, 2, gray);
	GravitySourceObject.Set_Pixel(1, 2, gray);
	GravitySourceObject.Set_Pixel(2, 2, gray);
	GravitySourceObject.Set_Pixel(3, 2, gray);
	GravitySourceObject.Set_Pixel(4, 2, gray);
	GravitySourceObject.Set_Pixel(5, 2, gray);
	GravitySourceObject.Set_Pixel(6, 2, gray);

	GravitySourceObject.Set_Pixel(0, 3, gray);
	GravitySourceObject.Set_Pixel(1, 3, gray);
	GravitySourceObject.Set_Pixel(2, 3, gray);
	GravitySourceObject.Set_Pixel(3, 3, gray);
	GravitySourceObject.Set_Pixel(4, 3, gray);
	GravitySourceObject.Set_Pixel(5, 3, gray);
	GravitySourceObject.Set_Pixel(6, 3, gray);

	GravitySourceObject.Set_Pixel(0, 4, gray);
	GravitySourceObject.Set_Pixel(1, 4, gray);
	GravitySourceObject.Set_Pixel(2, 4, gray);
	GravitySourceObject.Set_Pixel(3, 4, gray);
	GravitySourceObject.Set_Pixel(4, 4, gray);
	GravitySourceObject.Set_Pixel(5, 4, gray);
	GravitySourceObject.Set_Pixel(6, 4, gray);

	GravitySourceObject.Set_Pixel(0, 5, gray);
	GravitySourceObject.Set_Pixel(1, 5, gray);
	GravitySourceObject.Set_Pixel(2, 5, gray);
	GravitySourceObject.Set_Pixel(3, 5, gray);
	GravitySourceObject.Set_Pixel(4, 5, gray);
	GravitySourceObject.Set_Pixel(5, 5, gray);
	GravitySourceObject.Set_Pixel(6, 5, gray);

	GravitySourceObject.Set_Pixel(0, 6, black);
	GravitySourceObject.Set_Pixel(1, 6, gray);
	GravitySourceObject.Set_Pixel(2, 6, gray);
	GravitySourceObject.Set_Pixel(3, 6, gray);
	GravitySourceObject.Set_Pixel(4, 6, gray);
	GravitySourceObject.Set_Pixel(5, 6, gray);
	GravitySourceObject.Set_Pixel(6, 6, black);


	int32_t iGravitySourcePosX = 70;
	int32_t iGravitySourcePosY = 50;
	//int32_t iGravitySourcePosY = 40;
	//int32_t iGravitySourcePosY = 60;


	CSimplePhysicsObject GravitySource;
	GravitySource.PosX = static_cast<float>(iGravitySourcePosX);
	GravitySource.PosY = static_cast<float>(iGravitySourcePosY);
	GravitySource.Mass = 150000.0f;
	

	CSimplePhysicsObject FlightObject;

	
	float minRandomPlasticity = -3.0f;
	float maxRandomPlasticity = 3.0f;

	float minDeltaPlasticity = -0.0001f;
	float maxDeltaPlasticity = 0.0001f;

	float mutationRate = 0.25f;
	float crossoverRate = 0.5f;

	
	int32_t NumOfHiddenUnitsL1 = 2;
	

	CEvolutionParameter_NeuralCalculationNet EvolutionParameter;
	EvolutionParameter.value1 = minRandomPlasticity;
	EvolutionParameter.value2 = maxRandomPlasticity;
	EvolutionParameter.value3 = minDeltaPlasticity;
	EvolutionParameter.value4 = maxDeltaPlasticity;
	EvolutionParameter.value5 = mutationRate;
	EvolutionParameter.value6 = crossoverRate;

	COrbitalNavigationAI OrbitalNavigationAI;
	
	OrbitalNavigationAI.Initialize(NumOfHiddenUnitsL1, minRandomPlasticity, maxRandomPlasticity);
	
	

	// neuro-evolution running

	//float simulationTimeStep = 0.025f;
	float simulationTimeStep = 0.0075f;

	CNeuralCalculationNetDesc BestEvolvedCalculationNetDesc;
	OrbitalNavigationAI.Readout_CalculationNetData(&BestEvolvedCalculationNetDesc);

	static constexpr int32_t TrainingPopulationSize = 200;
	static constexpr int32_t NumTrainingGenerationsMax = 400;
	static constexpr int32_t NumTrainingGamesPerGeneration = 40;
	static constexpr int32_t NumSimpleMutationGenerations = 100;

	static CNeuralCalculationNetDesc CalculationNetDescArray[TrainingPopulationSize];

	CNeuralCalculationNetDescPopulation CalculationNetDescPopulation;
	CalculationNetDescPopulation.Initialize(TrainingPopulationSize);

	for (int32_t i = 0; i < TrainingPopulationSize; i++)
	{
		OrbitalNavigationAI.Readout_CalculationNetData(&CalculationNetDescArray[i]);
		Reinitialization(&CalculationNetDescArray[i], &RandomNumbers, &EvolutionParameter);

		CalculationNetDescPopulation.Set_NeuralCalculationNetDesc(&CalculationNetDescArray[i], i);
	}

	static CSimplePhysicsObject TrainingFlightObjectArray[4];
	static COrbitalNavigationAI TrainingOrbitalNavigationAIArray[4];

	for (int32_t i = 0; i < 4; i++)
	{
		TrainingOrbitalNavigationAIArray[i].Initialize(NumOfHiddenUnitsL1, minRandomPlasticity, maxRandomPlasticity);
	}

	RandomNumbers.Change_Seed(150);

	for (int32_t j = 0; j < NumTrainingGenerationsMax; j++)
	{
		CalculationNetDescPopulation.Reset_MinErrorSum_ActualGeneration();

		for (int32_t i = 0; i < TrainingPopulationSize; i++)
		{
			CalculationNetDescPopulation.Set_FitnessScore(i, 0.0f);
		}

		// RandomNumbers.Change_Seed(150);

		for (int32_t k = 0; k < NumTrainingGamesPerGeneration; k++)
		{
			// start training game:

			float dirX = -1.0f;
			float dirY = 0.0f;



			float distSq = dirX * dirX + dirY * dirY + 0.00001f;
			float invLength = 1.0f / sqrt(distSq);

			dirX *= invLength;
			dirY *= invLength;

			float radiusStart = RandomNumbers.Get_FloatNumber(20.0f, 30.0f);

			float  StartPosX = dirX * radiusStart + GravitySource.PosX;
			float  StartPosY = dirY * radiusStart + GravitySource.PosY;

			dirX = 1.0f;
			dirY = 0.0f;

			distSq = dirX * dirX + dirY * dirY + 0.00001f;
			invLength = 1.0f / sqrt(distSq);

			dirX *= invLength;
			dirY *= invLength;

			float radiusEnd = RandomNumbers.Get_FloatNumber(10.0f, 40.0f);

			float TargetPosX = dirX * radiusEnd + GravitySource.PosX;
			float TargetPosY = dirY * radiusEnd + GravitySource.PosY;

			float radiusMin = min(radiusStart, radiusEnd);
			float radiusMinSq = radiusMin * radiusMin;

			float radiusMax = min(radiusStart, radiusEnd);
			float radiusMaxSq = radiusMax * radiusMax;

#pragma omp parallel for num_threads(4)
			for (int32_t i = 0; i < TrainingPopulationSize; i++)
			{
				int32_t threadID = omp_get_thread_num();

				CSimplePhysicsObject* pFlightObject = &TrainingFlightObjectArray[threadID];
				COrbitalNavigationAI* pOrbitalNavigationAI = &TrainingOrbitalNavigationAIArray[threadID];

				pOrbitalNavigationAI->Modify_CalculationNet(&CalculationNetDescArray[i]);

				pFlightObject->Reset_Values();
				pFlightObject->PosX = StartPosX;
				pFlightObject->PosY = StartPosY;

				pOrbitalNavigationAI->Calculate_InitialOrbitalVelocity(&pFlightObject->VelX, &pFlightObject->VelY, pFlightObject->PosX, pFlightObject->PosY, TargetPosX, TargetPosY, GravitySource.PosX, GravitySource.PosY, GravitySource.Mass);

				

				float minDistSq = 100000000000.0f;
				float invDist, distXSq, distYSq;
				float velSq, invVel, acceleration, accelerationX, accelerationY;
				float moveDirX, moveDirY, distX, distY;



				velSq = pFlightObject->VelX * pFlightObject->VelX + pFlightObject->VelY * pFlightObject->VelY + 0.00001f;

				if (velSq < 0.2f)
					continue;

				int32_t counter = 0;
				int32_t TrainingGameLength = 300;

				do
				{

					velSq = pFlightObject->VelX * pFlightObject->VelX + pFlightObject->VelY * pFlightObject->VelY + 0.00001f;
					invVel = 1.0f / sqrt(velSq);



					moveDirX = invVel * pFlightObject->VelX;
					moveDirY = invVel * pFlightObject->VelY;

					distX = GravitySource.PosX - pFlightObject->PosX;
					distY = GravitySource.PosY - pFlightObject->PosY;

					distSq = distX * distX + distY * distY;


					invDist = 1.0f / sqrt(distSq + 0.00001f);

					dirX = invDist * distX;
					dirY = invDist * distY;


					acceleration = GravitySource.Mass / distSq;

					accelerationX = dirX * acceleration;
					accelerationY = dirY * acceleration;



					pFlightObject->AccelX = accelerationX;
					pFlightObject->AccelY = accelerationY;

					pFlightObject->Update(simulationTimeStep);

					distXSq = pFlightObject->PosX - TargetPosX;
					distXSq *= distXSq;

					distYSq = pFlightObject->PosY - TargetPosY;
					distYSq *= distYSq;


					distSq = distXSq + distYSq;

					if (distSq < minDistSq)
						minDistSq = distSq;

					counter++;

					if (counter > TrainingGameLength)
						break;

				} while (true);

				
				CalculationNetDescPopulation.Add_FitnessScore(i, exp(-(0.01f * minDistSq)));

			} // end of for (int32_t i = 0; i < TrainingPopulationSize; i++)
		} // end of for (int32_t k = 0; k < NumTrainingGamesPerGeneration; k++)

		for (int32_t i = 0; i < TrainingPopulationSize; i++)
		{
			CalculationNetDescPopulation.Update_MinErrorSum_ActualGeneration(CalculationNetDescPopulation.Calculate_Error_From_FitnessScore(i));
		}

		CalculationNetDescPopulation.Update_Population();


		//if (CalculationNetDescPopulation.MinErrorSum_ActualGeneration < 0.0001f)
			//break;


		CalculationNetDescPopulation.Update_BaseEvolution(Mutation, &EvolutionParameter);
		CalculationNetDescPopulation.Update_Evolution_BestBrainOnly(Mutation, &EvolutionParameter);
		CalculationNetDescPopulation.Update_Evolution_SecondBestBrainOnly(Mutation, &EvolutionParameter);

		if (j < NumSimpleMutationGenerations)
			continue;

		CalculationNetDescPopulation.Update_Evolution_Combine_BestTwoBrains(Recombination, &EvolutionParameter);
		CalculationNetDescPopulation.Update_Evolution_Combine_TwoBrains(Recombination, &EvolutionParameter);
		CalculationNetDescPopulation.Update_Evolution_Combine_TwoBrains(Recombination, &EvolutionParameter);
		CalculationNetDescPopulation.Replace_WorstFitted_Brain(Reinitialization, &EvolutionParameter);
		CalculationNetDescPopulation.Replace_SecondWorstFitted_Brain(Reinitialization, &EvolutionParameter);
		CalculationNetDescPopulation.Replace_ThirdWorstFitted_Brain(Reinitialization, &EvolutionParameter);

	} // end of for (int32_t j = 0; j < NumTrainingGenerationsMax; j++)


	CalculationNetDescPopulation.Get_Best_Evolved_NeuralCalculationNetDesc(&BestEvolvedCalculationNetDesc);


	OrbitalNavigationAI.Modify_CalculationNet(&BestEvolvedCalculationNetDesc);

	RandomNumbers.Change_Seed(150);

	//neuro-evolution completed

	Set_Title("Orbital Navigation (SPACE: Fire, ESC: Exit)");

	//char strBuffer[100];

	float FrameTime = 1.0f;
	float FrameRate = 1.0f;

	RandomNumbers.Change_Seed(150);


	float dirX = -1.0f;
	float dirY = 0.0f;


	float distSq = dirX * dirX + dirY * dirY + 0.00001f;
	float invLength = 1.0f / sqrt(distSq);

	dirX *= invLength;
	dirY *= invLength;

	float radius = RandomNumbers.Get_FloatNumber(20.0f, 30.0f);

	float  StartPosX = dirX * radius + GravitySource.PosX;
	float  StartPosY = dirY * radius + GravitySource.PosY;

	int32_t iStartPosX = static_cast<int32_t>(StartPosX);
	int32_t iStartPosY = static_cast<int32_t>(StartPosY);

	dirX = RandomNumbers.Get_FloatNumber(0.1f, 1.0f);
	dirY = RandomNumbers.Get_FloatNumber(-1.0f, -0.1f);

	float scale = RandomNumbers.Get_FloatNumber(10.0f, 40.0f);

	float  TargetPosX = dirX * scale + GravitySource.PosX;
	float  TargetPosY = dirY * scale + GravitySource.PosY;

	int32_t iTargetPosX = static_cast<int32_t>(TargetPosX);
	int32_t iTargetPosY = static_cast<int32_t>(TargetPosY);

	FlightObject.Reset_Values();
	FlightObject.PosX = StartPosX;
	FlightObject.PosY = StartPosY;


	OrbitalNavigationAI.Calculate_InitialOrbitalVelocity(&FlightObject.VelX, &FlightObject.VelY, FlightObject.PosX, FlightObject.PosY, TargetPosX, TargetPosY, GravitySource.PosX, GravitySource.PosY, GravitySource.Mass);

	

	int32_t counter = 0;

	do
	{
		if (KEYDOWN(VK_ESCAPE) == true)
			break;

		//auto last_timepoint = std::chrono::steady_clock::now();
		auto last_timepoint = steady_clock::now();

		float distX = GravitySource.PosX - FlightObject.PosX;
		float distY = GravitySource.PosY - FlightObject.PosY;

		float distSq = distX * distX + distY * distY;
		float invDist = 1.0f / sqrt(distSq + 0.00001f);

		float dirX = invDist * distX;
		float dirY = invDist * distY;

		float acceleration = GravitySource.Mass / distSq;

		FlightObject.AccelX = dirX * acceleration;
		FlightObject.AccelY = dirY * acceleration;

		FlightObject.Update(simulationTimeStep);

		WinConsole.Clear_BackBuffer();

		int32_t posX_Left = iGravitySourcePosX - GravitySourceObject.NumCharactersPerRow / 2;
		int32_t posY_Top = iGravitySourcePosY - GravitySourceObject.NumCharactersPerColumn / 2;

		WinConsole.Draw_2DObject_Into_BackBuffer(posX_Left, posY_Top, GravitySourceObject.pDataArray, GravitySourceObject.NumCharactersPerRow, GravitySourceObject.NumCharactersPerColumn);

		posX_Left = FlightObject.PosX - Ball.NumCharactersPerRow / 2;
		posY_Top = FlightObject.PosY - Ball.NumCharactersPerColumn / 2;

		WinConsole.Draw_2DObject_Into_BackBuffer(posX_Left, posY_Top, Ball.pDataArray, Ball.NumCharactersPerRow, Ball.NumCharactersPerColumn);

		posX_Left = static_cast<int32_t>(TargetPosX) - Target.NumCharactersPerRow / 2;
		posY_Top = static_cast<int32_t>(TargetPosY) - Target.NumCharactersPerColumn / 2;

		WinConsole.Draw_2DObject_Into_BackBuffer(posX_Left, posY_Top, Target.pDataArray, Target.NumCharactersPerRow, Target.NumCharactersPerColumn);
		//WinConsole.Write_Pixel_Into_BackBuffer(iTargetPosX, iTargetPosY, lightred);


		WinConsole.Present_BackBuffer();

		counter++;

		if (GetAsyncKeyState(VK_SPACE) || GetAsyncKeyState(VK_RETURN) || counter > 400)
		{
			counter = 0;

			float dirX = -1.0f;
			float dirY = 0.0f;

			float distSq = dirX * dirX + dirY * dirY + 0.00001f;
			float invLength = 1.0f / sqrt(distSq);

			dirX *= invLength;
			dirY *= invLength;

			float radius = RandomNumbers.Get_FloatNumber(20.0f, 30.0f);

			StartPosX = dirX * radius + GravitySource.PosX;
			StartPosY = dirY * radius + GravitySource.PosY;

			iStartPosX = static_cast<int32_t>(StartPosX);
			iStartPosY = static_cast<int32_t>(StartPosY);

			dirX = RandomNumbers.Get_FloatNumber(0.1f, 1.0f);
			dirY = RandomNumbers.Get_FloatNumber(-1.0f, -0.1f);

			float scale = RandomNumbers.Get_FloatNumber(10.0f, 40.0f);

			TargetPosX = dirX * scale + GravitySource.PosX;
			TargetPosY = dirY * scale + GravitySource.PosY;

			iTargetPosX = static_cast<int32_t>(TargetPosX);
			iTargetPosY = static_cast<int32_t>(TargetPosY);

			FlightObject.Reset_Values();
			FlightObject.PosX = StartPosX;
			FlightObject.PosY = StartPosY;


			OrbitalNavigationAI.Calculate_InitialOrbitalVelocity(&FlightObject.VelX, &FlightObject.VelY, FlightObject.PosX, FlightObject.PosY, TargetPosX, TargetPosY, GravitySource.PosX, GravitySource.PosY, GravitySource.Mass);

		}

		//Frame-Bremse:

		auto current_timepoint = steady_clock::now();

		//while (current_timepoint - last_timepoint < 250ms)
		//while (current_timepoint - last_timepoint < 50ms)
		while (current_timepoint - last_timepoint < 16ms)
			//while (current_timepoint - last_timepoint < 16666us) // 16.7 Millisekunden (ms)  bzw. 16666 Mikrosekunden (us): maximal 60 Frames pro Sekunde					
		{
			current_timepoint = steady_clock::now();
		}

		FrameTime = 0.000000001f * (current_timepoint - last_timepoint).count();
		FrameRate = 1.0f / FrameTime;

	} while (true);

	WinConsole.Clear_BackBuffer();
	WinConsole.Present_BackBuffer();
	WinConsole.CleanUp();

	Set_CursorVisibilityAndSize(true);
	Reset_CursorPos();
	Set_CursorPos(0, 0);

	cout << "bye bye (Press Return)" << endl;
	getchar();
	Add_To_Log(0, "bye bye");
	return 0;
}
*/




