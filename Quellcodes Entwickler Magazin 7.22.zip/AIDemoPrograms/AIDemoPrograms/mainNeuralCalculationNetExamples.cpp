#pragma warning( disable: 4996)

#include <iostream>
#include "LogFile.h"
#include "NeuralCalculationNet.h"

using namespace std;
using namespace HelperStuff;

#define KEYDOWN(vk_code) ((GetAsyncKeyState(vk_code) & 0x8000) ? 1 : 0)
#define KEYUP(vk_code)   ((GetAsyncKeyState(vk_code) & 0x8000) ? 0 : 1)

static void Identity(CNeuralCalculationUnit* pCalculationUnit)
{
	pCalculationUnit->OutputValue = pCalculationUnit->SumOfInputValues;
	pCalculationUnit->SumOfInputValues = 0.0f;
	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}

static void Quadric(CNeuralCalculationUnit* pCalculationUnit)
{
	float tempFloat = pCalculationUnit->SumOfInputValues;
	tempFloat *= tempFloat;
	pCalculationUnit->OutputValue = tempFloat;
	pCalculationUnit->SumOfInputValues = 0.0f;
	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}

static void Cubic(CNeuralCalculationUnit* pCalculationUnit)
{
	float tempFloat = pCalculationUnit->SumOfInputValues;
	pCalculationUnit->OutputValue = tempFloat * tempFloat * tempFloat;
	pCalculationUnit->SumOfInputValues = 0.0f;
	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}

static void LinearClippedToOne(CNeuralCalculationUnit* pCalculationUnit)
{
	pCalculationUnit->OutputValue = min(pCalculationUnit->SumOfInputValues, 1.0f);
	pCalculationUnit->SumOfInputValues = 0.0f;
	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}

static void Maximum(CNeuralCalculationUnit* pCalculationUnit)
{
	pCalculationUnit->OutputValue = pCalculationUnit->SumOfInputValues;
	pCalculationUnit->SumOfInputValues = -1000000.0f;
	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}

static void Minimum(CNeuralCalculationUnit* pCalculationUnit)
{
	pCalculationUnit->OutputValue = pCalculationUnit->SumOfInputValues;
	pCalculationUnit->SumOfInputValues = 1000000.0f;
	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}


static void TanH(CNeuralCalculationUnit* pCalculationUnit)
{
	// von -1.0f bis 1.0f:
	pCalculationUnit->OutputValue = tanh(pCalculationUnit->SumOfInputValues);
	pCalculationUnit->SumOfInputValues = 0.0f;
	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}


static void Multiply(CNeuralCalculationUnit* pCalculationUnit)
{
	pCalculationUnit->OutputValue = pCalculationUnit->AdditionalCalcValueArray[0] * pCalculationUnit->SumOfInputValues;
	pCalculationUnit->SumOfInputValues = 0.0f;
	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}

static void StdBinaryOutput(CNeuralCalculationUnit* pCalculationUnit)
{
	if (pCalculationUnit->SumOfInputValues > 0.0f)
	{
		pCalculationUnit->OutputValue = 1.0f;
		pCalculationUnit->SumOfInputValues = 0.0f;
		//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
		return;
	}

	pCalculationUnit->OutputValue = 0.0f;
	pCalculationUnit->SumOfInputValues = 0.0f;
}

static void Bias(CNeuralCalculationUnit* pCalculationUnit)
{
	pCalculationUnit->OutputValue = 1.0f;
	pCalculationUnit->SumOfInputValues = 0.0f;
	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}

static void BinaryRadialClusterCheck(CNeuralCalculationUnit* pCalculationUnit)
{
	pCalculationUnit->OutputValue = 0.0f;

	if (pCalculationUnit->SumOfInputValues < 1.0f)
	{
		pCalculationUnit->OutputValue = 1.0f;
		pCalculationUnit->SumOfOutputValues += 1.0f;
	}
	
	pCalculationUnit->SumOfInputValues = 0.0f;
}

static void BinaryRadialClusterCheckSumUp(CNeuralCalculationUnit* pCalculationUnit)
{
	float tempFloat = 0.0f;

	if (pCalculationUnit->SumOfInputValues < 1.0f)
		tempFloat = 1.0f;


	pCalculationUnit->OutputValue += tempFloat;

	pCalculationUnit->SumOfInputValues = 0.0f;
	pCalculationUnit->SumOfOutputValues += tempFloat;
}



static void ExpRBF(CNeuralCalculationUnit* pCalculationUnit)
{
	pCalculationUnit->OutputValue = exp(-pCalculationUnit->SumOfInputValues);
	pCalculationUnit->SumOfInputValues = 0.0f;
	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}

static void OneMinusExpRBF(CNeuralCalculationUnit* pCalculationUnit)
{
	pCalculationUnit->OutputValue = 1.0f - exp(-pCalculationUnit->SumOfInputValues);
	pCalculationUnit->SumOfInputValues = 0.0f;
	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}

static void ClippedExpRBF(CNeuralCalculationUnit* pCalculationUnit)
{
	pCalculationUnit->OutputValue = min(1.0f, pCalculationUnit->AdditionalCalcValueArray[0] * exp(-pCalculationUnit->SumOfInputValues));
	pCalculationUnit->SumOfInputValues = 0.0f;
	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}


static void ExpRBF2(CNeuralCalculationUnit* pCalculationUnit)
{
	float tempFloat = pCalculationUnit->SumOfInputValues - pCalculationUnit->AdditionalCalcValueArray[1];
	tempFloat *= tempFloat;
	tempFloat *= pCalculationUnit->AdditionalCalcValueArray[0];

	pCalculationUnit->OutputValue = exp(-tempFloat);
	pCalculationUnit->SumOfInputValues = 0.0f;

	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}

static void ClippedExpRBF2(CNeuralCalculationUnit* pCalculationUnit)
{
	float tempFloat = pCalculationUnit->SumOfInputValues - pCalculationUnit->AdditionalCalcValueArray[1];
	tempFloat *= tempFloat;
	tempFloat *= pCalculationUnit->AdditionalCalcValueArray[0];

	pCalculationUnit->OutputValue = min(1.0f, pCalculationUnit->AdditionalCalcValueArray[2] * exp(-tempFloat));
	pCalculationUnit->SumOfInputValues = 0.0f;

	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}

static void SumUp(CNeuralCalculationUnit* pCalculationUnit)
{
	pCalculationUnit->OutputValue += pCalculationUnit->SumOfInputValues;
	pCalculationUnit->SumOfInputValues = 0.0f;
	//pCalculationUnit->SumOfOutputValues += pCalculationUnit->OutputValue;
}

static void ExpRBFSumUp(CNeuralCalculationUnit* pCalculationUnit)
{
	float tempFloat = exp(-pCalculationUnit->SumOfInputValues);
	pCalculationUnit->OutputValue += tempFloat;
	pCalculationUnit->SumOfInputValues = 0.0f;
	//pCalculationUnit->SumOfOutputValues += tempFloat;
}

/*
int main(void)
{
	CNeuralCalculationFunctions CalculationFunctions;
	CalculationFunctions.Initialize(2);
	CalculationFunctions.Set_Function(0, nullptr);
	CalculationFunctions.Set_Function(1, ExpRBF2);


	CNeuralCalculationNet CalculationNet;
	CalculationNet.Initialize(1, 1, 1);
	CalculationNet.Set_InputUnit(0, 0);
	CalculationNet.Set_OutputUnit(0, 0);

	


	// InputOutputUnit:
	CalculationNet.Set_CalculationFunction(0, 1, &CalculationFunctions);
	//CalculationNet.Set_CalculationFunction(0, 1, ExpRBF2);

	CalculationNet.Set_CalculationUnit_AdditionalCalculationValue(0, 10.0f, 0);
	CalculationNet.Set_CalculationUnit_AdditionalCalculationValue(0, 1.0f, 1);
	

	float inputValue;
	float outputValue;
	//float inputValueArray[1];
	//float outputValueArray[1];

	inputValue = 0.7f;
	CalculationNet.Set_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl;

	inputValue = 0.8f;
	CalculationNet.Set_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl;

	inputValue = 0.9f;
	CalculationNet.Add_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl;

	inputValue = 1.0f;
	CalculationNet.Add_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl;

	inputValue = 1.1f;
	CalculationNet.Add_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl;

	inputValue = 1.2f;
	CalculationNet.Add_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl;

	inputValue = 1.3f;
	CalculationNet.Add_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl << endl;

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CNeuralCalculationFunctions CalculationFunctions;
	CalculationFunctions.Initialize(3);
	CalculationFunctions.Set_Function(0, nullptr);
	CalculationFunctions.Set_Function(1, Identity);
	CalculationFunctions.Set_Function(2, ExpRBF);


	CNeuralCalculationNet CalculationNet;
	CalculationNet.Initialize(2, 1, 1);
	CalculationNet.Set_InputUnit(0, 0);
	CalculationNet.Set_OutputUnit(1, 0);

	// neuronal connection scheme:

	// variant 1:

	//             InputUnit    | OutputUnit
	// --------------------------------------
	// InputUnit   (x=0 y=0): 0 | (x=1 y=0): 1          
	// OutputUnit  (x=0 y=1): 0 | (x=1 y=1): 0

	// variant 2 (connectionID = x + NumOfCalculationUnits * y):

	//             InputUnit           | OutputUnit
	// -----------------------------------------------------
	// InputUnit   (connectionID=0): 0 | (connectionID=1): 1          
	// OutputUnit  (connectionID=2): 0 | (connectionID=3): 0


	// InputUnit:
	CalculationNet.Set_CalculationFunction(0, 1, &CalculationFunctions);
	//CalculationNet.Set_CalculationFunction(0, 1, Identity);

	// OutputUnit:
	CalculationNet.Set_CalculationFunction(1, 2, &CalculationFunctions);
	//CalculationNet.Set_CalculationFunction(1, 2, ExpRBF);
	CalculationNet.Set_PropagationFunction(1, RBFPropagationFunctionID);


	// connection: InputUnit (ID=0) -> OutputUnit (ID=1)

	// variant 1:
	CalculationNet.Set_Connection_RBFConstant(1, 0, 15.0f);
	CalculationNet.Set_Connection_CentroidValue(1, 0, 1.0f);
	// variant 2:
	//CalculationNet.Set_Connection_RBFConstant(1, 15.0f);
	//CalculationNet.Set_Connection_CentroidValue(1, 1.0f);

	// variant 1:
	CalculationNet.Activate_Connection(1, 0);
	// variant 2:
	//CalculationNet.Activate_Connection(1);



	float inputValue;
	float outputValue;
	//float inputValueArray[1];
	//float outputValueArray[1];

	inputValue = 0.7f;
	CalculationNet.Set_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl;

	inputValue = 0.8f;
	CalculationNet.Set_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl;

	inputValue = 0.9f;
	CalculationNet.Add_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl;

	inputValue = 1.0f;
	CalculationNet.Add_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl;

	inputValue = 1.1f;
	CalculationNet.Add_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl;

	inputValue = 1.2f;
	CalculationNet.Add_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl;

	inputValue = 1.3f;
	CalculationNet.Add_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl << endl;

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CNeuralCalculationFunctions CalculationFunctions;
	CalculationFunctions.Initialize(4);
	CalculationFunctions.Set_Function(0, nullptr);
	CalculationFunctions.Set_Function(1, Identity);
	CalculationFunctions.Set_Function(2, Maximum);
	CalculationFunctions.Set_Function(3, Minimum);


	CNeuralCalculationNet MaxCalculationNet;
	MaxCalculationNet.Initialize(3, 2, 1);
	MaxCalculationNet.Set_InputUnit(0, 0);
	MaxCalculationNet.Set_InputUnit(1, 1);
	MaxCalculationNet.Set_OutputUnit(2, 0);
	MaxCalculationNet.Set_PropagationFunction(2, StandardMaxPropagationFunctionID);

	CNeuralCalculationNet MinCalculationNet;
	MinCalculationNet.Initialize(3, 2, 1);
	MinCalculationNet.Set_InputUnit(0, 0);
	MinCalculationNet.Set_InputUnit(1, 1);
	MinCalculationNet.Set_OutputUnit(2, 0);
	MinCalculationNet.Set_PropagationFunction(2, StandardMinPropagationFunctionID);

	// neuronal connection scheme:

	// variant 1:

	//             InputUnit1   | InputUnit2   | OutputUnit
	// -------------------------------------------------------
	// InputUnit1  (x=0 y=0): 0 | (x=1 y=0): 0 | (x=2 y=0): 1  
	// InputUnit2  (x=0 y=1): 0 | (x=1 y=1): 0 | (x=2 y=1): 1
	// OutputUnit  (x=0 y=2): 0 | (x=1 y=2): 0 | (x=2 y=2): 0

	// variant 2 (connectionID = x + NumOfCalculationUnits * y):

	//             InputUnit1          | InputUnit2          | OutputUnit
	// ----------------------------------------------------------------------------
	// InputUnit1  (connectionID=0): 0 | (connectionID=1): 0 | (connectionID=2): 1 
	// InputUnit2  (connectionID=3): 0 | (connectionID=4): 0 | (connectionID=5): 1
	// OutputUnit  (connectionID=6): 0 | (connectionID=7): 0 | (connectionID=8): 0


	// InputUnits:
	MaxCalculationNet.Set_CalculationFunction(0, 1, &CalculationFunctions);
	//MaxCalculationNet.Set_CalculationFunction(0, 1, Identity);
	MaxCalculationNet.Set_CalculationFunction(1, 1, &CalculationFunctions);
	//MaxCalculationNet.Set_CalculationFunction(1, 1, Identity);

	// OutputUnit:
	MaxCalculationNet.Set_CalculationFunction(2, 2, &CalculationFunctions);
	//MaxCalculationNet.Set_CalculationFunction(2, 2, Maximum);

	// connection: InputUnit1 (ID=0) -> OutputUnit (ID=2)
	// variant 1:
	MaxCalculationNet.Set_Connection_PlasticityValue(2, 0, 1.0f);
	MaxCalculationNet.Activate_Connection(2, 0);
	// variant 2:
	//MaxCalculationNet.Set_Connection_PlasticityValue(2, 1.0f);
	//MaxCalculationNet.Activate_Connection(2);

	// connection: InputUnit2 (ID=1) -> OutputUnit (ID=2)
	// variant 1:
	MaxCalculationNet.Set_Connection_PlasticityValue(2, 1, 1.0f);
	MaxCalculationNet.Activate_Connection(2, 1);
	// variant 2:
	//MaxCalculationNet.Set_Connection_PlasticityValue(5, 1.0f);
	//MaxCalculationNet.Activate_Connection(5);




	// InputUnits:
	MinCalculationNet.Set_CalculationFunction(0, 1, &CalculationFunctions);
	//MinCalculationNet.Set_CalculationFunction(0, 1, Identity);
	MinCalculationNet.Set_CalculationFunction(1, 1, &CalculationFunctions);
	//MinCalculationNet.Set_CalculationFunction(1, 1, Identity);

	// OutputUnit:
	MinCalculationNet.Set_CalculationFunction(2, 3, &CalculationFunctions);
	//MinCalculationNet.Set_CalculationFunction(2, 3, Minimum);
	
	// connection: InputUnit1 (ID=0) -> OutputUnit (ID=2)
	// variant 1:
	MinCalculationNet.Set_Connection_PlasticityValue(2, 0, 1.0f);
	MinCalculationNet.Activate_Connection(2, 0);
	// variant 2:
	//MinCalculationNet.Set_Connection_PlasticityValue(2, 1.0f);
	//MinCalculationNet.Activate_Connection(2);

	// connection: InputUnit2 (ID=1) -> OutputUnit (ID=2)
	// variant 1:
	MinCalculationNet.Set_Connection_PlasticityValue(2, 1, 1.0f);
	MinCalculationNet.Activate_Connection(2, 1);
	// variant 2:
	//MinCalculationNet.Set_Connection_PlasticityValue(5, 1.0f);
	//MinCalculationNet.Activate_Connection(5);

	


	float inputValueArray[2];
	float outputValue;

	inputValueArray[0] = 0.2f;
	inputValueArray[1] = 0.7f;
	MaxCalculationNet.Set_InputValues(inputValueArray);
	MaxCalculationNet.Execute_Calculations();
	MaxCalculationNet.Get_OutputValues(&outputValue);

	cout << "input1: " << inputValueArray[0] << " input2: " << inputValueArray[1] << " output: " << outputValue << endl;

	inputValueArray[0] = 0.9f;
	inputValueArray[1] = 0.1f;
	MaxCalculationNet.Set_InputValues(inputValueArray);
	MaxCalculationNet.Execute_Calculations();
	MaxCalculationNet.Get_OutputValues(&outputValue);

	cout << "input1: " << inputValueArray[0] << " input2: " << inputValueArray[1] << " output: " << outputValue << endl;
	
	inputValueArray[0] = 0.2f;
	inputValueArray[1] = 0.7f;
	MinCalculationNet.Set_InputValues(inputValueArray);
	MinCalculationNet.Execute_Calculations();
	MinCalculationNet.Get_OutputValues(&outputValue);

	cout << "input1: " << inputValueArray[0] << " input2: " << inputValueArray[1] << " output: " << outputValue << endl;

	inputValueArray[0] = 0.9f;
	inputValueArray[1] = 0.1f;
	MinCalculationNet.Set_InputValues(inputValueArray);
	MinCalculationNet.Execute_Calculations();
	MinCalculationNet.Get_OutputValues(&outputValue);

	cout << "input1: " << inputValueArray[0] << " input2: " << inputValueArray[1] << " output: " << outputValue << endl << endl;

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/



/*
int main(void)
{
	CNeuralCalculationFunctions CalculationFunctions;
	CalculationFunctions.Initialize(3);
	CalculationFunctions.Set_Function(0, nullptr);
	CalculationFunctions.Set_Function(1, Identity);
	CalculationFunctions.Set_Function(2, Multiply);


	CNeuralCalculationNet CalculationNet;
	CalculationNet.Initialize(2, 1, 1);
	CalculationNet.Set_InputUnit(0, 0);
	CalculationNet.Set_OutputUnit(1, 0);

	// neuronal connection scheme:

	// variant 1:

	//             InputUnit    | OutputUnit
	// --------------------------------------
	// InputUnit   (x=0 y=0): 0 | (x=1 y=0): 1          
	// OutputUnit  (x=0 y=1): 1 | (x=1 y=1): 0

	// variant 2 (connectionID = x + NumOfCalculationUnits * y):

	//             InputUnit           | OutputUnit
	// -----------------------------------------------------
	// InputUnit   (connectionID=0): 0 | (connectionID=1): 1          
	// OutputUnit  (connectionID=2): 1 | (connectionID=3): 0


	// InputUnit:
	CalculationNet.Set_CalculationFunction(0, 1, &CalculationFunctions);
	//CalculationNet.Set_CalculationFunction(0, 1, Identity);

	// OutputUnit:
	CalculationNet.Set_CalculationFunction(1, 2, &CalculationFunctions);
	//CalculationNet.Set_CalculationFunction(1, 2, MultiplyWith2);
	CalculationNet.Set_CalculationUnit_AdditionalCalculationValue(1, 2.0f, 0);

	// connection: InputUnit (ID=0) -> OutputUnit (ID=1)

	// variant 1:
	CalculationNet.Set_Connection_PlasticityValue(1, 0, 1.0f);
	// variant 2:
	//CalculationNet.Set_Connection_PlasticityValue(1, 1.0f);

	// variant 1:
	CalculationNet.Activate_Connection(1, 0);
	// variant 2:
	//CalculationNet.Activate_Connection(1);

	// connection: OutputUnit (ID=1) -> InputUnit (ID=0) (recurrency, R�ckkopplung, Rekurrenz) 
	CalculationNet.Set_Connection_PlasticityValue(0, 1, 0.5f);
	CalculationNet.Activate_Connection(0, 1);


	float inputValue;
	float outputValue;
	//float inputValueArray[1];
	//float outputValueArray[1];

	inputValue = 2.0f;
	CalculationNet.Set_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl;

	inputValue = 0.0f;
	CalculationNet.Set_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl;

	inputValue = 1.0f;
	CalculationNet.Add_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl;

	inputValue = 1.0f;
	CalculationNet.Add_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl;

	inputValue = 1.0f;
	CalculationNet.Add_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl << endl;

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CNeuralCalculationFunctions CalculationFunctions;
	CalculationFunctions.Initialize(3);
	CalculationFunctions.Set_Function(0, nullptr);
	CalculationFunctions.Set_Function(1, Identity);
	CalculationFunctions.Set_Function(2, Multiply);

	int32_t NumOfCalculationUnits = 2;

	CNeuralCalculationNetDesc CalculationNetDesc;
	CalculationNetDesc.Initialize(2);

	int32_t NumOfInputUnits = 1;
	

	for (int32_t i = 0; i < NumOfInputUnits; i++)
	{
		CalculationNetDesc.pCalculationFunctionIDArray[i] = 1;
		CalculationNetDesc.pCalculationUnitUsageStatusArray[i] = UsageStatus_CalculationInputUnit;
	}

	int32_t NumOfOutputUnits = 1;
	int32_t IdOfFirstOutputUnit = 1;
	

	for (int32_t i = 0; i < NumOfOutputUnits; i++)
	{
		int32_t unitID = i + IdOfFirstOutputUnit;

		CalculationNetDesc.pCalculationFunctionIDArray[unitID] = 2;
		CalculationNetDesc.pAdditionalCalcValueArray[NeuralCalcUnit_NumOfAdditionalCalcValues * unitID] = 2.0f;
		CalculationNetDesc.pAdditionalCalcValueArray[NeuralCalcUnit_NumOfAdditionalCalcValues * unitID + 1] = 0.0f;
		CalculationNetDesc.pCalculationUnitUsageStatusArray[unitID] = UsageStatus_CalculationOutputUnit;
	}

	

	// neuronal connection scheme:

	// variant 1:

	//             InputUnit    | OutputUnit
	// --------------------------------------
	// InputUnit   (x=0 y=0): 0 | (x=1 y=0): 1          
	// OutputUnit  (x=0 y=1): 1 | (x=1 y=1): 0

	// variant 2 (connectionID = x + NumOfCalculationUnits * y):

	//             InputUnit           | OutputUnit
	// -----------------------------------------------------
	// InputUnit   (connectionID=0): 0 | (connectionID=1): 1          
	// OutputUnit  (connectionID=2): 1 | (connectionID=3): 0

	

	// connection: InputUnit -> OutputUnit

	float plasticity = 1.0f;

	int32_t ix = 1;
	int32_t iy = 0;

	int32_t id = ix + iy * NumOfCalculationUnits;
	CalculationNetDesc.pConnectionStatusArray[id] = 1;
	CalculationNetDesc.pPlasticityValueArray[id] = plasticity;

	// connection: OutputUnit -> InputUnit

	plasticity = 0.5f;

	ix = 0;
	iy = 1;

	id = ix + iy * NumOfCalculationUnits;
	CalculationNetDesc.pConnectionStatusArray[id] = 1;
	CalculationNetDesc.pPlasticityValueArray[id] = plasticity;

	CNeuralCalculationNet CalculationNet;

	CalculationNet.Initialize(&CalculationNetDesc, &CalculationFunctions, NumOfInputUnits, NumOfOutputUnits);	
	//CalculationNet.Initialize(NumOfCalculationUnits, NumOfInputUnits, NumOfOutputUnits);
	//CalculationNet.Modify(&CalculationNetDesc, &CalculationFunctions);

	
	float inputValue;
	float outputValue;
	//float inputValueArray[1];
	//float outputValueArray[1];

	inputValue = 2.0f;
	CalculationNet.Set_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl;

	inputValue = 0.0f;
	CalculationNet.Set_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl;

	inputValue = 1.0f;
	CalculationNet.Add_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl;

	inputValue = 1.0f;
	CalculationNet.Add_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl;

	inputValue = 1.0f;
	CalculationNet.Add_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl << endl;

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CNeuralCalculationFunctions CalculationFunctions;
	CalculationFunctions.Initialize(4);
	CalculationFunctions.Set_Function(0, nullptr);
	CalculationFunctions.Set_Function(1, Identity);
	CalculationFunctions.Set_Function(2, Bias);
	CalculationFunctions.Set_Function(3, StdBinaryOutput);
	
	CNeuralCalculationNet CalculationNet;
	CalculationNet.Initialize(3, 1, 1);
	CalculationNet.Set_InputUnit(0, 0);
	CalculationNet.Set_OutputUnit(2, 0);

	// neuronal connection scheme:

	// variant 1:

	//             InputUnit    | BiasUnit     | OutputUnit
	// ------------------------------------------------------
	// InputUnit   (x=0 y=0): 0 | (x=1 y=0): 0 | (x=2 y=0): 1   
	// BiasUnit    (x=0 y=1): 0 | (x=1 y=1): 0 | (x=2 y=1): 1   
	// OutputUnit  (x=0 y=2): 0 | (x=1 y=2): 0 | (x=2 y=2): 0

	// variant 2 (connectionID = x + NumOfCalculationUnits * y):

	//             InputUnit           | BiasUnit            | OutputUnit
	// ----------------------------------------------------------------------------
	// InputUnit   (connectionID=0): 0 | (connectionID=1): 0 | (connectionID=2): 1   
	// BiasUnit    (connectionID=3): 0 | (connectionID=4): 0 | (connectionID=5): 1   
	// OutputUnit  (connectionID=6): 0 | (connectionID=7): 0 | (connectionID=8): 0

	


	// InputUnit:
	CalculationNet.Set_CalculationFunction(0, 1, &CalculationFunctions);
	//CalculationNet.Set_CalculationFunction(0, 1, Identity);

	// BiasUnit:
	CalculationNet.Set_CalculationFunction(1, 2, &CalculationFunctions);
	//CalculationNet.Set_CalculationFunction(1, 2, Bias);

	// OutputUnit:
	CalculationNet.Set_CalculationFunction(2, 3, &CalculationFunctions);
	//CalculationNet.Set_CalculationFunction(2, 3, StdBinaryOutput);
	

	// connection: InputUnit (ID=0) -> OutputUnit (ID=2)

	// variant 1:
	CalculationNet.Set_Connection_PlasticityValue(2, 0, 1.0f);
	// variant 2:
	//CalculationNet.Set_Connection_PlasticityValue(2, 1.0f);

	// variant 1:
	CalculationNet.Activate_Connection(2, 0);
	// variant 2:
	//CalculationNet.Activate_Connection(2)


	// Input <= 0.6  => Output = 0
	// Input > 0.6 => Output = 1

	// connection: BiasUnit (ID=1) -> OutputUnit (ID=2)
	CalculationNet.Set_Connection_PlasticityValue(2, 1, -0.6f);
	CalculationNet.Activate_Connection(2, 1);


	float inputValue;
	float outputValue;
	//float inputValueArray[1];
	//float outputValueArray[1];

	inputValue = 0.0f;
	CalculationNet.Set_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl;

	inputValue = 0.5f;
	CalculationNet.Set_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl;

	inputValue = 0.6f;
	CalculationNet.Set_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl;

	inputValue = 0.75f;
	CalculationNet.Set_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl;

	inputValue = 1.0f;
	CalculationNet.Add_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl;

	inputValue = 1.5f;
	CalculationNet.Add_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl;

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CNeuralCalculationFunctions CalculationFunctions;
	CalculationFunctions.Initialize(4);
	CalculationFunctions.Set_Function(0, nullptr);
	CalculationFunctions.Set_Function(1, Identity);
	CalculationFunctions.Set_Function(2, Bias);
	CalculationFunctions.Set_Function(3, StdBinaryOutput);

	CNeuralCalculationNet CalculationNet;
	CalculationNet.Initialize(3, 1, 1);
	CalculationNet.Set_InputUnit(0, 0);
	CalculationNet.Set_OutputUnit(2, 0);

	// neuronal connection scheme:

	// variant 1:

	//             InputUnit    | BiasUnit     | OutputUnit
	// ------------------------------------------------------
	// InputUnit   (x=0 y=0): 0 | (x=1 y=0): 0 | (x=2 y=0): 1   
	// BiasUnit    (x=0 y=1): 0 | (x=1 y=1): 0 | (x=2 y=1): 1   
	// OutputUnit  (x=0 y=2): 0 | (x=1 y=2): 0 | (x=2 y=2): 0

	// variant 2 (connectionID = x + NumOfCalculationUnits * y):

	//             InputUnit           | BiasUnit            | OutputUnit
	// ----------------------------------------------------------------------------
	// InputUnit   (connectionID=0): 0 | (connectionID=1): 0 | (connectionID=2): 1   
	// BiasUnit    (connectionID=3): 0 | (connectionID=4): 0 | (connectionID=5): 1   
	// OutputUnit  (connectionID=6): 0 | (connectionID=7): 0 | (connectionID=8): 0



	// InputUnit:
	CalculationNet.Set_CalculationFunction(0, 1, &CalculationFunctions);
	//CalculationNet.Set_CalculationFunction(0, 1, Identity);

	// BiasUnit:
	CalculationNet.Set_CalculationFunction(1, 2, &CalculationFunctions);
	//CalculationNet.Set_CalculationFunction(1, 2, Bias);

	// OutputUnit:
	CalculationNet.Set_CalculationFunction(2, 3, &CalculationFunctions);
	//CalculationNet.Set_CalculationFunction(2, 3, StdBinaryOutput);


	// connection: InputUnit (ID=0) -> OutputUnit (ID=2)

	// variant 1:
	CalculationNet.Set_Connection_PlasticityValue(2, 0, -1.0f);
	// variant 2:
	//CalculationNet.Set_Connection_PlasticityValue(2, 1.0f);

	// variant 1:
	CalculationNet.Activate_Connection(2, 0);
	// variant 2:
	//CalculationNet.Activate_Connection(2)

	// Input < 0.6  => Output = 1
	// Input >= 0.6 => Output = 0

	// connection: BiasUnit (ID=1) -> OutputUnit (ID=2)
	CalculationNet.Set_Connection_PlasticityValue(2, 1, 0.6f);
	CalculationNet.Activate_Connection(2, 1);


	float inputValue;
	float outputValue;
	//float inputValueArray[1];
	//float outputValueArray[1];

	inputValue = 0.0f;
	CalculationNet.Set_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl;

	inputValue = 0.25f;
	CalculationNet.Set_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl;

	inputValue = 0.5f;
	CalculationNet.Set_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl;

	inputValue = 0.6f;
	CalculationNet.Set_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl;

	inputValue = 0.75f;
	CalculationNet.Add_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl;

	inputValue = 1.0f;
	CalculationNet.Add_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl;

	inputValue = 1.5f;
	CalculationNet.Add_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl;

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CNeuralCalculationFunctions CalculationFunctions;
	CalculationFunctions.Initialize(4);
	CalculationFunctions.Set_Function(0, nullptr);
	CalculationFunctions.Set_Function(1, Identity);
	CalculationFunctions.Set_Function(2, StdBinaryOutput);

	CNeuralCalculationNet CalculationNet;
	CalculationNet.Initialize(4, 2, 2);
	CalculationNet.Set_InputUnit(0, 0);
	CalculationNet.Set_InputUnit(1, 1);
	CalculationNet.Set_OutputUnit(2, 0);
	CalculationNet.Set_OutputUnit(3, 1);

	// neuronal connection scheme:

	// variant 1:

	//              InputUnit1   | InputUnit2   | OutputUnit1  | OutputUni2  
	// -----------------------------------------------------------------------
	// InputUnit1   (x=0 y=0): 0 | (x=1 y=0): 0 | (x=2 y=0): 1 | (x=3 y=0): 1 
	// InputUnit2   (x=0 y=1): 0 | (x=1 y=1): 0 | (x=2 y=1): 1 | (x=3 y=1): 1 
	// OutputUnit1  (x=0 y=2): 0 | (x=1 y=2): 0 | (x=2 y=2): 0 | (x=3 y=2): 0
	// OutputUnit2  (x=0 y=3): 0 | (x=1 y=3): 0 | (x=2 y=3): 0 | (x=3 y=3): 0 
	

	CCalculationUnitLayer InputLayer;
	CCalculationUnitLayer OutputLayer;

	InputLayer.Intialize(0, 2);
	OutputLayer.Intialize(2, 2);

	
	InputLayer.Set_CalculationFunctions(&CalculationNet, 1, &CalculationFunctions);
	//InputLayer.Set_CalculationFunctions(&CalculationNet, 1, Identity);

	OutputLayer.Set_CalculationFunctions(&CalculationNet, 2, &CalculationFunctions);
	//OutputLayer.Set_CalculationFunctions(&CalculationNet, 2, StdBinaryOutput);


	float PlasticityValueArray1[2] = { 1.0f, -1.0f};
	OutputLayer.Set_IncomingPlasticityValues(&CalculationNet, &InputLayer, 2, PlasticityValueArray1);

	float PlasticityValueArray2[2] = { -1.0f, 1.0f };
	OutputLayer.Set_IncomingPlasticityValues(&CalculationNet, &InputLayer, 3, PlasticityValueArray2);
	
	InputLayer.Activate_Connections_If_Possible(&CalculationNet, &OutputLayer);
	

	
	float inputValueArray[2];
	float outputValueArray[2];

	inputValueArray[0] = 2.0f;
	inputValueArray[1] = 4.0f;
	CalculationNet.Set_InputValues(inputValueArray);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(outputValueArray);

	cout << "input1: " << inputValueArray[0] << " input2: " << inputValueArray[1] << " | output1: " << outputValueArray[0] << " output2: " << outputValueArray[1] << endl;

	inputValueArray[0] = 4.0f;
	inputValueArray[1] = 4.0f;
	CalculationNet.Set_InputValues(inputValueArray);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(outputValueArray);

	cout << "input1: " << inputValueArray[0] << " input2: " << inputValueArray[1] << " | output1: " << outputValueArray[0] << " output2: " << outputValueArray[1] << endl;

	inputValueArray[0] = 9.0f;
	inputValueArray[1] = 4.0f;
	CalculationNet.Set_InputValues(inputValueArray);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(outputValueArray);

	cout << "input1: " << inputValueArray[0] << " input2: " << inputValueArray[1] << " | output1: " << outputValueArray[0] << " output2: " << outputValueArray[1] << endl;

	

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CNeuralCalculationFunctions CalculationFunctions;
	CalculationFunctions.Initialize(4);
	CalculationFunctions.Set_Function(0, nullptr);
	CalculationFunctions.Set_Function(1, Identity);
	CalculationFunctions.Set_Function(2, Bias);
	CalculationFunctions.Set_Function(3, StdBinaryOutput);

	CNeuralCalculationNet CalculationNet;
	CalculationNet.Initialize(6, 1, 1);
	CalculationNet.Set_InputUnit(0, 0);
	CalculationNet.Set_OutputUnit(5, 0);

	// neuronal connection scheme:

	//              InputUnit    | BiasUnit1    | BiasUnit2    | HiddenUnit1  | HiddenUnit2  | OutputUnit
	// -----------------------------------------------------------------------------------------------------
	// InputUnit    (x=0 y=0): 0 | (x=1 y=0): 0 | (x=2 y=0): 0 | (x=3 y=0): 1 | (x=4 y=0): 1 | (x=5 y=0): 0
	// BiasUnit1    (x=0 y=1): 0 | (x=1 y=1): 0 | (x=2 y=1): 0 | (x=3 y=1): 1 | (x=4 y=1): 0 | (x=5 y=1): 0  
	// BiasUnit2    (x=0 y=2): 0 | (x=1 y=2): 0 | (x=2 y=2): 0 | (x=3 y=2): 0 | (x=4 y=2): 1 | (x=5 y=2): 0
	// HiddenUnit1  (x=0 y=3): 0 | (x=1 y=3): 0 | (x=2 y=3): 0 | (x=3 y=3): 0 | (x=4 y=3): 0 | (x=5 y=3): 1 
	// HiddenUnit2  (x=0 y=4): 0 | (x=1 y=4): 0 | (x=2 y=4): 0 | (x=3 y=4): 0 | (x=4 y=4): 0 | (x=5 y=4): 1  
	// OutputUnit   (x=0 y=5): 0 | (x=1 y=5): 0 | (x=2 y=5): 0 | (x=3 y=5): 0 | (x=4 y=5): 0 | (x=5 y=5): 0


	CCalculationUnitLayer InputAndBiasLayer;
	CCalculationUnitLayer HiddenLayer;
	CCalculationUnitLayer OutputLayer;

	InputAndBiasLayer.Intialize(0, 3);
	HiddenLayer.Intialize(3, 2);
	OutputLayer.Intialize(5, 1);

	// InputUnit:
	InputAndBiasLayer.Set_CalculationFunction(&CalculationNet, 0, 1, &CalculationFunctions);
	//InputAndBiasLayer.Set_CalculationFunction(&CalculationNet, 0, 1, Identity);

	// BiasUnit1:
	InputAndBiasLayer.Set_BiasUnit(&CalculationNet, 1, 2, &CalculationFunctions);
	//InputAndBiasLayer.Set_BiasUnit(&CalculationNet, 1, 2, Bias);

	// BiasUnit2:
	InputAndBiasLayer.Set_BiasUnit(&CalculationNet, 2, 2, &CalculationFunctions);
	//InputAndBiasLayer.Set_BiasUnit(&CalculationNet, 2, 2, Bias);


	HiddenLayer.Set_CalculationFunctions(&CalculationNet, 3, &CalculationFunctions);
	//HiddenLayer.Set_CalculationFunctions(&CalculationNet, 3, StdBinaryOutput);


	OutputLayer.Set_CalculationFunctions(&CalculationNet, 1, &CalculationFunctions);
	//OutputLayer.Set_CalculationFunctions(&CalculationNet, 1, Identity);



	float PlasticityValueArray1[3] = { 1.0f, -0.8f, 0.0f };
	HiddenLayer.Set_IncomingPlasticityValues(&CalculationNet, &InputAndBiasLayer, 3, PlasticityValueArray1);

	float PlasticityValueArray2[3] = { 1.0f, 0.0f, -1.1f };
	HiddenLayer.Set_IncomingPlasticityValues(&CalculationNet, &InputAndBiasLayer, 4, PlasticityValueArray2);

	float PlasticityValueArray3[2] = { 1.0f, -1.0f };
	OutputLayer.Set_IncomingPlasticityValues(&CalculationNet, &HiddenLayer, 5, PlasticityValueArray3);


	InputAndBiasLayer.Activate_Connections_If_Possible(&CalculationNet, &HiddenLayer);
	HiddenLayer.Activate_Connections_If_Possible(&CalculationNet, &OutputLayer);

	float inputValue;
	float outputValue;
	//float inputValueArray[1];
	//float outputValueArray[1];

	inputValue = 0.7f;
	CalculationNet.Set_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl;

	inputValue = 0.8f;
	CalculationNet.Set_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl;

	inputValue = 0.9f;
	CalculationNet.Set_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl;

	inputValue = 1.0f;
	CalculationNet.Set_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl;

	inputValue = 1.1f;
	CalculationNet.Add_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl;

	inputValue = 1.2f;
	CalculationNet.Add_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl;

	inputValue = 1.3f;
	CalculationNet.Add_InputValues(&inputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(&outputValue);

	cout << "input: " << inputValue << " output: " << outputValue << endl;

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CNeuralCalculationFunctions CalculationFunctions;
	CalculationFunctions.Initialize(4);
	CalculationFunctions.Set_Function(0, nullptr);
	CalculationFunctions.Set_Function(1, Identity);
	//CalculationFunctions.Set_Function(2, ExpRBF);
	CalculationFunctions.Set_Function(2, BinaryRadialClusterCheck);
	CalculationFunctions.Set_Function(3, Maximum);
	
	

	CNeuralCalculationNet CalculationNet;
	CalculationNet.Initialize(8, 2, 2);
	CalculationNet.Set_InputUnit(0, 0);
	CalculationNet.Set_InputUnit(1, 1);
	CalculationNet.Set_OutputUnit(6, 0);
	CalculationNet.Set_OutputUnit(7, 1);

	// neuronal connection scheme:

	//              InputUnit1  | InputUnit2   | RBFUnit1     | RBFUnit2     | RBFUnit3     | RBFUnit4     | OutputUnit1  | OutputUnit2
	// ----------------------------------------------------------------------------------------------------------------------------------
	// InputUnit1  (x=0 y=0): 0 | (x=1 y=0): 0 | (x=2 y=0): 1 | (x=3 y=0): 1 | (x=4 y=0): 1 | (x=5 y=0): 1 | (x=6 y=0): 0 | (x=7 y=0): 0
	// InputUnit2  (x=0 y=1): 0 | (x=1 y=1): 0 | (x=2 y=1): 1 | (x=3 y=1): 1 | (x=4 y=1): 1 | (x=5 y=1): 1 | (x=6 y=1): 0 | (x=7 y=1): 0  
	// RBFUnit1    (x=0 y=2): 0 | (x=1 y=2): 0 | (x=2 y=2): 0 | (x=3 y=2): 0 | (x=4 y=2): 0 | (x=5 y=2): 0 | (x=6 y=2): 1 | (x=7 y=2): 1
	// RBFUnit2    (x=0 y=3): 0 | (x=1 y=3): 0 | (x=2 y=3): 0 | (x=3 y=3): 0 | (x=4 y=3): 0 | (x=5 y=3): 0 | (x=6 y=3): 1 | (x=7 y=3): 1 
	// RBFUnit3    (x=0 y=4): 0 | (x=1 y=4): 0 | (x=2 y=4): 0 | (x=3 y=4): 0 | (x=4 y=4): 0 | (x=5 y=4): 0 | (x=6 y=4): 1 | (x=7 y=4): 1  
	// RBFUnit4    (x=0 y=5): 0 | (x=1 y=5): 0 | (x=2 y=5): 0 | (x=3 y=5): 0 | (x=4 y=5): 0 | (x=5 y=5): 0 | (x=6 y=5): 1 | (x=7 y=5): 1  
	// OutputUnit1 (x=0 y=6): 0 | (x=1 y=6): 0 | (x=2 y=6): 0 | (x=3 y=6): 0 | (x=4 y=6): 0 | (x=5 y=6): 0 | (x=6 y=6): 0 | (x=7 y=6): 0
	// OutputUnit2 (x=0 y=7): 0 | (x=1 y=7): 0 | (x=2 y=7): 0 | (x=3 y=7): 0 | (x=4 y=7): 0 | (x=5 y=7): 0 | (x=6 y=7): 0 | (x=7 y=7): 0


	CCalculationUnitLayer InputLayer;
	CCalculationUnitLayer RBFLayer;
	CCalculationUnitLayer OutputLayer;

	InputLayer.Intialize(0, 2);
	RBFLayer.Intialize(2, 4);
	OutputLayer.Intialize(6, 2);

	
	InputLayer.Set_CalculationFunctions(&CalculationNet, 1, &CalculationFunctions);
	//InputLayer.Set_CalculationFunctions(&CalculationNet, 1, Identity);

	RBFLayer.Set_CalculationFunctions(&CalculationNet, 2, &CalculationFunctions);
	//RBFLayer.Set_CalculationFunctions(&CalculationNet, 2, ExpRBF);
	//RBFLayer.Set_CalculationFunctions(&CalculationNet, 2, BinaryRadialClusterCheck);
	

	RBFLayer.Set_PropagationFunctions(&CalculationNet, RBFPropagationFunctionID);

	OutputLayer.Set_CalculationFunctions(&CalculationNet, 1, &CalculationFunctions);
	OutputLayer.Set_CalculationFunctions(&CalculationNet, 1, Identity);

	//OutputLayer.Set_PropagationFunction(&CalculationNet, 6, StandardMaxPropagationFunctionID);
	//OutputLayer.Set_CalculationFunction(&CalculationNet, 6, 3, &CalculationFunctions);
	//OutputLayer.Set_CalculationFunction(&CalculationNet, 6, 3, Maximum);

	//OutputLayer.Set_CalculationFunction(&CalculationNet, 7, 1, &CalculationFunctions);
	//OutputLayer.Set_CalculationFunction(&CalculationNet, 7, 1, Identity);

	
	float RBFConstantArray[2] = { 10.0f, 10.0f };
	//float RBFConstantArray[2] = { 100.0f, 100.0f };
	float RBFCentroidValueArray1[2] = { 0.0f, 0.0f };
	float RBFCentroidValueArray2[2] = { 0.0f, 1.0f };
	float RBFCentroidValueArray3[2] = { 1.0f, 0.0f };
	float RBFCentroidValueArray4[2] = { 1.0f, 1.0f };

	RBFLayer.Set_IncomingRBFValues(&CalculationNet, &InputLayer, 2, RBFConstantArray, RBFCentroidValueArray1);
	RBFLayer.Set_IncomingRBFValues(&CalculationNet, &InputLayer, 3, RBFConstantArray, RBFCentroidValueArray2);
	RBFLayer.Set_IncomingRBFValues(&CalculationNet, &InputLayer, 4, RBFConstantArray, RBFCentroidValueArray3);
	RBFLayer.Set_IncomingRBFValues(&CalculationNet, &InputLayer, 5, RBFConstantArray, RBFCentroidValueArray4);

	
	// correct hit output:
	float PlasticityValueArray1[4] = { 0.0f, 1.0f, 1.0f, 0.0f };
	OutputLayer.Set_IncomingPlasticityValues(&CalculationNet, &RBFLayer, 6, PlasticityValueArray1);

	// error hit output:
	float PlasticityValueArray2[4] = { 1.0f, 0.0f, 0.0f, 1.0f };
	OutputLayer.Set_IncomingPlasticityValues(&CalculationNet, &RBFLayer, 7, PlasticityValueArray2);


	InputLayer.Activate_Connections_If_Possible(&CalculationNet, &RBFLayer);
	RBFLayer.Activate_Connections_If_Possible(&CalculationNet, &OutputLayer);
	

	float InputArray[2][2];

	InputArray[0][0] = 0.0f; InputArray[0][1] = 1.0f;
	InputArray[1][0] = 1.0f; InputArray[1][1] = 0.0f;

	float outputValueArray[2];


	//CalculationNet.Reset_CalculationUnits_SumOfOutputValues();

	for (int32_t iy = 0; iy < 2; iy++)
	{
		for (int32_t ix = 0; ix < 2; ix++)
		{
			float value = InputArray[iy][ix];

			if (value > 0.0f)
			{
				CalculationNet.Set_InputValue(static_cast<float>(ix), 0);
				CalculationNet.Set_InputValue(static_cast<float>(iy), 1);
				CalculationNet.Execute_Calculations();
				CalculationNet.Get_OutputValues(outputValueArray);

				cout << "input1: " << ix << " input2: " << iy << endl;

				cout << "correct hit: " << outputValueArray[0] << " error hit: " << outputValueArray[1] << endl;
			}
		}
	}

	cout << endl << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CNeuralCalculationFunctions CalculationFunctions;
	CalculationFunctions.Initialize(4);
	CalculationFunctions.Set_Function(0, nullptr);
	CalculationFunctions.Set_Function(1, Identity);
	//CalculationFunctions.Set_Function(2, ExpRBF);
	CalculationFunctions.Set_Function(2, BinaryRadialClusterCheck);
	CalculationFunctions.Set_Function(3, SumUp);

	CNeuralCalculationNet CalculationNet;
	CalculationNet.Initialize(8, 2, 2);
	CalculationNet.Set_InputUnit(0, 0);
	CalculationNet.Set_InputUnit(1, 1);
	CalculationNet.Set_OutputUnit(6, 0);
	CalculationNet.Set_OutputUnit(7, 1);

	// neuronal connection scheme:

	//              InputUnit1  | InputUnit2   | RBFUnit1     | RBFUnit2     | RBFUnit3     | RBFUnit4     | OutputUnit1  | OutputUnit2
	// ----------------------------------------------------------------------------------------------------------------------------------
	// InputUnit1  (x=0 y=0): 0 | (x=1 y=0): 0 | (x=2 y=0): 1 | (x=3 y=0): 1 | (x=4 y=0): 1 | (x=5 y=0): 1 | (x=6 y=0): 0 | (x=7 y=0): 0
	// InputUnit2  (x=0 y=1): 0 | (x=1 y=1): 0 | (x=2 y=1): 1 | (x=3 y=1): 1 | (x=4 y=1): 1 | (x=5 y=1): 1 | (x=6 y=1): 0 | (x=7 y=1): 0  
	// RBFUnit1    (x=0 y=2): 0 | (x=1 y=2): 0 | (x=2 y=2): 0 | (x=3 y=2): 0 | (x=4 y=2): 0 | (x=5 y=2): 0 | (x=6 y=2): 1 | (x=7 y=2): 1
	// RBFUnit2    (x=0 y=3): 0 | (x=1 y=3): 0 | (x=2 y=3): 0 | (x=3 y=3): 0 | (x=4 y=3): 0 | (x=5 y=3): 0 | (x=6 y=3): 1 | (x=7 y=3): 1 
	// RBFUnit3    (x=0 y=4): 0 | (x=1 y=4): 0 | (x=2 y=4): 0 | (x=3 y=4): 0 | (x=4 y=4): 0 | (x=5 y=4): 0 | (x=6 y=4): 1 | (x=7 y=4): 1  
	// RBFUnit4    (x=0 y=5): 0 | (x=1 y=5): 0 | (x=2 y=5): 0 | (x=3 y=5): 0 | (x=4 y=5): 0 | (x=5 y=5): 0 | (x=6 y=5): 1 | (x=7 y=5): 1  
	// OutputUnit1 (x=0 y=6): 0 | (x=1 y=6): 0 | (x=2 y=6): 0 | (x=3 y=6): 0 | (x=4 y=6): 0 | (x=5 y=6): 0 | (x=6 y=6): 0 | (x=7 y=6): 0
	// OutputUnit2 (x=0 y=7): 0 | (x=1 y=7): 0 | (x=2 y=7): 0 | (x=3 y=7): 0 | (x=4 y=7): 0 | (x=5 y=7): 0 | (x=6 y=7): 0 | (x=7 y=7): 0


	CCalculationUnitLayer InputLayer;
	CCalculationUnitLayer RBFLayer;
	CCalculationUnitLayer OutputLayer;

	InputLayer.Intialize(0, 2);
	RBFLayer.Intialize(2, 4);
	OutputLayer.Intialize(6, 2);


	InputLayer.Set_CalculationFunctions(&CalculationNet, 1, &CalculationFunctions);
	//InputLayer.Set_CalculationFunctions(&CalculationNet, 1, Identity);

	RBFLayer.Set_CalculationFunctions(&CalculationNet, 2, &CalculationFunctions);
	//RBFLayer.Set_CalculationFunctions(&CalculationNet, 2, ExpRBF);
	//RBFLayer.Set_CalculationFunctions(&CalculationNet, 2, BinaryRadialClusterCheck);


	RBFLayer.Set_PropagationFunctions(&CalculationNet, RBFPropagationFunctionID);

	OutputLayer.Set_CalculationFunctions(&CalculationNet, 3, &CalculationFunctions);
	//OutputLayer.Set_CalculationFunctions(&CalculationNet, 3, SumUp);



	float RBFConstantArray[2] = { 100.0f, 100.0f };
	float RBFCentroidValueArray1[2] = { 0.0f, 0.0f };
	float RBFCentroidValueArray2[2] = { 0.0f, 1.0f };
	float RBFCentroidValueArray3[2] = { 1.0f, 0.0f };
	float RBFCentroidValueArray4[2] = { 1.0f, 1.0f };

	RBFLayer.Set_IncomingRBFValues(&CalculationNet, &InputLayer, 2, RBFConstantArray, RBFCentroidValueArray1);
	RBFLayer.Set_IncomingRBFValues(&CalculationNet, &InputLayer, 3, RBFConstantArray, RBFCentroidValueArray2);
	RBFLayer.Set_IncomingRBFValues(&CalculationNet, &InputLayer, 4, RBFConstantArray, RBFCentroidValueArray3);
	RBFLayer.Set_IncomingRBFValues(&CalculationNet, &InputLayer, 5, RBFConstantArray, RBFCentroidValueArray4);


	// correct hit output:
	float PlasticityValueArray1[4] = { 0.0f, 1.0f, 1.0f, 0.0f };
	OutputLayer.Set_IncomingPlasticityValues(&CalculationNet, &RBFLayer, 6, PlasticityValueArray1);

	// error hit output:
	float PlasticityValueArray2[4] = { 1.0f, 0.0f, 0.0f, 1.0f };
	OutputLayer.Set_IncomingPlasticityValues(&CalculationNet, &RBFLayer, 7, PlasticityValueArray2);



	InputLayer.Activate_Connections_If_Possible(&CalculationNet, &RBFLayer);
	RBFLayer.Activate_Connections_If_Possible(&CalculationNet, &OutputLayer);


	float InputArray[2][2];

	InputArray[0][0] = 0.0f; InputArray[0][1] = 1.0f;
	InputArray[1][0] = 1.0f; InputArray[1][1] = 0.0f;

	float outputValueArray[2];


	CalculationNet.Reset_OutputUnits_OutputValue();
	//CalculationNet.Reset_CalculationUnits_SumOfOutputValues();

	for (int32_t iy = 0; iy < 2; iy++)
	{
		for (int32_t ix = 0; ix < 2; ix++)
		{
			float value = InputArray[iy][ix];

			if (value > 0.0f)
			{
				CalculationNet.Set_InputValue(static_cast<float>(ix), 0);
				CalculationNet.Set_InputValue(static_cast<float>(iy), 1);
				CalculationNet.Execute_Calculations();
			}
		}
	}

	CalculationNet.Get_OutputValues(outputValueArray);

	cout << "correct hits: " << outputValueArray[0] << " error hits: " << outputValueArray[1] << endl;

	// output of these calculation units must be 0 (because of InputArray[0][0] = 0.0f; and InputArray[1][1] = 0.0f;):
	int32_t UnitIDArray1[2] = { 2, 5 };
	cout << CalculationNet.Get_CalculationUnit_With_MinSumOfOutputValues(nullptr, UnitIDArray1, 2) << " " << CalculationNet.Get_CalculationUnit_With_MaxSumOfOutputValues(nullptr, UnitIDArray1, 2) << endl;

	// output of these calculation units must be 1 (because of InputArray[0][1] = 1.0f; and InputArray[1][0] = 1.0f;):
	int32_t UnitIDArray2[2] = { 3, 4 };
	cout << CalculationNet.Get_CalculationUnit_With_MinSumOfOutputValues(nullptr, UnitIDArray2, 2) << " " << CalculationNet.Get_CalculationUnit_With_MaxSumOfOutputValues(nullptr, UnitIDArray2, 2) << endl;

	cout << endl << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/



/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	float InputArray1[2] = { 0.0f, 0.0f };
	float InputArray2[2] = { 1.0f, 0.0f };
	float InputArray3[2] = { 0.0f, 1.0f };
	float InputArray4[2] = { 1.0f, 1.0f };
	float InputArray5[2] = { 0.5f, 0.5f };

	static constexpr int32_t ConstNumOfInputArrays = 5;

	float* pInputArrayPointer[ConstNumOfInputArrays];

	pInputArrayPointer[0] = InputArray1;
	pInputArrayPointer[1] = InputArray2;
	pInputArrayPointer[2] = InputArray3;
	pInputArrayPointer[3] = InputArray4;
	pInputArrayPointer[4] = InputArray5;

	float DesiredXOROutputArray[ConstNumOfInputArrays] = { 0.0f, 1.0f, 1.0f, 0.0f, 0.0f };


	CNeuralCalculationFunctions CalculationFunctions;
	CalculationFunctions.Initialize(4);
	CalculationFunctions.Set_Function(0, nullptr);
	CalculationFunctions.Set_Function(1, Identity);
	CalculationFunctions.Set_Function(2, Bias);
	CalculationFunctions.Set_Function(3, TanH);

	static constexpr int32_t NumOfInputUnits = 2;
	static constexpr int32_t NumOfInputAndBiasUnits = NumOfInputUnits + 1;
	static constexpr int32_t NumOfHiddenUnits = 5;
	static constexpr int32_t NumOfOutputUnits = 1;
	static constexpr int32_t NumOfCalculationUnits = NumOfInputAndBiasUnits + NumOfHiddenUnits + NumOfOutputUnits;

	int32_t idOfFirstInputUnit = 0;
	int32_t idOfBiasUnit = NumOfInputUnits;
	int32_t idOfFirstHiddenUnit = NumOfInputAndBiasUnits;
	int32_t idOfFirstOutputUnit = idOfFirstHiddenUnit + NumOfHiddenUnits;

	CNeuralCalculationNet CalculationNet;
	CalculationNet.Initialize(NumOfCalculationUnits, NumOfInputUnits, NumOfOutputUnits);
	CalculationNet.Set_InputUnit(0, 0);
	CalculationNet.Set_InputUnit(1, 1);
	CalculationNet.Set_OutputUnit(idOfFirstOutputUnit, 0);
	

	//////////////

	CCalculationUnitLayer InputAndBiasLayer;
	CCalculationUnitLayer HiddenLayer;
	CCalculationUnitLayer OutputLayer;

	InputAndBiasLayer.Intialize(idOfFirstInputUnit, NumOfInputAndBiasUnits);
	HiddenLayer.Intialize(idOfFirstHiddenUnit, NumOfHiddenUnits);
	OutputLayer.Intialize(idOfFirstOutputUnit, NumOfOutputUnits);

	// InputUnit:
	InputAndBiasLayer.Set_CalculationFunctions(&CalculationNet, 1, &CalculationFunctions);
	//InputAndBiasLayer.Set_CalculationFunctions(&CalculationNet, 1, Identity);

	// BiasUnit1:
	InputAndBiasLayer.Set_BiasUnit(&CalculationNet, idOfBiasUnit, 2, &CalculationFunctions);
	//InputAndBiasLayer.Set_BiasUnit(&CalculationNet, idOfBiasUnit, 2, Bias);

	
	HiddenLayer.Set_CalculationFunctions(&CalculationNet, 3, &CalculationFunctions);
	//HiddenLayer.Set_CalculationFunctions(&CalculationNet, 3, TanH);


	OutputLayer.Set_CalculationFunctions(&CalculationNet, 1, &CalculationFunctions);
	OutputLayer.Set_CalculationFunctions(&CalculationNet, 1, Identity);
	//OutputLayer.Set_CalculationFunctions(&CalculationNet, 3, &CalculationFunctions);
	//OutputLayer.Set_CalculationFunctions(&CalculationNet, 3, TanH);


	float minRandomPlasticity = -2.0f;
	float maxRandomPlasticity = 2.0f;

	float PlasticityArray_InputToHiddenLayer[NumOfInputAndBiasUnits];
	float PlasticityArray_HiddenToOutputLayer[NumOfHiddenUnits];

	//for (int32_t i = idOfFirstHiddenUnit; i < idOfFirstOutputUnit; i++)
	for (int32_t i = HiddenLayer.FirstUnitID; i < HiddenLayer.LastUnitIDPlus1; i++)
	{
		for (int32_t j = 0; j < NumOfInputAndBiasUnits; j++)
		{
			PlasticityArray_InputToHiddenLayer[j] = RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
		}

		HiddenLayer.Set_IncomingPlasticityValues(&CalculationNet, &InputAndBiasLayer, i, PlasticityArray_InputToHiddenLayer);
	}
	

	for (int32_t j = 0; j < NumOfHiddenUnits; j++)
	{
		PlasticityArray_HiddenToOutputLayer[j] = RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
	}

	OutputLayer.Set_IncomingPlasticityValues(&CalculationNet, &HiddenLayer, idOfFirstOutputUnit, PlasticityArray_HiddenToOutputLayer);


	InputAndBiasLayer.Activate_Connections_If_Possible(&CalculationNet, &HiddenLayer);
	HiddenLayer.Activate_Connections_If_Possible(&CalculationNet, &OutputLayer);


	float outputValue;
	//float outputValueArray[1];

	float learningRate = 0.1f;
	//float learningRate = 0.2f;
	float errorFactor1 = 1.0f;
	float errorFactor2 = 1.0f;

	int32_t maxCount = 100000;
	int32_t epoch = 0;
	float errorSum;

	for (int32_t j = 0; j < maxCount; j++)
	{
		epoch++;
		errorSum = 0.0f;

		for (int32_t i = 0; i < ConstNumOfInputArrays; i++)
		{
			CalculationNet.Set_InputValues(pInputArrayPointer[i]);
			CalculationNet.Execute_Calculations();

			errorSum += CalculationNet.Calculate_OutputVarianceSum_And_OutputError(&DesiredXOROutputArray[i], errorFactor1, errorFactor2);

			CalculationNet.Learning(learningRate, errorFactor1, errorFactor2);
			//CalculationNet.ExtremeLearning(learningRate);
		}

		if (j % 50 == 0)
		{
			cout << "error: " << errorSum << endl;
		}

		if (errorSum < 0.0005f)
			break;
	}

	// training completed

	// training statistics:


	cout << endl << "epoch: " << epoch << endl;
	cout << "error: " << errorSum << endl << endl;

	cout << endl;

	//getchar();

	
	for (int32_t i = 0; i < ConstNumOfInputArrays; i++)
	{
		CalculationNet.Set_InputValues(pInputArrayPointer[i]);
		CalculationNet.Execute_Calculations();
		CalculationNet.Get_OutputValues(&outputValue);

		cout << "input values: " << pInputArrayPointer[i][0] << " " << pInputArrayPointer[i][1] << endl;
		cout << "activation value: " << outputValue << endl << endl;
	}

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	static constexpr int32_t ConstNumOfInputs = 8;

	float InputValueArray[ConstNumOfInputs] = { 0.0f, 0.25f, 0.5f, 0.75f, 1.0f, 0.3f, 0.6f, 0.85f };


	float OutputArray1[4] = { 1.0f, 0.0f, 0.0f, 0.0f };
	float OutputArray2[4] = { 0.0f, 1.0f, 0.0f, 0.0f };
	float OutputArray3[4] = { 0.0f, 0.5f, 0.5f, 0.0f };
	float OutputArray4[4] = { 0.0f, 0.0f, 1.0f, 0.0f };
	float OutputArray5[4] = { 0.0f, 0.0f, 0.0f, 1.0f };

	float OutputArray6[4] = { 0.0f, 0.8f, 0.2f, 0.0f };
	float OutputArray7[4] = { 0.0f, 0.3f, 0.6f, 0.0f };
	float OutputArray8[4] = { 0.0f, 0.0f, 0.2f, 0.9f };

	float* pOutputArrayPointer[ConstNumOfInputs];

	pOutputArrayPointer[0] = OutputArray1;
	pOutputArrayPointer[1] = OutputArray2;
	pOutputArrayPointer[2] = OutputArray3;
	pOutputArrayPointer[3] = OutputArray4;
	pOutputArrayPointer[4] = OutputArray5;
	pOutputArrayPointer[5] = OutputArray6;
	pOutputArrayPointer[6] = OutputArray7;
	pOutputArrayPointer[7] = OutputArray8;


	CNeuralCalculationFunctions CalculationFunctions;
	CalculationFunctions.Initialize(4);
	CalculationFunctions.Set_Function(0, nullptr);
	CalculationFunctions.Set_Function(1, Identity);
	CalculationFunctions.Set_Function(2, Bias);
	CalculationFunctions.Set_Function(3, TanH);

	static constexpr int32_t NumOfInputUnits = 1;
	static constexpr int32_t NumOfInputAndBiasUnits = NumOfInputUnits + 1;
	static constexpr int32_t NumOfHiddenUnits = 15;
	static constexpr int32_t NumOfOutputUnits = 4;
	static constexpr int32_t NumOfCalculationUnits = NumOfInputAndBiasUnits + NumOfHiddenUnits + NumOfOutputUnits;

	int32_t idOfFirstInputUnit = 0;
	int32_t idOfBiasUnit = NumOfInputUnits;
	int32_t idOfFirstHiddenUnit = NumOfInputAndBiasUnits;
	int32_t idOfFirstOutputUnit = idOfFirstHiddenUnit + NumOfHiddenUnits;

	CNeuralCalculationNet CalculationNet;
	CalculationNet.Initialize(NumOfCalculationUnits, NumOfInputUnits, NumOfOutputUnits);
	CalculationNet.Set_InputUnit(0, 0);
	CalculationNet.Set_OutputUnit(idOfFirstOutputUnit, 0);
	CalculationNet.Set_OutputUnit(idOfFirstOutputUnit + 1, 1);
	CalculationNet.Set_OutputUnit(idOfFirstOutputUnit + 2, 2);
	CalculationNet.Set_OutputUnit(idOfFirstOutputUnit + 3, 3);


	//////////////

	CCalculationUnitLayer InputAndBiasLayer;
	CCalculationUnitLayer HiddenLayer;
	CCalculationUnitLayer OutputLayer;

	InputAndBiasLayer.Intialize(idOfFirstInputUnit, NumOfInputAndBiasUnits);
	HiddenLayer.Intialize(idOfFirstHiddenUnit, NumOfHiddenUnits);
	OutputLayer.Intialize(idOfFirstOutputUnit, NumOfOutputUnits);

	// InputUnit:
	InputAndBiasLayer.Set_CalculationFunctions(&CalculationNet, 1, &CalculationFunctions);
	//InputAndBiasLayer.Set_CalculationFunctions(&CalculationNet, 1, Identity);

	// BiasUnit1:
	InputAndBiasLayer.Set_BiasUnit(&CalculationNet, idOfBiasUnit, 2, &CalculationFunctions);
	//InputAndBiasLayer.Set_BiasUnit(&CalculationNet, idOfBiasUnit, 2, Bias);


	HiddenLayer.Set_CalculationFunctions(&CalculationNet, 3, &CalculationFunctions);
	//HiddenLayer.Set_CalculationFunctions(&CalculationNet, 3, TanH);


	OutputLayer.Set_CalculationFunctions(&CalculationNet, 1, &CalculationFunctions);
	OutputLayer.Set_CalculationFunctions(&CalculationNet, 1, Identity);
	//OutputLayer.Set_CalculationFunctions(&CalculationNet, 3, &CalculationFunctions);
	//OutputLayer.Set_CalculationFunctions(&CalculationNet, 3, TanH);


	float minRandomPlasticity = -2.0f;
	float maxRandomPlasticity = 2.0f;

	float PlasticityArray_InputToHiddenLayer[NumOfInputAndBiasUnits];
	float PlasticityArray_HiddenToOutputLayer[NumOfHiddenUnits];

	//for (int32_t i = idOfFirstHiddenUnit; i < idOfFirstOutputUnit; i++)
	for (int32_t i = HiddenLayer.FirstUnitID; i < HiddenLayer.LastUnitIDPlus1; i++)
	{
		for (int32_t j = 0; j < NumOfInputAndBiasUnits; j++)
		{
			PlasticityArray_InputToHiddenLayer[j] = RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
		}

		HiddenLayer.Set_IncomingPlasticityValues(&CalculationNet, &InputAndBiasLayer, i, PlasticityArray_InputToHiddenLayer);
	}

	//int32_t lastOutputUnitIDPlus1 = idOfFirstOutputUnit + NumOfOutputUnits;
	//for (int32_t i = idOfFirstOutputUnit; i < lastOutputUnitIDPlus1; i++)
	for (int32_t i = OutputLayer.FirstUnitID; i < OutputLayer.LastUnitIDPlus1; i++)
	{
		for (int32_t j = 0; j < NumOfHiddenUnits; j++)
		{
			PlasticityArray_HiddenToOutputLayer[j] = RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
		}

		OutputLayer.Set_IncomingPlasticityValues(&CalculationNet, &HiddenLayer, i, PlasticityArray_HiddenToOutputLayer);
	}

	InputAndBiasLayer.Activate_Connections_If_Possible(&CalculationNet, &HiddenLayer);
	HiddenLayer.Activate_Connections_If_Possible(&CalculationNet, &OutputLayer);
	
	float outputValueArray[4];

	float learningRate = 0.1f;
	//float learningRate = 0.2f;
	float errorFactor1 = 1.0f;
	float errorFactor2 = 1.0f;

	int32_t maxCount = 100000;
	int32_t epoch = 0;
	float errorSum;

	for (int32_t j = 0; j < maxCount; j++)
	{
		epoch++;
		errorSum = 0.0f;

		for (int32_t i = 0; i < ConstNumOfInputs; i++)
		{
			CalculationNet.Set_InputValue(InputValueArray[i]);
			CalculationNet.Execute_Calculations();

			errorSum += CalculationNet.Calculate_OutputVarianceSum_And_OutputError(pOutputArrayPointer[i], errorFactor1, errorFactor2);

			CalculationNet.Learning(learningRate, errorFactor1, errorFactor2);
			//CalculationNet.ExtremeLearning(learningRate);
		}

		if (j % 50 == 0)
		{
			cout << "error: " << errorSum << endl;
		}

		if (errorSum < 0.0005f)
			break;
	}

	// training completed

	// training statistics:


	cout << endl << "epoch: " << epoch << endl;
	cout << "error: " << errorSum << endl << endl;

	cout << endl;

	//getchar();


	for (int32_t i = 0; i < ConstNumOfInputs; i++)
	{
		CalculationNet.Set_InputValue(InputValueArray[i]);
		CalculationNet.Execute_Calculations();
		CalculationNet.Get_OutputValues(outputValueArray);

		cout << "input: " << InputValueArray[i] << endl;
		cout << "outputs: " << outputValueArray[0] << " "
			                << outputValueArray[1] << " "
			                << outputValueArray[2] << " "
			                << outputValueArray[3] << " " << endl << endl;
	}

	float additionalInputValue = 0.35f;
	CalculationNet.Set_InputValue(additionalInputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(outputValueArray);

	cout << "input: " << additionalInputValue << endl;
	cout << "outputs: " << outputValueArray[0] << " "
		<< outputValueArray[1] << " "
		<< outputValueArray[2] << " "
		<< outputValueArray[3] << " " << endl << endl;

	additionalInputValue = 0.65f;
	CalculationNet.Set_InputValue(additionalInputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(outputValueArray);

	cout << "input: " << additionalInputValue << endl;
	cout << "outputs: " << outputValueArray[0] << " "
		<< outputValueArray[1] << " "
		<< outputValueArray[2] << " "
		<< outputValueArray[3] << " " << endl << endl;

	additionalInputValue = 0.83f;
	CalculationNet.Set_InputValue(additionalInputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(outputValueArray);

	cout << "input: " << additionalInputValue << endl;
	cout << "outputs: " << outputValueArray[0] << " "
		<< outputValueArray[1] << " "
		<< outputValueArray[2] << " "
		<< outputValueArray[3] << " " << endl << endl;


	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	float InputArray1[2] = { 0.0f, 0.0f };
	float InputArray2[2] = { 1.0f, 0.0f };
	float InputArray3[2] = { 0.0f, 1.0f };
	float InputArray4[2] = { 1.0f, 1.0f };
	float InputArray5[2] = { 0.5f, 0.5f };

	static constexpr int32_t ConstNumOfInputArrays = 5;

	float* pInputArrayPointer[ConstNumOfInputArrays];

	pInputArrayPointer[0] = InputArray1;
	pInputArrayPointer[1] = InputArray2;
	pInputArrayPointer[2] = InputArray3;
	pInputArrayPointer[3] = InputArray4;
	pInputArrayPointer[4] = InputArray5;

	float DesiredXOROutputArray[ConstNumOfInputArrays] = { 0.0f, 1.0f, 1.0f, 0.0f, 0.0f };


	CNeuralCalculationFunctions CalculationFunctions;
	CalculationFunctions.Initialize(4);
	CalculationFunctions.Set_Function(0, nullptr);
	CalculationFunctions.Set_Function(1, Identity);
	CalculationFunctions.Set_Function(2, Bias);
	CalculationFunctions.Set_Function(3, TanH);

	static constexpr int32_t NumOfInputUnits = 2;
	static constexpr int32_t NumOfInputAndBiasUnits = NumOfInputUnits + 1;
	static constexpr int32_t NumOfHiddenUnitsL1 = 5;
	//static constexpr int32_t NumOfHiddenUnitsL2 = 5;
	static constexpr int32_t NumOfHiddenUnitsL2 = 4;
	static constexpr int32_t NumOfOutputUnits = 1;
	static constexpr int32_t NumOfCalculationUnits = NumOfInputAndBiasUnits + NumOfHiddenUnitsL1 + NumOfHiddenUnitsL2 + NumOfOutputUnits;

	int32_t idOfFirstInputUnit = 0;
	int32_t idOfBiasUnit = NumOfInputUnits;
	int32_t idOfFirstHiddenUnitL1 = NumOfInputAndBiasUnits;
	int32_t idOfFirstHiddenUnitL2 = idOfFirstHiddenUnitL1 + NumOfHiddenUnitsL1;
	int32_t idOfFirstOutputUnit = idOfFirstHiddenUnitL2 + NumOfHiddenUnitsL2;

	CNeuralCalculationNet CalculationNet;
	CalculationNet.Initialize(NumOfCalculationUnits, NumOfInputUnits, NumOfOutputUnits);
	CalculationNet.Set_InputUnit(0, 0);
	CalculationNet.Set_InputUnit(1, 1);
	CalculationNet.Set_OutputUnit(idOfFirstOutputUnit, 0);


	//////////////

	CCalculationUnitLayer InputAndBiasLayer;
	CCalculationUnitLayer HiddenLayer1;
	CCalculationUnitLayer HiddenLayer2;
	CCalculationUnitLayer OutputLayer;

	InputAndBiasLayer.Intialize(idOfFirstInputUnit, NumOfInputAndBiasUnits);
	HiddenLayer1.Intialize(idOfFirstHiddenUnitL1, NumOfHiddenUnitsL1);
	HiddenLayer2.Intialize(idOfFirstHiddenUnitL2, NumOfHiddenUnitsL2);
	OutputLayer.Intialize(idOfFirstOutputUnit, NumOfOutputUnits);

	// InputUnit:
	InputAndBiasLayer.Set_CalculationFunctions(&CalculationNet, 1, &CalculationFunctions);
	//InputAndBiasLayer.Set_CalculationFunctions(&CalculationNet, 1, Identity);

	// BiasUnit1:
	InputAndBiasLayer.Set_BiasUnit(&CalculationNet, idOfBiasUnit, 2, &CalculationFunctions);
	//InputAndBiasLayer.Set_BiasUnit(&CalculationNet, idOfBiasUnit, 2, Bias);


	HiddenLayer1.Set_CalculationFunctions(&CalculationNet, 3, &CalculationFunctions);
	//HiddenLayer1.Set_CalculationFunctions(&CalculationNet, 3, TanH);

	HiddenLayer2.Set_CalculationFunctions(&CalculationNet, 3, &CalculationFunctions);
	//HiddenLayer2.Set_CalculationFunctions(&CalculationNet, 3, TanH);


	OutputLayer.Set_CalculationFunctions(&CalculationNet, 1, &CalculationFunctions);
	OutputLayer.Set_CalculationFunctions(&CalculationNet, 1, Identity);
	//OutputLayer.Set_CalculationFunctions(&CalculationNet, 3, &CalculationFunctions);
	//OutputLayer.Set_CalculationFunctions(&CalculationNet, 3, TanH);


	float minRandomPlasticity = -2.0f;
	float maxRandomPlasticity = 2.0f;

	float PlasticityArray_InputToHidden1Layer[NumOfInputAndBiasUnits];
	float PlasticityArray_Hidden1ToHidden2Layer[NumOfHiddenUnitsL1];
	float PlasticityArray_Hidden2ToOutputLayer[NumOfHiddenUnitsL2];

	for (int32_t i = idOfFirstHiddenUnitL1; i < idOfFirstHiddenUnitL2; i++)
	{
		for (int32_t j = 0; j < NumOfInputAndBiasUnits; j++)
		{
			PlasticityArray_InputToHidden1Layer[j] = RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
		}

		HiddenLayer1.Set_IncomingPlasticityValues(&CalculationNet, &InputAndBiasLayer, i, PlasticityArray_InputToHidden1Layer);
	}

	for (int32_t i = idOfFirstHiddenUnitL2; i < idOfFirstOutputUnit; i++)
	{
		for (int32_t j = 0; j < NumOfHiddenUnitsL1; j++)
		{
			PlasticityArray_Hidden1ToHidden2Layer[j] = RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
		}

		HiddenLayer2.Set_IncomingPlasticityValues(&CalculationNet, &HiddenLayer1, i, PlasticityArray_Hidden1ToHidden2Layer);
	}


	for (int32_t j = 0; j < NumOfHiddenUnitsL2; j++)
	{
		PlasticityArray_Hidden2ToOutputLayer[j] = RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
	}

	OutputLayer.Set_IncomingPlasticityValues(&CalculationNet, &HiddenLayer2, idOfFirstOutputUnit, PlasticityArray_Hidden2ToOutputLayer);


	InputAndBiasLayer.Activate_Connections_If_Possible(&CalculationNet, &HiddenLayer1);
	HiddenLayer1.Activate_Connections_If_Possible(&CalculationNet, &HiddenLayer2);
	HiddenLayer2.Activate_Connections_If_Possible(&CalculationNet, &OutputLayer);

	float outputValue;
	//float outputValueArray[1];

	float learningRate = 0.1f;
	//float learningRate = 0.2f;
	float errorFactor1 = 1.0f;
	float errorFactor2 = 1.0f;

	int32_t maxCount = 4000;
	int32_t epoch = 0;
	float errorSum;

	for (int32_t j = 0; j < maxCount; j++)
	{
		epoch++;
		errorSum = 0.0f;

		for (int32_t i = 0; i < ConstNumOfInputArrays; i++)
		{
			CalculationNet.Set_InputValues(pInputArrayPointer[i]);
			CalculationNet.Execute_Calculations();

			errorSum += CalculationNet.Calculate_OutputVarianceSum_And_OutputError(&DesiredXOROutputArray[i], errorFactor1, errorFactor2);

			CalculationNet.Learning(learningRate, errorFactor1, errorFactor2);
		}

		if (j % 50 == 0)
		{
			cout << "error: " << errorSum << endl;
		}

		if (errorSum < 0.0005f)
			break;
	}

	// training completed

	// training statistics:


	cout << endl << "epoch: " << epoch << endl;
	cout << "error: " << errorSum << endl << endl;

	cout << endl;

	//getchar();

	for (int32_t i = 0; i < ConstNumOfInputArrays; i++)
	{
		CalculationNet.Set_InputValues(pInputArrayPointer[i]);
		CalculationNet.Execute_Calculations();
		CalculationNet.Get_OutputValues(&outputValue);

		cout << "input values: " << pInputArrayPointer[i][0] << " " << pInputArrayPointer[i][1] << endl;
		cout << "activation value: " << outputValue << endl << endl;
	}

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	static constexpr int32_t ConstNumOfInputs = 8;

	//float InputValueArray[ConstNumOfInputs] = { 0.0f, 0.25f, 0.5f, 0.75f, 1.0f, 0.3f, 0.6f, 0.85f };

	float InputValueArray[ConstNumOfInputs] = { -0.2f, 0.0f, 0.3f, 0.5f, 0.6f, 0.75f, 1.0f, 1.2f };


	//float OutputArray1[4] = { 1.0f, 0.0f, 0.0f, 0.0f };
	//float OutputArray2[4] = { 0.0f, 1.0f, 0.0f, 0.0f };
	//float OutputArray3[4] = { 0.0f, 0.5f, 0.5f, 0.0f };
	//float OutputArray4[4] = { 0.0f, 0.0f, 1.0f, 0.0f };
	//float OutputArray5[4] = { 0.0f, 0.0f, 0.0f, 1.0f };
	//float OutputArray6[4] = { 0.0f, 0.8f, 0.2f, 0.0f };
	//float OutputArray7[4] = { 0.0f, 0.3f, 0.6f, 0.0f };
	//float OutputArray8[4] = { 0.0f, 0.0f, 0.2f, 0.9f };

	float OutputArray1[4] = { 1.0f, 0.0f, 0.0f, 0.0f };
	float OutputArray2[4] = { 1.0f, 0.0f, 0.0f, 0.0f };
	float OutputArray3[4] = { 0.0f, 1.0f, 0.0f, 0.0f };
	float OutputArray4[4] = { 0.0f, 0.6f, 0.3f, 0.0f };
	float OutputArray5[4] = { 0.0f, 0.5f, 0.7f, 1.0f };
	float OutputArray6[4] = { 0.0f, 0.0f, 1.0f, 0.0f };
	float OutputArray7[4] = { 0.0f, 0.0f, 0.0f, 1.0f };
	float OutputArray8[4] = { 0.0f, 0.0f, 0.0f, 1.0f };


	float* pOutputArrayPointer[ConstNumOfInputs];

	pOutputArrayPointer[0] = OutputArray1;
	pOutputArrayPointer[1] = OutputArray2;
	pOutputArrayPointer[2] = OutputArray3;
	pOutputArrayPointer[3] = OutputArray4;
	pOutputArrayPointer[4] = OutputArray5;
	pOutputArrayPointer[5] = OutputArray6;
	pOutputArrayPointer[6] = OutputArray7;
	pOutputArrayPointer[7] = OutputArray8;


	CNeuralCalculationFunctions CalculationFunctions;
	CalculationFunctions.Initialize(4);
	CalculationFunctions.Set_Function(0, nullptr);
	CalculationFunctions.Set_Function(1, Identity);
	CalculationFunctions.Set_Function(2, Bias);
	CalculationFunctions.Set_Function(3, TanH);

	static constexpr int32_t NumOfInputUnits = 1;
	static constexpr int32_t NumOfInputAndBiasUnits = NumOfInputUnits + 1;
	static constexpr int32_t NumOfHiddenUnitsL1 = 6;
	static constexpr int32_t NumOfHiddenUnitsL2 = 7;
	static constexpr int32_t NumOfOutputUnits = 4;
	static constexpr int32_t NumOfCalculationUnits = NumOfInputAndBiasUnits + NumOfHiddenUnitsL1 + NumOfHiddenUnitsL2 + NumOfOutputUnits;

	int32_t idOfFirstInputUnit = 0;
	int32_t idOfBiasUnit = NumOfInputUnits;
	int32_t idOfFirstHiddenUnitL1 = NumOfInputAndBiasUnits;
	int32_t idOfFirstHiddenUnitL2 = idOfFirstHiddenUnitL1 + NumOfHiddenUnitsL1;
	int32_t idOfFirstOutputUnit = idOfFirstHiddenUnitL2 + NumOfHiddenUnitsL2;



	CNeuralCalculationNet CalculationNet;
	CalculationNet.Initialize(NumOfCalculationUnits, NumOfInputUnits, NumOfOutputUnits);
	CalculationNet.Set_InputUnit(0, 0);
	CalculationNet.Set_OutputUnit(idOfFirstOutputUnit, 0);
	CalculationNet.Set_OutputUnit(idOfFirstOutputUnit + 1, 1);
	CalculationNet.Set_OutputUnit(idOfFirstOutputUnit + 2, 2);
	CalculationNet.Set_OutputUnit(idOfFirstOutputUnit + 3, 3);


	//////////////

	CCalculationUnitLayer InputAndBiasLayer;
	CCalculationUnitLayer HiddenLayer1;
	CCalculationUnitLayer HiddenLayer2;
	CCalculationUnitLayer OutputLayer;

	InputAndBiasLayer.Intialize(idOfFirstInputUnit, NumOfInputAndBiasUnits);
	HiddenLayer1.Intialize(idOfFirstHiddenUnitL1, NumOfHiddenUnitsL1);
	HiddenLayer2.Intialize(idOfFirstHiddenUnitL2, NumOfHiddenUnitsL2);
	OutputLayer.Intialize(idOfFirstOutputUnit, NumOfOutputUnits);


	// InputUnit:
	InputAndBiasLayer.Set_CalculationFunctions(&CalculationNet, 1, &CalculationFunctions);
	//InputAndBiasLayer.Set_CalculationFunctions(&CalculationNet, 1, Identity);

	// BiasUnit1:
	InputAndBiasLayer.Set_BiasUnit(&CalculationNet, idOfBiasUnit, 2, &CalculationFunctions);
	//InputAndBiasLayer.Set_BiasUnit(&CalculationNet, idOfBiasUnit, 2, Bias);


	HiddenLayer1.Set_CalculationFunctions(&CalculationNet, 3, &CalculationFunctions);
	//HiddenLayer1.Set_CalculationFunctions(&CalculationNet, 3, TanH);

	HiddenLayer2.Set_CalculationFunctions(&CalculationNet, 3, &CalculationFunctions);
	//HiddenLayer2.Set_CalculationFunctions(&CalculationNet, 3, TanH);


	OutputLayer.Set_CalculationFunctions(&CalculationNet, 1, &CalculationFunctions);
	OutputLayer.Set_CalculationFunctions(&CalculationNet, 1, Identity);
	//OutputLayer.Set_CalculationFunctions(&CalculationNet, 3, &CalculationFunctions);
	//OutputLayer.Set_CalculationFunctions(&CalculationNet, 3, TanH);


	float minRandomPlasticity = -2.0f;
	float maxRandomPlasticity = 2.0f;

	float PlasticityArray_InputToHidden1Layer[NumOfInputAndBiasUnits];
	float PlasticityArray_Hidden1ToHidden2Layer[NumOfHiddenUnitsL1];
	float PlasticityArray_Hidden2ToOutputLayer[NumOfHiddenUnitsL2];

	for (int32_t i = HiddenLayer1.FirstUnitID; i < HiddenLayer1.LastUnitIDPlus1; i++)
	{
		for (int32_t j = 0; j < NumOfInputAndBiasUnits; j++)
		{
			PlasticityArray_InputToHidden1Layer[j] = RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
		}

		HiddenLayer1.Set_IncomingPlasticityValues(&CalculationNet, &InputAndBiasLayer, i, PlasticityArray_InputToHidden1Layer);
	}

	for (int32_t i = HiddenLayer2.FirstUnitID; i < HiddenLayer2.LastUnitIDPlus1; i++)
	{
		for (int32_t j = 0; j < NumOfHiddenUnitsL1; j++)
		{
			PlasticityArray_Hidden1ToHidden2Layer[j] = RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
		}

		HiddenLayer2.Set_IncomingPlasticityValues(&CalculationNet, &HiddenLayer1, i, PlasticityArray_Hidden1ToHidden2Layer);
	}


	//int32_t lastOutputUnitIDPlus1 = idOfFirstOutputUnit + NumOfOutputUnits;
	//for (int32_t i = idOfFirstOutputUnit; i < lastOutputUnitIDPlus1; i++)
	for (int32_t i = OutputLayer.FirstUnitID; i < OutputLayer.LastUnitIDPlus1; i++)
	{
		for (int32_t j = 0; j < NumOfHiddenUnitsL2; j++)
		{
			PlasticityArray_Hidden2ToOutputLayer[j] = RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
		}

		OutputLayer.Set_IncomingPlasticityValues(&CalculationNet, &HiddenLayer2, i, PlasticityArray_Hidden2ToOutputLayer);
	}

	InputAndBiasLayer.Activate_Connections_If_Possible(&CalculationNet, &HiddenLayer1);
	HiddenLayer1.Activate_Connections_If_Possible(&CalculationNet, &HiddenLayer2);
	HiddenLayer2.Activate_Connections_If_Possible(&CalculationNet, &OutputLayer);



	float outputValueArray[4];

	float learningRate = 0.1f;
	//float learningRate = 0.2f;
	float errorFactor1 = 1.0f;
	float errorFactor2 = 1.0f;

	int32_t maxCount = 100000;
	int32_t epoch = 0;
	float errorSum;

	for (int32_t j = 0; j < maxCount; j++)
	{
		epoch++;
		errorSum = 0.0f;

		for (int32_t i = 0; i < ConstNumOfInputs; i++)
		{
			CalculationNet.Set_InputValue(InputValueArray[i]);
			CalculationNet.Execute_Calculations();

			errorSum += CalculationNet.Calculate_OutputVarianceSum_And_OutputError(pOutputArrayPointer[i], errorFactor1, errorFactor2);

			CalculationNet.Learning(learningRate, errorFactor1, errorFactor2);
			//CalculationNet.ExtremeLearning(learningRate);
		}

		if (j % 50 == 0)
		{
			cout << "error: " << errorSum << endl;
		}

		if (errorSum < 0.0005f)
			break;
	}

	// training completed

	// training statistics:


	cout << endl << "epoch: " << epoch << endl;
	cout << "error: " << errorSum << endl << endl;

	cout << endl;

	//getchar();


	for (int32_t i = 0; i < ConstNumOfInputs; i++)
	{
		CalculationNet.Set_InputValue(InputValueArray[i]);
		CalculationNet.Execute_Calculations();
		CalculationNet.Get_OutputValues(outputValueArray);

		cout << "input: " << InputValueArray[i] << endl;
		cout << "outputs: " << outputValueArray[0] << " "
			<< outputValueArray[1] << " "
			<< outputValueArray[2] << " "
			<< outputValueArray[3] << " " << endl << endl;
	}

	float additionalInputValue = 0.35f;
	CalculationNet.Set_InputValue(additionalInputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(outputValueArray);

	cout << "input: " << additionalInputValue << endl;
	cout << "outputs: " << outputValueArray[0] << " "
		<< outputValueArray[1] << " "
		<< outputValueArray[2] << " "
		<< outputValueArray[3] << " " << endl << endl;

	additionalInputValue = 0.65f;
	CalculationNet.Set_InputValue(additionalInputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(outputValueArray);

	cout << "input: " << additionalInputValue << endl;
	cout << "outputs: " << outputValueArray[0] << " "
		<< outputValueArray[1] << " "
		<< outputValueArray[2] << " "
		<< outputValueArray[3] << " " << endl << endl;

	additionalInputValue = 0.83f;
	CalculationNet.Set_InputValue(additionalInputValue);
	CalculationNet.Execute_Calculations();
	CalculationNet.Get_OutputValues(outputValueArray);

	cout << "input: " << additionalInputValue << endl;
	cout << "outputs: " << outputValueArray[0] << " "
		<< outputValueArray[1] << " "
		<< outputValueArray[2] << " "
		<< outputValueArray[3] << " " << endl << endl;


	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/


static void XORBrain_Reinitialization(CNeuralCalculationNetDesc* pInOutNetDesc, CRandomNumbersNN* pRandomNumbers, void* pParam)
{
	//CEvolutionParameter_NeuralCalculationNet *pParameter = static_cast<CEvolutionParameter_NeuralCalculationNet*>(pParam);

	float minRandomPlasticity = -2.0f;
	float maxRandomPlasticity = 2.0f;

	int32_t numOfNeuralConnections = pInOutNetDesc->NumOfNeuralConnections;

	for (int32_t i = 0; i < numOfNeuralConnections; i++)
	{
		if (pInOutNetDesc->pConnectionStatusArray[i] == 0.0f)
			continue;

		pInOutNetDesc->pPlasticityValueArray[i] = pRandomNumbers->Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
	}

}

static void XORBrain_Mutation(CNeuralCalculationNetDesc* pInOutNetDesc, CRandomNumbersNN* pRandomNumbers, void* pParam)
{
	//CEvolutionParameter_NeuralCalculationNet *pParameter = static_cast<CEvolutionParameter_NeuralCalculationNet*>(pParam);

	float minDeltaPlasticity = -0.01f;
	float maxDeltaPlasticity = 0.01f;
	float mutationRate = 0.75f;

	int32_t numOfNeuralConnections = pInOutNetDesc->NumOfNeuralConnections;

	for (int32_t i = 0; i < numOfNeuralConnections; i++)
	{
		if (pInOutNetDesc->pConnectionStatusArray[i] == 0.0f)
			continue;

		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
			continue;

		pInOutNetDesc->pPlasticityValueArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minDeltaPlasticity, maxDeltaPlasticity);
	}

}

static void XORBrain_Recombination(CNeuralCalculationNetDesc* pOffspring, const CNeuralCalculationNetDesc* pParent1, const CNeuralCalculationNetDesc* pParent2, CRandomNumbersNN* pRandomNumbers, void* pParam)
{
	//CEvolutionParameter_NeuralCalculationNet *pParameter = static_cast<CEvolutionParameter_NeuralCalculationNet*>(pParam);

	float crossoverRate = 0.75f;

	int32_t numOfNeuralConnections = pOffspring->NumOfNeuralConnections;

	if (pRandomNumbers->Get_IntegerNumber2(1, 2) == 1)
	{
		for (int32_t i = 0; i < numOfNeuralConnections; i++)
		{
			if (pOffspring->pConnectionStatusArray[i] == 0.0f)
				continue;

			pOffspring->pPlasticityValueArray[i] = pParent1->pPlasticityValueArray[i];
		}
	}
	else
	{
		for (int32_t i = 0; i < numOfNeuralConnections; i++)
		{
			if (pOffspring->pConnectionStatusArray[i] == 0.0f)
				continue;

			pOffspring->pPlasticityValueArray[i] = pParent2->pPlasticityValueArray[i];
		}
	}

	for (int32_t i = 0; i < numOfNeuralConnections; i++)
	{
		if (pOffspring->pConnectionStatusArray[i] == 0.0f)
			continue;

		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > crossoverRate)
			continue;

		float weight1 = pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f);
		float weight2 = 1.0f - weight1;

		pOffspring->pPlasticityValueArray[i] = weight1 * pParent1->pPlasticityValueArray[i] + weight2 * pParent2->pPlasticityValueArray[i];
	}
}

/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	float InputArray1[2] = { 0.0f, 0.0f };
	float InputArray2[2] = { 1.0f, 0.0f };
	float InputArray3[2] = { 0.0f, 1.0f };
	float InputArray4[2] = { 1.0f, 1.0f };
	float InputArray5[2] = { 0.5f, 0.5f };

	static constexpr int32_t ConstNumOfInputArrays = 5;

	float* pInputArrayPointer[ConstNumOfInputArrays];

	pInputArrayPointer[0] = InputArray1;
	pInputArrayPointer[1] = InputArray2;
	pInputArrayPointer[2] = InputArray3;
	pInputArrayPointer[3] = InputArray4;
	pInputArrayPointer[4] = InputArray5;

	float DesiredXOROutputArray[ConstNumOfInputArrays] = { 0.0f, 1.0f, 1.0f, 0.0f, 0.0f };


	CNeuralCalculationFunctions CalculationFunctions;
	CalculationFunctions.Initialize(4);
	CalculationFunctions.Set_Function(0, nullptr);
	CalculationFunctions.Set_Function(1, Identity);
	CalculationFunctions.Set_Function(2, Bias);
	CalculationFunctions.Set_Function(3, TanH);

	static constexpr int32_t NumOfInputUnits = 2;
	static constexpr int32_t NumOfInputAndBiasUnits = NumOfInputUnits + 1;
	static constexpr int32_t NumOfHiddenUnits = 5;
	static constexpr int32_t NumOfOutputUnits = 1;
	static constexpr int32_t NumOfCalculationUnits = NumOfInputAndBiasUnits + NumOfHiddenUnits + NumOfOutputUnits;

	int32_t idOfFirstInputUnit = 0;
	int32_t idOfBiasUnit = NumOfInputUnits;
	int32_t idOfFirstHiddenUnit = NumOfInputAndBiasUnits;
	int32_t idOfFirstOutputUnit = idOfFirstHiddenUnit + NumOfHiddenUnits;

	CNeuralCalculationNet CalculationNet;
	CalculationNet.Initialize(NumOfCalculationUnits, NumOfInputUnits, NumOfOutputUnits);
	CalculationNet.Set_InputUnit(0, 0);
	CalculationNet.Set_InputUnit(1, 1);
	CalculationNet.Set_OutputUnit(idOfFirstOutputUnit, 0);


	//////////////

	CCalculationUnitLayer InputAndBiasLayer;
	CCalculationUnitLayer HiddenLayer;
	CCalculationUnitLayer OutputLayer;

	InputAndBiasLayer.Intialize(idOfFirstInputUnit, NumOfInputAndBiasUnits);
	HiddenLayer.Intialize(idOfFirstHiddenUnit, NumOfHiddenUnits);
	OutputLayer.Intialize(idOfFirstOutputUnit, NumOfOutputUnits);

	// InputUnit:
	InputAndBiasLayer.Set_CalculationFunctions(&CalculationNet, 1, &CalculationFunctions);
	//InputAndBiasLayer.Set_CalculationFunctions(&CalculationNet, 1, Identity);

	// BiasUnit1:
	InputAndBiasLayer.Set_BiasUnit(&CalculationNet, idOfBiasUnit, 2, &CalculationFunctions);
	//InputAndBiasLayer.Set_BiasUnit(&CalculationNet, idOfBiasUnit, 2, Bias);


	HiddenLayer.Set_CalculationFunctions(&CalculationNet, 3, &CalculationFunctions);
	//HiddenLayer.Set_CalculationFunctions(&CalculationNet, 3, TanH);


	OutputLayer.Set_CalculationFunctions(&CalculationNet, 1, &CalculationFunctions);
	OutputLayer.Set_CalculationFunctions(&CalculationNet, 1, Identity);
	//OutputLayer.Set_CalculationFunctions(&CalculationNet, 3, &CalculationFunctions);
	//OutputLayer.Set_CalculationFunctions(&CalculationNet, 3, TanH);


	float minRandomPlasticity = -2.0f;
	float maxRandomPlasticity = 2.0f;

	float PlasticityArray_InputToHiddenLayer[NumOfInputAndBiasUnits];
	float PlasticityArray_HiddenToOutputLayer[NumOfHiddenUnits];

	//for (int32_t i = idOfFirstHiddenUnit; i < idOfFirstOutputUnit; i++)
	for (int32_t i = HiddenLayer.FirstUnitID; i < HiddenLayer.LastUnitIDPlus1; i++)
	{
		for (int32_t j = 0; j < NumOfInputAndBiasUnits; j++)
		{
			PlasticityArray_InputToHiddenLayer[j] = RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
		}

		HiddenLayer.Set_IncomingPlasticityValues(&CalculationNet, &InputAndBiasLayer, i, PlasticityArray_InputToHiddenLayer);
	}


	for (int32_t j = 0; j < NumOfHiddenUnits; j++)
	{
		PlasticityArray_HiddenToOutputLayer[j] = RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
	}

	OutputLayer.Set_IncomingPlasticityValues(&CalculationNet, &HiddenLayer, idOfFirstOutputUnit, PlasticityArray_HiddenToOutputLayer);

	InputAndBiasLayer.Activate_Connections_If_Possible(&CalculationNet, &HiddenLayer);
	HiddenLayer.Activate_Connections_If_Possible(&CalculationNet, &OutputLayer);


	CNeuralCalculationNetDesc BestEvolvedCalculationNetDesc;
	CalculationNet.Readout_Data(&BestEvolvedCalculationNetDesc);

	static constexpr int32_t TrainingPopulationSize = 50;
	static constexpr int32_t NumTrainingGenerationsMax = 1000;

	static CNeuralCalculationNetDesc CalculationNetDescArray[TrainingPopulationSize];

	CNeuralCalculationNetDescPopulation CalculationNetDescPopulation;
	CalculationNetDescPopulation.Initialize(TrainingPopulationSize);

	for (int32_t i = 0; i < TrainingPopulationSize; i++)
	{
		CalculationNet.Readout_Data(&CalculationNetDescArray[i]);
		XORBrain_Reinitialization(&CalculationNetDescArray[i], &RandomNumbers, nullptr);

		CalculationNetDescPopulation.Set_NeuralCalculationNetDesc(&CalculationNetDescArray[i], i);
	}


	float outputValue;
	//float outputValueArray[1];

	float errorSum;

	for (int32_t j = 0; j < NumTrainingGenerationsMax; j++)
	{
		CalculationNetDescPopulation.Reset_MinErrorSum_ActualGeneration();

		for (int32_t i = 0; i < TrainingPopulationSize; i++)
		{
			CalculationNet.Modify(&CalculationNetDescArray[i], &CalculationFunctions);

			errorSum = 0.0f;

			for (int32_t k = 0; k < ConstNumOfInputArrays; k++)
			{
				CalculationNet.Set_InputValues(pInputArrayPointer[k]);
				CalculationNet.Execute_Calculations();
				errorSum += CalculationNet.Calculate_OutputVarianceSum(&DesiredXOROutputArray[k]);
			}

			CalculationNetDescPopulation.Calculate_FitnessScore_FromError(i, errorSum);

			CalculationNetDescPopulation.Update_MinErrorSum_ActualGeneration(errorSum);

		} // end of for (int32_t i = 0; i < TrainingPopulationSize; i++)

		CalculationNetDescPopulation.Update_Population();

		if (j % 100 == 0)
		{
			cout << "minErrorSum: " << CalculationNetDescPopulation.MinErrorSum_ActualGeneration << endl;
		}

		if (CalculationNetDescPopulation.MinErrorSum_ActualGeneration < 0.01f)
		{
			cout << endl;
			cout << "minErrorSum: " << CalculationNetDescPopulation.MinErrorSum_ActualGeneration << endl;
			cout << "actual generation: " << j << endl;
			cout << "training completed" << endl << endl;
			break;
		}

		CalculationNetDescPopulation.Update_BaseEvolution(XORBrain_Mutation, nullptr);
		CalculationNetDescPopulation.Update_Evolution_BestBrainOnly(XORBrain_Mutation, nullptr);
		CalculationNetDescPopulation.Update_Evolution_SecondBestBrainOnly(XORBrain_Mutation, nullptr);
		CalculationNetDescPopulation.Update_Evolution_Combine_BestTwoBrains(XORBrain_Recombination, nullptr);
		CalculationNetDescPopulation.Update_Evolution_Combine_TwoBrains(XORBrain_Recombination, nullptr);
		CalculationNetDescPopulation.Update_Evolution_Combine_TwoBrains(XORBrain_Recombination, nullptr);
		CalculationNetDescPopulation.Replace_WorstFitted_Brain(XORBrain_Reinitialization, nullptr);
		CalculationNetDescPopulation.Replace_SecondWorstFitted_Brain(XORBrain_Reinitialization, nullptr);
		CalculationNetDescPopulation.Replace_ThirdWorstFitted_Brain(XORBrain_Reinitialization, nullptr);

	} // end of for (int32_t j = 0; j < NumTrainingGenerationsMax; j++)

	
	CalculationNetDescPopulation.Get_Best_Evolved_NeuralCalculationNetDesc(&BestEvolvedCalculationNetDesc);


	CalculationNet.Modify(&BestEvolvedCalculationNetDesc, &CalculationFunctions);


	cout << endl;

	//getchar();


	for (int32_t i = 0; i < ConstNumOfInputArrays; i++)
	{
		CalculationNet.Set_InputValues(pInputArrayPointer[i]);
		CalculationNet.Execute_Calculations();
		CalculationNet.Get_OutputValues(&outputValue);

		cout << "input values: " << pInputArrayPointer[i][0] << " " << pInputArrayPointer[i][1] << endl;
		cout << "activation value: " << outputValue << endl << endl;
	}

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CRandomNumbersNN RandomNumbers;

	float InputArray1[2] = { 0.0f, 0.0f };
	float InputArray2[2] = { 1.0f, 0.0f };
	float InputArray3[2] = { 0.0f, 1.0f };
	float InputArray4[2] = { 1.0f, 1.0f };
	float InputArray5[2] = { 0.5f, 0.5f };

	static constexpr int32_t ConstNumOfInputArrays = 5;

	float* pInputArrayPointer[ConstNumOfInputArrays];

	pInputArrayPointer[0] = InputArray1;
	pInputArrayPointer[1] = InputArray2;
	pInputArrayPointer[2] = InputArray3;
	pInputArrayPointer[3] = InputArray4;
	pInputArrayPointer[4] = InputArray5;

	float DesiredXOROutputArray[ConstNumOfInputArrays] = { 0.0f, 1.0f, 1.0f, 0.0f, 0.0f };


	CNeuralCalculationFunctions CalculationFunctions;
	CalculationFunctions.Initialize(4);
	CalculationFunctions.Set_Function(0, nullptr);
	CalculationFunctions.Set_Function(1, Identity);
	CalculationFunctions.Set_Function(2, Bias);
	CalculationFunctions.Set_Function(3, TanH);

	
	static constexpr int32_t NumOfInputUnits = 2;
	static constexpr int32_t NumOfInputAndBiasUnits = NumOfInputUnits + 1;
	static constexpr int32_t NumOfHiddenUnitsL1 = 5;
	//static constexpr int32_t NumOfHiddenUnitsL2 = 5;
	static constexpr int32_t NumOfHiddenUnitsL2 = 4;
	static constexpr int32_t NumOfOutputUnits = 1;
	static constexpr int32_t NumOfCalculationUnits = NumOfInputAndBiasUnits + NumOfHiddenUnitsL1 + NumOfHiddenUnitsL2 + NumOfOutputUnits;

	int32_t idOfFirstInputUnit = 0;
	int32_t idOfBiasUnit = NumOfInputUnits;
	int32_t idOfFirstHiddenUnitL1 = NumOfInputAndBiasUnits;
	int32_t idOfFirstHiddenUnitL2 = idOfFirstHiddenUnitL1 + NumOfHiddenUnitsL1;
	int32_t idOfFirstOutputUnit = idOfFirstHiddenUnitL2 + NumOfHiddenUnitsL2;

	CNeuralCalculationNet CalculationNet;
	CalculationNet.Initialize(NumOfCalculationUnits, NumOfInputUnits, NumOfOutputUnits);
	CalculationNet.Set_InputUnit(0, 0);
	CalculationNet.Set_InputUnit(1, 1);
	CalculationNet.Set_OutputUnit(idOfFirstOutputUnit, 0);


	//////////////

	CCalculationUnitLayer InputAndBiasLayer;
	CCalculationUnitLayer HiddenLayer1;
	CCalculationUnitLayer HiddenLayer2;
	CCalculationUnitLayer OutputLayer;

	InputAndBiasLayer.Intialize(idOfFirstInputUnit, NumOfInputAndBiasUnits);
	HiddenLayer1.Intialize(idOfFirstHiddenUnitL1, NumOfHiddenUnitsL1);
	HiddenLayer2.Intialize(idOfFirstHiddenUnitL2, NumOfHiddenUnitsL2);
	OutputLayer.Intialize(idOfFirstOutputUnit, NumOfOutputUnits);

	// InputUnit:
	InputAndBiasLayer.Set_CalculationFunctions(&CalculationNet, 1, &CalculationFunctions);
	//InputAndBiasLayer.Set_CalculationFunctions(&CalculationNet, 1, Identity);

	// BiasUnit1:
	InputAndBiasLayer.Set_BiasUnit(&CalculationNet, idOfBiasUnit, 2, &CalculationFunctions);
	//InputAndBiasLayer.Set_BiasUnit(&CalculationNet, idOfBiasUnit, 2, Bias);


	HiddenLayer1.Set_CalculationFunctions(&CalculationNet, 3, &CalculationFunctions);
	//HiddenLayer1.Set_CalculationFunctions(&CalculationNet, 3, TanH);

	HiddenLayer2.Set_CalculationFunctions(&CalculationNet, 3, &CalculationFunctions);
	//HiddenLayer2.Set_CalculationFunctions(&CalculationNet, 3, TanH);


	OutputLayer.Set_CalculationFunctions(&CalculationNet, 1, &CalculationFunctions);
	OutputLayer.Set_CalculationFunctions(&CalculationNet, 1, Identity);
	//OutputLayer.Set_CalculationFunctions(&CalculationNet, 3, &CalculationFunctions);
	//OutputLayer.Set_CalculationFunctions(&CalculationNet, 3, TanH);


	float minRandomPlasticity = -2.0f;
	float maxRandomPlasticity = 2.0f;

	float PlasticityArray_InputToHidden1Layer[NumOfInputAndBiasUnits];
	float PlasticityArray_Hidden1ToHidden2Layer[NumOfHiddenUnitsL1];
	float PlasticityArray_Hidden2ToOutputLayer[NumOfHiddenUnitsL2];

	for (int32_t i = idOfFirstHiddenUnitL1; i < idOfFirstHiddenUnitL2; i++)
	{
		for (int32_t j = 0; j < NumOfInputAndBiasUnits; j++)
		{
			PlasticityArray_InputToHidden1Layer[j] = RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
		}

		HiddenLayer1.Set_IncomingPlasticityValues(&CalculationNet, &InputAndBiasLayer, i, PlasticityArray_InputToHidden1Layer);
	}

	for (int32_t i = idOfFirstHiddenUnitL2; i < idOfFirstOutputUnit; i++)
	{
		for (int32_t j = 0; j < NumOfHiddenUnitsL1; j++)
		{
			PlasticityArray_Hidden1ToHidden2Layer[j] = RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
		}

		HiddenLayer2.Set_IncomingPlasticityValues(&CalculationNet, &HiddenLayer1, i, PlasticityArray_Hidden1ToHidden2Layer);
	}


	for (int32_t j = 0; j < NumOfHiddenUnitsL2; j++)
	{
		PlasticityArray_Hidden2ToOutputLayer[j] = RandomNumbers.Get_FloatNumber(minRandomPlasticity, maxRandomPlasticity);
	}

	OutputLayer.Set_IncomingPlasticityValues(&CalculationNet, &HiddenLayer2, idOfFirstOutputUnit, PlasticityArray_Hidden2ToOutputLayer);


	InputAndBiasLayer.Activate_Connections_If_Possible(&CalculationNet, &HiddenLayer1);
	HiddenLayer1.Activate_Connections_If_Possible(&CalculationNet, &HiddenLayer2);
	HiddenLayer2.Activate_Connections_If_Possible(&CalculationNet, &OutputLayer);
	

	CNeuralCalculationNetDesc BestEvolvedCalculationNetDesc;
	CalculationNet.Readout_Data(&BestEvolvedCalculationNetDesc);

	static constexpr int32_t TrainingPopulationSize = 50;
	static constexpr int32_t NumTrainingGenerationsMax = 1000;

	static CNeuralCalculationNetDesc CalculationNetDescArray[TrainingPopulationSize];

	CNeuralCalculationNetDescPopulation CalculationNetDescPopulation;
	CalculationNetDescPopulation.Initialize(TrainingPopulationSize);

	for (int32_t i = 0; i < TrainingPopulationSize; i++)
	{
		CalculationNet.Readout_Data(&CalculationNetDescArray[i]);
		XORBrain_Reinitialization(&CalculationNetDescArray[i], &RandomNumbers, nullptr);

		CalculationNetDescPopulation.Set_NeuralCalculationNetDesc(&CalculationNetDescArray[i], i);
	}


	float outputValue;
	//float outputValueArray[1];

	float errorSum;

	for (int32_t j = 0; j < NumTrainingGenerationsMax; j++)
	{
		CalculationNetDescPopulation.Reset_MinErrorSum_ActualGeneration();

		for (int32_t i = 0; i < TrainingPopulationSize; i++)
		{
			CalculationNet.Modify(&CalculationNetDescArray[i], &CalculationFunctions);

			errorSum = 0.0f;

			for (int32_t k = 0; k < ConstNumOfInputArrays; k++)
			{
				CalculationNet.Set_InputValues(pInputArrayPointer[k]);
				CalculationNet.Execute_Calculations();
				errorSum += CalculationNet.Calculate_OutputVarianceSum(&DesiredXOROutputArray[k]);
			}

			CalculationNetDescPopulation.Calculate_FitnessScore_FromError(i, errorSum);

			CalculationNetDescPopulation.Update_MinErrorSum_ActualGeneration(errorSum);

		} // end of for (int32_t i = 0; i < TrainingPopulationSize; i++)

		CalculationNetDescPopulation.Update_Population();

		if (j % 100 == 0)
		{
			cout << "minErrorSum: " << CalculationNetDescPopulation.MinErrorSum_ActualGeneration << endl;
		}

		if (CalculationNetDescPopulation.MinErrorSum_ActualGeneration < 0.01f)
		{
			cout << endl;
			cout << "minErrorSum: " << CalculationNetDescPopulation.MinErrorSum_ActualGeneration << endl;
			cout << "actual generation: " << j << endl;
			cout << "training completed" << endl << endl;
			break;
		}

		CalculationNetDescPopulation.Update_BaseEvolution(XORBrain_Mutation, nullptr);
		CalculationNetDescPopulation.Update_Evolution_BestBrainOnly(XORBrain_Mutation, nullptr);
		CalculationNetDescPopulation.Update_Evolution_SecondBestBrainOnly(XORBrain_Mutation, nullptr);
		CalculationNetDescPopulation.Update_Evolution_Combine_BestTwoBrains(XORBrain_Recombination, nullptr);
		CalculationNetDescPopulation.Update_Evolution_Combine_TwoBrains(XORBrain_Recombination, nullptr);
		CalculationNetDescPopulation.Update_Evolution_Combine_TwoBrains(XORBrain_Recombination, nullptr);
		CalculationNetDescPopulation.Replace_WorstFitted_Brain(XORBrain_Reinitialization, nullptr);
		CalculationNetDescPopulation.Replace_SecondWorstFitted_Brain(XORBrain_Reinitialization, nullptr);
		CalculationNetDescPopulation.Replace_ThirdWorstFitted_Brain(XORBrain_Reinitialization, nullptr);

	} // end of for (int32_t j = 0; j < NumTrainingGenerationsMax; j++)


	CalculationNetDescPopulation.Get_Best_Evolved_NeuralCalculationNetDesc(&BestEvolvedCalculationNetDesc);


	CalculationNet.Modify(&BestEvolvedCalculationNetDesc, &CalculationFunctions);


	cout << endl;

	//getchar();


	for (int32_t i = 0; i < ConstNumOfInputArrays; i++)
	{
		CalculationNet.Set_InputValues(pInputArrayPointer[i]);
		CalculationNet.Execute_Calculations();
		CalculationNet.Get_OutputValues(&outputValue);

		cout << "input values: " << pInputArrayPointer[i][0] << " " << pInputArrayPointer[i][1] << endl;
		cout << "activation value: " << outputValue << endl << endl;
	}

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/