#include <iostream>
#include "NeuralCalculationNet.h"
#include "Graph.h"
//#include "MathInlineFunctions.h"

using namespace std;
using namespace HelperStuff;


static void Reset_2DMovementSpace(float *pInOutDistanceData1, float *pInOutDistanceData2, int32_t sizeXY)
{
	//#pragma omp parallel for num_threads(2)
#pragma omp parallel for
	for (int32_t i = 0; i < sizeXY; i++)
	{
		/*if (pInOutDistanceData1[i] > 0.0f)
		{
		pInOutDistanceData1[i] = 0.0f;
		}*/

		pInOutDistanceData1[i] = min(pInOutDistanceData1[i], 0.0f);

		pInOutDistanceData2[i] = pInOutDistanceData1[i];
	}
}

static bool Set_2DMovementDestination(int32_t ix, int32_t iy, float *pInOutDestinationDistanceData, float *pInOutSourceDistanceData, int32_t sizeX, int32_t sizeY)
{
	ix = max(ix, 1);
	ix = min(ix, sizeX - 2);
	iy = max(iy, 1);
	iy = min(iy, sizeY - 2);

	int32_t centerTileID = ix + iy * sizeX;

	if (pInOutSourceDistanceData[centerTileID] < 0.0f)
	{
		return false;
	}

	int32_t directionCounter = 0;

	int32_t adjacentTileID = centerTileID - 1;

	if (pInOutSourceDistanceData[adjacentTileID] == 0.0f)
	{
		pInOutDestinationDistanceData[adjacentTileID] = 1.0f; // kleinstm�glicher Manhatten-Abstand vom Ziel
		pInOutSourceDistanceData[adjacentTileID] = 1.0f;
		directionCounter++;
	}

	adjacentTileID = centerTileID + 1;

	if (pInOutSourceDistanceData[adjacentTileID] == 0.0f)
	{
		pInOutDestinationDistanceData[adjacentTileID] = 1.0f;
		pInOutSourceDistanceData[adjacentTileID] = 1.0f;
		directionCounter++;
	}

	adjacentTileID = centerTileID - sizeX;

	if (pInOutSourceDistanceData[adjacentTileID] == 0.0f)
	{
		pInOutDestinationDistanceData[adjacentTileID] = 1.0f;
		pInOutSourceDistanceData[adjacentTileID] = 1.0f;
		directionCounter++;
	}

	adjacentTileID = centerTileID + sizeX;

	if (pInOutSourceDistanceData[adjacentTileID] == 0.0f)
	{
		pInOutDestinationDistanceData[adjacentTileID] = 1.0f;
		pInOutSourceDistanceData[adjacentTileID] = 1.0f;
		directionCounter++;
	}

	if (directionCounter == 0)
	{
		return false;
	}

	return true;
}

static void Update_DistanceData(float *pInOutDestinationDistanceData, float *pInOutSourceDistanceData, int32_t sizeX, int32_t sizeY)
{
	int32_t sizeXMinus1 = sizeX - 1;
	int32_t sizeYMinus1 = sizeY - 1;
	int32_t maxIDPlus1 = sizeX * sizeY;

	//#pragma omp parallel for num_threads(2)
#pragma omp parallel for
	for (int32_t centerTileID = 0; centerTileID < maxIDPlus1; centerTileID++)
	{
		int32_t ix = centerTileID % sizeX;

		// linke und rechte Spielfeldbegrenzung von der Wegfindung ausnehmen:
		if (ix == 0 || ix == sizeXMinus1)
			continue;

		int32_t iy = centerTileID / sizeX;

		// obere und untere Spielfeldbegrenzung von der Wegfindung ausnehmen:
		if (iy == 0 || iy == sizeYMinus1)
			continue;

		float centerTileValue = pInOutSourceDistanceData[centerTileID];

		// begehbares, nicht evaluiertes Tile:
		if (centerTileValue == 0.0f)
		{
			float minAdjacentManhattenDist = 1000000.0f;
			float randomAdditionalMovementCosts = 0.0f;

			int32_t adjacentTileID = centerTileID - 1;
			float adjacentDistance = pInOutSourceDistanceData[adjacentTileID];

			if (adjacentDistance < minAdjacentManhattenDist && adjacentDistance > 0.0f)
			{
				minAdjacentManhattenDist = adjacentDistance;
				pInOutDestinationDistanceData[centerTileID] = adjacentDistance + 1.0f; // n�chst gr��erer Manhatten-Abstand
			}

			adjacentTileID = centerTileID + 1;
			adjacentDistance = pInOutSourceDistanceData[adjacentTileID];

			if (adjacentDistance < minAdjacentManhattenDist && adjacentDistance > 0.0f)
			{
				minAdjacentManhattenDist = adjacentDistance;
				pInOutDestinationDistanceData[centerTileID] = adjacentDistance + 1.0f;
			}

			adjacentTileID = centerTileID - sizeX;
			adjacentDistance = pInOutSourceDistanceData[adjacentTileID];

			if (adjacentDistance < minAdjacentManhattenDist && adjacentDistance > 0.0f)
			{
				minAdjacentManhattenDist = adjacentDistance;
				pInOutDestinationDistanceData[centerTileID] = adjacentDistance + 1.0f;
			}

			adjacentTileID = centerTileID + sizeX;
			adjacentDistance = pInOutSourceDistanceData[adjacentTileID];

			if (adjacentDistance < minAdjacentManhattenDist && adjacentDistance > 0.0f)
			{
				minAdjacentManhattenDist = adjacentDistance;
				pInOutDestinationDistanceData[centerTileID] = adjacentDistance + 1.0f;
			}
		} // end of if (centerTileValue == 0.0f)
	} // end of for (int32_t centerTileID = 0; centerTileID < maxIDPlus1; centerTileID++)

	int32_t sizeXY = sizeX * sizeY;

	//#pragma omp parallel for num_threads(2)
#pragma omp parallel for
	for (int32_t i = 0; i < sizeXY; i++)
	{
		pInOutSourceDistanceData[i] = pInOutDestinationDistanceData[i];
	}
}

static void Get_MovementPath(int32_t *pOutPathTileIDArray, int32_t *pOutNumOfPathSteps, int32_t numOfPathStepsMax, int32_t startPosX, int32_t startPosY, int32_t destinationPosX, int32_t destinationPosY, float *pDistanceData, int32_t sizeX, int32_t sizeY)
{
	startPosX = max(startPosX, 1);
	startPosX = min(startPosX, sizeX - 2);
	startPosY = max(startPosY, 1);
	startPosY = min(startPosY, sizeY - 2);

	int32_t pathTileID = startPosX + startPosY * sizeX;

	float pathTileDistance = pDistanceData[pathTileID];

	// kein begehbares Tile:
	if (pathTileDistance < 0.0f)
	{
		cout << "startpunkt nicht betretbar" << endl;
		getchar();
		*pOutNumOfPathSteps = 0;
		return;
	}

	// Wegende gefunden:
	if (startPosX == destinationPosX && startPosY == destinationPosY)
	{
		pOutPathTileIDArray[0] = pathTileID;
		*pOutNumOfPathSteps = 1;
		return;
	}

	int32_t destinationTileID = destinationPosX + destinationPosY * sizeX;

	int32_t absDiffX = abs(destinationPosX - startPosX);
	int32_t absDiffY = abs(destinationPosY - startPosY);

	// Wegende gefunden:
	if (absDiffX == 1 && absDiffY == 0)
	{
		pOutPathTileIDArray[0] = pathTileID;
		pOutPathTileIDArray[1] = destinationTileID;
		*pOutNumOfPathSteps = 2;
		return;
	}
	// Wegende gefunden:
	else if (absDiffX == 0 && absDiffY == 1)
	{
		pOutPathTileIDArray[0] = pathTileID;
		pOutPathTileIDArray[1] = destinationTileID;
		*pOutNumOfPathSteps = 2;
		return;
	}
	// Wegende gefunden:
	else if (absDiffX == 1 && absDiffY == 1)
	{
		pOutPathTileIDArray[0] = pathTileID;
		pOutPathTileIDArray[1] = destinationTileID;
		*pOutNumOfPathSteps = 2;
		return;
	}


	pOutPathTileIDArray[0] = pathTileID;
	int32_t numOfPathSteps = 1;
	int32_t nextPathTileID = pathTileID;

	for (int32_t i = 1; i < numOfPathStepsMax; i++)
	{
		// Benachbartes Tile mit dem geringstm�glichen Abstand zum Ziel ermitteln: 

		// maximal m�glicher Manhatten-Abstand zwischen Start und Ziel:
		//float minAdjacentDistance = 1000000.0f;
		float minAdjacentDistance = pDistanceData[pathTileID];

		int32_t adjacentTileID = pathTileID - 1;
		float adjacentDistance = pDistanceData[adjacentTileID];

		if (adjacentDistance > 0.0f)
		{
			if (adjacentDistance < minAdjacentDistance)
			{
				minAdjacentDistance = adjacentDistance;
				nextPathTileID = adjacentTileID;
			}
		}

		adjacentTileID = pathTileID + 1;

		adjacentDistance = pDistanceData[adjacentTileID];

		if (adjacentDistance > 0.0f)
		{
			if (adjacentDistance < minAdjacentDistance)
			{
				minAdjacentDistance = adjacentDistance;
				nextPathTileID = adjacentTileID;
			}
		}

		adjacentTileID = pathTileID - sizeX;

		adjacentDistance = pDistanceData[adjacentTileID];

		if (adjacentDistance > 0.0f)
		{
			if (adjacentDistance < minAdjacentDistance)
			{
				minAdjacentDistance = adjacentDistance;
				nextPathTileID = adjacentTileID;
			}
		}

		adjacentTileID = pathTileID + sizeX;

		adjacentDistance = pDistanceData[adjacentTileID];

		if (adjacentDistance > 0.0f)
		{
			if (adjacentDistance < minAdjacentDistance)
			{
				minAdjacentDistance = adjacentDistance;
				nextPathTileID = adjacentTileID;
			}
		}

		adjacentTileID = pathTileID - sizeX - 1;

		adjacentDistance = pDistanceData[adjacentTileID];

		if (adjacentDistance > 0.0f)
		{
			if (adjacentDistance < minAdjacentDistance)
			{
				minAdjacentDistance = adjacentDistance;
				nextPathTileID = adjacentTileID;
			}
		}

		adjacentTileID = pathTileID - sizeX + 1;

		adjacentDistance = pDistanceData[adjacentTileID];

		if (adjacentDistance > 0.0f)
		{
			if (adjacentDistance < minAdjacentDistance)
			{
				minAdjacentDistance = adjacentDistance;
				nextPathTileID = adjacentTileID;
			}
		}

		adjacentTileID = pathTileID + sizeX - 1;

		adjacentDistance = pDistanceData[adjacentTileID];

		if (adjacentDistance > 0.0f)
		{
			if (adjacentDistance < minAdjacentDistance)
			{
				minAdjacentDistance = adjacentDistance;
				nextPathTileID = adjacentTileID;
			}
		}

		adjacentTileID = pathTileID + sizeX + 1;

		adjacentDistance = pDistanceData[adjacentTileID];

		if (adjacentDistance > 0.0f)
		{
			if (adjacentDistance < minAdjacentDistance)
			{
				minAdjacentDistance = adjacentDistance;
				nextPathTileID = adjacentTileID;
			}
		}

		// kein weg zum Ziel gefunden:
		if (pathTileID == nextPathTileID)
		{
			cout << "kein weg zum Ziel gefunden" << endl;
			getchar();
			*pOutNumOfPathSteps = 0;
			return;
		}

		pOutPathTileIDArray[numOfPathSteps] = nextPathTileID;
		numOfPathSteps++;

		if (minAdjacentDistance == 1.0f) // Nachbarschaft zum Ziel
		{
			// letztes Path-Tile entspricht dem Ziel:
			pOutPathTileIDArray[numOfPathSteps] = destinationTileID;
			break;
		}

		pathTileID = nextPathTileID;

	} // end of for (int32_t i = 1; i < numOfPathStepsMax; i++)

	*pOutNumOfPathSteps = numOfPathSteps + 1;
}



static void Add_PathData_To_SurfaceMap(float *pData, int32_t *pPathTileIDArray, int32_t numOfPathSteps)
{
	for (int32_t i = 0; i < numOfPathSteps; i++)
	{
		pData[pPathTileIDArray[i]] = 1000000.0f;
	}
}

static void Output_SurfaceMapData(float *pData, int32_t sizeX, int32_t sizeY)
{
	for (int32_t iy = 0; iy < sizeY; iy++)
	{
		int32_t iiy = iy * sizeX;

		for (int32_t ix = 0; ix < sizeX; ix++)
		{
			int32_t id = ix + iiy;

			if (pData[id] < 0.0f)
			{
				cout << "*" << " ";
			}
			else if (pData[id] == 1000000.0f)
			{
				cout << "P" << " ";
			}
			else if (pData[id] == 0.1f)
			{
				cout << "S" << " ";
			}
			else if (pData[id] == 0.2f)
			{
				cout << "D" << " ";
			}
			/*else if (pData[id] > 0.0f)
			{
			cout << "E" << " ";
			}*/
			else
			{
				cout << " " << " ";
			}
		}

		cout << endl;
	}

	cout << endl << endl;
}

/*
int main(void)
{
	static constexpr int32_t SizeX = 13;
	static constexpr int32_t SizeY = 13;
	static constexpr int32_t SizeXY = SizeX * SizeY;

	static float SurfaceMap1[SizeXY] = {
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
		-1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, -1,
		-1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, -1,
		-1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, -1,
		-1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, -1,
		-1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, -1,
		-1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, -1,
		-1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, -1,
		-1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, -1,
		-1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, -1,
		-1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, -1,
		-1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, -1,
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1 };


	int32_t ixStart = 11;
	int32_t iyStart = 10;
	int32_t StartTileID1 = ixStart + iyStart * SizeX;

	int32_t ixStart2 = 1;
	int32_t iyStart2 = 1;
	int32_t StartTileID2 = ixStart2 + iyStart2 * SizeX;

	int32_t ixDestination = 4;
	int32_t iyDestination = 2;
	int32_t DestinationTileID = ixDestination + iyDestination * SizeX;

	CRandomNumbersNN RandomNumbers;

	// zuf�llige Hindernisse generieren:
	for (int32_t i = 0; i < SizeXY; i++)
	{
		if (i == StartTileID1 || i == StartTileID2 || i == DestinationTileID)
		{
			continue;
		}
		if (RandomNumbers.Get_FloatNumber_IncludingZero(0.0f, 1.0f) > 0.9f)
		//if (RandomNumbers.Get_FloatNumber_IncludingZero(0.0f, 1.0f) > 0.8f)
		//if (RandomNumbers.Get_FloatNumber_IncludingZero(0.0f, 1.0f) > 0.4f)
		{
			SurfaceMap1[i] = -1.0f;
		}
	}


	static float SurfaceMap2[SizeXY];

	for (int32_t i = 0; i < SizeXY; i++)
	{
		SurfaceMap2[i] = SurfaceMap1[i];
	}

	static constexpr int32_t NumOfPathStepsMax = 100;
	static int32_t PathTileIDArray[NumOfPathStepsMax];

	static constexpr int32_t NumOfPathStepsMax2 = 100;
	static int32_t PathTileIDArray2[NumOfPathStepsMax2];


	Reset_2DMovementSpace(SurfaceMap1, SurfaceMap2, SizeXY);


	Set_2DMovementDestination(ixDestination, iyDestination, SurfaceMap1, SurfaceMap2, SizeX, SizeY);

	// Berechnung der Tile-Abst�nde mit zunehmender Entfernung vom Zielpunkt (Destination);
	for (int32_t i = 0; i < SizeXY; i++)
	{
		Update_DistanceData(SurfaceMap1, SurfaceMap2, SizeX, SizeY);
	}

	int32_t NumOfPathSteps = 0;
	Get_MovementPath(PathTileIDArray, &NumOfPathSteps, NumOfPathStepsMax, ixStart, iyStart, ixDestination, iyDestination, SurfaceMap1, SizeX, SizeY);

	int32_t NumOfPathSteps2 = 0;
	Get_MovementPath(PathTileIDArray2, &NumOfPathSteps2, NumOfPathStepsMax, ixStart2, iyStart2, ixDestination, iyDestination, SurfaceMap1, SizeX, SizeY);

	Add_PathData_To_SurfaceMap(SurfaceMap1, PathTileIDArray, NumOfPathSteps);
	Add_PathData_To_SurfaceMap(SurfaceMap1, PathTileIDArray2, NumOfPathSteps2);

	// Start- und Zielmarkierungen hinzuf�gen:
	SurfaceMap1[StartTileID1] = 0.1f;
	SurfaceMap1[StartTileID2] = 0.1f;
	SurfaceMap1[DestinationTileID] = 0.2f;

	Output_SurfaceMapData(SurfaceMap1, SizeX, SizeY);


	cout << "bye bye (Press Return)" << endl;
	getchar();

	return 0;
}
*/