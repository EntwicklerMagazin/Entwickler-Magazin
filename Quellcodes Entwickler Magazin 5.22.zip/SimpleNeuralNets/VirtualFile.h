#ifndef _VirtualFile_H_
#define _VirtualFile_H_  


#include <iostream>


namespace HelperStuff
{


char* ReadBinaryFile(const char *pFileName);
char* ReadFile(const char *pFileName, bool ignoreLineBreaks = true);

class CText
{
public:

	
	char *pData = nullptr;
	uint32_t Size = 0;

	CText()
	{}

	CText(char *pCharArray) : pData(pCharArray), Size(std::strlen(pCharArray) + 1)
	{}

	~CText()
	{
		delete[] pData;
		pData = nullptr;
	}

	// Kopierkonstruktor l�schen:
	CText(const CText &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CText& operator=(const CText &originalObject) = delete;

	void Connect_With_CharArray(char *pCharArray);
	uint32_t Calculate_TextLength(void);
	uint32_t Get_TextLength(void);
	void Set_Text(const char *pText);
	void Init_Memory(uint32_t size);
	void Reset(void);
	
	
	/* friend-Funktion mit vollst�ndigem Zugriff
	auf alle CText-Membervariablen und �Methoden zum
	�berladen des <<-Operators: */

	friend std::ostream& operator << (std::ostream &rOut, CText &rText);

};

class CMultipleTextStrings
{
public:

	CText *pTextArray = nullptr;
	uint32_t NumStrings = 0;

	CMultipleTextStrings()
	{ }

	~CMultipleTextStrings()
	{
		delete[] pTextArray;
		pTextArray = nullptr;
	}

	// Kopierkonstruktor l�schen:
	CMultipleTextStrings(const CMultipleTextStrings &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CMultipleTextStrings& operator=(const CMultipleTextStrings &originalObject) = delete;

	void Init_Strings(uint32_t numStrings, uint32_t size);
	void Reset(void);
};

void Read_SimpleTextString_FromFile(CText *pOutText, const char *pTextFile);
void Read_MultipleTextString_FromFile(CMultipleTextStrings *pOutMultipleTextStrings, uint32_t *pOutNumOfStrings, const char *pTextFile, uint32_t maxCharactersPerString = 500);


class CVirtualFile
{
public:

	// Zeiger auf die aktuelle Leseposition:
	char *ptr; 

	char *ptrFirstPos;

	uint32_t  length;
	
	CVirtualFile() : ptr(nullptr), ptrFirstPos(nullptr), length(0)
	{}


	CVirtualFile(char *pData) : ptr(pData), ptrFirstPos(pData), length(std::strlen(pData))
	{}

	~CVirtualFile()
	{}

	void SetData(char* pData)
	{
		ptr = pData;
		ptrFirstPos = pData;
		length = std::strlen(pData);
	}

	void Set_DataPos(size_t pos)
	{
		ptr = ptrFirstPos + pos;
	}

	void Rewind(void)
	{
		ptr = ptrFirstPos;
	}
};


void ReadFileData_DecInstruction(CVirtualFile *pVirtualFile, uint8_t *pData);
void ReadFileData_HexInstruction(CVirtualFile *pVirtualFile, uint8_t *pData);

void ReadFileData_1Byte(CVirtualFile *pVirtualFile, char *pData);
void ReadFileData_1Byte(CVirtualFile *pVirtualFile, int8_t *pData);
void ReadFileData_1Byte(CVirtualFile *pVirtualFile, uint8_t *pData);


void ReadFileData(CVirtualFile *pVirtualFile, char *pData, uint32_t length = 200);
void ReadFileData(CVirtualFile *pVirtualFile, unsigned char *pData, uint32_t length = 200);
void ReadFileData(CVirtualFile *pVirtualFile, int16_t *pData);
void ReadFileData(CVirtualFile *pVirtualFile, uint16_t *pData);
void ReadFileData(CVirtualFile *pVirtualFile, long *pData);
void ReadFileData(CVirtualFile *pVirtualFile, int32_t *pData);
void ReadFileData(CVirtualFile *pVirtualFile, uint32_t *pData);
//void ReadFileData(CVirtualFile *pVirtualFile, BOOL *pData); BOOL, int32_t, int => same data type
void ReadFileData(CVirtualFile *pVirtualFile, float *pData);
void ReadFileData(CVirtualFile *pVirtualFile, double *pData);

void ReadFileDataBin_1Byte(CVirtualFile *pVirtualFile, char *pData);
void ReadFileDataBin_1Byte(CVirtualFile *pVirtualFile, int8_t *pData);
void ReadFileDataBin_1Byte(CVirtualFile *pVirtualFile, uint8_t *pData);

void ReadFileDataBin(CVirtualFile *pVirtualFile, char *pData, uint32_t length = 200);
void ReadFileDataBin(CVirtualFile *pVirtualFile, unsigned char *pData, uint32_t length = 200);
void ReadFileDataBin(CVirtualFile *pVirtualFile, int16_t *pData);
void ReadFileDataBin(CVirtualFile *pVirtualFile, uint16_t *pData);
void ReadFileDataBin(CVirtualFile *pVirtualFile, long *pData);
void ReadFileDataBin(CVirtualFile *pVirtualFile, int32_t *pData);
void ReadFileDataBin(CVirtualFile *pVirtualFile, uint32_t *pData);
//void ReadFileDataBin(CVirtualFile *pVirtualFile, BOOL* pData); BOOL, int32_t, int => same data type
void ReadFileDataBin(CVirtualFile *pVirtualFile, float *pData);
void ReadFileDataBin(CVirtualFile *pVirtualFile, double *pData);


} /* end of namespace HelperStuff */


#endif
