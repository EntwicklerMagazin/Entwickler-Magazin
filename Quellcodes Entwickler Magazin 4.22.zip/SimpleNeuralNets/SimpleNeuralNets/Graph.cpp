#include "Graph.h"

using namespace std;

CWeightMatrix::CWeightMatrix()
{}

CWeightMatrix::~CWeightMatrix()
{
	delete[] pWeightArray;
	pWeightArray = nullptr;
}

void CWeightMatrix::Init_Matrix(int32_t sizeX, int32_t sizeY, float initalWeight)
{
	SizeX = sizeX;
	SizeY = sizeY;
	Size = sizeX*sizeY;

	delete[] pWeightArray;
	pWeightArray = nullptr;

	pWeightArray = new (std::nothrow) float[Size];

	for (int32_t i = 0; i < Size; i++)
		pWeightArray[i] = initalWeight;
}

float CWeightMatrix::Get_Weight(int32_t ix, int32_t iy)
{
	return pWeightArray[ix + iy*SizeX];
}

void CWeightMatrix::Set_Weight(int32_t ix, int32_t iy, float weight)
{
	pWeightArray[ix + iy*SizeX] = weight;
}

CGraphNode::CGraphNode()
{}

CGraphNode::~CGraphNode()
{}

void CGraphNode::Connect_With_Graph(CGraphNode *pNodeArray)
{
	pUsedNodeArray = pNodeArray;
}

void CGraphNode::Set_Position(float x, float y, float z)
{
	PosX = x;
	PosY = y;
	PosZ = z;
}

float CGraphNode::Get_Distance_to_Other_Node(int32_t nodeID)
{
	float dx = PosX - pUsedNodeArray[nodeID].PosX;
	float dy = PosY - pUsedNodeArray[nodeID].PosY;
	float dz = PosZ - pUsedNodeArray[nodeID].PosZ;

	return sqrt(dx*dx + dy*dy + dz*dz);
}

float CGraphNode::Get_InvDistance_to_Other_Node(int32_t nodeID)
{
	float dx = PosX - pUsedNodeArray[nodeID].PosX;
	float dy = PosY - pUsedNodeArray[nodeID].PosY;
	float dz = PosZ - pUsedNodeArray[nodeID].PosZ;

	return 1.0f / sqrt(dx*dx + dy*dy + dz*dz + 0.0001f);
}

float CGraphNode::Get_DistanceSq_to_Other_Node(int32_t nodeID)
{
	float dx = PosX - pUsedNodeArray[nodeID].PosX;
	float dy = PosY - pUsedNodeArray[nodeID].PosY;
	float dz = PosZ - pUsedNodeArray[nodeID].PosZ;

	return dx*dx + dy*dy + dz*dz;
}

float CGraphNode::Get_InvDistanceSq_to_Other_Node(int32_t nodeID)
{
	float dx = PosX - pUsedNodeArray[nodeID].PosX;
	float dy = PosY - pUsedNodeArray[nodeID].PosY;
	float dz = PosZ - pUsedNodeArray[nodeID].PosZ;

	return 1.0f / (dx*dx + dy*dy + dz*dz + 0.0001f);
}


float CGraphNode::Calculate_PathDistSq(const int32_t *pPathArray, int32_t numNodes)
{
	float distSq = 0.0f;

	int32_t numNodesMinus1 = numNodes - 1;

	for(int32_t i = 0; i < numNodesMinus1; i++)
	{
		distSq += pUsedNodeArray[pPathArray[i]].Get_DistanceSq_to_Other_Node(pPathArray[i + 1]);
	}

	return distSq;
}

float CGraphNode::Calculate_PathDist(const int32_t *pPathArray, int32_t numNodes)
{
	float dist = 0.0f;

	int32_t numNodesMinus1 = numNodes - 1;

	for (int32_t i = 0; i < numNodesMinus1; i++)
	{
		dist += pUsedNodeArray[pPathArray[i]].Get_Distance_to_Other_Node(pPathArray[i + 1]);
	}

	return dist;
}

float CGraphNode::Calculate_PathDistSq(const float *pPathArray, int32_t numNodes)
{
	float distSq = 0.0f;

	int32_t numNodesMinus1 = numNodes - 1;

	for (int32_t i = 0; i < numNodesMinus1; i++)
	{
		distSq += pUsedNodeArray[static_cast<int32_t>(pPathArray[i])].Get_DistanceSq_to_Other_Node(static_cast<int32_t>(pPathArray[i + 1]));
	}

	return distSq;
}

float CGraphNode::Calculate_PathDist(const float *pPathArray, int32_t numNodes)
{
	float dist = 0.0f;

	int32_t numNodesMinus1 = numNodes - 1;

	for (int32_t i = 0; i < numNodesMinus1; i++)
	{
		dist += pUsedNodeArray[static_cast<int32_t>(pPathArray[i])].Get_Distance_to_Other_Node(static_cast<int32_t>(pPathArray[i + 1]));
	}

	return dist;
}

float CGraphNode::Calculate_WeightedPathDistSq(const int32_t *pPathArray, const float *pWeightArray, int32_t numNodes)
{
	float distSq = 0.0f;

	int32_t numNodesMinus1 = numNodes - 1;

	for (int32_t i = 0; i < numNodesMinus1; i++)
	{
		distSq += pWeightArray[i] * pUsedNodeArray[pPathArray[i]].Get_DistanceSq_to_Other_Node(pPathArray[i + 1]);
	}

	return distSq;
}

float CGraphNode::Calculate_WeightedPathDistSq(const int32_t *pPathArray, CWeightMatrix *pWeightMatrix, int32_t numNodes)
{
	float distSq = 0.0f;

	int32_t numNodesMinus1 = numNodes - 1;

	int32_t id1, id2;
	
	for (int32_t i = 0; i < numNodesMinus1; i++)
	{
		id1 = pPathArray[i];
		id2 = pPathArray[i + 1];

		distSq += pWeightMatrix->Get_Weight(id1, id2) * pUsedNodeArray[id1].Get_DistanceSq_to_Other_Node(id2);
	}

	return distSq;
}


float CGraphNode::Calculate_WeightedPathDist(const int32_t *pPathArray, const float *pWeightArray, int32_t numNodes)
{
	float dist = 0.0f;

	int32_t numNodesMinus1 = numNodes - 1;

	for (int32_t i = 0; i < numNodesMinus1; i++)
	{
		dist += pWeightArray[i] * pUsedNodeArray[pPathArray[i]].Get_Distance_to_Other_Node(pPathArray[i + 1]);
	}

	return dist;
}

float CGraphNode::Calculate_WeightedPathDist(const int32_t *pPathArray, CWeightMatrix *pWeightMatrix, int32_t numNodes)
{
	float dist = 0.0f;

	int32_t numNodesMinus1 = numNodes - 1;

	int32_t id1, id2;

	for (int32_t i = 0; i < numNodesMinus1; i++)
	{
		id1 = pPathArray[i];
		id2 = pPathArray[i + 1];

		dist += pWeightMatrix->Get_Weight(id1, id2) * pUsedNodeArray[id1].Get_Distance_to_Other_Node(id2);
	}

	return dist;
}

float CGraphNode::Calculate_WeightedPathDistSq(const float *pPathArray, const float *pWeightArray, int32_t numNodes)
{
	float distSq = 0.0f;

	int32_t numNodesMinus1 = numNodes - 1;

	for (int32_t i = 0; i < numNodesMinus1; i++)
	{
		distSq += pWeightArray[i] * pUsedNodeArray[static_cast<int32_t>(pPathArray[i])].Get_DistanceSq_to_Other_Node(static_cast<int32_t>(pPathArray[i + 1]));
	}

	return distSq;
}

float CGraphNode::Calculate_WeightedPathDistSq(const float *pPathArray, CWeightMatrix *pWeightMatrix, int32_t numNodes)
{
	float distSq = 0.0f;

	int32_t numNodesMinus1 = numNodes - 1;

	int32_t id1, id2;

	for (int32_t i = 0; i < numNodesMinus1; i++)
	{
		id1 = static_cast<int32_t>(pPathArray[i]);
		id2 = static_cast<int32_t>(pPathArray[i + 1]);

		distSq += pWeightMatrix->Get_Weight(id1, id2) * pUsedNodeArray[id1].Get_DistanceSq_to_Other_Node(id2);
	}

	return distSq;
}

float CGraphNode::Calculate_WeightedPathDist(const float *pPathArray, const float *pWeightArray, int32_t numNodes)
{
	float dist = 0.0f;

	int32_t numNodesMinus1 = numNodes - 1;

	for (int32_t i = 0; i < numNodesMinus1; i++)
	{
		dist += pWeightArray[i] * pUsedNodeArray[static_cast<int32_t>(pPathArray[i])].Get_Distance_to_Other_Node(static_cast<int32_t>(pPathArray[i + 1]));
	}

	return dist;
}

float CGraphNode::Calculate_WeightedPathDist(const float *pPathArray, CWeightMatrix *pWeightMatrix, int32_t numNodes)
{
	float dist = 0.0f;

	int32_t numNodesMinus1 = numNodes - 1;

	int32_t id1, id2;

	for (int32_t i = 0; i < numNodesMinus1; i++)
	{
		id1 = static_cast<int32_t>(pPathArray[i]);
		id2 = static_cast<int32_t>(pPathArray[i + 1]);

		dist += pWeightMatrix->Get_Weight(id1, id2) * pUsedNodeArray[id1].Get_Distance_to_Other_Node(id2);
	}

	return dist;
}

void Rearrange_TSP_Path(int32_t *pOutPathArray,int32_t *pInPathArray, int32_t arraySize, int32_t iDofFirstAndLastWaypoint)
{
	int32_t id_InPathArray = 0;
	int32_t arraySizeMinus1 = arraySize - 1;

	for (int32_t i = 0; i < arraySize; i++)
	{
		if (pInPathArray[i] == iDofFirstAndLastWaypoint)
		{
			id_InPathArray = i;
			break;
		}
	}

	int32_t id_OutPathArray = 0;

	for (int32_t i = 0; i < arraySize; i++)
	{
		pOutPathArray[id_OutPathArray] = pInPathArray[id_InPathArray];

		id_OutPathArray++;

		id_InPathArray++;
		id_InPathArray = id_InPathArray % arraySizeMinus1;
	}
}

void Rearrange_TSP_Path(float *pOutPathArray, float *pInPathArray, int32_t arraySize, float iDofFirstAndLastWaypoint)
{
	int32_t id_InPathArray = 0;
	int32_t arraySizeMinus1 = arraySize - 1;

	for (int32_t i = 0; i < arraySize; i++)
	{
		if (pInPathArray[i] == iDofFirstAndLastWaypoint)
		{
			id_InPathArray = i;
			break;
		}
	}

	int32_t id_OutPathArray = 0;

	for (int32_t i = 0; i < arraySize; i++)
	{
		pOutPathArray[id_OutPathArray] = pInPathArray[id_InPathArray];

		id_OutPathArray++;

		id_InPathArray++;
		id_InPathArray = id_InPathArray % arraySizeMinus1;
	}
}

void Rearrange_TSP_Path(int32_t *pOutPathArray, float *pInPathArray, int32_t arraySize, float iDofFirstAndLastWaypoint)
{
	int32_t id_InPathArray = 0;
	int32_t arraySizeMinus1 = arraySize - 1;

	for (int32_t i = 0; i < arraySize; i++)
	{
		if (pInPathArray[i] == iDofFirstAndLastWaypoint)
		{
			id_InPathArray = i;
			break;
		}
	}

	int32_t id_OutPathArray = 0;

	for (int32_t i = 0; i < arraySize; i++)
	{
		pOutPathArray[id_OutPathArray] = static_cast<int32_t>(pInPathArray[id_InPathArray]);

		id_OutPathArray++;

		id_InPathArray++;
		id_InPathArray = id_InPathArray % arraySizeMinus1;
	}
}



