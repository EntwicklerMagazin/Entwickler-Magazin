#include <iostream>
#include "TicTacToe.h"
#include "NeuralNet.h"
#include "ConsoleHelperFunctions.h"

//#define HumanPlayer1
#define NeuralNetPlayer1

#define HumanPlayer2
//#define NeuralNetPlayer2

using namespace std;

#define KEYDOWN(vk_code) ((GetAsyncKeyState(vk_code) & 0x8000) ? 1 : 0)
#define KEYUP(vk_code)   ((GetAsyncKeyState(vk_code) & 0x8000) ? 0 : 1)

static char g_InputBuffer[100];

static uint32_t g_NumPlayer1Wins = 0;
static uint32_t g_NumPlayer2Wins = 0;
static uint32_t g_NumDraws = 0;

static CRandomNumbers_ParkMillerMLKG g_RandomNumbers;


inline float TicTacToePlayingBrainActivation(float neuronInput)
{
	// von 0.0f bis 1.0f:
	//return 1.0f / (1.0f + exp(-20.0f * neuronInput));
	return tanh(2.0f*neuronInput);
}

inline float LinearOutput(float neuronInput)
{
	return neuronInput;
}


inline float TicTacToePlayingBrainActivation1(float neuronInput)
{
	return neuronInput / (1.0f + abs(0.5f * neuronInput));
}

inline float TicTacToePlayingBrainActivation2(float neuronInput)
{
	return 0.5f + 0.5f * neuronInput / (1.0f + abs(0.5f * neuronInput));
}


class CTicTacToePlayingBrain
{
public:

	uint32_t NumInputNeurons = 18;
	uint32_t NumBiasNeurons = 1;
	uint32_t NumHiddenNeurons = 400;
	//uint32_t NumHiddenNeurons = 200;
    //uint32_t NumHiddenNeurons = 20;
	uint32_t NumOutputNeurons = 1;

	uint32_t NumNeurons = NumInputNeurons + NumHiddenNeurons + NumOutputNeurons + NumBiasNeurons;

	uint32_t BiasNeuronID = NumInputNeurons;
	uint32_t FirstHiddenNeuronID = NumInputNeurons + NumBiasNeurons;
	uint32_t OutputNeuronID = NumInputNeurons + NumHiddenNeurons + NumBiasNeurons;

	CNeuron *pNeuronArray = nullptr;

	CRandomNumbersNN RandomNumbers;

	CTicTacToePlayingBrain()
	{
		pNeuronArray = new (std::nothrow) CNeuron[NumNeurons];

		uint32_t i, j, id;

		for (i = 0; i < NumNeurons; i++)
			pNeuronArray[i].Connect_With_Brain(pNeuronArray);

		for (i = 0; i < NumInputNeurons; i++)
		{
			pNeuronArray[i].Use_As_InputNeuron();
			pNeuronArray[i].Init_OutputSynapses(NumHiddenNeurons);
			pNeuronArray[i].Randomize_OutputSynapsePlasticities(&RandomNumbers, -0.2f, 0.2f);
			pNeuronArray[i].Set_LearningRate(0.2f);

			for (j = 0; j < NumHiddenNeurons; j++)
			{
				id = FirstHiddenNeuronID + j;

				pNeuronArray[i].Connect_With_ReceiverNeuron(id, j);
			}
		}

		pNeuronArray[BiasNeuronID].Use_As_BiasNeuron();
		pNeuronArray[BiasNeuronID].Set_BiasNeuronOutput(-1.0f);
		pNeuronArray[BiasNeuronID].Init_OutputSynapses(NumHiddenNeurons);
		pNeuronArray[BiasNeuronID].Randomize_OutputSynapsePlasticities(&RandomNumbers, -0.2f, 0.2f);
		pNeuronArray[BiasNeuronID].Set_LearningRate(0.2f);

		for (j = 0; j < NumHiddenNeurons; j++)
		{
			id = FirstHiddenNeuronID + j;

			pNeuronArray[BiasNeuronID].Connect_With_ReceiverNeuron(id, j);
		}


		for (i = 0; i < NumHiddenNeurons; i++)
		{
			id = FirstHiddenNeuronID + i;
			pNeuronArray[id].Use_As_HiddenNeuron();
			pNeuronArray[id].Init_OutputSynapses(NumOutputNeurons);
			pNeuronArray[id].Randomize_OutputSynapsePlasticities(&RandomNumbers, -0.2f, 0.2f);
			pNeuronArray[id].Set_ActivationFunction(TicTacToePlayingBrainActivation);
			pNeuronArray[id].Set_ErrorFactors(1.0f, 1.0f);
			pNeuronArray[id].Set_LearningRate(0.001f);
			
			pNeuronArray[id].Connect_With_ReceiverNeuron(OutputNeuronID, 0);
		}

		pNeuronArray[OutputNeuronID].Use_As_OutputNeuron();
		pNeuronArray[OutputNeuronID].Set_ActivationFunction(LinearOutput);
		pNeuronArray[OutputNeuronID].Set_ErrorFactors(1.0f, 0.005f);
		//pNeuronArray[OutputNeuronID].Set_LearningRate(0.1f);
	}

	~CTicTacToePlayingBrain()
	{
		delete[] pNeuronArray;
		pNeuronArray = nullptr;
	}

	// Kopierkonstruktor l�schen:
	CTicTacToePlayingBrain(const CTicTacToePlayingBrain &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CTicTacToePlayingBrain& operator=(const CTicTacToePlayingBrain &originalObject) = delete;

	float Calculate_Output(const float *pInputPattern)
	{
		uint32_t i;

		for (i = 0; i < NumInputNeurons; i++)
		{
			pNeuronArray[i].Set_Input(pInputPattern[i]);
			pNeuronArray[i].Propagate_SynapticOutput();
		}

		pNeuronArray[BiasNeuronID].Propagate_SynapticOutput();

		uint32_t id;

		for (i = 0; i < NumHiddenNeurons; i++)
		{
			id = FirstHiddenNeuronID + i;

			pNeuronArray[id].Calculate_NeuronOutput();
			pNeuronArray[id].Propagate_SynapticOutput();
		}

		pNeuronArray[OutputNeuronID].Calculate_NeuronOutput();

		return pNeuronArray[OutputNeuronID].NeuronOutput;
	}

	float Learning(float desiredOutput)
	{
		float error = pNeuronArray[OutputNeuronID].Calculate_Error(desiredOutput);

		uint32_t i;
		uint32_t id;

		for (i = 0; i < NumHiddenNeurons; i++)
		{
			id = FirstHiddenNeuronID + i;
			pNeuronArray[id].Calculate_Error();
		}

		for (i = 0; i < NumHiddenNeurons; i++)
		{
			id = FirstHiddenNeuronID + i;
			pNeuronArray[id].Adjust_OutputSynapses_AfterErrorCalculations();
		}

		for (uint32_t i = 0; i < NumInputNeurons; i++)
			pNeuronArray[i].Adjust_OutputSynapses_AfterErrorCalculations();

		pNeuronArray[BiasNeuronID].Adjust_OutputSynapses_AfterErrorCalculations();

		return error;
	}
};

static void HumanPlayerMove(CGameState *pGameState, uint8_t player)
{
	if (pGameState->NumEmptyBoardPositions == 0)
		return;


	uint32_t row, column;

	bool moveCompleted = false;

	do
	{
		cout << "Player Move - select row: ";
		cin.getline(g_InputBuffer, 100);

		// C-String in eine Ganzzahl umrechnen:
		row = atoi(g_InputBuffer);

		cout << "Player Move - select column: ";
		cin.getline(g_InputBuffer, 100);

		// C-String in eine Ganzzahl umrechnen:
		column = atoi(g_InputBuffer);

		moveCompleted = pGameState->Make_Move(row, column, player);

		cout << endl;

	} while (moveCompleted == false);
}

static void AIPlayer_RandomMove(CGameState *pGameState, uint8_t player)
{
	if (pGameState->NumEmptyBoardPositions == 0)
		return;

	uint32_t row, column;

	bool moveCompleted = false;

	do
	{
		row = g_RandomNumbers.Get_UnsignedIntegerNumber(0, ConstNumBoardRows);
		column = g_RandomNumbers.Get_UnsignedIntegerNumber(0, ConstNumBoardColumns);

		moveCompleted = pGameState->Make_Move(row, column, player);

	} while (moveCompleted == false);
}

static bool AIPlayer_MakeWinMoveIfPossible(CGameState *pGameState, uint8_t player)
{
	if (pGameState->NumEmptyBoardPositions == 0)
		return false;

	uint32_t row, column;

	if (player == ConstBoardSymbol_Player1)
	{
		for (row = 0; row < ConstNumBoardRows; row++)
		{
			for (column = 0; column < ConstNumBoardColumns; column++)
			{
				if (pGameState->Board[row][column] == ConstBoardSymbol_Empty)
				{
					pGameState->Make_Move(row, column, player);

					if (pGameState->Evaluate_Player1() > 0.0f) // win move!
						return true;

					pGameState->Reset_LastMove_RowColumn();
				}
			}
		}
	}

	if (player == ConstBoardSymbol_Player2)
	{
		for (row = 0; row < ConstNumBoardRows; row++)
		{
			for (column = 0; column < ConstNumBoardColumns; column++)
			{
				if (pGameState->Board[row][column] == ConstBoardSymbol_Empty)
				{
					pGameState->Make_Move(row, column, player);

					if (pGameState->Evaluate_Player2() > 0.0f) // win move!
						return true;

					pGameState->Reset_LastMove_RowColumn();
				}
			}
		}
	}

	return false;
}

static void AIPlayer_RandomOrWinMove(CGameState *pGameState, uint8_t player)
{
	if (pGameState->NumEmptyBoardPositions == 0)
		return;

	uint32_t row, column;

	if (player == ConstBoardSymbol_Player1)
	{
		for (row = 0; row < ConstNumBoardRows; row++)
		{
			for (column = 0; column < ConstNumBoardColumns; column++)
			{
				if (pGameState->Board[row][column] == ConstBoardSymbol_Empty)
				{
					pGameState->Make_Move(row, column, player);

					if (pGameState->Evaluate_Player1() > 0.0f) // win move!
						return;

					pGameState->Reset_LastMove_RowColumn();
				}
			}
		}
	}

	if (player == ConstBoardSymbol_Player2)
	{
		for (row = 0; row < ConstNumBoardRows; row++)
		{
			for (column = 0; column < ConstNumBoardColumns; column++)
			{
				if (pGameState->Board[row][column] == ConstBoardSymbol_Empty)
				{
					pGameState->Make_Move(row, column, player);

					if (pGameState->Evaluate_Player2() > 0.0f) // win move!
						return;

					pGameState->Reset_LastMove_RowColumn();
				}
			}
		}
	}


	bool moveCompleted = false;

	do
	{
		row = g_RandomNumbers.Get_UnsignedIntegerNumber(0, ConstNumBoardRows);
		column = g_RandomNumbers.Get_UnsignedIntegerNumber(0, ConstNumBoardColumns);

		moveCompleted = pGameState->Make_Move(row, column, player);

	} while (moveCompleted == false);
}

static bool Check_If_Game_Is_Finished(CGameState *pGameState)
{
	float EvaluationValuePlayer1;
	float EvaluationValuePlayer2;


	EvaluationValuePlayer1 = pGameState->Evaluate_Player1();

	if (EvaluationValuePlayer1 > 0.0f)
	{
		cout << "Player 1 Winner!" << endl << endl;
		g_NumPlayer1Wins++;
		return true;
	}

	EvaluationValuePlayer2 = pGameState->Evaluate_Player2();

	if (EvaluationValuePlayer2 > 0.0f)
	{
		cout << "Player 2 Winner!" << endl << endl;
		g_NumPlayer2Wins++;
		return true;
	}

	if (pGameState->NumEmptyBoardPositions == 0)
	{
		if (EvaluationValuePlayer1 == 0.0f && EvaluationValuePlayer2 == 0.0f)
		{
			cout << "Draw" << endl << endl;
			g_NumDraws++;
			return true;
		}
	}

	return false;
}

static bool Check_If_TrainingGame_Is_Finished(CGameState *pGameState)
{
	float EvaluationValuePlayer1;
	float EvaluationValuePlayer2;


	EvaluationValuePlayer1 = pGameState->Evaluate_Player1();

	if (EvaluationValuePlayer1 > 0.0f)
	{
		//cout << "Player 1 Winner!" << endl << endl;
		//g_NumPlayer1Wins++;
		return true;
	}

	EvaluationValuePlayer2 = pGameState->Evaluate_Player2();

	if (EvaluationValuePlayer2 > 0.0f)
	{
		//cout << "Player 2 Winner!" << endl << endl;
		//g_NumPlayer2Wins++;
		return true;
	}

	if (pGameState->NumEmptyBoardPositions == 0)
	{
		if (EvaluationValuePlayer1 == 0.0f && EvaluationValuePlayer2 == 0.0f)
		{
			//cout << "Draw" << endl << endl;
			//g_NumDraws++;
			return true;
		}
	}

	return false;
}



static void NeuralNetPlayer(CTicTacToePlayingBrain *pBrain, CGameState *pGameState)
{
	if (pGameState->NumEmptyBoardPositions == 0)
		return;

	uint32_t index = static_cast<uint32_t>(10.0f * pBrain->Calculate_Output(pGameState->BoardDataArray));

	index = min(index, 8);

	uint32_t column = index % ConstNumBoardColumns;
	uint32_t row = index / ConstNumBoardColumns;

	if (pGameState->Board[row][column] == ConstBoardSymbol_Empty)
	{
#ifdef NeuralNetPlayer1
		pGameState->Make_Move(row, column, ConstBoardSymbol_Player1);
#else
		pGameState->Make_Move(row, column, ConstBoardSymbol_Player2);
#endif
		return;
	}

	cout << endl << "illegal move proposal, alternative move:" << endl << endl;

#ifdef NeuralNetPlayer1
	//AIPlayer_RandomMove(pGameState, ConstBoardSymbol_Player1);
	AIPlayer_RandomOrWinMove(pGameState, ConstBoardSymbol_Player1);
#else
	//AIPlayer_RandomMove(pGameState, ConstBoardSymbol_Player2);
	AIPlayer_RandomOrWinMove(pGameState, ConstBoardSymbol_Player2);
#endif
}

static void NeuralNetPlayer(CNeuralNet *pBrain, CGameState *pGameState)
{
	if (pGameState->NumEmptyBoardPositions == 0)
		return;

	float brainOutput;

	pBrain->Calculate_Output(&brainOutput, pGameState->BoardDataArray);

	uint32_t index = static_cast<uint32_t>(10.0f * brainOutput);

	index = min(index, 8);

	uint32_t column = index % ConstNumBoardColumns;
	uint32_t row = index / ConstNumBoardColumns;

	if (pGameState->Board[row][column] == ConstBoardSymbol_Empty)
	{
#ifdef NeuralNetPlayer1
		pGameState->Make_Move(row, column, ConstBoardSymbol_Player1);
#else
		pGameState->Make_Move(row, column, ConstBoardSymbol_Player2);
#endif
		return;
	}

	cout << endl << "illegal move proposal, alternative move:" << endl << endl;

#ifdef NeuralNetPlayer1
	//AIPlayer_RandomMove(pGameState, ConstBoardSymbol_Player1);
	AIPlayer_RandomOrWinMove(pGameState, ConstBoardSymbol_Player1);
#else
	//AIPlayer_RandomMove(pGameState, ConstBoardSymbol_Player2);
	AIPlayer_RandomOrWinMove(pGameState, ConstBoardSymbol_Player2);
#endif
}



static constexpr uint32_t NumTrainingGames = 1000;



// Backpropagation Deep Learning:
/*
int main(void)
{
	cout << "TIC TAC TOE" << endl << endl;

	cout << "Generating Training Games ..." << endl << endl;

	uint8_t Board[3][3];
	CGameState GameState;

	CNeuralNet TicTacToePlayingBrain;

	float minPlasticityVariance = -0.1f;
	float maxPlasticityVariance = 0.1f;

	TicTacToePlayingBrain.Init_NeuralNet(121);
	TicTacToePlayingBrain.Init_Input_And_OutputNeurons(18, 0.1f, false, 1, LinearOutput);
	TicTacToePlayingBrain.Init_HiddenLayer1(60, false, false, TicTacToePlayingBrainActivation, minPlasticityVariance, maxPlasticityVariance, minPlasticityVariance, maxPlasticityVariance, 0.05f);
	TicTacToePlayingBrain.Init_HiddenLayer2(42, false, true, TicTacToePlayingBrainActivation, minPlasticityVariance, maxPlasticityVariance, minPlasticityVariance, maxPlasticityVariance, 0.0125f);

	


	static CRecordedGame TrainingGameArray[NumTrainingGames];

	for(uint32_t i = 0; i < NumTrainingGames; i++)
	{
		uint32_t moveCounter = 0;

		GameState.Reset_Bord();

		// Beginn eines neuen Spiels:
		do
		{
#ifdef NeuralNetPlayer1

			if (moveCounter == 0)
				GameState.Make_Move(0, 0, ConstBoardSymbol_Player1);
			else
			{
				if (AIPlayer_MakeWinMoveIfPossible(&GameState, ConstBoardSymbol_Player1) == false)
				{
					GameState.Get_BoardData(Board);

					CMove bestMove = Find_BestMovePlayer1(Board);

					GameState.Make_Move(bestMove.row, bestMove.column, ConstBoardSymbol_Player1);
				}
			}
#else
			AIPlayer_RandomMove(&GameState, ConstBoardSymbol_Player1);
			//AIPlayer_RandomOrWinMove(&GameState, ConstBoardSymbol_Player1);
#endif

			TrainingGameArray[i].Record_Move(GameState.LastMove_Row, GameState.LastMove_Column);

			moveCounter++;

			if (Check_If_TrainingGame_Is_Finished(&GameState) == true)
				break;

#ifdef NeuralNetPlayer2

			if (moveCounter == 1 && GameState.Board[1][1] == ConstBoardSymbol_Empty)
				GameState.Make_Move(1, 1, ConstBoardSymbol_Player2);
			else
			{
				if (AIPlayer_MakeWinMoveIfPossible(&GameState, ConstBoardSymbol_Player2) == false)
				{
					GameState.Get_BoardData(Board);

					CMove bestMove = Find_BestMovePlayer2(Board);

					GameState.Make_Move(bestMove.row, bestMove.column, ConstBoardSymbol_Player2);
				}
			}

#else

			AIPlayer_RandomMove(&GameState, ConstBoardSymbol_Player2);
			//AIPlayer_RandomOrWinMove(&GameState, ConstBoardSymbol_Player2);
#endif

			TrainingGameArray[i].Record_Move(GameState.LastMove_Row, GameState.LastMove_Column);

			moveCounter++;

			// Ende des laufenden Spiels:
			if (Check_If_TrainingGame_Is_Finished(&GameState) == true)
				break;
		} while (true);

	} // end of for(uint32_t i = 0; i < NumTrainingGames; i++)

	

	uint32_t maxcount = 1000;
	uint32_t epoch = 0;
	float error;
	float desiredMove;

	for (uint32_t e = 0; e < maxcount; e++)
	{
		epoch++;
		error = 0.0f;

		for (uint32_t i = 0; i < NumTrainingGames; i++)
		{
			GameState.Reset_Bord();

			uint32_t moveCounter = 0;

			// Beginn eines neuen Spiels:
			do
			{
#ifdef NeuralNetPlayer1
				float brainOutput;
				TicTacToePlayingBrain.Calculate_Output(&brainOutput, GameState.BoardDataArray);
#endif				
				GameState.Make_Move(TrainingGameArray[i].MoveArray[moveCounter].row, TrainingGameArray[i].MoveArray[moveCounter].column, ConstBoardSymbol_Player1);

#ifdef NeuralNetPlayer1
				desiredMove = 0.01f + 0.1f * static_cast<float>(GameState.LastMove_Column + GameState.LastMove_Row * ConstNumBoardColumns);
				error += TicTacToePlayingBrain.Learning(&desiredMove);
#endif	

				moveCounter++;

				if (moveCounter == TrainingGameArray[i].NumMoves)
					break;

#ifdef NeuralNetPlayer2
				float brainOutput;
				TicTacToePlayingBrain.Calculate_Output(&brainOutput, GameState.BoardDataArray);
#endif
				GameState.Make_Move(TrainingGameArray[i].MoveArray[moveCounter].row, TrainingGameArray[i].MoveArray[moveCounter].column, ConstBoardSymbol_Player2);

#ifdef NeuralNetPlayer2
				desiredMove = 0.01f + 0.1f * static_cast<float>(GameState.LastMove_Column + GameState.LastMove_Row * ConstNumBoardColumns);
				error += TicTacToePlayingBrain.Learning(&desiredMove);
#endif

				moveCounter++;

				if (moveCounter == TrainingGameArray[i].NumMoves)
					break;

			}
			// Ende des aufgezeichneten Spiels:
			while (true);
		} // end of for (uint32_t i = 0; i < NumTrainingGames; i++)

		cout << "epoch: " << epoch << endl;
		cout << "error: " << error << endl << endl;

		if (error < 0.0005f)
			break;

	} // end of for (uint32_t e = 0; e < maxcount; e++)

	
	//cout << "epoch: " << epoch << endl;
	//cout << "error: " << error << endl << endl;

	GameState.Reset_Bord();

	while (true) // Game Loop
	{
		cout << endl << "Num Player 1 Wins: " << g_NumPlayer1Wins << endl;
		cout << "Num Player 2 Wins: " << g_NumPlayer2Wins << endl;
		cout << "Num Draws: " << g_NumDraws << endl << endl;

		GameState.Output();

		uint32_t moveCounter = 0;

		// Beginn eines neuen Spiels:
		do
		{
			cout << "Player 1 Move: " << endl << endl;

#ifdef HumanPlayer1
			HumanPlayerMove(&GameState, ConstBoardSymbol_Player1);
#else
			NeuralNetPlayer(&TicTacToePlayingBrain, &GameState);
#endif
			GameState.Output();

			moveCounter++;

			if (Check_If_Game_Is_Finished(&GameState) == true)
				break;


			cout << "Player 2 Move: " << endl << endl;

#ifdef HumanPlayer2
			HumanPlayerMove(&GameState, ConstBoardSymbol_Player2);
#else
			NeuralNetPlayer(&TicTacToePlayingBrain, &GameState);
#endif

			GameState.Output();

			moveCounter++;

			if (Check_If_Game_Is_Finished(&GameState) == true)
				break;

		}
		// Ende des laufenden Spiels:
		while (true);

		cout << "New Game (0/1): ";
		cin.getline(g_InputBuffer, 100);

		cout << endl << endl;

		// C-String in eine Ganzzahl umrechnen:
		if (atoi(g_InputBuffer) != 1)
			break;

		GameState.Reset_Bord();
	} // end of while (true) // Game Loop

	cout << "Bye Bye";

	getchar();
	return 0;
}
*/

// Backpropagation Learning:
/*
int main(void)
{
	cout << "TIC TAC TOE" << endl << endl;

	cout << "Generating Training Games ..." << endl << endl;

	uint8_t Board[3][3];
	CGameState GameState;

	CTicTacToePlayingBrain TicTacToePlayingBrain;

	static CRecordedGame TrainingGameArray[NumTrainingGames];

	for (uint32_t i = 0; i < NumTrainingGames; i++)
	{
		uint32_t moveCounter = 0;

		GameState.Reset_Bord();

		// Beginn eines neuen Spiels:
		do
		{
#ifdef NeuralNetPlayer1

			if (moveCounter == 0)
				GameState.Make_Move(0, 0, ConstBoardSymbol_Player1);
			else
			{
				if (AIPlayer_MakeWinMoveIfPossible(&GameState, ConstBoardSymbol_Player1) == false)
				{
					GameState.Get_BoardData(Board);

					CMove bestMove = Find_BestMovePlayer1(Board);

					GameState.Make_Move(bestMove.row, bestMove.column, ConstBoardSymbol_Player1);
				}
			}
#else
			AIPlayer_RandomMove(&GameState, ConstBoardSymbol_Player1);
			//AIPlayer_RandomOrWinMove(&GameState, ConstBoardSymbol_Player1);
#endif

			TrainingGameArray[i].Record_Move(GameState.LastMove_Row, GameState.LastMove_Column);

			moveCounter++;

			if (Check_If_TrainingGame_Is_Finished(&GameState) == true)
				break;

#ifdef NeuralNetPlayer2

			if (moveCounter == 1 && GameState.Board[1][1] == ConstBoardSymbol_Empty)
				GameState.Make_Move(1, 1, ConstBoardSymbol_Player2);
			else
			{
				if (AIPlayer_MakeWinMoveIfPossible(&GameState, ConstBoardSymbol_Player2) == false)
				{
					GameState.Get_BoardData(Board);

					CMove bestMove = Find_BestMovePlayer2(Board);

					GameState.Make_Move(bestMove.row, bestMove.column, ConstBoardSymbol_Player2);
				}
			}

#else

			AIPlayer_RandomMove(&GameState, ConstBoardSymbol_Player2);
			//AIPlayer_RandomOrWinMove(&GameState, ConstBoardSymbol_Player2);
#endif

			TrainingGameArray[i].Record_Move(GameState.LastMove_Row, GameState.LastMove_Column);

			moveCounter++;

			if (Check_If_TrainingGame_Is_Finished(&GameState) == true)
				break;
		}
		// Ende des laufenden Spiels:
		while (true);

	} // end of for (uint32_t i = 0; i < NumTrainingGames; i++)



	uint32_t maxcount = 1000;
	uint32_t epoch = 0;
	float error;
	float desiredMove;

	for (uint32_t e = 0; e < maxcount; e++)
	{
		epoch++;
		error = 0.0f;

		for (uint32_t i = 0; i < NumTrainingGames; i++)
		{
			GameState.Reset_Bord();

			uint32_t moveCounter = 0;

			do
			{
#ifdef NeuralNetPlayer1
				TicTacToePlayingBrain.Calculate_Output(GameState.BoardDataArray);
#endif				
				GameState.Make_Move(TrainingGameArray[i].MoveArray[moveCounter].row, TrainingGameArray[i].MoveArray[moveCounter].column, ConstBoardSymbol_Player1);

#ifdef NeuralNetPlayer1
				desiredMove = 0.01f + 0.1f * static_cast<float>(GameState.LastMove_Column + GameState.LastMove_Row * ConstNumBoardColumns);
				error += TicTacToePlayingBrain.Learning(desiredMove);
#endif	

				moveCounter++;

				if (moveCounter == TrainingGameArray[i].NumMoves)
					break;

#ifdef NeuralNetPlayer2
				TicTacToePlayingBrain.Calculate_Output(GameState.BoardDataArray);
#endif
				GameState.Make_Move(TrainingGameArray[i].MoveArray[moveCounter].row, TrainingGameArray[i].MoveArray[moveCounter].column, ConstBoardSymbol_Player2);

#ifdef NeuralNetPlayer2
				desiredMove = 0.01f + 0.1f * static_cast<float>(GameState.LastMove_Column + GameState.LastMove_Row * ConstNumBoardColumns);
				error += TicTacToePlayingBrain.Learning(desiredMove);
#endif

				moveCounter++;

				if (moveCounter == TrainingGameArray[i].NumMoves)
					break;

			}
			// Ende des aufgezeichneten Spiels:
			while (true);
		} // end of for (uint32_t i = 0; i < NumTrainingGames; i++)

		cout << "epoch: " << epoch << endl;
		cout << "error: " << error << endl << endl;

		if (error < 0.0005f)
			break;

	} // end of for (uint32_t e = 0; e < maxcount; e++)


	  //cout << "epoch: " << epoch << endl;
	  //cout << "error: " << error << endl << endl;

	GameState.Reset_Bord();

	while (true) // Game Loop
	{
		cout << endl << "Num Player 1 Wins: " << g_NumPlayer1Wins << endl;
		cout << "Num Player 2 Wins: " << g_NumPlayer2Wins << endl;
		cout << "Num Draws: " << g_NumDraws << endl << endl;

		GameState.Output();

		uint32_t moveCounter = 0;

		// Beginn eines neuen Spiels:
		do
		{
			cout << "Player 1 Move: " << endl << endl;

#ifdef HumanPlayer1
			HumanPlayerMove(&GameState, ConstBoardSymbol_Player1);
#else
			NeuralNetPlayer(&TicTacToePlayingBrain, &GameState);
#endif
			GameState.Output();

			moveCounter++;

			if (Check_If_Game_Is_Finished(&GameState) == true)
				break;


			cout << "Player 2 Move: " << endl << endl;

#ifdef HumanPlayer2
			HumanPlayerMove(&GameState, ConstBoardSymbol_Player2);
#else
			NeuralNetPlayer(&TicTacToePlayingBrain, &GameState);
#endif

			GameState.Output();

			moveCounter++;

			if (Check_If_Game_Is_Finished(&GameState) == true)
				break;

		}
		// Ende des laufenden Spiels:
		while (true);

		cout << "New Game (0/1): ";
		cin.getline(g_InputBuffer, 100);

		cout << endl << endl;

		// C-String in eine Ganzzahl umrechnen:
		if (atoi(g_InputBuffer) != 1)
			break;

		GameState.Reset_Bord();
	} // end of while (true) // Game Loop

	cout << "Bye Bye";

	getchar();
	return 0;
}
*/



