#include "NeuralNet_V2.h"
#include "LogFile.h"

using namespace std;
using namespace HelperStuff;

float DendriteCentroidDistance(float neuronInput, float centroidValue)
{
	return  neuronInput - centroidValue;
}

float MinDendriteCentroidDistance(float neuronInput, float centroidValue)
{
	return  min(neuronInput, centroidValue) - centroidValue;
}

float MaxDendriteCentroidDistance(float neuronInput, float centroidValue)
{
	return  max(neuronInput, centroidValue) - centroidValue;
}

void _Calculate_Error(float *pOutErrorValue, float *pOutVariance, float desiredValue, float actualValue, float errorFactor1, float errorFactor2)
{
	// Abweichung:
	float variance = desiredValue - actualValue;

	*pOutVariance = variance * variance;

	*pOutErrorValue = variance * errorFactor1 * exp(-(errorFactor2 * actualValue * actualValue));

	/* Hinweis: Wenn bereits eine geringe Neuronenaktivit�t (actualValue)
	zu einer gro�en Abweichung f�hrt, ist auch der Fehler gro�. Abweichungen
	bei einer starken Neuronenaktivit�t f�hren hingegen zu einem kleineren
	Fehler. */
}

void _Calculate_Errors(int32_t numOfValues, float *pOutErrorValueArray, float *pOutVarianceArray, float *pInDesiredValueArray, float *pInActualValueArray, float errorFactor1, float errorFactor2)
{
	float variance, actualValueSq;

	for (int32_t i = 0; i < numOfValues; i++)
	{
		variance = pInDesiredValueArray[i] - pInActualValueArray[i];

		pOutVarianceArray[i] = variance * variance;

		actualValueSq = pInActualValueArray[i];
		actualValueSq *= actualValueSq;

		pOutErrorValueArray[i] = variance * errorFactor1 * exp(-(errorFactor2 * actualValueSq));
		
	}

	/* Hinweis: Wenn bereits eine geringe Neuronenaktivit�t (actualValue)
	zu einer gro�en Abweichung f�hrt, ist auch der Fehler gro�. Abweichungen
	bei einer starken Neuronenaktivit�t f�hren hingegen zu einem kleineren
	Fehler. */

}

void LinearActivationFunction(CNeuronV2 *pNeuron)
{
	pNeuron->Dendrite_InputCounter = 0;
	pNeuron->NeuronOutput = pNeuron->NeuronInput;
	pNeuron->NeuronInput = 0.0f;
}

void NegLinearActivationFunction(CNeuronV2 *pNeuron)
{
	pNeuron->Dendrite_InputCounter = 0;
	pNeuron->NeuronOutput = -pNeuron->NeuronInput;
	pNeuron->NeuronInput = 0.0f;
}

void TanHActivationFunction(CNeuronV2 *pNeuron)
{
	// von -1.0f bis 1.0f:
	pNeuron->Dendrite_InputCounter = 0;
	pNeuron->NeuronOutput = tanh(pNeuron->NeuronInput);
	pNeuron->NeuronInput = 0.0f;
}

void FastTanHApproxActivationFunction(CNeuronV2 *pNeuron)
{
	// von -1.0f bis 1.0f:
	pNeuron->Dendrite_InputCounter = 0;
	pNeuron->NeuronOutput = pNeuron->NeuronInput / (1.0f + abs(pNeuron->NeuronInput));
	pNeuron->NeuronInput = 0.0f;
}

void FastSigmoidApproxActivationFunction(CNeuronV2 *pNeuron)
{
	// von -1.0f bis 1.0f:
	pNeuron->Dendrite_InputCounter = 0;
	pNeuron->NeuronOutput = 0.5f + 0.5f*pNeuron->NeuronInput / (1.0f + abs(pNeuron->NeuronInput));
	pNeuron->NeuronInput = 0.0f;
}

void SigmoidActivationFunction(CNeuronV2 *pNeuron)
{
	// von 0.0f bis 1.0f:
	pNeuron->Dendrite_InputCounter = 0;
	pNeuron->NeuronOutput = 1.0f / (1.0f + exp(-pNeuron->NeuronInput));
	pNeuron->NeuronInput = 0.0f;
}

void ReLUActivationFunction(CNeuronV2 *pNeuron)
{
	pNeuron->Dendrite_InputCounter = 0;
	pNeuron->NeuronOutput = max(0.0f, pNeuron->NeuronInput);
	pNeuron->NeuronInput = 0.0f;
}

void LeakyReLUActivationFunction(CNeuronV2 *pNeuron)
{
	pNeuron->Dendrite_InputCounter = 0;
	pNeuron->NeuronOutput = pNeuron->NeuronInput;

	if (pNeuron->NeuronInput < 0.0f)
		pNeuron->NeuronOutput *= 0.01f;
	
	pNeuron->NeuronInput = 0.0f;
}

void BinaryActivationFunction(CNeuronV2 *pNeuron)
{
	pNeuron->Dendrite_InputCounter = 0;

	pNeuron->NeuronOutput = 0.0f;

	if (pNeuron->NeuronInput > pNeuron->MinNeuronOutputTreshold)
		pNeuron->NeuronOutput = 1.0f;

	pNeuron->NeuronInput = 0.0f;
}

void BinaryActivationFunctionExt(CNeuronV2 *pNeuron)
{
	pNeuron->Dendrite_InputCounter = 0;

	pNeuron->NeuronOutput = 0.0f;

	if (pNeuron->NeuronInput > pNeuron->MinNeuronOutputTreshold && pNeuron->NeuronInput < pNeuron->MaxNeuronOutputValue)
		pNeuron->NeuronOutput = 1.0f;

	pNeuron->NeuronInput = 0.0f;
}




void BiasActivationFunction(CNeuronV2 *pNeuron)
{
	pNeuron->NeuronOutput = 1.0f;
}

void FindMaximumDendriteActivation(CNeuronV2 *pNeuron)
{
	float diff;
	int32_t dendriteID;
	float tempVarianceSum;
	int32_t firstDendriteID;

	int32_t usedDendritesMinID = pNeuron->UsedDendritesMinID;
	int32_t usedDendritesMaxIDPlus1 = pNeuron->UsedDendritesMaxIDPlus1;
	int32_t dendrite_InputCounter = pNeuron->Dendrite_InputCounter;

	float *pDendrite_CentroidValueArray = pNeuron->pDendrite_CentroidValueArray;
	float *pDendrite_FactorArray = pNeuron->pDendrite_FactorArray;
	float *pDendrite_InputValueArray = pNeuron->pDendrite_InputValueArray;


	float minVariance = 10000000.0f;

	firstDendriteID = usedDendritesMinID;

	do
	{
		if (firstDendriteID + dendrite_InputCounter > usedDendritesMaxIDPlus1)
			break;

		tempVarianceSum = 0.0f;

		for (int32_t i = 0; i < dendrite_InputCounter; i++)
		{
			dendriteID = i + firstDendriteID;

			diff = pDendrite_InputValueArray[i] - pDendrite_CentroidValueArray[dendriteID];
			diff *= diff;

			tempVarianceSum += pDendrite_FactorArray[dendriteID] * diff;
		}

		minVariance = min(minVariance, tempVarianceSum);

		if (minVariance < 0.01f)
			break;

		firstDendriteID += dendrite_InputCounter;
	} while (true);

	pNeuron->Dendrite_InputCounter = 0;

	//pNeuron->NeuronOutput = exp(-minVariance);
	pNeuron->NeuronOutput = max(0.0f, 1.0f - minVariance);
}

void FindMaximumDendriteActivation1(CNeuronV2 *pNeuron)
{
	float diff;
	int32_t dendriteID;
	float tempVarianceSum;
	int32_t firstDendriteID;


	float neuronOutput = 0.0f;
	

	int32_t usedDendritesMinID = pNeuron->UsedDendritesMinID;
	int32_t usedDendritesMaxIDPlus1 = pNeuron->UsedDendritesMaxIDPlus1;
	int32_t dendrite_InputCounter = pNeuron->Dendrite_InputCounter;

	float *pDendrite_CentroidValueArray = pNeuron->pDendrite_CentroidValueArray;
	float *pDendrite_FactorArray = pNeuron->pDendrite_FactorArray;
	float *pDendrite_InputValueArray = pNeuron->pDendrite_InputValueArray;

	firstDendriteID = usedDendritesMinID;

	do
	{
		if (firstDendriteID + dendrite_InputCounter > usedDendritesMaxIDPlus1)
			break;

		tempVarianceSum = 0.0f;

		for (int32_t i = 0; i < dendrite_InputCounter; i++)
		{
			dendriteID = i + firstDendriteID;

			diff = pDendrite_InputValueArray[i] - pDendrite_CentroidValueArray[dendriteID];
			diff *= diff;

			tempVarianceSum += pDendrite_FactorArray[dendriteID] * diff;
		}
	
		neuronOutput = max(neuronOutput, exp(-tempVarianceSum));

		if (neuronOutput > 0.99f)
			break;

		firstDendriteID += dendrite_InputCounter;
	} while (true);

	pNeuron->Dendrite_InputCounter = 0;

	pNeuron->NeuronOutput = neuronOutput;

	//if (neuronOutput > 0.9f)
	//pNeuron->NeuronOutput = 1.0f;
	//else
	//pNeuron->NeuronOutput = 0.0f;
}


void FindMaximumDendriteActivation2(CNeuronV2 *pNeuron)
{
	float diff;
	int32_t dendriteID;
	float tempVarianceSum;
	int32_t firstDendriteID;


	int32_t usedDendritesMinID = pNeuron->UsedDendritesMinID;
	int32_t usedDendritesMaxIDPlus1 = pNeuron->UsedDendritesMaxIDPlus1;
	int32_t dendrite_InputCounter = pNeuron->Dendrite_InputCounter;

	float *pDendrite_CentroidValueArray = pNeuron->pDendrite_CentroidValueArray;
	float *pDendrite_FactorArray = pNeuron->pDendrite_FactorArray;
	float *pDendrite_InputValueArray = pNeuron->pDendrite_InputValueArray;

	float minVariance = 10000000.0f;

	firstDendriteID = usedDendritesMinID;

	do
	{
		if (firstDendriteID + dendrite_InputCounter > usedDendritesMaxIDPlus1)
			break;

		tempVarianceSum = 0.0f;

		for (int32_t i = 0; i < dendrite_InputCounter; i++)
		{
			dendriteID = i + firstDendriteID;

			diff = pDendrite_InputValueArray[i] - pDendrite_CentroidValueArray[dendriteID];
			diff *= diff;

			tempVarianceSum += pDendrite_FactorArray[dendriteID] * diff;
		}

		minVariance = min(minVariance, tempVarianceSum);

		if (minVariance < 0.01f)
			break;

		firstDendriteID += dendrite_InputCounter;
	} while (true);

	pNeuron->Dendrite_InputCounter = 0;

	float activation = exp(-minVariance);

	pNeuron->NeuronOutput = activation;

	//if (activation > 0.9f)
	//pNeuron->NeuronOutput = 1.0f;
	//else
	//pNeuron->NeuronOutput = 0.0f;
}





void StandardRBFActivationFunction2(CNeuronV2 *pNeuron)
{
	int32_t num_Of_Dendrite_Elements = pNeuron->Num_Of_Dendrite_Elements;

	float diff;
	//int32_t RBF_CentroidDistanceFuncID;
	float output = 0.0f;

	for(int32_t i = 0; i < num_Of_Dendrite_Elements; i++)
	{
		//RBF_CentroidDistanceFuncID = pNeuron->pDendrite_CentroidDistanceFuncIDArray[i];
		//diff = pNeuron->pDendriteCentroidDistanceFuncArray[RBF_CentroidDistanceFuncID](pNeuron->pDendrite_InputValueArray[i], pNeuron->pDendrite_CentroidValueArray[i]);
		
		diff = pNeuron->pDendrite_InputValueArray[i] - pNeuron->pDendrite_CentroidValueArray[i];
		diff *= diff;

		output += pNeuron->pDendrite_FactorArray[i] * diff;
	}

	pNeuron->NeuronOutput = exp(-output);
	pNeuron->Dendrite_InputCounter = 0;
}

void StandardRBFActivationFunction(CNeuronV2 *pNeuron)
{
	pNeuron->Dendrite_InputCounter = 0;

	// von 0.0f bis 1.0f:
	pNeuron->NeuronOutput = exp(-pNeuron->NeuronInput);  // sehr gro�er Unterschied schon bei kleinen Abweichungen!
	//pNeuron->NeuronOutput = exp(-pow(pNeuron->NeuronInput, 0.25f));
	//pNeuron->NeuronOutput = exp(-sqrt(pNeuron->NeuronInput));
	//pNeuron->NeuronOutput = 1.0f / (pNeuron->NeuronInput + 0.0001f);
	//pNeuron->NeuronOutput =  max(0.0f, 1.0f - 0.05f * pNeuron->NeuronInput * pNeuron->NeuronInput);
	//pNeuron->NeuronOutput =  max(0.0f, 1.0f - 0.05f * pNeuron->NeuronInput);
	
	//float tempFloat = max(0.0f, 1.0f - 0.05f * pNeuron->NeuronInput);
	//pNeuron->NeuronOutput = tempFloat * tempFloat;

	pNeuron->NeuronInput = 0.0f;	
}

void StandardInvRBFActivationFunction(CNeuronV2 *pNeuron)
{
	pNeuron->Dendrite_InputCounter = 0;

	// von 0.0f bis 1.0f:
	pNeuron->NeuronOutput = 1.0f - exp(-pNeuron->NeuronInput);  

	pNeuron->NeuronInput = 0.0f;
}



void StandardSynapticFunction_Use_All_Connections(CNeuronV2 *pNeuron)
{
	CNeuronV2 *pUsedNeuronArray = pNeuron->pUsedNeuronArray;

	int32_t *pReceiverNeuronIDArray = pNeuron->pReceiverNeuronIDArray;

	float *pOutputSynapsePlasticityArray = pNeuron->pOutputSynapsePlasticityArray;

	float neuronOutput = pNeuron->NeuronOutput;

	int32_t numOfOutputSynapses = pNeuron->NumOfOutputSynapses;

	int32_t receiverNeuronID;

	for (int32_t i = 0; i < numOfOutputSynapses; i++)
	{
		receiverNeuronID = pReceiverNeuronIDArray[i];
		pUsedNeuronArray[receiverNeuronID].NeuronInput += pOutputSynapsePlasticityArray[i] * neuronOutput;
	}
}

void StandardSynapticFunction(CNeuronV2 *pNeuron)
{
	CNeuronV2 *pUsedNeuronArray = pNeuron->pUsedNeuronArray;

	int32_t *pReceiverNeuronIDArray = pNeuron->pReceiverNeuronIDArray;

	float *pOutputSynapsePlasticityArray = pNeuron->pOutputSynapsePlasticityArray;

	bool *pOutputSynapseActivityStatusArray = pNeuron->pOutputSynapseActivityStatusArray;

	float neuronOutput = pNeuron->NeuronOutput;

	int32_t numOfOutputSynapses = pNeuron->NumOfOutputSynapses;

	int32_t receiverNeuronID;

	for(int32_t i = 0; i < numOfOutputSynapses; i++)
	{
		if (pOutputSynapseActivityStatusArray[i] == false)
			continue;

		receiverNeuronID = pReceiverNeuronIDArray[i];
		pUsedNeuronArray[receiverNeuronID].NeuronInput += pOutputSynapsePlasticityArray[i] * neuronOutput;
	}
}

void RBF_SynapticTransferFunction(CNeuronV2 *pNeuron)
{
	CNeuronV2 *pUsedNeuronArray = pNeuron->pUsedNeuronArray;

	int32_t *pReceiverNeuronIDArray = pNeuron->pReceiverNeuronIDArray;

	float *pOutputSynapsePlasticityArray = pNeuron->pOutputSynapsePlasticityArray;

	bool *pOutputSynapseActivityStatusArray = pNeuron->pOutputSynapseActivityStatusArray;

	float neuronOutput = pNeuron->NeuronOutput;
	float synapticOutput;

	int32_t numOfOutputSynapses = pNeuron->NumOfOutputSynapses;

	int32_t receiverNeuronID;
	int32_t Dendrite_InputCounter;

	for (int32_t i = 0; i < numOfOutputSynapses; i++)
	{
		if (pOutputSynapseActivityStatusArray[i] == false)
			continue;

		receiverNeuronID = pReceiverNeuronIDArray[i];
		synapticOutput = pOutputSynapsePlasticityArray[i] * neuronOutput;

		Dendrite_InputCounter = pUsedNeuronArray[receiverNeuronID].Dendrite_InputCounter;
	
		pUsedNeuronArray[receiverNeuronID].pDendrite_InputValueArray[Dendrite_InputCounter] = synapticOutput;
		pUsedNeuronArray[receiverNeuronID].Dendrite_InputCounter++;
	}
}

void RBF_SynapticFunction_Use_All_Connections(CNeuronV2 *pNeuron)
{
	CNeuronV2 *pUsedNeuronArray = pNeuron->pUsedNeuronArray;

	int32_t *pReceiverNeuronIDArray = pNeuron->pReceiverNeuronIDArray;

	float *pOutputSynapsePlasticityArray = pNeuron->pOutputSynapsePlasticityArray;

	float neuronOutput = pNeuron->NeuronOutput;
	float synapticOutput;

	int32_t numOfOutputSynapses = pNeuron->NumOfOutputSynapses;

	int32_t receiverNeuronID;
	int32_t Dendrite_InputCounter;

	float RBF_Factor;
	float RBF_CentroidValue;
	float diff;

	for (int32_t i = 0; i < numOfOutputSynapses; i++)
	{
		receiverNeuronID = pReceiverNeuronIDArray[i];
		synapticOutput = pOutputSynapsePlasticityArray[i] * neuronOutput;

		Dendrite_InputCounter = pUsedNeuronArray[receiverNeuronID].Dendrite_InputCounter;
		RBF_Factor = pUsedNeuronArray[receiverNeuronID].pDendrite_FactorArray[Dendrite_InputCounter];
		RBF_CentroidValue = pUsedNeuronArray[receiverNeuronID].pDendrite_CentroidValueArray[Dendrite_InputCounter];

		//pUsedNeuronArray[receiverNeuronID].pDendrite_InputValueArray[Dendrite_InputCounter] = synapticOutput;

		diff = synapticOutput - RBF_CentroidValue;
		diff *= diff;
		
		pUsedNeuronArray[receiverNeuronID].NeuronInput += RBF_Factor * diff;
		pUsedNeuronArray[receiverNeuronID].Dendrite_InputCounter++;
	}
}

void RBF_SynapticFunction2_Use_All_Connections(CNeuronV2 *pNeuron)
{
	CNeuronV2 *pUsedNeuronArray = pNeuron->pUsedNeuronArray;

	int32_t *pReceiverNeuronIDArray = pNeuron->pReceiverNeuronIDArray;

	float *pOutputSynapsePlasticityArray = pNeuron->pOutputSynapsePlasticityArray;

	float neuronOutput = pNeuron->NeuronOutput;
	float synapticOutput;

	int32_t numOfOutputSynapses = pNeuron->NumOfOutputSynapses;

	int32_t receiverNeuronID;
	int32_t Dendrite_InputCounter;

	float RBF_Factor;
	float RBF_CentroidValue;
	int32_t RBF_CentroidDistanceFuncID;
	float diff;

	for (int32_t i = 0; i < numOfOutputSynapses; i++)
	{
		receiverNeuronID = pReceiverNeuronIDArray[i];
		synapticOutput = pOutputSynapsePlasticityArray[i] * neuronOutput;

		Dendrite_InputCounter = pUsedNeuronArray[receiverNeuronID].Dendrite_InputCounter;
		RBF_Factor = pUsedNeuronArray[receiverNeuronID].pDendrite_FactorArray[Dendrite_InputCounter];
		RBF_CentroidValue = pUsedNeuronArray[receiverNeuronID].pDendrite_CentroidValueArray[Dendrite_InputCounter];
		
		//pUsedNeuronArray[receiverNeuronID].pDendrite_InputValueArray[Dendrite_InputCounter] = synapticOutput;

		//diff = synapticOutput - RBF_CentroidValue;
		RBF_CentroidDistanceFuncID = pUsedNeuronArray[receiverNeuronID].pDendrite_CentroidDistanceFuncIDArray[Dendrite_InputCounter];
		diff = pUsedNeuronArray[receiverNeuronID].pDendriteCentroidDistanceFuncArray[RBF_CentroidDistanceFuncID](synapticOutput, RBF_CentroidValue);
		diff *= diff;

		pUsedNeuronArray[receiverNeuronID].NeuronInput += RBF_Factor * diff;
		pUsedNeuronArray[receiverNeuronID].Dendrite_InputCounter++;
	}
}

void RBF_SynapticFunction(CNeuronV2 *pNeuron)
{
	CNeuronV2 *pUsedNeuronArray = pNeuron->pUsedNeuronArray;

	int32_t *pReceiverNeuronIDArray = pNeuron->pReceiverNeuronIDArray;

	float *pOutputSynapsePlasticityArray = pNeuron->pOutputSynapsePlasticityArray;

	bool *pOutputSynapseActivityStatusArray = pNeuron->pOutputSynapseActivityStatusArray;

	float neuronOutput = pNeuron->NeuronOutput;
	float synapticOutput;

	int32_t numOfOutputSynapses = pNeuron->NumOfOutputSynapses;

	int32_t receiverNeuronID;
	int32_t Dendrite_InputCounter;

	float RBF_Factor;
	float RBF_CentroidValue;
	float diff;

	for (int32_t i = 0; i < numOfOutputSynapses; i++)
	{
		if (pOutputSynapseActivityStatusArray[i] == false)
			continue;

		receiverNeuronID = pReceiverNeuronIDArray[i];
		synapticOutput = pOutputSynapsePlasticityArray[i] * neuronOutput;

		Dendrite_InputCounter = pUsedNeuronArray[receiverNeuronID].Dendrite_InputCounter;
		RBF_Factor = pUsedNeuronArray[receiverNeuronID].pDendrite_FactorArray[Dendrite_InputCounter];
		RBF_CentroidValue = pUsedNeuronArray[receiverNeuronID].pDendrite_CentroidValueArray[Dendrite_InputCounter];

		//pUsedNeuronArray[receiverNeuronID].pDendrite_InputValueArray[Dendrite_InputCounter] = synapticOutput;

		diff = synapticOutput - RBF_CentroidValue;
		diff *= diff;

		pUsedNeuronArray[receiverNeuronID].NeuronInput += RBF_Factor * diff;
		pUsedNeuronArray[receiverNeuronID].Dendrite_InputCounter++;
	}
}



void RBF_SynapticFunction2(CNeuronV2 *pNeuron)
{
	CNeuronV2 *pUsedNeuronArray = pNeuron->pUsedNeuronArray;

	int32_t *pReceiverNeuronIDArray = pNeuron->pReceiverNeuronIDArray;

	float *pOutputSynapsePlasticityArray = pNeuron->pOutputSynapsePlasticityArray;

	bool *pOutputSynapseActivityStatusArray = pNeuron->pOutputSynapseActivityStatusArray;

	float neuronOutput = pNeuron->NeuronOutput;
	float synapticOutput;

	int32_t numOfOutputSynapses = pNeuron->NumOfOutputSynapses;

	int32_t receiverNeuronID;
	int32_t Dendrite_InputCounter;

	float RBF_Factor;
	float RBF_CentroidValue;
	int32_t RBF_CentroidDistanceFuncID;
	float diff;

	for (int32_t i = 0; i < numOfOutputSynapses; i++)
	{
		if (pOutputSynapseActivityStatusArray[i] == false)
			continue;

		receiverNeuronID = pReceiverNeuronIDArray[i];
		synapticOutput = pOutputSynapsePlasticityArray[i] * neuronOutput;

		Dendrite_InputCounter = pUsedNeuronArray[receiverNeuronID].Dendrite_InputCounter;
		RBF_Factor = pUsedNeuronArray[receiverNeuronID].pDendrite_FactorArray[Dendrite_InputCounter];
		RBF_CentroidValue = pUsedNeuronArray[receiverNeuronID].pDendrite_CentroidValueArray[Dendrite_InputCounter];
		RBF_CentroidDistanceFuncID = pUsedNeuronArray[receiverNeuronID].pDendrite_CentroidDistanceFuncIDArray[Dendrite_InputCounter];

		//pUsedNeuronArray[receiverNeuronID].pDendrite_InputValueArray[Dendrite_InputCounter] = synapticOutput;

		//diff = synapticOutput - RBF_CentroidValue;
		diff = pUsedNeuronArray[receiverNeuronID].pDendriteCentroidDistanceFuncArray[RBF_CentroidDistanceFuncID](synapticOutput, RBF_CentroidValue);
		diff *= diff;

		pUsedNeuronArray[receiverNeuronID].NeuronInput += RBF_Factor * diff;
		pUsedNeuronArray[receiverNeuronID].Dendrite_InputCounter++;
	}
}


CActivationSequence::CActivationSequence()
{}

CActivationSequence::~CActivationSequence()
{
	delete[] pNeuronIDArray;
	pNeuronIDArray = nullptr;
}



void CActivationSequence::Clone_Data(const CActivationSequence *pOriginalObject)
{
	Length = pOriginalObject->Length;

	for (uint32_t i = 0; i < Length; i++)
		pNeuronIDArray[i] = pOriginalObject->pNeuronIDArray[i];
}

void CActivationSequence::Clone(const CActivationSequence *pOriginalObject)
{
	if (pOriginalObject->Length > Length)
	{
		delete[] pNeuronIDArray;
		pNeuronIDArray = nullptr;

		pNeuronIDArray = new (std::nothrow) int32_t[pOriginalObject->Length];
	}

	Length = pOriginalObject->Length;

	for (uint32_t i = 0; i < Length; i++)
		pNeuronIDArray[i] = pOriginalObject->pNeuronIDArray[i];
}

bool CActivationSequence::Load_Data(const char* pFilename)
{
	std::ifstream ReadFile;

	// eine existierende Datei zum Lesen �ffnen:
	ReadFile.open(pFilename);

	if (ReadFile.good() == false)
		return false;

	int32_t tempInt;

	ReadFile >> tempInt;

	if (tempInt > Length)
	{
		delete[] pNeuronIDArray;
		pNeuronIDArray = nullptr;

		pNeuronIDArray = new (std::nothrow) int32_t[tempInt];
	}

	Length = tempInt;

	for (int32_t i = 0; i < Length; i++)
	{
		ReadFile >> pNeuronIDArray[i];
	}

	ReadFile.close();

	return true;
}

bool CActivationSequence::Save_Data(const char* pFilename)
{
	std::ofstream WriteFile;

	// neue Datei erzeugen bzw. alte �berschreiben:
	WriteFile.open(pFilename);

	// neue Datei erzeugen bzw. Inhalt ans Ende einer bestehenden Datei schreiben: 
	//WriteFile.open(pFilename, ios::app);

	if (WriteFile.good() == false)
		return false;

	WriteFile << Length << "  ";

	for (int32_t i = 0; i < Length; i++)
	{
		WriteFile << pNeuronIDArray[i] << "  ";
	}

	WriteFile.close();

	return true;
}

void CActivationSequence::Init_ActivationSequence(int32_t length)
{
	//if (length != Length)
	if (length > Length)
	{
		delete[] pNeuronIDArray;
		pNeuronIDArray = nullptr;

		pNeuronIDArray = new (std::nothrow) int32_t[length];
	}

	Length = length;

	for (uint32_t i = 0; i < length; i++)
		pNeuronIDArray[i] = i;
}

void CActivationSequence::Init_Or_Set_ActivationSequence(int32_t *pNeuronIDs, int32_t length)
{
	if (length > Length)
	{
		delete[] pNeuronIDArray;
		pNeuronIDArray = nullptr;

		pNeuronIDArray = new (std::nothrow) int32_t[length];
	}

	Length = length;

	for (int32_t i = 0; i < length; i++)
		pNeuronIDArray[i] = pNeuronIDs[i];
}

void CActivationSequence::Set_ActivationSequence(int32_t *pNeuronIDs)
{
	for (int32_t i = 0; i < Length; i++)
		pNeuronIDArray[i] = pNeuronIDs[i];
}

bool CActivationSequence::Change_ActivationSequence(int32_t neuronID, int32_t sequenceElement)
{
	if (sequenceElement >= Length)
		return false;

	pNeuronIDArray[sequenceElement] = neuronID;

	return true;
}

CNeuralConnections::CNeuralConnections()
{}

CNeuralConnections::~CNeuralConnections()
{
	delete[] pNeuronIDArray;
	pNeuronIDArray = nullptr;

	delete[] pSynapticPlasticityArray;
	pSynapticPlasticityArray = nullptr;
}



void CNeuralConnections::Clone_Data(const CNeuralConnections *pOriginalObject)
{
	Number = pOriginalObject->Number;

	for (int32_t i = 0; i < Number; i++)
	{
		pNeuronIDArray[i] = pOriginalObject->pNeuronIDArray[i];
		pSynapticPlasticityArray[i] = pOriginalObject->pSynapticPlasticityArray[i];
	}
}

void CNeuralConnections::Clone(const CNeuralConnections *pOriginalObject)
{
	//if (pOriginalObject->Number != Number)
	if (pOriginalObject->Number > Number)
	{
		delete[] pNeuronIDArray;
		pNeuronIDArray = nullptr;

		delete[] pSynapticPlasticityArray;
		pSynapticPlasticityArray = nullptr;

		pNeuronIDArray = new (std::nothrow) int32_t[pOriginalObject->Number];
		pSynapticPlasticityArray = new (std::nothrow) float[pOriginalObject->Number];
	}

	Number = pOriginalObject->Number;

	for (int32_t i = 0; i < Number; i++)
	{
		pNeuronIDArray[i] = pOriginalObject->pNeuronIDArray[i];
		pSynapticPlasticityArray[i] = pOriginalObject->pSynapticPlasticityArray[i];
	}
}

bool CNeuralConnections::Load_Data(const char* pFilename)
{
	std::ifstream ReadFile;

	// eine existierende Datei zum Lesen �ffnen:
	ReadFile.open(pFilename);

	if (ReadFile.good() == false)
		return false;

	int32_t tempInt;

	ReadFile >> tempInt;

	if (tempInt > Number)
	{
		delete[] pNeuronIDArray;
		pNeuronIDArray = nullptr;

		delete[] pSynapticPlasticityArray;
		pSynapticPlasticityArray = nullptr;

		pNeuronIDArray = new (std::nothrow) int32_t[tempInt];
		pSynapticPlasticityArray = new (std::nothrow) float[tempInt];
	}

	Number = tempInt;

	for (int32_t i = 0; i < Number; i++)
	{
		ReadFile >> pNeuronIDArray[i];
		ReadFile >> pSynapticPlasticityArray[i];
	}

	ReadFile.close();

	return true;
}

bool CNeuralConnections::Save_Data(const char* pFilename)
{
	std::ofstream WriteFile;

	// neue Datei erzeugen bzw. alte �berschreiben:
	WriteFile.open(pFilename);

	// neue Datei erzeugen bzw. Inhalt ans Ende einer bestehenden Datei schreiben: 
	//WriteFile.open(pFilename, ios::app);

	if (WriteFile.good() == false)
		return false;

	WriteFile << Number << "  ";

	for (int32_t i = 0; i < Number; i++)
	{
		WriteFile << pNeuronIDArray[i] << "  ";
		WriteFile << pSynapticPlasticityArray[i] << "  ";
	}

	WriteFile.close();

	return true;
}

void CNeuralConnections::Init_NeuralConnections(int32_t number)
{
	if (number > Number)
	{
		delete[] pNeuronIDArray;
		pNeuronIDArray = nullptr;

		delete[] pSynapticPlasticityArray;
		pSynapticPlasticityArray = nullptr;

		pNeuronIDArray = new (std::nothrow) int32_t[number];
		pSynapticPlasticityArray = new (std::nothrow) float[number];
	}

	Number = number;

	for (int32_t i = 0; i < number; i++)
	{
		pNeuronIDArray[i] = 0;
		pSynapticPlasticityArray[i] = 0.0f;
	}
}

void CNeuralConnections::Randomize_SynapticPlasticities(CRandomNumbersNN *pRandomNumbers, float minSynapticPlasticity, float maxSynapticPlasticity)
{
	for (int32_t i = 0; i < Number; i++)
	{
		pSynapticPlasticityArray[i] = pRandomNumbers->Get_FloatNumber(minSynapticPlasticity, maxSynapticPlasticity);
	}
}

void CNeuralConnections::Init_Or_Set_NeuralConnections(int32_t *pNeuronIDs, int32_t number, CRandomNumbersNN *pRandomNumbers, float minSynapticPlasticity, float maxSynapticPlasticity)
{
	//if (number != Number)
	if (number > Number)
	{
		delete[] pNeuronIDArray;
		pNeuronIDArray = nullptr;

		delete[] pSynapticPlasticityArray;
		pSynapticPlasticityArray = nullptr;

		pNeuronIDArray = new (std::nothrow) int32_t[number];
		pSynapticPlasticityArray = new (std::nothrow) float[number];
	}

	Number = number;

	for (int32_t i = 0; i < number; i++)
	{
		pNeuronIDArray[i] = pNeuronIDs[i];
		pSynapticPlasticityArray[i] = pRandomNumbers->Get_FloatNumber(minSynapticPlasticity, maxSynapticPlasticity);
	}
}

void CNeuralConnections::Init_Or_Set_NeuralConnections(int32_t *pNeuronIDs, float *pSynapticPlasticities, int32_t number)
{
	//if (number != Number)
	if (number > Number)
	{
		delete[] pNeuronIDArray;
		pNeuronIDArray = nullptr;

		delete[] pSynapticPlasticityArray;
		pSynapticPlasticityArray = nullptr;

		pNeuronIDArray = new (std::nothrow) int32_t[number];
		pSynapticPlasticityArray = new (std::nothrow) float[number];
	}

	Number = number;

	for (int32_t i = 0; i < number; i++)
	{
		pNeuronIDArray[i] = pNeuronIDs[i];
		pSynapticPlasticityArray[i] = pSynapticPlasticities[i];
	}
}

void CNeuralConnections::Init_Or_Set_NeuralConnections(int32_t *pNeuronIDs, int32_t number)
{
	//if (number != Number)
	if (number > Number)
	{
		delete[] pNeuronIDArray;
		pNeuronIDArray = nullptr;

		delete[] pSynapticPlasticityArray;
		pSynapticPlasticityArray = nullptr;

		pNeuronIDArray = new (std::nothrow) int32_t[number];
		pSynapticPlasticityArray = new (std::nothrow) float[number];
	}

	Number = number;

	for (int32_t i = 0; i < number; i++)
	{
		pNeuronIDArray[i] = pNeuronIDs[i];
		pSynapticPlasticityArray[i] = 1.0f;
	}
}

void CNeuralConnections::Set_NeuralConnections(int32_t *pNeuronIDs, float *pSynapticPlasticities)
{
	for (uint32_t i = 0; i < Number; i++)
	{
		pNeuronIDArray[i] = pNeuronIDs[i];
		pSynapticPlasticityArray[i] = pSynapticPlasticities[i];
	}
}

void CNeuralConnections::Set_NeuralConnections(int32_t *pNeuronIDs)
{
	for (uint32_t i = 0; i < Number; i++)
		pNeuronIDArray[i] = pNeuronIDs[i];
}

void CNeuralConnections::Set_NeuralConnections(float *pSynapticPlasticities)
{
	for (uint32_t i = 0; i < Number; i++)
		pSynapticPlasticityArray[i] = pSynapticPlasticities[i];
}

bool CNeuralConnections::Change_SynapticPlasticity(float plasticity, int32_t connectionID)
{
	if (connectionID >= Number)
		return false;

	pSynapticPlasticityArray[connectionID] = plasticity;

	return true;
}

bool CNeuralConnections::Change_NeuronID(int32_t neuronID, int32_t connectionID)
{
	if (connectionID >= Number)
		return false;

	pNeuronIDArray[connectionID] = neuronID;

	return true;
}


CNeuronV2::CNeuronV2()
{}

CNeuronV2::~CNeuronV2()
{
	//Add_To_Log(0, "~CNeuronV2() ...");
	//Add_To_Log(0, "NeuronID", NeuronID);
	
	delete[] pDendrite_InputValueArray;
	pDendrite_InputValueArray = nullptr;

	delete[] pDendrite_CentroidValueArray;
	pDendrite_CentroidValueArray = nullptr;

	delete[] pDendrite_FactorArray;
	pDendrite_FactorArray = nullptr;

	delete[] pDendrite_CentroidDistanceFuncIDArray;
	pDendrite_CentroidDistanceFuncIDArray = nullptr;

	delete[] pOutputSynapseActivityStatusArray;
	pOutputSynapseActivityStatusArray = nullptr;

	delete[] pReceiverNeuronIDArray;
	pReceiverNeuronIDArray = nullptr;

	delete[] pOutputSynapsePlasticityArray;
	pOutputSynapsePlasticityArray = nullptr;

	//Add_To_Log(0, "~CNeuronV2() ok");
}

void CNeuronV2::Use_OtherNeuron_Dendrite_InputValueArray(float *pArray)
{
	pDendrite_InputValueArray_OtherNeuron = pArray;
}

void CNeuronV2::Use_OtherNeuron_Dendrite_InputValueArray(float *pArray,int32_t idFirstSourceDendrite)
{
	pDendrite_InputValueArray_OtherNeuron = &pArray[idFirstSourceDendrite];
}

void CNeuronV2::Use_OtherNeuron_Dendrite_CentroidValueArray(float *pArray)
{
	pDendrite_CentroidValueArray_OtherNeuron = pArray;
}

void CNeuronV2::Use_OtherNeuron_Dendrite_CentroidValueArray(float *pArray, int32_t idFirstSourceDendrite)
{
	pDendrite_CentroidValueArray_OtherNeuron = &(pArray[idFirstSourceDendrite]);
}


void CNeuronV2::Use_OtherNeuron_Dendrite_FactorArray(float *pArray)
{
	pDendrite_FactorArray_OtherNeuron = pArray;
}

void CNeuronV2::Use_OtherNeuron_Dendrite_FactorArray(float *pArray, int32_t idFirstSourceDendrite)
{
	pDendrite_FactorArray_OtherNeuron = &(pArray[idFirstSourceDendrite]);
}


void CNeuronV2::Set_RandomSeedValue(int32_t newSeed)
{
	RandomSeedValue = max(0, newSeed);
	RandomSeedValue = min(RandomSeedValue, ConstRandomNumbersTableSize - 1000);
}

void CNeuronV2::Set_MinNeuronOutputTreshold(float value)
{
	MinNeuronOutputTreshold = value;
}

void CNeuronV2::Set_MaxNeuronOutputValue(float value)
{
	MaxNeuronOutputValue = value;
}

void CNeuronV2::Set_NumOfTrainingExamples(int32_t number)
{
	NumOfTrainingExamples = number;

	if (number == 0)
	{
		for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
		{
			pDendrite_CentroidValueArray[i] = 0.0f;
			pDendrite_FactorArray[i] = 1.0f;
		}
	}
}



void CNeuronV2::Set_NumOfTrainingExamples(int32_t minVectorElement, int32_t maxVectorElement, int32_t number)
{
	maxVectorElement++;

	NumOfTrainingExamples = number;

	if (number == 0)
	{
		for (int32_t i = minVectorElement; i < maxVectorElement; i++)
		{
			pDendrite_CentroidValueArray[i] = 0.0f;
			pDendrite_FactorArray[i] = 1.0f;
		}
	}
}



int32_t CNeuronV2::Get_NumOfTrainingExamples(void)
{
	return NumOfTrainingExamples;
}

void CNeuronV2::Get_WeightedNeuronOutput(float *pOutputValueArray)
{
	for (int32_t i = 0; i < NumOfOutputSynapses; i++)
		pOutputValueArray[i] = pOutputSynapsePlasticityArray[i]*NeuronOutput;
}

float CNeuronV2::Get_NeuronOutput(void)
{
	return NeuronOutput;
}

void CNeuronV2::Set_NeuronOutput(float value)
{
	NeuronOutput_LastCalculationStep = NeuronOutput;
	NeuronOutput = value;
}

void CNeuronV2::Reset_NeuronOutput(void)
{
	NeuronOutput_LastCalculationStep = 0.0f;
	NeuronOutput = 0.0f;
}

void CNeuronV2::Select_UsedDendrites(int32_t minID, int32_t numDendrites)
{
	UsedDendritesMinID = minID;
	UsedDendritesMaxIDPlus1 = minID + numDendrites;
}



void CNeuronV2::Reset_NeuronInput(void)
{
	NeuronInput = 0.0f;
	Dendrite_InputCounter = 0;
}

float CNeuronV2::Get_NeuronInput(void)
{
	return NeuronInput;
}

void CNeuronV2::Set_NeuronInput(float value)
{
	NeuronInput = value;
}


bool CNeuronV2::Set_Dendrite_NeuronInput(int32_t posX_left, int32_t posY_top, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY)
{
	Dendrite_InputCounter = localReceptiveFieldSizeX * localReceptiveFieldSizeY;

	UsedDendritesMinID = 0;
	UsedDendritesMaxIDPlus1 = Dendrite_InputCounter;

	if (inputMapSizeX == localReceptiveFieldSizeX && inputMapSizeY == localReceptiveFieldSizeY)
	{
		for (int32_t i = 0; i < Dendrite_InputCounter; i++)
		{
			pDendrite_InputValueArray[i] = pInputMap[i];
		}

		return true;
	}

	if(posX_left < 0)
		return false;
	if (posY_top < 0)
		return false;
	if (posX_left > inputMapSizeX - localReceptiveFieldSizeX)
		return false;	
	if (posY_top > inputMapSizeY - localReceptiveFieldSizeY)
		return false;

	int32_t ixStart = posX_left;
	int32_t ixStop = ixStart + localReceptiveFieldSizeX;
	
	int32_t iyStart = posY_top;
	int32_t iyStop = iyStart + localReceptiveFieldSizeY;

	int32_t iiy;
	int32_t counter = 0;

	for (int32_t iy = iyStart; iy < iyStop; iy++)
	{
		iiy = iy * inputMapSizeX;

		for (int32_t ix = ixStart; ix < ixStop; ix++)
		{
			pDendrite_InputValueArray[counter++] = pInputMap[ix + iiy];
		}
	}

	return true;
}

bool CNeuronV2::Set_Dendrite_NeuronInput4(int32_t posX_left, int32_t posY_bottom, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY)
{
	Dendrite_InputCounter = localReceptiveFieldSizeX * localReceptiveFieldSizeY;

	UsedDendritesMinID = 0;
	UsedDendritesMaxIDPlus1 = Dendrite_InputCounter;

	if (inputMapSizeX == localReceptiveFieldSizeX && inputMapSizeY == localReceptiveFieldSizeY)
	{
		for (int32_t i = 0; i < Dendrite_InputCounter; i++)
		{
			pDendrite_InputValueArray[i] = pInputMap[i];
		}

		return true;
	}

	if (posX_left < 0)
		return false;
	if (posY_bottom >= inputMapSizeY)
		return false;
	if (posX_left > inputMapSizeX - localReceptiveFieldSizeX)
		return false;
	
	if (posY_bottom < localReceptiveFieldSizeY - 1)
		return false;

	int32_t ixStart = posX_left;
	int32_t ixStop = ixStart + localReceptiveFieldSizeX;

	int32_t iyStop = posY_bottom + 1;
	int32_t iyStart = iyStop - localReceptiveFieldSizeY;

	int32_t iiy;
	int32_t counter = 0;

	for (int32_t iy = iyStart; iy < iyStop; iy++)
	{
		iiy = iy * inputMapSizeX;

		for (int32_t ix = ixStart; ix < ixStop; ix++)
		{
			pDendrite_InputValueArray[counter++] = pInputMap[ix + iiy];
		}
	}

	return true;
}

void CNeuronV2::Set_Dendrite_NeuronInput(int32_t posX_center, int32_t posY_center, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY,
	int32_t localReceptiveFieldNegRangeX, int32_t localReceptiveFieldPosRangeX, int32_t localReceptiveFieldNegRangeY, int32_t localReceptiveFieldPosRangeY, float fallBackInputValue)
{
	int32_t localReceptiveFieldSizeX = localReceptiveFieldNegRangeX + 1 + localReceptiveFieldPosRangeX;
	int32_t localReceptiveFieldSizeY = localReceptiveFieldNegRangeY + 1 + localReceptiveFieldPosRangeY;
	Dendrite_InputCounter = localReceptiveFieldSizeX * localReceptiveFieldSizeY;

	UsedDendritesMinID = 0;
	UsedDendritesMaxIDPlus1 = Dendrite_InputCounter;

	int32_t ixStart = posX_center - localReceptiveFieldNegRangeX;
	int32_t ixStop = posX_center + localReceptiveFieldPosRangeX + 1;
	int32_t iyStart = posY_center - localReceptiveFieldNegRangeY;
	int32_t iyStop = posY_center + localReceptiveFieldPosRangeY + 1;

	
	int32_t iiy;
	int32_t counter = 0;

	if (ixStart > -1 && ixStop <= inputMapSizeX && iyStart > -1 && iyStop <= inputMapSizeY)
	{ 
		for (int32_t iy = iyStart; iy < iyStop; iy++)
		{
			iiy = iy * inputMapSizeX;

			for (int32_t ix = ixStart; ix < ixStop; ix++)
			{
				pDendrite_InputValueArray[counter++] = pInputMap[ix + iiy];
			}
		}

		return;
	}

	for(int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
		pDendrite_InputValueArray[i] = fallBackInputValue;

	for (int32_t iy = iyStart; iy < iyStop; iy++)
	{
		iiy = iy * inputMapSizeX;

		for (int32_t ix = ixStart; ix < ixStop; ix++)
		{
			if (ix > -1 && ix < inputMapSizeX && iy > -1 && iy < inputMapSizeY)
				pDendrite_InputValueArray[counter] = pInputMap[ix + iiy];

			counter++;
		}
	}
}

bool CNeuronV2::Set_Dendrite_NeuronInput2(int32_t posX_right, int32_t posY_bottom, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY)
{
	Dendrite_InputCounter = localReceptiveFieldSizeX * localReceptiveFieldSizeY;

	UsedDendritesMinID = 0;
	UsedDendritesMaxIDPlus1 = Dendrite_InputCounter;

	if (inputMapSizeX == localReceptiveFieldSizeX && inputMapSizeY == localReceptiveFieldSizeY)
	{
		for (int32_t i = 0; i < Dendrite_InputCounter; i++)
		{
			pDendrite_InputValueArray[i] = pInputMap[i];
		}

		return true;
	}

	if (posX_right >= inputMapSizeX)
		return false;
	if (posY_bottom >= inputMapSizeY)
		return false;
	if (posX_right < localReceptiveFieldSizeX - 1)
		return false;
	if (posY_bottom < localReceptiveFieldSizeY -1)
		return false;

	int32_t ixStop = posX_right + 1;
	int32_t ixStart = ixStop - localReceptiveFieldSizeX;
	
	int32_t iyStop = posY_bottom + 1;
	int32_t iyStart = iyStop - localReceptiveFieldSizeY;
	

	int32_t iiy;
	int32_t counter = 0;

	for (int32_t iy = iyStart; iy < iyStop; iy++)
	{
		iiy = iy * inputMapSizeX;

		for (int32_t ix = ixStart; ix < ixStop; ix++)
		{
			pDendrite_InputValueArray[counter++] = pInputMap[ix + iiy];
		}
	}

	return true;
}

bool CNeuronV2::Set_Dendrite_NeuronInput3(int32_t posX_right, int32_t posY_top, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY)
{
	Dendrite_InputCounter = localReceptiveFieldSizeX * localReceptiveFieldSizeY;

	UsedDendritesMinID = 0;
	UsedDendritesMaxIDPlus1 = Dendrite_InputCounter;

	if (inputMapSizeX == localReceptiveFieldSizeX && inputMapSizeY == localReceptiveFieldSizeY)
	{
		for (int32_t i = 0; i < Dendrite_InputCounter; i++)
		{
			pDendrite_InputValueArray[i] = pInputMap[i];
		}

		return true;
	}

	if (posX_right >= inputMapSizeX)
		return false;
	if (posY_top < 0)
		return false;
	if (posX_right < localReceptiveFieldSizeX - 1)
		return false;
	
	if (posY_top > inputMapSizeY - localReceptiveFieldSizeY)
		return false;

	int32_t ixStop = posX_right + 1;
	int32_t ixStart = ixStop - localReceptiveFieldSizeX;

	int32_t iyStart = posY_top;
	int32_t iyStop = iyStart + localReceptiveFieldSizeY;


	int32_t iiy;
	int32_t counter = 0;

	for (int32_t iy = iyStart; iy < iyStop; iy++)
	{
		iiy = iy * inputMapSizeX;

		for (int32_t ix = ixStart; ix < ixStop; ix++)
		{
			pDendrite_InputValueArray[counter++] = pInputMap[ix + iiy];
		}
	}

	return true;
}

bool CNeuronV2::Set_Dendrite_NeuronInput(int32_t posX_left, int32_t posY_top, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, int32_t minDendriteID)
{
	Dendrite_InputCounter = localReceptiveFieldSizeX * localReceptiveFieldSizeY;

	UsedDendritesMinID = minDendriteID;
	UsedDendritesMaxIDPlus1 = minDendriteID + Dendrite_InputCounter;

	if (inputMapSizeX == localReceptiveFieldSizeX && inputMapSizeY == localReceptiveFieldSizeY)
	{
		for (int32_t i = 0; i < Dendrite_InputCounter; i++)
		{
			pDendrite_InputValueArray[i] = pInputMap[i];
		}

		return true;
	}

	if (posX_left < 0)
		return false;
	if (posY_top < 0)
		return false;
	if (posX_left > inputMapSizeX - localReceptiveFieldSizeX)
		return false;
	if (posY_top > inputMapSizeY - localReceptiveFieldSizeY)
		return false;

	int32_t ixStart = posX_left;
	int32_t ixStop = ixStart + localReceptiveFieldSizeX;

	int32_t iyStart = posY_top;
	int32_t iyStop = iyStart + localReceptiveFieldSizeY;

	int32_t iiy;
	int32_t counter = minDendriteID;

	for (int32_t iy = iyStart; iy < iyStop; iy++)
	{
		iiy = iy * inputMapSizeX;

		for (int32_t ix = ixStart; ix < ixStop; ix++)
		{
			pDendrite_InputValueArray[counter++] = pInputMap[ix + iiy];
		}
	}

	return true;
}

bool CNeuronV2::Set_Dendrite_NeuronInput4(int32_t posX_left, int32_t posY_bottom, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, int32_t minDendriteID)
{
	Dendrite_InputCounter = localReceptiveFieldSizeX * localReceptiveFieldSizeY;

	UsedDendritesMinID = minDendriteID;
	UsedDendritesMaxIDPlus1 = minDendriteID + Dendrite_InputCounter;

	if (inputMapSizeX == localReceptiveFieldSizeX && inputMapSizeY == localReceptiveFieldSizeY)
	{
		for (int32_t i = 0; i < Dendrite_InputCounter; i++)
		{
			pDendrite_InputValueArray[i] = pInputMap[i];
		}

		return true;
	}

	if (posX_left < 0)
		return false;
	if (posY_bottom >= inputMapSizeY)
		return false;
	if (posX_left > inputMapSizeX - localReceptiveFieldSizeX)
		return false;
	
	if (posY_bottom < localReceptiveFieldSizeY - 1)
		return false;

	int32_t ixStart = posX_left;
	int32_t ixStop = ixStart + localReceptiveFieldSizeX;

	int32_t iyStop = posY_bottom + 1;
	int32_t iyStart = iyStop - localReceptiveFieldSizeY;

	int32_t iiy;
	int32_t counter = minDendriteID;

	for (int32_t iy = iyStart; iy < iyStop; iy++)
	{
		iiy = iy * inputMapSizeX;

		for (int32_t ix = ixStart; ix < ixStop; ix++)
		{
			pDendrite_InputValueArray[counter++] = pInputMap[ix + iiy];
		}
	}

	return true;
}

void CNeuronV2::Set_Dendrite_NeuronInput(int32_t posX_center, int32_t posY_center, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY,
	int32_t localReceptiveFieldNegRangeX, int32_t localReceptiveFieldPosRangeX, int32_t localReceptiveFieldNegRangeY, int32_t localReceptiveFieldPosRangeY, int32_t minDendriteID, float fallBackInputValue)
{
	int32_t localReceptiveFieldSizeX = localReceptiveFieldNegRangeX + 1 + localReceptiveFieldPosRangeX;
	int32_t localReceptiveFieldSizeY = localReceptiveFieldNegRangeY + 1 + localReceptiveFieldPosRangeY;
	Dendrite_InputCounter = localReceptiveFieldSizeX * localReceptiveFieldSizeY;

	UsedDendritesMinID = minDendriteID;
	UsedDendritesMaxIDPlus1 = minDendriteID + Dendrite_InputCounter;

	int32_t ixStart = posX_center - localReceptiveFieldNegRangeX;
	int32_t ixStop = posX_center + localReceptiveFieldPosRangeX + 1;
	int32_t iyStart = posY_center - localReceptiveFieldNegRangeY;
	int32_t iyStop = posY_center + localReceptiveFieldPosRangeY + 1;

	int32_t iiy;
	int32_t counter = minDendriteID;
	
	if (ixStart > -1 && ixStop <= inputMapSizeX && iyStart > -1 && iyStop <= inputMapSizeY)
	{
		for (int32_t iy = iyStart; iy < iyStop; iy++)
		{
			iiy = iy * inputMapSizeX;

			for (int32_t ix = ixStart; ix < ixStop; ix++)
			{
				pDendrite_InputValueArray[counter++] = pInputMap[ix + iiy];
			}
		}

		return;
	}

	int32_t inputMapSizeXMinus1 = inputMapSizeX - 1;
	int32_t inputMapSizeYMinus1 = inputMapSizeY - 1;


	for (int32_t iy = iyStart; iy < iyStop; iy++)
	{
		if(iy < 0)
		{
			for (int32_t ix = ixStart; ix < ixStop; ix++)
			{
				pDendrite_InputValueArray[counter++] = fallBackInputValue;
			}
			continue;
		}

		if (iy > inputMapSizeYMinus1)
		{
			for (int32_t ix = ixStart; ix < ixStop; ix++)
			{
				pDendrite_InputValueArray[counter++] = fallBackInputValue;
			}
			continue;
		}
		
		iiy = iy * inputMapSizeX;

		for (int32_t ix = ixStart; ix < ixStop; ix++)
		{
			if (ix < 0)
			{
				pDendrite_InputValueArray[counter++] = fallBackInputValue;
				continue;
			}
			if (ix > inputMapSizeXMinus1)
			{
				pDendrite_InputValueArray[counter++] = fallBackInputValue;
				continue;
			}

			pDendrite_InputValueArray[counter++] = pInputMap[ix + iiy];
		}
	}
}

bool CNeuronV2::Set_Dendrite_NeuronInput2(int32_t posX_right, int32_t posY_bottom, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, int32_t minDendriteID)
{
	Dendrite_InputCounter = localReceptiveFieldSizeX * localReceptiveFieldSizeY;

	UsedDendritesMinID = minDendriteID;
	UsedDendritesMaxIDPlus1 = minDendriteID + Dendrite_InputCounter;

	if (inputMapSizeX == localReceptiveFieldSizeX && inputMapSizeY == localReceptiveFieldSizeY)
	{
		for (int32_t i = 0; i < Dendrite_InputCounter; i++)
		{
			pDendrite_InputValueArray[i] = pInputMap[i];
		}

		return true;
	}

	if (posX_right >= inputMapSizeX)
		return false;
	if (posY_bottom >= inputMapSizeY)
		return false;
	if (posX_right < localReceptiveFieldSizeX - 1)
		return false;
	
	if (posY_bottom < localReceptiveFieldSizeY - 1)
		return false;

	int32_t ixStop = posX_right + 1;
	int32_t ixStart = ixStop - localReceptiveFieldSizeX;

	int32_t iyStop = posY_bottom + 1;
	int32_t iyStart = iyStop - localReceptiveFieldSizeY;


	int32_t iiy;
	int32_t counter = minDendriteID;

	for (int32_t iy = iyStart; iy < iyStop; iy++)
	{
		iiy = iy * inputMapSizeX;

		for (int32_t ix = ixStart; ix < ixStop; ix++)
		{
			pDendrite_InputValueArray[counter++] = pInputMap[ix + iiy];
		}
	}

	return true;
}

bool CNeuronV2::Set_Dendrite_NeuronInput3(int32_t posX_right, int32_t posY_top, float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t localReceptiveFieldSizeX, int32_t localReceptiveFieldSizeY, int32_t minDendriteID)
{
	Dendrite_InputCounter = localReceptiveFieldSizeX * localReceptiveFieldSizeY;

	UsedDendritesMinID = minDendriteID;
	UsedDendritesMaxIDPlus1 = minDendriteID + Dendrite_InputCounter;

	if (inputMapSizeX == localReceptiveFieldSizeX && inputMapSizeY == localReceptiveFieldSizeY)
	{
		for (int32_t i = 0; i < Dendrite_InputCounter; i++)
		{
			pDendrite_InputValueArray[i] = pInputMap[i];
		}

		return true;
	}

	if (posX_right >= inputMapSizeX)
		return false;
	if (posY_top < 0)
		return false;
	if (posX_right < localReceptiveFieldSizeX - 1)
		return false;
	if (posY_top > inputMapSizeY - localReceptiveFieldSizeY)
		return false;

	int32_t ixStop = posX_right + 1;
	int32_t ixStart = ixStop - localReceptiveFieldSizeX;

	int32_t iyStart = posY_top;
	int32_t iyStop = iyStart + localReceptiveFieldSizeY;


	int32_t iiy;
	int32_t counter = minDendriteID;

	for (int32_t iy = iyStart; iy < iyStop; iy++)
	{
		iiy = iy * inputMapSizeX;

		for (int32_t ix = ixStart; ix < ixStop; ix++)
		{
			pDendrite_InputValueArray[counter++] = pInputMap[ix + iiy];
		}
	}

	return true;
}



void CNeuronV2::Set_RBF_NeuronInput2(float *pValueArray, int32_t numArrayElements, int32_t firstCentroidElementID)
{
	float diff;
	int32_t centroidElementID;

	for (int32_t i = 0; i < numArrayElements; i++)
	{
		centroidElementID = i + firstCentroidElementID;

		pDendrite_InputValueArray[centroidElementID] = pValueArray[i];
		diff = pDendriteCentroidDistanceFuncArray[pDendrite_CentroidDistanceFuncIDArray[centroidElementID]](pValueArray[i], pDendrite_CentroidValueArray[centroidElementID]);
		diff *= diff;

		NeuronInput += pDendrite_FactorArray[centroidElementID] * diff;
	}
}

void CNeuronV2::Set_RBF_NeuronInput(float *pValueArray, int32_t numArrayElements, int32_t firstCentroidElementID)
{
	float diff;
	int32_t centroidElementID;

	for (int32_t i = 0; i < numArrayElements; i++)
	{
		centroidElementID = i + firstCentroidElementID;

		pDendrite_InputValueArray[centroidElementID] = pValueArray[i];
		diff = pValueArray[i] - pDendrite_CentroidValueArray[centroidElementID];
		diff *= diff;

		NeuronInput += pDendrite_FactorArray[centroidElementID] * diff;
	}
}

void CNeuronV2::Set_MinRBF_NeuronInput(float *pValueArray, int32_t numArrayElements, int32_t firstCentroidElementID)
{
	float diff;
	int32_t centroidElementID;
	float centroidValue;

	for (int32_t i = 0; i < numArrayElements; i++)
	{
		centroidElementID = i + firstCentroidElementID;

		pDendrite_InputValueArray[centroidElementID] = pValueArray[i];
		centroidValue = pDendrite_CentroidValueArray[centroidElementID];
		diff = min(pValueArray[i], centroidValue) - centroidValue;
		diff *= diff;

		NeuronInput += pDendrite_FactorArray[centroidElementID] * diff;
	}
}

void CNeuronV2::Set_MaxRBF_NeuronInput(float *pValueArray, int32_t numArrayElements, int32_t firstCentroidElementID)
{
	float diff;
	int32_t centroidElementID;
	float centroidValue;

	for (int32_t i = 0; i < numArrayElements; i++)
	{
		centroidElementID = i + firstCentroidElementID;

		pDendrite_InputValueArray[centroidElementID] = pValueArray[i];
		centroidValue = pDendrite_CentroidValueArray[centroidElementID];
		diff = max(pValueArray[i], centroidValue) - centroidValue;
		diff *= diff;

		NeuronInput += pDendrite_FactorArray[centroidElementID] * diff;
	}
}


void CNeuronV2::Set_RBF_NeuronInput_Ext(float *pValueArray, int32_t numArrayElements)
{
	float diff;
	int32_t centroidElementID;
	float tempNeuronInput;
	int32_t firstCentroidElementID;

	firstCentroidElementID = 0;
	
	NeuronInput = 10000000.0f;

	do
	{
		if (firstCentroidElementID + numArrayElements > Num_Of_Dendrite_Elements)
			break;

		tempNeuronInput = 0.0f;

		for (int32_t i = 0; i < numArrayElements; i++)
		{
			centroidElementID = i + firstCentroidElementID;

			pDendrite_InputValueArray[centroidElementID] = pValueArray[i];
			diff = pValueArray[i] - pDendrite_CentroidValueArray[centroidElementID];
			diff *= diff;

			tempNeuronInput += pDendrite_FactorArray[centroidElementID] * diff;
		}

		NeuronInput = min(NeuronInput, tempNeuronInput);
		firstCentroidElementID += numArrayElements;
	}
	while (true);

}


void CNeuronV2::Set_RBF_NeuronInput2_Ext(float *pValueArray, int32_t numArrayElements)
{
	float diff;
	int32_t centroidElementID;
	float tempNeuronInput;
	int32_t firstCentroidElementID;

	firstCentroidElementID = 0;

	NeuronInput = 10000000.0f;

	do
	{
		if (firstCentroidElementID + numArrayElements > Num_Of_Dendrite_Elements)
			break;

		tempNeuronInput = 0.0f;

		for (int32_t i = 0; i < numArrayElements; i++)
		{
			centroidElementID = i + firstCentroidElementID;

			pDendrite_InputValueArray[centroidElementID] = pValueArray[i];
			diff = pDendriteCentroidDistanceFuncArray[pDendrite_CentroidDistanceFuncIDArray[centroidElementID]](pValueArray[i], pDendrite_CentroidValueArray[centroidElementID]);
			//diff = pValueArray[i] - pDendrite_CentroidValueArray[centroidElementID];
			diff *= diff;

			tempNeuronInput += pDendrite_FactorArray[centroidElementID] * diff;
		}

		NeuronInput = min(NeuronInput, tempNeuronInput);
		firstCentroidElementID += numArrayElements;
	} while (true);

}

void CNeuronV2::Set_MinRBF_NeuronInput_Ext(float *pValueArray, int32_t numArrayElements)
{
	float diff;
	int32_t centroidElementID;
	float tempNeuronInput;
	int32_t firstCentroidElementID;
	float centroidValue;

	firstCentroidElementID = 0;

	NeuronInput = 10000000.0f;

	do
	{
		if (firstCentroidElementID + numArrayElements > Num_Of_Dendrite_Elements)
			break;

		tempNeuronInput = 0.0f;

		for (int32_t i = 0; i < numArrayElements; i++)
		{
			centroidElementID = i + firstCentroidElementID;

			pDendrite_InputValueArray[centroidElementID] = pValueArray[i];
			centroidValue = pDendrite_CentroidValueArray[centroidElementID];
			diff = min(pValueArray[i], centroidValue) - centroidValue;
			diff *= diff;

			tempNeuronInput += pDendrite_FactorArray[centroidElementID] * diff;
		}

		NeuronInput = min(NeuronInput, tempNeuronInput);
		firstCentroidElementID += numArrayElements;
	} while (true);

}

void CNeuronV2::Set_MaxRBF_NeuronInput_Ext(float *pValueArray, int32_t numArrayElements)
{
	float diff;
	int32_t centroidElementID;
	float tempNeuronInput;
	int32_t firstCentroidElementID;
	float centroidValue;

	firstCentroidElementID = 0;

	NeuronInput = 10000000.0f;

	do
	{
		if (firstCentroidElementID + numArrayElements > Num_Of_Dendrite_Elements)
			break;

		tempNeuronInput = 0.0f;

		for (int32_t i = 0; i < numArrayElements; i++)
		{
			centroidElementID = i + firstCentroidElementID;

			pDendrite_InputValueArray[centroidElementID] = pValueArray[i];
			centroidValue = pDendrite_CentroidValueArray[centroidElementID];
			diff = max(pValueArray[i], centroidValue) - centroidValue;
			diff *= diff;

			tempNeuronInput += pDendrite_FactorArray[centroidElementID] * diff;
		}

		NeuronInput = min(NeuronInput, tempNeuronInput);
		firstCentroidElementID += numArrayElements;
	} while (true);

}

void CNeuronV2::Set_RBF_NeuronInput_Ext(float *pValueArray, int32_t numArrayElements, int32_t firstCentroidElementID)
{
	float diff;
	int32_t centroidElementID;
	float tempNeuronInput;
	
	NeuronInput = 10000000.0f;

	do
	{
		if (firstCentroidElementID + numArrayElements > Num_Of_Dendrite_Elements)
			break;

		tempNeuronInput = 0.0f;

		for (int32_t i = 0; i < numArrayElements; i++)
		{
			centroidElementID = i + firstCentroidElementID;

			pDendrite_InputValueArray[centroidElementID] = pValueArray[i];
			diff = pValueArray[i] - pDendrite_CentroidValueArray[centroidElementID];
			diff *= diff;

			tempNeuronInput += pDendrite_FactorArray[centroidElementID] * diff;
		}

		NeuronInput = min(NeuronInput, tempNeuronInput);
		firstCentroidElementID += numArrayElements;
	} while (true);

}



void CNeuronV2::Set_RBF_NeuronInput2_Ext(float *pValueArray, int32_t numArrayElements, int32_t firstCentroidElementID)
{
	float diff;
	int32_t centroidElementID;
	float tempNeuronInput;

	NeuronInput = 10000000.0f;

	do
	{
		if (firstCentroidElementID + numArrayElements > Num_Of_Dendrite_Elements)
			break;

		tempNeuronInput = 0.0f;

		for (int32_t i = 0; i < numArrayElements; i++)
		{
			centroidElementID = i + firstCentroidElementID;

			pDendrite_InputValueArray[centroidElementID] = pValueArray[i];
			//diff = pValueArray[i] - pDendrite_CentroidValueArray[centroidElementID];
			diff = pDendriteCentroidDistanceFuncArray[pDendrite_CentroidDistanceFuncIDArray[centroidElementID]](pValueArray[i], pDendrite_CentroidValueArray[centroidElementID]);
			diff *= diff;

			tempNeuronInput += pDendrite_FactorArray[centroidElementID] * diff;
		}

		NeuronInput = min(NeuronInput, tempNeuronInput);
		firstCentroidElementID += numArrayElements;
	} while (true);

}

void CNeuronV2::Set_MinRBF_NeuronInput_Ext(float *pValueArray, int32_t numArrayElements, int32_t firstCentroidElementID)
{
	float diff;
	int32_t centroidElementID;
	float tempNeuronInput;
	float centroidValue;

	NeuronInput = 10000000.0f;

	do
	{
		if (firstCentroidElementID + numArrayElements > Num_Of_Dendrite_Elements)
			break;

		tempNeuronInput = 0.0f;

		for (int32_t i = 0; i < numArrayElements; i++)
		{
			centroidElementID = i + firstCentroidElementID;

			pDendrite_InputValueArray[centroidElementID] = pValueArray[i];
			centroidValue = pDendrite_CentroidValueArray[centroidElementID];
			diff = min(pValueArray[i], centroidValue) - centroidValue;
			diff *= diff;

			tempNeuronInput += pDendrite_FactorArray[centroidElementID] * diff;
		}

		NeuronInput = min(NeuronInput, tempNeuronInput);
		firstCentroidElementID += numArrayElements;
	} while (true);

}

void CNeuronV2::Set_MaxRBF_NeuronInput_Ext(float *pValueArray, int32_t numArrayElements, int32_t firstCentroidElementID)
{
	float diff;
	int32_t centroidElementID;
	float tempNeuronInput;
	float centroidValue;

	NeuronInput = 10000000.0f;

	do
	{
		if (firstCentroidElementID + numArrayElements > Num_Of_Dendrite_Elements)
			break;

		tempNeuronInput = 0.0f;

		for (int32_t i = 0; i < numArrayElements; i++)
		{
			centroidElementID = i + firstCentroidElementID;
			pDendrite_InputValueArray[centroidElementID] = pValueArray[i];
			centroidValue = pDendrite_CentroidValueArray[centroidElementID];
			diff = max(pValueArray[i], centroidValue) - centroidValue;
			diff *= diff;

			tempNeuronInput += pDendrite_FactorArray[centroidElementID] * diff;
		}

		NeuronInput = min(NeuronInput, tempNeuronInput);
		firstCentroidElementID += numArrayElements;
	} while (true);

}

void CNeuronV2::Set_RBF_NeuronInput_Ext(float *pValueArray, int32_t numArrayElements, int32_t firstCentroidElementID, int32_t lastCentroidElementID)
{
	lastCentroidElementID++;

	float diff;
	int32_t centroidElementID;
	float tempNeuronInput;

	NeuronInput = 10000000.0f;

	do
	{
		if (firstCentroidElementID + numArrayElements > lastCentroidElementID)
			break;

		tempNeuronInput = 0.0f;

		for (int32_t i = 0; i < numArrayElements; i++)
		{
			centroidElementID = i + firstCentroidElementID;
			pDendrite_InputValueArray[centroidElementID] = pValueArray[i];
			diff = pValueArray[i] - pDendrite_CentroidValueArray[centroidElementID];
			diff *= diff;

			tempNeuronInput += pDendrite_FactorArray[centroidElementID] * diff;
		}

		NeuronInput = min(NeuronInput, tempNeuronInput);
		firstCentroidElementID += numArrayElements;
	} while (true);

}



void CNeuronV2::Set_RBF_NeuronInput2_Ext(float *pValueArray, int32_t numArrayElements, int32_t firstCentroidElementID, int32_t lastCentroidElementID)
{
	lastCentroidElementID++;

	float diff;
	int32_t centroidElementID;
	float tempNeuronInput;

	NeuronInput = 10000000.0f;

	do
	{
		if (firstCentroidElementID + numArrayElements > lastCentroidElementID)
			break;

		tempNeuronInput = 0.0f;

		for (int32_t i = 0; i < numArrayElements; i++)
		{
			centroidElementID = i + firstCentroidElementID;
			pDendrite_InputValueArray[centroidElementID] = pValueArray[i];
			//diff = pValueArray[i] - pDendrite_CentroidValueArray[centroidElementID];
			diff = pDendriteCentroidDistanceFuncArray[pDendrite_CentroidDistanceFuncIDArray[centroidElementID]](pValueArray[i], pDendrite_CentroidValueArray[centroidElementID]);
			diff *= diff;

			tempNeuronInput += pDendrite_FactorArray[centroidElementID] * diff;
		}

		NeuronInput = min(NeuronInput, tempNeuronInput);
		firstCentroidElementID += numArrayElements;
	} while (true);

}

void CNeuronV2::Set_MinRBF_NeuronInput_Ext(float *pValueArray, int32_t numArrayElements, int32_t firstCentroidElementID, int32_t lastCentroidElementID)
{
	lastCentroidElementID++;

	float diff;
	int32_t centroidElementID;
	float tempNeuronInput;
	float centroidValue;

	NeuronInput = 10000000.0f;

	do
	{
		if (firstCentroidElementID + numArrayElements > lastCentroidElementID)
			break;

		tempNeuronInput = 0.0f;

		for (int32_t i = 0; i < numArrayElements; i++)
		{
			centroidElementID = i + firstCentroidElementID;
			pDendrite_InputValueArray[centroidElementID] = pValueArray[i];
			centroidValue = pDendrite_CentroidValueArray[centroidElementID];
			diff = min(pValueArray[i], centroidValue) - centroidValue;
			diff *= diff;

			tempNeuronInput += pDendrite_FactorArray[centroidElementID] * diff;
		}

		NeuronInput = min(NeuronInput, tempNeuronInput);
		firstCentroidElementID += numArrayElements;
	} while (true);

}

void CNeuronV2::Set_MaxRBF_NeuronInput_Ext(float *pValueArray, int32_t numArrayElements, int32_t firstCentroidElementID, int32_t lastCentroidElementID)
{
	lastCentroidElementID++;

	float diff;
	int32_t centroidElementID;
	float tempNeuronInput;
	float centroidValue;

	NeuronInput = 10000000.0f;

	do
	{
		if (firstCentroidElementID + numArrayElements > lastCentroidElementID)
			break;

		tempNeuronInput = 0.0f;

		for (int32_t i = 0; i < numArrayElements; i++)
		{
			centroidElementID = i + firstCentroidElementID;
			pDendrite_InputValueArray[centroidElementID] = pValueArray[i];
			centroidValue = pDendrite_CentroidValueArray[centroidElementID];
			diff = max(pValueArray[i], centroidValue) - centroidValue;
			diff *= diff;

			tempNeuronInput += pDendrite_FactorArray[centroidElementID] * diff;
		}

		NeuronInput = min(NeuronInput, tempNeuronInput);
		firstCentroidElementID += numArrayElements;
	} while (true);

}

void CNeuronV2::Set_Dendrite_NeuronInput(float value, int32_t dendriteID)
{
	pDendrite_InputValueArray[dendriteID] = value;
}

void CNeuronV2::Set_And_Count_Dendrite_NeuronInput(float value, int32_t dendriteID)
{
	pDendrite_InputValueArray[dendriteID] = value;
	Dendrite_InputCounter++;
}

void CNeuronV2::Set_NeuronInput_For_All_Dendrites(float value)
{
	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
		pDendrite_InputValueArray[i] = value;
}

void CNeuronV2::Set_Dendrite_NeuronInput(float value)
{
	pDendrite_InputValueArray[Dendrite_InputCounter] = value;
	Dendrite_InputCounter++;
}

void CNeuronV2::Set_Dendrite_NeuronInput(float *pValueArray, int32_t numArrayElements, int32_t firstDendriteID)
{
	int32_t dendriteID;

	for (int32_t i = 0; i < numArrayElements; i++)
	{
		dendriteID = i + firstDendriteID;

		pDendrite_InputValueArray[dendriteID] = pValueArray[i];
	}
}

void CNeuronV2::Set_Dendrite_NeuronInput(float *pValueArray, int32_t numArrayElements)
{
	for (int32_t i = 0; i < numArrayElements; i++)
	{
		pDendrite_InputValueArray[i] = pValueArray[i];
	}
}

void CNeuronV2::Set_And_Count_Dendrite_NeuronInput(float *pValueArray, int32_t numArrayElements, int32_t firstDendriteID)
{
	int32_t dendriteID;

	for (int32_t i = 0; i < numArrayElements; i++)
	{
		dendriteID = i + firstDendriteID;

		pDendrite_InputValueArray[dendriteID] = pValueArray[i];
		Dendrite_InputCounter++;
	}
}

void CNeuronV2::Set_And_Count_Dendrite_NeuronInput(float *pValueArray, int32_t numArrayElements)
{
	for (int32_t i = 0; i < numArrayElements; i++)
	{
		pDendrite_InputValueArray[i] = pValueArray[i];
		Dendrite_InputCounter++;
	}
}



void CNeuronV2::Set_RBF_NeuronInput(float value, int32_t centroidElementID)
{
	pDendrite_InputValueArray[centroidElementID] = value;
	float diff = value - pDendrite_CentroidValueArray[centroidElementID];
	diff *= diff;

	NeuronInput += pDendrite_FactorArray[centroidElementID] * diff;
}

void CNeuronV2::Set_RBF_NeuronInput2(float value, int32_t centroidElementID)
{
	pDendrite_InputValueArray[centroidElementID] = value;
	float diff = pDendriteCentroidDistanceFuncArray[pDendrite_CentroidDistanceFuncIDArray[centroidElementID]](value, pDendrite_CentroidValueArray[centroidElementID]);
	//float diff = value - pDendrite_CentroidValueArray[centroidElementID];
	diff *= diff;

	NeuronInput += pDendrite_FactorArray[centroidElementID] * diff;
}

void CNeuronV2::Set_MinRBF_NeuronInput(float value, int32_t centroidElementID)
{
	pDendrite_InputValueArray[centroidElementID] = value;
	float centroidValue = pDendrite_CentroidValueArray[centroidElementID];

	float diff = min(value, centroidValue) - centroidValue;
	diff *= diff;

	NeuronInput += pDendrite_FactorArray[centroidElementID] * diff;
}

void CNeuronV2::Set_MaxRBF_NeuronInput(float value, int32_t centroidElementID)
{
	pDendrite_InputValueArray[centroidElementID] = value;
	float centroidValue = pDendrite_CentroidValueArray[centroidElementID];

	float diff = max(value, centroidValue) - centroidValue;
	diff *= diff;

	NeuronInput += pDendrite_FactorArray[centroidElementID] * diff;
}


void CNeuronV2::Set_RBF_NeuronInput(float value)
{
	pDendrite_InputValueArray[Dendrite_InputCounter] = value;
	float diff = value - pDendrite_CentroidValueArray[Dendrite_InputCounter];
	diff *= diff;

	NeuronInput += pDendrite_FactorArray[Dendrite_InputCounter] * diff;

	Dendrite_InputCounter++;
}

void CNeuronV2::Set_RBF_NeuronInput2(float value)
{
	pDendrite_InputValueArray[Dendrite_InputCounter] = value;
	float diff = pDendriteCentroidDistanceFuncArray[pDendrite_CentroidDistanceFuncIDArray[Dendrite_InputCounter]](value, pDendrite_CentroidValueArray[Dendrite_InputCounter]);
	//float diff = value - pDendrite_CentroidValueArray[Dendrite_InputCounter];
	diff *= diff;

	NeuronInput += pDendrite_FactorArray[Dendrite_InputCounter] * diff;

	Dendrite_InputCounter++;
}

void CNeuronV2::Set_MinRBF_NeuronInput(float value)
{
	pDendrite_InputValueArray[Dendrite_InputCounter] = value;
	float centroidValue = pDendrite_CentroidValueArray[Dendrite_InputCounter];
	float diff = min(value, centroidValue) - centroidValue;
	diff *= diff;

	NeuronInput += pDendrite_FactorArray[Dendrite_InputCounter] * diff;

	Dendrite_InputCounter++;
}

void CNeuronV2::Set_MaxRBF_NeuronInput(float value)
{
	pDendrite_InputValueArray[Dendrite_InputCounter] = value;
	float centroidValue = pDendrite_CentroidValueArray[Dendrite_InputCounter];
	float diff = max(value, centroidValue) - centroidValue;
	diff *= diff;

	NeuronInput += pDendrite_FactorArray[Dendrite_InputCounter] * diff;

	Dendrite_InputCounter++;
}

bool CNeuronV2::Save_Dendrite_Values(const char* pFilename)
{
	std::ofstream WriteFile;

	// neue Datei erzeugen bzw. alte �berschreiben:
	WriteFile.open(pFilename);

	// neue Datei erzeugen bzw. Inhalt ans Ende einer bestehenden Datei schreiben: 
	//WriteFile.open(pFilename, ios::app);

	if (WriteFile.good() == false)
		return false;

	WriteFile << Num_Of_Dendrite_Elements << "  ";

	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		WriteFile << pDendrite_FactorArray[i] << "  ";
		WriteFile << pDendrite_CentroidValueArray[i] << "  ";
	}

	WriteFile.close();

	return true;
}

bool CNeuronV2::Save_SynapticData(const char* pFilename)
{
	std::ofstream WriteFile;

	// neue Datei erzeugen bzw. alte �berschreiben:
	WriteFile.open(pFilename);

	// neue Datei erzeugen bzw. Inhalt ans Ende einer bestehenden Datei schreiben: 
	//WriteFile.open(pFilename, ios::app);

	if (WriteFile.good() == false)
		return false;

	WriteFile << NumOfOutputSynapses << "  ";

	for (int32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		WriteFile << pReceiverNeuronIDArray[i] << "  ";
		WriteFile << pOutputSynapsePlasticityArray[i] << "  ";
	}

	WriteFile.close();

	return true;
}

bool CNeuronV2::Load_Dendrite_Values(const char* pFilename)
{
	std::ifstream ReadFile;

	// eine existierende Datei zum Lesen �ffnen:
	ReadFile.open(pFilename);

	if (ReadFile.good() == false)
		return false;

	int32_t tempInt;
	
	ReadFile >> tempInt;

	if (tempInt > Num_Of_Dendrite_Elements)
	{
		delete[] pDendrite_FactorArray;
		pDendrite_FactorArray = nullptr;

		delete[] pDendrite_CentroidValueArray;
		pDendrite_CentroidValueArray = nullptr;

		pDendrite_CentroidValueArray = new (std::nothrow) float[tempInt];
		pDendrite_FactorArray = new (std::nothrow) float[tempInt];
	}

	Num_Of_Dendrite_Elements = tempInt;

	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		ReadFile >> pDendrite_FactorArray[i];
		ReadFile >> pDendrite_CentroidValueArray[i];
	}

	ReadFile.close();

	return true;
}

bool CNeuronV2::Load_SynapticData(const char* pFilename)
{
	std::ifstream ReadFile;

	// eine existierende Datei zum Lesen �ffnen:
	ReadFile.open(pFilename);

	if (ReadFile.good() == false)
		return false;

	int32_t tempInt;

	ReadFile >> tempInt;

	if (tempInt > NumOfOutputSynapses)
	{
		delete[] pOutputSynapseActivityStatusArray;
		pOutputSynapseActivityStatusArray = nullptr;

		delete[] pOutputSynapsePlasticityArray;
		pOutputSynapsePlasticityArray = nullptr;

		delete[] pReceiverNeuronIDArray;
		pReceiverNeuronIDArray = nullptr;

		pOutputSynapseActivityStatusArray = new (std::nothrow) bool[tempInt];
		pOutputSynapsePlasticityArray = new (std::nothrow) float[tempInt];
		pReceiverNeuronIDArray = new (std::nothrow) int32_t[tempInt];
	}

	NumOfOutputSynapses = tempInt;

	for (int32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		ReadFile >> pReceiverNeuronIDArray[i];
		ReadFile >> pOutputSynapsePlasticityArray[i];

		if (pOutputSynapsePlasticityArray[i] == 0.0f)
			pOutputSynapseActivityStatusArray[i] = false;
		else
			pOutputSynapseActivityStatusArray[i] = true;
	}

	ReadFile.close();

	return true;
}

void CNeuronV2::Set_ErrorFactors(float factor1, float factor2)
{
	ErrorFactor1 = factor1;
	ErrorFactor2 = factor2;
}

void CNeuronV2::Set_LearningRate(float learningRate)
{
	LearningRate = learningRate;
}

void CNeuronV2::Init_OutputSynapses(const CNeuralConnections * pNeuralConnections)
{
	pSynapticFunction = StandardSynapticFunction;

	BiasNeuron = false;
	Dropout = false;

	if (NumOfOutputSynapses < pNeuralConnections->Number)
	{
		delete[] pOutputSynapseActivityStatusArray;
		pOutputSynapseActivityStatusArray = nullptr;

		delete[] pOutputSynapsePlasticityArray;
		pOutputSynapsePlasticityArray = nullptr;

		delete[] pReceiverNeuronIDArray;
		pReceiverNeuronIDArray = nullptr;

		pOutputSynapseActivityStatusArray = new (std::nothrow) bool[pNeuralConnections->Number];
		pOutputSynapsePlasticityArray = new (std::nothrow) float[pNeuralConnections->Number];
		pReceiverNeuronIDArray = new (std::nothrow) int32_t[pNeuralConnections->Number];
	}

	NumOfOutputSynapses = pNeuralConnections->Number;

	for (int32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		pOutputSynapseActivityStatusArray[i] = true;
		pOutputSynapsePlasticityArray[i] = pNeuralConnections->pSynapticPlasticityArray[i];
		pReceiverNeuronIDArray[i] = pNeuralConnections->pNeuronIDArray[i];
	}
}

void CNeuronV2::Init_OutputSynapses(int32_t numOfOutputSynapses)
{
	pSynapticFunction = StandardSynapticFunction;

	BiasNeuron = false;
	Dropout = false;

	if (NumOfOutputSynapses < numOfOutputSynapses)
	{
		delete[] pOutputSynapseActivityStatusArray;
		pOutputSynapseActivityStatusArray = nullptr;

		delete[] pOutputSynapsePlasticityArray;
		pOutputSynapsePlasticityArray = nullptr;

		delete[] pReceiverNeuronIDArray;
		pReceiverNeuronIDArray = nullptr;

		pOutputSynapseActivityStatusArray = new (std::nothrow) bool[numOfOutputSynapses];
		pOutputSynapsePlasticityArray = new (std::nothrow) float[numOfOutputSynapses];
		pReceiverNeuronIDArray = new (std::nothrow) int32_t[numOfOutputSynapses];		
	}
	

	NumOfOutputSynapses = numOfOutputSynapses;

	for (int32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		pOutputSynapseActivityStatusArray[i] = true;
		pOutputSynapsePlasticityArray[i] = 0.0f;
		pReceiverNeuronIDArray[i] = 0;
	}
}

void CNeuronV2::Use_As_BiasNeuron(bool state)
{
	if (state == true)
		pActivationFunction = BiasActivationFunction;

	BiasNeuron = state;
}

void CNeuronV2::Init_Dendrite_Arrays(int32_t num_Of_Dendrite_Elements)
{
	if (Num_Of_Dendrite_Elements < num_Of_Dendrite_Elements)
	{
		delete[] pDendrite_InputValueArray;
		pDendrite_InputValueArray = nullptr;

		delete[] pDendrite_CentroidValueArray;
		pDendrite_CentroidValueArray = nullptr;

		delete[] pDendrite_FactorArray;
		pDendrite_FactorArray = nullptr;

		delete[] pDendrite_CentroidDistanceFuncIDArray;
		pDendrite_CentroidDistanceFuncIDArray = nullptr;

		pDendrite_InputValueArray = new (std::nothrow) float[num_Of_Dendrite_Elements];
		pDendrite_CentroidValueArray = new (std::nothrow) float[num_Of_Dendrite_Elements];
		pDendrite_FactorArray = new (std::nothrow) float[num_Of_Dendrite_Elements];
		pDendrite_CentroidDistanceFuncIDArray = new (std::nothrow) int32_t[num_Of_Dendrite_Elements];
	}

	Num_Of_Dendrite_Elements = num_Of_Dendrite_Elements;

	for (int32_t i = 0; i < num_Of_Dendrite_Elements; i++)
	{
		pDendrite_InputValueArray[i] = 0.0f;
		pDendrite_CentroidValueArray[i] = 0.0f;
		pDendrite_FactorArray[i] = 1.0f;
		pDendrite_CentroidDistanceFuncIDArray[i] = 0;
	}
}

void CNeuronV2::Clone(const CNeuronV2 *pOriginalObject)
{
	MinNeuronOutputTreshold = pOriginalObject->MinNeuronOutputTreshold;
	MaxNeuronOutputValue = pOriginalObject->MaxNeuronOutputValue;
	NumOfTrainingExamples = pOriginalObject->NumOfTrainingExamples;
	BiasNeuron = pOriginalObject->BiasNeuron;
	NeuronInput = pOriginalObject->NeuronInput;
	NeuronOutput = pOriginalObject->NeuronOutput;
	NeuronOutput_LastCalculationStep = pOriginalObject->NeuronOutput_LastCalculationStep;
	ErrorFactor1 = pOriginalObject->ErrorFactor1;
	ErrorFactor2 = pOriginalObject->ErrorFactor2;
	LearningRate = pOriginalObject->LearningRate;
	Dropout = pOriginalObject->Dropout;
	PosX = pOriginalObject->PosX;
	PosY = pOriginalObject->PosY;
	PosZ = pOriginalObject->PosZ;
	pActivationFunction = pOriginalObject->pActivationFunction;
	pSynapticFunction = pOriginalObject->pSynapticFunction;
	pDendriticFunction = pOriginalObject->pDendriticFunction;

	if (Num_Of_Dendrite_Elements < pOriginalObject->Num_Of_Dendrite_Elements)
	{
		delete[] pDendrite_InputValueArray;
		pDendrite_InputValueArray = nullptr;

		delete[] pDendrite_CentroidValueArray;
		pDendrite_CentroidValueArray = nullptr;

		delete[] pDendrite_FactorArray;
		pDendrite_FactorArray = nullptr;

		delete[] pDendrite_CentroidDistanceFuncIDArray;
		pDendrite_CentroidDistanceFuncIDArray = nullptr;

		pDendrite_InputValueArray = new (std::nothrow) float[pOriginalObject->Num_Of_Dendrite_Elements];
		pDendrite_CentroidValueArray = new (std::nothrow) float[pOriginalObject->Num_Of_Dendrite_Elements];
		pDendrite_FactorArray = new (std::nothrow) float[pOriginalObject->Num_Of_Dendrite_Elements];
		pDendrite_CentroidDistanceFuncIDArray = new (std::nothrow) int32_t[pOriginalObject->Num_Of_Dendrite_Elements];
	}

	Num_Of_Dendrite_Elements = pOriginalObject->Num_Of_Dendrite_Elements;
	
	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		pDendrite_InputValueArray[i] = pOriginalObject->pDendrite_InputValueArray[i];
		pDendrite_CentroidValueArray[i] = pOriginalObject->pDendrite_CentroidValueArray[i];
		pDendrite_FactorArray[i] = pOriginalObject->pDendrite_FactorArray[i];
		pDendrite_CentroidDistanceFuncIDArray[i] = pOriginalObject->pDendrite_CentroidDistanceFuncIDArray[i];
	}
	
	if (NumOfOutputSynapses < pOriginalObject->NumOfOutputSynapses)
	{
		delete[] pOutputSynapseActivityStatusArray;
		pOutputSynapseActivityStatusArray = nullptr;

		delete[] pReceiverNeuronIDArray;
		pReceiverNeuronIDArray = nullptr;

		delete[] pOutputSynapsePlasticityArray;
		pOutputSynapsePlasticityArray = nullptr;

		pOutputSynapseActivityStatusArray = new (std::nothrow) bool[pOriginalObject->NumOfOutputSynapses];
		pReceiverNeuronIDArray = new (std::nothrow) int32_t[pOriginalObject->NumOfOutputSynapses];
		pOutputSynapsePlasticityArray = new (std::nothrow) float[pOriginalObject->NumOfOutputSynapses];
	}

	NumOfOutputSynapses = pOriginalObject->NumOfOutputSynapses;

	for (int32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		pOutputSynapseActivityStatusArray[i] = pOriginalObject->pOutputSynapseActivityStatusArray[i];
		pReceiverNeuronIDArray[i] = pOriginalObject->pReceiverNeuronIDArray[i];
		pOutputSynapsePlasticityArray[i] = pOriginalObject->pOutputSynapsePlasticityArray[i];
	}
}

void CNeuronV2::Clone_Synaptic_Data(const CNeuronV2 *pOriginalObject)
{
	NumOfTrainingExamples = pOriginalObject->NumOfTrainingExamples;

	for (int32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		pOutputSynapseActivityStatusArray[i] = pOriginalObject->pOutputSynapseActivityStatusArray[i];
		pReceiverNeuronIDArray[i] = pOriginalObject->pReceiverNeuronIDArray[i];
		pOutputSynapsePlasticityArray[i] = pOriginalObject->pOutputSynapsePlasticityArray[i];
	}
}

void CNeuronV2::Combine_Synaptic_Data(CRandomNumbersNN *pRandomNumbers, const CNeuronV2 *pParentObject1, const CNeuronV2 *pParentObject2)
{
	for (int32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		if (pRandomNumbers->Get_IntegerNumber2(1, 2) == 1)
		{
			pOutputSynapseActivityStatusArray[i] = pParentObject1->pOutputSynapseActivityStatusArray[i];
			pReceiverNeuronIDArray[i] = pParentObject1->pReceiverNeuronIDArray[i];
			pOutputSynapsePlasticityArray[i] = pParentObject1->pOutputSynapsePlasticityArray[i];
		}
		else
		{
			pOutputSynapseActivityStatusArray[i] = pParentObject2->pOutputSynapseActivityStatusArray[i];
			pReceiverNeuronIDArray[i] = pParentObject2->pReceiverNeuronIDArray[i];
			pOutputSynapsePlasticityArray[i] = pParentObject2->pOutputSynapsePlasticityArray[i];
		}
	}
}

void CNeuronV2::Combine_Dendrite_Data_RandomWeighted(CRandomNumbersNN *pRandomNumbers, const CNeuronV2 *pParentObject1, const CNeuronV2 *pParentObject2)
{
	float weight1, weight2;

	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		weight1 = pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f);
		weight2 = 1.0f - weight1;

		pDendrite_CentroidValueArray[i] = weight1 * pParentObject1->pDendrite_CentroidValueArray[i] + weight2 * pParentObject2->pDendrite_CentroidValueArray[i];
		pDendrite_FactorArray[i] = weight1 * pParentObject1->pDendrite_FactorArray[i] + weight2 * pParentObject2->pDendrite_FactorArray[i];
	}
}

void CNeuronV2::Combine_Dendrite_Data_RandomWeighted(CRandomNumbersNN *pRandomNumbers, const CNeuronV2 *pParentObject1, const CNeuronV2 *pParentObject2, float minParent1Weight, float maxParent1Weight)
{
	float weight1, weight2;

	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		weight1 = pRandomNumbers->Get_FloatNumber_IncludingZero(minParent1Weight, maxParent1Weight);
		weight2 = 1.0f - weight1;

		pDendrite_CentroidValueArray[i] = weight1 * pParentObject1->pDendrite_CentroidValueArray[i] + weight2 * pParentObject2->pDendrite_CentroidValueArray[i];
		pDendrite_FactorArray[i] = weight1 * pParentObject1->pDendrite_FactorArray[i] + weight2 * pParentObject2->pDendrite_FactorArray[i];
	}
}

void CNeuronV2::Permute_Dendrite_Values(CRandomNumbersNN *pRandomNumbers, int32_t minVectorElement, int32_t maxVectorElement, int32_t permutationSteps)
{
	for (int32_t i = 0; i < permutationSteps; i++)
	{
		int32_t id1 = pRandomNumbers->Get_IntegerNumber2(minVectorElement, maxVectorElement);
		int32_t id2 = pRandomNumbers->Get_IntegerNumber2(minVectorElement, maxVectorElement);

		float tempValue1 = pDendrite_CentroidValueArray[id1];
		float tempValue2 = pDendrite_FactorArray[id1];

		pDendrite_CentroidValueArray[id1] = pDendrite_CentroidValueArray[id2];
		pDendrite_FactorArray[id1] = pDendrite_FactorArray[id2];

		pDendrite_CentroidValueArray[id2] = tempValue1;
		pDendrite_FactorArray[id2] = tempValue2;
	}
}

void CNeuronV2::Permute_Dendrite_Values(CRandomNumbersNN *pRandomNumbers, int32_t permutationSteps)
{
	for (int32_t i = 0; i < permutationSteps; i++)
	{
		int32_t id1 = pRandomNumbers->Get_IntegerNumber(0, Num_Of_Dendrite_Elements);
		int32_t id2 = pRandomNumbers->Get_IntegerNumber(0, Num_Of_Dendrite_Elements);

		float tempValue1 = pDendrite_CentroidValueArray[id1];
		float tempValue2 = pDendrite_FactorArray[id1];

		pDendrite_CentroidValueArray[id1] = pDendrite_CentroidValueArray[id2];
		pDendrite_FactorArray[id1] = pDendrite_FactorArray[id2];

		pDendrite_CentroidValueArray[id2] = tempValue1;
		pDendrite_FactorArray[id2] = tempValue2;
	}
}

void CNeuronV2::Permute_Dendrite_CentroidValues(CRandomNumbersNN *pRandomNumbers, int32_t minVectorElement, int32_t maxVectorElement, int32_t permutationSteps)
{
	for (int32_t i = 0; i < permutationSteps; i++)
	{
		int32_t id1 = pRandomNumbers->Get_IntegerNumber2(minVectorElement, maxVectorElement);
		int32_t id2 = pRandomNumbers->Get_IntegerNumber2(minVectorElement, maxVectorElement);

		float tempValue = pDendrite_CentroidValueArray[id1];
		
		pDendrite_CentroidValueArray[id1] = pDendrite_CentroidValueArray[id2];
		
		pDendrite_CentroidValueArray[id2] = tempValue;
	}
}

void CNeuronV2::Permute_Dendrite_CentroidValues(CRandomNumbersNN *pRandomNumbers, int32_t permutationSteps)
{
	for (int32_t i = 0; i < permutationSteps; i++)
	{
		int32_t id1 = pRandomNumbers->Get_IntegerNumber(0, Num_Of_Dendrite_Elements);
		int32_t id2 = pRandomNumbers->Get_IntegerNumber(0, Num_Of_Dendrite_Elements);

		float tempValue = pDendrite_CentroidValueArray[id1];

		pDendrite_CentroidValueArray[id1] = pDendrite_CentroidValueArray[id2];

		pDendrite_CentroidValueArray[id2] = tempValue;
	}
}

void CNeuronV2::Permute_Dendrite_Factors(CRandomNumbersNN *pRandomNumbers, int32_t minVectorElement, int32_t maxVectorElement, int32_t permutationSteps)
{
	for (int32_t i = 0; i < permutationSteps; i++)
	{
		int32_t id1 = pRandomNumbers->Get_IntegerNumber2(minVectorElement, maxVectorElement);
		int32_t id2 = pRandomNumbers->Get_IntegerNumber2(minVectorElement, maxVectorElement);

		float tempValue = pDendrite_FactorArray[id1];

		pDendrite_FactorArray[id1] = pDendrite_FactorArray[id2];

		pDendrite_FactorArray[id2] = tempValue;
	}
}

void CNeuronV2::Permute_Dendrite_Factors(CRandomNumbersNN *pRandomNumbers, int32_t permutationSteps)
{
	for (int32_t i = 0; i < permutationSteps; i++)
	{
		int32_t id1 = pRandomNumbers->Get_IntegerNumber(0, Num_Of_Dendrite_Elements);
		int32_t id2 = pRandomNumbers->Get_IntegerNumber(0, Num_Of_Dendrite_Elements);

		float tempValue = pDendrite_FactorArray[id1];

		pDendrite_FactorArray[id1] = pDendrite_FactorArray[id2];

		pDendrite_FactorArray[id2] = tempValue;
	}
}


void CNeuronV2::Combine_Synaptic_Data_RandomWeighted(CRandomNumbersNN *pRandomNumbers, const CNeuronV2 *pParentObject1, const CNeuronV2 *pParentObject2)
{
	float weight1, weight2;

	for (int32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		weight1 = pRandomNumbers->Get_FloatNumber_IncludingZero(0.0f, 1.0f);
		weight2 = 1.0f - weight1;

		pOutputSynapsePlasticityArray[i] = weight1 * pParentObject1->pOutputSynapsePlasticityArray[i] + weight2 * pParentObject2->pOutputSynapsePlasticityArray[i];

		pReceiverNeuronIDArray[i] = pParentObject1->pReceiverNeuronIDArray[i];

		if (pOutputSynapsePlasticityArray[i] != 0.0f)
			pOutputSynapseActivityStatusArray[i] = true;
		else
			pOutputSynapseActivityStatusArray[i] = false;
	}
}

void CNeuronV2::Combine_Synaptic_Data_RandomWeighted(CRandomNumbersNN *pRandomNumbers, const CNeuronV2 *pParentObject1, const CNeuronV2 *pParentObject2, float minParent1Weight, float maxParent1Weight)
{
	float weight1, weight2;

	for (int32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		weight1 = pRandomNumbers->Get_FloatNumber_IncludingZero(minParent1Weight, maxParent1Weight);
		weight2 = 1.0f - weight1;

		pOutputSynapsePlasticityArray[i] = weight1 * pParentObject1->pOutputSynapsePlasticityArray[i] + weight2 * pParentObject2->pOutputSynapsePlasticityArray[i];

		pReceiverNeuronIDArray[i] = pParentObject1->pReceiverNeuronIDArray[i];

		if (pOutputSynapsePlasticityArray[i] != 0.0f)
			pOutputSynapseActivityStatusArray[i] = true;
		else
			pOutputSynapseActivityStatusArray[i] = false;
	}
}

void CNeuronV2::Combine_Synaptic_Data(CRandomNumbersNN *pRandomNumbers, const CNeuronV2 *pParentObject1, const CNeuronV2 *pParentObject2, float weightFactorParent1)
{
	for (int32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		if (pRandomNumbers->Get_FloatNumber(0.0f, 100.0f) <= weightFactorParent1)
		{
			pOutputSynapseActivityStatusArray[i] = pParentObject1->pOutputSynapseActivityStatusArray[i];
			pReceiverNeuronIDArray[i] = pParentObject1->pReceiverNeuronIDArray[i];
			pOutputSynapsePlasticityArray[i] = pParentObject1->pOutputSynapsePlasticityArray[i];
		}
		else
		{
			pOutputSynapseActivityStatusArray[i] = pParentObject2->pOutputSynapseActivityStatusArray[i];
			pReceiverNeuronIDArray[i] = pParentObject2->pReceiverNeuronIDArray[i];
			pOutputSynapsePlasticityArray[i] = pParentObject2->pOutputSynapsePlasticityArray[i];
		}
	}
}

void CNeuronV2::Clone_Dendrite_Data(const CNeuronV2 *pOriginalObject)
{
	NumOfTrainingExamples = pOriginalObject->NumOfTrainingExamples;

	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		pDendrite_InputValueArray[i] = pOriginalObject->pDendrite_InputValueArray[i];
		pDendrite_CentroidValueArray[i] = pOriginalObject->pDendrite_CentroidValueArray[i];
		pDendrite_FactorArray[i] = pOriginalObject->pDendrite_FactorArray[i];
		pDendrite_CentroidDistanceFuncIDArray[i] = pOriginalObject->pDendrite_CentroidDistanceFuncIDArray[i];
	}
}

void CNeuronV2::Set_Dendrite_Data(float *pCentroidValueArray, float *pFactorArray)
{
	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		pDendrite_CentroidValueArray[i] = pCentroidValueArray[i];
		pDendrite_FactorArray[i] = pFactorArray[i];
	}
}

void CNeuronV2::Set_Dendrite_Data(int32_t minDendriteID, int32_t maxDendriteID, float *pCentroidValueArray, float *pFactorArray)
{
	maxDendriteID++;

	int32_t counter = 0;
	for (int32_t i = minDendriteID; i < maxDendriteID; i++)
	{
		pDendrite_CentroidValueArray[i] = pCentroidValueArray[counter];
		pDendrite_FactorArray[i] = pFactorArray[counter];
		counter++;
	}
}

void CNeuronV2::Add_Dendrite_CentroidValues(int32_t minDendriteID, int32_t maxDendriteID, float *pCentroidValueArray)
{
	maxDendriteID++;

	float weight1 = 1.0f / (static_cast<float>(NumOfTrainingExamples) + 1.0f);
	float weight2 = 1.0f - weight1;

	int32_t counter = 0;
	for (int32_t i = minDendriteID; i < maxDendriteID; i++)
	{
		pDendrite_CentroidValueArray[i] = weight1 * pCentroidValueArray[counter++] + weight2 * pDendrite_CentroidValueArray[i];
	}

	NumOfTrainingExamples++;
}

void CNeuronV2::SimpleAdd_Dendrite_CentroidValues(int32_t minDendriteID, int32_t maxDendriteID, float *pCentroidValueArray)
{
	maxDendriteID++;

	int32_t counter = 0;
	for (int32_t i = minDendriteID; i < maxDendriteID; i++)
	{
		pDendrite_CentroidValueArray[i] += pCentroidValueArray[counter++];
	}

	NumOfTrainingExamples++;
}

void CNeuronV2::Add_Dendrite_CentroidValues(int32_t minDendriteID, int32_t maxDendriteID, float *pCentroidValueArray, float centroidScale)
{
	maxDendriteID++;

	float weight1 = 1.0f / (static_cast<float>(NumOfTrainingExamples) + 1.0f);
	float weight2 = 1.0f - weight1;
	weight1 *= centroidScale;

	int32_t counter = 0;
	for (int32_t i = minDendriteID; i < maxDendriteID; i++)
	{
		pDendrite_CentroidValueArray[i] = weight1 * pCentroidValueArray[counter++] + weight2 * pDendrite_CentroidValueArray[i];
	}

	NumOfTrainingExamples++;
}

void CNeuronV2::SimpleAdd_Dendrite_CentroidValues(int32_t minDendriteID, int32_t maxDendriteID, float *pCentroidValueArray, float centroidScale)
{
	maxDendriteID++;

	int32_t counter = 0;
	for (int32_t i = minDendriteID; i < maxDendriteID; i++)
	{
		pDendrite_CentroidValueArray[i] += centroidScale * pCentroidValueArray[counter++];
	}

	NumOfTrainingExamples++;
}

void CNeuronV2::Add_Dendrite_CentroidValues(int32_t minDendriteID, int32_t maxDendriteID, int32_t *pCentroidValueArray, float centroidScale)
{
	maxDendriteID++;

	float weight1 = 1.0f / (static_cast<float>(NumOfTrainingExamples) + 1.0f);
	float weight2 = 1.0f - weight1;
	weight1 *= centroidScale;

	int32_t counter = 0;
	for (int32_t i = minDendriteID; i < maxDendriteID; i++)
	{
		pDendrite_CentroidValueArray[i] = weight1 * static_cast<float>(pCentroidValueArray[counter++]) + weight2 * pDendrite_CentroidValueArray[i];
	}

	NumOfTrainingExamples++;
}
void CNeuronV2::SimpleAdd_Dendrite_CentroidValues(int32_t minDendriteID, int32_t maxDendriteID, int32_t *pCentroidValueArray, float centroidScale)
{
	maxDendriteID++;

	int32_t counter = 0;
	for (int32_t i = minDendriteID; i < maxDendriteID; i++)
	{
		pDendrite_CentroidValueArray[i] += centroidScale * static_cast<float>(pCentroidValueArray[counter++]);
	}

	NumOfTrainingExamples++;
}


void CNeuronV2::Set_Dendrite_Factor(float factor, float regardedCentroidValue)
{
	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		if (pDendrite_CentroidValueArray[i] == regardedCentroidValue)
			pDendrite_FactorArray[i] = factor;
	}
}

void CNeuronV2::Set_Dendrite_Factor(float factor, float lowerCentroidValueThreshold, float upperCentroidValueThreshold)
{
	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		if (pDendrite_CentroidValueArray[i] <= upperCentroidValueThreshold && pDendrite_CentroidValueArray[i] >= lowerCentroidValueThreshold)
			pDendrite_FactorArray[i] = factor;
	}
}

void CNeuronV2::Set_Dendrite_Factor(int32_t minVectorElement, int32_t maxVectorElement, float factor, float regardedCentroidValue)
{
	maxVectorElement++;

	for (int32_t i = minVectorElement; i < maxVectorElement; i++)
	{
		if (pDendrite_CentroidValueArray[i] == regardedCentroidValue)
			pDendrite_FactorArray[i] = factor;
	}
}

void CNeuronV2::Set_Dendrite_Factor(int32_t minVectorElement, int32_t maxVectorElement, float factor, float lowerCentroidValueThreshold, float upperCentroidValueThreshold)
{
	maxVectorElement++;

	for (int32_t i = minVectorElement; i < maxVectorElement; i++)
	{
		if (pDendrite_CentroidValueArray[i] <= upperCentroidValueThreshold && pDendrite_CentroidValueArray[i] >= lowerCentroidValueThreshold)
			pDendrite_FactorArray[i] = factor;
	}
}

void CNeuronV2::Scale_Dendrite_CentroidValues_Up_To_One(void)
{
	float maxValue = -10000000.0f;

	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		if (pDendrite_CentroidValueArray[i] > maxValue && pDendrite_CentroidValueArray[i] != 0.0f)
			maxValue = pDendrite_CentroidValueArray[i];
	}

	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
		pDendrite_CentroidValueArray[i] /= maxValue;
}


void CNeuronV2::Normalize_Dendrite_CentroidValues(void)
{
	float tempFloat;
	float sum = 0.00001f;

	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		tempFloat = pDendrite_CentroidValueArray[i];
		tempFloat *= tempFloat;
		sum += tempFloat;
	}

	float invSum = 1.0f / sqrt(sum);

	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
		pDendrite_CentroidValueArray[i] *= invSum;
}

void CNeuronV2::Scale_Dendrite_Factors_Up_To_One(void)
{
	float maxValue = -10000000.0f;

	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		if (pDendrite_FactorArray[i] > maxValue && pDendrite_FactorArray[i] != 0.0f)
			maxValue = pDendrite_FactorArray[i];
	}

	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
		pDendrite_FactorArray[i] /= maxValue;
}

void CNeuronV2::Normalize_Dendrite_Factors(void)
{
	float tempFloat;
	float sum = 0.00001f;

	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		tempFloat = pDendrite_FactorArray[i];
		tempFloat *= tempFloat;
		sum += tempFloat;
	}

	float invSum = 1.0f / sqrt(sum);

	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
		pDendrite_FactorArray[i] *= invSum;
}


void CNeuronV2::Add_Dendrite_Factors(float *pFactorArray)
{
	float weight1 = 1.0f / (static_cast<float>(NumOfTrainingExamples) + 1.0f);
	float weight2 = 1.0f - weight1;

	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		pDendrite_FactorArray[i] = weight1 * pFactorArray[i] + weight2 * pDendrite_FactorArray[i];
	}

	NumOfTrainingExamples++;
}

void CNeuronV2::Add_Dendrite_Factors(float *pFactorArray, float factorScale)
{
	float weight1 = 1.0f / (static_cast<float>(NumOfTrainingExamples) + 1.0f);
	float weight2 = 1.0f - weight1;
	weight1 *= factorScale;

	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		pDendrite_FactorArray[i] = weight1 * pFactorArray[i] + weight2 * pDendrite_FactorArray[i];
	}

	NumOfTrainingExamples++;
}

void CNeuronV2::Add_Dendrite_Factors(int32_t *pFactorArray, float factorScale)
{
	float weight1 = 1.0f / (static_cast<float>(NumOfTrainingExamples) + 1.0f);
	float weight2 = 1.0f - weight1;
	weight1 *= factorScale;

	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		pDendrite_FactorArray[i] = weight1 * static_cast<float>(pFactorArray[i]) + weight2 * pDendrite_FactorArray[i];
	}

	NumOfTrainingExamples++;
}

void CNeuronV2::Add_Dendrite_Factors(int32_t minDendriteID, int32_t maxDendriteID, float *pFactorArray)
{
	maxDendriteID++;

	float weight1 = 1.0f / (static_cast<float>(NumOfTrainingExamples) + 1.0f);
	float weight2 = 1.0f - weight1;

	int32_t counter = 0;
	for (int32_t i = minDendriteID; i < maxDendriteID; i++)
	{
		pDendrite_FactorArray[i] = weight1 * pFactorArray[counter++] + weight2 * pDendrite_FactorArray[i];
	}

	NumOfTrainingExamples++;
}

void CNeuronV2::Add_Dendrite_Factors(int32_t minDendriteID, int32_t maxDendriteID, float *pFactorArray, float factorScale)
{
	maxDendriteID++;

	float weight1 = 1.0f / (static_cast<float>(NumOfTrainingExamples) + 1.0f);
	float weight2 = 1.0f - weight1;
	weight1 *= factorScale;

	int32_t counter = 0;
	for (int32_t i = minDendriteID; i < maxDendriteID; i++)
	{
		pDendrite_FactorArray[i] = weight1 * pFactorArray[counter++] + weight2 * pDendrite_FactorArray[i];
	}

	NumOfTrainingExamples++;
}

void CNeuronV2::Add_Dendrite_Factors(int32_t minDendriteID, int32_t maxDendriteID, int32_t *pFactorArray, float factorScale)
{
	maxDendriteID++;

	float weight1 = 1.0f / (static_cast<float>(NumOfTrainingExamples) + 1.0f);
	float weight2 = 1.0f - weight1;
	weight1 *= factorScale;

	int32_t counter = 0;
	for (int32_t i = minDendriteID; i < maxDendriteID; i++)
	{
		pDendrite_FactorArray[i] = weight1 * static_cast<float>(pFactorArray[counter++]) + weight2 * pDendrite_FactorArray[i];
	}

	NumOfTrainingExamples++;
}

void CNeuronV2::Add_Dendrite_CentroidValues(float *pCentroidValueArray)
{
	float weight1 = 1.0f / (static_cast<float>(NumOfTrainingExamples) + 1.0f);
	float weight2 = 1.0f - weight1;

	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		pDendrite_CentroidValueArray[i] = weight1 * pCentroidValueArray[i] + weight2 * pDendrite_CentroidValueArray[i];
	}

	NumOfTrainingExamples++;
}

void CNeuronV2::SimpleAdd_Dendrite_CentroidValues(float *pCentroidValueArray)
{
	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		pDendrite_CentroidValueArray[i] += pCentroidValueArray[i];
	}

	NumOfTrainingExamples++;
}

void CNeuronV2::Add_Dendrite_CentroidValues(float *pCentroidValueArray, float centroidScale)
{
	float weight1 = 1.0f / (static_cast<float>(NumOfTrainingExamples) + 1.0f);
	float weight2 = 1.0f - weight1;
	weight1 *= centroidScale;

	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		pDendrite_CentroidValueArray[i] = weight1 * pCentroidValueArray[i] + weight2 * pDendrite_CentroidValueArray[i];
	}

	NumOfTrainingExamples++;
}

void CNeuronV2::SimpleAdd_Dendrite_CentroidValues(float *pCentroidValueArray, float centroidScale)
{
	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		pDendrite_CentroidValueArray[i] += centroidScale * pCentroidValueArray[i];
	}

	NumOfTrainingExamples++;
}

void CNeuronV2::Add_Dendrite_CentroidValues(int32_t *pCentroidValueArray, float centroidScale)
{
	float weight1 = 1.0f / (static_cast<float>(NumOfTrainingExamples) + 1.0f);
	float weight2 = 1.0f - weight1;
	weight1 *= centroidScale;

	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		pDendrite_CentroidValueArray[i] = weight1 * static_cast<float>(pCentroidValueArray[i]) + weight2 * pDendrite_CentroidValueArray[i];
	}

	NumOfTrainingExamples++;
}

void CNeuronV2::SimpleAdd_Dendrite_CentroidValues(int32_t *pCentroidValueArray, float centroidScale)
{
	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		pDendrite_CentroidValueArray[i] += centroidScale * static_cast<float>(pCentroidValueArray[i]);
	}

	NumOfTrainingExamples++;
}

void CNeuronV2::Set_Dendrite_CentroidValues(float *pCentroidValueArray)
{
	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		pDendrite_CentroidValueArray[i] = pCentroidValueArray[i];
	}
}

void CNeuronV2::Set_Dendrite_CentroidValues(int32_t minDendriteID, int32_t maxDendriteID, float *pCentroidValueArray)
{
	maxDendriteID++;
	int32_t counter = 0;

	for (int32_t i = minDendriteID; i < maxDendriteID; i++)
	{
		pDendrite_CentroidValueArray[i] = pCentroidValueArray[counter++];
	}
}

void CNeuronV2::Set_Dendrite_Factors(float *pFactorArray)
{
	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		pDendrite_FactorArray[i] = pFactorArray[i];
	}
}

void CNeuronV2::Set_Dendrite_Factors(int32_t minDendriteID, int32_t maxDendriteID, float *pFactorArray)
{
	maxDendriteID++;
	int32_t counter = 0;

	for (int32_t i = minDendriteID; i < maxDendriteID; i++)
	{
		pDendrite_FactorArray[i] = pFactorArray[counter++];
	}
}

void CNeuronV2::Set_Dendrite_Factors(float value)
{
	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		pDendrite_FactorArray[i] = value;
	}
}

void CNeuronV2::Set_Dendrite_Factors(int32_t minDendriteID, int32_t maxDendriteID, float value)
{
	maxDendriteID++;

	
	for (int32_t i = minDendriteID; i < maxDendriteID; i++)
	{
		pDendrite_FactorArray[i] = value;
	}
}

void CNeuronV2::Set_Dendrite_CentroidDistanceFunctionsIDs(int32_t *pIDArray)
{
	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		pDendrite_CentroidDistanceFuncIDArray[i] = pIDArray[i];
	}
}

void CNeuronV2::Calculate_Dendrite_Factors_From_CentroidValues(int32_t minVectorElement, int32_t maxVectorElement, float fallback_RBF_Factor, float centroidWeightFactor, int32_t centroidExponent)
{
	maxVectorElement++;

	for (int32_t i = minVectorElement; i < maxVectorElement; i++)
	{
		pDendrite_FactorArray[i] = pDendrite_CentroidValueArray[i];
	}

	for (int32_t j = 1; j < centroidExponent; j++)
	{
		for (int32_t i = minVectorElement; i < maxVectorElement; i++)
		{
			pDendrite_FactorArray[i] *= pDendrite_CentroidValueArray[i];
		}
	}

	for (int32_t i = minVectorElement; i < maxVectorElement; i++)
	{
		pDendrite_FactorArray[i] *= centroidWeightFactor;
	}

	for (int32_t i = minVectorElement; i < maxVectorElement; i++)
	{
		if (pDendrite_CentroidValueArray[i] == 0.0f)
			pDendrite_FactorArray[i] = fallback_RBF_Factor;
	}
}

void CNeuronV2::Calculate_Dendrite_Factors_From_CentroidValues(float fallback_RBF_Factor, float centroidWeightFactor, int32_t centroidExponent)
{
	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		pDendrite_FactorArray[i] = pDendrite_CentroidValueArray[i];
	}

	for (int32_t j = 1; j < centroidExponent; j++)
	{
		for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
		{
			pDendrite_FactorArray[i] *= pDendrite_CentroidValueArray[i];
		}
	}

	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		pDendrite_FactorArray[i] *= centroidWeightFactor;
	}

	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		if(pDendrite_CentroidValueArray[i] == 0.0f)
			pDendrite_FactorArray[i] = fallback_RBF_Factor;
	}
}

void CNeuronV2::Combine_Dendrite_Data(CRandomNumbersNN *pRandomNumbers, const CNeuronV2 *pParentObject1, const CNeuronV2 *pParentObject2)
{
	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		if (pRandomNumbers->Get_IntegerNumber2(1, 2) == 1)
		{
			pDendrite_CentroidValueArray[i] = pParentObject1->pDendrite_CentroidValueArray[i];
			pDendrite_FactorArray[i] = pParentObject1->pDendrite_FactorArray[i];
		}
		else
		{
			pDendrite_CentroidValueArray[i] = pParentObject1->pDendrite_CentroidValueArray[i];
			pDendrite_FactorArray[i] = pParentObject1->pDendrite_FactorArray[i];
		}
	}
}

void CNeuronV2::Combine_Dendrite_Data(CRandomNumbersNN *pRandomNumbers, const CNeuronV2 *pParentObject1, const CNeuronV2 *pParentObject2, float weightFactorParent1)
{
	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		if (pRandomNumbers->Get_FloatNumber(0.0f, 100.0f) <= weightFactorParent1)
		{
			pDendrite_CentroidValueArray[i] = pParentObject1->pDendrite_CentroidValueArray[i];
			pDendrite_FactorArray[i] = pParentObject1->pDendrite_FactorArray[i];
		}
		else
		{
			pDendrite_CentroidValueArray[i] = pParentObject1->pDendrite_CentroidValueArray[i];
			pDendrite_FactorArray[i] = pParentObject1->pDendrite_FactorArray[i];
		}
	}
}

void CNeuronV2::Clone_Data(const CNeuronV2 *pOriginalObject)
{
	MinNeuronOutputTreshold = pOriginalObject->MinNeuronOutputTreshold;
	MaxNeuronOutputValue = pOriginalObject->MaxNeuronOutputValue;
	NumOfTrainingExamples = pOriginalObject->NumOfTrainingExamples;
	BiasNeuron = pOriginalObject->BiasNeuron;
	NeuronInput = pOriginalObject->NeuronInput;
	NeuronOutput = pOriginalObject->NeuronOutput;
	NeuronOutput_LastCalculationStep = pOriginalObject->NeuronOutput_LastCalculationStep;
	ErrorFactor1 = pOriginalObject->ErrorFactor1;
	ErrorFactor2 = pOriginalObject->ErrorFactor2;
	LearningRate = pOriginalObject->LearningRate;
	Dropout = pOriginalObject->Dropout;
	PosX = pOriginalObject->PosX;
	PosY = pOriginalObject->PosY;
	PosZ = pOriginalObject->PosZ;
	pActivationFunction = pOriginalObject->pActivationFunction;
	pSynapticFunction = pOriginalObject->pSynapticFunction;
	pDendriticFunction = pOriginalObject->pDendriticFunction;

	Num_Of_Dendrite_Elements = pOriginalObject->Num_Of_Dendrite_Elements;

	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		pDendrite_CentroidValueArray[i] = pOriginalObject->pDendrite_CentroidValueArray[i];
		pDendrite_FactorArray[i] = pOriginalObject->pDendrite_FactorArray[i];
		pDendrite_CentroidDistanceFuncIDArray[i] = pOriginalObject->pDendrite_CentroidDistanceFuncIDArray[i];
	}

	NumOfOutputSynapses = pOriginalObject->NumOfOutputSynapses;

	for (int32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		pOutputSynapseActivityStatusArray[i] = pOriginalObject->pOutputSynapseActivityStatusArray[i];
		pReceiverNeuronIDArray[i] = pOriginalObject->pReceiverNeuronIDArray[i];
		pOutputSynapsePlasticityArray[i] = pOriginalObject->pOutputSynapsePlasticityArray[i];
	}
}

void CNeuronV2::Round_Dendrite_CentroidValues(float precision, float invPrecision)
{
	float fValue;
	int32_t iValue;

	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		iValue = static_cast<int32_t>(invPrecision * pDendrite_CentroidValueArray[i]);
		fValue = static_cast<float>(iValue);
		fValue *= precision;

		pDendrite_CentroidValueArray[i] = fValue;
	}
}

void CNeuronV2::Round_Dendrite_CentroidValues(float precision, float invPrecision, int32_t minVectorElement, int32_t maxVectorElement)
{
	maxVectorElement++;

	float fValue;
	int32_t iValue;

	for (int32_t i = minVectorElement; i < maxVectorElement; i++)
	{
		iValue = static_cast<int32_t>(invPrecision * pDendrite_CentroidValueArray[i]);
		fValue = static_cast<float>(iValue);
		fValue *= precision;

		pDendrite_CentroidValueArray[i] = fValue;
	}
}

void CNeuronV2::Round_Dendrite_CentroidValues(float precision)
{
	float invPrecision = 1.0f / precision;

	float fValue;
	int32_t iValue;

	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		iValue = static_cast<int32_t>(invPrecision * pDendrite_CentroidValueArray[i]);
		fValue = static_cast<float>(iValue);
		fValue *= precision;

		pDendrite_CentroidValueArray[i] = fValue;
	}
}

void CNeuronV2::Round_Dendrite_CentroidValues(float precision, int32_t minVectorElement, int32_t maxVectorElement)
{
	maxVectorElement++;

	float invPrecision = 1.0f / precision;

	float fValue;
	int32_t iValue;

	for (int32_t i = minVectorElement; i < maxVectorElement; i++)
	{
		iValue = static_cast<int32_t>(invPrecision * pDendrite_CentroidValueArray[i]);
		fValue = static_cast<float>(iValue);
		fValue *= precision;

		pDendrite_CentroidValueArray[i] = fValue;
	}
}

void CNeuronV2::Round_Dendrite_Values(float precision, float invPrecision)
{
	float fValue;
	int32_t iValue;

	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		iValue = static_cast<int32_t>(invPrecision * pDendrite_CentroidValueArray[i]);
		fValue = static_cast<float>(iValue);
		fValue *= precision;

		pDendrite_CentroidValueArray[i] = fValue;

		iValue = static_cast<int32_t>(invPrecision * pDendrite_FactorArray[i]);
		fValue = static_cast<float>(iValue);
		fValue *= precision;

		pDendrite_FactorArray[i] = fValue;
	}
}

void CNeuronV2::Round_Dendrite_Values(float precision, float invPrecision, int32_t minVectorElement, int32_t maxVectorElement)
{
	maxVectorElement++;

	float fValue;
	int32_t iValue;

	for (int32_t i = minVectorElement; i < maxVectorElement; i++)
	{
		iValue = static_cast<int32_t>(invPrecision * pDendrite_CentroidValueArray[i]);
		fValue = static_cast<float>(iValue);
		fValue *= precision;

		pDendrite_CentroidValueArray[i] = fValue;

		iValue = static_cast<int32_t>(invPrecision * pDendrite_FactorArray[i]);
		fValue = static_cast<float>(iValue);
		fValue *= precision;

		pDendrite_FactorArray[i] = fValue;
	}
}

void CNeuronV2::Round_Dendrite_Values(float precision)
{
	float invPrecision = 1.0f / precision;

	float fValue;
	int32_t iValue;

	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		iValue = static_cast<int32_t>(invPrecision * pDendrite_CentroidValueArray[i]);
		fValue = static_cast<float>(iValue);
		fValue *= precision;

		pDendrite_CentroidValueArray[i] = fValue;

		iValue = static_cast<int32_t>(invPrecision * pDendrite_FactorArray[i]);
		fValue = static_cast<float>(iValue);
		fValue *= precision;

		pDendrite_FactorArray[i] = fValue;
	}
}

void CNeuronV2::Round_Dendrite_Values(float precision, int32_t minVectorElement, int32_t maxVectorElement)
{
	maxVectorElement++;

	float invPrecision = 1.0f / precision;

	float fValue;
	int32_t iValue;

	for (int32_t i = minVectorElement; i < maxVectorElement; i++)
	{
		iValue = static_cast<int32_t>(invPrecision * pDendrite_CentroidValueArray[i]);
		fValue = static_cast<float>(iValue);
		fValue *= precision;

		pDendrite_CentroidValueArray[i] = fValue;

		iValue = static_cast<int32_t>(invPrecision * pDendrite_FactorArray[i]);
		fValue = static_cast<float>(iValue);
		fValue *= precision;

		pDendrite_FactorArray[i] = fValue;
	}
}

void CNeuronV2::Round_Dendrite_Factors(float precision, float invPrecision)
{
	float fValue;
	int32_t iValue;

	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		iValue = static_cast<int32_t>(invPrecision * pDendrite_FactorArray[i]);
		fValue = static_cast<float>(iValue);
		fValue *= precision;

		pDendrite_FactorArray[i] = fValue;
	}
}

void CNeuronV2::Round_Dendrite_Factors(float precision, float invPrecision, int32_t minVectorElement, int32_t maxVectorElement)
{
	maxVectorElement++;

	float fValue;
	int32_t iValue;

	for (int32_t i = minVectorElement; i < maxVectorElement; i++)
	{
		iValue = static_cast<int32_t>(invPrecision * pDendrite_FactorArray[i]);
		fValue = static_cast<float>(iValue);
		fValue *= precision;

		pDendrite_FactorArray[i] = fValue;
	}
}

void CNeuronV2::Round_Dendrite_Factors(float precision)
{
	float invPrecision = 1.0f / precision;

	float fValue;
	int32_t iValue;

	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		iValue = static_cast<int32_t>(invPrecision * pDendrite_FactorArray[i]);
		fValue = static_cast<float>(iValue);
		fValue *= precision;

		pDendrite_FactorArray[i] = fValue;
	}
}

void CNeuronV2::Round_Dendrite_Factors(float precision, int32_t minVectorElement, int32_t maxVectorElement)
{
	maxVectorElement++;

	float invPrecision = 1.0f / precision;

	float fValue;
	int32_t iValue;

	for (int32_t i = minVectorElement; i < maxVectorElement; i++)
	{
		iValue = static_cast<int32_t>(invPrecision * pDendrite_FactorArray[i]);
		fValue = static_cast<float>(iValue);
		fValue *= precision;

		pDendrite_FactorArray[i] = fValue;
	}
}

void CNeuronV2::Round_SynapticPlasticities(float precision, float invPrecision)
{
	float fValue;
	int32_t iValue;

	for (int32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		iValue = static_cast<int32_t>(invPrecision * pOutputSynapsePlasticityArray[i]);
		fValue = static_cast<float>(iValue);
		fValue *= precision;

		pOutputSynapsePlasticityArray[i] = fValue;
	}
}

void CNeuronV2::Round_SynapticPlasticities(float precision)
{
	float invPrecision = 1.0f / precision;

	float fValue;
	int32_t iValue;

	for (int32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		iValue = static_cast<int32_t>(invPrecision * pOutputSynapsePlasticityArray[i]);
		fValue = static_cast<float>(iValue);
		fValue *= precision;

		pOutputSynapsePlasticityArray[i] = fValue;
	}
}



void CNeuronV2::Remove_Unused_Connections(void)
{
	int32_t numOfUsedConnections = 0;

	for (int32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		if (pOutputSynapsePlasticityArray[i] != 0.0f && pOutputSynapseActivityStatusArray[i] == true)
		{
			numOfUsedConnections++;
		}
	}

	float *pTempPlasticityArray = new (std::nothrow) float[numOfUsedConnections];
	int32_t *pTempReceiverNeuronIDArray = new (std::nothrow) int32_t[numOfUsedConnections];

	uint32_t counter = 0;

	for (uint32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		if (pOutputSynapsePlasticityArray[i] != 0.0f && pOutputSynapseActivityStatusArray[i] == true)
		{
			pTempPlasticityArray[counter] = pOutputSynapsePlasticityArray[i];
			pTempReceiverNeuronIDArray[counter] = pReceiverNeuronIDArray[i];
			counter++;	
		}
	}

	delete[] pOutputSynapseActivityStatusArray;
	pOutputSynapseActivityStatusArray = nullptr;

	delete[] pOutputSynapsePlasticityArray;
	pOutputSynapsePlasticityArray = nullptr;

	delete[] pReceiverNeuronIDArray;
	pReceiverNeuronIDArray = nullptr;

	NumOfOutputSynapses = numOfUsedConnections;

	pOutputSynapsePlasticityArray = new (std::nothrow) float[NumOfOutputSynapses];
	pReceiverNeuronIDArray = new (std::nothrow) int32_t[NumOfOutputSynapses];
	pOutputSynapseActivityStatusArray = new (std::nothrow) bool[numOfUsedConnections];

	for (int32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		pOutputSynapseActivityStatusArray[i] = true;
		pOutputSynapsePlasticityArray[i] = pTempPlasticityArray[i];
		pReceiverNeuronIDArray[i] = pTempReceiverNeuronIDArray[i];
	}

	delete[] pTempReceiverNeuronIDArray;
	pTempReceiverNeuronIDArray = nullptr;

	delete[] pTempPlasticityArray;
	pTempPlasticityArray = nullptr;
}

void CNeuronV2::Connect_With_Brain(CNeuronV2 *pNeuronArray)
{
	Dropout = false;
	pUsedNeuronArray = pNeuronArray;
}

void CNeuronV2::Set_ActivationFunction(pActivationFuncV2 pFunc)
{
	BiasNeuron = false;
	pActivationFunction = pFunc;

	if (pFunc == BiasActivationFunction)
		BiasNeuron = true;
}

void CNeuronV2::Set_DendriticFunction(pDendriticFuncV2 pFunc)
{
	pDendriticFunction = pFunc;
}

void CNeuronV2::Set_SynapticFunction(pSynapticFuncV2 pFunc)
{
	pSynapticFunction = pFunc;
}

void CNeuronV2::Set_Position(float x, float y, float z)
{
	PosX = x;
	PosY = y;
	PosZ = z;
}

float CNeuronV2::Get_Distance_to_Other_Neuron(int32_t neuronID)
{
	float dx = PosX - pUsedNeuronArray[neuronID].PosX;
	float dy = PosY - pUsedNeuronArray[neuronID].PosY;
	float dz = PosZ - pUsedNeuronArray[neuronID].PosZ;

	return sqrt(dx*dx + dy*dy + dz*dz);
}

float CNeuronV2::Get_InvDistance_to_Other_Neuron(int32_t neuronID)
{
	float dx = PosX - pUsedNeuronArray[neuronID].PosX;
	float dy = PosY - pUsedNeuronArray[neuronID].PosY;
	float dz = PosZ - pUsedNeuronArray[neuronID].PosZ;

	return 1.0f / sqrt(dx*dx + dy*dy + dz*dz + 0.0001f);
}

float CNeuronV2::Get_DistanceSq_to_Other_Neuron(int32_t neuronID)
{
	float dx = PosX - pUsedNeuronArray[neuronID].PosX;
	float dy = PosY - pUsedNeuronArray[neuronID].PosY;
	float dz = PosZ - pUsedNeuronArray[neuronID].PosZ;

	return dx*dx + dy*dy + dz*dz;
}

float CNeuronV2::Get_InvDistanceSq_to_Other_Neuron(int32_t neuronID)
{
	float dx = PosX - pUsedNeuronArray[neuronID].PosX;
	float dy = PosY - pUsedNeuronArray[neuronID].PosY;
	float dz = PosZ - pUsedNeuronArray[neuronID].PosZ;

	return 1.0f / (dx*dx + dy*dy + dz*dz + 0.0001f);
}

void CNeuronV2::Connect_With_ReceiverNeurons(int32_t *pNeuronIDArray, float *pPlasticityValueArray)
{
	for (int32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		pReceiverNeuronIDArray[i] = pNeuronIDArray[i];
		pOutputSynapsePlasticityArray[i] = pPlasticityValueArray[i];

		if (pOutputSynapsePlasticityArray[i] == 0.0f)
			pOutputSynapseActivityStatusArray[i] = false;
		else
			pOutputSynapseActivityStatusArray[i] = true;
	}
}

void CNeuronV2::Connect_With_ReceiverNeurons(int32_t *pNeuronIDArray, float *pPlasticityValueArray, bool *pSynapseActivityStatusArray)
{
	for (int32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		pReceiverNeuronIDArray[i] = pNeuronIDArray[i];
		pOutputSynapsePlasticityArray[i] = pPlasticityValueArray[i];
		pOutputSynapseActivityStatusArray[i] = pSynapseActivityStatusArray[i];
	}
}

void CNeuronV2::Connect_With_ReceiverNeuron(int32_t neuronID, int32_t synapseID)
{
	pReceiverNeuronIDArray[synapseID] = neuronID;
}

void CNeuronV2::Set_OutputSynapseActivityStatus(bool status, int32_t synapseID)
{
	pOutputSynapseActivityStatusArray[synapseID] = status;
}

void CNeuronV2::Set_OutputSynapsePlasticity(float value, int32_t synapseID)
{
	pOutputSynapsePlasticityArray[synapseID] = value;
}

void CNeuronV2::Set_DropoutState(bool state)
{
	Dropout = state;
}

void CNeuronV2::Calculate_NeuronOutput(void)
{
	pActivationFunction(this);
}

void CNeuronV2::Calculate_NeuronOutput_Ext(void)
{
	pDendriticFunction(this);
	pActivationFunction(this);
}

void CNeuronV2::Execute_DendriticCalculations(void)
{
	pDendriticFunction(this);
}


void CNeuronV2::Propagate_SynapticOutput(void)
{
	pSynapticFunction(this);
}

float CNeuronV2::Calculate_VarianceSq(float desiredNeuronOutput)
{
	// Abweichung:
	float variance = desiredNeuronOutput - NeuronOutput;
	return variance*variance;
}

float CNeuronV2::Calculate_Error(float desiredNeuronOutput)
{
	// Abweichung:
	float variance = desiredNeuronOutput - NeuronOutput;
	ErrorValue = variance * ErrorFactor1 * exp(-(ErrorFactor2 * NeuronOutput * NeuronOutput));

	/* Hinweis: Wenn bereits eine geringe Neuronenaktivit�t (NeuronOutput)
	zu einer gro�en Abweichung f�hrt, ist auch der Fehler gro�. Abweichungen
	bei einer starken Neuronenaktivit�t f�hren hingegen zu einem kleineren
	Fehler. */

	return variance*variance;
}

float CNeuronV2::Calculate_Error(float desiredNeuronOutput, float errorFactor1, float errorFactor2)
{
	// Abweichung:
	float variance = desiredNeuronOutput - NeuronOutput;
	ErrorValue = variance * errorFactor1 * exp(-(errorFactor2 * NeuronOutput * NeuronOutput));

	/* Hinweis: Wenn bereits eine geringe Neuronenaktivit�t (NeuronOutput)
	zu einer gro�en Abweichung f�hrt, ist auch der Fehler gro�. Abweichungen
	bei einer starken Neuronenaktivit�t f�hren hingegen zu einem kleineren
	Fehler. */

	return variance*variance;
}

void CNeuronV2::Calculate_Error(void)
{
	int32_t receiverNeuronID;

	float errorSum = 0.0f;

	for (int32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		receiverNeuronID = pReceiverNeuronIDArray[i];
		errorSum += pUsedNeuronArray[receiverNeuronID].ErrorValue * pOutputSynapsePlasticityArray[i];
	}

	ErrorValue = errorSum * ErrorFactor1 * exp(-(ErrorFactor2 * NeuronOutput * NeuronOutput));

	/* Hinweis: Abweichungen bei einer geringen Neuronenaktivit�t f�hren
	zu einem gr��eren Fehler. Abweichungen bei einer starken Neuronenaktivit�t
	f�hren hingegen zu einem kleineren Fehler. */
}

void CNeuronV2::Calculate_Error(float *pInErrorValueArray, float errorFactor1, float errorFactor2)
{
	float errorSum = 0.0f;

	for (int32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		errorSum += pInErrorValueArray[i] * pOutputSynapsePlasticityArray[i];
	}

	ErrorValue = errorSum * errorFactor1 * exp(-(errorFactor2 * NeuronOutput * NeuronOutput));

	/* Hinweis: Abweichungen bei einer geringen Neuronenaktivit�t f�hren
	zu einem gr��eren Fehler. Abweichungen bei einer starken Neuronenaktivit�t
	f�hren hingegen zu einem kleineren Fehler. */
}




void CNeuronV2::Adjust_OutputSynapses(const CNeuronV2 *pBestNeuron, CRandomNumbersNN *pRandomNumbers, float learningRate, float learningRateVariance, float errorFactor1, float errorFactor2)
{
	float errorValue;
	float variance;

	for (int32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		_Calculate_Error(&errorValue, &variance, pBestNeuron->pOutputSynapsePlasticityArray[i], pOutputSynapsePlasticityArray[i], errorFactor1, errorFactor2);
		pOutputSynapsePlasticityArray[i] += (learningRate + pRandomNumbers->Get_FloatNumber(-learningRateVariance, learningRateVariance)) * errorValue;

		//if (pOutputSynapsePlasticityArray[i] == 0.0f)
		//pOutputSynapsePlasticityArray[i] = 0.001f;
	}
}

void CNeuronV2::Adjust_OutputSynapses(const CNeuronV2 *pBestNeuron)
{
	float errorValue;
	float variance;

	for (int32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		_Calculate_Error(&errorValue, &variance, pBestNeuron->pOutputSynapsePlasticityArray[i], pOutputSynapsePlasticityArray[i], ErrorFactor1, ErrorFactor2);
		pOutputSynapsePlasticityArray[i] += LearningRate * errorValue;

		//if (pOutputSynapsePlasticityArray[i] == 0.0f)
		//pOutputSynapsePlasticityArray[i] = 0.001f;
	}
}

void CNeuronV2::Adjust_Dendrite_CentroidValues(const CNeuronV2 *pBestNeuron)
{
	float errorValue;
	float variance;

	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		_Calculate_Error(&errorValue, &variance, pBestNeuron->pDendrite_CentroidValueArray[i], pDendrite_CentroidValueArray[i], ErrorFactor1, ErrorFactor2);
		pDendrite_CentroidValueArray[i] += LearningRate * errorValue;
	}
}

void CNeuronV2::Adjust_Dendrite_Factors(const CNeuronV2 *pBestNeuron)
{
	float errorValue;
	float variance;

	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		_Calculate_Error(&errorValue, &variance, pBestNeuron->pDendrite_FactorArray[i], pDendrite_FactorArray[i], ErrorFactor1, ErrorFactor2);
		pDendrite_FactorArray[i] += LearningRate * errorValue;
	}
}

void CNeuronV2::Adjust_Dendrite_CentroidValues(const CNeuronV2 *pBestNeuron, CRandomNumbersNN *pRandomNumbers, float learningRate, float learningRateVariance, float errorFactor1, float errorFactor2)
{
	float errorValue;
	float variance;

	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		_Calculate_Error(&errorValue, &variance, pBestNeuron->pDendrite_CentroidValueArray[i], pDendrite_CentroidValueArray[i], errorFactor1, errorFactor2);
		pDendrite_CentroidValueArray[i] += (learningRate + pRandomNumbers->Get_FloatNumber(-learningRateVariance, learningRateVariance)) * errorValue;
	}
}

void CNeuronV2::Adjust_Dendrite_Factors(const CNeuronV2 *pBestNeuron, CRandomNumbersNN *pRandomNumbers, float learningRate, float learningRateVariance, float errorFactor1, float errorFactor2)
{
	float errorValue;
	float variance;

	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		_Calculate_Error(&errorValue, &variance, pBestNeuron->pDendrite_FactorArray[i], pDendrite_FactorArray[i], errorFactor1, errorFactor2);
		pDendrite_FactorArray[i] += (learningRate + pRandomNumbers->Get_FloatNumber(-learningRateVariance, learningRateVariance)) * errorValue;
	}
}

void CNeuronV2::Adjust_OutputSynapses_AfterErrorCalculations(void)
{
	int32_t receiverNeuronID;

	for (int32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		receiverNeuronID = pReceiverNeuronIDArray[i];
		pOutputSynapsePlasticityArray[i] += LearningRate * pUsedNeuronArray[receiverNeuronID].ErrorValue * NeuronOutput;

		//if (pOutputSynapsePlasticityArray[i] == 0.0f)
		//pOutputSynapsePlasticityArray[i] = 0.001f;
	}
}

void CNeuronV2::Adjust_Dendrite_CentroidValue_AfterErrorCalculations(int32_t centroidValueID, float learningRate)
{
	float tempValue = pDendrite_InputValueArray[centroidValueID] - pDendrite_CentroidValueArray[centroidValueID];
	pDendrite_CentroidValueArray[centroidValueID] += learningRate * ErrorValue * tempValue;

	//pDendrite_CentroidValueArray[centroidValueID] += learningRate * ErrorValue * pDendrite_InputValueArray[centroidValueID];
}

void CNeuronV2::Adjust_Dendrite_CentroidValue_AfterErrorCalculations_ExternalInput(int32_t centroidValueID, float learningRate)
{
	float tempValue = pDendrite_InputValueArray_OtherNeuron[centroidValueID] - pDendrite_CentroidValueArray[centroidValueID];
	pDendrite_CentroidValueArray[centroidValueID] += learningRate * ErrorValue * tempValue;

	//pDendrite_CentroidValueArray[centroidValueID] += learningRate * ErrorValue * pDendrite_InputValueArray_OtherNeuron[centroidValueID];
}

void CNeuronV2::Adjust_Dendrite_Factor_AfterErrorCalculations(int32_t factorID, float learningRate)
{
	pDendrite_FactorArray[factorID] += learningRate * ErrorValue * pDendrite_InputValueArray[factorID];
}

void CNeuronV2::Adjust_Dendrite_Factor_AfterErrorCalculations_ExternalInput(int32_t factorID, float learningRate)
{
	pDendrite_FactorArray[factorID] += learningRate * ErrorValue * pDendrite_InputValueArray_OtherNeuron[factorID];
}

float CNeuronV2::Adjust_Dendrite_CentroidValues(float desiredNeuronOutput, float learningRate, float errorFactor1, float errorFactor2)
{
	float outputError = Calculate_Error(desiredNeuronOutput, errorFactor1, errorFactor2);

	float tempValue;

	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		tempValue = pDendrite_InputValueArray[i] - pDendrite_CentroidValueArray[i];
		pDendrite_CentroidValueArray[i] += learningRate * ErrorValue * tempValue;

		//pDendrite_CentroidValueArray[i] += learningRate * ErrorValue * pDendrite_InputValueArray[i];
	}

	return outputError;
}

float CNeuronV2::Adjust_Dendrite_CentroidValues_ExternalInput(float desiredNeuronOutput, float learningRate, float errorFactor1, float errorFactor2)
{
	float outputError = Calculate_Error(desiredNeuronOutput, errorFactor1, errorFactor2);

	float tempValue;

	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		tempValue = pDendrite_InputValueArray_OtherNeuron[i] - pDendrite_CentroidValueArray[i];
		pDendrite_CentroidValueArray[i] += learningRate * ErrorValue * tempValue;
		//pDendrite_CentroidValueArray[i] += learningRate * ErrorValue * pDendrite_InputValueArray_OtherNeuron[i];
	}

	return outputError;
}

float CNeuronV2::Adjust_Dendrite_Factors(float desiredNeuronOutput, float learningRate, float errorFactor1, float errorFactor2)
{
	float outputError = Calculate_Error(desiredNeuronOutput, errorFactor1, errorFactor2);

	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		pDendrite_FactorArray[i] += learningRate * ErrorValue * pDendrite_InputValueArray[i];
	}

	return outputError;
}

float CNeuronV2::Adjust_Dendrite_Factors_ExternalInput(float desiredNeuronOutput, float learningRate, float errorFactor1, float errorFactor2)
{
	float outputError = Calculate_Error(desiredNeuronOutput, errorFactor1, errorFactor2);

	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		pDendrite_FactorArray[i] += learningRate * ErrorValue * pDendrite_InputValueArray_OtherNeuron[i];
	}

	return outputError;
}

float CNeuronV2::Adjust_Dendrite_CentroidValues(float desiredNeuronOutput, float learningRate, float errorFactor1, float errorFactor2, int32_t firstCentroidValueID, int32_t lastCentroidValueID)
{
	lastCentroidValueID++;

	float outputError = Calculate_Error(desiredNeuronOutput, errorFactor1, errorFactor2);

	float tempValue;

	for (int32_t i = firstCentroidValueID; i < lastCentroidValueID; i++)
	{
		tempValue = pDendrite_InputValueArray[i] - pDendrite_CentroidValueArray[i];
		pDendrite_CentroidValueArray[i] += learningRate * ErrorValue * tempValue;

		//pDendrite_CentroidValueArray[i] += learningRate * ErrorValue * pDendrite_InputValueArray[i];
	}

	return outputError;
}

float CNeuronV2::Adjust_Dendrite_CentroidValues_ExternalInput(float desiredNeuronOutput, float learningRate, float errorFactor1, float errorFactor2, int32_t firstCentroidValueID, int32_t lastCentroidValueID)
{
	lastCentroidValueID++;

	float outputError = Calculate_Error(desiredNeuronOutput, errorFactor1, errorFactor2);

	float tempValue;

	for (int32_t i = firstCentroidValueID; i < lastCentroidValueID; i++)
	{
		tempValue = pDendrite_InputValueArray_OtherNeuron[i] - pDendrite_CentroidValueArray[i];
		pDendrite_CentroidValueArray[i] += learningRate * ErrorValue * tempValue;

		//pDendrite_CentroidValueArray[i] += learningRate * ErrorValue * pDendrite_InputValueArray_OtherNeuron[i];
	}

	return outputError;
}

float CNeuronV2::Adjust_Dendrite_Factors(float desiredNeuronOutput, float learningRate, float errorFactor1, float errorFactor2, int32_t firstFactorID, int32_t lastFactorID)
{
	lastFactorID++;

	float outputError = Calculate_Error(desiredNeuronOutput, errorFactor1, errorFactor2);

	for (int32_t i = firstFactorID; i < lastFactorID; i++)
	{
		pDendrite_FactorArray[i] += learningRate * ErrorValue * pDendrite_InputValueArray[i];
	}

	return outputError;
}

float CNeuronV2::Adjust_Dendrite_Factors_ExternalInput(float desiredNeuronOutput, float learningRate, float errorFactor1, float errorFactor2, int32_t firstFactorID, int32_t lastFactorID)
{
	lastFactorID++;

	float outputError = Calculate_Error(desiredNeuronOutput, errorFactor1, errorFactor2);

	for (int32_t i = firstFactorID; i < lastFactorID; i++)
	{
		pDendrite_FactorArray[i] += learningRate * ErrorValue * pDendrite_InputValueArray_OtherNeuron[i];
	}

	return outputError;
}

void CNeuronV2::Adjust_Dendrite_CentroidValues_AfterErrorCalculations(float learningRate)
{
	float tempValue;

	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		tempValue = pDendrite_InputValueArray[i] - pDendrite_CentroidValueArray[i];
		pDendrite_CentroidValueArray[i] += learningRate * ErrorValue * tempValue;

		//pDendrite_CentroidValueArray[i] += learningRate * ErrorValue * pDendrite_InputValueArray[i];
	}
}

void CNeuronV2::Adjust_Dendrite_CentroidValues_AfterErrorCalculations_ExternalInput(float learningRate)
{
	float tempValue;

	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		tempValue = pDendrite_InputValueArray_OtherNeuron[i] - pDendrite_CentroidValueArray[i];
		pDendrite_CentroidValueArray[i] += learningRate * ErrorValue * tempValue;

		//pDendrite_CentroidValueArray[i] += learningRate * ErrorValue * pDendrite_InputValueArray_OtherNeuron[i];
	}
}

void CNeuronV2::Adjust_Dendrite_Factors_AfterErrorCalculations(float learningRate)
{
	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		pDendrite_FactorArray[i] += learningRate * ErrorValue * pDendrite_InputValueArray[i];
	}
}

void CNeuronV2::Adjust_Dendrite_Factors_AfterErrorCalculations_ExternalInput(float learningRate)
{
	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		pDendrite_FactorArray[i] += learningRate * ErrorValue * pDendrite_InputValueArray_OtherNeuron[i];
	}
}

void CNeuronV2::Adjust_Dendrite_CentroidValues_AfterErrorCalculations(float learningRate, int32_t firstCentroidValueID, int32_t lastCentroidValueID)
{
	lastCentroidValueID++;

	float tempValue;

	for (int32_t i = firstCentroidValueID; i < lastCentroidValueID; i++)
	{
		tempValue = pDendrite_InputValueArray[i] - pDendrite_CentroidValueArray[i];
		pDendrite_CentroidValueArray[i] += learningRate * ErrorValue * tempValue;
		//pDendrite_CentroidValueArray[i] += learningRate * ErrorValue * pDendrite_InputValueArray[i];
	}
}

void CNeuronV2::Adjust_Dendrite_CentroidValues_AfterErrorCalculations_ExternalInput(float learningRate, int32_t firstCentroidValueID, int32_t lastCentroidValueID)
{
	lastCentroidValueID++;

	float tempValue;

	for (int32_t i = firstCentroidValueID; i < lastCentroidValueID; i++)
	{
		tempValue = pDendrite_InputValueArray_OtherNeuron[i] - pDendrite_CentroidValueArray[i];
		pDendrite_CentroidValueArray[i] += learningRate * ErrorValue * tempValue;
		//pDendrite_CentroidValueArray[i] += learningRate * ErrorValue * pDendrite_InputValueArray_OtherNeuron[i];
	}
}

void CNeuronV2::Adjust_Dendrite_Factors_AfterErrorCalculations(float learningRate, int32_t firstFactorID, int32_t lastFactorID)
{
	lastFactorID++;

	for (int32_t i = firstFactorID; i < lastFactorID; i++)
	{
		pDendrite_FactorArray[i] += learningRate * ErrorValue * pDendrite_InputValueArray[i];
	}
}

void CNeuronV2::Adjust_Dendrite_Factors_AfterErrorCalculations_ExternalInput(float learningRate, int32_t firstFactorID, int32_t lastFactorID)
{
	lastFactorID++;

	for (int32_t i = firstFactorID; i < lastFactorID; i++)
	{
		pDendrite_FactorArray[i] += learningRate * ErrorValue * pDendrite_InputValueArray_OtherNeuron[i];
	}
}

void CNeuronV2::Adjust_OutputSynapses_AfterErrorCalculations(float learningRate)
{
	int32_t receiverNeuronID;

	for (int32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		receiverNeuronID = pReceiverNeuronIDArray[i];
		pOutputSynapsePlasticityArray[i] += learningRate * pUsedNeuronArray[receiverNeuronID].ErrorValue * NeuronOutput;

		//if (pOutputSynapsePlasticityArray[i] == 0.0f)
		//pOutputSynapsePlasticityArray[i] = 0.001f;
	}
}

void CNeuronV2::Adjust_OutputSynapse_AfterErrorCalculations(int32_t synapseID)
{
	int32_t receiverNeuronID = pReceiverNeuronIDArray[synapseID];
	pOutputSynapsePlasticityArray[synapseID] += LearningRate * pUsedNeuronArray[receiverNeuronID].ErrorValue * NeuronOutput;

	//if (pOutputSynapsePlasticityArray[synapseID] == 0.0f)
	//pOutputSynapsePlasticityArray[synapseID] = 0.001f;
}

void CNeuronV2::Adjust_OutputSynapse_AfterErrorCalculations(int32_t synapseID, float learningRate)
{
	int32_t receiverNeuronID = pReceiverNeuronIDArray[synapseID];
	pOutputSynapsePlasticityArray[synapseID] += learningRate * pUsedNeuronArray[receiverNeuronID].ErrorValue * NeuronOutput;

	//if (pOutputSynapsePlasticityArray[synapseID] == 0.0f)
	//pOutputSynapsePlasticityArray[synapseID] = 0.001f;
}

void CNeuronV2::Randomize_OutputSynapsePlasticities(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue)
{
	for (int32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		pOutputSynapsePlasticityArray[i] = pRandomNumbers->Get_FloatNumber(minValue, maxValue);
	}
}

void CNeuronV2::Randomize_OutputSynapsePlasticities(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float mutationRate)
{
	for (int32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
			continue;

		pOutputSynapsePlasticityArray[i] = pRandomNumbers->Get_FloatNumber(minValue, maxValue);
	}
}

void CNeuronV2::Modify_OutputSynapsePlasticities(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue)
{
	for (int32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		pOutputSynapsePlasticityArray[i] += pRandomNumbers->Get_FloatNumber(minValue, maxValue);
	}
}

void CNeuronV2::Modify_OutputSynapsePlasticities(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float mutationRate)
{
	for (int32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		if(pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
			continue;

		pOutputSynapsePlasticityArray[i] += pRandomNumbers->Get_FloatNumber(minValue, maxValue);
	}
}

void CNeuronV2::Randomize_Dendrite_CentroidValues(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue)
{
	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		pDendrite_CentroidValueArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minValue, maxValue);
	}
}

void CNeuronV2::Randomize_Dendrite_CentroidValues(CRandomNumbersNN *pRandomNumbers, int32_t minVectorElement, int32_t maxVectorElement, float minValue, float maxValue)
{
	maxVectorElement++;

	for (int32_t i = minVectorElement; i < maxVectorElement; i++)
	{
		pDendrite_CentroidValueArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minValue, maxValue);
	}
}

void CNeuronV2::Randomize_Dendrite_Factors(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue)
{
	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		pDendrite_FactorArray[i] = pRandomNumbers->Get_FloatNumber(minValue, maxValue);
	}
}

void CNeuronV2::Randomize_Dendrite_Factors(CRandomNumbersNN *pRandomNumbers, int32_t minVectorElement, int32_t maxVectorElement, float minValue, float maxValue)
{
	maxVectorElement++;

	for (int32_t i = minVectorElement; i < maxVectorElement; i++)
	{
		pDendrite_FactorArray[i] = pRandomNumbers->Get_FloatNumber(minValue, maxValue);
	}
}

void CNeuronV2::Modify_Dendrite_Factors(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue)
{
	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		pDendrite_FactorArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minValue, maxValue);
	}
}

void CNeuronV2::Modify_Dendrite_Factors(CRandomNumbersNN *pRandomNumbers, int32_t minVectorElement, int32_t maxVectorElement, float minValue, float maxValue)
{
	maxVectorElement++;

	for (int32_t i = minVectorElement; i < maxVectorElement; i++)
	{
		pDendrite_FactorArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minValue, maxValue);
	}
}

void CNeuronV2::Randomize_Dendrite_Factors(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float mutationRate)
{
	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
			continue;

		pDendrite_FactorArray[i] = pRandomNumbers->Get_FloatNumber(minValue, maxValue);
	}
}

void CNeuronV2::Randomize_Dendrite_Factors(CRandomNumbersNN *pRandomNumbers, int32_t minVectorElement, int32_t maxVectorElement, float minValue, float maxValue, float mutationRate)
{
	maxVectorElement++;

	for (int32_t i = minVectorElement; i < maxVectorElement; i++)
	{
		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
			continue;

		pDendrite_FactorArray[i] = pRandomNumbers->Get_FloatNumber(minValue, maxValue);
	}
}

void CNeuronV2::Modify_Dendrite_Factors(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float mutationRate)
{
	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
			continue;

		pDendrite_FactorArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minValue, maxValue);
	}
}

void CNeuronV2::Modify_Dendrite_Factors(CRandomNumbersNN *pRandomNumbers, int32_t minVectorElement, int32_t maxVectorElement, float minValue, float maxValue, float mutationRate)
{
	maxVectorElement++;

	for (int32_t i = minVectorElement; i < maxVectorElement; i++)
	{
		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
			continue;

		pDendrite_FactorArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minValue, maxValue);
	}
}

void CNeuronV2::Modify_Dendrite_CentroidValues(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue)
{
	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		if (minValue == maxValue && minValue != 0.0f)
		{
			if (pDendrite_CentroidValueArray[i] != 0.0f)
				pDendrite_CentroidValueArray[i] = 0.0f;
			else
				pDendrite_CentroidValueArray[i] = 1.0f;
		}
		else
			pDendrite_CentroidValueArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minValue, maxValue);
	}
}

void CNeuronV2::Modify_Dendrite_CentroidValues(CRandomNumbersNN *pRandomNumbers, int32_t minVectorElement, int32_t maxVectorElement, float minValue, float maxValue)
{
	maxVectorElement++;

	for (int32_t i = minVectorElement; i < maxVectorElement; i++)
	{
		if (minValue == maxValue && minValue != 0.0f)
		{
			if (pDendrite_CentroidValueArray[i] != 0.0f)
				pDendrite_CentroidValueArray[i] = 0.0f;
			else
				pDendrite_CentroidValueArray[i] = 1.0f;
		}
		else
			pDendrite_CentroidValueArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minValue, maxValue);
	}
}

void CNeuronV2::Randomize_Dendrite_CentroidValues(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float mutationRate)
{
	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
			continue;

		pDendrite_CentroidValueArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minValue, maxValue);
	}
}

void CNeuronV2::Randomize_Dendrite_CentroidValues(CRandomNumbersNN *pRandomNumbers, int32_t minVectorElement, int32_t maxVectorElement, float minValue, float maxValue, float mutationRate)
{
	maxVectorElement++;

	for (int32_t i = minVectorElement; i < maxVectorElement; i++)
	{
		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
			continue;

		pDendrite_CentroidValueArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minValue, maxValue);
	}
}

void CNeuronV2::Modify_Dendrite_CentroidValues(CRandomNumbersNN *pRandomNumbers, float minValue, float maxValue, float mutationRate)
{
	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
			continue;

		pDendrite_CentroidValueArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minValue, maxValue);
	}
}

void CNeuronV2::Modify_Dendrite_CentroidValues(CRandomNumbersNN *pRandomNumbers, int32_t minVectorElement, int32_t maxVectorElement, float minValue, float maxValue, float mutationRate)
{
	maxVectorElement++;

	for (int32_t i = minVectorElement; i < maxVectorElement; i++)
	{
		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
			continue;

		pDendrite_CentroidValueArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minValue, maxValue);
	}
}

void CNeuronV2::Randomize_Dendrite_Values(CRandomNumbersNN *pRandomNumbers, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor)
{
	if (minFactor != 0.0f || maxFactor != 0.0f)
	{
		for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
		{
			pDendrite_FactorArray[i] = pRandomNumbers->Get_FloatNumber(minFactor, maxFactor);
		}
	}

	if (minCentroidValue != 0.0f || maxCentroidValue != 0.0f)
	{
		for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
		{
			pDendrite_CentroidValueArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minCentroidValue, maxCentroidValue);
		}
	}

	/*if (minFactor == 0.0f)
	{
		for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
		{
			pDendrite_CentroidValueArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minCentroidValue, maxCentroidValue);
		}

		return;
	}
	else if (minCentroidValue == maxCentroidValue)
	{
		for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
		{
			pDendrite_FactorArray[i] = pRandomNumbers->Get_FloatNumber(minFactor, maxFactor);
		}

		return;
	}
	
	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		pDendrite_CentroidValueArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minCentroidValue, maxCentroidValue);
		pDendrite_FactorArray[i] = pRandomNumbers->Get_FloatNumber(minFactor, maxFactor);
	}*/
}

void CNeuronV2::Randomize_Dendrite_Values_WithNonZeroCentroids(CRandomNumbersNN *pRandomNumbers, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor)
{
	if (minFactor != 0.0f || maxFactor != 0.0f)
	{
		for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
		{
			pDendrite_FactorArray[i] = pRandomNumbers->Get_FloatNumber(minFactor, maxFactor);
		}
	}

	if (minCentroidValue != 0.0f || maxCentroidValue != 0.0f)
	{
		for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
		{
			pDendrite_CentroidValueArray[i] = pRandomNumbers->Get_FloatNumber(minCentroidValue, maxCentroidValue);
		}
	}

	/*if (minFactor == 0.0f)
	{
		for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
		{
			pDendrite_CentroidValueArray[i] = pRandomNumbers->Get_FloatNumber(minCentroidValue, maxCentroidValue);
		}

		return;
	}
	else if (minCentroidValue == maxCentroidValue)
	{
		for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
		{
			pDendrite_FactorArray[i] = pRandomNumbers->Get_FloatNumber(minFactor, maxFactor);
		}

		return;
	}

	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		pDendrite_CentroidValueArray[i] = pRandomNumbers->Get_FloatNumber(minCentroidValue, maxCentroidValue);
		pDendrite_FactorArray[i] = pRandomNumbers->Get_FloatNumber(minFactor, maxFactor);
	}*/
}

void CNeuronV2::Randomize_Dendrite_Values(CRandomNumbersNN *pRandomNumbers, int32_t minVectorElement, int32_t maxVectorElement, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor)
{
	maxVectorElement++;

	if (minFactor != 0.0f || maxFactor != 0.0f)
	{
		for (int32_t i = minVectorElement; i < maxVectorElement; i++)
		{
			pDendrite_FactorArray[i] = pRandomNumbers->Get_FloatNumber(minFactor, maxFactor);
		}
	}

	if (minCentroidValue != 0.0f || maxCentroidValue != 0.0f)
	{
		for (int32_t i = minVectorElement; i < maxVectorElement; i++)
		{
			pDendrite_CentroidValueArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minCentroidValue, maxCentroidValue);
		}
	}

	/*if (minFactor == 0.0f)
	{
		for (int32_t i = minVectorElement; i < maxVectorElement; i++)
		{
			pDendrite_CentroidValueArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minCentroidValue, maxCentroidValue);
		}

		return;
	}
	else if (minCentroidValue == maxCentroidValue)
	{
		for (int32_t i = minVectorElement; i < maxVectorElement; i++)
		{
			pDendrite_FactorArray[i] = pRandomNumbers->Get_FloatNumber(minFactor, maxFactor);
		}

		return;
	}

	for (int32_t i = minVectorElement; i < maxVectorElement; i++)
	{
		pDendrite_CentroidValueArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minCentroidValue, maxCentroidValue);
		pDendrite_FactorArray[i] = pRandomNumbers->Get_FloatNumber(minFactor, maxFactor);
	}*/
}

void CNeuronV2::Randomize_Dendrite_Values_WithNonZeroCentroids(CRandomNumbersNN *pRandomNumbers, int32_t minVectorElement, int32_t maxVectorElement, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor)
{
	maxVectorElement++;

	if (minFactor != 0.0f || maxFactor != 0.0f)
	{
		for (int32_t i = minVectorElement; i < maxVectorElement; i++)
		{
			pDendrite_FactorArray[i] = pRandomNumbers->Get_FloatNumber(minFactor, maxFactor);
		}
	}

	if (minCentroidValue != 0.0f || maxCentroidValue != 0.0f)
	{
		for (int32_t i = minVectorElement; i < maxVectorElement; i++)
		{
			pDendrite_CentroidValueArray[i] = pRandomNumbers->Get_FloatNumber(minCentroidValue, maxCentroidValue);
		}
	}

	/*if (minFactor == 0.0f)
	{
		for (int32_t i = minVectorElement; i < maxVectorElement; i++)
		{
			pDendrite_CentroidValueArray[i] = pRandomNumbers->Get_FloatNumber(minCentroidValue, maxCentroidValue);
		}

		return;
	}
	else if (minCentroidValue == maxCentroidValue)
	{
		for (int32_t i = minVectorElement; i < maxVectorElement; i++)
		{
			pDendrite_FactorArray[i] = pRandomNumbers->Get_FloatNumber(minFactor, maxFactor);
		}

		return;
	}

	for (int32_t i = minVectorElement; i < maxVectorElement; i++)
	{
		pDendrite_CentroidValueArray[i] = pRandomNumbers->Get_FloatNumber(minCentroidValue, maxCentroidValue);
		pDendrite_FactorArray[i] = pRandomNumbers->Get_FloatNumber(minFactor, maxFactor);
	}*/
}

void CNeuronV2::Randomize_Dendrite_Values(CRandomNumbersNN *pRandomNumbers, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor, float mutationRate)
{
	if (minFactor != 0.0f || maxFactor != 0.0f)
	{
		for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
		{
			if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pDendrite_FactorArray[i] = pRandomNumbers->Get_FloatNumber(minFactor, maxFactor);
		}
	}

	if (minCentroidValue != 0.0f || maxCentroidValue != 0.0f)
	{
		for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
		{
			if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pDendrite_CentroidValueArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minCentroidValue, maxCentroidValue);
		}
	}

	/*if (minFactor == 0.0f)
	{
		for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
		{
			if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pDendrite_CentroidValueArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minCentroidValue, maxCentroidValue);
		}

		return;
	}
	else if (minCentroidValue == maxCentroidValue)
	{
		for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
		{
			if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pDendrite_FactorArray[i] = pRandomNumbers->Get_FloatNumber(minFactor, maxFactor);
		}

		return;
	}

	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
			continue;

		pDendrite_CentroidValueArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minCentroidValue, maxCentroidValue);
		pDendrite_FactorArray[i] = pRandomNumbers->Get_FloatNumber(minFactor, maxFactor);
	}*/
}

void CNeuronV2::Randomize_Dendrite_Values_WithNonZeroCentroids(CRandomNumbersNN *pRandomNumbers, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor, float mutationRate)
{
	if (minFactor != 0.0f || maxFactor != 0.0f)
	{
		for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
		{
			if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pDendrite_FactorArray[i] = pRandomNumbers->Get_FloatNumber(minFactor, maxFactor);
		}
	}

	if (minCentroidValue != 0.0f || maxCentroidValue != 0.0f)
	{
		for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
		{
			if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pDendrite_CentroidValueArray[i] = pRandomNumbers->Get_FloatNumber(minCentroidValue, maxCentroidValue);
		}
	}

	/*if (minFactor == 0.0f)
	{
		for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
		{
			if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pDendrite_CentroidValueArray[i] = pRandomNumbers->Get_FloatNumber(minCentroidValue, maxCentroidValue);
		}

		return;
	}
	else if (minCentroidValue == maxCentroidValue)
	{
		for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
		{
			if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pDendrite_FactorArray[i] = pRandomNumbers->Get_FloatNumber(minFactor, maxFactor);
		}

		return;
	}

	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
			continue;

		pDendrite_CentroidValueArray[i] = pRandomNumbers->Get_FloatNumber(minCentroidValue, maxCentroidValue);
		pDendrite_FactorArray[i] = pRandomNumbers->Get_FloatNumber(minFactor, maxFactor);
	}*/
}

void CNeuronV2::Randomize_Dendrite_Values(CRandomNumbersNN *pRandomNumbers, int32_t minVectorElement, int32_t maxVectorElement, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor, float mutationRate)
{
	maxVectorElement++;

	if (minFactor != 0.0f || maxFactor != 0.0f)
	{
		for (int32_t i = minVectorElement; i < maxVectorElement; i++)
		{
			if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pDendrite_FactorArray[i] = pRandomNumbers->Get_FloatNumber(minFactor, maxFactor);
		}
	}

	if (minCentroidValue != 0.0f || maxCentroidValue != 0.0f)
	{
		for (int32_t i = minVectorElement; i < maxVectorElement; i++)
		{
			if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pDendrite_CentroidValueArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minCentroidValue, maxCentroidValue);
		}
	}

	/*if (minFactor == 0.0f)
	{
		for (int32_t i = minVectorElement; i < maxVectorElement; i++)
		{
			if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pDendrite_CentroidValueArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minCentroidValue, maxCentroidValue);
		}

		return;
	}
	else if (minCentroidValue == maxCentroidValue)
	{
		for (int32_t i = minVectorElement; i < maxVectorElement; i++)
		{
			if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pDendrite_FactorArray[i] = pRandomNumbers->Get_FloatNumber(minFactor, maxFactor);
		}

		return;
	}

	for (int32_t i = minVectorElement; i < maxVectorElement; i++)
	{
		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
			continue;

		pDendrite_CentroidValueArray[i] = pRandomNumbers->Get_FloatNumber_IncludingZero(minCentroidValue, maxCentroidValue);
		pDendrite_FactorArray[i] = pRandomNumbers->Get_FloatNumber(minFactor, maxFactor);
	}*/
}

void CNeuronV2::Randomize_Dendrite_Values_WithNonZeroCentroids(CRandomNumbersNN *pRandomNumbers, int32_t minVectorElement, int32_t maxVectorElement, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor, float mutationRate)
{
	maxVectorElement++;

	if (minFactor != 0.0f || maxFactor != 0.0f)
	{
		for (int32_t i = minVectorElement; i < maxVectorElement; i++)
		{
			if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pDendrite_FactorArray[i] = pRandomNumbers->Get_FloatNumber(minFactor, maxFactor);
		}
	}

	if (minCentroidValue != 0.0f || maxCentroidValue != 0.0f)
	{
		for (int32_t i = minVectorElement; i < maxVectorElement; i++)
		{
			if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pDendrite_CentroidValueArray[i] = pRandomNumbers->Get_FloatNumber(minCentroidValue, maxCentroidValue);
		}
	}

	/*if (minFactor == 0.0f)
	{
		for (int32_t i = minVectorElement; i < maxVectorElement; i++)
		{
			if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pDendrite_CentroidValueArray[i] = pRandomNumbers->Get_FloatNumber(minCentroidValue, maxCentroidValue);
		}

		return;
	}
	else if (minCentroidValue == maxCentroidValue)
	{
		for (int32_t i = minVectorElement; i < maxVectorElement; i++)
		{
			if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pDendrite_FactorArray[i] = pRandomNumbers->Get_FloatNumber(minFactor, maxFactor);
		}

		return;
	}

	for (int32_t i = minVectorElement; i < maxVectorElement; i++)
	{
		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
			continue;

		pDendrite_CentroidValueArray[i] = pRandomNumbers->Get_FloatNumber(minCentroidValue, maxCentroidValue);
		pDendrite_FactorArray[i] = pRandomNumbers->Get_FloatNumber(minFactor, maxFactor);
	}*/
}

void CNeuronV2::Modify_Dendrite_Values(CRandomNumbersNN *pRandomNumbers, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance)
{
	if (minFactorVariance != 0.0f || maxFactorVariance != 0.0f)
	{
		for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
		{
			pDendrite_FactorArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minFactorVariance, maxFactorVariance);
		}
	}

	if (minCentroidValueVariance == maxCentroidValueVariance && minCentroidValueVariance != 0.0f)
	{
		for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
		{
			if (pDendrite_CentroidValueArray[i] != 0.0f)
				pDendrite_CentroidValueArray[i] = 0.0f;
			else
				pDendrite_CentroidValueArray[i] = 1.0f;
		}
	}
	else if (minCentroidValueVariance != 0.0f || maxCentroidValueVariance != 0.0f)
	{
		for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
		{
			pDendrite_CentroidValueArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minCentroidValueVariance, maxCentroidValueVariance);
		}
	}

	/*if(minFactorVariance == 0.0f && maxFactorVariance == 0.0f)
	{
		for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
		{
			// test:
			if (minCentroidValueVariance == maxCentroidValueVariance && minCentroidValueVariance != 0.0f)
			{
				if (pDendrite_CentroidValueArray[i] != 0.0f)
					pDendrite_CentroidValueArray[i] = 0.0f;
				else
					pDendrite_CentroidValueArray[i] = 1.0f;
			}
			else
				pDendrite_CentroidValueArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minCentroidValueVariance, maxCentroidValueVariance);
		}

		return;
	}
	
	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		if (minCentroidValueVariance == maxCentroidValueVariance && minCentroidValueVariance != 0.0f)
		{
			if (pDendrite_CentroidValueArray[i] != 0.0f)
				pDendrite_CentroidValueArray[i] = 0.0f;
			else
				pDendrite_CentroidValueArray[i] = 1.0f;
		}
		else
			pDendrite_CentroidValueArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minCentroidValueVariance, maxCentroidValueVariance);

		pDendrite_FactorArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minFactorVariance, maxFactorVariance);
	}*/
}

void CNeuronV2::Modify_Dendrite_Values(CRandomNumbersNN *pRandomNumbers, int32_t minVectorElement, int32_t maxVectorElement, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance)
{
	maxVectorElement++;

	if (minFactorVariance != 0.0f || maxFactorVariance != 0.0f)
	{
		for (int32_t i = minVectorElement; i < maxVectorElement; i++)
		{
			pDendrite_FactorArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minFactorVariance, maxFactorVariance);
		}
	}

	if (minCentroidValueVariance == maxCentroidValueVariance && minCentroidValueVariance != 0.0f)
	{
		for (int32_t i = minVectorElement; i < maxVectorElement; i++)
		{
			if (pDendrite_CentroidValueArray[i] != 0.0f)
				pDendrite_CentroidValueArray[i] = 0.0f;
			else
				pDendrite_CentroidValueArray[i] = 1.0f;
		}
	}
	else if (minCentroidValueVariance != 0.0f || maxCentroidValueVariance != 0.0f)
	{
		for (int32_t i = minVectorElement; i < maxVectorElement; i++)
		{
			pDendrite_CentroidValueArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minCentroidValueVariance, maxCentroidValueVariance);
		}
	}

	/*if (minFactorVariance == 0.0f && maxFactorVariance == 0.0f)
	{
		for (int32_t i = minVectorElement; i < maxVectorElement; i++)
		{
			// test:
			if (minCentroidValueVariance == maxCentroidValueVariance && minCentroidValueVariance != 0.0f)
			{
				if (pDendrite_CentroidValueArray[i] != 0.0f)
					pDendrite_CentroidValueArray[i] = 0.0f;
				else
					pDendrite_CentroidValueArray[i] = 1.0f;
			}
			else
				pDendrite_CentroidValueArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minCentroidValueVariance, maxCentroidValueVariance);
		}

		return;
	}

	for (int32_t i = minVectorElement; i < maxVectorElement; i++)
	{
		if (minCentroidValueVariance == maxCentroidValueVariance && minCentroidValueVariance != 0.0f)
		{
			if (pDendrite_CentroidValueArray[i] != 0.0f)
				pDendrite_CentroidValueArray[i] = 0.0f;
			else
				pDendrite_CentroidValueArray[i] = 1.0f;
		}
		else
			pDendrite_CentroidValueArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minCentroidValueVariance, maxCentroidValueVariance);

		pDendrite_FactorArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minFactorVariance, maxFactorVariance);
	}*/
}

void CNeuronV2::Modify_Dendrite_Values(CRandomNumbersNN *pRandomNumbers, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance, float mutationRate)
{
	if (minFactorVariance != 0.0f || maxFactorVariance != 0.0f)
	{
		for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
		{
			if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pDendrite_FactorArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minFactorVariance, maxFactorVariance);
		}
	}

	if (minCentroidValueVariance == maxCentroidValueVariance && minCentroidValueVariance != 0.0f)
	{
		for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
		{
			if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			if (pDendrite_CentroidValueArray[i] != 0.0f)
				pDendrite_CentroidValueArray[i] = 0.0f;
			else
				pDendrite_CentroidValueArray[i] = 1.0f;
		}
	}
	else if (minCentroidValueVariance != 0.0f || maxCentroidValueVariance != 0.0f)
	{
		for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
		{
			if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pDendrite_CentroidValueArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minCentroidValueVariance, maxCentroidValueVariance);
		}
	}


	/*if (minFactorVariance == 0.0f && maxFactorVariance == 0.0f)
	{
		for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
		{
			if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			// test:
			if (minCentroidValueVariance == maxCentroidValueVariance && minCentroidValueVariance != 0.0f)
			{
				if (pDendrite_CentroidValueArray[i] != 0.0f)
					pDendrite_CentroidValueArray[i] = 0.0f;
				else
					pDendrite_CentroidValueArray[i] = 1.0f;
			}
			else
				pDendrite_CentroidValueArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minCentroidValueVariance, maxCentroidValueVariance);
		}

		return;
	}
	
	for (int32_t i = 0; i < Num_Of_Dendrite_Elements; i++)
	{
		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
			continue;

		if (minCentroidValueVariance == maxCentroidValueVariance && minCentroidValueVariance != 0.0f)
		{
			if (pDendrite_CentroidValueArray[i] != 0.0f)
				pDendrite_CentroidValueArray[i] = 0.0f;
			else
				pDendrite_CentroidValueArray[i] = 1.0f;
		}
		else
			pDendrite_CentroidValueArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minCentroidValueVariance, maxCentroidValueVariance);

		pDendrite_FactorArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minFactorVariance, maxFactorVariance);
	}*/
}

void CNeuronV2::Modify_Dendrite_Values(CRandomNumbersNN *pRandomNumbers, int32_t minVectorElement, int32_t maxVectorElement, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance, float mutationRate)
{
	maxVectorElement++;

	if (minFactorVariance != 0.0f || maxFactorVariance != 0.0f)
	{
		for (int32_t i = minVectorElement; i < maxVectorElement; i++)
		{
			if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pDendrite_FactorArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minFactorVariance, maxFactorVariance);
		}
	}

	if (minCentroidValueVariance == maxCentroidValueVariance && minCentroidValueVariance != 0.0f)
	{
		for (int32_t i = minVectorElement; i < maxVectorElement; i++)
		{
			if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			if (pDendrite_CentroidValueArray[i] != 0.0f)
				pDendrite_CentroidValueArray[i] = 0.0f;
			else
				pDendrite_CentroidValueArray[i] = 1.0f;
		}
	}
	else if (minCentroidValueVariance != 0.0f || maxCentroidValueVariance != 0.0f)
	{
		for (int32_t i = minVectorElement; i < maxVectorElement; i++)
		{
			if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			pDendrite_CentroidValueArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minCentroidValueVariance, maxCentroidValueVariance);
		}
	}

	/*if (minFactorVariance == 0.0f && maxFactorVariance == 0.0f)
	{
		for (int32_t i = minVectorElement; i < maxVectorElement; i++)
		{
			if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
				continue;

			// test:
			if (minCentroidValueVariance == maxCentroidValueVariance && minCentroidValueVariance != 0.0f)
			{
				if (pDendrite_CentroidValueArray[i] != 0.0f)
					pDendrite_CentroidValueArray[i] = 0.0f;
				else
					pDendrite_CentroidValueArray[i] = 1.0f;
			}
			else
				pDendrite_CentroidValueArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minCentroidValueVariance, maxCentroidValueVariance);
		}

		return;
	}

	for (int32_t i = minVectorElement; i < maxVectorElement; i++)
	{
		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > mutationRate)
			continue;

		if (minCentroidValueVariance == maxCentroidValueVariance && minCentroidValueVariance != 0.0f)
		{
			if (pDendrite_CentroidValueArray[i] != 0.0f)
				pDendrite_CentroidValueArray[i] = 0.0f;
			else
				pDendrite_CentroidValueArray[i] = 1.0f;
		}
		else
			pDendrite_CentroidValueArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minCentroidValueVariance, maxCentroidValueVariance);

		pDendrite_FactorArray[i] += pRandomNumbers->Get_FloatNumber_IncludingZero(minFactorVariance, maxFactorVariance);
	}*/
}

void CNeuronV2::Disable_Random_OutputSynapses(CRandomNumbersNN *pRandomNumbers, float probabilityValue)
{
	for (int32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > probabilityValue)
			continue;

		pOutputSynapseActivityStatusArray[i] = false;
	}
}

void CNeuronV2::Random_Enable_Disabled_OutputSynapses(CRandomNumbersNN *pRandomNumbers, float probabilityValue)
{
	for (int32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		if (pRandomNumbers->Get_FloatNumber(0.0f, 1.0f) > probabilityValue)
			continue;

		pOutputSynapseActivityStatusArray[i] = true;
	}
}

void CNeuronV2::Enable_Disabled_OutputSynapses(void)
{
	for (int32_t i = 0; i < NumOfOutputSynapses; i++)
	{
		pOutputSynapseActivityStatusArray[i] = true;
	}
}

CNeuronEnsembleV2::CNeuronEnsembleV2()
{}

CNeuronEnsembleV2::~CNeuronEnsembleV2()
{
	delete[] ppNeuronArray;
	ppNeuronArray = nullptr;

	delete[] pModifiedOutputArray;
	pModifiedOutputArray = nullptr;
}

void CNeuronEnsembleV2::Set_NumOfNeurons(int32_t numOfNeurons)
{
	if (numOfNeurons > NumOfNeurons)
	{
		delete[] ppNeuronArray;
		ppNeuronArray = nullptr;

		delete[] pModifiedOutputArray;
		pModifiedOutputArray = nullptr;

		ppNeuronArray = new (std::nothrow) CNeuronV2*[numOfNeurons];
		pModifiedOutputArray = new (std::nothrow) float[numOfNeurons];
	}

	NumOfNeurons = numOfNeurons;

	
	for (int32_t i = 0; i < NumOfNeurons; i++)
	{
		ppNeuronArray[i] = nullptr;
		pModifiedOutputArray[i] = 0.0f;
	}
}

void CNeuronEnsembleV2::Set_Neuron(CNeuronV2 *pNeuron, int32_t neuronId)
{
	ppNeuronArray[neuronId] = pNeuron;
}

float CNeuronEnsembleV2::Get_NeuronOutput(int32_t neuronId)
{
	if (ppNeuronArray[neuronId] == nullptr)
		return 0.0f;

	return ppNeuronArray[neuronId]->NeuronOutput;
}

float CNeuronEnsembleV2::Get_NeuronOutputSum(float minValue, float maxValue)
{
	float sum = 0.0f;

	for (int32_t i = 0; i < NumOfNeurons; i++)
	{
		if (ppNeuronArray[i] != nullptr)
			sum += ppNeuronArray[i]->NeuronOutput;
	}

	sum = min(sum, maxValue);
	sum = max(sum, minValue);

	return sum;
}

void CNeuronEnsembleV2::Get_NeuronOutputValues(float *pOutValueArray)
{
	for (int32_t i = 0; i < NumOfNeurons; i++)
	{
		pOutValueArray[i] = 0.0f;

		if (ppNeuronArray[i] != nullptr)
			pOutValueArray[i] = ppNeuronArray[i]->NeuronOutput;
	}
}


float CNeuronEnsembleV2::Get_ModifiedNeuronOutput(int32_t neuronId)
{
	if (ppNeuronArray[neuronId] == nullptr)
		return 0.0f;

	return pModifiedOutputArray[neuronId];
}

void CNeuronEnsembleV2::Get_ModifiedNeuronOutputValues(float *pOutValueArray)
{
	for (int32_t i = 0; i < NumOfNeurons; i++)
	{
		pOutValueArray[i] = pModifiedOutputArray[i];
	}
}

void CNeuronEnsembleV2::Calculate_SoftmaxValues(void)
{
	for (int32_t i = 0; i < NumOfNeurons; i++)
		pModifiedOutputArray[i] = 0.0f;

	int32_t counter = 0;

	for (int32_t i = 0; i < NumOfNeurons; i++)
	{
		
		if (ppNeuronArray[i] != nullptr)
		{
			pModifiedOutputArray[counter] = ppNeuronArray[i]->NeuronOutput;
			counter++;
		}
	}

	SoftMax(pModifiedOutputArray, pModifiedOutputArray, counter);
}

void CNeuronEnsembleV2::Calculate_ProbabilityValues(void)
{
	for (int32_t i = 0; i < NumOfNeurons; i++)
		pModifiedOutputArray[i] = 0.0f;

	float sum = 0.00001f;

	for (int32_t i = 0; i < NumOfNeurons; i++)
	{
		if (ppNeuronArray[i] == nullptr)
			continue;

		sum += ppNeuronArray[i]->NeuronOutput;
	}

	float invSum = 1.0f / sum;

	for (int32_t i = 0; i < NumOfNeurons; i++)
	{
		if (ppNeuronArray[i] == nullptr)
			continue;

		pModifiedOutputArray[i] = ppNeuronArray[i]->NeuronOutput * invSum;
	}
}

void CNeuronEnsembleV2::Calculate_NormalizedOutputValues(void)
{
	for (int32_t i = 0; i < NumOfNeurons; i++)
		pModifiedOutputArray[i] = 0.0f;

	float tempFloat;
	float sum = 0.00001f;

	for (int32_t i = 0; i < NumOfNeurons; i++)
	{
		if (ppNeuronArray[i] == nullptr)
			continue;

		tempFloat = ppNeuronArray[i]->NeuronOutput;
		tempFloat *= tempFloat;
		sum += tempFloat;
	}

	float invSum = 1.0f / sqrt(sum);

	for (int32_t i = 0; i < NumOfNeurons; i++)
	{
		if (ppNeuronArray[i] == nullptr)
			continue;

		pModifiedOutputArray[i] = ppNeuronArray[i]->NeuronOutput * invSum;
	}
}

int32_t CNeuronEnsembleV2::Get_LastCalculatedID(void)
{
	return LastCalculatedID;
}

int32_t CNeuronEnsembleV2::Get_ID_Of_NeuronWithMaxOutput(void)
{
	int32_t id = 0;
	float maxOutput = -10000000.0f;

	for (int32_t i = 0; i < NumOfNeurons; i++)
	{
		if (ppNeuronArray[i] == nullptr)
			continue;

		if (ppNeuronArray[i]->NeuronOutput > maxOutput)
		{
			maxOutput = ppNeuronArray[i]->NeuronOutput;
			id = i;
		}
	}

	LastCalculatedID = id;
	return id;
}

int32_t CNeuronEnsembleV2::Get_ID_Of_NeuronWithMinOutput(void)
{
	int32_t id = 0;
	float minOutput = 10000000.0f;

	for (int32_t i = 0; i < NumOfNeurons; i++)
	{
		if (ppNeuronArray[i] == nullptr)
			continue;

		if (ppNeuronArray[i]->NeuronOutput < minOutput)
		{
			minOutput = ppNeuronArray[i]->NeuronOutput;
			id = i;
		}
	}

	LastCalculatedID = id;
	return id;
}

void CNeuronEnsembleV2::Get_ID_And_Output_Of_NeuronWithMaxOutput(int32_t *pOutNeuronID, float *pOutNeuronOutput)
{
	int32_t id = 0;
	float maxOutput = -10000000.0f;

	for (int32_t i = 0; i < NumOfNeurons; i++)
	{
		if (ppNeuronArray[i] == nullptr)
			continue;

		if (ppNeuronArray[i]->NeuronOutput > maxOutput)
		{
			maxOutput = ppNeuronArray[i]->NeuronOutput;
			id = i;
		}
	}

	LastCalculatedID = id;
	*pOutNeuronID = id;
	*pOutNeuronOutput = maxOutput;
}



void CNeuronEnsembleV2::Get_ID_And_Output_Of_NeuronWithMinOutput(int32_t *pOutNeuronID, float *pOutNeuronOutput)
{
	int32_t id = 0;
	float minOutput = 10000000.0f;

	for (int32_t i = 0; i < NumOfNeurons; i++)
	{
		if (ppNeuronArray[i] == nullptr)
			continue;

		if (ppNeuronArray[i]->NeuronOutput < minOutput)
		{
			minOutput = ppNeuronArray[i]->NeuronOutput;
			id = i;
		}
	}

	LastCalculatedID = id;
	*pOutNeuronID = id;
	*pOutNeuronOutput = minOutput;
}

void CNeuronEnsembleV2::Use_OtherNeuron_Dendrite_InputValueArray(int32_t idDestinationNeuron, int32_t idSourceNeuron)
{
	ppNeuronArray[idDestinationNeuron]->Use_OtherNeuron_Dendrite_InputValueArray(ppNeuronArray[idSourceNeuron]->pDendrite_InputValueArray);
}

void CNeuronEnsembleV2::Use_OtherNeuron_Dendrite_CentroidValueArray(int32_t idDestinationNeuron, int32_t idSourceNeuron)
{
	ppNeuronArray[idDestinationNeuron]->Use_OtherNeuron_Dendrite_CentroidValueArray(ppNeuronArray[idSourceNeuron]->pDendrite_CentroidValueArray);
}

void CNeuronEnsembleV2::Use_OtherNeuron_Dendrite_FactorArray(int32_t idDestinationNeuron, int32_t idSourceNeuron)
{
	ppNeuronArray[idDestinationNeuron]->Use_OtherNeuron_Dendrite_FactorArray(ppNeuronArray[idSourceNeuron]->pDendrite_FactorArray);
}


CNeuralNetV2::CNeuralNetV2()
{}

CNeuralNetV2::~CNeuralNetV2()
{
	delete[] pNeuronArray;
	pNeuronArray = nullptr;

	delete[] pDendriteNeuronIDArray;
	pDendriteNeuronIDArray = nullptr;
}

void CNeuralNetV2::Change_Seed(uint64_t newSeed)
{
	RandomNumbers.Change_Seed(newSeed);
}



void CNeuralNetV2::Clone(const CNeuralNetV2 *pOriginalObject)
{
	if (NumOfNeurons < pOriginalObject->NumOfNeurons)
	{
		delete[] pNeuronArray;
		pNeuronArray = nullptr;

		pNeuronArray = new (std::nothrow) CNeuronV2[pOriginalObject->NumOfNeurons];

		for (int32_t i = 0; i < pOriginalObject->NumOfNeurons; i++)
			pNeuronArray[i].Connect_With_Brain(pNeuronArray);
	}

	NumOfNeurons = pOriginalObject->NumOfNeurons;
	NumOfInputValues = pOriginalObject->NumOfInputValues;
	NumOfOutputValues = pOriginalObject->NumOfOutputValues;
	IdOfFirstInputNeuron = pOriginalObject->IdOfFirstInputNeuron;

	pUsedActivationSequence = pOriginalObject->pUsedActivationSequence;
	pUsedActivationSequence_LastHiddenLayer = pOriginalObject->pUsedActivationSequence_LastHiddenLayer;

	for (int32_t i = 0; i < NumOfNeurons; i++)
		pNeuronArray[i].Clone(&pOriginalObject->pNeuronArray[i]);

	if (NumOfDendriteNeurons < pOriginalObject->NumOfDendriteNeurons)
	{
		delete[] pDendriteNeuronIDArray;
		pDendriteNeuronIDArray = nullptr;

		pDendriteNeuronIDArray = new (std::nothrow) int32_t[pOriginalObject->NumOfDendriteNeurons];
	}

	NumOfDendriteNeurons = pOriginalObject->NumOfDendriteNeurons;

	for (int32_t i = 0; i < NumOfDendriteNeurons; i++)
		pDendriteNeuronIDArray[i] = pOriginalObject->pDendriteNeuronIDArray[i];

}

void CNeuralNetV2::Clone_Data(const CNeuralNetV2 *pOriginalObject)
{
	NumOfNeurons = pOriginalObject->NumOfNeurons;
	NumOfInputValues = pOriginalObject->NumOfInputValues;
	NumOfOutputValues = pOriginalObject->NumOfOutputValues;
	IdOfFirstInputNeuron = pOriginalObject->IdOfFirstInputNeuron;

	pUsedActivationSequence = pOriginalObject->pUsedActivationSequence;
	pUsedActivationSequence_LastHiddenLayer = pOriginalObject->pUsedActivationSequence_LastHiddenLayer;

	for (int32_t i = 0; i < NumOfNeurons; i++)
		pNeuronArray[i].Clone_Data(&pOriginalObject->pNeuronArray[i]);

	NumOfDendriteNeurons = pOriginalObject->NumOfDendriteNeurons;

	for (int32_t i = 0; i < NumOfDendriteNeurons; i++)
		pDendriteNeuronIDArray[i] = pOriginalObject->pDendriteNeuronIDArray[i];
}

void CNeuralNetV2::Clone_OutputSynapsePlasticities(const CNeuralNetV2 *pOriginalObject, int32_t firstNeuronID, int32_t lastNeuronID)
{
	if (firstNeuronID < 0)
	{
		for (int32_t i = 0; i < NumOfNeurons; i++)
		{
			int32_t numOfOutputSynapses = pNeuronArray[i].NumOfOutputSynapses;

			for (int32_t j = 0; j < numOfOutputSynapses; j++)
			{
				pNeuronArray[i].pOutputSynapseActivityStatusArray[j] = pOriginalObject->pNeuronArray[i].pOutputSynapseActivityStatusArray[j];
				pNeuronArray[i].pOutputSynapsePlasticityArray[j] = pOriginalObject->pNeuronArray[i].pOutputSynapsePlasticityArray[j];
			}
		}
	}
	else
	{
		for (int32_t i = firstNeuronID; i <= lastNeuronID; i++)
		{
			int32_t numOfOutputSynapses = pNeuronArray[i].NumOfOutputSynapses;

			for (int32_t j = 0; j < numOfOutputSynapses; j++)
			{
				pNeuronArray[i].pOutputSynapseActivityStatusArray[j] = pOriginalObject->pNeuronArray[i].pOutputSynapseActivityStatusArray[j];
				pNeuronArray[i].pOutputSynapsePlasticityArray[j] = pOriginalObject->pNeuronArray[i].pOutputSynapsePlasticityArray[j];
			}
		}
	}
}

void CNeuralNetV2::Combine_OutputSynapsePlasticities(const CNeuralNetV2 *pParentObject1, const CNeuralNetV2 *pParentObject2, float weightFactorParent1, int32_t firstNeuronID, int32_t lastNeuronID)
{
	if (firstNeuronID < 0)
	{
		for (int32_t i = 0; i < NumOfNeurons; i++)
			pNeuronArray[i].Combine_Synaptic_Data(&RandomNumbers, &pParentObject1->pNeuronArray[i], &pParentObject2->pNeuronArray[i], weightFactorParent1);
	}
	else
	{
		for (int32_t i = firstNeuronID; i <= lastNeuronID; i++)
			pNeuronArray[i].Combine_Synaptic_Data(&RandomNumbers, &pParentObject1->pNeuronArray[i], &pParentObject2->pNeuronArray[i], weightFactorParent1);
	}
}

void CNeuralNetV2::Combine_OutputSynapsePlasticities(const CNeuralNetV2 *pParentObject1, const CNeuralNetV2 *pParentObject2, pRecombinationFunc pFunc, void *pParam, int32_t firstNeuronID, int32_t lastNeuronID)
{
	if (firstNeuronID < 0)
	{
		for (int32_t i = 0; i < NumOfNeurons; i++)
			pFunc(&pNeuronArray[i], &pParentObject1->pNeuronArray[i], &pParentObject2->pNeuronArray[i], &RandomNumbers, pParam);
	}
	else
	{
		for (int32_t i = firstNeuronID; i <= lastNeuronID; i++)
			pFunc(&pNeuronArray[i], &pParentObject1->pNeuronArray[i], &pParentObject2->pNeuronArray[i], &RandomNumbers, pParam);
	}

	
}

void CNeuralNetV2::Combine_OutputSynapsePlasticities(uint64_t newSeed, const CNeuralNetV2 *pParentObject1, const CNeuralNetV2 *pParentObject2, pRecombinationFunc pFunc, void *pParam, int32_t firstNeuronID, int32_t lastNeuronID)
{
	RandomNumbers.Change_Seed(newSeed);

	if (firstNeuronID < 0)
	{
		for (int32_t i = 0; i < NumOfNeurons; i++)
			pFunc(&pNeuronArray[i], &pParentObject1->pNeuronArray[i], &pParentObject2->pNeuronArray[i], &RandomNumbers, pParam);
	}
	else
	{
		for (int32_t i = firstNeuronID; i <= lastNeuronID; i++)
			pFunc(&pNeuronArray[i], &pParentObject1->pNeuronArray[i], &pParentObject2->pNeuronArray[i], &RandomNumbers, pParam);
	}


}

void CNeuralNetV2::Combine_OutputSynapsePlasticities(uint64_t newSeed, const CNeuralNetV2 *pParentObject1, const CNeuralNetV2 *pParentObject2, float weightFactorParent1, int32_t firstNeuronID, int32_t lastNeuronID)
{
	RandomNumbers.Change_Seed(newSeed);

	if (firstNeuronID < 0)
	{
		for (int32_t i = 0; i < NumOfNeurons; i++)
			pNeuronArray[i].Combine_Synaptic_Data(&RandomNumbers, &pParentObject1->pNeuronArray[i], &pParentObject2->pNeuronArray[i], weightFactorParent1);
	}
	else
	{
		for (int32_t i = firstNeuronID; i <= lastNeuronID; i++)
			pNeuronArray[i].Combine_Synaptic_Data(&RandomNumbers, &pParentObject1->pNeuronArray[i], &pParentObject2->pNeuronArray[i], weightFactorParent1);
	}
}

void CNeuralNetV2::Combine_OutputSynapsePlasticities_RandomWeighted(const CNeuralNetV2 *pParentObject1, const CNeuralNetV2 *pParentObject2, int32_t firstNeuronID, int32_t lastNeuronID)
{
	if (firstNeuronID < 0)
	{
		for (int32_t i = 0; i < NumOfNeurons; i++)
			pNeuronArray[i].Combine_Synaptic_Data_RandomWeighted(&RandomNumbers, &pParentObject1->pNeuronArray[i], &pParentObject2->pNeuronArray[i]);
	}
	else
	{
		for (int32_t i = firstNeuronID; i <= lastNeuronID; i++)
			pNeuronArray[i].Combine_Synaptic_Data_RandomWeighted(&RandomNumbers, &pParentObject1->pNeuronArray[i], &pParentObject2->pNeuronArray[i]);
	}
}

void CNeuralNetV2::Combine_OutputSynapsePlasticities_RandomWeighted(const CNeuralNetV2 *pParentObject1, const CNeuralNetV2 *pParentObject2, float minParent1Weight, float maxParent1Weight, int32_t firstNeuronID, int32_t lastNeuronID)
{
	if (firstNeuronID < 0)
	{
		for (int32_t i = 0; i < NumOfNeurons; i++)
			pNeuronArray[i].Combine_Synaptic_Data_RandomWeighted(&RandomNumbers, &pParentObject1->pNeuronArray[i], &pParentObject2->pNeuronArray[i], minParent1Weight, maxParent1Weight);
	}
	else
	{
		for (int32_t i = firstNeuronID; i <= lastNeuronID; i++)
			pNeuronArray[i].Combine_Synaptic_Data_RandomWeighted(&RandomNumbers, &pParentObject1->pNeuronArray[i], &pParentObject2->pNeuronArray[i], minParent1Weight, maxParent1Weight);
	}
}

void CNeuralNetV2::Combine_OutputSynapsePlasticities_RandomWeighted(uint64_t newSeed, const CNeuralNetV2 *pParentObject1, const CNeuralNetV2 *pParentObject2, int32_t firstNeuronID, int32_t lastNeuronID)
{
	RandomNumbers.Change_Seed(newSeed);

	if (firstNeuronID < 0)
	{
		for (int32_t i = 0; i < NumOfNeurons; i++)
			pNeuronArray[i].Combine_Synaptic_Data_RandomWeighted(&RandomNumbers, &pParentObject1->pNeuronArray[i], &pParentObject2->pNeuronArray[i]);
	}
	else
	{
		for (int32_t i = firstNeuronID; i <= lastNeuronID; i++)
			pNeuronArray[i].Combine_Synaptic_Data_RandomWeighted(&RandomNumbers, &pParentObject1->pNeuronArray[i], &pParentObject2->pNeuronArray[i]);
	}
}

void CNeuralNetV2::Combine_OutputSynapsePlasticities_RandomWeighted(uint64_t newSeed, const CNeuralNetV2 *pParentObject1, const CNeuralNetV2 *pParentObject2, float minParent1Weight, float maxParent1Weight, int32_t firstNeuronID, int32_t lastNeuronID)
{
	RandomNumbers.Change_Seed(newSeed);

	if (firstNeuronID < 0)
	{
		for (int32_t i = 0; i < NumOfNeurons; i++)
			pNeuronArray[i].Combine_Synaptic_Data_RandomWeighted(&RandomNumbers, &pParentObject1->pNeuronArray[i], &pParentObject2->pNeuronArray[i], minParent1Weight, maxParent1Weight);
	}
	else
	{
		for (int32_t i = firstNeuronID; i <= lastNeuronID; i++)
			pNeuronArray[i].Combine_Synaptic_Data_RandomWeighted(&RandomNumbers, &pParentObject1->pNeuronArray[i], &pParentObject2->pNeuronArray[i], minParent1Weight, maxParent1Weight);
	}
}

void CNeuralNetV2::Disable_Random_OutputSynapses(int32_t firstNeuronID, int32_t lastNeuronID, float probabilityValue)
{
	for (uint32_t i = firstNeuronID; i <= lastNeuronID; i++)
		pNeuronArray[i].Disable_Random_OutputSynapses(&RandomNumbers, probabilityValue);
}

void CNeuralNetV2::Random_Enable_Disabled_OutputSynapses(int32_t firstNeuronID, int32_t lastNeuronID, float probabilityValue)
{
	for (uint32_t i = firstNeuronID; i <= lastNeuronID; i++)
		pNeuronArray[i].Random_Enable_Disabled_OutputSynapses(&RandomNumbers, probabilityValue);
}

void CNeuralNetV2::Disable_Random_OutputSynapses(uint64_t newSeed, int32_t firstNeuronID, int32_t lastNeuronID, float probabilityValue)
{
	RandomNumbers.Change_Seed(newSeed);

	for (uint32_t i = firstNeuronID; i <= lastNeuronID; i++)
		pNeuronArray[i].Disable_Random_OutputSynapses(&RandomNumbers, probabilityValue);
}

void CNeuralNetV2::Random_Enable_Disabled_OutputSynapses(uint64_t newSeed, int32_t firstNeuronID, int32_t lastNeuronID, float probabilityValue)
{
	RandomNumbers.Change_Seed(newSeed);

	for (uint32_t i = firstNeuronID; i <= lastNeuronID; i++)
		pNeuronArray[i].Random_Enable_Disabled_OutputSynapses(&RandomNumbers, probabilityValue);
}

void CNeuralNetV2::Enable_Disabled_OutputSynapses(int32_t firstNeuronID, int32_t lastNeuronID)
{
	for (uint32_t i = firstNeuronID; i <= lastNeuronID; i++)
		pNeuronArray[i].Enable_Disabled_OutputSynapses();
}

void CNeuralNetV2::Set_DendriteNeuronID(int32_t neuronID, int32_t arrayPos)
{
	pDendriteNeuronIDArray[arrayPos] = neuronID;
}

void CNeuralNetV2::Set_DendriteNeuronID_And_Init_RBF_Arrays(int32_t neuronID, int32_t arrayPos, int32_t num_Of_Dendrite_Elements)
{
	pDendriteNeuronIDArray[arrayPos] = neuronID;
	pNeuronArray[neuronID].Init_Dendrite_Arrays(num_Of_Dendrite_Elements);
}

void CNeuralNetV2::Set_DendriteNeuronIDs(int32_t *pNeuronIDArray)
{
	for (int32_t i = 0; i < NumOfDendriteNeurons; i++)
		pDendriteNeuronIDArray[i] = pNeuronIDArray[i];
}

void CNeuralNetV2::Set_DendriteNeuronIDs_And_Init_Dendrite_Arrays(int32_t *pNeuronIDArray, int32_t num_Of_Dendrite_Elements)
{
	for (int32_t i = 0; i < NumOfDendriteNeurons; i++)
	{
		pDendriteNeuronIDArray[i] = pNeuronIDArray[i];
		pNeuronArray[pNeuronIDArray[i]].Init_Dendrite_Arrays(num_Of_Dendrite_Elements);
	}
}

void CNeuralNetV2::Init_DendriteNeuronIDArray(int32_t numOfDendriteNeurons)
{
	if(NumOfDendriteNeurons < numOfDendriteNeurons)
	{
		delete[] pDendriteNeuronIDArray;
		pDendriteNeuronIDArray = nullptr;

		pDendriteNeuronIDArray = new (std::nothrow) int32_t[numOfDendriteNeurons];

		for (int32_t i = 0; i < numOfDendriteNeurons; i++)
			pDendriteNeuronIDArray[i] = -1;
	}

	NumOfDendriteNeurons = numOfDendriteNeurons;
}

void CNeuralNetV2::Init_NeuralNet(int32_t numOfNeurons)
{
	if (NumOfNeurons < numOfNeurons)
	{
		delete[] pNeuronArray;
		pNeuronArray = nullptr;

		pNeuronArray = new (std::nothrow) CNeuronV2[numOfNeurons];

		for (int32_t i = 0; i < numOfNeurons; i++)
			pNeuronArray[i].Connect_With_Brain(pNeuronArray);
	}

	NumOfNeurons = numOfNeurons;
}

void CNeuralNetV2::Set_NumOfInputValues(int32_t number)
{
	NumOfInputValues = number;
}

void CNeuralNetV2::Set_NumOfOutputValues(int32_t number)
{
	NumOfOutputValues = number;
	IdOfFirstInputNeuron = number;
}

void CNeuralNetV2::Set_InputNeuron_LearningRate(float learningRate)
{
	for (int32_t i = 0; i < NumOfInputValues; i++)
		pNeuronArray[i + IdOfFirstInputNeuron].Set_LearningRate(learningRate);
}

void CNeuralNetV2::Set_InputNeuron_SynapticFunction(pSynapticFuncV2 pFunc)
{
	for (int32_t i = 0; i < NumOfInputValues; i++)
		pNeuronArray[i + IdOfFirstInputNeuron].Set_SynapticFunction(pFunc);
}

void CNeuralNetV2::Set_ActivationFunction(int32_t firstNeuronID, int32_t lastNeuronID, pActivationFuncV2 pFunc)
{
	for (int32_t i = firstNeuronID; i <= lastNeuronID; i++)
		pNeuronArray[i].Set_ActivationFunction(pFunc);
}

void CNeuralNetV2::Set_SynapticFunction(int32_t firstNeuronID, int32_t lastNeuronID, pSynapticFuncV2 pFunc)
{
	for (int32_t i = firstNeuronID; i <= lastNeuronID; i++)
		pNeuronArray[i].Set_SynapticFunction(pFunc);
}

void CNeuralNetV2::Set_LearningRate(int32_t firstNeuronID, int32_t lastNeuronID, float learningRate)
{
	for (int32_t i = firstNeuronID; i <= lastNeuronID; i++)
		pNeuronArray[i].Set_LearningRate(learningRate);
}

void CNeuralNetV2::Set_ErrorFactors(int32_t firstNeuronID, int32_t lastNeuronID, float factor1, float factor2)
{
	for (int32_t i = firstNeuronID; i <= lastNeuronID; i++)
		pNeuronArray[i].Set_ErrorFactors(factor1, factor2);
}

void CNeuralNetV2::Set_OutputNeuron_ActivationFunction(pActivationFuncV2 pFunc)
{
	for (int32_t i = 0; i < NumOfOutputValues; i++)
		pNeuronArray[i].Set_ActivationFunction(pFunc);
}

void CNeuralNetV2::Set_OutputNeuron_ErrorFactors(float factor1, float factor2)
{
	for (int32_t i = 0; i < NumOfOutputValues; i++)
		pNeuronArray[i].Set_ErrorFactors(factor1, factor2);
}

void CNeuralNetV2::Use_As_BiasNeuron(int32_t neuronID, bool status)
{
	pNeuronArray[neuronID].Use_As_BiasNeuron(status);
}

void CNeuralNetV2::Init_OutputSynapses(int32_t neuronID, const CNeuralConnections *pNeuralConnections)
{
	pNeuronArray[neuronID].Init_OutputSynapses(pNeuralConnections);
}

void CNeuralNetV2::Init_OutputSynapses(int32_t firstNeuronID, int32_t lastNeuronID, const CNeuralConnections *pNeuralConnections)
{
	for (int32_t i = firstNeuronID; i <= lastNeuronID; i++)
	{
		pNeuronArray[i].Init_OutputSynapses(pNeuralConnections);
	}
}

void CNeuralNetV2::Init_OutputSynapses(int32_t neuronID, CNeuralConnections *pNeuralConnections, float minSynapticPlasticity, float maxSynapticPlasticity)
{
	pNeuralConnections->Randomize_SynapticPlasticities(&RandomNumbers, minSynapticPlasticity, maxSynapticPlasticity);
	pNeuronArray[neuronID].Init_OutputSynapses(pNeuralConnections);
}

void CNeuralNetV2::Init_OutputSynapses(int32_t firstNeuronID, int32_t lastNeuronID, CNeuralConnections *pNeuralConnections, float minSynapticPlasticity, float maxSynapticPlasticity)
{
	for (int32_t i = firstNeuronID; i <= lastNeuronID; i++)
	{
		pNeuralConnections->Randomize_SynapticPlasticities(&RandomNumbers, minSynapticPlasticity, maxSynapticPlasticity);
		pNeuronArray[i].Init_OutputSynapses(pNeuralConnections);
	}
}

void CNeuralNetV2::Randomize_OutputSynapsePlasticities(int32_t neuronID, float minValue, float maxValue)
{
	pNeuronArray[neuronID].Randomize_OutputSynapsePlasticities(&RandomNumbers, minValue, maxValue);
}

void CNeuralNetV2::Randomize_OutputSynapsePlasticities(float minValue, float maxValue)
{
	for (int32_t i = 0; i < NumOfNeurons; i++)
	pNeuronArray[i].Randomize_OutputSynapsePlasticities(&RandomNumbers, minValue, maxValue);
}

void CNeuralNetV2::Randomize_OutputSynapsePlasticities(uint64_t newSeed, float minValue, float maxValue)
{
	RandomNumbers.Change_Seed(newSeed);
	for (int32_t i = 0; i < NumOfNeurons; i++)
		pNeuronArray[i].Randomize_OutputSynapsePlasticities(&RandomNumbers, minValue, maxValue);
}

void CNeuralNetV2::Randomize_OutputSynapsePlasticities(float minValue, float maxValue, float mutationRate)
{
	for (int32_t i = 0; i < NumOfNeurons; i++)
		pNeuronArray[i].Randomize_OutputSynapsePlasticities(&RandomNumbers, minValue, maxValue, mutationRate);
}

void CNeuralNetV2::Randomize_OutputSynapsePlasticities(uint64_t newSeed, float minValue, float maxValue, float mutationRate)
{
	RandomNumbers.Change_Seed(newSeed);
	for (int32_t i = 0; i < NumOfNeurons; i++)
		pNeuronArray[i].Randomize_OutputSynapsePlasticities(&RandomNumbers, minValue, maxValue, mutationRate);
}

void CNeuralNetV2::Randomize_OutputSynapsePlasticities(int32_t neuronID, float minValue, float maxValue, float mutationRate)
{
	pNeuronArray[neuronID].Randomize_OutputSynapsePlasticities(&RandomNumbers, minValue, maxValue, mutationRate);
}

void CNeuralNetV2::Randomize_OutputSynapsePlasticities(uint64_t newSeed, int32_t neuronID, float minValue, float maxValue)
{
	RandomNumbers.Change_Seed(newSeed);
	pNeuronArray[neuronID].Randomize_OutputSynapsePlasticities(&RandomNumbers, minValue, maxValue);
}

void CNeuralNetV2::Randomize_OutputSynapsePlasticities(uint64_t newSeed, int32_t neuronID, float minValue, float maxValue, float mutationRate)
{
	RandomNumbers.Change_Seed(newSeed);
	pNeuronArray[neuronID].Randomize_OutputSynapsePlasticities(&RandomNumbers, minValue, maxValue, mutationRate);
}

void CNeuralNetV2::Modify_OutputSynapsePlasticities(int32_t neuronID, float minValue, float maxValue)
{
	pNeuronArray[neuronID].Modify_OutputSynapsePlasticities(&RandomNumbers, minValue, maxValue);
}

void CNeuralNetV2::Modify_OutputSynapsePlasticities(float minValue, float maxValue)
{
	for (int32_t i = 0; i < NumOfNeurons; i++)
		pNeuronArray[i].Modify_OutputSynapsePlasticities(&RandomNumbers, minValue, maxValue);
}

void CNeuralNetV2::Modify_OutputSynapsePlasticities(uint64_t newSeed, float minValue, float maxValue)
{
	RandomNumbers.Change_Seed(newSeed);
	for (int32_t i = 0; i < NumOfNeurons; i++)
		pNeuronArray[i].Modify_OutputSynapsePlasticities(&RandomNumbers, minValue, maxValue);
}

void CNeuralNetV2::Modify_OutputSynapsePlasticities(int32_t neuronID, float minValue, float maxValue, float mutationRate)
{
	pNeuronArray[neuronID].Modify_OutputSynapsePlasticities(&RandomNumbers, minValue, maxValue, mutationRate);
}

void CNeuralNetV2::Modify_OutputSynapsePlasticities(float minValue, float maxValue, float mutationRate)
{
	for (int32_t i = 0; i < NumOfNeurons; i++)
		pNeuronArray[i].Modify_OutputSynapsePlasticities(&RandomNumbers, minValue, maxValue, mutationRate);
}

void CNeuralNetV2::Modify_OutputSynapsePlasticities(uint64_t newSeed, float minValue, float maxValue, float mutationRate)
{
	RandomNumbers.Change_Seed(newSeed);
	for (int32_t i = 0; i < NumOfNeurons; i++)
		pNeuronArray[i].Modify_OutputSynapsePlasticities(&RandomNumbers, minValue, maxValue, mutationRate);
}

void CNeuralNetV2::Modify_OutputSynapsePlasticities(uint64_t newSeed, int32_t neuronID, float minValue, float maxValue)
{
	RandomNumbers.Change_Seed(newSeed);
	pNeuronArray[neuronID].Modify_OutputSynapsePlasticities(&RandomNumbers, minValue, maxValue);
}

void CNeuralNetV2::Modify_OutputSynapsePlasticities(uint64_t newSeed, int32_t neuronID, float minValue, float maxValue, float mutationRate)
{
	RandomNumbers.Change_Seed(newSeed);
	pNeuronArray[neuronID].Modify_OutputSynapsePlasticities(&RandomNumbers, minValue, maxValue, mutationRate);
}

void CNeuralNetV2::Randomize_OutputSynapsePlasticities(int32_t firstNeuronID, int32_t lastNeuronID, float minValue, float maxValue)
{
	for (int32_t i = firstNeuronID; i <= lastNeuronID; i++)
	{
		pNeuronArray[i].Randomize_OutputSynapsePlasticities(&RandomNumbers, minValue, maxValue);
	}
}

void CNeuralNetV2::Randomize_OutputSynapsePlasticities(int32_t firstNeuronID, int32_t lastNeuronID, float minValue, float maxValue, float mutationRate)
{
	for (int32_t i = firstNeuronID; i <= lastNeuronID; i++)
	{
		pNeuronArray[i].Randomize_OutputSynapsePlasticities(&RandomNumbers, minValue, maxValue, mutationRate);
	}
}

void CNeuralNetV2::Randomize_OutputSynapsePlasticities(uint64_t newSeed, int32_t firstNeuronID, int32_t lastNeuronID, float minValue, float maxValue)
{
	RandomNumbers.Change_Seed(newSeed);
	for (int32_t i = firstNeuronID; i <= lastNeuronID; i++)
	{
		pNeuronArray[i].Randomize_OutputSynapsePlasticities(&RandomNumbers, minValue, maxValue);
	}
}

void CNeuralNetV2::Randomize_OutputSynapsePlasticities(uint64_t newSeed, int32_t firstNeuronID, int32_t lastNeuronID, float minValue, float maxValue, float mutationRate)
{
	RandomNumbers.Change_Seed(newSeed);
	for (int32_t i = firstNeuronID; i <= lastNeuronID; i++)
	{
		pNeuronArray[i].Randomize_OutputSynapsePlasticities(&RandomNumbers, minValue, maxValue, mutationRate);
	}
}

void CNeuralNetV2::Modify_OutputSynapsePlasticities(int32_t firstNeuronID, int32_t lastNeuronID, float minValue, float maxValue)
{
	for (int32_t i = firstNeuronID; i <= lastNeuronID; i++)
	{
		pNeuronArray[i].Modify_OutputSynapsePlasticities(&RandomNumbers, minValue, maxValue);
	}
}

void CNeuralNetV2::Modify_OutputSynapsePlasticities(int32_t firstNeuronID, int32_t lastNeuronID, float minValue, float maxValue, float mutationRate)
{
	for (int32_t i = firstNeuronID; i <= lastNeuronID; i++)
	{
		pNeuronArray[i].Modify_OutputSynapsePlasticities(&RandomNumbers, minValue, maxValue, mutationRate);
	}
}

void CNeuralNetV2::Modify_OutputSynapsePlasticities(uint64_t newSeed, int32_t firstNeuronID, int32_t lastNeuronID, float minValue, float maxValue)
{
	RandomNumbers.Change_Seed(newSeed);
	for (int32_t i = firstNeuronID; i <= lastNeuronID; i++)
	{
		pNeuronArray[i].Modify_OutputSynapsePlasticities(&RandomNumbers, minValue, maxValue);
	}
}

void CNeuralNetV2::Modify_OutputSynapsePlasticities(uint64_t newSeed, int32_t firstNeuronID, int32_t lastNeuronID, float minValue, float maxValue, float mutationRate)
{
	RandomNumbers.Change_Seed(newSeed);
	for (int32_t i = firstNeuronID; i <= lastNeuronID; i++)
	{
		pNeuronArray[i].Modify_OutputSynapsePlasticities(&RandomNumbers, minValue, maxValue, mutationRate);
	}
}

/*void CNeuralNetV2::Randomize_RBF_CentroidValues(float minValue, float maxValue)
{
	int32_t id;

	for (int32_t i = 0; i < NumOfRBFNeurons; i++)
	{
		id = pRBFNeuronIDArray[i];
		pNeuronArray[id].Randomize_RBF_CentroidValues(&RandomNumbers, minValue, maxValue);
	}
}*/

/*void CNeuralNetV2::Modify_RBF_CentroidValues(float minValue, float maxValue)
{
	int32_t id;

	for (int32_t i = 0; i < NumOfRBFNeurons; i++)
	{
		id = pRBFNeuronIDArray[i];
		pNeuronArray[id].Modify_RBF_CentroidValues(&RandomNumbers, minValue, maxValue);
	}
}*/

void CNeuralNetV2::Randomize_Dendrite_Values(float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor)
{
	int32_t id;

	for (int32_t i = 0; i < NumOfDendriteNeurons; i++)
	{
		id = pDendriteNeuronIDArray[i];
		pNeuronArray[id].Randomize_Dendrite_Values(&RandomNumbers, minCentroidValue, maxCentroidValue, minFactor, maxFactor);
	}
}

void CNeuralNetV2::Modify_Dendrite_Values(float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance)
{
	int32_t id;

	for (int32_t i = 0; i < NumOfDendriteNeurons; i++)
	{
		id = pDendriteNeuronIDArray[i];
		pNeuronArray[id].Modify_Dendrite_Values(&RandomNumbers, minCentroidValueVariance, maxCentroidValueVariance, minFactorVariance, maxFactorVariance);
	}
}

void CNeuralNetV2::Combine_Dendrite_Data(const CNeuralNetV2 *pParentObject1, const CNeuralNetV2 *pParentObject2)
{
	int32_t id;

	for (int32_t i = 0; i < NumOfDendriteNeurons; i++)
	{
		id = pDendriteNeuronIDArray[i];
		pNeuronArray[id].Combine_Dendrite_Data(&RandomNumbers, &pParentObject1->pNeuronArray[id], &pParentObject2->pNeuronArray[id]);
	}
}

void CNeuralNetV2::Combine_Dendrite_Data_RandomWeighted(uint64_t newSeed, const CNeuralNetV2 *pParentObject1, const CNeuralNetV2 *pParentObject2)
{
	RandomNumbers.Change_Seed(newSeed);

	int32_t id;

	for (int32_t i = 0; i < NumOfDendriteNeurons; i++)
	{
		id = pDendriteNeuronIDArray[i];
		pNeuronArray[id].Combine_Dendrite_Data_RandomWeighted(&RandomNumbers, &pParentObject1->pNeuronArray[id], &pParentObject2->pNeuronArray[id]);
	}
}

void CNeuralNetV2::Combine_Dendrite_Data_RandomWeighted(const CNeuralNetV2 *pParentObject1, const CNeuralNetV2 *pParentObject2)
{
	int32_t id;

	for (int32_t i = 0; i < NumOfDendriteNeurons; i++)
	{
		id = pDendriteNeuronIDArray[i];
		pNeuronArray[id].Combine_Dendrite_Data_RandomWeighted(&RandomNumbers, &pParentObject1->pNeuronArray[id], &pParentObject2->pNeuronArray[id]);
	}
}

void CNeuralNetV2::Combine_Dendrite_Data_RandomWeighted(uint64_t newSeed, const CNeuralNetV2 *pParentObject1, const CNeuralNetV2 *pParentObject2, float minParent1Weight, float maxParent1Weight)
{
	RandomNumbers.Change_Seed(newSeed);

	int32_t id;

	for (int32_t i = 0; i < NumOfDendriteNeurons; i++)
	{
		id = pDendriteNeuronIDArray[i];
		pNeuronArray[id].Combine_Dendrite_Data_RandomWeighted(&RandomNumbers, &pParentObject1->pNeuronArray[id], &pParentObject2->pNeuronArray[id], minParent1Weight, maxParent1Weight);
	}
}



void CNeuralNetV2::Combine_Dendrite_Data(const CNeuralNetV2 *pParentObject1, const CNeuralNetV2 *pParentObject2, pRecombinationFunc pFunc, void *pParam)
{
	int32_t id;

	for (int32_t i = 0; i < NumOfDendriteNeurons; i++)
	{
		id = pDendriteNeuronIDArray[i];
		pFunc(&pNeuronArray[id], &pParentObject1->pNeuronArray[id], &pParentObject2->pNeuronArray[id], &RandomNumbers, pParam);
	}
}

void CNeuralNetV2::Combine_Dendrite_Data(uint64_t newSeed, const CNeuralNetV2 *pParentObject1, const CNeuralNetV2 *pParentObject2, pRecombinationFunc pFunc, void *pParam)
{
	RandomNumbers.Change_Seed(newSeed);

	int32_t id;

	for (int32_t i = 0; i < NumOfDendriteNeurons; i++)
	{
		id = pDendriteNeuronIDArray[i];
		pFunc(&pNeuronArray[id], &pParentObject1->pNeuronArray[id], &pParentObject2->pNeuronArray[id], &RandomNumbers, pParam);
	}
}

void CNeuralNetV2::Combine_Dendrite_Data_RandomWeighted(const CNeuralNetV2 *pParentObject1, const CNeuralNetV2 *pParentObject2, float minParent1Weight, float maxParent1Weight)
{
	int32_t id;

	for (int32_t i = 0; i < NumOfDendriteNeurons; i++)
	{
		id = pDendriteNeuronIDArray[i];
		pNeuronArray[id].Combine_Dendrite_Data_RandomWeighted(&RandomNumbers, &pParentObject1->pNeuronArray[id], &pParentObject2->pNeuronArray[id], minParent1Weight, maxParent1Weight);
	}
}

void CNeuralNetV2::Combine_Dendrite_Data(const CNeuralNetV2 *pParentObject1, const CNeuralNetV2 *pParentObject2, float weightFactorParent1)
{
	int32_t id;

	for (int32_t i = 0; i < NumOfDendriteNeurons; i++)
	{
		id = pDendriteNeuronIDArray[i];
		pNeuronArray[id].Combine_Dendrite_Data(&RandomNumbers, &pParentObject1->pNeuronArray[id], &pParentObject2->pNeuronArray[id], weightFactorParent1);
	}
}

void CNeuralNetV2::Combine_Dendrite_Data(uint64_t newSeed, const CNeuralNetV2 *pParentObject1, const CNeuralNetV2 *pParentObject2, float weightFactorParent1)
{
	RandomNumbers.Change_Seed(newSeed);

	int32_t id;

	for (int32_t i = 0; i < NumOfDendriteNeurons; i++)
	{
		id = pDendriteNeuronIDArray[i];
		pNeuronArray[id].Combine_Dendrite_Data(&RandomNumbers, &pParentObject1->pNeuronArray[id], &pParentObject2->pNeuronArray[id], weightFactorParent1);
	}
}

void CNeuralNetV2::Combine_Dendrite_Data(uint64_t newSeed, const CNeuralNetV2 *pParentObject1, const CNeuralNetV2 *pParentObject2)
{
	RandomNumbers.Change_Seed(newSeed);

	int32_t id;

	for (int32_t i = 0; i < NumOfDendriteNeurons; i++)
	{
		id = pDendriteNeuronIDArray[i];
		pNeuronArray[id].Combine_Dendrite_Data(&RandomNumbers, &pParentObject1->pNeuronArray[id], &pParentObject2->pNeuronArray[id]);
	}
}

void CNeuralNetV2::Randomize_Dendrite_Values(uint64_t newSeed, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor)
{
	RandomNumbers.Change_Seed(newSeed);

	int32_t id;

	for (int32_t i = 0; i < NumOfDendriteNeurons; i++)
	{
		id = pDendriteNeuronIDArray[i];
		pNeuronArray[id].Randomize_Dendrite_Values(&RandomNumbers, minCentroidValue, maxCentroidValue, minFactor, maxFactor);
	}
}

void CNeuralNetV2::Modify_Dendrite_Values(uint64_t newSeed, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance)
{
	RandomNumbers.Change_Seed(newSeed);

	int32_t id;

	for (int32_t i = 0; i < NumOfDendriteNeurons; i++)
	{
		id = pDendriteNeuronIDArray[i];
		pNeuronArray[id].Modify_Dendrite_Values(&RandomNumbers, minCentroidValueVariance, maxCentroidValueVariance, minFactorVariance, maxFactorVariance);
	}
}

/*void CNeuralNetV2::Randomize_RBF_Factors(float minValue, float maxValue)
{
	int32_t id;

	for (int32_t i = 0; i < NumOfRBFNeurons; i++)
	{
		id = pRBFNeuronIDArray[i];
		pNeuronArray[id].Randomize_RBF_Factors(&RandomNumbers, minValue, maxValue);
	}
}*/

/*void CNeuralNetV2::Modify_RBF_Factors(float minValue, float maxValue)
{
	int32_t id;

	for (int32_t i = 0; i < NumOfRBFNeurons; i++)
	{
		id = pRBFNeuronIDArray[i];
		pNeuronArray[id].Modify_RBF_Factors(&RandomNumbers, minValue, maxValue);
	}
}*/

/*void CNeuralNetV2::Randomize_RBF_CentroidValues(uint64_t newSeed, float minValue, float maxValue)
{
	RandomNumbers.Change_Seed(newSeed);

	int32_t id;

	for (int32_t i = 0; i < NumOfRBFNeurons; i++)
	{
		id = pRBFNeuronIDArray[i];
		pNeuronArray[id].Randomize_RBF_CentroidValues(&RandomNumbers, minValue, maxValue);
	}
}*/

/*void CNeuralNetV2::Modify_RBF_CentroidValues(uint64_t newSeed, float minValue, float maxValue)
{
	RandomNumbers.Change_Seed(newSeed);

	int32_t id;

	for (int32_t i = 0; i < NumOfRBFNeurons; i++)
	{
		id = pRBFNeuronIDArray[i];
		pNeuronArray[id].Modify_RBF_CentroidValues(&RandomNumbers, minValue, maxValue);
	}
}*/

/*void CNeuralNetV2::Randomize_RBF_Factors(uint64_t newSeed, float minValue, float maxValue)
{
	RandomNumbers.Change_Seed(newSeed);

	int32_t id;

	for (int32_t i = 0; i < NumOfRBFNeurons; i++)
	{
		id = pRBFNeuronIDArray[i];
		pNeuronArray[id].Randomize_RBF_Factors(&RandomNumbers, minValue, maxValue);
	}
}*/

/*void CNeuralNetV2::Modify_RBF_Factors(uint64_t newSeed, float minValue, float maxValue)
{
	RandomNumbers.Change_Seed(newSeed);

	int32_t id;

	for (int32_t i = 0; i < NumOfRBFNeurons; i++)
	{
		id = pRBFNeuronIDArray[i];
		pNeuronArray[id].Modify_RBF_Factors(&RandomNumbers, minValue, maxValue);
	}
}*/

/*void CNeuralNetV2::Randomize_RBF_CentroidValues(int32_t neuronID, float minValue, float maxValue)
{
	pNeuronArray[neuronID].Randomize_RBF_CentroidValues(&RandomNumbers, minValue, maxValue);
}*/

/*void CNeuralNetV2::Modify_RBF_CentroidValues(int32_t neuronID, float minValue, float maxValue)
{
	pNeuronArray[neuronID].Modify_RBF_CentroidValues(&RandomNumbers, minValue, maxValue);
}*/

void CNeuralNetV2::Randomize_Dendrite_Values(int32_t neuronID, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor)
{
	pNeuronArray[neuronID].Randomize_Dendrite_Values(&RandomNumbers, minCentroidValue, maxCentroidValue, minFactor, maxFactor);
}

void CNeuralNetV2::Modify_RBF_Values(int32_t neuronID, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance)
{
	pNeuronArray[neuronID].Modify_Dendrite_Values(&RandomNumbers, minCentroidValueVariance, maxCentroidValueVariance, minFactorVariance, maxFactorVariance);
}

void CNeuralNetV2::Randomize_Dendrite_Values(uint64_t newSeed, int32_t neuronID, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor)
{
	RandomNumbers.Change_Seed(newSeed);
	pNeuronArray[neuronID].Randomize_Dendrite_Values(&RandomNumbers, minCentroidValue, maxCentroidValue, minFactor, maxFactor);
}

void CNeuralNetV2::Modify_Dendrite_Values(uint64_t newSeed, int32_t neuronID, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance)
{
	RandomNumbers.Change_Seed(newSeed);
	pNeuronArray[neuronID].Modify_Dendrite_Values(&RandomNumbers, minCentroidValueVariance, maxCentroidValueVariance, minFactorVariance, maxFactorVariance);
}

/*void CNeuralNetV2::Randomize_RBF_Factors(int32_t neuronID, float minValue, float maxValue)
{
	pNeuronArray[neuronID].Randomize_RBF_Factors(&RandomNumbers, minValue, maxValue);
}*/

/*void CNeuralNetV2::Modify_RBF_Factors(int32_t neuronID, float minValue, float maxValue)
{
	pNeuronArray[neuronID].Modify_RBF_Factors(&RandomNumbers, minValue, maxValue);
}*/

/*void CNeuralNetV2::Randomize_RBF_CentroidValues(uint64_t newSeed, int32_t neuronID, float minValue, float maxValue)
{
	RandomNumbers.Change_Seed(newSeed);

	pNeuronArray[neuronID].Randomize_RBF_CentroidValues(&RandomNumbers, minValue, maxValue);
}*/

/*void CNeuralNetV2::Modify_RBF_CentroidValues(uint64_t newSeed, int32_t neuronID, float minValue, float maxValue)
{
	RandomNumbers.Change_Seed(newSeed);

	pNeuronArray[neuronID].Modify_RBF_CentroidValues(&RandomNumbers, minValue, maxValue);
}*/

/*void CNeuralNetV2::Randomize_RBF_Factors(uint64_t newSeed, int32_t neuronID, float minValue, float maxValue)
{
	RandomNumbers.Change_Seed(newSeed);

	pNeuronArray[neuronID].Randomize_RBF_Factors(&RandomNumbers, minValue, maxValue);
}*/

/*void CNeuralNetV2::Modify_RBF_Factors(uint64_t newSeed, int32_t neuronID, float minValue, float maxValue)
{
	RandomNumbers.Change_Seed(newSeed);

	pNeuronArray[neuronID].Modify_RBF_Factors(&RandomNumbers, minValue, maxValue);
}*/

/*void CNeuralNetV2::Randomize_RBF_CentroidValues(float minValue, float maxValue, float mutationRate)
{
	int32_t id;

	for (int32_t i = 0; i < NumOfRBFNeurons; i++)
	{
		id = pRBFNeuronIDArray[i];
		pNeuronArray[id].Randomize_RBF_CentroidValues(&RandomNumbers, minValue, maxValue, mutationRate);
	}
}*/

/*void CNeuralNetV2::Modify_RBF_CentroidValues(float minValue, float maxValue, float mutationRate)
{
	int32_t id;

	for (int32_t i = 0; i < NumOfRBFNeurons; i++)
	{
		id = pRBFNeuronIDArray[i];
		pNeuronArray[id].Modify_RBF_CentroidValues(&RandomNumbers, minValue, maxValue, mutationRate);
	}
}*/

void CNeuralNetV2::Randomize_Dendrite_Values(float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor, float mutationRate)
{
	int32_t id;

	for (int32_t i = 0; i < NumOfDendriteNeurons; i++)
	{
		id = pDendriteNeuronIDArray[i];
		pNeuronArray[id].Randomize_Dendrite_Values(&RandomNumbers, minCentroidValue, maxCentroidValue, minFactor, maxFactor, mutationRate);
	}
}

void CNeuralNetV2::Modify_RBF_Values(float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance, float mutationRate)
{
	int32_t id;

	for (int32_t i = 0; i < NumOfDendriteNeurons; i++)
	{
		id = pDendriteNeuronIDArray[i];
		pNeuronArray[id].Modify_Dendrite_Values(&RandomNumbers, minCentroidValueVariance, maxCentroidValueVariance, minFactorVariance, maxFactorVariance, mutationRate);
	}
}

void CNeuralNetV2::Randomize_Dendrite_Values(uint64_t newSeed, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor, float mutationRate)
{
	RandomNumbers.Change_Seed(newSeed);

	int32_t id;

	for (int32_t i = 0; i < NumOfDendriteNeurons; i++)
	{
		id = pDendriteNeuronIDArray[i];
		pNeuronArray[id].Randomize_Dendrite_Values(&RandomNumbers, minCentroidValue, maxCentroidValue, minFactor, maxFactor, mutationRate);
	}
}

void CNeuralNetV2::Modify_Dendrite_Values(uint64_t newSeed, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance, float mutationRate)
{
	RandomNumbers.Change_Seed(newSeed);

	int32_t id;

	for (int32_t i = 0; i < NumOfDendriteNeurons; i++)
	{
		id = pDendriteNeuronIDArray[i];
		pNeuronArray[id].Modify_Dendrite_Values(&RandomNumbers, minCentroidValueVariance, maxCentroidValueVariance, minFactorVariance, maxFactorVariance, mutationRate);
	}
}

/*void CNeuralNetV2::Randomize_RBF_Factors(float minValue, float maxValue, float mutationRate)
{
	int32_t id;

	for (int32_t i = 0; i < NumOfRBFNeurons; i++)
	{
		id = pRBFNeuronIDArray[i];
		pNeuronArray[id].Randomize_RBF_Factors(&RandomNumbers, minValue, maxValue, mutationRate);
	}
}*/

/*void CNeuralNetV2::Modify_RBF_Factors(float minValue, float maxValue, float mutationRate)
{
	int32_t id;

	for (int32_t i = 0; i < NumOfRBFNeurons; i++)
	{
		id = pRBFNeuronIDArray[i];
		pNeuronArray[id].Modify_RBF_Factors(&RandomNumbers, minValue, maxValue, mutationRate);
	}
}*/

/*void CNeuralNetV2::Randomize_RBF_CentroidValues(uint64_t newSeed, float minValue, float maxValue, float mutationRate)
{
	RandomNumbers.Change_Seed(newSeed);

	int32_t id;

	for (int32_t i = 0; i < NumOfRBFNeurons; i++)
	{
		id = pRBFNeuronIDArray[i];
		pNeuronArray[id].Randomize_RBF_CentroidValues(&RandomNumbers, minValue, maxValue, mutationRate);
	}
}*/

/*void CNeuralNetV2::Modify_RBF_CentroidValues(uint64_t newSeed, float minValue, float maxValue, float mutationRate)
{
	RandomNumbers.Change_Seed(newSeed);

	int32_t id;

	for (int32_t i = 0; i < NumOfRBFNeurons; i++)
	{
		id = pRBFNeuronIDArray[i];
		pNeuronArray[id].Modify_RBF_CentroidValues(&RandomNumbers, minValue, maxValue, mutationRate);
	}
}*/

/*void CNeuralNetV2::Randomize_RBF_Factors(uint64_t newSeed, float minValue, float maxValue, float mutationRate)
{
	RandomNumbers.Change_Seed(newSeed);

	int32_t id;

	for (int32_t i = 0; i < NumOfRBFNeurons; i++)
	{
		id = pRBFNeuronIDArray[i];
		pNeuronArray[id].Randomize_RBF_Factors(&RandomNumbers, minValue, maxValue, mutationRate);
	}
}*/

/*void CNeuralNetV2::Modify_RBF_Factors(uint64_t newSeed, float minValue, float maxValue, float mutationRate)
{
	RandomNumbers.Change_Seed(newSeed);

	int32_t id;

	for (int32_t i = 0; i < NumOfRBFNeurons; i++)
	{
		id = pRBFNeuronIDArray[i];
		pNeuronArray[id].Modify_RBF_Factors(&RandomNumbers, minValue, maxValue, mutationRate);
	}
}*/

/*void CNeuralNetV2::Randomize_RBF_CentroidValues(int32_t neuronID, float minValue, float maxValue, float mutationRate)
{
	pNeuronArray[neuronID].Randomize_RBF_CentroidValues(&RandomNumbers, minValue, maxValue, mutationRate);
}*/

/*void CNeuralNetV2::Modify_RBF_CentroidValues(int32_t neuronID, float minValue, float maxValue, float mutationRate)
{
	pNeuronArray[neuronID].Modify_RBF_CentroidValues(&RandomNumbers, minValue, maxValue, mutationRate);
}*/

void CNeuralNetV2::Randomize_Dendrite_Values(int32_t neuronID, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor, float mutationRate)
{
	pNeuronArray[neuronID].Randomize_Dendrite_Values(&RandomNumbers, minCentroidValue, maxCentroidValue, minFactor, maxFactor, mutationRate);
}

void CNeuralNetV2::Modify_Dendrite_Values(int32_t neuronID, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance, float mutationRate)
{
	pNeuronArray[neuronID].Modify_Dendrite_Values(&RandomNumbers, minCentroidValueVariance, maxCentroidValueVariance, minFactorVariance, maxFactorVariance, mutationRate);
}

void CNeuralNetV2::Randomize_Dendrite_Values(uint64_t newSeed, int32_t neuronID, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor, float mutationRate)
{
	RandomNumbers.Change_Seed(newSeed);

	pNeuronArray[neuronID].Randomize_Dendrite_Values(&RandomNumbers, minCentroidValue, maxCentroidValue, minFactor, maxFactor, mutationRate);
}

void CNeuralNetV2::Modify_Dendrite_Values(uint64_t newSeed, int32_t neuronID, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance, float mutationRate)
{
	RandomNumbers.Change_Seed(newSeed);

	pNeuronArray[neuronID].Modify_Dendrite_Values(&RandomNumbers, minCentroidValueVariance, maxCentroidValueVariance, minFactorVariance, maxFactorVariance, mutationRate);
}

/*void CNeuralNetV2::Randomize_RBF_Factors(int32_t neuronID, float minValue, float maxValue, float mutationRate)
{
	pNeuronArray[neuronID].Randomize_RBF_Factors(&RandomNumbers, minValue, maxValue, mutationRate);
}*/

/*void CNeuralNetV2::Modify_RBF_Factors(int32_t neuronID, float minValue, float maxValue, float mutationRate)
{
	pNeuronArray[neuronID].Modify_RBF_Factors(&RandomNumbers, minValue, maxValue, mutationRate);
}*/

/*void CNeuralNetV2::Randomize_RBF_CentroidValues(uint64_t newSeed, int32_t neuronID, float minValue, float maxValue, float mutationRate)
{
	RandomNumbers.Change_Seed(newSeed);

	pNeuronArray[neuronID].Randomize_RBF_CentroidValues(&RandomNumbers, minValue, maxValue, mutationRate);
}*/

/*void CNeuralNetV2::Modify_RBF_CentroidValues(uint64_t newSeed, int32_t neuronID, float minValue, float maxValue, float mutationRate)
{
	RandomNumbers.Change_Seed(newSeed);

	pNeuronArray[neuronID].Modify_RBF_CentroidValues(&RandomNumbers, minValue, maxValue, mutationRate);
}*/

/*void CNeuralNetV2::Randomize_RBF_Factors(uint64_t newSeed, int32_t neuronID, float minValue, float maxValue, float mutationRate)
{
	RandomNumbers.Change_Seed(newSeed);

	pNeuronArray[neuronID].Randomize_RBF_Factors(&RandomNumbers, minValue, maxValue, mutationRate);
}*/

/*void CNeuralNetV2::Modify_RBF_Factors(uint64_t newSeed, int32_t neuronID, float minValue, float maxValue, float mutationRate)
{
	RandomNumbers.Change_Seed(newSeed);

	pNeuronArray[neuronID].Modify_RBF_Factors(&RandomNumbers, minValue, maxValue, mutationRate);
}*/






void CNeuralNetV2::Set_ActivationSequence(CActivationSequence *pSequence)
{
	pUsedActivationSequence = pSequence;
}

void CNeuralNetV2::Set_ActivationSequence_LastHiddenLayer(CActivationSequence *pSequence)
{
	pUsedActivationSequence_LastHiddenLayer = pSequence;
}

void CNeuralNetV2::Round_SynapticPlasticities(float precision)
{
	float invPrecision = 1.0f / precision;

	for (int32_t i = 0; i < NumOfNeurons; i++)
		pNeuronArray[i].Round_SynapticPlasticities(precision, invPrecision);
}

void CNeuralNetV2::Round_Dendrite_Values(float precision)
{
	float invPrecision = 1.0f / precision;

	for (int32_t i = 0; i < NumOfDendriteNeurons; i++)
	{
		pNeuronArray[pDendriteNeuronIDArray[i]].Round_Dendrite_Values(precision, invPrecision);
	}
}

void CNeuralNetV2::Round_Dendrite_CentroidValues(float precision)
{
	float invPrecision = 1.0f / precision;

	for (int32_t i = 0; i < NumOfDendriteNeurons; i++)
	{
		pNeuronArray[pDendriteNeuronIDArray[i]].Round_Dendrite_CentroidValues(precision, invPrecision);
	}
}
void CNeuralNetV2::Round_Dendrite_Factors(float precision)
{
	float invPrecision = 1.0f / precision;

	for (int32_t i = 0; i < NumOfDendriteNeurons; i++)
	{
		pNeuronArray[pDendriteNeuronIDArray[i]].Round_Dendrite_Factors(precision, invPrecision);
	}
}

void CNeuralNetV2::Remove_Unused_Connections(void)
{
	for (int32_t i = 0; i < NumOfNeurons; i++)
		pNeuronArray[i].Remove_Unused_Connections();
}

void CNeuralNetV2::Calculate_Output(float *pOutputValueArray, const float *pInputValueArray)
{
	int32_t id;

	for (int32_t i = 0; i < NumOfInputValues; i++)
	{
		id = i + IdOfFirstInputNeuron;
		pNeuronArray[id].Set_NeuronOutput(pInputValueArray[i]);
		pNeuronArray[id].Propagate_SynapticOutput();
	}

	
	int32_t activationSequenceLength = pUsedActivationSequence->Length;
	

	for (int32_t i = 0; i < activationSequenceLength; i++)
	{
		id = pUsedActivationSequence->pNeuronIDArray[i];

		pNeuronArray[id].Calculate_NeuronOutput();
		pNeuronArray[id].Propagate_SynapticOutput();
	}

	for (int32_t i = 0; i < NumOfOutputValues; i++)
	{
		pNeuronArray[i].Calculate_NeuronOutput();
		pOutputValueArray[i] = pNeuronArray[i].Get_NeuronOutput();
	}
}

float CNeuralNetV2::Calculate_Output_With_Error(float *pOutputValueArray, const float *pInputValueArray)
{
	int32_t id;

	for (int32_t i = 0; i < NumOfInputValues; i++)
	{
		id = i + IdOfFirstInputNeuron;
		pNeuronArray[id].Set_NeuronOutput(pInputValueArray[i]);
		pNeuronArray[id].Propagate_SynapticOutput();
	}

	int32_t activationSequenceLength = pUsedActivationSequence->Length;
	

	for (int32_t i = 0; i < activationSequenceLength; i++)
	{
		id = pUsedActivationSequence->pNeuronIDArray[i];

		pNeuronArray[id].Calculate_NeuronOutput();
		pNeuronArray[id].Propagate_SynapticOutput();
	}

	for (int32_t i = 0; i < NumOfOutputValues; i++)
	{
		pNeuronArray[i].Calculate_NeuronOutput();
		pOutputValueArray[i] = pNeuronArray[i].Get_NeuronOutput();
	}

	float error = 0.0f;

	for (int32_t i = 0; i < NumOfOutputValues; i++)
	{
		error += pNeuronArray[i].Calculate_Error(pInputValueArray[i]);
	}

	return error;
}

float CNeuralNetV2::Calculate_Error(const float *pDesiredOutputValueArray)
{
	int32_t id;
	float error = 0.0f;


	for (int32_t i = 0; i < NumOfOutputValues; i++)
	{
		error += pNeuronArray[i].Calculate_Error(pDesiredOutputValueArray[i]);
	}

	return error;
}

float CNeuralNetV2::Calculate_VarianceSq(const float *pDesiredOutputValueArray)
{
	int32_t id;
	float error = 0.0f;


	for (int32_t i = 0; i < NumOfOutputValues; i++)
	{
		error += pNeuronArray[i].Calculate_VarianceSq(pDesiredOutputValueArray[i]);
	}

	return error;
}

float CNeuralNetV2::Learning(const float *pDesiredOutputValueArray)
{
	int32_t id;
	float error = 0.0f;


	for (int32_t i = 0; i < NumOfOutputValues; i++)
	{
		error += pNeuronArray[i].Calculate_Error(pDesiredOutputValueArray[i]);
	}

	int32_t activationSequenceLength = pUsedActivationSequence->Length;

	for (int32_t i = activationSequenceLength - 1; i >= 1; i--)
	{
		id = pUsedActivationSequence->pNeuronIDArray[i];

		if (pNeuronArray[id].BiasNeuron == true)
			continue;

		pNeuronArray[id].Calculate_Error();
	}


	for (int32_t i = 0; i < activationSequenceLength; i++)
	{
		id = pUsedActivationSequence->pNeuronIDArray[i];
		pNeuronArray[id].Adjust_OutputSynapses_AfterErrorCalculations();
	}

	for (int32_t i = 0; i < NumOfInputValues; i++)
		pNeuronArray[i + IdOfFirstInputNeuron].Adjust_OutputSynapses_AfterErrorCalculations();

	return error;
}

// Nur die Plastizit�tswerte der mit den Output-Neuronen verbundenen Synapsen werden modifiziert:
float CNeuralNetV2::ExtremeLearning(const float *pDesiredOutputValueArray)
{
	int32_t id;
	float error = 0.0f;

	for (int32_t i = 0; i < NumOfOutputValues; i++)
	{
		error += pNeuronArray[i].Calculate_Error(pDesiredOutputValueArray[i]);
	}

	int32_t activationSequenceLength = pUsedActivationSequence_LastHiddenLayer->Length;

	for (int32_t i = 0; i < activationSequenceLength; i++)
	{
		id = pUsedActivationSequence_LastHiddenLayer->pNeuronIDArray[i];
		pNeuronArray[id].Adjust_OutputSynapses_AfterErrorCalculations();
	}

	return error;
}


void CNeuralNetV2::Adjust_OutputSynapses(const CNeuralNetV2 *pBestNeuralNet, float learningRate, float learningRateVariance, float errorFactor1, float errorFactor2)
{
	for (int32_t i = 0; i < NumOfNeurons; i++)
		pNeuronArray[i].Adjust_OutputSynapses(&pBestNeuralNet->pNeuronArray[i], &RandomNumbers, learningRate, learningRateVariance, errorFactor1, errorFactor2);
}

void CNeuralNetV2::Adjust_OutputSynapses(const CNeuralNetV2 *pBestNeuralNet)
{
	for (int32_t i = 0; i < NumOfNeurons; i++)
		pNeuronArray[i].Adjust_OutputSynapses(&pBestNeuralNet->pNeuronArray[i]);
}

// Nur die Plastizit�tswerte der mit den Output-Neuronen verbundenen Synapsen werden modifiziert:
float CNeuralNetV2::ExtremeLearning(float desiredOutputValue, int32_t idOfOutputNeuron)
{
	float error = pNeuronArray[idOfOutputNeuron].Calculate_Error(desiredOutputValue);

	int32_t activationSequenceLength = pUsedActivationSequence_LastHiddenLayer->Length;

	int32_t id;

	for (int32_t i = 0; i < activationSequenceLength; i++)
	{
		id = pUsedActivationSequence_LastHiddenLayer->pNeuronIDArray[i];
		pNeuronArray[id].Adjust_OutputSynapse_AfterErrorCalculations(idOfOutputNeuron);
	}

	return error;
}


CShortTermMemoryElementV2::CShortTermMemoryElementV2()
{}

CShortTermMemoryElementV2::~CShortTermMemoryElementV2()
{
	delete[] pNeuronArray;
	pNeuronArray = nullptr;
}

void CShortTermMemoryElementV2::Set_MemoryNeuronActivationFunction(pActivationFuncV2 pFunc, int32_t idOfMemeoryNeuron)
{
	pNeuronArray[FirstMemoryNeuronID + idOfMemeoryNeuron].Set_ActivationFunction(pFunc);
}


void CShortTermMemoryElementV2::Set_OutputNeuronActivationFunction(pActivationFuncV2 pFunc, int32_t idOfOutputNeuron)
{
	pNeuronArray[FirstOutputNeuronID + idOfOutputNeuron].Set_ActivationFunction(pFunc);
}

void CShortTermMemoryElementV2::Reset_Memory(void)
{
	uint32_t id;

	for (uint32_t i = 0; i < NumOfMemoryNeurons; i++)
	{
		id = i + FirstMemoryNeuronID;
		pNeuronArray[id].Reset_NeuronInput();
		pNeuronArray[id].Reset_NeuronOutput();
	}
}

float CShortTermMemoryElementV2::Get_Actual_Output(void)
{
	//return pNeuronArray[FirstOutputNeuronID].Get_NeuronOutput();
	return pNeuronArray[FirstOutputNeuronID].NeuronOutput;
}

void CShortTermMemoryElementV2::Get_Actual_Output(float *pOutputValueArray)
{
	int32_t id;

	for (int32_t i = 0; i < NumOfOutputNeurons; i++)
	{
		id = i + FirstOutputNeuronID;
		pOutputValueArray[i] = pNeuronArray[id].NeuronOutput;
	}
}

float CShortTermMemoryElementV2::Get_MemoryNeuronOutput(int32_t idOfMemeoryNeuron)
{
	//return pNeuronArray[FirstMemoryNeuronID + idOfMemeoryNeuron].Get_NeuronOutput();
	return pNeuronArray[FirstMemoryNeuronID + idOfMemeoryNeuron].NeuronOutput;
}

void CShortTermMemoryElementV2::Clone_Memory(CShortTermMemoryElementV2 *pMemoryNetwork)
{
	uint32_t id;

	for (uint32_t i = 0; i < NumOfMemoryNeurons; i++)
	{
		id = i + FirstMemoryNeuronID;
		pNeuronArray[id].NeuronOutput = pMemoryNetwork->pNeuronArray[id].NeuronOutput;
		pNeuronArray[id].NeuronInput = pMemoryNetwork->pNeuronArray[id].NeuronInput;
	}

	for (uint32_t i = 0; i < NumOfOutputNeurons; i++)
	{
		id = i + FirstOutputNeuronID;
		pNeuronArray[id].NeuronOutput = pMemoryNetwork->pNeuronArray[id].NeuronOutput;
		pNeuronArray[id].NeuronInput = pMemoryNetwork->pNeuronArray[id].NeuronInput;
	}
}

void CShortTermMemoryElementV2::Permute_Memory_Randomly(CRandomNumbersNN *pRandomNumbers)
{
	uint32_t id1 = pRandomNumbers->Get_UnsignedIntegerNumber(0, NumOfMemoryNeurons);
	uint32_t id2 = pRandomNumbers->Get_UnsignedIntegerNumber(0, NumOfMemoryNeurons);

	if (id1 == id2)
		return;

	uint32_t id11 = id1 + FirstMemoryNeuronID;
	uint32_t id22 = id2 + FirstMemoryNeuronID;

	float tempInput = pNeuronArray[id11].NeuronInput;
	float tempOutput = pNeuronArray[id11].NeuronOutput;

	pNeuronArray[id11].NeuronInput = pNeuronArray[id22].NeuronInput;
	pNeuronArray[id11].NeuronOutput = pNeuronArray[id22].NeuronOutput;

	pNeuronArray[id22].NeuronInput = tempInput;
	pNeuronArray[id22].NeuronOutput = tempOutput;

	id11 = id1 + FirstOutputNeuronID;
	id22 = id2 + FirstOutputNeuronID;

	tempInput = pNeuronArray[id11].NeuronInput;
	tempOutput = pNeuronArray[id11].NeuronOutput;

	pNeuronArray[id11].NeuronInput = pNeuronArray[id22].NeuronInput;
	pNeuronArray[id11].NeuronOutput = pNeuronArray[id22].NeuronOutput;

	pNeuronArray[id22].NeuronInput = tempInput;
	pNeuronArray[id22].NeuronOutput = tempOutput;
}

void CShortTermMemoryElementV2::Permute_Memory(int32_t id1, int32_t id2)
{
	if (id1 == id2)
		return;

	uint32_t id11 = id1 + FirstMemoryNeuronID;
	uint32_t id22 = id2 + FirstMemoryNeuronID;

	float tempInput = pNeuronArray[id11].NeuronInput;
	float tempOutput = pNeuronArray[id11].NeuronOutput;

	pNeuronArray[id11].NeuronInput = pNeuronArray[id22].NeuronInput;
	pNeuronArray[id11].NeuronOutput = pNeuronArray[id22].NeuronOutput;

	pNeuronArray[id22].NeuronInput = tempInput;
	pNeuronArray[id22].NeuronOutput = tempOutput;

	id11 = id1 + FirstOutputNeuronID;
	id22 = id2 + FirstOutputNeuronID;

	tempInput = pNeuronArray[id11].NeuronInput;
	tempOutput = pNeuronArray[id11].NeuronOutput;

	pNeuronArray[id11].NeuronInput = pNeuronArray[id22].NeuronInput;
	pNeuronArray[id11].NeuronOutput = pNeuronArray[id22].NeuronOutput;

	pNeuronArray[id22].NeuronInput = tempInput;
	pNeuronArray[id22].NeuronOutput = tempOutput;
}

float CShortTermMemoryElementV2::Calculate_Output(float inputValue)
{
	if (NumOfMemoryNeurons == 1)
	{
		pNeuronArray[FirstMemoryNeuronID].Calculate_NeuronOutput();
		pNeuronArray[FirstMemoryNeuronID].Propagate_SynapticOutput();

		pNeuronArray[0].Set_NeuronOutput(inputValue);
		pNeuronArray[0].Propagate_SynapticOutput();

		pNeuronArray[FirstOutputNeuronID].Calculate_NeuronOutput();

		//return pNeuronArray[FirstOutputNeuronID].Get_NeuronOutput();
		return pNeuronArray[FirstOutputNeuronID].NeuronOutput;
	}
	else //if (NumOfMemoryNeurons > 1)
	{
		int32_t id;

		for (int32_t i = NumOfMemoryNeurons - 1; i > -1; i--)
		{
			id = i + FirstMemoryNeuronID;

			pNeuronArray[id].Calculate_NeuronOutput();
			pNeuronArray[id].Propagate_SynapticOutput();
		}

		pNeuronArray[0].Set_NeuronOutput(inputValue);
		pNeuronArray[0].Propagate_SynapticOutput();

		pNeuronArray[FirstOutputNeuronID].Calculate_NeuronOutput();

		//return pNeuronArray[FirstOutputNeuronID].Get_NeuronOutput();
		return pNeuronArray[FirstOutputNeuronID].NeuronOutput;
	}
}

void CShortTermMemoryElementV2::Calculate_Output(float *pOutputValueArray, float inputValue)
{
	int32_t id;


	for (int32_t i = NumOfMemoryNeurons - 1; i > -1; i--)
	{
		id = i + FirstMemoryNeuronID;

		pNeuronArray[id].Calculate_NeuronOutput();
		pNeuronArray[id].Propagate_SynapticOutput();
	}

	pNeuronArray[0].Set_NeuronOutput(inputValue);
	pNeuronArray[0].Propagate_SynapticOutput();


	for (int32_t i = 0; i < NumOfOutputNeurons; i++)
	{
		id = i + FirstOutputNeuronID;

		pNeuronArray[id].Calculate_NeuronOutput();

		pOutputValueArray[i] = pNeuronArray[id].NeuronOutput;
	}
}

void CShortTermMemoryElementV2::Initialize_SingleInput_SingleOutput(int32_t numOfMemoryNeurons, pActivationFuncV2 pFunc, float memoryDrecreaseFactor)
{
	delete[] pNeuronArray;
	pNeuronArray = nullptr;

	NumOfOutputNeurons = 1;

	NumOfMemoryNeurons = max(1, numOfMemoryNeurons);

	NumOfNeurons = 2; //InputNeuron + OutputNeuron
	NumOfNeurons += NumOfMemoryNeurons;

	pNeuronArray = new (std::nothrow) CNeuronV2[NumOfNeurons];

	for (int32_t i = 0; i < NumOfNeurons; i++)
		pNeuronArray[i].Connect_With_Brain(pNeuronArray);

	FirstMemoryNeuronID = 1;
	FirstOutputNeuronID = 1 + NumOfMemoryNeurons;

	pNeuronArray[0].Init_OutputSynapses(2);

	pNeuronArray[0].Set_OutputSynapsePlasticity(1.0f, /*synapseID:*/ 0);
	pNeuronArray[0].Connect_With_ReceiverNeuron(FirstMemoryNeuronID, /*synapseID:*/ 0);

	pNeuronArray[0].Set_OutputSynapsePlasticity(1.0f, /*synapseID:*/ 1);
	pNeuronArray[0].Connect_With_ReceiverNeuron(FirstOutputNeuronID, /*synapseID:*/ 1);

	pNeuronArray[FirstOutputNeuronID].Set_ActivationFunction(pFunc);

	if (NumOfMemoryNeurons == 1)
	{
		int32_t id = FirstMemoryNeuronID;

		pNeuronArray[id].Set_ActivationFunction(pFunc);
		pNeuronArray[id].Init_OutputSynapses(1);

		pNeuronArray[id].Set_OutputSynapsePlasticity(1.0f * memoryDrecreaseFactor, /*synapseID:*/ 0);
		pNeuronArray[id].Connect_With_ReceiverNeuron(FirstOutputNeuronID, /*synapseID:*/ 0);
	}
	else //if (NumOfMemoryNeurons > 1)
	{
		int32_t id;

		int32_t numOfMemoryNeuronsMinus1 = NumOfMemoryNeurons - 1;

		float weightFactor = memoryDrecreaseFactor;

		for (int32_t i = 0; i < NumOfMemoryNeurons; i++)
		{
			id = i + FirstMemoryNeuronID;

			pNeuronArray[id].Set_ActivationFunction(pFunc);


			if (i < numOfMemoryNeuronsMinus1)
			{
				pNeuronArray[id].Init_OutputSynapses(2);

				pNeuronArray[id].Set_OutputSynapsePlasticity(1.0f * weightFactor, /*synapseID:*/ 0);
				pNeuronArray[id].Connect_With_ReceiverNeuron(FirstOutputNeuronID, /*synapseID:*/ 0);

				pNeuronArray[id].Set_OutputSynapsePlasticity(1.0f, /*synapseID:*/ 1);
				pNeuronArray[id].Connect_With_ReceiverNeuron(/*memoryNeuronID:*/ id + 1, /*synapseID:*/ 1);
			}
			else //if (i == numOfMemoryNeuronsMinus1)
			{
				pNeuronArray[id].Init_OutputSynapses(1);

				pNeuronArray[id].Set_OutputSynapsePlasticity(1.0f * weightFactor, /*synapseID:*/ 0);
				pNeuronArray[id].Connect_With_ReceiverNeuron(FirstOutputNeuronID, /*synapseID:*/ 0);
			}

			weightFactor *= memoryDrecreaseFactor;
		}
	}
}

void CShortTermMemoryElementV2::Initialize_SingleInput_SingleOutput(int32_t numOfMemoryNeurons, pActivationFuncV2 pFunc1, pActivationFuncV2 pFunc_LastMemoryNeuron, float memoryDrecreaseFactor)
{
	delete[] pNeuronArray;
	pNeuronArray = nullptr;

	NumOfOutputNeurons = 1;

	NumOfMemoryNeurons = max(1, numOfMemoryNeurons);

	NumOfNeurons = 2; //InputNeuron + OutputNeuron
	NumOfNeurons += NumOfMemoryNeurons;

	pNeuronArray = new (std::nothrow) CNeuronV2[NumOfNeurons];

	for (int32_t i = 0; i < NumOfNeurons; i++)
		pNeuronArray[i].Connect_With_Brain(pNeuronArray);

	FirstMemoryNeuronID = 1;
	FirstOutputNeuronID = 1 + NumOfMemoryNeurons;

	pNeuronArray[0].Init_OutputSynapses(2);

	pNeuronArray[0].Set_OutputSynapsePlasticity(1.0f, /*synapseID:*/ 0);
	pNeuronArray[0].Connect_With_ReceiverNeuron(FirstMemoryNeuronID, /*synapseID:*/ 0);

	pNeuronArray[0].Set_OutputSynapsePlasticity(1.0f, /*synapseID:*/ 1);
	pNeuronArray[0].Connect_With_ReceiverNeuron(FirstOutputNeuronID, /*synapseID:*/ 1);


	pNeuronArray[FirstOutputNeuronID].Set_ActivationFunction(pFunc1);

	if (NumOfMemoryNeurons == 1)
	{
		int32_t id = FirstMemoryNeuronID;

		pNeuronArray[id].Set_ActivationFunction(pFunc_LastMemoryNeuron);
		pNeuronArray[id].Init_OutputSynapses(1);

		pNeuronArray[id].Set_OutputSynapsePlasticity(1.0f * memoryDrecreaseFactor, /*synapseID:*/ 0);
		pNeuronArray[id].Connect_With_ReceiverNeuron(FirstOutputNeuronID, /*synapseID:*/ 0);
	}
	else //if (NumOfMemoryNeurons > 1)
	{
		int32_t id;

		int32_t numOfMemoryNeuronsMinus1 = NumOfMemoryNeurons - 1;

		float weightFactor = memoryDrecreaseFactor;

		for (uint32_t i = 0; i < NumOfMemoryNeurons; i++)
		{
			id = i + FirstMemoryNeuronID;

			if (i < numOfMemoryNeuronsMinus1)
			{
				pNeuronArray[id].Set_ActivationFunction(pFunc1);

				pNeuronArray[id].Init_OutputSynapses(1);

				pNeuronArray[id].Set_OutputSynapsePlasticity(1.0f * weightFactor, /*synapseID:*/ 0);
				pNeuronArray[id].Connect_With_ReceiverNeuron(/*memoryNeuronID:*/ id + 1, /*synapseID:*/ 0);
			}
			else //if (i == numOfMemoryNeuronsMinus1)
			{
				pNeuronArray[id].Set_ActivationFunction(pFunc_LastMemoryNeuron);

				pNeuronArray[id].Init_OutputSynapses(1);

				pNeuronArray[id].Set_OutputSynapsePlasticity(1.0f * weightFactor, /*synapseID:*/ 0);
				pNeuronArray[id].Connect_With_ReceiverNeuron(FirstOutputNeuronID, /*synapseID:*/ 0);
			}

			weightFactor *= memoryDrecreaseFactor;
		}
	}
}

void CShortTermMemoryElementV2::Initialize_SingleInput_OutputArray(int32_t numOfOutputNeurons, pActivationFuncV2 pFunc, float memoryDrecreaseFactor)
{
	delete[] pNeuronArray;
	pNeuronArray = nullptr;

	NumOfOutputNeurons = max(2, numOfOutputNeurons);



	NumOfMemoryNeurons = NumOfOutputNeurons - 1;

	NumOfNeurons = 1; //InputNeuron
	NumOfNeurons += NumOfMemoryNeurons;
	NumOfNeurons += NumOfOutputNeurons;

	pNeuronArray = new (std::nothrow) CNeuronV2[NumOfNeurons];

	for (int32_t i = 0; i < NumOfNeurons; i++)
		pNeuronArray[i].Connect_With_Brain(pNeuronArray);

	FirstMemoryNeuronID = 1;
	FirstOutputNeuronID = 1 + NumOfMemoryNeurons;

	pNeuronArray[0].Init_OutputSynapses(2);

	pNeuronArray[0].Set_OutputSynapsePlasticity(1.0f, /*synapseID:*/ 0);
	pNeuronArray[0].Connect_With_ReceiverNeuron(FirstMemoryNeuronID, /*synapseID:*/ 0);

	pNeuronArray[0].Set_OutputSynapsePlasticity(1.0f, /*synapseID:*/ 1);
	pNeuronArray[0].Connect_With_ReceiverNeuron(FirstOutputNeuronID, /*synapseID:*/ 1);

	uint32_t id;

	for (uint32_t i = 0; i < NumOfOutputNeurons; i++)
	{
		id = i + FirstOutputNeuronID;

		pNeuronArray[id].Set_ActivationFunction(pFunc);
	}

	uint32_t numOfMemoryNeuronsMinus1 = NumOfMemoryNeurons - 1;

	float weightFactor = memoryDrecreaseFactor;

	for (uint32_t i = 0; i < NumOfMemoryNeurons; i++)
	{
		id = i + FirstMemoryNeuronID;

		pNeuronArray[id].Set_ActivationFunction(pFunc);

		if (i < numOfMemoryNeuronsMinus1)
		{
			pNeuronArray[id].Init_OutputSynapses(2);

			pNeuronArray[id].Set_OutputSynapsePlasticity(1.0f * weightFactor, /*synapseID:*/ 0);
			pNeuronArray[id].Connect_With_ReceiverNeuron(i + 1 + FirstOutputNeuronID, /*synapseID:*/ 0);

			pNeuronArray[id].Set_OutputSynapsePlasticity(1.0f, /*synapseID:*/ 1);
			pNeuronArray[id].Connect_With_ReceiverNeuron(/*memoryNeuronID:*/ id + 1, /*synapseID:*/ 1);
		}
		else //if (i == numOfMemoryNeuronsMinus1)
		{
			pNeuronArray[id].Init_OutputSynapses(1);

			pNeuronArray[id].Set_OutputSynapsePlasticity(1.0f * weightFactor, /*synapseID:*/ 0);
			pNeuronArray[id].Connect_With_ReceiverNeuron(i + 1 + FirstOutputNeuronID, /*synapseID:*/ 0);
		}

		weightFactor *= memoryDrecreaseFactor;
	}
}

C2DPatternDetectorV2::C2DPatternDetectorV2()
{}

C2DPatternDetectorV2::~C2DPatternDetectorV2()
{
	delete[] pValueArray;
	pValueArray = nullptr;
}

void C2DPatternDetectorV2::Connect_With_Neuron(CNeuronV2 *pNeuron)
{
	pUsed_RBF_CentroidValueArray = pNeuron->pDendrite_CentroidValueArray;
	pUsed_RBF_FactorArray = pNeuron->pDendrite_FactorArray;
}

void C2DPatternDetectorV2::Connect_With_Neuron(CNeuronV2 *pNeuron, int32_t first_RBF_ElementID)
{
	pUsed_RBF_CentroidValueArray = &pNeuron->pDendrite_CentroidValueArray[first_RBF_ElementID];
	pUsed_RBF_FactorArray = &pNeuron->pDendrite_FactorArray[first_RBF_ElementID];
}

void C2DPatternDetectorV2::Set_SizeOnly(uint32_t sizeXDir, uint32_t sizeYDir)
{
	SizeXDir = sizeXDir;
	SizeYDir = sizeYDir;
	Size = sizeXDir * sizeYDir;
}

void C2DPatternDetectorV2::Initialize(uint32_t sizeXDir, uint32_t sizeYDir)
{
	delete[] pValueArray;
	pValueArray = nullptr;

	SizeXDir = sizeXDir;
	SizeYDir = sizeYDir;
	Size = sizeXDir * sizeYDir;

	pValueArray = new (std::nothrow) float[Size];


	for (uint32_t i = 0; i < Size; i++)
	{
		pValueArray[i] = 0.0f;
	}
}

bool C2DPatternDetectorV2::Load_Data(const char* pFilename)
{
	std::ifstream ReadFile;

	// eine existierende Datei zum Lesen �ffnen:
	ReadFile.open(pFilename);

	if (ReadFile.good() == false)
		return false;

	uint32_t sizeXDir, sizeYDir;

	ReadFile >> sizeXDir;
	ReadFile >> sizeYDir;

	Initialize(sizeXDir, sizeYDir);

	for (uint32_t i = 0; i < Size; i++)
		ReadFile >> pValueArray[i];


	ReadFile.close();

	return true;
}

bool C2DPatternDetectorV2::Save_Data(const char* pFilename)
{
	std::ofstream WriteFile;

	// neue Datei erzeugen bzw. alte �berschreiben:
	WriteFile.open(pFilename);

	// neue Datei erzeugen bzw. Inhalt ans Ende einer bestehenden Datei schreiben:
	//WriteFile.open(pFilename, ios::app);

	if (WriteFile.good() == false)
		return false;

	WriteFile << SizeXDir << "  ";
	WriteFile << SizeYDir << "  ";

	for (uint32_t i = 0; i < Size; i++)
		WriteFile << pValueArray[i] << "  ";

	WriteFile.close();

	return true;
}

bool C2DPatternDetectorV2::Load_Binary_Data_From_Bitmap(const char* pDescFilename /*not the bitmap*/, bool binaryImageData, bool use_0_And_1_Values)
{
	std::ifstream ReadFile;

	// eine existierende Datei zum Lesen �ffnen:
	ReadFile.open(pDescFilename);

	if (ReadFile.good() == false)
		return false;

	uint32_t sizeXDir, sizeYDir;

	ReadFile >> sizeXDir;
	ReadFile >> sizeYDir;

	Initialize(sizeXDir, sizeYDir);

	char bitmapFileName[256];

	ReadFile >> bitmapFileName;

	uint8_t *pImageData = nullptr;

	pImageData = Read_Bitmap_BGR(bitmapFileName);

	Get_BinaryImageData_BlueChannel(pValueArray, pImageData, sizeXDir, sizeYDir, use_0_And_1_Values);

	//Output_BinaryImageData(pValueArray, sizeXDir, sizeYDir);
	//getchar();

	delete[] pImageData;
	pImageData = nullptr;

	ReadFile.close();

	return true;
}

bool C2DPatternDetectorV2::Load_Data_From_Bitmap(const char* pDescFilename /*not the bitmap*/, float dataBiasValue)
{
	std::ifstream ReadFile;

	// eine existierende Datei zum Lesen �ffnen:
	ReadFile.open(pDescFilename);

	if (ReadFile.good() == false)
		return false;

	uint32_t sizeXDir, sizeYDir;

	ReadFile >> sizeXDir;
	ReadFile >> sizeYDir;

	Initialize(sizeXDir, sizeYDir);

	char bitmapFileName[256];

	ReadFile >> bitmapFileName;

	uint8_t *pImageData = nullptr;

	pImageData = Read_Bitmap_BGR(bitmapFileName);


	Get_ImageData_BlueChannel(pValueArray, pImageData, sizeXDir, sizeYDir, dataBiasValue);

	//Output_BinaryImageData(pValueArray, sizeXDir, sizeYDir);
	//getchar();

	delete[] pImageData;
	pImageData = nullptr;

	ReadFile.close();

	return true;
}

bool C2DPatternDetectorV2::Check_For_Pattern(int32_t patternTestPosX, int32_t patternTestPosY, const float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, float minActivationValue)
{
	if (SizeXDir == inputMapSizeX && SizeYDir == inputMapSizeY)
	{
		float inputValue, kernelValue, productValue, outputValue;

		float sumOfProductValues = 0.0f;

		for (uint32_t i = 0; i < Size; i++)
		{
			inputValue = pInputMap[i];
			kernelValue = pValueArray[i];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		if (sumOfProductValues < minActivationValue)
			return false;
		else
			return true;
	}

	int32_t posArrayCounter = 0;

	int32_t halfKernelSizeX = SizeXDir / 2;
	int32_t halfKernelSizeY = SizeYDir / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	//int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t ixKernelMax = halfKernelSizeX;

	if (SizeXDir % 2 != 0)
		ixKernelMax++;

	int32_t iyKernelMin = -halfKernelSizeY;
	//int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t iyKernelMax = halfKernelSizeY;

	if (SizeYDir % 2 != 0)
		iyKernelMax++;

	int32_t ixInputMax = inputMapSizeX - halfKernelSizeX;
	int32_t iyInputMax = inputMapSizeY - halfKernelSizeY;

	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;
	int32_t kernelID;


	float inputValue, kernelValue, productValue, sumOfProductValues, outputValue;

	bool returnValue = false;

	/*int32_t iyInput = max(halfKernelSizeY, patternTestPosY);
	iyInput = min(iyInput, iyInputMax - 1);

	int32_t ixInput = max(halfKernelSizeX, patternTestPosX);
	ixInput = min(ixInput, ixInputMax - 1);*/

	int32_t iyInput = max(halfKernelSizeY, patternTestPosY);

	if (SizeYDir % 2 == 0)
		iyInput = min(iyInput, iyInputMax);
	else
		iyInput = min(iyInput, iyInputMax - 1);

	int32_t ixInput = max(halfKernelSizeX, patternTestPosX);

	if (SizeXDir % 2 == 0)
		ixInput = min(ixInput, ixInputMax);
	else
		ixInput = min(ixInput, ixInputMax - 1);


	sumOfProductValues = 0.0f;

	for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
	{
		iiyInput = (iyInput + iyKernel) * inputMapSizeX;
		iiyKernel = (iyKernel + halfKernelSizeY) * SizeXDir;

		for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
		{
			inputValue = pInputMap[ixInput + ixKernel + iiyInput];

			kernelID = ixKernel + halfKernelSizeX + iiyKernel;

			kernelValue = pValueArray[kernelID];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}
	}

	if (sumOfProductValues >= minActivationValue)
		returnValue = true;

	return returnValue;

}

bool C2DPatternDetectorV2::Check_For_Pattern_RBF(int32_t patternTestPosX, int32_t patternTestPosY, const float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, pSimpleActivationFunc pActivationFunction, float minActivationValue)
{
	if (SizeXDir == inputMapSizeX && SizeYDir == inputMapSizeY)
	{
		float inputValue, varianceValue, outputValue;

		float sumOfVarianceValues = 0.0f;

		for (uint32_t i = 0; i < Size; i++)
		{
			inputValue = pInputMap[i];
			varianceValue = pUsed_RBF_CentroidValueArray[i] - inputValue;
			varianceValue *= varianceValue;
			varianceValue *= pUsed_RBF_FactorArray[i];
			sumOfVarianceValues += varianceValue;
		}

		float activation = pActivationFunction(sumOfVarianceValues);

		if (activation < minActivationValue)
			return false;
		else
			return true;
	}

	int32_t posArrayCounter = 0;

	int32_t halfKernelSizeX = SizeXDir / 2;
	int32_t halfKernelSizeY = SizeYDir / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	//int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t ixKernelMax = halfKernelSizeX;

	if (SizeXDir % 2 != 0)
		ixKernelMax++;

	int32_t iyKernelMin = -halfKernelSizeY;
	//int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t iyKernelMax = halfKernelSizeY;

	if (SizeYDir % 2 != 0)
		iyKernelMax++;

	int32_t ixInputMax = inputMapSizeX - halfKernelSizeX;
	int32_t iyInputMax = inputMapSizeY - halfKernelSizeY;

	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;
	int32_t kernelID;


	float inputValue, varianceValue, sumOfVarianceValues, outputValue;

	bool returnValue = false;

	/*int32_t iyInput = max(halfKernelSizeY, patternTestPosY);
	iyInput = min(iyInput, iyInputMax - 1);

	int32_t ixInput = max(halfKernelSizeX, patternTestPosX);
	ixInput = min(ixInput, ixInputMax - 1);*/

	int32_t iyInput = max(halfKernelSizeY, patternTestPosY);

	if (SizeYDir % 2 == 0)
		iyInput = min(iyInput, iyInputMax);
	else
		iyInput = min(iyInput, iyInputMax - 1);

	int32_t ixInput = max(halfKernelSizeX, patternTestPosX);

	if (SizeXDir % 2 == 0)
		ixInput = min(ixInput, ixInputMax);
	else
		ixInput = min(ixInput, ixInputMax - 1);

	sumOfVarianceValues = 0.0f;

	for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
	{
		iiyInput = (iyInput + iyKernel) * inputMapSizeX;
		iiyKernel = (iyKernel + halfKernelSizeY) * SizeXDir;

		for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
		{
			inputValue = pInputMap[ixInput + ixKernel + iiyInput];

			kernelID = ixKernel + halfKernelSizeX + iiyKernel;

			varianceValue = pUsed_RBF_CentroidValueArray[kernelID] - inputValue;
			varianceValue *= varianceValue;
			varianceValue *= pUsed_RBF_FactorArray[kernelID];
			sumOfVarianceValues += varianceValue;
		}
	}

	float activation = pActivationFunction(sumOfVarianceValues);

	if (activation >= minActivationValue)
		returnValue = true;

	return returnValue;

}

bool C2DPatternDetectorV2::Check_For_Pattern(float *pOutActivationvalue, int32_t patternTestPosX, int32_t patternTestPosY, const float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, float minActivationValue)
{
	if (SizeXDir == inputMapSizeX && SizeYDir == inputMapSizeY)
	{
		float inputValue, kernelValue, productValue, outputValue;

		float sumOfProductValues = 0.0f;

		for (uint32_t i = 0; i < Size; i++)
		{
			inputValue = pInputMap[i];
			kernelValue = pValueArray[i];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		if (sumOfProductValues < minActivationValue)
		{
			*pOutActivationvalue = 0.0f;
			return false;
		}
		else
		{
			*pOutActivationvalue = sumOfProductValues;
			return true;
		}
	}

	int32_t posArrayCounter = 0;

	int32_t halfKernelSizeX = SizeXDir / 2;
	int32_t halfKernelSizeY = SizeYDir / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	//int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t ixKernelMax = halfKernelSizeX;

	if (SizeXDir % 2 != 0)
		ixKernelMax++;

	int32_t iyKernelMin = -halfKernelSizeY;
	//int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t iyKernelMax = halfKernelSizeY;

	if (SizeYDir % 2 != 0)
		iyKernelMax++;

	int32_t ixInputMax = inputMapSizeX - halfKernelSizeX;
	int32_t iyInputMax = inputMapSizeY - halfKernelSizeY;

	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;
	int32_t kernelID;


	float inputValue, kernelValue, productValue, sumOfProductValues, outputValue;

	*pOutActivationvalue = 0.0f;
	bool returnValue = false;

	/*int32_t iyInput = max(halfKernelSizeY, patternTestPosY);
	iyInput = min(iyInput, iyInputMax - 1);

	int32_t ixInput = max(halfKernelSizeX, patternTestPosX);
	ixInput = min(ixInput, ixInputMax - 1);*/

	int32_t iyInput = max(halfKernelSizeY, patternTestPosY);

	if (SizeYDir % 2 == 0)
		iyInput = min(iyInput, iyInputMax);
	else
		iyInput = min(iyInput, iyInputMax - 1);

	int32_t ixInput = max(halfKernelSizeX, patternTestPosX);

	if (SizeXDir % 2 == 0)
		ixInput = min(ixInput, ixInputMax);
	else
		ixInput = min(ixInput, ixInputMax - 1);

	sumOfProductValues = 0.0f;

	for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
	{
		iiyInput = (iyInput + iyKernel) * inputMapSizeX;
		iiyKernel = (iyKernel + halfKernelSizeY) * SizeXDir;

		for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
		{
			inputValue = pInputMap[ixInput + ixKernel + iiyInput];

			kernelID = ixKernel + halfKernelSizeX + iiyKernel;

			kernelValue = pValueArray[kernelID];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}
	}

	if (sumOfProductValues >= minActivationValue)
	{
		*pOutActivationvalue = sumOfProductValues;
		returnValue = true;
	}

	return returnValue;

}

bool C2DPatternDetectorV2::Check_For_Pattern_RBF(float *pOutActivationvalue, int32_t patternTestPosX, int32_t patternTestPosY, const float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, pSimpleActivationFunc pActivationFunction, float minActivationValue)
{
	if (SizeXDir == inputMapSizeX && SizeYDir == inputMapSizeY)
	{
		float inputValue, varianceValue, outputValue;

		float sumOfVarianceValues = 0.0f;

		for (uint32_t i = 0; i < Size; i++)
		{
			inputValue = pInputMap[i];
			varianceValue = pUsed_RBF_CentroidValueArray[i] - inputValue;
			varianceValue *= varianceValue;
			varianceValue *= pUsed_RBF_FactorArray[i];
			sumOfVarianceValues += varianceValue;
		}

		float activation = pActivationFunction(sumOfVarianceValues);

		if (activation < minActivationValue)
		{
			*pOutActivationvalue = 0.0f;
			return false;
		}
		else
		{
			*pOutActivationvalue = activation;
			return true;
		}
	}

	int32_t posArrayCounter = 0;

	int32_t halfKernelSizeX = SizeXDir / 2;
	int32_t halfKernelSizeY = SizeYDir / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	int32_t ixKernelMax = halfKernelSizeX;

	if (SizeXDir % 2 != 0)
		ixKernelMax++;

	int32_t iyKernelMin = -halfKernelSizeY;
	int32_t iyKernelMax = halfKernelSizeY;

	if (SizeYDir % 2 != 0)
		iyKernelMax++;

	int32_t ixInputMax = inputMapSizeX - halfKernelSizeX;
	int32_t iyInputMax = inputMapSizeY - halfKernelSizeY;

	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;
	int32_t kernelID;


	float inputValue, varianceValue, sumOfVarianceValues, outputValue;

	*pOutActivationvalue = 0.0f;
	bool returnValue = false;

	int32_t iyInput = max(halfKernelSizeY, patternTestPosY);

	if (SizeYDir % 2 == 0)
		iyInput = min(iyInput, iyInputMax);
	else
		iyInput = min(iyInput, iyInputMax - 1);

	int32_t ixInput = max(halfKernelSizeX, patternTestPosX);
	
	if (SizeXDir % 2 == 0)
		ixInput = min(ixInput, ixInputMax);
	else
		ixInput = min(ixInput, ixInputMax - 1);

	//cout << endl << ixInput << " " << iyInput << endl;

	sumOfVarianceValues = 0.0f;

	//int32_t counter = 0;

	for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
	{
		iiyInput = (iyInput + iyKernel) * inputMapSizeX;
		iiyKernel = (iyKernel + halfKernelSizeY) * SizeXDir;

		for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
		{
			inputValue = pInputMap[ixInput + ixKernel + iiyInput];

			kernelID = ixKernel + halfKernelSizeX + iiyKernel;

			varianceValue = pUsed_RBF_CentroidValueArray[kernelID] - inputValue;
			varianceValue *= varianceValue;
			varianceValue *= pUsed_RBF_FactorArray[kernelID];
			sumOfVarianceValues += varianceValue;

			//counter++;
		}
	}

	//cout << counter << endl;

	float activation = pActivationFunction(sumOfVarianceValues);

	if (activation >= minActivationValue)
	{
		*pOutActivationvalue = activation;
		returnValue = true;
	}


	return returnValue;

}


bool C2DPatternDetectorV2::Check_For_Pattern(int32_t patternTestPosX, int32_t patternTestPosY, const float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, float activationValue, float minTolerance, float maxTolerance)
{
	float minActivationValue = activationValue + minTolerance;
	float maxActivationValue = activationValue + maxTolerance;

	if (SizeXDir == inputMapSizeX && SizeYDir == inputMapSizeY)
	{
		float inputValue, kernelValue, productValue, outputValue;

		float sumOfProductValues = 0.0f;

		for (uint32_t i = 0; i < Size; i++)
		{
			inputValue = pInputMap[i];
			kernelValue = pValueArray[i];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		if (sumOfProductValues < minActivationValue && sumOfProductValues > maxActivationValue)
			return false;
		else
			return true;
	}

	int32_t posArrayCounter = 0;

	int32_t halfKernelSizeX = SizeXDir / 2;
	int32_t halfKernelSizeY = SizeYDir / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	//int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t ixKernelMax = halfKernelSizeX;

	if (SizeXDir % 2 != 0)
		ixKernelMax++;

	int32_t iyKernelMin = -halfKernelSizeY;
	//int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t iyKernelMax = halfKernelSizeY;

	if (SizeYDir % 2 != 0)
		iyKernelMax++;

	int32_t ixInputMax = inputMapSizeX - halfKernelSizeX;
	int32_t iyInputMax = inputMapSizeY - halfKernelSizeY;

	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;
	int32_t kernelID;


	float inputValue, kernelValue, productValue, sumOfProductValues, outputValue;

	bool returnValue = false;

	/*int32_t iyInput = max(halfKernelSizeY, patternTestPosY);
	iyInput = min(iyInput, iyInputMax - 1);

	int32_t ixInput = max(halfKernelSizeX, patternTestPosX);
	ixInput = min(ixInput, ixInputMax - 1);*/

	int32_t iyInput = max(halfKernelSizeY, patternTestPosY);

	if (SizeYDir % 2 == 0)
		iyInput = min(iyInput, iyInputMax);
	else
		iyInput = min(iyInput, iyInputMax - 1);

	int32_t ixInput = max(halfKernelSizeX, patternTestPosX);

	if (SizeXDir % 2 == 0)
		ixInput = min(ixInput, ixInputMax);
	else
		ixInput = min(ixInput, ixInputMax - 1);

	sumOfProductValues = 0.0f;

	for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
	{
		iiyInput = (iyInput + iyKernel) * inputMapSizeX;
		iiyKernel = (iyKernel + halfKernelSizeY) * SizeXDir;

		for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
		{
			inputValue = pInputMap[ixInput + ixKernel + iiyInput];

			kernelID = ixKernel + halfKernelSizeX + iiyKernel;

			kernelValue = pValueArray[kernelID];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}
	}

	if (sumOfProductValues >= minActivationValue && sumOfProductValues <= maxActivationValue)
		returnValue = true;

	return returnValue;
}

bool C2DPatternDetectorV2::Check_For_Pattern_RBF(int32_t patternTestPosX, int32_t patternTestPosY, const float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, pSimpleActivationFunc pActivationFunction, float activationValue, float minTolerance, float maxTolerance)
{
	float minActivationValue = activationValue + minTolerance;
	float maxActivationValue = activationValue + maxTolerance;

	if (SizeXDir == inputMapSizeX && SizeYDir == inputMapSizeY)
	{
		float inputValue, varianceValue, outputValue;

		float sumOfVarianceValues = 0.0f;

		for (uint32_t i = 0; i < Size; i++)
		{
			inputValue = pInputMap[i];
			varianceValue = pUsed_RBF_CentroidValueArray[i] - inputValue;
			varianceValue *= varianceValue;
			varianceValue *= pUsed_RBF_FactorArray[i];
			sumOfVarianceValues += varianceValue;
		}

		float activation = pActivationFunction(sumOfVarianceValues);

		if (activation < minActivationValue && activation > maxActivationValue)
			return false;
		else
			return true;
	}

	int32_t posArrayCounter = 0;

	int32_t halfKernelSizeX = SizeXDir / 2;
	int32_t halfKernelSizeY = SizeYDir / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	//int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t ixKernelMax = halfKernelSizeX;

	if (SizeXDir % 2 != 0)
		ixKernelMax++;

	int32_t iyKernelMin = -halfKernelSizeY;
	//int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t iyKernelMax = halfKernelSizeY;

	if (SizeYDir % 2 != 0)
		iyKernelMax++;

	int32_t ixInputMax = inputMapSizeX - halfKernelSizeX;
	int32_t iyInputMax = inputMapSizeY - halfKernelSizeY;

	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;
	int32_t kernelID;


	float inputValue, varianceValue, sumOfVarianceValues, outputValue;

	bool returnValue = false;

	/*int32_t iyInput = max(halfKernelSizeY, patternTestPosY);
	iyInput = min(iyInput, iyInputMax - 1);

	int32_t ixInput = max(halfKernelSizeX, patternTestPosX);
	ixInput = min(ixInput, ixInputMax - 1);*/

	int32_t iyInput = max(halfKernelSizeY, patternTestPosY);

	if (SizeYDir % 2 == 0)
		iyInput = min(iyInput, iyInputMax);
	else
		iyInput = min(iyInput, iyInputMax - 1);

	int32_t ixInput = max(halfKernelSizeX, patternTestPosX);

	if (SizeXDir % 2 == 0)
		ixInput = min(ixInput, ixInputMax);
	else
		ixInput = min(ixInput, ixInputMax - 1);

	sumOfVarianceValues = 0.0f;

	for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
	{
		iiyInput = (iyInput + iyKernel) * inputMapSizeX;
		iiyKernel = (iyKernel + halfKernelSizeY) * SizeXDir;

		for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
		{
			inputValue = pInputMap[ixInput + ixKernel + iiyInput];

			kernelID = ixKernel + halfKernelSizeX + iiyKernel;

			varianceValue = pUsed_RBF_CentroidValueArray[kernelID] - inputValue;
			varianceValue *= varianceValue;
			varianceValue *= pUsed_RBF_FactorArray[kernelID];
			sumOfVarianceValues += varianceValue;
		}
	}

	float activation = pActivationFunction(sumOfVarianceValues);

	if (activation >= minActivationValue && activation <= maxActivationValue)
		returnValue = true;

	return returnValue;
}

bool C2DPatternDetectorV2::Check_For_Pattern(float *pOutActivationvalue, int32_t patternTestPosX, int32_t patternTestPosY, const float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, float activationValue, float minTolerance, float maxTolerance)
{
	float minActivationValue = activationValue + minTolerance;
	float maxActivationValue = activationValue + maxTolerance;

	if (SizeXDir == inputMapSizeX && SizeYDir == inputMapSizeY)
	{
		float inputValue, kernelValue, productValue, outputValue;

		float sumOfProductValues = 0.0f;

		for (uint32_t i = 0; i < Size; i++)
		{
			inputValue = pInputMap[i];
			kernelValue = pValueArray[i];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		if (sumOfProductValues < minActivationValue && sumOfProductValues > maxActivationValue)
		{
			*pOutActivationvalue = 0.0f;
			return false;
		}
		else
		{
			*pOutActivationvalue = sumOfProductValues;
			return true;
		}
	}

	int32_t posArrayCounter = 0;

	int32_t halfKernelSizeX = SizeXDir / 2;
	int32_t halfKernelSizeY = SizeYDir / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	//int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t ixKernelMax = halfKernelSizeX;

	if (SizeXDir % 2 != 0)
		ixKernelMax++;

	int32_t iyKernelMin = -halfKernelSizeY;
	//int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t iyKernelMax = halfKernelSizeY;

	if (SizeYDir % 2 != 0)
		iyKernelMax++;

	int32_t ixInputMax = inputMapSizeX - halfKernelSizeX;
	int32_t iyInputMax = inputMapSizeY - halfKernelSizeY;

	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;
	int32_t kernelID;


	float inputValue, kernelValue, productValue, sumOfProductValues, outputValue;

	*pOutActivationvalue = 0.0f;
	bool returnValue = false;

	/*int32_t iyInput = max(halfKernelSizeY, patternTestPosY);
	iyInput = min(iyInput, iyInputMax - 1);

	int32_t ixInput = max(halfKernelSizeX, patternTestPosX);
	ixInput = min(ixInput, ixInputMax - 1);*/

	int32_t iyInput = max(halfKernelSizeY, patternTestPosY);

	if (SizeYDir % 2 == 0)
		iyInput = min(iyInput, iyInputMax);
	else
		iyInput = min(iyInput, iyInputMax - 1);

	int32_t ixInput = max(halfKernelSizeX, patternTestPosX);

	if (SizeXDir % 2 == 0)
		ixInput = min(ixInput, ixInputMax);
	else
		ixInput = min(ixInput, ixInputMax - 1);

	sumOfProductValues = 0.0f;

	for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
	{
		iiyInput = (iyInput + iyKernel) * inputMapSizeX;
		iiyKernel = (iyKernel + halfKernelSizeY) * SizeXDir;

		for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
		{
			inputValue = pInputMap[ixInput + ixKernel + iiyInput];

			kernelID = ixKernel + halfKernelSizeX + iiyKernel;

			kernelValue = pValueArray[kernelID];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}
	}

	if (sumOfProductValues >= minActivationValue && sumOfProductValues <= maxActivationValue)
	{
		*pOutActivationvalue = sumOfProductValues;
		returnValue = true;
	}

	return returnValue;
}

bool C2DPatternDetectorV2::Check_For_Pattern_RBF(float *pOutActivationvalue, int32_t patternTestPosX, int32_t patternTestPosY, const float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, pSimpleActivationFunc pActivationFunction, float activationValue, float minTolerance, float maxTolerance)
{
	float minActivationValue = activationValue + minTolerance;
	float maxActivationValue = activationValue + maxTolerance;

	if (SizeXDir == inputMapSizeX && SizeYDir == inputMapSizeY)
	{
		float inputValue, varianceValue, outputValue;

		float sumOfVarianceValues = 0.0f;

		for (uint32_t i = 0; i < Size; i++)
		{
			inputValue = pInputMap[i];
			varianceValue = pUsed_RBF_CentroidValueArray[i] - inputValue;
			varianceValue *= varianceValue;
			varianceValue *= pUsed_RBF_FactorArray[i];
			sumOfVarianceValues += varianceValue;
		}

		float activation = pActivationFunction(sumOfVarianceValues);

		if (activation < minActivationValue && activation > maxActivationValue)
		{
			*pOutActivationvalue = 0.0f;
			return false;
		}
		else
		{
			*pOutActivationvalue = activation;
			return true;
		}
	}

	int32_t posArrayCounter = 0;

	int32_t halfKernelSizeX = SizeXDir / 2;
	int32_t halfKernelSizeY = SizeYDir / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	//int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t ixKernelMax = halfKernelSizeX;

	if (SizeXDir % 2 != 0)
		ixKernelMax++;

	int32_t iyKernelMin = -halfKernelSizeY;
	//int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t iyKernelMax = halfKernelSizeY;

	if (SizeYDir % 2 != 0)
		iyKernelMax++;

	int32_t ixInputMax = inputMapSizeX - halfKernelSizeX;
	int32_t iyInputMax = inputMapSizeY - halfKernelSizeY;

	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;
	int32_t kernelID;


	float inputValue, varianceValue, sumOfVarianceValues, outputValue;

	*pOutActivationvalue = 0.0f;
	bool returnValue = false;

	/*int32_t iyInput = max(halfKernelSizeY, patternTestPosY);
	iyInput = min(iyInput, iyInputMax - 1);

	int32_t ixInput = max(halfKernelSizeX, patternTestPosX);
	ixInput = min(ixInput, ixInputMax - 1);*/

	int32_t iyInput = max(halfKernelSizeY, patternTestPosY);

	if (SizeYDir % 2 == 0)
		iyInput = min(iyInput, iyInputMax);
	else
		iyInput = min(iyInput, iyInputMax - 1);

	int32_t ixInput = max(halfKernelSizeX, patternTestPosX);

	if (SizeXDir % 2 == 0)
		ixInput = min(ixInput, ixInputMax);
	else
		ixInput = min(ixInput, ixInputMax - 1);

	sumOfVarianceValues = 0.0f;

	for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
	{
		iiyInput = (iyInput + iyKernel) * inputMapSizeX;
		iiyKernel = (iyKernel + halfKernelSizeY) * SizeXDir;

		for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
		{
			inputValue = pInputMap[ixInput + ixKernel + iiyInput];

			kernelID = ixKernel + halfKernelSizeX + iiyKernel;

			varianceValue = pUsed_RBF_CentroidValueArray[kernelID] - inputValue;
			varianceValue *= varianceValue;
			varianceValue *= pUsed_RBF_FactorArray[kernelID];
			sumOfVarianceValues += varianceValue;
		}
	}

	float activation = pActivationFunction(sumOfVarianceValues);

	if (activation >= minActivationValue && activation <= maxActivationValue)
	{
		*pOutActivationvalue = activation;
		returnValue = true;
	}

	return returnValue;
}

bool C2DPatternDetectorV2::Search_Pattern(int32_t *pOutPatternCount, int32_t *pOutPatternPosXArray, int32_t *pOutPatternPosYArray, int32_t maxPosArrayElements, const float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, float minActivationValue)
{
	*pOutPatternCount = 0;


	if (SizeXDir == inputMapSizeX && SizeYDir == inputMapSizeY)
	{
		float inputValue, kernelValue, productValue, outputValue;

		float sumOfProductValues = 0.0f;

		for (uint32_t i = 0; i < Size; i++)
		{
			inputValue = pInputMap[i];
			kernelValue = pValueArray[i];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		if (sumOfProductValues < minActivationValue)
			return false;
		else
		{
			pOutPatternPosXArray[0] = SizeXDir / 2;
			pOutPatternPosYArray[0] = SizeYDir / 2;
			*pOutPatternCount = 1;
			return true;
		}
	}

	int32_t posArrayCounter = 0;

	int32_t halfKernelSizeX = SizeXDir / 2;
	int32_t halfKernelSizeY = SizeYDir / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	//int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t ixKernelMax = halfKernelSizeX;

	if (SizeXDir % 2 != 0)
		ixKernelMax++;

	int32_t iyKernelMin = -halfKernelSizeY;
	//int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t iyKernelMax = halfKernelSizeY;

	if (SizeYDir % 2 != 0)
		iyKernelMax++;

	//int32_t ixInputMax = inputMapSizeX - halfKernelSizeX;
	//int32_t iyInputMax = inputMapSizeY - halfKernelSizeY;

	int32_t ixInputMax = inputMapSizeX - halfKernelSizeX;

	if (SizeXDir % 2 == 0)
		ixInputMax++;

	int32_t iyInputMax = inputMapSizeY - halfKernelSizeY;

	if (SizeYDir % 2 == 0)
		iyInputMax++;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;
	int32_t kernelID;


	float inputValue, kernelValue, productValue, sumOfProductValues, outputValue;

	bool returnValue = false;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = 0.0f;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputMapSizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * SizeXDir;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputMap[ixInput + ixKernel + iiyInput];

					kernelID = ixKernel + halfKernelSizeX + iiyKernel;

					kernelValue = pValueArray[kernelID];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			if (sumOfProductValues >= minActivationValue)
			{
				returnValue = true;

				*pOutPatternCount += 1;

				pOutPatternPosXArray[posArrayCounter] = ixInput;
				pOutPatternPosYArray[posArrayCounter] = iyInput;

				posArrayCounter++;

				if (posArrayCounter >= maxPosArrayElements)
					return returnValue;
			}
		}
	}


	return returnValue;
}

bool C2DPatternDetectorV2::Search_Pattern_RBF(int32_t *pOutPatternCount, int32_t *pOutPatternPosXArray, int32_t *pOutPatternPosYArray, int32_t maxPosArrayElements, const float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, pSimpleActivationFunc pActivationFunction, float minActivationValue)
{
	*pOutPatternCount = 0;


	if (SizeXDir == inputMapSizeX && SizeYDir == inputMapSizeY)
	{
		float inputValue, varianceValue, outputValue;

		float sumOfVarianceValues = 0.0f;

		for (uint32_t i = 0; i < Size; i++)
		{
			inputValue = pInputMap[i];
			
			varianceValue = pUsed_RBF_CentroidValueArray[i] - inputValue;
			varianceValue *= varianceValue;
			varianceValue *= pUsed_RBF_FactorArray[i];
			sumOfVarianceValues += varianceValue;
		}

		float activation = pActivationFunction(sumOfVarianceValues);

		if (activation < minActivationValue)
			return false;
		else
		{
			pOutPatternPosXArray[0] = SizeXDir / 2;
			pOutPatternPosYArray[0] = SizeYDir / 2;
			*pOutPatternCount = 1;
			return true;
		}
	}

	int32_t posArrayCounter = 0;

	int32_t halfKernelSizeX = SizeXDir / 2;
	int32_t halfKernelSizeY = SizeYDir / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	//int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t ixKernelMax = halfKernelSizeX;

	if (SizeXDir % 2 != 0)
		ixKernelMax++;

	int32_t iyKernelMin = -halfKernelSizeY;
	//int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t iyKernelMax = halfKernelSizeY;

	if (SizeYDir % 2 != 0)
		iyKernelMax++;

	int32_t ixInputMax = inputMapSizeX - halfKernelSizeX;

	if (SizeXDir % 2 == 0)
		ixInputMax++;

	int32_t iyInputMax = inputMapSizeY - halfKernelSizeY;

	if (SizeYDir % 2 == 0)
		iyInputMax++;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;
	int32_t kernelID;


	float inputValue, varianceValue, sumOfVarianceValues, outputValue;

	bool returnValue = false;

	//int32_t counter = 0;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfVarianceValues = 0.0f;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputMapSizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * SizeXDir;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputMap[ixInput + ixKernel + iiyInput];

					kernelID = ixKernel + halfKernelSizeX + iiyKernel;

					varianceValue = pUsed_RBF_CentroidValueArray[kernelID] - inputValue;
					varianceValue *= varianceValue;
					varianceValue *= pUsed_RBF_FactorArray[kernelID];
					sumOfVarianceValues += varianceValue;

					//counter++;
				}
			}

			float activation = pActivationFunction(sumOfVarianceValues);

			if (activation >= minActivationValue)
			{
				returnValue = true;

				*pOutPatternCount += 1;

				pOutPatternPosXArray[posArrayCounter] = ixInput;
				pOutPatternPosYArray[posArrayCounter] = iyInput;

				posArrayCounter++;

				if (posArrayCounter >= maxPosArrayElements)
				{
					//cout << counter << endl;
					return returnValue;
				}
			}
		}
	}

	//cout << counter << endl;


	return returnValue;
}

bool C2DPatternDetectorV2::Search_Pattern(int32_t *pOutPatternCount, int32_t *pOutPatternPosXArray, int32_t *pOutPatternPosYArray, int32_t maxPosArrayElements, const float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, float activationValue, float minTolerance, float maxTolerance)
{
	*pOutPatternCount = 0;

	float minActivationValue = activationValue + minTolerance;
	float maxActivationValue = activationValue + maxTolerance;

	if (SizeXDir == inputMapSizeX && SizeYDir == inputMapSizeY)
	{
		float inputValue, kernelValue, productValue, outputValue;

		float sumOfProductValues = 0.0f;

		for (uint32_t i = 0; i < Size; i++)
		{
			inputValue = pInputMap[i];
			kernelValue = pValueArray[i];

			productValue = inputValue * kernelValue;
			sumOfProductValues += productValue;
		}

		if (sumOfProductValues < minActivationValue && sumOfProductValues > maxActivationValue)
			return false;
		else
		{
			pOutPatternPosXArray[0] = SizeXDir / 2;
			pOutPatternPosYArray[0] = SizeYDir / 2;
			*pOutPatternCount = 1;
			return true;
		}
	}

	int32_t posArrayCounter = 0;

	int32_t halfKernelSizeX = SizeXDir / 2;
	int32_t halfKernelSizeY = SizeYDir / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	//int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t ixKernelMax = halfKernelSizeX;

	if (SizeXDir % 2 != 0)
		ixKernelMax++;

	int32_t iyKernelMin = -halfKernelSizeY;
	//int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t iyKernelMax = halfKernelSizeY;

	if (SizeYDir % 2 != 0)
		iyKernelMax++;

	//int32_t ixInputMax = inputMapSizeX - halfKernelSizeX;
	//int32_t iyInputMax = inputMapSizeY - halfKernelSizeY;

	int32_t ixInputMax = inputMapSizeX - halfKernelSizeX;

	if (SizeXDir % 2 == 0)
		ixInputMax++;

	int32_t iyInputMax = inputMapSizeY - halfKernelSizeY;

	if (SizeYDir % 2 == 0)
		iyInputMax++;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;
	int32_t kernelID;


	float inputValue, kernelValue, productValue, sumOfProductValues, outputValue;

	bool returnValue = false;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfProductValues = 0.0f;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputMapSizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * SizeXDir;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputMap[ixInput + ixKernel + iiyInput];

					kernelID = ixKernel + halfKernelSizeX + iiyKernel;

					kernelValue = pValueArray[kernelID];

					productValue = inputValue * kernelValue;
					sumOfProductValues += productValue;
				}
			}

			if (sumOfProductValues >= minActivationValue && sumOfProductValues <= maxActivationValue)
			{
				returnValue = true;

				*pOutPatternCount += 1;

				pOutPatternPosXArray[posArrayCounter] = ixInput;
				pOutPatternPosYArray[posArrayCounter] = iyInput;

				posArrayCounter++;

				if (posArrayCounter >= maxPosArrayElements)
					return returnValue;
			}
		}
	}


	return returnValue;
}

bool C2DPatternDetectorV2::Search_Pattern_RBF(int32_t *pOutPatternCount, int32_t *pOutPatternPosXArray, int32_t *pOutPatternPosYArray, int32_t maxPosArrayElements, const float *pInputMap, int32_t inputMapSizeX, int32_t inputMapSizeY, int32_t strideX, int32_t strideY, pSimpleActivationFunc pActivationFunction, float activationValue, float minTolerance, float maxTolerance)
{
	*pOutPatternCount = 0;

	float minActivationValue = activationValue + minTolerance;
	float maxActivationValue = activationValue + maxTolerance;

	if (SizeXDir == inputMapSizeX && SizeYDir == inputMapSizeY)
	{
		float inputValue, varianceValue, outputValue;

		float sumOfVarianceValues = 0.0f;

		for (uint32_t i = 0; i < Size; i++)
		{
			inputValue = pInputMap[i];
			
			varianceValue = pUsed_RBF_CentroidValueArray[i] - inputValue;
			varianceValue *= varianceValue;
			varianceValue *= pUsed_RBF_FactorArray[i];
			sumOfVarianceValues += varianceValue;
		}

		float activation = pActivationFunction(sumOfVarianceValues);

		if (activation < minActivationValue && activation > maxActivationValue)
			return false;
		else
		{
			pOutPatternPosXArray[0] = SizeXDir / 2;
			pOutPatternPosYArray[0] = SizeYDir / 2;
			*pOutPatternCount = 1;
			return true;
		}
	}

	int32_t posArrayCounter = 0;

	int32_t halfKernelSizeX = SizeXDir / 2;
	int32_t halfKernelSizeY = SizeYDir / 2;

	int32_t ixKernelMin = -halfKernelSizeX;
	//int32_t ixKernelMax = halfKernelSizeX + 1;

	int32_t ixKernelMax = halfKernelSizeX;

	if (SizeXDir % 2 != 0)
		ixKernelMax++;

	int32_t iyKernelMin = -halfKernelSizeY;
	//int32_t iyKernelMax = halfKernelSizeY + 1;

	int32_t iyKernelMax = halfKernelSizeY;

	if (SizeYDir % 2 != 0)
		iyKernelMax++;

	//int32_t ixInputMax = inputMapSizeX - halfKernelSizeX;
	//int32_t iyInputMax = inputMapSizeY - halfKernelSizeY;

	int32_t ixInputMax = inputMapSizeX - halfKernelSizeX;

	if (SizeXDir % 2 == 0)
		ixInputMax++;

	int32_t iyInputMax = inputMapSizeY - halfKernelSizeY;

	if (SizeYDir % 2 == 0)
		iyInputMax++;

	int32_t ixInput, iyInput;
	int32_t ixKernel, iyKernel;

	int32_t iiyInput, iiyKernel;
	int32_t kernelID;


	float inputValue, varianceValue, sumOfVarianceValues, outputValue;

	bool returnValue = false;

	for (iyInput = halfKernelSizeY; iyInput < iyInputMax; iyInput += strideY)
	{
		for (ixInput = halfKernelSizeX; ixInput < ixInputMax; ixInput += strideX)
		{
			sumOfVarianceValues = 0.0f;

			for (iyKernel = iyKernelMin; iyKernel < iyKernelMax; iyKernel++)
			{
				iiyInput = (iyInput + iyKernel) * inputMapSizeX;
				iiyKernel = (iyKernel + halfKernelSizeY) * SizeXDir;

				for (ixKernel = ixKernelMin; ixKernel < ixKernelMax; ixKernel++)
				{
					inputValue = pInputMap[ixInput + ixKernel + iiyInput];

					kernelID = ixKernel + halfKernelSizeX + iiyKernel;

					varianceValue = pUsed_RBF_CentroidValueArray[kernelID] - inputValue;
					varianceValue *= varianceValue;
					varianceValue *= pUsed_RBF_FactorArray[kernelID];
					sumOfVarianceValues += varianceValue;
				}
			}

			float activation = pActivationFunction(sumOfVarianceValues);

			if (activation >= minActivationValue && activation <= maxActivationValue)
			{
				returnValue = true;

				*pOutPatternCount += 1;

				pOutPatternPosXArray[posArrayCounter] = ixInput;
				pOutPatternPosYArray[posArrayCounter] = iyInput;

				posArrayCounter++;

				if (posArrayCounter >= maxPosArrayElements)
					return returnValue;
			}
		}
	}


	return returnValue;
}

CNeuralNetPopulationV2::CNeuralNetPopulationV2()
{}

CNeuralNetPopulationV2::~CNeuralNetPopulationV2()
{
	delete[] pFitnessScoreArray;
	pFitnessScoreArray = nullptr;

	delete[] ppUsedNeuralNetArray;
	ppUsedNeuralNetArray = nullptr;
}

void CNeuralNetPopulationV2::Set_NeuralNet(CNeuralNetV2 *pNeuralNet, int32_t id)
{
	ppUsedNeuralNetArray[id] = pNeuralNet;
}

bool CNeuralNetPopulationV2::Initialize(uint32_t populationSize)
{
	int32_t minPopulationSize = constNumOfBestFittedBrains + constNumOfWorstFittedBrains + constNumOfAdditionalBrains + 10;

	//if (populationSize < minPopulationSize)
		//populationSize = minPopulationSize;

	for (int32_t i = 0; i < constNumOfBestFittedBrains; i++)
	{
		IDArrayOfBestFittedBrains[i] = 0;
		FitnessArrayOfBestFittedBrains[i] = 0.0f;
	}

	for (int32_t i = 0; i < constNumOfWorstFittedBrains; i++)
	{
		IDArrayOfWorstFittedBrains[i] = 0;
		FitnessArrayOfWorstFittedBrains[i] = 0.0f;
	}

	UseAdditionalMutatedBestBrain = false;
	UseAdditionalMutatedSecondBestBrain = false;
	UseAdditionalBestBrainsChild = false;

	RandomBrainsChildCounter = 0;

	for (int32_t i = 0; i < constNumOfRandomBrainsChilds; i++)
		UseAdditionalRandomBrainsChild[i] = false;

	delete[] pFitnessScoreArray;
	pFitnessScoreArray = nullptr;

	delete[] ppUsedNeuralNetArray;
	ppUsedNeuralNetArray = nullptr;

	PopulationSizePlusX = populationSize;
	PopulationSize = PopulationSizePlusX - constNumOfAdditionalBrains;

	pFitnessScoreArray = new (std::nothrow) float[PopulationSizePlusX];
	ppUsedNeuralNetArray = new (std::nothrow) CNeuralNetV2*[PopulationSizePlusX];

	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFitnessScoreArray[i] = 0.0f;
		ppUsedNeuralNetArray[i] = nullptr;
	}

	if (populationSize < minPopulationSize)
		return false;

	return true;
}



void CNeuralNetPopulationV2::Change_Seed(uint64_t seed)
{
	RandomNumbers.Change_Seed(seed);
}

void CNeuralNetPopulationV2::Reset_MinErrorSum_ActualGeneration(float value)
{
	MinErrorSum_ActualGeneration = value;
}

void CNeuralNetPopulationV2::Update_MinErrorSum_ActualGeneration(float value)
{
	if (value < MinErrorSum_ActualGeneration)
		MinErrorSum_ActualGeneration = value;
}

void CNeuralNetPopulationV2::Round_SynapticPlasticities(float precision)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->Round_SynapticPlasticities(precision);
	}
}

void CNeuralNetPopulationV2::Round_Dendrite_Values(float precision)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->Round_Dendrite_Values(precision);
	}
}

void CNeuralNetPopulationV2::Round_Dendrite_CentroidValues(float precision)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->Round_Dendrite_CentroidValues(precision);
	}
}

void CNeuralNetPopulationV2::Round_Dendrite_Factors(float precision)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->Round_Dendrite_Factors(precision);
	}
}

void CNeuralNetPopulationV2::Randomize_OutputSynapsePlasticities(uint64_t seed, float minValue, float maxValue)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->Randomize_OutputSynapsePlasticities(seed++, minValue, maxValue);
	}
}

void CNeuralNetPopulationV2::Modify_OutputSynapsePlasticities(uint64_t seed, float minValue, float maxValue)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->Modify_OutputSynapsePlasticities(seed++, minValue, maxValue);
	}
}

void CNeuralNetPopulationV2::Randomize_OutputSynapsePlasticities(uint64_t seed, int32_t neuronID, float minValue, float maxValue)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->Randomize_OutputSynapsePlasticities(seed++, neuronID, minValue, maxValue);
	}
}

void CNeuralNetPopulationV2::Modify_OutputSynapsePlasticities(uint64_t seed, int32_t neuronID, float minValue, float maxValue)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->Modify_OutputSynapsePlasticities(seed++, neuronID, minValue, maxValue);
	}
}

void CNeuralNetPopulationV2::Randomize_OutputSynapsePlasticities(uint64_t seed, int32_t firstNeuronID, int32_t lastNeuronID, float minValue, float maxValue)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->Randomize_OutputSynapsePlasticities(seed++, firstNeuronID, lastNeuronID, minValue, maxValue);
	}
}

void CNeuralNetPopulationV2::Modify_OutputSynapsePlasticities(uint64_t seed, int32_t firstNeuronID, int32_t lastNeuronID, float minValue, float maxValue)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->Modify_OutputSynapsePlasticities(seed++, firstNeuronID, lastNeuronID, minValue, maxValue);
	}
}

void CNeuralNetPopulationV2::Randomize_OutputSynapsePlasticities(uint64_t seed, float minValue, float maxValue, float mutationRate)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->Randomize_OutputSynapsePlasticities(seed++, minValue, maxValue, mutationRate);
	}
}

void CNeuralNetPopulationV2::Modify_OutputSynapsePlasticities(uint64_t seed, float minValue, float maxValue, float mutationRate)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->Modify_OutputSynapsePlasticities(seed++, minValue, maxValue, mutationRate);
	}
}

void CNeuralNetPopulationV2::Randomize_OutputSynapsePlasticities(uint64_t seed, int32_t neuronID, float minValue, float maxValue, float mutationRate)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->Randomize_OutputSynapsePlasticities(seed++, neuronID, minValue, maxValue, mutationRate);
	}
}

void CNeuralNetPopulationV2::Modify_OutputSynapsePlasticities(uint64_t seed, int32_t neuronID, float minValue, float maxValue, float mutationRate)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->Modify_OutputSynapsePlasticities(seed++, neuronID, minValue, maxValue, mutationRate);
	}
}

void CNeuralNetPopulationV2::Randomize_OutputSynapsePlasticities(uint64_t seed, int32_t firstNeuronID, int32_t lastNeuronID, float minValue, float maxValue, float mutationRate)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->Randomize_OutputSynapsePlasticities(seed++, firstNeuronID, lastNeuronID, minValue, maxValue, mutationRate);
	}
}

void CNeuralNetPopulationV2::Modify_OutputSynapsePlasticities(uint64_t seed, int32_t firstNeuronID, int32_t lastNeuronID, float minValue, float maxValue, float mutationRate)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->Modify_OutputSynapsePlasticities(seed++, firstNeuronID, lastNeuronID, minValue, maxValue, mutationRate);
	}
}

void CNeuralNetPopulationV2::Randomize_OutputSynapsePlasticities(float minValue, float maxValue)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->Randomize_OutputSynapsePlasticities(minValue, maxValue);
	}
}


void CNeuralNetPopulationV2::Reinitialize_Dendrite_Values(pNeuralNetV2ReinitializationFunc pFunc, void *pParam)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFunc(ppUsedNeuralNetArray[i], pParam);
	}
}

void CNeuralNetPopulationV2::Mutate_Dendrite_Values(pNeuralNetV2MutationFunc pFunc, void *pParam)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFunc(ppUsedNeuralNetArray[i], pParam);
	}
}

void CNeuralNetPopulationV2::Reinitialize_Dendrite_Values(uint64_t seed, pNeuralNetV2ReinitializationFunc pFunc, void *pParam)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->RandomNumbers.Change_Seed(seed++);
		pFunc(ppUsedNeuralNetArray[i], pParam);
	}
}

void CNeuralNetPopulationV2::Mutate_Dendrite_Values(uint64_t seed, pNeuralNetV2MutationFunc pFunc, void *pParam)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->RandomNumbers.Change_Seed(seed++);
		pFunc(ppUsedNeuralNetArray[i], pParam);
	}
}

void CNeuralNetPopulationV2::Randomize_Dendrite_Values(float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->Randomize_Dendrite_Values(minCentroidValue, maxCentroidValue, minFactor, maxFactor);
	}
}



void CNeuralNetPopulationV2::Randomize_Dendrite_Values(uint64_t seed, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->Randomize_Dendrite_Values(seed++, minCentroidValue, maxCentroidValue, minFactor, maxFactor);
	}
}


void CNeuralNetPopulationV2::Randomize_Dendrite_Values(int32_t neuronID, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->Randomize_Dendrite_Values(neuronID, minCentroidValue, maxCentroidValue, minFactor, maxFactor);
	}
}

void CNeuralNetPopulationV2::Modify_Dendrite_Values(int32_t neuronID, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->Modify_Dendrite_Values(neuronID, minCentroidValueVariance, maxCentroidValueVariance, minFactorVariance, maxFactorVariance);
	}
}

void CNeuralNetPopulationV2::Modify_Dendrite_Values(uint64_t seed, int32_t neuronID, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->Modify_Dendrite_Values(seed++, neuronID, minCentroidValueVariance, maxCentroidValueVariance, minFactorVariance, maxFactorVariance);
	}
}

void CNeuralNetPopulationV2::Modify_Dendrite_Values(float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->Modify_Dendrite_Values(minCentroidValueVariance, maxCentroidValueVariance, minFactorVariance, maxFactorVariance);
	}
}

void CNeuralNetPopulationV2::Modify_Dendrite_Values(uint64_t seed, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->Modify_Dendrite_Values(seed++, minCentroidValueVariance, maxCentroidValueVariance, minFactorVariance, maxFactorVariance);
	}
}

void CNeuralNetPopulationV2::Randomize_Dendrite_Values(uint64_t seed, int32_t neuronID, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->Randomize_Dendrite_Values(seed++, neuronID, minCentroidValue, maxCentroidValue, minFactor, maxFactor);
	}
}

void CNeuralNetPopulationV2::Randomize_Dendrite_Values(int32_t neuronID, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor, float mutationRate)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->Randomize_Dendrite_Values(neuronID, minCentroidValue, maxCentroidValue, minFactor, maxFactor, mutationRate);
	}
}

void CNeuralNetPopulationV2::Modify_Dendrite_Values(int32_t neuronID, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance, float mutationRate)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->Modify_Dendrite_Values(neuronID, minCentroidValueVariance, maxCentroidValueVariance, minFactorVariance, maxFactorVariance, mutationRate);
	}
}

void CNeuralNetPopulationV2::Modify_Dendrite_Values(uint64_t seed, int32_t neuronID, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance, float mutationRate)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->Modify_Dendrite_Values(seed++, neuronID, minCentroidValueVariance, maxCentroidValueVariance, minFactorVariance, maxFactorVariance, mutationRate);
	}
}

void CNeuralNetPopulationV2::Randomize_Dendrite_Values(uint64_t seed, int32_t neuronID, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor, float mutationRate)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->Randomize_Dendrite_Values(seed++, neuronID, minCentroidValue, maxCentroidValue, minFactor, maxFactor, mutationRate);
	}
}


void CNeuralNetPopulationV2::Randomize_Dendrite_Values(float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor, float mutationRate)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->Randomize_Dendrite_Values(minCentroidValue, maxCentroidValue, minFactor, maxFactor, mutationRate);
	}
}

void CNeuralNetPopulationV2::Modify_Dendrite_Values(float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance, float mutationRate)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->Modify_Dendrite_Values(minCentroidValueVariance, maxCentroidValueVariance, minFactorVariance, maxFactorVariance, mutationRate);
	}
}

void CNeuralNetPopulationV2::Modify_Dendrite_Values(uint64_t seed, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance, float mutationRate)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->Modify_Dendrite_Values(seed++, minCentroidValueVariance, maxCentroidValueVariance, minFactorVariance, maxFactorVariance, mutationRate);
	}
}

void CNeuralNetPopulationV2::Randomize_Dendrite_Values(uint64_t seed, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor, float mutationRate)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->Randomize_Dendrite_Values(seed++, minCentroidValue, maxCentroidValue, minFactor, maxFactor, mutationRate);
	}
}

void CNeuralNetPopulationV2::Modify_OutputSynapsePlasticities(float minValue, float maxValue)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->Modify_OutputSynapsePlasticities(minValue, maxValue);
	}
}

void CNeuralNetPopulationV2::Randomize_OutputSynapsePlasticities(int32_t neuronID, float minValue, float maxValue)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->Randomize_OutputSynapsePlasticities(neuronID, minValue, maxValue);
	}
}

void CNeuralNetPopulationV2::Modify_OutputSynapsePlasticities(int32_t neuronID, float minValue, float maxValue)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->Modify_OutputSynapsePlasticities(neuronID, minValue, maxValue);
	}
}

void CNeuralNetPopulationV2::Randomize_OutputSynapsePlasticities(int32_t firstNeuronID, int32_t lastNeuronID, float minValue, float maxValue)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->Randomize_OutputSynapsePlasticities(firstNeuronID, lastNeuronID, minValue, maxValue);
	}
}

void CNeuralNetPopulationV2::Modify_OutputSynapsePlasticities(int32_t firstNeuronID, int32_t lastNeuronID, float minValue, float maxValue)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->Modify_OutputSynapsePlasticities(firstNeuronID, lastNeuronID, minValue, maxValue);
	}
}

void CNeuralNetPopulationV2::Randomize_OutputSynapsePlasticities(float minValue, float maxValue, float mutationRate)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->Randomize_OutputSynapsePlasticities(minValue, maxValue, mutationRate);
	}
}

void CNeuralNetPopulationV2::Modify_OutputSynapsePlasticities(float minValue, float maxValue, float mutationRate)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->Modify_OutputSynapsePlasticities(minValue, maxValue, mutationRate);
	}
}

void CNeuralNetPopulationV2::Randomize_OutputSynapsePlasticities(int32_t neuronID, float minValue, float maxValue, float mutationRate)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->Randomize_OutputSynapsePlasticities(neuronID, minValue, maxValue, mutationRate);
	}
}

void CNeuralNetPopulationV2::Modify_OutputSynapsePlasticities(int32_t neuronID, float minValue, float maxValue, float mutationRate)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->Modify_OutputSynapsePlasticities(neuronID, minValue, maxValue, mutationRate);
	}
}

void CNeuralNetPopulationV2::Randomize_OutputSynapsePlasticities(int32_t firstNeuronID, int32_t lastNeuronID, float minValue, float maxValue, float mutationRate)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->Randomize_OutputSynapsePlasticities(firstNeuronID, lastNeuronID, minValue, maxValue, mutationRate);
	}
}

void CNeuralNetPopulationV2::Modify_OutputSynapsePlasticities(int32_t firstNeuronID, int32_t lastNeuronID, float minValue, float maxValue, float mutationRate)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppUsedNeuralNetArray[i]->Modify_OutputSynapsePlasticities(firstNeuronID, lastNeuronID, minValue, maxValue, mutationRate);
	}
}

CNeuralNetV2* CNeuralNetPopulationV2::Get_Best_Evolved_NeuralNet(void)
{
	return ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[0]];
}

void CNeuralNetPopulationV2::Get_Best_Evolved_NeuralNet(CNeuralNetV2* pOutNeuralNet)
{
	pOutNeuralNet->Clone(ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[0]]);
}

void CNeuralNetPopulationV2::Update_BaseEvolution(pNeuralNetV2MutationFunc pFunc, void *pParam)
{
	bool bestFittedBrains;
	int32_t j;

	for (int32_t i = 0; i < PopulationSize; i++)
	{
		bestFittedBrains = false;

		for (int32_t j = 0; j < constNumOfBestFittedBrains; j++)
		{
			if (i == IDArrayOfBestFittedBrains[j])
			{
				bestFittedBrains = true;
				break;
			}
		}

		if (bestFittedBrains == false)
		{
			pFunc(ppUsedNeuralNetArray[i], pParam);
		}
	}
}

void CNeuralNetPopulationV2::Update_Evolution_Combine_TwoBrains(pNeuralNetV2RecombinationFunc pFunc, void *pParam)
{
	if (UseAdditionalRandomBrainsChild[RandomBrainsChildCounter] == true)
		return;

	int32_t id1, id2;

	for (int32_t i = 0; i < constNumPopulationSearchStepsMax; i++)
	{
		id1 = RandomNumbers.Get_IntegerNumber(0, PopulationSize);

		// die am schlechtesten angepassten Individuen d�rfen sich nicht vermehren:
		if (pFitnessScoreArray[id1] <= FitnessArrayOfWorstFittedBrains[constNumOfWorstFittedBrains - 1])
			continue;

		id2 = RandomNumbers.Get_IntegerNumber(0, PopulationSize);

		// die am schlechtesten angepassten Individuen d�rfen sich nicht vermehren:
		if (pFitnessScoreArray[id2] <= FitnessArrayOfWorstFittedBrains[constNumOfWorstFittedBrains - 1])
			continue;

		if (id1 == id2)
			continue;

		pFunc(ppUsedNeuralNetArray[PopulationSize + 3 + RandomBrainsChildCounter], ppUsedNeuralNetArray[id1], ppUsedNeuralNetArray[id2], pParam);

		UseAdditionalRandomBrainsChild[RandomBrainsChildCounter] = true;

		if (RandomBrainsChildCounter < constNumOfRandomBrainsChilds - 1)
			RandomBrainsChildCounter++;

		break;
	}
}

void CNeuralNetPopulationV2::Update_Evolution_Combine_BestTwoBrains(pNeuralNetV2RecombinationFunc pFunc, void *pParam)
{
	if (UseAdditionalBestBrainsChild == true)
		return;

	pFunc(ppUsedNeuralNetArray[PopulationSize + 2], ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[0]], ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[1]], pParam);

	UseAdditionalBestBrainsChild = true;
}

void CNeuralNetPopulationV2::Update_Evolution_BestBrainOnly(pNeuralNetV2MutationFunc pFunc, void *pParam)
{
	if (UseAdditionalMutatedBestBrain == true)
		return;

	ppUsedNeuralNetArray[PopulationSize]->Clone_Data(ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[0]]);
	pFunc(ppUsedNeuralNetArray[PopulationSize], pParam);
	
	UseAdditionalMutatedBestBrain = true;
}

void CNeuralNetPopulationV2::Update_Evolution_SecondBestBrainOnly(pNeuralNetV2MutationFunc pFunc, void *pParam)
{
	if (UseAdditionalMutatedSecondBestBrain == true)
		return;

	ppUsedNeuralNetArray[PopulationSize + 1]->Clone_Data(ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[1]]);
	pFunc(ppUsedNeuralNetArray[PopulationSize + 1], pParam);

	UseAdditionalMutatedSecondBestBrain = true;
}

void CNeuralNetPopulationV2::Replace_WorstFitted_Brain(pNeuralNetV2ReinitializationFunc pFunc, void *pParam)
{
	pFunc(ppUsedNeuralNetArray[IDArrayOfWorstFittedBrains[0]], pParam);
}

void CNeuralNetPopulationV2::Replace_SecondWorstFitted_Brain(pNeuralNetV2ReinitializationFunc pFunc, void *pParam)
{
	pFunc(ppUsedNeuralNetArray[IDArrayOfWorstFittedBrains[1]], pParam);
}

void CNeuralNetPopulationV2::Replace_ThirdWorstFitted_Brain(pNeuralNetV2ReinitializationFunc pFunc, void *pParam)
{
	pFunc(ppUsedNeuralNetArray[IDArrayOfWorstFittedBrains[2]], pParam);
}

void CNeuralNetPopulationV2::Learning(int32_t neuralNetID, float learningRate, float learningRateVariance, float errorFactor1, float errorFactor2)
{
	if (neuralNetID >= PopulationSize)
		return;

	if (neuralNetID == IDArrayOfBestFittedBrains[0])
		return;

	ppUsedNeuralNetArray[neuralNetID]->Adjust_OutputSynapses(Get_Best_Evolved_NeuralNet(), learningRate, learningRateVariance, errorFactor1, errorFactor2);
}

void CNeuralNetPopulationV2::Learning(int32_t neuralNetID)
{
	if (neuralNetID >= PopulationSize)
		return;

	if (neuralNetID == IDArrayOfBestFittedBrains[0])
		return;

	ppUsedNeuralNetArray[neuralNetID]->Adjust_OutputSynapses(Get_Best_Evolved_NeuralNet());
}

void CNeuralNetPopulationV2::Update_Population(float *pFitnessValueArray)
{
	if (pFitnessValueArray != nullptr)
	{
		for (int32_t i = 0; i < PopulationSizePlusX; i++)
		{
			pFitnessScoreArray[i] = pFitnessValueArray[i];
		}
	}

	for (int32_t i = 0; i < constNumOfBestFittedBrains; i++)
	{
		IDArrayOfBestFittedBrains[i] = 0;
		FitnessArrayOfBestFittedBrains[i] = -100000000.0f;
	}

	for (int32_t i = 0; i < constNumOfWorstFittedBrains; i++)
	{
		IDArrayOfWorstFittedBrains[i] = 0;
		FitnessArrayOfWorstFittedBrains[i] = 100000000.0f;
	}

	for (int32_t i = 0; i < PopulationSize; i++)
	{
		for (int32_t j = 0; j < constNumOfBestFittedBrains; j++)
		{
			if (pFitnessScoreArray[i] > FitnessArrayOfBestFittedBrains[j])
			{
				for (uint32_t k = constNumOfBestFittedBrains - 1; k > j; k--)
				{
					IDArrayOfBestFittedBrains[k] = IDArrayOfBestFittedBrains[k - 1];
					FitnessArrayOfBestFittedBrains[k] = FitnessArrayOfBestFittedBrains[k - 1];
				}

				FitnessArrayOfBestFittedBrains[j] = pFitnessScoreArray[i];
				IDArrayOfBestFittedBrains[j] = i;

				break;
			}
		}

		for (int32_t j = 0; j < constNumOfWorstFittedBrains; j++)
		{
			if (pFitnessScoreArray[i] < FitnessArrayOfWorstFittedBrains[j])
			{
				for (int32_t k = constNumOfWorstFittedBrains - 1; k > j; k--)
				{
					IDArrayOfWorstFittedBrains[k] = IDArrayOfWorstFittedBrains[k - 1];
					FitnessArrayOfWorstFittedBrains[k] = FitnessArrayOfWorstFittedBrains[k - 1];
				}

				FitnessArrayOfWorstFittedBrains[j] = pFitnessScoreArray[i];
				IDArrayOfWorstFittedBrains[j] = i;

				break;
			}
		}

	} // end of for (int32_t i = 0; i < PopulationSize; i++)


	 //HelperStuff::Add_To_Log(0, "best fitness", pFitnessScoreArray[IDArrayOfBestFittedBrains[0]]);

	float fitnessScoreOfBestFittedAdditionalBrain = -1000000.0f;
	int32_t idOfBestFittedAdditionalBrain = 0;

	for (int32_t i = 0; i < constNumOfAdditionalBrains; i++)
	{
		if (pFitnessScoreArray[PopulationSize + i] > fitnessScoreOfBestFittedAdditionalBrain)
		{
			fitnessScoreOfBestFittedAdditionalBrain = pFitnessScoreArray[PopulationSize + i];
			idOfBestFittedAdditionalBrain = PopulationSize + i;
		}
	}

	/*for (int32_t i = constNumOfBestFittedBrains - 1; i > -1; i--)
	{
		if (pFitnessScoreArray[idOfBestFittedAdditionalBrain] > pFitnessScoreArray[IDArrayOfBestFittedBrains[i]])
		{
			ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[i]]->Clone_Data(ppUsedNeuralNetArray[idOfBestFittedAdditionalBrain]);
			break;
		}
	}*/

	if (pFitnessScoreArray[idOfBestFittedAdditionalBrain] > pFitnessScoreArray[IDArrayOfBestFittedBrains[0]])
	{
		ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[0]]->Clone_Data(ppUsedNeuralNetArray[idOfBestFittedAdditionalBrain]);
	}
	else if (pFitnessScoreArray[idOfBestFittedAdditionalBrain] > pFitnessScoreArray[IDArrayOfBestFittedBrains[1]])
	{
		ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[1]]->Clone_Data(ppUsedNeuralNetArray[idOfBestFittedAdditionalBrain]);
	}
	else if (pFitnessScoreArray[idOfBestFittedAdditionalBrain] > pFitnessScoreArray[IDArrayOfBestFittedBrains[2]])
	{
		ppUsedNeuralNetArray[IDArrayOfBestFittedBrains[2]]->Clone_Data(ppUsedNeuralNetArray[idOfBestFittedAdditionalBrain]);
	}

	UseAdditionalMutatedBestBrain = false;
	UseAdditionalMutatedSecondBestBrain = false;
	UseAdditionalBestBrainsChild = false;

	RandomBrainsChildCounter = 0;

	for (int32_t i = 0; i < constNumOfRandomBrainsChilds; i++)
		UseAdditionalRandomBrainsChild[i] = false;
}


CDendriteNeuronPopulation::CDendriteNeuronPopulation()
{
	for (int32_t i = 0; i < constNumOfBestFittedBrains; i++)
	{
		IDArrayOfBestFittedBrains[i] = 0;
		FitnessArrayOfBestFittedBrains[i] = 0.0f;
	}

	for (int32_t i = 0; i < constNumOfWorstFittedBrains; i++)
	{
		IDArrayOfWorstFittedBrains[i] = 0;
		FitnessArrayOfWorstFittedBrains[i] = 0.0f;
	}

}

CDendriteNeuronPopulation::~CDendriteNeuronPopulation()
{
	delete[] pFitnessScoreArray;
	pFitnessScoreArray = nullptr;

	delete[] ppNeuronArray;
	ppNeuronArray = nullptr;
}

CNeuronV2* CDendriteNeuronPopulation::Get_Best_Evolved_Neuron(void)
{
	return ppNeuronArray[IDArrayOfBestFittedBrains[0]];
}

void CDendriteNeuronPopulation::Get_Best_Evolved_Neuron(CNeuronV2* pOutNeuron)
{
	pOutNeuron->Clone(ppNeuronArray[IDArrayOfBestFittedBrains[0]]);
}

void CDendriteNeuronPopulation::Change_Seed(uint64_t seed)
{
	Seed = seed;
}

void CDendriteNeuronPopulation::Reset_MinErrorSum_ActualGeneration(float value)
{
	MinErrorSum_ActualGeneration = value;
}

void CDendriteNeuronPopulation::Update_MinErrorSum_ActualGeneration(float value)
{
	if (value < MinErrorSum_ActualGeneration)
		MinErrorSum_ActualGeneration = value;
}

void CDendriteNeuronPopulation::Set_ActivationFunction(pActivationFuncV2 pFunc)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Set_ActivationFunction(pFunc);
	}
}

void CDendriteNeuronPopulation::Set_DendriticFunction(pDendriticFuncV2 pFunc)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Set_DendriticFunction(pFunc);
	}
}

void CDendriteNeuronPopulation::Set_Neuron(CNeuronV2 *pNeuron, int32_t id)
{
	ppNeuronArray[id] = pNeuron;
}

bool CDendriteNeuronPopulation::Initialize(int32_t populationSize)
{
	int32_t minPopulationSize = constNumOfBestFittedBrains + constNumOfWorstFittedBrains + constNumOfAdditionalBrains + 10;

	//if (populationSize < minPopulationSize)
		//populationSize = minPopulationSize;

	for (int32_t i = 0; i < constNumOfBestFittedBrains; i++)
	{
		IDArrayOfBestFittedBrains[i] = 0;
		FitnessArrayOfBestFittedBrains[i] = 0.0f;
	}

	for (int32_t i = 0; i < constNumOfWorstFittedBrains; i++)
	{
		IDArrayOfWorstFittedBrains[i] = 0;
		FitnessArrayOfWorstFittedBrains[i] = 0.0f;
	}

	UseAdditionalMutatedBestBrain = false;
	UseAdditionalMutatedSecondBestBrain = false;
	UseAdditionalBestBrainsChild = false;

	RandomBrainsChildCounter = 0;

	for(int32_t i = 0; i < constNumOfRandomBrainsChilds; i++)
		UseAdditionalRandomBrainsChild[i] = false;

	delete[] pFitnessScoreArray;
	pFitnessScoreArray = nullptr;

	delete[] ppNeuronArray;
	ppNeuronArray = nullptr;

	PopulationSizePlusX = populationSize;
	PopulationSize = PopulationSizePlusX - constNumOfAdditionalBrains;

	//PopulationSize = populationSize;
	//PopulationSizePlusX = populationSize + constNumOfAdditionalBrains;

	pFitnessScoreArray = new (std::nothrow) float[PopulationSizePlusX];
	ppNeuronArray = new (std::nothrow) CNeuronV2*[PopulationSizePlusX];

	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFitnessScoreArray[i] = 0.0f;
		ppNeuronArray[i] = nullptr;
	}

	if (populationSize < minPopulationSize)
		return false;
	
	return true;
}

void CDendriteNeuronPopulation::Select_UsedDendrites(int32_t minID, int32_t numDendrites)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
		ppNeuronArray[i]->Select_UsedDendrites(minID, numDendrites);
}

void CDendriteNeuronPopulation::Init_Or_Reinitialize_Dendrite_Arrays(int32_t num_Of_Dendrite_Elements)
{
	for (int32_t i = 0; i < constNumOfBestFittedBrains; i++)
	{
		IDArrayOfBestFittedBrains[i] = 0;
		FitnessArrayOfBestFittedBrains[i] = 0.0f;
	}

	for (int32_t i = 0; i < constNumOfWorstFittedBrains; i++)
	{
		IDArrayOfWorstFittedBrains[i] = 0;
		FitnessArrayOfWorstFittedBrains[i] = 0.0f;
	}

	UseAdditionalMutatedBestBrain = false;
	UseAdditionalMutatedSecondBestBrain = false;
	UseAdditionalBestBrainsChild = false;

	RandomBrainsChildCounter = 0;

	for (int32_t i = 0; i < constNumOfRandomBrainsChilds; i++)
		UseAdditionalRandomBrainsChild[i] = false;
	

	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFitnessScoreArray[i] = 0.0f;
		ppNeuronArray[i]->Init_Dendrite_Arrays(num_Of_Dendrite_Elements);
	}
}

void CDendriteNeuronPopulation::Set_Dendrite_Data(float *pDendrite_CentroidValueArray, float *pDendrite_FactorArray)
{
	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Set_Dendrite_Data(pDendrite_CentroidValueArray, pDendrite_FactorArray);
	}
}

void CDendriteNeuronPopulation::Set_Dendrite_CentroidValues(float *pDendrite_CentroidValueArray)
{
	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Set_Dendrite_CentroidValues(pDendrite_CentroidValueArray);
	}
}

void CDendriteNeuronPopulation::Set_Dendrite_Factors(float *pDendrite_FactorArray)
{
	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Set_Dendrite_Factors(pDendrite_FactorArray);
	}
}

void CDendriteNeuronPopulation::Round_Dendrite_Values(float precision)
{
	float invPrecision = 1.0f / precision;

	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
		ppNeuronArray[i]->Round_Dendrite_Values(precision, invPrecision);
}

void CDendriteNeuronPopulation::Round_Dendrite_Values(float precision, int32_t minVectorElement, int32_t maxVectorElement)
{
	float invPrecision = 1.0f / precision;

	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
		ppNeuronArray[i]->Round_Dendrite_Values(precision, invPrecision, minVectorElement, maxVectorElement);
}

void CDendriteNeuronPopulation::Round_Dendrite_CentroidValues(float precision)
{
	float invPrecision = 1.0f / precision;

	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
		ppNeuronArray[i]->Round_Dendrite_CentroidValues(precision, invPrecision);
}

void CDendriteNeuronPopulation::Round_Dendrite_CentroidValues(float precision, int32_t minVectorElement, int32_t maxVectorElement)
{
	float invPrecision = 1.0f / precision;

	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
		ppNeuronArray[i]->Round_Dendrite_CentroidValues(precision, invPrecision, minVectorElement, maxVectorElement);
}

void CDendriteNeuronPopulation::Round_Dendrite_Factors(float precision)
{
	float invPrecision = 1.0f / precision;

	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
		ppNeuronArray[i]->Round_Dendrite_Factors(precision, invPrecision);
}

void CDendriteNeuronPopulation::Round_Dendrite_Factors(float precision, int32_t minVectorElement, int32_t maxVectorElement)
{
	float invPrecision = 1.0f / precision;

	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
		ppNeuronArray[i]->Round_Dendrite_Factors(precision, invPrecision, minVectorElement, maxVectorElement);
}


void CDendriteNeuronPopulation::Permute_Dendrite_Values(int32_t minVectorElement, int32_t maxVectorElement, int32_t permutationSteps)
{
	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Permute_Dendrite_Values(&RandomNumbers, minVectorElement, maxVectorElement, permutationSteps);
	}
}

void CDendriteNeuronPopulation::Permute_Dendrite_CentroidValues(int32_t minVectorElement, int32_t maxVectorElement, int32_t permutationSteps)
{
	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Permute_Dendrite_CentroidValues(&RandomNumbers, minVectorElement, maxVectorElement, permutationSteps);
	}
}

void CDendriteNeuronPopulation::Permute_Dendrite_Factors(int32_t minVectorElement, int32_t maxVectorElement, int32_t permutationSteps)
{
	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Permute_Dendrite_Factors(&RandomNumbers, minVectorElement, maxVectorElement, permutationSteps);
	}
}

void CDendriteNeuronPopulation::Permute_Dendrite_Values(uint64_t seed, int32_t minVectorElement, int32_t maxVectorElement, int32_t permutationSteps)
{
	RandomNumbers.Change_Seed(seed);

	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Permute_Dendrite_Values(&RandomNumbers, minVectorElement, maxVectorElement, permutationSteps);
	}
}

void CDendriteNeuronPopulation::Permute_Dendrite_CentroidValues(uint64_t seed, int32_t minVectorElement, int32_t maxVectorElement, int32_t permutationSteps)
{
	RandomNumbers.Change_Seed(seed);

	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Permute_Dendrite_CentroidValues(&RandomNumbers, minVectorElement, maxVectorElement, permutationSteps);
	}
}

void CDendriteNeuronPopulation::Permute_Dendrite_Factors(uint64_t seed, int32_t minVectorElement, int32_t maxVectorElement, int32_t permutationSteps)
{
	RandomNumbers.Change_Seed(seed);

	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Permute_Dendrite_Factors(&RandomNumbers, minVectorElement, maxVectorElement, permutationSteps);
	}
}

/*void CDendriteNeuronPopulation::Randomize_RBF_CentroidValues(float minValue, float maxValue)
{
	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pNeuronArray[i].Randomize_RBF_CentroidValues(&RandomNumbers, minValue, maxValue);
	}
}*/

/*void CDendriteNeuronPopulation::Randomize_RBF_Factors(float minValue, float maxValue)
{
	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pNeuronArray[i].Randomize_RBF_Factors(&RandomNumbers, minValue, maxValue);
	}
}*/

void CDendriteNeuronPopulation::Replace_WorstFitted_Brain(pReinitializationFunc pFunc, void *pParam)
{
	pFunc(ppNeuronArray[IDArrayOfWorstFittedBrains[0]], &RandomNumbers, pParam);
}

void CDendriteNeuronPopulation::Replace_SecondWorstFitted_Brain(pReinitializationFunc pFunc, void *pParam)
{
	pFunc(ppNeuronArray[IDArrayOfWorstFittedBrains[1]], &RandomNumbers, pParam);
}

void CDendriteNeuronPopulation::Replace_ThirdWorstFitted_Brain(pReinitializationFunc pFunc, void *pParam)
{
	pFunc(ppNeuronArray[IDArrayOfWorstFittedBrains[2]], &RandomNumbers, pParam);
}

void CDendriteNeuronPopulation::Replace_WorstFitted_Brain(uint64_t seed, pReinitializationFunc pFunc, void *pParam)
{
	RandomNumbers.Change_Seed(seed);
	pFunc(ppNeuronArray[IDArrayOfWorstFittedBrains[0]], &RandomNumbers, pParam);
}

void CDendriteNeuronPopulation::Replace_SecondWorstFitted_Brain(uint64_t seed, pReinitializationFunc pFunc, void *pParam)
{
	RandomNumbers.Change_Seed(seed);
	pFunc(ppNeuronArray[IDArrayOfWorstFittedBrains[1]], &RandomNumbers, pParam);
}

void CDendriteNeuronPopulation::Replace_ThirdWorstFitted_Brain(uint64_t seed, pReinitializationFunc pFunc, void *pParam)
{
	RandomNumbers.Change_Seed(seed);
	pFunc(ppNeuronArray[IDArrayOfWorstFittedBrains[2]], &RandomNumbers, pParam);
}


void CDendriteNeuronPopulation::Reinitialize_Dendrite_Values(pReinitializationFunc pFunc, void *pParam)
{
	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFunc(ppNeuronArray[i], &RandomNumbers, pParam);
	}
}

void CDendriteNeuronPopulation::Reinitialize_Dendrite_Values(uint64_t seed, pReinitializationFunc pFunc, void *pParam)
{
	RandomNumbers.Change_Seed(seed);

	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFunc(ppNeuronArray[i], &RandomNumbers, pParam);
	}
}

void CDendriteNeuronPopulation::Mutate_Dendrite_Values(pMutationFunc pFunc, void *pParam)
{
	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFunc(ppNeuronArray[i], &RandomNumbers, pParam);
	}
}

void CDendriteNeuronPopulation::Mutate_Dendrite_Values(uint64_t seed, pMutationFunc pFunc, void *pParam)
{
	RandomNumbers.Change_Seed(seed);

	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFunc(ppNeuronArray[i], &RandomNumbers, pParam);
	}
}


void CDendriteNeuronPopulation::Randomize_Dendrite_Values(float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor)
{
	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Randomize_Dendrite_Values(&RandomNumbers, minCentroidValue, maxCentroidValue, minFactor, maxFactor);
	}
}

void CDendriteNeuronPopulation::Randomize_Dendrite_Values(int32_t minVectorElement, int32_t maxVectorElement, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor)
{
	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Randomize_Dendrite_Values(&RandomNumbers, minVectorElement, maxVectorElement, minCentroidValue, maxCentroidValue, minFactor, maxFactor);
	}
}

void CDendriteNeuronPopulation::Randomize_Dendrite_Factors(int32_t minVectorElement, int32_t maxVectorElement, float minValue, float maxValue)
{
	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Randomize_Dendrite_Factors(&RandomNumbers, minVectorElement, maxVectorElement, minValue, maxValue);
	}
}

void CDendriteNeuronPopulation::Randomize_Dendrite_CentroidValues(int32_t minVectorElement, int32_t maxVectorElement, float minValue, float maxValue)
{
	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Randomize_Dendrite_CentroidValues(&RandomNumbers, minVectorElement, maxVectorElement, minValue, maxValue);
	}
}

void CDendriteNeuronPopulation::Randomize_Dendrite_Factors(int32_t minVectorElement, int32_t maxVectorElement, float minValue, float maxValue, float mutationRate)
{
	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Randomize_Dendrite_Factors(&RandomNumbers, minVectorElement, maxVectorElement, minValue, maxValue, mutationRate);
	}
}

void  CDendriteNeuronPopulation::Randomize_Dendrite_CentroidValues(int32_t minVectorElement, int32_t maxVectorElement, float minValue, float maxValue, float mutationRate)
{
	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Randomize_Dendrite_CentroidValues(&RandomNumbers, minVectorElement, maxVectorElement, minValue, maxValue, mutationRate);
	}
}

void CDendriteNeuronPopulation::Randomize_Dendrite_Factors(uint64_t seed, int32_t minVectorElement, int32_t maxVectorElement, float minValue, float maxValue, float mutationRate)
{
	RandomNumbers.Change_Seed(seed);

	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Randomize_Dendrite_Factors(&RandomNumbers, minVectorElement, maxVectorElement, minValue, maxValue, mutationRate);
	}
}

void CDendriteNeuronPopulation::Randomize_Dendrite_CentroidValues(uint64_t seed, int32_t minVectorElement, int32_t maxVectorElement, float minValue, float maxValue, float mutationRate)
{
	RandomNumbers.Change_Seed(seed);

	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Randomize_Dendrite_CentroidValues(&RandomNumbers, minVectorElement, maxVectorElement, minValue, maxValue, mutationRate);
	}
}

void CDendriteNeuronPopulation::Randomize_Dendrite_Factors(uint64_t seed, int32_t minVectorElement, int32_t maxVectorElement, float minValue, float maxValue)
{
	RandomNumbers.Change_Seed(seed);

	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Randomize_Dendrite_Factors(&RandomNumbers, minVectorElement, maxVectorElement, minValue, maxValue);
	}
}

void CDendriteNeuronPopulation::Randomize_Dendrite_CentroidValues(uint64_t seed, int32_t minVectorElement, int32_t maxVectorElement, float minValue, float maxValue)
{
	RandomNumbers.Change_Seed(seed);

	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Randomize_Dendrite_CentroidValues(&RandomNumbers, minVectorElement, maxVectorElement, minValue, maxValue);
	}
}

void CDendriteNeuronPopulation::Randomize_Dendrite_Values(int32_t minVectorElement, int32_t maxVectorElement, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor, float mutationRate)
{
	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Randomize_Dendrite_Values(&RandomNumbers, minVectorElement, maxVectorElement, minCentroidValue, maxCentroidValue, minFactor, maxFactor, mutationRate);
	}
}

void CDendriteNeuronPopulation::Randomize_Dendrite_Values(uint64_t seed, int32_t minVectorElement, int32_t maxVectorElement, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor)
{
	RandomNumbers.Change_Seed(seed);

	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Randomize_Dendrite_Values(&RandomNumbers, minVectorElement, maxVectorElement, minCentroidValue, maxCentroidValue, minFactor, maxFactor);
	}
}

void CDendriteNeuronPopulation::Randomize_Dendrite_Values(uint64_t seed, int32_t minVectorElement, int32_t maxVectorElement, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor, float mutationRate)
{
	RandomNumbers.Change_Seed(seed);

	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Randomize_Dendrite_Values(&RandomNumbers, minVectorElement, maxVectorElement, minCentroidValue, maxCentroidValue, minFactor, maxFactor, mutationRate);
	}
}

void CDendriteNeuronPopulation::Randomize_Dendrite_Factors(float minValue, float maxValue)
{
	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Randomize_Dendrite_Factors(&RandomNumbers, minValue, maxValue);
	}
}

void CDendriteNeuronPopulation::Randomize_Dendrite_CentroidValues(float minValue, float maxValue)
{
	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Randomize_Dendrite_CentroidValues(&RandomNumbers, minValue, maxValue);
	}
}


void CDendriteNeuronPopulation::Modify_Dendrite_Values(float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance)
{
	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Modify_Dendrite_Values(&RandomNumbers, minCentroidValueVariance, maxCentroidValueVariance, minFactorVariance, maxFactorVariance);
	}
}

void CDendriteNeuronPopulation::Modify_Dendrite_Factors(float minVariance, float maxVariance)
{
	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Modify_Dendrite_Factors(&RandomNumbers, minVariance, maxVariance);
	}
}

void CDendriteNeuronPopulation::Modify_Dendrite_CentroidValues(float minVariance, float maxVariance)
{
	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Modify_Dendrite_CentroidValues(&RandomNumbers, minVariance, maxVariance);
	}
}

void CDendriteNeuronPopulation::Modify_Dendrite_Factors(int32_t minVectorElement, int32_t maxVectorElement, float minVariance, float maxVariance)
{
	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Modify_Dendrite_Factors(&RandomNumbers, minVectorElement, maxVectorElement, minVariance, maxVariance);
	}
}

void CDendriteNeuronPopulation::Modify_Dendrite_CentroidValues(int32_t minVectorElement, int32_t maxVectorElement, float minVariance, float maxVariance)
{
	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Modify_Dendrite_CentroidValues(&RandomNumbers, minVectorElement, maxVectorElement, minVariance, maxVariance);
	}
}

void CDendriteNeuronPopulation::Modify_Dendrite_Factors(float minVariance, float maxVariance, float mutationRate)
{
	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Modify_Dendrite_Factors(&RandomNumbers, minVariance, maxVariance, mutationRate);
	}
}

void CDendriteNeuronPopulation::Modify_Dendrite_CentroidValues(float minVariance, float maxVariance, float mutationRate)
{
	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Modify_Dendrite_CentroidValues(&RandomNumbers, minVariance, maxVariance, mutationRate);
	}
}

void CDendriteNeuronPopulation::Modify_Dendrite_Factors(int32_t minVectorElement, int32_t maxVectorElement, float minVariance, float maxVariance, float mutationRate)
{
	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Modify_Dendrite_Factors(&RandomNumbers, minVectorElement, maxVectorElement, minVariance, maxVariance, mutationRate);
	}
}

void CDendriteNeuronPopulation::Modify_Dendrite_CentroidValues(int32_t minVectorElement, int32_t maxVectorElement, float minVariance, float maxVariance, float mutationRate)
{
	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Modify_Dendrite_CentroidValues(&RandomNumbers, minVectorElement, maxVectorElement, minVariance, maxVariance, mutationRate);
	}
}

void CDendriteNeuronPopulation::Modify_Dendrite_Factors(uint64_t seed, float minVariance, float maxVariance)
{
	RandomNumbers.Change_Seed(seed);

	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Modify_Dendrite_Factors(&RandomNumbers, minVariance, maxVariance);
	}
}

void CDendriteNeuronPopulation::Modify_Dendrite_CentroidValues(uint64_t seed, float minVariance, float maxVariance)
{
	RandomNumbers.Change_Seed(seed);

	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Modify_Dendrite_CentroidValues(&RandomNumbers, minVariance, maxVariance);
	}
}

void CDendriteNeuronPopulation::Modify_Dendrite_Factors(uint64_t seed, int32_t minVectorElement, int32_t maxVectorElement, float minVariance, float maxVariance)
{
	RandomNumbers.Change_Seed(seed);

	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Modify_Dendrite_Factors(&RandomNumbers, minVectorElement, maxVectorElement, minVariance, maxVariance);
	}
}

void CDendriteNeuronPopulation::Modify_Dendrite_CentroidValues(uint64_t seed, int32_t minVectorElement, int32_t maxVectorElement, float minVariance, float maxVariance)
{
	RandomNumbers.Change_Seed(seed);

	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Modify_Dendrite_CentroidValues(&RandomNumbers, minVectorElement, maxVectorElement, minVariance, maxVariance);
	}
}

void CDendriteNeuronPopulation::Modify_Dendrite_Factors(uint64_t seed, float minVariance, float maxVariance, float mutationRate)
{
	RandomNumbers.Change_Seed(seed);

	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Modify_Dendrite_Factors(&RandomNumbers, minVariance, maxVariance, mutationRate);
	}
}

void CDendriteNeuronPopulation::Modify_Dendrite_CentroidValues(uint64_t seed, float minVariance, float maxVariance, float mutationRate)
{
	RandomNumbers.Change_Seed(seed);

	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Modify_Dendrite_CentroidValues(&RandomNumbers, minVariance, maxVariance, mutationRate);
	}
}

void CDendriteNeuronPopulation::Modify_Dendrite_Factors(uint64_t seed, int32_t minVectorElement, int32_t maxVectorElement, float minVariance, float maxVariance, float mutationRate)
{
	RandomNumbers.Change_Seed(seed);

	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Modify_Dendrite_Factors(&RandomNumbers, minVectorElement, maxVectorElement, minVariance, maxVariance, mutationRate);
	}
}

void CDendriteNeuronPopulation::Modify_Dendrite_CentroidValues(uint64_t seed, int32_t minVectorElement, int32_t maxVectorElement, float minVariance, float maxVariance, float mutationRate)
{
	RandomNumbers.Change_Seed(seed);

	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Modify_Dendrite_CentroidValues(&RandomNumbers, minVectorElement, maxVectorElement, minVariance, maxVariance, mutationRate);
	}
}

void CDendriteNeuronPopulation::Modify_Dendrite_Values(int32_t minVectorElement, int32_t maxVectorElement, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance)
{
	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Modify_Dendrite_Values(&RandomNumbers, minVectorElement, maxVectorElement, minCentroidValueVariance, maxCentroidValueVariance, minFactorVariance, maxFactorVariance);
	}
}

void CDendriteNeuronPopulation::Modify_Dendrite_Values(int32_t minVectorElement, int32_t maxVectorElement, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance, float mutationRate)
{
	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Modify_Dendrite_Values(&RandomNumbers, minVectorElement, maxVectorElement, minCentroidValueVariance, maxCentroidValueVariance, minFactorVariance, maxFactorVariance, mutationRate);
	}
}

void CDendriteNeuronPopulation::Modify_Dendrite_Values(uint64_t seed, int32_t minVectorElement, int32_t maxVectorElement, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance)
{
	RandomNumbers.Change_Seed(seed);

	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Modify_Dendrite_Values(&RandomNumbers, minVectorElement, maxVectorElement, minCentroidValueVariance, maxCentroidValueVariance, minFactorVariance, maxFactorVariance);
	}
}

void CDendriteNeuronPopulation::Modify_Dendrite_Values(uint64_t seed, int32_t minVectorElement, int32_t maxVectorElement, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance, float mutationRate)
{
	RandomNumbers.Change_Seed(seed);

	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Modify_Dendrite_Values(&RandomNumbers, minVectorElement, maxVectorElement, minCentroidValueVariance, maxCentroidValueVariance, minFactorVariance, maxFactorVariance, mutationRate);
	}
}

void CDendriteNeuronPopulation::Modify_Dendrite_Values(float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance, float mutationRate)
{
	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Modify_Dendrite_Values(&RandomNumbers, minCentroidValueVariance, maxCentroidValueVariance, minFactorVariance, maxFactorVariance, mutationRate);
	}
}

void CDendriteNeuronPopulation::Modify_Dendrite_Values(uint64_t seed, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance, float mutationRate)
{
	RandomNumbers.Change_Seed(seed);

	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Modify_Dendrite_Values(&RandomNumbers, minCentroidValueVariance, maxCentroidValueVariance, minFactorVariance, maxFactorVariance, mutationRate);
	}
}



void CDendriteNeuronPopulation::Modify_Dendrite_Values(uint64_t seed, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance)
{
	RandomNumbers.Change_Seed(seed);

	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Modify_Dendrite_Values(&RandomNumbers, minCentroidValueVariance, maxCentroidValueVariance, minFactorVariance, maxFactorVariance);
	}
}

void CDendriteNeuronPopulation::Randomize_Dendrite_Values(float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor, float mutationRate)
{
	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Randomize_Dendrite_Values(&RandomNumbers, minCentroidValue, maxCentroidValue, minFactor, maxFactor, mutationRate);
	}
}

void CDendriteNeuronPopulation::Randomize_Dendrite_Factors(float minValue, float maxValue, float mutationRate)
{
	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Randomize_Dendrite_Factors(&RandomNumbers, minValue, maxValue, mutationRate);
	}
}

void CDendriteNeuronPopulation::Randomize_Dendrite_CentroidValues(float minValue, float maxValue, float mutationRate)
{
	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Randomize_Dendrite_CentroidValues(&RandomNumbers, minValue, maxValue, mutationRate);
	}
}

void CDendriteNeuronPopulation::Randomize_Dendrite_Values(uint64_t seed, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor, float mutationRate)
{
	RandomNumbers.Change_Seed(seed);

	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Randomize_Dendrite_Values(&RandomNumbers, minCentroidValue, maxCentroidValue, minFactor, maxFactor, mutationRate);
	}
}

void CDendriteNeuronPopulation::Randomize_Dendrite_Factors(uint64_t seed, float minValue, float maxValue, float mutationRate)
{
	RandomNumbers.Change_Seed(seed);

	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Randomize_Dendrite_Factors(&RandomNumbers, minValue, maxValue, mutationRate);
	}
}

void CDendriteNeuronPopulation::Randomize_Dendrite_CentroidValues(uint64_t seed, float minValue, float maxValue, float mutationRate)
{
	RandomNumbers.Change_Seed(seed);

	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Randomize_Dendrite_CentroidValues(&RandomNumbers, minValue, maxValue, mutationRate);
	}
}

void CDendriteNeuronPopulation::Randomize_Dendrite_Values(uint64_t seed, float minCentroidValue, float maxCentroidValue, float minFactor, float maxFactor)
{
	RandomNumbers.Change_Seed(seed);

	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Randomize_Dendrite_Values(&RandomNumbers, minCentroidValue, maxCentroidValue, minFactor, maxFactor);
	}
}

void CDendriteNeuronPopulation::Randomize_Dendrite_Factors(uint64_t seed, float minValue, float maxValue)
{
	RandomNumbers.Change_Seed(seed);

	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Randomize_Dendrite_Factors(&RandomNumbers, minValue, maxValue);
	}
}

void CDendriteNeuronPopulation::Randomize_Dendrite_CentroidValues(uint64_t seed, float minValue, float maxValue)
{
	RandomNumbers.Change_Seed(seed);

	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		ppNeuronArray[i]->Randomize_Dendrite_CentroidValues(&RandomNumbers, minValue, maxValue);
	}
}



void CDendriteNeuronPopulation::Update_Evolution_BestBrainOnly(pMutationFunc pFunc, void *pParam)
{
	if (UseAdditionalMutatedBestBrain == true)
		return;

	ppNeuronArray[PopulationSize]->Clone_Dendrite_Data(ppNeuronArray[IDArrayOfBestFittedBrains[0]]);

	pFunc(ppNeuronArray[PopulationSize], &RandomNumbers, pParam);

	UseAdditionalMutatedBestBrain = true;
}

void CDendriteNeuronPopulation::Update_Evolution_BestBrainOnly_Dendrite_Values(float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance, float mutationRate)
{
	if (UseAdditionalMutatedBestBrain == true)
		return;

	ppNeuronArray[PopulationSize]->Clone_Dendrite_Data(ppNeuronArray[IDArrayOfBestFittedBrains[0]]);
	ppNeuronArray[PopulationSize]->Modify_Dendrite_Values(&RandomNumbers, minCentroidValueVariance, maxCentroidValueVariance, minFactorVariance, maxFactorVariance, mutationRate);

	UseAdditionalMutatedBestBrain = true;
}

void CDendriteNeuronPopulation::Update_Evolution_BestBrainOnly_Dendrite_Factors(float minVariance, float maxVariance, float mutationRate)
{
	if (UseAdditionalMutatedBestBrain == true)
		return;

	ppNeuronArray[PopulationSize]->Clone_Dendrite_Data(ppNeuronArray[IDArrayOfBestFittedBrains[0]]);
	ppNeuronArray[PopulationSize]->Modify_Dendrite_Factors(&RandomNumbers, minVariance, maxVariance, mutationRate);

	UseAdditionalMutatedBestBrain = true;
}

void CDendriteNeuronPopulation::Update_Evolution_BestBrainOnly_Dendrite_CentroidValues(float minVariance, float maxVariance, float mutationRate)
{
	if (UseAdditionalMutatedBestBrain == true)
		return;

	ppNeuronArray[PopulationSize]->Clone_Dendrite_Data(ppNeuronArray[IDArrayOfBestFittedBrains[0]]);
	ppNeuronArray[PopulationSize]->Modify_Dendrite_CentroidValues(&RandomNumbers, minVariance, maxVariance, mutationRate);

	UseAdditionalMutatedBestBrain = true;
}

void CDendriteNeuronPopulation::Update_Evolution_BestBrainOnly_Dendrite_Values(int32_t minVectorElement, int32_t maxVectorElement, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance, float mutationRate)
{
	if (UseAdditionalMutatedBestBrain == true)
		return;

	ppNeuronArray[PopulationSize]->Clone_Dendrite_Data(ppNeuronArray[IDArrayOfBestFittedBrains[0]]);
	ppNeuronArray[PopulationSize]->Modify_Dendrite_Values(&RandomNumbers, minVectorElement, maxVectorElement, minCentroidValueVariance, maxCentroidValueVariance, minFactorVariance, maxFactorVariance, mutationRate);

	UseAdditionalMutatedBestBrain = true;
}

void CDendriteNeuronPopulation::Update_Evolution_BestBrainOnly_Dendrite_Factors(int32_t minVectorElement, int32_t maxVectorElement, float minVariance, float maxVariance, float mutationRate)
{
	if (UseAdditionalMutatedBestBrain == true)
		return;

	ppNeuronArray[PopulationSize]->Clone_Dendrite_Data(ppNeuronArray[IDArrayOfBestFittedBrains[0]]);
	ppNeuronArray[PopulationSize]->Modify_Dendrite_Factors(&RandomNumbers, minVectorElement, maxVectorElement, minVariance, maxVariance, mutationRate);

	UseAdditionalMutatedBestBrain = true;
}

void CDendriteNeuronPopulation::Update_Evolution_BestBrainOnly_Dendrite_CentroidValues(int32_t minVectorElement, int32_t maxVectorElement, float minVariance, float maxVariance, float mutationRate)
{
	if (UseAdditionalMutatedBestBrain == true)
		return;

	ppNeuronArray[PopulationSize]->Clone_Dendrite_Data(ppNeuronArray[IDArrayOfBestFittedBrains[0]]);
	ppNeuronArray[PopulationSize]->Modify_Dendrite_CentroidValues(&RandomNumbers, minVectorElement, maxVectorElement, minVariance, maxVariance, mutationRate);

	UseAdditionalMutatedBestBrain = true;
}

void CDendriteNeuronPopulation::Update_Evolution_SecondBestBrainOnly(pMutationFunc pFunc, void *pParam)
{
	if (UseAdditionalMutatedSecondBestBrain == true)
		return;

	ppNeuronArray[PopulationSize + 1]->Clone_Dendrite_Data(ppNeuronArray[IDArrayOfBestFittedBrains[1]]);

	pFunc(ppNeuronArray[PopulationSize + 1], &RandomNumbers, pParam);

	UseAdditionalMutatedSecondBestBrain = true;
}

void CDendriteNeuronPopulation::Update_Evolution_SecondBestBrainOnly_Dendrite_Values(float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance, float mutationRate)
{
	if (UseAdditionalMutatedSecondBestBrain == true)
		return;

	ppNeuronArray[PopulationSize + 1]->Clone_Dendrite_Data(ppNeuronArray[IDArrayOfBestFittedBrains[1]]);
	ppNeuronArray[PopulationSize + 1]->Modify_Dendrite_Values(&RandomNumbers, minCentroidValueVariance, maxCentroidValueVariance, minFactorVariance, maxFactorVariance, mutationRate);

	UseAdditionalMutatedSecondBestBrain = true;
}

void CDendriteNeuronPopulation::Update_Evolution_SecondBestBrainOnly_Dendrite_Factors(float minVariance, float maxVariance, float mutationRate)
{
	if (UseAdditionalMutatedSecondBestBrain == true)
		return;

	ppNeuronArray[PopulationSize + 1]->Clone_Dendrite_Data(ppNeuronArray[IDArrayOfBestFittedBrains[1]]);
	ppNeuronArray[PopulationSize + 1]->Modify_Dendrite_Factors(&RandomNumbers, minVariance, maxVariance, mutationRate);

	UseAdditionalMutatedSecondBestBrain = true;
}

void CDendriteNeuronPopulation::Update_Evolution_SecondBestBrainOnly_Dendrite_CentroidValues(float minVariance, float maxVariance, float mutationRate)
{
	if (UseAdditionalMutatedSecondBestBrain == true)
		return;

	ppNeuronArray[PopulationSize + 1]->Clone_Dendrite_Data(ppNeuronArray[IDArrayOfBestFittedBrains[1]]);
	ppNeuronArray[PopulationSize + 1]->Modify_Dendrite_CentroidValues(&RandomNumbers, minVariance, maxVariance, mutationRate);

	UseAdditionalMutatedSecondBestBrain = true;
}

void CDendriteNeuronPopulation::Update_Evolution_SecondBestBrainOnly_Dendrite_Values(int32_t minVectorElement, int32_t maxVectorElement, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance, float mutationRate)
{
	if (UseAdditionalMutatedSecondBestBrain == true)
		return;

	ppNeuronArray[PopulationSize + 1]->Clone_Dendrite_Data(ppNeuronArray[IDArrayOfBestFittedBrains[1]]);
	ppNeuronArray[PopulationSize + 1]->Modify_Dendrite_Values(&RandomNumbers, minVectorElement, maxVectorElement, minCentroidValueVariance, maxCentroidValueVariance, minFactorVariance, maxFactorVariance, mutationRate);

	UseAdditionalMutatedSecondBestBrain = true;
}

void CDendriteNeuronPopulation::Update_Evolution_SecondBestBrainOnly_Dendrite_Factors(int32_t minVectorElement, int32_t maxVectorElement, float minVariance, float maxVariance, float mutationRate)
{
	if (UseAdditionalMutatedSecondBestBrain == true)
		return;

	ppNeuronArray[PopulationSize + 1]->Clone_Dendrite_Data(ppNeuronArray[IDArrayOfBestFittedBrains[1]]);
	ppNeuronArray[PopulationSize + 1]->Modify_Dendrite_Factors(&RandomNumbers, minVectorElement, maxVectorElement, minVariance, maxVariance, mutationRate);

	UseAdditionalMutatedSecondBestBrain = true;
}

void CDendriteNeuronPopulation::Update_Evolution_SecondBestBrainOnly_Dendrite_CentroidValues(int32_t minVectorElement, int32_t maxVectorElement, float minVariance, float maxVariance, float mutationRate)
{
	if (UseAdditionalMutatedSecondBestBrain == true)
		return;

	ppNeuronArray[PopulationSize + 1]->Clone_Dendrite_Data(ppNeuronArray[IDArrayOfBestFittedBrains[1]]);
	ppNeuronArray[PopulationSize + 1]->Modify_Dendrite_CentroidValues(&RandomNumbers, minVectorElement, maxVectorElement, minVariance, maxVariance, mutationRate);

	UseAdditionalMutatedSecondBestBrain = true;
}

void CDendriteNeuronPopulation::Update_Evolution_Combine_TwoBrains(pRecombinationFunc pFunc, void *pParam)
{
	if (UseAdditionalRandomBrainsChild[RandomBrainsChildCounter] == true)
		return;

	int32_t id1, id2;

	for (int32_t i = 0; i < constNumPopulationSearchStepsMax; i++)
	{
		id1 = RandomNumbers.Get_IntegerNumber(0, PopulationSize);

		// die am schlechtesten angepassten Individuen d�rfen sich nicht vermehren:
		if (pFitnessScoreArray[id1] <= FitnessArrayOfWorstFittedBrains[constNumOfWorstFittedBrains - 1])
			continue;

		id2 = RandomNumbers.Get_IntegerNumber(0, PopulationSize);

		// die am schlechtesten angepassten Individuen d�rfen sich nicht vermehren:
		if (pFitnessScoreArray[id2] <= FitnessArrayOfWorstFittedBrains[constNumOfWorstFittedBrains - 1])
			continue;

		if (id1 == id2)
			continue;

		pFunc(ppNeuronArray[PopulationSize + 3 + RandomBrainsChildCounter], ppNeuronArray[id1], ppNeuronArray[id2], &RandomNumbers, pParam);

		UseAdditionalRandomBrainsChild[RandomBrainsChildCounter] = true;

		if (RandomBrainsChildCounter < constNumOfRandomBrainsChilds - 1)
			RandomBrainsChildCounter++;

		break;
	}
}

void CDendriteNeuronPopulation::Update_Evolution_Combine_TwoBrains(void)
{
	if (UseAdditionalRandomBrainsChild[RandomBrainsChildCounter] == true)
		return;

	int32_t id1, id2;

	for (int32_t i = 0; i < constNumPopulationSearchStepsMax; i++)
	{
		id1 = RandomNumbers.Get_IntegerNumber(0, PopulationSize);

		// die am schlechtesten angepassten Individuen d�rfen sich nicht vermehren:
		if (pFitnessScoreArray[id1] <= FitnessArrayOfWorstFittedBrains[constNumOfWorstFittedBrains - 1])
			continue;

		id2 = RandomNumbers.Get_IntegerNumber(0, PopulationSize);

		// die am schlechtesten angepassten Individuen d�rfen sich nicht vermehren:
		if (pFitnessScoreArray[id2] <= FitnessArrayOfWorstFittedBrains[constNumOfWorstFittedBrains - 1])
			continue;

		if (id1 == id2)
			continue;

		ppNeuronArray[PopulationSize + 3 + RandomBrainsChildCounter]->Combine_Dendrite_Data_RandomWeighted(&RandomNumbers, ppNeuronArray[id1], ppNeuronArray[id2]);

		UseAdditionalRandomBrainsChild[RandomBrainsChildCounter] = true;

		if (RandomBrainsChildCounter < constNumOfRandomBrainsChilds - 1)
			RandomBrainsChildCounter++;

		break;
	}
}

void CDendriteNeuronPopulation::Update_Evolution_Combine_BestTwoBrains(pRecombinationFunc pFunc, void *pParam)
{
	if (UseAdditionalBestBrainsChild == true)
		return;

	pFunc(ppNeuronArray[PopulationSize + 2], ppNeuronArray[IDArrayOfBestFittedBrains[0]], ppNeuronArray[IDArrayOfBestFittedBrains[1]], &RandomNumbers, pParam);

	UseAdditionalBestBrainsChild = true;
}



void CDendriteNeuronPopulation::Update_Evolution_Combine_BestTwoBrains(void)
{
	if (UseAdditionalBestBrainsChild == true)
		return;

	ppNeuronArray[PopulationSize + 2]->Combine_Dendrite_Data_RandomWeighted(&RandomNumbers, ppNeuronArray[IDArrayOfBestFittedBrains[0]], ppNeuronArray[IDArrayOfBestFittedBrains[1]]);

	UseAdditionalBestBrainsChild = true;
}

void CDendriteNeuronPopulation::Update_Population(float *pFitnessValueArray)
{
	if (pFitnessValueArray != nullptr)
	{
		for (int32_t i = 0; i < PopulationSizePlusX; i++)
		{
			pFitnessScoreArray[i] = pFitnessValueArray[i];
		}
	}

	for (int32_t i = 0; i < constNumOfBestFittedBrains; i++)
	{
		IDArrayOfBestFittedBrains[i] = 0;
		FitnessArrayOfBestFittedBrains[i] = -100000000.0f;
	}

	for (int32_t i = 0; i < constNumOfWorstFittedBrains; i++)
	{
		IDArrayOfWorstFittedBrains[i] = 0;
		FitnessArrayOfWorstFittedBrains[i] = 100000000.0f;
	}

	for (int32_t i = 0; i < PopulationSize; i++)
	{
		for (int32_t j = 0; j < constNumOfBestFittedBrains; j++)
		{
			if (pFitnessScoreArray[i] > FitnessArrayOfBestFittedBrains[j])
			{
				for (uint32_t k = constNumOfBestFittedBrains - 1; k > j; k--)
				{
					IDArrayOfBestFittedBrains[k] = IDArrayOfBestFittedBrains[k - 1];
					FitnessArrayOfBestFittedBrains[k] = FitnessArrayOfBestFittedBrains[k - 1];
				}

				FitnessArrayOfBestFittedBrains[j] = pFitnessScoreArray[i];
				IDArrayOfBestFittedBrains[j] = i;

				break;
			}
		}

		for (int32_t j = 0; j < constNumOfWorstFittedBrains; j++)
		{
			if (pFitnessScoreArray[i] < FitnessArrayOfWorstFittedBrains[j])
			{
				for (int32_t k = constNumOfWorstFittedBrains - 1; k > j; k--)
				{
					IDArrayOfWorstFittedBrains[k] = IDArrayOfWorstFittedBrains[k - 1];
					FitnessArrayOfWorstFittedBrains[k] = FitnessArrayOfWorstFittedBrains[k - 1];
				}

				FitnessArrayOfWorstFittedBrains[j] = pFitnessScoreArray[i];
				IDArrayOfWorstFittedBrains[j] = i;

				break;
			}
		}

	} // end of for (int32_t i = 0; i < PopulationSize; i++)


	 //HelperStuff::Add_To_Log(0, "best fitness", pFitnessScoreArray[IDArrayOfBestFittedBrains[0]]);

	float fitnessScoreOfBestFittedAdditionalBrain = -1000000.0f;
	int32_t idOfBestFittedAdditionalBrain = 0;

	for (int32_t i = 0; i < constNumOfAdditionalBrains; i++)
	{
		if (pFitnessScoreArray[PopulationSize + i] > fitnessScoreOfBestFittedAdditionalBrain)
		{
			fitnessScoreOfBestFittedAdditionalBrain = pFitnessScoreArray[PopulationSize + i];
			idOfBestFittedAdditionalBrain = PopulationSize + i;
		}
	}

	if (pFitnessScoreArray[idOfBestFittedAdditionalBrain] > pFitnessScoreArray[IDArrayOfBestFittedBrains[0]])
	{
		ppNeuronArray[IDArrayOfBestFittedBrains[0]]->Clone_Dendrite_Data(ppNeuronArray[idOfBestFittedAdditionalBrain]);
	}
	else if (pFitnessScoreArray[idOfBestFittedAdditionalBrain] > pFitnessScoreArray[IDArrayOfBestFittedBrains[1]])
	{
		ppNeuronArray[IDArrayOfBestFittedBrains[1]]->Clone_Dendrite_Data(ppNeuronArray[idOfBestFittedAdditionalBrain]);
	}
	else if (pFitnessScoreArray[idOfBestFittedAdditionalBrain] > pFitnessScoreArray[IDArrayOfBestFittedBrains[2]])
	{
		ppNeuronArray[IDArrayOfBestFittedBrains[2]]->Clone_Dendrite_Data(ppNeuronArray[idOfBestFittedAdditionalBrain]);
	}

	UseAdditionalMutatedBestBrain = false;
	UseAdditionalMutatedSecondBestBrain = false;
	UseAdditionalBestBrainsChild = false;
	
	RandomBrainsChildCounter = 0;

	for (int32_t i = 0; i < constNumOfRandomBrainsChilds; i++)
		UseAdditionalRandomBrainsChild[i] = false;
}

void CDendriteNeuronPopulation::Update_Population_Ext(float *pFitnessValueArray)
{
	if (pFitnessValueArray != nullptr)
	{
		for (int32_t i = 0; i < PopulationSizePlusX; i++)
		{
			pFitnessScoreArray[i] = pFitnessValueArray[i];
		}
	}

	for (int32_t i = 0; i < constNumOfBestFittedBrains; i++)
	{
		IDArrayOfBestFittedBrains[i] = 0;
		FitnessArrayOfBestFittedBrains[i] = -100000000.0f;
	}

	for (int32_t i = 0; i < constNumOfWorstFittedBrains; i++)
	{
		IDArrayOfWorstFittedBrains[i] = 0;
		FitnessArrayOfWorstFittedBrains[i] = 100000000.0f;
	}

	for (int32_t i = 0; i < PopulationSize; i++)
	{
		for (int32_t j = 0; j < constNumOfBestFittedBrains; j++)
		{
			if (pFitnessScoreArray[i] > FitnessArrayOfBestFittedBrains[j])
			{
				for (uint32_t k = constNumOfBestFittedBrains - 1; k > j; k--)
				{
					IDArrayOfBestFittedBrains[k] = IDArrayOfBestFittedBrains[k - 1];
					FitnessArrayOfBestFittedBrains[k] = FitnessArrayOfBestFittedBrains[k - 1];
				}

				FitnessArrayOfBestFittedBrains[j] = pFitnessScoreArray[i];
				IDArrayOfBestFittedBrains[j] = i;

				break;
			}
		}

		for (int32_t j = 0; j < constNumOfWorstFittedBrains; j++)
		{
			if (pFitnessScoreArray[i] < FitnessArrayOfWorstFittedBrains[j])
			{
				for (int32_t k = constNumOfWorstFittedBrains - 1; k > j; k--)
				{
					IDArrayOfWorstFittedBrains[k] = IDArrayOfWorstFittedBrains[k - 1];
					FitnessArrayOfWorstFittedBrains[k] = FitnessArrayOfWorstFittedBrains[k - 1];
				}

				FitnessArrayOfWorstFittedBrains[j] = pFitnessScoreArray[i];
				IDArrayOfWorstFittedBrains[j] = i;

				break;
			}
		}

	} // end of for (int32_t i = 0; i < PopulationSize; i++)


	  //HelperStuff::Add_To_Log(0, "best fitness", pFitnessScoreArray[IDArrayOfBestFittedBrains[0]]);

	float fitnessScoreOfBestFittedAdditionalBrain = -1000000.0f;
	int32_t idOfBestFittedAdditionalBrain = 0;

	for (int32_t i = 0; i < constNumOfAdditionalBrains; i++)
	{
		if (pFitnessScoreArray[PopulationSize + i] > fitnessScoreOfBestFittedAdditionalBrain)
		{
			fitnessScoreOfBestFittedAdditionalBrain = pFitnessScoreArray[PopulationSize + i];
			idOfBestFittedAdditionalBrain = PopulationSize + i;
		}
	}

	for (int32_t i = constNumOfBestFittedBrains - 1; i > -1; i--)
	{
		if (pFitnessScoreArray[idOfBestFittedAdditionalBrain] > pFitnessScoreArray[IDArrayOfBestFittedBrains[i]])
		{
			ppNeuronArray[IDArrayOfBestFittedBrains[i]]->Clone_Dendrite_Data(ppNeuronArray[idOfBestFittedAdditionalBrain]);
			break;
		}
	}

	UseAdditionalMutatedBestBrain = false;
	UseAdditionalMutatedSecondBestBrain = false;
	UseAdditionalBestBrainsChild = false;

	RandomBrainsChildCounter = 0;

	for (int32_t i = 0; i < constNumOfRandomBrainsChilds; i++)
		UseAdditionalRandomBrainsChild[i] = false;
}

void CDendriteNeuronPopulation::Update_Population(void)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFitnessScoreArray[i] = ppNeuronArray[i]->NeuronOutput;
	}

	for (int32_t i = 0; i < constNumOfBestFittedBrains; i++)
	{
		IDArrayOfBestFittedBrains[i] = 0;
		FitnessArrayOfBestFittedBrains[i] = -100000000.0f;
	}

	for (int32_t i = 0; i < constNumOfWorstFittedBrains; i++)
	{
		IDArrayOfWorstFittedBrains[i] = 0;
		FitnessArrayOfWorstFittedBrains[i] = 100000000.0f;
	}

	for (int32_t i = 0; i < PopulationSize; i++)
	{
		for (int32_t j = 0; j < constNumOfBestFittedBrains; j++)
		{
			if (pFitnessScoreArray[i] > FitnessArrayOfBestFittedBrains[j])
			{
				for (uint32_t k = constNumOfBestFittedBrains - 1; k > j; k--)
				{
					IDArrayOfBestFittedBrains[k] = IDArrayOfBestFittedBrains[k - 1];
					FitnessArrayOfBestFittedBrains[k] = FitnessArrayOfBestFittedBrains[k - 1];
				}

				FitnessArrayOfBestFittedBrains[j] = pFitnessScoreArray[i];
				IDArrayOfBestFittedBrains[j] = i;

				break;
			}
		}

		for (int32_t j = 0; j < constNumOfWorstFittedBrains; j++)
		{
			if (pFitnessScoreArray[i] < FitnessArrayOfWorstFittedBrains[j])
			{
				for (int32_t k = constNumOfWorstFittedBrains - 1; k > j; k--)
				{
					IDArrayOfWorstFittedBrains[k] = IDArrayOfWorstFittedBrains[k - 1];
					FitnessArrayOfWorstFittedBrains[k] = FitnessArrayOfWorstFittedBrains[k - 1];
				}

				FitnessArrayOfWorstFittedBrains[j] = pFitnessScoreArray[i];
				IDArrayOfWorstFittedBrains[j] = i;

				break;
			}
		}

	} // end of for (int32_t i = 0; i < PopulationSize; i++)


	  //HelperStuff::Add_To_Log(0, "best fitness", pFitnessScoreArray[IDArrayOfBestFittedBrains[0]]);

	float fitnessScoreOfBestFittedAdditionalBrain = -1000000.0f;
	int32_t idOfBestFittedAdditionalBrain = 0;

	for (int32_t i = 0; i < constNumOfAdditionalBrains; i++)
	{
		if (pFitnessScoreArray[PopulationSize + i] > fitnessScoreOfBestFittedAdditionalBrain)
		{
			fitnessScoreOfBestFittedAdditionalBrain = pFitnessScoreArray[PopulationSize + i];
			idOfBestFittedAdditionalBrain = PopulationSize + i;
		}
	}

	if (pFitnessScoreArray[idOfBestFittedAdditionalBrain] > pFitnessScoreArray[IDArrayOfBestFittedBrains[0]])
	{
		ppNeuronArray[IDArrayOfBestFittedBrains[0]]->Clone_Dendrite_Data(ppNeuronArray[idOfBestFittedAdditionalBrain]);
	}
	else if (pFitnessScoreArray[idOfBestFittedAdditionalBrain] > pFitnessScoreArray[IDArrayOfBestFittedBrains[1]])
	{
		ppNeuronArray[IDArrayOfBestFittedBrains[1]]->Clone_Dendrite_Data(ppNeuronArray[idOfBestFittedAdditionalBrain]);
	}
	else if (pFitnessScoreArray[idOfBestFittedAdditionalBrain] > pFitnessScoreArray[IDArrayOfBestFittedBrains[2]])
	{
		ppNeuronArray[IDArrayOfBestFittedBrains[2]]->Clone_Dendrite_Data(ppNeuronArray[idOfBestFittedAdditionalBrain]);
	}

	UseAdditionalMutatedBestBrain = false;
	UseAdditionalMutatedSecondBestBrain = false;
	UseAdditionalBestBrainsChild = false;
	
	RandomBrainsChildCounter = 0;

	for (int32_t i = 0; i < constNumOfRandomBrainsChilds; i++)
		UseAdditionalRandomBrainsChild[i] = false;
}

void CDendriteNeuronPopulation::Update_Population_Ext(void)
{
	for (int32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pFitnessScoreArray[i] = ppNeuronArray[i]->NeuronOutput;
	}

	for (int32_t i = 0; i < constNumOfBestFittedBrains; i++)
	{
		IDArrayOfBestFittedBrains[i] = 0;
		FitnessArrayOfBestFittedBrains[i] = -100000000.0f;
	}

	for (int32_t i = 0; i < constNumOfWorstFittedBrains; i++)
	{
		IDArrayOfWorstFittedBrains[i] = 0;
		FitnessArrayOfWorstFittedBrains[i] = 100000000.0f;
	}

	for (int32_t i = 0; i < PopulationSize; i++)
	{
		for (int32_t j = 0; j < constNumOfBestFittedBrains; j++)
		{
			if (pFitnessScoreArray[i] > FitnessArrayOfBestFittedBrains[j])
			{
				for (uint32_t k = constNumOfBestFittedBrains - 1; k > j; k--)
				{
					IDArrayOfBestFittedBrains[k] = IDArrayOfBestFittedBrains[k - 1];
					FitnessArrayOfBestFittedBrains[k] = FitnessArrayOfBestFittedBrains[k - 1];
				}

				FitnessArrayOfBestFittedBrains[j] = pFitnessScoreArray[i];
				IDArrayOfBestFittedBrains[j] = i;

				break;
			}
		}

		for (int32_t j = 0; j < constNumOfWorstFittedBrains; j++)
		{
			if (pFitnessScoreArray[i] < FitnessArrayOfWorstFittedBrains[j])
			{
				for (int32_t k = constNumOfWorstFittedBrains - 1; k > j; k--)
				{
					IDArrayOfWorstFittedBrains[k] = IDArrayOfWorstFittedBrains[k - 1];
					FitnessArrayOfWorstFittedBrains[k] = FitnessArrayOfWorstFittedBrains[k - 1];
				}

				FitnessArrayOfWorstFittedBrains[j] = pFitnessScoreArray[i];
				IDArrayOfWorstFittedBrains[j] = i;

				break;
			}
		}

	} // end of for (int32_t i = 0; i < PopulationSize; i++)


	  //HelperStuff::Add_To_Log(0, "best fitness", pFitnessScoreArray[IDArrayOfBestFittedBrains[0]]);

	float fitnessScoreOfBestFittedAdditionalBrain = -1000000.0f;
	int32_t idOfBestFittedAdditionalBrain = 0;

	for (int32_t i = 0; i < constNumOfAdditionalBrains; i++)
	{
		if (pFitnessScoreArray[PopulationSize + i] > fitnessScoreOfBestFittedAdditionalBrain)
		{
			fitnessScoreOfBestFittedAdditionalBrain = pFitnessScoreArray[PopulationSize + i];
			idOfBestFittedAdditionalBrain = PopulationSize + i;
		}
	}

	for (int32_t i = constNumOfBestFittedBrains - 1; i > -1; i--)
	{
		if (pFitnessScoreArray[idOfBestFittedAdditionalBrain] > pFitnessScoreArray[IDArrayOfBestFittedBrains[i]])
		{
			ppNeuronArray[IDArrayOfBestFittedBrains[i]]->Clone_Dendrite_Data(ppNeuronArray[idOfBestFittedAdditionalBrain]);
			break;
		}
	}

	

	UseAdditionalMutatedBestBrain = false;
	UseAdditionalMutatedSecondBestBrain = false;
	UseAdditionalBestBrainsChild = false;

	RandomBrainsChildCounter = 0;

	for (int32_t i = 0; i < constNumOfRandomBrainsChilds; i++)
		UseAdditionalRandomBrainsChild[i] = false;
}

void CDendriteNeuronPopulation::Update_BaseEvolution(pMutationFunc pFunc, void *pParam)
{
	bool bestFittedBrains;

	for (int32_t i = 0; i < PopulationSize; i++)
	{
		bestFittedBrains = false;

		for (int32_t j = 0; j < constNumOfBestFittedBrains; j++)
		{
			if (i == IDArrayOfBestFittedBrains[j])
			{
				bestFittedBrains = true;
				break;
			}
		}

		if (bestFittedBrains == false)
		{
			pFunc(ppNeuronArray[i], &RandomNumbers, pParam);
		}
	}
}

void CDendriteNeuronPopulation::Update_BaseEvolution_Dendrite_Values(float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance, float mutationRate)
{
	bool bestFittedBrains;

	for (int32_t i = 0; i < PopulationSize; i++)
	{
		bestFittedBrains = false;

		for (int32_t j = 0; j < constNumOfBestFittedBrains; j++)
		{
			if (i == IDArrayOfBestFittedBrains[j])
			{
				bestFittedBrains = true;
				break;
			}
		}

		if (bestFittedBrains == false)
		{
			ppNeuronArray[i]->Modify_Dendrite_Values(&RandomNumbers, minCentroidValueVariance, maxCentroidValueVariance, minFactorVariance, maxFactorVariance, mutationRate);
		}
	}
}

void CDendriteNeuronPopulation::Update_BaseEvolution_Dendrite_Factors(float minVariance, float maxVariance, float mutationRate)
{
	bool bestFittedBrains;

	for (int32_t i = 0; i < PopulationSize; i++)
	{
		bestFittedBrains = false;

		for (int32_t j = 0; j < constNumOfBestFittedBrains; j++)
		{
			if (i == IDArrayOfBestFittedBrains[j])
			{
				bestFittedBrains = true;
				break;
			}
		}

		if (bestFittedBrains == false)
		{
			ppNeuronArray[i]->Modify_Dendrite_Factors(&RandomNumbers, minVariance, maxVariance, mutationRate);
		}
	}
}

void CDendriteNeuronPopulation::Update_BaseEvolution_Dendrite_CentroidValues(float minVariance, float maxVariance, float mutationRate)
{
	bool bestFittedBrains;

	for (int32_t i = 0; i < PopulationSize; i++)
	{
		bestFittedBrains = false;

		for (int32_t j = 0; j < constNumOfBestFittedBrains; j++)
		{
			if (i == IDArrayOfBestFittedBrains[j])
			{
				bestFittedBrains = true;
				break;
			}
		}

		if (bestFittedBrains == false)
		{
			ppNeuronArray[i]->Modify_Dendrite_CentroidValues(&RandomNumbers, minVariance, maxVariance, mutationRate);
		}
	}
}

void CDendriteNeuronPopulation::Update_BaseEvolution_Dendrite_Values(int32_t minVectorElement, int32_t maxVectorElement, float minCentroidValueVariance, float maxCentroidValueVariance, float minFactorVariance, float maxFactorVariance, float mutationRate)
{
	bool bestFittedBrains;

	for (int32_t i = 0; i < PopulationSize; i++)
	{
		bestFittedBrains = false;

		for (int32_t j = 0; j < constNumOfBestFittedBrains; j++)
		{
			if (i == IDArrayOfBestFittedBrains[j])
			{
				bestFittedBrains = true;
				break;
			}
		}

		if (bestFittedBrains == false)
		{
			ppNeuronArray[i]->Modify_Dendrite_Values(&RandomNumbers, minVectorElement, maxVectorElement, minCentroidValueVariance, maxCentroidValueVariance, minFactorVariance, maxFactorVariance, mutationRate);
		}
	}
}

void CDendriteNeuronPopulation::Update_BaseEvolution_Dendrite_Factors(int32_t minVectorElement, int32_t maxVectorElement, float minVariance, float maxVariance, float mutationRate)
{
	bool bestFittedBrains;

	for (int32_t i = 0; i < PopulationSize; i++)
	{
		bestFittedBrains = false;

		for (int32_t j = 0; j < constNumOfBestFittedBrains; j++)
		{
			if (i == IDArrayOfBestFittedBrains[j])
			{
				bestFittedBrains = true;
				break;
			}
		}

		if (bestFittedBrains == false)
		{
			ppNeuronArray[i]->Modify_Dendrite_Factors(&RandomNumbers, minVectorElement, maxVectorElement, minVariance, maxVariance, mutationRate);
		}
	}
}

void CDendriteNeuronPopulation::Update_BaseEvolution_Dendrite_CentroidValues(int32_t minVectorElement, int32_t maxVectorElement, float minVariance, float maxVariance, float mutationRate)
{
	bool bestFittedBrains;

	for (int32_t i = 0; i < PopulationSize; i++)
	{
		bestFittedBrains = false;

		for (int32_t j = 0; j < constNumOfBestFittedBrains; j++)
		{
			if (i == IDArrayOfBestFittedBrains[j])
			{
				bestFittedBrains = true;
				break;
			}
		}

		if (bestFittedBrains == false)
		{
			ppNeuronArray[i]->Modify_Dendrite_CentroidValues(&RandomNumbers, minVectorElement, maxVectorElement, minVariance, maxVariance, mutationRate);
		}
	}
}





void CDendriteNeuronPopulation::Update_Evolution_BestBrainOnly_Dendrite_Permutations(int32_t minVectorElement, int32_t maxVectorElement, int32_t permutationSteps)
{
	if (UseAdditionalMutatedBestBrain == true)
		return;

	ppNeuronArray[PopulationSize]->Clone_Dendrite_Data(ppNeuronArray[IDArrayOfBestFittedBrains[0]]);
	ppNeuronArray[PopulationSize]->Permute_Dendrite_Values(&RandomNumbers, minVectorElement, maxVectorElement, permutationSteps);

	UseAdditionalMutatedBestBrain = true;
}

void CDendriteNeuronPopulation::Update_Evolution_BestBrainOnly_Dendrite_CentroidValue_Permutations(int32_t minVectorElement, int32_t maxVectorElement, int32_t permutationSteps)
{
	if (UseAdditionalMutatedBestBrain == true)
		return;

	ppNeuronArray[PopulationSize]->Clone_Dendrite_Data(ppNeuronArray[IDArrayOfBestFittedBrains[0]]);
	ppNeuronArray[PopulationSize]->Permute_Dendrite_CentroidValues(&RandomNumbers, minVectorElement, maxVectorElement, permutationSteps);

	UseAdditionalMutatedBestBrain = true;
}

void CDendriteNeuronPopulation::Update_Evolution_BestBrainOnly_Dendrite_Factor_Permutations(int32_t minVectorElement, int32_t maxVectorElement, int32_t permutationSteps)
{
	if (UseAdditionalMutatedBestBrain == true)
		return;

	ppNeuronArray[PopulationSize]->Clone_Dendrite_Data(ppNeuronArray[IDArrayOfBestFittedBrains[0]]);
	ppNeuronArray[PopulationSize]->Permute_Dendrite_Factors(&RandomNumbers, minVectorElement, maxVectorElement, permutationSteps);

	UseAdditionalMutatedBestBrain = true;
}

void CDendriteNeuronPopulation::Update_Evolution_SecondBestBrainOnly_Dendrite_Permutations(int32_t minVectorElement, int32_t maxVectorElement, int32_t permutationSteps)
{
	if (UseAdditionalMutatedSecondBestBrain == true)
		return;

	ppNeuronArray[PopulationSize + 1]->Clone_Dendrite_Data(ppNeuronArray[IDArrayOfBestFittedBrains[1]]);
	ppNeuronArray[PopulationSize + 1]->Permute_Dendrite_Values(&RandomNumbers, minVectorElement, maxVectorElement, permutationSteps);

	UseAdditionalMutatedSecondBestBrain = true;
}

void CDendriteNeuronPopulation::Update_Evolution_SecondBestBrainOnly_Dendrite_CentroidValue_Permutations(int32_t minVectorElement, int32_t maxVectorElement, int32_t permutationSteps)
{
	if (UseAdditionalMutatedSecondBestBrain == true)
		return;

	ppNeuronArray[PopulationSize + 1]->Clone_Dendrite_Data(ppNeuronArray[IDArrayOfBestFittedBrains[1]]);
	ppNeuronArray[PopulationSize + 1]->Permute_Dendrite_CentroidValues(&RandomNumbers, minVectorElement, maxVectorElement, permutationSteps);

	UseAdditionalMutatedSecondBestBrain = true;
}

void CDendriteNeuronPopulation::Update_PopulationKnowledge(int32_t minDendriteID, int32_t maxDendriteID)
{
	maxDendriteID++;

	CNeuronV2 *pNeuron = nullptr;
	CNeuronV2 *pBestNeuron = ppNeuronArray[IDArrayOfBestFittedBrains[0]];

	for (uint32_t i = 0; i < PopulationSizePlusX; i++)
	{
		pNeuron = ppNeuronArray[i];

		for(int32_t j = minDendriteID; j < maxDendriteID; j++)
		{
			pNeuron->pDendrite_CentroidValueArray[j] = pBestNeuron->pDendrite_CentroidValueArray[j];
			pNeuron->pDendrite_FactorArray[j] = pBestNeuron->pDendrite_FactorArray[j];
		}
	}
}

void CDendriteNeuronPopulation::Learning(pNeuronV2PopulationLearningFunc pFunc, int32_t neuronID, float learningRate, float learningRateVariance, float errorFactor1, float errorFactor2)
{
	if (neuronID >= PopulationSize)
		return;

	if (neuronID == IDArrayOfBestFittedBrains[0])
		return;

	CNeuronV2 *pBestNeuron = ppNeuronArray[IDArrayOfBestFittedBrains[0]];

	pFunc(ppNeuronArray[neuronID], pBestNeuron, &RandomNumbers, learningRate, learningRateVariance, errorFactor1, errorFactor2);
}



void CDendriteNeuronPopulation::Update_Evolution_SecondBestBrainOnly_Dendrite_Factor_Permutations(int32_t minVectorElement, int32_t maxVectorElement, int32_t permutationSteps)
{
	if (UseAdditionalMutatedSecondBestBrain == true)
		return;

	ppNeuronArray[PopulationSize + 1]->Clone_Dendrite_Data(ppNeuronArray[IDArrayOfBestFittedBrains[1]]);
	ppNeuronArray[PopulationSize + 1]->Permute_Dendrite_Factors(&RandomNumbers, minVectorElement, maxVectorElement, permutationSteps);

	UseAdditionalMutatedSecondBestBrain = true;
}

void CDendriteNeuronPopulation::Update_BaseEvolution_Dendrite_Permutations(int32_t minVectorElement, int32_t maxVectorElement, int32_t permutationSteps)
{
	bool bestFittedBrains;

	for (int32_t i = 0; i < PopulationSize; i++)
	{
		bestFittedBrains = false;

		for (int32_t j = 0; j < constNumOfBestFittedBrains; j++)
		{
			if (i == IDArrayOfBestFittedBrains[j])
			{
				bestFittedBrains = true;
				break;
			}
		}

		if (bestFittedBrains == false)
		{
			ppNeuronArray[i]->Permute_Dendrite_Values(&RandomNumbers, minVectorElement, maxVectorElement, permutationSteps);
		}
	}
}

void CDendriteNeuronPopulation::Update_BaseEvolution_Dendrite_CentroidValue_Permutations(int32_t minVectorElement, int32_t maxVectorElement, int32_t permutationSteps)
{
	bool bestFittedBrains;

	for (int32_t i = 0; i < PopulationSize; i++)
	{
		bestFittedBrains = false;

		for (int32_t j = 0; j < constNumOfBestFittedBrains; j++)
		{
			if (i == IDArrayOfBestFittedBrains[j])
			{
				bestFittedBrains = true;
				break;
			}
		}

		if (bestFittedBrains == false)
		{
			ppNeuronArray[i]->Permute_Dendrite_CentroidValues(&RandomNumbers, minVectorElement, maxVectorElement, permutationSteps);
		}
	}
}

void CDendriteNeuronPopulation::Update_BaseEvolution_Dendrite_Factor_Permutations(int32_t minVectorElement, int32_t maxVectorElement, int32_t permutationSteps)
{
	bool bestFittedBrains;

	for (int32_t i = 0; i < PopulationSize; i++)
	{
		bestFittedBrains = false;

		for (int32_t j = 0; j < constNumOfBestFittedBrains; j++)
		{
			if (i == IDArrayOfBestFittedBrains[j])
			{
				bestFittedBrains = true;
				break;
			}
		}

		if (bestFittedBrains == false)
		{
			ppNeuronArray[i]->Permute_Dendrite_Factors(&RandomNumbers, minVectorElement, maxVectorElement, permutationSteps);
		}
	}
}



CInputValueArrayList::CInputValueArrayList()
{}

CInputValueArrayList::~CInputValueArrayList()
{
	delete[] pInputArrayValues;
	pInputArrayValues = nullptr;
}

void CInputValueArrayList::Initialize(int32_t inputArraySize, int32_t numOfInputArrays)
{
	delete[] pInputArrayValues;
	pInputArrayValues = nullptr;

	InputArraySize = inputArraySize;
	NumOfInputArrays = numOfInputArrays;

	int32_t sumOfArrayEntries = inputArraySize * numOfInputArrays;

	pInputArrayValues = new (std::nothrow) float[sumOfArrayEntries];

	for (int32_t i = 0; i < sumOfArrayEntries; i++)
		pInputArrayValues[0] = 0.0f;
}

void CInputValueArrayList::Set_ArrayValues(float *pArrayValues, int32_t arrayID)
{
	int32_t firstID = InputArraySize * arrayID;
	int32_t lastID = firstID + InputArraySize;

	int32_t counter = 0;

	for (int32_t i = firstID; i < lastID; i++)
		pInputArrayValues[i] = pArrayValues[counter++];
}

float* CInputValueArrayList::Get_FirstArrayElement(int32_t arrayID)
{
	return &pInputArrayValues[arrayID*InputArraySize];
}

void CInputValueArrayList::Get_FirstArrayElement(float *pOutArrayElement, int32_t arrayID)
{
	pOutArrayElement = &pInputArrayValues[arrayID*InputArraySize];
}


CNeuronLayerV2::CNeuronLayerV2()
{}

CNeuronLayerV2::~CNeuronLayerV2()
{
	delete[] pNeuronArray;
	pNeuronArray = nullptr;
}

void CNeuronLayerV2::Initialize(int32_t numOfNeurons)
{
	delete[] pNeuronArray;
	pNeuronArray = nullptr;

	NumOfNeurons = numOfNeurons;

	pNeuronArray = new (std::nothrow) CNeuronV2[numOfNeurons];
}

COutputLayerV2::COutputLayerV2()
{}

COutputLayerV2::~COutputLayerV2()
{
	delete[] pNeuronValueArray;
	pNeuronValueArray = nullptr;

	delete[] pModifiedNeuronValueArray;
	pModifiedNeuronValueArray = nullptr;

	delete[] pErrorValueArray;
	pErrorValueArray = nullptr;
}

void COutputLayerV2::Set_ActivationFunction(pOutputActivationFuncV2 pFunc)
{
	pActivationFunction = pFunc;
}

void COutputLayerV2::Initialize(int32_t numOfElements)
{
	delete[] pNeuronValueArray;
	pNeuronValueArray = nullptr;

	delete[] pModifiedNeuronValueArray;
	pModifiedNeuronValueArray = nullptr;

	delete[] pErrorValueArray;
	pErrorValueArray = nullptr;

	NumOfElements = numOfElements;

	pNeuronValueArray = new (std::nothrow) float[numOfElements];
	pModifiedNeuronValueArray = new (std::nothrow) float[numOfElements];
	pErrorValueArray = new (std::nothrow) float[numOfElements];
}

void COutputLayerV2::Reset_InputValues(void)
{
	for (int32_t i = 0; i < NumOfElements; i++)
	{
		pNeuronValueArray[i] = 0.0f;
	}
}

void COutputLayerV2::Add_InputValues(float *pValueArray)
{
	for (int32_t i = 0; i < NumOfElements; i++)
	{
		pNeuronValueArray[i] += pValueArray[i];
	}
}

void COutputLayerV2::Add_InputValues(CNeuronV2 *pNeuron)
{
	float neuronOutput = pNeuron->NeuronOutput;

	float *pSynapticPlasticityArray = pNeuron->pOutputSynapsePlasticityArray;

	for (int32_t i = 0; i < NumOfElements; i++)
	{
		pNeuronValueArray[i] += neuronOutput * pSynapticPlasticityArray[i];
	}
}

void COutputLayerV2::Calculate_Input(CNeuronV2 *pNeuronArray, int32_t numOfNeurons)
{
	Reset_InputValues();

	for (int32_t i = 0; i < numOfNeurons; i++)
	{
		pNeuronArray[i].Calculate_NeuronOutput();
		Add_InputValues(&pNeuronArray[i]);
	}
}

void COutputLayerV2::Calculate_Input(CNeuronLayerV2 *pNeuronLayer)
{
	Reset_InputValues();

	int32_t numOfNeurons = pNeuronLayer->NumOfNeurons;
	CNeuronV2 *pNeuronArray = pNeuronLayer->pNeuronArray;

	for (int32_t i = 0; i < numOfNeurons; i++)
	{
		pNeuronArray[i].Calculate_NeuronOutput();
		Add_InputValues(&pNeuronArray[i]);
	}
}

void COutputLayerV2::Calculate_Output(pOutputActivationFuncV2 pFunc)
{
	for (int32_t i = 0; i < NumOfElements; i++)
	{
		pNeuronValueArray[i] = pFunc(pNeuronValueArray[i]);
	}
}

void COutputLayerV2::Calculate_Output(void)
{
	for (int32_t i = 0; i < NumOfElements; i++)
	{
		pNeuronValueArray[i] = pActivationFunction(pNeuronValueArray[i]);
	}
}

float COutputLayerV2::Calculate_ErrorValues(float *pInDesiredValueArray, float errorFactor1, float errorFactor2)
{
	float errorSum = 0.0f;

	float variance, actualValueSq;

	for (int32_t i = 0; i < NumOfElements; i++)
	{
		actualValueSq = pNeuronValueArray[i];

		variance = pInDesiredValueArray[i] - actualValueSq;

		errorSum += variance * variance;

		actualValueSq *= actualValueSq;

		pErrorValueArray[i] = variance * errorFactor1 * exp(-(errorFactor2 * actualValueSq));

	}

	/* Hinweis: Wenn bereits eine geringe Neuronenaktivit�t (actualValue)
	zu einer gro�en Abweichung f�hrt, ist auch der Fehler gro�. Abweichungen
	bei einer starken Neuronenaktivit�t f�hren hingegen zu einem kleineren
	Fehler. */

	return errorSum;
}

float COutputLayerV2::Calculate_ErrorValues(float *pOutVarianceArray, float *pInDesiredValueArray, float errorFactor1, float errorFactor2)
{
	float errorSum = 0.0f;

	float variance, varianceSq, actualValueSq;

	for (int32_t i = 0; i < NumOfElements; i++)
	{
		actualValueSq = pNeuronValueArray[i];

		variance = pInDesiredValueArray[i] - actualValueSq;
		varianceSq = variance * variance;

		errorSum += varianceSq;

		pOutVarianceArray[i] = varianceSq;

		actualValueSq *= actualValueSq;

		pErrorValueArray[i] = variance * errorFactor1 * exp(-(errorFactor2 * actualValueSq));

	}

	/* Hinweis: Wenn bereits eine geringe Neuronenaktivit�t (actualValue)
	zu einer gro�en Abweichung f�hrt, ist auch der Fehler gro�. Abweichungen
	bei einer starken Neuronenaktivit�t f�hren hingegen zu einem kleineren
	Fehler. */

	return errorSum;
}

void COutputLayerV2::Adjust_PrecedingNeuronOutputSynapses_AfterErrorCalculations(CNeuronV2 *pNeuron, float learningRate)
{
	float neuronOutput = pNeuron->NeuronOutput;

	float *pSynapticPlasticityArray = pNeuron->pOutputSynapsePlasticityArray;


	for (int32_t i = 0; i < NumOfElements; i++)
	{
		pSynapticPlasticityArray[i] += learningRate * pErrorValueArray[i] * neuronOutput;
	}
}

void COutputLayerV2::Adjust_PrecedingNeuronOutputSynapses_AfterErrorCalculations(CNeuronV2 *pNeuronArray, int32_t numOfNeurons, float learningRate)
{
	for (int32_t i = 0; i < numOfNeurons; i++)
		Adjust_PrecedingNeuronOutputSynapses_AfterErrorCalculations(&pNeuronArray[i], learningRate);
}

void COutputLayerV2::Calculate_PrecedingNeuronErrorValues(CNeuronV2 *pNeuron, float errorFactor1, float errorFactor2)
{
	pNeuron->Calculate_Error(pErrorValueArray, errorFactor1, errorFactor2);
}

void COutputLayerV2::Calculate_PrecedingNeuronErrorValues(CNeuronV2 *pNeuronArray, int32_t numOfNeurons, float errorFactor1, float errorFactor2)
{
	for (int32_t i = 0; i < numOfNeurons; i++)
		pNeuronArray[i].Calculate_Error(pErrorValueArray, errorFactor1, errorFactor2);
}

void COutputLayerV2::Calculate_PrecedingNeuronErrorValues(CNeuronLayerV2 *pNeuronLayer, float errorFactor1, float errorFactor2)
{
	int32_t numOfNeurons = pNeuronLayer->NumOfNeurons;
	CNeuronV2 *pNeuronArray = pNeuronLayer->pNeuronArray;

	for (int32_t i = 0; i < numOfNeurons; i++)
		pNeuronArray[i].Calculate_Error(pErrorValueArray, errorFactor1, errorFactor2);
}

void COutputLayerV2::Adjust_PrecedingNeuronOutputSynapses_AfterErrorCalculations(CNeuronLayerV2 *pNeuronLayer, float learningRate)
{
	int32_t numOfNeurons = pNeuronLayer->NumOfNeurons;
	CNeuronV2 *pNeuronArray = pNeuronLayer->pNeuronArray;

	for (int32_t i = 0; i < numOfNeurons; i++)
		Adjust_PrecedingNeuronOutputSynapses_AfterErrorCalculations(&pNeuronArray[i], learningRate);
}

void COutputLayerV2::Get_NeuronOutputValues(float *pOutValueArray)
{
	for (int32_t i = 0; i < NumOfElements; i++)
		pOutValueArray[i] = pNeuronValueArray[i];
}

void COutputLayerV2::Get_ModifiedNeuronOutputValues(float *pOutValueArray)
{
	for (int32_t i = 0; i < NumOfElements; i++)
		pOutValueArray[i] = pModifiedNeuronValueArray[i];
}

float COutputLayerV2::Get_NeuronOutputSum(float minValue, float maxValue)
{
	float sum = 0.0f;

	for (int32_t i = 0; i < NumOfElements; i++)
		sum += pNeuronValueArray[i];


	sum = min(sum, maxValue);
	sum = max(sum, minValue);

	return sum;
}

void COutputLayerV2::Get_ID_And_Output_Of_NeuronWithMaxOutput(int32_t *pOutNeuronID, float *pOutNeuronOutput)
{
	int32_t id = 0;
	float maxOutput = -1000000.0f;

	for (int32_t i = 0; i < NumOfElements; i++)
	{
		if (pNeuronValueArray[i] > maxOutput)
		{
			maxOutput = pNeuronValueArray[i];
			id = i;
		}
	}

	*pOutNeuronID = id;
	*pOutNeuronOutput = maxOutput;
}

float COutputLayerV2::Get_Output_Of_NeuronWithMaxOutput(void)
{
	float maxOutput = -1000000.0f;

	for (int32_t i = 0; i < NumOfElements; i++)
	{
		if (pNeuronValueArray[i] > maxOutput)
		{
			maxOutput = pNeuronValueArray[i];
		}
	}


	return maxOutput;
}

void COutputLayerV2::Get_ID_And_Output_Of_NeuronWithMinOutput(int32_t *pOutNeuronID, float *pOutNeuronOutput)
{
	int32_t id = 0;
	float minOutput = 1000000.0f;

	for (int32_t i = 0; i < NumOfElements; i++)
	{
		if (pNeuronValueArray[i] < minOutput)
		{
			minOutput = pNeuronValueArray[i];
			id = i;
		}
	}

	*pOutNeuronID = id;
	*pOutNeuronOutput = minOutput;
}

float COutputLayerV2::Get_Output_Of_NeuronWithMinOutput(void)
{
	float minOutput = 1000000.0f;

	for (int32_t i = 0; i < NumOfElements; i++)
	{
		if (pNeuronValueArray[i] < minOutput)
		{
			minOutput = pNeuronValueArray[i];
		}
	}

	return minOutput;
}

void COutputLayerV2::Calculate_SoftmaxValues(void)
{
	SoftMax(pModifiedNeuronValueArray, pNeuronValueArray, NumOfElements);
}

void COutputLayerV2::Calculate_ProbabilityValues(void)
{
	for (int32_t i = 0; i < NumOfElements; i++)
		pModifiedNeuronValueArray[i] = 0.0f;

	float sum = 0.00001f;

	for (int32_t i = 0; i < NumOfElements; i++)
		sum += pNeuronValueArray[i];


	float invSum = 1.0f / sum;

	for (int32_t i = 0; i < NumOfElements; i++)
		pModifiedNeuronValueArray[i] = pNeuronValueArray[i] * invSum;

}

void COutputLayerV2::Calculate_NormalizedOutputValues(void)
{
	for (int32_t i = 0; i < NumOfElements; i++)
		pModifiedNeuronValueArray[i] = 0.0f;

	float tempFloat;
	float sum = 0.00001f;

	for (int32_t i = 0; i < NumOfElements; i++)
	{
		tempFloat = pNeuronValueArray[i];
		tempFloat *= tempFloat;
		sum += tempFloat;
	}

	float invSum = 1.0f / sqrt(sum);

	for (int32_t i = 0; i < NumOfElements; i++)
	{
		pModifiedNeuronValueArray[i] = pNeuronValueArray[i] * invSum;
	}
}








