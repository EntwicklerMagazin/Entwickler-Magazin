#ifndef _MultiThreading_H_
#define _MultiThreading_H_

#include <iostream>
#include <thread>
#include <mutex>
#include <atomic>
#include <condition_variable>

static constexpr uint32_t g_NumOfUsableThreadsMax = 16;

class CThreadManager
{
public:

	uint32_t ThreadID = 0;

	CThreadManager() {}
	~CThreadManager() {}

	/* Methoden, die aus dem Hauptprogramm-Thread
	heraus aufgerufen werden: */

	void Set_ThreadID(uint32_t id);
	void Unblock_Thread(void);
	void Stop_Thread(void);
	void Wait_For_Results(void);
	
	/* Methoden, die aus dem Worker-Thread heraus
	aufgerufen werden: */

	bool Wait_For_UnblockingSignal_And_Continue(void);
	void Task_Completed(void);
	void Set_BlockingStatus(bool status);

	/* Operatormethode, die im Zuge des wait()-Aufrufs
	einer Bedingungsvariablen zum Einsatz kommt: */
	bool operator()(void);

};

#endif
