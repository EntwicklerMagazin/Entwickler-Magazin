// Schutz vor Mehrfachdeklarationen :

#ifndef _Konane_H_
#define _Konane_H_

#pragma warning( disable: 4996)

#include "NeuralCalculationNet.h"
#include "GameStateHandler.h"

static constexpr int32_t ConstGameBoardSizePerDir = 8;
//static constexpr int32_t ConstGameBoardSizePerDirPlus1 = ConstGameBoardSizePerDir + 1;
static constexpr int32_t ConstGameBoardSizePerDirMinus1 = ConstGameBoardSizePerDir - 1;
static constexpr int32_t ConstGameBoardSizePerDirMinus2 = ConstGameBoardSizePerDir - 2;

static constexpr int32_t ConstGameBoardSize = ConstGameBoardSizePerDir * ConstGameBoardSizePerDir;

static constexpr int8_t ConstGameBoard_Empty = 0;
static constexpr int8_t ConstGameBoard_Player1 = 1;
static constexpr int8_t ConstGameBoard_Player2 = 2;

static constexpr int8_t ConstGameBoard_Player1_Man = 1;
static constexpr int8_t ConstGameBoard_Player1_King = 2;
static constexpr int8_t ConstGameBoard_Player2_Man = 3;
static constexpr int8_t ConstGameBoard_Player2_King = 4;




void Calculate_KonaneScore(int32_t* pOutPlayer1Score, int32_t* pOutPlayer2Score, int8_t* pInGameData);

void Calculate_CheckersKonaneScore(int32_t* pOutPlayer1Score, int32_t* pOutPlayer2Score, int8_t* pInGameData);

void Calculate_KonanePlayer1Score(int32_t* pOutPlayer1Score, int8_t* pInGameData);
void Calculate_KonanePlayer2Score(int32_t* pOutPlayer2Score, int8_t* pInGameData);

void Calculate_CheckersKonanePlayer1Score(int32_t* pOutPlayer1Score, int8_t* pInGameData);
void Calculate_CheckersKonanePlayer2Score(int32_t* pOutPlayer2Score, int8_t* pInGameData);

bool Check_PossibleKonanePlayer1Moves(int8_t* pInGameData);
bool Check_PossibleKonanePlayer2Moves(int8_t* pInGameData);

bool Check_PossibleCheckersKonanePlayer1Moves(int8_t* pInGameData, CMovePatternList* pMoveList);
bool Check_PossibleCheckersKonanePlayer2Moves(int8_t* pInGameData, CMovePatternList* pMoveList);


void Evaluate_LeafGameStates_KonanePlayer1View(CExtendedGameStatePool* pGameStatePool);
void Evaluate_LeafGameStates_KonanePlayer2View(CExtendedGameStatePool* pGameStatePool);

void Evaluate_LeafGameStates_CheckersKonanePlayer1View(CExtendedGameStatePool* pGameStatePool, CMovePatternList* pPlayer1MoveList, CMovePatternList* pPlayer2MoveList);
void Evaluate_LeafGameStates_CheckersKonanePlayer2View(CExtendedGameStatePool* pGameStatePool, CMovePatternList* pPlayer1MoveList, CMovePatternList* pPlayer2MoveList);

void Evaluate_LeafGameStates_KonanePlayer1View(CExtendedGameStatePool* pGameStatePool, int32_t depth);
void Evaluate_LeafGameStates_KonanePlayer2View(CExtendedGameStatePool* pGameStatePool, int32_t depth);

void Evaluate_LeafGameStates_CheckersKonanePlayer1View(CExtendedGameStatePool* pGameStatePool, int32_t depth, CMovePatternList* pPlayer1MoveList, CMovePatternList* pPlayer2MoveList);
void Evaluate_LeafGameStates_CheckersKonanePlayer2View(CExtendedGameStatePool* pGameStatePool, int32_t depth, CMovePatternList* pPlayer1MoveList, CMovePatternList* pPlayer2MoveList);


void Evaluate_GameStates_KonanePlayer1View(CExtendedGameStatePool* pGameStatePool);
void Evaluate_GameStates_KonanePlayer2View(CExtendedGameStatePool* pGameStatePool);

void Evaluate_GameStates_CheckersKonanePlayer1View(CExtendedGameStatePool* pGameStatePool, CMovePatternList* pPlayer1MoveList, CMovePatternList* pPlayer2MoveList);
void Evaluate_GameStates_CheckersKonanePlayer2View(CExtendedGameStatePool* pGameStatePool, CMovePatternList* pPlayer1MoveList, CMovePatternList* pPlayer2MoveList);

void Evaluate_GameState_KonanePlayer1View(int32_t gameStateID, CExtendedGameStatePool* pGameStatePool);
void Evaluate_GameState_KonanePlayer2View(int32_t gameStateID, CExtendedGameStatePool* pGameStatePool);

void Evaluate_GameState_CheckersKonanePlayer1View(int32_t gameStateID, CExtendedGameStatePool* pGameStatePool, CMovePatternList* pPlayer1MoveList, CMovePatternList* pPlayer2MoveList);
void Evaluate_GameState_CheckersKonanePlayer2View(int32_t gameStateID, CExtendedGameStatePool* pGameStatePool, CMovePatternList* pPlayer1MoveList, CMovePatternList* pPlayer2MoveList);

void Check_KonaneLeafGameStates(CExtendedGameStatePool* pGameStatePool);




class CKonaneBreadthFirstSearchAI
{
public:

	int32_t MaxSearchDepth = 0;
	int32_t NumTestGameStatesMax = 0;
	int32_t NumTestGameStatesMaxPerDepthLayer = 0;

	CExtendedGameStatePool GameStatePool;

	CTestMove KonaneTestMove;

	CRandomNumbersNN RandomNumbers;

	CMovePatternList* pUsedPlayer1MoveList = nullptr;
	CMovePatternList* pUsedPlayer2MoveList = nullptr;

	CKonaneBreadthFirstSearchAI();
	~CKonaneBreadthFirstSearchAI();

	// Kopierkonstruktor l�schen:
	CKonaneBreadthFirstSearchAI(const CKonaneBreadthFirstSearchAI& originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CKonaneBreadthFirstSearchAI& operator=(const CKonaneBreadthFirstSearchAI& originalObject) = delete;

	void Initialize(CMovePatternList* pPlayer1MoveList, CMovePatternList* pPlayer2MoveList, int32_t numTestGameStatesMax, int32_t numTestGameStatesMaxPerDepthLayer, int32_t maxSearchDepth);

	void Prepare_KonaneGame(void);
	void Prepare_CheckersKonaneGame(void);

	void Change_Seed(uint64_t seed);

	void Execute_Player1AI(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState);
	void Execute_Player2AI(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState);

	void Execute_Player1AI(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, float* pSearchDepthMovementProbabilityArray);
	void Execute_Player2AI(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, float* pSearchDepthMovementProbabilityArray);

	void Execute_Player1AI_CheckersKonane(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState);
	void Execute_Player2AI_CheckersKonane(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState);

	void Execute_Player1AI_CheckersKonane(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, float* pSearchDepthMovementProbabilityArray);
	void Execute_Player2AI_CheckersKonane(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, float* pSearchDepthMovementProbabilityArray);
};

class CKonaneDepthFirstSearchAI
{
public:

	int32_t MaxSearchDepth = 0;
	int32_t MaxSearchDepthMinus1 = 0;
	int32_t NumTestGameStatesMax = 0;

	CExtendedGameStatePool GameStatePool;

	CTestMove* pKonaneTestMoveArray = nullptr;

	CMovePatternList* pUsedPlayer1MoveList = nullptr;
	CMovePatternList* pUsedPlayer2MoveList = nullptr;

	CKonaneDepthFirstSearchAI();
	~CKonaneDepthFirstSearchAI();

	// Kopierkonstruktor l�schen:
	CKonaneDepthFirstSearchAI(const CKonaneDepthFirstSearchAI& originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CKonaneDepthFirstSearchAI& operator=(const CKonaneDepthFirstSearchAI& originalObject) = delete;

	void Initialize(CMovePatternList* pPlayer1MoveList, CMovePatternList* pPlayer2MoveList, int32_t numTestGameStatesMax, int32_t maxSearchDepth);

	// must be called after Initialize():
	void Prepare_KonaneGame(void);
	// must be called after Initialize():
	void Prepare_CheckersKonaneGame(void);

	void Execute_Player1AI(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState);
	void Execute_Player2AI(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState);

	void Execute_Player1AI_CheckersKonane(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState);
	void Execute_Player2AI_CheckersKonane(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState);

	bool Player1AI_InnerEvalulationLoop(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth);
	bool Player2AI_InnerEvalulationLoop(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth);

	bool Player1AI_InnerEvalulationLoop_CheckersKonane(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth);
	bool Player2AI_InnerEvalulationLoop_CheckersKonane(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth);

	bool Player1AI_OuterEvalulationLoop(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth);
	bool Player2AI_OuterEvalulationLoop(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth);

	bool Player1AI_OuterEvalulationLoop_CheckersKonane(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth);
	bool Player2AI_OuterEvalulationLoop_CheckersKonane(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth);
};



#endif