#include "MemoryManagement.h"

using namespace std;

// Konstruktor:
CSimpleMemoryManager::CSimpleMemoryManager() : UnusedMemoryElementArray(nullptr), UsageStatusArray(nullptr), UnusedMemoryElementArrayID(0), NumMemoryElements(0), NumMemoryElementsMinus1(0)
{}

// Destruktor:
CSimpleMemoryManager::~CSimpleMemoryManager()
{
	delete[] UnusedMemoryElementArray;
	UnusedMemoryElementArray = nullptr;

	delete[] UsageStatusArray;
	UsageStatusArray = nullptr;
}

bool CSimpleMemoryManager::
Initialize(size_t numMemoryElements)
{
	delete[] UnusedMemoryElementArray;
	UnusedMemoryElementArray = nullptr;

	delete[] UsageStatusArray;
	UsageStatusArray = nullptr;

	NumMemoryElements = numMemoryElements;
	NumMemoryElementsMinus1 = numMemoryElements - 1;
	UnusedMemoryElementArrayID = 1;

	
	UnusedMemoryElementArray =
		new (std::nothrow) size_t[NumMemoryElements];

	if (UnusedMemoryElementArray == nullptr)
		return false;

	
	UsageStatusArray = new (std::nothrow) bool[NumMemoryElements];

	if (UsageStatusArray == nullptr)
		return false;


	for (size_t i = 0; i < NumMemoryElements; i++)
	{
		UnusedMemoryElementArray[i] = i;
		UsageStatusArray[i] = false;
	}

	return true;
}

void CSimpleMemoryManager::Reset_Arrays(void)
{
	UnusedMemoryElementArrayID = 1;

	for (size_t i = 0; i < NumMemoryElements; i++)
	{
		UnusedMemoryElementArray[i] = i;
		UsageStatusArray[i] = false;
	}
}

size_t CSimpleMemoryManager::
Request_Unused_MemoryElementID(void)
{
	if (UnusedMemoryElementArrayID == NumMemoryElementsMinus1)
		return 0;

	size_t id = UnusedMemoryElementArray[
		UnusedMemoryElementArrayID];

	UsageStatusArray[id] = true;

	UnusedMemoryElementArrayID++;
	return id;
}

bool CSimpleMemoryManager::
Free_Used_MemoryElement(size_t id)
{
	if (id < 1)
		return false;

	if (id >= NumMemoryElementsMinus1)
		return false;

	if (UsageStatusArray[id] == false)
		return false;

	//if (UnusedMemoryElementArrayID == 1)
		//return false;

	UsageStatusArray[id] = false;

	UnusedMemoryElementArrayID--;
	UnusedMemoryElementArray[UnusedMemoryElementArrayID] = id;

	return true;
}

// Konstruktor:
CSimpleLinkedListManager::CSimpleLinkedListManager() : LinkedListElementArray(nullptr), NumUsedListElements(0), NumListElements(0), NumListElementsMinus1(0)
{}

// Destruktor:
CSimpleLinkedListManager::~CSimpleLinkedListManager()
{
	delete[] LinkedListElementArray;
	LinkedListElementArray = nullptr;
}

bool CSimpleLinkedListManager::
Initialize(size_t numListElements)
{
	delete[] LinkedListElementArray;
	LinkedListElementArray = nullptr;

	NumUsedListElements = 0;
	NumListElements = numListElements;
	NumListElementsMinus1 = numListElements - 1;

	/* Verzicht auf eine m�gliche Fehlerbehandlung
	(Ausnahme-Behandlung) bei der Speicheranforderung: */
	LinkedListElementArray =
		new (std::nothrow) CSimpleLinkedListElement[NumListElements];

	if (LinkedListElementArray == nullptr)
		return false;

	/* Erstes Element mit dem letzten
	Element verbinden: */
	LinkedListElementArray[0].NextElementID =
		NumListElementsMinus1;
	/* Letztes Element mit dem ersten
	Element verbinden: */
	LinkedListElementArray[NumListElementsMinus1].
		PrevElementID = 0;

	return true;
}

bool CSimpleLinkedListManager::
Init_New_ListElement(size_t elementID)
{
	// Element wird bereits verwendet:
	if (LinkedListElementArray[elementID].Used == true)
		return false;

	/* Erstes (id==0) und letztes (id==NumListElementsMinus1)
	Element dienen lediglich zur Listenverwaltung: */
	if (elementID < 1)
		return false;

	if (elementID >= NumListElementsMinus1)
		return false;

	LinkedListElementArray[elementID].Used = true;

	// Neues Element am Anfang der Liste einf�gen:

	/* ID des bisherigen ersten Elements
	zwischenspeichern: */
	size_t OldFirstElementID = LinkedListElementArray[0].
		NextElementID;

	// neues Element hinter dem Kopfknoten einf�gen:
	LinkedListElementArray[0].NextElementID = elementID;

	/* vormals erstes Element mit dem neuen ersten
	Element verkn�pfen: */
	LinkedListElementArray[OldFirstElementID].PrevElementID =
		elementID;

	/* neues erstes Element mit dem vormals ersten
	Element verkn�pfen: */
	LinkedListElementArray[elementID].NextElementID =
		OldFirstElementID;

	/* neues erstes Element mit dem Kopfknoten
	verkn�pfen: */
	LinkedListElementArray[elementID].PrevElementID = 0;


	NumUsedListElements++;

	return true;
}


bool CSimpleLinkedListManager::
Free_Used_ListElement(size_t elementID)
{
	/* Erstes (id==0) und letztes (id==NumListElementsMinus1)
	Element dienen lediglich zur Listenverwaltung: */
	if (elementID < 1)
		return false;

	if (elementID >= NumListElementsMinus1)
		return false;

	// Element wird bereits nicht mehr verwendet:
	if (LinkedListElementArray[elementID].Used == false)
		return false;

	LinkedListElementArray[elementID].Used = false;

	size_t NextElementID = LinkedListElementArray[
		elementID].NextElementID;

	size_t PrevElementID = LinkedListElementArray[
		elementID].PrevElementID;

	// �berbr�ckung des zu entfernenden Elements:

	LinkedListElementArray[PrevElementID].
		NextElementID = NextElementID;

	LinkedListElementArray[NextElementID].
		PrevElementID = PrevElementID;

	NumUsedListElements--;

	return true;
}

size_t CSimpleLinkedListManager::
Get_Next_Used_ListElement(
	size_t previousListElementID
/*first ID-Value must be 0*/)
{
	/* Falls m�glich das erste verwendete
	Element zur�ckgeben: */
	if (previousListElementID == 0)
	{
		if (NumUsedListElements == 0)
			return 0;
		else
			return LinkedListElementArray[0].NextElementID;
	}
	/* Falls m�glich ein weiteres verwendetes
	Element zur�ckgeben: */
	else
	{
		size_t tempID =
			LinkedListElementArray[previousListElementID].
			NextElementID;

		/* Kein Element gefunden (das letzte Element ist
		nur f�r Verwaltungsaufgaben vorgesehen): */
		if (tempID >= NumListElementsMinus1)
			return 0;
		else
			return tempID;
	}
}

//-----------------------------------------------------------------------------
// Ring Buffer
//-----------------------------------------------------------------------------

CRingBuffer::CRingBuffer()
{
	EntryList = NULL;

	NumReceivedEntries = 0;
	NumProcessedEntries = 0;
	NumEntriesInsideListMax = 0;
}


CRingBuffer::~CRingBuffer()
{
	delete[] EntryList;
	EntryList = nullptr;
}

void CRingBuffer::Init_Buffer(int32_t numEntriesInsideListMax)
{
	NumReceivedEntries = 0;
	NumProcessedEntries = 0;
	NumEntriesInsideListMax = numEntriesInsideListMax;

	delete[] EntryList;
	EntryList = nullptr;

	EntryList = new (std::nothrow) int32_t[NumEntriesInsideListMax];
}

void CRingBuffer::Reset_Buffer(void)
{
	NumReceivedEntries = 0;
	NumProcessedEntries = 0;
}

void CRingBuffer::Add_BufferEntry(int32_t value)
{
	EntryList[NumReceivedEntries] = value;
	NumReceivedEntries = (NumReceivedEntries + 1) % NumEntriesInsideListMax;
}

bool CRingBuffer::Get_BufferEntry(int32_t* pValue)
{
	if (NumProcessedEntries == NumReceivedEntries)
		return false;

	*pValue = EntryList[NumProcessedEntries];

	NumProcessedEntries = (NumProcessedEntries + 1) % NumEntriesInsideListMax;

	return true;
}

//-----------------------------------------------------------------------------
// Order Preserving Double Linked List
//-----------------------------------------------------------------------------

COrderPreservingDoubleLinkedList::COrderPreservingDoubleLinkedList()
{

}

COrderPreservingDoubleLinkedList::~COrderPreservingDoubleLinkedList()
{
	delete[] pListElementArray;
	pListElementArray = nullptr;
}


void COrderPreservingDoubleLinkedList::Initialize(int32_t numOfElements)
{
	delete[] pListElementArray;
	pListElementArray = nullptr;

	NumOfElements = numOfElements;
	NumOfActiveElements = numOfElements;
	NumOfElementsPlus1 = numOfElements + 1;
	NumOfElementsPlus2 = numOfElements + 2;

	pListElementArray = new (std::nothrow) CIndexBasedDoubleLinkedListElement[NumOfElementsPlus2];

	for (int32_t i = 0; i < NumOfElementsPlus2; i++)
	{
		pListElementArray[i].Set_ElementID(i);
		pListElementArray[i].inUse = true;
	}

	pListElementArray[0].id_LeftElement = NumOfElementsPlus1;
	pListElementArray[NumOfElementsPlus1].id_RightElement = 0;
}

void COrderPreservingDoubleLinkedList::Deactivate_All_Elements(void)
{
	NumOfActiveElements = 0;

	pListElementArray[0].id_RightElement = NumOfElements + 1;
	pListElementArray[NumOfElements + 1].id_LeftElement = 0;

	for (int32_t i = 1; i < NumOfElementsPlus1; i++)
	{
		pListElementArray[i].inUse = false;
	}
}

void COrderPreservingDoubleLinkedList::Reactivate_All_Elements(void)
{
	for (int32_t i = 0; i < NumOfElementsPlus2; i++)
	{
		pListElementArray[i].Set_ElementID(i);
		pListElementArray[i].inUse = true;
	}

	pListElementArray[0].id_LeftElement = NumOfElementsPlus1;
	pListElementArray[NumOfElementsPlus1].id_RightElement = 0;
}

int32_t COrderPreservingDoubleLinkedList::Get_IDs_Of_Active_Elements(int32_t *pOutElementIDArray)
{
	int32_t elementID = 0;
	int32_t nextElementID = pListElementArray[elementID].id_RightElement;

	for (int32_t i = 0; i < NumOfActiveElements; i++)
	{
		elementID = nextElementID;

		pOutElementIDArray[i] = elementID;

		nextElementID = pListElementArray[elementID].id_RightElement;
	}

	return NumOfActiveElements;
}

int32_t COrderPreservingDoubleLinkedList::Get_CorrectedIDs_Of_Active_Elements(int32_t *pOutElementIDArray)
{
	int32_t elementID = 0;
	int32_t nextElementID = pListElementArray[elementID].id_RightElement;

	for (int32_t i = 0; i < NumOfActiveElements; i++)
	{
		elementID = nextElementID;

		pOutElementIDArray[i] = elementID - 1;

		nextElementID = pListElementArray[elementID].id_RightElement;
	}

	return NumOfActiveElements;
}



int32_t COrderPreservingDoubleLinkedList::Get_First_Active_ElementID(void)
{
	return pListElementArray[0].id_RightElement;
}

int32_t COrderPreservingDoubleLinkedList::Get_Last_Active_ElementID(void)
{
	return pListElementArray[NumOfElementsPlus1].id_LeftElement;
}

int32_t COrderPreservingDoubleLinkedList::Get_Next_Active_ElementID(int32_t prevElementID)
{
	int32_t id = pListElementArray[prevElementID].id_RightElement;

	if (id > NumOfElements)
	{
		return 0;
	}

	return id;
}

int32_t COrderPreservingDoubleLinkedList::Get_Previous_Active_ElementID(int32_t nextElementID)
{
	int32_t id = pListElementArray[nextElementID].id_LeftElement;

	if (id > NumOfElements)
	{
		return 0;
	}

	return id;
}

void COrderPreservingDoubleLinkedList::Deactivate_Element(int32_t id)
{
	if (NumOfActiveElements < 1)
	{
		return;
	}

	if (id < 1)
	{
		return;
	}

	if (id > NumOfElements)
	{
		return;
	}

	if (pListElementArray[id].inUse == false)
	{
		return;
	}

	int32_t elementID = 0;
	int32_t nextElementID = pListElementArray[elementID].id_RightElement;

	do
	{
		if (nextElementID == id)
		{
			int32_t id_RightElement = pListElementArray[id].id_RightElement;
			pListElementArray[elementID].id_RightElement = id_RightElement;
			pListElementArray[id_RightElement].id_LeftElement = pListElementArray[id].id_LeftElement;

			pListElementArray[id].inUse = false;
			NumOfActiveElements--;
			return;
		}

		elementID = nextElementID;
		nextElementID = pListElementArray[elementID].id_RightElement;

		if (nextElementID == 0)
		{
			break;
		}

	} while (true);
}

void COrderPreservingDoubleLinkedList::Reactivate_Element(int32_t id)
{
	if (NumOfActiveElements >= NumOfElements)
	{
		return;
	}

	if (id < 1)
	{
		return;
	}

	if (id > NumOfElements)
	{
		return;
	}

	if (pListElementArray[id].inUse == true)
	{
		return;
	}

	int32_t elementID = 0;
	int32_t nextElementID = pListElementArray[elementID].id_RightElement;

	do
	{
		if (nextElementID > id)
		{
			pListElementArray[elementID].id_RightElement = id;
			pListElementArray[id].id_LeftElement = elementID;
			pListElementArray[id].id_RightElement = nextElementID;
			pListElementArray[nextElementID].id_LeftElement = id;

			pListElementArray[id].inUse = true;
			NumOfActiveElements++;
			return;
		}

		elementID = nextElementID;
		nextElementID = pListElementArray[elementID].id_RightElement;

		if (nextElementID == 0)
		{
			break;
		}

	} while (true);
}

//-----------------------------------------------------------------------------
// Order Preserving Single Linked List
//-----------------------------------------------------------------------------

COrderPreservingSingleLinkedList::COrderPreservingSingleLinkedList()
{

}

COrderPreservingSingleLinkedList::~COrderPreservingSingleLinkedList()
{
	delete[] pListElementArray;
	pListElementArray = nullptr;
}


void COrderPreservingSingleLinkedList::Initialize(int32_t numOfElements)
{
	delete[] pListElementArray;
	pListElementArray = nullptr;

	NumOfElements = numOfElements;
	NumOfActiveElements = numOfElements;
	NumOfElementsPlus1 = numOfElements + 1;
	NumOfElementsPlus2 = numOfElements + 2;

	pListElementArray = new (std::nothrow) CIndexBasedSingleLinkedListElement[NumOfElementsPlus2];

	for (int32_t i = 0; i < NumOfElementsPlus2; i++)
	{
		pListElementArray[i].Set_ElementID(i);
		pListElementArray[i].inUse = true;
	}

	pListElementArray[NumOfElementsPlus1].id_RightElement = 0;
}

void COrderPreservingSingleLinkedList::Deactivate_All_Elements(void)
{
	NumOfActiveElements = 0;

	pListElementArray[0].id_RightElement = NumOfElements + 1;
	
	for (int32_t i = 1; i < NumOfElementsPlus1; i++)
	{
		pListElementArray[i].inUse = false;
	}
}

void COrderPreservingSingleLinkedList::Reactivate_All_Elements(void)
{
	for (int32_t i = 0; i < NumOfElementsPlus2; i++)
	{
		pListElementArray[i].Set_ElementID(i);
		pListElementArray[i].inUse = true;
	}

	pListElementArray[NumOfElementsPlus1].id_RightElement = 0;
}

int32_t COrderPreservingSingleLinkedList::Get_IDs_Of_Active_Elements(int32_t *pOutElementIDArray)
{
	int32_t elementID = 0;
	int32_t nextElementID = pListElementArray[elementID].id_RightElement;

	for (int32_t i = 0; i < NumOfActiveElements; i++)
	{
		elementID = nextElementID;

		pOutElementIDArray[i] = elementID;

		nextElementID = pListElementArray[elementID].id_RightElement;
	}

	return NumOfActiveElements;
}

int32_t COrderPreservingSingleLinkedList::Get_CorrectedIDs_Of_Active_Elements(int32_t *pOutElementIDArray)
{
	int32_t elementID = 0;
	int32_t nextElementID = pListElementArray[elementID].id_RightElement;

	for (int32_t i = 0; i < NumOfActiveElements; i++)
	{
		elementID = nextElementID;

		pOutElementIDArray[i] = elementID - 1;

		nextElementID = pListElementArray[elementID].id_RightElement;
	}

	return NumOfActiveElements;
}



int32_t COrderPreservingSingleLinkedList::Get_First_Active_ElementID(void)
{
	return pListElementArray[0].id_RightElement;
}

int32_t COrderPreservingSingleLinkedList::Get_Next_Active_ElementID(int32_t prevElementID)
{
	int32_t id = pListElementArray[prevElementID].id_RightElement;

	if (id > NumOfElements)
	{
		return 0;
	}

	return id;
}

void COrderPreservingSingleLinkedList::Deactivate_Element(int32_t id)
{
	if (NumOfActiveElements < 1)
	{
		return;
	}

	if (id < 1)
	{
		return;
	}

	if (id > NumOfElements)
	{
		return;
	}

	if (pListElementArray[id].inUse == false)
	{
		return;
	}

	int32_t elementID = 0;
	int32_t nextElementID = pListElementArray[elementID].id_RightElement;

	do
	{
		if (nextElementID == id)
		{
			int32_t id_RightElement = pListElementArray[id].id_RightElement;
			pListElementArray[elementID].id_RightElement = id_RightElement;
			
			pListElementArray[id].inUse = false;
			NumOfActiveElements--;
			return;
		}

		elementID = nextElementID;
		nextElementID = pListElementArray[elementID].id_RightElement;

		if (nextElementID == 0)
		{
			break;
		}

	} while (true);
}

void COrderPreservingSingleLinkedList::Reactivate_Element(int32_t id)
{
	if (NumOfActiveElements >= NumOfElements)
	{
		return;
	}

	if (id < 1)
	{
		return;
	}

	if (id > NumOfElements)
	{
		return;
	}

	if (pListElementArray[id].inUse == true)
	{
		return;
	}

	int32_t elementID = 0;
	int32_t nextElementID = pListElementArray[elementID].id_RightElement;

	do
	{
		if (nextElementID > id)
		{
			pListElementArray[elementID].id_RightElement = id;
			pListElementArray[id].id_RightElement = nextElementID;
			
			pListElementArray[id].inUse = true;
			NumOfActiveElements++;
			return;
		}

		elementID = nextElementID;
		nextElementID = pListElementArray[elementID].id_RightElement;

		if (nextElementID == 0)
		{
			break;
		}

	} while (true);
}