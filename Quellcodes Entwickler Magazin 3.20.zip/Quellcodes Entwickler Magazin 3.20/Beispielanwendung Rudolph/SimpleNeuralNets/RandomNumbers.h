// Schutz vor Mehrfachdeklarationen:
#ifndef _RandomNumbers_H_
#define _RandomNumbers_H_

#include <iostream>

//namespace HelperStuff
//{

class CRandomNumbers_ParkMillerMLKG
{
private:

	/* Deklaration der ben�tigten Membervariablen und
	Konstanten. Ein �ffentlicher Zugriff ist im
	vorliegenden Fall nicht m�glich (weil nicht
	erforderlich): */

	uint64_t newValue;

	static constexpr uint64_t constParkMillerModulus =
		2147483647;
	static constexpr uint64_t constParkMillerMultiplier =
		48271;
	static constexpr double fconstParkMillerModulus =
		2147483647.0;

public:

	// Konstruktor (Deklaration):
	CRandomNumbers_ParkMillerMLKG();

	// Destruktor (Deklaration):
	~CRandomNumbers_ParkMillerMLKG();

	/* Deklaration der �ffentlich aufrufbaren
	Memberfunktionen (Klassenmethoden): */

	/* Neuen Startwert f�r die Berechnung der
	Zufallszahlen festlegen */
	void Change_Seed(uint64_t newSeed);

	/* Hinweis: Memberfunktionen lassen sich auch innerhalb
	einer Klassendeklarationen implementieren: */
	/*void Change_Seed( uint64_t newSeed)
	{
	newValue = newSeed;
	}*/

	/* Startwert f�r die Berechnung der Zufallszahlen
	auf 1 zur�cksetzen */
	void Reset_Seed(void);

	// zuf�llige 32-Bit-Flie�kommazahlen:
	float Get_FloatNumber(float low, float high);

	// zuf�llige 64-Bit-Flie�kommazahlen:
	double Get_DoubleNumber(double low, double high);

	// zuf�llige 32-Bit-Ganzzahlen:
	int32_t Get_IntegerNumber(int32_t low,
		int32_t high_excluded);

	// zuf�llige positive 32-Bit-Ganzzahlen:
	uint32_t Get_UnsignedIntegerNumber(uint32_t low,
		uint32_t high_excluded);

}; // end of class CRandomNumbers_ParkMillerMLKG

//} /* end of namespace HelperStuff */

#endif