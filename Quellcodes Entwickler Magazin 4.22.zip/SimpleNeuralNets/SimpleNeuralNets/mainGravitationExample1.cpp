#include <iostream>
//#include <chrono>
#include <thread>
#include "ConsoleHelperFunctions.h"
#include "RandomNumbers.h"
#include "NeuralNet.h"
#include "GravitationSamples.h"


using namespace std;
using namespace chrono;



#define KEYDOWN(vk_code) ((GetAsyncKeyState(vk_code) & 0x8000) ? 1 : 0)
#define KEYUP(vk_code)   ((GetAsyncKeyState(vk_code) & 0x8000) ? 0 : 1)



static char g_InputBuffer[100];


static void Set_ProcessPriority(unsigned long priority)
{
	HANDLE ProcessHandle = GetCurrentProcess();

	if (priority == 0)
		SetPriorityClass(ProcessHandle, NORMAL_PRIORITY_CLASS);
	else if (priority == 1)
		SetPriorityClass(ProcessHandle, ABOVE_NORMAL_PRIORITY_CLASS);
	else if (priority == 2)
		SetPriorityClass(ProcessHandle, HIGH_PRIORITY_CLASS);
	else
		SetPriorityClass(ProcessHandle, REALTIME_PRIORITY_CLASS);
}


/*
int main(void)
{
	//Set_ProcessPriority(2);

	//HelperStuff::Begin_Log(0, "Begin_Log", "Logfile.txt");

	CRandomNumbersNN RandomNumbers;

	CWindowsConsoleScreenBuffer WinConsole;
	WinConsole.Initialize(ConstGameBoardSizeX, ConstGameBoardSizeY, false, BackgroundColor);

	Set_Title("NeuralNetGravitationSample1 (neuro-evolution running ... )");
	Set_ConsolePos(10, 10);

	WinConsole.Set_CursorVisibilityAndSize(FALSE);
	//WinConsole.Set_Font(L"Consolas", 15, 15);
	WinConsole.Set_Font(L"Consolas", 4, 4);
	//WinConsole.Set_Font(L"Consolas", 8, 8);
	//WinConsole.Set_Font_Ext(L"Consolas", 90, 10, 10);
	

	//WinConsole.Set_BackgroundColor(RGB(100, 50, 25));
	WinConsole.Set_BackgroundColor(BackgroundColor);

	Set_CursorVisibilityAndSize(false);

	
	float FrameTime = 0.0f;

	CWindowsConsole2DObject Target;
	Target.Initialize(5, 5);

	Target.Set_Pixel(0, 0, lightred);
	Target.Set_Pixel(4, 0, lightred);
	Target.Set_Pixel(1, 1, lightred);
	Target.Set_Pixel(3, 1, lightred);
	Target.Set_Pixel(2, 2, lightred);
	Target.Set_Pixel(1, 3, lightred);
	Target.Set_Pixel(3, 3, lightred);
	Target.Set_Pixel(0, 4, lightred);
	Target.Set_Pixel(4, 4, lightred);

	CWindowsConsole2DObject Ball;
	Ball.Initialize(5, 5);

	Ball.Set_Pixel(0, 0, black);
	Ball.Set_Pixel(1, 0, lightgreen);
	Ball.Set_Pixel(2, 0, lightgreen);
	Ball.Set_Pixel(3, 0, lightgreen);
	Ball.Set_Pixel(4, 0, black);

	Ball.Set_Pixel(0, 1, lightgreen);
	Ball.Set_Pixel(1, 1, lightgreen);
	Ball.Set_Pixel(2, 1, lightgreen);
	Ball.Set_Pixel(3, 1, lightgreen);
	Ball.Set_Pixel(4, 1, lightgreen);

	Ball.Set_Pixel(0, 2, lightgreen);
	Ball.Set_Pixel(1, 2, lightgreen);
	Ball.Set_Pixel(2, 2, lightgreen);
	Ball.Set_Pixel(3, 2, lightgreen);
	Ball.Set_Pixel(4, 2, lightgreen);

	Ball.Set_Pixel(0, 3, lightgreen);
	Ball.Set_Pixel(1, 3, lightgreen);
	Ball.Set_Pixel(2, 3, lightgreen);
	Ball.Set_Pixel(3, 3, lightgreen);
	Ball.Set_Pixel(4, 3, lightgreen);

	Ball.Set_Pixel(0, 4, black);
	Ball.Set_Pixel(1, 4, lightgreen);
	Ball.Set_Pixel(2, 4, lightgreen);
	Ball.Set_Pixel(3, 4, lightgreen);
	Ball.Set_Pixel(4, 4, black);
	
	CSimpleArtilleryAIPopulation ArtilleryAIPopulation;

	int32_t NumTrainingGenerationsMax = 500;
	int32_t NumSimpleMutationGenerations = 50;
	//int32_t NumTrainingGamesPerEpoch = 300;
	int32_t NumTrainingGamesPerEpoch = 30;

	int32_t TrainingPopulationSize = 200;
	int32_t NumOfHiddenNeuronsL1 = 10;
	//int32_t NumOfHiddenNeuronsL1 = 20;
	int32_t NumOfHiddenNeuronsL2 = 0;

	//float MinSynapticPlasticity = -0.1f;
	//float MaxSynapticPlasticity = 0.1f;

	float MinSynapticPlasticity = -0.05f;
	float MaxSynapticPlasticity = 0.05f;

	float MinSynapticPlasticityVariance = -0.0001f;
	float MaxSynapticPlasticityVariance = 0.0001f;

	//bool ExtremeLearning = false;
	bool ExtremeLearning = true;

	float PlasticityMutationRate = 0.1f;

	float PlasticityMutationRateL1 = 0.0f;
	float PlasticityMutationRateL2 = 0.0f;
	float PlasticityMutationRateL3 = 0.0f;

	//float PlasticityMutationRateL1 = 0.1f;
	//float PlasticityMutationRateL2 = 0.1f;
	//float PlasticityMutationRateL3 = 0.1f;


	//float TopologyMutationRateL1 = 0.1f;
	//float TopologyMutationRateL2 = 0.1f;
	//float TopologyMutationRateL3 = 0.1f;


	float TopologyMutationRateL1 = 0.0f;
	float TopologyMutationRateL2 = 0.0f;
	float TopologyMutationRateL3 = 0.0f;


	float GravitationAccelerationX = 0.0f;
	float GravitationAccelerationY = 20.0f;
	

	ArtilleryAIPopulation.Initialize(TrainingPopulationSize, NumOfHiddenNeuronsL1, NumOfHiddenNeuronsL2);

	ArtilleryAIPopulation.RandomChange_OutputSynapsePlasticities(MinSynapticPlasticity, MaxSynapticPlasticity);

	if (TopologyMutationRateL1 != 0.0f || TopologyMutationRateL2 != 0.0f || TopologyMutationRateL3 != 0.0f)
	{
		ArtilleryAIPopulation.RandomReduce_BrainConnections(TopologyMutationRateL1, TopologyMutationRateL2, TopologyMutationRateL3);
	}



	CNeuralNetPopulation NeuralNetPopulation;

	NeuralNetPopulation.Initialize(ArtilleryAIPopulation.PopulationSize, ArtilleryAIPopulation.NumOfInputNeurons, ArtilleryAIPopulation.NumOfOutputNeurons, NumOfHiddenNeuronsL1, NumOfHiddenNeuronsL1, NumOfHiddenNeuronsL2, NumOfHiddenNeuronsL2, FastTanHReplacementOutput, LinearOutput, LinearOutput);

	Init_NeuralNetPopulation(&NeuralNetPopulation, &ArtilleryAIPopulation);

	

	for (int32_t i = 0; i < NumSimpleMutationGenerations; i++)
	{
		ArtilleryAIPopulation.Init_Play_and_Evaluate_NewTrainingSequence(400, NumTrainingGamesPerEpoch, GravitationAccelerationX, GravitationAccelerationY, 0.025f);
		

		NeuralNetPopulation.Update_Population(ArtilleryAIPopulation.pFitnessScoreArray);


		if (PlasticityMutationRate != 0.0f)
		{
			NeuralNetPopulation.Update_Evolution_SynapticPlasticityMutationsOnly(MinSynapticPlasticity, MaxSynapticPlasticity, PlasticityMutationRate, ExtremeLearning);
		}
		else if (PlasticityMutationRate == 0.0f)
		{
			NeuralNetPopulation.Update_Evolution_SynapticPlasticityMutationsOnly(MinSynapticPlasticity, MaxSynapticPlasticity, PlasticityMutationRateL1, PlasticityMutationRateL2, PlasticityMutationRateL3, ExtremeLearning);
		}

		if (TopologyMutationRateL1 != 0.0f || TopologyMutationRateL2 != 0.0f || TopologyMutationRateL3 != 0.0f)
		{
			NeuralNetPopulation.Update_Evolution_ConnectionTopologyMutationsOnly(MinSynapticPlasticity, MaxSynapticPlasticity, TopologyMutationRateL1, TopologyMutationRateL2, TopologyMutationRateL3, true);
		}

		if (PlasticityMutationRate != 0.0f)
		{
			NeuralNetPopulation.Update_Evolution_BestBrainOnly(MinSynapticPlasticityVariance, MaxSynapticPlasticityVariance, PlasticityMutationRate);
			NeuralNetPopulation.Update_Evolution_SecondBestBrainOnly(MinSynapticPlasticityVariance, MaxSynapticPlasticityVariance, PlasticityMutationRate);
		}
		else if (PlasticityMutationRate == 0.0f)
		{
			NeuralNetPopulation.Update_Evolution_BestBrainOnly(MinSynapticPlasticityVariance, MaxSynapticPlasticityVariance, PlasticityMutationRateL1, PlasticityMutationRateL2, PlasticityMutationRateL3);
			NeuralNetPopulation.Update_Evolution_SecondBestBrainOnly(MinSynapticPlasticityVariance, MaxSynapticPlasticityVariance, PlasticityMutationRateL1, PlasticityMutationRateL2, PlasticityMutationRateL3);
		}

		if (TopologyMutationRateL1 != 0.0f || TopologyMutationRateL2 != 0.0f || TopologyMutationRateL3 != 0.0f)
		{
			NeuralNetPopulation.Restore_ConnectionTopology_WorstFitted_Brain(MinSynapticPlasticity, MaxSynapticPlasticity);
			NeuralNetPopulation.Restore_ConnectionTopology_SecondWorstFitted_Brain(MinSynapticPlasticity, MaxSynapticPlasticity);
			NeuralNetPopulation.Restore_ConnectionTopology_ThirdWorstFitted_Brain(MinSynapticPlasticity, MaxSynapticPlasticity);
		}
	}

	for (int32_t i = NumSimpleMutationGenerations; i < NumTrainingGenerationsMax; i++)
	{
		ArtilleryAIPopulation.Init_Play_and_Evaluate_NewTrainingSequence(400, NumTrainingGamesPerEpoch, GravitationAccelerationX, GravitationAccelerationY, 0.025f);
		

		NeuralNetPopulation.Update_Population(ArtilleryAIPopulation.pFitnessScoreArray);

		if (PlasticityMutationRate != 0.0f)
		{
			NeuralNetPopulation.Update_Evolution_SynapticPlasticityMutationsOnly(MinSynapticPlasticity, MaxSynapticPlasticity, PlasticityMutationRate, ExtremeLearning);
		}
		else if (PlasticityMutationRate == 0.0f)
		{
			NeuralNetPopulation.Update_Evolution_SynapticPlasticityMutationsOnly(MinSynapticPlasticity, MaxSynapticPlasticity, PlasticityMutationRateL1, PlasticityMutationRateL2, PlasticityMutationRateL3, ExtremeLearning);
		}



		if (TopologyMutationRateL1 != 0.0f || TopologyMutationRateL2 != 0.0f || TopologyMutationRateL3 != 0.0f)
		{
			NeuralNetPopulation.Update_Evolution_ConnectionTopologyMutationsOnly(MinSynapticPlasticity, MaxSynapticPlasticity, TopologyMutationRateL1, TopologyMutationRateL2, TopologyMutationRateL3, true);
		}

		if (PlasticityMutationRate != 0.0f)
		{
			NeuralNetPopulation.Update_Evolution_BestBrainOnly(MinSynapticPlasticityVariance, MaxSynapticPlasticityVariance, PlasticityMutationRate);
			NeuralNetPopulation.Update_Evolution_SecondBestBrainOnly(MinSynapticPlasticityVariance, MaxSynapticPlasticityVariance, PlasticityMutationRate);
		}
		else if (PlasticityMutationRate == 0.0f)
		{
			NeuralNetPopulation.Update_Evolution_BestBrainOnly(MinSynapticPlasticityVariance, MaxSynapticPlasticityVariance, PlasticityMutationRateL1, PlasticityMutationRateL2, PlasticityMutationRateL3);
			NeuralNetPopulation.Update_Evolution_SecondBestBrainOnly(MinSynapticPlasticityVariance, MaxSynapticPlasticityVariance, PlasticityMutationRateL1, PlasticityMutationRateL2, PlasticityMutationRateL3);
		}


		NeuralNetPopulation.Update_Evolution_Combine_BestTwoBrains();
		NeuralNetPopulation.Update_Evolution_Combine_TwoBrains();

		if (TopologyMutationRateL1 != 0.0f || TopologyMutationRateL2 != 0.0f || TopologyMutationRateL3 != 0.0f)
		{
			NeuralNetPopulation.Restore_ConnectionTopology_WorstFitted_Brain(MinSynapticPlasticity, MaxSynapticPlasticity);
			NeuralNetPopulation.Restore_ConnectionTopology_SecondWorstFitted_Brain(MinSynapticPlasticity, MaxSynapticPlasticity);
			NeuralNetPopulation.Restore_ConnectionTopology_ThirdWorstFitted_Brain(MinSynapticPlasticity, MaxSynapticPlasticity);
		}

		//NeuralNetPopulation.Round_OutputWeights(0.00001f);
	}

	Set_Title("NeuralNetGravitationSample1 (SPACE: Fire)");


	CSimpleArtilleryAI ArtilleryAI;
	ArtilleryAI.Initialize(NumOfHiddenNeuronsL1, NumOfHiddenNeuronsL2);
	ArtilleryAI.Brain.Clone_OutputSynapsePlasticities(NeuralNetPopulation.Get_Best_Evolved_NeuralNet());
	//NeuralNetPopulation.Get_Best_Evolved_NeuralNet_Ext(&ArtilleryAI.Brain);

	RandomNumbers.Change_Seed(10);

	int32_t iFirePosX = RandomNumbers.Get_IntegerNumber2(ArtilleryAIPopulation.iFirePosXMin, ArtilleryAIPopulation.iFirePosXMax);
	int32_t iFirePosY = RandomNumbers.Get_IntegerNumber2(ArtilleryAIPopulation.iFirePosYMin, ArtilleryAIPopulation.iFirePosYMax);

	int32_t iTargetPosX = RandomNumbers.Get_IntegerNumber2(ArtilleryAIPopulation.iTargetPosXMin, ArtilleryAIPopulation.iTargetPosXMax);
	int32_t iTargetPosY = RandomNumbers.Get_IntegerNumber2(ArtilleryAIPopulation.iTargetPosYMin, ArtilleryAIPopulation.iTargetPosYMax);

	int32_t iTargetVelX = RandomNumbers.Get_IntegerNumber2(ArtilleryAIPopulation.iTargetVelXMin, ArtilleryAIPopulation.iTargetVelXMax);
	int32_t iTargetVelY = RandomNumbers.Get_IntegerNumber2(ArtilleryAIPopulation.iTargetVelYMin, ArtilleryAIPopulation.iTargetVelYMax);

	float TargetPosX = static_cast<float>(iTargetPosX);
	float TargetPosY = static_cast<float>(iTargetPosY);

	float TargetVelX = static_cast<float>(iTargetVelX);
	float TargetVelY = static_cast<float>(iTargetVelY);
	

	CSimplePhysicsObject SimplePhysicsObject;

	SimplePhysicsObject.posX = static_cast<float>(iFirePosX);
	SimplePhysicsObject.posY = static_cast<float>(iFirePosY);


	ArtilleryAI.Calculate_FiringSolution(&SimplePhysicsObject.velX, &SimplePhysicsObject.velY, SimplePhysicsObject.posX, SimplePhysicsObject.posY, TargetPosX, TargetPosY, TargetVelX, TargetVelY, GravitationAccelerationX, GravitationAccelerationY);

	SimplePhysicsObject.accelX = GravitationAccelerationX;
	SimplePhysicsObject.accelY = GravitationAccelerationY;

	int32_t counter = 0;

	do
	{
		//auto last_timepoint = std::chrono::steady_clock::now();
		auto last_timepoint = steady_clock::now();
		

		if (KEYDOWN(VK_ESCAPE) == true)
			break;

		SimplePhysicsObject.Update(FrameTime);

		
		WinConsole.Clear_BackBuffer();

		//float distXSq = SimplePhysicsObject.posX - TargetPosX;
		//distXSq *= distXSq;

		//float distYSq = SimplePhysicsObject.posY - TargetPosY;
		//distYSq *= distYSq;

		int32_t posX_Left = SimplePhysicsObject.posX - Ball.NumCharactersPerRow / 2;
		int32_t posY_Top = SimplePhysicsObject.posY - Ball.NumCharactersPerColumn / 2;

		WinConsole.Draw_2DObject_Into_BackBuffer(posX_Left, posY_Top, Ball.pDataArray, Ball.NumCharactersPerRow, Ball.NumCharactersPerColumn);
	
		TargetPosX += TargetVelX * FrameTime;
		TargetPosY += TargetVelY * FrameTime;

		posX_Left = static_cast<int32_t>(TargetPosX) - Target.NumCharactersPerRow / 2;
		posY_Top = static_cast<int32_t>(TargetPosY) - Target.NumCharactersPerColumn / 2;

		WinConsole.Draw_2DObject_Into_BackBuffer(posX_Left, posY_Top, Target.pDataArray, Target.NumCharactersPerRow, Target.NumCharactersPerColumn);
		//WinConsole.Write_Pixel_Into_BackBuffer(iTargetPosX, iTargetPosY, lightred);

		WinConsole.Present_BackBuffer();

		counter++;

		if (GetAsyncKeyState(VK_SPACE) || GetAsyncKeyState(VK_RETURN) || counter > 400)
		{
			counter = 0;

			iFirePosX = RandomNumbers.Get_IntegerNumber2(ArtilleryAIPopulation.iFirePosXMin, ArtilleryAIPopulation.iFirePosXMax);
			iFirePosY = RandomNumbers.Get_IntegerNumber2(ArtilleryAIPopulation.iFirePosYMin, ArtilleryAIPopulation.iFirePosYMax);

			iTargetPosX = RandomNumbers.Get_IntegerNumber2(ArtilleryAIPopulation.iTargetPosXMin, ArtilleryAIPopulation.iTargetPosXMax);
			iTargetPosY = RandomNumbers.Get_IntegerNumber2(ArtilleryAIPopulation.iTargetPosYMin, ArtilleryAIPopulation.iTargetPosYMax);

			iTargetVelX = RandomNumbers.Get_IntegerNumber2(ArtilleryAIPopulation.iTargetVelXMin, ArtilleryAIPopulation.iTargetVelXMax);
			iTargetVelY = RandomNumbers.Get_IntegerNumber2(ArtilleryAIPopulation.iTargetVelYMin, ArtilleryAIPopulation.iTargetVelYMax);

			TargetPosX = static_cast<float>(iTargetPosX);
			TargetPosY = static_cast<float>(iTargetPosY);

			TargetVelX = static_cast<float>(iTargetVelX);
			TargetVelY = static_cast<float>(iTargetVelY);

			SimplePhysicsObject.Reset_Values();

			SimplePhysicsObject.posX = static_cast<float>(iFirePosX);
			SimplePhysicsObject.posY = static_cast<float>(iFirePosY);


			ArtilleryAI.Calculate_FiringSolution(&SimplePhysicsObject.velX, &SimplePhysicsObject.velY, SimplePhysicsObject.posX, SimplePhysicsObject.posY, TargetPosX, TargetPosY, TargetVelX, TargetVelY, GravitationAccelerationX, GravitationAccelerationY);

			SimplePhysicsObject.accelX = GravitationAccelerationX;
			SimplePhysicsObject.accelY = GravitationAccelerationY;
		}

		//Frame-Bremse:

		auto current_timepoint = steady_clock::now();
		

		//while (current_timepoint - last_timepoint < 50ms)
		//while (current_timepoint - last_timepoint < 16ms)
		while (current_timepoint - last_timepoint < 16666us) // 16.7 Millisekunden (ms)  bzw. 16666 Mikrosekunden (us): maximal 60 Frames pro Sekunde					
		{
			current_timepoint = steady_clock::now();
			
		}


		FrameTime = 0.000000001f * (current_timepoint - last_timepoint).count();
		//HelperStuff::Add_To_Log(0, "dt (s)", FrameTime);

		//FrameTime = 0.025f;


	} while (true);

	WinConsole.Clear_BackBuffer();
	WinConsole.Present_BackBuffer();
	WinConsole.CleanUp();


	Set_CursorVisibilityAndSize(true);
	Reset_CursorPos();
	//Set_CursorPos(0, 0);

	cout << "bye bye (Press Return)" << endl;


	getchar();
	return 0;

}
*/

