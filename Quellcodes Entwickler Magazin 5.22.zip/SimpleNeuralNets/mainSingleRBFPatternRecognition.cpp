#include <iostream>
#include "ConsoleHelperFunctions.h"
#include "NeuralNet_V2.h"

using namespace std;

inline void RBFActivationFunction(CNeuronV2 *pNeuron)
{
	pNeuron->Dendrite_InputCounter = 0;

	//pNeuron->NeuronOutput = exp(-pNeuron->NeuronInput); 
	pNeuron->NeuronOutput = max(0.0f, 1.0f - pNeuron->NeuronInput);

	pNeuron->NeuronInput = 0.0f;
}

inline float StandardRBFActivationFunction(float neuronInput)
{
	return exp(-0.1f * neuronInput); 
	//return exp(-neuronInput); // sehr gro�er Unterschied schon bei kleinen Abweichungen!
	//return exp(-pow(neuronInput, 0.25f));
	//return exp(-sqrt(neuronInput));
	//return 1.0f / (neuronInput + 0.0001f);
	//return  max(0.0f, 1.0f - 0.05f*neuronInput);
	//return  max(0.0f, 1.0f - 0.05f*neuronInput*neuronInput);
	
	//float tempFloat = max(0.0f, 1.0f - 0.05f*neuronInput);
	//return tempFloat*tempFloat;	
}

inline float RBFActivationFunction1(float neuronInput)
{
	return 1.0f - tanh(0.05f * neuronInput);
}

inline float RBFActivationFunction2(float neuronInput)
{
	//return exp(-neuronInput * neuronInput * neuronInput * neuronInput);

/*	//return 1.0f - tanh(neuronInput * neuronInput * neuronInput);

	float tempfloat = 1.0f - tanh(neuronInput * neuronInput * neuronInput * neuronInput);
	//float tempfloat = 1.0f - tanh(neuronInput * neuronInput * neuronInput);
	
	if (tempfloat < 0.1f)
		return 0.0f;

	return tempfloat;
	*/

	return 1.0f - tanh(neuronInput * neuronInput * neuronInput * neuronInput);
}

/*
int main(void)
{
	static float Image_Object1[32 * 32];
	static float Image_Object2[32 * 32];
	static float Image_Object3[32 * 32];
	static float Image_Object4[32 * 32];
	static float Image_Object5[32 * 32];
	static float Image_Object6[32 * 32];

	static float Image_5_1[32 * 32];
	static float Image_5_2[32 * 32];
	static float Image_5_3[32 * 32];
	static float Image_5_4[32 * 32];
	static float Image_5_5[32 * 32];
	static float Image_S_1[32 * 32];

	uint8_t *pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_Object1.bmp");

	Get_BinaryImageData_BlueChannel(Image_Object1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_Object2.bmp");

	Get_BinaryImageData_BlueChannel(Image_Object2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_Object3.bmp");

	Get_BinaryImageData_BlueChannel(Image_Object3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_Object4.bmp");

	Get_BinaryImageData_BlueChannel(Image_Object4, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_Object5.bmp");

	Get_BinaryImageData_BlueChannel(Image_Object5, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_Object6.bmp");

	Get_BinaryImageData_BlueChannel(Image_Object6, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_5_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_5_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_5_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_4.bmp");

	Get_BinaryImageData_BlueChannel(Image_5_4, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_5_5.bmp");

	Get_BinaryImageData_BlueChannel(Image_5_5, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_S_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_S_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;



	C2DPatternDetectorV2 PatternDetector;

	PatternDetector.Set_SizeOnly(32, 32);

	CNeuronV2 Neuron;

	Neuron.Init_Dendrite_Arrays(32 * 32);

	Neuron.Set_NumOfTrainingExamples(0);

	Neuron.Add_Dendrite_CentroidValues(Image_Object1);
	Neuron.Calculate_Dendrite_Factors_From_CentroidValues(10.0f, 0.025f, 2);

	Neuron.Add_Dendrite_CentroidValues(Image_Object2);
	Neuron.Calculate_Dendrite_Factors_From_CentroidValues(10.0f, 0.025f, 2);

	Neuron.Add_Dendrite_CentroidValues(Image_Object3);
	Neuron.Calculate_Dendrite_Factors_From_CentroidValues(10.0f, 0.025f, 2);

	Neuron.Add_Dendrite_CentroidValues(Image_Object6);
	Neuron.Calculate_Dendrite_Factors_From_CentroidValues(10.0f, 0.025f, 2);

	Neuron.Add_Dendrite_CentroidValues(Image_5_3);
	Neuron.Calculate_Dendrite_Factors_From_CentroidValues(10.0f, 0.025f, 2);

	Neuron.Add_Dendrite_CentroidValues(Image_S_1);
	Neuron.Calculate_Dendrite_Factors_From_CentroidValues(10.0f, 0.025f, 2);

	

	PatternDetector.Connect_With_Neuron(&Neuron);

	float activationValue;

	PatternDetector.Check_For_Pattern_RBF(&activationValue, 0, 0, Image_Object1, 32, 32, StandardRBFActivationFunction, 0.0f);
	cout << activationValue << endl;

	PatternDetector.Check_For_Pattern_RBF(&activationValue, 0, 0, Image_Object2, 32, 32, StandardRBFActivationFunction, 0.0f);
	cout << activationValue << endl;

	PatternDetector.Check_For_Pattern_RBF(&activationValue, 0, 0, Image_Object3, 32, 32, StandardRBFActivationFunction, 0.0f);
	cout << activationValue << endl;

	PatternDetector.Check_For_Pattern_RBF(&activationValue, 0, 0, Image_Object4, 32, 32, StandardRBFActivationFunction, 0.0f);
	cout << activationValue << endl;

	PatternDetector.Check_For_Pattern_RBF(&activationValue, 0, 0, Image_Object5, 32, 32, StandardRBFActivationFunction, 0.0f);
	cout << activationValue << endl;

	PatternDetector.Check_For_Pattern_RBF(&activationValue, 0, 0, Image_Object6, 32, 32, StandardRBFActivationFunction, 0.0f);
	cout << activationValue << endl;

	PatternDetector.Check_For_Pattern_RBF(&activationValue, 0, 0, Image_5_1, 32, 32, StandardRBFActivationFunction, 0.0f);
	cout << activationValue << endl;

	PatternDetector.Check_For_Pattern_RBF(&activationValue, 0, 0, Image_5_2, 32, 32, StandardRBFActivationFunction, 0.0f);
	cout << activationValue << endl;

	PatternDetector.Check_For_Pattern_RBF(&activationValue, 0, 0, Image_5_3, 32, 32, StandardRBFActivationFunction, 0.0f);
	cout << activationValue << endl;

	PatternDetector.Check_For_Pattern_RBF(&activationValue, 0, 0, Image_5_4, 32, 32, StandardRBFActivationFunction, 0.0f);
	cout << activationValue << endl;

	PatternDetector.Check_For_Pattern_RBF(&activationValue, 0, 0, Image_5_5, 32, 32, StandardRBFActivationFunction, 0.0f);
	cout << activationValue << endl;

	PatternDetector.Check_For_Pattern_RBF(&activationValue, 0, 0, Image_S_1, 32, 32, StandardRBFActivationFunction, 0.0f);
	cout << activationValue << endl;

	getchar();
	return 0;
}
*/




/*
int main(void)
{
	static float Image_B_1[32 * 32];
	static float Image_B_2[32 * 32];
	static float Image_B_3[32 * 32];
	static float Image_B_4[32 * 32];
	static float Image_B_5[32 * 32];
	static float Image_B_6[32 * 32];

	static float Image_8_1[32 * 32];
	static float Image_8_2[32 * 32];
	static float Image_8_3[32 * 32];

	static float Image_B_Part1[32 * 32];
	static float Image_B_Part2[32 * 32];
	static float Image_B_Part3[32 * 32];

	uint8_t *pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_4.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_4, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_5.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_5, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_6.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_6, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	//////////////////

	pImageData = Read_Bitmap_BGR("Sample_B_Part1.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_Part1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_Part2.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_Part2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_B_Part3.bmp");

	Get_BinaryImageData_BlueChannel(Image_B_Part3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	//////////////////

	pImageData = Read_Bitmap_BGR("Sample_8_1.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_1, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_2.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_2, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;

	pImageData = Read_Bitmap_BGR("Sample_8_3.bmp");

	Get_BinaryImageData_BlueChannel(Image_8_3, pImageData, 32, 32);

	delete[] pImageData;
	pImageData = nullptr;



	C2DPatternDetectorV2 PatternDetector;

	PatternDetector.Set_SizeOnly(32, 32);

	CNeuronV2 Neuron;

	Neuron.Init_Dendrite_Arrays(32 * 32);

	Neuron.Set_NumOfTrainingExamples(0);

	Neuron.Add_Dendrite_CentroidValues(Image_B_1);
	Neuron.Calculate_Dendrite_Factors_From_CentroidValues(0.5f, 0.025f, 4);

	Neuron.Add_Dendrite_CentroidValues(Image_B_2);
	Neuron.Calculate_Dendrite_Factors_From_CentroidValues(0.5f, 0.025f, 4);

	Neuron.Add_Dendrite_CentroidValues(Image_B_4);
	Neuron.Calculate_Dendrite_Factors_From_CentroidValues(0.5f, 0.025f, 4);

	//Neuron.Add_Dendrite_CentroidValues(Image_B_6);
	//Neuron.Calculate_Dendrite_Factors_From_CentroidValues(0.5f, 0.025f, 4);
	
	//Neuron.Set_Dendrite_Factor(0.2f, 0.0f, 0.0f);

	PatternDetector.Connect_With_Neuron(&Neuron);

	float activationValue;

	PatternDetector.Check_For_Pattern_RBF(&activationValue, 0, 0, Image_B_1, 32, 32, RBFActivationFunction1, 0.0f);
	cout << activationValue << endl;

	PatternDetector.Check_For_Pattern_RBF(&activationValue, 0, 0, Image_B_2, 32, 32, RBFActivationFunction1, 0.0f);
	cout << activationValue << endl;

	// Detector identifiziert unbekanntes Image_B_3 als B
	PatternDetector.Check_For_Pattern_RBF(&activationValue, 0, 0, Image_B_3, 32, 32, RBFActivationFunction1, 0.0f);
	cout << activationValue << endl;

	PatternDetector.Check_For_Pattern_RBF(&activationValue, 0, 0, Image_B_4, 32, 32, RBFActivationFunction1, 0.0f);
	cout << activationValue << endl;

	// Detector identifiziert unbekanntes Image_B_5 als B
	PatternDetector.Check_For_Pattern_RBF(&activationValue, 0, 0, Image_B_5, 32, 32, RBFActivationFunction1, 0.0f);
	cout << activationValue << endl;

	PatternDetector.Check_For_Pattern_RBF(&activationValue, 0, 0, Image_8_1, 32, 32, RBFActivationFunction1, 0.0f);
	cout << activationValue << endl;

	PatternDetector.Check_For_Pattern_RBF(&activationValue, 0, 0, Image_8_2, 32, 32, RBFActivationFunction1, 0.0f);
	cout << activationValue << endl;

	PatternDetector.Check_For_Pattern_RBF(&activationValue, 0, 0, Image_8_3, 32, 32, RBFActivationFunction1, 0.0f);
	cout << activationValue << endl;

	//////////////////////////////////////////////

	cout << endl;

	CNeuronV2 Neuron2;

	Neuron2.Init_Dendrite_Arrays(32 * 32);

	Neuron2.Set_NumOfTrainingExamples(0);

	Neuron2.Add_Dendrite_CentroidValues(Image_B_Part1);	
	Neuron2.Calculate_Dendrite_Factors_From_CentroidValues(0.5f, 0.025f, 4);
	
	Neuron2.Add_Dendrite_CentroidValues(Image_B_Part2);
	Neuron2.Calculate_Dendrite_Factors_From_CentroidValues(0.5f, 0.025f, 4);
	
	Neuron2.Add_Dendrite_CentroidValues(Image_B_Part3);
	Neuron2.Calculate_Dendrite_Factors_From_CentroidValues(0.5f, 0.025f, 4);
	
	//Neuron2.Set_Dendrite_Factor(0.001f, 0.0f, 0.0f);
	Neuron2.Set_Dendrite_Factor(0.0f, 0.0f, 0.0f);
	
	PatternDetector.Connect_With_Neuron(&Neuron2);

	PatternDetector.Check_For_Pattern_RBF(&activationValue, 0, 0, Image_B_1, 32, 32, RBFActivationFunction2, 0.0f);
	cout << activationValue << endl;

	PatternDetector.Check_For_Pattern_RBF(&activationValue, 0, 0, Image_B_2, 32, 32, RBFActivationFunction2, 0.0f);
	cout << activationValue << endl;

	PatternDetector.Check_For_Pattern_RBF(&activationValue, 0, 0, Image_B_3, 32, 32, RBFActivationFunction2, 0.0f);
	cout << activationValue << endl;

	PatternDetector.Check_For_Pattern_RBF(&activationValue, 0, 0, Image_B_4, 32, 32, RBFActivationFunction2, 0.0f);
	cout << activationValue << endl;

	PatternDetector.Check_For_Pattern_RBF(&activationValue, 0, 0, Image_B_5, 32, 32, RBFActivationFunction2, 0.0f);
	cout << activationValue << endl;

	PatternDetector.Check_For_Pattern_RBF(&activationValue, 0, 0, Image_8_1, 32, 32, RBFActivationFunction2, 0.0f);
	cout << activationValue << endl;

	PatternDetector.Check_For_Pattern_RBF(&activationValue, 0, 0, Image_8_2, 32, 32, RBFActivationFunction2, 0.0f);
	cout << activationValue << endl;

	PatternDetector.Check_For_Pattern_RBF(&activationValue, 0, 0, Image_8_3, 32, 32, RBFActivationFunction2, 0.0f);
	cout << activationValue << endl;

	

	getchar();
	return 0;
}
*/







