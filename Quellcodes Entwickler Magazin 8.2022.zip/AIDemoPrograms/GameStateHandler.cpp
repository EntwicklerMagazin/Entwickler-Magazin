#include "GameStateHandler.h"


using namespace std;
using namespace HelperStuff;


#define PRUNING

int32_t g_NumOfMultipleVisitedGameStates = 0;
int32_t g_NumOfGameStatesWithTooLowEvalValues = 0;

CInitialGameBoards::CInitialGameBoards()
{

}

CInitialGameBoards::~CInitialGameBoards()
{
	delete[] pInitialGameStateArray;
	pInitialGameStateArray = nullptr;
}

bool CInitialGameBoards::Initialize(const char* pFilename, int32_t gameBoardSizeXDir, int32_t gameBoardSizeYDir)
{
	delete[] pInitialGameStateArray;
	pInitialGameStateArray = nullptr;

	int32_t gameBoardSizeXY = gameBoardSizeXDir * gameBoardSizeYDir;

	std::ifstream ReadFile;

	// eine existierende Datei zum Lesen �ffnen:
	ReadFile.open(pFilename);

	if (ReadFile.good() == false)
		return false;

	char strBuffer[200];
	int32_t tempInt;

	ReadFile >> strBuffer;
	ReadFile >> NumOfInitialBoards;

	pInitialGameStateArray = new (std::nothrow) CGameStateValues[NumOfInitialBoards];

	for (int32_t i = 0; i < NumOfInitialBoards; i++)
	{
		pInitialGameStateArray[i].Initialize(gameBoardSizeXDir, gameBoardSizeYDir);

		int8_t* pInitialBoardData = &pInitialGameStateArray[i].pValueArray[0];

		for (int32_t j = 0; j < gameBoardSizeXY; j++)
		{
			ReadFile >> tempInt;
			pInitialBoardData[j] = static_cast<int8_t>(tempInt);
		}
	}

	ReadFile.close();
	return true;
}



void Init_GameBoard(int8_t* pInOutGameData, CInitialGameBoards* pInitialGameBoards, int32_t boardID, int32_t gameBoardSizeXY)
{
	int8_t* pInitialBoardData = &pInitialGameBoards->pInitialGameStateArray[boardID].pValueArray[0];

	for (int32_t i = 0; i < gameBoardSizeXY; i++)
	{
		pInOutGameData[i] = pInitialBoardData[i];
	}
}

void Clone_GameBoard(int8_t* pOutGameData, int8_t* pInGameData, int32_t gameBoardSizeXY)
{
	for (int32_t i = 0; i < gameBoardSizeXY; i++)
		pOutGameData[i] = pInGameData[i];
}


CMovePattern::CMovePattern()
{}

CMovePattern::~CMovePattern()
{
	delete[] pBoardValueArray;
	pBoardValueArray = nullptr;

	delete[] pRelBoardPosIDArray;
	pRelBoardPosIDArray = nullptr;

	delete[] pBoardValueArray_Outcome;
	pBoardValueArray_Outcome = nullptr;

	delete[] pRelBoardPosIDArray_Outcome;
	pRelBoardPosIDArray_Outcome = nullptr;
}

void CMovePattern::Set_AdditionalMoveFunction(pAdditionalMoveOrValidationFunc pFunc)
{
	AdditionalMoveFunc = pFunc;
}

void CMovePattern::Set_AdditionalValidationFunction(pAdditionalMoveOrValidationFunc pFunc)
{
	AdditionalValidationFunc = pFunc;
}


void CMovePattern::Set_MoveStatus(bool moveCurrentlyPermitted)
{
	MoveCurrentlyPermitted = moveCurrentlyPermitted;
}

void CMovePattern::Initialize(int32_t numOfMoveElements)
{
	delete[] pBoardValueArray;
	pBoardValueArray = nullptr;

	delete[] pRelBoardPosIDArray;
	pRelBoardPosIDArray = nullptr;

	delete[] pBoardValueArray_Outcome;
	pBoardValueArray_Outcome = nullptr;

	delete[] pRelBoardPosIDArray_Outcome;
	pRelBoardPosIDArray_Outcome = nullptr;

	NumOfMoveElements = numOfMoveElements;

	pBoardValueArray = new (std::nothrow) int8_t[numOfMoveElements];
	pRelBoardPosIDArray = new (std::nothrow) int32_t[numOfMoveElements];

	pBoardValueArray_Outcome = new (std::nothrow) int8_t[numOfMoveElements];
	pRelBoardPosIDArray_Outcome = new (std::nothrow) int32_t[numOfMoveElements];

	MoveCurrentlyPermitted = true;
}

bool CMovePattern::Validate_PossibleMove(int32_t ixStart, int32_t iyStart, int32_t startPosID, int32_t endPosID, CGameStateValues* pInGameStateValues)
{
	if (MoveCurrentlyPermitted == false)
		return false;

	int32_t moveEndPosID = startPosID + pRelBoardPosIDArray[NumOfMoveElements - 1];

	if (ixStartMin > -1)
	{
		if (ixStart < ixStartMin)
			return false;
		if (iyStart > iyStartMax)
			return false;
		if (iyStart < iyStartMin)
			return false;
		if (ixStart > ixStartMax)
			return false;
	}
	else
	{
		if (moveEndPosID < 0)
			return false;
		if (moveEndPosID > GameBoardSizeXYMinus1)
			return false;
	}

	int8_t* pValueArray = &pInGameStateValues->pValueArray[0];

	if (pValueArray[startPosID] != pBoardValueArray[0])
		return false;

	

	if (moveEndPosID != endPosID)
		return false;

	for (int32_t i = 0; i < NumOfMoveElements; i++)
	{
		if (pValueArray[startPosID + pRelBoardPosIDArray[i]] != pBoardValueArray[i])
			return false;
	}

	if(AdditionalValidationFunc)
		return AdditionalValidationFunc(startPosID, moveEndPosID, pValueArray);
	else
		return true;

}



bool CMovePattern::Validate_PossibleMove(int32_t ixStart, int32_t iyStart, int32_t startPosID, int32_t endPosID, int8_t* pInGameStateValues)
{
	if (MoveCurrentlyPermitted == false)
		return false;

	int32_t moveEndPosID = startPosID + pRelBoardPosIDArray[NumOfMoveElements - 1];

	if (ixStartMin > -1)
	{
		if (ixStart < ixStartMin)
			return false;
		if (iyStart > iyStartMax)
			return false;
		if (iyStart < iyStartMin)
			return false;
		if (ixStart > ixStartMax)
			return false;
	}
	else
	{
		

		if (moveEndPosID < 0)
			return false;
		if (moveEndPosID > GameBoardSizeXYMinus1)
			return false;
	}

	
	if (pInGameStateValues[startPosID] != pBoardValueArray[0])
		return false;


	if (moveEndPosID != endPosID)
		return false;

	
	for (int32_t i = 0; i < NumOfMoveElements; i++)
	{
		if (pInGameStateValues[startPosID + pRelBoardPosIDArray[i]] != pBoardValueArray[i])
			return false;
	}

	if(AdditionalValidationFunc)
		return AdditionalValidationFunc(startPosID, moveEndPosID, pInGameStateValues);
	else
		return true;

}



bool CMovePattern::Make_Move_If_Possible(int32_t ixStart, int32_t iyStart, int32_t startPosID, int32_t endPosID, CGameStateValues* pInOutGameStateValues)
{
	if (MoveCurrentlyPermitted == false)
		return false;

	int32_t moveEndPosID = startPosID + pRelBoardPosIDArray[NumOfMoveElements - 1];

	if (ixStartMin > -1)
	{
		if (ixStart < ixStartMin)
			return false;
		if (iyStart > iyStartMax)
			return false;
		if (iyStart < iyStartMin)
			return false;
		if (ixStart > ixStartMax)
			return false;
	}
	else
	{
		if (moveEndPosID < 0)
			return false;
		if (moveEndPosID > GameBoardSizeXYMinus1)
			return false;
	}

	int8_t* pValueArray = &pInOutGameStateValues->pValueArray[0];

	if (pValueArray[startPosID] != pBoardValueArray[0])
		return false;

	

	if (moveEndPosID != endPosID)
		return false;

	for (int32_t i = 0; i < NumOfMoveElements; i++)
	{
		if (pValueArray[startPosID + pRelBoardPosIDArray[i]] != pBoardValueArray[i])
			return false;
	}

	for (int32_t i = 0; i < NumOfMoveElements; i++)
	{
		pValueArray[startPosID + pRelBoardPosIDArray[i]] = pBoardValueArray_Outcome[i];
	}

	if(AdditionalMoveFunc)
		return AdditionalMoveFunc(startPosID, moveEndPosID, pValueArray);
	else
		return true;

}



bool CMovePattern::Make_Move_If_Possible(int32_t ixStart, int32_t iyStart, int32_t startPosID, int32_t endPosID, int8_t* pInOutGameStateValues)
{
	if (MoveCurrentlyPermitted == false)
		return false;

	int32_t moveEndPosID = startPosID + pRelBoardPosIDArray[NumOfMoveElements - 1];

	if (ixStartMin > -1)
	{
		if (ixStart < ixStartMin)
			return false;
		if (iyStart > iyStartMax)
			return false;
		if (iyStart < iyStartMin)
			return false;
		if (ixStart > ixStartMax)
			return false;
	}
	else
	{

		if (moveEndPosID < 0)
			return false;
		if (moveEndPosID > GameBoardSizeXYMinus1)
			return false;
	}

	
	if (pInOutGameStateValues[startPosID] != pBoardValueArray[0])
		return false;

	

	if (moveEndPosID != endPosID)
		return false;

	for (int32_t i = 0; i < NumOfMoveElements; i++)
	{
		if (pInOutGameStateValues[startPosID + pRelBoardPosIDArray[i]] != pBoardValueArray[i])
			return false;
	}

	for (int32_t i = 0; i < NumOfMoveElements; i++)
	{
		pInOutGameStateValues[startPosID + pRelBoardPosIDArray[i]] = pBoardValueArray_Outcome[i];
	}

	if(AdditionalMoveFunc)
		return AdditionalMoveFunc(startPosID, moveEndPosID, pInOutGameStateValues);
	else
		return true;

}



bool CMovePattern::Make_Move_If_Possible(int32_t ixStart, int32_t iyStart, int32_t startPosID, CGameStateValues* pInOutGameStateValues)
{
	if (MoveCurrentlyPermitted == false)
		return false;

	int32_t moveEndPosID = startPosID + pRelBoardPosIDArray[NumOfMoveElements - 1];

	if (ixStartMin > -1)
	{
		if (ixStart < ixStartMin)
			return false;
		if (iyStart > iyStartMax)
			return false;
		if (iyStart < iyStartMin)
			return false;
		if (ixStart > ixStartMax)
			return false;
	}
	else
	{
		if (moveEndPosID < 0)
			return false;
		if (moveEndPosID > GameBoardSizeXYMinus1)
			return false;
	}

	int8_t * pValueArray = &pInOutGameStateValues->pValueArray[0];

	for (int32_t i = 0; i < NumOfMoveElements; i++)
	{
		if(pValueArray[startPosID + pRelBoardPosIDArray[i]] != pBoardValueArray[i])
			return false;
	}

	for (int32_t i = 0; i < NumOfMoveElements; i++)
	{
		pValueArray[startPosID + pRelBoardPosIDArray[i]] = pBoardValueArray_Outcome[i];
	}
	
	if(AdditionalMoveFunc)
		return AdditionalMoveFunc(startPosID, moveEndPosID, pValueArray);
	else
		return true;
}



void CMovePattern::Make_Move(int32_t ixStart, int32_t iyStart, int32_t startPosID, CGameStateValues* pInOutGameStateValues)
{
	/*if (ixStart < ixStartMin)
		return false;
	if (iyStart > iyStartMax)
		return false;
	if (iyStart < iyStartMin)
		return false;
	if (ixStart > ixStartMax)
		return false;*/

	int8_t* pValueArray = &pInOutGameStateValues->pValueArray[0];

	/*for (int32_t i = 0; i < NumOfMoveElements; i++)
	{
		if (pValueArray[startPosID + pRelBoardPosIDArray[i]] != pBoardValueArray[i])
			return false;
	}*/

	for (int32_t i = 0; i < NumOfMoveElements; i++)
	{
		pValueArray[startPosID + pRelBoardPosIDArray[i]] = pBoardValueArray_Outcome[i];
	}

	if (AdditionalMoveFunc)
	{
		int32_t moveEndPosID = startPosID + pRelBoardPosIDArray[NumOfMoveElements - 1];

		AdditionalMoveFunc(startPosID, moveEndPosID, pValueArray);
	}


	//return true;
}



bool CMovePattern::Make_Move_If_Possible(int32_t ixStart, int32_t iyStart, int32_t startPosID, int8_t* pInOutGameStateValues)
{
	if (MoveCurrentlyPermitted == false)
		return false;

	int32_t moveEndPosID = startPosID + pRelBoardPosIDArray[NumOfMoveElements - 1];

	if (ixStartMin > -1)
	{
		if (ixStart < ixStartMin)
			return false;
		if (iyStart > iyStartMax)
			return false;
		if (iyStart < iyStartMin)
			return false;
		if (ixStart > ixStartMax)
			return false;
	}
	else
	{
		if (moveEndPosID < 0)
			return false;
		if (moveEndPosID > GameBoardSizeXYMinus1)
			return false;
	}

	

	for (int32_t i = 0; i < NumOfMoveElements; i++)
	{
		if (pInOutGameStateValues[startPosID + pRelBoardPosIDArray[i]] != pBoardValueArray[i])
			return false;
	}

	for (int32_t i = 0; i < NumOfMoveElements; i++)
	{
		pInOutGameStateValues[startPosID + pRelBoardPosIDArray[i]] = pBoardValueArray_Outcome[i];
	}

	if(AdditionalMoveFunc)
		return AdditionalMoveFunc(startPosID, moveEndPosID, pInOutGameStateValues);
	else
		return true;
}


void CMovePattern::Make_Move(int32_t ixStart, int32_t iyStart, int32_t startPosID, int8_t* pInOutGameStateValues)
{
	/*if (ixStart < ixStartMin)
		return false;
	if (iyStart > iyStartMax)
		return false;
	if (iyStart < iyStartMin)
		return false;
	if (ixStart > ixStartMax)
		return false;



	for (int32_t i = 0; i < NumOfMoveElements; i++)
	{
		if (pInOutGameStateValues[startPosID + pRelBoardPosIDArray[i]] != pBoardValueArray[i])
			return false;
	}*/

	for (int32_t i = 0; i < NumOfMoveElements; i++)
	{
		pInOutGameStateValues[startPosID + pRelBoardPosIDArray[i]] = pBoardValueArray_Outcome[i];
	}

	if (AdditionalMoveFunc)
	{
		int32_t moveEndPosID = startPosID + pRelBoardPosIDArray[NumOfMoveElements - 1];

		AdditionalMoveFunc(startPosID, moveEndPosID, pInOutGameStateValues);
	}

	//return true;
}



bool CMovePattern::Validate_PossibleMove(int32_t ixStart, int32_t iyStart, int32_t startPosID, CGameStateValues* pInGameStateValues)
{
	if (MoveCurrentlyPermitted == false)
		return false;

	int32_t moveEndPosID = startPosID + pRelBoardPosIDArray[NumOfMoveElements - 1];

	if (ixStartMin > -1)
	{
		if (ixStart < ixStartMin)
			return false;
		if (iyStart > iyStartMax)
			return false;
		if (iyStart < iyStartMin)
			return false;
		if (ixStart > ixStartMax)
			return false;
	}
	else
	{
		if (moveEndPosID < 0)
			return false;
		if (moveEndPosID > GameBoardSizeXYMinus1)
			return false;
	}
	

	int8_t* pValueArray = &pInGameStateValues->pValueArray[0];

	for (int32_t i = 0; i < NumOfMoveElements; i++)
	{
		if (pValueArray[startPosID + pRelBoardPosIDArray[i]] != pBoardValueArray[i])
			return false;
	}

	if(AdditionalValidationFunc)
		return AdditionalValidationFunc(startPosID, moveEndPosID, pValueArray);
	else
		return true;
}



bool CMovePattern::Validate_PossibleMove(int32_t ixStart, int32_t iyStart, int32_t startPosID, int8_t* pInGameStateValues)
{
	if (MoveCurrentlyPermitted == false)
		return false;

	int32_t moveEndPosID = startPosID + pRelBoardPosIDArray[NumOfMoveElements - 1];

	if (ixStartMin > -1)
	{
		if (ixStart < ixStartMin)
			return false;
		if (iyStart > iyStartMax)
			return false;
		if (iyStart < iyStartMin)
			return false;
		if (ixStart > ixStartMax)
			return false;
	}
	else
	{
		
		if (moveEndPosID < 0)
			return false;
		if (moveEndPosID > GameBoardSizeXYMinus1)
			return false;
	}

	
	for (int32_t i = 0; i < NumOfMoveElements; i++)
	{
		if (pInGameStateValues[startPosID + pRelBoardPosIDArray[i]] != pBoardValueArray[i])
			return false;
	}

	if(AdditionalValidationFunc)
		return AdditionalValidationFunc(startPosID, moveEndPosID, pInGameStateValues);
	else
		return true;
}



CMovePatternList::CMovePatternList()
{}

CMovePatternList::~CMovePatternList()
{
	delete[] pMoveArray;
	pMoveArray = nullptr;
}

bool CMovePatternList::Validate_PossibleMove(int32_t moveID, int32_t ixStart, int32_t iyStart, int32_t startPosID, int32_t endPosID, CGameStateValues* pInGameStateValues)
{
	return pMoveArray[moveID].Validate_PossibleMove(ixStart, iyStart, startPosID, endPosID, pInGameStateValues);
}



bool CMovePatternList::Validate_PossibleMove(int32_t moveID, int32_t ixStart, int32_t iyStart, int32_t startPosID, int32_t endPosID, int8_t* pInGameStateValues)
{
	return pMoveArray[moveID].Validate_PossibleMove(ixStart, iyStart, startPosID, endPosID, pInGameStateValues);
}



bool CMovePatternList::Validate_PossibleMove(int32_t moveID, int32_t ixStart, int32_t iyStart, int32_t startPosID, CGameStateValues* pInGameStateValues)
{
	return pMoveArray[moveID].Validate_PossibleMove(ixStart, iyStart, startPosID, pInGameStateValues);
}



bool CMovePatternList::Validate_PossibleMove(int32_t moveID, int32_t ixStart, int32_t iyStart, int32_t startPosID, int8_t* pInGameStateValues)
{
	return pMoveArray[moveID].Validate_PossibleMove(ixStart, iyStart, startPosID, pInGameStateValues);
}



bool CMovePatternList::Make_Move_If_Possible(int32_t moveID, int32_t ixStart, int32_t iyStart, int32_t startPosID, CGameStateValues* pInOutGameStateValues)
{
	return pMoveArray[moveID].Make_Move_If_Possible(ixStart, iyStart, startPosID, pInOutGameStateValues);
}



void CMovePatternList::Make_Move(int32_t moveID, int32_t ixStart, int32_t iyStart, int32_t startPosID, CGameStateValues* pInOutGameStateValues)
{
	pMoveArray[moveID].Make_Move(ixStart, iyStart, startPosID, pInOutGameStateValues);
}



bool CMovePatternList::Make_Move_If_Possible(int32_t moveID, int32_t ixStart, int32_t iyStart, int32_t startPosID, int8_t* pInOutGameStateValues)
{
	return pMoveArray[moveID].Make_Move_If_Possible(ixStart, iyStart, startPosID, pInOutGameStateValues);
}



void CMovePatternList::Make_Move(int32_t moveID, int32_t ixStart, int32_t iyStart, int32_t startPosID, int8_t* pInOutGameStateValues)
{
	pMoveArray[moveID].Make_Move(ixStart, iyStart, startPosID, pInOutGameStateValues);
}



bool CMovePatternList::Make_Move_If_Possible(int32_t moveID, int32_t ixStart, int32_t iyStart, int32_t startPosID, int32_t endPosID, CGameStateValues* pInOutGameStateValues)
{
	return pMoveArray[moveID].Make_Move_If_Possible(ixStart, iyStart, startPosID, endPosID, pInOutGameStateValues);
}



bool CMovePatternList::Make_Move_If_Possible(int32_t moveID, int32_t ixStart, int32_t iyStart, int32_t startPosID, int32_t endPosID, int8_t* pInOutGameStateValues)
{
	return pMoveArray[moveID].Make_Move_If_Possible(ixStart, iyStart, startPosID, endPosID, pInOutGameStateValues);
}




void CMovePatternList::Set_AdditionalMoveFunction(pAdditionalMoveOrValidationFunc pFunc)
{
	for (int32_t i = 0; i < NumOfMoves; i++)
	{
		pMoveArray[i].Set_AdditionalMoveFunction(pFunc);
	}
}

void CMovePatternList::Set_AdditionalValidationFunction(pAdditionalMoveOrValidationFunc pFunc)
{
	for (int32_t i = 0; i < NumOfMoves; i++)
	{
		pMoveArray[i].Set_AdditionalValidationFunction(pFunc);
	}
}



void CMovePatternList::Set_AdditionalMoveFunction(int32_t moveID, pAdditionalMoveOrValidationFunc pFunc)
{
	pMoveArray[moveID].Set_AdditionalMoveFunction(pFunc);
}

void CMovePatternList::Set_AdditionalMoveFunction(int32_t minMoveID, int32_t maxMoveIDPlus1, pAdditionalMoveOrValidationFunc pFunc)
{
	for (int32_t i = minMoveID; i < maxMoveIDPlus1; i++)
	{
		pMoveArray[i].Set_AdditionalMoveFunction(pFunc);
	}
}

void CMovePatternList::Set_AdditionalValidationFunction(int32_t moveID, pAdditionalMoveOrValidationFunc pFunc)
{
	pMoveArray[moveID].Set_AdditionalValidationFunction(pFunc);
}

void CMovePatternList::Set_AdditionalValidationFunction(int32_t minMoveID, int32_t maxMoveIDPlus1, pAdditionalMoveOrValidationFunc pFunc)
{
	for (int32_t i = minMoveID; i < maxMoveIDPlus1; i++)
	{
		pMoveArray[i].Set_AdditionalValidationFunction(pFunc);
	}
}




void CMovePatternList::Set_MoveStatus(int32_t moveID, bool moveCurrentlyPermitted)
{
	pMoveArray[moveID].Set_MoveStatus(moveCurrentlyPermitted);
}

bool CMovePatternList::Initialize(const char* pFilename)
{
	delete[] pMoveArray;
	pMoveArray = nullptr;

	std::ifstream ReadFile;

	// eine existierende Datei zum Lesen �ffnen:
	ReadFile.open(pFilename);

	if (ReadFile.good() == false)
		return false;

	char strBuffer[200];
	int32_t numOfMoveElements, tempInt;

	ReadFile >> strBuffer;
	ReadFile >> NumOfMoves;

	pMoveArray = new (std::nothrow) CMovePattern[NumOfMoves];

	for (int32_t i = 0; i < NumOfMoves; i++)
	{
		ReadFile >> strBuffer;
		ReadFile >> numOfMoveElements;

		ReadFile >> strBuffer;
		ReadFile >> pMoveArray[i].ixStartMin;

		ReadFile >> strBuffer;
		ReadFile >> pMoveArray[i].ixStartMax;

		ReadFile >> strBuffer;
		ReadFile >> pMoveArray[i].iyStartMin;

		ReadFile >> strBuffer;
		ReadFile >> pMoveArray[i].iyStartMax;
		
		pMoveArray[i].Initialize(numOfMoveElements);

		for (int32_t j = 0; j < numOfMoveElements; j++)
		{
			ReadFile >> strBuffer;
			ReadFile >> tempInt;

			pMoveArray[i].pBoardValueArray[j] = static_cast<int8_t>(tempInt);

			ReadFile >> strBuffer;
			ReadFile >> tempInt;

			pMoveArray[i].pRelBoardPosIDArray[j] = tempInt;

			ReadFile >> strBuffer;
		}

		for (int32_t j = 0; j < numOfMoveElements; j++)
		{
			ReadFile >> strBuffer;
			ReadFile >> tempInt;

			pMoveArray[i].pBoardValueArray_Outcome[j] = static_cast<int8_t>(tempInt);

			ReadFile >> strBuffer;
			ReadFile >> tempInt;

			pMoveArray[i].pRelBoardPosIDArray_Outcome[j] = tempInt;

			ReadFile >> strBuffer;
		}
	}

	ReadFile.close();
	return true;
}

bool CMovePatternList::Initialize_UseMoveEndPositionsforValidation(const char* pFilename)
{
	delete[] pMoveArray;
	pMoveArray = nullptr;

	std::ifstream ReadFile;

	// eine existierende Datei zum Lesen �ffnen:
	ReadFile.open(pFilename);

	if (ReadFile.good() == false)
		return false;

	char strBuffer[200];
	int32_t numOfMoveElements, tempInt;

	int32_t gameBoardSizeXY;

	ReadFile >> strBuffer;
	ReadFile >> gameBoardSizeXY;

	int32_t gameBoardSizeXYMinus1 = gameBoardSizeXY - 1;

	ReadFile >> strBuffer;
	ReadFile >> NumOfMoves;

	

	pMoveArray = new (std::nothrow) CMovePattern[NumOfMoves];

	for (int32_t i = 0; i < NumOfMoves; i++)
	{
		ReadFile >> strBuffer;
		ReadFile >> numOfMoveElements;

		pMoveArray[i].GameBoardSizeXYMinus1 = gameBoardSizeXYMinus1;

		ReadFile >> strBuffer;
		ReadFile >> pMoveArray[i].ixStartMin;

		ReadFile >> strBuffer;
		ReadFile >> pMoveArray[i].ixStartMax;

		ReadFile >> strBuffer;
		ReadFile >> pMoveArray[i].iyStartMin;

		ReadFile >> strBuffer;
		ReadFile >> pMoveArray[i].iyStartMax;

		pMoveArray[i].Initialize(numOfMoveElements);

		for (int32_t j = 0; j < numOfMoveElements; j++)
		{
			ReadFile >> strBuffer;
			ReadFile >> tempInt;

			pMoveArray[i].pBoardValueArray[j] = static_cast<int8_t>(tempInt);

			ReadFile >> strBuffer;
			ReadFile >> tempInt;

			pMoveArray[i].pRelBoardPosIDArray[j] = tempInt;

			ReadFile >> strBuffer;
		}

		for (int32_t j = 0; j < numOfMoveElements; j++)
		{
			ReadFile >> strBuffer;
			ReadFile >> tempInt;

			pMoveArray[i].pBoardValueArray_Outcome[j] = static_cast<int8_t>(tempInt);

			ReadFile >> strBuffer;
			ReadFile >> tempInt;

			pMoveArray[i].pRelBoardPosIDArray_Outcome[j] = tempInt;

			ReadFile >> strBuffer;
		}
	}

	ReadFile.close();
	return true;
}






CTestMove::CTestMove()
{
	for (int32_t i = 0; i < NumOfMoveExcludedBoardElementsMax; i++)
	{
		Player1MoveExcludedBoardElementsArray[i] = 0;
		Player2MoveExcludedBoardElementsArray[i] = 0;
	}
}

CTestMove::~CTestMove()
{}

void CTestMove::Set_EvaluationFunctions(pCheckGameStateEvalFunc Player1ViewFunc, pCheckGameStateEvalFunc Player2ViewFunc)
{
	Player1ViewCheckGameStateEvalFunc = Player1ViewFunc;
	Player2ViewCheckGameStateEvalFunc = Player2ViewFunc;
}

void CTestMove::Set_GameBoardSizeXDir(int32_t sizeX)
{
	GameBoardSizeXDir = sizeX;
}

void CTestMove::Set_GameBoardSizeXY(int32_t sizeXY)
{
	GameBoardSizeXY = sizeXY;
}

void CTestMove::Set_MovePatternLists(CMovePatternList* pPlayer1MoveList, CMovePatternList* pPlayer2MoveList)
{
	pUsedPlayer1MoveList = pPlayer1MoveList;
	pUsedPlayer2MoveList = pPlayer2MoveList;
}

void CTestMove::Prepare_Move(int32_t boardPosID, int32_t moveID)
{
	BoardPosID = boardPosID;
	MoveID = moveID;
}

int32_t CTestMove::Make_Player1Move_If_Possible(CGameStateValues** ppOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool* pGameStatePool, int32_t depthLayer, bool resultingGameStateIsMaximizer)
{
	ResultingGameStateObjectID = -1;

	if (BoardPosID >= GameBoardSizeXY)
	{
		*ppOutNewGameState = nullptr;
		return 0;
	}

	int8_t gameStateValue = pInActualGameState->pValueArray[BoardPosID];

	for (int32_t i = 0; i < NumOfPlayer1MoveExcludedBoardElements; i++)
	{
		if (gameStateValue == Player1MoveExcludedBoardElementsArray[i])
		{
			*ppOutNewGameState = nullptr;
			return 0;
		}
	}

	

	int32_t ix = BoardPosID % GameBoardSizeXDir;
	int32_t iy = BoardPosID / GameBoardSizeXDir;

	//if (pUsedPlayer1MoveList->Validate_PossibleMove(MoveID, ix, iy, BoardPosID, pInActualGameState) == true)
	if (pUsedPlayer1MoveList->pMoveArray[MoveID].Validate_PossibleMove(ix, iy, BoardPosID, pInActualGameState) == true)
	{
		CGameStateValues* pOutNewGameState = nullptr;

		if (pGameStatePool->Get_UnusedGameStateObject(depthLayer, &pOutNewGameState, &ResultingGameStateObjectID) == false)
		{
			*ppOutNewGameState = nullptr;
			return -1;
		}

		pOutNewGameState->Clone_GameStateValues(pInActualGameState);

		pOutNewGameState->LastMove_BoardPosID = BoardPosID;
		pOutNewGameState->LastMove_MoveID = MoveID;

		// test move:
		//pUsedPlayer1MoveList->Make_Move_If_Possible(MoveID, ix, iy, BoardPosID, pOutNewGameState);
		//pUsedPlayer1MoveList->Make_Move(MoveID, ix, iy, BoardPosID, pOutNewGameState);
		pUsedPlayer1MoveList->pMoveArray[MoveID].Make_Move(ix, iy, BoardPosID, pOutNewGameState);
		pOutNewGameState->PlayerID = 0;
		pInActualGameState->LeafNode = false;
		pOutNewGameState->IDofPrevGameState = pInActualGameState->IDofGameState;

		if (resultingGameStateIsMaximizer == true)
		{
			pOutNewGameState->Use_As_Maximizer();
		}
		else
		{
			pOutNewGameState->Use_As_Minimizer();
		}

		*ppOutNewGameState = pOutNewGameState;
		return 1;
	}


	// no move from BoardPosID found:
	*ppOutNewGameState = nullptr;
	return 0;
}


int32_t CTestMove::Make_Player1Move_If_Possible_AvoidRepetitiveStates(CGameStateValues** ppOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool* pGameStatePool, int32_t depthLayer, bool resultingGameStateIsMaximizer)
{
	ResultingGameStateObjectID = -1;

	if (BoardPosID >= GameBoardSizeXY)
	{
		*ppOutNewGameState = nullptr;
		return 0;
	}

	int8_t gameStateValue = pInActualGameState->pValueArray[BoardPosID];

	for (int32_t i = 0; i < NumOfPlayer1MoveExcludedBoardElements; i++)
	{
		if (gameStateValue == Player1MoveExcludedBoardElementsArray[i])
		{
			*ppOutNewGameState = nullptr;
			return 0;
		}
	}



	int32_t ix = BoardPosID % GameBoardSizeXDir;
	int32_t iy = BoardPosID / GameBoardSizeXDir;

	//if (pUsedPlayer1MoveList->Validate_PossibleMove(MoveID, ix, iy, BoardPosID, pInActualGameState) == true)
	if (pUsedPlayer1MoveList->pMoveArray[MoveID].Validate_PossibleMove(ix, iy, BoardPosID, pInActualGameState) == true)
	{
		pGameStatePool->TempGameState.Clone_GameStateValues(pInActualGameState);

		// test move:
		pUsedPlayer1MoveList->pMoveArray[MoveID].Make_Move(ix, iy, BoardPosID, &pGameStatePool->TempGameState);
		pGameStatePool->TempGameState.Calculate_SimpleHashValue();

		if (pGameStatePool->Check_If_TempGameState_Already_Exists(depthLayer) == true)
		{
			
			g_NumOfMultipleVisitedGameStates++;
			
			*ppOutNewGameState = nullptr;
			return -2;
		}


		CGameStateValues* pOutNewGameState = nullptr;

		if (pGameStatePool->Get_UnusedGameStateObject(depthLayer, &pOutNewGameState, &ResultingGameStateObjectID) == false)
		{
			*ppOutNewGameState = nullptr;
			return -1;
		}

		pOutNewGameState->Clone_GameStateValues(&pGameStatePool->TempGameState);
		
		pOutNewGameState->LastMove_BoardPosID = BoardPosID;
		pOutNewGameState->LastMove_MoveID = MoveID;

		pOutNewGameState->PlayerID = 0;
		pInActualGameState->LeafNode = false;
		pOutNewGameState->IDofPrevGameState = pInActualGameState->IDofGameState;

		if (resultingGameStateIsMaximizer == true)
		{
			pOutNewGameState->Use_As_Maximizer();
		}
		else
		{
			pOutNewGameState->Use_As_Minimizer();
		}

		*ppOutNewGameState = pOutNewGameState;
		return 1;
	}


	// no move from BoardPosID found:
	*ppOutNewGameState = nullptr;
	return 0;
}


int32_t CTestMove::Make_Player1Move_If_Possible_DiscardInsufficientStates(CGameStateValues** ppOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool* pGameStatePool, int32_t depthLayer, bool resultingGameStateIsMaximizer)
{
	ResultingGameStateObjectID = -1;

	if (BoardPosID >= GameBoardSizeXY)
	{
		*ppOutNewGameState = nullptr;
		return 0;
	}

	int8_t gameStateValue = pInActualGameState->pValueArray[BoardPosID];

	for (int32_t i = 0; i < NumOfPlayer1MoveExcludedBoardElements; i++)
	{
		if (gameStateValue == Player1MoveExcludedBoardElementsArray[i])
		{
			*ppOutNewGameState = nullptr;
			return 0;
		}
	}


	int32_t ix = BoardPosID % GameBoardSizeXDir;
	int32_t iy = BoardPosID / GameBoardSizeXDir;

	//if (pUsedPlayer1MoveList->Validate_PossibleMove(MoveID, ix, iy, BoardPosID, pInActualGameState) == true)
	if (pUsedPlayer1MoveList->pMoveArray[MoveID].Validate_PossibleMove(ix, iy, BoardPosID, pInActualGameState) == true)
	{
		pGameStatePool->TempGameState.Clone_GameStateValues(pInActualGameState);

		// test move:
		pUsedPlayer1MoveList->pMoveArray[MoveID].Make_Move(ix, iy, BoardPosID, &pGameStatePool->TempGameState);

		//if (resultingGameStateIsMaximizer == false)
		{
			if (Player1ViewCheckGameStateEvalFunc(&pGameStatePool->TempGameState, MinTolerableEvaluationValue_Player1, pUsedPlayer1MoveList, pUsedPlayer2MoveList) == false)
			{
				g_NumOfGameStatesWithTooLowEvalValues++;

				*ppOutNewGameState = nullptr;
				return -2;
			}
		}


		CGameStateValues* pOutNewGameState = nullptr;

		if (pGameStatePool->Get_UnusedGameStateObject(depthLayer, &pOutNewGameState, &ResultingGameStateObjectID) == false)
		{
			*ppOutNewGameState = nullptr;
			return -1;
		}

		pOutNewGameState->Clone_GameStateValues(&pGameStatePool->TempGameState);

		pOutNewGameState->LastMove_BoardPosID = BoardPosID;
		pOutNewGameState->LastMove_MoveID = MoveID;

		pOutNewGameState->PlayerID = 0;
		pInActualGameState->LeafNode = false;
		pOutNewGameState->IDofPrevGameState = pInActualGameState->IDofGameState;

		if (resultingGameStateIsMaximizer == true)
		{
			pOutNewGameState->Use_As_Maximizer();
		}
		else
		{
			pOutNewGameState->Use_As_Minimizer();
		}

		*ppOutNewGameState = pOutNewGameState;
		return 1;
	}


	// no move from BoardPosID found:
	*ppOutNewGameState = nullptr;
	return 0;
}


int32_t CTestMove::Make_Player2Move_If_Possible(CGameStateValues** ppOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool* pGameStatePool, int32_t depthLayer, bool resultingGameStateIsMaximizer)
{
	ResultingGameStateObjectID = -1;

	if (BoardPosID >= GameBoardSizeXY)
	{
		*ppOutNewGameState = nullptr;
		return 0;
	}


	int8_t gameStateValue = pInActualGameState->pValueArray[BoardPosID];

	for (int32_t i = 0; i < NumOfPlayer2MoveExcludedBoardElements; i++)
	{
		if (gameStateValue == Player2MoveExcludedBoardElementsArray[i])
		{
			*ppOutNewGameState = nullptr;
			return 0;
		}
	}

	

	int32_t ix = BoardPosID % GameBoardSizeXDir;
	int32_t iy = BoardPosID / GameBoardSizeXDir;

	//if (pUsedPlayer2MoveList->Validate_PossibleMove(MoveID, ix, iy, BoardPosID, pInActualGameState) == true)
	if (pUsedPlayer2MoveList->pMoveArray[MoveID].Validate_PossibleMove(ix, iy, BoardPosID, pInActualGameState) == true)
	{
		CGameStateValues* pOutNewGameState = nullptr;

		if (pGameStatePool->Get_UnusedGameStateObject(depthLayer, &pOutNewGameState, &ResultingGameStateObjectID) == false)
		{
			*ppOutNewGameState = nullptr;
			return -1;
		}

		pOutNewGameState->Clone_GameStateValues(pInActualGameState);

		pOutNewGameState->LastMove_BoardPosID = BoardPosID;
		pOutNewGameState->LastMove_MoveID = MoveID;

		// test move:
		//pUsedPlayer2MoveList->Make_Move_If_Possible(MoveID, ix, iy, BoardPosID, pOutNewGameState);
		//pUsedPlayer2MoveList->Make_Move(MoveID, ix, iy, BoardPosID, pOutNewGameState);
		pUsedPlayer2MoveList->pMoveArray[MoveID].Make_Move(ix, iy, BoardPosID, pOutNewGameState);
		pOutNewGameState->PlayerID = 1;
		pInActualGameState->LeafNode = false;
		pOutNewGameState->IDofPrevGameState = pInActualGameState->IDofGameState;

		if (resultingGameStateIsMaximizer == true)
		{
			pOutNewGameState->Use_As_Maximizer();
		}
		else
		{
			pOutNewGameState->Use_As_Minimizer();
		}

		*ppOutNewGameState = pOutNewGameState;
		return 1;
	}


	// no move from BoardPosID found:
	*ppOutNewGameState = nullptr;
	return 0;
}

int32_t CTestMove::Make_Player2Move_If_Possible_AvoidRepetitiveStates(CGameStateValues** ppOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool* pGameStatePool, int32_t depthLayer, bool resultingGameStateIsMaximizer)
{
	ResultingGameStateObjectID = -1;

	if (BoardPosID >= GameBoardSizeXY)
	{
		*ppOutNewGameState = nullptr;
		return 0;
	}


	int8_t gameStateValue = pInActualGameState->pValueArray[BoardPosID];

	for (int32_t i = 0; i < NumOfPlayer2MoveExcludedBoardElements; i++)
	{
		if (gameStateValue == Player2MoveExcludedBoardElementsArray[i])
		{
			*ppOutNewGameState = nullptr;
			return 0;
		}
	}



	int32_t ix = BoardPosID % GameBoardSizeXDir;
	int32_t iy = BoardPosID / GameBoardSizeXDir;

	//if (pUsedPlayer2MoveList->Validate_PossibleMove(MoveID, ix, iy, BoardPosID, pInActualGameState) == true)
	if (pUsedPlayer2MoveList->pMoveArray[MoveID].Validate_PossibleMove(ix, iy, BoardPosID, pInActualGameState) == true)
	{
		pGameStatePool->TempGameState.Clone_GameStateValues(pInActualGameState);
		
		// test move:
		pUsedPlayer2MoveList->pMoveArray[MoveID].Make_Move(ix, iy, BoardPosID, &pGameStatePool->TempGameState);
		pGameStatePool->TempGameState.Calculate_SimpleHashValue();

		if (pGameStatePool->Check_If_TempGameState_Already_Exists(depthLayer) == true)
		{
			
			g_NumOfMultipleVisitedGameStates++;
			
			*ppOutNewGameState = nullptr;
			return -2;
		}

		CGameStateValues* pOutNewGameState = nullptr;

		if (pGameStatePool->Get_UnusedGameStateObject(depthLayer, &pOutNewGameState, &ResultingGameStateObjectID) == false)
		{
			*ppOutNewGameState = nullptr;
			return -1;
		}

		pOutNewGameState->Clone_GameStateValues(&pGameStatePool->TempGameState);

		pOutNewGameState->LastMove_BoardPosID = BoardPosID;
		pOutNewGameState->LastMove_MoveID = MoveID;

		pOutNewGameState->PlayerID = 1;
		pInActualGameState->LeafNode = false;
		pOutNewGameState->IDofPrevGameState = pInActualGameState->IDofGameState;

		if (resultingGameStateIsMaximizer == true)
		{
			pOutNewGameState->Use_As_Maximizer();
		}
		else
		{
			pOutNewGameState->Use_As_Minimizer();
		}

		*ppOutNewGameState = pOutNewGameState;
		return 1;
	}


	// no move from BoardPosID found:
	*ppOutNewGameState = nullptr;
	return 0;
}

int32_t CTestMove::Make_Player2Move_If_Possible_DiscardInsufficientStates(CGameStateValues** ppOutNewGameState, CGameStateValues* pInActualGameState, CExtendedGameStatePool* pGameStatePool, int32_t depthLayer, bool resultingGameStateIsMaximizer)
{
	ResultingGameStateObjectID = -1;

	if (BoardPosID >= GameBoardSizeXY)
	{
		*ppOutNewGameState = nullptr;
		return 0;
	}


	int8_t gameStateValue = pInActualGameState->pValueArray[BoardPosID];

	for (int32_t i = 0; i < NumOfPlayer2MoveExcludedBoardElements; i++)
	{
		if (gameStateValue == Player2MoveExcludedBoardElementsArray[i])
		{
			*ppOutNewGameState = nullptr;
			return 0;
		}
	}



	int32_t ix = BoardPosID % GameBoardSizeXDir;
	int32_t iy = BoardPosID / GameBoardSizeXDir;

	//if (pUsedPlayer2MoveList->Validate_PossibleMove(MoveID, ix, iy, BoardPosID, pInActualGameState) == true)
	if (pUsedPlayer2MoveList->pMoveArray[MoveID].Validate_PossibleMove(ix, iy, BoardPosID, pInActualGameState) == true)
	{
		pGameStatePool->TempGameState.Clone_GameStateValues(pInActualGameState);

		// test move:
		pUsedPlayer2MoveList->pMoveArray[MoveID].Make_Move(ix, iy, BoardPosID, &pGameStatePool->TempGameState);

		//if (resultingGameStateIsMaximizer == false)
		{
			if (Player2ViewCheckGameStateEvalFunc(&pGameStatePool->TempGameState, MinTolerableEvaluationValue_Player2, pUsedPlayer1MoveList, pUsedPlayer2MoveList) == false)
			{
				g_NumOfGameStatesWithTooLowEvalValues++;

				*ppOutNewGameState = nullptr;
				return -2;
			}
		}

		CGameStateValues* pOutNewGameState = nullptr;

		if (pGameStatePool->Get_UnusedGameStateObject(depthLayer, &pOutNewGameState, &ResultingGameStateObjectID) == false)
		{
			*ppOutNewGameState = nullptr;
			return -1;
		}

		pOutNewGameState->Clone_GameStateValues(&pGameStatePool->TempGameState);

		pOutNewGameState->LastMove_BoardPosID = BoardPosID;
		pOutNewGameState->LastMove_MoveID = MoveID;

		pOutNewGameState->PlayerID = 1;
		pInActualGameState->LeafNode = false;
		pOutNewGameState->IDofPrevGameState = pInActualGameState->IDofGameState;

		if (resultingGameStateIsMaximizer == true)
		{
			pOutNewGameState->Use_As_Maximizer();
		}
		else
		{
			pOutNewGameState->Use_As_Minimizer();
		}

		*ppOutNewGameState = pOutNewGameState;
		return 1;
	}


	// no move from BoardPosID found:
	*ppOutNewGameState = nullptr;
	return 0;
}


int32_t CTestMove::Make_Player1Move_If_Possible(CGameStateValues* pInActualGameState, CExtendedGameStatePool* pGameStatePool, int32_t depthLayer, bool resultingGameStateIsMaximizer)
{
	ResultingGameStateObjectID = -1;

	if (BoardPosID >= GameBoardSizeXY)
	{
		return 0;
	}

	int8_t gameStateValue = pInActualGameState->pValueArray[BoardPosID];

	for (int32_t i = 0; i < NumOfPlayer1MoveExcludedBoardElements; i++)
	{
		if (gameStateValue == Player1MoveExcludedBoardElementsArray[i])
		{
			return 0;
		}
	}

	

	int32_t ix = BoardPosID % GameBoardSizeXDir;
	int32_t iy = BoardPosID / GameBoardSizeXDir;

	//if (pUsedPlayer1MoveList->Validate_PossibleMove(MoveID, ix, iy, BoardPosID, pInActualGameState) == true)
	if (pUsedPlayer1MoveList->pMoveArray[MoveID].Validate_PossibleMove(ix, iy, BoardPosID, pInActualGameState) == true)
	{
		CGameStateValues* pOutNewGameState = nullptr;

		if (pGameStatePool->Get_UnusedGameStateObject(depthLayer, &pOutNewGameState, &ResultingGameStateObjectID) == false)
		{
			return -1;
		}

		pOutNewGameState->Clone_GameStateValues(pInActualGameState);

		pOutNewGameState->LastMove_BoardPosID = BoardPosID;
		pOutNewGameState->LastMove_MoveID = MoveID;

		// test move:
		pUsedPlayer1MoveList->Make_Move(MoveID, ix, iy, BoardPosID, pOutNewGameState);
		//pUsedPlayer1MoveList->Make_Move_If_Possible(MoveID, ix, iy, BoardPosID, pOutNewGameState);
		
		
		pOutNewGameState->PlayerID = 0;
		pInActualGameState->LeafNode = false;
		pOutNewGameState->IDofPrevGameState = pInActualGameState->IDofGameState;

		if (resultingGameStateIsMaximizer == true)
		{
			pOutNewGameState->Use_As_Maximizer();
		}
		else
		{
			pOutNewGameState->Use_As_Minimizer();
		}

		

		return 1;
	}

	// no move from BoardPosID found:
	return 0;
}

int32_t CTestMove::Make_Player1Move_If_Possible_AvoidRepetitiveStates(CGameStateValues* pInActualGameState, CExtendedGameStatePool* pGameStatePool, int32_t depthLayer, bool resultingGameStateIsMaximizer)
{
	ResultingGameStateObjectID = -1;

	if (BoardPosID >= GameBoardSizeXY)
	{
		return 0;
	}

	int8_t gameStateValue = pInActualGameState->pValueArray[BoardPosID];

	for (int32_t i = 0; i < NumOfPlayer1MoveExcludedBoardElements; i++)
	{
		if (gameStateValue == Player1MoveExcludedBoardElementsArray[i])
		{
			return 0;
		}
	}



	int32_t ix = BoardPosID % GameBoardSizeXDir;
	int32_t iy = BoardPosID / GameBoardSizeXDir;

	//if (pUsedPlayer1MoveList->Validate_PossibleMove(MoveID, ix, iy, BoardPosID, pInActualGameState) == true)
	if (pUsedPlayer1MoveList->pMoveArray[MoveID].Validate_PossibleMove(ix, iy, BoardPosID, pInActualGameState) == true)
	{
		pGameStatePool->TempGameState.Clone_GameStateValues(pInActualGameState);

		// test move:
		pUsedPlayer1MoveList->pMoveArray[MoveID].Make_Move(ix, iy, BoardPosID, &pGameStatePool->TempGameState);
		pGameStatePool->TempGameState.Calculate_SimpleHashValue();

		if (pGameStatePool->Check_If_TempGameState_Already_Exists(depthLayer) == true)
		{
			
			g_NumOfMultipleVisitedGameStates++;
			
			return -2;
		}

		CGameStateValues* pOutNewGameState = nullptr;

		if (pGameStatePool->Get_UnusedGameStateObject(depthLayer, &pOutNewGameState, &ResultingGameStateObjectID) == false)
		{
			return -1;
		}

		pOutNewGameState->Clone_GameStateValues(&pGameStatePool->TempGameState);

		pOutNewGameState->LastMove_BoardPosID = BoardPosID;
		pOutNewGameState->LastMove_MoveID = MoveID;

		pOutNewGameState->PlayerID = 0;
		pInActualGameState->LeafNode = false;
		pOutNewGameState->IDofPrevGameState = pInActualGameState->IDofGameState;

		if (resultingGameStateIsMaximizer == true)
		{
			pOutNewGameState->Use_As_Maximizer();
		}
		else
		{
			pOutNewGameState->Use_As_Minimizer();
		}



		return 1;
	}

	// no move from BoardPosID found:
	return 0;
}

int32_t CTestMove::Make_Player1Move_If_Possible_DiscardInsufficientStates(CGameStateValues* pInActualGameState, CExtendedGameStatePool* pGameStatePool, int32_t depthLayer, bool resultingGameStateIsMaximizer)
{
	ResultingGameStateObjectID = -1;

	if (BoardPosID >= GameBoardSizeXY)
	{
		return 0;
	}

	int8_t gameStateValue = pInActualGameState->pValueArray[BoardPosID];

	for (int32_t i = 0; i < NumOfPlayer1MoveExcludedBoardElements; i++)
	{
		if (gameStateValue == Player1MoveExcludedBoardElementsArray[i])
		{
			return 0;
		}
	}



	int32_t ix = BoardPosID % GameBoardSizeXDir;
	int32_t iy = BoardPosID / GameBoardSizeXDir;

	//if (pUsedPlayer1MoveList->Validate_PossibleMove(MoveID, ix, iy, BoardPosID, pInActualGameState) == true)
	if (pUsedPlayer1MoveList->pMoveArray[MoveID].Validate_PossibleMove(ix, iy, BoardPosID, pInActualGameState) == true)
	{
		pGameStatePool->TempGameState.Clone_GameStateValues(pInActualGameState);

		// test move:
		pUsedPlayer1MoveList->pMoveArray[MoveID].Make_Move(ix, iy, BoardPosID, &pGameStatePool->TempGameState);

		//if (resultingGameStateIsMaximizer == false)
		{
			if (Player1ViewCheckGameStateEvalFunc(&pGameStatePool->TempGameState, MinTolerableEvaluationValue_Player1, pUsedPlayer1MoveList, pUsedPlayer2MoveList) == false)
			{
				g_NumOfGameStatesWithTooLowEvalValues++;

				return -2;
			}
		}

		CGameStateValues* pOutNewGameState = nullptr;

		if (pGameStatePool->Get_UnusedGameStateObject(depthLayer, &pOutNewGameState, &ResultingGameStateObjectID) == false)
		{
			return -1;
		}

		pOutNewGameState->Clone_GameStateValues(&pGameStatePool->TempGameState);

		pOutNewGameState->LastMove_BoardPosID = BoardPosID;
		pOutNewGameState->LastMove_MoveID = MoveID;

		pOutNewGameState->PlayerID = 0;
		pInActualGameState->LeafNode = false;
		pOutNewGameState->IDofPrevGameState = pInActualGameState->IDofGameState;

		if (resultingGameStateIsMaximizer == true)
		{
			pOutNewGameState->Use_As_Maximizer();
		}
		else
		{
			pOutNewGameState->Use_As_Minimizer();
		}



		return 1;
	}

	// no move from BoardPosID found:
	return 0;
}

int32_t CTestMove::Make_Player2Move_If_Possible(CGameStateValues* pInActualGameState, CExtendedGameStatePool* pGameStatePool, int32_t depthLayer, bool resultingGameStateIsMaximizer)
{
	ResultingGameStateObjectID = -1;

	if (BoardPosID >= GameBoardSizeXY)
	{
		return 0;
	}

	int8_t gameStateValue = pInActualGameState->pValueArray[BoardPosID];

	

	for (int32_t i = 0; i < NumOfPlayer2MoveExcludedBoardElements; i++)
	{
		if (gameStateValue == Player2MoveExcludedBoardElementsArray[i])
		{
			return 0;
		}
	}

	

	int32_t ix = BoardPosID % GameBoardSizeXDir;
	int32_t iy = BoardPosID / GameBoardSizeXDir;

	//Add_To_Log(0, "Player2Move_If_Possible ...");

	//if (pUsedPlayer2MoveList->Validate_PossibleMove(MoveID, ix, iy, BoardPosID, pInActualGameState) == true)
	if (pUsedPlayer2MoveList->pMoveArray[MoveID].Validate_PossibleMove(ix, iy, BoardPosID, pInActualGameState) == true)
	{
		CGameStateValues* pOutNewGameState = nullptr;

		if (pGameStatePool->Get_UnusedGameStateObject(depthLayer, &pOutNewGameState, &ResultingGameStateObjectID) == false)
		{
			return -1;
		}

		pOutNewGameState->Clone_GameStateValues(pInActualGameState);

		pOutNewGameState->LastMove_BoardPosID = BoardPosID;
		pOutNewGameState->LastMove_MoveID = MoveID;

		// test move:
		//pUsedPlayer2MoveList->Make_Move_If_Possible(MoveID, ix, iy, BoardPosID, pOutNewGameState);
		//pUsedPlayer2MoveList->Make_Move(MoveID, ix, iy, BoardPosID, pOutNewGameState);
		pUsedPlayer2MoveList->pMoveArray[MoveID].Make_Move(ix, iy, BoardPosID, pOutNewGameState);
		
		pOutNewGameState->PlayerID = 0;
		pInActualGameState->LeafNode = false;
		pOutNewGameState->IDofPrevGameState = pInActualGameState->IDofGameState;

		if (resultingGameStateIsMaximizer == true)
		{
			pOutNewGameState->Use_As_Maximizer();
		}
		else
		{
			pOutNewGameState->Use_As_Minimizer();
		}

		

		return 1;
	}


	// no move from BoardPosID found:
	return 0;
}


int32_t CTestMove::Make_Player2Move_If_Possible_AvoidRepetitiveStates(CGameStateValues* pInActualGameState, CExtendedGameStatePool* pGameStatePool, int32_t depthLayer, bool resultingGameStateIsMaximizer)
{
	ResultingGameStateObjectID = -1;

	if (BoardPosID >= GameBoardSizeXY)
	{
		return 0;
	}

	int8_t gameStateValue = pInActualGameState->pValueArray[BoardPosID];



	for (int32_t i = 0; i < NumOfPlayer2MoveExcludedBoardElements; i++)
	{
		if (gameStateValue == Player2MoveExcludedBoardElementsArray[i])
		{
			return 0;
		}
	}



	int32_t ix = BoardPosID % GameBoardSizeXDir;
	int32_t iy = BoardPosID / GameBoardSizeXDir;

	//Add_To_Log(0, "Player2Move_If_Possible ...");

	//if (pUsedPlayer2MoveList->Validate_PossibleMove(MoveID, ix, iy, BoardPosID, pInActualGameState) == true)
	if (pUsedPlayer2MoveList->pMoveArray[MoveID].Validate_PossibleMove(ix, iy, BoardPosID, pInActualGameState) == true)
	{
		pGameStatePool->TempGameState.Clone_GameStateValues(pInActualGameState);

		// test move:
		pUsedPlayer2MoveList->pMoveArray[MoveID].Make_Move(ix, iy, BoardPosID, &pGameStatePool->TempGameState);
		pGameStatePool->TempGameState.Calculate_SimpleHashValue();

		if (pGameStatePool->Check_If_TempGameState_Already_Exists(depthLayer) == true)
		{
			
			g_NumOfMultipleVisitedGameStates++;
			return -2;
		}


		CGameStateValues* pOutNewGameState = nullptr;

		if (pGameStatePool->Get_UnusedGameStateObject(depthLayer, &pOutNewGameState, &ResultingGameStateObjectID) == false)
		{
			return -1;
		}

		pOutNewGameState->Clone_GameStateValues(&pGameStatePool->TempGameState);

		pOutNewGameState->LastMove_BoardPosID = BoardPosID;
		pOutNewGameState->LastMove_MoveID = MoveID;

		pOutNewGameState->PlayerID = 0;
		pInActualGameState->LeafNode = false;
		pOutNewGameState->IDofPrevGameState = pInActualGameState->IDofGameState;

		if (resultingGameStateIsMaximizer == true)
		{
			pOutNewGameState->Use_As_Maximizer();
		}
		else
		{
			pOutNewGameState->Use_As_Minimizer();
		}



		return 1;
	}


	// no move from BoardPosID found:
	return 0;
}

int32_t CTestMove::Make_Player2Move_If_Possible_DiscardInsufficientStates(CGameStateValues* pInActualGameState, CExtendedGameStatePool* pGameStatePool, int32_t depthLayer, bool resultingGameStateIsMaximizer)
{
	ResultingGameStateObjectID = -1;

	if (BoardPosID >= GameBoardSizeXY)
	{
		return 0;
	}

	int8_t gameStateValue = pInActualGameState->pValueArray[BoardPosID];



	for (int32_t i = 0; i < NumOfPlayer2MoveExcludedBoardElements; i++)
	{
		if (gameStateValue == Player2MoveExcludedBoardElementsArray[i])
		{
			return 0;
		}
	}



	int32_t ix = BoardPosID % GameBoardSizeXDir;
	int32_t iy = BoardPosID / GameBoardSizeXDir;

	//Add_To_Log(0, "Player2Move_If_Possible ...");

	//if (pUsedPlayer2MoveList->Validate_PossibleMove(MoveID, ix, iy, BoardPosID, pInActualGameState) == true)
	if (pUsedPlayer2MoveList->pMoveArray[MoveID].Validate_PossibleMove(ix, iy, BoardPosID, pInActualGameState) == true)
	{
		pGameStatePool->TempGameState.Clone_GameStateValues(pInActualGameState);

		// test move:
		pUsedPlayer2MoveList->pMoveArray[MoveID].Make_Move(ix, iy, BoardPosID, &pGameStatePool->TempGameState);

		//if (resultingGameStateIsMaximizer == false)
		{
			if (Player2ViewCheckGameStateEvalFunc(&pGameStatePool->TempGameState, MinTolerableEvaluationValue_Player2, pUsedPlayer1MoveList, pUsedPlayer2MoveList) == false)
			{
				g_NumOfGameStatesWithTooLowEvalValues++;

				return -2;
			}
		}

		CGameStateValues* pOutNewGameState = nullptr;

		if (pGameStatePool->Get_UnusedGameStateObject(depthLayer, &pOutNewGameState, &ResultingGameStateObjectID) == false)
		{
			return -1;
		}

		pOutNewGameState->Clone_GameStateValues(&pGameStatePool->TempGameState);

		pOutNewGameState->LastMove_BoardPosID = BoardPosID;
		pOutNewGameState->LastMove_MoveID = MoveID;

		pOutNewGameState->PlayerID = 0;
		pInActualGameState->LeafNode = false;
		pOutNewGameState->IDofPrevGameState = pInActualGameState->IDofGameState;

		if (resultingGameStateIsMaximizer == true)
		{
			pOutNewGameState->Use_As_Maximizer();
		}
		else
		{
			pOutNewGameState->Use_As_Minimizer();
		}



		return 1;
	}


	// no move from BoardPosID found:
	return 0;
}


C1DimMoveDesc::C1DimMoveDesc()
{}

C1DimMoveDesc::~C1DimMoveDesc()
{}

void C1DimMoveDesc::Reset(void)
{
	id_Old = -1;
	id_New = -1;

	iEvaluation = -2000000;
	fEvaluation = -2000000.0f;
}

void C1DimMoveDesc::Clone_Data(C1DimMoveDesc *pOriginalObject)
{
	id_Old = pOriginalObject->id_Old;
	id_New = pOriginalObject->id_New;

	iEvaluation = pOriginalObject->iEvaluation;
	fEvaluation = pOriginalObject->fEvaluation;
}

C2DimMoveDesc::C2DimMoveDesc()
{}

C2DimMoveDesc::~C2DimMoveDesc()
{}

void C2DimMoveDesc::Reset(void)
{
	ix_Old = -1;
	iy_Old = -1;

	ix_New = -1;
	iy_New = -1;

	iEvaluation = -2000000;
	fEvaluation = -2000000.0f;
}

void C2DimMoveDesc::Clone_Data(C2DimMoveDesc *pOriginalObject)
{
	ix_Old = pOriginalObject->ix_Old;
	iy_Old = pOriginalObject->iy_Old;

	ix_New = pOriginalObject->ix_New;
	iy_New = pOriginalObject->iy_New;

	iEvaluation = pOriginalObject->iEvaluation;
	fEvaluation = pOriginalObject->fEvaluation;
}


C3DimMoveDesc::C3DimMoveDesc()
{}

C3DimMoveDesc::~C3DimMoveDesc()
{}

void C3DimMoveDesc::Reset(void)
{
	ix_Old = -1;
	iy_Old = -1;
	iz_Old = -1;

	ix_New = -1;
	iy_New = -1;
	iz_New = -1;

	iEvaluation = -2000000;
	fEvaluation = -2000000.0f;
}

void C3DimMoveDesc::Clone_Data(C3DimMoveDesc *pOriginalObject)
{
	ix_Old = pOriginalObject->ix_Old;
	iy_Old = pOriginalObject->iy_Old;
	iz_Old = pOriginalObject->iz_Old;

	ix_New = pOriginalObject->ix_New;
	iy_New = pOriginalObject->iy_New;
	iz_New = pOriginalObject->iz_New;

	iEvaluation = pOriginalObject->iEvaluation;
	fEvaluation = pOriginalObject->fEvaluation;
}

void Update_ListOfBestMoves_IntegerEvaluation(C1DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C1DimMoveDesc* pInMoveDesc)
{
	int32_t iEvaluation = pInMoveDesc->iEvaluation;

	for (int32_t j = 0; j < numOfBestMoves; j++)
	{
		if (iEvaluation > pOutBestMoveDescArray[j].iEvaluation)
		{
			for (uint32_t k = numOfBestMoves - 1; k > j; k--)
			{
				pOutBestMoveDescArray[k].Clone_Data(&pOutBestMoveDescArray[k - 1]);
			}

			pOutBestMoveDescArray[j].Clone_Data(pInMoveDesc);

			break;
		}
	}	
}

void Update_ListOfBestMoves_IntegerEvaluation(C2DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C2DimMoveDesc* pInMoveDesc)
{
	int32_t iEvaluation = pInMoveDesc->iEvaluation;

	for (int32_t j = 0; j < numOfBestMoves; j++)
	{
		if (iEvaluation >= pOutBestMoveDescArray[j].iEvaluation)
		{
			for (uint32_t k = numOfBestMoves - 1; k > j; k--)
			{
				pOutBestMoveDescArray[k].Clone_Data(&pOutBestMoveDescArray[k - 1]);
			}

			pOutBestMoveDescArray[j].Clone_Data(pInMoveDesc);

			break;
		}
	}
}

void Update_ListOfBestMoves_IntegerEvaluation(C3DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C3DimMoveDesc* pInMoveDesc)
{
	int32_t iEvaluation = pInMoveDesc->iEvaluation;

	for (int32_t j = 0; j < numOfBestMoves; j++)
	{
		if (iEvaluation >= pOutBestMoveDescArray[j].iEvaluation)
		{
			for (uint32_t k = numOfBestMoves - 1; k > j; k--)
			{
				pOutBestMoveDescArray[k].Clone_Data(&pOutBestMoveDescArray[k - 1]);
			}

			pOutBestMoveDescArray[j].Clone_Data(pInMoveDesc);

			break;
		}
	}
}

void Update_ListOfBestMoves_FloatEvaluation(C1DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C1DimMoveDesc* pInMoveDesc)
{
	float fEvaluation = pInMoveDesc->fEvaluation;

	for (int32_t j = 0; j < numOfBestMoves; j++)
	{
		if (fEvaluation >= pOutBestMoveDescArray[j].fEvaluation)
		{
			for (uint32_t k = numOfBestMoves - 1; k > j; k--)
			{
				pOutBestMoveDescArray[k].Clone_Data(&pOutBestMoveDescArray[k - 1]);
			}

			pOutBestMoveDescArray[j].Clone_Data(pInMoveDesc);

			break;
		}
	}
}

void Update_ListOfBestMoves_FloatEvaluation(C2DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C2DimMoveDesc* pInMoveDesc)
{
	float fEvaluation = pInMoveDesc->fEvaluation;

	for (int32_t j = 0; j < numOfBestMoves; j++)
	{
		if (fEvaluation >= pOutBestMoveDescArray[j].fEvaluation)
		{
			for (uint32_t k = numOfBestMoves - 1; k > j; k--)
			{
				pOutBestMoveDescArray[k].Clone_Data(&pOutBestMoveDescArray[k - 1]);
			}

			pOutBestMoveDescArray[j].Clone_Data(pInMoveDesc);

			break;
		}
	}
}

void Update_ListOfBestMoves_FloatEvaluation(C3DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C3DimMoveDesc* pInMoveDesc)
{
	float fEvaluation = pInMoveDesc->fEvaluation;

	for (int32_t j = 0; j < numOfBestMoves; j++)
	{
		if (fEvaluation >= pOutBestMoveDescArray[j].fEvaluation)
		{
			for (uint32_t k = numOfBestMoves - 1; k > j; k--)
			{
				pOutBestMoveDescArray[k].Clone_Data(&pOutBestMoveDescArray[k - 1]);
			}

			pOutBestMoveDescArray[j].Clone_Data(pInMoveDesc);

			break;
		}
	}
}

void Generate_ListOfBestMoves_IntegerEvaluation(C1DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C1DimMoveDesc* pInMoveDescArray, int32_t numOfMoves)
{
	numOfMoves = min(numOfMoves, numOfBestMoves);

	for (int32_t i = 0; i < numOfBestMoves; i++)
	{
		pOutBestMoveDescArray[i].Reset();
	}

	for (int32_t i = 0; i < numOfMoves; i++)
	{
		int32_t iEvaluation = pInMoveDescArray[i].iEvaluation;

		for (int32_t j = 0; j < numOfBestMoves; j++)
		{
			if (iEvaluation >= pOutBestMoveDescArray[j].iEvaluation)
			{
				for (uint32_t k = numOfBestMoves - 1; k > j; k--)
				{
					pOutBestMoveDescArray[k].Clone_Data(&pOutBestMoveDescArray[k - 1]);
				}

				pOutBestMoveDescArray[j].Clone_Data(&pInMoveDescArray[i]);

				break;
			}
		}
	}
}

void Generate_ListOfBestMoves_IntegerEvaluation(C2DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C2DimMoveDesc* pInMoveDescArray, int32_t numOfMoves)
{
	numOfMoves = min(numOfMoves, numOfBestMoves);

	for (int32_t i = 0; i < numOfBestMoves; i++)
	{
		pOutBestMoveDescArray[i].Reset();
	}

	for (int32_t i = 0; i < numOfMoves; i++)
	{
		int32_t iEvaluation = pInMoveDescArray[i].iEvaluation;

		for (int32_t j = 0; j < numOfBestMoves; j++)
		{
			if (iEvaluation >= pOutBestMoveDescArray[j].iEvaluation)
			{
				for (uint32_t k = numOfBestMoves - 1; k > j; k--)
				{
					pOutBestMoveDescArray[k].Clone_Data(&pOutBestMoveDescArray[k - 1]);
				}

				pOutBestMoveDescArray[j].Clone_Data(&pInMoveDescArray[i]);

				break;
			}
		}
	}
}

void Generate_ListOfBestMoves_IntegerEvaluation(C3DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C3DimMoveDesc* pInMoveDescArray, int32_t numOfMoves)
{
	numOfMoves = min(numOfMoves, numOfBestMoves);

	for (int32_t i = 0; i < numOfBestMoves; i++)
	{
		pOutBestMoveDescArray[i].Reset();
	}

	for (int32_t i = 0; i < numOfMoves; i++)
	{
		int32_t iEvaluation = pInMoveDescArray[i].iEvaluation;

		for (int32_t j = 0; j < numOfBestMoves; j++)
		{
			if (iEvaluation >= pOutBestMoveDescArray[j].iEvaluation)
			{
				for (uint32_t k = numOfBestMoves - 1; k > j; k--)
				{
					pOutBestMoveDescArray[k].Clone_Data(&pOutBestMoveDescArray[k - 1]);
				}

				pOutBestMoveDescArray[j].Clone_Data(&pInMoveDescArray[i]);

				break;
			}
		}
	}
}

void Generate_ListOfBestMoves_FloatEvaluation(C1DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C1DimMoveDesc* pInMoveDescArray, int32_t numOfMoves)
{
	numOfMoves = min(numOfMoves, numOfBestMoves);

	for (int32_t i = 0; i < numOfBestMoves; i++)
	{
		pOutBestMoveDescArray[i].Reset();
	}

	for (int32_t i = 0; i < numOfMoves; i++)
	{
		float fEvaluation = pInMoveDescArray[i].fEvaluation;

		for (int32_t j = 0; j < numOfBestMoves; j++)
		{
			if (fEvaluation >= pOutBestMoveDescArray[j].fEvaluation)
			{
				for (uint32_t k = numOfBestMoves - 1; k > j; k--)
				{
					pOutBestMoveDescArray[k] = pOutBestMoveDescArray[k - 1];
					//pOutBestMoveDescArray[k].Clone_Data(&pOutBestMoveDescArray[k - 1]);
				}

				pOutBestMoveDescArray[j] = pInMoveDescArray[i];
				//pOutBestMoveDescArray[j].Clone_Data(&pInMoveDescArray[i]);

				break;
			}
		}
	}
}

void Generate_ListOfBestMoves_FloatEvaluation(C2DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C2DimMoveDesc* pInMoveDescArray, int32_t numOfMoves)
{
	numOfMoves = min(numOfMoves, numOfBestMoves);

	for (int32_t i = 0; i < numOfBestMoves; i++)
	{
		pOutBestMoveDescArray[i].Reset();
	}

	for (int32_t i = 0; i < numOfMoves; i++)
	{
		float fEvaluation = pInMoveDescArray[i].fEvaluation;

		for (int32_t j = 0; j < numOfBestMoves; j++)
		{
			if (fEvaluation >= pOutBestMoveDescArray[j].fEvaluation)
			{
				for (uint32_t k = numOfBestMoves - 1; k > j; k--)
				{
					pOutBestMoveDescArray[k].Clone_Data(&pOutBestMoveDescArray[k - 1]);
				}

				pOutBestMoveDescArray[j].Clone_Data(&pInMoveDescArray[i]);

				break;
			}
		}
	}
}

void Generate_ListOfBestMoves_FloatEvaluation(C3DimMoveDesc* pOutBestMoveDescArray, int32_t numOfBestMoves, C3DimMoveDesc* pInMoveDescArray, int32_t numOfMoves)
{
	numOfMoves = min(numOfMoves, numOfBestMoves);

	for (int32_t i = 0; i < numOfBestMoves; i++)
	{
		pOutBestMoveDescArray[i].Reset();
	}

	for (int32_t i = 0; i < numOfMoves; i++)
	{
		float fEvaluation = pInMoveDescArray[i].fEvaluation;

		for (int32_t j = 0; j < numOfBestMoves; j++)
		{
			if (fEvaluation >= pOutBestMoveDescArray[j].fEvaluation)
			{
				for (uint32_t k = numOfBestMoves - 1; k > j; k--)
				{
					pOutBestMoveDescArray[k].Clone_Data(&pOutBestMoveDescArray[k - 1]);
				}

				pOutBestMoveDescArray[j].Clone_Data(&pInMoveDescArray[i]);

				break;
			}
		}
	}
}


CGameStateValues::CGameStateValues()
{

}

CGameStateValues::~CGameStateValues()
{
	delete[] pValueArray;
	pValueArray = nullptr;
}

void CGameStateValues::Set_EvaluationValue(float value)
{
	fEvaluation = value;
}

void CGameStateValues::Set_EvaluationValue(int32_t value)
{
	iEvaluation = value;
}

void CGameStateValues::Update_Evaluation(int32_t valueOfChange)
{
	iEvaluationChange = valueOfChange;
	iEvaluation += valueOfChange;
}

void CGameStateValues::Update_Evaluation(float valueOfChange)
{
	fEvaluationChange = valueOfChange;
	fEvaluation += valueOfChange;
}


void CGameStateValues::Backpropagate_IntegerEvaluationChange(void)
{
	if (DepthValue < 1)
	{
		return;
	}

	pUsedGameStateArray[IDofPrevGameState].iEvaluationChange = iEvaluationChange;
	pUsedGameStateArray[IDofPrevGameState].iEvaluation += iEvaluationChange;
}

void CGameStateValues::Backpropagate_MinimaxIntegerEvaluation(void)
{
	if (DepthValue < 1)
	{
		return;
	}

	if (pUsedGameStateArray[IDofPrevGameState].Minimizer == true)
	{
		if (pUsedGameStateArray[IDofPrevGameState].iEvaluation > iEvaluation)
		{
			pUsedGameStateArray[IDofPrevGameState].iEvaluation = iEvaluation;
		}
	}
	else
	{
		if (pUsedGameStateArray[IDofPrevGameState].iEvaluation < iEvaluation)
		{
			pUsedGameStateArray[IDofPrevGameState].iEvaluation = iEvaluation;
		}
	}
}

void CGameStateValues::Backpropagate_IntegerEvaluationChange(int32_t intendedDepth)
{
	if (DepthValue != intendedDepth)
	{
		return;
	}

	pUsedGameStateArray[IDofPrevGameState].iEvaluationChange = iEvaluationChange;
	pUsedGameStateArray[IDofPrevGameState].iEvaluation += iEvaluationChange;
}

void CGameStateValues::Backpropagate_MinimaxIntegerEvaluation(int32_t intendedDepth)
{
	if (DepthValue != intendedDepth)
	{
		return;
	}

	if (pUsedGameStateArray[IDofPrevGameState].Minimizer == true)
	{
		if (pUsedGameStateArray[IDofPrevGameState].iEvaluation > iEvaluation)
		{
			pUsedGameStateArray[IDofPrevGameState].iEvaluation = iEvaluation;
		}
	}
	else
	{
		if (pUsedGameStateArray[IDofPrevGameState].iEvaluation < iEvaluation)
		{
			pUsedGameStateArray[IDofPrevGameState].iEvaluation = iEvaluation;
		}
	}
}

void CGameStateValues::Backpropagate_FloatEvaluationChange(void)
{
	if (DepthValue < 1)
	{
		return;
	}

	pUsedGameStateArray[IDofPrevGameState].fEvaluationChange = fEvaluationChange;
	pUsedGameStateArray[IDofPrevGameState].fEvaluation += fEvaluationChange;
}

void CGameStateValues::Backpropagate_MinimaxFloatEvaluation(void)
{
	if (DepthValue < 1)
	{
		return;
	}

	if (pUsedGameStateArray[IDofPrevGameState].Minimizer == true)
	{
		if (pUsedGameStateArray[IDofPrevGameState].fEvaluation > fEvaluation)
		{
			pUsedGameStateArray[IDofPrevGameState].fEvaluation = fEvaluation;
		}
	}
	else
	{
		if (pUsedGameStateArray[IDofPrevGameState].fEvaluation < fEvaluation)
		{
			pUsedGameStateArray[IDofPrevGameState].fEvaluation = fEvaluation;
		}
	}
}

void CGameStateValues::Backpropagate_FloatEvaluationChange(int32_t intendedDepth)
{
	if (DepthValue != intendedDepth)
	{
		return;
	}

	pUsedGameStateArray[IDofPrevGameState].fEvaluationChange = fEvaluationChange;
	pUsedGameStateArray[IDofPrevGameState].fEvaluation += fEvaluationChange;
}

void CGameStateValues::Backpropagate_MinimaxFloatEvaluation(int32_t intendedDepth)
{
	if (DepthValue != intendedDepth)
	{
		return;
	}

	if (pUsedGameStateArray[IDofPrevGameState].Minimizer == true)
	{
		if (pUsedGameStateArray[IDofPrevGameState].fEvaluation > fEvaluation)
		{
			pUsedGameStateArray[IDofPrevGameState].fEvaluation = fEvaluation;
		}
	}
	else
	{
		if (pUsedGameStateArray[IDofPrevGameState].fEvaluation < fEvaluation)
		{
			pUsedGameStateArray[IDofPrevGameState].fEvaluation = fEvaluation;
		}
	}
}




void CGameStateValues::Reset_Evaluation(void)
{
	iEvaluation = ConstMinEvaluationScore_Minimax;
	fEvaluation = fConstMinEvaluationScore_Minimax;
	FurtherExploration = true;

	//LastMove_BoardPosID = -1;
	//LastMove_MoveID = -1;
}

void CGameStateValues::Connect_With_GameStateArray(CGameStateValues *pGameStateArray)
{
	pUsedGameStateArray = pGameStateArray;
}

void CGameStateValues::Set_Value(int8_t value, int32_t id)
{
	pValueArray[id] = value;
}

int8_t CGameStateValues::Get_Value(int32_t id)
{
	return pValueArray[id];
}

void CGameStateValues::Set_Value(int8_t value, int32_t ix, int32_t iy)
{
	pValueArray[ix + SizeX * iy] = value;
}

int8_t CGameStateValues::Get_Value(int32_t ix, int32_t iy)
{
	return pValueArray[ix + SizeX * iy];
}

void CGameStateValues::Set_Value(int8_t value, int32_t ix, int32_t iy, int32_t iz)
{
	pValueArray[ix + SizeX * iy + SizeXY * iz] = value;
}

int8_t CGameStateValues::Get_Value(int32_t ix, int32_t iy, int32_t iz)
{
	return pValueArray[ix + SizeX * iy + SizeXY * iz];
}


int32_t CGameStateValues::Get_ID_From_CartesianCoord(int32_t ix, int32_t iy)
{
	return ix + SizeX * iy;
}

int32_t CGameStateValues::Get_ID_From_CartesianCoord(int32_t ix, int32_t iy, int32_t iz)
{
	return ix + SizeX * iy + SizeXY * iz;
}

void CGameStateValues::Get_ID_From_CartesianCoord(int32_t *pOutID, int32_t ix, int32_t iy)
{
	*pOutID = ix + SizeX * iy;
}



void CGameStateValues::Get_ID_From_CartesianCoord(int32_t *pOutID, int32_t ix, int32_t iy, int32_t iz)
{
	*pOutID = ix + SizeX * iy + SizeXY * iz;
}

void CGameStateValues::Get_CartesianCoord_From_ID(int32_t *pOut_ix, int32_t *pOut_iy, int32_t id)
{
	*pOut_ix = id % SizeX;
	*pOut_iy = id / SizeX;
}

void CGameStateValues::Get_CartesianCoord_From_ID(int32_t *pOut_ix, int32_t *pOut_iy, int32_t *pOut_iz, int32_t id)
{
	int32_t iz = id / SizeXY;
	id -= iz * SizeXY;

	*pOut_ix = id % SizeX;
	*pOut_iy = id / SizeX;
	*pOut_iz = iz;
}

bool CGameStateValues::Check_If_Possible_Successor(CGameStateValues *pPrevGameState)
{
	if (IDofPrevGameState == pPrevGameState->IDofGameState)
	{
		return true;
	}

	return false;
}


int32_t CGameStateValues::Get_RootID(void)
{
	if (IDofPrevGameState < 0)
	{
		return IDofGameState;
	}

	int32_t id = IDofPrevGameState;

	CGameStateValues* pTempGameStateObject = nullptr;

	do
	{
		pTempGameStateObject = &pUsedGameStateArray[id];

		id = pTempGameStateObject->IDofPrevGameState;

		if (id < 0)
		{
			return pTempGameStateObject->IDofGameState;
		}

	} while (true);

	return -1;
}

int32_t CGameStateValues::Get_Root_And_RootID(CGameStateValues **ppOutPrevGameState)
{
	*ppOutPrevGameState = &pUsedGameStateArray[IDofGameState];

	if (IDofPrevGameState < 0)
	{
		return IDofGameState;
	}

	int32_t id = IDofPrevGameState;

	CGameStateValues* pTempGameStateObject = nullptr;

	do
	{
		pTempGameStateObject = &pUsedGameStateArray[id];

		id = pTempGameStateObject->IDofPrevGameState;

		if (id < 0)
		{
			*ppOutPrevGameState = pTempGameStateObject;
			return pTempGameStateObject->IDofGameState;
		}

	} while (true);

	return -1;
}

int32_t CGameStateValues::Get_PrevGameState(CGameStateValues **ppOutPrevGameState)
{
	if (IDofPrevGameState < 0)
	{
		*ppOutPrevGameState = nullptr;
		return -1;
	}

	*ppOutPrevGameState = &pUsedGameStateArray[IDofPrevGameState];
	return IDofPrevGameState;
}

int32_t CGameStateValues::Get_PrevGameStateID(void)
{
	return IDofPrevGameState;
}



void CGameStateValues::Use_As_Root_GameState(bool leafNodeToo)
{
	LeafNode = leafNodeToo;
	IDofPrevGameState = -1;
	DepthValue = 0;
}

void CGameStateValues::Reset(void)
{
	SimpleHashValue = 0;
	PlayerID = -1;
	LeafNode = false;
	IDofGameState = -1;
	IDofPrevGameState = -1;
	DepthValue = 0;
	iEvaluation = ConstMinEvaluationScore_Minimax;
	fEvaluation = fConstMinEvaluationScore_Minimax;
	FurtherExploration = true;

	LastMove_BoardPosID = 0;
	LastMove_MoveID = 0;
}

void CGameStateValues::Set_TreeInfo_If_Desired(int32_t depth, int32_t IDPrevGameState, bool leafNode)
{
	LeafNode = leafNode;
	DepthValue = depth;
	IDofPrevGameState = IDPrevGameState;
}

void CGameStateValues::Clone_GameStateValues(int8_t *pOriginalValueArray)
{
	for (int32_t i = 0; i < Size; i++)
	{
		pValueArray[i] = pOriginalValueArray[i];
	}
}

void CGameStateValues::Clone_GameStateValues(CGameStateValues *pOriginalObject)
{
	SimpleHashValue = pOriginalObject->SimpleHashValue;

	//PlayerID = pOriginalObject->PlayerID;
	//IDofPrevGameState = pOriginalObject->IDofPrevGameState;
	//DepthValue = pOriginalObject->DepthValue;
	//LeafNode = pOriginalObject->LeafNode;

	int8_t *pOriginalValue = &pOriginalObject->pValueArray[0];

	for (int32_t i = 0; i < Size; i++)
	{
		pValueArray[i] = pOriginalValue[i];
	}
}


void CGameStateValues::Calculate_SimpleHashValue(void)
{
	// variant of bernstein hash:

	SimpleHashValue = 0;

	for (int32_t i = 0; i < Size; i++)
	{
		uint32_t value = static_cast<uint32_t>(pValueArray[i]);
		SimpleHashValue = 33 * SimpleHashValue + value;
		//SimpleHashValue = (33 * SimpleHashValue)^value;     // ^ := bitwise exclusive OR (XOR)- Operator
	}
}

bool CGameStateValues::Check_Identity(CGameStateValues *pOtherObject)
{
	if (SimpleHashValue != pOtherObject->SimpleHashValue)
		return false;

	// with (SimpleHashValue == pOtherObject->SimpleHashValue) there could be a possible collision (2 non-identical game states)

	// collision avoidance:

	int8_t *pOtherValue = &pOtherObject->pValueArray[0];

	for (int32_t i = 0; i < Size; i++)
	{
		if (pValueArray[i] != pOtherValue[i])
		{
			return false;
		}
	}

	return true;
}

void CGameStateValues::Clone_Data(CGameStateValues *pOriginalObject)
{
	SimpleHashValue = pOriginalObject->SimpleHashValue;

	SizeX = pOriginalObject->SizeX;
	SizeY = pOriginalObject->SizeY;
	SizeZ = pOriginalObject->SizeZ;
	Size = pOriginalObject->Size;
	SizeXY = pOriginalObject->SizeXY;
	IDofPrevGameState = pOriginalObject->IDofPrevGameState;
	DepthValue = pOriginalObject->DepthValue;
	LeafNode = pOriginalObject->LeafNode;
	PlayerID = pOriginalObject->PlayerID;
	iEvaluation = pOriginalObject->iEvaluation;
	fEvaluation = pOriginalObject->fEvaluation;
	FurtherExploration = pOriginalObject->FurtherExploration;

	LastMove_BoardPosID = pOriginalObject->LastMove_BoardPosID;
	LastMove_MoveID = pOriginalObject->LastMove_MoveID;

	int8_t *pOriginalValue = &pOriginalObject->pValueArray[0];

	for (int32_t i = 0; i < Size; i++)
	{
		pValueArray[i] = pOriginalValue[i];
	}
}

void CGameStateValues::Reset_MinimaxEvaluation(void)
{
	if (Minimizer == true)
	{
		iEvaluation = ConstMaxEvaluationScore_Minimax;
		fEvaluation = fConstMaxEvaluationScore_Minimax;
	}
	else
	{
		iEvaluation = ConstMinEvaluationScore_Minimax;
		fEvaluation = fConstMinEvaluationScore_Minimax;
	}
}

void CGameStateValues::Use_As_Minimizer(void)
{
	Minimizer = true;
	iEvaluation = ConstMaxEvaluationScore_Minimax;
	fEvaluation = fConstMaxEvaluationScore_Minimax;
}

void CGameStateValues::Use_As_Maximizer(void)
{
	Minimizer = false;
	iEvaluation = ConstMinEvaluationScore_Minimax;
	fEvaluation = fConstMinEvaluationScore_Minimax;
}

bool CGameStateValues::Check_Usage(void)
{
	if (IDofGameState < 1)
	{
		return false;
	}

	return true;
}

void CGameStateValues::Initialize(int32_t size)
{
	LeafNode = false;
	IDofGameState = -1;
	IDofPrevGameState = -1;
	DepthValue = 0;
	iEvaluation = ConstMinEvaluationScore_Minimax;
	fEvaluation = fConstMinEvaluationScore_Minimax;

	SizeX = size;
	SizeY = 0;
	SizeZ = 0;
	SizeXY = 0;

	if (size <= Size)
	{
		Size = size;

		for (int32_t i = 0; i < Size; i++)
		{
			pValueArray[i] = 0;
		}
		
		return;
	}

	delete[] pValueArray;
	pValueArray = nullptr;

	Size = size;

	pValueArray = new (std::nothrow) int8_t[Size];

	for (int32_t i = 0; i < Size; i++)
	{
		pValueArray[i] = 0;
	}
}

CGameStateValues::CGameStateValues(int32_t size)
{
	LeafNode = false;
	IDofGameState = -1;
	IDofPrevGameState = -1;
	DepthValue = 0;
	iEvaluation = ConstMinEvaluationScore_Minimax;
	fEvaluation = fConstMinEvaluationScore_Minimax;

	SizeX = size;
	SizeY = 0;
	SizeZ = 0;
	SizeXY = 0;

	Size = size;

	pValueArray = new (std::nothrow) int8_t[Size];

	for (int32_t i = 0; i < Size; i++)
	{
		pValueArray[i] = 0;
	}
}

void CGameStateValues::Initialize(int32_t sizeX, int32_t sizeY)
{
	LeafNode = false;
	IDofGameState = -1;
	IDofPrevGameState = -1;
	DepthValue = 0;
	iEvaluation = ConstMinEvaluationScore_Minimax;
	fEvaluation = fConstMinEvaluationScore_Minimax;

	SizeX = sizeX;
	SizeY = sizeY;
	SizeZ = 0;

	int32_t size = sizeX * sizeY;
	SizeXY = size;

	if (size <= Size)
	{
		Size = size;

		for (int32_t i = 0; i < Size; i++)
		{
			pValueArray[i] = 0;
		}

		return;
	}

	delete[] pValueArray;
	pValueArray = nullptr;

	Size = size;

	pValueArray = new (std::nothrow) int8_t[Size];

	for (int32_t i = 0; i < Size; i++)
	{
		pValueArray[i] = 0;
	}
}

CGameStateValues::CGameStateValues(int32_t sizeX, int32_t sizeY)
{
	LeafNode = false;
	IDofGameState = -1;
	IDofPrevGameState = -1;
	DepthValue = 0;
	iEvaluation = ConstMinEvaluationScore_Minimax;
	fEvaluation = fConstMinEvaluationScore_Minimax;

	

	SizeX = sizeX;
	SizeY = sizeY;
	SizeZ = 0;

	int32_t size = sizeX * sizeY;
	SizeXY = size;

	Size = size;

	pValueArray = new (std::nothrow) int8_t[Size];

	for (int32_t i = 0; i < Size; i++)
	{
		pValueArray[i] = 0;
	}
}

void CGameStateValues::Initialize(int32_t sizeX, int32_t sizeY, int32_t sizeZ)
{
	LeafNode = false;
	IDofGameState = -1;
	IDofPrevGameState = -1;
	DepthValue = 0;
	iEvaluation = ConstMinEvaluationScore_Minimax;
	fEvaluation = fConstMinEvaluationScore_Minimax;

	SizeX = sizeX;
	SizeY = sizeY;
	SizeZ = sizeZ;

	SizeXY = sizeX * sizeY;

	int32_t size = sizeX * sizeY  * sizeZ;

	if (size <= Size)
	{
		Size = size;

		for (int32_t i = 0; i < Size; i++)
		{
			pValueArray[i] = 0;
		}

		return;
	}

	delete[] pValueArray;
	pValueArray = nullptr;

	Size = size;

	pValueArray = new (std::nothrow) int8_t[Size];

	for (int32_t i = 0; i < Size; i++)
	{
		pValueArray[i] = 0;
	}
}

CGameStateValues::CGameStateValues(int32_t sizeX, int32_t sizeY, int32_t sizeZ)
{
	LeafNode = false;
	IDofGameState = -1;
	IDofPrevGameState = -1;
	DepthValue = 0;
	iEvaluation = ConstMinEvaluationScore_Minimax;
	fEvaluation = fConstMinEvaluationScore_Minimax;

	

	SizeX = sizeX;
	SizeY = sizeY;
	SizeZ = sizeZ;

	SizeXY = sizeX * sizeY;

	int32_t size = sizeX * sizeY  * sizeZ;

	Size = size;

	pValueArray = new (std::nothrow) int8_t[Size];

	for (int32_t i = 0; i < Size; i++)
	{
		pValueArray[i] = 0;
	}
}





CGameStateRingBuffer::CGameStateRingBuffer()
{

}

CGameStateRingBuffer::~CGameStateRingBuffer()
{
	delete[] pGameStateArray;
	pGameStateArray = nullptr;
}


int32_t CGameStateRingBuffer::Get_PreviousBufferElementID(void)
{
	return PreviousBufferElement;
}


int32_t CGameStateRingBuffer::Get_PreviousBufferElement(int8_t **ppGameState)
{
	*ppGameState = &(pGameStateArray[PreviousBufferElement].pValueArray[0]);
	return PreviousBufferElement;
}

void CGameStateRingBuffer::Set_PreviousBufferElementData(int8_t *pGameState)
{
	pGameStateArray[PreviousBufferElement].Clone_GameStateValues(pGameState);
}

void CGameStateRingBuffer::Set_PreviousBufferElementData(CGameStateValues *pGameStateObject)
{
	pGameStateArray[PreviousBufferElement].Clone_GameStateValues(pGameStateObject);
}

int32_t CGameStateRingBuffer::Get_PreviousBufferElement(CGameStateValues **ppGameStateObject)
{
	*ppGameStateObject = &pGameStateArray[PreviousBufferElement];

	return PreviousBufferElement;
}




int32_t CGameStateRingBuffer::Get_ActualBufferElementID(void)
{
	return ActualBufferElement;
}


int32_t CGameStateRingBuffer::Get_ActualBufferElement(int8_t **ppGameState)
{
	*ppGameState = &(pGameStateArray[ActualBufferElement].pValueArray[0]);
	return ActualBufferElement;
}

void CGameStateRingBuffer::Set_ActualBufferElementData(CGameStateValues *pGameStateObject)
{
	pGameStateArray[ActualBufferElement].Clone_GameStateValues(pGameStateObject);
}

void CGameStateRingBuffer::Set_ActualBufferElementData(int8_t *pGameState)
{
	pGameStateArray[ActualBufferElement].Clone_GameStateValues(pGameState);
}

int32_t CGameStateRingBuffer::Get_ActualBufferElement(CGameStateValues **ppGameStateObject)
{
	*ppGameStateObject = &pGameStateArray[ActualBufferElement];

	return ActualBufferElement;
}



void CGameStateRingBuffer::Reset_ActualBufferElement(void)
{
	PreviousBufferElement = Size - 1;
	ActualBufferElement = 0;
}

void CGameStateRingBuffer::Set_ActualBufferElement(int32_t value)
{
	ActualBufferElement = value % Size;

	if (ActualBufferElement > 0)
	{
		PreviousBufferElement = ActualBufferElement - 1;
	}
	else
	{
		PreviousBufferElement = Size - 1;
	}
}

void CGameStateRingBuffer::Decrease_ActualBufferElement(void)
{
	if (ActualBufferElement > 0)
	{
		ActualBufferElement--;
	}
	else
	{
		ActualBufferElement = Size - 1;
	}

	if (PreviousBufferElement > 0)
	{
		PreviousBufferElement--;
	}
	else
	{
		PreviousBufferElement = Size - 1;
	}
}

void CGameStateRingBuffer::Increase_ActualBufferElement(void)
{
	PreviousBufferElement = ActualBufferElement;

	ActualBufferElement++;
	ActualBufferElement = ActualBufferElement % Size;

	pGameStateArray[ActualBufferElement].Clone_GameStateValues(&pGameStateArray[PreviousBufferElement]);
}

void CGameStateRingBuffer::Initialize(int32_t bufferSize, int32_t gameStateSize)
{
	PreviousBufferElement = bufferSize - 1;
	ActualBufferElement = 0;

	if (bufferSize <= Size)
	{
		Size = bufferSize;

		for (int32_t i = 0; i < Size; i++)
		{
			pGameStateArray[i].Initialize(gameStateSize);
			pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
		}

		return;
	}

	delete[] pGameStateArray;
	pGameStateArray = nullptr;

	Size = bufferSize;

	pGameStateArray = new (std::nothrow) CGameStateValues[Size];

	for (int32_t i = 0; i < Size; i++)
	{		
		pGameStateArray[i].Initialize(gameStateSize);	
		pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
	}
}

void CGameStateRingBuffer::Initialize(int32_t bufferSize, int32_t gameStateSizeX, int32_t gameStateSizeY)
{
	PreviousBufferElement = bufferSize - 1;
	ActualBufferElement = 0;

	if (bufferSize <= Size)
	{
		Size = bufferSize;

		for (int32_t i = 0; i < Size; i++)
		{
			pGameStateArray[i].Initialize(gameStateSizeX, gameStateSizeY);
			pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
		}

		return;
	}

	delete[] pGameStateArray;
	pGameStateArray = nullptr;

	Size = bufferSize;

	pGameStateArray = new (std::nothrow) CGameStateValues[Size];

	for (int32_t i = 0; i < Size; i++)
	{
		pGameStateArray[i].Initialize(gameStateSizeX, gameStateSizeY);
		pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
	}
}

void CGameStateRingBuffer::Initialize(int32_t bufferSize, int32_t gameStateSizeX, int32_t gameStateSizeY, int32_t gameStateSizeZ)
{
	PreviousBufferElement = bufferSize - 1;
	ActualBufferElement = 0;

	if (bufferSize <= Size)
	{
		Size = bufferSize;

		for (int32_t i = 0; i < Size; i++)
		{
			pGameStateArray[i].Initialize(gameStateSizeX, gameStateSizeY, gameStateSizeZ);
			pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
		}

		return;
	}

	delete[] pGameStateArray;
	pGameStateArray = nullptr;

	Size = bufferSize;

	pGameStateArray = new (std::nothrow) CGameStateValues[Size];

	for (int32_t i = 0; i < Size; i++)
	{
		pGameStateArray[i].Initialize(gameStateSizeX, gameStateSizeY, gameStateSizeZ);
		pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
	}
}

CSimpleGameTree_DepthLayerInfo::CSimpleGameTree_DepthLayerInfo()
{}

CSimpleGameTree_DepthLayerInfo::~CSimpleGameTree_DepthLayerInfo()
{
	delete[] pGameStateIDArray;
	pGameStateIDArray = nullptr;
}

void CSimpleGameTree_DepthLayerInfo::Initialize(int32_t numGameStatesMax)
{
	NumGameStatesMax = numGameStatesMax;
	NumGameStatesUsed = 0;

	delete[] pGameStateIDArray;
	pGameStateIDArray = nullptr;

	pGameStateIDArray = new (std::nothrow) int32_t[numGameStatesMax];
}


bool CSimpleGameTree_DepthLayerInfo::Remove_GameState(int32_t gameStateID)
{
	for (int32_t i = 0; i < NumGameStatesUsed; i++)
	{
		if (pGameStateIDArray[i] == gameStateID)
		{
			pGameStateIDArray[i] = -1;
			NumGameStatesUsed--;
			return true;
		}
	}

	return false;
}
bool CSimpleGameTree_DepthLayerInfo::Add_GameState(int32_t gameStateID)
{
	if (NumGameStatesUsed >= NumGameStatesMax)
	{
		return false;
	}

	pGameStateIDArray[NumGameStatesUsed] = gameStateID;
	NumGameStatesUsed++;

	return true;
}

void CSimpleGameTree_DepthLayerInfo::Reset(void)
{
	NumGameStatesUsed = 0;
}


CGameStatePool::CGameStatePool()
{

}

CGameStatePool_SimpleGameTree::CGameStatePool_SimpleGameTree()
{

}

void CGameStatePool_SimpleGameTree::Initialize_DepthLayers(int32_t numOfDepthLayersMax, int32_t numOfGameStatesMaxPerLayer)
{
	delete[] pDepthLayerInfoArray;
	pDepthLayerInfoArray = nullptr;

	NumOfDepthLayersMax = numOfDepthLayersMax;

	pDepthLayerInfoArray = new (std::nothrow) CSimpleGameTree_DepthLayerInfo[numOfDepthLayersMax];

	for (int32_t i = 0; i < numOfDepthLayersMax; i++)
	{
		pDepthLayerInfoArray[i].Initialize(numOfGameStatesMaxPerLayer);
	}
}

void CGameStatePool_SimpleGameTree::Initialize_DepthLayers(int32_t numOfDepthLayersMax, int32_t *pNumOfGameStatesMaxPerLayerArray)
{
	delete[] pDepthLayerInfoArray;
	pDepthLayerInfoArray = nullptr;

	NumOfDepthLayersMax = numOfDepthLayersMax;

	pDepthLayerInfoArray = new (std::nothrow) CSimpleGameTree_DepthLayerInfo[numOfDepthLayersMax];

	for (int32_t i = 0; i < numOfDepthLayersMax; i++)
	{
		pDepthLayerInfoArray[i].Initialize(pNumOfGameStatesMaxPerLayerArray[i % numOfDepthLayersMax]);
	}
}


CExtendedGameStatePool::CExtendedGameStatePool()
{

}

CSimpleGameStatePool::CSimpleGameStatePool()
{

}

CGameStatePool::~CGameStatePool()
{
	delete[] pGameStateArray;
	pGameStateArray = nullptr;
}

CGameStatePool_SimpleGameTree::~CGameStatePool_SimpleGameTree()
{
	delete[] pGameStateArray;
	pGameStateArray = nullptr;

	delete[] pDepthLayerInfoArray;
	pDepthLayerInfoArray = nullptr;
}

CExtendedGameStatePool::~CExtendedGameStatePool()
{
	delete[] pGameStateArray;
	pGameStateArray = nullptr;

	delete[] pSimpleLinkedListManagerArray;
	pSimpleLinkedListManagerArray = nullptr;
}

void CExtendedGameStatePool::Reset_NextBestMoveData(void)
{
	NextBestMove_BoardID = 0;
	NextBestMove_MoveID = 0;
	NextBestMove_iEvaluation = ConstMinEvaluationScore_Minimax;
	NextBestMove_fEvaluation = fConstMinEvaluationScore_Minimax;
}


int32_t CExtendedGameStatePool::Get_Random_GameStateID_LastDepthLayerExcluded(int32_t minDepth, int32_t maxDepth, int32_t numAttemptsMax, CRandomNumbersNN *pRandomNumbers)
{
	// ein Game-State auf der untersten Ebene stellt bereits den Endpunkt eines m�glichen testspiels dar:
	maxDepth = min(maxDepth, NumOfDepthLayersMax - 2);

	int32_t id;

	for (int32_t i = 0; i < numAttemptsMax; i++)
	{
		id = pRandomNumbers->Get_IntegerNumber(0, Size);

		if (pGameStateArray[id].IDofGameState < 1)
		{
			continue;
		}

		if (pGameStateArray[id].DepthValue < minDepth)
		{
			continue;
		}

		if (pGameStateArray[id].DepthValue > maxDepth)
		{
			continue;
		}

		return id;

	}

	return -1;
}

int32_t CExtendedGameStatePool::Get_Random_GameStateID(int32_t minDepth, int32_t maxDepth, int32_t numAttemptsMax, CRandomNumbersNN *pRandomNumbers)
{
	maxDepth = min(maxDepth, NumOfDepthLayersMax - 1);

	int32_t id;

	for (int32_t i = 0; i < numAttemptsMax; i++)
	{
		id = pRandomNumbers->Get_IntegerNumber(0, Size);

		if (pGameStateArray[id].IDofGameState < 1)
		{
			continue;
		}

		if (pGameStateArray[id].DepthValue < minDepth)
		{
			continue;
		}

		if (pGameStateArray[id].DepthValue > maxDepth)
		{
			continue;
		}

		return id;

	}

	return -1;
}


CSimpleGameStatePool::~CSimpleGameStatePool()
{
	delete[] pGameStateArray;
	pGameStateArray = nullptr;
}

void CGameStatePool::Initialize(int32_t poolSize, int32_t gameStateSize)
{
	NumGameStateObjectsUsed = 0;

	if (poolSize <= Size)
	{
		Size = poolSize;

		for (int32_t i = 0; i < Size; i++)
		{
			pGameStateArray[i].Initialize(gameStateSize);
			pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
		}

		SimpleMemoryManager.Initialize(Size);
		SimpleLinkedListManager.Initialize(Size);

		return;
	}

	delete[] pGameStateArray;
	pGameStateArray = nullptr;

	Size = poolSize;

	pGameStateArray = new (std::nothrow) CGameStateValues[Size];

	for (int32_t i = 0; i < Size; i++)
	{
		pGameStateArray[i].Initialize(gameStateSize);
		pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
	}

	SimpleMemoryManager.Initialize(Size);
	SimpleLinkedListManager.Initialize(Size);
}

void CGameStatePool_SimpleGameTree::Initialize(int32_t poolSize, int32_t gameStateSize)
{
	NumGameStateObjectsUsed = 0;

	if (poolSize <= Size)
	{
		Size = poolSize;

		for (int32_t i = 0; i < Size; i++)
		{
			pGameStateArray[i].Initialize(gameStateSize);
			pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
		}

		SimpleMemoryManager.Initialize(Size);
		SimpleLinkedListManager.Initialize(Size);

		return;
	}

	delete[] pGameStateArray;
	pGameStateArray = nullptr;

	Size = poolSize;

	pGameStateArray = new (std::nothrow) CGameStateValues[Size];

	for (int32_t i = 0; i < Size; i++)
	{
		pGameStateArray[i].Initialize(gameStateSize);
		pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
	}

	SimpleMemoryManager.Initialize(Size);
	SimpleLinkedListManager.Initialize(Size);
}

void CExtendedGameStatePool::Initialize(int32_t numOfDepthLayersMax, int32_t poolSize, int32_t gameStateSize)
{
	NumGameStateObjectsUsed = 0;

	TempGameState.Initialize(gameStateSize);

	if (poolSize <= Size)
	{
		Size = poolSize;

		for (int32_t i = 0; i < Size; i++)
		{
			pGameStateArray[i].Initialize(gameStateSize);
			pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
		}

		SimpleMemoryManager.Initialize(Size);

		if (numOfDepthLayersMax <= NumOfDepthLayersMax)
		{
			NumOfDepthLayersMax = numOfDepthLayersMax;
			

			for (int32_t i = 0; i < NumOfDepthLayersMax; i++)
			{
				pSimpleLinkedListManagerArray[i].Initialize(Size);
			}
		}
		else
		{
			delete[] pSimpleLinkedListManagerArray;
			pSimpleLinkedListManagerArray = nullptr;

			NumOfDepthLayersMax = numOfDepthLayersMax;
			

			pSimpleLinkedListManagerArray = new (std::nothrow) CSimpleLinkedListManager[NumOfDepthLayersMax];

			for (int32_t i = 0; i < NumOfDepthLayersMax; i++)
			{
				pSimpleLinkedListManagerArray[i].Initialize(Size);
			}
		}

		return;
	}

	

	delete[] pGameStateArray;
	pGameStateArray = nullptr;

	delete[] pSimpleLinkedListManagerArray;
	pSimpleLinkedListManagerArray = nullptr;

	NumOfDepthLayersMax = numOfDepthLayersMax;
	

	pSimpleLinkedListManagerArray = new (std::nothrow) CSimpleLinkedListManager[NumOfDepthLayersMax];

	Size = poolSize;

	pGameStateArray = new (std::nothrow) CGameStateValues[Size];

	for (int32_t i = 0; i < Size; i++)
	{
		pGameStateArray[i].Initialize(gameStateSize);
		pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
	}

	SimpleMemoryManager.Initialize(Size);

	for (int32_t i = 0; i < NumOfDepthLayersMax; i++)
	{
		pSimpleLinkedListManagerArray[i].Initialize(Size);
	}
}

void CExtendedGameStatePool::Initialize(int32_t numOfDepthLayersMax, int32_t poolSize, int32_t gameStateSizeX, int32_t gameStateSizeY)
{
	NumGameStateObjectsUsed = 0;

	TempGameState.Initialize(gameStateSizeX, gameStateSizeY);

	if (poolSize <= Size)
	{
		Size = poolSize;

		for (int32_t i = 0; i < Size; i++)
		{
			pGameStateArray[i].Initialize(gameStateSizeX, gameStateSizeY);
			pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
		}

		SimpleMemoryManager.Initialize(Size);

		if (numOfDepthLayersMax <= NumOfDepthLayersMax)
		{
			NumOfDepthLayersMax = numOfDepthLayersMax;
			

			for (int32_t i = 0; i < NumOfDepthLayersMax; i++)
			{
				pSimpleLinkedListManagerArray[i].Initialize(Size);
			}
		}
		else
		{
			delete[] pSimpleLinkedListManagerArray;
			pSimpleLinkedListManagerArray = nullptr;

			NumOfDepthLayersMax = numOfDepthLayersMax;
			

			pSimpleLinkedListManagerArray = new (std::nothrow) CSimpleLinkedListManager[NumOfDepthLayersMax];

			for (int32_t i = 0; i < NumOfDepthLayersMax; i++)
			{
				pSimpleLinkedListManagerArray[i].Initialize(Size);
			}
		}

		return;
	}



	delete[] pGameStateArray;
	pGameStateArray = nullptr;

	delete[] pSimpleLinkedListManagerArray;
	pSimpleLinkedListManagerArray = nullptr;

	NumOfDepthLayersMax = numOfDepthLayersMax;
	

	pSimpleLinkedListManagerArray = new (std::nothrow) CSimpleLinkedListManager[NumOfDepthLayersMax];

	Size = poolSize;

	pGameStateArray = new (std::nothrow) CGameStateValues[Size];

	for (int32_t i = 0; i < Size; i++)
	{
		pGameStateArray[i].Initialize(gameStateSizeX, gameStateSizeY);
		pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
	}

	SimpleMemoryManager.Initialize(Size);

	for (int32_t i = 0; i < NumOfDepthLayersMax; i++)
	{
		pSimpleLinkedListManagerArray[i].Initialize(Size);
	}
}

void CExtendedGameStatePool::Initialize(int32_t numOfDepthLayersMax, int32_t poolSize, int32_t gameStateSizeX, int32_t gameStateSizeY, int32_t gameStateSizeZ)
{
	NumGameStateObjectsUsed = 0;

	TempGameState.Initialize(gameStateSizeX, gameStateSizeY, gameStateSizeZ);

	if (poolSize <= Size)
	{
		Size = poolSize;

		for (int32_t i = 0; i < Size; i++)
		{
			pGameStateArray[i].Initialize(gameStateSizeX, gameStateSizeY, gameStateSizeZ);
			pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
		}

		SimpleMemoryManager.Initialize(Size);

		if (numOfDepthLayersMax <= NumOfDepthLayersMax)
		{
			NumOfDepthLayersMax = numOfDepthLayersMax;
			

			for (int32_t i = 0; i < NumOfDepthLayersMax; i++)
			{
				pSimpleLinkedListManagerArray[i].Initialize(Size);
			}
		}
		else
		{
			delete[] pSimpleLinkedListManagerArray;
			pSimpleLinkedListManagerArray = nullptr;

			NumOfDepthLayersMax = numOfDepthLayersMax;
			

			pSimpleLinkedListManagerArray = new (std::nothrow) CSimpleLinkedListManager[NumOfDepthLayersMax];

			for (int32_t i = 0; i < NumOfDepthLayersMax; i++)
			{
				pSimpleLinkedListManagerArray[i].Initialize(Size);
			}
		}

		return;
	}



	delete[] pGameStateArray;
	pGameStateArray = nullptr;

	delete[] pSimpleLinkedListManagerArray;
	pSimpleLinkedListManagerArray = nullptr;

	NumOfDepthLayersMax = numOfDepthLayersMax;
	

	pSimpleLinkedListManagerArray = new (std::nothrow) CSimpleLinkedListManager[NumOfDepthLayersMax];

	Size = poolSize;

	pGameStateArray = new (std::nothrow) CGameStateValues[Size];

	for (int32_t i = 0; i < Size; i++)
	{
		pGameStateArray[i].Initialize(gameStateSizeX, gameStateSizeY, gameStateSizeZ);
		pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
	}

	SimpleMemoryManager.Initialize(Size);

	for (int32_t i = 0; i < NumOfDepthLayersMax; i++)
	{
		pSimpleLinkedListManagerArray[i].Initialize(Size);
	}
}

void CSimpleGameStatePool::Initialize(int32_t poolSize, int32_t gameStateSize)
{
	NumGameStateObjectsUsed = 0;

	if (poolSize <= Size)
	{
		Size = poolSize;

		for (int32_t i = 0; i < Size; i++)
		{
			pGameStateArray[i].Initialize(gameStateSize);
			pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
		}

		SimpleMemoryManager.Initialize(Size);
		

		return;
	}

	delete[] pGameStateArray;
	pGameStateArray = nullptr;

	Size = poolSize;

	pGameStateArray = new (std::nothrow) CGameStateValues[Size];

	for (int32_t i = 0; i < Size; i++)
	{
		pGameStateArray[i].Initialize(gameStateSize);
		pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
	}

	SimpleMemoryManager.Initialize(Size);
	
}

void CGameStatePool::Initialize(int32_t poolSize, int32_t gameStateSizeX, int32_t gameStateSizeY)
{
	NumGameStateObjectsUsed = 0;

	if (poolSize < Size)
	{
		Size = poolSize;

		for (int32_t i = 0; i < Size; i++)
		{
			pGameStateArray[i].Initialize(gameStateSizeX, gameStateSizeY);
			pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
		}

		SimpleMemoryManager.Initialize(Size);
		SimpleLinkedListManager.Initialize(Size);

		return;
	}

	delete[] pGameStateArray;
	pGameStateArray = nullptr;

	Size = poolSize;

	pGameStateArray = new (std::nothrow) CGameStateValues[Size];

	for (int32_t i = 0; i < Size; i++)
	{
		pGameStateArray[i].Initialize(gameStateSizeX, gameStateSizeY);
		pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
	}

	SimpleMemoryManager.Initialize(Size);
	SimpleLinkedListManager.Initialize(Size);
}



void CGameStatePool_SimpleGameTree::Initialize(int32_t poolSize, int32_t gameStateSizeX, int32_t gameStateSizeY)
{
	NumGameStateObjectsUsed = 0;

	if (poolSize < Size)
	{
		Size = poolSize;

		for (int32_t i = 0; i < Size; i++)
		{
			pGameStateArray[i].Initialize(gameStateSizeX, gameStateSizeY);
			pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
		}

		SimpleMemoryManager.Initialize(Size);
		SimpleLinkedListManager.Initialize(Size);

		return;
	}

	delete[] pGameStateArray;
	pGameStateArray = nullptr;

	Size = poolSize;

	pGameStateArray = new (std::nothrow) CGameStateValues[Size];

	for (int32_t i = 0; i < Size; i++)
	{
		pGameStateArray[i].Initialize(gameStateSizeX, gameStateSizeY);
		pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
	}

	SimpleMemoryManager.Initialize(Size);
	SimpleLinkedListManager.Initialize(Size);
}


void CSimpleGameStatePool::Initialize(int32_t poolSize, int32_t gameStateSizeX, int32_t gameStateSizeY)
{
	NumGameStateObjectsUsed = 0;

	if (poolSize <= Size)
	{
		Size = poolSize;

		for (int32_t i = 0; i < Size; i++)
		{
			pGameStateArray[i].Initialize(gameStateSizeX, gameStateSizeY);
			pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
		}

		SimpleMemoryManager.Initialize(Size);
		

		return;
	}

	delete[] pGameStateArray;
	pGameStateArray = nullptr;

	Size = poolSize;

	pGameStateArray = new (std::nothrow) CGameStateValues[Size];

	for (int32_t i = 0; i < Size; i++)
	{
		pGameStateArray[i].Initialize(gameStateSizeX, gameStateSizeY);
		pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
	}

	SimpleMemoryManager.Initialize(Size);
	
}

void CGameStatePool::Initialize(int32_t poolSize, int32_t gameStateSizeX, int32_t gameStateSizeY, int32_t gameStateSizeZ)
{
	NumGameStateObjectsUsed = 0;

	if (poolSize <= Size)
	{
		Size = poolSize;

		for (int32_t i = 0; i < Size; i++)
		{
			pGameStateArray[i].Initialize(gameStateSizeX, gameStateSizeY, gameStateSizeZ);
			pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
		}

		SimpleMemoryManager.Initialize(Size);
		SimpleLinkedListManager.Initialize(Size);

		return;
	}

	delete[] pGameStateArray;
	pGameStateArray = nullptr;

	Size = poolSize;

	pGameStateArray = new (std::nothrow) CGameStateValues[Size];

	for (int32_t i = 0; i < Size; i++)
	{
		pGameStateArray[i].Initialize(gameStateSizeX, gameStateSizeY, gameStateSizeZ);
		pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
	}

	SimpleMemoryManager.Initialize(Size);
	SimpleLinkedListManager.Initialize(Size);
}



void CGameStatePool_SimpleGameTree::Initialize(int32_t poolSize, int32_t gameStateSizeX, int32_t gameStateSizeY, int32_t gameStateSizeZ)
{
	NumGameStateObjectsUsed = 0;

	if (poolSize <= Size)
	{
		Size = poolSize;

		for (int32_t i = 0; i < Size; i++)
		{
			pGameStateArray[i].Initialize(gameStateSizeX, gameStateSizeY, gameStateSizeZ);
			pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
		}

		SimpleMemoryManager.Initialize(Size);
		SimpleLinkedListManager.Initialize(Size);

		return;
	}

	delete[] pGameStateArray;
	pGameStateArray = nullptr;

	Size = poolSize;

	pGameStateArray = new (std::nothrow) CGameStateValues[Size];

	for (int32_t i = 0; i < Size; i++)
	{
		pGameStateArray[i].Initialize(gameStateSizeX, gameStateSizeY, gameStateSizeZ);
		pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
	}

	SimpleMemoryManager.Initialize(Size);
	SimpleLinkedListManager.Initialize(Size);
}


void CSimpleGameStatePool::Initialize(int32_t poolSize, int32_t gameStateSizeX, int32_t gameStateSizeY, int32_t gameStateSizeZ)
{
	NumGameStateObjectsUsed = 0;

	if (poolSize <= Size)
	{
		Size = poolSize;

		for (int32_t i = 0; i < Size; i++)
		{
			pGameStateArray[i].Initialize(gameStateSizeX, gameStateSizeY, gameStateSizeZ);
			pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
		}

		SimpleMemoryManager.Initialize(Size);
	

		return;
	}

	delete[] pGameStateArray;
	pGameStateArray = nullptr;

	Size = poolSize;

	pGameStateArray = new (std::nothrow) CGameStateValues[Size];

	for (int32_t i = 0; i < Size; i++)
	{
		pGameStateArray[i].Initialize(gameStateSizeX, gameStateSizeY, gameStateSizeZ);
		pGameStateArray[i].Connect_With_GameStateArray(pGameStateArray);
	}

	SimpleMemoryManager.Initialize(Size);
	
}

bool CGameStatePool::Get_UnusedGameStateObject(int32_t* pBelongingID)
{
	int32_t id = SimpleMemoryManager.Request_Unused_MemoryElementID();

	if (id == 0) // no unused object found
	{
		*pBelongingID = 0;
		return false;
	}
	else // unused object found
	{
		SimpleLinkedListManager.Init_New_ListElement(id);

		*pBelongingID = id;
		pGameStateArray[id].IDofGameState = id;
		

		NumGameStateObjectsUsed++;
		return true;
	}
}



bool CGameStatePool_SimpleGameTree::Get_UnusedGameStateObject(int32_t depth, int32_t* pBelongingID)
{
	int32_t id = SimpleMemoryManager.Request_Unused_MemoryElementID();

	if (id == 0) // no unused object found
	{
		*pBelongingID = 0;
		return false;
	}
	else // unused object found
	{
		SimpleLinkedListManager.Init_New_ListElement(id);

		pDepthLayerInfoArray[depth].Add_GameState(id);

		*pBelongingID = id;
		pGameStateArray[id].IDofGameState = id;
		pGameStateArray[id].IDofPrevGameState = -1;
		pGameStateArray[id].DepthValue = depth;
		pGameStateArray[id].LeafNode = true;


		NumGameStateObjectsUsed++;
		return true;
	}
}

bool CExtendedGameStatePool::Check_If_TempGameState_Already_Exists(int32_t depth)
{
	CSimpleLinkedListManager* pSimpleLinkedListManager = &pSimpleLinkedListManagerArray[depth];
	int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
	int32_t id = 0;

	for (int32_t j = 0; j < NumObjectsUsed; j++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
		
		if (pGameStateArray[id].Check_Identity(&TempGameState) == true)
			return true;
	}

	return false;
}

bool CExtendedGameStatePool::Get_UnusedGameStateObject(int32_t depth, int32_t* pBelongingID)
{
	if (depth < 0)
	{
		return false;
	}
	if (depth >= NumOfDepthLayersMax)
	{
		return false;
	}

	int32_t id = SimpleMemoryManager.Request_Unused_MemoryElementID();

	if (id == 0) // no unused object found
	{
		*pBelongingID = 0;
		return false;
	}
	else // unused object found
	{
		pSimpleLinkedListManagerArray[depth].Init_New_ListElement(id);

		IDofLastReturnedGameStateObject = id;

		*pBelongingID = id;
		pGameStateArray[id].IDofPrevGameState = -1;
		pGameStateArray[id].IDofGameState = id;
		pGameStateArray[id].DepthValue = depth;
		pGameStateArray[id].LeafNode = true;
		NumGameStateObjectsUsed++;
		return true;
	}
}

bool CSimpleGameStatePool::Get_UnusedGameStateObject(int32_t* pBelongingID)
{
	int32_t id = SimpleMemoryManager.Request_Unused_MemoryElementID();

	if (id == 0) // no unused object found
	{
		*pBelongingID = 0;
		return false;
	}
	else // unused object found
	{
		*pBelongingID = id;
		pGameStateArray[id].IDofGameState = id;

		NumGameStateObjectsUsed++;
		return true;
	}
}


bool CGameStatePool::Get_UnusedGameStateObject(CGameStateValues** ppGameStateObject, int32_t* pBelongingID)
{
	int32_t id = SimpleMemoryManager.Request_Unused_MemoryElementID();

	//_Add_To_Log("id", &id);

	if (id == 0) // no unused object found
	{
		*pBelongingID = 0;
		*ppGameStateObject = nullptr;
		return false;
	}
	else // unused object found
	{
		SimpleLinkedListManager.Init_New_ListElement(id);

		//if(SimpleLinkedListManager.Init_New_ListElement(id) == true)
		//Add_To_Log("Init_New_ListElement");

		*pBelongingID = id;
		pGameStateArray[id].IDofGameState = id;
		*ppGameStateObject = &pGameStateArray[id];

		NumGameStateObjectsUsed++;

		return true;
	}
}



bool CGameStatePool_SimpleGameTree::Get_UnusedGameStateObject(int32_t depth, CGameStateValues** ppGameStateObject, int32_t* pBelongingID)
{
	int32_t id = SimpleMemoryManager.Request_Unused_MemoryElementID();

	//_Add_To_Log("id", &id);

	if (id == 0) // no unused object found
	{
		*pBelongingID = 0;
		*ppGameStateObject = nullptr;
		return false;
	}
	else // unused object found
	{
		SimpleLinkedListManager.Init_New_ListElement(id);

		//if(SimpleLinkedListManager.Init_New_ListElement(id) == true)
		//Add_To_Log("Init_New_ListElement");

		pDepthLayerInfoArray[depth].Add_GameState(id);

		*pBelongingID = id;
		
		pGameStateArray[id].IDofGameState = id;
		pGameStateArray[id].IDofPrevGameState = -1;
		pGameStateArray[id].DepthValue = depth;
		pGameStateArray[id].LeafNode = true;

		*ppGameStateObject = &pGameStateArray[id];

		NumGameStateObjectsUsed++;

		return true;
	}
}


bool CExtendedGameStatePool::Get_UnusedGameStateObject(int32_t depth, CGameStateValues** ppGameStateObject, int32_t* pBelongingID)
{
	if (depth < 0)
	{
		Add_To_Log(0, "Get_UnusedGameStateObject: depth < 0");
		return false;
	}
	if (depth >= NumOfDepthLayersMax)
	{
		Add_To_Log(0, "Get_UnusedGameStateObject: depth >= NumOfDepthLayersMax");
		return false;
	}

	int32_t id = SimpleMemoryManager.Request_Unused_MemoryElementID();

	//_Add_To_Log("id", &id);

	if (id == 0) // no unused object found
	{
		*pBelongingID = 0;
		*ppGameStateObject = nullptr;
		return false;
	}
	else // unused object found
	{
		pSimpleLinkedListManagerArray[depth].Init_New_ListElement(id);

		//if(SimpleLinkedListManager.Init_New_ListElement(id) == true)
		//Add_To_Log("Init_New_ListElement");

		IDofLastReturnedGameStateObject = id;

		*pBelongingID = id;
		pGameStateArray[id].IDofPrevGameState = -1;
		pGameStateArray[id].IDofGameState = id;
		pGameStateArray[id].DepthValue = depth;
		pGameStateArray[id].LeafNode = true;
		*ppGameStateObject = &pGameStateArray[id];

		NumGameStateObjectsUsed++;

		return true;
	}
}

bool CSimpleGameStatePool::Get_UnusedGameStateObject(CGameStateValues** ppGameStateObject, int32_t* pBelongingID)
{
	int32_t id = SimpleMemoryManager.Request_Unused_MemoryElementID();

	//_Add_To_Log("id", &id);

	if (id == 0) // no unused object found
	{
		*pBelongingID = 0;
		*ppGameStateObject = nullptr;
		return false;
	}
	else // unused object found
	{
		*pBelongingID = id;
		pGameStateArray[id].IDofGameState = id;
		*ppGameStateObject = &pGameStateArray[id];

		NumGameStateObjectsUsed++;

		return true;
	}
}


bool CGameStatePool::Stop_Using_GameStateObject(CGameStateValues** ppGameStateObject)
{
	if (*ppGameStateObject == nullptr)
	{
		return false;
	}

	int32_t id = (*ppGameStateObject)->IDofGameState;

	if (id < 0)
	{
		return false;
	}

	if (SimpleMemoryManager.Free_Used_MemoryElement(id) == true)
	{
		pGameStateArray[id].Reset();
		*ppGameStateObject = nullptr;

		NumGameStateObjectsUsed--;

		return SimpleLinkedListManager.Free_Used_ListElement(id);
	}

	return false;
}

bool CGameStatePool::Stop_Using_GameStateObject(int32_t id)
{
	if (SimpleMemoryManager.Free_Used_MemoryElement(id) == true)
	{
		pGameStateArray[id].Reset();

		NumGameStateObjectsUsed--;

		return SimpleLinkedListManager.Free_Used_ListElement(id);
	}

	return false;
}

bool CExtendedGameStatePool::Stop_Using_GameStateObject(int32_t id)
{
	if (SimpleMemoryManager.Free_Used_MemoryElement(id) == true)
	{
		int32_t depth = pGameStateArray[id].DepthValue;
		pGameStateArray[id].Reset();

		NumGameStateObjectsUsed--;

		return pSimpleLinkedListManagerArray[depth].Free_Used_ListElement(id);
	}

	return false;
}

bool CExtendedGameStatePool::Stop_Using_GameStateObject(CGameStateValues** ppGameStateObject)
{
	if (*ppGameStateObject == nullptr)
	{
		return false;
	}

	int32_t id = (*ppGameStateObject)->IDofGameState;

	if (id < 0)
	{
		return false;
	}

	if (SimpleMemoryManager.Free_Used_MemoryElement(id) == true)
	{
		int32_t depth = pGameStateArray[id].DepthValue;
		pGameStateArray[id].Reset();
		*ppGameStateObject = nullptr;

		NumGameStateObjectsUsed--;

		return pSimpleLinkedListManagerArray[depth].Free_Used_ListElement(id);
	}

	return false;
}


bool CSimpleGameStatePool::Stop_Using_GameStateObject(int32_t id)
{
	if (SimpleMemoryManager.Free_Used_MemoryElement(id) == true)
	{
		pGameStateArray[id].Reset();

		NumGameStateObjectsUsed--;

		return true;
	}

	return false;
}

bool CSimpleGameStatePool::Stop_Using_GameStateObject(CGameStateValues** ppGameStateObject)
{
	if (*ppGameStateObject == nullptr)
	{
		return false;
	}

	int32_t id = (*ppGameStateObject)->IDofGameState;

	if (id < 0)
	{
		return false;
	}

	if (SimpleMemoryManager.Free_Used_MemoryElement(id) == true)
	{
		pGameStateArray[id].Reset();
		*ppGameStateObject = nullptr;

		NumGameStateObjectsUsed--;

		return true;
	}

	return false;
}


void CGameStatePool::Stop_Using_AllGameStateObjects(void)
{
	int32_t NumObjectsUsed = SimpleLinkedListManager.NumUsedListElements;
	int32_t id = 0;

	for (int32_t i = 0; i < NumObjectsUsed; i++)
	{
		id = SimpleLinkedListManager.Get_Next_Used_ListElement(id);

		pGameStateArray[id].Reset();

		NumGameStateObjectsUsed--;

		SimpleMemoryManager.Free_Used_MemoryElement(id);
		SimpleLinkedListManager.Free_Used_ListElement(id);
	}
}



void CGameStatePool_SimpleGameTree::Stop_Using_AllGameStateObjects(void)
{
	int32_t NumObjectsUsed = SimpleLinkedListManager.NumUsedListElements;
	int32_t id = 0;

	for (int32_t i = 0; i < NumObjectsUsed; i++)
	{
		id = SimpleLinkedListManager.Get_Next_Used_ListElement(id);

		pGameStateArray[id].Reset();

		NumGameStateObjectsUsed--;

		SimpleMemoryManager.Free_Used_MemoryElement(id);
		SimpleLinkedListManager.Free_Used_ListElement(id);
	}

	for (int32_t i = 0; i < NumOfDepthLayersMax; i++)
		pDepthLayerInfoArray[i].Reset();
}


int32_t CExtendedGameStatePool::Get_Root_And_RootID(CGameStateValues** ppOutGameStateObject, CGameStateValues* pInGameStateObject)
{
	*ppOutGameStateObject = pInGameStateObject;

	int32_t id = pInGameStateObject->IDofPrevGameState;

	if (id < 0)
	{
		return pInGameStateObject->IDofGameState;
	}

	CGameStateValues* pTempGameStateObject = nullptr;

	do
	{
		pTempGameStateObject = &pGameStateArray[id];

		id = pTempGameStateObject->IDofPrevGameState;

		if (id < 0)
		{
			*ppOutGameStateObject = pTempGameStateObject;
			return pTempGameStateObject->IDofGameState;
		}

	} while (true);

	return -1;
}

int32_t CExtendedGameStatePool::Get_RootID(CGameStateValues* pGameStateObject)
{
	int32_t id = pGameStateObject->IDofPrevGameState;

	if (id < 0)
	{
		return pGameStateObject->IDofGameState;
	}

	CGameStateValues* pTempGameStateObject = nullptr;

	do
	{
		pTempGameStateObject = &pGameStateArray[id];

		id = pTempGameStateObject->IDofPrevGameState;

		if (id < 0)
		{
			return pTempGameStateObject->IDofGameState;
		}

	} while (true);

	return -1;
}

void CExtendedGameStatePool::Reset_EvaluationValues(void)
{
	for (int32_t j = 0; j < NumOfDepthLayersMax; j++)
	{
		int32_t NumObjectsUsed = pSimpleLinkedListManagerArray[j].NumUsedListElements;
		int32_t id = 0;

		for (int32_t i = 0; i < NumObjectsUsed; i++)
		{
			id = pSimpleLinkedListManagerArray[j].Get_Next_Used_ListElement(id);

			pGameStateArray[id].Reset_Evaluation();
		}
	}
}

void CExtendedGameStatePool::Stop_Using_AllGameStateObjects(void)
{
	IDofLastReturnedGameStateObject = 0;

	for (int32_t j = 0; j < NumOfDepthLayersMax; j++)
	{
		int32_t NumObjectsUsed = pSimpleLinkedListManagerArray[j].NumUsedListElements;
		int32_t id = 0;

		for (int32_t i = 0; i < NumObjectsUsed; i++)
		{
			id = pSimpleLinkedListManagerArray[j].Get_Next_Used_ListElement(id);

			pGameStateArray[id].Reset();

			NumGameStateObjectsUsed--;

			SimpleMemoryManager.Free_Used_MemoryElement(id);
			pSimpleLinkedListManagerArray[j].Free_Used_ListElement(id);
		}
	}
}

void CExtendedGameStatePool::Get_Best_GameState_IntegerEvaluation(CGameStateValues** ppOutGameStateObject, int32_t* pOutBelongingID, int32_t deepthLayer)
{
	CSimpleLinkedListManager *pSimpleLinkedListManager = &pSimpleLinkedListManagerArray[deepthLayer];

	int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;

	if (NumObjectsUsed < 1)
	{
		*ppOutGameStateObject = nullptr;
		*pOutBelongingID = -1;
		return;
	}

	int32_t bestEvaluation = -2000000;
	int32_t belongingID = -1;

	
	int32_t id = 0;

	for (int32_t i = 0; i < NumObjectsUsed; i++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);

		if (pGameStateArray[id].iEvaluation >= bestEvaluation)
		{
			bestEvaluation = pGameStateArray[id].iEvaluation;
			belongingID = id;
		}
	}

	*ppOutGameStateObject = &pGameStateArray[belongingID];
	*pOutBelongingID = belongingID;
}

void CExtendedGameStatePool::Get_Worst_GameState_IntegerEvaluation(CGameStateValues** ppOutGameStateObject, int32_t* pOutBelongingID, int32_t deepthLayer)
{
	CSimpleLinkedListManager* pSimpleLinkedListManager = &pSimpleLinkedListManagerArray[deepthLayer];

	int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;

	if (NumObjectsUsed < 1)
	{
		*ppOutGameStateObject = nullptr;
		*pOutBelongingID = -1;
		return;
	}

	int32_t bestEvaluation = 2000000;
	int32_t belongingID = -1;


	int32_t id = 0;

	for (int32_t i = 0; i < NumObjectsUsed; i++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);

		if (pGameStateArray[id].iEvaluation <= bestEvaluation)
		{
			bestEvaluation = pGameStateArray[id].iEvaluation;
			belongingID = id;
		}
	}

	*ppOutGameStateObject = &pGameStateArray[belongingID];
	*pOutBelongingID = belongingID;
}

void CExtendedGameStatePool::Get_Best_GameState_FloatEvaluation(CGameStateValues** ppOutGameStateObject, int32_t* pOutBelongingID, int32_t deepthLayer)
{
	CSimpleLinkedListManager* pSimpleLinkedListManager = &pSimpleLinkedListManagerArray[deepthLayer];

	int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;

	if (NumObjectsUsed < 1)
	{
		*ppOutGameStateObject = nullptr;
		*pOutBelongingID = -1;
		return;
	}

	float bestEvaluation = -2000000.0f;
	int32_t belongingID = -1;

	
	int32_t id = 0;

	for (uint32_t i = 0; i < NumObjectsUsed; i++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);

		if (pGameStateArray[id].fEvaluation >= bestEvaluation)
		{
			bestEvaluation = pGameStateArray[id].fEvaluation;
			belongingID = id;
		}
	}

	*ppOutGameStateObject = &pGameStateArray[belongingID];
	*pOutBelongingID = belongingID;
}

void CExtendedGameStatePool::Get_Worst_GameState_FloatEvaluation(CGameStateValues** ppOutGameStateObject, int32_t* pOutBelongingID, int32_t deepthLayer)
{
	CSimpleLinkedListManager* pSimpleLinkedListManager = &pSimpleLinkedListManagerArray[deepthLayer];

	int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;

	if (NumObjectsUsed < 1)
	{
		*ppOutGameStateObject = nullptr;
		*pOutBelongingID = -1;
		return;
	}

	float bestEvaluation = 2000000.0f;
	int32_t belongingID = -1;


	int32_t id = 0;

	for (uint32_t i = 0; i < NumObjectsUsed; i++)
	{
		id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);

		if (pGameStateArray[id].fEvaluation <= bestEvaluation)
		{
			bestEvaluation = pGameStateArray[id].fEvaluation;
			belongingID = id;
		}
	}

	*ppOutGameStateObject = &pGameStateArray[belongingID];
	*pOutBelongingID = belongingID;
}


void CSimpleGameStatePool::Stop_Using_AllGameStateObjects(void)
{
	SimpleMemoryManager.Reset_Arrays();

	for (int32_t i = 0; i < Size; i++)
	{
		pGameStateArray[i].Reset();
	}
}

void Backpropagate_IntegerEvaluationValues_Player1(CExtendedGameStatePool *pGameStatePool)
{
	CGameStateValues *pGameState = nullptr;
	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;

	for (int32_t i = numOfDepthLayersMax - 1; i > 0; i--)
	{
		CSimpleLinkedListManager *pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[i];
		int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
		int32_t id = 0;


		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);

			pGameState = &pGameStatePool->pGameStateArray[id];

			pGameState->Backpropagate_MinimaxIntegerEvaluation();
		}
	}
}


void OneStepBackpropagate_MinimaxIntegerEvaluationValues(int32_t IDofSourceGameState, CExtendedGameStatePool* pGameStatePool)
{
	CGameStateValues* pGameState = &pGameStatePool->pGameStateArray[IDofSourceGameState];
	pGameState->Backpropagate_MinimaxIntegerEvaluation();

	/*if (pGameState->DepthValue == 3)
	{
		int32_t iEvaluation = pGameState->iEvaluation;

		if(pGameStatePool->NextBestMove_iEvaluation < iEvaluation)
		{
			pGameStatePool->NextBestMove_iEvaluation = iEvaluation;
			pGameStatePool->NextBestMove_BoardID = pGameState->LastMove_BoardPosID;
			pGameStatePool->NextBestMove_MoveID = pGameState->LastMove_MoveID;
		}
	}*/
}

void OneStepBackpropagate_MinimaxFloatEvaluationValues(int32_t IDofSourceGameState, CExtendedGameStatePool* pGameStatePool)
{
	CGameStateValues* pGameState = &pGameStatePool->pGameStateArray[IDofSourceGameState];
	pGameState->Backpropagate_MinimaxFloatEvaluation();

	/*if (pGameState->DepthValue == 3)
	{
		float fEvaluation = pGameState->fEvaluation;

		if (pGameStatePool->NextBestMove_fEvaluation < fEvaluation)
		{
			pGameStatePool->NextBestMove_fEvaluation = fEvaluation;
			pGameStatePool->NextBestMove_BoardID = pGameState->LastMove_BoardPosID;
			pGameStatePool->NextBestMove_MoveID = pGameState->LastMove_MoveID;
		}
	}*/
}

void Backpropagate_MinimaxIntegerEvaluationValues(CExtendedGameStatePool *pGameStatePool)
{
	CGameStateValues *pGameState = nullptr;
	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;

	for (int32_t i = numOfDepthLayersMax - 1; i > 0; i--)
	{
		CSimpleLinkedListManager *pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[i];
		int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
		int32_t id = 0;


		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);

			pGameState = &pGameStatePool->pGameStateArray[id];

			pGameState->Backpropagate_MinimaxIntegerEvaluation();
		}
	}
}

void Backpropagate_MinimaxIntegerEvaluationValues(CGameStatePool_SimpleGameTree *pGameStatePool)
{
	CGameStateValues *pGameState = nullptr;
	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;

	for (int32_t i = numOfDepthLayersMax - 1; i > 0; i--)
	{
		CSimpleGameTree_DepthLayerInfo *pDepthLayerInfo = &pGameStatePool->pDepthLayerInfoArray[i];

		int32_t NumObjectsUsed = pDepthLayerInfo->NumGameStatesUsed;

		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			pGameState = &pGameStatePool->pGameStateArray[pDepthLayerInfo->pGameStateIDArray[j]];

			pGameState->Backpropagate_MinimaxIntegerEvaluation();
		}
	}
}

void OneStepBackpropagate_IntegerEvaluationChanges(int32_t IDofSourceGameState, CExtendedGameStatePool* pGameStatePool)
{
	CGameStateValues* pGameState = &pGameStatePool->pGameStateArray[IDofSourceGameState];
	pGameState->Backpropagate_IntegerEvaluationChange();
}

void OneStepBackpropagate_FloatEvaluationChanges(int32_t IDofSourceGameState, CExtendedGameStatePool* pGameStatePool)
{
	CGameStateValues* pGameState = &pGameStatePool->pGameStateArray[IDofSourceGameState];
	pGameState->Backpropagate_FloatEvaluationChange();
}

void Backpropagate_IntegerEvaluationChanges(CExtendedGameStatePool *pGameStatePool)
{
	CGameStateValues *pGameState = nullptr;
	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;

	for (int32_t i = numOfDepthLayersMax - 1; i > 0; i--)
	{
		CSimpleLinkedListManager *pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[i];
		int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
		int32_t id = 0;


		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);

			pGameState = &pGameStatePool->pGameStateArray[id];

			pGameState->Backpropagate_IntegerEvaluationChange();
		}
	}
}

void Backpropagate_IntegerEvaluationChanges(CGameStatePool_SimpleGameTree *pGameStatePool)
{
	CGameStateValues *pGameState = nullptr;
	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;

	for (int32_t i = numOfDepthLayersMax - 1; i > 0; i--)
	{
		CSimpleGameTree_DepthLayerInfo *pDepthLayerInfo = &pGameStatePool->pDepthLayerInfoArray[i];

		int32_t NumObjectsUsed = pDepthLayerInfo->NumGameStatesUsed;

		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			pGameState = &pGameStatePool->pGameStateArray[pDepthLayerInfo->pGameStateIDArray[j]];

			pGameState->Backpropagate_IntegerEvaluationChange();
		}
	}
}


void Backpropagate_MinimaxFloatEvaluationValues(CExtendedGameStatePool *pGameStatePool)
{
	CGameStateValues *pGameState = nullptr;
	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;

	for (int32_t i = numOfDepthLayersMax - 1; i > 0; i--)
	{
		CSimpleLinkedListManager *pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[i];
		int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
		int32_t id = 0;


		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);

			pGameState = &pGameStatePool->pGameStateArray[id];

			pGameState->Backpropagate_MinimaxFloatEvaluation();
		}
	}
}

void Backpropagate_MinimaxFloatEvaluationValues(CGameStatePool_SimpleGameTree *pGameStatePool)
{
	CGameStateValues *pGameState = nullptr;
	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;

	for (int32_t i = numOfDepthLayersMax - 1; i > 0; i--)
	{
		CSimpleGameTree_DepthLayerInfo *pDepthLayerInfo = &pGameStatePool->pDepthLayerInfoArray[i];

		int32_t NumObjectsUsed = pDepthLayerInfo->NumGameStatesUsed;

		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			pGameState = &pGameStatePool->pGameStateArray[pDepthLayerInfo->pGameStateIDArray[j]];

			pGameState->Backpropagate_MinimaxFloatEvaluation();
		}
	}
}

void Backpropagate_FloatEvaluationChanges(CExtendedGameStatePool *pGameStatePool)
{
	CGameStateValues *pGameState = nullptr;
	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;

	for (int32_t i = numOfDepthLayersMax - 1; i > 0; i--)
	{
		CSimpleLinkedListManager *pSimpleLinkedListManager = &pGameStatePool->pSimpleLinkedListManagerArray[i];
		int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
		int32_t id = 0;


		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);

			pGameState = &pGameStatePool->pGameStateArray[id];

			pGameState->Backpropagate_FloatEvaluationChange();
		}
	}
}

void Backpropagate_FloatEvaluationChanges(CGameStatePool_SimpleGameTree *pGameStatePool)
{
	CGameStateValues *pGameState = nullptr;
	int32_t numOfDepthLayersMax = pGameStatePool->NumOfDepthLayersMax;

	for (int32_t i = numOfDepthLayersMax - 1; i > 0; i--)
	{
		CSimpleGameTree_DepthLayerInfo *pDepthLayerInfo = &pGameStatePool->pDepthLayerInfoArray[i];

		int32_t NumObjectsUsed = pDepthLayerInfo->NumGameStatesUsed;

		for (int32_t j = 0; j < NumObjectsUsed; j++)
		{
			pGameState = &pGameStatePool->pGameStateArray[pDepthLayerInfo->pGameStateIDArray[j]];

			pGameState->Backpropagate_FloatEvaluationChange();
		}
	}
}


CBreadthFirstSearchAI::CBreadthFirstSearchAI()
{}

CBreadthFirstSearchAI::~CBreadthFirstSearchAI()
{
	delete[] pMoveDescValuesArray;
	pMoveDescValuesArray = nullptr;
}

void CBreadthFirstSearchAI::Change_Seed(uint64_t seed)
{
	RandomNumbers.Change_Seed(seed);
}

void CBreadthFirstSearchAI::Use_MaxSearchDepth(void)
{
	MaxSearchDepth = MaxSearchDepthOriginal;
}

void CBreadthFirstSearchAI::Set_SearchDepth(int32_t depth)
{
	MaxSearchDepth = min(depth, MaxSearchDepthOriginal);
}

void CBreadthFirstSearchAI::Improve_MoveOrder(int32_t numOfSortingStepsMax)
{
	int32_t numOfMoveDescriptionsMinus1 = NumOfMoveDescriptions - 1;

	numOfSortingStepsMax = min(numOfSortingStepsMax, numOfMoveDescriptionsMinus1);

	for (int32_t i = 0; i < numOfSortingStepsMax; i++)
	{
		bool swappedMove = false;

		for (int32_t j = numOfMoveDescriptionsMinus1; j > i; j--)
		{
			int32_t jMinus1 = j - 1;

			if (pMoveDescValuesArray[j].EstimatedEvaluation > pMoveDescValuesArray[jMinus1].EstimatedEvaluation)
			{
				swappedMove = true;

				int32_t tempMoveID = pMoveDescValuesArray[jMinus1].MoveID;
				int32_t tempBoardPosID = pMoveDescValuesArray[jMinus1].BoardPosID;
				int32_t tempEstimatedEvaluation = pMoveDescValuesArray[jMinus1].EstimatedEvaluation;

				pMoveDescValuesArray[jMinus1].MoveID = pMoveDescValuesArray[j].MoveID;
				pMoveDescValuesArray[jMinus1].BoardPosID = pMoveDescValuesArray[j].BoardPosID;
				pMoveDescValuesArray[jMinus1].EstimatedEvaluation = pMoveDescValuesArray[j].EstimatedEvaluation;

				pMoveDescValuesArray[j].MoveID = tempMoveID;
				pMoveDescValuesArray[j].BoardPosID = tempBoardPosID;
				pMoveDescValuesArray[j].EstimatedEvaluation = tempEstimatedEvaluation;
			}
		}

		// no Swapping happened, moves are sorted
		if (swappedMove == false)
		{
			break;
		}
	}

	/*for (int32_t i = 0; i < 4; i++)
	{
		Add_To_Log(0, "eval", pMoveDescValuesArray[i].EstimatedEvaluation);
	}*/
}


void CBreadthFirstSearchAI::Set_Player1MoveExcludedBoardElements(int32_t numOfValues, int8_t *pValueArray)
{
	TestMove.NumOfPlayer1MoveExcludedBoardElements = numOfValues;

	for (int32_t i = 0; i < numOfValues; i++)
	{
		TestMove.Player1MoveExcludedBoardElementsArray[i] = pValueArray[i];
	}
}

void CBreadthFirstSearchAI::Set_Player2MoveExcludedBoardElements(int32_t numOfValues, int8_t *pValueArray)
{
	TestMove.NumOfPlayer2MoveExcludedBoardElements = numOfValues;

	for (int32_t i = 0; i < numOfValues; i++)
	{
		TestMove.Player2MoveExcludedBoardElementsArray[i] = pValueArray[i];
	}
}

void CBreadthFirstSearchAI::Initialize(CMovePatternList* pPlayer1MoveList, CMovePatternList* pPlayer2MoveList, int32_t numTestGameStatesMax, int32_t numTestGameStatesMaxPerDepthLayer, int32_t maxSearchDepth, int32_t gameBoardSizeXDir, int32_t gameBoardSizeYDir)
{
	delete[] pMoveDescValuesArray;
	pMoveDescValuesArray = nullptr;

	GameBoardSizeXY = gameBoardSizeXDir * gameBoardSizeYDir;

	MaxSearchDepthOriginal = maxSearchDepth;
	MaxSearchDepth = maxSearchDepth;
	NumTestGameStatesMax = numTestGameStatesMax;
	NumTestGameStatesMaxPerDepthLayer = numTestGameStatesMaxPerDepthLayer;

	pUsedPlayer1MoveList = pPlayer1MoveList;
	pUsedPlayer2MoveList = pPlayer2MoveList;

	TestMove.Set_MovePatternLists(pPlayer1MoveList, pPlayer2MoveList);

	TestMove.Set_GameBoardSizeXDir(gameBoardSizeXDir);
	TestMove.Set_GameBoardSizeXY(GameBoardSizeXY);

	GameStatePool.Initialize(MaxSearchDepth, NumTestGameStatesMax, gameBoardSizeXDir, gameBoardSizeYDir);

	NumOfDifferentMoveTypes = pUsedPlayer1MoveList->NumOfMoves;
	NumOfMoveDescriptions = NumOfDifferentMoveTypes * GameBoardSizeXY;

	pMoveDescValuesArray = new (std::nothrow) CMoveDescValues[NumOfMoveDescriptions];


	int32_t boardPosIDCounter = 0;
	int32_t moveID = 0;

	for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	{
		pMoveDescValuesArray[i].BoardPosID = i % GameBoardSizeXY;
		pMoveDescValuesArray[i].MoveID = moveID;
		pMoveDescValuesArray[i].EstimatedEvaluation = ConstMinEvaluationScore_Minimax;

		boardPosIDCounter++;

		if (boardPosIDCounter == GameBoardSizeXY)
		{
			boardPosIDCounter = 0;
			moveID++;
		}
	}
}

void CBreadthFirstSearchAI::Initialize(CMovePatternList* pPlayer1MoveList, CMovePatternList* pPlayer2MoveList, int32_t numTestGameStatesMax, int32_t numTestGameStatesMaxPerDepthLayer, int32_t maxSearchDepth, int32_t gameBoardSizeXDir, int32_t gameBoardSizeYDir, pCheckGameStateEvalFunc Player1ViewFunc, pCheckGameStateEvalFunc Player2ViewFunc)
{
	delete[] pMoveDescValuesArray;
	pMoveDescValuesArray = nullptr;

	GameBoardSizeXY = gameBoardSizeXDir * gameBoardSizeYDir;

	MaxSearchDepthOriginal = maxSearchDepth;
	MaxSearchDepth = maxSearchDepth;
	NumTestGameStatesMax = numTestGameStatesMax;
	NumTestGameStatesMaxPerDepthLayer = numTestGameStatesMaxPerDepthLayer;

	pUsedPlayer1MoveList = pPlayer1MoveList;
	pUsedPlayer2MoveList = pPlayer2MoveList;

	TestMove.Set_MovePatternLists(pPlayer1MoveList, pPlayer2MoveList);

	TestMove.Set_GameBoardSizeXDir(gameBoardSizeXDir);
	TestMove.Set_GameBoardSizeXY(GameBoardSizeXY);

	TestMove.Set_EvaluationFunctions(Player1ViewFunc, Player2ViewFunc);

	GameStatePool.Initialize(MaxSearchDepth, NumTestGameStatesMax, gameBoardSizeXDir, gameBoardSizeYDir);

	NumOfDifferentMoveTypes = pUsedPlayer1MoveList->NumOfMoves;
	NumOfMoveDescriptions = NumOfDifferentMoveTypes * GameBoardSizeXY;

	pMoveDescValuesArray = new (std::nothrow) CMoveDescValues[NumOfMoveDescriptions];


	int32_t boardPosIDCounter = 0;
	int32_t moveID = 0;

	for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	{
		pMoveDescValuesArray[i].BoardPosID = i % GameBoardSizeXY;
		pMoveDescValuesArray[i].MoveID = moveID;
		pMoveDescValuesArray[i].EstimatedEvaluation = ConstMinEvaluationScore_Minimax;

		boardPosIDCounter++;

		if (boardPosIDCounter == GameBoardSizeXY)
		{
			boardPosIDCounter = 0;
			moveID++;
		}
	}
}



void CBreadthFirstSearchAI::Set_LeafGameStatesEvaluationFunctions(pLeafGameStatesEvalFunc Player1ViewFunc, pLeafGameStatesEvalFunc Player2ViewFunc)
{
	Player1ViewLeafGameStatesEvalFunc = Player1ViewFunc;
	Player2ViewLeafGameStatesEvalFunc = Player2ViewFunc;
}



void CBreadthFirstSearchAI::Execute_Player1AI(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState)
{
	GameStatePool.Stop_Using_AllGameStateObjects();

	for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	{
		TestMove.BoardPosID = pMoveDescValuesArray[i].BoardPosID;
		TestMove.MoveID = pMoveDescValuesArray[i].MoveID;
		pMoveDescValuesArray[i].EstimatedEvaluation = ConstMinEvaluationScore_Minimax;
		pMoveDescValuesArray[i].IDofResultingGameState = 0;

		int32_t result = TestMove.Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, 0, false);
		
		if (result == -1)
		{
			Add_To_Log(0, "game tree too large, searchDepth 1");
			goto GameTreeCreationFinished;
		}
		else if (result == 1)
		{
			pMoveDescValuesArray[i].IDofResultingGameState = GameStatePool.IDofLastReturnedGameStateObject;
		}
	}

	/*int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

	for (int32_t i = 0; i < GameBoardSizeXY; i++)
	{
		TestMove.BoardPosID = i;

		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			TestMove.MoveID = j;

			if (TestMove.Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, 0, false) == -1)
			{
				Add_To_Log(0, "game tree too large, searchDepth 1");
				goto GameTreeCreationFinished;
			}
		} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
	} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	*/

	for (int32_t searchDepth = 1; searchDepth < MaxSearchDepth; searchDepth++)
	{
		int32_t playerID = searchDepth % 2;

		int32_t movementCounter = 0;

		if (playerID == 0)
		{
			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			int32_t id = 0;
			int32_t movementCounter = 0;

			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					TestMove.BoardPosID = i;

					for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
					{
						TestMove.MoveID = j;

						int32_t result = TestMove.Make_Player1Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, false);
						if(result == -1)
						//if (TestMove.Make_Player1Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, false) == -1)
						{
							Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
							goto GameTreeCreationFinished;
						}

						if (result == 1)
						movementCounter++;

						if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
						{
							Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
							goto TooManyTestGameStates1;
							//break;
						}
					} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

			TooManyTestGameStates1:;

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)
		}
		else // if (playerID == 1)
		{
			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			int32_t id = 0;


			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					TestMove.BoardPosID = i;

					for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
					{
						TestMove.MoveID = j;

						int32_t result = TestMove.Make_Player2Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, true);
						if (result == -1)
						//if (TestMove.Make_Player2Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, true) == -1)
						{
							Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
							goto GameTreeCreationFinished;
						}

						if (result == 1)
						movementCounter++;

						if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
						{
							Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
							goto TooManyTestGameStates2;
							//break;
						}
					} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

			TooManyTestGameStates2:;

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)
		}
	} // end of for (int32_t searchDepth = 0; searchDepth < MaxSearchDepthPlus1; searchDepth++)

GameTreeCreationFinished:;

	Player1ViewLeafGameStatesEvalFunc(&GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
	Backpropagate_MinimaxIntegerEvaluationValues(&GameStatePool);

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID);
	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

	for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	{
		int32_t id = pMoveDescValuesArray[i].IDofResultingGameState;

		if (id > 0)
		{
			pMoveDescValuesArray[i].EstimatedEvaluation = GameStatePool.pGameStateArray[id].iEvaluation;
		}
	}
}

void CBreadthFirstSearchAI::Execute_Player1AI_DiscardInsufficientStates(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, int32_t minTolerableEvalValuePlayer1, int32_t minTolerableEvalValuePlayer2)
{
	g_NumOfGameStatesWithTooLowEvalValues = 0;

	TestMove.MinTolerableEvaluationValue_Player1 = minTolerableEvalValuePlayer1;
	TestMove.MinTolerableEvaluationValue_Player2 = minTolerableEvalValuePlayer2;

	GameStatePool.Stop_Using_AllGameStateObjects();

	for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	{
		TestMove.BoardPosID = pMoveDescValuesArray[i].BoardPosID;
		TestMove.MoveID = pMoveDescValuesArray[i].MoveID;
		pMoveDescValuesArray[i].EstimatedEvaluation = ConstMinEvaluationScore_Minimax;
		pMoveDescValuesArray[i].IDofResultingGameState = 0;

		int32_t result = TestMove.Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, 0, false);

		if (result == -1)
		{
			Add_To_Log(0, "game tree too large, searchDepth 1");
			goto GameTreeCreationFinished;
		}
		else if (result == 1)
		{
			pMoveDescValuesArray[i].IDofResultingGameState = GameStatePool.IDofLastReturnedGameStateObject;
		}
	}

	/*int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

	for (int32_t i = 0; i < GameBoardSizeXY; i++)
	{
		TestMove.BoardPosID = i;

		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			TestMove.MoveID = j;

			if (TestMove.Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, 0, false) == -1)
			{
				Add_To_Log(0, "game tree too large, searchDepth 1");
				goto GameTreeCreationFinished;
			}
		} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
	} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	*/

	for (int32_t searchDepth = 1; searchDepth < MaxSearchDepth; searchDepth++)
	{
		int32_t playerID = searchDepth % 2;

		int32_t movementCounter = 0;

		if (playerID == 0)
		{
			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			int32_t id = 0;
			int32_t movementCounter = 0;

			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					TestMove.BoardPosID = i;

					for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
					{
						TestMove.MoveID = j;

						int32_t result = TestMove.Make_Player1Move_If_Possible_DiscardInsufficientStates(pActualGameState, &GameStatePool, searchDepth, false);

						if (result == -1)
						{
							Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
							goto GameTreeCreationFinished;
						}

						if (result > 0)
							movementCounter++;

						if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
						{
							Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
							goto TooManyTestGameStates1;
							//break;
						}
					} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

			TooManyTestGameStates1:;

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)
		}
		else // if (playerID == 1)
		{
			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			int32_t id = 0;


			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					TestMove.BoardPosID = i;

					for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
					{
						TestMove.MoveID = j;

						//if (TestMove.Make_Player2Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, true) == -1)

						//int32_t result = TestMove.Make_Player2Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, true);
						int32_t result = TestMove.Make_Player2Move_If_Possible_DiscardInsufficientStates(pActualGameState, &GameStatePool, searchDepth, true);

						if (result == -1)
						{
							Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
							goto GameTreeCreationFinished;
						}

						if (result > 0)
							movementCounter++;

						if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
						{
							Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
							goto TooManyTestGameStates2;
							//break;
						}
					} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

			TooManyTestGameStates2:;

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)
		}
	} // end of for (int32_t searchDepth = 0; searchDepth < MaxSearchDepthPlus1; searchDepth++)

GameTreeCreationFinished:;

	Player1ViewLeafGameStatesEvalFunc(&GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
	Backpropagate_MinimaxIntegerEvaluationValues(&GameStatePool);

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID);
	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

	Add_To_Log(0, "g_NumOfGameStatesWithTooLowEvalValues", g_NumOfGameStatesWithTooLowEvalValues);

	for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	{
		int32_t id = pMoveDescValuesArray[i].IDofResultingGameState;

		if (id > 0)
		{
			pMoveDescValuesArray[i].EstimatedEvaluation = GameStatePool.pGameStateArray[id].iEvaluation;
		}
	}
}

void CBreadthFirstSearchAI::Execute_Player1AI_AvoidRepetitiveStates(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState)
{
	g_NumOfMultipleVisitedGameStates = 0;

	GameStatePool.Stop_Using_AllGameStateObjects();

	for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	{
		TestMove.BoardPosID = pMoveDescValuesArray[i].BoardPosID;
		TestMove.MoveID = pMoveDescValuesArray[i].MoveID;
		pMoveDescValuesArray[i].EstimatedEvaluation = ConstMinEvaluationScore_Minimax;
		pMoveDescValuesArray[i].IDofResultingGameState = 0;

		int32_t result = TestMove.Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, 0, false);

		if (result == -1)
		{
			Add_To_Log(0, "game tree too large, searchDepth 1");
			goto GameTreeCreationFinished;
		}
		else if (result == 1)
		{
			pMoveDescValuesArray[i].IDofResultingGameState = GameStatePool.IDofLastReturnedGameStateObject;
		}

	}
	/*int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

	for (int32_t i = 0; i < GameBoardSizeXY; i++)
	{
		TestMove.BoardPosID = i;

		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			TestMove.MoveID = j;

			if (TestMove.Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, 0, false) == -1)
			{
				Add_To_Log(0, "game tree too large, searchDepth 1");
				goto GameTreeCreationFinished;
			}
		} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
	} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	*/

	for (int32_t searchDepth = 1; searchDepth < MaxSearchDepth; searchDepth++)
	{
		int32_t playerID = searchDepth % 2;

		int32_t movementCounter = 0;

		if (playerID == 0)
		{
			Add_To_Log(0, "move");

			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			int32_t id = 0;
			
			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					TestMove.BoardPosID = i;

					for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
					{
						TestMove.MoveID = j;

						int32_t result = TestMove.Make_Player1Move_If_Possible_AvoidRepetitiveStates(pActualGameState, &GameStatePool, searchDepth, false);

						if (result == -1)
						{
							Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
							goto GameTreeCreationFinished;
						}

						if (result > 0)
							movementCounter++;

						if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
						{
							Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
							goto TooManyTestGameStates1;
							//break;
						}
					} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

			TooManyTestGameStates1:;

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

			Add_To_Log(0, "searchDepth", searchDepth + 1);
			Add_To_Log(0, "...movementCounter", movementCounter);
		}
		else // if (playerID == 1)
		{
			Add_To_Log(0, "counter move");

			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			int32_t id = 0;


			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					TestMove.BoardPosID = i;

					for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
					{
						TestMove.MoveID = j;

						int32_t result = TestMove.Make_Player2Move_If_Possible_AvoidRepetitiveStates(pActualGameState, &GameStatePool, searchDepth, true);

						if (result == -1)
						{
							Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
							goto GameTreeCreationFinished;
						}

						if(result > 0)
							movementCounter++;

						if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
						{
							Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
							goto TooManyTestGameStates2;
							//break;
						}
					} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

			TooManyTestGameStates2:;

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

			Add_To_Log(0, "searchDepth", searchDepth + 1);
			Add_To_Log(0, "...movementCounter", movementCounter);
		}

	} // end of for (int32_t searchDepth = 0; searchDepth < MaxSearchDepthPlus1; searchDepth++)

GameTreeCreationFinished:;

	Player1ViewLeafGameStatesEvalFunc(&GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
	Backpropagate_MinimaxIntegerEvaluationValues(&GameStatePool);

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID);
	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

	Add_To_Log(0, "g_NumOfMultipleVisitedGameStates", g_NumOfMultipleVisitedGameStates);

	for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	{
		int32_t id = pMoveDescValuesArray[i].IDofResultingGameState;

		if (id > 0)
		{
			pMoveDescValuesArray[i].EstimatedEvaluation = GameStatePool.pGameStateArray[id].iEvaluation;
		}
	}
}

void CBreadthFirstSearchAI::Execute_Player2AI(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState)
{
	GameStatePool.Stop_Using_AllGameStateObjects();


	for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	{
		TestMove.BoardPosID = pMoveDescValuesArray[i].BoardPosID;
		TestMove.MoveID = pMoveDescValuesArray[i].MoveID;
		pMoveDescValuesArray[i].EstimatedEvaluation = ConstMinEvaluationScore_Minimax;
		pMoveDescValuesArray[i].IDofResultingGameState = 0;

		int32_t result = TestMove.Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, 0, false);

		if (result == -1)
		{
			Add_To_Log(0, "game tree too large, searchDepth 1");
			goto GameTreeCreationFinished;
		}
		else if (result == 1)
		{
			pMoveDescValuesArray[i].IDofResultingGameState = GameStatePool.IDofLastReturnedGameStateObject;
		}
	}

	/*
	int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

	for (int32_t i = 0; i < GameBoardSizeXY; i++)
	{
		TestMove.BoardPosID = i;

		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			TestMove.MoveID = j;
		
			if (TestMove.Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, 0, false) == -1)
			{
				Add_To_Log(0, "game tree too large, searchDepth 1");
				goto GameTreeCreationFinished;
			}
		} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
	} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	*/

	for (int32_t searchDepth = 1; searchDepth < MaxSearchDepth; searchDepth++)
	{
		int32_t playerID = (1 + searchDepth) % 2;

		int32_t movementCounter = 0;

		if (playerID == 0)
		{
			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			//Add_To_Log(0, "NumUsedListElements", NumObjectsUsed);

			int32_t id = 0;


			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					TestMove.BoardPosID = i;

					for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
					{
						TestMove.MoveID = j;

						int32_t result = TestMove.Make_Player1Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, true);

						if(result == -1)
						//if (TestMove.Make_Player1Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, true) == -1)
						{
							Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
							goto GameTreeCreationFinished;
						}

						if (result == 1)
						movementCounter++;

						if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
						{
							Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
							goto TooManyTestGameStates1;
							//break;
						}
					} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

			TooManyTestGameStates1:;

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)
		}
		else // if (playerID == 1)
		{
			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			//Add_To_Log(0, "NumUsedListElements", NumObjectsUsed);
			int32_t id = 0;
			

			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					TestMove.BoardPosID = i;

					for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
					{
						TestMove.MoveID = j;

						int32_t result = TestMove.Make_Player2Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, false);
						if (result == -1)
						//if (TestMove.Make_Player2Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, false) == -1)
						{
							Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
							goto GameTreeCreationFinished;
						}

						if (result == 1)
						movementCounter++;

						if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
						{
							Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
							goto TooManyTestGameStates2;
							//break;
						}
					} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

			TooManyTestGameStates2:;

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)
		}

	} // end of for (int32_t searchDepth = 0; searchDepth < MaxSearchDepthPlus1; searchDepth++)

GameTreeCreationFinished:;

	Player2ViewLeafGameStatesEvalFunc(&GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
	

	Backpropagate_MinimaxIntegerEvaluationValues(&GameStatePool);
	//Add_To_Log(0, "Backpropagate_MinimaxIntegerEvaluationValues() ok");

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID);

	//if(pGameStateObject == nullptr)
		//Add_To_Log(0, "pGameStateObject == nullptr");

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

	for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	{
		int32_t id = pMoveDescValuesArray[i].IDofResultingGameState;

		if (id > 0)
		{
			pMoveDescValuesArray[i].EstimatedEvaluation = GameStatePool.pGameStateArray[id].iEvaluation;
		}
	}
}

void CBreadthFirstSearchAI::Execute_Player2AI_DiscardInsufficientStates(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, int32_t minTolerableEvalValuePlayer1, int32_t minTolerableEvalValuePlayer2)
{
	g_NumOfGameStatesWithTooLowEvalValues = 0;
	
	TestMove.MinTolerableEvaluationValue_Player1 = minTolerableEvalValuePlayer1;
	TestMove.MinTolerableEvaluationValue_Player2 = minTolerableEvalValuePlayer2;

	GameStatePool.Stop_Using_AllGameStateObjects();

	for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	{
		TestMove.BoardPosID = pMoveDescValuesArray[i].BoardPosID;
		TestMove.MoveID = pMoveDescValuesArray[i].MoveID;
		pMoveDescValuesArray[i].EstimatedEvaluation = ConstMinEvaluationScore_Minimax;
		pMoveDescValuesArray[i].IDofResultingGameState = 0;

		int32_t result = TestMove.Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, 0, false);

		if (result == -1)
		{
			Add_To_Log(0, "game tree too large, searchDepth 1");
			goto GameTreeCreationFinished;
		}
		else if (result == 1)
		{
			pMoveDescValuesArray[i].IDofResultingGameState = GameStatePool.IDofLastReturnedGameStateObject;
		}
	}

	/*int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

	for (int32_t i = 0; i < GameBoardSizeXY; i++)
	{
		TestMove.BoardPosID = i;

		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			TestMove.MoveID = j;

			if (TestMove.Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, 0, false) == -1)
			{
				Add_To_Log(0, "game tree too large, searchDepth 1");
				goto GameTreeCreationFinished;
			}
		} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
	} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	*/

	for (int32_t searchDepth = 1; searchDepth < MaxSearchDepth; searchDepth++)
	{
		int32_t playerID = (1 + searchDepth) % 2;

		int32_t movementCounter = 0;

		if (playerID == 0)
		{
			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			//Add_To_Log(0, "NumUsedListElements", NumObjectsUsed);

			int32_t id = 0;


			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					TestMove.BoardPosID = i;

					for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
					{
						TestMove.MoveID = j;

						//if (TestMove.Make_Player1Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, true) == -1)
						//int32_t result = TestMove.Make_Player1Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, false);
						int32_t result = TestMove.Make_Player1Move_If_Possible_DiscardInsufficientStates(pActualGameState, &GameStatePool, searchDepth, true);

						if (result == -1)
						{
							Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
							goto GameTreeCreationFinished;
						}

						if (result > 0)
						movementCounter++;

						if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
						{
							Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
							goto TooManyTestGameStates1;
							//break;
						}
					} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

			TooManyTestGameStates1:;

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)
		}
		else // if (playerID == 1)
		{
			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			//Add_To_Log(0, "NumUsedListElements", NumObjectsUsed);
			int32_t id = 0;


			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					TestMove.BoardPosID = i;

					for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
					{
						TestMove.MoveID = j;

						int32_t result = TestMove.Make_Player2Move_If_Possible_DiscardInsufficientStates(pActualGameState, &GameStatePool, searchDepth, false);

						if (result == -1)
						{
							Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
							goto GameTreeCreationFinished;
						}


						if(result > 0)
							movementCounter++;

						if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
						{
							Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
							goto TooManyTestGameStates2;
							//break;
						}
					} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

			TooManyTestGameStates2:;

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)
		}

	} // end of for (int32_t searchDepth = 0; searchDepth < MaxSearchDepthPlus1; searchDepth++)

GameTreeCreationFinished:;

	Player2ViewLeafGameStatesEvalFunc(&GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);


	Backpropagate_MinimaxIntegerEvaluationValues(&GameStatePool);
	//Add_To_Log(0, "Backpropagate_MinimaxIntegerEvaluationValues() ok");

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID);

	//if(pGameStateObject == nullptr)
		//Add_To_Log(0, "pGameStateObject == nullptr");

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

	Add_To_Log(0, "g_NumOfGameStatesWithTooLowEvalValues", g_NumOfGameStatesWithTooLowEvalValues);

	for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	{
		int32_t id = pMoveDescValuesArray[i].IDofResultingGameState;

		if (id > 0)
		{
			pMoveDescValuesArray[i].EstimatedEvaluation = GameStatePool.pGameStateArray[id].iEvaluation;
		}
	}
}

void CBreadthFirstSearchAI::Execute_Player2AI_AvoidRepetitiveStates(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState)
{
	g_NumOfMultipleVisitedGameStates = 0;

	GameStatePool.Stop_Using_AllGameStateObjects();

	for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	{
		TestMove.BoardPosID = pMoveDescValuesArray[i].BoardPosID;
		TestMove.MoveID = pMoveDescValuesArray[i].MoveID;
		pMoveDescValuesArray[i].EstimatedEvaluation = ConstMinEvaluationScore_Minimax;
		pMoveDescValuesArray[i].IDofResultingGameState = 0;

		int32_t result = TestMove.Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, 0, false);

		if (result == -1)
		{
			Add_To_Log(0, "game tree too large, searchDepth 1");
			goto GameTreeCreationFinished;
		}
		else if (result == 1)
		{
			pMoveDescValuesArray[i].IDofResultingGameState = GameStatePool.IDofLastReturnedGameStateObject;
		}
	}

	/*int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

	for (int32_t i = 0; i < GameBoardSizeXY; i++)
	{
		TestMove.BoardPosID = i;

		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			TestMove.MoveID = j;

			if (TestMove.Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, 0, false) == -1)
			{
				Add_To_Log(0, "game tree too large, searchDepth 1");
				goto GameTreeCreationFinished;
			}
		} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
	} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	*/

	for (int32_t searchDepth = 1; searchDepth < MaxSearchDepth; searchDepth++)
	{
		int32_t playerID = (1 + searchDepth) % 2;

		int32_t movementCounter = 0;

		if (playerID == 0)
		{
			Add_To_Log(0, "counter move");

			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			//Add_To_Log(0, "NumUsedListElements", NumObjectsUsed);

			int32_t id = 0;


			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					TestMove.BoardPosID = i;

					for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
					{
						TestMove.MoveID = j;

						int32_t result = TestMove.Make_Player1Move_If_Possible_AvoidRepetitiveStates(pActualGameState, &GameStatePool, searchDepth, true);

						if (result == -1)
						{
							Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
							goto GameTreeCreationFinished;
						}

						if(result > 0)
							movementCounter++;

						if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
						{
							Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
							goto TooManyTestGameStates1;
							//break;
						}
					} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

			TooManyTestGameStates1:;

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

			Add_To_Log(0, "searchDepth", searchDepth + 1);
			Add_To_Log(0, "...movementCounter", movementCounter);
		}
		else // if (playerID == 1)
		{
			Add_To_Log(0, "move");

			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			//Add_To_Log(0, "NumUsedListElements", NumObjectsUsed);
			int32_t id = 0;

			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					TestMove.BoardPosID = i;

					for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
					{
						TestMove.MoveID = j;

						int32_t result = TestMove.Make_Player2Move_If_Possible_AvoidRepetitiveStates(pActualGameState, &GameStatePool, searchDepth, false);
						
						if (result == -1)
						{
							Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
							goto GameTreeCreationFinished;
						}

						if (result > 0)
							movementCounter++;

						if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
						{
							Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
							goto TooManyTestGameStates2;
							//break;
						}
					} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

			TooManyTestGameStates2:;

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

			Add_To_Log(0, "searchDepth", searchDepth + 1);
			Add_To_Log(0, "...movementCounter", movementCounter);
		}
	} // end of for (int32_t searchDepth = 0; searchDepth < MaxSearchDepthPlus1; searchDepth++)

GameTreeCreationFinished:;

	Player2ViewLeafGameStatesEvalFunc(&GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);


	Backpropagate_MinimaxIntegerEvaluationValues(&GameStatePool);
	//Add_To_Log(0, "Backpropagate_MinimaxIntegerEvaluationValues() ok");

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID);

	//if(pGameStateObject == nullptr)
		//Add_To_Log(0, "pGameStateObject == nullptr");

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

	Add_To_Log(0, "g_NumOfMultipleVisitedGameStates", g_NumOfMultipleVisitedGameStates);

	for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	{
		int32_t id = pMoveDescValuesArray[i].IDofResultingGameState;

		if (id > 0)
		{
			pMoveDescValuesArray[i].EstimatedEvaluation = GameStatePool.pGameStateArray[id].iEvaluation;
		}
	}
}

void CBreadthFirstSearchAI::Execute_Player1AI(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, float* pSearchDepthMovementProbabilityArray)
{
	GameStatePool.Stop_Using_AllGameStateObjects();

	for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	{
		TestMove.BoardPosID = pMoveDescValuesArray[i].BoardPosID;
		TestMove.MoveID = pMoveDescValuesArray[i].MoveID;
		pMoveDescValuesArray[i].EstimatedEvaluation = ConstMinEvaluationScore_Minimax;
		pMoveDescValuesArray[i].IDofResultingGameState = 0;

		int32_t result = TestMove.Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, 0, false);

		if (result == -1)
		{
			Add_To_Log(0, "game tree too large, searchDepth 1");
			goto GameTreeCreationFinished;
		}
		else if (result == 1)
		{
			pMoveDescValuesArray[i].IDofResultingGameState = GameStatePool.IDofLastReturnedGameStateObject;
		}
	}

	/*int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

	for (int32_t i = 0; i < GameBoardSizeXY; i++)
	{
		TestMove.BoardPosID = i;

		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			TestMove.MoveID = j;

			if (TestMove.Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, 0, false) == -1)
			{
				Add_To_Log(0, "game tree too large, searchDepth 1");
				goto GameTreeCreationFinished;
			}
		} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
	} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	*/

	for (int32_t searchDepth = 1; searchDepth < MaxSearchDepth; searchDepth++)
	{
		int32_t playerID = searchDepth % 2;

		int32_t movementCounter = 0;

		if (playerID == 0)
		{
			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			int32_t id = 0;
			int32_t movementCounter = 0;

			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				if (RandomNumbers.Get_FloatNumber_IncludingZero(0.0f, 1.0) > pSearchDepthMovementProbabilityArray[searchDepth])
				{
					continue;
				}

				int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					TestMove.BoardPosID = i;

					for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
					{
						TestMove.MoveID = j;

						int32_t result = TestMove.Make_Player1Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, false);
						if(result == -1)
						//if (TestMove.Make_Player1Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, false) == -1)
						{
							Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
							goto GameTreeCreationFinished;
						}

						if (result == 1)
						movementCounter++;

						if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
						{
							Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
							goto TooManyTestGameStates1;
							//break;
						}
					} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

			TooManyTestGameStates1:;

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)
		}
		else // if (playerID == 1)
		{
			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			int32_t id = 0;


			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				if (RandomNumbers.Get_FloatNumber_IncludingZero(0.0f, 1.0) > pSearchDepthMovementProbabilityArray[searchDepth])
				{
					continue;
				}

				int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					TestMove.BoardPosID = i;

					for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
					{
						TestMove.MoveID = j;

						int32_t result = TestMove.Make_Player2Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, true);
						if(result == -1)
						//if (TestMove.Make_Player2Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, true) == -1)
						{
							Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
							goto GameTreeCreationFinished;
						}

						if (result == 1)
						movementCounter++;

						if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
						{
							Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
							goto TooManyTestGameStates2;
							//break;
						}
					} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

			TooManyTestGameStates2:;

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)
		}

	} // end of for (int32_t searchDepth = 0; searchDepth < MaxSearchDepthPlus1; searchDepth++)

GameTreeCreationFinished:;

	Player1ViewLeafGameStatesEvalFunc(&GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
	Backpropagate_MinimaxIntegerEvaluationValues(&GameStatePool);

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID);
	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

	for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	{
		int32_t id = pMoveDescValuesArray[i].IDofResultingGameState;

		if (id > 0)
		{
			pMoveDescValuesArray[i].EstimatedEvaluation = GameStatePool.pGameStateArray[id].iEvaluation;
		}
	}
}

void CBreadthFirstSearchAI::Execute_Player1AI_DiscardInsufficientStates(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, float* pSearchDepthMovementProbabilityArray, int32_t minTolerableEvalValuePlayer1, int32_t minTolerableEvalValuePlayer2)
{
	g_NumOfGameStatesWithTooLowEvalValues = 0;

	TestMove.MinTolerableEvaluationValue_Player1 = minTolerableEvalValuePlayer1;
	TestMove.MinTolerableEvaluationValue_Player2 = minTolerableEvalValuePlayer2;

	GameStatePool.Stop_Using_AllGameStateObjects();

	for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	{
		TestMove.BoardPosID = pMoveDescValuesArray[i].BoardPosID;
		TestMove.MoveID = pMoveDescValuesArray[i].MoveID;
		pMoveDescValuesArray[i].EstimatedEvaluation = ConstMinEvaluationScore_Minimax;
		pMoveDescValuesArray[i].IDofResultingGameState = 0;

		int32_t result = TestMove.Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, 0, false);

		if (result == -1)
		{
			Add_To_Log(0, "game tree too large, searchDepth 1");
			goto GameTreeCreationFinished;
		}
		else if (result == 1)
		{
			pMoveDescValuesArray[i].IDofResultingGameState = GameStatePool.IDofLastReturnedGameStateObject;
		}
	}

	/*int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

	for (int32_t i = 0; i < GameBoardSizeXY; i++)
	{
		TestMove.BoardPosID = i;

		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			TestMove.MoveID = j;

			if (TestMove.Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, 0, false) == -1)
			{
				Add_To_Log(0, "game tree too large, searchDepth 1");
				goto GameTreeCreationFinished;
			}
		} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
	} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	*/


	for (int32_t searchDepth = 1; searchDepth < MaxSearchDepth; searchDepth++)
	{
		int32_t playerID = searchDepth % 2;

		int32_t movementCounter = 0;

		if (playerID == 0)
		{
			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			int32_t id = 0;
			int32_t movementCounter = 0;

			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				if (RandomNumbers.Get_FloatNumber_IncludingZero(0.0f, 1.0) > pSearchDepthMovementProbabilityArray[searchDepth])
				{
					continue;
				}

				int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					TestMove.BoardPosID = i;

					for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
					{
						TestMove.MoveID = j;

						int32_t result = TestMove.Make_Player1Move_If_Possible_DiscardInsufficientStates(pActualGameState, &GameStatePool, searchDepth, false);

						if (result == -1)
						{
							Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
							goto GameTreeCreationFinished;
						}

						if (result > 0)
							movementCounter++;

						if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
						{
							Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
							goto TooManyTestGameStates1;
							//break;
						}
					} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

			TooManyTestGameStates1:;

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)
		}
		else // if (playerID == 1)
		{
			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			int32_t id = 0;


			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				if (RandomNumbers.Get_FloatNumber_IncludingZero(0.0f, 1.0) > pSearchDepthMovementProbabilityArray[searchDepth])
				{
					continue;
				}

				int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					TestMove.BoardPosID = i;

					for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
					{
						TestMove.MoveID = j;

						int32_t result = TestMove.Make_Player2Move_If_Possible_DiscardInsufficientStates(pActualGameState, &GameStatePool, searchDepth, true);

						//if (TestMove.Make_Player2Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, true) == -1)
						if (result == -1)
						{
							Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
							goto GameTreeCreationFinished;
						}

						if (result > 0)
							movementCounter++;

						if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
						{
							Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
							goto TooManyTestGameStates2;
							//break;
						}
					} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

			TooManyTestGameStates2:;

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)
		}

	} // end of for (int32_t searchDepth = 0; searchDepth < MaxSearchDepthPlus1; searchDepth++)

GameTreeCreationFinished:;

	Player1ViewLeafGameStatesEvalFunc(&GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
	Backpropagate_MinimaxIntegerEvaluationValues(&GameStatePool);

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID);
	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

	Add_To_Log(0, "g_NumOfGameStatesWithTooLowEvalValues", g_NumOfGameStatesWithTooLowEvalValues);

	for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	{
		int32_t id = pMoveDescValuesArray[i].IDofResultingGameState;

		if (id > 0)
		{
			pMoveDescValuesArray[i].EstimatedEvaluation = GameStatePool.pGameStateArray[id].iEvaluation;
		}
	}
}

void CBreadthFirstSearchAI::Execute_Player1AI_AvoidRepetitiveStates(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, float* pSearchDepthMovementProbabilityArray)
{
	g_NumOfMultipleVisitedGameStates = 0;

	GameStatePool.Stop_Using_AllGameStateObjects();

	for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	{
		TestMove.BoardPosID = pMoveDescValuesArray[i].BoardPosID;
		TestMove.MoveID = pMoveDescValuesArray[i].MoveID;
		pMoveDescValuesArray[i].EstimatedEvaluation = ConstMinEvaluationScore_Minimax;
		pMoveDescValuesArray[i].IDofResultingGameState = 0;

		int32_t result = TestMove.Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, 0, false);
		if (result == -1)
		{
			Add_To_Log(0, "game tree too large, searchDepth 1");
			goto GameTreeCreationFinished;
		}
		else if (result == 1)
		{
			pMoveDescValuesArray[i].IDofResultingGameState = GameStatePool.IDofLastReturnedGameStateObject;
		}
	}

	/*int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

	for (int32_t i = 0; i < GameBoardSizeXY; i++)
	{
		TestMove.BoardPosID = i;

		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			TestMove.MoveID = j;

			if (TestMove.Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, 0, false) == -1)
			{
				Add_To_Log(0, "game tree too large, searchDepth 1");
				goto GameTreeCreationFinished;
			}
		} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
	} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	*/

	for (int32_t searchDepth = 1; searchDepth < MaxSearchDepth; searchDepth++)
	{
		int32_t playerID = searchDepth % 2;

		int32_t movementCounter = 0;

		if (playerID == 0)
		{
			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			int32_t id = 0;
			
			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				if (RandomNumbers.Get_FloatNumber_IncludingZero(0.0f, 1.0) > pSearchDepthMovementProbabilityArray[searchDepth])
				{
					continue;
				}

				int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					TestMove.BoardPosID = i;

					for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
					{
						TestMove.MoveID = j;

						int32_t result = TestMove.Make_Player1Move_If_Possible_AvoidRepetitiveStates(pActualGameState, &GameStatePool, searchDepth, false);

						if (result == -1)
						{
							Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
							goto GameTreeCreationFinished;
						}

						if (result > 0)
							movementCounter++;

						if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
						{
							Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
							goto TooManyTestGameStates1;
							//break;
						}
					} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

			TooManyTestGameStates1:;

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

			Add_To_Log(0, "searchDepth", searchDepth + 1);
			Add_To_Log(0, "...movementCounter", movementCounter);
		}
		else // if (playerID == 1)
		{
			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			int32_t id = 0;


			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				if (RandomNumbers.Get_FloatNumber_IncludingZero(0.0f, 1.0) > pSearchDepthMovementProbabilityArray[searchDepth])
				{
					continue;
				}

				int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					TestMove.BoardPosID = i;

					for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
					{
						TestMove.MoveID = j;

						int32_t result = TestMove.Make_Player2Move_If_Possible_AvoidRepetitiveStates(pActualGameState, &GameStatePool, searchDepth, true);

						if (result == -1)
						{
							Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
							goto GameTreeCreationFinished;
						}

						if (result > 0)
							movementCounter++;

						if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
						{
							Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
							goto TooManyTestGameStates2;
							//break;
						}
					} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

			TooManyTestGameStates2:;

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

			Add_To_Log(0, "searchDepth", searchDepth + 1);
			Add_To_Log(0, "...movementCounter", movementCounter);
		}

	} // end of for (int32_t searchDepth = 0; searchDepth < MaxSearchDepthPlus1; searchDepth++)

GameTreeCreationFinished:;

	Player1ViewLeafGameStatesEvalFunc(&GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
	Backpropagate_MinimaxIntegerEvaluationValues(&GameStatePool);

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID);
	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

	Add_To_Log(0, "g_NumOfMultipleVisitedGameStates", g_NumOfMultipleVisitedGameStates);

	for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	{
		int32_t id = pMoveDescValuesArray[i].IDofResultingGameState;

		if (id > 0)
		{
			pMoveDescValuesArray[i].EstimatedEvaluation = GameStatePool.pGameStateArray[id].iEvaluation;
		}
	}
}

void CBreadthFirstSearchAI::Execute_Player2AI(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, float* pSearchDepthMovementProbabilityArray)
{
	GameStatePool.Stop_Using_AllGameStateObjects();

	for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	{
		TestMove.BoardPosID = pMoveDescValuesArray[i].BoardPosID;
		TestMove.MoveID = pMoveDescValuesArray[i].MoveID;
		pMoveDescValuesArray[i].EstimatedEvaluation = ConstMinEvaluationScore_Minimax;
		pMoveDescValuesArray[i].IDofResultingGameState = 0;

		int32_t result = TestMove.Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, 0, false);

		if (result == -1)
		{
			Add_To_Log(0, "game tree too large, searchDepth 1");
			goto GameTreeCreationFinished;
		}
		else if (result == 1)
		{
			pMoveDescValuesArray[i].IDofResultingGameState = GameStatePool.IDofLastReturnedGameStateObject;
		}
	}

	/*int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

	for (int32_t i = 0; i < GameBoardSizeXY; i++)
	{
		TestMove.BoardPosID = i;

		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			TestMove.MoveID = j;

			if (TestMove.Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, 0, false) == -1)
			{
				Add_To_Log(0, "game tree too large, searchDepth 1");
				goto GameTreeCreationFinished;
			}
		} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
	} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	*/

	for (int32_t searchDepth = 1; searchDepth < MaxSearchDepth; searchDepth++)
	{
		int32_t playerID = (1 + searchDepth) % 2;

		int32_t movementCounter = 0;

		if (playerID == 0)
		{
			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			//Add_To_Log(0, "NumUsedListElements", NumObjectsUsed);

			int32_t id = 0;


			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				if (RandomNumbers.Get_FloatNumber_IncludingZero(0.0f, 1.0) > pSearchDepthMovementProbabilityArray[searchDepth])
				{
					continue;
				}

				int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					TestMove.BoardPosID = i;

					for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
					{
						TestMove.MoveID = j;

						int32_t result = TestMove.Make_Player1Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, true);
						if(result == -1)
						//if (TestMove.Make_Player1Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, true) == -1)
						{
							Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
							goto GameTreeCreationFinished;
						}

						if (result == 1)
						movementCounter++;

						if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
						{
							Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
							goto TooManyTestGameStates1;
							//break;
						}
					} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)

					/*if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					{
						//Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
						break;
					}*/
				} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

			TooManyTestGameStates1:;

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)
		}
		else // if (playerID == 1)
		{
			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			//Add_To_Log(0, "NumUsedListElements", NumObjectsUsed);
			int32_t id = 0;
			

			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				if (RandomNumbers.Get_FloatNumber_IncludingZero(0.0f, 1.0) > pSearchDepthMovementProbabilityArray[searchDepth])
				{
					continue;
				}

				int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					TestMove.BoardPosID = i;

					for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
					{
						TestMove.MoveID = j;

						int32_t result = TestMove.Make_Player2Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, false);
						if(result == -1)
						//if (TestMove.Make_Player2Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, false) == -1)
						{
							Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
							goto GameTreeCreationFinished;
						}

						if (result == 1)
						movementCounter++;

						if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
						{
							Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
							goto TooManyTestGameStates2;
							//break;
						}
					} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)

					/*if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					{
						//Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
						break;
					}*/
				} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

			TooManyTestGameStates2:;

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)
		}

	} // end of for (int32_t searchDepth = 0; searchDepth < MaxSearchDepthPlus1; searchDepth++)

GameTreeCreationFinished:;

	Player2ViewLeafGameStatesEvalFunc(&GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
	

	Backpropagate_MinimaxIntegerEvaluationValues(&GameStatePool);
	//Add_To_Log(0, "Backpropagate_MinimaxIntegerEvaluationValues() ok");

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID);

	//if(pGameStateObject == nullptr)
		//Add_To_Log(0, "pGameStateObject == nullptr");

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

	for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	{
		int32_t id = pMoveDescValuesArray[i].IDofResultingGameState;

		if (id > 0)
		{
			pMoveDescValuesArray[i].EstimatedEvaluation = GameStatePool.pGameStateArray[id].iEvaluation;
		}
	}
}

void CBreadthFirstSearchAI::Execute_Player2AI_DiscardInsufficientStates(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, float* pSearchDepthMovementProbabilityArray, int32_t minTolerableEvalValuePlayer1, int32_t minTolerableEvalValuePlayer2)
{
	g_NumOfGameStatesWithTooLowEvalValues = 0;

	TestMove.MinTolerableEvaluationValue_Player1 = minTolerableEvalValuePlayer1;
	TestMove.MinTolerableEvaluationValue_Player2 = minTolerableEvalValuePlayer2;

	GameStatePool.Stop_Using_AllGameStateObjects();

	for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	{
		TestMove.BoardPosID = pMoveDescValuesArray[i].BoardPosID;
		TestMove.MoveID = pMoveDescValuesArray[i].MoveID;
		pMoveDescValuesArray[i].EstimatedEvaluation = ConstMinEvaluationScore_Minimax;
		pMoveDescValuesArray[i].IDofResultingGameState = 0;

		int32_t result = TestMove.Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, 0, false);
		if (result == -1)
		{
			Add_To_Log(0, "game tree too large, searchDepth 1");
			goto GameTreeCreationFinished;
		}
		else if (result == 1)
		{
			pMoveDescValuesArray[i].IDofResultingGameState = GameStatePool.IDofLastReturnedGameStateObject;
		}
	}

	/*int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

	for (int32_t i = 0; i < GameBoardSizeXY; i++)
	{
		TestMove.BoardPosID = i;

		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			TestMove.MoveID = j;

			if (TestMove.Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, 0, false) == -1)
			{
				Add_To_Log(0, "game tree too large, searchDepth 1");
				goto GameTreeCreationFinished;
			}
		} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
	} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	*/

	for (int32_t searchDepth = 1; searchDepth < MaxSearchDepth; searchDepth++)
	{
		int32_t playerID = (1 + searchDepth) % 2;

		int32_t movementCounter = 0;

		if (playerID == 0)
		{
			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			//Add_To_Log(0, "NumUsedListElements", NumObjectsUsed);

			int32_t id = 0;


			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				if (RandomNumbers.Get_FloatNumber_IncludingZero(0.0f, 1.0) > pSearchDepthMovementProbabilityArray[searchDepth])
				{
					continue;
				}

				int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					TestMove.BoardPosID = i;

					for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
					{
						TestMove.MoveID = j;

						int32_t result = TestMove.Make_Player1Move_If_Possible_DiscardInsufficientStates(pActualGameState, &GameStatePool, searchDepth, true);
						//if (TestMove.Make_Player1Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, true) == -1)
						if (result == -1)
						{
							Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
							goto GameTreeCreationFinished;
						}

						if (result > 0)
							movementCounter++;

						if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
						{
							Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
							goto TooManyTestGameStates1;
							//break;
						}
					} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)

					/*if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					{
						//Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
						break;
					}*/
				} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

			TooManyTestGameStates1:;

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)
		}
		else // if (playerID == 1)
		{
			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			//Add_To_Log(0, "NumUsedListElements", NumObjectsUsed);
			int32_t id = 0;


			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				if (RandomNumbers.Get_FloatNumber_IncludingZero(0.0f, 1.0) > pSearchDepthMovementProbabilityArray[searchDepth])
				{
					continue;
				}

				int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					TestMove.BoardPosID = i;

					for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
					{
						TestMove.MoveID = j;

						int32_t result = TestMove.Make_Player2Move_If_Possible_DiscardInsufficientStates(pActualGameState, &GameStatePool, searchDepth, false);
						if (result == -1)
						//if(TestMove.Make_Player2Move_If_Possible(pActualGameState, &GameStatePool, searchDepth, false) == -1)
						{
							Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
							goto GameTreeCreationFinished;
						}

						if (result > 0)
							movementCounter++;

						if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
						{
							Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
							goto TooManyTestGameStates2;
							//break;
						}
					} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)

					/*if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					{
						//Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
						break;
					}*/
				} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

			TooManyTestGameStates2:;

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)
		} // end of else if (playerID == 1)
	} // end of for (int32_t searchDepth = 0; searchDepth < MaxSearchDepthPlus1; searchDepth++)

GameTreeCreationFinished:;

	Player2ViewLeafGameStatesEvalFunc(&GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);


	Backpropagate_MinimaxIntegerEvaluationValues(&GameStatePool);
	//Add_To_Log(0, "Backpropagate_MinimaxIntegerEvaluationValues() ok");

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID);

	//if(pGameStateObject == nullptr)
		//Add_To_Log(0, "pGameStateObject == nullptr");

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

	Add_To_Log(0, "g_NumOfGameStatesWithTooLowEvalValues", g_NumOfGameStatesWithTooLowEvalValues);

	for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	{
		int32_t id = pMoveDescValuesArray[i].IDofResultingGameState;

		if (id > 0)
		{
			pMoveDescValuesArray[i].EstimatedEvaluation = GameStatePool.pGameStateArray[id].iEvaluation;
		}
	}
}

void CBreadthFirstSearchAI::Execute_Player2AI_AvoidRepetitiveStates(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, float* pSearchDepthMovementProbabilityArray)
{
	g_NumOfMultipleVisitedGameStates = 0;

	GameStatePool.Stop_Using_AllGameStateObjects();

	for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	{
		TestMove.BoardPosID = pMoveDescValuesArray[i].BoardPosID;
		TestMove.MoveID = pMoveDescValuesArray[i].MoveID;
		pMoveDescValuesArray[i].EstimatedEvaluation = ConstMinEvaluationScore_Minimax;
		pMoveDescValuesArray[i].IDofResultingGameState = 0;

		int32_t result = TestMove.Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, 0, false);

		if (result == -1)
		{
			Add_To_Log(0, "game tree too large, searchDepth 1");
			goto GameTreeCreationFinished;
		}
		else if (result == 1)
		{
			pMoveDescValuesArray[i].IDofResultingGameState = GameStatePool.IDofLastReturnedGameStateObject;
		}
	}

	/*int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

	for (int32_t i = 0; i < GameBoardSizeXY; i++)
	{
		TestMove.BoardPosID = i;

		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			TestMove.MoveID = j;

			if (TestMove.Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, 0, false) == -1)
			{
				Add_To_Log(0, "game tree too large, searchDepth 1");
				goto GameTreeCreationFinished;
			}
		} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
	} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	*/

	for (int32_t searchDepth = 1; searchDepth < MaxSearchDepth; searchDepth++)
	{
		int32_t playerID = (1 + searchDepth) % 2;

		int32_t movementCounter = 0;

		if (playerID == 0)
		{
			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			//Add_To_Log(0, "NumUsedListElements", NumObjectsUsed);

			int32_t id = 0;


			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				if (RandomNumbers.Get_FloatNumber_IncludingZero(0.0f, 1.0) > pSearchDepthMovementProbabilityArray[searchDepth])
				{
					continue;
				}

				int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					TestMove.BoardPosID = i;

					for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
					{
						TestMove.MoveID = j;

						int32_t result = TestMove.Make_Player1Move_If_Possible_AvoidRepetitiveStates(pActualGameState, &GameStatePool, searchDepth, true);

						if (result == -1)
						{
							Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
							goto GameTreeCreationFinished;
						}

						if (result > 0)
							movementCounter++;

						if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
						{
							Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
							goto TooManyTestGameStates1;
							//break;
						}
					} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)

					/*if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					{
						//Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
						break;
					}*/
				} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

			TooManyTestGameStates1:;

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

			Add_To_Log(0, "searchDepth", searchDepth + 1);
			Add_To_Log(0, "...movementCounter", movementCounter);
		}
		else // if (playerID == 1)
		{
			CGameStateValues* pActualGameState = nullptr;
			CSimpleLinkedListManager* pSimpleLinkedListManager = &GameStatePool.pSimpleLinkedListManagerArray[searchDepth - 1];
			int32_t NumObjectsUsed = pSimpleLinkedListManager->NumUsedListElements;
			//Add_To_Log(0, "NumUsedListElements", NumObjectsUsed);
			int32_t id = 0;
			

			for (int32_t j = 0; j < NumObjectsUsed; j++)
			{
				id = pSimpleLinkedListManager->Get_Next_Used_ListElement(id);
				pActualGameState = &GameStatePool.pGameStateArray[id];

				if (RandomNumbers.Get_FloatNumber_IncludingZero(0.0f, 1.0) > pSearchDepthMovementProbabilityArray[searchDepth])
				{
					continue;
				}

				int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					TestMove.BoardPosID = i;

					for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
					{
						TestMove.MoveID = j;

						int32_t result = TestMove.Make_Player2Move_If_Possible_AvoidRepetitiveStates(pActualGameState, &GameStatePool, searchDepth, false);

						if (result == -1)
						{
							Add_To_Log(0, "game tree too large, searchDepth", searchDepth + 1);
							goto GameTreeCreationFinished;
						}

						if (result > 0)
							movementCounter++;

						if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
						{
							Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
							goto TooManyTestGameStates2;
							//break;
						}
					} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)

					/*if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					{
						//Add_To_Log(0, "movementCounter >= NumTestGameStatesMaxPerDepthLayer, searchDepth", searchDepth + 1);
						break;
					}*/
				} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

			TooManyTestGameStates2:;

				if (movementCounter >= NumTestGameStatesMaxPerDepthLayer)
					break;

			} // end of for (int32_t j = 0; j < NumObjectsUsed; j++)

			Add_To_Log(0, "searchDepth", searchDepth + 1);
			Add_To_Log(0, "...movementCounter", movementCounter);
		}
	} // end of for (int32_t searchDepth = 0; searchDepth < MaxSearchDepthPlus1; searchDepth++)

GameTreeCreationFinished:;

	Player2ViewLeafGameStatesEvalFunc(&GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);


	Backpropagate_MinimaxIntegerEvaluationValues(&GameStatePool);
	//Add_To_Log(0, "Backpropagate_MinimaxIntegerEvaluationValues() ok");

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID);

	//if(pGameStateObject == nullptr)
		//Add_To_Log(0, "pGameStateObject == nullptr");

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

	Add_To_Log(0, "g_NumOfMultipleVisitedGameStates", g_NumOfMultipleVisitedGameStates);

	for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	{
		int32_t id = pMoveDescValuesArray[i].IDofResultingGameState;

		if (id > 0)
		{
			pMoveDescValuesArray[i].EstimatedEvaluation = GameStatePool.pGameStateArray[id].iEvaluation;
		}
	}
}








CDepthFirstSearchAI::CDepthFirstSearchAI()
{}

CDepthFirstSearchAI::~CDepthFirstSearchAI()
{
	delete[] pTestMoveArray;
	pTestMoveArray = nullptr;

	delete[] pMoveDescValuesArray;
	pMoveDescValuesArray = nullptr;
}

void CDepthFirstSearchAI::Change_Seed(uint64_t seed)
{
	RandomNumbers.Change_Seed(seed);
}




void CDepthFirstSearchAI::Improve_MoveOrder(int32_t numOfSortingStepsMax)
{
	int32_t numOfMoveDescriptionsMinus1 = NumOfMoveDescriptions - 1;

	numOfSortingStepsMax = min(numOfSortingStepsMax, numOfMoveDescriptionsMinus1);

	for (int32_t i = 0; i < numOfSortingStepsMax; i++)
	{
		bool swappedMove = false;

		for (int32_t j = numOfMoveDescriptionsMinus1; j > i; j--)
		{
			int32_t jMinus1 = j - 1;

			if (pMoveDescValuesArray[j].EstimatedEvaluation > pMoveDescValuesArray[jMinus1].EstimatedEvaluation)
			{
				swappedMove = true;

				int32_t tempMoveID = pMoveDescValuesArray[jMinus1].MoveID;
				int32_t tempBoardPosID = pMoveDescValuesArray[jMinus1].BoardPosID;
				int32_t tempEstimatedEvaluation = pMoveDescValuesArray[jMinus1].EstimatedEvaluation;

				pMoveDescValuesArray[jMinus1].MoveID = pMoveDescValuesArray[j].MoveID;
				pMoveDescValuesArray[jMinus1].BoardPosID = pMoveDescValuesArray[j].BoardPosID;
				pMoveDescValuesArray[jMinus1].EstimatedEvaluation = pMoveDescValuesArray[j].EstimatedEvaluation;

				pMoveDescValuesArray[j].MoveID = tempMoveID;
				pMoveDescValuesArray[j].BoardPosID = tempBoardPosID;
				pMoveDescValuesArray[j].EstimatedEvaluation = tempEstimatedEvaluation;
			}
		}

		// no Swapping happened, moves are sorted
		if (swappedMove == false)
		{
			break;
		}
	}

}

void CDepthFirstSearchAI::Reset_MoveDescValuesArray(void)
{
	int32_t boardPosIDCounter = 0;
	int32_t moveID = 0;

	for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	{
		pMoveDescValuesArray[i].BoardPosID = i % GameBoardSizeXY;
		pMoveDescValuesArray[i].MoveID = moveID;
		pMoveDescValuesArray[i].EstimatedEvaluation = ConstMinEvaluationScore_Minimax;

		boardPosIDCounter++;

		if (boardPosIDCounter == GameBoardSizeXY)
		{
			boardPosIDCounter = 0;
			moveID++;
		}
	}
}



void CDepthFirstSearchAI::Randomize_MoveDescValuesArray(int32_t numOfPermutationSteps)
{
	for (int32_t i = 0; i < numOfPermutationSteps; i++)
	{
		do
		{
			int32_t id1 = RandomNumbers.Get_IntegerNumber(0, NumOfMoveDescriptions);
			int32_t id2 = RandomNumbers.Get_IntegerNumber(0, NumOfMoveDescriptions);

			if (id1 != id2)
			{
				int32_t tempMoveID = pMoveDescValuesArray[id1].MoveID;
				int32_t tempBoardPosID = pMoveDescValuesArray[id1].BoardPosID;
				int32_t tempEstimatedEvaluation = pMoveDescValuesArray[id1].EstimatedEvaluation;

				pMoveDescValuesArray[id1].MoveID = pMoveDescValuesArray[id2].MoveID;
				pMoveDescValuesArray[id1].BoardPosID = pMoveDescValuesArray[id2].BoardPosID;
				pMoveDescValuesArray[id1].EstimatedEvaluation = pMoveDescValuesArray[id2].EstimatedEvaluation;
				
				pMoveDescValuesArray[id2].MoveID = tempMoveID;
				pMoveDescValuesArray[id2].BoardPosID = tempBoardPosID;
				pMoveDescValuesArray[id2].EstimatedEvaluation = tempEstimatedEvaluation;
				
				break;
			}

		} while (true);

	} // end of for (int32_t i = 0; i < numOfPermutationSteps; i++)
}

void CDepthFirstSearchAI::Randomize_MoveDescValuesArray_OnlyBoardPosIDs(int32_t numOfPermutationSteps)
{
	for (int32_t i = 0; i < numOfPermutationSteps; i++)
	{
		do
		{
			int32_t boardPosID1 = RandomNumbers.Get_IntegerNumber(0, GameBoardSizeXY);
			int32_t boardPosID2 = RandomNumbers.Get_IntegerNumber(0, GameBoardSizeXY);

			if (boardPosID1 != boardPosID2)
			{
				for (int32_t j = 0; j < NumOfMoveDescriptions; j++)
				{
					if (pMoveDescValuesArray[j].BoardPosID == boardPosID1)
					{
						pMoveDescValuesArray[j].BoardPosID = boardPosID2;
						pMoveDescValuesArray[j].EstimatedEvaluation = ConstMinEvaluationScore_Minimax;
					}
					else if (pMoveDescValuesArray[j].BoardPosID == boardPosID2)
					{
						pMoveDescValuesArray[j].BoardPosID = boardPosID1;
						pMoveDescValuesArray[j].EstimatedEvaluation = ConstMinEvaluationScore_Minimax;
					}
				}

				break;
			}

		} while (true);

	} // end of for (int32_t i = 0; i < numOfPermutationSteps; i++)
}

void CDepthFirstSearchAI::Randomize_MoveDescValuesArray_OnlyMoveIDs(int32_t numOfPermutationSteps)
{
	for (int32_t i = 0; i < numOfPermutationSteps; i++)
	{
		do
		{
			int32_t moveID1 = RandomNumbers.Get_IntegerNumber(0, NumOfDifferentMoveTypes);
			int32_t moveID2 = RandomNumbers.Get_IntegerNumber(0, NumOfDifferentMoveTypes);

			if (moveID1 != moveID2)
			{
				for (int32_t j = 0; j < NumOfMoveDescriptions; j++)
				{
					if (pMoveDescValuesArray[j].MoveID == moveID1)
					{
						pMoveDescValuesArray[j].MoveID = moveID2;
						pMoveDescValuesArray[j].EstimatedEvaluation = ConstMinEvaluationScore_Minimax;
					}
					else if (pMoveDescValuesArray[j].MoveID == moveID2)
					{
						pMoveDescValuesArray[j].MoveID = moveID1;
						pMoveDescValuesArray[j].EstimatedEvaluation = ConstMinEvaluationScore_Minimax;
					}
				}

				break;
			}

		} while (true);
		

	} // end of for (int32_t i = 0; i < numOfPermutationSteps; i++)
}

void CDepthFirstSearchAI::Stop_FurtherExploration_From_Separate_Thread(void)
{
	StopFurtherExploration = true;
}



void CDepthFirstSearchAI::Set_Player1MoveExcludedBoardElements(int32_t numOfValues, int8_t* pValueArray)
{
	int32_t maxSearchDepthPlus1 = MaxSearchDepth + 1;

	for (int32_t i = 0; i < maxSearchDepthPlus1; i++)
	{
		pTestMoveArray[i].NumOfPlayer1MoveExcludedBoardElements = numOfValues;

		for (int32_t j = 0; j < numOfValues; j++)
		{
			pTestMoveArray[i].Player1MoveExcludedBoardElementsArray[j] = pValueArray[j];
		}
	}
}

void CDepthFirstSearchAI::Set_Player2MoveExcludedBoardElements(int32_t numOfValues, int8_t* pValueArray)
{
	int32_t maxSearchDepthPlus1 = MaxSearchDepth + 1;

	for (int32_t i = 0; i < maxSearchDepthPlus1; i++)
	{
		pTestMoveArray[i].NumOfPlayer2MoveExcludedBoardElements = numOfValues;

		for (int32_t j = 0; j < numOfValues; j++)
		{
			pTestMoveArray[i].Player2MoveExcludedBoardElementsArray[j] = pValueArray[j];
		}
	}
}
void CDepthFirstSearchAI::Initialize(CMovePatternList* pPlayer1MoveList, CMovePatternList* pPlayer2MoveList, int32_t numTestGameStatesMax, int32_t maxSearchDepth, int32_t gameBoardSizeXDir, int32_t gameBoardSizeYDir)
{
	GameBoardSizeXY = gameBoardSizeXDir * gameBoardSizeYDir;

	MaxSearchDepth = max(2, maxSearchDepth);
	MaxSearchDepthMinus1 = MaxSearchDepth - 1;
	NumTestGameStatesMax = numTestGameStatesMax;

	pUsedPlayer1MoveList = pPlayer1MoveList;
	pUsedPlayer2MoveList = pPlayer2MoveList;

	int32_t maxSearchDepthPlus1 = MaxSearchDepth + 1;

	GameStatePool.Initialize(maxSearchDepthPlus1, NumTestGameStatesMax, gameBoardSizeXDir, gameBoardSizeYDir);

	delete[] pTestMoveArray;
	pTestMoveArray = nullptr;

	

	delete[] pMoveDescValuesArray;
	pMoveDescValuesArray = nullptr;

	

	pTestMoveArray = new (std::nothrow) CTestMove[maxSearchDepthPlus1];

	for (int32_t i = 0; i < maxSearchDepthPlus1; i++)
	{
		pTestMoveArray[i].Set_MovePatternLists(pPlayer1MoveList, pPlayer2MoveList);
		pTestMoveArray[i].Set_GameBoardSizeXDir(gameBoardSizeXDir);
		pTestMoveArray[i].Set_GameBoardSizeXY(GameBoardSizeXY);
	}

	NumOfDifferentMoveTypes = pUsedPlayer1MoveList->NumOfMoves;
	NumOfMoveDescriptions = NumOfDifferentMoveTypes * GameBoardSizeXY;

	pMoveDescValuesArray = new (std::nothrow) CMoveDescValues[NumOfMoveDescriptions];
	

	int32_t boardPosIDCounter = 0;
	int32_t moveID = 0;

	for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	{
		pMoveDescValuesArray[i].BoardPosID = i % GameBoardSizeXY;
		pMoveDescValuesArray[i].MoveID = moveID;
		pMoveDescValuesArray[i].EstimatedEvaluation = ConstMinEvaluationScore_Minimax;

		boardPosIDCounter++;

		if (boardPosIDCounter == GameBoardSizeXY)
		{
			boardPosIDCounter = 0;
			moveID++;
		}
	}
}

void CDepthFirstSearchAI::Initialize(CMovePatternList* pPlayer1MoveList, CMovePatternList* pPlayer2MoveList, int32_t numTestGameStatesMax, int32_t maxSearchDepth, 
	int32_t gameBoardSizeXDir, int32_t gameBoardSizeYDir, pCheckGameStateEvalFunc Player1ViewFunc, pCheckGameStateEvalFunc Player2ViewFunc)
{
	GameBoardSizeXY = gameBoardSizeXDir * gameBoardSizeYDir;

	MaxSearchDepth = max(2, maxSearchDepth);
	MaxSearchDepthMinus1 = MaxSearchDepth - 1;
	NumTestGameStatesMax = numTestGameStatesMax;

	pUsedPlayer1MoveList = pPlayer1MoveList;
	pUsedPlayer2MoveList = pPlayer2MoveList;

	int32_t maxSearchDepthPlus1 = MaxSearchDepth + 1;

	GameStatePool.Initialize(maxSearchDepthPlus1, NumTestGameStatesMax, gameBoardSizeXDir, gameBoardSizeYDir);

	delete[] pTestMoveArray;
	pTestMoveArray = nullptr;

	

	delete[] pMoveDescValuesArray;
	pMoveDescValuesArray = nullptr;

	

	pTestMoveArray = new (std::nothrow) CTestMove[maxSearchDepthPlus1];

	for (int32_t i = 0; i < maxSearchDepthPlus1; i++)
	{
		pTestMoveArray[i].Set_MovePatternLists(pPlayer1MoveList, pPlayer2MoveList);
		pTestMoveArray[i].Set_GameBoardSizeXDir(gameBoardSizeXDir);
		pTestMoveArray[i].Set_GameBoardSizeXY(GameBoardSizeXY);
		pTestMoveArray[i].Set_EvaluationFunctions(Player1ViewFunc, Player2ViewFunc);
	}

	NumOfDifferentMoveTypes = pUsedPlayer1MoveList->NumOfMoves;
	NumOfMoveDescriptions = NumOfDifferentMoveTypes * GameBoardSizeXY;

	pMoveDescValuesArray = new (std::nothrow) CMoveDescValues[NumOfMoveDescriptions];

	int32_t boardPosIDCounter = 0;
	int32_t moveID = 0;

	for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	{
		pMoveDescValuesArray[i].BoardPosID = i % GameBoardSizeXY;
		pMoveDescValuesArray[i].MoveID = moveID;
		pMoveDescValuesArray[i].EstimatedEvaluation = ConstMinEvaluationScore_Minimax;

		boardPosIDCounter++;

		if (boardPosIDCounter == GameBoardSizeXY)
		{
			boardPosIDCounter = 0;
			moveID++;
		}
	}
}

void CDepthFirstSearchAI::Set_MinTolerableEvaluationValues(int32_t player1Value, int32_t player2Value)
{
	int32_t maxSearchDepthPlus1 = MaxSearchDepth + 1;

	for (int32_t i = 0; i < maxSearchDepthPlus1; i++)
	{
		pTestMoveArray[i].MinTolerableEvaluationValue_Player1 = player1Value;
		pTestMoveArray[i].MinTolerableEvaluationValue_Player2 = player2Value;
	}
}


void CDepthFirstSearchAI::Set_GameStateEvaluationFunctions(pGameStateEvalFunc Player1ViewFunc, pGameStateEvalFunc Player2ViewFunc)
{
	Player1ViewGameStateEvalFunc = Player1ViewFunc;
	Player2ViewGameStateEvalFunc = Player2ViewFunc;
}

/*
void CDepthFirstSearchAI::Execute_Player1AI(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState)
{
	StopFurtherExploration = false;

	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t RootGameStateID = -1;
	CGameStateValues* pRootGameStateObject = nullptr;

	GameStatePool.Get_UnusedGameStateObject(0, &pRootGameStateObject, &RootGameStateID);
	pRootGameStateObject->Clone_GameStateValues(pInActualGameState);
	pRootGameStateObject->Use_As_Maximizer();

	CTestMove* pTestMove = &pTestMoveArray[1];

	if (MaxSearchDepth == 2)
	{
		int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

		//for (int32_t i = 0; i < GameBoardSizeXY; i++)
		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			//pTestMove->BoardPosID = pBoardPosIDArray[i];
			pTestMove->MoveID = j;

			//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			for (int32_t i = 0; i < GameBoardSizeXY; i++)
			{
				//pTestMove->MoveID = j;
				pTestMove->BoardPosID = pBoardPosIDArray[i];

				if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
				{
					CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

					bool TestMoveDepth2Failed = Player1AI_InnerEvalulationLoop(pGameStateObjectDepth1, 1, 2);

					if (TestMoveDepth2Failed == true)
					{
						Player1ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
					}

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);

				} // end of if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

				if (StopFurtherExploration == true)
				{
					goto GameTreeExplorationFinished;
				}

			} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	} // end of if (MaxSearchDepth == 2)
	else if (MaxSearchDepth > 2)
	{
		int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

		//for (int32_t i = 0; i < GameBoardSizeXY; i++)
		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			//pTestMove->BoardPosID = pBoardPosIDArray[i];
			pTestMove->MoveID = j;

			//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			for (int32_t i = 0; i < GameBoardSizeXY; i++)
			{
				//pTestMove->MoveID = j;
				pTestMove->BoardPosID = pBoardPosIDArray[i];

				if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
				{
					CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

					bool TestMoveDepth2Failed = Player1AI_OuterEvalulationLoop(pGameStateObjectDepth1, 1, 2);

					if (TestMoveDepth2Failed == true)
					{
						Player1ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
					}

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);

				} // end of if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

				if (StopFurtherExploration == true)
				{
					goto GameTreeExplorationFinished;
				}

			} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	} // end of else if (MaxSearchDepth > 2)

	
GameTreeExplorationFinished:;

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID, 1);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

	
}
*/

void CDepthFirstSearchAI::Find_PromisingMoves_Player1View(CGameStateValues* pInActualGameState, int32_t moveOrder_NumOfSortingStepsMax, int32_t searchDepth)
{
	StopFurtherExploration = false;

	searchDepth = min(searchDepth, MaxSearchDepth);

	int32_t tempMaxSearchDepth = MaxSearchDepth;
	int32_t tempMaxSearchDepthMinus1 = MaxSearchDepthMinus1;

	MaxSearchDepth = searchDepth;
	MaxSearchDepthMinus1 = searchDepth - 1;

	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t RootGameStateID = -1;
	CGameStateValues* pRootGameStateObject = nullptr;

	GameStatePool.Get_UnusedGameStateObject(0, &pRootGameStateObject, &RootGameStateID);
	pRootGameStateObject->Clone_GameStateValues(pInActualGameState);
	pRootGameStateObject->Use_As_Maximizer();

	CTestMove* pTestMove = &pTestMoveArray[1];

	if (searchDepth == 1)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;
			pMoveDescValuesArray[i].EstimatedEvaluation = ConstMinEvaluationScore_Minimax;

			if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				Player1ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				pMoveDescValuesArray[i].EstimatedEvaluation = pGameStateObjectDepth1->iEvaluation;

			} // end of if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	}
	else if (searchDepth == 2)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;
			pMoveDescValuesArray[i].EstimatedEvaluation = ConstMinEvaluationScore_Minimax;

			if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				bool TestMoveDepth2Failed = Player1AI_InnerEvalulationLoop(pGameStateObjectDepth1, 1, 2);

				if (TestMoveDepth2Failed == true)
				{
					Player1ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				}

				pMoveDescValuesArray[i].EstimatedEvaluation = pGameStateObjectDepth1->iEvaluation;

			} // end of if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

			if (StopFurtherExploration == true)
			{
				goto GameTreeExplorationFinished;
			}
		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	}
	else if (searchDepth > 2)
	{ 
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;

			if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				bool TestMoveDepth2Failed = Player1AI_OuterEvalulationLoop(pGameStateObjectDepth1, 1, 2);

				if (TestMoveDepth2Failed == true)
				{
					Player1ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				}

				pMoveDescValuesArray[i].EstimatedEvaluation = pGameStateObjectDepth1->iEvaluation;

			} // end of if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

			if (StopFurtherExploration == true)
			{
				goto GameTreeExplorationFinished;
			}
		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	} // end of else if (searchDepth > 2)

	

GameTreeExplorationFinished:;

	MaxSearchDepth = tempMaxSearchDepth;
	MaxSearchDepthMinus1 = tempMaxSearchDepthMinus1;

	Improve_MoveOrder(moveOrder_NumOfSortingStepsMax);
}

int32_t CDepthFirstSearchAI::IterativeDeepeningStep_Player1View(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, int32_t moveOrder_NumOfSortingStepsMax, int32_t searchDepth)
{
	StopFurtherExploration = false;

	searchDepth = min(searchDepth, MaxSearchDepth);

	int32_t tempMaxSearchDepth = MaxSearchDepth;
	int32_t tempMaxSearchDepthMinus1 = MaxSearchDepthMinus1;

	MaxSearchDepth = searchDepth;
	MaxSearchDepthMinus1 = searchDepth - 1;

	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t RootGameStateID = -1;
	CGameStateValues* pRootGameStateObject = nullptr;

	GameStatePool.Get_UnusedGameStateObject(0, &pRootGameStateObject, &RootGameStateID);
	pRootGameStateObject->Clone_GameStateValues(pInActualGameState);
	pRootGameStateObject->Use_As_Maximizer();

	CTestMove* pTestMove = &pTestMoveArray[1];

	if (searchDepth == 1)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;
			pMoveDescValuesArray[i].EstimatedEvaluation = ConstMinEvaluationScore_Minimax;

			if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				Player1ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				pMoveDescValuesArray[i].EstimatedEvaluation = pGameStateObjectDepth1->iEvaluation;

			} // end of if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	}
	else if (searchDepth == 2)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;
			pMoveDescValuesArray[i].EstimatedEvaluation = ConstMinEvaluationScore_Minimax;

			if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				bool TestMoveDepth2Failed = Player1AI_InnerEvalulationLoop(pGameStateObjectDepth1, 1, 2);

				if (TestMoveDepth2Failed == true)
				{
					Player1ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				}

				pMoveDescValuesArray[i].EstimatedEvaluation = pGameStateObjectDepth1->iEvaluation;

			} // end of if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

			if (StopFurtherExploration == true)
			{
				goto GameTreeExplorationFinished;
			}
		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	}
	else if (searchDepth > 2)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;

			if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				bool TestMoveDepth2Failed = Player1AI_OuterEvalulationLoop(pGameStateObjectDepth1, 1, 2);

				if (TestMoveDepth2Failed == true)
				{
					Player1ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				}

				pMoveDescValuesArray[i].EstimatedEvaluation = pGameStateObjectDepth1->iEvaluation;

			} // end of if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

			if (StopFurtherExploration == true)
			{
				goto GameTreeExplorationFinished;
			}
		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	} // end of else if (searchDepth > 2)



GameTreeExplorationFinished:;

	MaxSearchDepth = tempMaxSearchDepth;
	MaxSearchDepthMinus1 = tempMaxSearchDepthMinus1;

	Improve_MoveOrder(moveOrder_NumOfSortingStepsMax);

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID, 1);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

	int32_t bestEstimatedEvaluation = pMoveDescValuesArray[0].EstimatedEvaluation;

	if (bestEstimatedEvaluation == ConstMaxEvaluationScore_Minimax)
	{
		return 1;
	}
	if (bestEstimatedEvaluation == ConstMinEvaluationScore_Minimax)
	{
		return -1;
	}

	return 0;
}

int32_t CDepthFirstSearchAI::IterativeDeepeningStep_Player1View_EarlyOut_DiscardInsufficientStates(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, int32_t minAcceptableEvalValuePlayer1, int32_t minTolerableEvalValuePlayer1, float minTolerableEvalValuePlayer2, int32_t moveOrder_NumOfSortingStepsMax, int32_t searchDepth)
{
	StopFurtherExploration = false;

	EarlyOutCounter = 0;
	g_NumOfGameStatesWithTooLowEvalValues = 0;

	searchDepth = min(searchDepth, MaxSearchDepth);

	int32_t tempMaxSearchDepth = MaxSearchDepth;
	int32_t tempMaxSearchDepthMinus1 = MaxSearchDepthMinus1;

	MaxSearchDepth = searchDepth;
	MaxSearchDepthMinus1 = searchDepth - 1;

	MinAcceptableEvalValueEarlyOut = minAcceptableEvalValuePlayer1;

	Set_MinTolerableEvaluationValues(minTolerableEvalValuePlayer1, minTolerableEvalValuePlayer2);

	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t RootGameStateID = -1;
	CGameStateValues* pRootGameStateObject = nullptr;

	GameStatePool.Get_UnusedGameStateObject(0, &pRootGameStateObject, &RootGameStateID);
	pRootGameStateObject->Clone_GameStateValues(pInActualGameState);
	pRootGameStateObject->Use_As_Maximizer();

	CTestMove* pTestMove = &pTestMoveArray[1];

	if (searchDepth == 1)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;
			pMoveDescValuesArray[i].EstimatedEvaluation = ConstMinEvaluationScore_Minimax;

			if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				Player1ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				pMoveDescValuesArray[i].EstimatedEvaluation = pGameStateObjectDepth1->iEvaluation;

			} // end of if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	}
	else if (searchDepth == 2)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;
			pMoveDescValuesArray[i].EstimatedEvaluation = ConstMinEvaluationScore_Minimax;

			if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				bool TestMoveDepth2Failed = Player1AI_InnerEvalulationLoop(pGameStateObjectDepth1, 1, 2);

				if (TestMoveDepth2Failed == true)
				{
					Player1ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				}

				pMoveDescValuesArray[i].EstimatedEvaluation = pGameStateObjectDepth1->iEvaluation;

			} // end of if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

			if (StopFurtherExploration == true)
			{
				goto GameTreeExplorationFinished;
			}
		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	}
	else if (searchDepth > 2)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;

			if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				bool TestMoveDepth2Failed = Player1AI_OuterEvalulationLoop_EarlyOut_DiscardInsufficientStates(pGameStateObjectDepth1, 1, 2);

				if (TestMoveDepth2Failed == true)
				{
					Player1ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				}

				pMoveDescValuesArray[i].EstimatedEvaluation = pGameStateObjectDepth1->iEvaluation;

				if (pGameStateObjectDepth1->iEvaluation >= MinAcceptableEvalValueEarlyOut)
				{
					EarlyOutCounter++;
					goto GameTreeExplorationFinished;
				}

			} // end of if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

			if (StopFurtherExploration == true)
			{
				goto GameTreeExplorationFinished;
			}
		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	} // end of else if (searchDepth > 2)



GameTreeExplorationFinished:;

	MaxSearchDepth = tempMaxSearchDepth;
	MaxSearchDepthMinus1 = tempMaxSearchDepthMinus1;

	Improve_MoveOrder(moveOrder_NumOfSortingStepsMax);

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID, 1);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

	int32_t bestEstimatedEvaluation = pMoveDescValuesArray[0].EstimatedEvaluation;

	if (bestEstimatedEvaluation == ConstMaxEvaluationScore_Minimax)
	{
		return 1;
	}
	if (bestEstimatedEvaluation == ConstMinEvaluationScore_Minimax)
	{
		return -1;
	}

	return 0;
}


int32_t CDepthFirstSearchAI::IterativeDeepeningStep_Player1View_EarlyOut(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, int32_t minAcceptableEvalValuePlayer1, int32_t moveOrder_NumOfSortingStepsMax, int32_t searchDepth)
{
	StopFurtherExploration = false;

	EarlyOutCounter = 0;

	searchDepth = min(searchDepth, MaxSearchDepth);

	int32_t tempMaxSearchDepth = MaxSearchDepth;
	int32_t tempMaxSearchDepthMinus1 = MaxSearchDepthMinus1;

	MaxSearchDepth = searchDepth;
	MaxSearchDepthMinus1 = searchDepth - 1;

	MinAcceptableEvalValueEarlyOut = minAcceptableEvalValuePlayer1;

	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t RootGameStateID = -1;
	CGameStateValues* pRootGameStateObject = nullptr;

	GameStatePool.Get_UnusedGameStateObject(0, &pRootGameStateObject, &RootGameStateID);
	pRootGameStateObject->Clone_GameStateValues(pInActualGameState);
	pRootGameStateObject->Use_As_Maximizer();

	CTestMove* pTestMove = &pTestMoveArray[1];

	if (searchDepth == 1)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;
			pMoveDescValuesArray[i].EstimatedEvaluation = ConstMinEvaluationScore_Minimax;

			if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				Player1ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				pMoveDescValuesArray[i].EstimatedEvaluation = pGameStateObjectDepth1->iEvaluation;

			} // end of if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	}
	else if (searchDepth == 2)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;
			pMoveDescValuesArray[i].EstimatedEvaluation = ConstMinEvaluationScore_Minimax;

			if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				bool TestMoveDepth2Failed = Player1AI_InnerEvalulationLoop(pGameStateObjectDepth1, 1, 2);

				if (TestMoveDepth2Failed == true)
				{
					Player1ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				}

				pMoveDescValuesArray[i].EstimatedEvaluation = pGameStateObjectDepth1->iEvaluation;

			} // end of if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

			if (StopFurtherExploration == true)
			{
				goto GameTreeExplorationFinished;
			}
		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	}
	else if (searchDepth > 2)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;

			if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				bool TestMoveDepth2Failed = Player1AI_OuterEvalulationLoop_EarlyOut(pGameStateObjectDepth1, 1, 2);

				if (TestMoveDepth2Failed == true)
				{
					Player1ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				}

				pMoveDescValuesArray[i].EstimatedEvaluation = pGameStateObjectDepth1->iEvaluation;

				if (pGameStateObjectDepth1->iEvaluation >= MinAcceptableEvalValueEarlyOut)
				{
					EarlyOutCounter++;
					goto GameTreeExplorationFinished;
				}

			} // end of if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

			if (StopFurtherExploration == true)
			{
				goto GameTreeExplorationFinished;
			}
		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	} // end of else if (searchDepth > 2)



GameTreeExplorationFinished:;

	MaxSearchDepth = tempMaxSearchDepth;
	MaxSearchDepthMinus1 = tempMaxSearchDepthMinus1;

	Improve_MoveOrder(moveOrder_NumOfSortingStepsMax);

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID, 1);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

	int32_t bestEstimatedEvaluation = pMoveDescValuesArray[0].EstimatedEvaluation;

	if (bestEstimatedEvaluation == ConstMaxEvaluationScore_Minimax)
	{
		return 1;
	}
	if (bestEstimatedEvaluation == ConstMinEvaluationScore_Minimax)
	{
		return -1;
	}

	return 0;
}


int32_t CDepthFirstSearchAI::IterativeDeepeningStep_Player1View_DiscardInsufficientStates(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, int32_t minTolerableEvalValuePlayer1, int32_t minTolerableEvalValuePlayer2, int32_t moveOrder_NumOfSortingStepsMax, int32_t searchDepth)
{
	StopFurtherExploration = false;

	g_NumOfGameStatesWithTooLowEvalValues = 0;

	searchDepth = min(searchDepth, MaxSearchDepth);

	int32_t tempMaxSearchDepth = MaxSearchDepth;
	int32_t tempMaxSearchDepthMinus1 = MaxSearchDepthMinus1;

	MaxSearchDepth = searchDepth;
	MaxSearchDepthMinus1 = searchDepth - 1;

	Set_MinTolerableEvaluationValues(minTolerableEvalValuePlayer1, minTolerableEvalValuePlayer2);

	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t RootGameStateID = -1;
	CGameStateValues* pRootGameStateObject = nullptr;

	GameStatePool.Get_UnusedGameStateObject(0, &pRootGameStateObject, &RootGameStateID);
	pRootGameStateObject->Clone_GameStateValues(pInActualGameState);
	pRootGameStateObject->Use_As_Maximizer();

	CTestMove* pTestMove = &pTestMoveArray[1];

	if (searchDepth == 1)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;
			pMoveDescValuesArray[i].EstimatedEvaluation = ConstMinEvaluationScore_Minimax;

			if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				Player1ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				pMoveDescValuesArray[i].EstimatedEvaluation = pGameStateObjectDepth1->iEvaluation;

			} // end of if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	}
	else if (searchDepth == 2)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;
			pMoveDescValuesArray[i].EstimatedEvaluation = ConstMinEvaluationScore_Minimax;

			if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				bool TestMoveDepth2Failed = Player1AI_InnerEvalulationLoop(pGameStateObjectDepth1, 1, 2);

				if (TestMoveDepth2Failed == true)
				{
					Player1ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				}

				pMoveDescValuesArray[i].EstimatedEvaluation = pGameStateObjectDepth1->iEvaluation;

			} // end of if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

			if (StopFurtherExploration == true)
			{
				goto GameTreeExplorationFinished;
			}
		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	}
	else if (searchDepth > 2)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;

			if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				bool TestMoveDepth2Failed = Player1AI_OuterEvalulationLoop_DiscardInsufficientStates(pGameStateObjectDepth1, 1, 2);

				if (TestMoveDepth2Failed == true)
				{
					Player1ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				}

				pMoveDescValuesArray[i].EstimatedEvaluation = pGameStateObjectDepth1->iEvaluation;

			} // end of if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

			if (StopFurtherExploration == true)
			{
				goto GameTreeExplorationFinished;
			}
		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	} // end of else if (searchDepth > 2)



GameTreeExplorationFinished:;

	MaxSearchDepth = tempMaxSearchDepth;
	MaxSearchDepthMinus1 = tempMaxSearchDepthMinus1;

	Improve_MoveOrder(moveOrder_NumOfSortingStepsMax);

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID, 1);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

	int32_t bestEstimatedEvaluation = pMoveDescValuesArray[0].EstimatedEvaluation;

	if (bestEstimatedEvaluation == ConstMaxEvaluationScore_Minimax)
	{
		return 1;
	}
	if (bestEstimatedEvaluation == ConstMinEvaluationScore_Minimax)
	{
		return -1;
	}

	return 0;
}

void CDepthFirstSearchAI::Find_PromisingMoves_Player2View(CGameStateValues* pInActualGameState, int32_t moveOrder_NumOfSortingStepsMax, int32_t searchDepth)
{
	StopFurtherExploration = false;

	searchDepth = min(searchDepth, MaxSearchDepth);

	int32_t tempMaxSearchDepth = MaxSearchDepth;
	int32_t tempMaxSearchDepthMinus1 = MaxSearchDepthMinus1;

	MaxSearchDepth = searchDepth;
	MaxSearchDepthMinus1 = searchDepth - 1;

	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t RootGameStateID = -1;
	CGameStateValues* pRootGameStateObject = nullptr;

	GameStatePool.Get_UnusedGameStateObject(0, &pRootGameStateObject, &RootGameStateID);
	pRootGameStateObject->Clone_GameStateValues(pInActualGameState);
	pRootGameStateObject->Use_As_Maximizer();

	CTestMove* pTestMove = &pTestMoveArray[1];

	if (searchDepth == 1)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;
			pMoveDescValuesArray[i].EstimatedEvaluation = ConstMinEvaluationScore_Minimax;

			if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				Player2ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				pMoveDescValuesArray[i].EstimatedEvaluation = pGameStateObjectDepth1->iEvaluation;

			} // end of if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	} // end of if (searchDepth == 1)
	else if (searchDepth == 2)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;
			pMoveDescValuesArray[i].EstimatedEvaluation = ConstMinEvaluationScore_Minimax;

			if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				bool TestMoveDepth2Failed = Player2AI_InnerEvalulationLoop(pGameStateObjectDepth1, 0, 2);

				if (TestMoveDepth2Failed == true)
				{
					Player2ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				}

				pMoveDescValuesArray[i].EstimatedEvaluation = pGameStateObjectDepth1->iEvaluation;

			} // end of if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

			if (StopFurtherExploration == true)
			{
				goto GameTreeExplorationFinished;
			}

		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	} 
	else if (searchDepth > 2)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;

			if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				bool TestMoveDepth2Failed = Player2AI_OuterEvalulationLoop(pGameStateObjectDepth1, 0, 2);

				if (TestMoveDepth2Failed == true)
				{
					Player2ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				}

				pMoveDescValuesArray[i].EstimatedEvaluation = pGameStateObjectDepth1->iEvaluation;

			} // end of if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

			if (StopFurtherExploration == true)
			{
				goto GameTreeExplorationFinished;
			}
		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	}

	
GameTreeExplorationFinished:;

	MaxSearchDepth = tempMaxSearchDepth;
	MaxSearchDepthMinus1 = tempMaxSearchDepthMinus1;

	Improve_MoveOrder(moveOrder_NumOfSortingStepsMax);

	/*for (int32_t i = 0; i < 4; i++)
	{
		Add_To_Log(0, "eval", pMoveDescValuesArray[i].EstimatedEvaluation);
	}*/
}

int32_t CDepthFirstSearchAI::IterativeDeepeningStep_Player2View(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, int32_t moveOrder_NumOfSortingStepsMax, int32_t searchDepth)
{
	StopFurtherExploration = false;

	searchDepth = min(searchDepth, MaxSearchDepth);

	int32_t tempMaxSearchDepth = MaxSearchDepth;
	int32_t tempMaxSearchDepthMinus1 = MaxSearchDepthMinus1;

	MaxSearchDepth = searchDepth;
	MaxSearchDepthMinus1 = searchDepth - 1;

	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t RootGameStateID = -1;
	CGameStateValues* pRootGameStateObject = nullptr;

	GameStatePool.Get_UnusedGameStateObject(0, &pRootGameStateObject, &RootGameStateID);
	pRootGameStateObject->Clone_GameStateValues(pInActualGameState);
	pRootGameStateObject->Use_As_Maximizer();

	CTestMove* pTestMove = &pTestMoveArray[1];

	if (searchDepth == 1)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;
			pMoveDescValuesArray[i].EstimatedEvaluation = ConstMinEvaluationScore_Minimax;

			if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				Player2ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				pMoveDescValuesArray[i].EstimatedEvaluation = pGameStateObjectDepth1->iEvaluation;

			} // end of if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	}
	else if (searchDepth == 2)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;
			pMoveDescValuesArray[i].EstimatedEvaluation = ConstMinEvaluationScore_Minimax;

			if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				bool TestMoveDepth2Failed = Player2AI_InnerEvalulationLoop(pGameStateObjectDepth1, 0, 2);

				if (TestMoveDepth2Failed == true)
				{
					Player2ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				}

				pMoveDescValuesArray[i].EstimatedEvaluation = pGameStateObjectDepth1->iEvaluation;

			} // end of if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

			if (StopFurtherExploration == true)
			{
				goto GameTreeExplorationFinished;
			}

		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	}
	else if (searchDepth > 2)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;

			if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				bool TestMoveDepth2Failed = Player2AI_OuterEvalulationLoop(pGameStateObjectDepth1, 0, 2);

				if (TestMoveDepth2Failed == true)
				{
					Player2ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				}

				pMoveDescValuesArray[i].EstimatedEvaluation = pGameStateObjectDepth1->iEvaluation;

			} // end of if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

			if (StopFurtherExploration == true)
			{
				goto GameTreeExplorationFinished;
			}
		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	}


GameTreeExplorationFinished:;

	MaxSearchDepth = tempMaxSearchDepth;
	MaxSearchDepthMinus1 = tempMaxSearchDepthMinus1;

	Improve_MoveOrder(moveOrder_NumOfSortingStepsMax);

	/*for (int32_t i = 0; i < 4; i++)
	{
		Add_To_Log(0, "eval", pMoveDescValuesArray[i].EstimatedEvaluation);
	}*/

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID, 1);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

	int32_t bestEstimatedEvaluation = pMoveDescValuesArray[0].EstimatedEvaluation;

	if (bestEstimatedEvaluation == ConstMaxEvaluationScore_Minimax)
	{
		return 1;
	}
	if (bestEstimatedEvaluation == ConstMinEvaluationScore_Minimax)
	{
		return -1;
	}

	return 0;
}

int32_t CDepthFirstSearchAI::IterativeDeepeningStep_Player2View_EarlyOut_DiscardInsufficientStates(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, int32_t minAcceptableEvalValuePlayer2, int32_t minTolerableEvalValuePlayer1, float minTolerableEvalValuePlayer2, int32_t moveOrder_NumOfSortingStepsMax, int32_t searchDepth)
{
	StopFurtherExploration = false;

	EarlyOutCounter = 0;
	g_NumOfGameStatesWithTooLowEvalValues = 0;

	searchDepth = min(searchDepth, MaxSearchDepth);

	int32_t tempMaxSearchDepth = MaxSearchDepth;
	int32_t tempMaxSearchDepthMinus1 = MaxSearchDepthMinus1;

	MaxSearchDepth = searchDepth;
	MaxSearchDepthMinus1 = searchDepth - 1;

	MinAcceptableEvalValueEarlyOut = minAcceptableEvalValuePlayer2;

	Set_MinTolerableEvaluationValues(minTolerableEvalValuePlayer1, minTolerableEvalValuePlayer2);

	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t RootGameStateID = -1;
	CGameStateValues* pRootGameStateObject = nullptr;

	GameStatePool.Get_UnusedGameStateObject(0, &pRootGameStateObject, &RootGameStateID);
	pRootGameStateObject->Clone_GameStateValues(pInActualGameState);
	pRootGameStateObject->Use_As_Maximizer();

	CTestMove* pTestMove = &pTestMoveArray[1];

	if (searchDepth == 1)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;
			pMoveDescValuesArray[i].EstimatedEvaluation = ConstMinEvaluationScore_Minimax;

			if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				Player2ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				pMoveDescValuesArray[i].EstimatedEvaluation = pGameStateObjectDepth1->iEvaluation;

			} // end of if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	}
	else if (searchDepth == 2)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;
			pMoveDescValuesArray[i].EstimatedEvaluation = ConstMinEvaluationScore_Minimax;

			if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				bool TestMoveDepth2Failed = Player2AI_InnerEvalulationLoop(pGameStateObjectDepth1, 0, 2);

				if (TestMoveDepth2Failed == true)
				{
					Player2ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				}

				pMoveDescValuesArray[i].EstimatedEvaluation = pGameStateObjectDepth1->iEvaluation;

			} // end of if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

			if (StopFurtherExploration == true)
			{
				goto GameTreeExplorationFinished;
			}

		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	}
	else if (searchDepth > 2)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;

			if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				bool TestMoveDepth2Failed = Player2AI_OuterEvalulationLoop_EarlyOut_DiscardInsufficientStates(pGameStateObjectDepth1, 0, 2);

				if (TestMoveDepth2Failed == true)
				{
					Player2ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				}

				pMoveDescValuesArray[i].EstimatedEvaluation = pGameStateObjectDepth1->iEvaluation;

				if (pGameStateObjectDepth1->iEvaluation >= MinAcceptableEvalValueEarlyOut)
				{
					EarlyOutCounter++;
					goto GameTreeExplorationFinished;
				}

			} // end of if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

			if (StopFurtherExploration == true)
			{
				goto GameTreeExplorationFinished;
			}
		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	}


GameTreeExplorationFinished:;

	MaxSearchDepth = tempMaxSearchDepth;
	MaxSearchDepthMinus1 = tempMaxSearchDepthMinus1;

	Improve_MoveOrder(moveOrder_NumOfSortingStepsMax);

	/*for (int32_t i = 0; i < 4; i++)
	{
		Add_To_Log(0, "eval", pMoveDescValuesArray[i].EstimatedEvaluation);
	}*/

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID, 1);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

	int32_t bestEstimatedEvaluation = pMoveDescValuesArray[0].EstimatedEvaluation;

	if (bestEstimatedEvaluation == ConstMaxEvaluationScore_Minimax)
	{
		return 1;
	}
	if (bestEstimatedEvaluation == ConstMinEvaluationScore_Minimax)
	{
		return -1;
	}

	return 0;
}


int32_t CDepthFirstSearchAI::IterativeDeepeningStep_Player2View_EarlyOut(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, int32_t minAcceptableEvalValuePlayer2, int32_t moveOrder_NumOfSortingStepsMax, int32_t searchDepth)
{
	StopFurtherExploration = false;

	EarlyOutCounter = 0;

	searchDepth = min(searchDepth, MaxSearchDepth);

	int32_t tempMaxSearchDepth = MaxSearchDepth;
	int32_t tempMaxSearchDepthMinus1 = MaxSearchDepthMinus1;

	MaxSearchDepth = searchDepth;
	MaxSearchDepthMinus1 = searchDepth - 1;

	MinAcceptableEvalValueEarlyOut = minAcceptableEvalValuePlayer2;

	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t RootGameStateID = -1;
	CGameStateValues* pRootGameStateObject = nullptr;

	GameStatePool.Get_UnusedGameStateObject(0, &pRootGameStateObject, &RootGameStateID);
	pRootGameStateObject->Clone_GameStateValues(pInActualGameState);
	pRootGameStateObject->Use_As_Maximizer();

	CTestMove* pTestMove = &pTestMoveArray[1];

	if (searchDepth == 1)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;
			pMoveDescValuesArray[i].EstimatedEvaluation = ConstMinEvaluationScore_Minimax;

			if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				Player2ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				pMoveDescValuesArray[i].EstimatedEvaluation = pGameStateObjectDepth1->iEvaluation;

			} // end of if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	}
	else if (searchDepth == 2)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;
			pMoveDescValuesArray[i].EstimatedEvaluation = ConstMinEvaluationScore_Minimax;

			if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				bool TestMoveDepth2Failed = Player2AI_InnerEvalulationLoop(pGameStateObjectDepth1, 0, 2);

				if (TestMoveDepth2Failed == true)
				{
					Player2ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				}

				pMoveDescValuesArray[i].EstimatedEvaluation = pGameStateObjectDepth1->iEvaluation;

			} // end of if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

			if (StopFurtherExploration == true)
			{
				goto GameTreeExplorationFinished;
			}

		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	}
	else if (searchDepth > 2)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;

			if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				bool TestMoveDepth2Failed = Player2AI_OuterEvalulationLoop_EarlyOut(pGameStateObjectDepth1, 0, 2);

				if (TestMoveDepth2Failed == true)
				{
					Player2ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				}

				pMoveDescValuesArray[i].EstimatedEvaluation = pGameStateObjectDepth1->iEvaluation;

				if (pGameStateObjectDepth1->iEvaluation >= MinAcceptableEvalValueEarlyOut)
				{
					EarlyOutCounter++;
					goto GameTreeExplorationFinished;
				}

			} // end of if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

			if (StopFurtherExploration == true)
			{
				goto GameTreeExplorationFinished;
			}
		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	}


GameTreeExplorationFinished:;

	MaxSearchDepth = tempMaxSearchDepth;
	MaxSearchDepthMinus1 = tempMaxSearchDepthMinus1;

	Improve_MoveOrder(moveOrder_NumOfSortingStepsMax);

	/*for (int32_t i = 0; i < 4; i++)
	{
		Add_To_Log(0, "eval", pMoveDescValuesArray[i].EstimatedEvaluation);
	}*/

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID, 1);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

	int32_t bestEstimatedEvaluation = pMoveDescValuesArray[0].EstimatedEvaluation;

	if (bestEstimatedEvaluation == ConstMaxEvaluationScore_Minimax)
	{
		return 1;
	}
	if (bestEstimatedEvaluation == ConstMinEvaluationScore_Minimax)
	{
		return -1;
	}

	return 0;
}


int32_t CDepthFirstSearchAI::IterativeDeepeningStep_Player2View_DiscardInsufficientStates(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, int32_t minTolerableEvalValuePlayer1, int32_t minTolerableEvalValuePlayer2, int32_t moveOrder_NumOfSortingStepsMax, int32_t searchDepth)
{
	StopFurtherExploration = false;

	g_NumOfGameStatesWithTooLowEvalValues = 0;

	searchDepth = min(searchDepth, MaxSearchDepth);

	int32_t tempMaxSearchDepth = MaxSearchDepth;
	int32_t tempMaxSearchDepthMinus1 = MaxSearchDepthMinus1;

	MaxSearchDepth = searchDepth;
	MaxSearchDepthMinus1 = searchDepth - 1;

	Set_MinTolerableEvaluationValues(minTolerableEvalValuePlayer1, minTolerableEvalValuePlayer2);

	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t RootGameStateID = -1;
	CGameStateValues* pRootGameStateObject = nullptr;

	GameStatePool.Get_UnusedGameStateObject(0, &pRootGameStateObject, &RootGameStateID);
	pRootGameStateObject->Clone_GameStateValues(pInActualGameState);
	pRootGameStateObject->Use_As_Maximizer();

	CTestMove* pTestMove = &pTestMoveArray[1];

	if (searchDepth == 1)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;
			pMoveDescValuesArray[i].EstimatedEvaluation = ConstMinEvaluationScore_Minimax;

			if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				Player2ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				pMoveDescValuesArray[i].EstimatedEvaluation = pGameStateObjectDepth1->iEvaluation;

			} // end of if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	}
	else if (searchDepth == 2)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;
			pMoveDescValuesArray[i].EstimatedEvaluation = ConstMinEvaluationScore_Minimax;

			if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				bool TestMoveDepth2Failed = Player2AI_InnerEvalulationLoop(pGameStateObjectDepth1, 0, 2);

				if (TestMoveDepth2Failed == true)
				{
					Player2ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				}

				pMoveDescValuesArray[i].EstimatedEvaluation = pGameStateObjectDepth1->iEvaluation;

			} // end of if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

			if (StopFurtherExploration == true)
			{
				goto GameTreeExplorationFinished;
			}

		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	}
	else if (searchDepth > 2)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;

			if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				bool TestMoveDepth2Failed = Player2AI_OuterEvalulationLoop_DiscardInsufficientStates(pGameStateObjectDepth1, 0, 2);

				if (TestMoveDepth2Failed == true)
				{
					Player2ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				}

				pMoveDescValuesArray[i].EstimatedEvaluation = pGameStateObjectDepth1->iEvaluation;

			} // end of if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

			if (StopFurtherExploration == true)
			{
				goto GameTreeExplorationFinished;
			}
		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	}


GameTreeExplorationFinished:;

	MaxSearchDepth = tempMaxSearchDepth;
	MaxSearchDepthMinus1 = tempMaxSearchDepthMinus1;

	Improve_MoveOrder(moveOrder_NumOfSortingStepsMax);

	/*for (int32_t i = 0; i < 4; i++)
	{
		Add_To_Log(0, "eval", pMoveDescValuesArray[i].EstimatedEvaluation);
	}*/

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID, 1);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

	int32_t bestEstimatedEvaluation = pMoveDescValuesArray[0].EstimatedEvaluation;

	if (bestEstimatedEvaluation == ConstMaxEvaluationScore_Minimax)
	{
		return 1;
	}
	if (bestEstimatedEvaluation == ConstMinEvaluationScore_Minimax)
	{
		return -1;
	}

	return 0;
}

void CDepthFirstSearchAI::Execute_Player1AI(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState)
{
	StopFurtherExploration = false;

	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t RootGameStateID = -1;
	CGameStateValues* pRootGameStateObject = nullptr;

	GameStatePool.Get_UnusedGameStateObject(0, &pRootGameStateObject, &RootGameStateID);
	pRootGameStateObject->Clone_GameStateValues(pInActualGameState);
	pRootGameStateObject->Use_As_Maximizer();

	CTestMove* pTestMove = &pTestMoveArray[1];

	if (MaxSearchDepth == 2)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;
		
			if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				bool TestMoveDepth2Failed = Player1AI_InnerEvalulationLoop(pGameStateObjectDepth1, 1, 2);

				if (TestMoveDepth2Failed == true)
				{
					Player1ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				}

				//OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);

			} // end of if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

			if (StopFurtherExploration == true)
			{
				goto GameTreeExplorationFinished;
			}
		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	} // end of if (MaxSearchDepth == 2)
	else if (MaxSearchDepth > 2)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;

			if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				bool TestMoveDepth2Failed = Player1AI_OuterEvalulationLoop(pGameStateObjectDepth1, 1, 2);

				if (TestMoveDepth2Failed == true)
				{
					Player1ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				}

				//OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);

			} // end of if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

			if (StopFurtherExploration == true)
			{
				goto GameTreeExplorationFinished;
			}
		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	} // end of else if (MaxSearchDepth > 2)


GameTreeExplorationFinished:;

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID, 1);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);


}

/*
void CDepthFirstSearchAI::Execute_Player1AI_EarlyOut(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, int32_t minAcceptableEvaluationValue)
{
	StopFurtherExploration = false;

	MinAcceptableEvalValueEarlyOut = minAcceptableEvaluationValue;

	EarlyOutCounter = 0;

	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t RootGameStateID = -1;
	CGameStateValues* pRootGameStateObject = nullptr;

	GameStatePool.Get_UnusedGameStateObject(0, &pRootGameStateObject, &RootGameStateID);
	pRootGameStateObject->Clone_GameStateValues(pInActualGameState);
	pRootGameStateObject->Use_As_Maximizer();

	CTestMove* pTestMove = &pTestMoveArray[1];

	if (MaxSearchDepth == 2)
	{
		int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

		//for (int32_t i = 0; i < GameBoardSizeXY; i++)
		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			//pTestMove->BoardPosID = pBoardPosIDArray[i];
			pTestMove->MoveID = j;

			//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			for (int32_t i = 0; i < GameBoardSizeXY; i++)
			{
				//pTestMove->MoveID = j;
				pTestMove->BoardPosID = pBoardPosIDArray[i];

				if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
				{
					CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

					bool TestMoveDepth2Failed = Player1AI_InnerEvalulationLoop(pGameStateObjectDepth1, 1, 2);

					if (TestMoveDepth2Failed == true)
					{
						Player1ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
					}

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);

					if (pGameStateObjectDepth1->iEvaluation >= MinAcceptableEvalValueEarlyOut)
					{
						EarlyOutCounter++;
						goto StopEvaluationPlayer1A;
					}
				} // end of if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

				if (StopFurtherExploration == true)
				{
					goto StopEvaluationPlayer1A;
				}

			} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	StopEvaluationPlayer1A:;

	} // end of if (MaxSearchDepth == 2)
	else if (MaxSearchDepth > 2)
	{
		int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

		//for (int32_t i = 0; i < GameBoardSizeXY; i++)
		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			//pTestMove->BoardPosID = pBoardPosIDArray[i];
			pTestMove->MoveID = j;

			//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			for (int32_t i = 0; i < GameBoardSizeXY; i++)
			{
				//pTestMove->MoveID = j;
				pTestMove->BoardPosID = pBoardPosIDArray[i];

				if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
				{
					CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

					bool TestMoveDepth2Failed = Player1AI_OuterEvalulationLoop_EarlyOut(pGameStateObjectDepth1, 1, 2);

					if (TestMoveDepth2Failed == true)
					{
						Player1ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
					}

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);

					if (pGameStateObjectDepth1->iEvaluation >= MinAcceptableEvalValueEarlyOut)
					{
						EarlyOutCounter++;
						goto StopEvaluationPlayer1B;
					}
				} // end of if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

				if (StopFurtherExploration == true)
				{
					goto StopEvaluationPlayer1B;
				}

			} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	StopEvaluationPlayer1B:;

	} // end of else if (MaxSearchDepth > 2)



	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID, 1);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

	Add_To_Log(0, "EarlyOutCounter", EarlyOutCounter);
}
*/

void CDepthFirstSearchAI::Execute_Player1AI_EarlyOut(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, int32_t minAcceptableEvalValuePlayer1)
{
	StopFurtherExploration = false;

	MinAcceptableEvalValueEarlyOut = minAcceptableEvalValuePlayer1;

	EarlyOutCounter = 0;

	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t RootGameStateID = -1;
	CGameStateValues* pRootGameStateObject = nullptr;

	GameStatePool.Get_UnusedGameStateObject(0, &pRootGameStateObject, &RootGameStateID);
	pRootGameStateObject->Clone_GameStateValues(pInActualGameState);
	pRootGameStateObject->Use_As_Maximizer();

	CTestMove* pTestMove = &pTestMoveArray[1];

	if (MaxSearchDepth == 2)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;

			if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				bool TestMoveDepth2Failed = Player1AI_InnerEvalulationLoop(pGameStateObjectDepth1, 1, 2);

				if (TestMoveDepth2Failed == true)
				{
					Player1ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				}

				//OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);

				/*if (pGameStateObjectDepth1->iEvaluation >= MinAcceptableEvalValueEarlyOut)
				{
					EarlyOutCounter++;
					goto StopEvaluationPlayer1A;
				}*/
			} // end of if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

			if (StopFurtherExploration == true)
			{
				goto StopEvaluationPlayer1A;
			}
		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)

	StopEvaluationPlayer1A:;

	} // end of if (MaxSearchDepth == 2)
	else if (MaxSearchDepth > 2)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;

			if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				bool TestMoveDepth2Failed = Player1AI_OuterEvalulationLoop_EarlyOut(pGameStateObjectDepth1, 1, 2);

				if (TestMoveDepth2Failed == true)
				{
					Player1ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				}

				//OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);

				if (pGameStateObjectDepth1->iEvaluation >= MinAcceptableEvalValueEarlyOut)
				{
					EarlyOutCounter++;
					goto StopEvaluationPlayer1B;
				}
			} // end of if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

			if (StopFurtherExploration == true)
			{
				goto StopEvaluationPlayer1B;
			}
		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)

	StopEvaluationPlayer1B:;

	} // end of else if (MaxSearchDepth > 2)



	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID, 1);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

	Add_To_Log(0, "EarlyOutCounter", EarlyOutCounter);
}

void CDepthFirstSearchAI::Execute_Player1AI_EarlyOut_DiscardInsufficientStates(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, int32_t minAcceptableEvalValuePlayer1, int32_t minTolerableEvalValuePlayer1, int32_t minTolerableEvalValuePlayer2)
{
	StopFurtherExploration = false;

	MinAcceptableEvalValueEarlyOut = minAcceptableEvalValuePlayer1;
	Set_MinTolerableEvaluationValues(minTolerableEvalValuePlayer1, minTolerableEvalValuePlayer2);

	EarlyOutCounter = 0;
	g_NumOfGameStatesWithTooLowEvalValues = 0;

	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t RootGameStateID = -1;
	CGameStateValues* pRootGameStateObject = nullptr;

	GameStatePool.Get_UnusedGameStateObject(0, &pRootGameStateObject, &RootGameStateID);
	pRootGameStateObject->Clone_GameStateValues(pInActualGameState);
	pRootGameStateObject->Use_As_Maximizer();

	CTestMove* pTestMove = &pTestMoveArray[1];

	if (MaxSearchDepth == 2)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;

			if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				bool TestMoveDepth2Failed = Player1AI_InnerEvalulationLoop(pGameStateObjectDepth1, 1, 2);

				if (TestMoveDepth2Failed == true)
				{
					Player1ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				}

				//OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);

				/*if (pGameStateObjectDepth1->iEvaluation >= MinAcceptableEvalValueEarlyOut)
				{
					EarlyOutCounter++;
					goto StopEvaluationPlayer1A;
				}*/
			} // end of if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

			if (StopFurtherExploration == true)
			{
				goto StopEvaluationPlayer1A;
			}
		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)

	StopEvaluationPlayer1A:;

	} // end of if (MaxSearchDepth == 2)
	else if (MaxSearchDepth > 2)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;

			if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				bool TestMoveDepth2Failed = Player1AI_OuterEvalulationLoop_EarlyOut_DiscardInsufficientStates(pGameStateObjectDepth1, 1, 2);

				if (TestMoveDepth2Failed == true)
				{
					Player1ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				}

				//OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);

				if (pGameStateObjectDepth1->iEvaluation >= MinAcceptableEvalValueEarlyOut)
				{
					EarlyOutCounter++;
					goto StopEvaluationPlayer1B;
				}
			} // end of if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

			if (StopFurtherExploration == true)
			{
				goto StopEvaluationPlayer1B;
			}
		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)

	StopEvaluationPlayer1B:;

	} // end of else if (MaxSearchDepth > 2)



	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID, 1);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

	Add_To_Log(0, "EarlyOutCounter", EarlyOutCounter);
	Add_To_Log(0, "g_NumOfGameStatesWithTooLowEvalValues", g_NumOfGameStatesWithTooLowEvalValues);
}

/*
void CDepthFirstSearchAI::Execute_Player1AI_Ext(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, float minAcceptableEvaluationValue)
{
	StopFurtherExploration = false;

	g_NumOfGameStatesWithTooLowEvalValues = 0;

	Set_MinAcceptableEvaluationValue(minAcceptableEvaluationValue);

	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t RootGameStateID = -1;
	CGameStateValues* pRootGameStateObject = nullptr;

	GameStatePool.Get_UnusedGameStateObject(0, &pRootGameStateObject, &RootGameStateID);
	pRootGameStateObject->Clone_GameStateValues(pInActualGameState);
	pRootGameStateObject->Use_As_Maximizer();

	CTestMove* pTestMove = &pTestMoveArray[1];

	if (MaxSearchDepth == 2)
	{
		int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

		//for (int32_t i = 0; i < GameBoardSizeXY; i++)
		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			//pTestMove->BoardPosID = pBoardPosIDArray[i];
			pTestMove->MoveID = j;

			//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			for (int32_t i = 0; i < GameBoardSizeXY; i++)
			{
				//pTestMove->MoveID = j;
				pTestMove->BoardPosID = pBoardPosIDArray[i];

				if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
				{
					CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

					bool TestMoveDepth2Failed = Player1AI_InnerEvalulationLoop(pGameStateObjectDepth1, 1, 2);

					if (TestMoveDepth2Failed == true)
					{
						Player1ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
					}

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);

				} // end of if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

				if (StopFurtherExploration == true)
				{
					goto GameTreeExplorationFinished;
				}

			} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	} // end of if (MaxSearchDepth == 2)
	else if (MaxSearchDepth > 2)
	{
		int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

		//for (int32_t i = 0; i < GameBoardSizeXY; i++)
		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			//pTestMove->BoardPosID = pBoardPosIDArray[i];
			pTestMove->MoveID = j;

			//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			for (int32_t i = 0; i < GameBoardSizeXY; i++)
			{
				//pTestMove->MoveID = j;
				pTestMove->BoardPosID = pBoardPosIDArray[i];

				if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
				{
					CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

					bool TestMoveDepth2Failed = Player1AI_OuterEvalulationLoop_Ext(pGameStateObjectDepth1, 1, 2);

					if (TestMoveDepth2Failed == true)
					{
						Player1ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
					}

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);

				} // end of if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

				if (StopFurtherExploration == true)
				{
					goto GameTreeExplorationFinished;
				}

			} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	} // end of else if (MaxSearchDepth > 2)

GameTreeExplorationFinished:;

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID, 1);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

	Add_To_Log(0, "g_NumOfGameStatesWithTooLowEvalValues", g_NumOfGameStatesWithTooLowEvalValues);
}
*/

void CDepthFirstSearchAI::Execute_Player1AI_DiscardInsufficientStates(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, int32_t minTolerableEvalValuePlayer1, int32_t minTolerableEvalValuePlayer2)
{
	StopFurtherExploration = false;

	g_NumOfGameStatesWithTooLowEvalValues = 0;

	Set_MinTolerableEvaluationValues(minTolerableEvalValuePlayer1, minTolerableEvalValuePlayer2);

	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t RootGameStateID = -1;
	CGameStateValues* pRootGameStateObject = nullptr;

	GameStatePool.Get_UnusedGameStateObject(0, &pRootGameStateObject, &RootGameStateID);
	pRootGameStateObject->Clone_GameStateValues(pInActualGameState);
	pRootGameStateObject->Use_As_Maximizer();

	CTestMove* pTestMove = &pTestMoveArray[1];

	if (MaxSearchDepth == 2)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;

			if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				bool TestMoveDepth2Failed = Player1AI_InnerEvalulationLoop(pGameStateObjectDepth1, 1, 2);

				if (TestMoveDepth2Failed == true)
				{
					Player1ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				}

				//OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);

			} // end of if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

			if (StopFurtherExploration == true)
			{
				goto GameTreeExplorationFinished;
			}
		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	} // end of if (MaxSearchDepth == 2)
	else if (MaxSearchDepth > 2)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;

			if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				bool TestMoveDepth2Failed = Player1AI_OuterEvalulationLoop_DiscardInsufficientStates(pGameStateObjectDepth1, 1, 2);

				if (TestMoveDepth2Failed == true)
				{
					Player1ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				}

				//OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);

			} // end of if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

			if (StopFurtherExploration == true)
			{
				goto GameTreeExplorationFinished;
			}
		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	} // end of else if (MaxSearchDepth > 2)

GameTreeExplorationFinished:;

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID, 1);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

	Add_To_Log(0, "g_NumOfGameStatesWithTooLowEvalValues", g_NumOfGameStatesWithTooLowEvalValues);
}

/*
void CDepthFirstSearchAI::Execute_Player2AI(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState)
{
	StopFurtherExploration = false;

	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t RootGameStateID = -1;
	CGameStateValues* pRootGameStateObject = nullptr;

	GameStatePool.Get_UnusedGameStateObject(0, &pRootGameStateObject, &RootGameStateID);
	pRootGameStateObject->Clone_GameStateValues(pInActualGameState);
	pRootGameStateObject->Use_As_Maximizer();

	CTestMove* pTestMove = &pTestMoveArray[1];

	if (MaxSearchDepth == 2)
	{
		int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

		//for (int32_t i = 0; i < GameBoardSizeXY; i++)
		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			//pTestMove->BoardPosID = pBoardPosIDArray[i];
			pTestMove->MoveID = j;

			//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			for (int32_t i = 0; i < GameBoardSizeXY; i++)
			{
				//pTestMove->MoveID = j;
				pTestMove->BoardPosID = pBoardPosIDArray[i];

				if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
				{
					CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

					bool TestMoveDepth2Failed = Player2AI_InnerEvalulationLoop(pGameStateObjectDepth1, 0, 2);

					if (TestMoveDepth2Failed == true)
					{
						Player2ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
					}

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);

				} // end of if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

				if (StopFurtherExploration == true)
				{
					goto GameTreeExplorationFinished;
				}

			} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	} // end of if (MaxSearchDepth == 2)
	else if (MaxSearchDepth > 2)
	{
		int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

		//for (int32_t i = 0; i < GameBoardSizeXY; i++)
		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			//pTestMove->BoardPosID = pBoardPosIDArray[i];
			pTestMove->MoveID = j;

			//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			for (int32_t i = 0; i < GameBoardSizeXY; i++)
			{
				//pTestMove->MoveID = j;
				pTestMove->BoardPosID = pBoardPosIDArray[i];

				if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
				{
					CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

					bool TestMoveDepth2Failed = Player2AI_OuterEvalulationLoop(pGameStateObjectDepth1, 0, 2);

					if (TestMoveDepth2Failed == true)
					{
						Player2ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
					}

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);

				} // end of if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

				if (StopFurtherExploration == true)
				{
					goto GameTreeExplorationFinished;
				}

			} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	} // end of else if (MaxSearchDepth > 2)

GameTreeExplorationFinished:;

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID, 1);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

	
}
*/

void CDepthFirstSearchAI::Execute_Player2AI(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState)
{
	StopFurtherExploration = false;

	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t RootGameStateID = -1;
	CGameStateValues* pRootGameStateObject = nullptr;

	GameStatePool.Get_UnusedGameStateObject(0, &pRootGameStateObject, &RootGameStateID);
	pRootGameStateObject->Clone_GameStateValues(pInActualGameState);
	pRootGameStateObject->Use_As_Maximizer();

	CTestMove* pTestMove = &pTestMoveArray[1];

	int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

	if (MaxSearchDepth == 2)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;

			if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				bool TestMoveDepth2Failed = Player2AI_InnerEvalulationLoop(pGameStateObjectDepth1, 0, 2);

				if (TestMoveDepth2Failed == true)
				{
					Player2ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				}

				//OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);

			} // end of if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

			if (StopFurtherExploration == true)
			{
				goto GameTreeExplorationFinished;
			}
		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	} // end of if (MaxSearchDepth == 2)
	else if (MaxSearchDepth > 2)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;

			if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				bool TestMoveDepth2Failed = Player2AI_OuterEvalulationLoop(pGameStateObjectDepth1, 0, 2);

				if (TestMoveDepth2Failed == true)
				{
					Player2ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				}

				//OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);

			} // end of if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

			if (StopFurtherExploration == true)
			{
				goto GameTreeExplorationFinished;
			}
		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	} // end of else if (MaxSearchDepth > 2)

GameTreeExplorationFinished:;

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID, 1);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);
	//pOutNewGameState->Clone_Data(pGameStateObject);
	//Add_To_Log(0, "eval", pOutNewGameState->iEvaluation);
}

/*
void CDepthFirstSearchAI::Execute_Player2AI_EarlyOut(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, int32_t minAcceptableEvaluationValue)
{
	StopFurtherExploration = false;

	iMinAcceptableEvalValueEarlyOut = minAcceptableEvaluationValue;

	EarlyOutCounter = 0;

	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t RootGameStateID = -1;
	CGameStateValues* pRootGameStateObject = nullptr;

	GameStatePool.Get_UnusedGameStateObject(0, &pRootGameStateObject, &RootGameStateID);
	pRootGameStateObject->Clone_GameStateValues(pInActualGameState);
	pRootGameStateObject->Use_As_Maximizer();

	CTestMove* pTestMove = &pTestMoveArray[1];

	if (MaxSearchDepth == 2)
	{
		int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

		//for (int32_t i = 0; i < GameBoardSizeXY; i++)
		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			//pTestMove->BoardPosID = pBoardPosIDArray[i];
			pTestMove->MoveID = j;

			//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			for (int32_t i = 0; i < GameBoardSizeXY; i++)
			{
				//pTestMove->MoveID = j;
				pTestMove->BoardPosID = pBoardPosIDArray[i];

				if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
				{
					CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

					bool TestMoveDepth2Failed = Player2AI_InnerEvalulationLoop(pGameStateObjectDepth1, 0, 2);

					if (TestMoveDepth2Failed == true)
					{
						Player2ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
					}

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);

					if (pGameStateObjectDepth1->iEvaluation >= iMinAcceptableEvalValueEarlyOut)
					{
						EarlyOutCounter++;
						goto StopEvaluationPlayer2A;
					}
				} // end of if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

				if (StopFurtherExploration == true)
				{
					goto StopEvaluationPlayer2A;
				}

			} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	StopEvaluationPlayer2A:;

	} // end of if (MaxSearchDepth == 2)
	else if (MaxSearchDepth > 2)
	{
		int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

		//for (int32_t i = 0; i < GameBoardSizeXY; i++)
		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			//pTestMove->BoardPosID = pBoardPosIDArray[i];
			pTestMove->MoveID = j;

			//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			for (int32_t i = 0; i < GameBoardSizeXY; i++)
			{
				//pTestMove->MoveID = j;
				pTestMove->BoardPosID = pBoardPosIDArray[i];

				if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
				{
					CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

					bool TestMoveDepth2Failed = Player2AI_OuterEvalulationLoop_EarlyOut(pGameStateObjectDepth1, 0, 2);

					if (TestMoveDepth2Failed == true)
					{
						Player2ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
					}

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);

					if (pGameStateObjectDepth1->iEvaluation >= iMinAcceptableEvalValueEarlyOut)
					{
						EarlyOutCounter++;
						goto StopEvaluationPlayer2B;
					}
				} // end of if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

				if (StopFurtherExploration == true)
				{
					goto StopEvaluationPlayer2B;
				}

			} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	StopEvaluationPlayer2B:;

	} // end of else if (MaxSearchDepth > 2)


	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID, 1);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

	Add_To_Log(0, "EarlyOutCounter", EarlyOutCounter);
}
*/

void CDepthFirstSearchAI::Execute_Player2AI_EarlyOut(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, int32_t minAcceptableEvalValuePlayer2)
{
	StopFurtherExploration = false;

	MinAcceptableEvalValueEarlyOut = minAcceptableEvalValuePlayer2;

	EarlyOutCounter = 0;

	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t RootGameStateID = -1;
	CGameStateValues* pRootGameStateObject = nullptr;

	GameStatePool.Get_UnusedGameStateObject(0, &pRootGameStateObject, &RootGameStateID);
	pRootGameStateObject->Clone_GameStateValues(pInActualGameState);
	pRootGameStateObject->Use_As_Maximizer();

	CTestMove* pTestMove = &pTestMoveArray[1];

	if (MaxSearchDepth == 2)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;

			if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				bool TestMoveDepth2Failed = Player2AI_InnerEvalulationLoop(pGameStateObjectDepth1, 0, 2);

				if (TestMoveDepth2Failed == true)
				{
					Player2ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				}

				//OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);

				/*if (pGameStateObjectDepth1->iEvaluation >= MinAcceptableEvalValueEarlyOut)
				{
					EarlyOutCounter++;
					goto StopEvaluationPlayer2A;
				}*/
			} // end of if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

			if (StopFurtherExploration == true)
			{
				goto StopEvaluationPlayer2A;
			}
		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)

	StopEvaluationPlayer2A:;

	} // end of if (MaxSearchDepth == 2)
	else if (MaxSearchDepth > 2)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;

			if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				bool TestMoveDepth2Failed = Player2AI_OuterEvalulationLoop_EarlyOut(pGameStateObjectDepth1, 0, 2);

				if (TestMoveDepth2Failed == true)
				{
					Player2ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				}

				//OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);

				if (pGameStateObjectDepth1->iEvaluation >= MinAcceptableEvalValueEarlyOut)
				{
					EarlyOutCounter++;
					goto StopEvaluationPlayer2B;
				}
			} // end of if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

			if (StopFurtherExploration == true)
			{
				goto StopEvaluationPlayer2B;
			}
		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)

	StopEvaluationPlayer2B:;

	} // end of else if (MaxSearchDepth > 2)


	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID, 1);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

	Add_To_Log(0, "EarlyOutCounter", EarlyOutCounter);
}

void CDepthFirstSearchAI::Execute_Player2AI_EarlyOut_DiscardInsufficientStates(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, int32_t minAcceptableEvalValuePlayer2, int32_t minTolerableEvalValuePlayer1, int32_t minTolerableEvalValuePlayer2)
{
	StopFurtherExploration = false;

	MinAcceptableEvalValueEarlyOut = minAcceptableEvalValuePlayer2;
	Set_MinTolerableEvaluationValues(minTolerableEvalValuePlayer1, minTolerableEvalValuePlayer2);

	EarlyOutCounter = 0;
	g_NumOfGameStatesWithTooLowEvalValues = 0;

	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t RootGameStateID = -1;
	CGameStateValues* pRootGameStateObject = nullptr;

	GameStatePool.Get_UnusedGameStateObject(0, &pRootGameStateObject, &RootGameStateID);
	pRootGameStateObject->Clone_GameStateValues(pInActualGameState);
	pRootGameStateObject->Use_As_Maximizer();

	CTestMove* pTestMove = &pTestMoveArray[1];

	if (MaxSearchDepth == 2)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;

			if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				bool TestMoveDepth2Failed = Player2AI_InnerEvalulationLoop(pGameStateObjectDepth1, 0, 2);

				if (TestMoveDepth2Failed == true)
				{
					Player2ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				}

				//OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);

				/*if (pGameStateObjectDepth1->iEvaluation >= MinAcceptableEvalValueEarlyOut)
				{
					EarlyOutCounter++;
					goto StopEvaluationPlayer2A;
				}*/
			} // end of if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

			if (StopFurtherExploration == true)
			{
				goto StopEvaluationPlayer2A;
			}
		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)

	StopEvaluationPlayer2A:;

	} // end of if (MaxSearchDepth == 2)
	else if (MaxSearchDepth > 2)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;

			if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				bool TestMoveDepth2Failed = Player2AI_OuterEvalulationLoop_EarlyOut_DiscardInsufficientStates(pGameStateObjectDepth1, 0, 2);

				if (TestMoveDepth2Failed == true)
				{
					Player2ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				}

				//OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);

				if (pGameStateObjectDepth1->iEvaluation >= MinAcceptableEvalValueEarlyOut)
				{
					EarlyOutCounter++;
					goto StopEvaluationPlayer2B;
				}
			} // end of if (pTestMove->Make_Player1Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

			if (StopFurtherExploration == true)
			{
				goto StopEvaluationPlayer2B;
			}
		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)

	StopEvaluationPlayer2B:;

	} // end of else if (MaxSearchDepth > 2)


	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID, 1);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

	Add_To_Log(0, "EarlyOutCounter", EarlyOutCounter);
	Add_To_Log(0, "g_NumOfGameStatesWithTooLowEvalValues", g_NumOfGameStatesWithTooLowEvalValues);
}

/*
void CDepthFirstSearchAI::Execute_Player2AI_Ext(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, float minAcceptableEvaluationValue)
{
	StopFurtherExploration = false;

	g_NumOfGameStatesWithTooLowEvalValues = 0;

	Set_MinAcceptableEvaluationValue(minAcceptableEvaluationValue);

	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t RootGameStateID = -1;
	CGameStateValues* pRootGameStateObject = nullptr;

	GameStatePool.Get_UnusedGameStateObject(0, &pRootGameStateObject, &RootGameStateID);
	pRootGameStateObject->Clone_GameStateValues(pInActualGameState);
	pRootGameStateObject->Use_As_Maximizer();

	CTestMove* pTestMove = &pTestMoveArray[1];

	if (MaxSearchDepth == 2)
	{
		int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

		//for (int32_t i = 0; i < GameBoardSizeXY; i++)
		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			//pTestMove->BoardPosID = pBoardPosIDArray[i];
			pTestMove->MoveID = j;

			//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			for (int32_t i = 0; i < GameBoardSizeXY; i++)
			{
				//pTestMove->MoveID = j;
				pTestMove->BoardPosID = pBoardPosIDArray[i];

				if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
				{
					CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

					bool TestMoveDepth2Failed = Player2AI_InnerEvalulationLoop(pGameStateObjectDepth1, 0, 2);

					if (TestMoveDepth2Failed == true)
					{
						Player2ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
					}

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);

				} // end of if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

				if (StopFurtherExploration == true)
				{
					goto GameTreeExplorationFinished;
				}

			} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	} // end of if (MaxSearchDepth == 2)
	else if (MaxSearchDepth > 2)
	{
		int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

		//for (int32_t i = 0; i < GameBoardSizeXY; i++)
		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			//pTestMove->BoardPosID = pBoardPosIDArray[i];
			pTestMove->MoveID = j;

			//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			for (int32_t i = 0; i < GameBoardSizeXY; i++)
			{
				//pTestMove->MoveID = j;
				pTestMove->BoardPosID = pBoardPosIDArray[i];

				if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
				{
					CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

					bool TestMoveDepth2Failed = Player2AI_OuterEvalulationLoop_Ext(pGameStateObjectDepth1, 0, 2);

					if (TestMoveDepth2Failed == true)
					{
						Player2ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
					}

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);

				} // end of if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

				if (StopFurtherExploration == true)
				{
					goto GameTreeExplorationFinished;
				}

			} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)
	} // end of else if (MaxSearchDepth > 2)

GameTreeExplorationFinished:;

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID, 1);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

	Add_To_Log(0, "g_NumOfGameStatesWithTooLowEvalValues", g_NumOfGameStatesWithTooLowEvalValues);
}
*/


void CDepthFirstSearchAI::Execute_Player2AI_DiscardInsufficientStates(CGameStateValues* pOutNewGameState, CGameStateValues* pInActualGameState, int32_t minTolerableEvalValuePlayer1, int32_t minTolerableEvalValuePlayer2)
{
	StopFurtherExploration = false;

	g_NumOfGameStatesWithTooLowEvalValues = 0;

	Set_MinTolerableEvaluationValues(minTolerableEvalValuePlayer1, minTolerableEvalValuePlayer2);

	GameStatePool.Stop_Using_AllGameStateObjects();

	int32_t RootGameStateID = -1;
	CGameStateValues* pRootGameStateObject = nullptr;

	GameStatePool.Get_UnusedGameStateObject(0, &pRootGameStateObject, &RootGameStateID);
	pRootGameStateObject->Clone_GameStateValues(pInActualGameState);
	pRootGameStateObject->Use_As_Maximizer();

	CTestMove* pTestMove = &pTestMoveArray[1];

	if (MaxSearchDepth == 2)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;

			if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				bool TestMoveDepth2Failed = Player2AI_InnerEvalulationLoop(pGameStateObjectDepth1, 0, 2);

				if (TestMoveDepth2Failed == true)
				{
					Player2ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				}

				//OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);

			} // end of if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

			if (StopFurtherExploration == true)
			{
				goto GameTreeExplorationFinished;
			}
		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	} // end of if (MaxSearchDepth == 2)
	else if (MaxSearchDepth > 2)
	{
		for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
		{
			pTestMove->BoardPosID = pMoveDescValuesArray[i].BoardPosID;
			pTestMove->MoveID = pMoveDescValuesArray[i].MoveID;

			if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)
			{
				CGameStateValues* pGameStateObjectDepth1 = &GameStatePool.pGameStateArray[pTestMove->ResultingGameStateObjectID];

				bool TestMoveDepth2Failed = Player2AI_OuterEvalulationLoop_DiscardInsufficientStates(pGameStateObjectDepth1, 0, 2);

				if (TestMoveDepth2Failed == true)
				{
					Player2ViewGameStateEvalFunc(pGameStateObjectDepth1->IDofGameState, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
				}

				//OneStepBackpropagate_MinimaxIntegerEvaluationValues(pGameStateObjectDepth1->IDofGameState, &GameStatePool);

			} // end of if (pTestMove->Make_Player2Move_If_Possible(pRootGameStateObject, &GameStatePool, 1, false) > 0)

			if (StopFurtherExploration == true)
			{
				goto GameTreeExplorationFinished;
			}
		} // end of for (int32_t i = 0; i < NumOfMoveDescriptions; i++)
	} // end of else if (MaxSearchDepth > 2)

GameTreeExplorationFinished:;

	CGameStateValues* pGameStateObject = nullptr;
	int32_t GameStateObjectID = -1;
	GameStatePool.Get_Best_GameState_IntegerEvaluation(&pGameStateObject, &GameStateObjectID, 1);

	pOutNewGameState->Clone_GameStateValues(pGameStateObject);

	Add_To_Log(0, "g_NumOfGameStatesWithTooLowEvalValues", g_NumOfGameStatesWithTooLowEvalValues);
}


bool CDepthFirstSearchAI::Player1AI_InnerEvalulationLoop(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth)
{
	CTestMove* pTestMove = &pTestMoveArray[depth];

	if (playerID == 0)
	{
		int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

		bool TestMovesFailed = true;

		int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

		//for (int32_t i = 0; i < GameBoardSizeXY; i++)
		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			//pTestMove->BoardPosID = i;
			pTestMove->MoveID = j;

			//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			for (int32_t i = 0; i < GameBoardSizeXY; i++)
			{
				//pTestMove->MoveID = j;
				pTestMove->BoardPosID = i;

				if (pTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)
				{
					TestMovesFailed = false;

					int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
					Player1ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
					if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
					{
						//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
						goto StopEvaluationPlayer1;
					}
#endif
				} // end of if (pTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)

				if (StopFurtherExploration == true)
				{
					goto StopEvaluationPlayer1;
				}

			} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	StopEvaluationPlayer1:;

		return TestMovesFailed;

	} // end of if (playerID == 0)
	else //if (playerID == 1)
	{
		int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

		bool TestMovesFailed = true;

		int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

		//for (int32_t i = 0; i < GameBoardSizeXY; i++)
		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			//pTestMove->BoardPosID = i;
			pTestMove->MoveID = j;

			//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			for (int32_t i = 0; i < GameBoardSizeXY; i++)
			{
				//pTestMove->MoveID = j;
				pTestMove->BoardPosID = i;

				if (pTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)
				{
					TestMovesFailed = false;

					int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
					Player1ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
					if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
					{
						//Add_To_Log(0, "PrevMaximizerEvalValue >= pInActualGameState->iEvaluation");
						goto StopEvaluationPlayer2;
					}
#endif
				} // end of if (pTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)

				if (StopFurtherExploration == true)
				{
					goto StopEvaluationPlayer2;
				}

			} // for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	StopEvaluationPlayer2:;

		return TestMovesFailed;

	} // end of else //if (playerID == 1)

	return false;
}

bool CDepthFirstSearchAI::Player1AI_InnerEvalulationLoop_DiscardInsufficientStates(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth)
{
	CTestMove* pTestMove = &pTestMoveArray[depth];

	if (playerID == 0)
	{
		int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

		bool TestMovesFailed = true;

		int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

		//for (int32_t i = 0; i < GameBoardSizeXY; i++)
		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			//pTestMove->BoardPosID = i;
			pTestMove->MoveID = j;

			//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			for (int32_t i = 0; i < GameBoardSizeXY; i++)
			{
				//pTestMove->MoveID = j;
				pTestMove->BoardPosID = i;

				//if (pTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)
				if (pTestMove->Make_Player1Move_If_Possible_DiscardInsufficientStates(pInActualGameState, &GameStatePool, depth, false) > 0)
				{
					TestMovesFailed = false;

					int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
					Player1ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
					if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
					{
						//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
						goto StopEvaluationPlayer1;
					}
#endif
				} // end of if (pTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)

				if (StopFurtherExploration == true)
				{
					goto StopEvaluationPlayer1;
				}

			} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	StopEvaluationPlayer1:;

		return TestMovesFailed;

	} // end of if (playerID == 0)
	else //if (playerID == 1)
	{
		int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

		bool TestMovesFailed = true;

		int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

		//for (int32_t i = 0; i < GameBoardSizeXY; i++)
		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			//pTestMove->BoardPosID = i;
			pTestMove->MoveID = j;

			//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			for (int32_t i = 0; i < GameBoardSizeXY; i++)
			{
				//pTestMove->MoveID = j;
				pTestMove->BoardPosID = i;

				//if (pTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)
				if (pTestMove->Make_Player2Move_If_Possible_DiscardInsufficientStates(pInActualGameState, &GameStatePool, depth, true) > 0)
				{
					TestMovesFailed = false;

					int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
					Player1ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
					if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
					{
						//Add_To_Log(0, "PrevMaximizerEvalValue >= pInActualGameState->iEvaluation");
						goto StopEvaluationPlayer2;
					}
#endif
				} // end of if (pTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)

				if (StopFurtherExploration == true)
				{
					goto StopEvaluationPlayer2;
				}

			} // for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	StopEvaluationPlayer2:;

		return TestMovesFailed;

	} // end of else //if (playerID == 1)

	return false;
}

bool CDepthFirstSearchAI::Player1AI_InnerEvalulationLoop_EarlyOut(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth)
{
	CTestMove* pTestMove = &pTestMoveArray[depth];

	if (playerID == 0)
	{
		int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

		bool TestMovesFailed = true;

		int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

		//for (int32_t i = 0; i < GameBoardSizeXY; i++)
		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			//pTestMove->BoardPosID = i;
			pTestMove->MoveID = j;

			//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			for (int32_t i = 0; i < GameBoardSizeXY; i++)
			{
				//pTestMove->MoveID = j;
				pTestMove->BoardPosID = i;

				if (pTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)
				{
					TestMovesFailed = false;

					int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
					Player1ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);

					int32_t evalValue = GameStatePool.pGameStateArray[resultingGameStateObjectID].iEvaluation;

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

					if (evalValue >= MinAcceptableEvalValueEarlyOut)
					{
						EarlyOutCounter++;
						goto StopEvaluationPlayer1;
					}

#ifdef PRUNING
					if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
					{
						//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
						goto StopEvaluationPlayer1;
					}
#endif
				} // end of if (pTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)

				if (StopFurtherExploration == true)
				{
					goto StopEvaluationPlayer1;
				}

			} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	StopEvaluationPlayer1:;

		return TestMovesFailed;

	} // end of if (playerID == 0)
	else //if (playerID == 1)
	{
		int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

		bool TestMovesFailed = true;

		int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

		//for (int32_t i = 0; i < GameBoardSizeXY; i++)
		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			//pTestMove->BoardPosID = i;
			pTestMove->MoveID = j;

			//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			for (int32_t i = 0; i < GameBoardSizeXY; i++)
			{
				//pTestMove->MoveID = j;
				pTestMove->BoardPosID = i;

				if (pTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)
				{
					TestMovesFailed = false;

					int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
					Player1ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
					if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
					{
						//Add_To_Log(0, "PrevMaximizerEvalValue >= pInActualGameState->iEvaluation");
						goto StopEvaluationPlayer2;
					}
#endif
				}  // end of if (pTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)

				if (StopFurtherExploration == true)
				{
					goto StopEvaluationPlayer2;
				}

			} // for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	StopEvaluationPlayer2:;

		return TestMovesFailed;

	} // end of else //if (playerID == 1)

	return false;
}

bool CDepthFirstSearchAI::Player1AI_InnerEvalulationLoop_EarlyOut_DiscardInsufficientStates(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth)
{
	CTestMove* pTestMove = &pTestMoveArray[depth];

	if (playerID == 0)
	{
		int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

		bool TestMovesFailed = true;

		int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

		//for (int32_t i = 0; i < GameBoardSizeXY; i++)
		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			//pTestMove->BoardPosID = i;
			pTestMove->MoveID = j;

			//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			for (int32_t i = 0; i < GameBoardSizeXY; i++)
			{
				//pTestMove->MoveID = j;
				pTestMove->BoardPosID = i;

				if (pTestMove->Make_Player1Move_If_Possible_DiscardInsufficientStates(pInActualGameState, &GameStatePool, depth, false) > 0)
				{
					TestMovesFailed = false;

					int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
					Player1ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);

					int32_t evalValue = GameStatePool.pGameStateArray[resultingGameStateObjectID].iEvaluation;

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

					if (evalValue >= MinAcceptableEvalValueEarlyOut)
					{
						EarlyOutCounter++;
						goto StopEvaluationPlayer1;
					}

#ifdef PRUNING
					if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
					{
						//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
						goto StopEvaluationPlayer1;
					}
#endif
				} // end of if (pTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)

				if (StopFurtherExploration == true)
				{
					goto StopEvaluationPlayer1;
				}

			} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	StopEvaluationPlayer1:;

		return TestMovesFailed;

	} // end of if (playerID == 0)
	else //if (playerID == 1)
	{
		int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

		bool TestMovesFailed = true;

		int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

		//for (int32_t i = 0; i < GameBoardSizeXY; i++)
		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			//pTestMove->BoardPosID = i;
			pTestMove->MoveID = j;

			//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			for (int32_t i = 0; i < GameBoardSizeXY; i++)
			{
				//pTestMove->MoveID = j;
				pTestMove->BoardPosID = i;

				if (pTestMove->Make_Player2Move_If_Possible_DiscardInsufficientStates(pInActualGameState, &GameStatePool, depth, true) > 0)
				{
					TestMovesFailed = false;

					int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
					Player1ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
					if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
					{
						//Add_To_Log(0, "PrevMaximizerEvalValue >= pInActualGameState->iEvaluation");
						goto StopEvaluationPlayer2;
					}
#endif
				}  // end of if (pTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)

				if (StopFurtherExploration == true)
				{
					goto StopEvaluationPlayer2;
				}

			} // for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	StopEvaluationPlayer2:;

		return TestMovesFailed;

	} // end of else //if (playerID == 1)

	return false;
}

bool CDepthFirstSearchAI::Player2AI_InnerEvalulationLoop(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth)
{
	CTestMove* pTestMove = &pTestMoveArray[depth];

	if (playerID == 0)
	{
		int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

		bool TestMovesFailed = true;

		int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

		//for (int32_t i = 0; i < GameBoardSizeXY; i++)
		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			//pTestMove->BoardPosID = i;
			pTestMove->MoveID = j;

			//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			for (int32_t i = 0; i < GameBoardSizeXY; i++)
			{
				//pTestMove->MoveID = j;
				pTestMove->BoardPosID = i;

				if (pTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)
				{
					TestMovesFailed = false;

					int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
					Player2ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);


					OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
					if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
					{
						//Add_To_Log(0, "PrevMaxEvalValue >= pInActualGameState->iEvaluation");
						goto StopEvaluationPlayer1;
					}
#endif
				} // end of if (pTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)

				if (StopFurtherExploration == true)
				{
					goto StopEvaluationPlayer1;
				}

			} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	StopEvaluationPlayer1:;

		return TestMovesFailed;

	} // end of if (playerID == 0)
	else //if (playerID == 1)
	{
		int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

		bool TestMovesFailed = true;

		int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

		//for (int32_t i = 0; i < GameBoardSizeXY; i++)
		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			//pTestMove->BoardPosID = i;
			pTestMove->MoveID = j;

			//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			for (int32_t i = 0; i < GameBoardSizeXY; i++)
			{
				//pTestMove->MoveID = j;
				pTestMove->BoardPosID = i;

				if (pTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)
				{
					TestMovesFailed = false;

					int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
					Player2ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
					if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
					{
						//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
						goto StopEvaluationPlayer2;
					}
#endif
				} // end of if (pTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)

				if (StopFurtherExploration == true)
				{
					goto StopEvaluationPlayer2;
				}

			} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	StopEvaluationPlayer2:;

		return TestMovesFailed;

	} // end of else if (playerID == 1)

	return false;
}

bool CDepthFirstSearchAI::Player2AI_InnerEvalulationLoop_DiscardInsufficientStates(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth)
{
	CTestMove* pTestMove = &pTestMoveArray[depth];

	if (playerID == 0)
	{
		int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

		bool TestMovesFailed = true;

		int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

		//for (int32_t i = 0; i < GameBoardSizeXY; i++)
		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			//pTestMove->BoardPosID = i;
			pTestMove->MoveID = j;

			//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			for (int32_t i = 0; i < GameBoardSizeXY; i++)
			{
				//pTestMove->MoveID = j;
				pTestMove->BoardPosID = i;

				//if (pTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)
				if (pTestMove->Make_Player1Move_If_Possible_DiscardInsufficientStates(pInActualGameState, &GameStatePool, depth, true) > 0)
				{
					TestMovesFailed = false;

					int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
					Player2ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);


					OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
					if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
					{
						//Add_To_Log(0, "PrevMaxEvalValue >= pInActualGameState->iEvaluation");
						goto StopEvaluationPlayer1;
					}
#endif
				} // end of if (pTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)

				if (StopFurtherExploration == true)
				{
					goto StopEvaluationPlayer1;
				}

			} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	StopEvaluationPlayer1:;

		return TestMovesFailed;

	} // end of if (playerID == 0)
	else //if (playerID == 1)
	{
		int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

		bool TestMovesFailed = true;

		int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

		//for (int32_t i = 0; i < GameBoardSizeXY; i++)
		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			//pTestMove->BoardPosID = i;
			pTestMove->MoveID = j;

			//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			for (int32_t i = 0; i < GameBoardSizeXY; i++)
			{
				//pTestMove->MoveID = j;
				pTestMove->BoardPosID = i;

				//if (pTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)
				if (pTestMove->Make_Player2Move_If_Possible_DiscardInsufficientStates(pInActualGameState, &GameStatePool, depth, false) > 0)
				{
					TestMovesFailed = false;

					int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
					Player2ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
					if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
					{
						//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
						goto StopEvaluationPlayer2;
					}
#endif
				} // end of if (pTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)

				if (StopFurtherExploration == true)
				{
					goto StopEvaluationPlayer2;
				}

			} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	StopEvaluationPlayer2:;

		return TestMovesFailed;

	} // end of else //if (playerID == 1)

	return false;
}

bool CDepthFirstSearchAI::Player2AI_InnerEvalulationLoop_EarlyOut(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth)
{
	CTestMove* pTestMove = &pTestMoveArray[depth];

	if (playerID == 0)
	{
		int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

		bool TestMovesFailed = true;

		int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

		//for (int32_t i = 0; i < GameBoardSizeXY; i++)
		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			//pTestMove->BoardPosID = i;
			pTestMove->MoveID = j;

			//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			for (int32_t i = 0; i < GameBoardSizeXY; i++)
			{
				//pTestMove->MoveID = j;
				pTestMove->BoardPosID = i;

				if (pTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)
				{
					TestMovesFailed = false;

					int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
					Player2ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);


					OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
					if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
					{
						//Add_To_Log(0, "PrevMaxEvalValue >= pInActualGameState->iEvaluation");
						goto StopEvaluationPlayer1;
					}
#endif
				} // end of if (pTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)

				if (StopFurtherExploration == true)
				{
					goto StopEvaluationPlayer1;
				}

			} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	StopEvaluationPlayer1:;

		return TestMovesFailed;

	} // end of if (playerID == 0)
	else //if (playerID == 1)
	{
		int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

		bool TestMovesFailed = true;

		int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

		//for (int32_t i = 0; i < GameBoardSizeXY; i++)
		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			//pTestMove->BoardPosID = i;
			pTestMove->MoveID = j;

			//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			for (int32_t i = 0; i < GameBoardSizeXY; i++)
			{
				//pTestMove->MoveID = j;
				pTestMove->BoardPosID = i;

				if (pTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)
				{
					TestMovesFailed = false;

					int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
					Player2ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);

					int32_t evalValue = GameStatePool.pGameStateArray[resultingGameStateObjectID].iEvaluation;

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

					if (evalValue >= MinAcceptableEvalValueEarlyOut)
					{
						EarlyOutCounter++;
						goto StopEvaluationPlayer2;
					}

#ifdef PRUNING
					if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
					{
						//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
						goto StopEvaluationPlayer2;
					}
#endif
				} // end of if (pTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)

				if (StopFurtherExploration == true)
				{
					goto StopEvaluationPlayer2;
				}

			} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	StopEvaluationPlayer2:;

		return TestMovesFailed;

	} // end of else //if (playerID == 1)

	return false;
}

bool CDepthFirstSearchAI::Player2AI_InnerEvalulationLoop_EarlyOut_DiscardInsufficientStates(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth)
{
	CTestMove* pTestMove = &pTestMoveArray[depth];

	if (playerID == 0)
	{
		int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

		bool TestMovesFailed = true;

		int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

		//for (int32_t i = 0; i < GameBoardSizeXY; i++)
		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			//pTestMove->BoardPosID = i;
			pTestMove->MoveID = j;

			//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			for (int32_t i = 0; i < GameBoardSizeXY; i++)
			{
				//pTestMove->MoveID = j;
				pTestMove->BoardPosID = i;

				if (pTestMove->Make_Player1Move_If_Possible_DiscardInsufficientStates(pInActualGameState, &GameStatePool, depth, true) > 0)
				{
					TestMovesFailed = false;

					int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
					Player2ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);


					OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
					if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
					{
						//Add_To_Log(0, "PrevMaxEvalValue >= pInActualGameState->iEvaluation");
						goto StopEvaluationPlayer1;
					}
#endif
				} // end of if (pTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)

				if (StopFurtherExploration == true)
				{
					goto StopEvaluationPlayer1;
				}

			} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	StopEvaluationPlayer1:;

		return TestMovesFailed;

	} // end of if (playerID == 0)
	else //if (playerID == 1)
	{
		int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

		bool TestMovesFailed = true;

		int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

		//for (int32_t i = 0; i < GameBoardSizeXY; i++)
		for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		{
			//pTestMove->BoardPosID = i;
			pTestMove->MoveID = j;

			//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			for (int32_t i = 0; i < GameBoardSizeXY; i++)
			{
				//pTestMove->MoveID = j;
				pTestMove->BoardPosID = i;

				if (pTestMove->Make_Player2Move_If_Possible_DiscardInsufficientStates(pInActualGameState, &GameStatePool, depth, false) > 0)
				{
					TestMovesFailed = false;

					int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
					Player2ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);

					int32_t evalValue = GameStatePool.pGameStateArray[resultingGameStateObjectID].iEvaluation;

					OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
					GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

					if (evalValue >= MinAcceptableEvalValueEarlyOut)
					{
						EarlyOutCounter++;
						goto StopEvaluationPlayer2;
					}

#ifdef PRUNING
					if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
					{
						//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
						goto StopEvaluationPlayer2;
					}
#endif
				} // end of if (pTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)

				if (StopFurtherExploration == true)
				{
					goto StopEvaluationPlayer2;
				}

			} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
		} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

	StopEvaluationPlayer2:;

		return TestMovesFailed;

	} // end of else //if (playerID == 1)

	return false;
}

bool CDepthFirstSearchAI::Player1AI_OuterEvalulationLoop(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth)
{
	CTestMove* pTestMove = &pTestMoveArray[depth];

	int32_t depthPlus1 = depth + 1;


	if (depth == MaxSearchDepthMinus1)
	{
		if (playerID == 0)
		{
			int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

			//for (int32_t i = 0; i < GameBoardSizeXY; i++)
			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				//pTestMove->BoardPosID = i;
				pTestMove->MoveID = j;

				//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					//pTestMove->MoveID = j;
					pTestMove->BoardPosID = i;

					if (pTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player1AI_InnerEvalulationLoop(pResultingGameStateObject, 1, depthPlus1);

						if (TestMovesNextDepth == true)
						{
							Player1ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
						}

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
						if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer1A;
						}
#endif
					} // end of if (pTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)

					if (StopFurtherExploration == true)
					{
						goto StopEvaluationPlayer1A;
					}

				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer1A:;

			return TestMovesFailed;
		} // end of if (playerID == 0)
		else //if (playerID == 1)
		{
			int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

			//for (int32_t i = 0; i < GameBoardSizeXY; i++)
			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				//pTestMove->BoardPosID = i;
				pTestMove->MoveID = j;

				//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					//pTestMove->MoveID = j;
					pTestMove->BoardPosID = i;

					if (pTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player1AI_InnerEvalulationLoop(pResultingGameStateObject, 0, depthPlus1);

						if (TestMovesNextDepth == true)
						{
							Player1ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
						}

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
						if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMaximizerEvalValue >= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer2A;
						}
#endif
					} // end of if (pTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)

					if (StopFurtherExploration == true)
					{
						goto StopEvaluationPlayer2A;
					}

				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer2A:;

			return TestMovesFailed;
		} // end of else //if (playerID == 1)
	} // end of if (depth == MaxSearchDepthMinus1)
	else if (depth < MaxSearchDepthMinus1)
	{
		if (playerID == 0)
		{
			int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

			//for (int32_t i = 0; i < GameBoardSizeXY; i++)
			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				//pTestMove->BoardPosID = i;
				pTestMove->MoveID = j;

				//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					//pTestMove->MoveID = j;
					pTestMove->BoardPosID = i;

					if (pTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player1AI_OuterEvalulationLoop(pResultingGameStateObject, 1, depthPlus1);

						if (TestMovesNextDepth == true)
						{
							Player1ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
						}

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
						if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer1B;
						}
#endif
					} // end of if (pTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)

					if (StopFurtherExploration == true)
					{
						goto StopEvaluationPlayer1B;
					}

				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer1B:;

			return TestMovesFailed;
		} // end of if (playerID == 0)
		else //if (playerID == 1)
		{
			int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

			//for (int32_t i = 0; i < GameBoardSizeXY; i++)
			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				//pTestMove->BoardPosID = i;
				pTestMove->MoveID = j;

				//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					//pTestMove->MoveID = j;
					pTestMove->BoardPosID = i;

					if (pTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player1AI_OuterEvalulationLoop(pResultingGameStateObject, 0, depthPlus1);


						if (TestMovesNextDepth == true)
						{
							Player1ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
						}

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
						if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMaximizerEvalValue >= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer2B;
						}
#endif
					} // end of if (pTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)

					if (StopFurtherExploration == true)
					{
						goto StopEvaluationPlayer2B;
					}

				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer2B:;

			return TestMovesFailed;
		} // end of else //if (playerID == 1)
	} // end of else if (depth < MaxSearchDepthMinus1)

	return false;
}

bool CDepthFirstSearchAI::Player1AI_OuterEvalulationLoop_EarlyOut(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth)
{
	CTestMove* pTestMove = &pTestMoveArray[depth];

	int32_t depthPlus1 = depth + 1;


	if (depth == MaxSearchDepthMinus1)
	{
		if (playerID == 0)
		{
			int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

			//for (int32_t i = 0; i < GameBoardSizeXY; i++)
			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				//pTestMove->BoardPosID = i;
				pTestMove->MoveID = j;

				//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					//pTestMove->MoveID = j;
					pTestMove->BoardPosID = i;

					if (pTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player1AI_InnerEvalulationLoop_EarlyOut(pResultingGameStateObject, 1, depthPlus1);

						if (TestMovesNextDepth == true)
						{
							Player1ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
						}

						int32_t evalValue = GameStatePool.pGameStateArray[resultingGameStateObjectID].iEvaluation;

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

					
						if (evalValue >= MinAcceptableEvalValueEarlyOut)
						{
							EarlyOutCounter++;
							goto StopEvaluationPlayer1A;
						}

#ifdef PRUNING
						if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer1A;
						}
#endif
					} // end of if (pTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)

					if (StopFurtherExploration == true)
					{
						goto StopEvaluationPlayer1A;
					}

				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer1A:;

			return TestMovesFailed;
		} // end of if (playerID == 0)
		else //if (playerID == 1)
		{
			int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

			//for (int32_t i = 0; i < GameBoardSizeXY; i++)
			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				//pTestMove->BoardPosID = i;
				pTestMove->MoveID = j;

				//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					//pTestMove->MoveID = j;
					pTestMove->BoardPosID = i;

					if (pTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player1AI_InnerEvalulationLoop_EarlyOut(pResultingGameStateObject, 0, depthPlus1);

						if (TestMovesNextDepth == true)
						{
							Player1ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
						}

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
						if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMaximizerEvalValue >= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer2A;
						}
#endif
					} // end of if (pTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)

					if (StopFurtherExploration == true)
					{
						goto StopEvaluationPlayer2A;
					}

				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer2A:;

			return TestMovesFailed;
		} // end of else //if (playerID == 1)
	} // end of if (depth == MaxSearchDepthMinus1)
	else if (depth < MaxSearchDepthMinus1)
	{
		if (playerID == 0)
		{
			int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

			//for (int32_t i = 0; i < GameBoardSizeXY; i++)
			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				//pTestMove->BoardPosID = i;
				pTestMove->MoveID = j;

				//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					//pTestMove->MoveID = j;
					pTestMove->BoardPosID = i;

					if (pTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player1AI_OuterEvalulationLoop_EarlyOut(pResultingGameStateObject, 1, depthPlus1);

						if (TestMovesNextDepth == true)
						{
							Player1ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
						}

						int32_t evalValue = GameStatePool.pGameStateArray[resultingGameStateObjectID].iEvaluation;

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);
						
						if (evalValue >= MinAcceptableEvalValueEarlyOut)
						{
							EarlyOutCounter++;
							goto StopEvaluationPlayer1B;
						}

#ifdef PRUNING
						if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer1B;
						}
#endif
					} // end of if (pTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)

					if (StopFurtherExploration == true)
					{
						goto StopEvaluationPlayer1B;
					}

				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer1B:;

			return TestMovesFailed;
		} // end of if (playerID == 0)
		else //if (playerID == 1)
		{
			int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

			//for (int32_t i = 0; i < GameBoardSizeXY; i++)
			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				//pTestMove->BoardPosID = i;
				pTestMove->MoveID = j;

				//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					//pTestMove->MoveID = j;
					pTestMove->BoardPosID = i;

					if (pTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player1AI_OuterEvalulationLoop_EarlyOut(pResultingGameStateObject, 0, depthPlus1);


						if (TestMovesNextDepth == true)
						{
							Player1ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
						}

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
						if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMaximizerEvalValue >= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer2B;
						}
#endif
					} // end of if (pTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)

					if (StopFurtherExploration == true)
					{
						goto StopEvaluationPlayer2B;
					}

				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer2B:;

			return TestMovesFailed;
		} // end of else //if (playerID == 1)
	} // end of else if (depth < MaxSearchDepthMinus1)

	return false;
}

bool CDepthFirstSearchAI::Player1AI_OuterEvalulationLoop_EarlyOut_DiscardInsufficientStates(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth)
{
	CTestMove* pTestMove = &pTestMoveArray[depth];

	int32_t depthPlus1 = depth + 1;


	if (depth == MaxSearchDepthMinus1)
	{
		if (playerID == 0)
		{
			int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

			//for (int32_t i = 0; i < GameBoardSizeXY; i++)
			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				//pTestMove->BoardPosID = i;
				pTestMove->MoveID = j;

				//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					//pTestMove->MoveID = j;
					pTestMove->BoardPosID = i;

					if (pTestMove->Make_Player1Move_If_Possible_DiscardInsufficientStates(pInActualGameState, &GameStatePool, depth, false) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player1AI_InnerEvalulationLoop_EarlyOut_DiscardInsufficientStates(pResultingGameStateObject, 1, depthPlus1);

						if (TestMovesNextDepth == true)
						{
							Player1ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
						}

						int32_t evalValue = GameStatePool.pGameStateArray[resultingGameStateObjectID].iEvaluation;

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);


						if (evalValue >= MinAcceptableEvalValueEarlyOut)
						{
							EarlyOutCounter++;
							goto StopEvaluationPlayer1A;
						}

#ifdef PRUNING
						if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer1A;
						}
#endif
					} // end of if (pTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)

					if (StopFurtherExploration == true)
					{
						goto StopEvaluationPlayer1A;
					}

				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer1A:;

			return TestMovesFailed;
		} // end of if (playerID == 0)
		else //if (playerID == 1)
		{
			int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

			//for (int32_t i = 0; i < GameBoardSizeXY; i++)
			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				//pTestMove->BoardPosID = i;
				pTestMove->MoveID = j;

				//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					//pTestMove->MoveID = j;
					pTestMove->BoardPosID = i;

					if (pTestMove->Make_Player2Move_If_Possible_DiscardInsufficientStates(pInActualGameState, &GameStatePool, depth, true) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player1AI_InnerEvalulationLoop_EarlyOut_DiscardInsufficientStates(pResultingGameStateObject, 0, depthPlus1);

						if (TestMovesNextDepth == true)
						{
							Player1ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
						}

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
						if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMaximizerEvalValue >= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer2A;
						}
#endif
					} // end of if (pTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)

					if (StopFurtherExploration == true)
					{
						goto StopEvaluationPlayer2A;
					}

				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer2A:;

			return TestMovesFailed;
		} // end of else //if (playerID == 1)
	} // end of if (depth == MaxSearchDepthMinus1)
	else if (depth < MaxSearchDepthMinus1)
	{
		if (playerID == 0)
		{
			int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

			//for (int32_t i = 0; i < GameBoardSizeXY; i++)
			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				//pTestMove->BoardPosID = i;
				pTestMove->MoveID = j;

				//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					//pTestMove->MoveID = j;
					pTestMove->BoardPosID = i;

					if (pTestMove->Make_Player1Move_If_Possible_DiscardInsufficientStates(pInActualGameState, &GameStatePool, depth, false) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player1AI_OuterEvalulationLoop_EarlyOut_DiscardInsufficientStates(pResultingGameStateObject, 1, depthPlus1);

						if (TestMovesNextDepth == true)
						{
							Player1ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
						}

						int32_t evalValue = GameStatePool.pGameStateArray[resultingGameStateObjectID].iEvaluation;

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

						if (evalValue >= MinAcceptableEvalValueEarlyOut)
						{
							EarlyOutCounter++;
							goto StopEvaluationPlayer1B;
						}

#ifdef PRUNING
						if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer1B;
						}
#endif
					} // end of if (pTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)

					if (StopFurtherExploration == true)
					{
						goto StopEvaluationPlayer1B;
					}

				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer1B:;

			return TestMovesFailed;
		} // end of if (playerID == 0)
		else //if (playerID == 1)
		{
			int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

			//for (int32_t i = 0; i < GameBoardSizeXY; i++)
			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				//pTestMove->BoardPosID = i;
				pTestMove->MoveID = j;

				//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					//pTestMove->MoveID = j;
					pTestMove->BoardPosID = i;

					if (pTestMove->Make_Player2Move_If_Possible_DiscardInsufficientStates(pInActualGameState, &GameStatePool, depth, true) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player1AI_OuterEvalulationLoop_EarlyOut_DiscardInsufficientStates(pResultingGameStateObject, 0, depthPlus1);


						if (TestMovesNextDepth == true)
						{
							Player1ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
						}

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
						if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMaximizerEvalValue >= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer2B;
						}
#endif
					} // end of if (pTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)

					if (StopFurtherExploration == true)
					{
						goto StopEvaluationPlayer2B;
					}

				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer2B:;

			return TestMovesFailed;
		} // end of else //if (playerID == 1)
	} // end of else if (depth < MaxSearchDepthMinus1)

	return false;
}

bool CDepthFirstSearchAI::Player1AI_OuterEvalulationLoop_DiscardInsufficientStates(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth)
{
	CTestMove* pTestMove = &pTestMoveArray[depth];

	int32_t depthPlus1 = depth + 1;


	if (depth == MaxSearchDepthMinus1)
	{
		if (playerID == 0)
		{
			int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

			//for (int32_t i = 0; i < GameBoardSizeXY; i++)
			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				//pTestMove->BoardPosID = i;
				pTestMove->MoveID = j;

				//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					//pTestMove->MoveID = j;
					pTestMove->BoardPosID = i;

					if (pTestMove->Make_Player1Move_If_Possible_DiscardInsufficientStates(pInActualGameState, &GameStatePool, depth, false) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player1AI_InnerEvalulationLoop_DiscardInsufficientStates(pResultingGameStateObject, 1, depthPlus1);

						if (TestMovesNextDepth == true)
						{
							Player1ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
						}

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
						if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer1A;
						}
#endif
					} // end of if (pTestMove->Make_Player1Move_If_Possible_Ext2(pInActualGameState, &GameStatePool, depth, false) > 0)

					if (StopFurtherExploration == true)
					{
						goto StopEvaluationPlayer1A;
					}

				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer1A:;

			return TestMovesFailed;
		} // end of if (playerID == 0)
		else //if (playerID == 1)
		{
			int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

			//for (int32_t i = 0; i < GameBoardSizeXY; i++)
			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				//pTestMove->BoardPosID = i;
				pTestMove->MoveID = j;

				//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					//pTestMove->MoveID = j;
					pTestMove->BoardPosID = i;

					if (pTestMove->Make_Player2Move_If_Possible_DiscardInsufficientStates(pInActualGameState, &GameStatePool, depth, true) > 0)
					//if (pTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player1AI_InnerEvalulationLoop_DiscardInsufficientStates(pResultingGameStateObject, 0, depthPlus1);

						if (TestMovesNextDepth == true)
						{
							Player1ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
						}

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);
#ifdef PRUNING
						if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMaximizerEvalValue >= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer2A;
						}
#endif
					} // end of if (pTestMove->Make_Player2Move_If_Possible_Ext2(pInActualGameState, &GameStatePool, depth, true) > 0)

					if (StopFurtherExploration == true)
					{
						goto StopEvaluationPlayer2A;
					}

				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer2A:;

			return TestMovesFailed;
		} // end of else //if (playerID == 1)
	} // end of if (depth == MaxSearchDepthMinus1)
	else if (depth < MaxSearchDepthMinus1)
	{
		if (playerID == 0)
		{
			int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

			//for (int32_t i = 0; i < GameBoardSizeXY; i++)
			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				//pTestMove->BoardPosID = i;
				pTestMove->MoveID = j;

				//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					//pTestMove->MoveID = j;
					pTestMove->BoardPosID = i;

					if (pTestMove->Make_Player1Move_If_Possible_DiscardInsufficientStates(pInActualGameState, &GameStatePool, depth, false) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player1AI_OuterEvalulationLoop_DiscardInsufficientStates(pResultingGameStateObject, 1, depthPlus1);

						if (TestMovesNextDepth == true)
						{
							Player1ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
						}

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
						if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer1B;
						}
#endif
					} // end of if (pTestMove->Make_Player1Move_If_Possible_Ext2(pInActualGameState, &GameStatePool, depth, false) > 0)

					if (StopFurtherExploration == true)
					{
						goto StopEvaluationPlayer1B;
					}

				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer1B:;

			return TestMovesFailed;
		} // end of if (playerID == 0)
		else //if (playerID == 1)
		{
			int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

			//for (int32_t i = 0; i < GameBoardSizeXY; i++)
			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				//pTestMove->BoardPosID = i;
				pTestMove->MoveID = j;

				//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					//pTestMove->MoveID = j;
					pTestMove->BoardPosID = i;

					if (pTestMove->Make_Player2Move_If_Possible_DiscardInsufficientStates(pInActualGameState, &GameStatePool, depth, true) > 0)
					//if (pTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player1AI_OuterEvalulationLoop_DiscardInsufficientStates(pResultingGameStateObject, 0, depthPlus1);


						if (TestMovesNextDepth == true)
						{
							Player1ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
						}

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
						if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMaximizerEvalValue >= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer2B;
						}
#endif
					} // end of if (pTestMove->Make_Player2Move_If_Possible_Ext2(pInActualGameState, &GameStatePool, depth, true) > 0)

					if (StopFurtherExploration == true)
					{
						goto StopEvaluationPlayer2B;
					}

				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer2B:;

			return TestMovesFailed;
		} // end of else //if (playerID == 1)
	} // end of else if (depth < MaxSearchDepthMinus1)

	return false;
}

bool CDepthFirstSearchAI::Player2AI_OuterEvalulationLoop(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth)
{
	CTestMove* pTestMove = &pTestMoveArray[depth];

	int32_t depthPlus1 = depth + 1;


	if (depth == MaxSearchDepthMinus1)
	{
		if (playerID == 0)
		{
			int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

			//for (int32_t i = 0; i < GameBoardSizeXY; i++)
			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				//pTestMove->BoardPosID = i;
				pTestMove->MoveID = j;

				//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					//pTestMove->MoveID = j;
					pTestMove->BoardPosID = i;

					if (pTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player2AI_InnerEvalulationLoop(pResultingGameStateObject, 1, depthPlus1);

						if (TestMovesNextDepth == true)
						{
							Player2ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
						}

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
						if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMaximizerEvalValue >= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer1A;
						}
#endif
					} // end of if (pTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)

					if (StopFurtherExploration == true)
					{
						goto StopEvaluationPlayer1A;
					}

				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer1A:;

			return TestMovesFailed;
		} // end of if (playerID == 0)
		else //if (playerID == 1)
		{
			int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

			//for (int32_t i = 0; i < GameBoardSizeXY; i++)
			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				//pTestMove->BoardPosID = i;
				pTestMove->MoveID = j;

				//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					//pTestMove->MoveID = j;
					pTestMove->BoardPosID = i;

					if (pTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player2AI_InnerEvalulationLoop(pResultingGameStateObject, 0, depthPlus1);

						if (TestMovesNextDepth == true)
						{
							Player2ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
						}

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
						if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer2A;
						}
#endif
					} // end of if (pTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)

					if (StopFurtherExploration == true)
					{
						goto StopEvaluationPlayer2A;
					}

				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer2A:;

			return TestMovesFailed;
		} // end of else //if (playerID == 1)
	} // end of if (depth == MaxSearchDepthMinus1)
	else if (depth < MaxSearchDepthMinus1)
	{
		if (playerID == 0)
		{
			int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

			//for (int32_t i = 0; i < GameBoardSizeXY; i++)
			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				//pTestMove->BoardPosID = i;
				pTestMove->MoveID = j;

				//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					//pTestMove->MoveID = j;
					pTestMove->BoardPosID = i;

					if (pTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player2AI_OuterEvalulationLoop(pResultingGameStateObject, 1, depthPlus1);

						if (TestMovesNextDepth == true)
						{
							Player2ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
						}

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
						if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMaximizerEvalValue >= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer1B;
						}
#endif
					} // end of if (pTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)

					if (StopFurtherExploration == true)
					{
						goto StopEvaluationPlayer1B;
					}

				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer1B:;

			return TestMovesFailed;
		} // end of if (playerID == 0)
		else //if (playerID == 1)
		{
			int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

			//for (int32_t i = 0; i < GameBoardSizeXY; i++)
			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				//pTestMove->BoardPosID = i;
				pTestMove->MoveID = j;

				//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					//pTestMove->MoveID = j;
					pTestMove->BoardPosID = i;

					if (pTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player2AI_OuterEvalulationLoop(pResultingGameStateObject, 0, depthPlus1);

						if (TestMovesNextDepth == true)
						{
							Player2ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
						}

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
						if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer2B;
						}
#endif
					} // end of if (pTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)

					if (StopFurtherExploration == true)
					{
						goto StopEvaluationPlayer2B;
					}

				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer2B:;

			return TestMovesFailed;
		} // end of else //if (playerID == 1)
	} // end of else if (depth < MaxSearchDepthMinus1)

	return false;
}

bool CDepthFirstSearchAI::Player2AI_OuterEvalulationLoop_EarlyOut(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth)
{
	CTestMove* pTestMove = &pTestMoveArray[depth];

	int32_t depthPlus1 = depth + 1;


	if (depth == MaxSearchDepthMinus1)
	{
		if (playerID == 0)
		{
			int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

			//for (int32_t i = 0; i < GameBoardSizeXY; i++)
			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				//pTestMove->BoardPosID = i;
				pTestMove->MoveID = j;

				//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					//pTestMove->MoveID = j;
					pTestMove->BoardPosID = i;

					if (pTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player2AI_InnerEvalulationLoop_EarlyOut(pResultingGameStateObject, 1, depthPlus1);

						if (TestMovesNextDepth == true)
						{
							Player2ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
						}

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
						if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMaximizerEvalValue >= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer1A;
						}
#endif
					} // end of if (pTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)

					if (StopFurtherExploration == true)
					{
						goto StopEvaluationPlayer1A;
					}

				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer1A:;

			return TestMovesFailed;
		} // end of if (playerID == 0)
		else //if (playerID == 1)
		{
			int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

			//for (int32_t i = 0; i < GameBoardSizeXY; i++)
			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				//pTestMove->BoardPosID = i;
				pTestMove->MoveID = j;

				//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					//pTestMove->MoveID = j;
					pTestMove->BoardPosID = i;

					if (pTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player2AI_InnerEvalulationLoop_EarlyOut(pResultingGameStateObject, 0, depthPlus1);

						if (TestMovesNextDepth == true)
						{
							Player2ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
						}

						int32_t evalValue = GameStatePool.pGameStateArray[resultingGameStateObjectID].iEvaluation;

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

						
						if (evalValue >= MinAcceptableEvalValueEarlyOut)
						{
							EarlyOutCounter++;
							goto StopEvaluationPlayer2A;
						}

#ifdef PRUNING
						if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer2A;
						}
#endif
					} // if (pTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)

					if (StopFurtherExploration == true)
					{
						goto StopEvaluationPlayer2A;
					}

				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer2A:;

			return TestMovesFailed;
		} // end of else //if (playerID == 1)
	} // end of if (depth == MaxSearchDepthMinus1)
	else if (depth < MaxSearchDepthMinus1)
	{
		if (playerID == 0)
		{
			int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

			//for (int32_t i = 0; i < GameBoardSizeXY; i++)
			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				//pTestMove->BoardPosID = i;
				pTestMove->MoveID = j;

				//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					//pTestMove->MoveID = j;
					pTestMove->BoardPosID = i;

					if (pTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player2AI_OuterEvalulationLoop_EarlyOut(pResultingGameStateObject, 1, depthPlus1);

						if (TestMovesNextDepth == true)
						{
							Player2ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
						}

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);
					
#ifdef PRUNING
						if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMaximizerEvalValue >= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer1B;
						}
#endif
					} // if (pTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)

					if (StopFurtherExploration == true)
					{
						goto StopEvaluationPlayer1B;
					}

				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer1B:;

			return TestMovesFailed;
		} // end of if (playerID == 0)
		else //if (playerID == 1)
		{
			int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

			//for (int32_t i = 0; i < GameBoardSizeXY; i++)
			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				//pTestMove->BoardPosID = i;
				pTestMove->MoveID = j;

				//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					//pTestMove->MoveID = j;
					pTestMove->BoardPosID = i;

					if (pTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player2AI_OuterEvalulationLoop_EarlyOut(pResultingGameStateObject, 0, depthPlus1);

						if (TestMovesNextDepth == true)
						{
							Player2ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
						}

						int32_t evalValue = GameStatePool.pGameStateArray[resultingGameStateObjectID].iEvaluation;

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

						

						if (evalValue >= MinAcceptableEvalValueEarlyOut)
						{
							EarlyOutCounter++;
							goto StopEvaluationPlayer2B;
						}

#ifdef PRUNING
						if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer2B;
						}
#endif
					} // end of if (pTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)

					if (StopFurtherExploration == true)
					{
						goto StopEvaluationPlayer2B;
					}

				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer2B:;

			return TestMovesFailed;
		} // end of else //if (playerID == 1)
	} // end of else if (depth < MaxSearchDepthMinus1)

	return false;
}

bool CDepthFirstSearchAI::Player2AI_OuterEvalulationLoop_EarlyOut_DiscardInsufficientStates(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth)
{
	CTestMove* pTestMove = &pTestMoveArray[depth];

	int32_t depthPlus1 = depth + 1;


	if (depth == MaxSearchDepthMinus1)
	{
		if (playerID == 0)
		{
			int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

			//for (int32_t i = 0; i < GameBoardSizeXY; i++)
			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				//pTestMove->BoardPosID = i;
				pTestMove->MoveID = j;

				//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					//pTestMove->MoveID = j;
					pTestMove->BoardPosID = i;

					if (pTestMove->Make_Player1Move_If_Possible_DiscardInsufficientStates(pInActualGameState, &GameStatePool, depth, true) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player2AI_InnerEvalulationLoop_EarlyOut_DiscardInsufficientStates(pResultingGameStateObject, 1, depthPlus1);

						if (TestMovesNextDepth == true)
						{
							Player2ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
						}

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
						if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMaximizerEvalValue >= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer1A;
						}
#endif
					} // end of if (pTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)

					if (StopFurtherExploration == true)
					{
						goto StopEvaluationPlayer1A;
					}

				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer1A:;

			return TestMovesFailed;
		} // end of if (playerID == 0)
		else //if (playerID == 1)
		{
			int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

			//for (int32_t i = 0; i < GameBoardSizeXY; i++)
			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				//pTestMove->BoardPosID = i;
				pTestMove->MoveID = j;

				//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					//pTestMove->MoveID = j;
					pTestMove->BoardPosID = i;

					if (pTestMove->Make_Player2Move_If_Possible_DiscardInsufficientStates(pInActualGameState, &GameStatePool, depth, false) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player2AI_InnerEvalulationLoop_EarlyOut_DiscardInsufficientStates(pResultingGameStateObject, 0, depthPlus1);

						if (TestMovesNextDepth == true)
						{
							Player2ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
						}

						int32_t evalValue = GameStatePool.pGameStateArray[resultingGameStateObjectID].iEvaluation;

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);


						if (evalValue >= MinAcceptableEvalValueEarlyOut)
						{
							EarlyOutCounter++;
							goto StopEvaluationPlayer2A;
						}

#ifdef PRUNING
						if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer2A;
						}
#endif
					} // if (pTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)

					if (StopFurtherExploration == true)
					{
						goto StopEvaluationPlayer2A;
					}

				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer2A:;

			return TestMovesFailed;
		} // end of else //if (playerID == 1)
	} // end of if (depth == MaxSearchDepthMinus1)
	else if (depth < MaxSearchDepthMinus1)
	{
		if (playerID == 0)
		{
			int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

			//for (int32_t i = 0; i < GameBoardSizeXY; i++)
			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				//pTestMove->BoardPosID = i;
				pTestMove->MoveID = j;

				//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					//pTestMove->MoveID = j;
					pTestMove->BoardPosID = i;

					if (pTestMove->Make_Player1Move_If_Possible_DiscardInsufficientStates(pInActualGameState, &GameStatePool, depth, true) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player2AI_OuterEvalulationLoop_EarlyOut_DiscardInsufficientStates(pResultingGameStateObject, 1, depthPlus1);

						if (TestMovesNextDepth == true)
						{
							Player2ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
						}

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
						if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMaximizerEvalValue >= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer1B;
						}
#endif
					} // if (pTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)

					if (StopFurtherExploration == true)
					{
						goto StopEvaluationPlayer1B;
					}

				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer1B:;

			return TestMovesFailed;
		} // end of if (playerID == 0)
		else //if (playerID == 1)
		{
			int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

			//for (int32_t i = 0; i < GameBoardSizeXY; i++)
			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				//pTestMove->BoardPosID = i;
				pTestMove->MoveID = j;

				//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					//pTestMove->MoveID = j;
					pTestMove->BoardPosID = i;

					if (pTestMove->Make_Player2Move_If_Possible_DiscardInsufficientStates(pInActualGameState, &GameStatePool, depth, false) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player2AI_OuterEvalulationLoop_EarlyOut_DiscardInsufficientStates(pResultingGameStateObject, 0, depthPlus1);

						if (TestMovesNextDepth == true)
						{
							Player2ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
						}

						int32_t evalValue = GameStatePool.pGameStateArray[resultingGameStateObjectID].iEvaluation;

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);



						if (evalValue >= MinAcceptableEvalValueEarlyOut)
						{
							EarlyOutCounter++;
							goto StopEvaluationPlayer2B;
						}

#ifdef PRUNING
						if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer2B;
						}
#endif
					} // end of if (pTestMove->Make_Player2Move_If_Possible(pInActualGameState, &GameStatePool, depth, false) > 0)

					if (StopFurtherExploration == true)
					{
						goto StopEvaluationPlayer2B;
					}

				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer2B:;

			return TestMovesFailed;
		} // end of else //if (playerID == 1)
	} // end of else if (depth < MaxSearchDepthMinus1)

	return false;
}

bool CDepthFirstSearchAI::Player2AI_OuterEvalulationLoop_DiscardInsufficientStates(CGameStateValues* pInActualGameState, int32_t playerID, int32_t depth)
{
	CTestMove* pTestMove = &pTestMoveArray[depth];

	int32_t depthPlus1 = depth + 1;


	if (depth == MaxSearchDepthMinus1)
	{
		if (playerID == 0)
		{
			int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

			//for (int32_t i = 0; i < GameBoardSizeXY; i++)
			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				//pTestMove->BoardPosID = i;
				pTestMove->MoveID = j;

				//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					//pTestMove->MoveID = j;
					pTestMove->BoardPosID = i;

					if (pTestMove->Make_Player1Move_If_Possible_DiscardInsufficientStates(pInActualGameState, &GameStatePool, depth, true) > 0)
					//if (pTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player2AI_InnerEvalulationLoop_DiscardInsufficientStates(pResultingGameStateObject, 1, depthPlus1);

						if (TestMovesNextDepth == true)
						{
							Player2ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
						}

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
						if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMaximizerEvalValue >= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer1A;
						}
#endif
					} // end of if (pTestMove->Make_Player1Move_If_Possible_Ext2(pInActualGameState, &GameStatePool, depth, true) > 0)

					if (StopFurtherExploration == true)
					{
						goto StopEvaluationPlayer1A;
					}

				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer1A:;

			return TestMovesFailed;
		} // end of if (playerID == 0)
		else //if (playerID == 1)
		{
			int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

			//for (int32_t i = 0; i < GameBoardSizeXY; i++)
			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				//pTestMove->BoardPosID = i;
				pTestMove->MoveID = j;

				//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					//pTestMove->MoveID = j;
					pTestMove->BoardPosID = i;

					if (pTestMove->Make_Player2Move_If_Possible_DiscardInsufficientStates(pInActualGameState, &GameStatePool, depth, false) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player2AI_InnerEvalulationLoop_DiscardInsufficientStates(pResultingGameStateObject, 0, depthPlus1);

						if (TestMovesNextDepth == true)
						{
							Player2ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
						}

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
						if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer2A;
						}
#endif
					} // end of if (pTestMove->Make_Player2Move_If_Possible_Ext2(pInActualGameState, &GameStatePool, depth, false) > 0)

					if (StopFurtherExploration == true)
					{
						goto StopEvaluationPlayer2A;
					}

				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer2A:;

			return TestMovesFailed;
		} // end of else //if (playerID == 1)
	} // end of if (depth == MaxSearchDepthMinus1)
	else if (depth < MaxSearchDepthMinus1)
	{
		if (playerID == 0)
		{
			int32_t PrevMaximizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer1MoveList->NumOfMoves;

			//for (int32_t i = 0; i < GameBoardSizeXY; i++)
			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				//pTestMove->BoardPosID = i;
				pTestMove->MoveID = j;

				//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					//pTestMove->MoveID = j;
					pTestMove->BoardPosID = i;

					if (pTestMove->Make_Player1Move_If_Possible_DiscardInsufficientStates(pInActualGameState, &GameStatePool, depth, true) > 0)
					//if (pTestMove->Make_Player1Move_If_Possible(pInActualGameState, &GameStatePool, depth, true) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player2AI_OuterEvalulationLoop_DiscardInsufficientStates(pResultingGameStateObject, 1, depthPlus1);

						if (TestMovesNextDepth == true)
						{
							Player2ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
						}

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);

#ifdef PRUNING
						if (PrevMaximizerEvalValue >= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMaximizerEvalValue >= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer1B;
						}
#endif
					} // end of if (pTestMove->Make_Player1Move_If_Possible_Ext2(pInActualGameState, &GameStatePool, depth, true) > 0)

					if (StopFurtherExploration == true)
					{
						goto StopEvaluationPlayer1B;
					}

				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer1B:;

			return TestMovesFailed;
		} // end of if (playerID == 0)
		else //if (playerID == 1)
		{
			int32_t PrevMinimizerEvalValue = GameStatePool.pGameStateArray[pInActualGameState->IDofPrevGameState].iEvaluation;

			bool TestMovesFailed = true;

			int32_t numOfPossibleTestMoves = pUsedPlayer2MoveList->NumOfMoves;

			//for (int32_t i = 0; i < GameBoardSizeXY; i++)
			for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			{
				//pTestMove->BoardPosID = i;
				pTestMove->MoveID = j;

				//for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
				for (int32_t i = 0; i < GameBoardSizeXY; i++)
				{
					//pTestMove->MoveID = j;
					pTestMove->BoardPosID = i;

					if (pTestMove->Make_Player2Move_If_Possible_DiscardInsufficientStates(pInActualGameState, &GameStatePool, depth, false) > 0)
					{
						TestMovesFailed = false;

						int32_t resultingGameStateObjectID = pTestMove->ResultingGameStateObjectID;
						CGameStateValues* pResultingGameStateObject = &GameStatePool.pGameStateArray[resultingGameStateObjectID];

						bool TestMovesNextDepth = Player2AI_OuterEvalulationLoop_DiscardInsufficientStates(pResultingGameStateObject, 0, depthPlus1);

						if (TestMovesNextDepth == true)
						{
							Player2ViewGameStateEvalFunc(resultingGameStateObjectID, &GameStatePool, pUsedPlayer1MoveList, pUsedPlayer2MoveList);
						}

						OneStepBackpropagate_MinimaxIntegerEvaluationValues(resultingGameStateObjectID, &GameStatePool);
						GameStatePool.Stop_Using_GameStateObject(resultingGameStateObjectID);
#ifdef PRUNING
						if (PrevMinimizerEvalValue <= pInActualGameState->iEvaluation)
						{
							//Add_To_Log(0, "PrevMinimizerEvalValue <= pInActualGameState->iEvaluation");
							goto StopEvaluationPlayer2B;
						}
#endif
					} // end of if (pTestMove->Make_Player2Move_If_Possible_Ext2(pInActualGameState, &GameStatePool, depth, false) > 0)

					if (StopFurtherExploration == true)
					{
						goto StopEvaluationPlayer2B;
					}

				} // end of for (int32_t j = 0; j < numOfPossibleTestMoves; j++)
			} // end of for (int32_t i = 0; i < ConstGameBoardSize; i++)

		StopEvaluationPlayer2B:;

			return TestMovesFailed;
		} // end of else //if (playerID == 1)
	} // end of else if (depth < MaxSearchDepthMinus1)

	return false;
}