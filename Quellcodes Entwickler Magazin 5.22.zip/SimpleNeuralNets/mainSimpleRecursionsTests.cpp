#include <iostream>

using namespace std;


/*

int32_t g_FunctionCallCounter = 0;

void OutputTestFunction1(int32_t num)
{
	cout << num << " ";
}

void OutputTestFunction2(int32_t num)
{
	cout << "(" << g_FunctionCallCounter << ") " << num << " ";	
}


// Tail-Rekursion: Der rekursive Funktionsaufruf erfolgt im letzten Schritt.
// Tail-rekursive Funktionen gehen sparsam mit dem Stack-Speicher um
// (alle Berechnungen, die den Stack involvieren sind bereits abgeschlossen)
// und lassen sich vom Compiler optimieren 

   // Ausgabereihenfolge: (1) 0, (2) 1, (3) 2, (4) 3
void TailRecursiveTestFunction(int32_t counter, int32_t maxCountPlus1) 
{
	g_FunctionCallCounter++;

	if (counter >= maxCountPlus1)
	{
		return;
	}

	OutputTestFunction2(counter); 

	TailRecursiveTestFunction(counter + 1, maxCountPlus1);
}

// Ausgabereihenfolge: (5) 3, (5) 2, (5) 1, (5) 0
void RecursiveTestFunction(int32_t counter, int32_t maxCountPlus1)
{
	g_FunctionCallCounter++;

	if (counter >= maxCountPlus1)
	{
		return;
	}

	RecursiveTestFunction(counter + 1, maxCountPlus1);

	OutputTestFunction2(counter); 
}

int main(void)
{
	for (int32_t i = 0; i < 4; i++)
	{
		OutputTestFunction1(i);
	}

	cout << endl;

	g_FunctionCallCounter = 0;
	RecursiveTestFunction(0, 4);

	cout << endl;

	g_FunctionCallCounter = 0;
	TailRecursiveTestFunction(0, 4);

	cout << endl;

	cout << "bye bye (Press Return)" << endl;
	getchar();
	return 0;
}
*/