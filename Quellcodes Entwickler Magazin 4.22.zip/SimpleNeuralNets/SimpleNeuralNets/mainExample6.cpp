#include <iostream>
#include "NeuralNet.h"

using namespace std;

inline float BinaryOutput(float neuronInput)
{
	if (neuronInput > 0.9999f)
		return 1.0f;

	return 0.0f;
}

inline float SigmoidOutput(float neuronInput)
{
	// von 0.0f bis 1.0f:
	return 1.0f / (1.0f + exp(-neuronInput));
}


#define BINARY
//#define SIGMOID

class CLogicGateBrain
{
public:

	uint32_t NumInputNeurons = 2;
	uint32_t NumBiasNeurons = 1;
	uint32_t NumOutputNeurons = 1;

	uint32_t NumNeurons = NumInputNeurons + NumOutputNeurons + NumBiasNeurons;

	uint32_t InputNeuronID1 = 0;
	uint32_t InputNeuronID2 = 1;
	uint32_t BiasNeuronID = 2;  
	uint32_t OutputNeuronID = 3;

	CNeuron *pNeuronArray = nullptr;

	CRandomNumbersNN RandomNumbers;

	CLogicGateBrain()
	{
		pNeuronArray = new (std::nothrow) CNeuron[NumNeurons];

		
		for (uint32_t i = 0; i < NumNeurons; i++)
			pNeuronArray[i].Connect_With_Brain(pNeuronArray);

		pNeuronArray[InputNeuronID1].Use_As_InputNeuron();
		pNeuronArray[InputNeuronID1].Init_OutputSynapses(NumOutputNeurons);
		pNeuronArray[InputNeuronID1].Connect_With_ReceiverNeuron(OutputNeuronID, /*SynapseID:*/  0);
		pNeuronArray[InputNeuronID1].Randomize_OutputSynapsePlasticities(&RandomNumbers, -2.0f, 2.0f);
		pNeuronArray[InputNeuronID1].Set_LearningRate(0.2f);

		pNeuronArray[InputNeuronID2].Use_As_InputNeuron();
		pNeuronArray[InputNeuronID2].Init_OutputSynapses(NumOutputNeurons);
		pNeuronArray[InputNeuronID2].Connect_With_ReceiverNeuron(OutputNeuronID, /*SynapseID:*/  0);
		pNeuronArray[InputNeuronID2].Randomize_OutputSynapsePlasticities(&RandomNumbers, -2.0f, 2.0f);
		pNeuronArray[InputNeuronID2].Set_LearningRate(0.2f);

		pNeuronArray[BiasNeuronID].Use_As_BiasNeuron();
		pNeuronArray[BiasNeuronID].Set_BiasNeuronOutput(1.0f);
		pNeuronArray[BiasNeuronID].Init_OutputSynapses(NumOutputNeurons);
		pNeuronArray[BiasNeuronID].Connect_With_ReceiverNeuron(OutputNeuronID, /*SynapseID:*/ 0);
		pNeuronArray[BiasNeuronID].Randomize_OutputSynapsePlasticities(&RandomNumbers, -2.0f, 2.0f);
		pNeuronArray[BiasNeuronID].Set_LearningRate(0.2f);

		pNeuronArray[OutputNeuronID].Use_As_OutputNeuron();

#ifdef BINARY
		pNeuronArray[OutputNeuronID].Set_ActivationFunction(BinaryOutput);
#endif
#ifdef SIGMOID
		pNeuronArray[OutputNeuronID].Set_ActivationFunction(SigmoidOutput);
#endif
		pNeuronArray[OutputNeuronID].Set_ErrorFactors(1.0f, 1.0f);
	}

	~CLogicGateBrain()
	{
		delete[] pNeuronArray;
		pNeuronArray = nullptr;
	}

	// Kopierkonstruktor l�schen:
	CLogicGateBrain(const CLogicGateBrain &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CLogicGateBrain& operator=(const CLogicGateBrain &originalObject) = delete;

	float Calculate_Output(float input1, float input2)
	{
		pNeuronArray[InputNeuronID1].Set_Input(input1);
		pNeuronArray[InputNeuronID1].Propagate_SynapticOutput();

		pNeuronArray[InputNeuronID2].Set_Input(input2);
		pNeuronArray[InputNeuronID2].Propagate_SynapticOutput();

		pNeuronArray[BiasNeuronID].Propagate_SynapticOutput();

		pNeuronArray[OutputNeuronID].Calculate_NeuronOutput();
		return pNeuronArray[OutputNeuronID].Get_NeuronOutput();
	}

	float Learning(float desiredOutput)
	{
		float error = pNeuronArray[OutputNeuronID].Calculate_Error(desiredOutput);

		pNeuronArray[InputNeuronID1].Adjust_OutputSynapses_AfterErrorCalculations();
		pNeuronArray[InputNeuronID2].Adjust_OutputSynapses_AfterErrorCalculations();
		pNeuronArray[BiasNeuronID].Adjust_OutputSynapses_AfterErrorCalculations();

		return error;
	}
}; // end of class CLogicGateBrain





#define OR
//#define AND
//#define NOR // NOT OR
//#define NAND // NOT AND

/*
int main(void)
{
	CLogicGateBrain Brain;

	float Input1a = 0.0f;
	float Input1b = 0.0f;

	float Input2a = 1.0f;
	float Input2b = 0.0f;

	float Input3a = 0.0f;
	float Input3b = 1.0f;

	float Input4a = 1.0f;
	float Input4b = 1.0f;

	uint32_t maxCount = 10000;
	uint32_t epoch = 0;
	float error;

	// start training:

	for (uint32_t i = 0; i < maxCount; i++)
	{
		epoch++;
		error = 0.0f;

#ifdef OR
		Brain.Calculate_Output(Input1a, Input1b);
		error += Brain.Learning(0.0f);

		Brain.Calculate_Output(Input2a, Input2b);
		error += Brain.Learning(1.0f);

		Brain.Calculate_Output(Input3a, Input3b);
		error += Brain.Learning(1.0f);

		Brain.Calculate_Output(Input4a, Input4b);
		error += Brain.Learning(1.0f);
#endif
#ifdef AND
		Brain.Calculate_Output(Input1a, Input1b);
		error += Brain.Learning(0.0f);

		Brain.Calculate_Output(Input2a, Input2b);
		error += Brain.Learning(0.0f);

		Brain.Calculate_Output(Input3a, Input3b);
		error += Brain.Learning(0.0f);

		Brain.Calculate_Output(Input4a, Input4b);
		error += Brain.Learning(1.0f);
#endif
#ifdef NOR
		Brain.Calculate_Output(Input1a, Input1b);
		error += Brain.Learning(1.0f);

		Brain.Calculate_Output(Input2a, Input2b);
		error += Brain.Learning(0.0f);

		Brain.Calculate_Output(Input3a, Input3b);
		error += Brain.Learning(0.0f);

		Brain.Calculate_Output(Input4a, Input4b);
		error += Brain.Learning(0.0f);
#endif
#ifdef NAND
		Brain.Calculate_Output(Input1a, Input1b);
		error += Brain.Learning(1.0f);

		Brain.Calculate_Output(Input2a, Input2b);
		error += Brain.Learning(1.0f);

		Brain.Calculate_Output(Input3a, Input3b);
		error += Brain.Learning(1.0f);

		Brain.Calculate_Output(Input4a, Input4b);
		error += Brain.Learning(0.0f);
#endif
		
		if (error < 0.001f)
			break;

	}

	// training completed

	// training statistics:

	cout << "epoch: " << epoch << endl;
	cout << "error: " << error << endl << endl;

	// neural network tests:

#ifdef OR
	cout << "input : " << Input1a << " --- " << Input1b;
	cout << "  output: " << Brain.Calculate_Output(Input1a, Input1b) << " --- desired output: " << 0.0f << endl;
	// => output: 0

	cout << "input : " << Input2a << " --- " << Input2b;
	cout << "  output: " << Brain.Calculate_Output(Input2a, Input2b) << " --- desired output: " << 1.0f << endl;
	// => output: 1

	cout << "input : " << Input3a << " --- " << Input3b;
	cout << "  output: " << Brain.Calculate_Output(Input3a, Input3b) << " --- desired output: " << 1.0f << endl;
	// => output: 1

	cout << "input : " << Input4a << " --- " << Input4b;
	cout << "  output: " << Brain.Calculate_Output(Input4a, Input4b) << " --- desired output: " << 1.0f << endl;
	// => output: 1
#endif
#ifdef AND
	cout << "input : " << Input1a << " --- " << Input1b;
	cout << "  output: " << Brain.Calculate_Output(Input1a, Input1b) << " --- desired output: " << 0.0f << endl;
	// => output: 0

	cout << "input : " << Input2a << " --- " << Input2b;
	cout << "  output: " << Brain.Calculate_Output(Input2a, Input2b) << " --- desired output: " << 0.0f << endl;
	// => output: 0

	cout << "input : " << Input3a << " --- " << Input3b;
	cout << "  output: " << Brain.Calculate_Output(Input3a, Input3b) << " --- desired output: " << 0.0f << endl;
	// => output: 0

	cout << "input : " << Input4a << " --- " << Input4b;
	cout << "  output: " << Brain.Calculate_Output(Input4a, Input4b) << " --- desired output: " << 1.0f << endl;
	// => output: 1
#endif
#ifdef NOR
	cout << "input : " << Input1a << " --- " << Input1b;
	cout << "  output: " << Brain.Calculate_Output(Input1a, Input1b) << " --- desired output: " << 1.0f << endl;
	// => output: 1

	cout << "input : " << Input2a << " --- " << Input2b;
	cout << "  output: " << Brain.Calculate_Output(Input2a, Input2b) << " --- desired output: " << 0.0f << endl;
	// => output: 0

	cout << "input : " << Input3a << " --- " << Input3b;
	cout << "  output: " << Brain.Calculate_Output(Input3a, Input3b) << " --- desired output: " << 0.0f << endl;
	// => output: 0

	cout << "input : " << Input4a << " --- " << Input4b;
	cout << "  output: " << Brain.Calculate_Output(Input4a, Input4b) << " --- desired output: " << 0.0f << endl;
	// => output: 0
#endif
#ifdef NAND
	cout << "input : " << Input1a << " --- " << Input1b;
	cout << "  output: " << Brain.Calculate_Output(Input1a, Input1b) << " --- desired output: " << 1.0f << endl;
	// => output: 1

	cout << "input : " << Input2a << " --- " << Input2b;
	cout << "  output: " << Brain.Calculate_Output(Input2a, Input2b) << " --- desired output: " << 1.0f << endl;
	// => output: 1

	cout << "input : " << Input3a << " --- " << Input3b;
	cout << "  output: " << Brain.Calculate_Output(Input3a, Input3b) << " --- desired output: " << 1.0f << endl;
	// => output: 1

	cout << "input : " << Input4a << " --- " << Input4b;
	cout << "  output: " << Brain.Calculate_Output(Input4a, Input4b) << " --- desired output: " << 0.0f << endl;
	// => output: 0
#endif

	getchar();
	return 0;
}
*/

/*
int main(void)
{
	CNeuralNet Brain;
	Brain.Init_NeuralNet(4);

#ifdef BINARY
	Brain.Init_TwoLayerNetwork(2, -2.0f, 2.0f, 0.2f, true, 1, BinaryOutput);
#endif
#ifdef SIGMOID
	Brain.Init_TwoLayerNetwork(2, -2.0f, 2.0f, 0.2f, true, 1, SigmoidOutput);
#endif
	
	float InputArray1[2] = { 0.0f, 0.0f };
	float Input1a = 0.0f;
	float Input1b = 0.0f;

	float InputArray2[2] = { 1.0f, 0.0f };
	float Input2a = 1.0f;
	float Input2b = 0.0f;

	float InputArray3[2] = { 0.0f, 1.0f };
	float Input3a = 0.0f;
	float Input3b = 1.0f;

	float InputArray4[2] = { 1.0f, 1.0f };
	float Input4a = 1.0f;
	float Input4b = 1.0f;

	float output;
	float desiredOutput;

	uint32_t maxCount = 10000;
	uint32_t epoch = 0;
	float error;

	// start training:

	for (uint32_t i = 0; i < maxCount; i++)
	{
		epoch++;
		error = 0.0f;

#ifdef OR
		Brain.Calculate_Output_TwoLayerNetwork(&output, InputArray1);
		desiredOutput = 0.0f;
		error += Brain.Learning_TwoLayerNetwork(&desiredOutput);

		Brain.Calculate_Output_TwoLayerNetwork(&output, InputArray2);
		desiredOutput = 1.0f;
		error += Brain.Learning_TwoLayerNetwork(&desiredOutput);

		Brain.Calculate_Output_TwoLayerNetwork(&output, InputArray3);
		desiredOutput = 1.0f;
		error += Brain.Learning_TwoLayerNetwork(&desiredOutput);

		Brain.Calculate_Output_TwoLayerNetwork(&output, InputArray4);
		desiredOutput = 1.0f;
		error += Brain.Learning_TwoLayerNetwork(&desiredOutput);
#endif
#ifdef AND
		Brain.Calculate_Output_TwoLayerNetwork(&output, InputArray1);
		desiredOutput = 0.0f;
		error += Brain.Learning_TwoLayerNetwork(&desiredOutput);

		Brain.Calculate_Output_TwoLayerNetwork(&output, InputArray2);
		desiredOutput = 0.0f;
		error += Brain.Learning_TwoLayerNetwork(&desiredOutput);

		Brain.Calculate_Output_TwoLayerNetwork(&output, InputArray3);
		desiredOutput = 0.0f;
		error += Brain.Learning_TwoLayerNetwork(&desiredOutput);

		Brain.Calculate_Output_TwoLayerNetwork(&output, InputArray4);
		desiredOutput = 1.0f;
		error += Brain.Learning_TwoLayerNetwork(&desiredOutput);
#endif
#ifdef NOR
		Brain.Calculate_Output_TwoLayerNetwork(&output, InputArray1);
		desiredOutput = 1.0f;
		error += Brain.Learning_TwoLayerNetwork(&desiredOutput);

		Brain.Calculate_Output_TwoLayerNetwork(&output, InputArray2);
		desiredOutput = 0.0f;
		error += Brain.Learning_TwoLayerNetwork(&desiredOutput);

		Brain.Calculate_Output_TwoLayerNetwork(&output, InputArray3);
		desiredOutput = 0.0f;
		error += Brain.Learning_TwoLayerNetwork(&desiredOutput);

		Brain.Calculate_Output_TwoLayerNetwork(&output, InputArray4);
		desiredOutput = 0.0f;
		error += Brain.Learning_TwoLayerNetwork(&desiredOutput);
#endif
#ifdef NAND
		Brain.Calculate_Output_TwoLayerNetwork(&output, InputArray1);
		desiredOutput = 1.0f;
		error += Brain.Learning_TwoLayerNetwork(&desiredOutput);

		Brain.Calculate_Output_TwoLayerNetwork(&output, InputArray2);
		desiredOutput = 1.0f;
		error += Brain.Learning_TwoLayerNetwork(&desiredOutput);

		Brain.Calculate_Output_TwoLayerNetwork(&output, InputArray3);
		desiredOutput = 1.0f;
		error += Brain.Learning_TwoLayerNetwork(&desiredOutput);

		Brain.Calculate_Output_TwoLayerNetwork(&output, InputArray4);
		desiredOutput = 0.0f;
		error += Brain.Learning_TwoLayerNetwork(&desiredOutput);
#endif

		if (error < 0.001f)
			break;

	}

	// training completed

	// training statistics:

	cout << "epoch: " << epoch << endl;
	cout << "error: " << error << endl << endl;

	// neural network tests:

#ifdef OR
	Brain.Calculate_Output_TwoLayerNetwork(&output, InputArray1);
	cout << "input : " << Input1a << " --- " << Input1b;
	cout << "  output: " << output << " --- desired output: " << 0.0f << endl;
	// => output: 0

	Brain.Calculate_Output_TwoLayerNetwork(&output, InputArray2);
	cout << "input : " << Input2a << " --- " << Input2b;
	cout << "  output: " << output << " --- desired output: " << 1.0f << endl;
	// => output: 1

	Brain.Calculate_Output_TwoLayerNetwork(&output, InputArray3);
	cout << "input : " << Input3a << " --- " << Input3b;
	cout << "  output: " << output << " --- desired output: " << 1.0f << endl;
	// => output: 1

	Brain.Calculate_Output_TwoLayerNetwork(&output, InputArray4);
	cout << "input : " << Input4a << " --- " << Input4b;
	cout << "  output: " << output << " --- desired output: " << 1.0f << endl;
	// => output: 1
#endif
#ifdef AND
	Brain.Calculate_Output_TwoLayerNetwork(&output, InputArray1);
	cout << "input : " << Input1a << " --- " << Input1b;
	cout << "  output: " << output << " --- desired output: " << 0.0f << endl;
	// => output: 0

	Brain.Calculate_Output_TwoLayerNetwork(&output, InputArray2);
	cout << "input : " << Input2a << " --- " << Input2b;
	cout << "  output: " << output << " --- desired output: " << 0.0f << endl;
	// => output: 0

	Brain.Calculate_Output_TwoLayerNetwork(&output, InputArray3);
	cout << "input : " << Input3a << " --- " << Input3b;
	cout << "  output: " << output << " --- desired output: " << 0.0f << endl;
	// => output: 0

	Brain.Calculate_Output_TwoLayerNetwork(&output, InputArray4);
	cout << "input : " << Input4a << " --- " << Input4b;
	cout << "  output: " << output << " --- desired output: " << 1.0f << endl;
	// => output: 1
#endif
#ifdef NOR
	Brain.Calculate_Output_TwoLayerNetwork(&output, InputArray1);
	cout << "input : " << Input1a << " --- " << Input1b;
	cout << "  output: " << output << " --- desired output: " << 1.0f << endl;
	// => output: 1

	Brain.Calculate_Output_TwoLayerNetwork(&output, InputArray2);
	cout << "input : " << Input2a << " --- " << Input2b;
	cout << "  output: " << output << " --- desired output: " << 0.0f << endl;
	// => output: 0

	Brain.Calculate_Output_TwoLayerNetwork(&output, InputArray3);
	cout << "input : " << Input3a << " --- " << Input3b;
	cout << "  output: " << output << " --- desired output: " << 0.0f << endl;
	// => output: 0

	Brain.Calculate_Output_TwoLayerNetwork(&output, InputArray4);
	cout << "input : " << Input4a << " --- " << Input4b;
	cout << "  output: " << output << " --- desired output: " << 0.0f << endl;
	// => output: 0
#endif
#ifdef NAND
	Brain.Calculate_Output_TwoLayerNetwork(&output, InputArray1);
	cout << "input : " << Input1a << " --- " << Input1b;
	cout << "  output: " << output << " --- desired output: " << 1.0f << endl;
	// => output: 1

	Brain.Calculate_Output_TwoLayerNetwork(&output, InputArray2);
	cout << "input : " << Input2a << " --- " << Input2b;
	cout << "  output: " << output << " --- desired output: " << 1.0f << endl;
	// => output: 1

	Brain.Calculate_Output_TwoLayerNetwork(&output, InputArray3);
	cout << "input : " << Input3a << " --- " << Input3b;
	cout << "  output: " << output << " --- desired output: " << 1.0f << endl;
	// => output: 1

	Brain.Calculate_Output_TwoLayerNetwork(&output, InputArray4);
	cout << "input : " << Input4a << " --- " << Input4b;
	cout << "  output: " << output << " --- desired output: " << 0.0f << endl;
	// => output: 0
#endif

	getchar();
	return 0;
}
*/