#include <iostream>
#include "NeuralNet.h"

using namespace std;




inline float TanHOutput(float neuronInput)
{
	// von -1.0f bis 1.0f:
	return tanh(neuronInput);
}

inline float TrinaryOutput(float neuronInput)
{
	if (neuronInput > 0.9999f)
		return 1.0f;
	else if (neuronInput < -0.9999f)
		return -1.0f;
	else
		return 0.0f;
}


static constexpr uint32_t NumPatternElements = 16;
static constexpr uint32_t NumOfLearnablePatterns = 3;


class CIterativePatternRecognitionBrain
{
public:

	uint32_t NumInputNeurons = NumPatternElements;
	uint32_t NumHiddenNeurons = NumOfLearnablePatterns;
	uint32_t NumOutputNeurons = NumPatternElements;

	uint32_t NumNeurons = NumInputNeurons + NumHiddenNeurons + NumOutputNeurons;
	uint32_t FirstHiddenNeuronID = NumInputNeurons;
	uint32_t FirstOutputNeuronID = FirstHiddenNeuronID + NumHiddenNeurons;

	CNeuron *pNeuronArray = nullptr;

	CRandomNumbersNN RandomNumbers;
	
	CIterativePatternRecognitionBrain()
	{
		pNeuronArray = new (std::nothrow) CNeuron[NumNeurons];

		uint32_t i, j, id;

		for (i = 0; i < NumNeurons; i++)
			pNeuronArray[i].Connect_With_Brain(pNeuronArray);

		for (i = 0; i < NumInputNeurons; i++)
		{
			pNeuronArray[i].Use_As_InputNeuron();
			pNeuronArray[i].Init_OutputSynapses(NumHiddenNeurons);
			pNeuronArray[i].Randomize_OutputSynapsePlasticities(&RandomNumbers, -0.002f, 0.002f);
			pNeuronArray[i].Set_LearningRate(0.1f);
			

			for (j = 0; j < NumHiddenNeurons; j++)
			{
				pNeuronArray[i].Connect_With_ReceiverNeuron(/*NeuronID:*/ FirstHiddenNeuronID + j, /*SynapseID:*/ j);
			}
		}

		for (i = 0; i < NumHiddenNeurons; i++)
		{
			id = FirstHiddenNeuronID + i;

			pNeuronArray[id].Use_As_HiddenNeuron();
			pNeuronArray[id].Init_OutputSynapses(NumOutputNeurons);
			pNeuronArray[id].Randomize_OutputSynapsePlasticities(&RandomNumbers, -0.002f, 0.002f);
			pNeuronArray[id].Set_LearningRate(0.1f);
			pNeuronArray[id].Set_ActivationFunction(TanHOutput);
			//pNeuronArray[id].Set_ActivationFunction(TrinaryOutput);
			
			for (j = 0; j < NumOutputNeurons; j++)
			{
				pNeuronArray[id].Connect_With_ReceiverNeuron(/*NeuronID:*/ FirstOutputNeuronID + j, /*SynapseID:*/ j);
			}
		}

		for (i = 0; i < NumOutputNeurons; i++)
		{
			id = FirstOutputNeuronID + i;

			pNeuronArray[id].Use_As_OutputNeuron();
			pNeuronArray[id].Set_ErrorFactors(1.0f, 1.0f);
			pNeuronArray[id].Set_ActivationFunction(TanHOutput);
			//pNeuronArray[id].Set_ActivationFunction(TrinaryOutput);
		}
	}

	CIterativePatternRecognitionBrain(uint32_t numOfLearnablePatterns)
	{
		NumHiddenNeurons = numOfLearnablePatterns;

		NumNeurons = NumInputNeurons + NumHiddenNeurons + NumOutputNeurons;
		FirstHiddenNeuronID = NumInputNeurons;
		FirstOutputNeuronID = FirstHiddenNeuronID + NumHiddenNeurons;

		pNeuronArray = new (std::nothrow) CNeuron[NumNeurons];

		uint32_t i, j, id;

		for (i = 0; i < NumNeurons; i++)
			pNeuronArray[i].Connect_With_Brain(pNeuronArray);

		for (i = 0; i < NumInputNeurons; i++)
		{
			pNeuronArray[i].Use_As_InputNeuron();
			pNeuronArray[i].Init_OutputSynapses(NumHiddenNeurons);
			pNeuronArray[i].Randomize_OutputSynapsePlasticities(&RandomNumbers, -0.002f, 0.002f);
			pNeuronArray[i].Set_LearningRate(0.1f);


			for (j = 0; j < NumHiddenNeurons; j++)
			{
				pNeuronArray[i].Connect_With_ReceiverNeuron(/*NeuronID:*/ FirstHiddenNeuronID + j, /*SynapseID:*/ j);
			}
		}

		for (i = 0; i < NumHiddenNeurons; i++)
		{
			id = FirstHiddenNeuronID + i;

			pNeuronArray[id].Use_As_HiddenNeuron();
			pNeuronArray[id].Init_OutputSynapses(NumOutputNeurons);
			pNeuronArray[id].Randomize_OutputSynapsePlasticities(&RandomNumbers, -0.002f, 0.002f);
			pNeuronArray[id].Set_LearningRate(0.1f);
			pNeuronArray[id].Set_ActivationFunction(TanHOutput);
			//pNeuronArray[id].Set_ActivationFunction(TrinaryOutput);

			for (j = 0; j < NumOutputNeurons; j++)
			{
				pNeuronArray[id].Connect_With_ReceiverNeuron(/*NeuronID:*/ FirstOutputNeuronID + j, /*SynapseID:*/ j);
			}
		}

		for (i = 0; i < NumOutputNeurons; i++)
		{
			id = FirstOutputNeuronID + i;

			pNeuronArray[id].Use_As_OutputNeuron();
			pNeuronArray[id].Set_ErrorFactors(1.0f, 1.0f);
			pNeuronArray[id].Set_ActivationFunction(TanHOutput);
			//pNeuronArray[id].Set_ActivationFunction(TrinaryOutput);
		}
	}

	~CIterativePatternRecognitionBrain()
	{
		delete[] pNeuronArray;
		pNeuronArray = nullptr;
	}

	// Kopierkonstruktor l�schen:
	CIterativePatternRecognitionBrain(const CIterativePatternRecognitionBrain &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CIterativePatternRecognitionBrain& operator=(const CIterativePatternRecognitionBrain &originalObject) = delete;


	float Calculate_Output_With_Error(float *pOutputPattern, const float *pInputPattern)
	{
		uint32_t i, id;

		for (i = 0; i < NumInputNeurons; i++)
		{
			pNeuronArray[i].Set_Input(pInputPattern[i]);
			pNeuronArray[i].Propagate_SynapticOutput();
		}

		
		for (i = 0; i < NumHiddenNeurons; i++)
		{
			id = FirstHiddenNeuronID + i;
			pNeuronArray[id].Calculate_NeuronOutput();
			pNeuronArray[id].Propagate_SynapticOutput();
		}

		

		for (i = 0; i < NumOutputNeurons; i++)
		{
			id = FirstOutputNeuronID + i;
			pNeuronArray[id].Calculate_NeuronOutput();
			pOutputPattern[i] = pNeuronArray[id].Get_NeuronOutput();
		}

		float error = 0.0f;

		for (i = 0; i < NumOutputNeurons; i++)
		{
			id = FirstOutputNeuronID + i;
			error += pNeuronArray[id].Calculate_Error(pInputPattern[i]);
		}

		return error;
	}

	void Calculate_Output_Without_Error(float *pOutputPattern, const float *pInputPattern)
	{
		uint32_t i, id;

		for (i = 0; i < NumInputNeurons; i++)
		{
			pNeuronArray[i].Set_Input(pInputPattern[i]);
			pNeuronArray[i].Propagate_SynapticOutput();
		}


		for (i = 0; i < NumHiddenNeurons; i++)
		{
			id = FirstHiddenNeuronID + i;
			pNeuronArray[id].Calculate_NeuronOutput();
			pNeuronArray[id].Propagate_SynapticOutput();
		}

		
		for (i = 0; i < NumOutputNeurons; i++)
		{
			id = FirstOutputNeuronID + i;
			pNeuronArray[id].Calculate_NeuronOutput();
			pOutputPattern[i] = pNeuronArray[id].Get_NeuronOutput();
		}
	}

	float Learning(const float *pDesiredOutputPattern)
	{
		float error = 0.0f;

		uint32_t i, id;

		for (i = 0; i < NumOutputNeurons; i++)
		{
			id = FirstOutputNeuronID + i;
			error += pNeuronArray[id].Calculate_Error(pDesiredOutputPattern[i]);
		}

		for (i = 0; i < NumHiddenNeurons; i++)
		{
			id = FirstHiddenNeuronID + i;
			pNeuronArray[id].Calculate_Error();
		}

		for (i = 0; i < NumHiddenNeurons; i++)
		{
			id = FirstHiddenNeuronID + i;
			pNeuronArray[id].Adjust_OutputSynapses_AfterErrorCalculations();
		}

		for (i = 0; i < NumInputNeurons; i++)
			pNeuronArray[i].Adjust_OutputSynapses_AfterErrorCalculations();

		return error;
	}
}; // end of class CIterativePatternRecognitionBrain

/*
int main(void)
{
	//CIterativePatternRecognitionBrain Brain;
	CIterativePatternRecognitionBrain Brain(6);

	float InputPattern1[NumPatternElements];

	InputPattern1[0] = 1.0f;
	InputPattern1[1] = 1.0f;
	InputPattern1[2] = -1.0f;
	InputPattern1[3] = -1.0f;

	InputPattern1[4] = 1.0f;
	InputPattern1[5] = 1.0f;
	InputPattern1[6] = -1.0f;
	InputPattern1[7] = -1.0f;

	InputPattern1[8] = -1.0f;
	InputPattern1[9] = -1.0f;
	InputPattern1[10] = 1.0f;
	InputPattern1[11] = 1.0f;

	InputPattern1[12] = -1.0f;
	InputPattern1[13] = -1.0f;
	InputPattern1[14] = 1.0f;
	InputPattern1[15] = 1.0f;


	float InputPattern2[NumPatternElements];

	InputPattern2[0] = -1.0f;
	InputPattern2[1] = -1.0f;
	InputPattern2[2] = -1.0f;
	InputPattern2[3] = -1.0f;

	InputPattern2[4] = -1.0f;
	InputPattern2[5] = 1.0f;
	InputPattern2[6] = 1.0f;
	InputPattern2[7] = -1.0f;

	InputPattern2[8] = -1.0f;
	InputPattern2[9] = 1.0f;
	InputPattern2[10] = 1.0f;
	InputPattern2[11] = -1.0f;

	InputPattern2[12] = -1.0f;
	InputPattern2[13] = -1.0f;
	InputPattern2[14] = -1.0f;
	InputPattern2[15] = -1.0f;

	float InputPattern3[NumPatternElements];

	InputPattern3[0] = 1.0f;
	InputPattern3[1] = 1.0f;
	InputPattern3[2] = 1.0f;
	InputPattern3[3] = 1.0f;

	InputPattern3[4] = -1.0f;
	InputPattern3[5] = -1.0f;
	InputPattern3[6] = -1.0f;
	InputPattern3[7] = -1.0f;

	InputPattern3[8] = -1.0f;
	InputPattern3[9] = -1.0f;
	InputPattern3[10] = -1.0f;
	InputPattern3[11] = -1.0f;

	InputPattern3[12] = 1.0f;
	InputPattern3[13] = 1.0f;
	InputPattern3[14] = 1.0f;
	InputPattern3[15] = 1.0f;



	float OutputPattern[NumPatternElements];


	uint32_t maxcount = 20000;
	uint32_t epoch = 0;
	float error;

	uint32_t i;

	// start training:

	for (i = 0; i < maxcount; i++)
	{
		epoch++;
		error = 0.0f;

		Brain.Calculate_Output_Without_Error(OutputPattern, InputPattern1);
		error += Brain.Learning(InputPattern1);
		

		Brain.Calculate_Output_Without_Error(OutputPattern, InputPattern2);
		error += Brain.Learning(InputPattern2);
		

		Brain.Calculate_Output_Without_Error(OutputPattern, InputPattern3);
		error += Brain.Learning(InputPattern3);
		

		if (error < 0.0001f)
			break;
	}

	// training completed


	// training statistics:

	cout << "epoch: " << epoch << endl;
	cout << "error: " << error << endl << endl;

	// neural network tests:

	error = Brain.Calculate_Output_With_Error(OutputPattern, InputPattern1);
	// => error == 0.0f

	cout << "InputPattern1: ";

	for (i = 0; i < NumPatternElements; i++)
	{
		if (InputPattern1[i] > 0.0f)
			cout << 1;
		else
			cout << 0;
	}

	cout << endl;

	cout << "Output: ";

	for (i = 0; i < NumPatternElements; i++)
	{
		if (OutputPattern[i] > 0.0f)
			cout << 1;
		else
			cout << 0;
	}

	cout << endl << "recognition error: " << error << endl;
	cout << endl << endl;

	error = Brain.Calculate_Output_With_Error(OutputPattern, InputPattern2);
	// => error == 0.0f

	cout << "InputPattern2: ";

	for (i = 0; i < NumPatternElements; i++)
	{
		if (InputPattern2[i] > 0.0f)
			cout << 1;
		else
			cout << 0;
	}

	cout << endl;

	cout << "Output: ";

	for (i = 0; i < NumPatternElements; i++)
	{
		if (OutputPattern[i] > 0.0f)
			cout << 1;
		else
			cout << 0;
	}

	cout << endl << "recognition error: " << error << endl;
	cout << endl << endl;

	error = Brain.Calculate_Output_With_Error(OutputPattern, InputPattern3);
	// => error == 0.0f

	cout << "InputPattern3: ";

	for (i = 0; i < NumPatternElements; i++)
	{
		if (InputPattern3[i] > 0.0f)
			cout << 1;
		else
			cout << 0;
	}

	cout << endl;

	cout << "Output: ";

	for (i = 0; i < NumPatternElements; i++)
	{
		if (OutputPattern[i] > 0.0f)
			cout << 1;
		else
			cout << 0;
	}

	cout << endl << "recognition error: " << error << endl;
	cout << endl << endl;


	////////////////////////////////////////////////////

	// incomplete patterns:

	// add noise:
	InputPattern2[1] = 1.0f;
	InputPattern2[12] = 1.0f;
	InputPattern2[13] = 1.0f;
	

	// schrittweise entrauschen:
	error = Brain.Calculate_Output_With_Error(OutputPattern, InputPattern2);
	// => error > 0.0f
	error = Brain.Calculate_Output_With_Error(OutputPattern, OutputPattern);
	// => error == 0.0f

	cout << "Input: ";

	for (i = 0; i < NumPatternElements; i++)
	{
		if (InputPattern2[i] > 0.0f)
			cout << 1;
		else
			cout << 0;
	}

	cout << endl;

	cout << "Output: ";

	for (i = 0; i < NumPatternElements; i++)
	{
		if (OutputPattern[i] > 0.0f)
			cout << 1;
		else
			cout << 0;
	}

	cout << endl << "recognition error: " << error << endl;
	cout << endl << endl;


	// add noise:
	InputPattern3[8] = 1.0f;
	InputPattern3[9] = 1.0f;


	// schrittweise entrauschen:
	error = Brain.Calculate_Output_With_Error(OutputPattern, InputPattern3);
	// => error > 0.0f
	error = Brain.Calculate_Output_With_Error(OutputPattern, OutputPattern);
	// => error == 0.0f

	cout << "Input: ";

	for (i = 0; i < NumPatternElements; i++)
	{
		if (InputPattern3[i] > 0.0f)
			cout << 1;
		else
			cout << 0;
	}

	cout << endl;

	cout << "Output: ";

	for (i = 0; i < NumPatternElements; i++)
	{
		if (OutputPattern[i] > 0.0f)
			cout << 1;
		else
			cout << 0;
	}

	cout << endl << "recognition error: " << error << endl;
	cout << endl << endl;



	getchar();
	return 0;
}
*/



/*
int main(void)
{
	CNeuralNet Brain;

	Brain.Init_NeuralNet(2 * NumPatternElements + NumOfLearnablePatterns);
	Brain.Init_Input_And_OutputNeurons(NumPatternElements, 0.1f, false, NumPatternElements, TanHOutput);
	Brain.Init_HiddenLayer1(NumOfLearnablePatterns, false, true, TanHOutput, -0.002f, 0.002f, -0.002f, 0.002f, 0.1f);
	
	float InputPattern1[NumPatternElements];

	InputPattern1[0] = 1.0f;
	InputPattern1[1] = 1.0f;
	InputPattern1[2] = -1.0f;
	InputPattern1[3] = -1.0f;

	InputPattern1[4] = 1.0f;
	InputPattern1[5] = 1.0f;
	InputPattern1[6] = -1.0f;
	InputPattern1[7] = -1.0f;

	InputPattern1[8] = -1.0f;
	InputPattern1[9] = -1.0f;
	InputPattern1[10] = 1.0f;
	InputPattern1[11] = 1.0f;

	InputPattern1[12] = -1.0f;
	InputPattern1[13] = -1.0f;
	InputPattern1[14] = 1.0f;
	InputPattern1[15] = 1.0f;


	float InputPattern2[NumPatternElements];

	InputPattern2[0] = -1.0f;
	InputPattern2[1] = -1.0f;
	InputPattern2[2] = -1.0f;
	InputPattern2[3] = -1.0f;

	InputPattern2[4] = -1.0f;
	InputPattern2[5] = 1.0f;
	InputPattern2[6] = 1.0f;
	InputPattern2[7] = -1.0f;

	InputPattern2[8] = -1.0f;
	InputPattern2[9] = 1.0f;
	InputPattern2[10] = 1.0f;
	InputPattern2[11] = -1.0f;

	InputPattern2[12] = -1.0f;
	InputPattern2[13] = -1.0f;
	InputPattern2[14] = -1.0f;
	InputPattern2[15] = -1.0f;

	float InputPattern3[NumPatternElements];

	InputPattern3[0] = 1.0f;
	InputPattern3[1] = 1.0f;
	InputPattern3[2] = 1.0f;
	InputPattern3[3] = 1.0f;

	InputPattern3[4] = -1.0f;
	InputPattern3[5] = -1.0f;
	InputPattern3[6] = -1.0f;
	InputPattern3[7] = -1.0f;

	InputPattern3[8] = -1.0f;
	InputPattern3[9] = -1.0f;
	InputPattern3[10] = -1.0f;
	InputPattern3[11] = -1.0f;

	InputPattern3[12] = 1.0f;
	InputPattern3[13] = 1.0f;
	InputPattern3[14] = 1.0f;
	InputPattern3[15] = 1.0f;



	float OutputPattern[NumPatternElements];


	uint32_t maxcount = 120000;
	uint32_t epoch = 0;
	float error;

	uint32_t i;

	// start training:

	for (i = 0; i < maxcount; i++)
	{
		epoch++;
		error = 0.0f;

		Brain.Calculate_Output(OutputPattern, InputPattern1);
		error += Brain.Learning(InputPattern1);
		

		Brain.Calculate_Output(OutputPattern, InputPattern2);
		error += Brain.Learning(InputPattern2);
		

		Brain.Calculate_Output(OutputPattern, InputPattern3);
		error += Brain.Learning(InputPattern3);
		
		
		if (error < 0.0001f)
			break;
	}

	// training completed


	// training statistics:

	cout << "epoch: " << epoch << endl;
	cout << "error: " << error << endl << endl;

	// neural network tests:

	error = Brain.Calculate_Output_With_Error(OutputPattern, InputPattern1);
	// => error == 0.0f

	cout << "InputPattern1: ";

	for (i = 0; i < NumPatternElements; i++)
	{
		if (InputPattern1[i] > 0.0f)
			cout << 1;
		else
			cout << 0;
	}

	cout << endl;

	cout << "Output: ";

	for (i = 0; i < NumPatternElements; i++)
	{
		if (OutputPattern[i] > 0.0f)
			cout << 1;
		else
			cout << 0;
	}

	cout << endl << "recognition error: " << error << endl;
	cout << endl << endl;

	error = Brain.Calculate_Output_With_Error(OutputPattern, InputPattern2);
	// => error == 0.0f

	cout << "InputPattern2: ";

	for (i = 0; i < NumPatternElements; i++)
	{
		if (InputPattern2[i] > 0.0f)
			cout << 1;
		else
			cout << 0;
	}

	cout << endl;

	cout << "Output: ";

	for (i = 0; i < NumPatternElements; i++)
	{
		if (OutputPattern[i] > 0.0f)
			cout << 1;
		else
			cout << 0;
	}

	cout << endl << "recognition error: " << error << endl;
	cout << endl << endl;

	error = Brain.Calculate_Output_With_Error(OutputPattern, InputPattern3);
	// => error == 0.0f

	cout << "InputPattern3: ";

	for (i = 0; i < NumPatternElements; i++)
	{
		if (InputPattern3[i] > 0.0f)
			cout << 1;
		else
			cout << 0;
	}

	cout << endl;

	cout << "Output: ";

	for (i = 0; i < NumPatternElements; i++)
	{
		if (OutputPattern[i] > 0.0f)
			cout << 1;
		else
			cout << 0;
	}

	cout << endl << "recognition error: " << error << endl;
	cout << endl << endl;

	////////////////////////////////////////////////////

	// incomplete patterns:

	// add noise:
	InputPattern2[1] = 1.0f;
	InputPattern2[12] = 1.0f;
	InputPattern2[13] = 1.0f;

	// schrittweise entrauschen:
	error = Brain.Calculate_Output_With_Error(OutputPattern, InputPattern2);
	// => error > 0.0f
	error = Brain.Calculate_Output_With_Error(OutputPattern, OutputPattern);
	// => error == 0.0f

	cout << "Input: ";

	for (i = 0; i < NumPatternElements; i++)
	{
		if (InputPattern2[i] > 0.0f)
			cout << 1;
		else
			cout << 0;
	}

	cout << endl;

	cout << "Output: ";

	for (i = 0; i < NumPatternElements; i++)
	{
		if (OutputPattern[i] > 0.0f)
			cout << 1;
		else
			cout << 0;
	}

	cout << endl << "recognition error: " << error << endl;
	cout << endl << endl;


	// add noise:
	InputPattern3[8] = 1.0f;
	InputPattern3[9] = 1.0f;


	// schrittweise entrauschen:
	error = Brain.Calculate_Output_With_Error(OutputPattern, InputPattern3);
	// => error > 0.0f
	error = Brain.Calculate_Output_With_Error(OutputPattern, OutputPattern);
	// => error == 0.0f

	cout << "Input: ";

	for (i = 0; i < NumPatternElements; i++)
	{
		if (InputPattern3[i] > 0.0f)
			cout << 1;
		else
			cout << 0;
	}

	cout << endl;

	cout << "Output: ";

	for (i = 0; i < NumPatternElements; i++)
	{
		if (OutputPattern[i] > 0.0f)
			cout << 1;
		else
			cout << 0;
	}

	cout << endl << "recognition error: " << error << endl;
	cout << endl << endl;



	getchar();
	return 0;
}
*/





/*
int main(void)
{
	CIterativePatternRecognitionBrain Brain1(1);
	CIterativePatternRecognitionBrain Brain2(1);

	float TestInputPattern[NumPatternElements];

	TestInputPattern[0] = 1.0f;
	TestInputPattern[1] = 1.0f;
	TestInputPattern[2] = -1.0f;
	TestInputPattern[3] = -1.0f;

	TestInputPattern[4] = 1.0f;
	TestInputPattern[5] = -1.0f;
	TestInputPattern[6] = -1.0f;
	TestInputPattern[7] = -1.0f;

	TestInputPattern[8] = -1.0f;
	TestInputPattern[9] = -1.0f;
	TestInputPattern[10] = 1.0f;
	TestInputPattern[11] = 1.0f;

	TestInputPattern[12] = 1.0f;
	TestInputPattern[13] = -1.0f;
	TestInputPattern[14] = 1.0f;
	TestInputPattern[15] = 1.0f;


	float InputPattern1[NumPatternElements];

	InputPattern1[0] = 1.0f;
	InputPattern1[1] = 1.0f;
	InputPattern1[2] = -1.0f;
	InputPattern1[3] = -1.0f;

	InputPattern1[4] = 1.0f;
	InputPattern1[5] = 1.0f;
	InputPattern1[6] = -1.0f;
	InputPattern1[7] = -1.0f;

	InputPattern1[8] = -1.0f;
	InputPattern1[9] = -1.0f;
	InputPattern1[10] = 1.0f;
	InputPattern1[11] = 1.0f;

	InputPattern1[12] = -1.0f;
	InputPattern1[13] = -1.0f;
	InputPattern1[14] = 1.0f;
	InputPattern1[15] = 1.0f;


	float InputPattern2[NumPatternElements];

	InputPattern2[0] = -1.0f;
	InputPattern2[1] = -1.0f;
	InputPattern2[2] = -1.0f;
	InputPattern2[3] = -1.0f;

	InputPattern2[4] = -1.0f;
	InputPattern2[5] = 1.0f;
	InputPattern2[6] = 1.0f;
	InputPattern2[7] = -1.0f;

	InputPattern2[8] = -1.0f;
	InputPattern2[9] = 1.0f;
	InputPattern2[10] = 1.0f;
	InputPattern2[11] = -1.0f;

	InputPattern2[12] = -1.0f;
	InputPattern2[13] = -1.0f;
	InputPattern2[14] = -1.0f;
	InputPattern2[15] = -1.0f;

	float OutputPattern[NumPatternElements];


	uint32_t maxcount = 20000;
	uint32_t epoch = 0;
	float error;

	uint32_t i;

	// start training:

	for (i = 0; i < maxcount; i++)
	{
		epoch++;
		error = 0.0f;

		Brain1.Calculate_Output_Without_Error(OutputPattern, InputPattern1);
		error += Brain1.Learning(InputPattern1);

		if (error < 0.00001f)
			break;
	}

	// training statistics:

	cout << "epoch (Brain1): " << epoch << endl;
	cout << "error (Brain1): " << error << endl << endl;

	for (i = 0; i < maxcount; i++)
	{
		epoch++;
		error = 0.0f;

		Brain2.Calculate_Output_Without_Error(OutputPattern, InputPattern2);
		error += Brain2.Learning(InputPattern2);

		if (error < 0.00001f)
			break;
	}

	// training completed


	// training statistics:

	cout << "epoch (Brain2): " << epoch << endl;
	cout << "error (Brain2): " << error << endl << endl;

	
	// neural network tests:

	cout << "Brain1.Calculate_Output_With_Error(OutputPattern, InputPattern1);" << endl;
	error = Brain1.Calculate_Output_With_Error(OutputPattern, InputPattern1);
	// => error == 0.0f

	cout << "Input: ";

	for (i = 0; i < NumPatternElements; i++)
	{
		if (InputPattern1[i] > 0.0f)
			cout << 1;
		else
			cout << 0;
	}

	cout << endl;

	cout << "Output: ";

	for (i = 0; i < NumPatternElements; i++)
	{
		if (OutputPattern[i] > 0.0f)
			cout << 1;
		else
			cout << 0;
	}

	cout << endl << "recognition error: " << error << endl;
	cout << endl << endl;

	cout << "Brain2.Calculate_Output_With_Error(OutputPattern, InputPattern2);" << endl;
	error = Brain2.Calculate_Output_With_Error(OutputPattern, InputPattern2);
	// => error == 0.0f

	cout << "Input: ";

	for (i = 0; i < NumPatternElements; i++)
	{
		if (InputPattern2[i] > 0.0f)
			cout << 1;
		else
			cout << 0;
	}

	cout << endl;

	cout << "Output: ";

	for (i = 0; i < NumPatternElements; i++)
	{
		if (OutputPattern[i] > 0.0f)
			cout << 1;
		else
			cout << 0;
	}

	cout << endl << "recognition error: " << error << endl;
	cout << endl << endl;

	cout << "Brain1.Calculate_Output_With_Error(OutputPattern, TestInputPattern);" << endl;
	error = Brain1.Calculate_Output_With_Error(OutputPattern, TestInputPattern);

	cout << "Input: ";

	for (i = 0; i < NumPatternElements; i++)
	{
		if (TestInputPattern[i] > 0.0f)
			cout << 1;
		else
			cout << 0;
	}

	cout << endl;

	cout << "Output (InputPattern1): ";

	for (i = 0; i < NumPatternElements; i++)
	{
		if (OutputPattern[i] > 0.0f)
			cout << 1;
		else
			cout << 0;
	}

	cout << endl << "recognition error: " << error << endl;
	cout << endl << endl;

	cout << "Brain2.Calculate_Output_With_Error(OutputPattern, TestInputPattern);" << endl;
	error = Brain2.Calculate_Output_With_Error(OutputPattern, TestInputPattern);

	cout << "Input: ";

	for (i = 0; i < NumPatternElements; i++)
	{
		if (TestInputPattern[i] > 0.0f)
			cout << 1;
		else
			cout << 0;
	}

	cout << endl;

	cout << "Output (Inverse of InputPattern2): ";

	for (i = 0; i < NumPatternElements; i++)
	{
		if (OutputPattern[i] > 0.0f)
			cout << 1;
		else
			cout << 0;
	}

	cout << endl << "recognition error: " << error << endl;
	cout << endl << endl;


	getchar();
	return 0;
}
*/