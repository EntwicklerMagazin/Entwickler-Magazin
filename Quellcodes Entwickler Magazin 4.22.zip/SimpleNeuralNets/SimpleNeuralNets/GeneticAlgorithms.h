// Schutz vor Mehrfachdeklarationen :

#ifndef _GeneticAlgorithms_H_
#define _GeneticAlgorithms_H_

#include <iostream>
#include "RandomNumbers.h"

typedef void(*pGeneralRecombination)(void *pOffspring, void *pParent1, void *pParent2, CRandomNumbersNN *pRandomNumbers, void *pParam);
typedef void(*pGeneralMutation)(void *pInOutGenome, CRandomNumbersNN *pRandomNumbers, void *pParam);
typedef void(*pGeneralPermutation)(void *pInOutGenome, CRandomNumbersNN *pRandomNumbers, void *pParam);
typedef void(*pGeneralReinitialization)(void *pInOutGenome, CRandomNumbersNN *pRandomNumbers, void *pParam);

typedef void(*pGenomeValueCloning)(void *pOutGenome, void *pInGenome);

class CSimpleIntegerValueGenome
{
public:

	int32_t NumOfGenes = 0;
	int32_t *pGeneArray = nullptr;

	CSimpleIntegerValueGenome() {};

	~CSimpleIntegerValueGenome()
	{
		delete[] pGeneArray;
		pGeneArray = nullptr;
	};

	// Kopierkonstruktor l�schen:
	CSimpleIntegerValueGenome(const CSimpleIntegerValueGenome &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CSimpleIntegerValueGenome& operator=(const CSimpleIntegerValueGenome &originalObject) = delete;

	void Initialize(int32_t numOfGenes)
	{
		delete[] pGeneArray;
		pGeneArray = nullptr;

		NumOfGenes = numOfGenes;

		pGeneArray = new (std::nothrow) int32_t[NumOfGenes];
	}

	void Set_GeneData(int32_t *pData)
	{
		for (int32_t i = 0; i < NumOfGenes; i++)
		{
			pGeneArray[i] = pData[i];
		}
	}

	void Permute_GeneData(CRandomNumbersNN *pRandomNumbers, int32_t minGeneID, int32_t maxGeneID, int32_t permutationSteps)
	{
		for (int32_t i = 0; i < permutationSteps; i++)
		{
			int32_t id1 = pRandomNumbers->Get_IntegerNumber2(minGeneID, maxGeneID);
			int32_t id2 = pRandomNumbers->Get_IntegerNumber2(minGeneID, maxGeneID);

			int32_t tempValue = pGeneArray[id1];

			pGeneArray[id1] = pGeneArray[id2];
			pGeneArray[id2] = tempValue;
		}
	}
};

inline void CSimpleIntegerValueGenome_CloningFunction(void *pOutGenome, void *pInGenome)
{
	CSimpleIntegerValueGenome *pOriginalGenome = static_cast<CSimpleIntegerValueGenome*>(pInGenome);
	CSimpleIntegerValueGenome *pClonedGenome = static_cast<CSimpleIntegerValueGenome*>(pOutGenome);

	int32_t *pOriginalGeneArray = pOriginalGenome->pGeneArray;
	int32_t *pClonedGeneArray = pClonedGenome->pGeneArray;

	int32_t numOfGenes = pOriginalGenome->NumOfGenes;

	for (int32_t i = 0; i < numOfGenes; i++)
		pClonedGeneArray[i] = pOriginalGeneArray[i];
}

class CSimpleFloatValueGenome
{
public:

	int32_t NumOfGenes = 0;
	float *pGeneArray = nullptr;

	CSimpleFloatValueGenome() {};

	~CSimpleFloatValueGenome()
	{
		delete[] pGeneArray;
		pGeneArray = nullptr;
	};

	// Kopierkonstruktor l�schen:
	CSimpleFloatValueGenome(const CSimpleFloatValueGenome &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CSimpleFloatValueGenome& operator=(const CSimpleFloatValueGenome &originalObject) = delete;

	void Initialize(int32_t numOfGenes)
	{
		delete[] pGeneArray;
		pGeneArray = nullptr;

		NumOfGenes = numOfGenes;

		pGeneArray = new (std::nothrow) float[NumOfGenes];
	}

	void Set_GeneData(float *pData)
	{
		for (int32_t i = 0; i < NumOfGenes; i++)
		{
			pGeneArray[i] = pData[i];
		}
	}

	void Permute_GeneData(CRandomNumbersNN *pRandomNumbers, int32_t minGeneID, int32_t maxGeneID, int32_t permutationSteps)
	{
		for (int32_t i = 0; i < permutationSteps; i++)
		{
			int32_t id1 = pRandomNumbers->Get_IntegerNumber2(minGeneID, maxGeneID);
			int32_t id2 = pRandomNumbers->Get_IntegerNumber2(minGeneID, maxGeneID);

			float tempValue = pGeneArray[id1];

			pGeneArray[id1] = pGeneArray[id2];
			pGeneArray[id2] = tempValue;
		}
	}
};

inline void CSimpleFloatValueGenome_CloningFunction(void *pOutGenome, void *pInGenome)
{
	CSimpleFloatValueGenome *pOriginalGenome = static_cast<CSimpleFloatValueGenome*>(pInGenome);
	CSimpleFloatValueGenome *pClonedGenome = static_cast<CSimpleFloatValueGenome*>(pOutGenome);

	float *pOriginalGeneArray = pOriginalGenome->pGeneArray;
	float *pClonedGeneArray = pClonedGenome->pGeneArray;

	int32_t numOfGenes = pOriginalGenome->NumOfGenes;

	for (int32_t i = 0; i < numOfGenes; i++)
		pClonedGeneArray[i] = pOriginalGeneArray[i];
}

class CGeneralPopulation
{
public:

	uint64_t Seed = 1;
	CRandomNumbersNN RandomNumbers;

	int32_t PopulationSize;
	int32_t PopulationSizePlusX;

	static constexpr int32_t constNumOfAdditionalGenomes = 5;
	static constexpr int32_t constNumOfRandomGenomesChildren = constNumOfAdditionalGenomes - 3;

	void **ppGenomeArray = nullptr;
	float *pFitnessScoreArray = nullptr;

	static constexpr int32_t constNumOfBestFittedGenomes = 10;
	int32_t IDArrayOfBestFittedGenomes[constNumOfBestFittedGenomes];
	float FitnessArrayOfBestFittedGenomes[constNumOfBestFittedGenomes];

	static constexpr int32_t constNumOfWorstFittedGenomes = 10;
	int32_t IDArrayOfWorstFittedGenomes[constNumOfWorstFittedGenomes];
	float FitnessArrayOfWorstFittedGenomes[constNumOfWorstFittedGenomes];

	bool UseAdditionalMutatedBestGenome = false;
	bool UseAdditionalMutatedSecondBestGenome = false;
	bool UseAdditionalBestGenomesChild = false;
	bool UseAdditionalRandomGenomesChild[constNumOfRandomGenomesChildren];

	int32_t RandomGenomesChildCounter = 0;

	static constexpr int32_t constNumPopulationSearchStepsMax = 3;

	float MinErrorSum_ActualGeneration;

	pGenomeValueCloning GenomeValueCloningFunc = nullptr;

	CGeneralPopulation();
	~CGeneralPopulation();

	// Kopierkonstruktor l�schen:
	CGeneralPopulation(const CGeneralPopulation &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CGeneralPopulation& operator=(const CGeneralPopulation &originalObject) = delete;

	void Set_GenomeValueCloningFunction(pGenomeValueCloning pFunc);

	void Change_Seed(uint64_t seed);

	bool Initialize(int32_t populationSize);
	void Set_Genome(void *pInGenome, int32_t id);

	void* Get_Best_Evolved_Genome(void);
	void Get_Best_Evolved_Genome(void* pOutGenome);

	void Reset_Population(void);

	void Reset_MinErrorSum_ActualGeneration(float value = 10000000.0f);
	void Update_MinErrorSum_ActualGeneration(float value);

	void Calculate_FitnessScore_FromError(int32_t genomeID, float error);
	void Set_FitnessScore(int32_t genomeID, float score);

	void Update_Population(void);
	void Update_Population_Ext(void);

	void Update_PopulationKnowledge(void);

	void Update_Evolution_Combine_BestTwoGenomes(pGeneralRecombination pFunc, void *pParam);
	void Update_Evolution_Combine_TwoGenomes(pGeneralRecombination pFunc, void *pParam);

	void Update_BaseEvolution(pGeneralMutation pFunc, void *pParam);
	void Update_BaseEvolution2(pGeneralPermutation pFunc, void *pParam);

	void Update_Evolution_BestGenomeOnly(pGeneralMutation pFunc, void *pParam);
	void Update_Evolution_BestGenomeOnly2(pGeneralPermutation pFunc, void *pParam);

	void Update_Evolution_SecondBestGenomeOnly(pGeneralMutation pFunc, void *pParam);
	void Update_Evolution_SecondBestGenomeOnly2(pGeneralPermutation pFunc, void *pParam);

	void Replace_WorstFitted_Genome(pGeneralReinitialization pFunc, void *pParam);
	void Replace_SecondWorstFitted_Genome(pGeneralReinitialization pFunc, void *pParam);
	void Replace_ThirdWorstFitted_Genome(pGeneralReinitialization pFunc, void *pParam);

	void Replace_WorstFitted_Genome(uint64_t seed, pGeneralReinitialization pFunc, void *pParam);
	void Replace_SecondWorstFitted_Genome(uint64_t seed, pGeneralReinitialization pFunc, void *pParam);
	void Replace_ThirdWorstFitted_Genome(uint64_t seed, pGeneralReinitialization pFunc, void *pParam);

	void Modify_All_Genomes(pGeneralMutation pFunc, void *pParam);
	void Modify_All_Genomes2(pGeneralPermutation pFunc, void *pParam);
};



#endif