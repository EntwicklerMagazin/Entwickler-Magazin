#include <iostream>
#include "NeuralNet.h"

using namespace std;

static constexpr uint32_t NumSurfaceMapElements = 49;
static constexpr uint32_t NumSurfaceMapElementsPerDir = 7;

static constexpr uint32_t NumCities_TSP = 12;
static constexpr uint32_t NumNeurons_TSP = NumCities_TSP;

static constexpr uint32_t NumCities_PathFinding = 10;
static constexpr uint32_t NumNeurons_PathFinding = NumCities_PathFinding;


static void Output_SurfaceMapData(char *pData)
{
	uint32_t ix, iy, id;

	for (iy = 0; iy < NumSurfaceMapElementsPerDir; iy++)
	{
		for (ix = 0; ix < NumSurfaceMapElementsPerDir; ix++)
		{
			id = ix + iy * NumSurfaceMapElementsPerDir;
			cout << pData[id] << " ";
		}

		cout << endl;
	}

	cout << endl << endl;
}

static void Set_SurfaceMapData(char *pOutData, uint32_t ix, uint32_t iy, char sign)
{
	uint32_t id = ix + iy * NumSurfaceMapElementsPerDir;
	pOutData[id] = sign;
}

static void Init_SurfaceMap(char *pOutData, char sign)
{
	uint32_t ix, iy, id;

	for (iy = 0; iy < NumSurfaceMapElementsPerDir; iy++)
	{
		for (ix = 0; ix < NumSurfaceMapElementsPerDir; ix++)
		{
			id = ix + iy * NumSurfaceMapElementsPerDir;
			pOutData[id] = sign;
		}
	}
}






// Travelling Salesman Problem:

/*
int main(void)
{
    // Visualisierung der einzelnen St�dte:

	static char SurfaceMap[NumSurfaceMapElements];

	Init_SurfaceMap(SurfaceMap, '*');

	Set_SurfaceMapData(SurfaceMap, 2, 0, '0');
	Set_SurfaceMapData(SurfaceMap, 4, 0, '1');
	Set_SurfaceMapData(SurfaceMap, 0, 1, '2');
	Set_SurfaceMapData(SurfaceMap, 4, 2, '3');
	Set_SurfaceMapData(SurfaceMap, 0, 4, '4');
	Set_SurfaceMapData(SurfaceMap, 2, 3, '5');
	Set_SurfaceMapData(SurfaceMap, 3, 4, '6');
	Set_SurfaceMapData(SurfaceMap, 5, 5, '7');
	Set_SurfaceMapData(SurfaceMap, 6, 3, '8');
	Set_SurfaceMapData(SurfaceMap, 1, 6, '9');
	Set_SurfaceMapData(SurfaceMap, 6, 1, 'A');
	Set_SurfaceMapData(SurfaceMap, 3, 6, 'B');
	

	Output_SurfaceMapData(SurfaceMap);

	// Visualisierung der einzelnen St�dte abgeschlossen

	C3DNeuralMap Brain;
	Brain.Initialize_FullyConnected_NeuralNet(NumNeurons_TSP); //<=NumCities_TSP

	

	Brain.Set_Position(0, 2.0f, 0.0f, 0.0f);
	Brain.Set_Position(1, 4.0f, 0.0f, 0.0f);
	Brain.Set_Position(2, 0.0f, 1.0f, 0.0f);
	Brain.Set_Position(3, 4.0f, 2.0f, 0.0f);
	Brain.Set_Position(4, 0.0f, 4.0f, 0.0f);
	Brain.Set_Position(5, 2.0f, 3.0f, 0.0f);
	Brain.Set_Position(6, 3.0f, 4.0f, 0.0f);
	Brain.Set_Position(7, 5.0f, 5.0f, 0.0f);
	Brain.Set_Position(8, 6.0f, 3.0f, 0.0f);
	Brain.Set_Position(9, 1.0f, 6.0f, 0.0f);
	Brain.Set_Position(10, 6.0f, 1.0f, 0.0f);
	Brain.Set_Position(11, 3.0f, 6.0f, 0.0f);
	
	
	Brain.Calculate_ConnectionDistanceFactors(3, 0.75f);
	
	int32_t IDofFirstAndLastNeuron = 3;
	//int32_t IDofFirstAndLastNeuron = 10;

	float minDistance = 1000000000.0f;

	int32_t pathArray[NumCities_TSP + 1];

	int32_t tempPathArray1[NumCities_TSP + 1];
	int32_t tempPathArray2[NumCities_TSP + 1];



	Brain.Init_Possible_TSP_Path(tempPathArray1);
	Brain.Init_Possible_TSP_Path(tempPathArray2);

	Brain.Mutate_TSP_Path(tempPathArray1);
	Brain.Mutate_TSP_Path(tempPathArray1);
	Brain.Mutate_TSP_Path(tempPathArray1);
	Brain.Mutate_TSP_Path(tempPathArray1);

	Brain.Mutate_TSP_Path(tempPathArray2);
	Brain.Mutate_TSP_Path(tempPathArray2);
	Brain.Mutate_TSP_Path(tempPathArray2);
	Brain.Mutate_TSP_Path(tempPathArray2);

	for (int32_t i = 0; i <= NumNeurons_TSP; i++)
		cout << tempPathArray1[i] << " ";

	cout << endl;

	for (int32_t i = 0; i <= NumNeurons_TSP; i++)
		cout << tempPathArray2[i] << " ";

	cout << endl;

	Brain.Combine_Two_TSP_Paths(pathArray, tempPathArray1, tempPathArray2);

	for (int32_t i = 0; i <= NumNeurons_TSP; i++)
		cout << pathArray[i] << " ";

	cout << endl;


	getchar();

	Brain.Init_And_Mutate_TSP_Path(pathArray, tempPathArray1, tempPathArray2, IDofFirstAndLastNeuron, 10000);
	cout << "TSP_Path_Distance " << Brain.Get_TSP_Path_Length(pathArray) << endl;

	for (int32_t i = 0; i <= NumNeurons_TSP; i++)
		cout << pathArray[i] << " ";

	cout << endl;


	

	
	getchar();
	
	Brain.Prepare_Training();
	
	//for (int32_t j = 0; j < 100000; j++)
	for (int32_t j = 0; j < 1000000; j++)
	{
		Brain.Train_NeuralNet_TSP(IDofFirstAndLastNeuron, 1.0f, 0.1f, 0.95f, true);
	
		Brain.Get_TSP_Path(pathArray, IDofFirstAndLastNeuron);
	
		bool legalPath = Brain.Check_TSP_Path_Legality(pathArray);

		
		if (legalPath == true)
		{
			float distance = Brain.Get_TSP_Path_Length(pathArray);

			if (distance < minDistance)
			{
				minDistance = distance;

				cout << j << " --- " << distance << endl;

				for (int32_t i = 0; i <= NumNeurons_TSP; i++)
					cout << pathArray[i] << " ";

				cout << endl;		
			}
		}
	}

	cout << endl << "calculations finished" << endl;

	

	getchar();
	return 0;
}
*/

// Pathfinding (Routenplanung) - Teil 1:

/*
int main(void)
{
    // Visualisierung der einzelnen St�dte:

	static char SurfaceMap[NumSurfaceMapElements];

	Init_SurfaceMap(SurfaceMap, '*');

	Set_SurfaceMapData(SurfaceMap, 0, 0, '0');
	Set_SurfaceMapData(SurfaceMap, 1, 1, '1');
	Set_SurfaceMapData(SurfaceMap, 3, 1, '2');
	Set_SurfaceMapData(SurfaceMap, 4, 1, '3');
	Set_SurfaceMapData(SurfaceMap, 0, 2, '4');
	Set_SurfaceMapData(SurfaceMap, 3, 2, '5');
	Set_SurfaceMapData(SurfaceMap, 0, 3, '6');
	Set_SurfaceMapData(SurfaceMap, 2, 3, '7');
	Set_SurfaceMapData(SurfaceMap, 2, 4, '8');
	Set_SurfaceMapData(SurfaceMap, 4, 4, '9');

	Output_SurfaceMapData(SurfaceMap);

	// Visualisierung der einzelnen St�dte abgeschlossen

	C3DNeuralMap Brain;
	Brain.Initialize_NeuralNet(NumNeurons_PathFinding); // <= NumCities_PathFinding

	Brain.Set_Position(0, 0.0f, 0.0f, 0.0f);
	Brain.Set_Position(1, 1.0f, 1.0f, 0.0f);
	Brain.Set_Position(2, 3.0f, 1.0f, 0.0f);
	Brain.Set_Position(3, 4.0f, 1.0f, 0.0f);
	Brain.Set_Position(4, 0.0f, 2.0f, 0.0f);
	Brain.Set_Position(5, 3.0f, 2.0f, 0.0f);
	Brain.Set_Position(6, 0.0f, 3.0f, 0.0f);
	Brain.Set_Position(7, 2.0f, 3.0f, 0.0f);
	Brain.Set_Position(8, 2.0f, 4.0f, 0.0f);
	Brain.Set_Position(9, 4.0f, 4.0f, 0.0f);

	Brain.Init_Neuron(0, 1);
	Brain.Connect_With_ReceiverNeuron(0, 1, 0);

	Brain.Init_Neuron(1, 3);
	Brain.Connect_With_ReceiverNeuron(1, 0, 0);
	Brain.Connect_With_ReceiverNeuron(1, 4, 1);
	Brain.Connect_With_ReceiverNeuron(1, 2, 2);

	Brain.Init_Neuron(2, 3);
	Brain.Connect_With_ReceiverNeuron(2, 1, 0);
	Brain.Connect_With_ReceiverNeuron(2, 3, 1);
	Brain.Connect_With_ReceiverNeuron(2, 5, 2);

	//Brain.Set_ConnectionWeight(2, 5, 0.0025f);

	Brain.Init_Neuron(3, 2);
	Brain.Connect_With_ReceiverNeuron(3, 2, 0);
	Brain.Connect_With_ReceiverNeuron(3, 5, 1);

	Brain.Init_Neuron(4, 2);
	Brain.Connect_With_ReceiverNeuron(4, 1, 0);
	Brain.Connect_With_ReceiverNeuron(4, 6, 1);

	Brain.Init_Neuron(5, 3);
	Brain.Connect_With_ReceiverNeuron(5, 2, 0);
	Brain.Connect_With_ReceiverNeuron(5, 3, 1);
	Brain.Connect_With_ReceiverNeuron(5, 7, 2);

	Brain.Init_Neuron(6, 1);
	Brain.Connect_With_ReceiverNeuron(6, 4, 0);

	Brain.Init_Neuron(7, 3);
	Brain.Connect_With_ReceiverNeuron(7, 8, 0);
	Brain.Connect_With_ReceiverNeuron(7, 5, 1);
	Brain.Connect_With_ReceiverNeuron(7, 9, 2);

	Brain.Init_Neuron(8, 2);
	Brain.Connect_With_ReceiverNeuron(8, 7, 0);
	Brain.Connect_With_ReceiverNeuron(8, 9, 1);

	Brain.Init_Neuron(9, 2);
	Brain.Connect_With_ReceiverNeuron(9, 8, 0);
	Brain.Connect_With_ReceiverNeuron(9, 7, 1);

	
	Brain.Calculate_ConnectionDistanceFactors(2);
	
	int32_t IDofFirstNeuron = 6;
	int32_t IDofLastNeuron = 9;


	

	Brain.Prepare_Training();

	
	for (int32_t i = 0; i < 200; i++)
		Brain.Train_NeuralNet_PathFinding(IDofFirstNeuron, IDofLastNeuron, 1.0f, 0.1f, 0.0f, false);

	// Output Path:

	int32_t pathArray[20];
	int32_t numPathElements;

	Brain.Get_Path(pathArray, &numPathElements, 20, IDofFirstNeuron, IDofLastNeuron);

	cout << Brain.Get_Path_Length(pathArray, numPathElements) << endl;

	for(int32_t i = 0; i < numPathElements; i++)
		cout << pathArray[i] << " ";


	getchar();
	return 0;
}
*/

// Pathfinding (Routenplanung) - Teil 2:

/*
int main(void)
{
	// Visualisierung der einzelnen St�dte:

	static char SurfaceMap[NumSurfaceMapElements];

	Init_SurfaceMap(SurfaceMap, '*');

	Set_SurfaceMapData(SurfaceMap, 0, 0, '0');
	Set_SurfaceMapData(SurfaceMap, 1, 1, '1');
	Set_SurfaceMapData(SurfaceMap, 3, 1, '2');
	Set_SurfaceMapData(SurfaceMap, 4, 1, '3');
	Set_SurfaceMapData(SurfaceMap, 0, 2, '4');
	Set_SurfaceMapData(SurfaceMap, 3, 2, '5');
	Set_SurfaceMapData(SurfaceMap, 0, 3, '6');
	Set_SurfaceMapData(SurfaceMap, 2, 3, '7');
	Set_SurfaceMapData(SurfaceMap, 2, 4, '8');
	Set_SurfaceMapData(SurfaceMap, 4, 4, '9');

	Output_SurfaceMapData(SurfaceMap);

	// Visualisierung der einzelnen St�dte abgeschlossen

	C3DNeuralMap Brain;
	Brain.Initialize_FullyConnected_NeuralNet(NumNeurons_PathFinding); // <= NumCities_PathFinding

	Brain.Set_Position(0, 0.0f, 0.0f, 0.0f);
	Brain.Set_Position(1, 1.0f, 1.0f, 0.0f);
	Brain.Set_Position(2, 3.0f, 1.0f, 0.0f);
	Brain.Set_Position(3, 4.0f, 1.0f, 0.0f);
	Brain.Set_Position(4, 0.0f, 2.0f, 0.0f);
	Brain.Set_Position(5, 3.0f, 2.0f, 0.0f);
	Brain.Set_Position(6, 0.0f, 3.0f, 0.0f);
	Brain.Set_Position(7, 2.0f, 3.0f, 0.0f);
	Brain.Set_Position(8, 2.0f, 4.0f, 0.0f);
	Brain.Set_Position(9, 4.0f, 4.0f, 0.0f);

	// einige Wege nachezu unpassierbar machen:
	Brain.Set_ConnectionWeight(6, 9, 0.0025f);
	Brain.Set_ConnectionWeight(6, 8, 0.0025f);
	Brain.Set_ConnectionWeight(6, 7, 0.0025f);

	Brain.Calculate_ConnectionDistanceFactors(2);


	int32_t IDofFirstNeuron = 6;
	int32_t IDofLastNeuron = 9;

	Brain.Prepare_Training();
	
	for (int32_t i = 0; i < 100; i++)
		Brain.Train_NeuralNet_PathFinding(IDofFirstNeuron, IDofLastNeuron, 1.0f, 100.0f, 0.0f, true);
	


	// Output Path:

	int32_t pathArray[20];
	int32_t numPathElements;

	Brain.Get_Path(pathArray, &numPathElements, 20, IDofFirstNeuron, IDofLastNeuron);
	
	cout << Brain.Get_Path_Length(pathArray, numPathElements) << endl;

	for (int32_t i = 0; i < numPathElements; i++)
		cout << pathArray[i] << " ";


	getchar();
	return 0;
}
*/



