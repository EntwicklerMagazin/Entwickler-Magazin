// Schutz vor Mehrfachdeklarationen :

#ifndef _Graph_H_
#define _Graph_H_

#pragma warning( disable: 4996)

#include <iostream>
#include <fstream>
#include "LogFile.h"
#include "RandomNumbers.h"
#include "MemoryManagement.h"


#ifndef max
#define max(a,b)    ( ((a) > (b)) ? (a) : (b) )
#endif

#ifndef min
#define min(a,b)    ( ((a) < (b)) ? (a) : (b) )
#endif



static constexpr float fConstPI = 3.14159f;
static constexpr float fConst2PI = 2.0f * fConstPI;


class CWeightMatrix
{
public:

	int32_t SizeX = 0;
	int32_t SizeY = 0;
	int32_t Size = 0;

	float *pWeightArray = nullptr;

	CWeightMatrix();
	~CWeightMatrix();

	// Kopierkonstruktor l�schen:
	CWeightMatrix(const CWeightMatrix  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CWeightMatrix & operator=(const CWeightMatrix  &originalObject) = delete;

	void Init_Matrix(int32_t sizeX, int32_t sizeY, float initalWeight);

	float Get_Weight(int32_t ix, int32_t iy);
	void Set_Weight(int32_t ix, int32_t iy, float weight);
};

class CGraphNode
{
public:

	CGraphNode *pUsedNodeArray = nullptr;

	float PosX = 0.0f;
	float PosY = 0.0f;
	float PosZ = 0.0f;

	CGraphNode();
	~CGraphNode();

	// Kopierkonstruktor l�schen:
	CGraphNode(const CGraphNode  &originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CGraphNode & operator=(const CGraphNode  &originalObject) = delete;

	void Connect_With_Graph(CGraphNode *pNodeArray);

	void Set_Position(float x, float y, float z);

	float Get_Distance_to_Other_Node(int32_t nodeID);
	float Get_InvDistance_to_Other_Node(int32_t nodeID);
	float Get_DistanceSq_to_Other_Node(int32_t nodeID);
	float Get_InvDistanceSq_to_Other_Node(int32_t nodeID);

	float Get_2DimDistance_to_Other_Node(int32_t nodeID);
	float Get_Inv2DimDistance_to_Other_Node(int32_t nodeID);
	float Get_2DimDistanceSq_to_Other_Node(int32_t nodeID);
	float Get_Inv2DimDistanceSq_to_Other_Node(int32_t nodeID);


	float Calculate_PathDistSq(int32_t *pPathArray, int32_t numNodes);
	float Calculate_PathDistSq(float *pPathArray, int32_t numNodes);

	float Calculate_PathDist(int32_t *pPathArray, int32_t numNodes);
	float Calculate_PathDist(float *pPathArray, int32_t numNodes);

	float Calculate_WeightedPathDistSq(int32_t *pPathArray, float *pWeightArray, int32_t numNodes);
	float Calculate_WeightedPathDistSq(float *pPathArray, float *pWeightArray, int32_t numNodes);

	float Calculate_WeightedPathDistSq(int32_t *pPathArray, CWeightMatrix *pWeightMatrix, int32_t numNodes);
	float Calculate_WeightedPathDistSq(float *pPathArray, CWeightMatrix *pWeightMatrix, int32_t numNodes);


	float Calculate_WeightedPathDist(int32_t *pPathArray, float *pWeightArray, int32_t numNodes);
	float Calculate_WeightedPathDist(float *pPathArray, float *pWeightArray, int32_t numNodes);

	float Calculate_WeightedPathDist(int32_t *pPathArray, CWeightMatrix *pWeightMatrix, int32_t numNodes);
	float Calculate_WeightedPathDist(float *pPathArray, CWeightMatrix *pWeightMatrix, int32_t numNodes);
};

void Rearrange_TSP_Path(float *pOutPathArray, float *pInPathArray, int32_t arraySize, float iDofFirstAndLastWaypoint);
void Rearrange_TSP_Path(int32_t *pOutPathArray, int32_t *pInPathArray, int32_t arraySize, int32_t iDofFirstAndLastWaypoint);
void Rearrange_TSP_Path(int32_t *pOutPathArray, float *pInPathArray, int32_t arraySize, float iDofFirstAndLastWaypoint);


class CGeneralNode
{
public:

	float PosX1 = 0.0f;
	float PosX2 = 0.0f;
	float PosX3 = 0.0f;

	int32_t NumOfAdjacentNodesMax = 0;
	int32_t NumOfAdjacentNodes = 0;

	int32_t *pAdjacentNodeIDArray = nullptr;
	int32_t *pAdjacentNodeMemoryArray = nullptr;

	int32_t NumOfNodes = 0;
	CGeneralNode *pUsedNodeArray = nullptr;

	int32_t NumOfFeatures = 0;
	float* pFeatureValueArray = nullptr;

	bool CompetitionModusEnabled = true;
	bool AdaptionModusEnabled = true;

	CGeneralNode();
	~CGeneralNode();

	// Kopierkonstruktor l�schen:
	CGeneralNode(const CGeneralNode& originalObject) = delete;
	// Zuweisungsoperator l�schen:
	CGeneralNode& operator=(const CGeneralNode& originalObject) = delete;

	void Init_FeatureValueArray(int32_t numOfFeatures);

	void Set_Features(float *pFeatureArray);
	void Get_Features(float *pOutFeatureArray);

	void Disable_CompetitionModus(void);
	void Enable_CompetitionModus(void);

	void Disable_AdaptionModus(void);
	void Enable_AdaptionModus(void);

	void Connect_With_NodeArray(CGeneralNode* pNodeArray, int32_t numOfNodes);

	void Set_Position(float x1);
	void Set_Position(float x1, float x2);
	void Set_Position(float x1, float x2, float x3);
	void Set_CircumferencePos(float angle, float radius);

	float Get_CircumferenceDistance_to_Other_Node(int32_t nodeID);
	float Get_CircumferenceDistanceSq_to_Other_Node(int32_t nodeID);

	float Get_3DimDistance_to_Other_Node(int32_t nodeID);
	float Get_2DimDistance_to_Other_Node(int32_t nodeID);
	float Get_1DimDistance_to_Other_Node(int32_t nodeID);

	float Get_3DimDistanceSq_to_Other_Node(int32_t nodeID);
	float Get_2DimDistanceSq_to_Other_Node(int32_t nodeID);
	float Get_1DimDistanceSq_to_Other_Node(int32_t nodeID);

	void Init_AdjacentNodes(int32_t numOfAdjacentNodesMax);
	bool Add_AdjacentNode(int32_t nodeID);
	bool Remove_AdjacentNode(int32_t nodeID);

	void Output_Init_AdjacentNodeIDs(void);

	int32_t Get_ListOfAdjacentNodeIDs(int32_t* pOutIDArray);

	float Calculate_FeatureDist(float* pInputArray);

	void Adapt_Features(float adaptionRate, float* pInputArray);

	void Adapt_Features_3DNodeSpace(int32_t idOfBestMatchingNode, float adaptionRate, float adaptionDistFactor, float* pInputArray);
	void Adapt_Features_3DNodeSpace(int32_t idOfBestMatchingNode, float adaptionRate, int32_t iterationCount, float adaptionIterationCountFactor, float adaptionDistFactor, float* pInputArray);

	void Adapt_Features_2DNodeSpace(int32_t idOfBestMatchingNode, float adaptionRate, float adaptionDistFactor, float* pInputArray);
	void Adapt_Features_2DNodeSpace(int32_t idOfBestMatchingNode, float adjustmentRate, int32_t iterationCount, float adaptionIterationCountFactor, float adaptionDistFactor, float* pInputArray);

	void Adapt_Features_1DNodeSpace(int32_t idOfBestMatchingNode, float adaptionRate, float adjustmentDistFactor, float* pInputArray);
	void Adapt_Features_1DNodeSpace(int32_t idOfBestMatchingNode, float adaptionRate, int32_t iterationCount, float adaptionRateIterationCountFactor, float adaptionDistFactor, float* pInputArray);

	void Adapt_Features_CircumferenceNodeSpace(int32_t idOfBestMatchingNode, float adaptionRate, float adaptionDistFactor, float* pInputArray);
	void Adapt_Features_CircumferenceNodeSpace(int32_t idOfBestMatchingNode, float adaptionRate, int32_t iterationCount, float adaptionIterationCountFactor, float adaptionDistFactor, float* pInputArray);

};

int32_t Get_IDOfBestMatchingNode(float* pInputArray, CGeneralNode* pNodeArray, int32_t numOfNodes);
int32_t Get_IDOfWorstMatchingNode(float* pInputArray, CGeneralNode* pNodeArray, int32_t numOfNodes);






#endif