#include "VirtualFile.h"

#pragma warning( disable: 4996)

namespace HelperStuff
{


#ifndef max
#define max(a,b)    ( ((a) > (b)) ? (a) : (b) )
#endif

#ifndef min
#define min(a,b)    ( ((a) < (b)) ? (a) : (b) )
#endif


using namespace std;

void CText::Init_Memory(uint32_t size)
{
	delete[] pData;
	pData = nullptr;

	Size = size;

	pData = new (std::nothrow) char[size];

	memset(pData, '\0', size * sizeof(char));
}

void CText::Reset(void)
{
	delete[] pData;
	pData = nullptr;
	Size = 0;
}

void CText::Connect_With_CharArray(char *pCharArray)
{
	delete[] pData;
	pData = nullptr;

	pData = pCharArray;
	Size = strlen(pCharArray) + 1;
}

void CText::Set_Text(const char *pText)
{
	delete[] pData;
	pData = nullptr;

	Size = strlen(pText) + 1;

	pData = new (std::nothrow) char[Size];

	strcpy(pData, pText);
}

uint32_t CText::Calculate_TextLength(void)
{
	Size = 0;

	if (pData != nullptr)
		Size = strlen(pData) + 1;

	return max(0, Size - 1);
}

uint32_t CText::Get_TextLength(void)
{
	return max(0, Size - 1);
}


std::ostream& operator << (std::ostream &rOut, CText &rText)
{
	uint32_t counter = 0;

	while (rText.pData[counter] != '\0')
	{
		rOut << rText.pData[counter];
		counter++;
	}

	return rOut;
}


void CMultipleTextStrings::Init_Strings(uint32_t numStrings, uint32_t size)
{
	delete[] pTextArray;
	pTextArray = nullptr;

	NumStrings = numStrings;

	pTextArray = new (std::nothrow) CText[numStrings];

	for (uint32_t i = 0; i < numStrings; i++)
		pTextArray[i].Init_Memory(size);
}

void CMultipleTextStrings::Reset(void)
{
	delete[] pTextArray;
	pTextArray = nullptr;
	NumStrings = 0;
}


char* ReadFile(const char *pFileName, bool ignoreLineBreaks)
{
	char *content = nullptr;

	int32_t count = 0;

	if (pFileName != nullptr)
	{
		// Textdatei �ffnen:
		FILE *fp = fopen(pFileName, "rt");

		if (fp != nullptr)
		{
			// Lesezeiger ans Dateiende setzen:
			fseek(fp, 0, SEEK_END);
			// Leseposition (=>Dateil�nge) ermitteln:
			count = ftell(fp);
			// Lesezeiger wieder auf Anfang setzen:
			rewind(fp);

			if (count > 0)
			{
				/* Speicher reservieren, um die Daten aus der Datei
				aufzunehmen: */
				content = new  (std::nothrow) char[count + 2];
				// Daten aus Datei auslesen:
				count = fread(content, sizeof(char), count, fp);
				content[count] = ' ';
				content[count + 1] = '\0';

			} // end if (count > 0)

			  // Datei schlie�en:
			fclose(fp);

		} // end if (fp != nullptr)

	} // if (pFileName != nullptr)
	

	if (content && ignoreLineBreaks == true)
	{
		count++;

		// Zeilenumbr�che entfernen:
		for (int32_t i = 0; i < count; i++)
		{
			if (content[i] == '\n')
				content[i] = ' ';
		}
	}

	
	return content;
}



char* ReadBinaryFile(const char *pFileName)
{
	char *content = nullptr;
	int32_t count = 0;

	

	if (pFileName != nullptr)
	{
		// Bin�rdatei �ffnen:
		FILE *fp = fopen(pFileName, "rb");

		if (fp != nullptr)
		{
			// Lesezeiger ans Dateiende setzen:
			fseek(fp, 0, SEEK_END);
			// Leseposition (=>Dateil�nge) ermitteln:
			count = ftell(fp);
			// Lesezeiger wieder auf Anfang setzen:
			rewind(fp);

			if (count > 0)
			{
				/* Speicher reservieren, um die Daten aus der Datei
				aufzunehmen: */
				content = new (std::nothrow) char[count + 2];
				// Daten aus Datei auslesen:
				count = fread(content, sizeof(char), count, fp);
				content[count] = ' ';
				content[count + 1] = '\0';

			} // end if (count > 0)

			  // Datei schlie�en:
			fclose(fp);

		} // end if (fp != nullptr)
	}

	return content;
}

void Read_SimpleTextString_FromFile(CText *pOutText, const char *pTextFile)
{
	/* Standardeinstellung: */
	setlocale(LC_ALL, "C");

	CText Text(ReadFile(pTextFile, false));

	//CText Text;
	//Text.Connect_With_CharArray(ReadFile(pTextFile, false));

	uint32_t textLength = Text.Get_TextLength() - 2; // 2 #-Zeichen werden ignoriert
	//uint32_t textLength = strlen(Text.pData) - 2; // 2 #-Zeichen werden ignoriert
	
	pOutText->Init_Memory(textLength + 1); // zust�tzliches '\0'-Zeichen am Ende der Zeichenkette 

	uint32_t counter = 0;

	for (uint32_t i = 0; i < textLength; i++)
	{
		if (Text.pData[i] != '#')
		{
			pOutText->pData[counter] = Text.pData[i];
			counter++;
		}
	}
}



void Read_MultipleTextString_FromFile(CMultipleTextStrings *pOutMultipleTextStrings, uint32_t *pOutNumOfStrings, const char *pTextFile, uint32_t maxCharactersPerString)
{
	/* Standardeinstellung: */
	setlocale(LC_ALL, "C");

	uint32_t maxCharactersPerStringPlus1 = maxCharactersPerString + 1;

	CText Text(ReadFile(pTextFile, false));

	//CText Text;
	//Text.pData = ReadFile(pTextFile, false);

	CVirtualFile FileData(Text.pData);

	char strBuffer[200];

	uint32_t numOfTextStrings;

	ReadFileData(&FileData, strBuffer, 200);
	ReadFileData(&FileData, &numOfTextStrings);

	if (numOfTextStrings == 1)
	{
		*pOutNumOfStrings = numOfTextStrings;

		pOutMultipleTextStrings->Init_Strings(numOfTextStrings, maxCharactersPerStringPlus1);

		char *pData = pOutMultipleTextStrings->pTextArray[0].pData;

		uint32_t textLength = Text.Get_TextLength();
		//uint32_t textLength = strlen(Text.pData);

		uint32_t counter = 0;

		bool textString = false;

		for (uint32_t i = 0; i < textLength; i++)
		{
			if (Text.pData[i] == '#' && textString == false)
				textString = true;
			else if (Text.pData[i] == '#' && textString == true)
				break;
			else if (textString == true)
			{
				if(counter < maxCharactersPerString)
					pData[counter] = Text.pData[i];

				counter++;
			}
		}
	}
	else if (numOfTextStrings > 1)
	{
		*pOutNumOfStrings = numOfTextStrings;

		pOutMultipleTextStrings->Init_Strings(numOfTextStrings, maxCharactersPerStringPlus1);

		char *pData = nullptr;

		uint32_t textLength = Text.Get_TextLength();
		//uint32_t textLength = strlen(Text.pData);

		uint32_t characterCounter = 0;
		uint32_t stringCounter = 0;

		bool textString = false;

		pData = pOutMultipleTextStrings->pTextArray[stringCounter].pData;

		for (uint32_t i = 0; i < textLength; i++)
		{
			if (Text.pData[i] == '#' && textString == false)
				textString = true;
			else if (Text.pData[i] == '#' && textString == true)
			{
				stringCounter++;

				if (stringCounter >= numOfTextStrings)
					break;

				textString = false;
				characterCounter = 0;

				pData = pOutMultipleTextStrings->pTextArray[stringCounter].pData;
			}
			else if (textString == true)
			{
				if (characterCounter < maxCharactersPerString)
					pData[characterCounter] = Text.pData[i];

				characterCounter++;
			}
		}

	}
}



////////////////

void ReadFileData_HexInstruction(CVirtualFile *pVirtualFile, uint8_t *pData)
{
	/* Instruktionen werden im folgenden hexadezimalen Format gespeichert:
	00
	01
	[...]
	4C   */

	char *ptr = pVirtualFile->ptr;


	do
	{
		if (*ptr != ' ')
		{
			uint8_t res = 0;


			if (ptr[0] < 58)
				res += (ptr[0] - 48) * 16;
			else
				res += (ptr[0] - 55) * 16;

			if (ptr[1] < 58)
				res += (ptr[1] - 48);
			else
				res += (ptr[1] - 55);

			*pData = res;

			break;
		}

		ptr++;

	} while (true);

	pVirtualFile->ptr = ptr + 2;
}

void ReadFileData_DecInstruction(CVirtualFile *pVirtualFile, uint8_t *pData)
{
	/* Instruktionen werden im folgenden dezimalen Format gespeichert:
	00
	01
	[...]
	76   */

	char *ptr = pVirtualFile->ptr;

	do
	{
		if (*ptr != ' ')
		{
			uint8_t res = (ptr[0] - 48) * 10;
			res += ptr[1] - 48;
			*pData = res;
			break;
		}

		ptr++;

	} while (true);

	pVirtualFile->ptr = ptr + 2;

}


void ReadFileData_1Byte(CVirtualFile *pVirtualFile, char *pData)
{

	char *ptr = pVirtualFile->ptr;


	do
	{
		if (*ptr != ' ')
		{
			*pData = *ptr;

			ptr++;
			break;
		}

		ptr++;

	} while (true);

	// go to next entry:
	do
	{
		if (*ptr == ' ')
			break;

		ptr++;

	} while (true);



	pVirtualFile->ptr = ptr + 1;

}

void ReadFileData_1Byte(CVirtualFile *pVirtualFile, int8_t *pData)
{

	char *ptr = pVirtualFile->ptr;


	do
	{
		if (*ptr != ' ')
		{
			*pData = (int8_t)atol(ptr);
			
			ptr++;
			break;
		}

		ptr++;

	} while (true);

	// go to next entry:
	do
	{
		if (*ptr == ' ')
			break;

		ptr++;

	} while (true);



	pVirtualFile->ptr = ptr + 1;

}

void ReadFileData_1Byte(CVirtualFile *pVirtualFile, uint8_t *pData)
{

	char *ptr = pVirtualFile->ptr;


	do
	{
		if (*ptr != ' ')
		{
			*pData = (uint8_t)atol(ptr);
		
			ptr++;
			break;
		}

		ptr++;

	} while (true);

	// go to next entry:
	do
	{
		if (*ptr == ' ')
			break;

		ptr++;

	} while (true);



	pVirtualFile->ptr = ptr + 1;

}


////////////////




void ReadFileData(CVirtualFile *pVirtualFile, char *pData, uint32_t length)
{
	int32_t firstchar = -1;
	int32_t i = 0;


	char *ptr = pVirtualFile->ptr;



	while (true)
	{
		if (i == length - 1)
			break;

		if (firstchar == -1)
		{
			if (*ptr != ' ')
				firstchar = i;
		}

		if (firstchar != -1)
		{
			if (*ptr == ' ')
				break;

			if (*ptr == '\n')
				break;



			sscanf(ptr, "%1s", pData + i - firstchar);
		}

		ptr++;
		i++;
	}

	pVirtualFile->ptr = ptr + 1;
}

void ReadFileData(CVirtualFile *pVirtualFile, unsigned char *pData, uint32_t length)
{
	int32_t firstchar = -1;
	int32_t i = 0;


	char *ptr = pVirtualFile->ptr;

	i = 0;

	while (true)
	{
		if (i == length - 1)
			break;

		if (firstchar == -1)
		{
			if (*ptr != ' ')
				firstchar = i;
		}

		if (firstchar != -1)
		{
			if (*ptr == ' ')
				break;

			if (*ptr == '\n')
				break;



			sscanf(ptr, "%hhu", pData + i - firstchar);
		}

		ptr++;
		i++;
	}

	pVirtualFile->ptr = ptr + 1;
}

void ReadFileData(CVirtualFile *pVirtualFile, int16_t *pData)
{

	char *ptr = pVirtualFile->ptr;


	do
	{
		if (*ptr != ' ')
		{
			*pData = (int16_t)atol(ptr);

			ptr++;
			break;
		}

		ptr++;

	} while (true);

	// go to next entry:
	do
	{
		if (*ptr == ' ')
			break;

		ptr++;

	} while (true);



	pVirtualFile->ptr = ptr + 1;

}

void ReadFileData(CVirtualFile *pVirtualFile, uint16_t *pData)
{

	char *ptr = pVirtualFile->ptr;


	do
	{
		if (*ptr != ' ')
		{
			*pData = (uint16_t)atol(ptr);

			ptr++;
			break;
		}

		ptr++;

	} while (true);

	// go to next entry:
	do
	{
		if (*ptr == ' ')
			break;

		ptr++;

	} while (true);



	pVirtualFile->ptr = ptr + 1;

}

void ReadFileData(CVirtualFile *pVirtualFile, long *pData)
{

	char *ptr = pVirtualFile->ptr;


	do
	{
		if (*ptr != ' ')
		{
			*pData = atol(ptr);

			ptr++;
			break;
		}

		ptr++;

	} while (true);

	// go to next entry:
	do
	{
		if (*ptr == ' ')
			break;

		ptr++;

	} while (true);



	pVirtualFile->ptr = ptr + 1;

}

/*void ReadFileData(CVirtualFile *pVirtualFile, BOOL *pData)
{

char *ptr = pVirtualFile->ptr;


do
{
if (*ptr != ' ')
{
*pData = atol(ptr);

ptr++;
break;
}

ptr++;


} while (true);

// go to next entry:
do
{
if (*ptr == ' ')
break;

ptr++;

} while (true);


pVirtualFile->ptr = ptr + 1;

}*/

void ReadFileData(CVirtualFile *pVirtualFile, int32_t *pData)
{

	char *ptr = pVirtualFile->ptr;



	do
	{
		if (*ptr != ' ')
		{
			*pData = (int32_t)atol(ptr);
			ptr++;
			break;
		}

		ptr++;

	} while (true);

	// go to next entry:
	do
	{
		if (*ptr == ' ')
			break;

		ptr++;

	} while (true);


	pVirtualFile->ptr = ptr + 1;

}

void ReadFileData(CVirtualFile *pVirtualFile, uint32_t *pData)
{

	char *ptr = pVirtualFile->ptr;

	do
	{
		if (*ptr != ' ')
		{
			*pData = (uint32_t)atol(ptr);

			ptr++;
			break;
		}

		ptr++;

	} while (true);

	// go to next entry:
	do
	{
		if (*ptr == ' ')
			break;

		ptr++;

	} while (true);


	pVirtualFile->ptr = ptr + 1;

}

void ReadFileData(CVirtualFile *pVirtualFile, float *pData)
{

	char *ptr = pVirtualFile->ptr;

	do
	{
		if (*ptr != ' ')
		{
			*pData = (float)atof(ptr);

			ptr++;
			break;
		}

		ptr++;

	} while (true);

	// go to next entry:
	do
	{
		if (*ptr == ' ')
			break;

		ptr++;

	} while (true);


	pVirtualFile->ptr = ptr + 1;

}

void ReadFileData(CVirtualFile *pVirtualFile, double *pData)
{

	char *ptr = pVirtualFile->ptr;

	do
	{
		if (*ptr != ' ')
		{
			*pData = atof(ptr);

			ptr++;
			break;
		}

		ptr++;

	} while (true);

	// go to next entry:
	do
	{
		if (*ptr == ' ')
			break;

		ptr++;

	} while (true);


	pVirtualFile->ptr = ptr + 1;

}

void ReadFileDataBin(CVirtualFile *pVirtualFile, long *pData)
{
	char *ptr = pVirtualFile->ptr;


	memcpy(pData, ptr, 4);

	pVirtualFile->ptr = ptr + 4;
}

void ReadFileDataBin(CVirtualFile *pVirtualFile, int16_t *pData)
{
	char *ptr = pVirtualFile->ptr;


	memcpy(pData, ptr, 2);

	pVirtualFile->ptr = ptr + 2;
}

void ReadFileDataBin_1Byte(CVirtualFile *pVirtualFile, char *pData)
{
	char *ptr = pVirtualFile->ptr;

	*pData = *ptr;
	//memcpy(pData, ptr, 1);

	pVirtualFile->ptr = ptr + 1;
}

void ReadFileDataBin_1Byte(CVirtualFile *pVirtualFile, int8_t *pData)
{
	char *ptr = pVirtualFile->ptr;


	memcpy(pData, ptr, 1);

	pVirtualFile->ptr = ptr + 1;
}

void ReadFileDataBin_1Byte(CVirtualFile *pVirtualFile, uint8_t *pData)
{
	char *ptr = pVirtualFile->ptr;


	memcpy(pData, ptr, 1);

	pVirtualFile->ptr = ptr + 1;
}


void ReadFileDataBin(CVirtualFile *pVirtualFile, uint16_t *pData)
{
	char *ptr = pVirtualFile->ptr;


	memcpy(pData, ptr, 2);

	pVirtualFile->ptr = ptr + 2;
}

/*void ReadFileDataBin(CVirtualFile *pVirtualFile, BOOL *pData)
{
char *ptr = pVirtualFile->ptr;


memcpy(pData, ptr, sizeof(BOOL));

pVirtualFile->ptr = ptr + sizeof(BOOL);
}*/

void ReadFileDataBin(CVirtualFile *pVirtualFile, int32_t *pData)
{
	char *ptr = pVirtualFile->ptr;


	memcpy(pData, ptr, sizeof(int32_t));

	pVirtualFile->ptr = ptr + sizeof(int32_t);
}

void ReadFileDataBin(CVirtualFile *pVirtualFile, uint32_t *pData)
{
	char *ptr = pVirtualFile->ptr;


	memcpy(pData, ptr, sizeof(uint32_t));

	pVirtualFile->ptr = ptr + sizeof(uint32_t);
}

void ReadFileDataBin(CVirtualFile *pVirtualFile, char *pData, uint32_t length)
{
	char *ptr = pVirtualFile->ptr;

	memcpy(pData, ptr, length);

	pVirtualFile->ptr = ptr + length;
}

void ReadFileDataBin(CVirtualFile *pVirtualFile, unsigned char *pData, uint32_t length)
{
	char *ptr = pVirtualFile->ptr;

	memcpy(pData, ptr, length);

	pVirtualFile->ptr = ptr + length;
}

void ReadFileDataBin(CVirtualFile *pVirtualFile, float *pData)
{
	char *ptr = pVirtualFile->ptr;

	memcpy(pData, ptr, 4);

	pVirtualFile->ptr = ptr + 4;
}

void ReadFileDataBin(CVirtualFile *pVirtualFile, double *pData)
{
	char *ptr = pVirtualFile->ptr;

	memcpy(pData, ptr, 8);

	pVirtualFile->ptr = ptr + 8;
}


} /* end of namespace HelperStuff */
