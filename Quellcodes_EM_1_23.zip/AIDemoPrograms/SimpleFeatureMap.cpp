#include "SimpleFeatureMap.h"

using namespace std;
using namespace HelperStuff;

CSimpleFeatureMap::CSimpleFeatureMap()
{}

CSimpleFeatureMap::~CSimpleFeatureMap()
{
	delete[] pDataArray;
	pDataArray = nullptr;
}


void CSimpleFeatureMap::Clone_Values(CSimpleFeatureMap *pOriginalObject)
{
	for (int32_t i = 0; i < Size; i++)
	{
		pDataArray[i] = pOriginalObject->pDataArray[i];
	}
}

void CSimpleFeatureMap::Clone_Values_OMP(CSimpleFeatureMap *pOriginalObject)
{
#pragma omp parallel for num_threads(2)
	for (int32_t i = 0; i < Size; i++)
	{
		pDataArray[i] = pOriginalObject->pDataArray[i];
	}
}

void CSimpleFeatureMap::Clone_Values_OMP_AllThreads(CSimpleFeatureMap *pOriginalObject)
{
#pragma omp parallel for
	for (int32_t i = 0; i < Size; i++)
	{
		pDataArray[i] = pOriginalObject->pDataArray[i];
	}
}

void CSimpleFeatureMap::Reset_Values(float value)
{
	for (int32_t i = 0; i < Size; i++)
	{
		pDataArray[i] = value;
	}
}

void CSimpleFeatureMap::Init_Map(int32_t size)
{
	if (size > Size)
	{
		delete[] pDataArray;
		pDataArray = nullptr;

		pDataArray = new (std::nothrow) float[size];
	}

	Size = size;
	SizeX = 0;
	SizeY = 0;

	for (int32_t i = 0; i < size; i++)
	{
		pDataArray[i] = 0.0f;
	}
}

void CSimpleFeatureMap::Init_Map(int32_t sizeX, int32_t sizeY)
{
	int32_t size = sizeX * sizeY;

	if (size > Size)
	{
		delete[] pDataArray;
		pDataArray = nullptr;

		pDataArray = new (std::nothrow) float[size];
	}

	Size = size;
	SizeX = sizeX;
	SizeY = sizeY;

	for (int32_t i = 0; i < size; i++)
	{
		pDataArray[i] = 0.0f;
	}
}

void CSimpleFeatureMap::Apply_ReLU_Activation(void)
{
	for (int32_t i = 0; i < Size; i++)
	{
		pDataArray[i] = max(0.0f, pDataArray[i]);
	}
}

void CSimpleFeatureMap::Apply_TanH_Activation(void)
{
	for (int32_t i = 0; i < Size; i++)
	{
		pDataArray[i] = tanh(pDataArray[i]);
	}
}

void CSimpleFeatureMap::Apply_FastTanHReplacement_Activation(void)
{
	float tempValue;

	for (int32_t i = 0; i < Size; i++)
	{
		tempValue = pDataArray[i];
		pDataArray[i] = tempValue / (1.0f + abs(tempValue));
	}
}

void CSimpleFeatureMap::Apply_Sigmoid_Activation(void)
{
	for (int32_t i = 0; i < Size; i++)
	{
		pDataArray[i] = 1.0f / (1.0f + exp(-pDataArray[i]));
	}
}

void CSimpleFeatureMap::Apply_LeakyReLU_Activation(float leakingValue)
{
	float tempValue;

	for (int32_t i = 0; i < Size; i++)
	{
		tempValue = pDataArray[i];

		if (tempValue < 0.0f)
			pDataArray[i] = leakingValue * tempValue;
		else
			pDataArray[i] = tempValue;
	}
}

void CSimpleFeatureMap::Get_FeaturePositions(float *pOutFeaturePosIDArray, int32_t numFeaturePositionsMax, float minFeatureValue)
{
	int32_t featurePositionCounter = 0;

	for (int32_t i = 0; i < Size; i++)
	{
		if (pDataArray[i] > minFeatureValue)
		{
			pOutFeaturePosIDArray[featurePositionCounter] = static_cast<float>(i);
			featurePositionCounter++;

			if (featurePositionCounter >= numFeaturePositionsMax)
				return;
		}
	}
}

void CSimpleFeatureMap::Get_FeaturePositions(int32_t *pOutFeaturePosIDArray, int32_t numFeaturePositionsMax, float minFeatureValue)
{
	int32_t featurePositionCounter = 0;

	for (int32_t i = 0; i < Size; i++)
	{
		if (pDataArray[i] > minFeatureValue)
		{
			pOutFeaturePosIDArray[featurePositionCounter] = i;
			featurePositionCounter++;

			if (featurePositionCounter >= numFeaturePositionsMax)
				return;
		}
	}
}

void CSimpleFeatureMap::Get_FeaturePositions(float *pOutFeaturePosXArray, float *pOutFeaturePosYArray, int32_t numFeaturePositionsMax, float minFeatureValue)
{
	int32_t featurePositionCounter = 0;

	for (int32_t iy = 0; iy < SizeY; iy++)
	{
		int32_t iiy = iy * SizeX;

		for (int32_t ix = 0; ix < SizeX; ix++)
		{
			if (pDataArray[ix + iiy] > minFeatureValue)
			{
				pOutFeaturePosXArray[featurePositionCounter] = static_cast<float>(ix);
				pOutFeaturePosYArray[featurePositionCounter] = static_cast<float>(iy);

				featurePositionCounter++;

				if (featurePositionCounter >= numFeaturePositionsMax)
					return;
			}
		}
	}
}

void CSimpleFeatureMap::Get_FeaturePositions(int32_t *pOutFeaturePosXArray, int32_t *pOutFeaturePosYArray, int32_t numFeaturePositionsMax, float minFeatureValue)
{
	int32_t featurePositionCounter = 0;

	for (int32_t iy = 0; iy < SizeY; iy++)
	{
		int32_t iiy = iy * SizeX;

		for (int32_t ix = 0; ix < SizeX; ix++)
		{
			if (pDataArray[ix + iiy] > minFeatureValue)
			{
				pOutFeaturePosXArray[featurePositionCounter] = ix;
				pOutFeaturePosYArray[featurePositionCounter] = iy;

				featurePositionCounter++;

				if (featurePositionCounter >= numFeaturePositionsMax)
					return;
			}
		}
	}
}